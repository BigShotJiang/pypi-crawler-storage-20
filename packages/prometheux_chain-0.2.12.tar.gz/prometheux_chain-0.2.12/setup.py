import os
from setuptools import setup, find_packages

# Read version from version.txt
with open("version.txt", "r") as f:
    version = f.read().strip()
    
# Get the directory where setup.py is located
this_directory = os.path.abspath(os.path.dirname(__file__))

# Read the contents of ReadMe.md
with open(os.path.join(this_directory, 'ReadMe.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name="prometheux_chain",
    version=version,
    packages=find_packages(),
    install_requires=[
        "requests",
        "pyyaml",
    ],
    package_data={
        'prometheux_chain': ['config.yaml'],
    },
    include_package_data=True,
    author='Prometheux Limited',
    author_email='davben@prometheux.co.uk',
    description='Prometheux chain is a Python SDK designed to build, evolve and deploy your new knowledge graphs.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/prometheuxresearch/prometheux_chain',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    python_requires='>=3.9',
    license='BSD-3-Clause',
)
