from yta_math_easings.abstract import EasingFunction
from yta_math_easings.enums import EasingFunctionName


class LinearEasing(EasingFunction):
    """
    A linear easing function.

    The formula:
    - `t_normalized`
    """
    name: str = EasingFunctionName.LINEAR.value

    def _ease(
        self,
        t_normalized: float
    ) -> float:
        return t_normalized
    
