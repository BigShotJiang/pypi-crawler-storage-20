from yta_math_easings.abstract import EasingFunction
from yta_math_easings.enums import EasingFunctionName

import numpy as np


class SlowIntoEasing(EasingFunction):
    """
    A slow into easing function.

    The formula:
    - `np.sqrt(1 - (1 - t_normalized) * (1 - t_normalized))`
    """
    name: str = EasingFunctionName.SLOW_INTO.value

    def _ease(
        self,
        t_normalized: float
    ) -> float:
        return np.sqrt(1 - (1 - t_normalized) * (1 - t_normalized))