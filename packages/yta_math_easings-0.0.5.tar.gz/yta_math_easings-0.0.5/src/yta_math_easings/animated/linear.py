from yta_math_easings.animated.abstract import EasingAnimatedFunction
from yta_math_easings.enums import EasingFunctionName
from yta_math_easings.linear import LinearEasing


class LinearAnimatedEasing(EasingAnimatedFunction):
    """
    A linear function but animated, including a
    range of values and a duration.

    The formula:
    - `t_normalized`
    """
    name: str = EasingFunctionName.LINEAR.value
    may_overshoot: bool = False

    def __init__(
        self,
        start_value: float,
        end_value: float,
        duration: float
    ):
        super().__init__(
            start_value = start_value,
            end_value = end_value,
            duration = duration,
            easing_function = LinearEasing()
        )