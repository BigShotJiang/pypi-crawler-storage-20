"""
Module to hold the easing functions but using
start and end values and a time duration.
"""
from yta_math_easings.animated.linear import LinearAnimatedEasing
from yta_math_easings.animated.slow_into import SlowIntoAnimatedEasing


__all__ = [
    'LinearAnimatedEasing',
    'SlowIntoAnimatedEasing'
]