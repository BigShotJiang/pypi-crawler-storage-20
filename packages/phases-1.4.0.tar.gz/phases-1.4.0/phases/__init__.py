__version__ = "v1.4.0"

from phases.commands.run import Run
from .DefaultProject import DefaultProject


loadProject = Run.loadProject
