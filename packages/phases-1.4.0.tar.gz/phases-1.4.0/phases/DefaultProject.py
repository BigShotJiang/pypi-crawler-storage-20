from pyPhases import pdict
from .commands.run import Run


class DefaultProject:
  
  @staticmethod
  def create(configFiles=None, plugins=""):
    config = pdict()
    config["name"] = "myProject"
    config["plugins"] = ["SleePyPhases"]
    config["config"] = pdict()

    phasesRun = Run({})
    if configFiles != "":
      phasesRun.projectConfigFileName = configFiles
    
    phasesRun.prepareConfig()

    return phasesRun.createProjectFromConfig(phasesRun.config)
    