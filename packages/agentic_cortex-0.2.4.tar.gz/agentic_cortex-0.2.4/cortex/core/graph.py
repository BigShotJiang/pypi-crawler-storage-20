"""Graph query engine for dependency analysis and context injection.

This module implements the GraphQuery class for:
- Upstream dependency analysis (who calls this function)
- Context injection for semantic anchoring by file
"""

import logging
import sqlite3
from typing import List, Dict, Optional
from pathlib import Path

from cortex.vector.store import VectorStore

logger = logging.getLogger(__name__)


class GraphQuery:
    """Graph query engine for dependency analysis and context injection.
    
    Provides methods for:
    - Upstream analysis: Find who calls a specific function (up to depth 2)
    - Context injection: Get relevant memories for symbols in a file
    """

    def __init__(self, conn: sqlite3.Connection):
        """Initialize graph query engine.
        
        Args:
            conn: SQLite database connection
        """
        self.conn = conn

    def get_upstream(self, symbol_id: str, depth: int = 2) -> List[str]:
        """Find upstream callers (who calls this function).
        
        Per spec: Traverses the graph backwards from the target symbol
        to find all symbols that call it, up to the specified depth.
        
        Args:
            symbol_id: Symbol ID to find callers for
            depth: Maximum traversal depth (default: 2 per spec)
            
        Returns:
            List of symbol IDs that call the given symbol (upstream callers)
            
        Note:
            Uses recursive CTE to traverse edges backwards:
            - Base case: edges where target_id = symbol_id (direct callers)
            - Recursive case: edges where target_id matches previous source_id
        """
        cursor = self.conn.cursor()
        
        # Build recursive CTE query per spec
        # Finds upstream callers: edges where target_id matches our symbol
        query = """
            WITH RECURSIVE callers(source_id, target_id, depth) AS (
                -- Base case: direct callers (depth 1)
                SELECT source_id, target_id, 1
                FROM edges
                WHERE target_id = ?
                
                UNION ALL
                
                -- Recursive case: callers of callers
                SELECT e.source_id, e.target_id, c.depth + 1
                FROM edges e
                JOIN callers c ON e.target_id = c.source_id
                WHERE c.depth < ?
            )
            SELECT DISTINCT source_id FROM callers
        """
        
        cursor.execute(query, (symbol_id, depth))
        rows = cursor.fetchall()
        
        # Extract symbol IDs
        caller_ids = [row[0] for row in rows]
        
        return caller_ids

    def get_context_memories(
        self, file_path: str, store: VectorStore, limit: int = 3
    ) -> List[Dict[str, any]]:
        """Get context memories (semantic anchoring) for symbols in a file.
        
        Per spec: When opening a file, find relevant "tribal knowledge" by:
        1. Identifying all Symbol IDs in the file
        2. Querying LanceDB for items where 'anchor_symbol_id' matches any of these IDs
        3. Returning top 3 most recent/relevant notes
        
        Args:
            file_path: File path to get context memories for
            store: VectorStore instance
            limit: Maximum number of memories to return (default: 3 per spec)
            
        Returns:
            List of dictionaries with memory content and metadata
            Each dict contains: 'anchor_symbol_id', 'text_content', 'created_at', etc.
        """
        cursor = self.conn.cursor()
        
        # Step 1: Get all Symbol IDs for symbols in the file
        cursor.execute("SELECT id FROM symbols WHERE file_path = ?", (file_path,))
        rows = cursor.fetchall()
        symbol_ids = [row[0] for row in rows]
        
        if not symbol_ids:
            return []
        
        # Step 2: Query LanceDB for memories anchored to any of these symbol IDs
        # Query vector store table directly to find all memories for these symbols
        all_memories = []
        
        try:
            # Get the table from store
            table = store.table
            
            # Query all records and filter by anchor_symbol_id
            # LanceDB supports filtering via .where() or we can use to_table() and filter in Python
            try:
                # Get all data from table
                all_data = table.to_table()
                
                if len(all_data) > 0:
                    # Convert to Python lists for filtering
                    anchor_ids = all_data["anchor_symbol_id"].to_pylist()
                    text_contents = all_data["text_content"].to_pylist()
                    created_ats_list = all_data["created_at"]
                    
                    # Filter memories that match any of our symbol IDs
                    symbol_ids_set = set(symbol_ids)
                    for idx, anchor_id in enumerate(anchor_ids):
                        if anchor_id in symbol_ids_set:
                            # Extract this memory
                            text_content = text_contents[idx] if idx < len(text_contents) else ""
                            
                            # Handle created_at timestamp
                            created_at = None
                            try:
                                if hasattr(created_ats_list, '__getitem__'):
                                    created_at_val = created_ats_list[idx]
                                    # Convert PyArrow timestamp to datetime if needed
                                    if hasattr(created_at_val, 'as_py'):
                                        created_at = created_at_val.as_py()
                                    elif hasattr(created_at_val, 'value'):
                                        # Nanosecond timestamp
                                        ns = created_at_val.value
                                        from datetime import datetime
                                        created_at = datetime.fromtimestamp(ns / 1e9)
                                    else:
                                        created_at = created_at_val
                            except (AttributeError, TypeError, ValueError):
                                # Timestamp conversion can fail on various data formats
                                pass
                            
                            memory = {
                                "anchor_symbol_id": anchor_id,
                                "text_content": text_content,
                                "created_at": created_at,
                            }
                            all_memories.append(memory)
            except (AttributeError, KeyError, IndexError):
                # Table data access failures - return empty list as fallback
                pass
        except (AttributeError, OSError):
            # Store or table access failures - return empty list as fallback
            pass
        
        # Step 3: Return top limit most recent/relevant notes
        # Sort by created_at (most recent first) if available
        try:
            all_memories.sort(
                key=lambda x: x.get("created_at") or 0,
                reverse=True  # Most recent first
            )
        except (TypeError, ValueError):
            # Sorting can fail on incompatible types - keep original order
            pass
        
        return all_memories[:limit]
