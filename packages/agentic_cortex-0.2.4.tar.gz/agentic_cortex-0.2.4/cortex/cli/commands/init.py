"""CLI command for 'cortex init'."""

import json
import shutil
from pathlib import Path
import yaml
import fnmatch

from cortex.config import generate_default_config, get_db_paths
from cortex.db import initialize_db, initialize_lancedb


def init_command(project_root: Path, force: bool = False) -> None:
    """Initialize a Cortex project.

    Creates .cortex/ directory structure, initializes databases, copies language files,
    writes config.yaml, updates .gitignore, and triggers initial codebase scan.

    Args:
        project_root: Path to project root directory
        force: If True, overwrite existing .cortex/ directory
    """
    project_root = Path(project_root).resolve()
    cortex_dir = project_root / ".cortex"

    # Check if .cortex/ already exists
    if cortex_dir.exists():
        if not force:
            raise FileExistsError(
                f".cortex/ directory already exists at {cortex_dir}. Use --force to overwrite."
            )
        # Remove existing directory if force=True
        shutil.rmtree(cortex_dir)

    # Create directory structure
    print("Creating .cortex/ directory structure...", flush=True)
    cortex_dir.mkdir(parents=True, exist_ok=True)
    languages_dir = cortex_dir / "languages"
    languages_dir.mkdir(parents=True, exist_ok=True)
    logs_dir = cortex_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    # Generate default config
    config = generate_default_config(project_root)

    # Get database paths from config
    sqlite_path, lancedb_path = get_db_paths(config, cortex_dir)

    # Initialize SQLite database
    print("Initializing databases...", flush=True)
    conn = initialize_db(str(sqlite_path), check_same_thread=False)
    conn.close()

    # Initialize LanceDB
    initialize_lancedb(str(lancedb_path))

    # Copy language YAML files from package to .cortex/languages/
    package_languages_dir = Path(__file__).parent.parent.parent / "data" / "languages"
    for yaml_file in package_languages_dir.glob("*.yaml"):
        dest_file = languages_dir / yaml_file.name
        shutil.copy2(yaml_file, dest_file)

    # Write config.yaml
    config_file = cortex_dir / "config.yaml"
    with open(config_file, "w") as f:
        # Convert config to dict for YAML serialization
        config_dict = {
            "project": {
                "name": config.project.name,
                "roots": config.project.roots,
            },
            "files": {
                "include": config.files.include,
                "exclude": config.files.exclude,
            },
            "database": {
                "sqlite_path": config.database.sqlite_path,
                "lancedb_path": config.database.lancedb_path,
            },
        }
        yaml.dump(config_dict, f, default_flow_style=False, sort_keys=False)

    # Update .gitignore
    gitignore_path = project_root / ".gitignore"
    gitignore_content = ""
    if gitignore_path.exists():
        gitignore_content = gitignore_path.read_text()

    # Add .cortex/ if not already present
    if ".cortex/" not in gitignore_content:
        if gitignore_content and not gitignore_content.endswith("\n"):
            gitignore_content += "\n"
        gitignore_content += ".cortex/\n"
        gitignore_path.write_text(gitignore_content)

    # Trigger initial codebase scan
    print("Scanning codebase...", flush=True)
    file_count = _scan_codebase(project_root, config, sqlite_path)
    print(f"  Parsed {file_count} files", flush=True)

    # Index symbols into vector store
    print("Generating embeddings (this may take a moment)...", flush=True)
    symbol_count = _index_symbols(sqlite_path, lancedb_path)
    print(f"  Indexed {symbol_count} symbols", flush=True)

    # Create/update .mcp.json for Claude Code integration
    print("Configuring MCP server...", flush=True)
    _setup_mcp_config(project_root)


def _scan_codebase(project_root: Path, config, db_path: Path) -> int:
    """Scan codebase and parse files to extract symbols.

    Args:
        project_root: Project root directory
        config: Config object with file patterns
        db_path: Path to SQLite database

    Returns:
        Number of files parsed
    """
    import sqlite3
    from cortex.parser.registry import LanguageRegistry
    from cortex.watcher.sync import sync_file

    # Initialize language registry from .cortex/languages/
    languages_dir = project_root / ".cortex" / "languages"
    registry = LanguageRegistry(languages_dir)
    registry.load_languages()

    # Get database connection
    conn = sqlite3.connect(str(db_path), check_same_thread=False)

    # Find all files matching include/exclude patterns
    files_to_scan = []
    for root_pattern in config.project.roots:
        # Resolve root pattern relative to project root
        if root_pattern == ".":
            root_dir = project_root
        else:
            root_dir = project_root / root_pattern

        if not root_dir.exists():
            continue

        # Walk directory tree
        for file_path in root_dir.rglob("*"):
            if not file_path.is_file():
                continue

            # Convert to relative path from project_root
            try:
                rel_path = file_path.relative_to(project_root)
            except ValueError:
                continue

            rel_path_str = str(rel_path)

            # Check include patterns
            matched_include = False
            for include_pattern in config.files.include:
                if fnmatch.fnmatch(rel_path_str, include_pattern) or fnmatch.fnmatch(
                    str(file_path), include_pattern
                ):
                    matched_include = True
                    break

            if not matched_include:
                continue

            # Check exclude patterns
            matched_exclude = False
            for exclude_pattern in config.files.exclude:
                if fnmatch.fnmatch(rel_path_str, exclude_pattern) or fnmatch.fnmatch(
                    str(file_path), exclude_pattern
                ):
                    matched_exclude = True
                    break

            if matched_exclude:
                continue

            files_to_scan.append((file_path, rel_path_str))

    # Parse each file and sync to database
    parsed_count = 0
    for file_path, rel_path_str in files_to_scan:
        # Get parser for this file
        parser = registry.get_parser_for_file(rel_path_str)
        if parser is None:
            continue

        # Read file content
        try:
            source = file_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            # Skip files that can't be read
            continue

        # Parse file
        try:
            symbols = parser.parse(source, rel_path_str)
        except (ValueError, RuntimeError):
            # Skip files that can't be parsed
            continue

        # Sync to database
        if symbols:
            sync_file(conn, rel_path_str, symbols)
            parsed_count += 1

    conn.close()
    return parsed_count


def _index_symbols(sqlite_path: Path, lancedb_path: Path) -> int:
    """Index all symbols into the vector store.

    Reads all symbols from SQLite and creates vector embeddings for each,
    storing them in LanceDB with the symbol ID as anchor.

    Args:
        sqlite_path: Path to SQLite database
        lancedb_path: Path to LanceDB directory

    Returns:
        Number of symbols indexed
    """
    import sqlite3
    from cortex.vector.store import VectorStore
    from cortex.vector.embeddings import generate_embedding
    from cortex.types import VectorRecord

    # Get database connection
    conn = sqlite3.connect(str(sqlite_path), check_same_thread=False)
    cursor = conn.cursor()

    # Get all symbols from database
    cursor.execute("SELECT id, signature, docstring FROM symbols")
    symbols = cursor.fetchall()
    conn.close()

    if not symbols:
        # No symbols to index
        return 0

    # Initialize vector store
    vector_store = VectorStore(str(lancedb_path))

    # Index each symbol
    indexed_count = 0
    for symbol_id, signature, docstring in symbols:
        # Build text content from signature and docstring
        text_parts = []
        if signature:
            text_parts.append(signature)
        if docstring:
            text_parts.append(docstring)

        if not text_parts:
            # Skip symbols with no signature or docstring
            continue

        text_content = " ".join(text_parts)

        # Generate embedding
        try:
            vector = generate_embedding(text_content)
        except (RuntimeError, ValueError, OSError):
            # Skip if embedding generation fails
            continue

        # Create vector record
        record = VectorRecord(
            vector=vector,
            text_content=text_content,
            anchor_symbol_id=symbol_id,
        )

        # Insert into vector store
        try:
            vector_store.insert(record)
            indexed_count += 1
        except (OSError, ValueError):
            # Skip if insertion fails
            continue

    return indexed_count


def _setup_mcp_config(project_root: Path) -> None:
    """Create or update .mcp.json for Claude Code integration.

    If .mcp.json doesn't exist, creates it with cortex server config.
    If it exists, adds cortex server if not already present.

    Args:
        project_root: Path to project root directory
    """
    mcp_config_path = project_root / ".mcp.json"

    # Default cortex server configuration
    # Uses the installed `cortex` command (from pip/pipx/uv install)
    cortex_config = {
        "type": "stdio",
        "command": "cortex",
        "args": ["start"],
    }

    if mcp_config_path.exists():
        # Load existing config
        try:
            with open(mcp_config_path, "r") as f:
                mcp_config = json.load(f)
        except (json.JSONDecodeError, OSError):
            # If file is corrupt, start fresh
            mcp_config = {"mcpServers": {}}

        # Ensure mcpServers key exists
        if "mcpServers" not in mcp_config:
            mcp_config["mcpServers"] = {}

        # Add cortex if not present
        if "cortex" not in mcp_config["mcpServers"]:
            mcp_config["mcpServers"]["cortex"] = cortex_config
    else:
        # Create new config
        mcp_config = {"mcpServers": {"cortex": cortex_config}}

    # Write config
    with open(mcp_config_path, "w") as f:
        json.dump(mcp_config, f, indent=2)
        f.write("\n")
