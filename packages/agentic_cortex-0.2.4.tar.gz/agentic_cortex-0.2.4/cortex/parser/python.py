"""Python AST parser using Tree-sitter.

This module implements the Python parser using tree-sitter-python to extract
functions, classes, methods with signatures, docstrings, line ranges, and checksums.

Now uses LanguageRegistry to load queries from YAML configuration.
"""

from typing import List, Optional
from pathlib import Path
import tree_sitter_python as tspython
from tree_sitter import Language, Parser as TSParser, Node

from cortex.types import Symbol
from cortex.symbols.id import generate_symbol_id
from cortex.parser.registry import LanguageRegistry, GenericParser
from cortex.parser.extraction import (
    extract_identifier_name,
    extract_signature,
    extract_body_text,
    extract_docstring,
    calculate_checksum,
)


class PythonParser:
    """Python parser using Tree-sitter for symbol extraction.

    Extracts functions, classes, and methods with:
    - Symbol IDs in format: {file_path}::{scope_chain}::{symbol_name}
    - Signatures with type annotations
    - Docstrings
    - Line ranges (1-indexed)
    - Checksums based on body content only

    Now uses LanguageRegistry to load queries from YAML configuration.
    """

    def __init__(self, languages_dir: Optional[Path] = None):
        """Initialize the Python parser.
        
        Args:
            languages_dir: Optional path to languages directory. If None, tries to find
                .cortex/languages/ from current directory or uses package defaults.
        """
        # Try to load from registry if languages_dir is provided or can be found
        self.registry_parser: Optional[GenericParser] = None
        
        if languages_dir:
            try:
                registry = LanguageRegistry(languages_dir)
                registry.load_languages()
                self.registry_parser = registry.get_parser("python")
            except (ValueError, KeyError):
                # Fall back to hardcoded logic if registry fails
                pass
        else:
            # Try to find .cortex/languages/ from current directory
            try:
                from cortex.config import find_cortex_root
                cortex_dir = find_cortex_root(Path.cwd())
                languages_dir = cortex_dir / "languages"
                if languages_dir.exists():
                    registry = LanguageRegistry(languages_dir)
                    registry.load_languages()
                    self.registry_parser = registry.get_parser("python")
            except (FileNotFoundError, ValueError, KeyError):
                # Fall back to hardcoded logic
                pass
        
        # Fallback: Load Python language directly if registry not available
        if self.registry_parser is None:
            PY_LANGUAGE = Language(tspython.language())
            self.parser = TSParser(PY_LANGUAGE)
            self.use_registry = False
        else:
            self.use_registry = True

    def parse(self, source: str, file_path: str = "") -> List[Symbol]:
        """Parse Python source code and extract symbols.

        Args:
            source: Python source code to parse
            file_path: File path for symbol ID generation

        Returns:
            List of extracted Symbol objects
        """
        # Use registry parser if available
        if self.use_registry and self.registry_parser:
            return self.registry_parser.parse(source, file_path)
        
        # Fallback to hardcoded logic
        tree = self.parser.parse(bytes(source, "utf8"))
        root = tree.root_node

        symbols: List[Symbol] = []
        self._extract_symbols(root, source, file_path, "", symbols)

        return symbols

    def _extract_symbols(
        self,
        node: Node,
        source: str,
        file_path: str,
        scope_chain: str,
        symbols: List[Symbol],
    ) -> None:
        """Recursively extract symbols from AST nodes.

        Args:
            node: Tree-sitter node to process
            source: Full source code string
            file_path: File path for symbol IDs
            scope_chain: Current scope chain (for nested symbols)
            symbols: List to append extracted symbols to
        """
        if node.type == "function_definition":
            symbol = self._extract_function(node, source, file_path, scope_chain)
            if symbol:
                symbols.append(symbol)
                # Recurse into function body to find nested functions/classes
                # Nested symbols keep the same scope_chain (functions don't create new scope for classes/functions)
                for child in node.children:
                    if child.type == "block":
                        self._extract_symbols(child, source, file_path, scope_chain, symbols)

        elif node.type == "class_definition":
            symbol = self._extract_class(node, source, file_path, scope_chain)
            if symbol:
                symbols.append(symbol)
                # Update scope chain for nested symbols
                class_name = extract_identifier_name(node, source)
                if class_name:
                    new_scope = f"{scope_chain}::{class_name}" if scope_chain else class_name
                    # Recurse into class body
                    for child in node.children:
                        if child.type == "block":
                            self._extract_symbols(child, source, file_path, new_scope, symbols)

        else:
            # Recurse into children for nested structures
            for child in node.children:
                self._extract_symbols(child, source, file_path, scope_chain, symbols)

    def _extract_function(
        self, node: Node, source: str, file_path: str, scope_chain: str
    ) -> Symbol | None:
        """Extract a function definition symbol.

        Args:
            node: function_definition node
            source: Full source code
            file_path: File path
            scope_chain: Current scope chain

        Returns:
            Symbol object or None if extraction fails
        """
        name = extract_identifier_name(node, source)
        if not name:
            return None

        signature = extract_signature(node, source, "def")
        if not signature:
            return None

        docstring = extract_docstring(node, source)
        body_text = extract_body_text(node, source)
        checksum = calculate_checksum(body_text)

        # Get line numbers (1-indexed)
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # Generate symbol ID
        symbol_id = generate_symbol_id(file_path, scope_chain, name)

        # Determine kind based on scope
        kind = "method" if scope_chain else "function"

        return Symbol(
            id=symbol_id,
            file_path=file_path,
            kind=kind,
            signature=signature,
            docstring=docstring,
            start_line=start_line,
            end_line=end_line,
            checksum=checksum,
        )

    def _extract_class(
        self, node: Node, source: str, file_path: str, scope_chain: str
    ) -> Symbol | None:
        """Extract a class definition symbol.

        Args:
            node: class_definition node
            source: Full source code
            file_path: File path
            scope_chain: Current scope chain

        Returns:
            Symbol object or None if extraction fails
        """
        name = extract_identifier_name(node, source)
        if not name:
            return None

        signature = extract_signature(node, source, "class")
        if not signature:
            return None

        docstring = extract_docstring(node, source)
        body_text = extract_body_text(node, source)
        checksum = calculate_checksum(body_text)

        # Get line numbers
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        # Generate symbol ID
        symbol_id = generate_symbol_id(file_path, scope_chain, name)

        return Symbol(
            id=symbol_id,
            file_path=file_path,
            kind="class",
            signature=signature,
            docstring=docstring,
            start_line=start_line,
            end_line=end_line,
            checksum=checksum,
        )
