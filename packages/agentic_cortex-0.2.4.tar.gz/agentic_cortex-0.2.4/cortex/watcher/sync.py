"""File sync logic for updating database based on file changes.

This module implements update strategies for syncing parsed symbols
to the database based on the planning document:
- Body Edit: Update checksum, preserve memory links
- Signature Edit: Update signature field, preserve memory links
- Rename/Refactor: If checksum unchanged → move (update ID), else delete old + create new
"""

import sqlite3
from typing import List, Dict

from cortex.types import Symbol
from cortex.parser.python import PythonParser


def sync_file(conn: sqlite3.Connection, file_path: str, symbols: List[Symbol]) -> None:
    """Sync parsed symbols from a file to the database.

    This function inserts or updates symbols in the database.
    It does not implement the sophisticated update strategies (that's sync_file_changes).

    Args:
        conn: SQLite database connection
        file_path: Relative path to the file
        symbols: List of parsed symbols from the file
    """
    cursor = conn.cursor()

    # Get existing symbols for this file
    cursor.execute("SELECT id FROM symbols WHERE file_path = ?", (file_path,))
    existing_ids = {row[0] for row in cursor.fetchall()}
    new_ids = {s.id for s in symbols}

    # Delete symbols that no longer exist
    to_delete = existing_ids - new_ids
    if to_delete:
        placeholders = ",".join("?" * len(to_delete))
        cursor.execute(f"DELETE FROM symbols WHERE id IN ({placeholders})", list(to_delete))

    # Insert or update symbols
    for symbol in symbols:
        cursor.execute(
            """
            INSERT INTO symbols (id, file_path, kind, signature, docstring, start_line, end_line, checksum)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                signature = excluded.signature,
                docstring = excluded.docstring,
                start_line = excluded.start_line,
                end_line = excluded.end_line,
                checksum = excluded.checksum,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                symbol.id,
                symbol.file_path,
                symbol.kind,
                symbol.signature,
                symbol.docstring,
                symbol.start_line,
                symbol.end_line,
                symbol.checksum,
            ),
        )

    conn.commit()


def sync_file_changes(
    conn: sqlite3.Connection, file_path: str, old_source: str, new_source: str
) -> None:
    """Sync file changes by comparing old and new source.

    Implements update strategies:
    - Body Edit: Update checksum, preserve ID and memory links
    - Signature Edit: Update signature field, preserve ID and memory links
    - Rename/Refactor with unchanged checksum: Move (update ID)
    - Rename/Refactor with changed checksum: Delete old + create new

    Args:
        conn: SQLite database connection
        file_path: Relative path to the file
        old_source: Previous source code content
        new_source: New source code content
    """
    parser = PythonParser()

    # Parse old and new symbols
    old_symbols = parser.parse(old_source, file_path)
    new_symbols = parser.parse(new_source, file_path)

    cursor = conn.cursor()

    # Build maps for comparison
    old_by_id: Dict[str, Symbol] = {s.id: s for s in old_symbols}
    new_by_id: Dict[str, Symbol] = {s.id: s for s in new_symbols}

    # Find symbols that disappeared
    disappeared_ids = set(old_by_id.keys()) - set(new_by_id.keys())
    # Find symbols that appeared
    appeared_ids = set(new_by_id.keys()) - set(old_by_id.keys())
    # Find symbols that remained
    common_ids = set(old_by_id.keys()) & set(new_by_id.keys())

    # Strategy 1: Handle disappeared symbols
    # Check if they were renamed/refactored by comparing checksums
    for old_id in list(disappeared_ids):
        old_symbol = old_by_id[old_id]

        # Try to find a new symbol with the same checksum (rename/refactor)
        matching_new = None
        for new_id in appeared_ids:
            new_symbol = new_by_id[new_id]
            if new_symbol.checksum == old_symbol.checksum:
                matching_new = new_symbol
                break

        if matching_new:
            # Rename/Refactor with unchanged checksum → Move (update ID)
            cursor.execute(
                """
                UPDATE symbols
                SET id = ?, signature = ?, docstring = ?, start_line = ?, end_line = ?
                WHERE id = ?
                """,
                (
                    matching_new.id,
                    matching_new.signature,
                    matching_new.docstring,
                    matching_new.start_line,
                    matching_new.end_line,
                    old_id,
                ),
            )
            # Update edges that reference this symbol
            cursor.execute(
                "UPDATE edges SET source_id = ? WHERE source_id = ?", (matching_new.id, old_id)
            )
            cursor.execute(
                "UPDATE edges SET target_id = ? WHERE target_id = ?", (matching_new.id, old_id)
            )

            # Remove from disappeared and appeared lists
            disappeared_ids.remove(old_id)
            appeared_ids.discard(matching_new.id)
        else:
            # No matching checksum → Delete old (rename/refactor with changed checksum or actual deletion)
            cursor.execute("DELETE FROM symbols WHERE id = ?", (old_id,))
            # Also delete edges (cascade behavior)
            cursor.execute(
                "DELETE FROM edges WHERE source_id = ? OR target_id = ?", (old_id, old_id)
            )

    # Strategy 2: Handle new symbols (those that appeared and weren't matched)
    for new_id in appeared_ids:
        new_symbol = new_by_id[new_id]
        cursor.execute(
            """
            INSERT INTO symbols (id, file_path, kind, signature, docstring, start_line, end_line, checksum)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                new_symbol.id,
                new_symbol.file_path,
                new_symbol.kind,
                new_symbol.signature,
                new_symbol.docstring,
                new_symbol.start_line,
                new_symbol.end_line,
                new_symbol.checksum,
            ),
        )

    # Strategy 3: Handle common symbols (check for body or signature edits)
    for symbol_id in common_ids:
        old_symbol = old_by_id[symbol_id]
        new_symbol = new_by_id[symbol_id]

        # Check if body changed (checksum changed)
        body_changed = old_symbol.checksum != new_symbol.checksum
        # Check if signature changed
        signature_changed = old_symbol.signature != new_symbol.signature

        if body_changed or signature_changed:
            # Update the symbol (preserves ID and memory links)
            cursor.execute(
                """
                UPDATE symbols
                SET signature = ?, docstring = ?, start_line = ?, end_line = ?, checksum = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (
                    new_symbol.signature,
                    new_symbol.docstring,
                    new_symbol.start_line,
                    new_symbol.end_line,
                    new_symbol.checksum,
                    symbol_id,
                ),
            )

    conn.commit()
