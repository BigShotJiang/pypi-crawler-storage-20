from datetime import date
from typing import List, Dict
from uuid import UUID, uuid4
from pydantic import BaseModel, Field

class RobustnessAnalysisRequest(BaseModel):
    strategy_id: UUID

class ScenarioResult(BaseModel):
    scenario_name: str
    robustness_score: float
    max_drawdown: float
    sharpe_ratio: float

class RobustnessMatrix(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    strategy_id: UUID
    aggregate_score: float
    scenario_results: List[ScenarioResult]
    created_at: date = Field(default_factory=date.today)
