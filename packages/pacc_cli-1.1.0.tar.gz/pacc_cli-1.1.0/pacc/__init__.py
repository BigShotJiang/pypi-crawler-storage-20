"""PACC - Package manager for Claude Code."""

__version__ = "1.1.0"
