# leetcodelib

<div align="center">

[![PyPI version](https://badge.fury.io/py/leetcodelib.svg)](https://pypi.org/project/leetcodelib/)
[![Python Version](https://img.shields.io/pypi/pyversions/leetcodelib.svg)](https://pypi.org/project/leetcodelib/)
[![License](https://img.shields.io/github/license/ciaoyizhen/leetcodelib.svg)](https://github.com/ciaoyizhen/leetcodelib/blob/main/LICENSE)
[![Downloads](https://pepy.tech/badge/leetcodelib)](https://pepy.tech/project/leetcodelib)

**专为 LeetCode 刷题设计的本地调试神器**

[快速开始](#快速开始) • [功能特性](#功能特性) • [API 文档](#api-文档) • [示例](#使用示例) • [贡献](#贡献)

</div>

---

## 📖 简介

**leetcodelib** 是一个轻量级的 Python 工具库，旨在解决 LeetCode 刷题时**本地输入与题目要求数据结构不一致**的痛点。

在 LeetCode 上，题目通常以**数组**（如 `[1, 2, 3]`）的形式给出输入，但算法代码却需要处理 **链表 (ListNode)** 或 **二叉树 (TreeNode)** 对象。`leetcodelib` 提供了高效的序列化与反序列化工具，助你在本地 IDE（如 PyCharm, VS Code）中轻松构建测试用例，享受断点调试的便利。

### ✨ 为什么选择 leetcodelib？

- 🚀 **开箱即用**：零依赖，纯 Python 实现，安装即用
- 🌳 **完美还原**：完美支持 LeetCode 的层序遍历（BFS）二叉树格式（含 `null` 处理）
- 🔗 **链表神器**：一行代码实现数组与链表的相互转换
- ⚡ **调试友好**：提供将对象转回数组的函数，方便 `print` 验证结果
- 📝 **类型提示**：完整的 Type Hinting，让 IDE 智能补全更顺畅
- 🧪 **测试覆盖**：经过大量边界条件测试（空树、单节点、不平衡树）

---

## 🚀 快速开始

### 安装

```bash
pip install leetcodelib
```

### 一分钟上手
```
from leetcodelib import *

# 1. 构造输入：将 LeetCode 数组转为二叉树对象
root = build_tree([3, 9, 20, None, None, 15, 7])

# 2. 构造输入：将 LeetCode 数组转为链表对象
root = build_link_list([3, 9, 1, 2])
```