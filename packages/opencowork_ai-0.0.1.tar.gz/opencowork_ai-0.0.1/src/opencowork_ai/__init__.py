"""OpenCoWork AI - Open-source AI collaborative assistant with sandboxed execution."""

__version__ = "0.0.1"

def main():
    print("OpenCoWork AI is under development. Visit https://openco.work for updates.")
