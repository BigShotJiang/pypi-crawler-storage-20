# OpenCoWork AI

Open-source AI collaborative assistant with sandboxed execution.

🚧 **Under Development** 🚧

Visit https://openco.work for updates.
