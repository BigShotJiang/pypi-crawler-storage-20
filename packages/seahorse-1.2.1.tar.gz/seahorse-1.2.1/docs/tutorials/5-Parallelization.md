#5 - Parallelization
