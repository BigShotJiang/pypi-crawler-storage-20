#4 - Recording games
