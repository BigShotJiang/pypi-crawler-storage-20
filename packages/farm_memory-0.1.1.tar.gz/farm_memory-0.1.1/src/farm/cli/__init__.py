"""CLI module for FARM."""
