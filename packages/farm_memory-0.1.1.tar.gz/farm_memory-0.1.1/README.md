# FARM - Filesystem As Remote Memory

为 AI Agent 设计的持久化记忆系统。让 Agent 能够跨会话记住重要信息，并通过语义搜索快速检索。

## 核心功能

- **记忆存储**: 保存对话摘要、用户偏好、学习到的知识
- **语义搜索**: 基于 ChromaDB 向量搜索，用自然语言查询相关记忆
- **多接口**: MCP Server (Claude)、REST API、CLI

## 快速开始

```bash
# 安装
uv sync

# 初始化存储
uv run farm init

# 添加记忆
uv run farm add "用户偏好 Vue 框架" --tag preference

# 搜索记忆
uv run farm search "前端框架" --semantic

# 启动 API 服务
uv run farm serve
```

## Claude 集成

添加到 Claude 配置 (`~/.claude.json`):

```json
{
  "mcpServers": {
    "farm": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/farm", "farm", "mcp"]
    }
  }
}
```

## 文档

- [快速入门](docs/getting-started.md)
- [CLI 命令](docs/cli.md)
- [REST API](docs/api.md)
- [MCP Server](docs/mcp.md)

## License

MIT
