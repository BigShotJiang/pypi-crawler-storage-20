"""Configuration helpers (flattened)."""
