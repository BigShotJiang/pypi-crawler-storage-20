"""Base world class for Plato worlds - OpenAI Gym-like interface."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, ClassVar

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from plato.worlds.config import RunConfig

logger = logging.getLogger(__name__)

# Global registry of worlds
_WORLD_REGISTRY: dict[str, type[BaseWorld]] = {}


def register_world(name: str | None = None):
    """Decorator to register a world class.

    Usage:
        @register_world("code")
        class CodeWorld(BaseWorld):
            ...
    """

    def decorator(cls: type[BaseWorld]) -> type[BaseWorld]:
        world_name = name or getattr(cls, "name", cls.__name__.lower().replace("world", ""))
        _WORLD_REGISTRY[world_name] = cls
        logger.debug(f"Registered world: {world_name} -> {cls.__name__}")
        return cls

    return decorator


def get_registered_worlds() -> dict[str, type[BaseWorld]]:
    """Get all registered worlds."""
    return _WORLD_REGISTRY.copy()


def get_world(name: str) -> type[BaseWorld] | None:
    """Get a world by name."""
    return _WORLD_REGISTRY.get(name)


class AgentSlot(BaseModel):
    """Definition of an agent slot in a world."""

    name: str
    description: str = ""
    required: bool = True


class Observation(BaseModel):
    """Observation returned from reset/step - what the agent sees."""

    data: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow"}


class StepResult(BaseModel):
    """Result of a step - OpenAI Gym style."""

    observation: Observation
    done: bool = False
    info: dict[str, Any] = Field(default_factory=dict)


class BaseWorld(ABC):
    """Base class for Plato worlds - OpenAI Gym-like interface.

    Subclasses implement:
    - reset(): Setup the world, return initial observation
    - step(): Execute one step, return StepResult

    The base run() method handles the loop: reset -> step until done.

    Example:
        @register_world("code")
        class CodeWorld(BaseWorld):
            name = "code"
            agents = ["coder"]

            async def reset(self, config: RunConfig) -> Observation:
                # Clone repo, setup workspace
                return Observation(data={"workspace": "/workspace"})

            async def step(self) -> StepResult:
                # Run agent, check if done
                return StepResult(observation=obs, done=True)
    """

    # Class attributes
    name: ClassVar[str] = "base"
    description: ClassVar[str] = ""
    agents: ClassVar[list[AgentSlot | str]] = []

    def __init__(self) -> None:
        self.logger = logging.getLogger(f"plato.worlds.{self.name}")
        self.config: RunConfig | None = None
        self._step_count: int = 0

    @classmethod
    def get_version(cls) -> str:
        """Get version from package metadata."""
        import importlib.metadata

        for pkg_name in [cls.__module__.split(".")[0], f"plato-world-{cls.name}"]:
            try:
                return importlib.metadata.version(pkg_name)
            except importlib.metadata.PackageNotFoundError:
                continue
        return "0.0.0"

    @classmethod
    def get_agent_slots(cls) -> list[AgentSlot]:
        """Get the list of agent slots."""
        return [AgentSlot(name=a) if isinstance(a, str) else a for a in cls.agents]

    @classmethod
    def get_schema(cls) -> dict:
        """Get JSON schema for world configuration."""
        return {"type": "object", "properties": {}, "required": []}

    @abstractmethod
    async def reset(self, config: RunConfig) -> Observation:
        """Setup the world and return initial observation.

        Called once at the start. Setup workspace, clone repos, etc.
        """
        pass

    @abstractmethod
    async def step(self) -> StepResult:
        """Execute one step of the world.

        Called repeatedly until done=True is returned.
        """
        pass

    async def close(self) -> None:
        """Cleanup resources. Called after run completes."""
        pass

    async def run(self, config: RunConfig) -> None:
        """Run the world: reset -> step until done -> close.

        This is the main entry point. Don't override this.
        """
        self.config = config
        self._step_count = 0

        self.logger.info(f"Starting world '{self.name}'")

        try:
            # Reset (setup)
            obs = await self.reset(config)
            self.logger.info(f"World reset complete: {obs}")

            # Step loop
            while True:
                self._step_count += 1
                result = await self.step()
                self.logger.info(f"Step {self._step_count}: done={result.done}")

                if result.done:
                    break

        finally:
            await self.close()
            self.logger.info(f"World '{self.name}' completed after {self._step_count} steps")
