"""Configuration models for Plato worlds."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class AgentConfig(BaseModel):
    """Configuration for a single agent slot.

    Attributes:
        image: Docker image URI for the agent
        config: Agent-specific configuration (passed to the agent)
    """

    image: str
    config: dict[str, Any] = Field(default_factory=dict)


class WorldConfig(BaseModel):
    """World-specific configuration.

    This is the configuration that gets passed to the world's run() method.
    The schema is defined by each world.
    """

    model_config = {"extra": "allow"}

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by key."""
        return getattr(self, key, default)


class RunConfig(BaseModel):
    """Full configuration for running a world.

    This is passed to the world runner and contains everything
    needed to execute a world.

    Attributes:
        world_config: World-specific configuration
        agents: Mapping of slot name to agent configuration
        secrets: Secret values (API keys, tokens, etc.)
        session_id: Unique session identifier
    """

    world_config: WorldConfig = Field(default_factory=WorldConfig)
    agents: dict[str, AgentConfig] = Field(default_factory=dict)
    secrets: dict[str, str] = Field(default_factory=dict)
    session_id: str = ""

    def get_agent(self, slot_name: str) -> AgentConfig | None:
        """Get agent config for a slot."""
        return self.agents.get(slot_name)

    def get_secret(self, key: str, default: str | None = None) -> str | None:
        """Get a secret value."""
        return self.secrets.get(key, default)

    @classmethod
    def from_file(cls, path: str | Path) -> RunConfig:
        """Load run config from a JSON file."""
        import json

        path = Path(path)
        with open(path) as f:
            data = json.load(f)

        # Parse agents into AgentConfig objects
        agents = {}
        for slot_name, agent_data in data.get("agents", {}).items():
            if isinstance(agent_data, dict):
                agents[slot_name] = AgentConfig(**agent_data)
            else:
                agents[slot_name] = AgentConfig(image=str(agent_data))

        return cls(
            world_config=WorldConfig(**data.get("world_config", {})),
            agents=agents,
            secrets=data.get("secrets", {}),
            session_id=data.get("session_id", ""),
        )
