from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.redis_detail import RedisDetail
from ...models.redis_patch_input import RedisPATCHInput
from ...types import Response


def _get_kwargs(
    redis_id: str,
    *,
    body: RedisPATCHInput,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": f"/redis/{redis_id}",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Error, RedisDetail]]:
    if response.status_code == 200:
        response_200 = RedisDetail.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = Error.from_dict(response.json())

        return response_409

    if response.status_code == 429:
        response_429 = Error.from_dict(response.json())

        return response_429

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if response.status_code == 503:
        response_503 = Error.from_dict(response.json())

        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Error, RedisDetail]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    redis_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: RedisPATCHInput,
) -> Response[Union[Error, RedisDetail]]:
    """Update Redis instance

     Update a Redis instance by ID.

    Args:
        redis_id (str):
        body (RedisPATCHInput): Input type for updating a Redis instance

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, RedisDetail]]
    """

    kwargs = _get_kwargs(
        redis_id=redis_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    redis_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: RedisPATCHInput,
) -> Optional[Union[Error, RedisDetail]]:
    """Update Redis instance

     Update a Redis instance by ID.

    Args:
        redis_id (str):
        body (RedisPATCHInput): Input type for updating a Redis instance

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Error, RedisDetail]
    """

    return sync_detailed(
        redis_id=redis_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    redis_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: RedisPATCHInput,
) -> Response[Union[Error, RedisDetail]]:
    """Update Redis instance

     Update a Redis instance by ID.

    Args:
        redis_id (str):
        body (RedisPATCHInput): Input type for updating a Redis instance

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Error, RedisDetail]]
    """

    kwargs = _get_kwargs(
        redis_id=redis_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    redis_id: str,
    *,
    client: Union[AuthenticatedClient, Client],
    body: RedisPATCHInput,
) -> Optional[Union[Error, RedisDetail]]:
    """Update Redis instance

     Update a Redis instance by ID.

    Args:
        redis_id (str):
        body (RedisPATCHInput): Input type for updating a Redis instance

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Error, RedisDetail]
    """

    return (
        await asyncio_detailed(
            redis_id=redis_id,
            client=client,
            body=body,
        )
    ).parsed
