class UnregisteredHandler(Exception):
    pass
