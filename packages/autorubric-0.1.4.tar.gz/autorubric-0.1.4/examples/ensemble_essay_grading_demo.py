#!/usr/bin/env python3
"""
Ensemble grading demonstration using multiple LLM judges.

Uses the same Industrial Revolution essay dataset as essay_grading_demo.py,
but grades each response with three different LLMs and aggregates their votes.

Judges:
- Gemini 2.5 Flash (fast, cost-effective)
- Claude Sonnet 4.5 (balanced quality)
- GPT-5.2-mini (high quality)

This demonstrates:
- Multi-model ensemble grading
- Per-judge score comparison
- Agreement metrics across judges
- Cost comparison vs. single-model grading
"""

import asyncio
import math
import os
import sys
import litellm

from autorubric import (
    CannotAssessConfig,
    CannotAssessStrategy,
    Criterion,
    CriterionVerdict,
    EnsembleEvaluationReport,
    LLMConfig,
    Rubric,
    aggregate_token_usage,
)
from autorubric.dataset import DataItem, RubricDataset
from autorubric.graders import CriterionGrader, JudgeSpec
from dotenv import load_dotenv

load_dotenv()

litellm.suppress_debug_info = True

# -----------------------------------------------------------------------------
# Create the Essay Grading Dataset
# -----------------------------------------------------------------------------


def create_essay_grading_dataset() -> RubricDataset:
    """Create a simple essay grading dataset."""

    MET = CriterionVerdict.MET
    UNMET = CriterionVerdict.UNMET
    CANNOT_ASSESS = CriterionVerdict.CANNOT_ASSESS

    # Define the rubric with criteria
    rubric = Rubric(
        [
            Criterion(
                name="Causes",
                weight=30.0,
                requirement=(
                    "Correctly identifies at least 2 major causes of the Industrial Revolution "
                    "(e.g., natural resources like coal/iron, agricultural changes, technological "
                    "innovation, capital availability, stable political system, colonial trade)"
                ),
            ),
            Criterion(
                name="Effects",
                weight=30.0,
                requirement=(
                    "Correctly describes at least 2 major effects of the Industrial Revolution "
                    "(e.g., urbanization, factory system, changes in working conditions, rise of "
                    "middle class, environmental impact, labor movements)"
                ),
            ),
            Criterion(
                name="Structure",
                weight=12.0,
                requirement=(
                    "Demonstrates clear essay structure with introduction, body paragraphs, and "
                    "logical flow between ideas"
                ),
            ),
            Criterion(
                name="Britain",
                weight=8.0,
                requirement=(
                    "Correctly identifies Britain as the origin and provides accurate timeframe "
                    "(starting between 1760-1800)"
                ),
            ),
            Criterion(
                name="Errors",
                weight=-15.0,
                requirement=(
                    "Contains significant factual errors such as wrong country of origin, "
                    "incorrect dates (off by more than 50 years), or misattribution of inventions"
                ),
            ),
        ]
    )

    # Create dataset
    dataset = RubricDataset(
        prompt="Explain the causes and effects of the Industrial Revolution.",
        rubric=rubric,
    )

    # Add items with ground truth
    # Ground truth format: [causes, effects, structure, britain, errors]
    # For errors: MET = errors present (bad), UNMET = no errors (good)

    dataset.add_item(
        text="""The Industrial Revolution, spanning roughly 1760-1840, originated in Britain due to several
    key factors. First, Britain possessed abundant natural resources, particularly coal and iron ore,
    which powered factories and machinery. Second, agricultural improvements like crop rotation and
    the enclosure movement freed rural workers to migrate to cities. Third, a stable political system
    and strong property rights encouraged investment in new technologies.

    The effects were profound and far-reaching. Economically, factory production replaced cottage
    industries, dramatically increasing output and creating new wealth. Socially, urbanization
    accelerated as workers flocked to industrial centers, leading to overcrowded cities with poor
    sanitation. Working conditions in early factories were harsh, with long hours, low wages, and
    child labor common. Environmentally, coal burning polluted air and waterways.

    Long-term consequences included the rise of the middle class, labor movements demanding workers'
    rights, and technological innovations that continue shaping our world today.""",
        description="Excellent - all criteria met",
        ground_truth=[MET, MET, MET, MET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution happened because Britain had lots of coal and iron. Factories
    started using machines instead of hand tools. James Watt improved the steam engine which
    helped power many factories.

    Effects included people moving from farms to cities. Factory work was hard and dangerous.
    Children often worked in mines and mills. Cities became crowded and dirty. But there were
    also positive effects - more goods were produced cheaper, and eventually living standards
    improved. The middle class grew as factory owners and merchants became wealthy.""",
        description="Good - content strong, missing timeframe",
        ground_truth=[MET, MET, MET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution was when factories started. It happened in England first
    because they had resources. People used to work at home but then moved to factories.

    Steam engines were invented and this helped make things faster. Cities got bigger because
    people moved there for jobs. Some effects were good like more products, but some were bad
    like pollution and child labor.""",
        description="Basic - core content present, weak structure",
        ground_truth=[MET, MET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The industrial revolution was a big change in history. Factories were made and people
    worked in them. Machines replaced handwork. It started a long time ago in Europe.

    Things changed a lot because of it. People lived differently after. There was more stuff
    to buy.""",
        description="Minimal - vague, only hints at effects",
        ground_truth=[UNMET, MET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The industrial revolution happened because people wanted change. It made things different.
    Factories are where they made stuff. I think it was important for history.""",
        description="Poor - no real content",
        ground_truth=[UNMET, UNMET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution began around 1800 in Britain (though some historians date it
    to 1760). Key causes included technological innovation, available labor from enclosed farms,
    capital from colonial trade, and natural resources like coal.

    Major inventions like the spinning jenny, water frame, and steam engine transformed textile
    manufacturing. The cotton gin, invented by Eli Whitney, also boosted cotton production
    (though this was in America, not Britain).

    Effects included urbanization, class struggle between workers and owners, environmental
    degradation, and eventually improved living standards. The labor movement emerged in response
    to exploitation of workers.""",
        description="Comprehensive - all content, correctly notes cotton gin is American",
        ground_truth=[MET, MET, MET, MET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution started in France around 1700. The main cause was that people
    invented electricity which powered all the factories. Thomas Edison was the key figure
    who started the revolution.

    People moved to cities and worked in factories. This was better than farming because they
    got paid more money. The main effect was that everyone got richer and life improved
    immediately for workers.""",
        description="Major errors - wrong country, date, technology",
        ground_truth=[UNMET, UNMET, MET, UNMET, MET],
    )

    dataset.add_item(
        text="""Britain had coal iron and rivers for transport also they had colonies for raw materials
    and markets this helped them start factories. Steam power was key because water power
    limited where factories could be built but steam let them go anywhere.

    Socially there was major disruption traditional crafts died out and families split up as
    members moved to different cities for work the new urban conditions bred disease and crime
    but also new forms of social organization like unions and reform movements.

    Long term effects include modern capitalism the labor movement industrialized warfare and
    eventually the environmental challenges we face today from centuries of burning fossil fuels.""",
        description="Good content, run-on sentences, poor structure",
        ground_truth=[MET, MET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution had massive effects on society.

    Economic effects: Productivity soared. Goods that once took weeks to produce by hand could
    be made in hours by machine. This lowered prices, made products accessible to more people,
    and generated enormous wealth - though distributed unequally.

    Social effects: The traditional social order was disrupted. Landed aristocracy gradually
    ceded power to industrial capitalists. A new working class emerged, often living in squalid
    conditions. Child labor was rampant until reform movements succeeded in passing protective
    legislation.

    Environmental effects: Deforestation, air pollution from coal burning, and water
    contamination became serious problems. Rivers like the Thames became essentially open sewers.

    Political effects: Workers organized into unions and demanded rights. The Chartist movement
    pushed for democratic reforms. Eventually, the middle and working classes gained political
    representation.""",
        description="Excellent effects coverage, but ignores causes entirely",
        ground_truth=[UNMET, MET, MET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The French Revolution was caused by inequality between the nobility and common people.
    King Louis XVI was a weak ruler who couldn't solve France's financial problems. The
    storming of the Bastille in 1789 marked the beginning of major changes.

    The effects included the execution of the king and queen, the Reign of Terror, and
    eventually Napoleon taking power. The revolution inspired democratic movements across
    Europe and the Americas.""",
        description="Off-topic - discusses French Revolution instead",
        ground_truth=[UNMET, UNMET, MET, UNMET, MET],
    )

    return dataset


# -----------------------------------------------------------------------------
# Metrics (same as essay_grading_demo.py, plus ensemble-specific)
# -----------------------------------------------------------------------------


def rmse(predictions: list[float], actuals: list[float]) -> float:
    """Root Mean Square Error."""
    n = len(predictions)
    if n == 0:
        return 0.0
    squared_errors = [(p - a) ** 2 for p, a in zip(predictions, actuals)]
    return math.sqrt(sum(squared_errors) / n)


def accuracy(
    predictions: list[CriterionVerdict], actuals: list[CriterionVerdict]
) -> float:
    """Binary accuracy."""
    if len(predictions) == 0:
        return 0.0
    correct = sum(1 for p, a in zip(predictions, actuals) if p == a)
    return correct / len(predictions)


def cohens_kappa(
    predictions: list[CriterionVerdict], actuals: list[CriterionVerdict]
) -> float:
    """Cohen's Kappa for binary classification."""
    n = len(predictions)
    if n == 0:
        return 0.0

    MET = CriterionVerdict.MET
    UNMET = CriterionVerdict.UNMET
    tp = sum(1 for p, a in zip(predictions, actuals) if p == MET and a == MET)
    tn = sum(1 for p, a in zip(predictions, actuals) if p == UNMET and a == UNMET)
    fp = sum(1 for p, a in zip(predictions, actuals) if p == MET and a == UNMET)
    fn = sum(1 for p, a in zip(predictions, actuals) if p == UNMET and a == MET)

    po = (tp + tn) / n
    p_yes = ((tp + fp) / n) * ((tp + fn) / n)
    p_no = ((tn + fn) / n) * ((tn + fp) / n)
    pe = p_yes + p_no

    if pe == 1.0:
        return 1.0
    return (po - pe) / (1 - pe)


def spearman_correlation(x: list[float], y: list[float]) -> float:
    """Spearman rank correlation coefficient."""
    n = len(x)
    if n < 2:
        return 0.0

    def rank(values: list[float]) -> list[float]:
        sorted_indices = sorted(range(len(values)), key=lambda i: values[i])
        ranks = [0.0] * len(values)
        i = 0
        while i < len(sorted_indices):
            j = i
            while (
                j < len(sorted_indices)
                and values[sorted_indices[j]] == values[sorted_indices[i]]
            ):
                j += 1
            avg_rank = (i + j + 1) / 2
            for k in range(i, j):
                ranks[sorted_indices[k]] = avg_rank
            i = j
        return ranks

    rx = rank(x)
    ry = rank(y)

    mean_rx = sum(rx) / n
    mean_ry = sum(ry) / n

    numerator = sum((rx[i] - mean_rx) * (ry[i] - mean_ry) for i in range(n))
    denom_x = math.sqrt(sum((rx[i] - mean_rx) ** 2 for i in range(n)))
    denom_y = math.sqrt(sum((ry[i] - mean_ry) ** 2 for i in range(n)))

    if denom_x == 0 or denom_y == 0:
        return 0.0
    return numerator / (denom_x * denom_y)


def kendall_tau(x: list[float], y: list[float]) -> float:
    """Kendall Tau-b correlation coefficient."""
    n = len(x)
    if n < 2:
        return 0.0

    concordant = 0
    discordant = 0
    ties_x = 0
    ties_y = 0

    for i in range(n):
        for j in range(i + 1, n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]

            if dx == 0 and dy == 0:
                ties_x += 1
                ties_y += 1
            elif dx == 0:
                ties_x += 1
            elif dy == 0:
                ties_y += 1
            elif (dx > 0 and dy > 0) or (dx < 0 and dy < 0):
                concordant += 1
            else:
                discordant += 1

    n_pairs = n * (n - 1) // 2
    denom = math.sqrt((n_pairs - ties_x) * (n_pairs - ties_y))
    if denom == 0:
        return 0.0
    return (concordant - discordant) / denom


def extract_verdicts(
    report: EnsembleEvaluationReport, num_criteria: int
) -> list[CriterionVerdict]:
    """Extract final verdicts from an EnsembleEvaluationReport."""
    if report.report is None:
        return [CriterionVerdict.UNMET] * num_criteria
    return [cr.final_verdict for cr in report.report]


# -----------------------------------------------------------------------------
# Grading
# -----------------------------------------------------------------------------


async def grade_single_item(
    rubric: Rubric,
    grader: CriterionGrader,
    item: DataItem,
    item_idx: int,
    prompt: str,
) -> tuple[int, EnsembleEvaluationReport]:
    """Grade a single data item with the ensemble."""
    result = await rubric.grade(
        to_grade=item.text,
        grader=grader,
        query=prompt,
    )
    return item_idx, result


async def main():
    dataset = create_essay_grading_dataset()

    # Configure ensemble judges
    judges = [
        JudgeSpec(
            llm_config=LLMConfig(
                model="gemini/gemini-2.5-flash",
                temperature=0.0,
            ),
            judge_id="gemini-flash",
            weight=1.0,
        ),
        JudgeSpec(
            llm_config=LLMConfig(
                model="anthropic/claude-sonnet-4-5-20250929",
                temperature=0.0,
            ),
            judge_id="claude-sonnet",
            weight=1.0,
        ),
        JudgeSpec(
            llm_config=LLMConfig(
                model="openai/gpt-5.2",
                temperature=0.0,
            ),
            judge_id="gpt-5.2",
            weight=1.2,
        ),
    ]

    grader = CriterionGrader(
        judges=judges,
        aggregation="majority",  # Use majority voting
        normalize=True,
        cannot_assess_config=CannotAssessConfig(
            strategy=CannotAssessStrategy.SKIP,  # Default: exclude unassessable from scoring
        ),
    )

    print("=" * 80)
    print("Ensemble Grading Demo: Multi-LLM Panel Evaluation")
    print("=" * 80)
    print("\nJudges:")
    for spec in judges:
        print(f"  - {spec.judge_id} (weight: {spec.weight})")
    print("\nAggregation Strategy: majority")
    print(f"\nPrompt: {dataset.prompt}\n")
    print(f"Rubric Criteria (total positive weight: {dataset.total_positive_weight}):")
    for i, (criterion, name) in enumerate(
        zip(dataset.rubric.rubric, dataset.criterion_names)
    ):
        weight_str = (
            f"+{criterion.weight}" if criterion.weight > 0 else str(criterion.weight)
        )
        print(f"  {i + 1}. {name:10} [{weight_str:>6}]")
    print("\n" + "-" * 80)

    # Grade all items
    print(f"\nGrading {len(dataset)} items with ensemble of {len(judges)} judges...")
    print(
        f"(This may take a while as each item requires {len(judges)} x {dataset.num_criteria} = {len(judges) * dataset.num_criteria} LLM calls)\n"
    )

    tasks = [
        grade_single_item(dataset.rubric, grader, item, i + 1, dataset.prompt)
        for i, item in enumerate(dataset)
    ]
    results = await asyncio.gather(*tasks)
    results = sorted(results, key=lambda x: x[0])

    # Collect predictions and ground truth
    all_pred_verdicts: list[list[CriterionVerdict]] = []
    all_true_verdicts: list[list[CriterionVerdict]] = []
    all_pred_scores: list[float] = []
    all_true_scores: list[float] = []
    all_agreements: list[float] = []

    print("\n" + "=" * 80)
    print("INDIVIDUAL RESULTS")
    print("=" * 80)

    for (item_idx, result), item in zip(results, dataset):
        pred_verdicts = extract_verdicts(result, dataset.num_criteria)
        true_verdicts = item.ground_truth

        pred_score = result.score if not result.error else 0.0
        true_score = dataset.compute_weighted_score(true_verdicts)

        all_pred_verdicts.append(pred_verdicts)
        all_true_verdicts.append(true_verdicts)
        all_pred_scores.append(pred_score)
        all_true_scores.append(true_score)
        all_agreements.append(result.mean_agreement)

        item_accuracy = accuracy(pred_verdicts, true_verdicts)
        score_error = abs(pred_score - true_score)

        print(f"\nItem {item_idx}: {item.description}")
        print(
            f"  Scores: Ensemble={pred_score:.3f} | Actual={true_score:.3f} | Error={score_error:.3f}"
        )
        print(f"  Agreement: {result.mean_agreement:.1%}")

        # Show per-judge scores
        print("  Judge Scores: ", end="")
        for judge_id, score in sorted(result.judge_scores.items()):
            print(f"{judge_id}={score:.3f}  ", end="")
        print()

        print(
            f"  Criterion Accuracy: {item_accuracy:.0%} "
            f"({sum(1 for p, t in zip(pred_verdicts, true_verdicts) if p == t)}/{dataset.num_criteria})"
        )

        # Show per-criterion comparison with agreement
        print("  Criteria:  ", end="")
        for name in dataset.criterion_names:
            print(f"{name[:6]:>10}", end="")
        print()
        print("  Ensemble:  ", end="")
        for v in pred_verdicts:
            print(f"{v.value:>10}", end="")
        print()
        print("  Actual:    ", end="")
        for v in true_verdicts:
            print(f"{v.value:>10}", end="")
        print()
        print("  Agreement: ", end="")
        if result.report:
            for cr in result.report:
                print(f"{cr.agreement:>9.0%} ", end="")
        print()

    # -----------------------------------------------------------------------------
    # Per-Criterion Metrics
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PER-CRITERION METRICS")
    print("=" * 80)

    print(f"\n{'Criterion':<12} {'Accuracy':>10} {'Kappa':>10} {'Avg Agreement':>15}")
    print("-" * 50)

    criterion_accuracies = []
    criterion_kappas = []
    criterion_agreements = []

    for c_idx, name in enumerate(dataset.criterion_names):
        pred_c = [v[c_idx] for v in all_pred_verdicts]
        true_c = [v[c_idx] for v in all_true_verdicts]

        acc = accuracy(pred_c, true_c)
        kappa = cohens_kappa(pred_c, true_c)

        # Calculate average agreement for this criterion across all items
        agreements = []
        for _, result in results:
            if result.report:
                agreements.append(result.report[c_idx].agreement)
        avg_agreement = sum(agreements) / len(agreements) if agreements else 0.0

        criterion_accuracies.append(acc)
        criterion_kappas.append(kappa)
        criterion_agreements.append(avg_agreement)

        print(f"{name:<12} {acc:>10.1%} {kappa:>10.3f} {avg_agreement:>15.1%}")

    print("-" * 50)
    print(
        f"{'Average':<12} {sum(criterion_accuracies)/len(criterion_accuracies):>10.1%} "
        f"{sum(criterion_kappas)/len(criterion_kappas):>10.3f} "
        f"{sum(criterion_agreements)/len(criterion_agreements):>15.1%}"
    )

    # -----------------------------------------------------------------------------
    # Cumulative Score Metrics
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("CUMULATIVE SCORE METRICS")
    print("=" * 80)

    score_rmse = rmse(all_pred_scores, all_true_scores)
    spearman = spearman_correlation(all_pred_scores, all_true_scores)
    kendall = kendall_tau(all_pred_scores, all_true_scores)

    print(f"\nRMSE:                    {score_rmse:.4f}")
    print(f"Spearman Correlation:    {spearman:.4f}")
    print(f"Kendall Tau:             {kendall:.4f}")
    print(f"Mean Judge Agreement:    {sum(all_agreements)/len(all_agreements):.1%}")

    # Interpretation
    print("\nInterpretation:")
    if spearman >= 0.9:
        print("  Spearman: Very strong positive correlation")
    elif spearman >= 0.7:
        print("  Spearman: Strong positive correlation")
    elif spearman >= 0.5:
        print("  Spearman: Moderate positive correlation")
    elif spearman >= 0.3:
        print("  Spearman: Weak positive correlation")
    else:
        print("  Spearman: Very weak or no correlation")

    if kendall >= 0.8:
        print("  Kendall:  Almost perfect agreement")
    elif kendall >= 0.6:
        print("  Kendall:  Substantial agreement")
    elif kendall >= 0.4:
        print("  Kendall:  Moderate agreement")
    elif kendall >= 0.2:
        print("  Kendall:  Fair agreement")
    else:
        print("  Kendall:  Slight agreement")

    # -----------------------------------------------------------------------------
    # Per-Judge Score Analysis
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PER-JUDGE ANALYSIS")
    print("=" * 80)

    # Collect per-judge scores across all items
    judge_all_scores: dict[str, list[float]] = {spec.judge_id: [] for spec in judges}
    for _, result in results:
        for judge_id, score in result.judge_scores.items():
            judge_all_scores[judge_id].append(score)

    print(
        f"\n{'Judge':<15} {'Mean Score':>12} {'RMSE':>10} {'Spearman':>10} {'Kendall':>10}"
    )
    print("-" * 60)

    for judge_id in sorted(judge_all_scores.keys()):
        scores = judge_all_scores[judge_id]
        mean_score = sum(scores) / len(scores)
        judge_rmse = rmse(scores, all_true_scores)
        judge_spearman = spearman_correlation(scores, all_true_scores)
        judge_kendall = kendall_tau(scores, all_true_scores)

        print(
            f"{judge_id:<15} {mean_score:>12.3f} {judge_rmse:>10.4f} "
            f"{judge_spearman:>10.4f} {judge_kendall:>10.4f}"
        )

    print("-" * 60)
    mean_ensemble = sum(all_pred_scores) / len(all_pred_scores)
    print(
        f"{'ENSEMBLE':<15} {mean_ensemble:>12.3f} {score_rmse:>10.4f} "
        f"{spearman:>10.4f} {kendall:>10.4f}"
    )

    # -----------------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)

    overall_criterion_acc = sum(
        1
        for pv, tv in zip(all_pred_verdicts, all_true_verdicts)
        for p, t in zip(pv, tv)
        if p == t
    ) / (len(all_pred_verdicts) * dataset.num_criteria)

    print(f"\nDataset: {len(dataset)} items, {dataset.num_criteria} criteria")
    print(f"Ensemble: {len(judges)} judges with weighted aggregation")
    print(f"\nOverall Criterion Accuracy: {overall_criterion_acc:.1%}")
    print(
        f"Average Criterion Kappa:    {sum(criterion_kappas)/len(criterion_kappas):.3f}"
    )
    print(f"Score RMSE:                 {score_rmse:.4f}")
    print(f"Score Spearman r:           {spearman:.4f}")
    print(f"Score Kendall tau:          {kendall:.4f}")
    print(f"Mean Judge Agreement:       {sum(all_agreements)/len(all_agreements):.1%}")

    # -----------------------------------------------------------------------------
    # Cost Summary
    # -----------------------------------------------------------------------------
    all_reports = [result for _, result in results]
    usages = [r.token_usage for r in all_reports if r.token_usage]
    total_usage = aggregate_token_usage(usages)
    total_cost = sum(r.completion_cost or 0 for r in all_reports)

    print("\n" + "-" * 80)
    print("COST ANALYSIS")
    print("-" * 80)

    if total_usage:
        print(f"\nTotal Token Usage:")
        print(f"  Prompt tokens:     {total_usage.prompt_tokens:>12,}")
        print(f"  Completion tokens: {total_usage.completion_tokens:>12,}")
        print(f"  Total tokens:      {total_usage.total_tokens:>12,}")

    if total_cost > 0:
        print(f"\nTotal Cost: ${total_cost:.6f}")
        cost_per_item = total_cost / len(dataset)
        print(f"Cost per Item: ${cost_per_item:.6f}")
        print(f"Cost per Item per Judge: ${cost_per_item / len(judges):.6f}")

    print("\n" + "=" * 80)
    print(
        f"Note: This ensemble grading uses {len(judges)}x the LLM calls of single-model grading,"
    )
    print(
        "but can improve reliability through consensus and highlight ambiguous cases."
    )
    print("=" * 80)


def check_api_keys() -> list[str]:
    """Check which API keys are available."""
    missing = []
    if not os.environ.get("GEMINI_API_KEY"):
        missing.append("GEMINI_API_KEY")
    if not os.environ.get("ANTHROPIC_API_KEY"):
        missing.append("ANTHROPIC_API_KEY")
    if not os.environ.get("OPENAI_API_KEY"):
        missing.append("OPENAI_API_KEY")
    return missing


if __name__ == "__main__":
    missing_keys = check_api_keys()
    if missing_keys:
        print("Warning: The following API keys are not set:")
        for key in missing_keys:
            print(f"  - {key}")
        print("\nSet them to run the ensemble demo:")
        print("  export GEMINI_API_KEY='your-key'")
        print("  export ANTHROPIC_API_KEY='your-key'")
        print("  export OPENAI_API_KEY='your-key'")
        print("\nAlternatively, modify the judges list to use available providers.")
        sys.exit(1)

    asyncio.run(main())
