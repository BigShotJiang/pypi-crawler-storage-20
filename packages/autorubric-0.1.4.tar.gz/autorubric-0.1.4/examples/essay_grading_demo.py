#!/usr/bin/env python3
"""
Standalone demonstration of the autorubric library with criterion-level accuracy evaluation.

Dataset: 10 student essay responses to the prompt:
    "Explain the causes and effects of the Industrial Revolution."

Rubric: 5 criteria evaluating historical accuracy, structure, and analysis.

Evaluation: Compares LLM verdicts against simulated human judgments at the criterion
level, then aggregates to cumulative scores. Reports RMSE and correlation metrics.

METRICS:
- Per-criterion: Accuracy (binary agreement) and Cohen's Kappa
- Cumulative scores: RMSE and Spearman correlation (robust to non-linearity)
- Overall: Kendall Tau (ordinal agreement, handles ties well for small samples)
"""

import asyncio
import math
import os

from autorubric import (
    CannotAssessConfig,
    CannotAssessStrategy,
    Criterion,
    CriterionVerdict,
    EvaluationReport,
    LLMConfig,
    Rubric,
    TokenUsage,
    aggregate_evaluation_usage,
)
from autorubric.dataset import DataItem, RubricDataset
from autorubric.graders import CriterionGrader
from dotenv import load_dotenv

load_dotenv()


# -----------------------------------------------------------------------------
# Create the Essay Grading Dataset
# -----------------------------------------------------------------------------


def create_essay_grading_dataset() -> RubricDataset:
    """Create a simple Essay Grading Dataset."""

    MET = CriterionVerdict.MET
    UNMET = CriterionVerdict.UNMET
    CANNOT_ASSESS = CriterionVerdict.CANNOT_ASSESS

    # Define the rubric with criteria
    rubric = Rubric(
        [
            Criterion(
                name="Causes",
                weight=30.0,
                requirement=(
                    "Correctly identifies at least 2 major causes of the Industrial Revolution "
                    "(e.g., natural resources like coal/iron, agricultural changes, technological "
                    "innovation, capital availability, stable political system, colonial trade)"
                ),
            ),
            Criterion(
                name="Effects",
                weight=30.0,
                requirement=(
                    "Correctly describes at least 2 major effects of the Industrial Revolution "
                    "(e.g., urbanization, factory system, changes in working conditions, rise of "
                    "middle class, environmental impact, labor movements)"
                ),
            ),
            Criterion(
                name="Structure",
                weight=12.0,
                requirement=(
                    "Demonstrates clear essay structure with introduction, body paragraphs, and "
                    "logical flow between ideas"
                ),
            ),
            Criterion(
                name="Britain",
                weight=8.0,
                requirement=(
                    "Correctly identifies Britain as the origin and provides accurate timeframe "
                    "(starting between 1760-1800)"
                ),
            ),
            Criterion(
                name="Errors",
                weight=-15.0,
                requirement=(
                    "Contains significant factual errors such as wrong country of origin, "
                    "incorrect dates (off by more than 50 years), or misattribution of inventions"
                ),
            ),
        ]
    )

    # Create dataset
    dataset = RubricDataset(
        prompt="Explain the causes and effects of the Industrial Revolution.",
        rubric=rubric,
    )

    # Add items with ground truth
    # Ground truth format: [causes, effects, structure, britain, errors]
    # For errors: MET = errors present (bad), UNMET = no errors (good)

    dataset.add_item(
        text="""The Industrial Revolution, spanning roughly 1760-1840, originated in Britain due to several
    key factors. First, Britain possessed abundant natural resources, particularly coal and iron ore,
    which powered factories and machinery. Second, agricultural improvements like crop rotation and
    the enclosure movement freed rural workers to migrate to cities. Third, a stable political system
    and strong property rights encouraged investment in new technologies.

    The effects were profound and far-reaching. Economically, factory production replaced cottage
    industries, dramatically increasing output and creating new wealth. Socially, urbanization
    accelerated as workers flocked to industrial centers, leading to overcrowded cities with poor
    sanitation. Working conditions in early factories were harsh, with long hours, low wages, and
    child labor common. Environmentally, coal burning polluted air and waterways.

    Long-term consequences included the rise of the middle class, labor movements demanding workers'
    rights, and technological innovations that continue shaping our world today.""",
        description="Excellent - all criteria met",
        ground_truth=[MET, MET, MET, MET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution happened because Britain had lots of coal and iron. Factories
    started using machines instead of hand tools. James Watt improved the steam engine which
    helped power many factories.

    Effects included people moving from farms to cities. Factory work was hard and dangerous.
    Children often worked in mines and mills. Cities became crowded and dirty. But there were
    also positive effects - more goods were produced cheaper, and eventually living standards
    improved. The middle class grew as factory owners and merchants became wealthy.""",
        description="Good - content strong, missing timeframe",
        ground_truth=[MET, MET, MET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution was when factories started. It happened in England first
    because they had resources. People used to work at home but then moved to factories.

    Steam engines were invented and this helped make things faster. Cities got bigger because
    people moved there for jobs. Some effects were good like more products, but some were bad
    like pollution and child labor.""",
        description="Basic - core content present, weak structure",
        ground_truth=[MET, MET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The industrial revolution was a big change in history. Factories were made and people
    worked in them. Machines replaced handwork. It started a long time ago in Europe.

    Things changed a lot because of it. People lived differently after. There was more stuff
    to buy.""",
        description="Minimal - vague, only hints at effects",
        ground_truth=[UNMET, MET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The industrial revolution happened because people wanted change. It made things different.
    Factories are where they made stuff. I think it was important for history.""",
        description="Poor - no real content",
        ground_truth=[UNMET, UNMET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution began around 1800 in Britain (though some historians date it
    to 1760). Key causes included technological innovation, available labor from enclosed farms,
    capital from colonial trade, and natural resources like coal.

    Major inventions like the spinning jenny, water frame, and steam engine transformed textile
    manufacturing. The cotton gin, invented by Eli Whitney, also boosted cotton production
    (though this was in America, not Britain).

    Effects included urbanization, class struggle between workers and owners, environmental
    degradation, and eventually improved living standards. The labor movement emerged in response
    to exploitation of workers.""",
        description="Comprehensive - all content, correctly notes cotton gin is American",
        ground_truth=[MET, MET, MET, MET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution started in France around 1700. The main cause was that people
    invented electricity which powered all the factories. Thomas Edison was the key figure
    who started the revolution.

    People moved to cities and worked in factories. This was better than farming because they
    got paid more money. The main effect was that everyone got richer and life improved
    immediately for workers.""",
        description="Major errors - wrong country, date, technology",
        ground_truth=[UNMET, UNMET, MET, UNMET, MET],
    )

    dataset.add_item(
        text="""Britain had coal iron and rivers for transport also they had colonies for raw materials
    and markets this helped them start factories. Steam power was key because water power
    limited where factories could be built but steam let them go anywhere.

    Socially there was major disruption traditional crafts died out and families split up as
    members moved to different cities for work the new urban conditions bred disease and crime
    but also new forms of social organization like unions and reform movements.

    Long term effects include modern capitalism the labor movement industrialized warfare and
    eventually the environmental challenges we face today from centuries of burning fossil fuels.""",
        description="Good content, run-on sentences, poor structure",
        ground_truth=[MET, MET, UNMET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The Industrial Revolution had massive effects on society.

    Economic effects: Productivity soared. Goods that once took weeks to produce by hand could
    be made in hours by machine. This lowered prices, made products accessible to more people,
    and generated enormous wealth - though distributed unequally.

    Social effects: The traditional social order was disrupted. Landed aristocracy gradually
    ceded power to industrial capitalists. A new working class emerged, often living in squalid
    conditions. Child labor was rampant until reform movements succeeded in passing protective
    legislation.

    Environmental effects: Deforestation, air pollution from coal burning, and water
    contamination became serious problems. Rivers like the Thames became essentially open sewers.

    Political effects: Workers organized into unions and demanded rights. The Chartist movement
    pushed for democratic reforms. Eventually, the middle and working classes gained political
    representation.""",
        description="Excellent effects coverage, but ignores causes entirely",
        ground_truth=[UNMET, MET, MET, UNMET, UNMET],
    )

    dataset.add_item(
        text="""The French Revolution was caused by inequality between the nobility and common people.
    King Louis XVI was a weak ruler who couldn't solve France's financial problems. The
    storming of the Bastille in 1789 marked the beginning of major changes.

    The effects included the execution of the king and queen, the Reign of Terror, and
    eventually Napoleon taking power. The revolution inspired democratic movements across
    Europe and the Americas.""",
        description="Off-topic - discusses French Revolution instead",
        ground_truth=[UNMET, UNMET, MET, UNMET, MET],
    )

    dataset.add_item(
        text="""[Image attachment: factory_diagram.png]

    As shown in the diagram above, the process flow demonstrates the key mechanisms.
    Refer to Table 3.2 for the complete data analysis. The highlighted sections in
    the appendix provide additional context for the claims made in my previous
    submission.

    See also: Bibliography items 7-12 for supporting evidence.""",
        description="Unassessable - references missing attachments/context",
        ground_truth=[CANNOT_ASSESS, CANNOT_ASSESS, MET, CANNOT_ASSESS, CANNOT_ASSESS],
    )

    return dataset


# -----------------------------------------------------------------------------
# Metrics
# -----------------------------------------------------------------------------


def rmse(predictions: list[float], actuals: list[float]) -> float:
    """Root Mean Square Error."""
    n = len(predictions)
    if n == 0:
        return 0.0
    squared_errors = [(p - a) ** 2 for p, a in zip(predictions, actuals)]
    return math.sqrt(sum(squared_errors) / n)


def accuracy(
    predictions: list[CriterionVerdict], actuals: list[CriterionVerdict]
) -> float:
    """Binary accuracy."""
    if len(predictions) == 0:
        return 0.0
    correct = sum(1 for p, a in zip(predictions, actuals) if p == a)
    return correct / len(predictions)


def cohens_kappa(
    predictions: list[CriterionVerdict], actuals: list[CriterionVerdict]
) -> float:
    """Cohen's Kappa for binary classification."""
    n = len(predictions)
    if n == 0:
        return 0.0

    MET = CriterionVerdict.MET
    UNMET = CriterionVerdict.UNMET
    tp = sum(1 for p, a in zip(predictions, actuals) if p == MET and a == MET)
    tn = sum(1 for p, a in zip(predictions, actuals) if p == UNMET and a == UNMET)
    fp = sum(1 for p, a in zip(predictions, actuals) if p == MET and a == UNMET)
    fn = sum(1 for p, a in zip(predictions, actuals) if p == UNMET and a == MET)

    po = (tp + tn) / n
    p_yes = ((tp + fp) / n) * ((tp + fn) / n)
    p_no = ((tn + fn) / n) * ((tn + fp) / n)
    pe = p_yes + p_no

    if pe == 1.0:
        return 1.0
    return (po - pe) / (1 - pe)


def spearman_correlation(x: list[float], y: list[float]) -> float:
    """Spearman rank correlation coefficient."""
    n = len(x)
    if n < 2:
        return 0.0

    def rank(values: list[float]) -> list[float]:
        sorted_indices = sorted(range(len(values)), key=lambda i: values[i])
        ranks = [0.0] * len(values)
        i = 0
        while i < len(sorted_indices):
            j = i
            while (
                j < len(sorted_indices)
                and values[sorted_indices[j]] == values[sorted_indices[i]]
            ):
                j += 1
            avg_rank = (i + j + 1) / 2
            for k in range(i, j):
                ranks[sorted_indices[k]] = avg_rank
            i = j
        return ranks

    rx = rank(x)
    ry = rank(y)

    mean_rx = sum(rx) / n
    mean_ry = sum(ry) / n

    numerator = sum((rx[i] - mean_rx) * (ry[i] - mean_ry) for i in range(n))
    denom_x = math.sqrt(sum((rx[i] - mean_rx) ** 2 for i in range(n)))
    denom_y = math.sqrt(sum((ry[i] - mean_ry) ** 2 for i in range(n)))

    if denom_x == 0 or denom_y == 0:
        return 0.0
    return numerator / (denom_x * denom_y)


def kendall_tau(x: list[float], y: list[float]) -> float:
    """Kendall Tau-b correlation coefficient."""
    n = len(x)
    if n < 2:
        return 0.0

    concordant = 0
    discordant = 0
    ties_x = 0
    ties_y = 0

    for i in range(n):
        for j in range(i + 1, n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]

            if dx == 0 and dy == 0:
                ties_x += 1
                ties_y += 1
            elif dx == 0:
                ties_x += 1
            elif dy == 0:
                ties_y += 1
            elif (dx > 0 and dy > 0) or (dx < 0 and dy < 0):
                concordant += 1
            else:
                discordant += 1

    n_pairs = n * (n - 1) // 2
    denom = math.sqrt((n_pairs - ties_x) * (n_pairs - ties_y))
    if denom == 0:
        return 0.0
    return (concordant - discordant) / denom


def extract_verdicts(
    report: EvaluationReport, num_criteria: int
) -> list[CriterionVerdict]:
    """Extract CriterionVerdict verdicts from an EvaluationReport."""
    if report.report is None:
        return [CriterionVerdict.UNMET] * num_criteria
    return [cr.final_verdict for cr in report.report]


# -----------------------------------------------------------------------------
# Grading
# -----------------------------------------------------------------------------


async def grade_single_item(
    rubric: Rubric,
    grader: CriterionGrader,
    item: DataItem,
    item_idx: int,
    prompt: str,
) -> tuple[int, EvaluationReport]:
    """Grade a single data item."""
    result = await rubric.grade(
        to_grade=item.text,
        grader=grader,
        query=prompt,
    )
    return item_idx, result


async def main():
    # Create the dataset
    dataset = create_essay_grading_dataset()

    # Configure LLM with thinking enabled
    llm_config = LLMConfig(
        model="gemini/gemini-2.5-flash",
        temperature=0.0,
        thinking="medium",  # Enable reasoning for better evaluation quality
        cache_enabled=False,
    )

    # Create grader with CANNOT_ASSESS handling
    # Options: SKIP (default), ZERO, PARTIAL, FAIL
    grader = CriterionGrader(
        llm_config=llm_config,
        normalize=True,
        cannot_assess_config=CannotAssessConfig(
            strategy=CannotAssessStrategy.SKIP,  # Exclude unassessable from scoring
        ),
    )

    print("=" * 80)
    print("AutoRubric Demo: Criterion-Level Accuracy Evaluation")
    print(f"Model: {llm_config.model}")
    print(f"Thinking: {llm_config.thinking}")
    print("=" * 80)
    print(f"\nPrompt: {dataset.prompt}\n")
    print(f"Rubric Criteria (total positive weight: {dataset.total_positive_weight}):")
    for i, (criterion, name) in enumerate(
        zip(dataset.rubric.rubric, dataset.criterion_names)
    ):
        weight_str = (
            f"+{criterion.weight}" if criterion.weight > 0 else str(criterion.weight)
        )
        print(f"  {i + 1}. {name:10} [{weight_str:>6}]")
    print("\n" + "-" * 80)

    # Grade all items in parallel
    print(f"\nGrading all {len(dataset)} items in parallel...")
    tasks = [
        grade_single_item(dataset.rubric, grader, item, i + 1, dataset.prompt)
        for i, item in enumerate(dataset)
    ]
    results = await asyncio.gather(*tasks)
    results = sorted(results, key=lambda x: x[0])

    # Collect predictions and ground truth
    all_pred_verdicts: list[list[CriterionVerdict]] = []
    all_true_verdicts: list[list[CriterionVerdict]] = []
    all_pred_scores: list[float] = []
    all_true_scores: list[float] = []

    print("\n" + "=" * 80)
    print("INDIVIDUAL RESULTS")
    print("=" * 80)

    for (item_idx, result), item in zip(results, dataset):
        pred_verdicts = extract_verdicts(result, dataset.num_criteria)
        true_verdicts = item.ground_truth

        pred_score = result.score if not result.error else 0.0
        true_score = dataset.compute_weighted_score(true_verdicts)

        all_pred_verdicts.append(pred_verdicts)
        all_true_verdicts.append(true_verdicts)
        all_pred_scores.append(pred_score)
        all_true_scores.append(true_score)

        item_accuracy = accuracy(pred_verdicts, true_verdicts)
        score_error = abs(pred_score - true_score)

        print(f"\nItem {item_idx}: {item.description}")
        print(
            f"  Scores: Predicted={pred_score:.3f} | Actual={true_score:.3f} | Error={score_error:.3f}"
        )
        # Show CANNOT_ASSESS count if any
        if result.cannot_assess_count > 0:
            print(f"  Could not assess: {result.cannot_assess_count} criteria")
        print(
            f"  Criterion Accuracy: {item_accuracy:.0%} "
            f"({sum(1 for p, t in zip(pred_verdicts, true_verdicts) if p == t)}/{dataset.num_criteria})"
        )
        # Show usage and cost
        if result.token_usage:
            usage = result.token_usage
            cost_str = (
                f"${result.completion_cost:.6f}" if result.completion_cost else "N/A"
            )
            print(
                f"  LLM Usage: {usage.total_tokens:,} tokens "
                f"(prompt: {usage.prompt_tokens:,}, completion: {usage.completion_tokens:,}) | Cost: {cost_str}"
            )

        # Show per-criterion comparison
        print("  Criteria:  ", end="")
        for name in dataset.criterion_names:
            print(f"{name[:6]:>8}", end="")
        print()
        print("  Predicted: ", end="")
        for v in pred_verdicts:
            print(f"{v.value:>8}", end="")
        print()
        print("  Actual:    ", end="")
        for v in true_verdicts:
            print(f"{v.value:>8}", end="")
        print()
        print("  Match:     ", end="")
        for p, t in zip(pred_verdicts, true_verdicts):
            print(f"{'=':>8}" if p == t else f"{'X':>8}", end="")
        print()

    # -----------------------------------------------------------------------------
    # Per-Criterion Metrics
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("PER-CRITERION METRICS")
    print("=" * 80)

    print(f"\n{'Criterion':<12} {'Accuracy':>10} {'Kappa':>10} {'RMSE':>10}")
    print("-" * 45)

    criterion_accuracies = []
    criterion_kappas = []
    criterion_rmses = []

    for c_idx, name in enumerate(dataset.criterion_names):
        pred_c = [v[c_idx] for v in all_pred_verdicts]
        true_c = [v[c_idx] for v in all_true_verdicts]

        acc = accuracy(pred_c, true_c)
        kappa = cohens_kappa(pred_c, true_c)
        # Convert CriterionVerdict to float for RMSE (MET=1.0, UNMET=0.0)
        criterion_rmse = rmse(
            [1.0 if p == CriterionVerdict.MET else 0.0 for p in pred_c],
            [1.0 if t == CriterionVerdict.MET else 0.0 for t in true_c],
        )

        criterion_accuracies.append(acc)
        criterion_kappas.append(kappa)
        criterion_rmses.append(criterion_rmse)

        print(f"{name:<12} {acc:>10.1%} {kappa:>10.3f} {criterion_rmse:>10.3f}")

    print("-" * 45)
    print(
        f"{'Average':<12} {sum(criterion_accuracies)/len(criterion_accuracies):>10.1%} "
        f"{sum(criterion_kappas)/len(criterion_kappas):>10.3f} "
        f"{sum(criterion_rmses)/len(criterion_rmses):>10.3f}"
    )

    # -----------------------------------------------------------------------------
    # Cumulative Score Metrics
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("CUMULATIVE SCORE METRICS")
    print("=" * 80)

    score_rmse = rmse(all_pred_scores, all_true_scores)
    spearman = spearman_correlation(all_pred_scores, all_true_scores)
    kendall = kendall_tau(all_pred_scores, all_true_scores)

    print(f"\nRMSE:                    {score_rmse:.4f}")
    print(f"Spearman Correlation:    {spearman:.4f}")
    print(f"Kendall Tau:             {kendall:.4f}")

    # Interpretation
    print("\nInterpretation:")
    if spearman >= 0.9:
        print("  Spearman: Very strong positive correlation")
    elif spearman >= 0.7:
        print("  Spearman: Strong positive correlation")
    elif spearman >= 0.5:
        print("  Spearman: Moderate positive correlation")
    elif spearman >= 0.3:
        print("  Spearman: Weak positive correlation")
    else:
        print("  Spearman: Very weak or no correlation")

    if kendall >= 0.8:
        print("  Kendall:  Almost perfect agreement")
    elif kendall >= 0.6:
        print("  Kendall:  Substantial agreement")
    elif kendall >= 0.4:
        print("  Kendall:  Moderate agreement")
    elif kendall >= 0.2:
        print("  Kendall:  Fair agreement")
    else:
        print("  Kendall:  Slight agreement")

    # -----------------------------------------------------------------------------
    # Score Comparison Table
    # -----------------------------------------------------------------------------
    print("\n" + "-" * 80)
    print("Score Comparison:")
    print(f"{'Item':<10} {'Predicted':>12} {'Actual':>12} {'Error':>12}")
    print("-" * 50)
    for i, (pred, actual) in enumerate(zip(all_pred_scores, all_true_scores)):
        error = abs(pred - actual)
        print(f"{i + 1:<10} {pred:>12.3f} {actual:>12.3f} {error:>12.3f}")
    print("-" * 50)
    print(
        f"{'Mean':<10} {sum(all_pred_scores)/len(all_pred_scores):>12.3f} "
        f"{sum(all_true_scores)/len(all_true_scores):>12.3f} {score_rmse:>12.3f} (RMSE)"
    )

    # -----------------------------------------------------------------------------
    # Summary
    # -----------------------------------------------------------------------------
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)

    overall_criterion_acc = sum(
        1
        for pv, tv in zip(all_pred_verdicts, all_true_verdicts)
        for p, t in zip(pv, tv)
        if p == t
    ) / (len(all_pred_verdicts) * dataset.num_criteria)

    print(f"\nDataset: {len(dataset)} items, {dataset.num_criteria} criteria")
    print(f"Overall Criterion Accuracy: {overall_criterion_acc:.1%}")
    print(
        f"Average Criterion Kappa:    {sum(criterion_kappas)/len(criterion_kappas):.3f}"
    )
    print(f"Score RMSE:                 {score_rmse:.4f}")
    print(f"Score Spearman r:           {spearman:.4f}")
    print(f"Score Kendall tau:          {kendall:.4f}")

    # -----------------------------------------------------------------------------
    # LLM Usage and Cost Summary
    # -----------------------------------------------------------------------------
    all_reports = [result for _, result in results]
    total_usage, total_cost = aggregate_evaluation_usage(all_reports)

    print("\n" + "-" * 80)
    print("LLM USAGE AND COST")
    print("-" * 80)

    if total_usage:
        print(f"\nTotal Token Usage:")
        print(f"  Prompt tokens:     {total_usage.prompt_tokens:>12,}")
        print(f"  Completion tokens: {total_usage.completion_tokens:>12,}")
        print(f"  Total tokens:      {total_usage.total_tokens:>12,}")
        if total_usage.cache_creation_input_tokens > 0:
            print(
                f"  Cache created:     {total_usage.cache_creation_input_tokens:>12,}"
            )
        if total_usage.cache_read_input_tokens > 0:
            print(f"  Cache hits:        {total_usage.cache_read_input_tokens:>12,}")
        print(f"\nTotal Cost: ${total_cost:.6f}" if total_cost else "\nTotal Cost: N/A")
        if total_cost:
            cost_per_item = total_cost / len(dataset)
            print(f"Cost per Item: ${cost_per_item:.6f}")
    else:
        print("\nNo usage data available (provider may not support usage tracking)")


if __name__ == "__main__":
    if not os.environ.get("GEMINI_API_KEY"):
        print("Warning: GEMINI_API_KEY not set. Set it to run the demo.")
        print("  export GEMINI_API_KEY='your-key-here'")
        print("\nAlternatively, modify llm_config to use a different provider.")
        exit(1)

    asyncio.run(main())
