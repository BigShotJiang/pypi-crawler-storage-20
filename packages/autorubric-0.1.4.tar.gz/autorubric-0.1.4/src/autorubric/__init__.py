from pathlib import Path

from autorubric.dataset import DataItem, RubricDataset
from autorubric.llm import (
    GenerateResult,
    LLMClient,
    LLMConfig,
    ThinkingConfig,
    ThinkingLevel,
    ThinkingLevelLiteral,
    ThinkingParam,
    generate,
)
from autorubric.rubric import Rubric
from autorubric.types import (
    AggregationStrategy,
    CannotAssessConfig,
    CannotAssessStrategy,
    CountFn,
    Criterion,
    CriterionJudgment,
    CriterionReport,
    CriterionVerdict,
    EnsembleCriterionReport,
    EnsembleEvaluationReport,
    EvaluationReport,
    FewShotConfig,
    FewShotExample,
    JudgeVote,
    LengthPenalty,
    PenaltyType,
    ThinkingOutputDict,
    ToGradeInput,
    TokenUsage,
)
from autorubric.utils import (
    aggregate_completion_cost,
    aggregate_evaluation_usage,
    aggregate_token_usage,
    compute_length_penalty,
    normalize_to_grade_input,
    parse_thinking_output,
    word_count,
)

# Read version from VERSION file at project root
_version_file = Path(__file__).parent.parent.parent / "VERSION"
__version__ = _version_file.read_text().strip() if _version_file.exists() else "0.0.0"
__all__ = [
    # Dataset classes
    "DataItem",
    "RubricDataset",
    # LLM Infrastructure
    "GenerateResult",
    "LLMClient",
    "LLMConfig",
    "ThinkingConfig",
    "ThinkingLevel",
    "ThinkingLevelLiteral",
    "ThinkingParam",
    "generate",
    # Core types
    "AggregationStrategy",
    "CannotAssessConfig",
    "CannotAssessStrategy",
    "CountFn",
    "Criterion",
    "CriterionJudgment",
    "CriterionReport",
    "CriterionVerdict",
    "EvaluationReport",
    "LengthPenalty",
    "PenaltyType",
    "Rubric",
    "ThinkingOutputDict",
    "ToGradeInput",
    "TokenUsage",
    # Few-shot types
    "FewShotConfig",
    "FewShotExample",
    # Ensemble types
    "EnsembleCriterionReport",
    "EnsembleEvaluationReport",
    "JudgeVote",
    # Utility functions
    "aggregate_completion_cost",
    "aggregate_evaluation_usage",
    "aggregate_token_usage",
    "compute_length_penalty",
    "normalize_to_grade_input",
    "parse_thinking_output",
    "word_count",
]
__name__ = "autorubric"
__author__ = "Delip Rao"
