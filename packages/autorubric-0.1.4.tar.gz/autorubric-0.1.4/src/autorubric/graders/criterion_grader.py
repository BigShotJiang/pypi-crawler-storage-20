"""Unified criterion-based grader with compositional few-shot and ensemble support."""

from __future__ import annotations

import asyncio
import logging
import random
from collections import defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from pydantic import ValidationError

from autorubric.graders.base import Grader
from autorubric.llm import GenerateResult, LLMClient, LLMConfig
from autorubric.prompts import (
    FEW_SHOT_SYSTEM_PROMPT_ADDITION,
    GRADER_SYSTEM_PROMPT_DEFAULT,
    build_few_shot_user_prompt,
    build_user_prompt,
)
from autorubric.types import (
    AggregationStrategy,
    CannotAssessConfig,
    CannotAssessStrategy,
    Criterion,
    CriterionJudgment,
    CriterionReport,
    CriterionVerdict,
    EnsembleCriterionReport,
    EnsembleEvaluationReport,
    FewShotConfig,
    FewShotExample,
    JudgeVote,
    LengthPenalty,
    TokenUsage,
)

if TYPE_CHECKING:
    from autorubric.dataset import RubricDataset

logger = logging.getLogger(__name__)


@dataclass
class JudgeSpec:
    """Specification for a single judge in an ensemble.

    Attributes:
        llm_config: Configuration for this judge's LLM.
        judge_id: Unique identifier for this judge (e.g., "gpt-4", "claude-sonnet").
        weight: Voting weight for weighted aggregation (default 1.0).
    """

    llm_config: LLMConfig
    judge_id: str
    weight: float = 1.0


@dataclass
class CriterionResult:
    """Result from evaluating a single criterion by a single judge."""

    report: CriterionReport
    usage: TokenUsage | None = None
    cost: float | None = None


@dataclass
class JudgeCriterionResults:
    """All criterion results from a single judge."""

    judge_id: str
    weight: float
    criterion_results: list[CriterionResult] = field(default_factory=list)

    @property
    def reports(self) -> list[CriterionReport]:
        return [r.report for r in self.criterion_results]

    @property
    def total_usage(self) -> TokenUsage | None:
        usages = [r.usage for r in self.criterion_results if r.usage is not None]
        return sum(usages, TokenUsage()) if usages else None

    @property
    def total_cost(self) -> float | None:
        costs = [r.cost for r in self.criterion_results if r.cost is not None]
        return sum(costs) if costs else None


class CriterionGrader(Grader):
    """Unified criterion-based grader with compositional few-shot and ensemble support.

    This grader evaluates each criterion independently and supports:
    - Single LLM mode (via llm_config)
    - Ensemble mode with multiple judges (via judges)
    - Few-shot prompting (via training_data + few_shot_config)

    All combinations work: single LLM, single + few-shot, ensemble, ensemble + few-shot.

    Parameters are orthogonal:
    - llm_config OR judges: Choose single-LLM or ensemble mode
    - training_data + few_shot_config: Enable few-shot prompting (applies to all judges)

    Example:
        >>> from autorubric import LLMConfig, FewShotConfig, RubricDataset
        >>> from autorubric.graders import CriterionGrader, JudgeSpec
        >>>
        >>> # Single LLM
        >>> grader = CriterionGrader(llm_config=LLMConfig(model="gemini/gemini-3-flash-preview"))
        >>>
        >>> # Single LLM + few-shot
        >>> train, test = dataset.split_train_test(n_train=100)
        >>> grader = CriterionGrader(
        ...     llm_config=LLMConfig(model="gemini/gemini-3-flash-preview"),
        ...     training_data=train,
        ...     few_shot_config=FewShotConfig(n_examples=3),
        ... )
        >>>
        >>> # Ensemble
        >>> grader = CriterionGrader(
        ...     judges=[
        ...         JudgeSpec(LLMConfig(model="gemini/gemini-3-flash-preview"), "gemini"),
        ...         JudgeSpec(LLMConfig(model="anthropic/claude-sonnet-4-5-20250929"), "claude"),
        ...     ],
        ...     aggregation="majority",
        ... )
        >>>
        >>> # Ensemble + few-shot
        >>> grader = CriterionGrader(
        ...     judges=[JudgeSpec(...), JudgeSpec(...)],
        ...     aggregation="majority",
        ...     training_data=train,
        ...     few_shot_config=FewShotConfig(n_examples=3),
        ... )
    """

    def __init__(
        self,
        *,
        # Single LLM mode
        llm_config: LLMConfig | None = None,
        # Ensemble mode (overrides llm_config)
        judges: list[JudgeSpec] | None = None,
        aggregation: AggregationStrategy = "majority",
        # Few-shot mode (orthogonal - applies to all judges)
        training_data: RubricDataset | None = None,
        few_shot_config: FewShotConfig | None = None,
        # Common parameters
        system_prompt: str | None = None,
        length_penalty: LengthPenalty | None = None,
        normalize: bool = True,
        cannot_assess_config: CannotAssessConfig | None = None,
    ):
        """Initialize the criterion grader.

        Args:
            llm_config: Configuration for single-LLM mode. Mutually exclusive with judges.
            judges: List of JudgeSpec for ensemble mode. Mutually exclusive with llm_config.
            aggregation: Strategy for aggregating votes in ensemble mode.
            training_data: Dataset for few-shot examples. If provided, enables few-shot prompting.
            few_shot_config: Configuration for few-shot example selection.
            system_prompt: Custom system prompt. If None, uses default (with few-shot addition if applicable).
            length_penalty: Optional length penalty configuration.
            normalize: If True, normalize score to [0, 1]. If False, return raw sum.
            cannot_assess_config: Configuration for handling CANNOT_ASSESS verdicts.

        Raises:
            ValueError: If neither llm_config nor judges is provided, or both are provided.
        """
        super().__init__(length_penalty=length_penalty, normalize=normalize)

        # Validate: must have either llm_config or judges, not both, not neither
        if llm_config is None and judges is None:
            raise ValueError("Must provide either llm_config or judges")
        if llm_config is not None and judges is not None:
            raise ValueError("Cannot provide both llm_config and judges")

        # Normalize to ensemble representation (single LLM = ensemble of 1)
        if llm_config is not None:
            self._judges = [JudgeSpec(llm_config=llm_config, judge_id="default", weight=1.0)]
        else:
            self._judges = judges  # type: ignore

        self._aggregation = aggregation
        self._training_data = training_data
        self._few_shot_config = few_shot_config or FewShotConfig()
        self._cannot_assess_config = cannot_assess_config or CannotAssessConfig()

        # Build system prompt
        if system_prompt is None:
            self._system_prompt = GRADER_SYSTEM_PROMPT_DEFAULT
            if training_data is not None:
                self._system_prompt += FEW_SHOT_SYSTEM_PROMPT_ADDITION
        else:
            self._system_prompt = system_prompt

        # Create LLM clients for each judge
        self._clients = {
            judge.judge_id: LLMClient(judge.llm_config)
            for judge in self._judges
        }

        # Pre-compute few-shot examples if training data provided
        self._criterion_examples: dict[int, list[FewShotExample]] = {}
        if training_data is not None:
            self._prepare_examples()

    @property
    def is_ensemble(self) -> bool:
        """Whether this grader uses multiple judges."""
        return len(self._judges) > 1

    @property
    def has_few_shot(self) -> bool:
        """Whether this grader uses few-shot prompting."""
        return self._training_data is not None

    # =========================================================================
    # Few-Shot Example Preparation
    # =========================================================================

    def _prepare_examples(self) -> None:
        """Pre-compute few-shot examples for each criterion."""
        if self._training_data is None:
            return

        n_criteria = self._training_data.num_criteria
        for criterion_idx in range(n_criteria):
            examples = self._select_examples_for_criterion(criterion_idx)
            self._criterion_examples[criterion_idx] = examples

    def _select_examples_for_criterion(self, criterion_idx: int) -> list[FewShotExample]:
        """Select stratified examples for a specific criterion."""
        if self._training_data is None:
            return []

        config = self._few_shot_config
        rng = random.Random(config.seed)

        # Group items by verdict for this criterion
        verdict_groups: dict[CriterionVerdict, list] = {
            CriterionVerdict.MET: [],
            CriterionVerdict.UNMET: [],
            CriterionVerdict.CANNOT_ASSESS: [],
        }

        for item in self._training_data:
            if item.ground_truth is None:
                continue
            verdict = item.ground_truth[criterion_idx]
            verdict_groups[verdict].append(item)

        available_verdicts = [v for v, items in verdict_groups.items() if items]
        if not available_verdicts:
            return []

        n_examples = config.n_examples

        if config.balance_verdicts and len(available_verdicts) > 1:
            return self._balanced_selection(verdict_groups, n_examples, criterion_idx, rng)
        else:
            all_items = [item for items in verdict_groups.values() for item in items]
            rng.shuffle(all_items)
            return [
                FewShotExample(
                    text=item.text,
                    verdict=item.ground_truth[criterion_idx],  # type: ignore
                    reason=None,
                )
                for item in all_items[:n_examples]
            ]

    def _balanced_selection(
        self,
        verdict_groups: dict[CriterionVerdict, list],
        n_examples: int,
        criterion_idx: int,
        rng: random.Random,
    ) -> list[FewShotExample]:
        """Select examples with balanced verdict distribution."""
        examples: list[FewShotExample] = []
        available_verdicts = [v for v, items in verdict_groups.items() if items]

        base_per_verdict = n_examples // len(available_verdicts)
        remainder = n_examples % len(available_verdicts)

        for i, verdict in enumerate(available_verdicts):
            items = verdict_groups[verdict].copy()
            rng.shuffle(items)
            count = base_per_verdict + (1 if i < remainder else 0)
            count = min(count, len(items))

            for item in items[:count]:
                examples.append(
                    FewShotExample(
                        text=item.text,
                        verdict=item.ground_truth[criterion_idx],  # type: ignore
                        reason=None,
                    )
                )

        # Fill remaining slots if some groups were too small
        if len(examples) < n_examples:
            used_texts = {e.text for e in examples}
            all_remaining = [
                item
                for items in verdict_groups.values()
                for item in items
                if item.text not in used_texts
            ]
            rng.shuffle(all_remaining)
            for item in all_remaining[: n_examples - len(examples)]:
                examples.append(
                    FewShotExample(
                        text=item.text,
                        verdict=item.ground_truth[criterion_idx],  # type: ignore
                        reason=None,
                    )
                )

        return examples

    # =========================================================================
    # Single Criterion Evaluation
    # =========================================================================

    async def _judge_single_criterion(
        self,
        judge: JudgeSpec,
        criterion: Criterion,
        criterion_idx: int,
        to_grade: str,
        query: str | None = None,
    ) -> CriterionResult:
        """Judge a single criterion with a single judge."""
        client = self._clients[judge.judge_id]
        examples = self._criterion_examples.get(criterion_idx, [])

        # Build prompt (with or without few-shot examples)
        if examples:
            user_prompt = build_few_shot_user_prompt(
                criterion=criterion,
                to_grade=to_grade,
                examples=examples,
                query=query,
                include_reason=self._few_shot_config.include_reason,
            )
        else:
            user_prompt = build_user_prompt(criterion, to_grade, query)

        try:
            result: GenerateResult = await client.generate(
                system_prompt=self._system_prompt,
                user_prompt=user_prompt,
                response_format=CriterionJudgment,
                return_result=True,
            )

            judgment: CriterionJudgment = result.parsed
            report = CriterionReport(
                requirement=criterion.requirement,
                verdict=judgment.criterion_status,
                reason=judgment.explanation,
                weight=criterion.weight,
                name=criterion.name,
            )
            return CriterionResult(report=report, usage=result.usage, cost=result.cost)

        except (ValidationError, Exception) as e:
            # Conservative default: worst case for each criterion type
            default_verdict = (
                CriterionVerdict.MET if criterion.weight < 0 else CriterionVerdict.UNMET
            )
            logger.warning(
                f"Error evaluating criterion '{criterion.requirement[:50]}...' "
                f"with judge '{judge.judge_id}': {e}"
            )
            report = CriterionReport(
                requirement=criterion.requirement,
                verdict=default_verdict,
                reason=f"Error parsing judge response: {str(e)}",
                weight=criterion.weight,
                name=criterion.name,
            )
            return CriterionResult(report=report, usage=None, cost=None)

    async def _judge_all_criteria_for_judge(
        self,
        judge: JudgeSpec,
        rubric: list[Criterion],
        to_grade: str,
        query: str | None = None,
    ) -> JudgeCriterionResults:
        """Evaluate all criteria for a single judge (parallel per criterion)."""
        tasks = [
            self._judge_single_criterion(judge, criterion, idx, to_grade, query)
            for idx, criterion in enumerate(rubric)
        ]
        results = list(await asyncio.gather(*tasks))
        return JudgeCriterionResults(
            judge_id=judge.judge_id,
            weight=judge.weight,
            criterion_results=results,
        )

    # =========================================================================
    # Judge and Aggregate (Grader Interface)
    # =========================================================================

    async def judge(
        self, to_grade: str, rubric: list[Criterion], query: str | None = None
    ) -> list[JudgeCriterionResults]:
        """Judge all criteria with all judges (parallel across judges)."""
        tasks = [
            self._judge_all_criteria_for_judge(judge, rubric, to_grade, query)
            for judge in self._judges
        ]
        return list(await asyncio.gather(*tasks))

    async def aggregate(
        self, judge_results: list[JudgeCriterionResults], *, normalize: bool = True
    ) -> EnsembleEvaluationReport:
        """Aggregate results from all judges into final report."""
        if not judge_results:
            return EnsembleEvaluationReport(
                score=0.0,
                raw_score=0.0,
                llm_raw_score=0.0,
                error="No judge results to aggregate",
            )

        n_criteria = len(judge_results[0].criterion_results)

        # Build ensemble criterion reports
        ensemble_reports: list[EnsembleCriterionReport] = []
        for criterion_idx in range(n_criteria):
            votes = []
            criterion = None

            for judge_result in judge_results:
                cr = judge_result.criterion_results[criterion_idx]
                criterion = cr.report
                votes.append(
                    JudgeVote(
                        judge_id=judge_result.judge_id,
                        verdict=cr.report.verdict,
                        reason=cr.report.reason,
                        weight=judge_result.weight,
                    )
                )

            final_verdict, final_reason = self._aggregate_votes(votes)

            ensemble_reports.append(
                EnsembleCriterionReport(
                    criterion=Criterion(
                        weight=criterion.weight,  # type: ignore
                        requirement=criterion.requirement,  # type: ignore
                        name=criterion.name,  # type: ignore
                    ),
                    final_verdict=final_verdict,
                    final_reason=final_reason,
                    votes=votes,
                )
            )

        # Calculate per-judge scores
        judge_scores = {}
        for judge_result in judge_results:
            score = self._calculate_score_from_reports(judge_result.reports, normalize)
            judge_scores[judge_result.judge_id] = score

        # Calculate final score from aggregated verdicts
        final_reports = [
            CriterionReport(
                weight=er.criterion.weight,
                requirement=er.criterion.requirement,
                name=er.criterion.name,
                verdict=er.final_verdict,
                reason=er.final_reason,
            )
            for er in ensemble_reports
        ]
        final_score = self._calculate_score_from_reports(final_reports, normalize)
        raw_score = self._calculate_score_from_reports(final_reports, normalize=False)

        # Calculate agreement
        mean_agreement = (
            sum(er.agreement for er in ensemble_reports) / len(ensemble_reports)
            if ensemble_reports
            else 1.0
        )

        # Count CANNOT_ASSESS
        cannot_assess_count = sum(
            1 for er in ensemble_reports if er.final_verdict == CriterionVerdict.CANNOT_ASSESS
        )

        # Aggregate token usage and cost
        total_usage = TokenUsage()
        total_cost = 0.0
        for jr in judge_results:
            if jr.total_usage:
                total_usage = total_usage + jr.total_usage
            if jr.total_cost:
                total_cost += jr.total_cost

        return EnsembleEvaluationReport(
            score=final_score,
            raw_score=raw_score,
            llm_raw_score=raw_score,
            report=ensemble_reports,
            judge_scores=judge_scores,
            mean_agreement=mean_agreement,
            cannot_assess_count=cannot_assess_count,
            token_usage=total_usage if total_usage.total_tokens > 0 else None,
            completion_cost=total_cost if total_cost > 0 else None,
        )

    def _aggregate_votes(
        self, votes: list[JudgeVote]
    ) -> tuple[CriterionVerdict, str]:
        """Aggregate votes from multiple judges into a single verdict."""
        if not votes:
            return CriterionVerdict.CANNOT_ASSESS, "No votes"

        # Filter out CANNOT_ASSESS for aggregation (unless all are CANNOT_ASSESS)
        assessable_votes = [v for v in votes if v.verdict != CriterionVerdict.CANNOT_ASSESS]
        if not assessable_votes:
            return CriterionVerdict.CANNOT_ASSESS, "All judges could not assess"

        met_weight = sum(v.weight for v in assessable_votes if v.verdict == CriterionVerdict.MET)
        unmet_weight = sum(v.weight for v in assessable_votes if v.verdict == CriterionVerdict.UNMET)
        total_weight = met_weight + unmet_weight

        if self._aggregation == "majority":
            verdict = CriterionVerdict.MET if met_weight > unmet_weight else CriterionVerdict.UNMET
        elif self._aggregation == "weighted":
            verdict = CriterionVerdict.MET if met_weight > unmet_weight else CriterionVerdict.UNMET
        elif self._aggregation == "unanimous":
            verdict = CriterionVerdict.MET if unmet_weight == 0 else CriterionVerdict.UNMET
        elif self._aggregation == "any":
            verdict = CriterionVerdict.MET if met_weight > 0 else CriterionVerdict.UNMET
        else:
            verdict = CriterionVerdict.MET if met_weight > unmet_weight else CriterionVerdict.UNMET

        # Combine reasons
        reasons = [f"{v.judge_id}: {v.reason}" for v in votes]
        combined_reason = " | ".join(reasons)

        return verdict, combined_reason

    def _calculate_score_from_reports(
        self, reports: list[CriterionReport], normalize: bool
    ) -> float:
        """Calculate score from criterion reports using CANNOT_ASSESS config."""
        config = self._cannot_assess_config

        cannot_assess_count = sum(
            1 for r in reports if r.verdict == CriterionVerdict.CANNOT_ASSESS
        )

        assessable = [r for r in reports if r.verdict != CriterionVerdict.CANNOT_ASSESS]
        cannot_assess = [r for r in reports if r.verdict == CriterionVerdict.CANNOT_ASSESS]

        # Apply strategy
        if config.strategy == CannotAssessStrategy.SKIP:
            working_reports = assessable
        elif config.strategy == CannotAssessStrategy.FAIL:
            working_reports = assessable + [
                CriterionReport(
                    requirement=r.requirement,
                    verdict=CriterionVerdict.UNMET if r.weight > 0 else CriterionVerdict.MET,
                    reason=r.reason,
                    weight=r.weight,
                    name=r.name,
                )
                for r in cannot_assess
            ]
        elif config.strategy == CannotAssessStrategy.ZERO:
            working_reports = assessable + [
                CriterionReport(
                    requirement=r.requirement,
                    verdict=CriterionVerdict.UNMET,
                    reason=r.reason,
                    weight=r.weight,
                    name=r.name,
                )
                for r in cannot_assess
            ]
        else:  # PARTIAL
            working_reports = assessable

        # Calculate weights
        if config.strategy == CannotAssessStrategy.SKIP:
            total_positive_weight = sum(max(0.0, r.weight) for r in working_reports)
            total_negative_weight = sum(abs(r.weight) for r in working_reports if r.weight < 0)
        else:
            total_positive_weight = sum(max(0.0, r.weight) for r in reports)
            total_negative_weight = sum(abs(r.weight) for r in reports if r.weight < 0)

        # Calculate weighted sum
        weighted_sum = sum(
            (1.0 if r.verdict == CriterionVerdict.MET else 0.0) * r.weight
            for r in working_reports
        )

        # Add partial credit for PARTIAL strategy
        if config.strategy == CannotAssessStrategy.PARTIAL:
            for r in cannot_assess:
                if r.weight > 0:
                    weighted_sum += config.partial_credit * r.weight

        if not normalize:
            return weighted_sum

        if total_positive_weight > 0:
            return max(0.0, min(1.0, weighted_sum / total_positive_weight))
        elif total_negative_weight > 0:
            return max(0.0, min(1.0, 1.0 + weighted_sum / total_negative_weight))
        else:
            return 0.0
