"""Dataset classes for rubric-based evaluation.

This module provides data structures for organizing evaluation datasets with
ground truth labels, supporting both training and evaluation workflows.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Iterator

from autorubric.rubric import Rubric
from autorubric.types import CriterionVerdict

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class DataItem:
    """A single item to be graded, optionally with ground truth verdicts.

    Attributes:
        text: The text content to be evaluated.
        description: A brief description of this item (e.g., "High quality response").
        ground_truth: Optional list of CriterionVerdict values, one per criterion.
            Used for computing evaluation metrics against LLM predictions.

    Example:
        >>> item = DataItem(
        ...     text="The Industrial Revolution began in Britain around 1760...",
        ...     description="Excellent essay covering all criteria",
        ...     ground_truth=[CriterionVerdict.MET, CriterionVerdict.MET, CriterionVerdict.UNMET]
        ... )
    """

    text: str
    description: str
    ground_truth: list[CriterionVerdict] | None = None

    def __post_init__(self) -> None:
        """Validate ground truth values are CriterionVerdict if provided."""
        if self.ground_truth is not None:
            for v in self.ground_truth:
                if not isinstance(v, CriterionVerdict):
                    raise ValueError(
                        f"Ground truth values must be CriterionVerdict, got {type(v).__name__}"
                    )


@dataclass
class RubricDataset:
    """A collection of DataItems tied to a specific prompt and rubric.

    The RubricDataset encapsulates:
    - The prompt that generated the responses
    - The rubric used for evaluation
    - A collection of DataItems with optional ground truth labels

    This is useful for:
    - Evaluating LLM grader accuracy against human judgments
    - Training reward models with labeled data
    - Benchmarking different grading strategies

    Attributes:
        prompt: The prompt/question that items are responses to.
        rubric: The Rubric used to evaluate items.
        items: List of DataItem instances to evaluate.

    Example:
        >>> from autorubric import Rubric, Criterion, CriterionVerdict
        >>> rubric = Rubric([
        ...     Criterion(name="Accuracy", weight=10.0, requirement="Factually correct"),
        ...     Criterion(name="Clarity", weight=5.0, requirement="Clear and concise"),
        ... ])
        >>> dataset = RubricDataset(
        ...     prompt="Explain photosynthesis",
        ...     rubric=rubric,
        ... )
        >>> dataset.add_item(
        ...     text="Photosynthesis is the process...",
        ...     description="Good response",
        ...     ground_truth=[CriterionVerdict.MET, CriterionVerdict.MET]
        ... )
    """

    prompt: str
    rubric: Rubric
    items: list[DataItem] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Validate dataset consistency."""
        for i, item in enumerate(self.items):
            if item.ground_truth is not None and len(item.ground_truth) != len(
                self.rubric.rubric
            ):
                raise ValueError(
                    f"Item {i} has {len(item.ground_truth)} ground truth values, "
                    f"but rubric has {len(self.rubric.rubric)} criteria"
                )

    @property
    def criterion_names(self) -> list[str]:
        """Get criterion names from rubric (falls back to 'C{index}' if name is None)."""
        return [c.name or f"C{i+1}" for i, c in enumerate(self.rubric.rubric)]

    @property
    def num_criteria(self) -> int:
        """Number of criteria in the rubric."""
        return len(self.rubric.rubric)

    @property
    def total_positive_weight(self) -> float:
        """Sum of all positive criterion weights."""
        return sum(c.weight for c in self.rubric.rubric if c.weight > 0)

    def compute_weighted_score(
        self, verdicts: list[CriterionVerdict], normalize: bool = True
    ) -> float:
        """Compute weighted score from CriterionVerdict verdicts.

        Args:
            verdicts: List of CriterionVerdict values, one per criterion.
            normalize: If True, normalize score to [0, 1]. If False, return raw sum.

        Returns:
            Weighted score based on criterion weights and verdicts.
        """
        score = 0.0
        for i, verdict in enumerate(verdicts):
            weight = self.rubric.rubric[i].weight
            # MET contributes weight, UNMET contributes 0
            if verdict == CriterionVerdict.MET:
                score += weight
        if normalize:
            return max(0.0, min(1.0, score / self.total_positive_weight))
        return score

    def add_item(
        self,
        text: str,
        description: str,
        ground_truth: list[CriterionVerdict] | None = None,
    ) -> None:
        """Add a new item to the dataset.

        Args:
            text: The text content to be evaluated.
            description: A brief description of this item.
            ground_truth: Optional list of CriterionVerdict values.

        Raises:
            ValueError: If ground_truth length doesn't match rubric criteria count.
        """
        item = DataItem(text=text, description=description, ground_truth=ground_truth)
        if item.ground_truth is not None and len(item.ground_truth) != len(
            self.rubric.rubric
        ):
            raise ValueError(
                f"Ground truth has {len(item.ground_truth)} values, "
                f"but rubric has {len(self.rubric.rubric)} criteria"
            )
        self.items.append(item)

    def __len__(self) -> int:
        """Return number of items in the dataset."""
        return len(self.items)

    def __iter__(self) -> Iterator[DataItem]:
        """Iterate over items in the dataset."""
        return iter(self.items)

    def __getitem__(self, idx: int) -> DataItem:
        """Get item by index."""
        return self.items[idx]

    # =========================================================================
    # Serialization
    # =========================================================================

    def to_json(self, indent: int | None = 2) -> str:
        """Serialize the dataset to a JSON string.

        Args:
            indent: Number of spaces for indentation. None for compact output.

        Returns:
            JSON string representation of the dataset.
        """
        data: dict[str, Any] = {
            "prompt": self.prompt,
            "rubric": [
                {
                    "name": c.name,
                    "weight": c.weight,
                    "requirement": c.requirement,
                }
                for c in self.rubric.rubric
            ],
            "items": [
                {
                    "text": item.text,
                    "description": item.description,
                    "ground_truth": (
                        [v.value for v in item.ground_truth]
                        if item.ground_truth is not None
                        else None
                    ),
                }
                for item in self.items
            ],
        }
        return json.dumps(data, indent=indent)

    def to_file(self, path: str | Path) -> None:
        """Save dataset to a JSON file.

        Args:
            path: Path to write the JSON file.
        """
        from pathlib import Path

        Path(path).write_text(self.to_json(), encoding="utf-8")

    @classmethod
    def from_json(cls, json_string: str) -> RubricDataset:
        """Deserialize a dataset from a JSON string.

        Args:
            json_string: JSON string representation of the dataset.

        Returns:
            RubricDataset instance.

        Raises:
            ValueError: If the JSON is invalid or missing required fields.
        """
        try:
            data = json.loads(json_string)
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse JSON: {e}") from e

        if not isinstance(data, dict):
            raise ValueError(f"Expected JSON object, got {type(data).__name__}")

        # Validate required fields
        if "prompt" not in data:
            raise ValueError("Missing required field: 'prompt'")
        if "rubric" not in data:
            raise ValueError("Missing required field: 'rubric'")

        # Parse rubric
        rubric = Rubric.from_dict(data["rubric"])

        # Parse items
        items: list[DataItem] = []
        for i, item_data in enumerate(data.get("items", [])):
            if not isinstance(item_data, dict):
                raise ValueError(
                    f"Item {i} must be a dict, got {type(item_data).__name__}"
                )

            text = item_data.get("text")
            description = item_data.get("description")

            if text is None:
                raise ValueError(f"Item {i} missing required field: 'text'")
            if description is None:
                raise ValueError(f"Item {i} missing required field: 'description'")

            ground_truth_raw = item_data.get("ground_truth")
            ground_truth: list[CriterionVerdict] | None = None
            if ground_truth_raw is not None:
                ground_truth = []
                for j, v in enumerate(ground_truth_raw):
                    try:
                        ground_truth.append(CriterionVerdict(v))
                    except ValueError:
                        raise ValueError(
                            f"Item {i}, ground_truth[{j}]: invalid verdict '{v}'. "
                            f"Must be 'MET', 'UNMET', or 'CANNOT_ASSESS'."
                        ) from None

            items.append(
                DataItem(text=text, description=description, ground_truth=ground_truth)
            )

        return cls(prompt=data["prompt"], rubric=rubric, items=items)

    @classmethod
    def from_file(cls, path: str | Path) -> RubricDataset:
        """Load dataset from a JSON file.

        Args:
            path: Path to the JSON file.

        Returns:
            RubricDataset instance.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            ValueError: If the JSON is invalid.
        """
        from pathlib import Path

        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Dataset file not found: {path}")

        return cls.from_json(path.read_text(encoding="utf-8"))

    # =========================================================================
    # Dataset Splitting
    # =========================================================================

    def split_train_test(
        self,
        n_train: int,
        *,
        stratify: bool = True,
        seed: int | None = None,
    ) -> tuple[RubricDataset, RubricDataset]:
        """Split dataset into training and test sets.

        The training set can be used to provide few-shot examples for grading,
        while the test set is used for evaluation.

        Args:
            n_train: Exact number of items for training set.
            stratify: If True, stratify by per-criterion verdict distribution.
                This ensures each split has similar proportion of MET/UNMET/CANNOT_ASSESS
                for each criterion position. Requires all items to have ground_truth.
            seed: Random seed for reproducible splits.

        Returns:
            Tuple of (train_dataset, test_dataset).

        Raises:
            ValueError: If n_train is invalid or stratify=True but items lack ground_truth.

        Example:
            >>> dataset = RubricDataset.from_file("data.json")
            >>> train, test = dataset.split_train_test(n_train=100, stratify=True, seed=42)
            >>> print(f"Train: {len(train)}, Test: {len(test)}")
        """
        import random
        from collections import defaultdict

        if n_train < 0:
            raise ValueError(f"n_train must be non-negative, got {n_train}")
        if n_train > len(self.items):
            raise ValueError(
                f"n_train ({n_train}) exceeds dataset size ({len(self.items)})"
            )

        rng = random.Random(seed)

        if stratify:
            train_items, test_items = self._stratified_split(n_train, rng)
        else:
            # Simple random split
            indices = list(range(len(self.items)))
            rng.shuffle(indices)
            train_items = [self.items[i] for i in indices[:n_train]]
            test_items = [self.items[i] for i in indices[n_train:]]

        train_dataset = RubricDataset(
            prompt=self.prompt,
            rubric=self.rubric,
            items=train_items,
        )
        test_dataset = RubricDataset(
            prompt=self.prompt,
            rubric=self.rubric,
            items=test_items,
        )

        return train_dataset, test_dataset

    def _stratified_split(
        self,
        n_train: int,
        rng: "random.Random",
    ) -> tuple[list[DataItem], list[DataItem]]:
        """Perform stratified split based on verdict signature patterns.

        Groups items by their full verdict signature (e.g., "MET-UNMET-MET")
        and samples proportionally from each group.

        Args:
            n_train: Number of items for training set.
            rng: Random number generator for reproducibility.

        Returns:
            Tuple of (train_items, test_items).
        """
        from collections import defaultdict

        # Group by verdict signature
        groups: dict[str, list[DataItem]] = defaultdict(list)
        for item in self.items:
            if item.ground_truth is None:
                raise ValueError(
                    "Stratified split requires ground_truth on all items. "
                    "Use stratify=False for items without ground truth."
                )
            signature = "-".join(v.value for v in item.ground_truth)
            groups[signature].append(item)

        train_items: list[DataItem] = []
        test_items: list[DataItem] = []
        total_items = len(self.items)

        # Shuffle each group
        for items in groups.values():
            rng.shuffle(items)

        # Allocate proportionally from each group
        remaining_train = n_train
        remaining_total = total_items

        for signature, group_items in groups.items():
            group_size = len(group_items)

            # Calculate how many to take from this group
            # Use proportional allocation with rounding
            if remaining_total > 0:
                n_from_group = round(group_size * remaining_train / remaining_total)
                n_from_group = max(0, min(n_from_group, group_size, remaining_train))
            else:
                n_from_group = 0

            train_items.extend(group_items[:n_from_group])
            test_items.extend(group_items[n_from_group:])

            remaining_train -= n_from_group
            remaining_total -= group_size

        # Final shuffle to mix up the signatures
        rng.shuffle(train_items)
        rng.shuffle(test_items)

        return train_items, test_items
