# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, Optional, cast

import pytest

from tests.utils import assert_matches_type
from channel3_sdk import Channel3, AsyncChannel3
from channel3_sdk.types import Website

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWebsites:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_find(self, client: Channel3) -> None:
        website = client.websites.find(
            query="query",
        )
        assert_matches_type(Optional[Website], website, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_find(self, client: Channel3) -> None:
        response = client.websites.with_raw_response.find(
            query="query",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        website = response.parse()
        assert_matches_type(Optional[Website], website, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_find(self, client: Channel3) -> None:
        with client.websites.with_streaming_response.find(
            query="query",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            website = response.parse()
            assert_matches_type(Optional[Website], website, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncWebsites:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_find(self, async_client: AsyncChannel3) -> None:
        website = await async_client.websites.find(
            query="query",
        )
        assert_matches_type(Optional[Website], website, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_find(self, async_client: AsyncChannel3) -> None:
        response = await async_client.websites.with_raw_response.find(
            query="query",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        website = await response.parse()
        assert_matches_type(Optional[Website], website, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_find(self, async_client: AsyncChannel3) -> None:
        async with async_client.websites.with_streaming_response.find(
            query="query",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            website = await response.parse()
            assert_matches_type(Optional[Website], website, path=["response"])

        assert cast(Any, response.is_closed) is True
