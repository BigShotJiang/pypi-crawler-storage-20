import aiohttp
import asyncio
import json
import logging
from urllib.parse import quote as _uriquote

_log = logging.getLogger(__name__)

class Route:
    def __init__(self, method, path, **parameters):
        self.method = method
        self.path = path
        url = 'http://localhost:4000/api' + path
        if parameters:
            self.url = url.format(**{k: _uriquote(v) if isinstance(v, str) else v for k, v in parameters.items()})
        else:
            self.url = url

class HTTPClient:
    def __init__(self, token=None):
        self.token = token
        self._session = None

    async def static_login(self, token):
        self.token = token
        self._session = aiohttp.ClientSession()

    async def close(self):
        if self._session:
            await self._session.close()

    async def request(self, route, **kwargs):
        if self._session is None:
             self._session = aiohttp.ClientSession()

        headers = {
            'Authorization': f'Bot {self.token}',
            'Content-Type': 'application/json'
        }

        if 'headers' in kwargs:
            headers.update(kwargs['headers'])
            del kwargs['headers']

        if 'json' in kwargs:
            kwargs['data'] = json.dumps(kwargs['json'])
            del kwargs['json']

        async with self._session.request(route.method, route.url, headers=headers, **kwargs) as response:
            try:
                data = await response.json()
            except:
                data = await response.text()

            if 200 <= response.status < 300:
                return data
            
            _log.error(f'API Request Failed: {route.method} {route.url} -> {response.status} {data}')
            # TODO: Raise exceptions based on status code (Forbidden, NotFound, etc.)
            return None

    # --- API Wrapper Methods ---

    async def send_message(self, channel_id, content=None, embed=None, reply_to_id=None):
        r = Route('POST', '/channels/{channel_id}/messages', channel_id=channel_id)
        payload = {}
        if content: payload['content'] = content
        if embed: payload['embed'] = embed
        if reply_to_id: payload['replyToId'] = reply_to_id
        
        return await self.request(r, json=payload)

    async def edit_message(self, message_id, content=None, embed=None):
        r = Route('PUT', '/messages/{message_id}', message_id=message_id)
        payload = {}
        if content is not None: payload['content'] = content
        if embed is not None: payload['embed'] = embed
        
        return await self.request(r, json=payload)

    async def delete_message(self, message_id):
        r = Route('DELETE', '/messages/{message_id}', message_id=message_id)
        return await self.request(r)

    async def send_interaction_event(self, message_id, data):
        r = Route('POST', '/messages/{message_id}/interaction', message_id=message_id)
        return await self.request(r, json={'data': data})

    async def add_reaction(self, message_id, emoji):
        """Add a reaction to a message"""
        r = Route('POST', '/messages/{message_id}/reactions', message_id=message_id)
        return await self.request(r, json={'emoji': emoji})

    async def remove_reaction(self, message_id, emoji, user_id=None):
        """Remove a reaction from a message. Supports removing other users' reactions if bot has permission."""
        params = {}
        if user_id and user_id != '@me':
             params['userId'] = user_id

        # Note: Emoji needs to be URL encoded if it contains handled characters
        # Route class formats path parameters.
        r = Route('DELETE', '/messages/{message_id}/reactions/{emoji}', message_id=message_id, emoji=emoji)
        return await self.request(r, params=params)

    def send_dm(self, user_id, content):
        # First create/get conversation? Or backend handles it?
        # Typically we send to channel_id. 
        # If we only have user_id, we need a method to create DM.
        pass 
