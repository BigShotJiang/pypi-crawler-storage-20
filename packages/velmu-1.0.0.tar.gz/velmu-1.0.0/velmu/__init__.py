from .client import Client
from .flags import Intents
from .embed import Embed
from .models import BaseModel, User, Member, Guild, Channel, Message

__title__ = 'velmu'
__author__ = 'Velmu'
__license__ = 'MIT'
__copyright__ = 'Copyright 2024-2025 Velmu'
__version__ = '1.0.0'
