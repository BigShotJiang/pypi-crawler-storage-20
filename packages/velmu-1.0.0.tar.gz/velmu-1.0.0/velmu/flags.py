class BaseFlags:
    def __init__(self, value=0):
        self.value = value

    def __eq__(self, other):
        return isinstance(other, self.__class__) and self.value == other.value

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(self.value)

    def __iter__(self):
        for name, value in self.__class__.__dict__.items():
            if isinstance(value, int) and not name.startswith('_'):
                yield name, (self.value & value) == value

class Intents(BaseFlags):
    GUILDS = 1 << 0
    GUILD_MEMBERS = 1 << 1
    GUILD_MODERATION = 1 << 2
    GUILD_EMOJIS_AND_STICKERS = 1 << 3
    GUILD_INTEGRATIONS = 1 << 4
    GUILD_WEBHOOKS = 1 << 5
    GUILD_INVITES = 1 << 6
    GUILD_VOICE_STATES = 1 << 7
    GUILD_PRESENCES = 1 << 8
    GUILD_MESSAGES = 1 << 9
    GUILD_MESSAGE_REACTIONS = 1 << 10
    GUILD_MESSAGE_TYPING = 1 << 11
    DIRECT_MESSAGES = 1 << 12
    DIRECT_MESSAGE_REACTIONS = 1 << 13
    DIRECT_MESSAGE_TYPING = 1 << 14
    MESSAGE_CONTENT = 1 << 15
    GUILD_SCHEDULED_EVENTS = 1 << 16
    AUTO_MODERATION_CONFIGURATION = 1 << 20
    AUTO_MODERATION_EXECUTION = 1 << 21

    @classmethod
    def default(cls):
        self = cls(0)
        self.value = (
            cls.GUILDS |
            cls.GUILD_MESSAGES |
            cls.GUILD_MESSAGE_REACTIONS |
            cls.DIRECT_MESSAGES |
            cls.DIRECT_MESSAGE_REACTIONS
        )
        return self

    @classmethod
    def all(cls):
        self = cls(0)
        # Calculate all bits
        all_bits = 0
        for name, value in cls.__dict__.items():
            if isinstance(value, int) and not name.startswith('_'):
                all_bits |= value
        self.value = all_bits
        return self
    
    @classmethod
    def none(cls):
        return cls(0)
    
    # Utility properties
    @property
    def guilds(self): return (self.value & self.GUILDS) == self.GUILDS
    @guilds.setter
    def guilds(self, v): self._set_flag(self.GUILDS, v)

    @property
    def members(self): return (self.value & self.GUILD_MEMBERS) == self.GUILD_MEMBERS
    @members.setter
    def members(self, v): self._set_flag(self.GUILD_MEMBERS, v)

    @property
    def message_content(self): return (self.value & self.MESSAGE_CONTENT) == self.MESSAGE_CONTENT
    @message_content.setter
    def message_content(self, v): self._set_flag(self.MESSAGE_CONTENT, v)
    
    @property
    def presences(self): return (self.value & self.GUILD_PRESENCES) == self.GUILD_PRESENCES
    @presences.setter
    def presences(self, v): self._set_flag(self.GUILD_PRESENCES, v)

    def _set_flag(self, flag, value):
        if value:
            self.value |= flag
        else:
            self.value &= ~flag
