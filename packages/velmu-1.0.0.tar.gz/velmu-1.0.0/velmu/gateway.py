class GatewayOp:
    DISPATCH = 0
    HEARTBEAT = 1
    IDENTIFY = 2
    HELLO = 10
    HEARTBEAT_ACK = 11

class EventType:
    READY = 'READY'
    MESSAGE_CREATE = 'MESSAGE_CREATE'
    # Add others as needed
