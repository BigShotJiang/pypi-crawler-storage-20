import socketio
import asyncio
import time
import logging
from .gateway import GatewayOp
from .flags import Intents
from .http import HTTPClient
from .models import Message, User

import warnings

_log = logging.getLogger(__name__)

# Map of events to their required intents
_PRIVILEGED_INTENT_EVENTS = {
    'on_member_join': ('GUILD_MEMBERS', Intents.GUILD_MEMBERS),
    'on_member_remove': ('GUILD_MEMBERS', Intents.GUILD_MEMBERS),
    'on_member_update': ('GUILD_MEMBERS', Intents.GUILD_MEMBERS),
    'on_presence_update': ('GUILD_PRESENCES', Intents.GUILD_PRESENCES),
}

class ConnectionState:
    def __init__(self, dispatch, http, loop):
        self.dispatch = dispatch
        self.http = http
        self.loop = loop
        self.user = None
        self._users = {} # Cache

class Client:
    def __init__(self, intents=None):
        self.intents = intents or Intents.default()
        self.loop = asyncio.get_event_loop()
        self.http = HTTPClient()
        self._connection = ConnectionState(self.dispatch, self.http, self.loop)
        
        self.sio = socketio.AsyncClient(logger=False, engineio_logger=False)
        self._token = None
        self._heartbeat_task = None
        
        # Event handlers
        self._events = {} 

        # Socket events
        self.sio.on('connect', self._on_connect, namespace='/gateway-bot')
        self.sio.on('disconnect', self._on_disconnect, namespace='/gateway-bot')
        self.sio.on('payload', self._on_payload, namespace='/gateway-bot')
        self.sio.on('connect_error', self._on_connect_error, namespace='/gateway-bot')
        self.sio.on('connect_timeout', self._on_connect_error, namespace='/gateway-bot')

    def event(self, coro):
        """Decorator to register an event handler"""
        if not asyncio.iscoroutinefunction(coro):
            raise TypeError('Events must be coroutines')
        
        event_name = coro.__name__
        
        # Check if this event requires a privileged intent
        if event_name in _PRIVILEGED_INTENT_EVENTS:
            intent_name, intent_value = _PRIVILEGED_INTENT_EVENTS[event_name]
            if not (self.intents.value & intent_value):
                warnings.warn(
                    f"\n⚠️  L'événement '{event_name}' nécessite l'intent privilégié '{intent_name}'.\n"
                    f"   Ton bot ne recevra PAS cet événement sans cet intent.\n"
                    f"   Active-le dans : Portail Développeur > Ton Bot > Bot & Token > Privileged Gateway Intents\n"
                    f"   Et ajoute-le au code : intents = Intents.default(); intents.{intent_name.lower()} = True",
                    UserWarning,
                    stacklevel=2
                )
        
        self._events[event_name] = coro
        return coro

    # Dispatcher
    def dispatch(self, event_name, *args, **kwargs):
        _log.debug(f'Dispatching {event_name}')
        method = f'on_{event_name}'
        
        # Listeners registered via @client.event
        if method in self._events:
            self.loop.create_task(self._events[method](*args, **kwargs))

    def run(self, token):
        """Run the bot"""
        self._token = token
        
        try:
            self.loop.run_until_complete(self._start())
        except KeyboardInterrupt:
            self.loop.run_until_complete(self.close())

    async def _start(self):
        # Login to HTTP (create session)
        await self.http.static_login(self._token)
        
        # Connect to Gateway
        # TODO: Configurable URL
        await self.sio.connect('http://localhost:4000', namespaces=['/gateway-bot']) # Default local dev
        await self.sio.wait()

    async def close(self):
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
        await self.sio.disconnect()
        await self.http.close()

    async def _on_connect(self):
        _log.info('Connected to Gateway')

    async def _on_connect_error(self, data):
        _log.error(f'Gateway Connection Error: {data}')

    async def _on_disconnect(self):
        _log.info('Disconnected from Gateway')
        if self._heartbeat_task:
            self._heartbeat_task.cancel()

    async def _on_payload(self, data):
        op = data.get('op')
        d = data.get('d')
        t = data.get('t')

        if op == GatewayOp.HELLO:
            interval = d['heartbeat_interval'] / 1000
            self._heartbeat_task = self.loop.create_task(self._heartbeat_loop(interval))
            await self._identify()
        
        elif op == GatewayOp.HEARTBEAT_ACK:
            # _log.debug('Heartbeat ACK')
            pass
        
        elif op == GatewayOp.DISPATCH:
            await self._handle_dispatch(t, d)

    async def _identify(self):
        _log.info('Identifying...')
        payload = {
            'op': GatewayOp.IDENTIFY,
            'd': {
                'token': self._token,
                'intents': self.intents.value
            }
        }
        await self.sio.emit('payload', payload, namespace='/gateway-bot')

    async def _heartbeat_loop(self, interval):
        _log.info(f'Starting heartbeat loop (interval: {interval}s)')
        while True:
            await asyncio.sleep(interval)
            try:
                await self.sio.emit('payload', {'op': GatewayOp.HEARTBEAT}, namespace='/gateway-bot')
            except socketio.exceptions.BadNamespaceError:
                # Connection lost during sleep loop
                _log.debug('Lost connection during heartbeat')
                break

    async def _handle_dispatch(self, event_name, data):
        # Import models at function level to avoid UnboundLocalError
        from .models import User as UserModel, Member, Interaction
        
        # Handle gateway errors (like missing privileged intents)
        if event_name == 'ERROR':
            code = data.get('code', 0)
            message = data.get('message', 'Unknown error')
            missing = data.get('missing_intents', [])
            
            print("\n" + "=" * 60)
            print("❌ ERREUR DE CONNEXION AU GATEWAY")
            print("=" * 60)
            print(f"   Code: {code}")
            print(f"   Message: {message}")
            if missing:
                print(f"   Intents manquants: {', '.join(missing)}")
                print("\n   💡 Solution:")
                print("      1. Va dans le Portail Développeur")
                print("      2. Sélectionne ton bot > Bot & Token")
                print("      3. Active les intents manquants dans 'Privileged Gateway Intents'")
            print("=" * 60 + "\n")
            _log.error(f'Gateway Error: {message}')
            return
        
        if event_name == 'READY':
            self._connection.user = UserModel(self._connection, data.get('user'))
            self.user = self._connection.user
            _log.info(f'Logged in as {self.user.username} (ID: {self.user.id})')
            self.dispatch('ready')
        
        elif event_name == 'MESSAGE_UPDATE':
            # Payload is a Message Object (partial or full)
            if 'content' in data:
                message = Message(state=None, data=data) # We need state/guild ideally
                message._state = self._connection
                # Fetch cached message if we had cache
                before = None 
                after = message
                self.dispatch('message_edit', before, after)
        
        elif event_name == 'MESSAGE_DELETE':
            # Payload: { id, channelId, guildId }
            # Construct a dummy message with ID
            class DeletedMessage:
                def __init__(self, data):
                    self.id = data.get('id')
                    self.channel_id = data.get('channelId')
                    self.guild_id = data.get('guildId')
            
            self.dispatch('message_delete', DeletedMessage(data))

        elif event_name == 'MESSAGE_REACTION_ADD':
            self.dispatch('reaction_add', data) # Todo: Wrap in Reaction object

        elif event_name == 'MESSAGE_REACTION_REMOVE':
            self.dispatch('reaction_remove', data)
        
        elif event_name == 'MESSAGE_CREATE':
            message = Message(self._connection, data)
            self.dispatch('message', message)
        
        elif event_name == 'INTERACTION_CREATE':
            interaction = Interaction(self._connection, data)
            self.dispatch('html_interaction', interaction)
        
        elif event_name == 'TYPING_START':
            # TODO: Parse TypingRaw -> Typing Event
            pass
        
        # Member Events
        elif event_name == 'GUILD_MEMBER_ADD':
            member_data = {
                'user': data.get('user'),
                'guild_id': data.get('guildId'),
                'joined_at': data.get('joinedAt')
            }
            user = UserModel(self._connection, data.get('user', {}))
            self.dispatch('member_join', user, data.get('guildId'))
        
        elif event_name == 'GUILD_MEMBER_REMOVE':
            user = UserModel(self._connection, data.get('user', {}))
            self.dispatch('member_remove', user, data.get('guildId'))
        
        # Presence Events
        elif event_name == 'PRESENCE_UPDATE':
            self.dispatch('presence_update', 
                          data.get('user', {}).get('id'),
                          data.get('guildId'),
                          data.get('status'))

