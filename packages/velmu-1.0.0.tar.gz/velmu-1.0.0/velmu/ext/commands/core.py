import inspect
import asyncio
from ...models import Message, User
from ...client import Client

class Command:
    def __init__(self, func, **kwargs):
        self.callback = func
        self.name = kwargs.get('name') or func.__name__
        self.checks = kwargs.get('checks', [])

    async def invoke(self, ctx):
        if self.checks:
            for check in self.checks:
                if not check(ctx):
                    # TODO: Dispatch on_command_error
                    raise Exception('Check failed')
        
        # Argument Parsing & Conversion
        sig = inspect.signature(self.callback)
        params = list(sig.parameters.values())[1:] # Skip ctx
        
        converted_args = []
        remaining_args = ctx.args # List of strings
        
        for i, param in enumerate(params):
            if param.kind == param.KEYWORD_ONLY:
                # Consume rest
                val = ' '.join(remaining_args[i:])
                # Check for Converter
                if param.annotation is not param.empty:
                     # Reuse logic or simple cast? For str it's fine.
                     pass
                ctx.kwargs[param.name] = val
                break
            
            if i >= len(remaining_args):
                if param.default is not param.empty:
                    converted_args.append(param.default)
                    continue
                else:
                    raise Exception(f'Missing argument: {param.name}')

            arg = remaining_args[i]
            
            # Check for Converter
            # We need to handle Member specifically if annotation is models.Member
            # For now, check class name
            annotation = param.annotation
            if annotation is not param.empty:
                if hasattr(annotation, 'convert'):
                   converter = annotation()
                   arg = await converter.convert(ctx, arg)
                elif hasattr(annotation, '__name__') and annotation.__name__ == 'Member':
                   # Dynamic import to avoid circular dependency
                   from .converters import MemberConverter
                   converter = MemberConverter()
                   arg = await converter.convert(ctx, arg)
                elif hasattr(annotation, '__call__'):
                   try:
                       arg = annotation(arg)
                   except:
                       pass

            converted_args.append(arg)

        await self.callback(ctx, *converted_args, **ctx.kwargs)

class Context:
    def __init__(self, **kwargs):
        self.bot = kwargs.get('bot')
        self.message = kwargs.get('message')
        self.view = kwargs.get('view')
        self.args = []
        self.kwargs = {}
        
        self.guild = getattr(self.message, 'guild', None)
        self.channel = self.message.channel
        self.author = self.message.author

    async def send(self, content=None, embed=None):
        if embed and hasattr(embed, 'to_dict'):
            embed = embed.to_dict()
        return await self.channel.send(content, embed)

class Bot(Client):
    def __init__(self, command_prefix, **options):
        super().__init__(**options)
        self.command_prefix = command_prefix
        self.commands = {}
        self.extensions = {}
        
        # Register on_message listener
        self.event(self.on_message)

    def load_extension(self, name):
        import importlib
        try:
            lib = importlib.import_module(name)
            if hasattr(lib, 'setup'):
                lib.setup(self)
            self.extensions[name] = lib
        except Exception as e:
            print(f'Failed to load extension {name}: {e}')

    def command(self, **kwargs):
        def decorator(func):
            cmd = Command(func, **kwargs)
            self.commands[cmd.name] = cmd
            return cmd
        return decorator

    async def on_message(self, message):
        # Ignore bots (including self)
        if message.author and message.author.bot:
            return

        await self.process_commands(message)

    async def process_commands(self, message):
        content = message.content
        if not content.startswith(self.command_prefix):
            return

        # Simple parsing
        view = content[len(self.command_prefix):].split(' ')
        invoker = view[0]
        args = view[1:]

        if invoker in self.commands:
            ctx = Context(bot=self, message=message, view=view)
            ctx.args = args 
            
            # Args processing is now moved to Command.invoke
            cmd = self.commands[invoker]
            try:
                await cmd.invoke(ctx)
            except Exception as e:
                print(f'Command Error: {e}')

