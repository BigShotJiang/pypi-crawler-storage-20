from ...models import Member, User, Channel

class Converter:
    async def convert(self, ctx, argument):
        raise NotImplementedError('Derived classes must implement convert.')

class MemberConverter(Converter):
    async def convert(self, ctx, argument):
        user_id = None
        # 1. Check ID
        # 1. Check if argument comes as a raw ID (UUID length check roughly?)
        # Velmu IDs are UUIDs (string)
        # Verify if it looks like a potential ID (alphanumeric, dashes)
        if len(argument) > 5 and not argument.startswith('<@'):
             user_id = argument

        # 2. Check Mention <@ID>
        if argument.startswith('<@') and argument.endswith('>'):
            # Strip <@ and >
            try:
                # Format is <@id|username> or <@id>
                content = argument[2:-1] 
                if '|' in content:
                    user_id = content.split('|')[0]
                else:
                    user_id = content
            except:
                pass
        
        # 3. Check Username
        # return ctx.guild.get_member_named(argument)
        
        if user_id:
             # Create a dummy state-bound Member
             # We need a state. ctx.bot is a Client which has _state? No, Client IS the state mostly.
             # Client has _state in HTTPClient etc is messy. 
             # Let's assume we can construct Member with ctx.bot and minimal data
             
             # Mimic data payload
             data = {
                 'user': {
                     'id': str(user_id),
                     'username': 'Utilisateur', # Placeholder, SDK should fetch real user
                     'discriminator': '0000',
                     'avatarUrl': None
                 },
                 'nickname': None
             }
             # State needs message.state or ctx.bot._connection (if existing)
             # Client._state is not exposed easily? 
             # Client.__init__ sets self._state = ConnectionState...
             
             # Let's assume ctx.bot IS the state interface required by models (it has http, etc)
             # Actually models expect 'state' to have 'http'. ctx.bot has 'http'.
             return Member(ctx.bot, data)

        raise Exception(f'Member "{argument}" not found.')

class ChannelConverter(Converter):
    async def convert(self, ctx, argument):
        # Similar logic: ID, Mention <#ID>, Name
        pass
