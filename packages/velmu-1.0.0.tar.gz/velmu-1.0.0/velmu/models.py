from datetime import datetime

class BaseModel:
    def __init__(self, state, data):
        self._state = state
        self.id = data.get('id')

class User(BaseModel):
    def __init__(self, state, data):
        super().__init__(state, data)
        self.username = data.get('username')
        self.discriminator = data.get('discriminator')
        self.avatar_url = data.get('avatarUrl')
        self.bot = data.get('bot', False)

    @property
    def mention(self):
        return f'<@{self.id}>'

    def __str__(self):
        return f'{self.username}'

class Member(BaseModel):
    def __init__(self, state, data, guild=None):
        super().__init__(state, data)
        self.guild = guild
        self.user = User(state, data.get('user')) if 'user' in data else None
        self.nickname = data.get('nickname')
        # TODO: Roles processing

class Guild(BaseModel):
    def __init__(self, state, data):
        super().__init__(state, data)
        self.name = data.get('name')
        self.owner_id = data.get('ownerId')
        
        self.channels = {}
        self.members = {}

class Channel(BaseModel):
    def __init__(self, state, data, guild=None):
        super().__init__(state, data)
        self.name = data.get('name')
        self.type = data.get('type')
        self.guild = guild

    async def send(self, content=None, embed=None, reply_to_id=None):
        data = await self._state.http.send_message(self.id, content, embed, reply_to_id)
        return Message(self._state, data)

class Message(BaseModel):
    def __init__(self, state, data):
        super().__init__(state, data)
        self.content = data.get('content')
        self.channel_id = data.get('channelId')
        self.conversation_id = data.get('conversationId')
        self.guild_id = data.get('guildId') # Handled by raw processed payload?
        
        self.author = User(state, data.get('user')) if 'user' in data else None
        
        # Helper to get the channel object from cache needs state
        
    @property
    def guild(self):
        # TODO: Fetch from state cache
        return None

    @property
    def channel(self):
        # TODO: Fetch from state cache
        # For now, return a partial channel that can send messages
        return PartialMessageable(self._state, self.channel_id or self.conversation_id)

    async def reply(self, content=None, embed=None):
        """Reply to this message."""
        if self.channel:
            return await self.channel.send(content, embed=embed, reply_to_id=self.id)

    async def edit(self, content=None, embed=None):
        if embed and hasattr(embed, 'to_dict'):
            embed = embed.to_dict()
        return await self._state.http.edit_message(self.id, content, embed)

    async def delete(self):
        return await self._state.http.delete_message(self.id)

    async def add_reaction(self, emoji):
        """Add a reaction to this message."""
        return await self._state.http.add_reaction(self.id, emoji)

    async def remove_reaction(self, emoji, member=None):
        """Remove a reaction from this message."""
        user_id = member.id if hasattr(member, 'id') else member # Accept Member object or ID
        return await self._state.http.remove_reaction(self.id, emoji, user_id)

class PartialMessageable:
    def __init__(self, state, id):
        self._state = state
        self.id = id
    
    async def send(self, content=None, embed=None, reply_to_id=None):
        # We assume it's a channel message for now. 
        # Ideally we check if it is a channel or DM.
        # But the backend route /channels/:id/messages works for channels.
        # DMs might need separate route if logic differs. 
        # For phase 2, let's assume unified sending or handle error.
        data = await self._state.http.send_message(self.id, content, embed, reply_to_id)
        return Message(self._state, data)
class Interaction(BaseModel):
    def __init__(self, state, data):
        super().__init__(state, data)
        self.message_id = data.get('messageId')
        self.channel_id = data.get('channelId')
        self.guild_id = data.get('guildId')
        self.data = data.get('data') # The payload from JS
        
        # Parse full user object if available, otherwise minimal with just ID
        user_data = data.get('user') or {'id': data.get('userId')}
        self.user = User(state, user_data)

    async def reply(self, data):
        """Sends data back to the HTML Embed"""
        await self._state.http.send_interaction_event(self.message_id, data)
