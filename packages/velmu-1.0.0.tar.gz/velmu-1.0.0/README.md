# Velmu Python SDK

Une bibliothèque Python moderne et facile à utiliser pour interagir avec l'API Velmu et créer des bots puissants.

## Installation

Vous pouvez installer la bibliothèque via pip (une fois publiée) ou directement depuis les sources :

```bash
pip install velmu
```

Ou en local :

```bash
pip install .
```

## Exemple Rapide

Voici un bot simple qui répond "Pong !" quand on envoie `!ping`.

```python
import velmu
import asyncio

class MyBot(velmu.Client):
    async def on_ready(self):
        print(f'Connecté en tant que {self.user.username}')

    async def on_message(self, message):
        # Ne pas répondre à soi-même
        if message.user.id == self.user.id:
            return

        if message.content == '!ping':
            await message.channel.send('Pong !')

    async def on_member_join(self, member):
        print(f'{member.user.username} a rejoint le serveur !')

# Remplacez par votre token
TOKEN = "VOTRE_TOKEN_ICI"

client = MyBot()
client.run(TOKEN)
```

## Fonctionnalités Clés

- **Asyncio** : Construit sur `asyncio` et `aiohttp` pour des performances maximales.
- **Socket.IO** : Connexion temps réel robuste avec la Gateway Velmu.
- **Objets Typés** : Tout est objet (`Message`, `User`, `Channel`) pour une autocomplétion parfaite.

## Événements Disponibles

- `on_ready()` : Appelé quand le bot est connecté.
- `on_message(message)` : Appelé à chaque nouveau message.
- `on_message_delete(message)` : Appelé quand un message est supprimé.
- `on_message_update(before, after)` : Appelé quand un message est modifié.
- `on_member_join(member)` : Appelé quand un membre rejoint un serveur.
- `on_member_remove(member)` : Appelé quand un membre quitte un serveur.

## Licence

Distribué sous la licence MIT. Voir `LICENSE` pour plus d'informations.
