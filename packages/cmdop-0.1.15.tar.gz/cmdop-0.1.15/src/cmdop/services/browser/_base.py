"""Shared browser utilities."""

from __future__ import annotations

import json
from typing import Any

from cmdop.services.browser.models import BrowserCookie


def build_fetch_js(url: str) -> str:
    """Build JS for single fetch."""
    return f"""
    (async function() {{
        try {{
            const resp = await fetch("{url}");
            if (!resp.ok) return JSON.stringify({{__error: resp.status}});
            return JSON.stringify(await resp.json());
        }} catch(e) {{
            return JSON.stringify({{__error: e.message}});
        }}
    }})()
    """


def build_fetch_all_js(urls: dict[str, str]) -> tuple[str, list[str]]:
    """Build JS for parallel fetch. Returns (js_code, keys)."""
    keys = list(urls.keys())
    fetches = [
        f'fetch("{urls[k]}").then(r => r.ok ? r.json() : null).catch(() => null)'
        for k in keys
    ]

    js = f"""
    (async function() {{
        try {{
            const results = await Promise.all([{", ".join(fetches)}]);
            return JSON.stringify(results);
        }} catch(e) {{
            return JSON.stringify({{__error: e.message}});
        }}
    }})()
    """
    return js, keys


def parse_fetch_result(result: str) -> dict | list | None:
    """Parse single fetch result."""
    if result:
        try:
            data = json.loads(result)
            if isinstance(data, dict) and "__error" in data:
                return None
            return data
        except json.JSONDecodeError:
            return None
    return None


def parse_fetch_all_result(result: str, keys: list[str]) -> dict[str, Any]:
    """Parse parallel fetch result."""
    if result:
        try:
            data = json.loads(result)
            if isinstance(data, dict) and "__error" in data:
                return {k: None for k in keys}
            return {k: data[i] for i, k in enumerate(keys)}
        except json.JSONDecodeError:
            return {k: None for k in keys}
    return {k: None for k in keys}


def cookie_to_pb(c: BrowserCookie | dict, PbCookie: type) -> Any:
    """Convert cookie to protobuf."""
    if isinstance(c, dict):
        return PbCookie(
            name=c.get("name", ""),
            value=c.get("value", ""),
            domain=c.get("domain", ""),
            path=c.get("path", "/"),
            secure=c.get("secure", False),
            http_only=c.get("http_only", False),
            same_site=c.get("same_site", ""),
            expires=c.get("expires", 0),
        )
    return PbCookie(
        name=c.name,
        value=c.value,
        domain=c.domain,
        path=c.path,
        secure=c.secure,
        http_only=c.http_only,
        same_site=c.same_site,
        expires=c.expires,
    )


def pb_to_cookie(c: Any) -> BrowserCookie:
    """Convert protobuf to cookie."""
    return BrowserCookie(
        name=c.name,
        value=c.value,
        domain=c.domain,
        path=c.path,
        secure=c.secure,
        http_only=c.http_only,
        same_site=c.same_site,
        expires=c.expires,
    )
