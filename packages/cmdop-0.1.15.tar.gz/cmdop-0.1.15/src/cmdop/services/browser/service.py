"""Browser service (sync)."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from cmdop.services.base import BaseService
from cmdop.services.browser.models import BrowserCookie, BrowserState, raise_browser_error
from cmdop.services.browser.session import BrowserSession
from cmdop.services.browser._base import cookie_to_pb, pb_to_cookie

if TYPE_CHECKING:
    from cmdop.transport.base import BaseTransport


class BrowserService(BaseService):
    """
    Synchronous browser service.

    Example:
        with client.browser.create_session() as session:
            session.navigate("https://google.com")
            session.type("input[name='q']", "Python")
            results = session.extract(".result-title")
    """

    def __init__(self, transport: BaseTransport) -> None:
        super().__init__(transport)
        self._stub: Any = None

    @property
    def _get_stub(self) -> Any:
        if self._stub is None:
            from cmdop._generated.service_pb2_grpc import TerminalStreamingServiceStub
            self._stub = TerminalStreamingServiceStub(self._channel)
        return self._stub

    def create_session(
        self,
        start_url: str | None = None,
        provider: str = "camoufox",
        profile_id: str | None = None,
        headless: bool = False,
        width: int = 1280,
        height: int = 800,
    ) -> BrowserSession:
        """Create browser session."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserCreateSessionRequest

        request = BrowserCreateSessionRequest(
            provider=provider,
            profile_id=profile_id or "",
            start_url=start_url or "",
            headless=headless,
            width=width,
            height=height,
        )
        response = self._call_sync(self._get_stub.BrowserCreateSession, request)

        if not response.success:
            raise_browser_error(response.error, "create_session")

        return BrowserSession(self, response.browser_session_id)

    def close_session(self, session_id: str) -> None:
        """Close browser session."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserCloseSessionRequest

        request = BrowserCloseSessionRequest(browser_session_id=session_id)
        response = self._call_sync(self._get_stub.BrowserCloseSession, request)

        if not response.success:
            raise RuntimeError(f"Failed to close browser session: {response.error}")

    def navigate(self, session_id: str, url: str, timeout_ms: int = 30000) -> str:
        """Navigate to URL."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserNavigateRequest

        request = BrowserNavigateRequest(
            browser_session_id=session_id, url=url, timeout_ms=timeout_ms
        )
        response = self._call_sync(self._get_stub.BrowserNavigate, request)

        if not response.success:
            raise_browser_error(response.error, "navigate", url=url)

        return response.final_url

    def click(self, session_id: str, selector: str, timeout_ms: int = 5000) -> None:
        """Click element."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserClickRequest

        request = BrowserClickRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = self._call_sync(self._get_stub.BrowserClick, request)

        if not response.success:
            raise_browser_error(response.error, "click", selector=selector)

    def type(
        self,
        session_id: str,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """Type text into element."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserTypeRequest

        request = BrowserTypeRequest(
            browser_session_id=session_id,
            selector=selector,
            text=text,
            human_like=human_like,
            clear_first=clear_first,
        )
        response = self._call_sync(self._get_stub.BrowserType, request)

        if not response.success:
            raise_browser_error(response.error, "type", selector=selector)

    def wait_for(self, session_id: str, selector: str, timeout_ms: int = 30000) -> bool:
        """Wait for element."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserWaitRequest

        request = BrowserWaitRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = self._call_sync(self._get_stub.BrowserWait, request)

        if not response.success:
            raise_browser_error(response.error, "wait_for", selector=selector)

        return response.found

    def extract(
        self, session_id: str, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """Extract text/attributes."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRequest

        request = BrowserExtractRequest(
            browser_session_id=session_id,
            selector=selector,
            attribute=attr or "",
            limit=limit,
        )
        response = self._call_sync(self._get_stub.BrowserExtract, request)

        if not response.success:
            raise RuntimeError(f"Extract failed: {response.error}")

        return list(response.values)

    def extract_regex(
        self, session_id: str, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """Extract using regex."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRegexRequest

        request = BrowserExtractRegexRequest(
            browser_session_id=session_id,
            pattern=pattern,
            from_html=from_html,
            limit=limit,
        )
        response = self._call_sync(self._get_stub.BrowserExtractRegex, request)

        if not response.success:
            raise RuntimeError(f"ExtractRegex failed: {response.error}")

        return list(response.matches)

    def get_html(self, session_id: str, selector: str | None = None) -> str:
        """Get page HTML."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetHTMLRequest

        request = BrowserGetHTMLRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = self._call_sync(self._get_stub.BrowserGetHTML, request)

        if not response.success:
            raise RuntimeError(f"GetHTML failed: {response.error}")

        return response.html

    def get_text(self, session_id: str, selector: str | None = None) -> str:
        """Get page text."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetTextRequest

        request = BrowserGetTextRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = self._call_sync(self._get_stub.BrowserGetText, request)

        if not response.success:
            raise RuntimeError(f"GetText failed: {response.error}")

        return response.text

    def execute_script(self, session_id: str, script: str) -> str:
        """Execute JavaScript."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExecuteScriptRequest

        request = BrowserExecuteScriptRequest(
            browser_session_id=session_id, script=script
        )
        response = self._call_sync(self._get_stub.BrowserExecuteScript, request)

        if not response.success:
            raise RuntimeError(f"ExecuteScript failed: {response.error}")

        return response.result

    def screenshot(self, session_id: str, full_page: bool = False) -> bytes:
        """Take screenshot."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserScreenshotRequest

        request = BrowserScreenshotRequest(
            browser_session_id=session_id, full_page=full_page
        )
        response = self._call_sync(self._get_stub.BrowserScreenshot, request)

        if not response.success:
            raise RuntimeError(f"Screenshot failed: {response.error}")

        return response.data

    def get_state(self, session_id: str) -> BrowserState:
        """Get browser state."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetStateRequest

        request = BrowserGetStateRequest(browser_session_id=session_id)
        response = self._call_sync(self._get_stub.BrowserGetState, request)

        if not response.success:
            raise RuntimeError(f"GetState failed: {response.error}")

        return BrowserState(url=response.url, title=response.title)

    def set_cookies(self, session_id: str, cookies: list[BrowserCookie | dict]) -> None:
        """Set cookies."""
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCookie as PbCookie,
            BrowserSetCookiesRequest,
        )

        pb_cookies = [cookie_to_pb(c, PbCookie) for c in cookies]
        request = BrowserSetCookiesRequest(
            browser_session_id=session_id, cookies=pb_cookies
        )
        response = self._call_sync(self._get_stub.BrowserSetCookies, request)

        if not response.success:
            raise RuntimeError(f"SetCookies failed: {response.error}")

    def get_cookies(self, session_id: str, domain: str = "") -> list[BrowserCookie]:
        """Get cookies."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetCookiesRequest

        request = BrowserGetCookiesRequest(
            browser_session_id=session_id, domain=domain
        )
        response = self._call_sync(self._get_stub.BrowserGetCookies, request)

        if not response.success:
            raise RuntimeError(f"GetCookies failed: {response.error}")

        return [pb_to_cookie(c) for c in response.cookies]

    def validate_selectors(
        self, session_id: str, item: str, fields: dict[str, str]
    ) -> dict:
        """Validate CSS selectors on page."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserValidateSelectorsRequest

        request = BrowserValidateSelectorsRequest(
            browser_session_id=session_id,
            item=item,
            fields=fields,
        )
        response = self._call_sync(self._get_stub.BrowserValidateSelectors, request)

        if not response.success:
            raise RuntimeError(f"ValidateSelectors failed: {response.error}")

        return {
            "valid": response.valid,
            "counts": dict(response.counts),
            "samples": dict(response.samples),
            "errors": list(response.errors),
        }

    def extract_data(
        self, session_id: str, item: str, fields_json: str, limit: int = 100
    ) -> dict:
        """Extract structured data from page."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractDataRequest

        request = BrowserExtractDataRequest(
            browser_session_id=session_id,
            item=item,
            fields_json=fields_json,
            limit=limit,
        )
        response = self._call_sync(self._get_stub.BrowserExtractData, request)

        if not response.success:
            raise RuntimeError(f"ExtractData failed: {response.error}")

        return {
            "items": json.loads(response.items_json) if response.items_json else [],
            "count": response.count,
        }
