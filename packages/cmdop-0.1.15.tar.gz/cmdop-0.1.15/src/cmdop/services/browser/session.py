"""Browser session (sync)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from cmdop.services.browser.models import BrowserCookie, BrowserState
from cmdop.services.browser._base import (
    build_fetch_js,
    build_fetch_all_js,
    parse_fetch_result,
    parse_fetch_all_result,
)

if TYPE_CHECKING:
    from cmdop.services.browser.service import BrowserService


class BrowserSession:
    """
    Browser session with fluent API.

    Use as context manager:
        with client.browser.create_session() as session:
            session.navigate("https://example.com")
            session.click("button.submit")
    """

    def __init__(self, service: BrowserService, session_id: str) -> None:
        self._service = service
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        return self._session_id

    def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        """Navigate to URL."""
        return self._service.navigate(self._session_id, url, timeout_ms)

    def click(self, selector: str, timeout_ms: int = 5000) -> None:
        """Click element by CSS selector."""
        self._service.click(self._session_id, selector, timeout_ms)

    def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """Type text into element."""
        self._service.type(self._session_id, selector, text, human_like, clear_first)

    def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        """Wait for element to appear."""
        return self._service.wait_for(self._session_id, selector, timeout_ms)

    def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """Extract text/attributes from elements."""
        return self._service.extract(self._session_id, selector, attr, limit)

    def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """Extract data using regex pattern."""
        return self._service.extract_regex(self._session_id, pattern, from_html, limit)

    def get_html(self, selector: str | None = None) -> str:
        """Get page HTML."""
        return self._service.get_html(self._session_id, selector)

    def get_text(self, selector: str | None = None) -> str:
        """Get page text content."""
        return self._service.get_text(self._session_id, selector)

    def execute_script(self, script: str) -> str:
        """Execute JavaScript."""
        return self._service.execute_script(self._session_id, script)

    def fetch_json(self, url: str) -> dict | list | None:
        """Fetch JSON from URL using JS fetch()."""
        js = build_fetch_js(url)
        result = self.execute_script(js)
        return parse_fetch_result(result)

    def fetch_all(self, urls: dict[str, str]) -> dict[str, Any]:
        """Fetch multiple URLs in parallel using Promise.all."""
        if not urls:
            return {}
        js, keys = build_fetch_all_js(urls)
        result = self.execute_script(js)
        return parse_fetch_all_result(result, keys)

    def screenshot(self, full_page: bool = False) -> bytes:
        """Take screenshot."""
        return self._service.screenshot(self._session_id, full_page)

    def get_state(self) -> BrowserState:
        """Get current browser state."""
        return self._service.get_state(self._session_id)

    def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        """Set browser cookies."""
        self._service.set_cookies(self._session_id, cookies)

    def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        """Get browser cookies."""
        return self._service.get_cookies(self._session_id, domain)

    def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        """Validate CSS selectors on page."""
        return self._service.validate_selectors(self._session_id, item, fields)

    def extract_data(self, item: str, fields_json: str, limit: int = 100) -> dict:
        """Extract structured data from page."""
        return self._service.extract_data(self._session_id, item, fields_json, limit)

    def close(self) -> None:
        """Close browser session."""
        self._service.close_session(self._session_id)

    def __enter__(self) -> "BrowserSession":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
