"""Browser models and error handling."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from cmdop.exceptions import (
    BrowserElementNotFoundError,
    BrowserError,
    BrowserNavigationError,
    BrowserSessionClosedError,
)


def raise_browser_error(error: str, operation: str, **context: Any) -> None:
    """Raise appropriate browser exception based on error message."""
    error_lower = error.lower()

    if "target closed" in error_lower or "context closed" in error_lower:
        raise BrowserSessionClosedError(error)

    if operation == "navigate":
        raise BrowserNavigationError(context.get("url", ""), error)

    if "element not found" in error_lower or "no element" in error_lower:
        raise BrowserElementNotFoundError(context.get("selector", ""), operation)

    raise BrowserError(f"{operation} failed: {error}")


class BrowserCookie(BaseModel):
    """Browser cookie."""

    name: str
    value: str
    domain: str = ""
    path: str = "/"
    secure: bool = False
    http_only: bool = False
    same_site: str = ""
    expires: int = 0


class BrowserState(BaseModel):
    """Current browser state."""

    url: str
    title: str
