"""Browser session (async)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from cmdop.services.browser.models import BrowserCookie, BrowserState
from cmdop.services.browser._base import (
    build_fetch_js,
    build_fetch_all_js,
    parse_fetch_result,
    parse_fetch_all_result,
)

if TYPE_CHECKING:
    from cmdop.services.browser.async_service import AsyncBrowserService


class AsyncBrowserSession:
    """
    Async browser session with fluent API.

    Use as async context manager:
        async with client.browser.create_session() as session:
            await session.navigate("https://example.com")
            await session.click("button.submit")
    """

    def __init__(self, service: AsyncBrowserService, session_id: str) -> None:
        self._service = service
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        return self._session_id

    async def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        return await self._service.navigate(self._session_id, url, timeout_ms)

    async def click(self, selector: str, timeout_ms: int = 5000) -> None:
        await self._service.click(self._session_id, selector, timeout_ms)

    async def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        await self._service.type(
            self._session_id, selector, text, human_like, clear_first
        )

    async def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        return await self._service.wait_for(self._session_id, selector, timeout_ms)

    async def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        return await self._service.extract(self._session_id, selector, attr, limit)

    async def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        return await self._service.extract_regex(
            self._session_id, pattern, from_html, limit
        )

    async def get_html(self, selector: str | None = None) -> str:
        return await self._service.get_html(self._session_id, selector)

    async def get_text(self, selector: str | None = None) -> str:
        return await self._service.get_text(self._session_id, selector)

    async def execute_script(self, script: str) -> str:
        return await self._service.execute_script(self._session_id, script)

    async def fetch_json(self, url: str) -> dict | list | None:
        """Fetch JSON from URL using JS fetch()."""
        js = build_fetch_js(url)
        result = await self.execute_script(js)
        return parse_fetch_result(result)

    async def fetch_all(self, urls: dict[str, str]) -> dict[str, Any]:
        """Fetch multiple URLs in parallel using Promise.all."""
        if not urls:
            return {}
        js, keys = build_fetch_all_js(urls)
        result = await self.execute_script(js)
        return parse_fetch_all_result(result, keys)

    async def screenshot(self, full_page: bool = False) -> bytes:
        return await self._service.screenshot(self._session_id, full_page)

    async def get_state(self) -> BrowserState:
        return await self._service.get_state(self._session_id)

    async def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        await self._service.set_cookies(self._session_id, cookies)

    async def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        return await self._service.get_cookies(self._session_id, domain)

    async def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        return await self._service.validate_selectors(self._session_id, item, fields)

    async def extract_data(self, item: str, fields_json: str, limit: int = 100) -> dict:
        return await self._service.extract_data(
            self._session_id, item, fields_json, limit
        )

    async def close(self) -> None:
        await self._service.close_session(self._session_id)

    async def __aenter__(self) -> "AsyncBrowserSession":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
