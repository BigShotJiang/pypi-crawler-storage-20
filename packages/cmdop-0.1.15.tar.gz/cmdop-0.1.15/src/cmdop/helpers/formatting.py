"""JSON formatting utilities."""

import json

import yaml
from flatten_json import flatten


class JSONFormatter:
    """
    JSON to various formats converter.

    Usage:
        fmt = JSONFormatter()

        flat = fmt.flatten({"a": {"b": 1}})  # {"a.b": 1}
        yaml_str = fmt.to_yaml(data)
        text = fmt.to_text(data)  # key: value lines
    """

    def __init__(self, separator: str = "."):
        self.separator = separator

    def flatten(self, data: dict | list) -> dict:
        """
        Flatten nested JSON to flat dict with dot notation.

        {"a": {"b": 1}} -> {"a.b": 1}
        """
        if isinstance(data, list):
            data = {"items": data}
        return flatten(data, self.separator)

    def to_yaml(self, data: dict | list) -> str:
        """Convert to YAML string."""
        return yaml.dump(
            data,
            allow_unicode=True,
            default_flow_style=False,
            sort_keys=False,
            indent=2,
        )

    def to_text(self, data: dict | list) -> str:
        """Convert to flat text (key: value per line)."""
        flat = self.flatten(data)
        lines = []
        for key, value in flat.items():
            if isinstance(value, str):
                val_str = value
            elif value is None:
                val_str = "null"
            elif isinstance(value, bool):
                val_str = "true" if value else "false"
            else:
                val_str = str(value)
            lines.append(f"{key}: {val_str}")
        return "\n".join(lines)

    def to_json(self, data: dict | list, indent: int = 2) -> str:
        """Convert to formatted JSON string."""
        return json.dumps(data, indent=indent, ensure_ascii=False)


# Default instance
_fmt = JSONFormatter()

flatten_json = _fmt.flatten
json_to_yaml = _fmt.to_yaml
json_to_text = _fmt.to_text
