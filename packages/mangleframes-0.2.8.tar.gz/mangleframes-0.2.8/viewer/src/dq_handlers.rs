//! HTTP handlers for DQX data quality operations.
//! Proxies requests to Python DQX sidecar when available.

use std::sync::Arc;

use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::json;
use tracing::{error, info};

use crate::web_server::AppState;

/// Check if DQX is available.
pub async fn dqx_available(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let Some(ref dqx_url) = state.dqx_url else {
        return Json(json!({
            "available": false,
            "reason": "DQX sidecar not configured"
        }));
    };

    let client = reqwest::Client::new();
    let url = format!("{}/dqx/available", dqx_url);

    match client.get(&url).send().await {
        Ok(resp) => match resp.json::<serde_json::Value>().await {
            Ok(data) => Json(data),
            Err(e) => {
                error!("Failed to parse DQX response: {}", e);
                Json(json!({
                    "available": false,
                    "reason": format!("DQX sidecar error: {}", e)
                }))
            }
        },
        Err(e) => {
            error!("Failed to connect to DQX sidecar: {}", e);
            Json(json!({
                "available": false,
                "reason": format!("Cannot reach DQX sidecar: {}", e)
            }))
        }
    }
}

/// Profile a DataFrame and return suggested quality rules.
pub async fn profile_frame(
    State(state): State<Arc<AppState>>,
    Path(name): Path<String>,
) -> impl IntoResponse {
    let Some(ref dqx_url) = state.dqx_url else {
        return (
            StatusCode::NOT_IMPLEMENTED,
            Json(json!({
                "error": "DQX sidecar not configured"
            })),
        );
    };

    info!("Proxying profile request for frame: {}", name);
    let client = reqwest::Client::new();
    let url = format!("{}/frames/{}/profile", dqx_url, name);

    match client.post(&url).send().await {
        Ok(resp) => {
            let status = resp.status();
            match resp.json::<serde_json::Value>().await {
                Ok(data) => {
                    if status.is_success() {
                        (StatusCode::OK, Json(data))
                    } else {
                        (StatusCode::from_u16(status.as_u16()).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR), Json(data))
                    }
                }
                Err(e) => {
                    error!("Failed to parse profile response: {}", e);
                    (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error": e.to_string()})))
                }
            }
        }
        Err(e) => {
            error!("Failed to proxy profile request: {}", e);
            (StatusCode::BAD_GATEWAY, Json(json!({"error": e.to_string()})))
        }
    }
}

#[derive(Deserialize)]
pub struct CheckRequest {
    rules: Vec<DQRuleInput>,
}

#[derive(Deserialize, serde::Serialize)]
pub struct DQRuleInput {
    name: Option<String>,
    check_func: String,
    column: Option<String>,
    criticality: Option<String>,
    #[serde(default)]
    check_func_kwargs: serde_json::Value,
}

/// Apply quality checks to a DataFrame.
pub async fn run_quality_checks(
    State(state): State<Arc<AppState>>,
    Path(name): Path<String>,
    Json(req): Json<CheckRequest>,
) -> impl IntoResponse {
    let Some(ref dqx_url) = state.dqx_url else {
        return (
            StatusCode::NOT_IMPLEMENTED,
            Json(json!({
                "error": "DQX sidecar not configured"
            })),
        );
    };

    info!("Proxying check request for frame: {} with {} rules", name, req.rules.len());
    let client = reqwest::Client::new();
    let url = format!("{}/frames/{}/check", dqx_url, name);

    match client.post(&url).json(&json!({"rules": req.rules})).send().await {
        Ok(resp) => {
            let status = resp.status();
            match resp.json::<serde_json::Value>().await {
                Ok(data) => {
                    if status.is_success() {
                        (StatusCode::OK, Json(data))
                    } else {
                        (StatusCode::from_u16(status.as_u16()).unwrap_or(StatusCode::INTERNAL_SERVER_ERROR), Json(data))
                    }
                }
                Err(e) => {
                    error!("Failed to parse check response: {}", e);
                    (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error": e.to_string()})))
                }
            }
        }
        Err(e) => {
            error!("Failed to proxy check request: {}", e);
            (StatusCode::BAD_GATEWAY, Json(json!({"error": e.to_string()})))
        }
    }
}
