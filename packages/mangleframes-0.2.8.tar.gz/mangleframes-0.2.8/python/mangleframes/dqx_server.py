"""DQX sidecar HTTP server for data quality operations.

This server runs alongside the Rust viewer and provides DQX functionality
via HTTP endpoints. The Rust viewer proxies DQX requests to this server.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

from loguru import logger

if TYPE_CHECKING:
    from pyspark.sql import SparkSession

# Check if DQX is available
try:
    from databricks.labs.dqx.profiler.profiler import DQProfiler
    from databricks.labs.dqx.engine import DQEngine
    DQX_AVAILABLE = True
    logger.info("[DQX Sidecar] databricks-labs-dqx is available")
except ImportError:
    DQX_AVAILABLE = False
    logger.warning("[DQX Sidecar] databricks-labs-dqx not installed")

_spark_session: SparkSession | None = None
_server: ThreadingHTTPServer | None = None
_server_thread: threading.Thread | None = None


def set_spark_session(spark: SparkSession) -> None:
    """Set the SparkSession to use for DQX operations."""
    global _spark_session
    _spark_session = spark
    logger.info("[DQX Sidecar] SparkSession configured")


class DQXRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for DQX operations."""

    def log_message(self, format: str, *args: Any) -> None:
        """Override to use loguru for logging."""
        logger.debug(f"[DQX Sidecar] {format % args}")

    def _send_json(self, data: dict, status: int = 200) -> None:
        """Send a JSON response."""
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self) -> dict | None:
        """Read and parse JSON request body."""
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length == 0:
            return None
        body = self.rfile.read(content_length)
        return json.loads(body.decode("utf-8"))

    def do_OPTIONS(self) -> None:
        """Handle CORS preflight requests."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self) -> None:
        """Handle GET requests."""
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/health":
            self._handle_health()
        elif path == "/dqx/available":
            self._handle_available()
        else:
            self._send_json({"error": "Not found"}, 404)

    def do_POST(self) -> None:
        """Handle POST requests."""
        parsed = urlparse(self.path)
        path = parsed.path

        # Match /frames/{name}/profile
        if path.startswith("/frames/") and path.endswith("/profile"):
            frame_name = path[8:-8]  # Extract name between /frames/ and /profile
            self._handle_profile(frame_name)
        # Match /frames/{name}/check
        elif path.startswith("/frames/") and path.endswith("/check"):
            frame_name = path[8:-6]  # Extract name between /frames/ and /check
            self._handle_check(frame_name)
        else:
            self._send_json({"error": "Not found"}, 404)

    def _handle_health(self) -> None:
        """Health check endpoint."""
        self._send_json({"status": "ok"})

    def _handle_available(self) -> None:
        """Check if DQX is available."""
        if DQX_AVAILABLE:
            self._send_json({"available": True})
        else:
            self._send_json({
                "available": False,
                "reason": "databricks-labs-dqx is not installed",
            })

    def _handle_profile(self, frame_name: str) -> None:
        """Profile a DataFrame and return suggested rules."""
        if not DQX_AVAILABLE:
            self._send_json({
                "error": "DQX is not available",
                "reason": "databricks-labs-dqx is not installed",
            }, 501)
            return

        if _spark_session is None:
            self._send_json({
                "error": "SparkSession not configured",
            }, 500)
            return

        try:
            logger.info(f"[DQX Sidecar] Profiling frame: {frame_name}")
            df = _spark_session.table(frame_name)
            profiler = DQProfiler(_spark_session)
            summary_stats, checks = profiler.profile(df)
            logger.info(f"[DQX Sidecar] Generated {len(checks)} quality rules")

            # Convert checks to serializable format
            rules = []
            for check in checks:
                rule = {
                    "name": getattr(check, "name", None),
                    "check_func": check.check_func,
                    "column": check.col_name,
                    "criticality": check.criticality,
                }
                if check.check_func_kwargs:
                    rule["check_func_kwargs"] = check.check_func_kwargs
                rules.append(rule)

            self._send_json({
                "rules": rules,
                "summary": summary_stats,
            })
        except Exception as e:
            logger.error(f"[DQX Sidecar] Profile failed: {e}")
            self._send_json({"error": str(e)}, 500)

    def _handle_check(self, frame_name: str) -> None:
        """Run quality checks on a DataFrame."""
        if not DQX_AVAILABLE:
            self._send_json({
                "error": "DQX is not available",
                "reason": "databricks-labs-dqx is not installed",
            }, 501)
            return

        if _spark_session is None:
            self._send_json({
                "error": "SparkSession not configured",
            }, 500)
            return

        body = self._read_json_body()
        if not body or "rules" not in body:
            self._send_json({"error": "Missing 'rules' in request body"}, 400)
            return

        try:
            logger.info(f"[DQX Sidecar] Running checks on: {frame_name}")
            df = _spark_session.table(frame_name)

            from databricks.labs.dqx.col_functions import make_condition
            from databricks.labs.dqx.rule import DQRule

            # Convert input rules to DQRule objects
            dq_rules = []
            for rule_input in body["rules"]:
                rule = DQRule(
                    name=rule_input.get("name"),
                    criticality=rule_input.get("criticality", "error"),
                    check_func=rule_input["check_func"],
                    col_name=rule_input.get("column"),
                    check_func_kwargs=rule_input.get("check_func_kwargs", {}),
                )
                dq_rules.append(rule)

            engine = DQEngine(_spark_session)
            valid_df, invalid_df = engine.apply_checks(df, dq_rules)
            valid_count = valid_df.count()
            invalid_count = invalid_df.count()
            total_count = valid_count + invalid_count

            logger.info(
                f"[DQX Sidecar] Check complete: "
                f"{valid_count} valid, {invalid_count} invalid"
            )

            self._send_json({
                "total_rows": total_count,
                "valid_rows": valid_count,
                "invalid_rows": invalid_count,
                "pass_rate": valid_count / total_count if total_count > 0 else 1.0,
            })
        except Exception as e:
            logger.error(f"[DQX Sidecar] Check failed: {e}")
            self._send_json({"error": str(e)}, 500)


def start_server(port: int = 8766) -> bool:
    """Start the DQX sidecar server.

    Args:
        port: Port to listen on (default: 8766)

    Returns:
        True if server started successfully, False otherwise
    """
    global _server, _server_thread

    if _server is not None:
        logger.warning("[DQX Sidecar] Server already running")
        return True

    try:
        _server = ThreadingHTTPServer(("127.0.0.1", port), DQXRequestHandler)
        _server_thread = threading.Thread(target=_server.serve_forever, daemon=True)
        _server_thread.start()
        logger.info(f"[DQX Sidecar] Started on http://localhost:{port}")
        return True
    except Exception as e:
        logger.error(f"[DQX Sidecar] Failed to start: {e}")
        _server = None
        _server_thread = None
        return False


def stop_server() -> None:
    """Stop the DQX sidecar server."""
    global _server, _server_thread

    if _server is not None:
        logger.info("[DQX Sidecar] Stopping server...")
        _server.shutdown()
        _server = None
        _server_thread = None


def is_running() -> bool:
    """Check if the server is running."""
    return _server is not None
