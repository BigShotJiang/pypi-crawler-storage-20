# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for stack deployment functionality."""

from unittest.mock import MagicMock, patch

import pytest

from py_docker_admin.exceptions import StackCreationError
from py_docker_admin.models import StackConfig
from py_docker_admin.stack import StackManager


class TestStackManager:
    """Test StackManager class."""

    def test_stack_manager_initialization(self):
        """Test StackManager initialization."""
        mock_client = MagicMock()
        manager = StackManager(mock_client)
        assert manager.client == mock_client
        assert manager.logger is not None

    def test_deploy_stack_success(self):
        """Test successful stack deployment."""
        mock_client = MagicMock()
        stack_config = StackConfig(name="test-stack", compose_file="docker-compose.yml")

        mock_client.create_stack.return_value = {"id": 1, "name": "test-stack"}

        manager = StackManager(mock_client)
        manager.deploy_stack(stack_config)

        mock_client.create_stack.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,
            env_file=None,
        )

    def test_deploy_stack_failure(self):
        """Test failed stack deployment."""
        mock_client = MagicMock()
        stack_config = StackConfig(name="test-stack", compose_file="docker-compose.yml")

        mock_client.create_stack.side_effect = Exception("Deployment failed")

        manager = StackManager(mock_client)

        with pytest.raises(
            StackCreationError, match="Failed to deploy stack test-stack"
        ):
            manager.deploy_stack(stack_config)

    def test_deploy_stack_with_endpoint(self):
        """Test stack deployment with endpoint ID."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack", compose_file="docker-compose.yml", endpoint_id=2
        )

        mock_client.create_stack.return_value = {"id": 1, "name": "test-stack"}

        manager = StackManager(mock_client)
        manager.deploy_stack(stack_config)

        mock_client.create_stack.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=2,
            env_file=None,
        )

    def test_deploy_stack_with_env_file(self):
        """Test stack deployment with environment file."""
        mock_client = MagicMock()
        stack_config = StackConfig(
            name="test-stack", compose_file="docker-compose.yml", env_file="env.env"
        )

        mock_client.create_stack.return_value = {"id": 1, "name": "test-stack"}

        manager = StackManager(mock_client)
        manager.deploy_stack(stack_config)

        mock_client.create_stack.assert_called_once_with(
            name="test-stack",
            compose_file="docker-compose.yml",
            endpoint_id=None,
            env_file="env.env",
        )

    @patch("py_docker_admin.stack.StackManager.deploy_stack")
    def test_deploy_stacks_empty_list(self, mock_deploy_stack):
        """Test deploying empty stack list."""
        manager = StackManager(MagicMock())

        manager.deploy_stacks([])

        mock_deploy_stack.assert_not_called()

    @patch("py_docker_admin.stack.StackManager.deploy_stack")
    def test_deploy_stacks_multiple(self, mock_deploy_stack):
        """Test deploying multiple stacks."""
        stack_configs = [
            StackConfig(name="stack1", compose_file="compose1.yml"),
            StackConfig(name="stack2", compose_file="compose2.yml"),
            StackConfig(name="stack3", compose_file="compose3.yml"),
        ]

        manager = StackManager(MagicMock())
        manager.deploy_stacks(stack_configs)

        assert mock_deploy_stack.call_count == 3
        mock_deploy_stack.assert_any_call(stack_configs[0])
        mock_deploy_stack.assert_any_call(stack_configs[1])
        mock_deploy_stack.assert_any_call(stack_configs[2])

    @patch("py_docker_admin.stack.StackManager.deploy_stack")
    def test_deploy_stacks_with_failure(self, mock_deploy_stack):
        """Test deploying stacks with one failure."""
        stack_configs = [
            StackConfig(name="stack1", compose_file="compose1.yml"),
            StackConfig(name="stack2", compose_file="compose2.yml"),
        ]

        mock_deploy_stack.side_effect = [
            None,
            StackCreationError("Failed to deploy stack stack2: Failed"),
        ]

        manager = StackManager(MagicMock())

        with pytest.raises(StackCreationError, match="Failed to deploy stack stack2"):
            manager.deploy_stacks(stack_configs)

        assert mock_deploy_stack.call_count == 2
