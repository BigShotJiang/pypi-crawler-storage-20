# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Portainer installation and API client functionality."""

import logging
from typing import TYPE_CHECKING, Any

import requests

from .exceptions import PortainerAPIError, PortainerInstallationError
from .utils import run_command, wait_for_portainer

if TYPE_CHECKING:
    from .models import PortainerConfig


class PortainerClient:
    """Client for interacting with Portainer API."""

    def __init__(self, base_url: str = "http://localhost:9000"):
        """Initialize Portainer client.

        Args:
            base_url: Base URL for Portainer API
        """
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.logger = logging.getLogger(__name__)
        self._auth_token: str | None = None
        self._csrf_token: str | None = None

    def _request(
        self,
        method: str,
        endpoint: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a request to Portainer API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE)
            endpoint: API endpoint (without leading slash)
            data: Form data
            params: Query parameters
            json_data: JSON data

        Returns:
            Parsed JSON response

        Raises:
            PortainerAPIError: If request fails
        """
        url = f"{self.base_url}/api/{endpoint}"
        headers = {}

        if self._auth_token:
            headers["Authorization"] = f"Bearer {self._auth_token}"

        # For state-changing methods (POST, PUT, DELETE), we need CSRF token
        if method in ("POST", "PUT", "DELETE"):
            self._ensure_csrf_token()
            if self._csrf_token:
                headers["X-CSRF-Token"] = self._csrf_token

        try:
            response = self.session.request(
                method,
                url,
                data=data,
                params=params,
                json=json_data,
                headers=headers,
                timeout=30,
            )

            if response.status_code >= 400:
                error_msg = f"Portainer API error: {response.status_code}"
                if response.text:
                    error_msg += f" - {response.text}"
                raise PortainerAPIError(error_msg)

            return response.json()

        except requests.exceptions.RequestException as e:
            raise PortainerAPIError(f"Portainer API request failed: {e}")

    def _ensure_csrf_token(self) -> None:
        """Ensure we have a valid CSRF token for state-changing requests.

        Portainer requires CSRF tokens for POST, PUT, and DELETE requests.
        """
        if hasattr(self, "_csrf_token") and self._csrf_token:
            return

        try:
            # Get CSRF token from the login page or API
            response = self.session.get(f"{self.base_url}/api/auth", timeout=30)

            # Try to get CSRF token from cookies first
            csrf_token = None
            if "csrf_token" in self.session.cookies:
                csrf_token = self.session.cookies["csrf_token"]
            elif "portainer.csrf_token" in self.session.cookies:
                csrf_token = self.session.cookies["portainer.csrf_token"]

            # If not in cookies, try to extract from response headers
            if not csrf_token and "X-CSRF-Token" in response.headers:
                csrf_token = response.headers["X-CSRF-Token"]

            # If still not found, try to get it from the initial setup endpoint
            if not csrf_token:
                try:
                    init_response = self.session.get(
                        f"{self.base_url}/api/users/admin/init", timeout=30
                    )
                    if "X-CSRF-Token" in init_response.headers:
                        csrf_token = init_response.headers["X-CSRF-Token"]
                except requests.exceptions.RequestException:
                    pass

            if csrf_token:
                self._csrf_token = csrf_token
                self.logger.debug("Successfully obtained CSRF token")
            else:
                self.logger.warning(
                    "Could not obtain CSRF token, some operations may fail"
                )

        except requests.exceptions.RequestException as e:
            self.logger.warning(f"Failed to obtain CSRF token: {e}")
            self._csrf_token = None

    def create_admin_user(self, username: str, password: str) -> dict[str, Any]:
        """Create admin user using Portainer API.

        Args:
            username: Admin username
            password: Admin password

        Returns:
            API response

        Raises:
            PortainerAPIError: If admin creation fails
        """
        self.logger.info("Creating Portainer admin user")
        endpoint = "users/admin/init"

        data = {"username": username, "password": password}

        try:
            response = self._request("POST", endpoint, json_data=data)
            self.logger.info("Admin user created successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create admin user: {e}")
            raise

    def authenticate(self, username: str, password: str) -> dict[str, Any]:
        """Authenticate with Portainer and get JWT token.

        Args:
            username: Username
            password: Password

        Returns:
            Authentication response containing JWT token

        Raises:
            PortainerAPIError: If authentication fails
        """
        self.logger.info("Authenticating with Portainer")
        endpoint = "auth"

        data = {"username": username, "password": password}

        try:
            response = self._request("POST", endpoint, json_data=data)
            self._auth_token = response.get("jwt")
            self.logger.info("Authentication successful")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Authentication failed: {e}")
            raise

    def get_endpoints(self) -> dict[str, Any]:
        """Get list of Docker endpoints.

        Returns:
            List of endpoints

        Raises:
            PortainerAPIError: If request fails
        """
        return self._request("GET", "endpoints")

    def create_stack(
        self,
        name: str,
        compose_file: str,
        endpoint_id: int | None = None,
        env_file: str | None = None,
    ) -> dict[str, Any]:
        """Create a stack in Portainer.

        Args:
            name: Stack name
            compose_file: Path to docker-compose file
            endpoint_id: Portainer endpoint ID
            env_file: Path to environment file

        Returns:
            Stack creation response

        Raises:
            PortainerAPIError: If stack creation fails
        """
        self.logger.info(f"Creating stack: {name}")

        # Read compose file
        try:
            with open(compose_file) as f:
                compose_content = f.read()
        except OSError as e:
            raise PortainerAPIError(f"Failed to read compose file: {e}")

        # Read env file if provided
        env_vars = {}
        if env_file:
            try:
                with open(env_file) as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#"):
                            if "=" in line:
                                key, value = line.split("=", 1)
                                env_vars[key.strip()] = value.strip()
            except OSError as e:
                raise PortainerAPIError(f"Failed to read env file: {e}")

        # Prepare stack data
        stack_data = {
            "name": name,
            "type": 1,  # Docker Compose
            "endpointId": endpoint_id,
            "env": env_vars,
            "stackFileContent": compose_content,
        }

        try:
            response = self._request(
                "POST",
                "stacks?type=1&method=string&endpointId={endpoint_id}",
                json_data=stack_data,
            )
            self.logger.info(f"Stack {name} created successfully")
            return response
        except PortainerAPIError as e:
            self.logger.error(f"Failed to create stack {name}: {e}")
            raise


class PortainerInstaller:
    """Handles Portainer container installation."""

    def __init__(self, config: "PortainerConfig"):
        """Initialize Portainer installer with configuration.

        Args:
            config: Portainer configuration object
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

    def is_portainer_running(self) -> bool:
        """Check if Portainer container is already running.

        Returns:
            True if Portainer is running, False otherwise
        """
        try:
            result = run_command(
                f"docker ps --filter 'name={self.config.container_name}' --format '{{{{.Names}}}}'",
                check=False,
                capture_output=True,
            )
            return self.config.container_name in result.stdout
        except Exception:
            return False

    def remove_existing_container(self) -> None:
        """Remove existing Portainer container if configured to do so."""
        if not self.config.remove_existing:
            return

        try:
            run_command(f"docker rm -f {self.config.container_name}", log_level="info")
            self.logger.info("Removed existing Portainer container")
        except Exception as e:
            self.logger.warning(f"Failed to remove existing container: {e}")

    def install_portainer(self) -> None:
        """Install Portainer as a Docker container."""
        self.logger.info("Installing Portainer container")

        if self.is_portainer_running():
            if self.config.remove_existing:
                self.remove_existing_container()
            else:
                self.logger.info("Portainer is already running")
                return

        try:
            # Run Portainer container with auto-restart policy
            command = (
                f"docker run -d --name {self.config.container_name} "
                f"--restart unless-stopped "
                f"-p {self.config.port}:9000 "
                f"-v {self.config.volume} "
                f"portainer/portainer-ce:latest"
            )

            # Add base_url parameter if configured (for reverse proxy support)
            if self.config.base_url and self.config.base_url.strip():
                command += f" --base-url {self.config.base_url}"

            run_command(command, log_level="info")
            self.logger.info(
                "Portainer container started successfully with auto-restart policy"
            )

            # Wait for Portainer to be ready
            base_url = f"http://localhost:{self.config.port}"
            wait_for_portainer(base_url)

        except Exception as e:
            raise PortainerInstallationError(f"Failed to install Portainer: {e}")

    def setup_portainer(self) -> PortainerClient:
        """Install and setup Portainer with admin user.

        Returns:
            Configured PortainerClient instance

        Raises:
            PortainerInstallationError: If setup fails
        """
        try:
            self.install_portainer()

            # Create Portainer client
            base_url = f"http://localhost:{self.config.port}"
            client = PortainerClient(base_url)

            # Create admin user
            client.create_admin_user(
                self.config.admin_username, self.config.admin_password
            )

            # Authenticate to get JWT token
            client.authenticate(self.config.admin_username, self.config.admin_password)

            self.logger.info("Portainer setup completed successfully")
            return client

        except Exception as e:
            raise PortainerInstallationError(f"Portainer setup failed: {e}")
