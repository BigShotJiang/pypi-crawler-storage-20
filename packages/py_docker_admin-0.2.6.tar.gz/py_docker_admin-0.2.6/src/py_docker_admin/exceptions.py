# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Custom exceptions for py-docker-admin package."""

class DockerAdminError(Exception):
    """Base exception for all py-docker-admin errors."""

class DockerInstallationError(DockerAdminError):
    """Exception raised when Docker installation fails."""

class PortainerInstallationError(DockerAdminError):
    """Exception raised when Portainer installation fails."""

class PortainerAPIError(DockerAdminError):
    """Exception raised when Portainer API operations fail."""

class StackCreationError(DockerAdminError):
    """Exception raised when stack creation fails."""

class ConfigurationError(DockerAdminError):
    """Exception raised when configuration is invalid."""

class DockerNotRunningError(DockerAdminError):
    """Exception raised when Docker is not running."""
