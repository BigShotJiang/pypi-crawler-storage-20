from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class Experiment:
    name: str


@dataclass(frozen=True, slots=True)
class Project:
    name: str


@dataclass(frozen=True, slots=True)
class Run:
    name: str
    sequential: int
    experiment: Experiment
    project: Project

    @property
    def urki(self) -> str:
        return f"https://tyko-labs.com/dashboard/projects/{self.project.name}/experiments/{self.experiment.name}/runs/{self.name}-{self.sequential}"

    def __enter__(self) -> "Run":
        # Setup code for starting the run can go here
        return self

    def __exit__(self, exc_type: Any, exc_value: Any, traceback: Any) -> None:
        # Cleanup code for ending the run can go here
        pass
