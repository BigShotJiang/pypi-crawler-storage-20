import sys
import pandas as pd
import numpy as np

def topsis(matrix, weights, impacts):
    # Check if empty
    if len(matrix) == 0:
        raise ValueError("Decision matrix cannot be empty")

    # Normalize matrix
    matrix = np.array(matrix, dtype=float)
    norm_matrix = matrix / np.sqrt((matrix ** 2).sum(axis=0))

    # Apply weights
    weights = np.array(weights, dtype=float)
    weighted_matrix = norm_matrix * weights

    # Ideal best and worst
    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted_matrix[:, i].max())
            ideal_worst.append(weighted_matrix[:, i].min())
        else:
            ideal_best.append(weighted_matrix[:, i].min())
            ideal_worst.append(weighted_matrix[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    # Euclidean distance
    dist_best = np.sqrt(((weighted_matrix - ideal_best) ** 2).sum(axis=1))
    dist_worst = np.sqrt(((weighted_matrix - ideal_worst) ** 2).sum(axis=1))

    # Performance score
    score = dist_worst / (dist_best + dist_worst)

    return score

def main():
    if len(sys.argv) != 4:
        print("Usage: topsis <InputDataFile> <Weights> <Impacts>")
        print('Example: topsis data.csv "1,1,1,1" "+,+,-,+"')
        return

    input_file = sys.argv[1]
    weights_str = sys.argv[2]
    impacts_str = sys.argv[3]

    try:
        # Read the input file
        df = pd.read_csv(input_file)
        
        # Check if file has enough columns (at least 3)
        if df.shape[1] < 3:
            print("Error: Input file must contain at least 3 columns.")
            return

        # Preprocessing: Drop the first column (assuming it's Model/Name) 
        # and convert categorical values if necessary.
        # For this specific implementation, we assume the user provides numeric data 
        # for columns 2 onwards, or pre-processes categorical data.
        
        # We process only the numeric columns (skipping the first object column)
        data = df.iloc[:, 1:].values
        
        weights = [float(w) for w in weights_str.split(',')]
        impacts = impacts_str.split(',')

        if len(weights) != data.shape[1] or len(impacts) != data.shape[1]:
            print("Error: Number of weights/impacts must match the number of criteria columns.")
            return

        # Calculate TOPSIS
        scores = topsis(data, weights, impacts)

        # Append scores to dataframe
        df['Topsis Score'] = scores
        
        # Calculate Rank
        df['Rank'] = df['Topsis Score'].rank(ascending=False).astype(int)

        # Print result to console (Type A requirement)
        print(df.to_string(index=False))

    except FileNotFoundError:
        print("Error: File not found.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()