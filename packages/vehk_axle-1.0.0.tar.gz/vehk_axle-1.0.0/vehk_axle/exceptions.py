"""
Vehk SDK Exceptions
===================

Custom exceptions for the Vehk Python SDK.
"""

from typing import Optional, Dict, Any


class VehkError(Exception):
    """Base exception for all Vehk SDK errors."""
    
    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)
    
    def __str__(self) -> str:
        if self.code:
            return f"[{self.code}] {self.message}"
        return self.message
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, code={self.code!r})"


class VehkAPIError(VehkError):
    """Error returned from the Vehk API."""
    
    def __init__(
        self,
        message: str,
        status_code: int,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None
    ):
        super().__init__(message, code, details)
        self.status_code = status_code
        self.correlation_id = correlation_id
    
    def __str__(self) -> str:
        base = f"[HTTP {self.status_code}] {self.message}"
        if self.correlation_id:
            base += f" (correlation_id: {self.correlation_id})"
        return base


class VehkAuthenticationError(VehkAPIError):
    """Authentication failed - invalid or expired API key."""
    
    def __init__(
        self,
        message: str = "Authentication failed. Check your API key.",
        status_code: int = 401,
        **kwargs
    ):
        super().__init__(message, status_code, code="AUTHENTICATION_ERROR", **kwargs)


class VehkRateLimitError(VehkAPIError):
    """Rate limit exceeded."""
    
    def __init__(
        self,
        message: str = "Rate limit exceeded. Please slow down.",
        status_code: int = 429,
        retry_after: Optional[int] = None,
        **kwargs
    ):
        super().__init__(message, status_code, code="RATE_LIMIT_ERROR", **kwargs)
        self.retry_after = retry_after


class VehkValidationError(VehkError):
    """Invalid request data."""
    
    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        **kwargs
    ):
        super().__init__(message, code="VALIDATION_ERROR", **kwargs)
        self.field = field


class VehkConnectionError(VehkError):
    """Failed to connect to Vehk API."""
    
    def __init__(
        self,
        message: str = "Failed to connect to Vehk API. Please check your network.",
        original_error: Optional[Exception] = None,
        **kwargs
    ):
        super().__init__(message, code="CONNECTION_ERROR", **kwargs)
        self.original_error = original_error


class VehkTimeoutError(VehkConnectionError):
    """Request timed out."""
    
    def __init__(
        self,
        message: str = "Request timed out. The server took too long to respond.",
        **kwargs
    ):
        super().__init__(message, **kwargs)
        self.code = "TIMEOUT_ERROR"
