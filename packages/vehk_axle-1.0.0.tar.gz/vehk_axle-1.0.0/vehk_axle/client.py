"""
Vehk SDK Client
===============

Main client class for interacting with the Vehk Axle API.
"""

import time
import logging
from typing import Optional, Dict, Any, List, Union
from datetime import datetime
import requests
from urllib.parse import urljoin

from .exceptions import (
    VehkError,
    VehkAPIError,
    VehkAuthenticationError,
    VehkRateLimitError,
    VehkValidationError,
    VehkConnectionError,
    VehkTimeoutError,
)
from .models import (
    TelemetryData,
    Prediction,
    Vehicle,
    BatchResult,
)

logger = logging.getLogger("vehk_axle")


class TelemetryAPI:
    """Telemetry operations."""
    
    def __init__(self, client: "VehkClient"):
        self._client = client
    
    def send(
        self,
        vehicle_id: str,
        sensor_data: Dict[str, Any],
        timestamp: Optional[str] = None,
        location: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Send a single telemetry data point.
        
        Args:
            vehicle_id: Unique vehicle identifier
            sensor_data: Dictionary of sensor readings (e.g., {"speed": 65, "rpm": 2500})
            timestamp: ISO timestamp (defaults to now)
            location: GPS coordinates {"lat": 12.97, "lng": 77.59}
        
        Returns:
            API response with telemetry_id and received_at
        
        Example:
            >>> client.telemetry.send(
            ...     vehicle_id="VH-001",
            ...     sensor_data={"speed": 65, "rpm": 2500, "coolant_temp": 92}
            ... )
            {'success': True, 'telemetry_id': '...', 'received_at': '...'}
        """
        payload = {
            "vehicle_id": vehicle_id,
            "sensor_data": sensor_data,
        }
        if timestamp:
            payload["timestamp"] = timestamp
        if location:
            payload["location"] = location
        
        return self._client._request("POST", "/api/external/telemetry", json=payload)
    
    def send_batch(
        self,
        data: List[Union[TelemetryData, Dict[str, Any]]]
    ) -> BatchResult:
        """
        Send multiple telemetry data points in a single request.
        
        Args:
            data: List of TelemetryData objects or dicts with vehicle_id and sensor_data
        
        Returns:
            BatchResult with processing summary
        
        Example:
            >>> client.telemetry.send_batch([
            ...     {"vehicle_id": "VH-001", "sensor_data": {"speed": 65}},
            ...     {"vehicle_id": "VH-002", "sensor_data": {"speed": 70}},
            ... ])
            BatchResult(records_processed=2, ...)
        """
        if len(data) > 100:
            raise VehkValidationError(
                "Maximum 100 records per batch. Split your data into smaller batches.",
                field="data"
            )
        
        # Normalize data
        normalized = []
        for item in data:
            if isinstance(item, TelemetryData):
                normalized.append(item.to_dict())
            else:
                normalized.append(item)
        
        response = self._client._request(
            "POST",
            "/api/external/telemetry/batch",
            json={"data": normalized}
        )
        return BatchResult.from_api_response(response)


class PredictionAPI:
    """Prediction operations."""
    
    def __init__(self, client: "VehkClient"):
        self._client = client
    
    def get(
        self,
        vehicle_id: str,
        sensor_data: Dict[str, Any],
        timestamp: Optional[str] = None
    ) -> Prediction:
        """
        Get an ML prediction for a vehicle.
        
        Args:
            vehicle_id: Unique vehicle identifier
            sensor_data: Current sensor readings
            timestamp: ISO timestamp (defaults to now)
        
        Returns:
            Prediction object with health score, alerts, and recommendations
        
        Example:
            >>> prediction = client.predictions.get(
            ...     vehicle_id="VH-001",
            ...     sensor_data={"speed": 65, "rpm": 2500, "coolant_temp": 92}
            ... )
            >>> print(prediction.health_score)
            78.5
            >>> print(prediction.is_critical)
            False
        """
        payload = {
            "vehicle_id": vehicle_id,
            "sensor_data": sensor_data,
        }
        if timestamp:
            payload["timestamp"] = timestamp
        
        response = self._client._request("POST", "/api/external/predict", json=payload)
        return Prediction.from_api_response(response)
    
    def list(
        self,
        vehicle_id: Optional[str] = None,
        limit: int = 50
    ) -> List[Prediction]:
        """
        Get recent predictions for your vehicles.
        
        Args:
            vehicle_id: Filter by specific vehicle (optional)
            limit: Maximum results (default 50, max 500)
        
        Returns:
            List of Prediction objects
        """
        params = {"limit": min(limit, 500)}
        if vehicle_id:
            params["vehicle_id"] = vehicle_id
        
        response = self._client._request("GET", "/api/external/predictions", params=params)
        
        predictions = []
        for item in response.get("predictions", []):
            # Wrap in expected format for parsing
            wrapped = {
                "vehicle_id": item.get("vehicle_id"),
                "prediction": item.get("prediction", {}),
                "metadata": {
                    "timestamp": item.get("processed_at")
                }
            }
            predictions.append(Prediction.from_api_response(wrapped))
        
        return predictions


class VehicleAPI:
    """Vehicle operations."""
    
    def __init__(self, client: "VehkClient"):
        self._client = client
    
    def list(self) -> List[Vehicle]:
        """
        Get all vehicles registered under your tenant.
        
        Returns:
            List of Vehicle objects
        
        Example:
            >>> vehicles = client.vehicles.list()
            >>> for v in vehicles:
            ...     print(f"{v.vehicle_id}: {v.health_score}")
        """
        response = self._client._request("GET", "/api/external/vehicles")
        return [Vehicle.from_api_response(v) for v in response.get("vehicles", [])]


class VehkClient:
    """
    Vehk Axle Python SDK Client.
    
    This is the main entry point for all Vehk API operations.
    
    Args:
        api_key: Your Vehk API key (starts with 'vehk_')
        base_url: API base URL (defaults to production)
        timeout: Request timeout in seconds (default 30)
        retries: Number of retries for failed requests (default 3)
        retry_delay: Delay between retries in seconds (default 1)
    
    Example:
        >>> from vehk_axle import VehkClient
        >>> 
        >>> client = VehkClient(api_key="vehk_your_api_key")
        >>> 
        >>> # Send telemetry
        >>> client.telemetry.send(
        ...     vehicle_id="VH-001",
        ...     sensor_data={"speed": 65, "rpm": 2500}
        ... )
        >>> 
        >>> # Get prediction
        >>> prediction = client.predict(
        ...     vehicle_id="VH-001",
        ...     sensor_data={"speed": 65, "rpm": 2500}
        ... )
        >>> print(f"Health: {prediction.health_score}%")
    """
    
    DEFAULT_BASE_URL = "https://vehk-api.bravedune-34ccdec3.centralindia.azurecontainerapps.io"
    SDK_VERSION = "1.0.0"
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: int = 30,
        retries: int = 3,
        retry_delay: float = 1.0,
    ):
        if not api_key:
            raise VehkValidationError("API key is required", field="api_key")
        if not api_key.startswith("vehk_"):
            raise VehkValidationError(
                "Invalid API key format. API key must start with 'vehk_'",
                field="api_key"
            )
        
        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self.retry_delay = retry_delay
        
        # Create session for connection pooling
        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": f"vehk-python-sdk/{self.SDK_VERSION}",
        })
        
        # Initialize sub-APIs
        self.telemetry = TelemetryAPI(self)
        self.predictions = PredictionAPI(self)
        self.vehicles = VehicleAPI(self)
        
        logger.debug(f"VehkClient initialized with base_url={self.base_url}")
    
    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Make an HTTP request to the Vehk API."""
        url = urljoin(self.base_url, path)
        
        last_error = None
        for attempt in range(self.retries):
            try:
                response = self._session.request(
                    method=method,
                    url=url,
                    params=params,
                    json=json,
                    timeout=self.timeout,
                    **kwargs
                )
                
                # Parse response
                try:
                    data = response.json()
                except ValueError:
                    data = {"raw": response.text}
                
                # Handle errors
                if response.status_code == 401:
                    raise VehkAuthenticationError(
                        message=data.get("error", {}).get("message", "Authentication failed"),
                        correlation_id=data.get("error", {}).get("correlation_id")
                    )
                
                if response.status_code == 429:
                    retry_after = response.headers.get("Retry-After", 60)
                    raise VehkRateLimitError(
                        message="Rate limit exceeded",
                        retry_after=int(retry_after) if retry_after else None
                    )
                
                if response.status_code >= 400:
                    error_msg = data.get("error", {}).get("message", data.get("detail", "Unknown error"))
                    if isinstance(error_msg, dict):
                        error_msg = error_msg.get("message", str(error_msg))
                    
                    raise VehkAPIError(
                        message=str(error_msg),
                        status_code=response.status_code,
                        code=data.get("error", {}).get("code"),
                        correlation_id=data.get("error", {}).get("correlation_id")
                    )
                
                return data
                
            except requests.exceptions.Timeout:
                last_error = VehkTimeoutError()
                logger.warning(f"Request timeout (attempt {attempt + 1}/{self.retries})")
                
            except requests.exceptions.ConnectionError as e:
                last_error = VehkConnectionError(original_error=e)
                logger.warning(f"Connection error (attempt {attempt + 1}/{self.retries}): {e}")
                
            except (VehkAuthenticationError, VehkRateLimitError):
                # Don't retry auth or rate limit errors
                raise
                
            except VehkAPIError:
                # Don't retry API errors (they're not transient)
                raise
            
            # Wait before retry
            if attempt < self.retries - 1:
                time.sleep(self.retry_delay * (attempt + 1))
        
        # All retries exhausted
        if last_error:
            raise last_error
        raise VehkConnectionError("Request failed after all retries")
    
    # Convenience methods
    def predict(
        self,
        vehicle_id: str,
        sensor_data: Dict[str, Any],
        timestamp: Optional[str] = None
    ) -> Prediction:
        """
        Shortcut for client.predictions.get().
        
        Example:
            >>> prediction = client.predict("VH-001", {"speed": 65, "rpm": 2500})
        """
        return self.predictions.get(vehicle_id, sensor_data, timestamp)
    
    def send_telemetry(
        self,
        vehicle_id: str,
        sensor_data: Dict[str, Any],
        **kwargs
    ) -> Dict[str, Any]:
        """
        Shortcut for client.telemetry.send().
        
        Example:
            >>> client.send_telemetry("VH-001", {"speed": 65, "rpm": 2500})
        """
        return self.telemetry.send(vehicle_id, sensor_data, **kwargs)
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check if the Vehk API is healthy.
        
        Returns:
            Health status dictionary
        """
        # Health endpoint doesn't require auth
        response = requests.get(
            urljoin(self.base_url, "/api/external/health"),
            timeout=10
        )
        return response.json()
    
    def close(self):
        """Close the HTTP session."""
        self._session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
    
    def __repr__(self) -> str:
        key_preview = f"{self.api_key[:12]}..." if len(self.api_key) > 12 else self.api_key
        return f"VehkClient(api_key='{key_preview}', base_url='{self.base_url}')"
