"""
Vehk SDK Data Models
====================

Pydantic models for type-safe SDK responses.
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class HealthStatus(Enum):
    """Vehicle health status levels."""
    CRITICAL = "critical"
    WARNING = "warning"
    HEALTHY = "healthy"
    UNKNOWN = "unknown"


class RiskLevel(Enum):
    """Risk assessment levels."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    NONE = "none"


@dataclass
class TelemetryData:
    """Telemetry data point."""
    
    vehicle_id: str
    sensor_data: Dict[str, Any]
    timestamp: Optional[str] = None
    location: Optional[Dict[str, float]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API request."""
        data = {
            "vehicle_id": self.vehicle_id,
            "sensor_data": self.sensor_data,
        }
        if self.timestamp:
            data["timestamp"] = self.timestamp
        if self.location:
            data["location"] = self.location
        return data


@dataclass
class ComponentHealth:
    """Health status for a specific component."""
    
    name: str
    score: float
    risk: RiskLevel
    issues: List[str] = field(default_factory=list)
    
    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> "ComponentHealth":
        return cls(
            name=name,
            score=data.get("score", 0),
            risk=RiskLevel(data.get("risk", "low")),
            issues=data.get("issues", [])
        )


@dataclass
class MaintenanceAlert:
    """Maintenance recommendation."""
    
    type: str
    urgency: str
    description: str
    due_in_days: Optional[int] = None
    due_in_km: Optional[int] = None
    estimated_cost: Optional[float] = None


@dataclass
class Prediction:
    """ML prediction result."""
    
    vehicle_id: str
    health_score: float
    health_status: HealthStatus
    risk_level: RiskLevel
    components: Dict[str, ComponentHealth]
    maintenance_alerts: List[MaintenanceAlert]
    recommendations: List[str]
    confidence: float
    model_version: str
    processing_time_ms: float
    timestamp: str
    raw_response: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "Prediction":
        """Parse API response into Prediction object."""
        prediction = data.get("prediction", {})
        metadata = data.get("metadata", {})
        
        # Parse components
        components = {}
        for name, comp_data in prediction.get("component_health", {}).items():
            components[name] = ComponentHealth.from_dict(name, comp_data)
        
        # Parse maintenance alerts
        alerts = []
        for alert_data in prediction.get("maintenance_alerts", []):
            alerts.append(MaintenanceAlert(
                type=alert_data.get("type", "unknown"),
                urgency=alert_data.get("urgency", "low"),
                description=alert_data.get("description", ""),
                due_in_days=alert_data.get("due_in_days"),
                due_in_km=alert_data.get("due_in_km"),
                estimated_cost=alert_data.get("estimated_cost")
            ))
        
        # Parse health status
        health_status_str = prediction.get("health_status", "unknown")
        try:
            health_status = HealthStatus(health_status_str)
        except ValueError:
            health_status = HealthStatus.UNKNOWN
        
        # Parse risk level
        risk_str = prediction.get("risk_level", "low")
        try:
            risk_level = RiskLevel(risk_str)
        except ValueError:
            risk_level = RiskLevel.LOW
        
        return cls(
            vehicle_id=data.get("vehicle_id", ""),
            health_score=prediction.get("health_score", 0),
            health_status=health_status,
            risk_level=risk_level,
            components=components,
            maintenance_alerts=alerts,
            recommendations=prediction.get("recommendations", []),
            confidence=prediction.get("confidence", 0.0),
            model_version=metadata.get("model_version", "unknown"),
            processing_time_ms=metadata.get("processing_time_ms", 0),
            timestamp=metadata.get("timestamp", ""),
            raw_response=data
        )
    
    @property
    def is_critical(self) -> bool:
        """Check if vehicle needs immediate attention."""
        return self.health_status == HealthStatus.CRITICAL or self.risk_level == RiskLevel.HIGH
    
    @property
    def needs_maintenance(self) -> bool:
        """Check if vehicle has pending maintenance."""
        return len(self.maintenance_alerts) > 0


@dataclass
class Vehicle:
    """Vehicle information."""
    
    id: str
    vehicle_id: str
    vin: Optional[str] = None
    make: Optional[str] = None
    model: Optional[str] = None
    year: Optional[int] = None
    registration: Optional[str] = None
    health_score: Optional[float] = None
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "Vehicle":
        return cls(
            id=data.get("id", ""),
            vehicle_id=data.get("vehicle_id", ""),
            vin=data.get("vin"),
            make=data.get("make"),
            model=data.get("model"),
            year=data.get("year"),
            registration=data.get("registration"),
            health_score=data.get("health_score")
        )


@dataclass
class BatchResult:
    """Result of a batch operation."""
    
    success: bool
    records_processed: int
    records_failed: int
    processing_time_ms: float
    errors: List[Dict[str, Any]] = field(default_factory=list)
    
    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "BatchResult":
        return cls(
            success=data.get("success", False),
            records_processed=data.get("records_ingested", data.get("records_processed", 0)),
            records_failed=data.get("records_failed", 0),
            processing_time_ms=data.get("processing_time_ms", 0),
            errors=data.get("errors", [])
        )


@dataclass
class APIKeyInfo:
    """API key information."""
    
    key_id: str
    name: str
    prefix: str
    expires_at: str
    usage_count: int
    rate_limit: Dict[str, int]
    status: str
    
    @property
    def is_active(self) -> bool:
        return self.status == "active"
