"""
Vehk Axle Python SDK
====================

Official Python SDK for Vehk Axle Fleet Management & Predictive Maintenance Platform.

Installation:
    pip install vehk-axle

Quick Start:
    from vehk_axle import VehkClient
    
    client = VehkClient(api_key="vehk_your_api_key")
    
    # Send telemetry
    client.telemetry.send(
        vehicle_id="VH-001",
        sensor_data={"speed": 65, "rpm": 2500}
    )
    
    # Get prediction
    prediction = client.predict(
        vehicle_id="VH-001",
        sensor_data={"speed": 65, "rpm": 2500}
    )
    print(prediction.health_score)

Documentation: https://docs.vehk.in/sdk/python
"""

__version__ = "1.0.0"
__author__ = "Vehk Engineering Team"
__email__ = "support@vehk.in"

from .client import VehkClient
from .exceptions import (
    VehkError,
    VehkAPIError,
    VehkAuthenticationError,
    VehkRateLimitError,
    VehkValidationError,
    VehkConnectionError,
)
from .models import (
    TelemetryData,
    Prediction,
    Vehicle,
    BatchResult,
)

__all__ = [
    "VehkClient",
    "VehkError",
    "VehkAPIError",
    "VehkAuthenticationError",
    "VehkRateLimitError",
    "VehkValidationError",
    "VehkConnectionError",
    "TelemetryData",
    "Prediction",
    "Vehicle",
    "BatchResult",
]
