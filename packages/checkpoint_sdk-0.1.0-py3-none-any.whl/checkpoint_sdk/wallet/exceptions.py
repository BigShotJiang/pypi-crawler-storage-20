class InsufficientBalance(Exception):
    pass