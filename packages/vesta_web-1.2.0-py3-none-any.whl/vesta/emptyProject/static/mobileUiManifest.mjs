let mobileTemplatesAlts = {

}