# SPDX-FileCopyrightText: 2024 Forschungszentrum Jülich GmbH
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileContributor: Nitai Heeb

import argparse
import logging
import os
import re
import shutil
import sys
import traceback
from dataclasses import dataclass
from enum import Enum, auto
from importlib import metadata
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests
import toml
from pydantic import BaseModel
from requests import HTTPError

import hermes.commands.init.util.slim_click as sc
from hermes.commands import marketplace
from hermes.commands.base import HermesCommand, HermesPlugin
from hermes.commands.init.util import (connect_github, connect_gitlab,
                                       connect_zenodo, git_info)

TUTORIAL_URL = "https://hermes.software-metadata.pub/en/latest/tutorials/automated-publication-with-ci.html"


class GitHoster(Enum):
    Empty = auto()
    GitHub = auto()
    GitLab = auto()


class DepositPlatform(Enum):
    Empty = auto()
    Zenodo = auto()
    ZenodoSandbox = auto()


DepositPlatformNames: dict[DepositPlatform, str] = {
        DepositPlatform.ZenodoSandbox: "Zenodo (Sandbox)",
        DepositPlatform.Zenodo: "Zenodo",
    }


DepositPlatformUrls: dict[DepositPlatform, str] = {
        DepositPlatform.Zenodo: "https://zenodo.org/",
        DepositPlatform.ZenodoSandbox: "https://sandbox.zenodo.org/"
    }


@dataclass
class HermesInitFolderInfo:
    """
    Contains information about the current state of the target project directory.
    """
    def __init__(self):
        self.absolute_path: str = ""
        self.has_git_folder: bool = False
        self.has_hermes_toml: bool = False
        self.has_gitignore: bool = False
        self.has_citation_cff: bool = False
        self.has_readme: bool = False
        self.current_dir: str = ""
        self.dir_list: list[str] = []
        self.dir_folders: list[str] = []


def scout_current_folder() -> HermesInitFolderInfo:
    """
    This method looks at the current directory and collects all init relevant data.
    This method is not meant to contain any user interactions.
    @return: HermesInitFolderInfo object containing the gathered knowledge
    """
    info = HermesInitFolderInfo()
    current_dir = os.getcwd()
    info.current_dir = current_dir
    info.absolute_path = str(current_dir)
    info.has_git_folder = os.path.isdir(os.path.join(current_dir, ".git"))
    info.has_hermes_toml = os.path.isfile(os.path.join(current_dir, "hermes.toml"))
    info.has_gitignore = os.path.isfile(os.path.join(current_dir, ".gitignore"))
    info.has_citation_cff = os.path.isfile(os.path.join(current_dir, "CITATION.cff"))
    info.has_readme = os.path.isfile(os.path.join(current_dir, "README.md"))
    info.dir_list = os.listdir(current_dir)
    info.dir_folders = [
        f for f in info.dir_list
        if os.path.isdir(os.path.join(current_dir, f))
        and not f.startswith(".")
    ]
    return info


def get_git_hoster_from_url(url: str) -> GitHoster:
    """
    Returns the matching GitHoster value to the given url. Returns GitHoster.Empty if none is found.
    """
    parsed_url = urlparse(url)
    git_base_url = f"{parsed_url.scheme}://{parsed_url.netloc}/"  # noqa E231
    if "github.com" in url:
        return GitHoster.GitHub
    elif connect_gitlab.is_url_gitlab(git_base_url):
        return GitHoster.GitLab
    return GitHoster.Empty


def download_file_from_url(url, filepath, append: bool = False) -> None:
    try:
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(filepath, 'ab' if append else 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
    except HTTPError:
        sc.echo(f"No file found at {url}.", formatting=sc.Formats.FAIL)


def string_in_file(file_path, search_string: str) -> bool:
    with open(file_path, 'r', encoding='utf-8') as file:
        return any(search_string in line for line in file)


def get_builtin_plugins(plugin_commands: list[str]) -> dict[str: HermesPlugin]:
    """
    Returns a list of installed HermesPlugins based on a list of related command names.
    This is currently not used (we use the marketplace code instead) but maybe later.
    """
    plugins = {}
    for plugin_command_name in plugin_commands:
        entry_point_group = f"hermes.{plugin_command_name}"
        group_plugins = {
            entry_point.name: entry_point.load()
            for entry_point in metadata.entry_points(group=entry_point_group)
        }
        plugins.update(group_plugins)
    return plugins


def get_handler_by_name(name: str) -> logging.Handler | None:
    """Own implementation of logging.getHandlerByName so that we don't require Python 3.12"""
    for logger_name in logging.root.manager.loggerDict:
        logger = logging.getLogger(logger_name)
        for handler in logger.handlers:
            if handler.get_name() == name:
                return handler
    return None


class _HermesInitSettings(BaseModel):
    """Configuration of the ``init`` command."""
    pass


class HermesInitCommand(HermesCommand):
    """ Install HERMES onto a project. """
    command_name = "init"
    settings_class = _HermesInitSettings

    def __init__(self, parser: argparse.ArgumentParser):
        super().__init__(parser)
        self.folder_info: HermesInitFolderInfo = HermesInitFolderInfo()
        self.hermes_was_already_installed: bool = False
        self.new_created_paths: list[Path] = []
        self.tokens: dict = {}
        self.setup_method: str = ""
        self.deposit_platform: DepositPlatform = DepositPlatform.Empty
        self.git_remote: str = ""
        self.git_remote_url = ""
        self.git_hoster: GitHoster = GitHoster.Empty
        self.template_base_url: str = "https://raw.githubusercontent.com"
        self.template_branch: str = "feature/init-custom-ci"
        self.template_repo: str = "softwarepub/ci-templates"
        self.template_folder: str = "init"
        self.ci_parameters: dict = {
            "deposit_zip_name": "artifact.zip",
            "deposit_zip_files": "",
            "deposit_initial": "--initial",
            "deposit_extra_files": "",
            "push_branch": "main"
        }
        self.hermes_toml_data = {
            "harvest": {
                "sources": ["cff"]
            },
            "deposit": {
                "target": "invenio_rdm",
                "invenio_rdm": {
                    "site_url": "",
                    "access_right": "open"
                 }
            }
        }
        self.plugin_relevant_commands = ["harvest", "deposit"]
        self.builtin_plugins: dict[str: HermesPlugin] = get_builtin_plugins(self.plugin_relevant_commands)
        self.selected_plugins: list[marketplace.PluginInfo] = []

    def init_command_parser(self, command_parser: argparse.ArgumentParser) -> None:
        command_parser.add_argument('--template-branch', nargs=1, default="",
                                    help="Branch or tag of the ci-templates repository.")

    def load_settings(self, args: argparse.Namespace):
        pass

    def refresh_folder_info(self) -> None:
        """Checks the contents of the current directory and saves relevant info in self.folder_info"""
        sc.debug_info("Scanning folder...")
        self.folder_info = scout_current_folder()
        sc.debug_info("Scan complete.")

    def setup_file_logging(self) -> None:
        # Silence old StreamHandler
        handler = get_handler_by_name("terminal")
        if handler:
            handler.setLevel(logging.CRITICAL)
        # Set file logger level
        self.log.setLevel(level=logging.INFO)
        # Connect logger with sc
        sc.default_file_logger = self.log

    def __call__(self, args: argparse.Namespace) -> None:
        # Setup logging
        self.setup_file_logging()

        # Save command parameter (template branch)
        if hasattr(args, "template_branch"):
            if args.template_branch != "":
                self.template_branch = args.template_branch

        try:
            # Test if init is valid in current folder
            self.test_initialization()

            sc.echo(f"Starting to initialize HERMES in {self.folder_info.absolute_path}\n")
            sc.max_steps = 8

            sc.next_step("Configure HERMES plugins")
            self.choose_plugins()
            self.integrate_plugins()

            sc.next_step("Configure deposition platform and setup method")
            self.choose_deposit_platform()
            self.integrate_deposit_platform()
            self.choose_setup_method()

            sc.next_step("Configure HERMES behaviour")
            self.choose_push_branch()
            self.choose_deposit_files()

            sc.next_step("Create hermes.toml file")
            self.create_hermes_toml()

            sc.next_step("Create CITATION.cff file")
            self.create_citation_cff()

            sc.next_step("Create git CI files")
            self.update_gitignore()
            self.create_ci_template()

            sc.next_step("Connect with deposition platform")
            self.connect_deposit_platform()

            sc.next_step("Connect with git hoster")
            self.configure_git_project()

            self.clean_up_files(False)
            sc.echo("\nHERMES is now initialized and ready to be used.\n",
                    formatting=sc.Formats.OKGREEN+sc.Formats.BOLD)

        # Nice message on Ctrl+C
        except KeyboardInterrupt:
            sc.echo("")
            sc.echo("HERMES init was aborted.", sc.Formats.WARNING)
            self.clean_up_files(True)
            sys.exit()

        # Useful message on error
        except Exception as e:
            sc.echo(f"An error occurred during execution of HERMES init: {e}",
                    formatting=sc.Formats.FAIL+sc.Formats.BOLD)
            sc.debug_info(traceback.format_exc())
            self.clean_up_files(True)
            sys.exit(2)

    def test_initialization(self) -> None:
        """Test if init is possible and wanted. If not: sys.exit()"""
        sc.echo("Preparing HERMES initialization\n")

        # Abort if git is not installed
        if not git_info.is_git_installed():
            sc.echo("Git is currently not installed. It is recommended to use HERMES with git.",
                    formatting=sc.Formats.WARNING)
            self.no_git_setup()
            sys.exit()

        # Look at the current folder
        self.refresh_folder_info()
        self.hermes_was_already_installed = self.folder_info.has_hermes_toml

        # Abort if there is no git
        if not self.folder_info.has_git_folder:
            sc.echo("The current directory has no `.git` subdirectory. "
                    "Please execute `hermes init` in the root directory of your git project.",
                    formatting=sc.Formats.WARNING)
            self.no_git_setup()
            sys.exit()

        # Look at git remotes
        remotes = git_info.get_remotes()
        if remotes:
            self.git_remote = remotes[0]

        # Let the user choose if there are multiple remotes
        if len(remotes) > 1:
            remote_index = sc.choose(
                "Your git project has multiple remotes. For which remote do you want to setup HERMES?",
                [f"{remote} ({git_info.get_remote_url(remote)})" for remote in remotes]
            )
            self.git_remote = remotes[remote_index]

        # Get url & hoster from remote
        if self.git_remote:
            self.git_remote_url = git_info.get_remote_url(self.git_remote)
            self.git_hoster = get_git_hoster_from_url(self.git_remote_url)

        # Abort with no remote
        else:
            sc.echo("Your git project does not have a remote. It is recommended for HERMES to "
                    "use either GitHub or GitLab as hosting service.", formatting=sc.Formats.WARNING)
            self.no_git_setup()
            sys.exit()

        # Abort if neither GitHub nor gitlab is used
        if self.git_hoster == GitHoster.Empty:
            project_url = " (" + self.git_remote_url + ")" if self.git_remote_url else ""
            sc.echo("Your git project{} is not connected to GitHub or GitLab. It is recommended for HERMES to "
                    "use one of these hosting services.".format(project_url),
                    formatting=sc.Formats.WARNING)
            self.no_git_setup()
            sys.exit()
        else:
            sc.echo(f"Git project using {self.git_hoster.name} detected.\n")

        # Abort if there is already a hermes.toml
        if self.folder_info.has_hermes_toml:
            sc.echo("The current directory already has a `hermes.toml`. "
                    "It seems like HERMES was already initialized for this project.", formatting=sc.Formats.WARNING)
            if not sc.confirm("Do you want to initialize Hermes anyway? "
                              "(Hermes config files and related project variables will be overwritten.) "):
                sys.exit()

    def create_hermes_toml(self) -> None:
        """Creates the hermes.toml file based on a self.hermes_toml_data"""
        hermes_toml_path = Path("hermes.toml")
        self.mark_as_new_path(hermes_toml_path)
        if (not self.folder_info.has_hermes_toml) \
                or sc.confirm("Do you want to replace your `hermes.toml` with a new one?", default=True):
            with open(hermes_toml_path, 'w') as toml_file:
                # noinspection PyTypeChecker
                toml.dump(self.hermes_toml_data, toml_file)
            sc.echo("`hermes.toml` was created.", formatting=sc.Formats.OKGREEN)

    def create_citation_cff(self) -> None:
        """If there is no CITATION.cff, the user gets the opportunity to create one online."""
        if not self.folder_info.has_citation_cff:
            citation_cff_url = "https://citation-file-format.github.io/cff-initializer-javascript/#/"
            sc.echo("Your project does not contain a `CITATION.cff` file (yet). It would be very helpful for "
                    "saving important metadata which is necessary for publishing.")
            create_cff_now = sc.confirm("Do you want to create a `CITATION.cff` file now?", default=True)
            if create_cff_now:
                sc.echo("{} to create the file. Then move it into the project folder before you continue.".format(
                    sc.create_console_hyperlink(citation_cff_url, "Use this website")))
                sc.press_enter_to_continue()
                self.refresh_folder_info()
                if self.folder_info.has_citation_cff:
                    sc.echo("Good job!", formatting=sc.Formats.OKGREEN)
                else:
                    sc.echo("There is still no `CITATION.cff` file. Don't forget to add it later!",
                            formatting=sc.Formats.WARNING)
            else:
                sc.echo("You better do it later or HERMES won't work properly.")
                sc.echo("You can {} to create the file. Then move it into the project folder.".format(
                    sc.create_console_hyperlink(citation_cff_url, "use this website")))
        else:
            sc.echo("Your project already contains a `CITATION.cff` file. Nice!", formatting=sc.Formats.OKGREEN)

    def update_gitignore(self) -> None:
        """Creates .gitignore if there is none and adds '.hermes' to it"""
        gitignore_path = Path(".gitignore")
        self.mark_as_new_path(gitignore_path)
        if not self.folder_info.has_gitignore:
            open(gitignore_path, 'w')
            sc.echo("A new `.gitignore` file was created.", formatting=sc.Formats.OKGREEN)
        self.refresh_folder_info()
        if self.folder_info.has_gitignore:
            with open(gitignore_path, "r") as file:
                gitignore_lines = file.readlines()
            if any([line.startswith(".hermes") for line in gitignore_lines]):
                sc.echo("The `.gitignore` file already contains `.hermes/`")
            else:
                with open(gitignore_path, "a") as file:
                    file.write("# Ignoring all HERMES cache files\n")
                    file.write(".hermes/\n")
                    file.write("hermes.log\n")
                sc.echo("Added `.hermes/` to the `.gitignore` file.", formatting=sc.Formats.OKGREEN)

    def get_template_url(self, filename: str) -> str:
        """Returns the full template url with a given filename."""
        return (f"{self.template_base_url}/{self.template_repo}/refs/heads/"
                f"{self.template_branch}/{self.template_folder}/{filename}")

    def create_ci_template(self) -> None:
        """Downloads and configures the ci workflow files using templates from the chosen template branch."""
        match self.git_hoster:
            case GitHoster.GitHub:
                template_url = self.get_template_url("TEMPLATE_hermes_github_to_zenodo.yml")
                ci_file_folder = Path(".github/workflows")
                ci_file_name = "hermes_github.yml"
                ci_file_path = ci_file_folder / ci_file_name
                # Adding paths to our list
                self.mark_as_new_path(Path(".github"))
                self.mark_as_new_path(ci_file_folder)
                self.mark_as_new_path(ci_file_path)
                # Creating folder & ci file
                ci_file_folder.mkdir(parents=True, exist_ok=True)
                download_file_from_url(template_url, ci_file_path)
                self.configure_ci_template(ci_file_path)
                sc.echo(f"GitHub CI: File was created at {ci_file_path}", formatting=sc.Formats.OKGREEN)
            case GitHoster.GitLab:
                gitlab_ci_template_url = self.get_template_url("TEMPLATE_hermes_gitlab_to_zenodo.yml")
                hermes_ci_template_url = self.get_template_url("hermes-ci.yml")
                gitlab_ci_path = Path(".gitlab-ci.yml")
                gitlab_folder_path = Path("gitlab")
                hermes_ci_path = gitlab_folder_path / "hermes-ci.yml"
                # Adding paths to our list
                self.mark_as_new_path(gitlab_ci_path)
                self.mark_as_new_path(gitlab_folder_path)
                self.mark_as_new_path(hermes_ci_path)
                # Creating the gitlab folder
                gitlab_folder_path.mkdir(parents=True, exist_ok=True)
                # Creating / updating gitlab-ci
                if gitlab_ci_path.exists():
                    if string_in_file(gitlab_ci_path, "hermes-ci.yml"):
                        sc.echo(f"It seems like your {gitlab_ci_path} file is already configured for hermes.")
                    else:
                        download_file_from_url(gitlab_ci_template_url, gitlab_ci_path, append=True)
                        sc.echo(f"GitLab CI: {gitlab_ci_path} was updated.", formatting=sc.Formats.OKGREEN)
                else:
                    download_file_from_url(gitlab_ci_template_url, gitlab_ci_path)
                    sc.echo(f"GitLab CI: {gitlab_ci_path} was created.", formatting=sc.Formats.OKGREEN)
                self.configure_ci_template(gitlab_ci_path)
                # Creating hermes-ci
                download_file_from_url(hermes_ci_template_url, hermes_ci_path)
                self.configure_ci_template(hermes_ci_path)

                # When using gitlab.com we need to use gitlab-org-docker as tag
                if "gitlab.com" in self.git_remote_url:
                    with open(hermes_ci_path, 'r') as file:
                        content = file.read()
                    new_content = re.sub(r'(tags:\n\s+- )docker', r'\1gitlab-org-docker', content)
                    with open(hermes_ci_path, 'w') as file:
                        file.write(new_content)

                sc.echo(f"GitLab CI: {hermes_ci_path} was created.", formatting=sc.Formats.OKGREEN)

    def configure_ci_template(self, ci_file_path) -> None:
        """Replaces all {%parameter%} in a ci file with values from ci_parameters dict"""
        with open(ci_file_path, 'r') as file:
            content = file.read()
        parameters = list(set(re.findall(r'{%(.*?)%}', content)))
        for parameter in parameters:
            if parameter in self.ci_parameters:
                value = str(self.ci_parameters[parameter])
                content = content.replace(f'{{%{parameter}%}}', value)
            else:
                sc.debug_info(f"CI File Parameter {{%{parameter}%}} was not set.", formatting=sc.Formats.WARNING)
                content = content.replace(f'{{%{parameter}%}}', '')
        with open(ci_file_path, 'w') as file:
            file.write(content)

    def create_zenodo_token(self) -> None:
        """Makes the user create a zenodo token and saves it in self.tokens."""
        self.tokens[self.deposit_platform] = ""
        # Deactivated Zenodo OAuth as long as the refresh token bug is not fixed.
        if self.setup_method == "a":
            sc.echo("Doing OAuth with Zenodo is currently not available.")
        if self.setup_method == "m" or self.tokens[self.deposit_platform] == '':
            zenodo_token_url = urljoin(DepositPlatformUrls[self.deposit_platform],
                                       "account/settings/applications/tokens/new/")
            sc.echo("{} and create an access token.".format(
                sc.create_console_hyperlink(zenodo_token_url, "Open this link")
            ))
            sc.echo("It needs the scopes \"deposit:actions\" and \"deposit:write\".")
            if self.setup_method == "m":
                sc.press_enter_to_continue()
            else:
                while True:
                    self.tokens[self.deposit_platform] = sc.answer("Enter the token here: ")
                    valid = connect_zenodo.test_if_token_is_valid(self.tokens[self.deposit_platform])
                    if valid:
                        sc.echo(f"The token was validated by {connect_zenodo.name}.",
                                formatting=sc.Formats.OKGREEN)
                        break
                    else:
                        sc.echo(f"The token could not be validated by {connect_zenodo.name}. "
                                "Make sure to enter the complete token.\n"
                                "(If this error persists, you should try switching to the manual setup mode.)",
                                formatting=sc.Formats.WARNING)

    def configure_git_project(self) -> None:
        """Adds the token to the git secrets & changes action workflow settings."""
        match self.git_hoster:
            case GitHoster.GitHub:
                self.configure_github()
            case GitHoster.GitLab:
                self.configure_gitlab()

    def configure_github(self) -> None:
        oauth_success = False
        if self.setup_method == "a":
            self.tokens[GitHoster.GitHub] = connect_github.get_access_token()
            if self.tokens[GitHoster.GitHub]:
                sc.echo("OAuth at GitHub was successful.", formatting=sc.Formats.OKGREEN)
                sc.debug_info(github_token=self.tokens[GitHoster.GitHub])
                connect_github.create_secret(self.git_remote_url, "ZENODO_SANDBOX",
                                             secret_value=self.tokens[self.deposit_platform],
                                             token=self.tokens[GitHoster.GitHub])
                connect_github.allow_actions(self.git_remote_url,
                                             token=self.tokens[GitHoster.GitHub])
                oauth_success = True
            else:
                sc.echo("Something went wrong while doing OAuth. You'll have to do it manually instead.",
                        formatting=sc.Formats.WARNING)
        if not oauth_success:
            sc.echo("Add the {} token{} to your {} under the name ZENODO_SANDBOX.".format(
                self.deposit_platform.name,
                f" ({self.tokens[self.deposit_platform]})" if self.tokens[self.deposit_platform] else "",
                sc.create_console_hyperlink(
                    self.git_remote_url + "/settings/secrets/actions",
                    "project's GitHub secrets"
                )
            ))
            sc.press_enter_to_continue()
            sc.echo("Next open your {} and check the checkbox which reads:".format(
                sc.create_console_hyperlink(
                    self.git_remote_url + "/settings/actions", "project settings"
                )
            ))
            sc.echo("Allow GitHub Actions to create and approve pull requests")
            sc.press_enter_to_continue()

    def configure_gitlab(self) -> None:
        # Doing it with API / OAuth
        oauth_success = False
        if self.setup_method == "a":
            gl = connect_gitlab.GitLabConnection(self.git_remote_url)
            token = ""
            if not gl.has_client():
                sc.echo("Unfortunately HERMES does not support automatic authorization with your GitLab "
                        "installment.")
                sc.echo("Go to your {} and create a new token.".format(
                    sc.create_console_hyperlink(
                        self.git_remote_url + "/-/settings/access_tokens",
                        "project's access tokens")
                ))
                sc.echo("It needs to have the 'developer' role and 'api' + 'write_repository' scope.")
                token = sc.answer("Then paste the token here: ")
            if gl.authorize(token):
                vars_created = gl.create_variable(
                    "ZENODO_TOKEN", self.tokens[self.deposit_platform],
                    f"This token is used by Hermes to publish on {self.deposit_platform.name}."
                )
                if vars_created:
                    project_token = gl.create_project_access_token("hermes_token")
                    if project_token:
                        vars_created = gl.create_variable(
                            "HERMES_PUSH_TOKEN", project_token,
                            "This token is used by Hermes to create pull requests."
                        )
                    else:
                        vars_created = False
                oauth_success = vars_created
            if not oauth_success:
                sc.echo("Something went wrong while setting up GitLab automatically.", formatting=sc.Formats.WARNING)
                sc.echo("You will have to do it manually instead.", formatting=sc.Formats.WARNING)

        # Doing it without API
        if not oauth_success:
            sc.echo("Go to your {} and create a new token.".format(
                sc.create_console_hyperlink(
                    self.git_remote_url + "/-/settings/access_tokens", "project's access tokens")
            ))
            sc.echo("It needs to have the 'developer' role and 'write_repository' scope.")
            sc.press_enter_to_continue()
            sc.echo("Open your {} and go to 'Variables'".format(
                sc.create_console_hyperlink(
                    self.git_remote_url + "/-/settings/ci_cd", "project's ci settings")
            ))
            sc.echo("Then, add that token as variable with key HERMES_PUSH_TOKEN.")
            sc.echo("(For your safety, you should set the visibility to 'Masked'.)")
            sc.press_enter_to_continue()
            sc.echo("Next, add the {} token{} as variable with key ZENODO_TOKEN.".format(
                self.deposit_platform.name,
                f" ({self.tokens[self.deposit_platform]})" if self.tokens[self.deposit_platform] else ""
            ))
            sc.echo("(For your safety, you should set the visibility to 'Masked'.)")
            sc.press_enter_to_continue()

    def choose_deposit_platform(self) -> None:
        """User chooses his desired deposit platform."""
        deposit_platform_list = list(DepositPlatformNames.keys())
        deposit_platform_index = sc.choose(
            "Where do you want to publish the software?", [DepositPlatformNames[dp] for dp in deposit_platform_list]
        )
        self.deposit_platform = deposit_platform_list[deposit_platform_index]

    def integrate_deposit_platform(self) -> None:
        """Makes changes to the toml data or something else based on the chosen deposit platform."""
        deposit_url = DepositPlatformUrls.get(self.deposit_platform)
        self.hermes_toml_data["deposit"]["invenio_rdm"]["site_url"] = deposit_url

    def choose_setup_method(self) -> None:
        """User chooses his desired setup method: Either preferring automatic (if available) or manual."""
        setup_method_index = sc.choose(
            f"How do you want to connect {DepositPlatformNames[self.deposit_platform]} "
            f"with your {self.git_hoster.name} CI?",
            options=[
                "Automatically (using OAuth / Device Flow)",
                "Manually (with instructions)",
            ]
        )
        self.setup_method = ["a", "m"][setup_method_index]

    def connect_deposit_platform(self) -> None:
        """Acquires the access token of the chosen deposit platform."""
        assert self.deposit_platform != DepositPlatform.Empty
        match self.deposit_platform:
            case DepositPlatform.Zenodo:
                connect_zenodo.setup(using_sandbox=False)
                self.create_zenodo_token()
            case DepositPlatform.ZenodoSandbox:
                connect_zenodo.setup(using_sandbox=True)
                self.create_zenodo_token()

    def choose_plugins(self) -> None:
        """User chooses the plugins he wants to use."""
        plugin_infos: list[marketplace.PluginInfo] = marketplace.get_plugin_infos()
        plugins_builtin: list[marketplace.PluginInfo] = list(filter(lambda p: p.builtin, plugin_infos))
        plugins_available: list[marketplace.PluginInfo] = list(filter(lambda p: not p.builtin, plugin_infos))
        plugins_selected: list[marketplace.PluginInfo] = []
        sc.echo("The following plugins are already builtin:")
        for info in plugins_builtin:
            sc.echo(str(info), formatting=sc.Formats.OKGREEN)
        sc.echo("")
        while True:
            if plugins_selected:
                sc.echo("The following plugins are going to be installed:")
                for info in plugins_selected:
                    sc.echo(str(info), formatting=sc.Formats.OKCYAN)
                sc.echo("")
            if plugins_available:
                sc.echo("The following plugins are available for installation:")
                for info in plugins_available:
                    sc.echo(str(info), formatting=sc.Formats.WARNING, no_log=True)
                    if info.abstract:
                        sc.echo("-> " + info.abstract, formatting=sc.Formats.ITALIC+sc.Formats.WARNING, no_log=True)
                sc.echo("")
            else:
                self.selected_plugins = plugins_selected
                break
            no_text = "No further plugins needed"
            choice = sc.choose("Do you want to add a plugin?",
                               [no_text] + [f"Add {p.name}" for p in plugins_available])
            if choice == 0:
                self.selected_plugins = plugins_selected
                break
            else:
                chosen_plugin = plugins_available.pop(choice - 1)
                plugins_selected.append(chosen_plugin)

    def integrate_plugins(self) -> None:
        """
        Plugin installation is added to the ci-parameters.
        Also for now we use this method to do custom plugin installation steps.
        """
        for plugin_info in self.selected_plugins:
            if not plugin_info.is_valid():
                sc.echo(f"Could not install plugin: {plugin_info.name}", formatting=sc.Formats.FAIL)
                continue
            pip_install = plugin_info.get_pip_install_command()
            self.ci_parameters["pip_install_plugins_github"] = \
                self.ci_parameters.get("pip_install_plugins_github", "") + "      - run: " + pip_install + "\n"
            self.ci_parameters["pip_install_plugins_gitlab"] = \
                self.ci_parameters.get("pip_install_plugins_gitlab", "") + "    - " + pip_install + "\n"
            match plugin_info.name:
                case "hermes-plugin-python":
                    self.hermes_toml_data["harvest"]["sources"].append("toml")
                case "hermes-plugin-git":
                    self.hermes_toml_data["harvest"]["sources"].append("git")

    def no_git_setup(self, start_question: str = "") -> None:
        """Makes the init for a gitless project (basically just creating hermes.toml)"""
        if start_question == "":
            start_question = ("Do you want to initialize HERMES anyways? (CI/CD files for automated publishing will "
                              "NOT be created)")
        if sc.confirm(start_question):
            sc.max_steps = 2

            sc.next_step("Create hermes.toml file")
            self.create_hermes_toml()

            sc.next_step("Create CITATION.cff file")
            self.create_citation_cff()

            self.clean_up_files(False)
            sc.echo("\nHERMES is now initialized (without git integration or CI/CD files).\n",
                    formatting=sc.Formats.OKGREEN)

    def choose_push_branch(self) -> None:
        """User chooses the branch that should be used to activate the whole hermes process."""
        push_choice = sc.choose(
            "When should the automated HERMES process start?",
            [
                "When I push a branch",
                "When I push a specific tag (not implemented)",
            ]
        )
        if push_choice == 0:
            branch = sc.answer("Enter target branch: ")
            self.ci_parameters["push_branch"] = branch
            sc.echo(f"The HERMES pipeline will be activated when you push on {sc.Formats.BOLD.wrap_around(branch)}",
                    formatting=sc.Formats.OKGREEN)
            sc.echo()
        elif push_choice == 1:
            sc.echo("Setting up triggering by tags is currently not implemented.", formatting=sc.Formats.WARNING)
            sc.echo(f"You can visit {TUTORIAL_URL} to set it up manually later-on.", formatting=sc.Formats.WARNING)

    def choose_deposit_files(self) -> None:
        """User chooses the files that should be included in the deposition."""
        dp_name = DepositPlatformNames[self.deposit_platform]
        add_readme = False
        if self.folder_info.has_readme:
            if sc.confirm(f"Do you want to append your README.md to the {dp_name} upload?"):
                self.ci_parameters["deposit_extra_files"] = "--file README.md "
                add_readme = True
        options = [
            "All (non hidden) folders",
            "Everything (all folders & all files)",
            "Enter a custom list of paths",
        ]
        folder_base_index: int = len(options)
        for folder in self.folder_info.dir_folders:
            options.append(f"Only {folder}/*")
        _other = ' other' if add_readme else ''
        file_choice = sc.choose(f"Which{_other} folders / files of your root directory "
                                f"should be included in the {dp_name} upload?", options=options)
        match file_choice:
            case 0:
                self.ci_parameters["deposit_zip_files"] = " ".join(self.folder_info.dir_folders)
            case 1:
                self.ci_parameters["deposit_zip_files"] = ""
            case 2:
                custom_files = []
                while True:
                    custom_path = sc.answer("Enter a path you want to include (enter nothing if you are done): ")
                    if custom_path == "":
                        break
                    if os.path.exists(os.path.join(self.folder_info.current_dir, custom_path)):
                        custom_files.append(custom_path)
                        sc.echo(f"{custom_path} has been added.", formatting=sc.Formats.OKGREEN)
                    else:
                        sc.echo(f"{custom_path} does not exist.", formatting=sc.Formats.FAIL)
                self.ci_parameters["deposit_zip_files"] = " ".join(custom_files)
            case _:
                index = int(file_choice) - folder_base_index
                if 0 <= index < len(self.folder_info.dir_folders):
                    self.ci_parameters["deposit_zip_files"] = self.folder_info.dir_folders[index]
        sc.echo("Your upload will consist of the following:")
        if add_readme:
            sc.echo("\tUnzipped:", formatting=sc.Formats.BOLD)
            sc.echo("\t\tREADME.md", formatting=sc.Formats.OKCYAN)
        sc.echo("\tZipped:", formatting=sc.Formats.BOLD)
        if self.ci_parameters["deposit_zip_files"] != "":
            for file in self.ci_parameters["deposit_zip_files"].split(" "):
                sc.echo(f"\t\t{file}", formatting=sc.Formats.OKCYAN)
        else:
            for file in self.folder_info.dir_list:
                sc.echo(f"\t\t{file}", formatting=sc.Formats.OKCYAN)

    def mark_as_new_path(self, path: Path, avoid_existing: bool = True) -> None:
        """
        This method should be called directly BEFORE creating a new file in the given Path.
        This way we can look if something already exists there to decide later-on if we want to delete it on abort.
        """
        if (not avoid_existing) or (not path.exists()):
            self.new_created_paths.append(path)

    def clean_up_files(self, aborted: bool) -> None:
        """
        This gets called when init is finished (successfully or aborted).
        It cleans up unwanted files (like .hermes folder) and everything new when aborted.
        """
        sc.echo("Cleaning unused files...")
        hidden_hermes_path = Path(".hermes")
        if hidden_hermes_path.exists() and hidden_hermes_path.is_dir():
            shutil.rmtree(hidden_hermes_path)
        if aborted:
            if not self.hermes_was_already_installed:
                for path in reversed(self.new_created_paths):
                    try:
                        if path.is_dir():
                            path.rmdir()
                        else:
                            os.remove(path)
                    except Exception as e:
                        sc.echo(f"Cleaning Warning: Could not remove {path}. ({e})")
