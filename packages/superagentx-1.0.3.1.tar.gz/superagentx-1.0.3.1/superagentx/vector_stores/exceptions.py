class InvalidUrl(Exception):
    pass
