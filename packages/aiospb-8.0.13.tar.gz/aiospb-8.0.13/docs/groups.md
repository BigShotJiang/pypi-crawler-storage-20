# Node groups

It's a runnable class, where the node app can be executed. It can contains one or more nodes. Very easy class. You inject the nodes inside the class and the it can be run with run() method.

# Device factories

They are the main responsible of generate the nodes.
