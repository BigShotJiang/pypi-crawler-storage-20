from unittest.mock import MagicMock

import pytest

from aiospb.bootstrap import MetricsNetwork, new_edge_of_node, new_host
from aiospb.infra.paho import MQTTConfig
from aiospb.shared import DeviceKey, HostOptions, NodeOptions


def test_node_edge_creation():
    mock = MagicMock(spec=MetricsNetwork)
    mock.get_device_keys.return_value = [
        DeviceKey("group/node"),
        DeviceKey("group/node/device"),
    ]
    assert new_edge_of_node(
        "node/group",
        MQTTConfig("localhost", 1883),
        NodeOptions(),
        mock,
    )


def test_correct_edge_key():
    mock = MagicMock(spec=MetricsNetwork)
    for key in ("hostame", "group/node/device"):
        with pytest.raises(ValueError):
            new_edge_of_node(
                key,
                MQTTConfig("localhost", 1883),
                NodeOptions(),
                mock,
            )


def test_host_creation():
    assert new_host("hostname", MQTTConfig("localhost", 1883), HostOptions())


def test_correct_host_key():
    for key in ("group/node", "group/node/device"):
        with pytest.raises(ValueError):
            new_host(key, MQTTConfig("localhost", 1883), HostOptions())
