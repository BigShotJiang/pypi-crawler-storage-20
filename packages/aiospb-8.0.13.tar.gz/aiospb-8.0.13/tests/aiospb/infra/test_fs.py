from aiospb.infra.fs import FSHistorian, Historian
from tempfile import TemporaryDirectory

import tests.aiospb.infra.stores as s


class A_FSHistorian(s.A_Historian):
    def get_implementation(self) -> Historian:
        return FSHistorian(self._dirpath)

    def setup_method(self, _):
        self._dir = TemporaryDirectory()
        self._dirpath = self._dir.__enter__()

    def teardown_method(self, _):
        self._dir.__exit__(None, None, None)

    async def should_persist_metric_history_from_a_device(self):
        return await self._should_persist_metric_history_from_a_device()
