from aiospb.infra.encoding.json import JsonPayloadEncoder, Payload
from aiospb.shared import DataType, Metric


class A_JsonPayloadEncoder:
    def should_encode_host_payload(self):
        encoder = JsonPayloadEncoder()
        payload = Payload(timestamp=1000, online=False)
        assert encoder.decode(encoder.encode(payload)) == payload

    def should_encode_node_payload(self):
        encoder = JsonPayloadEncoder()
        payload = Payload(
            timestamp=1000,
            metrics=[Metric(900, 1, DataType.Int16, name="my/metric")],
            seq=1,
        )
        assert encoder.decode(encoder.encode(payload)) == payload
