from aiospb.hosts.commands import MinMetricInfoCache
from aiospb.infra.inmem import (
    InMemHistorian,
    Historian,
    InMemMinMetricInfoCache,
    InMemReadingStore,
    ReadingStore,
)
from .stores import A_Historian, A_ReadingStore, A_MinMetricInfoCache


class A_InMemHistorian(A_Historian):
    def get_implementation(self) -> Historian:
        return InMemHistorian()

    async def should_persist_metric_history_from_a_device(self):
        return await self._should_persist_metric_history_from_a_device()


class A_InmemReadingStore(A_ReadingStore):
    def get_implementation(self) -> ReadingStore:
        return InMemReadingStore()

    async def should_persist_readings(self):
        return await self._should_persist_readings()


class A_InmemMinMetricInfoCache(A_MinMetricInfoCache):
    def get_implementation(self) -> MinMetricInfoCache:
        return InMemMinMetricInfoCache()

    async def should_persist_min_metric_info(self):
        return await self._should_persist_min_metric_info()
