"""
Very quick acceptance test of the main products of the library, Host and EdgeNode
Only happy path, sad paths are in unit tests

Infrastructures are InMemory implementations for quick feedback
"""
