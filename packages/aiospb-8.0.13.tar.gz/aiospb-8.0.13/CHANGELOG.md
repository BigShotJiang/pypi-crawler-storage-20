## v8.0.13 (2026-01-15)

### Fix

- increase speed reading history

## v8.0.12 (2025-11-06)

### Fix

- proper remove of bdSeq metric

## v8.0.11 (2025-10-28)

### Fix

- infinite loop if ticker waiting <0

## v8.0.10 (2025-10-17)

### Fix

- host notify offline edge

## v8.0.9 (2025-10-17)

### Fix

-  incorrect process of bq_seq in host

## v8.0.8 (2025-10-15)

### Fix

- avoid follow control commands from host

## v8.0.7 (2025-10-08)

### Fix

- historian ommit wrong lines

## v8.0.6 (2025-10-07)

### Fix

- retray dont await establish

## v8.0.5 (2025-10-07)

### Fix

- if writing is bad, scan doesnt know
- establish session from several tasks

## v8.0.4 (2025-10-06)

### Fix

- convert float string to integer
- add skip cicd to repeat main

## v8.0.3 (2025-10-06)

### Fix

- assert MQTTClient is disconnected when error
- add retry on sub

## v8.0.2 (2025-10-01)

### Fix

- disconnect when session error

## v8.0.1 (2025-09-29)

### Fix

=======
## v8.0.1 (2025-10-05)

### Fix

- assert MQTTClient is disconnected when error
- add retry on sub
>>>>>>> 27d073fe168c9fdde82d87ec5d969d3768542f46
- add some loggings
- failure into end2end test
- fix ip of container test
- run merge without test faile

## v8.0.0 (2025-09-23)

### Feat

- stale scanning if DeviceConnectionIsBroken
- connect and disconnect devices when rise and die
- stop scan when scan rate is 0
- inject full mqtt config
- parse node messages with protobuf
- include timeout to write metrics command
- create metric from dict
- add mqtt config
- send writings from host
- change scan rate in scanner

### Fix

- unable TLS at docker
- some mistakes in acceptance test
- write scan rate if possible
- continue recieving message even with message error
- break host by publishing error
- retry several time before break connection
- host app breaks when send message
- lack of write confirmation if no quality
- incorrect rebirth command process as node
- ammend wrong init when death
- ammend wrong init when death
- adjust to correct value type protobuf
- add uint types to protobuf
- dont pass to disconnected state
- add try to publish 3 times
- add timeout to publish
- node can not reconnect if mqtterror
- infinite loop when birth
- rebirth when to reporting
- stop properly scanner
- null values are sent
- convert signed integer to protobuf
- call scan metric by name
- scan metrics even without alias
- stop incomming at node if writing error
- log all main tasks against exceptions
- listen before send state online
- listen first and then establish
- stop host listening if observer exc
- port is converted to int
- incorrect logging of timestamp
- send metric writing with only alias
- send metric writing with only alias
- send topic instead of str
- send will messages with wrong topic
- incorrect loading of historical
- send topic in message
- correct scanning rate in node

### Refactor

- nodes behaviour to MessageSession
- all external dependencies to infra module
- scanning
- node only send messages
- edge of nodes
- NodeSubscriber & HostSubscriber
- simplify publishers
- all publishing in one module
- create NodeCourier
- unify name data_type in metrics
- increase information of commands
- simplify scanning
- move responsability of mqtt to carrier
- simplify states
- create paho mqtt from dict
- complete change of interfacings
- remove excess of dataclasses
- remove reason from mqtt disconnect
- reduce node states to three
- publish is a method of MessageContent
- change nodes inner
- unify all in ms
- unify all in ms
- improve message structures
- change in definition of device driver
- change device_factory to node_factory
