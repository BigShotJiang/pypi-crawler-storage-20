"""
Django-Flex Core Query Engine

The main query execution engine that ties together field parsing,
filter building, and permission checking.

Provides:
- FlexQuery class for OOP-style queries
- execute_query function for procedural usage
"""

from django.apps import apps

from django_flex.conf import flex_settings
from django_flex.fields import parse_fields, expand_fields, extract_relations, get_json_fields
from django_flex.filters import build_q_object, extract_filter_keys
from django_flex.permissions import (
    check_permission,
    check_filter_permission,
    check_order_permission,
)
from django_flex.response import FlexResponse, build_nested_response


def get_model_by_name(model_name):
    """
    Get Django model class by name (case-insensitive).

    Searches all installed apps for a matching model.

    Args:
        model_name: Model name to find (case-insensitive, singular)

    Returns:
        Model class or None if not found
    """
    for app_config in apps.get_app_configs():
        for model in app_config.get_models():
            if model.__name__.lower() == model_name.lower():
                return model
    return None


class FlexQuery:
    """
    Flexible query builder for Django models.

    Provides a fluent interface for building and executing queries
    with field selection, filtering, and pagination.

    Example:
        # Direct usage
        result = FlexQuery(Booking).execute({
            'fields': 'id, customer.name, status',
            'filters': {'status': 'confirmed'},
            'limit': 20,
        }, user=request.user)

        # With model name
        result = FlexQuery('booking').execute({...}, user=request.user)

        # Chained configuration
        query = FlexQuery(Booking)
        query.set_user(request.user)
        query.set_permissions(custom_permissions)
        result = query.execute({...})
    """

    def __init__(self, model):
        """
        Initialize a FlexQuery.

        Args:
            model: Django model class or model name string
        """
        if isinstance(model, str):
            self.model_name = model.lower()
            self.model = get_model_by_name(model)
        else:
            self.model = model
            self.model_name = model.__name__.lower()

        self.user = None
        self.permissions = None

    def set_user(self, user):
        """Set the user for permission checking."""
        self.user = user
        return self

    def set_permissions(self, permissions):
        """Set custom permissions configuration."""
        self.permissions = permissions
        return self

    def execute(self, query_spec, user=None, action=None):
        """
        Execute a query with the given specification.

        Args:
            query_spec: Dict with query parameters (fields, filters, etc.)
            user: Optional user (overrides set_user)
            action: Optional action override (defaults to 'get' for id, 'query' for no id)

        Returns:
            FlexResponse with query results
        """
        user = user or self.user
        permissions = self.permissions

        if self.model is None:
            return FlexResponse.error("MODEL_NOT_FOUND")

        # Determine action
        if action:
            pass
        elif "id" in query_spec:
            action = "get"
        else:
            action = "query"

        if action == "get":
            return self._execute_get(query_spec, user, permissions)
        else:
            return self._execute_query(query_spec, user, permissions)

    def _execute_get(self, query_spec, user, permissions):
        """Execute single object retrieval."""
        # Parse fields
        field_specs = parse_fields(query_spec.get("fields", "*"))
        expanded_fields = expand_fields(self.model, field_specs, permissions=permissions)

        # Check permissions
        try:
            if user:
                row_filter, validated_fields = check_permission(user, self.model_name, "get", expanded_fields, permissions)
            else:
                row_filter = None
                validated_fields = expanded_fields
        except PermissionError as e:
            return FlexResponse.error("PERMISSION_DENIED", str(e))

        # Extract relations for select_related (avoid N+1)
        relations = extract_relations(validated_fields)

        # Build queryset
        try:
            queryset = self.model.objects.all()
            if row_filter:
                queryset = queryset.filter(row_filter)
            if relations:
                queryset = queryset.select_related(*relations)
            obj = queryset.get(pk=query_spec["id"])
        except self.model.DoesNotExist:
            return FlexResponse.error("NOT_FOUND")

        # Build response
        json_fields = set(get_json_fields(self.model))
        response_data = build_nested_response(obj, validated_fields, json_fields)
        return FlexResponse.ok(**response_data)

    def _execute_query(self, query_spec, user, permissions):
        """Execute paginated query retrieval."""
        # Parse fields
        field_specs = parse_fields(query_spec.get("fields", "*"))
        expanded_fields = expand_fields(self.model, field_specs, permissions=permissions)

        # Check permissions
        try:
            if user:
                row_filter, validated_fields = check_permission(user, self.model_name, "query", expanded_fields, permissions)
            else:
                row_filter = None
                validated_fields = expanded_fields
        except PermissionError as e:
            return FlexResponse.error("PERMISSION_DENIED", str(e))

        # Validate filter keys
        filters = query_spec.get("filters", {})
        try:
            if user:
                filter_keys = extract_filter_keys(filters)
                check_filter_permission(user, self.model_name, filter_keys, permissions)
        except PermissionError as e:
            return FlexResponse.error("PERMISSION_DENIED", str(e))

        # Validate order_by
        order_by = query_spec.get("order_by")
        try:
            if user:
                check_order_permission(user, self.model_name, order_by, permissions)
        except PermissionError as e:
            return FlexResponse.error("PERMISSION_DENIED", str(e))

        # Extract relations for select_related
        relations = extract_relations(validated_fields)

        # Build query
        user_filter = build_q_object(filters)
        queryset = self.model.objects.all()
        if row_filter:
            queryset = queryset.filter(row_filter & user_filter)
        else:
            queryset = queryset.filter(user_filter)

        # Apply select_related
        if relations:
            queryset = queryset.select_related(*relations)

        # Ordering
        if order_by:
            order_by_django = order_by.replace(".", "__")
            queryset = queryset.order_by(order_by_django)

        # Pagination with limit clamping
        requested_limit = query_spec.get("limit", flex_settings.DEFAULT_LIMIT)
        max_limit = flex_settings.MAX_LIMIT
        limit = min(requested_limit, max_limit)
        limit_clamped = requested_limit > max_limit
        offset = query_spec.get("offset", 0)

        # Fetch limit + 1 to check for more results (avoids expensive COUNT query)
        paginated = list(queryset[offset : offset + limit + 1])

        # Determine if there are more results
        has_more = len(paginated) > limit
        if has_more:
            paginated = paginated[:limit]  # Drop the extra row

        # Build results dict keyed by id
        json_fields = set(get_json_fields(self.model))
        results = {}
        for obj in paginated:
            obj_data = build_nested_response(obj, validated_fields, json_fields)
            results[str(obj.pk)] = obj_data

        # Build pagination info
        pagination = {
            "offset": offset,
            "limit": limit,
            "has_more": has_more,
        }

        # Build next cursor if more results exist
        if has_more:
            pagination["next"] = {
                "fields": query_spec.get("fields", "*"),
                "filters": filters,
                "limit": limit,
                "offset": offset + limit,
            }
            if order_by:
                pagination["next"]["order_by"] = order_by

        # Return warning if limit was clamped
        if limit_clamped:
            return FlexResponse.warning_response(
                "LIMIT_CLAMPED",
                results=results,
                pagination=pagination,
                requested_limit=requested_limit,
            )

        return FlexResponse.ok_query(results=results, pagination=pagination)


def execute_query(model, query_spec, user=None, permissions=None):
    """
    Execute a flexible query on a model.

    Convenience function that wraps FlexQuery.

    Args:
        model: Django model class or model name string
        query_spec: Dict with query parameters
        user: Optional user for permission checking
        permissions: Optional custom permissions

    Returns:
        FlexResponse with query results

    Example:
        result = execute_query(Booking, {
            'fields': 'id, customer.name',
            'filters': {'status': 'confirmed'},
            'limit': 20,
        }, user=request.user)
    """
    query = FlexQuery(model)
    if permissions:
        query.set_permissions(permissions)
    return query.execute(query_spec, user=user)
