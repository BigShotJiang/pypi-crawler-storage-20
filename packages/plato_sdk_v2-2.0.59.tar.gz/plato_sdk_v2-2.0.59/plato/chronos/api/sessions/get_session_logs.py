"""Get Session Logs"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import SessionLogsResponse


def _build_request_args(
    public_id: str,
    limit: int | None = 100,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/sessions/{public_id}/logs"

    params: dict[str, Any] = {}
    if limit is not None:
        params["limit"] = limit

    return {
        "method": "GET",
        "url": url,
        "params": params,
    }


def sync(
    client: httpx.Client,
    public_id: str,
    limit: int | None = 100,
) -> SessionLogsResponse:
    """Get logs/events for a session."""

    request_args = _build_request_args(
        public_id=public_id,
        limit=limit,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return SessionLogsResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    public_id: str,
    limit: int | None = 100,
) -> SessionLogsResponse:
    """Get logs/events for a session."""

    request_args = _build_request_args(
        public_id=public_id,
        limit=limit,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return SessionLogsResponse.model_validate(response.json())
