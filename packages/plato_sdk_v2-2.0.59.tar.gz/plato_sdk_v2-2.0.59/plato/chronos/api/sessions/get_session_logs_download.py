"""Get Session Logs Download"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import LogsDownloadResponse


def _build_request_args(
    public_id: str,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/sessions/{public_id}/logs-download"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
    public_id: str,
) -> LogsDownloadResponse:
    """Get a presigned download URL for the session's zipped logs."""

    request_args = _build_request_args(
        public_id=public_id,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return LogsDownloadResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    public_id: str,
) -> LogsDownloadResponse:
    """Get a presigned download URL for the session's zipped logs."""

    request_args = _build_request_args(
        public_id=public_id,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return LogsDownloadResponse.model_validate(response.json())
