"""Test Runtime"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status


def _build_request_args(
    artifact_id: str,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/runtimes/{artifact_id}/test"

    return {
        "method": "POST",
        "url": url,
    }


def sync(
    client: httpx.Client,
    artifact_id: str,
) -> dict[str, Any]:
    """Test a runtime by starting a session from it.

    Creates a session from the runtime artifact, waits for it to be ready,
    then returns the session info. The session stays open for manual testing."""

    request_args = _build_request_args(
        artifact_id=artifact_id,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return response.json()


async def asyncio(
    client: httpx.AsyncClient,
    artifact_id: str,
) -> dict[str, Any]:
    """Test a runtime by starting a session from it.

    Creates a session from the runtime artifact, waits for it to be ready,
    then returns the session info. The session stays open for manual testing."""

    request_args = _build_request_args(
        artifact_id=artifact_id,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return response.json()
