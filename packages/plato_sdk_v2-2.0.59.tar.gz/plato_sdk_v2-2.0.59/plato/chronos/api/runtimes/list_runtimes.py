"""List Runtimes"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import RuntimeListResponse


def _build_request_args() -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/runtimes"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
) -> RuntimeListResponse:
    """List all runtimes for the org."""

    request_args = _build_request_args()

    response = client.request(**request_args)
    raise_for_status(response)
    return RuntimeListResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
) -> RuntimeListResponse:
    """List all runtimes for the org."""

    request_args = _build_request_args()

    response = await client.request(**request_args)
    raise_for_status(response)
    return RuntimeListResponse.model_validate(response.json())
