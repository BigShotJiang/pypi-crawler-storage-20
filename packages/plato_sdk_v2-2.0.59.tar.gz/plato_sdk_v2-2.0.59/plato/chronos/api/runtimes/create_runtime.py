"""Create Runtime"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import RuntimeCreate, RuntimeCreateResponse


def _build_request_args(
    body: RuntimeCreate,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/runtimes"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: RuntimeCreate,
) -> RuntimeCreateResponse:
    """Create a new runtime (starts background job to build)."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return RuntimeCreateResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: RuntimeCreate,
) -> RuntimeCreateResponse:
    """Create a new runtime (starts background job to build)."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return RuntimeCreateResponse.model_validate(response.json())
