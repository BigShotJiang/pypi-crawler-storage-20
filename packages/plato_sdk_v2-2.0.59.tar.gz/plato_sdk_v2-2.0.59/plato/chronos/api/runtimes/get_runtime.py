"""Get Runtime"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import RuntimeResponse


def _build_request_args(
    artifact_id: str,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/runtimes/{artifact_id}"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
    artifact_id: str,
) -> RuntimeResponse:
    """Get a runtime by artifact ID."""

    request_args = _build_request_args(
        artifact_id=artifact_id,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return RuntimeResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    artifact_id: str,
) -> RuntimeResponse:
    """Get a runtime by artifact ID."""

    request_args = _build_request_args(
        artifact_id=artifact_id,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return RuntimeResponse.model_validate(response.json())
