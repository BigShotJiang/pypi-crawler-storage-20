"""Get Secret"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import EnvSecretResponse


def _build_request_args(
    name: str,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/secrets/{name}"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
    name: str,
) -> EnvSecretResponse:
    """Get an environment secret by name."""

    request_args = _build_request_args(
        name=name,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return EnvSecretResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    name: str,
) -> EnvSecretResponse:
    """Get an environment secret by name."""

    request_args = _build_request_args(
        name=name,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return EnvSecretResponse.model_validate(response.json())
