"""Update Secret"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import EnvSecretResponse, EnvSecretUpdate


def _build_request_args(
    name: str,
    body: EnvSecretUpdate,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/secrets/{name}"

    return {
        "method": "PUT",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    name: str,
    body: EnvSecretUpdate,
) -> EnvSecretResponse:
    """Update an environment secret."""

    request_args = _build_request_args(
        name=name,
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return EnvSecretResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    name: str,
    body: EnvSecretUpdate,
) -> EnvSecretResponse:
    """Update an environment secret."""

    request_args = _build_request_args(
        name=name,
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return EnvSecretResponse.model_validate(response.json())
