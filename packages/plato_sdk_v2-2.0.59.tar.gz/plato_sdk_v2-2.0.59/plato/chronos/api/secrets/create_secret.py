"""Create Secret"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import EnvSecretCreate, EnvSecretResponse


def _build_request_args(
    body: EnvSecretCreate,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/secrets"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: EnvSecretCreate,
) -> EnvSecretResponse:
    """Create or update an environment secret."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return EnvSecretResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: EnvSecretCreate,
) -> EnvSecretResponse:
    """Create or update an environment secret."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return EnvSecretResponse.model_validate(response.json())
