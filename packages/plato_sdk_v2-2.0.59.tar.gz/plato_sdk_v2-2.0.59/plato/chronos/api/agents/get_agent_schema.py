"""Get Agent Schema"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import ChronosModelsAgentAgentSchemaResponse


def _build_request_args(
    name: str,
    version: str | None = None,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/agents/by-name/{name}/schema"

    params: dict[str, Any] = {}
    if version is not None:
        params["version"] = version

    return {
        "method": "GET",
        "url": url,
        "params": params,
    }


def sync(
    client: httpx.Client,
    name: str,
    version: str | None = None,
) -> ChronosModelsAgentAgentSchemaResponse:
    """Get agent schema by name and optional version."""

    request_args = _build_request_args(
        name=name,
        version=version,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return ChronosModelsAgentAgentSchemaResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    name: str,
    version: str | None = None,
) -> ChronosModelsAgentAgentSchemaResponse:
    """Get agent schema by name and optional version."""

    request_args = _build_request_args(
        name=name,
        version=version,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return ChronosModelsAgentAgentSchemaResponse.model_validate(response.json())
