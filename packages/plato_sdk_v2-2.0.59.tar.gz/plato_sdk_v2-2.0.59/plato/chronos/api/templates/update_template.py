"""Update Template"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import JobTemplateResponse, JobTemplateUpdate


def _build_request_args(
    public_id: str,
    body: JobTemplateUpdate,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/templates/{public_id}"

    return {
        "method": "PUT",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    public_id: str,
    body: JobTemplateUpdate,
) -> JobTemplateResponse:
    """Update a job template."""

    request_args = _build_request_args(
        public_id=public_id,
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return JobTemplateResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    public_id: str,
    body: JobTemplateUpdate,
) -> JobTemplateResponse:
    """Update a job template."""

    request_args = _build_request_args(
        public_id=public_id,
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return JobTemplateResponse.model_validate(response.json())
