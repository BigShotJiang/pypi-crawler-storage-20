"""Create Template"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import JobTemplateCreate, JobTemplateResponse


def _build_request_args(
    body: JobTemplateCreate,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/templates"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: JobTemplateCreate,
) -> JobTemplateResponse:
    """Create a new job template."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return JobTemplateResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: JobTemplateCreate,
) -> JobTemplateResponse:
    """Create a new job template."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return JobTemplateResponse.model_validate(response.json())
