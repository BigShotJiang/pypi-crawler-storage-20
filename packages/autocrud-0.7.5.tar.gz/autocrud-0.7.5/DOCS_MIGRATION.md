# AutoCRUD 文檔遷移至 MkDocs Material

## 概要

AutoCRUD 文檔系統已成功從 **Sphinx** 遷移至 **MkDocs Material**，與 FastAPI、uv、Pydantic 等現代 Python 專案保持一致的文檔風格。

## 變更內容

### 1. 文檔系統

- ❌ 移除：Sphinx + Furo 主題
- ✅ 新增：MkDocs Material（現代化、響應式設計）

### 2. 依賴更新

`pyproject.toml` 中的 `[project.optional-dependencies]` docs 區塊已更新：

```toml
docs = [
    "mkdocs>=1.6.0",
    "mkdocs-material>=9.5.0",
    "mkdocs-material-extensions>=1.3.0",
    "pymdown-extensions>=10.0.0",
    "mkdocstrings[python]>=0.26.0",
    "mkdocs-gen-files>=0.5.0",
    "mkdocs-literate-nav>=0.6.0",
    "mkdocs-section-index>=0.3.0",
    "autocrud[s3]",
]
```

### 3. 文檔結構

新的文檔結構位於 `docs/` 目錄：

```
docs/
├── index.md                    # 首頁（全新設計）
├── getting-started/           # 開始使用
│   ├── installation.md        # 安裝指南
│   ├── quickstart.md          # 快速開始
│   └── first-api.md          # 第一個 API
├── core-concepts/             # 核心概念
│   ├── architecture.md        # 架構概覽
│   ├── auto-routes.md        # AutoCRUD 路由
│   ├── resource-manager.md   # ResourceManager
│   └── query-builder.md      # Query Builder
├── examples/                  # 範例
│   └── index.md
├── benchmarks/                # 效能測試
│   └── index.md
├── stylesheets/              # 自定義樣式
│   └── extra.css
├── javascripts/              # JavaScript
│   └── mathjax.js
├── includes/                  # 共用內容
│   └── abbreviations.md
└── gen_ref_pages.py          # API 參考自動生成
```

### 4. Makefile 命令更新

新的文檔命令：

```bash
# 建置文檔
make docs

# 啟動開發服務器（http://127.0.0.1:8000）
make serve

# 部署到 GitHub Pages
make deploy-docs

# 清理構建文件
make clean-docs

# 檢查文檔配置
make docs-check

# 快速構建（不清理）
make docs-quick
```

向後相容的別名：
- `make html` → `make docs`
- `make livehtml` → `make serve`

### 5. 特色功能

#### Material Design 風格
- 🎨 現代化的 UI/UX
- 🌓 淺色/深色主題切換
- 📱 完美的行動裝置支援
- 🔍 強大的全文搜尋

#### 自動化 API 文檔
- 使用 `mkdocstrings` 自動從 Python docstrings 生成 API 文檔
- 支援型別提示與交叉引用

#### 增強的 Markdown 功能
- ✅ Admonitions（提示框）
- ✅ Tabs（分頁顯示）
- ✅ Cards（卡片式佈局）
- ✅ Mermaid 圖表支援
- ✅ MathJax 數學公式
- ✅ 程式碼區塊高亮與複製
- ✅ 任務清單

## 快速開始

### 安裝依賴

```bash
uv sync
```

或僅安裝文檔依賴：

```bash
uv pip install mkdocs mkdocs-material "mkdocstrings[python]" \
  mkdocs-gen-files mkdocs-literate-nav mkdocs-section-index
```

### 本地預覽

```bash
make serve
```

訪問 http://127.0.0.1:8000

### 建置文檔

```bash
make docs
```

輸出位於 `site/` 目錄。

### 部署到 GitHub Pages

```bash
make deploy-docs
```

## 配置檔案

主要配置位於 `mkdocs.yml`：

- **主題配置**：Material Design、配色、功能開關
- **插件**：搜尋、自動生成 API 文檔
- **Markdown 擴展**：程式碼高亮、數學公式、Mermaid 等
- **導航結構**：文檔目錄樹

## 舊文檔備份

原 Sphinx 文檔保留在 `docs/source/` 目錄，可在需要時參考。

## 注意事項

1. **API 參考**：會自動從 Python 程式碼生成，請確保 docstrings 完整
2. **內部連結**：使用相對路徑（如 `../guides/permissions.md`）
3. **圖片資源**：放在 `docs/` 目錄下的適當位置
4. **Mermaid 圖表**：使用 ` ```mermaid` 程式碼區塊

## 相關資源

- [MkDocs 官方文檔](https://www.mkdocs.org/)
- [Material for MkDocs](https://squidfunk.github.io/mkdocs-material/)
- [PyMdown Extensions](https://facelessuser.github.io/pymdown-extensions/)

## 遷移檢查清單

- [x] 安裝 MkDocs Material 依賴
- [x] 建立 `mkdocs.yml` 配置
- [x] 遷移核心文檔到新結構
- [x] 更新 Makefile 命令
- [x] 測試文檔建置
- [x] 更新部署腳本
- [ ] 補齊缺少的文檔頁面（guides/, advanced/）
- [ ] 檢查並修復所有內部連結
- [ ] 優化 SEO 與 meta 標籤
- [ ] 設定 GitHub Actions 自動部署

## 後續工作

建議逐步補齊以下文檔：

1. **功能指南** (`guides/`)
   - 版本控制
   - 權限系統
   - 事件處理
   - 搜尋與過濾
   - Binary 檔案
   - 資料遷移

2. **進階主題** (`advanced/`)
   - GraphQL 整合
   - 自定義儲存
   - 效能優化
   - 訊息佇列

3. **其他**
   - 貢獻指南
   - 更新日誌
   - 更多範例

---

**文檔遷移完成！** 🎉
