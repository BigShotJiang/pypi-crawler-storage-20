# autocrud.cli

::: autocrud.cli