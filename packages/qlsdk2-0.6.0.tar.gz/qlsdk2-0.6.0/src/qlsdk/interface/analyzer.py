class IAnalyzer:
    pass