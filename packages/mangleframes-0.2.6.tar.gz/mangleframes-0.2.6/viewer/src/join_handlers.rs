//! HTTP handlers for join analysis endpoints.

use std::sync::Arc;

use axum::body::Body;
use axum::extract::{Path, Query, State};
use axum::http::{header, Response, StatusCode};
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::json;

use crate::arrow_reader::batches_to_json;
use crate::export;
use crate::sql_builder;
use crate::web_server::AppState;

#[derive(Deserialize)]
pub struct JoinRequest {
    left_frame: String,
    right_frame: String,
    left_keys: Vec<String>,
    right_keys: Vec<String>,
}

pub async fn analyze_join(
    State(state): State<Arc<AppState>>,
    Json(req): Json<JoinRequest>,
) -> impl IntoResponse {
    if req.left_keys.len() != req.right_keys.len() {
        return error_response(StatusCode::BAD_REQUEST, "Key count mismatch");
    }
    if req.left_keys.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "At least one join key required");
    }

    let dbx = match &state.databricks_client {
        Some(c) => c,
        None => {
            return error_response(
                StatusCode::SERVICE_UNAVAILABLE,
                "No Databricks connection available",
            )
        }
    };

    // Execute join analysis via SQL
    let sql = sql_builder::join_analyze_sql(
        &req.left_frame,
        &req.right_frame,
        &req.left_keys,
        &req.right_keys,
    );

    match dbx.execute_sql(&sql, 1).await {
        Ok(response) => {
            if response.batches.is_empty() || response.batches[0].num_rows() == 0 {
                return error_response(StatusCode::NOT_FOUND, "No join analysis results");
            }

            // Parse the single row result into JSON
            let rows_value = batches_to_json(&response.batches, 0, 1);
            let rows = rows_value.as_array();
            if rows.is_none() || rows.unwrap().is_empty() {
                return error_response(StatusCode::NOT_FOUND, "No join analysis results");
            }

            let row = &rows.unwrap()[0];
            let left_total = row.get("left_total").and_then(|v| v.as_i64()).unwrap_or(0);
            let right_total = row.get("right_total").and_then(|v| v.as_i64()).unwrap_or(0);
            let left_matched = row.get("left_matched").and_then(|v| v.as_i64()).unwrap_or(0);
            let left_only = row.get("left_only").and_then(|v| v.as_i64()).unwrap_or(0);
            let right_only = row.get("right_only").and_then(|v| v.as_i64()).unwrap_or(0);

            let match_rate = if left_total > 0 {
                (left_matched as f64 / left_total as f64) * 100.0
            } else {
                0.0
            };

            Json(json!({
                "left_total": left_total,
                "right_total": right_total,
                "left_matched": left_matched,
                "left_only": left_only,
                "right_only": right_only,
                "match_rate_pct": match_rate,
                "left_keys": req.left_keys,
                "right_keys": req.right_keys
            }))
            .into_response()
        }
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

#[derive(Deserialize)]
pub struct UnmatchedQuery {
    left_frame: String,
    right_frame: String,
    left_keys: String,
    right_keys: String,
    offset: Option<usize>,
    limit: Option<usize>,
}

pub async fn get_unmatched(
    State(state): State<Arc<AppState>>,
    Path(side): Path<String>,
    Query(query): Query<UnmatchedQuery>,
) -> impl IntoResponse {
    if side != "left" && side != "right" {
        return error_response(StatusCode::BAD_REQUEST, "Side must be 'left' or 'right'");
    }

    let left_keys: Vec<String> = query
        .left_keys
        .split(',')
        .map(|s| s.trim().to_string())
        .collect();
    let right_keys: Vec<String> = query
        .right_keys
        .split(',')
        .map(|s| s.trim().to_string())
        .collect();

    if left_keys.len() != right_keys.len() {
        return error_response(StatusCode::BAD_REQUEST, "Key count mismatch");
    }

    let offset = query.offset.unwrap_or(0);
    let limit = query.limit.unwrap_or(100).min(1000);

    let dbx = match &state.databricks_client {
        Some(c) => c,
        None => {
            return error_response(
                StatusCode::SERVICE_UNAVAILABLE,
                "No Databricks connection available",
            )
        }
    };

    // Execute via SQL
    let sql = sql_builder::join_unmatched_sql(
        &query.left_frame,
        &query.right_frame,
        &left_keys,
        &right_keys,
        &side,
        offset,
        limit,
    );

    match dbx.execute_sql(&sql, limit).await {
        Ok(response) => {
            let rows = batches_to_json(&response.batches, 0, limit);
            Json(json!({
                "rows": rows,
                "total": response.row_count,
                "offset": offset,
                "limit": limit,
                "side": side
            }))
            .into_response()
        }
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

#[derive(Deserialize)]
pub struct ExportRequest {
    left_frame: String,
    right_frame: String,
    left_keys: Vec<String>,
    right_keys: Vec<String>,
    side: String,
    format: String,
}

pub async fn export_unmatched(
    State(state): State<Arc<AppState>>,
    Json(req): Json<ExportRequest>,
) -> impl IntoResponse {
    if req.side != "left" && req.side != "right" {
        return error_response(StatusCode::BAD_REQUEST, "Side must be 'left' or 'right'");
    }

    let dbx = match &state.databricks_client {
        Some(c) => c,
        None => {
            return error_response(
                StatusCode::SERVICE_UNAVAILABLE,
                "No Databricks connection available",
            )
        }
    };

    // Execute via SQL to get all unmatched rows
    let sql = sql_builder::join_unmatched_sql(
        &req.left_frame,
        &req.right_frame,
        &req.left_keys,
        &req.right_keys,
        &req.side,
        0,
        100000,
    );

    let batches = match dbx.execute_sql(&sql, 100000).await {
        Ok(response) => response.batches,
        Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    };

    let (content_type, data, ext) = match req.format.as_str() {
        "csv" => match export::to_csv(&batches) {
            Ok(d) => ("text/csv", d, "csv"),
            Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        "json" => match export::to_json(&batches) {
            Ok(d) => ("application/json", d, "json"),
            Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        "parquet" => match export::to_parquet(&batches) {
            Ok(d) => ("application/octet-stream", d, "parquet"),
            Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        _ => return error_response(StatusCode::BAD_REQUEST, "Invalid format"),
    };

    let filename = format!("{}_unmatched.{}", req.side, ext);
    Response::builder()
        .header(header::CONTENT_TYPE, content_type)
        .header(
            header::CONTENT_DISPOSITION,
            format!("attachment; filename=\"{}\"", filename),
        )
        .body(Body::from(data))
        .unwrap()
        .into_response()
}

fn error_response(status: StatusCode, msg: &str) -> axum::response::Response {
    (status, Json(json!({"error": msg}))).into_response()
}
