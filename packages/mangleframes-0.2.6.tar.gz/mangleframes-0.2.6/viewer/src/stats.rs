//! Statistics computation for DataFrame columns.

use arrow::array::Array;
use arrow::datatypes::{DataType, Schema};
use arrow::record_batch::RecordBatch;
use serde_json::{json, Value};
use tracing::info;

pub fn compute_stats(batches: &[RecordBatch]) -> Value {
    if batches.is_empty() {
        return json!({"columns": []});
    }

    let schema = batches[0].schema();
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();

    let columns: Vec<Value> = schema
        .fields()
        .iter()
        .enumerate()
        .map(|(col_idx, field)| {
            let mut null_count = 0usize;
            for batch in batches {
                null_count += batch.column(col_idx).null_count();
            }

            let mut stats = json!({
                "name": field.name(),
                "type": format!("{:?}", field.data_type()),
                "null_count": null_count,
                "non_null_count": total_rows - null_count,
            });

            if is_numeric(field.data_type()) {
                if let Some((min, max)) = compute_min_max(batches, col_idx) {
                    stats["min"] = json!(min);
                    stats["max"] = json!(max);
                }
            }

            stats
        })
        .collect();

    json!({
        "row_count": total_rows,
        "columns": columns
    })
}

fn is_numeric(dtype: &DataType) -> bool {
    matches!(
        dtype,
        DataType::Int8 | DataType::Int16 | DataType::Int32 | DataType::Int64
        | DataType::UInt8 | DataType::UInt16 | DataType::UInt32 | DataType::UInt64
        | DataType::Float32 | DataType::Float64
    )
}

fn compute_min_max(batches: &[RecordBatch], col_idx: usize) -> Option<(f64, f64)> {
    let mut min: Option<f64> = None;
    let mut max: Option<f64> = None;

    for batch in batches {
        let col = batch.column(col_idx);
        for i in 0..col.len() {
            if col.is_null(i) {
                continue;
            }
            if let Some(val) = extract_numeric(col.as_ref(), i) {
                min = Some(min.map_or(val, |m| m.min(val)));
                max = Some(max.map_or(val, |m| m.max(val)));
            }
        }
    }

    min.zip(max)
}

fn extract_numeric(array: &dyn Array, index: usize) -> Option<f64> {
    match array.data_type() {
        DataType::Int8 => {
            let arr = array.as_any().downcast_ref::<arrow::array::Int8Array>()?;
            Some(arr.value(index) as f64)
        }
        DataType::Int16 => {
            let arr = array.as_any().downcast_ref::<arrow::array::Int16Array>()?;
            Some(arr.value(index) as f64)
        }
        DataType::Int32 => {
            let arr = array.as_any().downcast_ref::<arrow::array::Int32Array>()?;
            Some(arr.value(index) as f64)
        }
        DataType::Int64 => {
            let arr = array.as_any().downcast_ref::<arrow::array::Int64Array>()?;
            Some(arr.value(index) as f64)
        }
        DataType::Float32 => {
            let arr = array.as_any().downcast_ref::<arrow::array::Float32Array>()?;
            Some(arr.value(index) as f64)
        }
        DataType::Float64 => {
            let arr = array.as_any().downcast_ref::<arrow::array::Float64Array>()?;
            Some(arr.value(index))
        }
        _ => None,
    }
}

/// Generate SQL aggregation query for computing stats on a Databricks table.
pub fn generate_stats_sql(table_name: &str, schema: &Schema) -> String {
    info!("Generating stats SQL for table: {}", table_name);

    let mut select_parts = vec!["COUNT(*) AS row_count".to_string()];

    for field in schema.fields() {
        let col_name = field.name();
        let quoted = format!("`{}`", col_name);

        select_parts.push(format!("COUNT({}) AS `{}_non_null`", quoted, col_name));
        select_parts.push(format!(
            "COUNT(*) - COUNT({}) AS `{}_null`",
            quoted, col_name
        ));

        if is_numeric(field.data_type()) {
            select_parts.push(format!("MIN({}) AS `{}_min`", quoted, col_name));
            select_parts.push(format!("MAX({}) AS `{}_max`", quoted, col_name));
        }
    }

    format!("SELECT {} FROM {}", select_parts.join(", "), table_name)
}

/// Parse SQL aggregation result into stats JSON format.
pub fn parse_stats_result(batches: &[RecordBatch], schema: &Schema) -> Value {
    info!("Parsing stats result from {} batches", batches.len());

    if batches.is_empty() || batches[0].num_rows() == 0 {
        return json!({"row_count": 0, "columns": []});
    }

    let result_batch = &batches[0];
    let result_schema = result_batch.schema();

    let row_count = get_result_value(result_batch, &result_schema, "row_count")
        .and_then(|v| v.as_i64())
        .unwrap_or(0) as usize;

    let columns: Vec<Value> = schema
        .fields()
        .iter()
        .map(|field| {
            let col_name = field.name();

            let non_null = get_result_value(
                result_batch,
                &result_schema,
                &format!("{}_non_null", col_name),
            )
            .and_then(|v| v.as_i64())
            .unwrap_or(0) as usize;

            let null_count = get_result_value(
                result_batch,
                &result_schema,
                &format!("{}_null", col_name),
            )
            .and_then(|v| v.as_i64())
            .unwrap_or(0) as usize;

            let mut stats = json!({
                "name": col_name,
                "type": format!("{:?}", field.data_type()),
                "null_count": null_count,
                "non_null_count": non_null,
            });

            if is_numeric(field.data_type()) {
                if let Some(min) = get_result_value(
                    result_batch,
                    &result_schema,
                    &format!("{}_min", col_name),
                )
                .and_then(|v| v.as_f64())
                {
                    stats["min"] = json!(min);
                }
                if let Some(max) = get_result_value(
                    result_batch,
                    &result_schema,
                    &format!("{}_max", col_name),
                )
                .and_then(|v| v.as_f64())
                {
                    stats["max"] = json!(max);
                }
            }

            stats
        })
        .collect();

    json!({
        "row_count": row_count,
        "columns": columns
    })
}

/// Extract a value from the result batch by column name.
fn get_result_value(
    batch: &RecordBatch,
    schema: &std::sync::Arc<Schema>,
    col_name: &str,
) -> Option<Value> {
    let col_idx = schema.index_of(col_name).ok()?;
    let col = batch.column(col_idx);

    if col.is_null(0) {
        return None;
    }

    match col.data_type() {
        DataType::Int64 => {
            let arr = col.as_any().downcast_ref::<arrow::array::Int64Array>()?;
            Some(json!(arr.value(0)))
        }
        DataType::Float64 => {
            let arr = col.as_any().downcast_ref::<arrow::array::Float64Array>()?;
            Some(json!(arr.value(0)))
        }
        DataType::Int32 => {
            let arr = col.as_any().downcast_ref::<arrow::array::Int32Array>()?;
            Some(json!(arr.value(0) as i64))
        }
        DataType::Float32 => {
            let arr = col.as_any().downcast_ref::<arrow::array::Float32Array>()?;
            Some(json!(arr.value(0) as f64))
        }
        _ => None,
    }
}
