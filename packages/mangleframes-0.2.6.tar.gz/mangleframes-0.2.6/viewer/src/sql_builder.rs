//! SQL query generation for Spark Connect operations.

use serde_json::Value;

/// Quote an identifier to prevent SQL injection.
pub fn quote_identifier(name: &str) -> String {
    format!("`{}`", name.replace('`', "``"))
}

/// Quote multiple identifiers and join with commas.
pub fn quote_identifiers(names: &[String]) -> String {
    names.iter().map(|n| quote_identifier(n)).collect::<Vec<_>>().join(", ")
}

/// Generate SQL to list all tables/views.
pub fn list_tables_sql() -> String {
    "SHOW TABLES".to_string()
}

/// Generate SQL to describe a table's schema.
pub fn describe_table_sql(table: &str) -> String {
    format!("DESCRIBE TABLE {}", quote_identifier(table))
}

/// Generate SQL to select data with pagination.
pub fn select_data_sql(table: &str, limit: usize, offset: usize) -> String {
    let quoted = quote_identifier(table);
    if offset == 0 {
        format!("SELECT * FROM {} LIMIT {}", quoted, limit)
    } else {
        // Use ROW_NUMBER() for offset support
        format!(
            "SELECT * FROM (SELECT *, ROW_NUMBER() OVER () as __row_num FROM {}) \
             WHERE __row_num > {} AND __row_num <= {} \
             ORDER BY __row_num",
            quoted, offset, offset + limit
        )
    }
}

/// Generate SQL to count total rows in a table.
pub fn count_rows_sql(table: &str) -> String {
    format!("SELECT COUNT(*) as total FROM {}", quote_identifier(table))
}

/// Generate SQL for column statistics.
pub fn stats_sql(table: &str, columns: &[(String, String)]) -> String {
    let quoted_table = quote_identifier(table);
    let mut select_parts = vec!["COUNT(*) AS row_count".to_string()];

    for (col_name, col_type) in columns {
        let quoted = quote_identifier(col_name);
        select_parts.push(format!("COUNT({}) AS {}_non_null", quoted, quote_identifier(&format!("{}_non_null", col_name))));
        select_parts.push(format!(
            "COUNT(*) - COUNT({}) AS {}",
            quoted, quote_identifier(&format!("{}_null", col_name))
        ));

        if is_numeric_type(col_type) {
            select_parts.push(format!("MIN({}) AS {}", quoted, quote_identifier(&format!("{}_min", col_name))));
            select_parts.push(format!("MAX({}) AS {}", quoted, quote_identifier(&format!("{}_max", col_name))));
        }
    }

    format!("SELECT {} FROM {}", select_parts.join(", "), quoted_table)
}

/// Generate SQL for join key analysis.
pub fn join_keys_sql(table: &str, keys: &[String]) -> String {
    let quoted_table = quote_identifier(table);
    let mut select_parts = vec!["COUNT(*) AS total_rows".to_string()];

    for key in keys {
        let quoted = quote_identifier(key);
        select_parts.push(format!("COUNT(DISTINCT {}) AS {}", quoted, quote_identifier(&format!("{}_distinct", key))));
        select_parts.push(format!(
            "COUNT(*) - COUNT({}) AS {}",
            quoted, quote_identifier(&format!("{}_nulls", key))
        ));
    }

    format!("SELECT {} FROM {}", select_parts.join(", "), quoted_table)
}

/// Generate SQL for join analysis between two tables.
pub fn join_analyze_sql(
    left_table: &str,
    right_table: &str,
    left_keys: &[String],
    right_keys: &[String],
) -> String {
    let left_quoted = quote_identifier(left_table);
    let right_quoted = quote_identifier(right_table);

    // Build join condition
    let join_cond = build_join_condition("l", "r", left_keys, right_keys);

    format!(
        "WITH
  left_stats AS (
    SELECT COUNT(*) as total, COUNT(DISTINCT {}) as distinct_keys FROM {} l
  ),
  right_stats AS (
    SELECT COUNT(*) as total, COUNT(DISTINCT {}) as distinct_keys FROM {} r
  ),
  matched AS (
    SELECT COUNT(DISTINCT l.{}) as left_matched, COUNT(*) as pairs
    FROM {} l INNER JOIN {} r ON {}
  ),
  left_only AS (
    SELECT COUNT(*) as cnt FROM {} l
    WHERE NOT EXISTS (SELECT 1 FROM {} r WHERE {})
  ),
  right_only AS (
    SELECT COUNT(*) as cnt FROM {} r
    WHERE NOT EXISTS (SELECT 1 FROM {} l WHERE {})
  )
SELECT
  left_stats.total as left_total,
  left_stats.distinct_keys as left_distinct,
  right_stats.total as right_total,
  right_stats.distinct_keys as right_distinct,
  matched.left_matched,
  matched.pairs,
  left_only.cnt as left_only,
  right_only.cnt as right_only
FROM left_stats, right_stats, matched, left_only, right_only",
        quote_identifier(&left_keys[0]), left_quoted,
        quote_identifier(&right_keys[0]), right_quoted,
        quote_identifier(&left_keys[0]),
        left_quoted, right_quoted, join_cond,
        left_quoted, right_quoted, join_cond,
        right_quoted, left_quoted, join_cond
    )
}

/// Generate SQL to get unmatched rows from one side of a join.
pub fn join_unmatched_sql(
    left_table: &str,
    right_table: &str,
    left_keys: &[String],
    right_keys: &[String],
    side: &str,
    offset: usize,
    limit: usize,
) -> String {
    let left_quoted = quote_identifier(left_table);
    let right_quoted = quote_identifier(right_table);
    let join_cond = build_join_condition("l", "r", left_keys, right_keys);

    if side == "left" {
        format!(
            "SELECT l.* FROM {} l \
             WHERE NOT EXISTS (SELECT 1 FROM {} r WHERE {}) \
             LIMIT {} OFFSET {}",
            left_quoted, right_quoted, join_cond, limit, offset
        )
    } else {
        format!(
            "SELECT r.* FROM {} r \
             WHERE NOT EXISTS (SELECT 1 FROM {} l WHERE {}) \
             LIMIT {} OFFSET {}",
            right_quoted, left_quoted, join_cond, limit, offset
        )
    }
}

/// Generate SQL for aggregated reconciliation.
pub fn reconcile_agg_sql(
    source_table: &str,
    target_table: &str,
    config: &Value,
) -> Result<String, String> {
    let source_group_by = config["source_group_by"]
        .as_array()
        .ok_or("Missing source_group_by")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let target_group_by = config["target_group_by"]
        .as_array()
        .ok_or("Missing target_group_by")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let source_join_keys = config["source_join_keys"]
        .as_array()
        .ok_or("Missing source_join_keys")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let target_join_keys = config["target_join_keys"]
        .as_array()
        .ok_or("Missing target_join_keys")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let aggregations = config["aggregations"]
        .as_array()
        .ok_or("Missing aggregations")?;

    let join_type = config["join_type"]
        .as_str()
        .unwrap_or("inner")
        .to_uppercase();

    let sample_limit = config["sample_limit"].as_u64().unwrap_or(100) as usize;

    // Build aggregation expressions
    let agg_exprs = build_agg_expressions(aggregations)?;

    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);
    let source_group = quote_identifiers(&source_group_by);
    let target_group = quote_identifiers(&target_group_by);

    // Build join condition for aggregated results
    let join_cond = build_join_condition("s", "t", &source_join_keys, &target_join_keys);

    format!(
        "WITH
  source_agg AS (
    SELECT {}, {} FROM {} GROUP BY {}
  ),
  target_agg AS (
    SELECT {}, {} FROM {} GROUP BY {}
  ),
  reconciled AS (
    SELECT s.*, {} as __match_status
    FROM source_agg s
    {} JOIN target_agg t ON {}
  )
SELECT * FROM reconciled LIMIT {}",
        source_group, agg_exprs.source, source_quoted, source_group,
        target_group, agg_exprs.target, target_quoted, target_group,
        build_match_status_expr(&agg_exprs),
        join_type, join_cond,
        sample_limit
    );

    // Actually build a simpler reconciliation query
    Ok(build_reconcile_query(
        source_table,
        target_table,
        &source_group_by,
        &target_group_by,
        &source_join_keys,
        &target_join_keys,
        aggregations,
        &join_type,
        sample_limit,
    )?)
}

struct AggExpressions {
    source: String,
    target: String,
    comparisons: Vec<String>,
}

fn build_agg_expressions(aggregations: &[Value]) -> Result<AggExpressions, String> {
    let mut source_parts = Vec::new();
    let mut target_parts = Vec::new();
    let mut comparisons = Vec::new();

    for agg in aggregations {
        let column = agg["column"]
            .as_str()
            .ok_or("Missing column in aggregation")?;
        let agg_types = agg["aggregations"]
            .as_array()
            .ok_or("Missing aggregations array")?;

        for agg_type in agg_types {
            let agg_name = agg_type.as_str().unwrap_or("sum");
            let func = agg_name.to_uppercase();
            let alias = format!("{}_{}", column, agg_name);

            source_parts.push(format!(
                "{}({}) AS {}",
                func, quote_identifier(column), quote_identifier(&alias)
            ));
            target_parts.push(format!(
                "{}({}) AS {}",
                func, quote_identifier(column), quote_identifier(&alias)
            ));
            comparisons.push(alias);
        }
    }

    Ok(AggExpressions {
        source: source_parts.join(", "),
        target: target_parts.join(", "),
        comparisons,
    })
}

fn build_match_status_expr(agg_exprs: &AggExpressions) -> String {
    if agg_exprs.comparisons.is_empty() {
        return "'matched'".to_string();
    }

    let conditions: Vec<String> = agg_exprs.comparisons.iter()
        .map(|c| format!("s.{} = t.{}", quote_identifier(c), quote_identifier(c)))
        .collect();

    format!("CASE WHEN {} THEN 'matched' ELSE 'mismatched' END", conditions.join(" AND "))
}

fn build_reconcile_query(
    source_table: &str,
    target_table: &str,
    source_group_by: &[String],
    target_group_by: &[String],
    source_join_keys: &[String],
    target_join_keys: &[String],
    aggregations: &[Value],
    join_type: &str,
    sample_limit: usize,
) -> Result<String, String> {
    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);
    let source_group = quote_identifiers(source_group_by);
    let target_group = quote_identifiers(target_group_by);

    let agg_exprs = build_agg_expressions(aggregations)?;
    let join_cond = build_join_condition("s", "t", source_join_keys, target_join_keys);

    Ok(format!(
        "WITH
  source_agg AS (
    SELECT {}, {} FROM {} GROUP BY {}
  ),
  target_agg AS (
    SELECT {}, {} FROM {} GROUP BY {}
  ),
  joined AS (
    SELECT
      s.*,
      {}
    FROM source_agg s
    {} JOIN target_agg t ON {}
  )
SELECT * FROM joined LIMIT {}",
        source_group, agg_exprs.source, source_quoted, source_group,
        target_group, agg_exprs.target, target_quoted, target_group,
        build_target_columns(&agg_exprs.comparisons),
        join_type, join_cond,
        sample_limit
    ))
}

fn build_target_columns(comparisons: &[String]) -> String {
    comparisons.iter()
        .map(|c| format!("t.{} AS target_{}", quote_identifier(c), c))
        .collect::<Vec<_>>()
        .join(", ")
}

/// Generate SQL for reconciliation statistics counts.
/// Uses JOINs instead of EXISTS/NOT EXISTS to avoid SPARK-47070 bug
/// with correlated subqueries on same-named columns from CTEs.
pub fn reconcile_stats_sql(
    source_table: &str,
    target_table: &str,
    config: &Value,
) -> Result<String, String> {
    let (source_group_by, target_group_by, source_join_keys, target_join_keys, agg_exprs) =
        parse_reconcile_config(config)?;

    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);
    let source_group = quote_identifiers(&source_group_by);
    let target_group = quote_identifiers(&target_group_by);
    let join_cond = build_join_condition("s", "t", &source_join_keys, &target_join_keys);

    // Use first target key for NULL check in source_only (after LEFT JOIN)
    let target_null_check = quote_identifier(&target_join_keys[0]);
    // Use first source key for NULL check in target_only (after LEFT JOIN)
    let source_null_check = quote_identifier(&source_join_keys[0]);

    Ok(format!(
        "WITH
  source_agg AS (SELECT {}, {} FROM {} GROUP BY {}),
  target_agg AS (SELECT {}, {} FROM {} GROUP BY {}),
  source_count AS (SELECT COUNT(*) as cnt FROM source_agg),
  target_count AS (SELECT COUNT(*) as cnt FROM target_agg),
  matched AS (
    SELECT COUNT(*) as cnt
    FROM source_agg s
    INNER JOIN target_agg t ON {}
  ),
  source_only AS (
    SELECT COUNT(*) as cnt
    FROM source_agg s
    LEFT JOIN target_agg t ON {}
    WHERE t.{} IS NULL
  ),
  target_only AS (
    SELECT COUNT(*) as cnt
    FROM target_agg t
    LEFT JOIN source_agg s ON {}
    WHERE s.{} IS NULL
  )
SELECT
  source_count.cnt as source_groups,
  target_count.cnt as target_groups,
  matched.cnt as matched_groups,
  source_only.cnt as source_only_groups,
  target_only.cnt as target_only_groups
FROM source_count, target_count, matched, source_only, target_only",
        source_group, agg_exprs.source, source_quoted, source_group,
        target_group, agg_exprs.target, target_quoted, target_group,
        join_cond,
        join_cond, target_null_check,
        join_cond, source_null_check
    ))
}

/// Generate SQL for source-only rows (unmatched in target).
/// Uses LEFT JOIN instead of NOT EXISTS to avoid SPARK-47070 bug.
pub fn reconcile_source_only_sql(
    source_table: &str,
    target_table: &str,
    config: &Value,
    limit: usize,
) -> Result<String, String> {
    let (source_group_by, target_group_by, source_join_keys, target_join_keys, agg_exprs) =
        parse_reconcile_config(config)?;

    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);
    let source_group = quote_identifiers(&source_group_by);
    let target_group = quote_identifiers(&target_group_by);
    let join_cond = build_join_condition("s", "t", &source_join_keys, &target_join_keys);
    let target_null_check = quote_identifier(&target_join_keys[0]);

    Ok(format!(
        "WITH
  source_agg AS (SELECT {}, {} FROM {} GROUP BY {}),
  target_agg AS (SELECT {}, {} FROM {} GROUP BY {})
SELECT s.* FROM source_agg s
LEFT JOIN target_agg t ON {}
WHERE t.{} IS NULL
LIMIT {}",
        source_group, agg_exprs.source, source_quoted, source_group,
        target_group, agg_exprs.target, target_quoted, target_group,
        join_cond, target_null_check, limit
    ))
}

/// Generate SQL for target-only rows (unmatched in source).
/// Uses LEFT JOIN instead of NOT EXISTS to avoid SPARK-47070 bug.
pub fn reconcile_target_only_sql(
    source_table: &str,
    target_table: &str,
    config: &Value,
    limit: usize,
) -> Result<String, String> {
    let (source_group_by, target_group_by, source_join_keys, target_join_keys, agg_exprs) =
        parse_reconcile_config(config)?;

    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);
    let source_group = quote_identifiers(&source_group_by);
    let target_group = quote_identifiers(&target_group_by);
    let join_cond = build_join_condition("s", "t", &source_join_keys, &target_join_keys);
    let source_null_check = quote_identifier(&source_join_keys[0]);

    Ok(format!(
        "WITH
  source_agg AS (SELECT {}, {} FROM {} GROUP BY {}),
  target_agg AS (SELECT {}, {} FROM {} GROUP BY {})
SELECT t.* FROM target_agg t
LEFT JOIN source_agg s ON {}
WHERE s.{} IS NULL
LIMIT {}",
        source_group, agg_exprs.source, source_quoted, source_group,
        target_group, agg_exprs.target, target_quoted, target_group,
        join_cond, source_null_check, limit
    ))
}

/// Generate SQL for matched rows with comparison data.
pub fn reconcile_matched_sql(
    source_table: &str,
    target_table: &str,
    config: &Value,
    limit: usize,
) -> Result<String, String> {
    let (source_group_by, target_group_by, source_join_keys, target_join_keys, agg_exprs) =
        parse_reconcile_config(config)?;

    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);
    let source_group = quote_identifiers(&source_group_by);
    let target_group = quote_identifiers(&target_group_by);
    let join_cond = build_join_condition("s", "t", &source_join_keys, &target_join_keys);

    Ok(format!(
        "WITH
  source_agg AS (SELECT {}, {} FROM {} GROUP BY {}),
  target_agg AS (SELECT {}, {} FROM {} GROUP BY {})
SELECT s.*, {}
FROM source_agg s
INNER JOIN target_agg t ON {}
LIMIT {}",
        source_group, agg_exprs.source, source_quoted, source_group,
        target_group, agg_exprs.target, target_quoted, target_group,
        build_target_columns(&agg_exprs.comparisons),
        join_cond, limit
    ))
}

/// Generate SQL for column totals comparison.
pub fn reconcile_totals_sql(
    source_table: &str,
    target_table: &str,
    config: &Value,
) -> Result<String, String> {
    let aggregations = config["aggregations"]
        .as_array()
        .ok_or("Missing aggregations")?;

    let source_quoted = quote_identifier(source_table);
    let target_quoted = quote_identifier(target_table);

    let mut source_aggs = Vec::new();
    let mut target_aggs = Vec::new();

    for agg in aggregations {
        let column = agg["column"].as_str().ok_or("Missing column")?;
        let agg_types = agg["aggregations"].as_array().ok_or("Missing aggregations")?;

        for agg_type in agg_types {
            let func = agg_type.as_str().unwrap_or("sum").to_uppercase();
            let alias = format!("{}_{}", column, func.to_lowercase());
            source_aggs.push(format!(
                "{}({}) AS source_{}",
                func, quote_identifier(column), alias
            ));
            target_aggs.push(format!(
                "{}({}) AS target_{}",
                func, quote_identifier(column), alias
            ));
        }
    }

    Ok(format!(
        "SELECT s.*, t.* FROM (SELECT {} FROM {}) s, (SELECT {} FROM {}) t",
        source_aggs.join(", "), source_quoted,
        target_aggs.join(", "), target_quoted
    ))
}

fn parse_reconcile_config(config: &Value) -> Result<(Vec<String>, Vec<String>, Vec<String>, Vec<String>, AggExpressions), String> {
    let source_group_by = config["source_group_by"]
        .as_array()
        .ok_or("Missing source_group_by")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let target_group_by = config["target_group_by"]
        .as_array()
        .ok_or("Missing target_group_by")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let source_join_keys = config["source_join_keys"]
        .as_array()
        .ok_or("Missing source_join_keys")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let target_join_keys = config["target_join_keys"]
        .as_array()
        .ok_or("Missing target_join_keys")?
        .iter()
        .filter_map(|v| v.as_str().map(String::from))
        .collect::<Vec<_>>();

    let aggregations = config["aggregations"]
        .as_array()
        .ok_or("Missing aggregations")?;

    let agg_exprs = build_agg_expressions(aggregations)?;

    Ok((source_group_by, target_group_by, source_join_keys, target_join_keys, agg_exprs))
}

fn build_join_condition(
    left_alias: &str,
    right_alias: &str,
    left_keys: &[String],
    right_keys: &[String],
) -> String {
    left_keys
        .iter()
        .zip(right_keys.iter())
        .map(|(lk, rk)| {
            // Use NULL-safe equality (<=>). Standard = returns NULL when comparing NULLs,
            // causing rows with NULL keys to never match even in identical tables.
            format!(
                "{}.{} <=> {}.{}",
                left_alias, quote_identifier(lk),
                right_alias, quote_identifier(rk)
            )
        })
        .collect::<Vec<_>>()
        .join(" AND ")
}

fn is_numeric_type(type_str: &str) -> bool {
    let t = type_str.to_lowercase();
    t.contains("int") || t.contains("float") || t.contains("double")
        || t.contains("decimal") || t.contains("numeric")
}

/// Generate SQL for join key statistics.
pub fn join_key_stats_sql(table: &str, columns: &[String]) -> String {
    let quoted_table = quote_identifier(table);
    let key_expr = if columns.len() == 1 {
        quote_identifier(&columns[0])
    } else {
        format!(
            "CONCAT_WS('|', {})",
            columns
                .iter()
                .map(|c| format!("COALESCE(CAST({} AS STRING), '')", quote_identifier(c)))
                .collect::<Vec<_>>()
                .join(", ")
        )
    };

    format!(
        "SELECT
            COUNT(*) as total_rows,
            COUNT(DISTINCT {}) as cardinality,
            COUNT(*) - COUNT({}) as null_count
         FROM {}",
        key_expr, key_expr, quoted_table
    )
}

/// Generate SQL for temporal bucket analysis.
pub fn temporal_buckets_sql(table: &str, date_column: &str, bucket: &str) -> String {
    let quoted_table = quote_identifier(table);
    let quoted_col = quote_identifier(date_column);

    let trunc_expr = match bucket {
        "day" => format!("DATE_TRUNC('DAY', {})", quoted_col),
        "week" => format!("DATE_TRUNC('WEEK', {})", quoted_col),
        "month" => format!("DATE_TRUNC('MONTH', {})", quoted_col),
        "year" => format!("DATE_TRUNC('YEAR', {})", quoted_col),
        _ => format!("DATE_TRUNC('MONTH', {})", quoted_col),
    };

    format!(
        "SELECT
            {} as bucket,
            MIN({}) as min_date,
            MAX({}) as max_date,
            COUNT(*) as row_count
         FROM {}
         WHERE {} IS NOT NULL
         GROUP BY 1
         ORDER BY 1",
        trunc_expr, quoted_col, quoted_col, quoted_table, quoted_col
    )
}

/// Generate SQL for temporal range stats.
pub fn temporal_range_sql(table: &str, date_column: &str) -> String {
    let quoted_table = quote_identifier(table);
    let quoted_col = quote_identifier(date_column);

    format!(
        "SELECT
            MIN({}) as min_date,
            MAX({}) as max_date,
            COUNT(*) as total_rows,
            COUNT(*) - COUNT({}) as null_dates,
            COUNT(DISTINCT {}) as distinct_dates
         FROM {}",
        quoted_col, quoted_col, quoted_col, quoted_col, quoted_table
    )
}

/// Generate SQL for computing join overlap between two tables.
pub fn join_overlap_sql(
    left_table: &str,
    right_table: &str,
    left_keys: &[String],
    right_keys: &[String],
) -> String {
    let left_quoted = quote_identifier(left_table);
    let right_quoted = quote_identifier(right_table);
    let join_cond = build_join_condition("l", "r", left_keys, right_keys);

    format!(
        "WITH
  left_keys AS (SELECT DISTINCT {} FROM {} l),
  right_keys AS (SELECT DISTINCT {} FROM {} r),
  stats AS (
    SELECT
      (SELECT COUNT(*) FROM left_keys) as left_total,
      (SELECT COUNT(*) FROM right_keys) as right_total,
      (SELECT COUNT(*) FROM left_keys lk WHERE NOT EXISTS (
        SELECT 1 FROM right_keys rk WHERE {}
      )) as left_only,
      (SELECT COUNT(*) FROM right_keys rk WHERE NOT EXISTS (
        SELECT 1 FROM left_keys lk WHERE {}
      )) as right_only,
      (SELECT COUNT(*) FROM left_keys lk WHERE EXISTS (
        SELECT 1 FROM right_keys rk WHERE {}
      )) as both_count
  )
SELECT *,
  CASE WHEN left_total + right_total - both_count > 0
    THEN both_count * 100.0 / (left_total + right_total - both_count)
    ELSE 0
  END as overlap_pct
FROM stats",
        left_keys.iter().map(|k| quote_identifier(k)).collect::<Vec<_>>().join(", "),
        left_quoted,
        right_keys.iter().map(|k| quote_identifier(k)).collect::<Vec<_>>().join(", "),
        right_quoted,
        build_overlap_condition("lk", "rk", left_keys, right_keys),
        build_overlap_condition("lk", "rk", left_keys, right_keys),
        build_overlap_condition("lk", "rk", left_keys, right_keys)
    )
}

fn build_overlap_condition(
    left_alias: &str,
    right_alias: &str,
    left_keys: &[String],
    right_keys: &[String],
) -> String {
    left_keys
        .iter()
        .zip(right_keys.iter())
        .map(|(lk, rk)| {
            // Use NULL-safe equality (<=>)
            format!(
                "{}.{} <=> {}.{}",
                left_alias, quote_identifier(lk),
                right_alias, quote_identifier(rk)
            )
        })
        .collect::<Vec<_>>()
        .join(" AND ")
}

/// Generate SQL for temporal data loss calculation.
pub fn temporal_loss_sql(
    table: &str,
    date_column: &str,
    overlap_start: &str,
    overlap_end: &str,
) -> String {
    let quoted_table = quote_identifier(table);
    let quoted_col = quote_identifier(date_column);

    format!(
        "SELECT
            SUM(CASE WHEN {} < '{}' THEN 1 ELSE 0 END) as rows_before,
            SUM(CASE WHEN {} > '{}' THEN 1 ELSE 0 END) as rows_after,
            SUM(CASE WHEN {} < '{}' OR {} > '{}' THEN 1 ELSE 0 END) as total_lost,
            COUNT(*) as total_rows,
            CASE WHEN COUNT(*) > 0 THEN
                SUM(CASE WHEN {} < '{}' OR {} > '{}' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)
            ELSE 0 END as pct_lost
         FROM {}
         WHERE {} IS NOT NULL",
        quoted_col, overlap_start,
        quoted_col, overlap_end,
        quoted_col, overlap_start, quoted_col, overlap_end,
        quoted_col, overlap_start, quoted_col, overlap_end,
        quoted_table, quoted_col
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_quote_identifier() {
        assert_eq!(quote_identifier("column"), "`column`");
        assert_eq!(quote_identifier("my`col"), "`my``col`");
    }

    #[test]
    fn test_list_tables_sql() {
        assert_eq!(list_tables_sql(), "SHOW TABLES");
    }

    #[test]
    fn test_select_data_sql_no_offset() {
        let sql = select_data_sql("my_table", 100, 0);
        assert_eq!(sql, "SELECT * FROM `my_table` LIMIT 100");
    }

    #[test]
    fn test_select_data_sql_with_offset() {
        let sql = select_data_sql("my_table", 100, 50);
        assert!(sql.contains("ROW_NUMBER()"));
        assert!(sql.contains("> 50"));
        assert!(sql.contains("<= 150"));
    }

    #[test]
    fn test_count_rows_sql() {
        let sql = count_rows_sql("test_table");
        assert_eq!(sql, "SELECT COUNT(*) as total FROM `test_table`");
    }

    #[test]
    fn test_join_condition() {
        let cond = build_join_condition(
            "l", "r",
            &["id".to_string(), "date".to_string()],
            &["key".to_string(), "dt".to_string()]
        );
        assert_eq!(cond, "l.`id` <=> r.`key` AND l.`date` <=> r.`dt`");
    }
}
