//! HTTP handlers for DQX data quality operations.
//! Note: DQX is a Python-only SDK and is not available in pure Rust mode.

use std::sync::Arc;

use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::json;

use crate::web_server::AppState;

/// Check if DQX is available - always returns false in Rust-only mode.
pub async fn dqx_available(State(_state): State<Arc<AppState>>) -> impl IntoResponse {
    Json(json!({
        "available": false,
        "reason": "DQX requires Python SDK and is not available in direct Spark Connect mode"
    }))
}

/// Profile a DataFrame - not available in Rust-only mode.
pub async fn profile_frame(
    State(_state): State<Arc<AppState>>,
    Path(_name): Path<String>,
) -> impl IntoResponse {
    (
        StatusCode::NOT_IMPLEMENTED,
        Json(json!({
            "error": "DQX profiling requires Python SDK and is not available in direct Spark Connect mode"
        })),
    )
}

#[derive(Deserialize)]
pub struct CheckRequest {
    #[allow(dead_code)]
    rules: Vec<DQRuleInput>,
}

#[derive(Deserialize)]
pub struct DQRuleInput {
    #[allow(dead_code)]
    name: Option<String>,
    #[allow(dead_code)]
    check_func: String,
    #[allow(dead_code)]
    column: Option<String>,
    #[allow(dead_code)]
    criticality: Option<String>,
    #[allow(dead_code)]
    #[serde(default)]
    check_func_kwargs: serde_json::Value,
}

/// Apply quality checks - not available in Rust-only mode.
pub async fn run_quality_checks(
    State(_state): State<Arc<AppState>>,
    Path(_name): Path<String>,
    Json(_req): Json<CheckRequest>,
) -> impl IntoResponse {
    (
        StatusCode::NOT_IMPLEMENTED,
        Json(json!({
            "error": "DQX quality checks require Python SDK and are not available in direct Spark Connect mode"
        })),
    )
}
