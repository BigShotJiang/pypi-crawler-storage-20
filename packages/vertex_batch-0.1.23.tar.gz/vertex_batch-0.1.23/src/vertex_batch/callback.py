from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pathlib import Path
import uvicorn
import json_repair
import asyncio
from .file import File
from .db import Db
import os
import logging

logging.basicConfig(
    level= logging.INFO,
)

class Callback:

    def __init__(self, db:Db, port: int, destination_dir: Path, func: callable = None, gateway: bool = False,
                 input_token_cost_per_million: float = 0.15, output_token_cost_per_million: float = 0.60):
        self.port = port
        self.app = FastAPI()
        self.destination_dir = destination_dir
        self.func = func
        self.db = db
        self.gateway = gateway
        self.input_token_cost_per_million = input_token_cost_per_million
        self.output_token_cost_per_million = output_token_cost_per_million

        # register routes
        self.app.post("/batch_processing_done")(self.callback)

    def _calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """
        Calculate the total cost based on input and output tokens.

        Args:
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens

        Returns:
            Total cost in dollars
        """
        input_cost = (input_tokens / 1_000_000) * self.input_token_cost_per_million
        output_cost = (output_tokens / 1_000_000) * self.output_token_cost_per_million
        return input_cost + output_cost

    def _process_file_gemini(self, file_path: Path, db: Db) -> dict:
        try:
            # Initialize token counters
            total_input_tokens = 0
            total_output_tokens = 0
            total_tokens = 0

            if file_path.suffix != ".jsonl" or not file_path.is_relative_to(Path("output/")):
                raise ValueError("File must be a .jsonl file and starts with output/")

            downloaded_file_path = File.download(
                google_storage_file_path=file_path,
                destination_dir=self.destination_dir
            )

            if not downloaded_file_path:
                db.flag_payloads(
                    file_path = Path(f"{Path(file_path).parts[2]}.jsonl"),
                    flag = "FAILED",
                    clean = True
                )
                raise Exception("File does not downloaded successfuly")

            with open(downloaded_file_path, "r") as file:
                for line in file:
                    try:
                        data = json_repair.loads(line)

                        # Skip if status is present (indicating an error)
                        if data.get("status") or data.get("response")["candidates"][0]['finishReason'] != "STOP":
                            db.update_payload(
                                custom_id=data.get('custom_id'),
                                status="FAILED"
                            )
                            continue

                        response_brut = data.get("response")["candidates"][0]["content"]["parts"][0]["text"]
                        response = (
                            response_brut.replace("```json", "").replace("```", "").strip()
                        )

                        # Extract token usage from response
                        usage_metadata = data.get("response", {}).get("usageMetadata", {})
                        input_tokens = usage_metadata.get("promptTokenCount", 0)
                        output_tokens = usage_metadata.get("candidatesTokenCount", 0)
                        total_token_count = usage_metadata.get("totalTokenCount", 0)

                        # Log token extraction for debugging
                        logging.info(
                            f"Processing custom_id={data.get('custom_id')}: "
                            f"input_tokens={input_tokens}, output_tokens={output_tokens}, "
                            f"total_tokens={total_token_count}, usage_metadata={usage_metadata}"
                        )

                        # Accumulate tokens
                        total_input_tokens += input_tokens
                        total_output_tokens += output_tokens
                        total_tokens += total_token_count

                        db.update_payload(
                            custom_id=data.get('custom_id',''),
                            llm_response=json_repair.loads(response),
                            tokens=total_token_count,
                            input_tokens=input_tokens,
                            output_tokens=output_tokens,
                            status="DONE"
                        )
                    except Exception as e:
                        logging.error(f"Error processing line in file: {e}", exc_info=True)
                        continue

            os.remove(downloaded_file_path)

            # Return token statistics
            token_stats = {
                "total_input_tokens": total_input_tokens,
                "total_output_tokens": total_output_tokens,
                "total_tokens": total_tokens
            }

            logging.info(
                f"File processing complete: {file_path}, "
                f"Aggregated totals - input_tokens={total_input_tokens}, "
                f"output_tokens={total_output_tokens}, total_tokens={total_tokens}"
            )

            return token_stats

        except Exception as e:
            logging.exception(f"exception appeared on process file gemini function : {e}")
            return {
                "total_input_tokens": 0,
                "total_output_tokens": 0,
                "total_tokens": 0
            }

    async def callback(self, request: Request):
        try:
            data = await request.json()
            file_path = data.get("name")

            if not file_path:
                raise ValueError("File path is required")
            
            # in case of multiple files in multiple collections
            request_db = self.db

            if self.gateway:
                collection_name = str(Path(file_path).parts[2]).split("_")[0]
                request_db = self.db.clone_db(batch_collection_name=collection_name)

            try:
                # Process file and get token statistics
                token_stats = await asyncio.to_thread(
                    self._process_file_gemini, Path(file_path), request_db
                )

                # Calculate total cost
                total_cost = self._calculate_cost(
                    token_stats["total_input_tokens"],
                    token_stats["total_output_tokens"]
                )

                # Update file record with token usage and cost
                request_db.update_file(
                    file_path=Path(f"{Path(file_path).parts[2]}.jsonl"),
                    status="DONE",
                    total_input_tokens=token_stats["total_input_tokens"],
                    total_output_tokens=token_stats["total_output_tokens"],
                    total_tokens=token_stats["total_tokens"],
                    total_cost=total_cost
                )

                logging.info(
                    f"File processed: {file_path}, "
                    f"Input tokens: {token_stats['total_input_tokens']}, "
                    f"Output tokens: {token_stats['total_output_tokens']}, "
                    f"Total cost: ${total_cost:.4f}"
                )

                if self.func:
                    await asyncio.to_thread(self.func, Path(file_path))

            except Exception as e:
                logging.exception(f"An error occurred while processing the file : {e}")
                return JSONResponse(
                    content={
                        "message": f"An error occurred while processing the file : {e}"
                    },
                    status_code=500
                )
                    
            return JSONResponse(
                content = {
                    "message": f"Callback completed successfully"
                },
                status_code=200
            )

        except Exception as e:
            logging.exception(f"An error occurred while processing the callback : {e}")
            return JSONResponse(
                content = {
                    "message" : f"An error occurred while processing the callback : {e}"
                },
                status_code=500
            )

    def start_server(self):
        try:
            uvicorn.run(app=self.app, host="0.0.0.0", port=self.port)
        except Exception as e:
            logging.exception(f"error while starting the server : {e}")
