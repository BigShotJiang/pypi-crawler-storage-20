var ja = Object.defineProperty;
var yi = (t) => {
  throw TypeError(t);
};
var Va = (t, e, n) => e in t ? ja(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var q = (t, e, n) => Va(t, typeof e != "symbol" ? e + "" : e, n), Xa = (t, e, n) => e.has(t) || yi("Cannot " + n);
var Ei = (t, e, n) => e.has(t) ? yi("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n);
var At = (t, e, n) => (Xa(t, e, "access private method"), n);
const {
  SvelteComponent: kh,
  append_hydration: Ch,
  attr: Sh,
  children: xh,
  claim_svg_element: Th,
  detach: Bh,
  init: Ih,
  insert_hydration: Rh,
  noop: Lh,
  safe_not_equal: Nh,
  svg_element: Oh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ph,
  append_hydration: Hh,
  attr: Mh,
  children: qh,
  claim_svg_element: Uh,
  detach: zh,
  init: Gh,
  insert_hydration: jh,
  noop: Vh,
  safe_not_equal: Xh,
  svg_element: Zh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wh,
  append_hydration: Yh,
  attr: Qh,
  children: Kh,
  claim_svg_element: Jh,
  detach: e_,
  init: t_,
  insert_hydration: n_,
  noop: i_,
  safe_not_equal: r_,
  svg_element: a_
} = window.__gradio__svelte__internal, {
  SvelteComponent: o_,
  append_hydration: s_,
  attr: l_,
  children: u_,
  claim_svg_element: c_,
  detach: h_,
  init: __,
  insert_hydration: d_,
  noop: f_,
  safe_not_equal: p_,
  svg_element: m_
} = window.__gradio__svelte__internal, {
  SvelteComponent: g_,
  append_hydration: b_,
  attr: v_,
  children: y_,
  claim_svg_element: E_,
  detach: D_,
  init: w_,
  insert_hydration: $_,
  noop: F_,
  safe_not_equal: A_,
  svg_element: k_
} = window.__gradio__svelte__internal, {
  SvelteComponent: C_,
  append_hydration: S_,
  attr: x_,
  children: T_,
  claim_svg_element: B_,
  detach: I_,
  init: R_,
  insert_hydration: L_,
  noop: N_,
  safe_not_equal: O_,
  svg_element: P_
} = window.__gradio__svelte__internal, {
  SvelteComponent: H_,
  append_hydration: M_,
  attr: q_,
  children: U_,
  claim_svg_element: z_,
  detach: G_,
  init: j_,
  insert_hydration: V_,
  noop: X_,
  safe_not_equal: Z_,
  svg_element: W_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y_,
  append_hydration: Q_,
  attr: K_,
  children: J_,
  claim_svg_element: ed,
  detach: td,
  init: nd,
  insert_hydration: id,
  noop: rd,
  safe_not_equal: ad,
  svg_element: od
} = window.__gradio__svelte__internal, {
  SvelteComponent: sd,
  append_hydration: ld,
  attr: ud,
  children: cd,
  claim_svg_element: hd,
  detach: _d,
  init: dd,
  insert_hydration: fd,
  noop: pd,
  safe_not_equal: md,
  svg_element: gd
} = window.__gradio__svelte__internal, {
  SvelteComponent: bd,
  append_hydration: vd,
  attr: yd,
  children: Ed,
  claim_svg_element: Dd,
  detach: wd,
  init: $d,
  insert_hydration: Fd,
  noop: Ad,
  safe_not_equal: kd,
  svg_element: Cd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sd,
  append_hydration: xd,
  attr: Td,
  children: Bd,
  claim_svg_element: Id,
  detach: Rd,
  init: Ld,
  insert_hydration: Nd,
  noop: Od,
  safe_not_equal: Pd,
  svg_element: Hd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Md,
  append_hydration: qd,
  attr: Ud,
  children: zd,
  claim_svg_element: Gd,
  detach: jd,
  init: Vd,
  insert_hydration: Xd,
  noop: Zd,
  safe_not_equal: Wd,
  svg_element: Yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Za,
  append_hydration: cn,
  attr: ve,
  children: kt,
  claim_svg_element: Ct,
  detach: lt,
  init: Wa,
  insert_hydration: Ya,
  noop: hn,
  safe_not_equal: Qa,
  set_style: ke,
  svg_element: St
} = window.__gradio__svelte__internal;
function Ka(t) {
  let e, n, i, r;
  return {
    c() {
      e = St("svg"), n = St("g"), i = St("path"), r = St("path"), this.h();
    },
    l(o) {
      e = Ct(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = kt(e);
      n = Ct(a, "g", { transform: !0 });
      var s = kt(n);
      i = Ct(s, "path", { d: !0, style: !0 }), kt(i).forEach(lt), s.forEach(lt), r = Ct(a, "path", { d: !0, style: !0 }), kt(r).forEach(lt), a.forEach(lt), this.h();
    },
    h() {
      ve(i, "d", "M18,6L6.087,17.913"), ke(i, "fill", "none"), ke(i, "fill-rule", "nonzero"), ke(i, "stroke-width", "2px"), ve(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), ve(r, "d", "M4.364,4.364L19.636,19.636"), ke(r, "fill", "none"), ke(r, "fill-rule", "nonzero"), ke(r, "stroke-width", "2px"), ve(e, "width", "100%"), ve(e, "height", "100%"), ve(e, "viewBox", "0 0 24 24"), ve(e, "version", "1.1"), ve(e, "xmlns", "http://www.w3.org/2000/svg"), ve(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), ve(e, "xml:space", "preserve"), ve(e, "stroke", "currentColor"), ke(e, "fill-rule", "evenodd"), ke(e, "clip-rule", "evenodd"), ke(e, "stroke-linecap", "round"), ke(e, "stroke-linejoin", "round");
    },
    m(o, a) {
      Ya(o, e, a), cn(e, n), cn(n, i), cn(e, r);
    },
    p: hn,
    i: hn,
    o: hn,
    d(o) {
      o && lt(e);
    }
  };
}
class zr extends Za {
  constructor(e) {
    super(), Wa(this, e, null, Ka, Qa, {});
  }
}
const {
  SvelteComponent: Qd,
  append_hydration: Kd,
  attr: Jd,
  children: ef,
  claim_svg_element: tf,
  claim_text: nf,
  detach: rf,
  init: af,
  insert_hydration: of,
  noop: sf,
  safe_not_equal: lf,
  svg_element: uf,
  text: cf
} = window.__gradio__svelte__internal, {
  SvelteComponent: hf,
  append_hydration: _f,
  attr: df,
  children: ff,
  claim_svg_element: pf,
  detach: mf,
  init: gf,
  insert_hydration: bf,
  noop: vf,
  safe_not_equal: yf,
  svg_element: Ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: Df,
  append_hydration: wf,
  attr: $f,
  children: Ff,
  claim_svg_element: Af,
  detach: kf,
  init: Cf,
  insert_hydration: Sf,
  noop: xf,
  safe_not_equal: Tf,
  svg_element: Bf
} = window.__gradio__svelte__internal, {
  SvelteComponent: If,
  append_hydration: Rf,
  attr: Lf,
  children: Nf,
  claim_svg_element: Of,
  detach: Pf,
  init: Hf,
  insert_hydration: Mf,
  noop: qf,
  safe_not_equal: Uf,
  svg_element: zf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gf,
  append_hydration: jf,
  attr: Vf,
  children: Xf,
  claim_svg_element: Zf,
  detach: Wf,
  init: Yf,
  insert_hydration: Qf,
  noop: Kf,
  safe_not_equal: Jf,
  svg_element: ep
} = window.__gradio__svelte__internal, {
  SvelteComponent: tp,
  append_hydration: np,
  attr: ip,
  children: rp,
  claim_svg_element: ap,
  detach: op,
  init: sp,
  insert_hydration: lp,
  noop: up,
  safe_not_equal: cp,
  svg_element: hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: _p,
  append_hydration: dp,
  attr: fp,
  children: pp,
  claim_svg_element: mp,
  detach: gp,
  init: bp,
  insert_hydration: vp,
  noop: yp,
  safe_not_equal: Ep,
  svg_element: Dp
} = window.__gradio__svelte__internal, {
  SvelteComponent: wp,
  append_hydration: $p,
  attr: Fp,
  children: Ap,
  claim_svg_element: kp,
  detach: Cp,
  init: Sp,
  insert_hydration: xp,
  noop: Tp,
  safe_not_equal: Bp,
  svg_element: Ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rp,
  append_hydration: Lp,
  attr: Np,
  children: Op,
  claim_svg_element: Pp,
  detach: Hp,
  init: Mp,
  insert_hydration: qp,
  noop: Up,
  safe_not_equal: zp,
  svg_element: Gp
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: Vp,
  attr: Xp,
  children: Zp,
  claim_svg_element: Wp,
  detach: Yp,
  init: Qp,
  insert_hydration: Kp,
  noop: Jp,
  safe_not_equal: em,
  svg_element: tm
} = window.__gradio__svelte__internal, {
  SvelteComponent: nm,
  append_hydration: im,
  attr: rm,
  children: am,
  claim_svg_element: om,
  detach: sm,
  init: lm,
  insert_hydration: um,
  noop: cm,
  safe_not_equal: hm,
  svg_element: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: dm,
  append_hydration: fm,
  attr: pm,
  children: mm,
  claim_svg_element: gm,
  detach: bm,
  init: vm,
  insert_hydration: ym,
  noop: Em,
  safe_not_equal: Dm,
  svg_element: wm
} = window.__gradio__svelte__internal, {
  SvelteComponent: $m,
  append_hydration: Fm,
  attr: Am,
  children: km,
  claim_svg_element: Cm,
  detach: Sm,
  init: xm,
  insert_hydration: Tm,
  noop: Bm,
  safe_not_equal: Im,
  svg_element: Rm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lm,
  append_hydration: Nm,
  attr: Om,
  children: Pm,
  claim_svg_element: Hm,
  detach: Mm,
  init: qm,
  insert_hydration: Um,
  noop: zm,
  safe_not_equal: Gm,
  svg_element: jm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vm,
  append_hydration: Xm,
  attr: Zm,
  children: Wm,
  claim_svg_element: Ym,
  detach: Qm,
  init: Km,
  insert_hydration: Jm,
  noop: e0,
  safe_not_equal: t0,
  svg_element: n0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ja,
  append_hydration: Di,
  attr: ce,
  children: _n,
  claim_svg_element: dn,
  detach: xt,
  init: eo,
  insert_hydration: to,
  noop: fn,
  safe_not_equal: no,
  svg_element: pn
} = window.__gradio__svelte__internal;
function io(t) {
  let e, n, i;
  return {
    c() {
      e = pn("svg"), n = pn("path"), i = pn("polyline"), this.h();
    },
    l(r) {
      e = dn(r, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var o = _n(e);
      n = dn(o, "path", { d: !0 }), _n(n).forEach(xt), i = dn(o, "polyline", { points: !0 }), _n(i).forEach(xt), o.forEach(xt), this.h();
    },
    h() {
      ce(n, "d", "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"), ce(i, "points", "13 2 13 9 20 9"), ce(e, "xmlns", "http://www.w3.org/2000/svg"), ce(e, "width", "100%"), ce(e, "height", "100%"), ce(e, "viewBox", "0 0 24 24"), ce(e, "fill", "none"), ce(e, "stroke", "currentColor"), ce(e, "stroke-width", "1.5"), ce(e, "stroke-linecap", "round"), ce(e, "stroke-linejoin", "round"), ce(e, "class", "feather feather-file");
    },
    m(r, o) {
      to(r, e, o), Di(e, n), Di(e, i);
    },
    p: fn,
    i: fn,
    o: fn,
    d(r) {
      r && xt(e);
    }
  };
}
class ro extends Ja {
  constructor(e) {
    super(), eo(this, e, null, io, no, {});
  }
}
const {
  SvelteComponent: i0,
  append_hydration: r0,
  attr: a0,
  children: o0,
  claim_svg_element: s0,
  detach: l0,
  init: u0,
  insert_hydration: c0,
  noop: h0,
  safe_not_equal: _0,
  svg_element: d0
} = window.__gradio__svelte__internal, {
  SvelteComponent: f0,
  append_hydration: p0,
  attr: m0,
  children: g0,
  claim_svg_element: b0,
  detach: v0,
  init: y0,
  insert_hydration: E0,
  noop: D0,
  safe_not_equal: w0,
  svg_element: $0
} = window.__gradio__svelte__internal, {
  SvelteComponent: F0,
  append_hydration: A0,
  attr: k0,
  children: C0,
  claim_svg_element: S0,
  detach: x0,
  init: T0,
  insert_hydration: B0,
  noop: I0,
  safe_not_equal: R0,
  svg_element: L0
} = window.__gradio__svelte__internal, {
  SvelteComponent: N0,
  append_hydration: O0,
  attr: P0,
  children: H0,
  claim_svg_element: M0,
  detach: q0,
  init: U0,
  insert_hydration: z0,
  noop: G0,
  safe_not_equal: j0,
  svg_element: V0
} = window.__gradio__svelte__internal, {
  SvelteComponent: X0,
  append_hydration: Z0,
  attr: W0,
  children: Y0,
  claim_svg_element: Q0,
  detach: K0,
  init: J0,
  insert_hydration: eg,
  noop: tg,
  safe_not_equal: ng,
  svg_element: ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: rg,
  append_hydration: ag,
  attr: og,
  children: sg,
  claim_svg_element: lg,
  detach: ug,
  init: cg,
  insert_hydration: hg,
  noop: _g,
  safe_not_equal: dg,
  svg_element: fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: pg,
  append_hydration: mg,
  attr: gg,
  children: bg,
  claim_svg_element: vg,
  detach: yg,
  init: Eg,
  insert_hydration: Dg,
  noop: wg,
  safe_not_equal: $g,
  svg_element: Fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ag,
  append_hydration: kg,
  attr: Cg,
  children: Sg,
  claim_svg_element: xg,
  detach: Tg,
  init: Bg,
  insert_hydration: Ig,
  noop: Rg,
  safe_not_equal: Lg,
  svg_element: Ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: Og,
  append_hydration: Pg,
  attr: Hg,
  children: Mg,
  claim_svg_element: qg,
  detach: Ug,
  init: zg,
  insert_hydration: Gg,
  noop: jg,
  safe_not_equal: Vg,
  svg_element: Xg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zg,
  append_hydration: Wg,
  attr: Yg,
  children: Qg,
  claim_svg_element: Kg,
  detach: Jg,
  init: e1,
  insert_hydration: t1,
  noop: n1,
  safe_not_equal: i1,
  svg_element: r1
} = window.__gradio__svelte__internal, {
  SvelteComponent: a1,
  append_hydration: o1,
  attr: s1,
  children: l1,
  claim_svg_element: u1,
  detach: c1,
  init: h1,
  insert_hydration: _1,
  noop: d1,
  safe_not_equal: f1,
  svg_element: p1
} = window.__gradio__svelte__internal, {
  SvelteComponent: m1,
  append_hydration: g1,
  attr: b1,
  children: v1,
  claim_svg_element: y1,
  detach: E1,
  init: D1,
  insert_hydration: w1,
  noop: $1,
  safe_not_equal: F1,
  svg_element: A1
} = window.__gradio__svelte__internal, {
  SvelteComponent: k1,
  append_hydration: C1,
  attr: S1,
  children: x1,
  claim_svg_element: T1,
  detach: B1,
  init: I1,
  insert_hydration: R1,
  noop: L1,
  safe_not_equal: N1,
  svg_element: O1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append_hydration: H1,
  attr: M1,
  children: q1,
  claim_svg_element: U1,
  detach: z1,
  init: G1,
  insert_hydration: j1,
  noop: V1,
  safe_not_equal: X1,
  svg_element: Z1
} = window.__gradio__svelte__internal, {
  SvelteComponent: W1,
  append_hydration: Y1,
  attr: Q1,
  children: K1,
  claim_svg_element: J1,
  detach: eb,
  init: tb,
  insert_hydration: nb,
  noop: ib,
  safe_not_equal: rb,
  svg_element: ab
} = window.__gradio__svelte__internal, {
  SvelteComponent: ob,
  append_hydration: sb,
  attr: lb,
  children: ub,
  claim_svg_element: cb,
  detach: hb,
  init: _b,
  insert_hydration: db,
  noop: fb,
  safe_not_equal: pb,
  svg_element: mb
} = window.__gradio__svelte__internal, {
  SvelteComponent: gb,
  append_hydration: bb,
  attr: vb,
  children: yb,
  claim_svg_element: Eb,
  detach: Db,
  init: wb,
  insert_hydration: $b,
  noop: Fb,
  safe_not_equal: Ab,
  svg_element: kb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cb,
  append_hydration: Sb,
  attr: xb,
  children: Tb,
  claim_svg_element: Bb,
  detach: Ib,
  init: Rb,
  insert_hydration: Lb,
  noop: Nb,
  safe_not_equal: Ob,
  svg_element: Pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hb,
  append_hydration: Mb,
  attr: qb,
  children: Ub,
  claim_svg_element: zb,
  detach: Gb,
  init: jb,
  insert_hydration: Vb,
  noop: Xb,
  safe_not_equal: Zb,
  set_style: Wb,
  svg_element: Yb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qb,
  append_hydration: Kb,
  attr: Jb,
  children: ev,
  claim_svg_element: tv,
  detach: nv,
  init: iv,
  insert_hydration: rv,
  noop: av,
  safe_not_equal: ov,
  svg_element: sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: lv,
  append_hydration: uv,
  attr: cv,
  children: hv,
  claim_svg_element: _v,
  detach: dv,
  init: fv,
  insert_hydration: pv,
  noop: mv,
  safe_not_equal: gv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append_hydration: yv,
  attr: Ev,
  children: Dv,
  claim_svg_element: wv,
  detach: $v,
  init: Fv,
  insert_hydration: Av,
  noop: kv,
  safe_not_equal: Cv,
  svg_element: Sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: xv,
  append_hydration: Tv,
  attr: Bv,
  children: Iv,
  claim_svg_element: Rv,
  detach: Lv,
  init: Nv,
  insert_hydration: Ov,
  noop: Pv,
  safe_not_equal: Hv,
  svg_element: Mv
} = window.__gradio__svelte__internal, {
  SvelteComponent: qv,
  append_hydration: Uv,
  attr: zv,
  children: Gv,
  claim_svg_element: jv,
  detach: Vv,
  init: Xv,
  insert_hydration: Zv,
  noop: Wv,
  safe_not_equal: Yv,
  svg_element: Qv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kv,
  append_hydration: Jv,
  attr: ey,
  children: ty,
  claim_svg_element: ny,
  detach: iy,
  init: ry,
  insert_hydration: ay,
  noop: oy,
  safe_not_equal: sy,
  svg_element: ly
} = window.__gradio__svelte__internal, {
  SvelteComponent: uy,
  append_hydration: cy,
  attr: hy,
  children: _y,
  claim_svg_element: dy,
  detach: fy,
  init: py,
  insert_hydration: my,
  noop: gy,
  safe_not_equal: by,
  svg_element: vy
} = window.__gradio__svelte__internal, {
  SvelteComponent: yy,
  append_hydration: Ey,
  attr: Dy,
  children: wy,
  claim_svg_element: $y,
  detach: Fy,
  init: Ay,
  insert_hydration: ky,
  noop: Cy,
  safe_not_equal: Sy,
  svg_element: xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ty,
  append_hydration: By,
  attr: Iy,
  children: Ry,
  claim_svg_element: Ly,
  claim_text: Ny,
  detach: Oy,
  init: Py,
  insert_hydration: Hy,
  noop: My,
  safe_not_equal: qy,
  svg_element: Uy,
  text: zy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gy,
  append_hydration: jy,
  attr: Vy,
  children: Xy,
  claim_svg_element: Zy,
  detach: Wy,
  init: Yy,
  insert_hydration: Qy,
  noop: Ky,
  safe_not_equal: Jy,
  svg_element: eE
} = window.__gradio__svelte__internal, {
  SvelteComponent: tE,
  append_hydration: nE,
  attr: iE,
  children: rE,
  claim_svg_element: aE,
  detach: oE,
  init: sE,
  insert_hydration: lE,
  noop: uE,
  safe_not_equal: cE,
  svg_element: hE
} = window.__gradio__svelte__internal, {
  SvelteComponent: _E,
  append_hydration: dE,
  attr: fE,
  children: pE,
  claim_svg_element: mE,
  detach: gE,
  init: bE,
  insert_hydration: vE,
  noop: yE,
  safe_not_equal: EE,
  svg_element: DE
} = window.__gradio__svelte__internal, {
  SvelteComponent: wE,
  append_hydration: $E,
  attr: FE,
  children: AE,
  claim_svg_element: kE,
  detach: CE,
  init: SE,
  insert_hydration: xE,
  noop: TE,
  safe_not_equal: BE,
  svg_element: IE
} = window.__gradio__svelte__internal, {
  SvelteComponent: RE,
  append_hydration: LE,
  attr: NE,
  children: OE,
  claim_svg_element: PE,
  detach: HE,
  init: ME,
  insert_hydration: qE,
  noop: UE,
  safe_not_equal: zE,
  svg_element: GE
} = window.__gradio__svelte__internal, {
  SvelteComponent: jE,
  append_hydration: VE,
  attr: XE,
  children: ZE,
  claim_svg_element: WE,
  detach: YE,
  init: QE,
  insert_hydration: KE,
  noop: JE,
  safe_not_equal: e2,
  svg_element: t2
} = window.__gradio__svelte__internal, {
  SvelteComponent: n2,
  append_hydration: i2,
  attr: r2,
  children: a2,
  claim_svg_element: o2,
  detach: s2,
  init: l2,
  insert_hydration: u2,
  noop: c2,
  safe_not_equal: h2,
  svg_element: _2
} = window.__gradio__svelte__internal, {
  SvelteComponent: d2,
  append_hydration: f2,
  attr: p2,
  children: m2,
  claim_svg_element: g2,
  claim_text: b2,
  detach: v2,
  init: y2,
  insert_hydration: E2,
  noop: D2,
  safe_not_equal: w2,
  svg_element: $2,
  text: F2
} = window.__gradio__svelte__internal, {
  SvelteComponent: A2,
  append_hydration: k2,
  attr: C2,
  children: S2,
  claim_svg_element: x2,
  claim_text: T2,
  detach: B2,
  init: I2,
  insert_hydration: R2,
  noop: L2,
  safe_not_equal: N2,
  svg_element: O2,
  text: P2
} = window.__gradio__svelte__internal, {
  SvelteComponent: H2,
  append_hydration: M2,
  attr: q2,
  children: U2,
  claim_svg_element: z2,
  claim_text: G2,
  detach: j2,
  init: V2,
  insert_hydration: X2,
  noop: Z2,
  safe_not_equal: W2,
  svg_element: Y2,
  text: Q2
} = window.__gradio__svelte__internal, {
  SvelteComponent: K2,
  append_hydration: J2,
  attr: eD,
  children: tD,
  claim_svg_element: nD,
  detach: iD,
  init: rD,
  insert_hydration: aD,
  noop: oD,
  safe_not_equal: sD,
  svg_element: lD
} = window.__gradio__svelte__internal, {
  SvelteComponent: uD,
  append_hydration: cD,
  attr: hD,
  children: _D,
  claim_svg_element: dD,
  detach: fD,
  init: pD,
  insert_hydration: mD,
  noop: gD,
  safe_not_equal: bD,
  svg_element: vD
} = window.__gradio__svelte__internal, {
  SvelteComponent: yD,
  append_hydration: ED,
  attr: DD,
  children: wD,
  claim_svg_element: $D,
  detach: FD,
  init: AD,
  insert_hydration: kD,
  noop: CD,
  safe_not_equal: SD,
  svg_element: xD
} = window.__gradio__svelte__internal, {
  SvelteComponent: TD,
  append_hydration: BD,
  attr: ID,
  children: RD,
  claim_svg_element: LD,
  detach: ND,
  init: OD,
  insert_hydration: PD,
  noop: HD,
  safe_not_equal: MD,
  svg_element: qD
} = window.__gradio__svelte__internal, {
  SvelteComponent: UD,
  append_hydration: zD,
  attr: GD,
  children: jD,
  claim_svg_element: VD,
  detach: XD,
  init: ZD,
  insert_hydration: WD,
  noop: YD,
  safe_not_equal: QD,
  svg_element: KD
} = window.__gradio__svelte__internal, {
  SvelteComponent: JD,
  append_hydration: ew,
  attr: tw,
  children: nw,
  claim_svg_element: iw,
  detach: rw,
  init: aw,
  insert_hydration: ow,
  noop: sw,
  safe_not_equal: lw,
  svg_element: uw
} = window.__gradio__svelte__internal, {
  SvelteComponent: cw,
  append_hydration: hw,
  attr: _w,
  children: dw,
  claim_svg_element: fw,
  detach: pw,
  init: mw,
  insert_hydration: gw,
  noop: bw,
  safe_not_equal: vw,
  svg_element: yw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ew,
  append_hydration: Dw,
  attr: ww,
  children: $w,
  claim_svg_element: Fw,
  detach: Aw,
  init: kw,
  insert_hydration: Cw,
  noop: Sw,
  safe_not_equal: xw,
  svg_element: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bw,
  append_hydration: Iw,
  attr: Rw,
  children: Lw,
  claim_svg_element: Nw,
  detach: Ow,
  init: Pw,
  insert_hydration: Hw,
  noop: Mw,
  safe_not_equal: qw,
  svg_element: Uw
} = window.__gradio__svelte__internal, {
  SvelteComponent: zw,
  append_hydration: Gw,
  attr: jw,
  children: Vw,
  claim_svg_element: Xw,
  detach: Zw,
  init: Ww,
  insert_hydration: Yw,
  noop: Qw,
  safe_not_equal: Kw,
  svg_element: Jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: e$,
  append_hydration: t$,
  attr: n$,
  children: i$,
  claim_svg_element: r$,
  detach: a$,
  init: o$,
  insert_hydration: s$,
  noop: l$,
  safe_not_equal: u$,
  svg_element: c$
} = window.__gradio__svelte__internal, {
  SvelteComponent: ao,
  append_hydration: Nn,
  assign: oo,
  attr: Y,
  binding_callbacks: so,
  children: ht,
  claim_element: Gr,
  claim_space: jr,
  claim_svg_element: mn,
  create_slot: lo,
  detach: Ce,
  element: Vr,
  empty: wi,
  get_all_dirty_from_scope: uo,
  get_slot_changes: co,
  get_spread_update: ho,
  init: _o,
  insert_hydration: pt,
  listen: fo,
  noop: po,
  safe_not_equal: mo,
  set_dynamic_element_data: $i,
  set_style: O,
  space: Xr,
  svg_element: gn,
  toggle_class: X,
  transition_in: Zr,
  transition_out: Wr,
  update_slot_base: go
} = window.__gradio__svelte__internal;
function Fi(t) {
  let e, n, i, r, o;
  return {
    c() {
      e = gn("svg"), n = gn("line"), i = gn("line"), this.h();
    },
    l(a) {
      e = mn(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var s = ht(e);
      n = mn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), ht(n).forEach(Ce), i = mn(s, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), ht(i).forEach(Ce), s.forEach(Ce), this.h();
    },
    h() {
      Y(n, "x1", "1"), Y(n, "y1", "9"), Y(n, "x2", "9"), Y(n, "y2", "1"), Y(n, "stroke", "gray"), Y(n, "stroke-width", "0.5"), Y(i, "x1", "5"), Y(i, "y1", "9"), Y(i, "x2", "9"), Y(i, "y2", "5"), Y(i, "stroke", "gray"), Y(i, "stroke-width", "0.5"), Y(e, "class", "resize-handle svelte-239wnu"), Y(e, "xmlns", "http://www.w3.org/2000/svg"), Y(e, "viewBox", "0 0 10 10");
    },
    m(a, s) {
      pt(a, e, s), Nn(e, n), Nn(e, i), r || (o = fo(
        e,
        "mousedown",
        /*resize*/
        t[27]
      ), r = !0);
    },
    p: po,
    d(a) {
      a && Ce(e), r = !1, o();
    }
  };
}
function bo(t) {
  var _;
  let e, n, i, r, o;
  const a = (
    /*#slots*/
    t[31].default
  ), s = lo(
    a,
    t,
    /*$$scope*/
    t[30],
    null
  );
  let l = (
    /*resizable*/
    t[19] && Fi(t)
  ), u = [
    { "data-testid": (
      /*test_id*/
      t[11]
    ) },
    { id: (
      /*elem_id*/
      t[6]
    ) },
    {
      class: i = "block " + /*elem_classes*/
      (((_ = t[7]) == null ? void 0 : _.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: r = /*rtl*/
      t[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let h = 0; h < u.length; h += 1)
    c = oo(c, u[h]);
  return {
    c() {
      e = Vr(
        /*tag*/
        t[25]
      ), s && s.c(), n = Xr(), l && l.c(), this.h();
    },
    l(h) {
      e = Gr(
        h,
        /*tag*/
        (t[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var p = ht(e);
      s && s.l(p), n = jr(p), l && l.l(p), p.forEach(Ce), this.h();
    },
    h() {
      $i(
        /*tag*/
        t[25]
      )(e, c), X(
        e,
        "hidden",
        /*visible*/
        t[14] === !1 || /*visible*/
        t[14] === "hidden"
      ), X(
        e,
        "padded",
        /*padding*/
        t[10]
      ), X(
        e,
        "flex",
        /*flex*/
        t[1]
      ), X(
        e,
        "border_focus",
        /*border_mode*/
        t[9] === "focus"
      ), X(
        e,
        "border_contrast",
        /*border_mode*/
        t[9] === "contrast"
      ), X(e, "hide-container", !/*explicit_call*/
      t[12] && !/*container*/
      t[13]), X(
        e,
        "fullscreen",
        /*fullscreen*/
        t[0]
      ), X(
        e,
        "animating",
        /*fullscreen*/
        t[0] && /*preexpansionBoundingRect*/
        t[24] !== null
      ), X(
        e,
        "auto-margin",
        /*scale*/
        t[17] === null
      ), O(
        e,
        "height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*height*/
            t[2]
          )
        )
      ), O(
        e,
        "min-height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*min_height*/
            t[3]
          )
        )
      ), O(
        e,
        "max-height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*max_height*/
            t[4]
          )
        )
      ), O(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].top}px` : "0px"
      ), O(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].left}px` : "0px"
      ), O(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].width}px` : "0px"
      ), O(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].height}px` : "0px"
      ), O(
        e,
        "width",
        /*fullscreen*/
        t[0] ? void 0 : typeof /*width*/
        t[5] == "number" ? `calc(min(${/*width*/
        t[5]}px, 100%))` : (
          /*get_dimension*/
          t[26](
            /*width*/
            t[5]
          )
        )
      ), O(
        e,
        "border-style",
        /*variant*/
        t[8]
      ), O(
        e,
        "overflow",
        /*allow_overflow*/
        t[15] ? (
          /*overflow_behavior*/
          t[16]
        ) : "hidden"
      ), O(
        e,
        "flex-grow",
        /*scale*/
        t[17]
      ), O(e, "min-width", `calc(min(${/*min_width*/
      t[18]}px, 100%))`), O(e, "border-width", "var(--block-border-width)");
    },
    m(h, p) {
      pt(h, e, p), s && s.m(e, null), Nn(e, n), l && l.m(e, null), t[32](e), o = !0;
    },
    p(h, p) {
      var b;
      s && s.p && (!o || p[0] & /*$$scope*/
      1073741824) && go(
        s,
        a,
        h,
        /*$$scope*/
        h[30],
        o ? co(
          a,
          /*$$scope*/
          h[30],
          p,
          null
        ) : uo(
          /*$$scope*/
          h[30]
        ),
        null
      ), /*resizable*/
      h[19] ? l ? l.p(h, p) : (l = Fi(h), l.c(), l.m(e, null)) : l && (l.d(1), l = null), $i(
        /*tag*/
        h[25]
      )(e, c = ho(u, [
        (!o || p[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          h[11]
        ) },
        (!o || p[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          h[6]
        ) },
        (!o || p[0] & /*elem_classes*/
        128 && i !== (i = "block " + /*elem_classes*/
        (((b = h[7]) == null ? void 0 : b.join(" ")) || "") + " svelte-239wnu")) && { class: i },
        (!o || p[0] & /*rtl*/
        1048576 && r !== (r = /*rtl*/
        h[20] ? "rtl" : "ltr")) && { dir: r }
      ])), X(
        e,
        "hidden",
        /*visible*/
        h[14] === !1 || /*visible*/
        h[14] === "hidden"
      ), X(
        e,
        "padded",
        /*padding*/
        h[10]
      ), X(
        e,
        "flex",
        /*flex*/
        h[1]
      ), X(
        e,
        "border_focus",
        /*border_mode*/
        h[9] === "focus"
      ), X(
        e,
        "border_contrast",
        /*border_mode*/
        h[9] === "contrast"
      ), X(e, "hide-container", !/*explicit_call*/
      h[12] && !/*container*/
      h[13]), X(
        e,
        "fullscreen",
        /*fullscreen*/
        h[0]
      ), X(
        e,
        "animating",
        /*fullscreen*/
        h[0] && /*preexpansionBoundingRect*/
        h[24] !== null
      ), X(
        e,
        "auto-margin",
        /*scale*/
        h[17] === null
      ), p[0] & /*fullscreen, height*/
      5 && O(
        e,
        "height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*height*/
            h[2]
          )
        )
      ), p[0] & /*fullscreen, min_height*/
      9 && O(
        e,
        "min-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*min_height*/
            h[3]
          )
        )
      ), p[0] & /*fullscreen, max_height*/
      17 && O(
        e,
        "max-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*max_height*/
            h[4]
          )
        )
      ), p[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].top}px` : "0px"
      ), p[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].left}px` : "0px"
      ), p[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].width}px` : "0px"
      ), p[0] & /*preexpansionBoundingRect*/
      16777216 && O(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].height}px` : "0px"
      ), p[0] & /*fullscreen, width*/
      33 && O(
        e,
        "width",
        /*fullscreen*/
        h[0] ? void 0 : typeof /*width*/
        h[5] == "number" ? `calc(min(${/*width*/
        h[5]}px, 100%))` : (
          /*get_dimension*/
          h[26](
            /*width*/
            h[5]
          )
        )
      ), p[0] & /*variant*/
      256 && O(
        e,
        "border-style",
        /*variant*/
        h[8]
      ), p[0] & /*allow_overflow, overflow_behavior*/
      98304 && O(
        e,
        "overflow",
        /*allow_overflow*/
        h[15] ? (
          /*overflow_behavior*/
          h[16]
        ) : "hidden"
      ), p[0] & /*scale*/
      131072 && O(
        e,
        "flex-grow",
        /*scale*/
        h[17]
      ), p[0] & /*min_width*/
      262144 && O(e, "min-width", `calc(min(${/*min_width*/
      h[18]}px, 100%))`);
    },
    i(h) {
      o || (Zr(s, h), o = !0);
    },
    o(h) {
      Wr(s, h), o = !1;
    },
    d(h) {
      h && Ce(e), s && s.d(h), l && l.d(), t[32](null);
    }
  };
}
function Ai(t) {
  let e;
  return {
    c() {
      e = Vr("div"), this.h();
    },
    l(n) {
      e = Gr(n, "DIV", { class: !0 }), ht(e).forEach(Ce), this.h();
    },
    h() {
      Y(e, "class", "placeholder svelte-239wnu"), O(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), O(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    m(n, i) {
      pt(n, e, i);
    },
    p(n, i) {
      i[0] & /*placeholder_height*/
      4194304 && O(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), i[0] & /*placeholder_width*/
      8388608 && O(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    d(n) {
      n && Ce(e);
    }
  };
}
function vo(t) {
  let e, n, i, r = (
    /*tag*/
    t[25] && bo(t)
  ), o = (
    /*fullscreen*/
    t[0] && Ai(t)
  );
  return {
    c() {
      r && r.c(), e = Xr(), o && o.c(), n = wi();
    },
    l(a) {
      r && r.l(a), e = jr(a), o && o.l(a), n = wi();
    },
    m(a, s) {
      r && r.m(a, s), pt(a, e, s), o && o.m(a, s), pt(a, n, s), i = !0;
    },
    p(a, s) {
      /*tag*/
      a[25] && r.p(a, s), /*fullscreen*/
      a[0] ? o ? o.p(a, s) : (o = Ai(a), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null);
    },
    i(a) {
      i || (Zr(r, a), i = !0);
    },
    o(a) {
      Wr(r, a), i = !1;
    },
    d(a) {
      a && (Ce(e), Ce(n)), r && r.d(a), o && o.d(a);
    }
  };
}
function yo(t, e, n) {
  let { $$slots: i = {}, $$scope: r } = e, { height: o = void 0 } = e, { min_height: a = void 0 } = e, { max_height: s = void 0 } = e, { width: l = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: _ = "solid" } = e, { border_mode: h = "base" } = e, { padding: p = !0 } = e, { type: b = "normal" } = e, { test_id: y = void 0 } = e, { explicit_call: E = !1 } = e, { container: $ = !0 } = e, { visible: m = !0 } = e, { allow_overflow: d = !0 } = e, { overflow_behavior: f = "auto" } = e, { scale: v = null } = e, { min_width: g = 0 } = e, { flex: D = !1 } = e, { resizable: C = !1 } = e, { rtl: F = !1 } = e, { fullscreen: x = !1 } = e, w = x, L, re = b === "fieldset" ? "fieldset" : "div", te = 0, be = 0, j = null;
  function Q(A) {
    x && A.key === "Escape" && n(0, x = !1);
  }
  const M = (A) => {
    if (A !== void 0) {
      if (typeof A == "number")
        return A + "px";
      if (typeof A == "string")
        return A;
    }
  }, K = (A) => {
    let Z = A.clientY;
    const Te = (Ae) => {
      const Re = Ae.clientY - Z;
      Z = Ae.clientY, n(21, L.style.height = `${L.offsetHeight + Re}px`, L);
    }, ae = () => {
      window.removeEventListener("mousemove", Te), window.removeEventListener("mouseup", ae);
    };
    window.addEventListener("mousemove", Te), window.addEventListener("mouseup", ae);
  };
  function Fe(A) {
    so[A ? "unshift" : "push"](() => {
      L = A, n(21, L);
    });
  }
  return t.$$set = (A) => {
    "height" in A && n(2, o = A.height), "min_height" in A && n(3, a = A.min_height), "max_height" in A && n(4, s = A.max_height), "width" in A && n(5, l = A.width), "elem_id" in A && n(6, u = A.elem_id), "elem_classes" in A && n(7, c = A.elem_classes), "variant" in A && n(8, _ = A.variant), "border_mode" in A && n(9, h = A.border_mode), "padding" in A && n(10, p = A.padding), "type" in A && n(28, b = A.type), "test_id" in A && n(11, y = A.test_id), "explicit_call" in A && n(12, E = A.explicit_call), "container" in A && n(13, $ = A.container), "visible" in A && n(14, m = A.visible), "allow_overflow" in A && n(15, d = A.allow_overflow), "overflow_behavior" in A && n(16, f = A.overflow_behavior), "scale" in A && n(17, v = A.scale), "min_width" in A && n(18, g = A.min_width), "flex" in A && n(1, D = A.flex), "resizable" in A && n(19, C = A.resizable), "rtl" in A && n(20, F = A.rtl), "fullscreen" in A && n(0, x = A.fullscreen), "$$scope" in A && n(30, r = A.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && x !== w && (n(29, w = x), x ? (n(24, j = L.getBoundingClientRect()), n(22, te = L.offsetHeight), n(23, be = L.offsetWidth), window.addEventListener("keydown", Q)) : (n(24, j = null), window.removeEventListener("keydown", Q))), t.$$.dirty[0] & /*visible*/
    16384 && (m || n(1, D = !1));
  }, [
    x,
    D,
    o,
    a,
    s,
    l,
    u,
    c,
    _,
    h,
    p,
    y,
    E,
    $,
    m,
    d,
    f,
    v,
    g,
    C,
    F,
    L,
    te,
    be,
    j,
    re,
    M,
    K,
    b,
    w,
    r,
    i,
    Fe
  ];
}
class Eo extends ao {
  constructor(e) {
    super(), _o(
      this,
      e,
      yo,
      vo,
      mo,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function ti() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let ze = ti();
function Yr(t) {
  ze = t;
}
const Qr = /[&<>"']/, Do = new RegExp(Qr.source, "g"), Kr = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, wo = new RegExp(Kr.source, "g"), $o = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, ki = (t) => $o[t];
function se(t, e) {
  if (e) {
    if (Qr.test(t))
      return t.replace(Do, ki);
  } else if (Kr.test(t))
    return t.replace(wo, ki);
  return t;
}
const Fo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Ao(t) {
  return t.replace(Fo, (e, n) => (n = n.toLowerCase(), n === "colon" ? ":" : n.charAt(0) === "#" ? n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1)) : ""));
}
const ko = /(^|[^\[])\^/g;
function H(t, e) {
  let n = typeof t == "string" ? t : t.source;
  e = e || "";
  const i = {
    replace: (r, o) => {
      let a = typeof o == "string" ? o : o.source;
      return a = a.replace(ko, "$1"), n = n.replace(r, a), i;
    },
    getRegex: () => new RegExp(n, e)
  };
  return i;
}
function Ci(t) {
  try {
    t = encodeURI(t).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return t;
}
const _t = { exec: () => null };
function Si(t, e) {
  const n = t.replace(/\|/g, (o, a, s) => {
    let l = !1, u = a;
    for (; --u >= 0 && s[u] === "\\"; )
      l = !l;
    return l ? "|" : " |";
  }), i = n.split(/ \|/);
  let r = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i[i.length - 1].trim() && i.pop(), e)
    if (i.length > e)
      i.splice(e);
    else
      for (; i.length < e; )
        i.push("");
  for (; r < i.length; r++)
    i[r] = i[r].trim().replace(/\\\|/g, "|");
  return i;
}
function Tt(t, e, n) {
  const i = t.length;
  if (i === 0)
    return "";
  let r = 0;
  for (; r < i && t.charAt(i - r - 1) === e; )
    r++;
  return t.slice(0, i - r);
}
function Co(t, e) {
  if (t.indexOf(e[1]) === -1)
    return -1;
  let n = 0;
  for (let i = 0; i < t.length; i++)
    if (t[i] === "\\")
      i++;
    else if (t[i] === e[0])
      n++;
    else if (t[i] === e[1] && (n--, n < 0))
      return i;
  return -1;
}
function xi(t, e, n, i) {
  const r = e.href, o = e.title ? se(e.title) : null, a = t[1].replace(/\\([\[\]])/g, "$1");
  if (t[0].charAt(0) !== "!") {
    i.state.inLink = !0;
    const s = {
      type: "link",
      raw: n,
      href: r,
      title: o,
      text: a,
      tokens: i.inlineTokens(a)
    };
    return i.state.inLink = !1, s;
  }
  return {
    type: "image",
    raw: n,
    href: r,
    title: o,
    text: se(a)
  };
}
function So(t, e) {
  const n = t.match(/^(\s+)(?:```)/);
  if (n === null)
    return e;
  const i = n[1];
  return e.split(`
`).map((r) => {
    const o = r.match(/^\s+/);
    if (o === null)
      return r;
    const [a] = o;
    return a.length >= i.length ? r.slice(i.length) : r;
  }).join(`
`);
}
class Ut {
  // set by the lexer
  constructor(e) {
    q(this, "options");
    q(this, "rules");
    // set by the lexer
    q(this, "lexer");
    this.options = e || ze;
  }
  space(e) {
    const n = this.rules.block.newline.exec(e);
    if (n && n[0].length > 0)
      return {
        type: "space",
        raw: n[0]
      };
  }
  code(e) {
    const n = this.rules.block.code.exec(e);
    if (n) {
      const i = n[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: n[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? i : Tt(i, `
`)
      };
    }
  }
  fences(e) {
    const n = this.rules.block.fences.exec(e);
    if (n) {
      const i = n[0], r = So(i, n[3] || "");
      return {
        type: "code",
        raw: i,
        lang: n[2] ? n[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : n[2],
        text: r
      };
    }
  }
  heading(e) {
    const n = this.rules.block.heading.exec(e);
    if (n) {
      let i = n[2].trim();
      if (/#$/.test(i)) {
        const r = Tt(i, "#");
        (this.options.pedantic || !r || / $/.test(r)) && (i = r.trim());
      }
      return {
        type: "heading",
        raw: n[0],
        depth: n[1].length,
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  hr(e) {
    const n = this.rules.block.hr.exec(e);
    if (n)
      return {
        type: "hr",
        raw: n[0]
      };
  }
  blockquote(e) {
    const n = this.rules.block.blockquote.exec(e);
    if (n) {
      let i = n[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      i = Tt(i.replace(/^ *>[ \t]?/gm, ""), `
`);
      const r = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(i);
      return this.lexer.state.top = r, {
        type: "blockquote",
        raw: n[0],
        tokens: o,
        text: i
      };
    }
  }
  list(e) {
    let n = this.rules.block.list.exec(e);
    if (n) {
      let i = n[1].trim();
      const r = i.length > 1, o = {
        type: "list",
        raw: "",
        ordered: r,
        start: r ? +i.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      i = r ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = r ? i : "[*+-]");
      const a = new RegExp(`^( {0,3}${i})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let s = "", l = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(n = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        s = n[0], e = e.substring(s.length);
        let _ = n[2].split(`
`, 1)[0].replace(/^\t+/, ($) => " ".repeat(3 * $.length)), h = e.split(`
`, 1)[0], p = 0;
        this.options.pedantic ? (p = 2, l = _.trimStart()) : (p = n[2].search(/[^ ]/), p = p > 4 ? 1 : p, l = _.slice(p), p += n[1].length);
        let b = !1;
        if (!_ && /^ *$/.test(h) && (s += h + `
`, e = e.substring(h.length + 1), c = !0), !c) {
          const $ = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, p - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), d = new RegExp(`^ {0,${Math.min(3, p - 1)}}(?:\`\`\`|~~~)`), f = new RegExp(`^ {0,${Math.min(3, p - 1)}}#`);
          for (; e; ) {
            const v = e.split(`
`, 1)[0];
            if (h = v, this.options.pedantic && (h = h.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), d.test(h) || f.test(h) || $.test(h) || m.test(e))
              break;
            if (h.search(/[^ ]/) >= p || !h.trim())
              l += `
` + h.slice(p);
            else {
              if (b || _.search(/[^ ]/) >= 4 || d.test(_) || f.test(_) || m.test(_))
                break;
              l += `
` + h;
            }
            !b && !h.trim() && (b = !0), s += v + `
`, e = e.substring(v.length + 1), _ = h.slice(p);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(s) && (u = !0));
        let y = null, E;
        this.options.gfm && (y = /^\[[ xX]\] /.exec(l), y && (E = y[0] !== "[ ] ", l = l.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: s,
          task: !!y,
          checked: E,
          loose: !1,
          text: l,
          tokens: []
        }), o.raw += s;
      }
      o.items[o.items.length - 1].raw = s.trimEnd(), o.items[o.items.length - 1].text = l.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const _ = o.items[c].tokens.filter((p) => p.type === "space"), h = _.length > 0 && _.some((p) => /\n.*\n/.test(p.raw));
          o.loose = h;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const n = this.rules.block.html.exec(e);
    if (n)
      return {
        type: "html",
        block: !0,
        raw: n[0],
        pre: n[1] === "pre" || n[1] === "script" || n[1] === "style",
        text: n[0]
      };
  }
  def(e) {
    const n = this.rules.block.def.exec(e);
    if (n) {
      const i = n[1].toLowerCase().replace(/\s+/g, " "), r = n[2] ? n[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = n[3] ? n[3].substring(1, n[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : n[3];
      return {
        type: "def",
        tag: i,
        raw: n[0],
        href: r,
        title: o
      };
    }
  }
  table(e) {
    const n = this.rules.block.table.exec(e);
    if (!n || !/[:|]/.test(n[2]))
      return;
    const i = Si(n[1]), r = n[2].replace(/^\||\| *$/g, "").split("|"), o = n[3] && n[3].trim() ? n[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: n[0],
      header: [],
      align: [],
      rows: []
    };
    if (i.length === r.length) {
      for (const s of r)
        /^ *-+: *$/.test(s) ? a.align.push("right") : /^ *:-+: *$/.test(s) ? a.align.push("center") : /^ *:-+ *$/.test(s) ? a.align.push("left") : a.align.push(null);
      for (const s of i)
        a.header.push({
          text: s,
          tokens: this.lexer.inline(s)
        });
      for (const s of o)
        a.rows.push(Si(s, a.header.length).map((l) => ({
          text: l,
          tokens: this.lexer.inline(l)
        })));
      return a;
    }
  }
  lheading(e) {
    const n = this.rules.block.lheading.exec(e);
    if (n)
      return {
        type: "heading",
        raw: n[0],
        depth: n[2].charAt(0) === "=" ? 1 : 2,
        text: n[1],
        tokens: this.lexer.inline(n[1])
      };
  }
  paragraph(e) {
    const n = this.rules.block.paragraph.exec(e);
    if (n) {
      const i = n[1].charAt(n[1].length - 1) === `
` ? n[1].slice(0, -1) : n[1];
      return {
        type: "paragraph",
        raw: n[0],
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  text(e) {
    const n = this.rules.block.text.exec(e);
    if (n)
      return {
        type: "text",
        raw: n[0],
        text: n[0],
        tokens: this.lexer.inline(n[0])
      };
  }
  escape(e) {
    const n = this.rules.inline.escape.exec(e);
    if (n)
      return {
        type: "escape",
        raw: n[0],
        text: se(n[1])
      };
  }
  tag(e) {
    const n = this.rules.inline.tag.exec(e);
    if (n)
      return !this.lexer.state.inLink && /^<a /i.test(n[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(n[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(n[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(n[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: n[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: n[0]
      };
  }
  link(e) {
    const n = this.rules.inline.link.exec(e);
    if (n) {
      const i = n[2].trim();
      if (!this.options.pedantic && /^</.test(i)) {
        if (!/>$/.test(i))
          return;
        const a = Tt(i.slice(0, -1), "\\");
        if ((i.length - a.length) % 2 === 0)
          return;
      } else {
        const a = Co(n[2], "()");
        if (a > -1) {
          const l = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + a;
          n[2] = n[2].substring(0, a), n[0] = n[0].substring(0, l).trim(), n[3] = "";
        }
      }
      let r = n[2], o = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);
        a && (r = a[1], o = a[3]);
      } else
        o = n[3] ? n[3].slice(1, -1) : "";
      return r = r.trim(), /^</.test(r) && (this.options.pedantic && !/>$/.test(i) ? r = r.slice(1) : r = r.slice(1, -1)), xi(n, {
        href: r && r.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, n[0], this.lexer);
    }
  }
  reflink(e, n) {
    let i;
    if ((i = this.rules.inline.reflink.exec(e)) || (i = this.rules.inline.nolink.exec(e))) {
      const r = (i[2] || i[1]).replace(/\s+/g, " "), o = n[r.toLowerCase()];
      if (!o) {
        const a = i[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return xi(i, o, i[0], this.lexer);
    }
  }
  emStrong(e, n, i = "") {
    let r = this.rules.inline.emStrongLDelim.exec(e);
    if (!r || r[3] && i.match(/[\p{L}\p{N}]/u))
      return;
    if (!(r[1] || r[2] || "") || !i || this.rules.inline.punctuation.exec(i)) {
      const a = [...r[0]].length - 1;
      let s, l, u = a, c = 0;
      const _ = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (_.lastIndex = 0, n = n.slice(-1 * e.length + a); (r = _.exec(n)) != null; ) {
        if (s = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !s)
          continue;
        if (l = [...s].length, r[3] || r[4]) {
          u += l;
          continue;
        } else if ((r[5] || r[6]) && a % 3 && !((a + l) % 3)) {
          c += l;
          continue;
        }
        if (u -= l, u > 0)
          continue;
        l = Math.min(l, l + u + c);
        const h = [...r[0]][0].length, p = e.slice(0, a + r.index + h + l);
        if (Math.min(a, l) % 2) {
          const y = p.slice(1, -1);
          return {
            type: "em",
            raw: p,
            text: y,
            tokens: this.lexer.inlineTokens(y)
          };
        }
        const b = p.slice(2, -2);
        return {
          type: "strong",
          raw: p,
          text: b,
          tokens: this.lexer.inlineTokens(b)
        };
      }
    }
  }
  codespan(e) {
    const n = this.rules.inline.code.exec(e);
    if (n) {
      let i = n[2].replace(/\n/g, " ");
      const r = /[^ ]/.test(i), o = /^ /.test(i) && / $/.test(i);
      return r && o && (i = i.substring(1, i.length - 1)), i = se(i, !0), {
        type: "codespan",
        raw: n[0],
        text: i
      };
    }
  }
  br(e) {
    const n = this.rules.inline.br.exec(e);
    if (n)
      return {
        type: "br",
        raw: n[0]
      };
  }
  del(e) {
    const n = this.rules.inline.del.exec(e);
    if (n)
      return {
        type: "del",
        raw: n[0],
        text: n[2],
        tokens: this.lexer.inlineTokens(n[2])
      };
  }
  autolink(e) {
    const n = this.rules.inline.autolink.exec(e);
    if (n) {
      let i, r;
      return n[2] === "@" ? (i = se(n[1]), r = "mailto:" + i) : (i = se(n[1]), r = i), {
        type: "link",
        raw: n[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  url(e) {
    var i;
    let n;
    if (n = this.rules.inline.url.exec(e)) {
      let r, o;
      if (n[2] === "@")
        r = se(n[0]), o = "mailto:" + r;
      else {
        let a;
        do
          a = n[0], n[0] = ((i = this.rules.inline._backpedal.exec(n[0])) == null ? void 0 : i[0]) ?? "";
        while (a !== n[0]);
        r = se(n[0]), n[1] === "www." ? o = "http://" + n[0] : o = n[0];
      }
      return {
        type: "link",
        raw: n[0],
        text: r,
        href: o,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  inlineText(e) {
    const n = this.rules.inline.text.exec(e);
    if (n) {
      let i;
      return this.lexer.state.inRawBlock ? i = n[0] : i = se(n[0]), {
        type: "text",
        raw: n[0],
        text: i
      };
    }
  }
}
const xo = /^(?: *(?:\n|$))+/, To = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Bo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, yt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Io = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Jr = /(?:[*+-]|\d{1,9}[.)])/, ea = H(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Jr).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), ni = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Ro = /^[^\n]+/, ii = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Lo = H(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ii).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), No = H(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Jr).getRegex(), tn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ri = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Oo = H("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", ri).replace("tag", tn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ta = H(ni).replace("hr", yt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", tn).getRegex(), Po = H(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ta).getRegex(), ai = {
  blockquote: Po,
  code: To,
  def: Lo,
  fences: Bo,
  heading: Io,
  hr: yt,
  html: Oo,
  lheading: ea,
  list: No,
  newline: xo,
  paragraph: ta,
  table: _t,
  text: Ro
}, Ti = H("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", yt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", tn).getRegex(), Ho = {
  ...ai,
  table: Ti,
  paragraph: H(ni).replace("hr", yt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Ti).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", tn).getRegex()
}, Mo = {
  ...ai,
  html: H(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", ri).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: _t,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: H(ni).replace("hr", yt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ea).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, na = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, qo = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ia = /^( {2,}|\\)\n(?!\s*$)/, Uo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Et = "\\p{P}\\p{S}", zo = H(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Et).getRegex(), Go = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, jo = H(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Et).getRegex(), Vo = H("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Et).getRegex(), Xo = H("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Et).getRegex(), Zo = H(/\\([punct])/, "gu").replace(/punct/g, Et).getRegex(), Wo = H(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Yo = H(ri).replace("(?:-->|$)", "-->").getRegex(), Qo = H("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Yo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), zt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Ko = H(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", zt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ra = H(/^!?\[(label)\]\[(ref)\]/).replace("label", zt).replace("ref", ii).getRegex(), aa = H(/^!?\[(ref)\](?:\[\])?/).replace("ref", ii).getRegex(), Jo = H("reflink|nolink(?!\\()", "g").replace("reflink", ra).replace("nolink", aa).getRegex(), oi = {
  _backpedal: _t,
  // only used for GFM url
  anyPunctuation: Zo,
  autolink: Wo,
  blockSkip: Go,
  br: ia,
  code: qo,
  del: _t,
  emStrongLDelim: jo,
  emStrongRDelimAst: Vo,
  emStrongRDelimUnd: Xo,
  escape: na,
  link: Ko,
  nolink: aa,
  punctuation: zo,
  reflink: ra,
  reflinkSearch: Jo,
  tag: Qo,
  text: Uo,
  url: _t
}, es = {
  ...oi,
  link: H(/^!?\[(label)\]\((.*?)\)/).replace("label", zt).getRegex(),
  reflink: H(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", zt).getRegex()
}, On = {
  ...oi,
  escape: H(na).replace("])", "~|])").getRegex(),
  url: H(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, ts = {
  ...On,
  br: H(ia).replace("{2,}", "*").getRegex(),
  text: H(On.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Bt = {
  normal: ai,
  gfm: Ho,
  pedantic: Mo
}, ut = {
  normal: oi,
  gfm: On,
  breaks: ts,
  pedantic: es
};
class Se {
  constructor(e) {
    q(this, "tokens");
    q(this, "options");
    q(this, "state");
    q(this, "tokenizer");
    q(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || ze, this.options.tokenizer = this.options.tokenizer || new Ut(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const n = {
      block: Bt.normal,
      inline: ut.normal
    };
    this.options.pedantic ? (n.block = Bt.pedantic, n.inline = ut.pedantic) : this.options.gfm && (n.block = Bt.gfm, this.options.breaks ? n.inline = ut.breaks : n.inline = ut.gfm), this.tokenizer.rules = n;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Bt,
      inline: ut
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, n) {
    return new Se(n).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, n) {
    return new Se(n).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let n = 0; n < this.inlineQueue.length; n++) {
      const i = this.inlineQueue[n];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, n = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (s, l, u) => l + "    ".repeat(u.length));
    let i, r, o, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((s) => (i = s.call({ lexer: this }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.space(e)) {
          e = e.substring(i.raw.length), i.raw.length === 1 && n.length > 0 ? n[n.length - 1].raw += `
` : n.push(i);
          continue;
        }
        if (i = this.tokenizer.code(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.fences(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.heading(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.hr(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.blockquote(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.list(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.html(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.def(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.raw, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
            href: i.href,
            title: i.title
          });
          continue;
        }
        if (i = this.tokenizer.table(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.lheading(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let s = 1 / 0;
          const l = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, l), typeof u == "number" && u >= 0 && (s = Math.min(s, u));
          }), s < 1 / 0 && s >= 0 && (o = e.substring(0, s + 1));
        }
        if (this.state.top && (i = this.tokenizer.paragraph(o))) {
          r = n[n.length - 1], a && r.type === "paragraph" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i), a = o.length !== e.length, e = e.substring(i.raw.length);
          continue;
        }
        if (i = this.tokenizer.text(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && r.type === "text" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return this.state.top = !0, n;
  }
  inline(e, n = []) {
    return this.inlineQueue.push({ src: e, tokens: n }), n;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, n = []) {
    let i, r, o, a = e, s, l, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          c.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, s.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (l || (u = ""), l = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (i = c.call({ lexer: this }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.escape(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.tag(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.link(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.emStrong(e, a, u)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.codespan(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.br(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.del(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.autolink(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (!this.state.inLink && (i = this.tokenizer.url(e))) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const _ = e.slice(1);
          let h;
          this.options.extensions.startInline.forEach((p) => {
            h = p.call({ lexer: this }, _), typeof h == "number" && h >= 0 && (c = Math.min(c, h));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (i = this.tokenizer.inlineText(o)) {
          e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (u = i.raw.slice(-1)), l = !0, r = n[n.length - 1], r && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return n;
  }
}
class Gt {
  constructor(e) {
    q(this, "options");
    this.options = e || ze;
  }
  code(e, n, i) {
    var o;
    const r = (o = (n || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, r ? '<pre><code class="language-' + se(r) + '">' + (i ? e : se(e, !0)) + `</code></pre>
` : "<pre><code>" + (i ? e : se(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, n) {
    return e;
  }
  heading(e, n, i) {
    return `<h${n}>${e}</h${n}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, n, i) {
    const r = n ? "ol" : "ul", o = n && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + r + o + `>
` + e + "</" + r + `>
`;
  }
  listitem(e, n, i) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, n) {
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + n + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, n) {
    const i = n.header ? "th" : "td";
    return (n.align ? `<${i} align="${n.align}">` : `<${i}>`) + e + `</${i}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, n, i) {
    const r = Ci(e);
    if (r === null)
      return i;
    e = r;
    let o = '<a href="' + e + '"';
    return n && (o += ' title="' + n + '"'), o += ">" + i + "</a>", o;
  }
  image(e, n, i) {
    const r = Ci(e);
    if (r === null)
      return i;
    e = r;
    let o = `<img src="${e}" alt="${i}"`;
    return n && (o += ` title="${n}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class si {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, n, i) {
    return "" + i;
  }
  image(e, n, i) {
    return "" + i;
  }
  br() {
    return "";
  }
}
class xe {
  constructor(e) {
    q(this, "options");
    q(this, "renderer");
    q(this, "textRenderer");
    this.options = e || ze, this.options.renderer = this.options.renderer || new Gt(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new si();
  }
  /**
   * Static Parse Method
   */
  static parse(e, n) {
    return new xe(n).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, n) {
    return new xe(n).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, n = !0) {
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const o = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const a = o, s = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (s !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          i += s || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          i += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = o;
          i += this.renderer.heading(this.parseInline(a.tokens), a.depth, Ao(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = o;
          i += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = o;
          let s = "", l = "";
          for (let c = 0; c < a.header.length; c++)
            l += this.renderer.tablecell(this.parseInline(a.header[c].tokens), { header: !0, align: a.align[c] });
          s += this.renderer.tablerow(l);
          let u = "";
          for (let c = 0; c < a.rows.length; c++) {
            const _ = a.rows[c];
            l = "";
            for (let h = 0; h < _.length; h++)
              l += this.renderer.tablecell(this.parseInline(_[h].tokens), { header: !1, align: a.align[h] });
            u += this.renderer.tablerow(l);
          }
          i += this.renderer.table(s, u);
          continue;
        }
        case "blockquote": {
          const a = o, s = this.parse(a.tokens);
          i += this.renderer.blockquote(s);
          continue;
        }
        case "list": {
          const a = o, s = a.ordered, l = a.start, u = a.loose;
          let c = "";
          for (let _ = 0; _ < a.items.length; _++) {
            const h = a.items[_], p = h.checked, b = h.task;
            let y = "";
            if (h.task) {
              const E = this.renderer.checkbox(!!p);
              u ? h.tokens.length > 0 && h.tokens[0].type === "paragraph" ? (h.tokens[0].text = E + " " + h.tokens[0].text, h.tokens[0].tokens && h.tokens[0].tokens.length > 0 && h.tokens[0].tokens[0].type === "text" && (h.tokens[0].tokens[0].text = E + " " + h.tokens[0].tokens[0].text)) : h.tokens.unshift({
                type: "text",
                text: E + " "
              }) : y += E + " ";
            }
            y += this.parse(h.tokens, u), c += this.renderer.listitem(y, b, !!p);
          }
          i += this.renderer.list(c, s, l);
          continue;
        }
        case "html": {
          const a = o;
          i += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = o;
          i += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = o, s = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; r + 1 < e.length && e[r + 1].type === "text"; )
            a = e[++r], s += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          i += n ? this.renderer.paragraph(s) : s;
          continue;
        }
        default: {
          const a = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, n) {
    n = n || this.renderer;
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const o = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const a = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          i += a || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const a = o;
          i += n.text(a.text);
          break;
        }
        case "html": {
          const a = o;
          i += n.html(a.text);
          break;
        }
        case "link": {
          const a = o;
          i += n.link(a.href, a.title, this.parseInline(a.tokens, n));
          break;
        }
        case "image": {
          const a = o;
          i += n.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = o;
          i += n.strong(this.parseInline(a.tokens, n));
          break;
        }
        case "em": {
          const a = o;
          i += n.em(this.parseInline(a.tokens, n));
          break;
        }
        case "codespan": {
          const a = o;
          i += n.codespan(a.text);
          break;
        }
        case "br": {
          i += n.br();
          break;
        }
        case "del": {
          const a = o;
          i += n.del(this.parseInline(a.tokens, n));
          break;
        }
        case "text": {
          const a = o;
          i += n.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return i;
  }
}
class dt {
  constructor(e) {
    q(this, "options");
    this.options = e || ze;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
q(dt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Ue, Pn, oa;
class ns {
  constructor(...e) {
    Ei(this, Ue);
    q(this, "defaults", ti());
    q(this, "options", this.setOptions);
    q(this, "parse", At(this, Ue, Pn).call(this, Se.lex, xe.parse));
    q(this, "parseInline", At(this, Ue, Pn).call(this, Se.lexInline, xe.parseInline));
    q(this, "Parser", xe);
    q(this, "Renderer", Gt);
    q(this, "TextRenderer", si);
    q(this, "Lexer", Se);
    q(this, "Tokenizer", Ut);
    q(this, "Hooks", dt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, n) {
    var r, o;
    let i = [];
    for (const a of e)
      switch (i = i.concat(n.call(this, a)), a.type) {
        case "table": {
          const s = a;
          for (const l of s.header)
            i = i.concat(this.walkTokens(l.tokens, n));
          for (const l of s.rows)
            for (const u of l)
              i = i.concat(this.walkTokens(u.tokens, n));
          break;
        }
        case "list": {
          const s = a;
          i = i.concat(this.walkTokens(s.items, n));
          break;
        }
        default: {
          const s = a;
          (o = (r = this.defaults.extensions) == null ? void 0 : r.childTokens) != null && o[s.type] ? this.defaults.extensions.childTokens[s.type].forEach((l) => {
            const u = s[l].flat(1 / 0);
            i = i.concat(this.walkTokens(u, n));
          }) : s.tokens && (i = i.concat(this.walkTokens(s.tokens, n)));
        }
      }
    return i;
  }
  use(...e) {
    const n = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((i) => {
      const r = { ...i };
      if (r.async = this.defaults.async || r.async || !1, i.extensions && (i.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const a = n.renderers[o.name];
          a ? n.renderers[o.name] = function(...s) {
            let l = o.renderer.apply(this, s);
            return l === !1 && (l = a.apply(this, s)), l;
          } : n.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = n[o.level];
          a ? a.unshift(o.tokenizer) : n[o.level] = [o.tokenizer], o.start && (o.level === "block" ? n.startBlock ? n.startBlock.push(o.start) : n.startBlock = [o.start] : o.level === "inline" && (n.startInline ? n.startInline.push(o.start) : n.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (n.childTokens[o.name] = o.childTokens);
      }), r.extensions = n), i.renderer) {
        const o = this.defaults.renderer || new Gt(this.defaults);
        for (const a in i.renderer) {
          if (!(a in o))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const s = a, l = i.renderer[s], u = o[s];
          o[s] = (...c) => {
            let _ = l.apply(o, c);
            return _ === !1 && (_ = u.apply(o, c)), _ || "";
          };
        }
        r.renderer = o;
      }
      if (i.tokenizer) {
        const o = this.defaults.tokenizer || new Ut(this.defaults);
        for (const a in i.tokenizer) {
          if (!(a in o))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const s = a, l = i.tokenizer[s], u = o[s];
          o[s] = (...c) => {
            let _ = l.apply(o, c);
            return _ === !1 && (_ = u.apply(o, c)), _;
          };
        }
        r.tokenizer = o;
      }
      if (i.hooks) {
        const o = this.defaults.hooks || new dt();
        for (const a in i.hooks) {
          if (!(a in o))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const s = a, l = i.hooks[s], u = o[s];
          dt.passThroughHooks.has(a) ? o[s] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(l.call(o, c)).then((h) => u.call(o, h));
            const _ = l.call(o, c);
            return u.call(o, _);
          } : o[s] = (...c) => {
            let _ = l.apply(o, c);
            return _ === !1 && (_ = u.apply(o, c)), _;
          };
        }
        r.hooks = o;
      }
      if (i.walkTokens) {
        const o = this.defaults.walkTokens, a = i.walkTokens;
        r.walkTokens = function(s) {
          let l = [];
          return l.push(a.call(this, s)), o && (l = l.concat(o.call(this, s))), l;
        };
      }
      this.defaults = { ...this.defaults, ...r };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, n) {
    return Se.lex(e, n ?? this.defaults);
  }
  parser(e, n) {
    return xe.parse(e, n ?? this.defaults);
  }
}
Ue = new WeakSet(), Pn = function(e, n) {
  return (i, r) => {
    const o = { ...r }, a = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const s = At(this, Ue, oa).call(this, !!a.silent, !!a.async);
    if (typeof i > "u" || i === null)
      return s(new Error("marked(): input parameter is undefined or null"));
    if (typeof i != "string")
      return s(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(i) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(i) : i).then((l) => e(l, a)).then((l) => a.hooks ? a.hooks.processAllTokens(l) : l).then((l) => a.walkTokens ? Promise.all(this.walkTokens(l, a.walkTokens)).then(() => l) : l).then((l) => n(l, a)).then((l) => a.hooks ? a.hooks.postprocess(l) : l).catch(s);
    try {
      a.hooks && (i = a.hooks.preprocess(i));
      let l = e(i, a);
      a.hooks && (l = a.hooks.processAllTokens(l)), a.walkTokens && this.walkTokens(l, a.walkTokens);
      let u = n(l, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (l) {
      return s(l);
    }
  };
}, oa = function(e, n) {
  return (i) => {
    if (i.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const r = "<p>An error occurred:</p><pre>" + se(i.message + "", !0) + "</pre>";
      return n ? Promise.resolve(r) : r;
    }
    if (n)
      return Promise.reject(i);
    throw i;
  };
};
const qe = new ns();
function P(t, e) {
  return qe.parse(t, e);
}
P.options = P.setOptions = function(t) {
  return qe.setOptions(t), P.defaults = qe.defaults, Yr(P.defaults), P;
};
P.getDefaults = ti;
P.defaults = ze;
P.use = function(...t) {
  return qe.use(...t), P.defaults = qe.defaults, Yr(P.defaults), P;
};
P.walkTokens = function(t, e) {
  return qe.walkTokens(t, e);
};
P.parseInline = qe.parseInline;
P.Parser = xe;
P.parser = xe.parse;
P.Renderer = Gt;
P.TextRenderer = si;
P.Lexer = Se;
P.lexer = Se.lex;
P.Tokenizer = Ut;
P.Hooks = dt;
P.parse = P;
P.options;
P.setOptions;
P.use;
P.walkTokens;
P.parseInline;
xe.parse;
Se.lex;
const is = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, rs = Object.hasOwnProperty;
class sa {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, n) {
    const i = this;
    let r = as(e, n === !0);
    const o = r;
    for (; rs.call(i.occurrences, r); )
      i.occurrences[o]++, r = o + "-" + i.occurrences[o];
    return i.occurrences[r] = 0, r;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function as(t, e) {
  return typeof t != "string" ? "" : (e || (t = t.toLowerCase()), t.replace(is, "").replace(/ /g, "-"));
}
new sa();
var Bi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, os = { exports: {} };
(function(t) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var n = function(i) {
    var r = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, a = {}, s = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(d) {
          return d instanceof l ? new l(d.type, m(d.content), d.alias) : Array.isArray(d) ? d.map(m) : d.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++o }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(d, f) {
          f = f || {};
          var v, g;
          switch (s.util.type(d)) {
            case "Object":
              if (g = s.util.objId(d), f[g])
                return f[g];
              v = /** @type {Record<string, any>} */
              {}, f[g] = v;
              for (var D in d)
                d.hasOwnProperty(D) && (v[D] = m(d[D], f));
              return (
                /** @type {any} */
                v
              );
            case "Array":
              return g = s.util.objId(d), f[g] ? f[g] : (v = [], f[g] = v, /** @type {Array} */
              /** @type {any} */
              d.forEach(function(C, F) {
                v[F] = m(C, f);
              }), /** @type {any} */
              v);
            default:
              return d;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var d = r.exec(m.className);
            if (d)
              return d[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, d) {
          m.className = m.className.replace(RegExp(r, "gi"), ""), m.classList.add("language-" + d);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if (document.currentScript && document.currentScript.tagName === "SCRIPT")
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (v) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(v.stack) || [])[1];
            if (m) {
              var d = document.getElementsByTagName("script");
              for (var f in d)
                if (d[f].src == m)
                  return d[f];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, d, f) {
          for (var v = "no-" + d; m; ) {
            var g = m.classList;
            if (g.contains(d))
              return !0;
            if (g.contains(v))
              return !1;
            m = m.parentElement;
          }
          return !!f;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, d) {
          var f = s.util.clone(s.languages[m]);
          for (var v in d)
            f[v] = d[v];
          return f;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, d, f, v) {
          v = v || /** @type {any} */
          s.languages;
          var g = v[m], D = {};
          for (var C in g)
            if (g.hasOwnProperty(C)) {
              if (C == d)
                for (var F in f)
                  f.hasOwnProperty(F) && (D[F] = f[F]);
              f.hasOwnProperty(C) || (D[C] = g[C]);
            }
          var x = v[m];
          return v[m] = D, s.languages.DFS(s.languages, function(w, L) {
            L === x && w != m && (this[w] = D);
          }), D;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(d, f, v, g) {
          g = g || {};
          var D = s.util.objId;
          for (var C in d)
            if (d.hasOwnProperty(C)) {
              f.call(d, C, d[C], v || C);
              var F = d[C], x = s.util.type(F);
              x === "Object" && !g[D(F)] ? (g[D(F)] = !0, m(F, f, null, g)) : x === "Array" && !g[D(F)] && (g[D(F)] = !0, m(F, f, C, g));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, d) {
        s.highlightAllUnder(document, m, d);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, d, f) {
        var v = {
          callback: f,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        s.hooks.run("before-highlightall", v), v.elements = Array.prototype.slice.apply(v.container.querySelectorAll(v.selector)), s.hooks.run("before-all-elements-highlight", v);
        for (var g = 0, D; D = v.elements[g++]; )
          s.highlightElement(D, d === !0, v.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, d, f) {
        var v = s.util.getLanguage(m), g = s.languages[v];
        s.util.setLanguage(m, v);
        var D = m.parentElement;
        D && D.nodeName.toLowerCase() === "pre" && s.util.setLanguage(D, v);
        var C = m.textContent, F = {
          element: m,
          language: v,
          grammar: g,
          code: C
        };
        function x(L) {
          F.highlightedCode = L, s.hooks.run("before-insert", F), F.element.innerHTML = F.highlightedCode, s.hooks.run("after-highlight", F), s.hooks.run("complete", F), f && f.call(F.element);
        }
        if (s.hooks.run("before-sanity-check", F), D = F.element.parentElement, D && D.nodeName.toLowerCase() === "pre" && !D.hasAttribute("tabindex") && D.setAttribute("tabindex", "0"), !F.code) {
          s.hooks.run("complete", F), f && f.call(F.element);
          return;
        }
        if (s.hooks.run("before-highlight", F), !F.grammar) {
          x(s.util.encode(F.code));
          return;
        }
        if (d && i.Worker) {
          var w = new Worker(s.filename);
          w.onmessage = function(L) {
            x(L.data);
          }, w.postMessage(JSON.stringify({
            language: F.language,
            code: F.code,
            immediateClose: !0
          }));
        } else
          x(s.highlight(F.code, F.grammar, F.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, d, f) {
        var v = {
          code: m,
          grammar: d,
          language: f
        };
        if (s.hooks.run("before-tokenize", v), !v.grammar)
          throw new Error('The language "' + v.language + '" has no grammar.');
        return v.tokens = s.tokenize(v.code, v.grammar), s.hooks.run("after-tokenize", v), l.stringify(s.util.encode(v.tokens), v.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, d) {
        var f = d.rest;
        if (f) {
          for (var v in f)
            d[v] = f[v];
          delete d.rest;
        }
        var g = new _();
        return h(g, g.head, m), c(m, g, d, g.head, 0), b(g);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, d) {
          var f = s.hooks.all;
          f[m] = f[m] || [], f[m].push(d);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, d) {
          var f = s.hooks.all[m];
          if (!(!f || !f.length))
            for (var v = 0, g; g = f[v++]; )
              g(d);
        }
      },
      Token: l
    };
    i.Prism = s;
    function l(m, d, f, v) {
      this.type = m, this.content = d, this.alias = f, this.length = (v || "").length | 0;
    }
    l.stringify = function m(d, f) {
      if (typeof d == "string")
        return d;
      if (Array.isArray(d)) {
        var v = "";
        return d.forEach(function(x) {
          v += m(x, f);
        }), v;
      }
      var g = {
        type: d.type,
        content: m(d.content, f),
        tag: "span",
        classes: ["token", d.type],
        attributes: {},
        language: f
      }, D = d.alias;
      D && (Array.isArray(D) ? Array.prototype.push.apply(g.classes, D) : g.classes.push(D)), s.hooks.run("wrap", g);
      var C = "";
      for (var F in g.attributes)
        C += " " + F + '="' + (g.attributes[F] || "").replace(/"/g, "&quot;") + '"';
      return "<" + g.tag + ' class="' + g.classes.join(" ") + '"' + C + ">" + g.content + "</" + g.tag + ">";
    };
    function u(m, d, f, v) {
      m.lastIndex = d;
      var g = m.exec(f);
      if (g && v && g[1]) {
        var D = g[1].length;
        g.index += D, g[0] = g[0].slice(D);
      }
      return g;
    }
    function c(m, d, f, v, g, D) {
      for (var C in f)
        if (!(!f.hasOwnProperty(C) || !f[C])) {
          var F = f[C];
          F = Array.isArray(F) ? F : [F];
          for (var x = 0; x < F.length; ++x) {
            if (D && D.cause == C + "," + x)
              return;
            var w = F[x], L = w.inside, re = !!w.lookbehind, te = !!w.greedy, be = w.alias;
            if (te && !w.pattern.global) {
              var j = w.pattern.toString().match(/[imsuy]*$/)[0];
              w.pattern = RegExp(w.pattern.source, j + "g");
            }
            for (var Q = w.pattern || w, M = v.next, K = g; M !== d.tail && !(D && K >= D.reach); K += M.value.length, M = M.next) {
              var Fe = M.value;
              if (d.length > m.length)
                return;
              if (!(Fe instanceof l)) {
                var A = 1, Z;
                if (te) {
                  if (Z = u(Q, K, m, re), !Z || Z.index >= m.length)
                    break;
                  var Re = Z.index, Te = Z.index + Z[0].length, ae = K;
                  for (ae += M.value.length; Re >= ae; )
                    M = M.next, ae += M.value.length;
                  if (ae -= M.value.length, K = ae, M.value instanceof l)
                    continue;
                  for (var Ae = M; Ae !== d.tail && (ae < Te || typeof Ae.value == "string"); Ae = Ae.next)
                    A++, ae += Ae.value.length;
                  A--, Fe = m.slice(K, ae), Z.index -= K;
                } else if (Z = u(Q, 0, Fe, re), !Z)
                  continue;
                var Re = Z.index, je = Z[0], S = Fe.slice(0, Re), vi = Fe.slice(Re + je.length), ln = K + Fe.length;
                D && ln > D.reach && (D.reach = ln);
                var Ft = M.prev;
                S && (Ft = h(d, Ft, S), K += S.length), p(d, Ft, A);
                var Ga = new l(C, L ? s.tokenize(je, L) : je, be, je);
                if (M = h(d, Ft, Ga), vi && h(d, M, vi), A > 1) {
                  var un = {
                    cause: C + "," + x,
                    reach: ln
                  };
                  c(m, d, f, M.prev, K, un), D && un.reach > D.reach && (D.reach = un.reach);
                }
              }
            }
          }
        }
    }
    function _() {
      var m = { value: null, prev: null, next: null }, d = { value: null, prev: m, next: null };
      m.next = d, this.head = m, this.tail = d, this.length = 0;
    }
    function h(m, d, f) {
      var v = d.next, g = { value: f, prev: d, next: v };
      return d.next = g, v.prev = g, m.length++, g;
    }
    function p(m, d, f) {
      for (var v = d.next, g = 0; g < f && v !== m.tail; g++)
        v = v.next;
      d.next = v, v.prev = d, m.length -= g;
    }
    function b(m) {
      for (var d = [], f = m.head.next; f !== m.tail; )
        d.push(f.value), f = f.next;
      return d;
    }
    if (!i.document)
      return i.addEventListener && (s.disableWorkerMessageHandler || i.addEventListener("message", function(m) {
        var d = JSON.parse(m.data), f = d.language, v = d.code, g = d.immediateClose;
        i.postMessage(s.highlight(v, s.languages[f], f)), g && i.close();
      }, !1)), s;
    var y = s.util.currentScript();
    y && (s.filename = y.src, y.hasAttribute("data-manual") && (s.manual = !0));
    function E() {
      s.manual || s.highlightAll();
    }
    if (!s.manual) {
      var $ = document.readyState;
      $ === "loading" || $ === "interactive" && y && y.defer ? document.addEventListener("DOMContentLoaded", E) : window.requestAnimationFrame ? window.requestAnimationFrame(E) : window.setTimeout(E, 16);
    }
    return s;
  }(e);
  t.exports && (t.exports = n), typeof Bi < "u" && (Bi.Prism = n), n.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, n.languages.markup.tag.inside["attr-value"].inside.entity = n.languages.markup.entity, n.languages.markup.doctype.inside["internal-subset"].inside = n.languages.markup, n.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(n.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(r, o) {
      var a = {};
      a["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: n.languages[o]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var s = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      s["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: n.languages[o]
      };
      var l = {};
      l[r] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return r;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: s
      }, n.languages.insertBefore("markup", "cdata", l);
    }
  }), Object.defineProperty(n.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, r) {
      n.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [r, "language-" + r],
                inside: n.languages[r]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), n.languages.html = n.languages.markup, n.languages.mathml = n.languages.markup, n.languages.svg = n.languages.markup, n.languages.xml = n.languages.extend("markup", {}), n.languages.ssml = n.languages.xml, n.languages.atom = n.languages.xml, n.languages.rss = n.languages.xml, function(i) {
    var r = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + r.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + r.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + r.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + r.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: r,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var o = i.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(n), n.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, n.languages.javascript = n.languages.extend("clike", {
    "class-name": [
      n.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), n.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, n.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: n.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: n.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), n.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: n.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), n.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), n.languages.markup && (n.languages.markup.tag.addInlined("script", "javascript"), n.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), n.languages.js = n.languages.javascript, function() {
    if (typeof n > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", r = function(y, E) {
      return "✖ Error " + y + " while fetching file: " + E;
    }, o = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, s = "data-src-status", l = "loading", u = "loaded", c = "failed", _ = "pre[data-src]:not([" + s + '="' + u + '"]):not([' + s + '="' + l + '"])';
    function h(y, E, $) {
      var m = new XMLHttpRequest();
      m.open("GET", y, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? E(m.responseText) : m.status >= 400 ? $(r(m.status, m.statusText)) : $(o));
      }, m.send(null);
    }
    function p(y) {
      var E = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(y || "");
      if (E) {
        var $ = Number(E[1]), m = E[2], d = E[3];
        return m ? d ? [$, Number(d)] : [$, void 0] : [$, $];
      }
    }
    n.hooks.add("before-highlightall", function(y) {
      y.selector += ", " + _;
    }), n.hooks.add("before-sanity-check", function(y) {
      var E = (
        /** @type {HTMLPreElement} */
        y.element
      );
      if (E.matches(_)) {
        y.code = "", E.setAttribute(s, l);
        var $ = E.appendChild(document.createElement("CODE"));
        $.textContent = i;
        var m = E.getAttribute("data-src"), d = y.language;
        if (d === "none") {
          var f = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          d = a[f] || f;
        }
        n.util.setLanguage($, d), n.util.setLanguage(E, d);
        var v = n.plugins.autoloader;
        v && v.loadLanguages(d), h(
          m,
          function(g) {
            E.setAttribute(s, u);
            var D = p(E.getAttribute("data-range"));
            if (D) {
              var C = g.split(/\r\n?|\n/g), F = D[0], x = D[1] == null ? C.length : D[1];
              F < 0 && (F += C.length), F = Math.max(0, Math.min(F - 1, C.length)), x < 0 && (x += C.length), x = Math.max(0, Math.min(x, C.length)), g = C.slice(F, x).join(`
`), E.hasAttribute("data-start") || E.setAttribute("data-start", String(F + 1));
            }
            $.textContent = g, n.highlightElement($);
          },
          function(g) {
            E.setAttribute(s, c), $.textContent = g;
          }
        );
      }
    }), n.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(E) {
        for (var $ = (E || document).querySelectorAll(_), m = 0, d; d = $[m++]; )
          n.highlightElement(d);
      }
    };
    var b = !1;
    n.fileHighlight = function() {
      b || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), b = !0), n.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(os);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(t) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, n = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  t.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: n,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: n,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, t.languages.tex = t.languages.latex, t.languages.context = t.languages.latex;
})(Prism);
(function(t) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", n = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, i = {
    bash: n,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  t.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: n
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: i.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: i.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, n.inside = t.languages.bash;
  for (var r = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = i.variable[1].inside, a = 0; a < r.length; a++)
    o[r[a]] = t.languages.bash[r[a]];
  t.languages.sh = t.languages.bash, t.languages.shell = t.languages.bash;
})(Prism);
Prism.languages.c = Prism.languages.extend("clike", {
  comment: {
    pattern: /\/\/(?:[^\r\n\\]|\\(?:\r\n?|\n|(?![\r\n])))*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  string: {
    // https://en.cppreference.com/w/c/language/string_literal
    pattern: /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"/,
    greedy: !0
  },
  "class-name": {
    pattern: /(\b(?:enum|struct)\s+(?:__attribute__\s*\(\([\s\S]*?\)\)\s*)?)\w+|\b[a-z]\w*_t\b/,
    lookbehind: !0
  },
  keyword: /\b(?:_Alignas|_Alignof|_Atomic|_Bool|_Complex|_Generic|_Imaginary|_Noreturn|_Static_assert|_Thread_local|__attribute__|asm|auto|break|case|char|const|continue|default|do|double|else|enum|extern|float|for|goto|if|inline|int|long|register|return|short|signed|sizeof|static|struct|switch|typedef|typeof|union|unsigned|void|volatile|while)\b/,
  function: /\b[a-z_]\w*(?=\s*\()/i,
  number: /(?:\b0x(?:[\da-f]+(?:\.[\da-f]*)?|\.[\da-f]+)(?:p[+-]?\d+)?|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?)[ful]{0,4}/i,
  operator: />>=?|<<=?|->|([-+&|:])\1|[?:~]|[-+*/%&|^!=<>]=?/
});
Prism.languages.insertBefore("c", "string", {
  char: {
    // https://en.cppreference.com/w/c/language/character_constant
    pattern: /'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n]){0,32}'/,
    greedy: !0
  }
});
Prism.languages.insertBefore("c", "string", {
  macro: {
    // allow for multiline macro definitions
    // spaces after the # character compile fine with gcc
    pattern: /(^[\t ]*)#\s*[a-z](?:[^\r\n\\/]|\/(?!\*)|\/\*(?:[^*]|\*(?!\/))*\*\/|\\(?:\r\n|[\s\S]))*/im,
    lookbehind: !0,
    greedy: !0,
    alias: "property",
    inside: {
      string: [
        {
          // highlight the path of the include statement as a string
          pattern: /^(#\s*include\s*)<[^>]+>/,
          lookbehind: !0
        },
        Prism.languages.c.string
      ],
      char: Prism.languages.c.char,
      comment: Prism.languages.c.comment,
      "macro-name": [
        {
          pattern: /(^#\s*define\s+)\w+\b(?!\()/i,
          lookbehind: !0
        },
        {
          pattern: /(^#\s*define\s+)\w+\b(?=\()/i,
          lookbehind: !0,
          alias: "function"
        }
      ],
      // highlight macro directives as keywords
      directive: {
        pattern: /^(#\s*)[a-z]+/,
        lookbehind: !0,
        alias: "keyword"
      },
      "directive-hash": /^#/,
      punctuation: /##|\\(?=[\r\n])/,
      expression: {
        pattern: /\S[\s\S]*/,
        inside: Prism.languages.c
      }
    }
  }
});
Prism.languages.insertBefore("c", "function", {
  // highlight predefined macros as constants
  constant: /\b(?:EOF|NULL|SEEK_CUR|SEEK_END|SEEK_SET|__DATE__|__FILE__|__LINE__|__TIMESTAMP__|__TIME__|__func__|stderr|stdin|stdout)\b/
});
delete Prism.languages.c.boolean;
(function(t) {
  var e = /\b(?:alignas|alignof|asm|auto|bool|break|case|catch|char|char16_t|char32_t|char8_t|class|co_await|co_return|co_yield|compl|concept|const|const_cast|consteval|constexpr|constinit|continue|decltype|default|delete|do|double|dynamic_cast|else|enum|explicit|export|extern|final|float|for|friend|goto|if|import|inline|int|int16_t|int32_t|int64_t|int8_t|long|module|mutable|namespace|new|noexcept|nullptr|operator|override|private|protected|public|register|reinterpret_cast|requires|return|short|signed|sizeof|static|static_assert|static_cast|struct|switch|template|this|thread_local|throw|try|typedef|typeid|typename|uint16_t|uint32_t|uint64_t|uint8_t|union|unsigned|using|virtual|void|volatile|wchar_t|while)\b/, n = /\b(?!<keyword>)\w+(?:\s*\.\s*\w+)*\b/.source.replace(/<keyword>/g, function() {
    return e.source;
  });
  t.languages.cpp = t.languages.extend("c", {
    "class-name": [
      {
        pattern: RegExp(/(\b(?:class|concept|enum|struct|typename)\s+)(?!<keyword>)\w+/.source.replace(/<keyword>/g, function() {
          return e.source;
        })),
        lookbehind: !0
      },
      // This is intended to capture the class name of method implementations like:
      //   void foo::bar() const {}
      // However! The `foo` in the above example could also be a namespace, so we only capture the class name if
      // it starts with an uppercase letter. This approximation should give decent results.
      /\b[A-Z]\w*(?=\s*::\s*\w+\s*\()/,
      // This will capture the class name before destructors like:
      //   Foo::~Foo() {}
      /\b[A-Z_]\w*(?=\s*::\s*~\w+\s*\()/i,
      // This also intends to capture the class name of method implementations but here the class has template
      // parameters, so it can't be a namespace (until C++ adds generic namespaces).
      /\b\w+(?=\s*<(?:[^<>]|<(?:[^<>]|<[^<>]*>)*>)*>\s*::\s*\w+\s*\()/
    ],
    keyword: e,
    number: {
      pattern: /(?:\b0b[01']+|\b0x(?:[\da-f']+(?:\.[\da-f']*)?|\.[\da-f']+)(?:p[+-]?[\d']+)?|(?:\b[\d']+(?:\.[\d']*)?|\B\.[\d']+)(?:e[+-]?[\d']+)?)[ful]{0,4}/i,
      greedy: !0
    },
    operator: />>=?|<<=?|->|--|\+\+|&&|\|\||[?:~]|<=>|[-+*/%&|^!=<>]=?|\b(?:and|and_eq|bitand|bitor|not|not_eq|or|or_eq|xor|xor_eq)\b/,
    boolean: /\b(?:false|true)\b/
  }), t.languages.insertBefore("cpp", "string", {
    module: {
      // https://en.cppreference.com/w/cpp/language/modules
      pattern: RegExp(
        /(\b(?:import|module)\s+)/.source + "(?:" + // header-name
        /"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|<[^<>\r\n]*>/.source + "|" + // module name or partition or both
        /<mod-name>(?:\s*:\s*<mod-name>)?|:\s*<mod-name>/.source.replace(/<mod-name>/g, function() {
          return n;
        }) + ")"
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        string: /^[<"][\s\S]+/,
        operator: /:/,
        punctuation: /\./
      }
    },
    "raw-string": {
      pattern: /R"([^()\\ ]{0,16})\([\s\S]*?\)\1"/,
      alias: "string",
      greedy: !0
    }
  }), t.languages.insertBefore("cpp", "keyword", {
    "generic-function": {
      pattern: /\b(?!operator\b)[a-z_]\w*\s*<(?:[^<>]|<[^<>]*>)*>(?=\s*\()/i,
      inside: {
        function: /^\w+/,
        generic: {
          pattern: /<[\s\S]+/,
          alias: "class-name",
          inside: t.languages.cpp
        }
      }
    }
  }), t.languages.insertBefore("cpp", "operator", {
    "double-colon": {
      pattern: /::/,
      alias: "punctuation"
    }
  }), t.languages.insertBefore("cpp", "class-name", {
    // the base clause is an optional list of parent classes
    // https://en.cppreference.com/w/cpp/language/class
    "base-clause": {
      pattern: /(\b(?:class|struct)\s+\w+\s*:\s*)[^;{}"'\s]+(?:\s+[^;{}"'\s]+)*(?=\s*[;{])/,
      lookbehind: !0,
      greedy: !0,
      inside: t.languages.extend("cpp", {})
    }
  }), t.languages.insertBefore("inside", "double-colon", {
    // All untokenized words that are not namespaces should be class names
    "class-name": /\b[a-z_]\w*\b(?!\s*::)/i
  }, t.languages.cpp["base-clause"]);
})(Prism);
Prism.languages.json = {
  property: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?=\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^\\"\r\n])*"(?!\s*:)/,
    lookbehind: !0,
    greedy: !0
  },
  comment: {
    pattern: /\/\/.*|\/\*[\s\S]*?(?:\*\/|$)/,
    greedy: !0
  },
  number: /-?\b\d+(?:\.\d+)?(?:e[+-]?\d+)?\b/i,
  punctuation: /[{}[\],]/,
  operator: /:/,
  boolean: /\b(?:false|true)\b/,
  null: {
    pattern: /\bnull\b/,
    alias: "keyword"
  }
};
Prism.languages.webmanifest = Prism.languages.json;
Prism.languages.sql = {
  comment: {
    pattern: /(^|[^\\])(?:\/\*[\s\S]*?\*\/|(?:--|\/\/|#).*)/,
    lookbehind: !0
  },
  variable: [
    {
      pattern: /@(["'`])(?:\\[\s\S]|(?!\1)[^\\])+\1/,
      greedy: !0
    },
    /@[\w.$]+/
  ],
  string: {
    pattern: /(^|[^@\\])("|')(?:\\[\s\S]|(?!\2)[^\\]|\2\2)*\2/,
    greedy: !0,
    lookbehind: !0
  },
  identifier: {
    pattern: /(^|[^@\\])`(?:\\[\s\S]|[^`\\]|``)*`/,
    greedy: !0,
    lookbehind: !0,
    inside: {
      punctuation: /^`|`$/
    }
  },
  function: /\b(?:AVG|COUNT|FIRST|FORMAT|LAST|LCASE|LEN|MAX|MID|MIN|MOD|NOW|ROUND|SUM|UCASE)(?=\s*\()/i,
  // Should we highlight user defined functions too?
  keyword: /\b(?:ACTION|ADD|AFTER|ALGORITHM|ALL|ALTER|ANALYZE|ANY|APPLY|AS|ASC|AUTHORIZATION|AUTO_INCREMENT|BACKUP|BDB|BEGIN|BERKELEYDB|BIGINT|BINARY|BIT|BLOB|BOOL|BOOLEAN|BREAK|BROWSE|BTREE|BULK|BY|CALL|CASCADED?|CASE|CHAIN|CHAR(?:ACTER|SET)?|CHECK(?:POINT)?|CLOSE|CLUSTERED|COALESCE|COLLATE|COLUMNS?|COMMENT|COMMIT(?:TED)?|COMPUTE|CONNECT|CONSISTENT|CONSTRAINT|CONTAINS(?:TABLE)?|CONTINUE|CONVERT|CREATE|CROSS|CURRENT(?:_DATE|_TIME|_TIMESTAMP|_USER)?|CURSOR|CYCLE|DATA(?:BASES?)?|DATE(?:TIME)?|DAY|DBCC|DEALLOCATE|DEC|DECIMAL|DECLARE|DEFAULT|DEFINER|DELAYED|DELETE|DELIMITERS?|DENY|DESC|DESCRIBE|DETERMINISTIC|DISABLE|DISCARD|DISK|DISTINCT|DISTINCTROW|DISTRIBUTED|DO|DOUBLE|DROP|DUMMY|DUMP(?:FILE)?|DUPLICATE|ELSE(?:IF)?|ENABLE|ENCLOSED|END|ENGINE|ENUM|ERRLVL|ERRORS|ESCAPED?|EXCEPT|EXEC(?:UTE)?|EXISTS|EXIT|EXPLAIN|EXTENDED|FETCH|FIELDS|FILE|FILLFACTOR|FIRST|FIXED|FLOAT|FOLLOWING|FOR(?: EACH ROW)?|FORCE|FOREIGN|FREETEXT(?:TABLE)?|FROM|FULL|FUNCTION|GEOMETRY(?:COLLECTION)?|GLOBAL|GOTO|GRANT|GROUP|HANDLER|HASH|HAVING|HOLDLOCK|HOUR|IDENTITY(?:COL|_INSERT)?|IF|IGNORE|IMPORT|INDEX|INFILE|INNER|INNODB|INOUT|INSERT|INT|INTEGER|INTERSECT|INTERVAL|INTO|INVOKER|ISOLATION|ITERATE|JOIN|KEYS?|KILL|LANGUAGE|LAST|LEAVE|LEFT|LEVEL|LIMIT|LINENO|LINES|LINESTRING|LOAD|LOCAL|LOCK|LONG(?:BLOB|TEXT)|LOOP|MATCH(?:ED)?|MEDIUM(?:BLOB|INT|TEXT)|MERGE|MIDDLEINT|MINUTE|MODE|MODIFIES|MODIFY|MONTH|MULTI(?:LINESTRING|POINT|POLYGON)|NATIONAL|NATURAL|NCHAR|NEXT|NO|NONCLUSTERED|NULLIF|NUMERIC|OFF?|OFFSETS?|ON|OPEN(?:DATASOURCE|QUERY|ROWSET)?|OPTIMIZE|OPTION(?:ALLY)?|ORDER|OUT(?:ER|FILE)?|OVER|PARTIAL|PARTITION|PERCENT|PIVOT|PLAN|POINT|POLYGON|PRECEDING|PRECISION|PREPARE|PREV|PRIMARY|PRINT|PRIVILEGES|PROC(?:EDURE)?|PUBLIC|PURGE|QUICK|RAISERROR|READS?|REAL|RECONFIGURE|REFERENCES|RELEASE|RENAME|REPEAT(?:ABLE)?|REPLACE|REPLICATION|REQUIRE|RESIGNAL|RESTORE|RESTRICT|RETURN(?:ING|S)?|REVOKE|RIGHT|ROLLBACK|ROUTINE|ROW(?:COUNT|GUIDCOL|S)?|RTREE|RULE|SAVE(?:POINT)?|SCHEMA|SECOND|SELECT|SERIAL(?:IZABLE)?|SESSION(?:_USER)?|SET(?:USER)?|SHARE|SHOW|SHUTDOWN|SIMPLE|SMALLINT|SNAPSHOT|SOME|SONAME|SQL|START(?:ING)?|STATISTICS|STATUS|STRIPED|SYSTEM_USER|TABLES?|TABLESPACE|TEMP(?:ORARY|TABLE)?|TERMINATED|TEXT(?:SIZE)?|THEN|TIME(?:STAMP)?|TINY(?:BLOB|INT|TEXT)|TOP?|TRAN(?:SACTIONS?)?|TRIGGER|TRUNCATE|TSEQUAL|TYPES?|UNBOUNDED|UNCOMMITTED|UNDEFINED|UNION|UNIQUE|UNLOCK|UNPIVOT|UNSIGNED|UPDATE(?:TEXT)?|USAGE|USE|USER|USING|VALUES?|VAR(?:BINARY|CHAR|CHARACTER|YING)|VIEW|WAITFOR|WARNINGS|WHEN|WHERE|WHILE|WITH(?: ROLLUP|IN)?|WORK|WRITE(?:TEXT)?|YEAR)\b/i,
  boolean: /\b(?:FALSE|NULL|TRUE)\b/i,
  number: /\b0x[\da-f]+\b|\b\d+(?:\.\d*)?|\B\.\d+\b/i,
  operator: /[-+*\/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?|\b(?:AND|BETWEEN|DIV|ILIKE|IN|IS|LIKE|NOT|OR|REGEXP|RLIKE|SOUNDS LIKE|XOR)\b/i,
  punctuation: /[;[\]()`,.]/
};
(function(t) {
  var e = /\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|do|double|else|enum|exports|extends|final|finally|float|for|goto|if|implements|import|instanceof|int|interface|long|module|native|new|non-sealed|null|open|opens|package|permits|private|protected|provides|public|record(?!\s*[(){}[\]<>=%~.:,;?+\-*/&|^])|requires|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|to|transient|transitive|try|uses|var|void|volatile|while|with|yield)\b/, n = /(?:[a-z]\w*\s*\.\s*)*(?:[A-Z]\w*\s*\.\s*)*/.source, i = {
    pattern: RegExp(/(^|[^\w.])/.source + n + /[A-Z](?:[\d_A-Z]*[a-z]\w*)?\b/.source),
    lookbehind: !0,
    inside: {
      namespace: {
        pattern: /^[a-z]\w*(?:\s*\.\s*[a-z]\w*)*(?:\s*\.)?/,
        inside: {
          punctuation: /\./
        }
      },
      punctuation: /\./
    }
  };
  t.languages.java = t.languages.extend("clike", {
    string: {
      pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"/,
      lookbehind: !0,
      greedy: !0
    },
    "class-name": [
      i,
      {
        // variables, parameters, and constructor references
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(^|[^\w.])/.source + n + /[A-Z]\w*(?=\s+\w+\s*[;,=()]|\s*(?:\[[\s,]*\]\s*)?::\s*new\b)/.source),
        lookbehind: !0,
        inside: i.inside
      },
      {
        // class names based on keyword
        // this to support class names (or generic parameters) which do not contain a lower case letter (also works for methods)
        pattern: RegExp(/(\b(?:class|enum|extends|implements|instanceof|interface|new|record|throws)\s+)/.source + n + /[A-Z]\w*\b/.source),
        lookbehind: !0,
        inside: i.inside
      }
    ],
    keyword: e,
    function: [
      t.languages.clike.function,
      {
        pattern: /(::\s*)[a-z_]\w*/,
        lookbehind: !0
      }
    ],
    number: /\b0b[01][01_]*L?\b|\b0x(?:\.[\da-f_p+-]+|[\da-f_]+(?:\.[\da-f_p+-]+)?)\b|(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?\d[\d_]*)?[dfl]?/i,
    operator: {
      pattern: /(^|[^.])(?:<<=?|>>>?=?|->|--|\+\+|&&|\|\||::|[?:~]|[-+*/%&|^!=<>]=?)/m,
      lookbehind: !0
    },
    constant: /\b[A-Z][A-Z_\d]+\b/
  }), t.languages.insertBefore("java", "string", {
    "triple-quoted-string": {
      // http://openjdk.java.net/jeps/355#Description
      pattern: /"""[ \t]*[\r\n](?:(?:"|"")?(?:\\.|[^"\\]))*"""/,
      greedy: !0,
      alias: "string"
    },
    char: {
      pattern: /'(?:\\.|[^'\\\r\n]){1,6}'/,
      greedy: !0
    }
  }), t.languages.insertBefore("java", "class-name", {
    annotation: {
      pattern: /(^|[^.])@\w+(?:\s*\.\s*\w+)*/,
      lookbehind: !0,
      alias: "punctuation"
    },
    generics: {
      pattern: /<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&)|<(?:[\w\s,.?]|&(?!&))*>)*>)*>)*>/,
      inside: {
        "class-name": i,
        keyword: e,
        punctuation: /[<>(),.:]/,
        operator: /[?&|]/
      }
    },
    import: [
      {
        pattern: RegExp(/(\bimport\s+)/.source + n + /(?:[A-Z]\w*|\*)(?=\s*;)/.source),
        lookbehind: !0,
        inside: {
          namespace: i.inside.namespace,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      },
      {
        pattern: RegExp(/(\bimport\s+static\s+)/.source + n + /(?:\w+|\*)(?=\s*;)/.source),
        lookbehind: !0,
        alias: "static",
        inside: {
          namespace: i.inside.namespace,
          static: /\b\w+$/,
          punctuation: /\./,
          operator: /\*/,
          "class-name": /\w+/
        }
      }
    ],
    namespace: {
      pattern: RegExp(
        /(\b(?:exports|import(?:\s+static)?|module|open|opens|package|provides|requires|to|transitive|uses|with)\s+)(?!<keyword>)[a-z]\w*(?:\.[a-z]\w*)*\.?/.source.replace(/<keyword>/g, function() {
          return e.source;
        })
      ),
      lookbehind: !0,
      inside: {
        punctuation: /\./
      }
    }
  });
})(Prism);
Prism.languages.go = Prism.languages.extend("clike", {
  string: {
    pattern: /(^|[^\\])"(?:\\.|[^"\\\r\n])*"|`[^`]*`/,
    lookbehind: !0,
    greedy: !0
  },
  keyword: /\b(?:break|case|chan|const|continue|default|defer|else|fallthrough|for|func|go(?:to)?|if|import|interface|map|package|range|return|select|struct|switch|type|var)\b/,
  boolean: /\b(?:_|false|iota|nil|true)\b/,
  number: [
    // binary and octal integers
    /\b0(?:b[01_]+|o[0-7_]+)i?\b/i,
    // hexadecimal integers and floats
    /\b0x(?:[a-f\d_]+(?:\.[a-f\d_]*)?|\.[a-f\d_]+)(?:p[+-]?\d+(?:_\d+)*)?i?(?!\w)/i,
    // decimal integers and floats
    /(?:\b\d[\d_]*(?:\.[\d_]*)?|\B\.\d[\d_]*)(?:e[+-]?[\d_]+)?i?(?!\w)/i
  ],
  operator: /[*\/%^!=]=?|\+[=+]?|-[=-]?|\|[=|]?|&(?:=|&|\^=?)?|>(?:>=?|=)?|<(?:<=?|=|-)?|:=|\.\.\./,
  builtin: /\b(?:append|bool|byte|cap|close|complex|complex(?:64|128)|copy|delete|error|float(?:32|64)|u?int(?:8|16|32|64)?|imag|len|make|new|panic|print(?:ln)?|real|recover|rune|string|uintptr)\b/
});
Prism.languages.insertBefore("go", "string", {
  char: {
    pattern: /'(?:\\.|[^'\\\r\n]){0,10}'/,
    greedy: !0
  }
});
delete Prism.languages.go["class-name"];
(function(t) {
  for (var e = /\/\*(?:[^*/]|\*(?!\/)|\/(?!\*)|<self>)*\*\//.source, n = 0; n < 2; n++)
    e = e.replace(/<self>/g, function() {
      return e;
    });
  e = e.replace(/<self>/g, function() {
    return /[^\s\S]/.source;
  }), t.languages.rust = {
    comment: [
      {
        pattern: RegExp(/(^|[^\\])/.source + e),
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /b?"(?:\\[\s\S]|[^\\"])*"|b?r(#*)"(?:[^"]|"(?!\1))*"\1/,
      greedy: !0
    },
    char: {
      pattern: /b?'(?:\\(?:x[0-7][\da-fA-F]|u\{(?:[\da-fA-F]_*){1,6}\}|.)|[^\\\r\n\t'])'/,
      greedy: !0
    },
    attribute: {
      pattern: /#!?\[(?:[^\[\]"]|"(?:\\[\s\S]|[^\\"])*")*\]/,
      greedy: !0,
      alias: "attr-name",
      inside: {
        string: null
        // see below
      }
    },
    // Closure params should not be confused with bitwise OR |
    "closure-params": {
      pattern: /([=(,:]\s*|\bmove\s*)\|[^|]*\||\|[^|]*\|(?=\s*(?:\{|->))/,
      lookbehind: !0,
      greedy: !0,
      inside: {
        "closure-punctuation": {
          pattern: /^\||\|$/,
          alias: "punctuation"
        },
        rest: null
        // see below
      }
    },
    "lifetime-annotation": {
      pattern: /'\w+/,
      alias: "symbol"
    },
    "fragment-specifier": {
      pattern: /(\$\w+:)[a-z]+/,
      lookbehind: !0,
      alias: "punctuation"
    },
    variable: /\$\w+/,
    "function-definition": {
      pattern: /(\bfn\s+)\w+/,
      lookbehind: !0,
      alias: "function"
    },
    "type-definition": {
      pattern: /(\b(?:enum|struct|trait|type|union)\s+)\w+/,
      lookbehind: !0,
      alias: "class-name"
    },
    "module-declaration": [
      {
        pattern: /(\b(?:crate|mod)\s+)[a-z][a-z_\d]*/,
        lookbehind: !0,
        alias: "namespace"
      },
      {
        pattern: /(\b(?:crate|self|super)\s*)::\s*[a-z][a-z_\d]*\b(?:\s*::(?:\s*[a-z][a-z_\d]*\s*::)*)?/,
        lookbehind: !0,
        alias: "namespace",
        inside: {
          punctuation: /::/
        }
      }
    ],
    keyword: [
      // https://github.com/rust-lang/reference/blob/master/src/keywords.md
      /\b(?:Self|abstract|as|async|await|become|box|break|const|continue|crate|do|dyn|else|enum|extern|final|fn|for|if|impl|in|let|loop|macro|match|mod|move|mut|override|priv|pub|ref|return|self|static|struct|super|trait|try|type|typeof|union|unsafe|unsized|use|virtual|where|while|yield)\b/,
      // primitives and str
      // https://doc.rust-lang.org/stable/rust-by-example/primitives.html
      /\b(?:bool|char|f(?:32|64)|[ui](?:8|16|32|64|128|size)|str)\b/
    ],
    // functions can technically start with an upper-case letter, but this will introduce a lot of false positives
    // and Rust's naming conventions recommend snake_case anyway.
    // https://doc.rust-lang.org/1.0.0/style/style/naming/README.html
    function: /\b[a-z_]\w*(?=\s*(?:::\s*<|\())/,
    macro: {
      pattern: /\b\w+!/,
      alias: "property"
    },
    constant: /\b[A-Z_][A-Z_\d]+\b/,
    "class-name": /\b[A-Z]\w*\b/,
    namespace: {
      pattern: /(?:\b[a-z][a-z_\d]*\s*::\s*)*\b[a-z][a-z_\d]*\s*::(?!\s*<)/,
      inside: {
        punctuation: /::/
      }
    },
    // Hex, oct, bin, dec numbers with visual separators and type suffix
    number: /\b(?:0x[\dA-Fa-f](?:_?[\dA-Fa-f])*|0o[0-7](?:_?[0-7])*|0b[01](?:_?[01])*|(?:(?:\d(?:_?\d)*)?\.)?\d(?:_?\d)*(?:[Ee][+-]?\d+)?)(?:_?(?:f32|f64|[iu](?:8|16|32|64|size)?))?\b/,
    boolean: /\b(?:false|true)\b/,
    punctuation: /->|\.\.=|\.{1,3}|::|[{}[\];(),:]/,
    operator: /[-+*\/%!^]=?|=[=>]?|&[&=]?|\|[|=]?|<<?=?|>>?=?|[@?]/
  }, t.languages.rust["closure-params"].inside.rest = t.languages.rust, t.languages.rust.attribute.inside.string = t.languages.rust.string;
})(Prism);
(function(t) {
  var e = /\/\*[\s\S]*?\*\/|\/\/.*|#(?!\[).*/, n = [
    {
      pattern: /\b(?:false|true)\b/i,
      alias: "boolean"
    },
    {
      pattern: /(::\s*)\b[a-z_]\w*\b(?!\s*\()/i,
      greedy: !0,
      lookbehind: !0
    },
    {
      pattern: /(\b(?:case|const)\s+)\b[a-z_]\w*(?=\s*[;=])/i,
      greedy: !0,
      lookbehind: !0
    },
    /\b(?:null)\b/i,
    /\b[A-Z_][A-Z0-9_]*\b(?!\s*\()/
  ], i = /\b0b[01]+(?:_[01]+)*\b|\b0o[0-7]+(?:_[0-7]+)*\b|\b0x[\da-f]+(?:_[\da-f]+)*\b|(?:\b\d+(?:_\d+)*\.?(?:\d+(?:_\d+)*)?|\B\.\d+)(?:e[+-]?\d+)?/i, r = /<?=>|\?\?=?|\.{3}|\??->|[!=]=?=?|::|\*\*=?|--|\+\+|&&|\|\||<<|>>|[?~]|[/^|%*&<>.+-]=?/, o = /[{}\[\](),:;]/;
  t.languages.php = {
    delimiter: {
      pattern: /\?>$|^<\?(?:php(?=\s)|=)?/i,
      alias: "important"
    },
    comment: e,
    variable: /\$+(?:\w+\b|(?=\{))/,
    package: {
      pattern: /(namespace\s+|use\s+(?:function\s+)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    "class-name-definition": {
      pattern: /(\b(?:class|enum|interface|trait)\s+)\b[a-z_]\w*(?!\\)\b/i,
      lookbehind: !0,
      alias: "class-name"
    },
    "function-definition": {
      pattern: /(\bfunction\s+)[a-z_]\w*(?=\s*\()/i,
      lookbehind: !0,
      alias: "function"
    },
    keyword: [
      {
        pattern: /(\(\s*)\b(?:array|bool|boolean|float|int|integer|object|string)\b(?=\s*\))/i,
        alias: "type-casting",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|object|self|static|string)\b(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b(?:array(?!\s*\()|bool|callable|(?:false|null)(?=\s*\|)|float|int|iterable|mixed|never|object|self|static|string|void)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:array(?!\s*\()|bool|float|int|iterable|mixed|object|string|void)\b/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:false|null)\b|\b(?:false|null)(?=\s*\|)/i,
        alias: "type-declaration",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b(?:parent|self|static)(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        // yield from
        pattern: /(\byield\s+)from\b/i,
        lookbehind: !0
      },
      // `class` is always a keyword unlike other keywords
      /\bclass\b/i,
      {
        // https://www.php.net/manual/en/reserved.keywords.php
        //
        // keywords cannot be preceded by "->"
        // the complex lookbehind means `(?<!(?:->|::)\s*)`
        pattern: /((?:^|[^\s>:]|(?:^|[^-])>|(?:^|[^:]):)\s*)\b(?:abstract|and|array|as|break|callable|case|catch|clone|const|continue|declare|default|die|do|echo|else|elseif|empty|enddeclare|endfor|endforeach|endif|endswitch|endwhile|enum|eval|exit|extends|final|finally|fn|for|foreach|function|global|goto|if|implements|include|include_once|instanceof|insteadof|interface|isset|list|match|namespace|never|new|or|parent|print|private|protected|public|readonly|require|require_once|return|self|static|switch|throw|trait|try|unset|use|var|while|xor|yield|__halt_compiler)\b/i,
        lookbehind: !0
      }
    ],
    "argument-name": {
      pattern: /([(,]\s*)\b[a-z_]\w*(?=\s*:(?!:))/i,
      lookbehind: !0
    },
    "class-name": [
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self|\s+static))\s+|\bcatch\s*\()\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\|\s*)\b[a-z_]\w*(?!\\)\b/i,
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /\b[a-z_]\w*(?!\\)\b(?=\s*\|)/i,
        greedy: !0
      },
      {
        pattern: /(\|\s*)(?:\\?\b[a-z_]\w*)+\b/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+\b(?=\s*\|)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\b(?:extends|implements|instanceof|new(?!\s+self\b|\s+static\b))\s+|\bcatch\s*\()(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: "class-name-fully-qualified",
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*\$)/i,
        alias: "type-declaration",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-declaration"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /\b[a-z_]\w*(?=\s*::)/i,
        alias: "static-context",
        greedy: !0
      },
      {
        pattern: /(?:\\?\b[a-z_]\w*)+(?=\s*::)/i,
        alias: ["class-name-fully-qualified", "static-context"],
        greedy: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /([(,?]\s*)[a-z_]\w*(?=\s*\$)/i,
        alias: "type-hint",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /([(,?]\s*)(?:\\?\b[a-z_]\w*)+(?=\s*\$)/i,
        alias: ["class-name-fully-qualified", "type-hint"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)\b[a-z_]\w*(?!\\)\b/i,
        alias: "return-type",
        greedy: !0,
        lookbehind: !0
      },
      {
        pattern: /(\)\s*:\s*(?:\?\s*)?)(?:\\?\b[a-z_]\w*)+\b(?!\\)/i,
        alias: ["class-name-fully-qualified", "return-type"],
        greedy: !0,
        lookbehind: !0,
        inside: {
          punctuation: /\\/
        }
      }
    ],
    constant: n,
    function: {
      pattern: /(^|[^\\\w])\\?[a-z_](?:[\w\\]*\w)?(?=\s*\()/i,
      lookbehind: !0,
      inside: {
        punctuation: /\\/
      }
    },
    property: {
      pattern: /(->\s*)\w+/,
      lookbehind: !0
    },
    number: i,
    operator: r,
    punctuation: o
  };
  var a = {
    pattern: /\{\$(?:\{(?:\{[^{}]+\}|[^{}]+)\}|[^{}])+\}|(^|[^\\{])\$+(?:\w+(?:\[[^\r\n\[\]]+\]|->\w+)?)/,
    lookbehind: !0,
    inside: t.languages.php
  }, s = [
    {
      pattern: /<<<'([^']+)'[\r\n](?:.*[\r\n])*?\1;/,
      alias: "nowdoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<'[^']+'|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<'?|[';]$/
          }
        }
      }
    },
    {
      pattern: /<<<(?:"([^"]+)"[\r\n](?:.*[\r\n])*?\1;|([a-z_]\w*)[\r\n](?:.*[\r\n])*?\2;)/i,
      alias: "heredoc-string",
      greedy: !0,
      inside: {
        delimiter: {
          pattern: /^<<<(?:"[^"]+"|[a-z_]\w*)|[a-z_]\w*;$/i,
          alias: "symbol",
          inside: {
            punctuation: /^<<<"?|[";]$/
          }
        },
        interpolation: a
      }
    },
    {
      pattern: /`(?:\\[\s\S]|[^\\`])*`/,
      alias: "backtick-quoted-string",
      greedy: !0
    },
    {
      pattern: /'(?:\\[\s\S]|[^\\'])*'/,
      alias: "single-quoted-string",
      greedy: !0
    },
    {
      pattern: /"(?:\\[\s\S]|[^\\"])*"/,
      alias: "double-quoted-string",
      greedy: !0,
      inside: {
        interpolation: a
      }
    }
  ];
  t.languages.insertBefore("php", "variable", {
    string: s,
    attribute: {
      pattern: /#\[(?:[^"'\/#]|\/(?![*/])|\/\/.*$|#(?!\[).*$|\/\*(?:[^*]|\*(?!\/))*\*\/|"(?:\\[\s\S]|[^\\"])*"|'(?:\\[\s\S]|[^\\'])*')+\](?=\s*[a-z$#])/im,
      greedy: !0,
      inside: {
        "attribute-content": {
          pattern: /^(#\[)[\s\S]+(?=\]$)/,
          lookbehind: !0,
          // inside can appear subset of php
          inside: {
            comment: e,
            string: s,
            "attribute-class-name": [
              {
                pattern: /([^:]|^)\b[a-z_]\w*(?!\\)\b/i,
                alias: "class-name",
                greedy: !0,
                lookbehind: !0
              },
              {
                pattern: /([^:]|^)(?:\\?\b[a-z_]\w*)+/i,
                alias: [
                  "class-name",
                  "class-name-fully-qualified"
                ],
                greedy: !0,
                lookbehind: !0,
                inside: {
                  punctuation: /\\/
                }
              }
            ],
            constant: n,
            number: i,
            operator: r,
            punctuation: o
          }
        },
        delimiter: {
          pattern: /^#\[|\]$/,
          alias: "punctuation"
        }
      }
    }
  }), t.hooks.add("before-tokenize", function(l) {
    if (/<\?/.test(l.code)) {
      var u = /<\?(?:[^"'/#]|\/(?![*/])|("|')(?:\\[\s\S]|(?!\1)[^\\])*\1|(?:\/\/|#(?!\[))(?:[^?\n\r]|\?(?!>))*(?=$|\?>|[\r\n])|#\[|\/\*(?:[^*]|\*(?!\/))*(?:\*\/|$))*?(?:\?>|$)/g;
      t.languages["markup-templating"].buildPlaceholders(l, "php", u);
    }
  }), t.hooks.add("after-tokenize", function(l) {
    t.languages["markup-templating"].tokenizePlaceholders(l, "php");
  });
})(Prism);
(function(t) {
  var e = /[*&][^\s[\]{},]+/, n = /!(?:<[\w\-%#;/?:@&=+$,.!~*'()[\]]+>|(?:[a-zA-Z\d-]*!)?[\w\-%#;/?:@&=+$.~*'()]+)?/, i = "(?:" + n.source + "(?:[ 	]+" + e.source + ")?|" + e.source + "(?:[ 	]+" + n.source + ")?)", r = /(?:[^\s\x00-\x08\x0e-\x1f!"#%&'*,\-:>?@[\]`{|}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]|[?:-]<PLAIN>)(?:[ \t]*(?:(?![#:])<PLAIN>|:<PLAIN>))*/.source.replace(/<PLAIN>/g, function() {
    return /[^\s\x00-\x08\x0e-\x1f,[\]{}\x7f-\x84\x86-\x9f\ud800-\udfff\ufffe\uffff]/.source;
  }), o = /"(?:[^"\\\r\n]|\\.)*"|'(?:[^'\\\r\n]|\\.)*'/.source;
  function a(s, l) {
    l = (l || "").replace(/m/g, "") + "m";
    var u = /([:\-,[{]\s*(?:\s<<prop>>[ \t]+)?)(?:<<value>>)(?=[ \t]*(?:$|,|\]|\}|(?:[\r\n]\s*)?#))/.source.replace(/<<prop>>/g, function() {
      return i;
    }).replace(/<<value>>/g, function() {
      return s;
    });
    return RegExp(u, l);
  }
  t.languages.yaml = {
    scalar: {
      pattern: RegExp(/([\-:]\s*(?:\s<<prop>>[ \t]+)?[|>])[ \t]*(?:((?:\r?\n|\r)[ \t]+)\S[^\r\n]*(?:\2[^\r\n]+)*)/.source.replace(/<<prop>>/g, function() {
        return i;
      })),
      lookbehind: !0,
      alias: "string"
    },
    comment: /#.*/,
    key: {
      pattern: RegExp(/((?:^|[:\-,[{\r\n?])[ \t]*(?:<<prop>>[ \t]+)?)<<key>>(?=\s*:\s)/.source.replace(/<<prop>>/g, function() {
        return i;
      }).replace(/<<key>>/g, function() {
        return "(?:" + r + "|" + o + ")";
      })),
      lookbehind: !0,
      greedy: !0,
      alias: "atrule"
    },
    directive: {
      pattern: /(^[ \t]*)%.+/m,
      lookbehind: !0,
      alias: "important"
    },
    datetime: {
      pattern: a(/\d{4}-\d\d?-\d\d?(?:[tT]|[ \t]+)\d\d?:\d{2}:\d{2}(?:\.\d*)?(?:[ \t]*(?:Z|[-+]\d\d?(?::\d{2})?))?|\d{4}-\d{2}-\d{2}|\d\d?:\d{2}(?::\d{2}(?:\.\d*)?)?/.source),
      lookbehind: !0,
      alias: "number"
    },
    boolean: {
      pattern: a(/false|true/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    null: {
      pattern: a(/null|~/.source, "i"),
      lookbehind: !0,
      alias: "important"
    },
    string: {
      pattern: a(o),
      lookbehind: !0,
      greedy: !0
    },
    number: {
      pattern: a(/[+-]?(?:0x[\da-f]+|0o[0-7]+|(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|\.inf|\.nan)/.source, "i"),
      lookbehind: !0
    },
    tag: n,
    important: e,
    punctuation: /---|[:[\]{}\-,|>?]|\.\.\./
  }, t.languages.yml = t.languages.yaml;
})(Prism);
(function(t) {
  function e(n, i) {
    return "___" + n.toUpperCase() + i + "___";
  }
  Object.defineProperties(t.languages["markup-templating"] = {}, {
    buildPlaceholders: {
      /**
       * Tokenize all inline templating expressions matching `placeholderPattern`.
       *
       * If `replaceFilter` is provided, only matches of `placeholderPattern` for which `replaceFilter` returns
       * `true` will be replaced.
       *
       * @param {object} env The environment of the `before-tokenize` hook.
       * @param {string} language The language id.
       * @param {RegExp} placeholderPattern The matches of this pattern will be replaced by placeholders.
       * @param {(match: string) => boolean} [replaceFilter]
       */
      value: function(n, i, r, o) {
        if (n.language === i) {
          var a = n.tokenStack = [];
          n.code = n.code.replace(r, function(s) {
            if (typeof o == "function" && !o(s))
              return s;
            for (var l = a.length, u; n.code.indexOf(u = e(i, l)) !== -1; )
              ++l;
            return a[l] = s, u;
          }), n.grammar = t.languages.markup;
        }
      }
    },
    tokenizePlaceholders: {
      /**
       * Replace placeholders with proper tokens after tokenizing.
       *
       * @param {object} env The environment of the `after-tokenize` hook.
       * @param {string} language The language id.
       */
      value: function(n, i) {
        if (n.language !== i || !n.tokenStack)
          return;
        n.grammar = t.languages[i];
        var r = 0, o = Object.keys(n.tokenStack);
        function a(s) {
          for (var l = 0; l < s.length && !(r >= o.length); l++) {
            var u = s[l];
            if (typeof u == "string" || u.content && typeof u.content == "string") {
              var c = o[r], _ = n.tokenStack[c], h = typeof u == "string" ? u : u.content, p = e(i, c), b = h.indexOf(p);
              if (b > -1) {
                ++r;
                var y = h.substring(0, b), E = new t.Token(i, t.tokenize(_, n.grammar), "language-" + i, _), $ = h.substring(b + p.length), m = [];
                y && m.push.apply(m, a([y])), m.push(E), $ && m.push.apply(m, a([$])), typeof u == "string" ? s.splice.apply(s, [l, 1].concat(m)) : u.content = m;
              }
            } else u.content && a(u.content);
          }
          return s;
        }
        a(n.tokens);
      }
    }
  });
})(Prism);
new sa();
const ss = (t) => {
  const e = {};
  for (let n = 0, i = t.length; n < i; n++) {
    const r = t[n];
    for (const o in r)
      e[o] ? e[o] = e[o].concat(r[o]) : e[o] = r[o];
  }
  return e;
}, ls = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], us = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], cs = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
ss([
  Object.fromEntries(ls.map((t) => [t, ["*"]])),
  Object.fromEntries(us.map((t) => [t, ["svg:*"]])),
  Object.fromEntries(cs.map((t) => [t, ["math:*"]]))
]);
const {
  HtmlTagHydration: h$,
  SvelteComponent: _$,
  attr: d$,
  binding_callbacks: f$,
  children: p$,
  claim_element: m$,
  claim_html_tag: g$,
  detach: b$,
  element: v$,
  init: y$,
  insert_hydration: E$,
  noop: D$,
  safe_not_equal: w$,
  toggle_class: $$
} = window.__gradio__svelte__internal, { afterUpdate: F$, tick: A$, onMount: k$ } = window.__gradio__svelte__internal, {
  SvelteComponent: C$,
  attr: S$,
  children: x$,
  claim_component: T$,
  claim_element: B$,
  create_component: I$,
  destroy_component: R$,
  detach: L$,
  element: N$,
  init: O$,
  insert_hydration: P$,
  mount_component: H$,
  safe_not_equal: M$,
  transition_in: q$,
  transition_out: U$
} = window.__gradio__svelte__internal, {
  SvelteComponent: z$,
  attr: G$,
  check_outros: j$,
  children: V$,
  claim_component: X$,
  claim_element: Z$,
  claim_space: W$,
  create_component: Y$,
  create_slot: Q$,
  destroy_component: K$,
  detach: J$,
  element: eF,
  empty: tF,
  get_all_dirty_from_scope: nF,
  get_slot_changes: iF,
  group_outros: rF,
  init: aF,
  insert_hydration: oF,
  mount_component: sF,
  safe_not_equal: lF,
  space: uF,
  toggle_class: cF,
  transition_in: hF,
  transition_out: _F,
  update_slot_base: dF
} = window.__gradio__svelte__internal, {
  SvelteComponent: hs,
  append_hydration: bn,
  attr: Ve,
  children: Ii,
  claim_component: _s,
  claim_element: Ri,
  claim_space: ds,
  claim_text: fs,
  create_component: ps,
  destroy_component: ms,
  detach: vn,
  element: Li,
  init: gs,
  insert_hydration: bs,
  mount_component: vs,
  safe_not_equal: ys,
  set_data: Es,
  space: Ds,
  text: ws,
  toggle_class: Le,
  transition_in: $s,
  transition_out: Fs
} = window.__gradio__svelte__internal;
function As(t) {
  let e, n, i, r, o, a, s;
  return i = new /*Icon*/
  t[1]({}), {
    c() {
      e = Li("label"), n = Li("span"), ps(i.$$.fragment), r = Ds(), o = ws(
        /*label*/
        t[0]
      ), this.h();
    },
    l(l) {
      e = Ri(l, "LABEL", {
        for: !0,
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var u = Ii(e);
      n = Ri(u, "SPAN", { class: !0 });
      var c = Ii(n);
      _s(i.$$.fragment, c), c.forEach(vn), r = ds(u), o = fs(
        u,
        /*label*/
        t[0]
      ), u.forEach(vn), this.h();
    },
    h() {
      Ve(n, "class", "svelte-igqdol"), Ve(e, "for", ""), Ve(e, "data-testid", "block-label"), Ve(e, "dir", a = /*rtl*/
      t[5] ? "rtl" : "ltr"), Ve(e, "class", "svelte-igqdol"), Le(e, "hide", !/*show_label*/
      t[2]), Le(e, "sr-only", !/*show_label*/
      t[2]), Le(
        e,
        "float",
        /*float*/
        t[4]
      ), Le(
        e,
        "hide-label",
        /*disable*/
        t[3]
      );
    },
    m(l, u) {
      bs(l, e, u), bn(e, n), vs(i, n, null), bn(e, r), bn(e, o), s = !0;
    },
    p(l, [u]) {
      (!s || u & /*label*/
      1) && Es(
        o,
        /*label*/
        l[0]
      ), (!s || u & /*rtl*/
      32 && a !== (a = /*rtl*/
      l[5] ? "rtl" : "ltr")) && Ve(e, "dir", a), (!s || u & /*show_label*/
      4) && Le(e, "hide", !/*show_label*/
      l[2]), (!s || u & /*show_label*/
      4) && Le(e, "sr-only", !/*show_label*/
      l[2]), (!s || u & /*float*/
      16) && Le(
        e,
        "float",
        /*float*/
        l[4]
      ), (!s || u & /*disable*/
      8) && Le(
        e,
        "hide-label",
        /*disable*/
        l[3]
      );
    },
    i(l) {
      s || ($s(i.$$.fragment, l), s = !0);
    },
    o(l) {
      Fs(i.$$.fragment, l), s = !1;
    },
    d(l) {
      l && vn(e), ms(i);
    }
  };
}
function ks(t, e, n) {
  let { label: i = null } = e, { Icon: r } = e, { show_label: o = !0 } = e, { disable: a = !1 } = e, { float: s = !0 } = e, { rtl: l = !1 } = e;
  return t.$$set = (u) => {
    "label" in u && n(0, i = u.label), "Icon" in u && n(1, r = u.Icon), "show_label" in u && n(2, o = u.show_label), "disable" in u && n(3, a = u.disable), "float" in u && n(4, s = u.float), "rtl" in u && n(5, l = u.rtl);
  }, [i, r, o, a, s, l];
}
class Cs extends hs {
  constructor(e) {
    super(), gs(this, e, ks, As, ys, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4,
      rtl: 5
    });
  }
}
const {
  SvelteComponent: fF,
  assign: pF,
  children: mF,
  claim_element: gF,
  compute_rest_props: bF,
  create_slot: vF,
  detach: yF,
  element: EF,
  exclude_internal_props: DF,
  get_all_dirty_from_scope: wF,
  get_slot_changes: $F,
  get_spread_update: FF,
  init: AF,
  insert_hydration: kF,
  listen: CF,
  safe_not_equal: SF,
  set_attributes: xF,
  set_style: TF,
  toggle_class: BF,
  transition_in: IF,
  transition_out: RF,
  update_slot_base: LF
} = window.__gradio__svelte__internal, { createEventDispatcher: NF } = window.__gradio__svelte__internal, {
  SvelteComponent: Ss,
  append_hydration: Ht,
  attr: Be,
  bubble: xs,
  check_outros: Ts,
  children: Hn,
  claim_component: Bs,
  claim_element: Mn,
  claim_space: Ni,
  claim_text: Is,
  construct_svelte_component: Oi,
  create_component: Pi,
  create_slot: Rs,
  destroy_component: Hi,
  detach: ft,
  element: qn,
  get_all_dirty_from_scope: Ls,
  get_slot_changes: Ns,
  group_outros: Os,
  init: Ps,
  insert_hydration: la,
  listen: Hs,
  mount_component: Mi,
  safe_not_equal: Ms,
  set_data: qs,
  set_style: Xe,
  space: qi,
  text: Us,
  toggle_class: W,
  transition_in: yn,
  transition_out: En,
  update_slot_base: zs
} = window.__gradio__svelte__internal;
function Ui(t) {
  let e, n;
  return {
    c() {
      e = qn("span"), n = Us(
        /*label*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = Mn(i, "SPAN", { class: !0 });
      var r = Hn(e);
      n = Is(
        r,
        /*label*/
        t[1]
      ), r.forEach(ft), this.h();
    },
    h() {
      Be(e, "class", "svelte-y0enk4");
    },
    m(i, r) {
      la(i, e, r), Ht(e, n);
    },
    p(i, r) {
      r & /*label*/
      2 && qs(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && ft(e);
    }
  };
}
function Gs(t) {
  let e, n, i, r, o, a, s, l, u = (
    /*show_label*/
    t[2] && Ui(t)
  );
  var c = (
    /*Icon*/
    t[0]
  );
  function _(b, y) {
    return {};
  }
  c && (r = Oi(c, _()));
  const h = (
    /*#slots*/
    t[15].default
  ), p = Rs(
    h,
    t,
    /*$$scope*/
    t[14],
    null
  );
  return {
    c() {
      e = qn("button"), u && u.c(), n = qi(), i = qn("div"), r && Pi(r.$$.fragment), o = qi(), p && p.c(), this.h();
    },
    l(b) {
      e = Mn(b, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0
      });
      var y = Hn(e);
      u && u.l(y), n = Ni(y), i = Mn(y, "DIV", { class: !0 });
      var E = Hn(i);
      r && Bs(r.$$.fragment, E), o = Ni(E), p && p.l(E), E.forEach(ft), y.forEach(ft), this.h();
    },
    h() {
      Be(i, "class", "svelte-y0enk4"), W(
        i,
        "x-small",
        /*size*/
        t[4] === "x-small"
      ), W(
        i,
        "small",
        /*size*/
        t[4] === "small"
      ), W(
        i,
        "large",
        /*size*/
        t[4] === "large"
      ), W(
        i,
        "medium",
        /*size*/
        t[4] === "medium"
      ), Be(e, "class", "icon-button svelte-y0enk4"), e.disabled = /*disabled*/
      t[7], Be(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), Be(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), Be(
        e,
        "title",
        /*label*/
        t[1]
      ), W(
        e,
        "pending",
        /*pending*/
        t[3]
      ), W(
        e,
        "padded",
        /*padded*/
        t[5]
      ), W(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), W(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), Xe(
        e,
        "--border-color",
        /*border*/
        t[11]
      ), Xe(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[12] ? (
        /*_color*/
        t[12]
      ) : "var(--block-label-text-color)"), Xe(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      ));
    },
    m(b, y) {
      la(b, e, y), u && u.m(e, null), Ht(e, n), Ht(e, i), r && Mi(r, i, null), Ht(i, o), p && p.m(i, null), a = !0, s || (l = Hs(
        e,
        "click",
        /*click_handler*/
        t[16]
      ), s = !0);
    },
    p(b, [y]) {
      if (/*show_label*/
      b[2] ? u ? u.p(b, y) : (u = Ui(b), u.c(), u.m(e, n)) : u && (u.d(1), u = null), y & /*Icon*/
      1 && c !== (c = /*Icon*/
      b[0])) {
        if (r) {
          Os();
          const E = r;
          En(E.$$.fragment, 1, 0, () => {
            Hi(E, 1);
          }), Ts();
        }
        c ? (r = Oi(c, _()), Pi(r.$$.fragment), yn(r.$$.fragment, 1), Mi(r, i, o)) : r = null;
      }
      p && p.p && (!a || y & /*$$scope*/
      16384) && zs(
        p,
        h,
        b,
        /*$$scope*/
        b[14],
        a ? Ns(
          h,
          /*$$scope*/
          b[14],
          y,
          null
        ) : Ls(
          /*$$scope*/
          b[14]
        ),
        null
      ), (!a || y & /*size*/
      16) && W(
        i,
        "x-small",
        /*size*/
        b[4] === "x-small"
      ), (!a || y & /*size*/
      16) && W(
        i,
        "small",
        /*size*/
        b[4] === "small"
      ), (!a || y & /*size*/
      16) && W(
        i,
        "large",
        /*size*/
        b[4] === "large"
      ), (!a || y & /*size*/
      16) && W(
        i,
        "medium",
        /*size*/
        b[4] === "medium"
      ), (!a || y & /*disabled*/
      128) && (e.disabled = /*disabled*/
      b[7]), (!a || y & /*label*/
      2) && Be(
        e,
        "aria-label",
        /*label*/
        b[1]
      ), (!a || y & /*hasPopup*/
      256) && Be(
        e,
        "aria-haspopup",
        /*hasPopup*/
        b[8]
      ), (!a || y & /*label*/
      2) && Be(
        e,
        "title",
        /*label*/
        b[1]
      ), (!a || y & /*pending*/
      8) && W(
        e,
        "pending",
        /*pending*/
        b[3]
      ), (!a || y & /*padded*/
      32) && W(
        e,
        "padded",
        /*padded*/
        b[5]
      ), (!a || y & /*highlight*/
      64) && W(
        e,
        "highlight",
        /*highlight*/
        b[6]
      ), (!a || y & /*transparent*/
      512) && W(
        e,
        "transparent",
        /*transparent*/
        b[9]
      ), y & /*border*/
      2048 && Xe(
        e,
        "--border-color",
        /*border*/
        b[11]
      ), y & /*disabled, _color*/
      4224 && Xe(e, "color", !/*disabled*/
      b[7] && /*_color*/
      b[12] ? (
        /*_color*/
        b[12]
      ) : "var(--block-label-text-color)"), y & /*disabled, background*/
      1152 && Xe(e, "--bg-color", /*disabled*/
      b[7] ? "auto" : (
        /*background*/
        b[10]
      ));
    },
    i(b) {
      a || (r && yn(r.$$.fragment, b), yn(p, b), a = !0);
    },
    o(b) {
      r && En(r.$$.fragment, b), En(p, b), a = !1;
    },
    d(b) {
      b && ft(e), u && u.d(), r && Hi(r), p && p.d(b), s = !1, l();
    }
  };
}
function js(t, e, n) {
  let i, { $$slots: r = {}, $$scope: o } = e, { Icon: a } = e, { label: s = "" } = e, { show_label: l = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: _ = !0 } = e, { highlight: h = !1 } = e, { disabled: p = !1 } = e, { hasPopup: b = !1 } = e, { color: y = "var(--block-label-text-color)" } = e, { transparent: E = !1 } = e, { background: $ = "var(--block-background-fill)" } = e, { border: m = "transparent" } = e;
  function d(f) {
    xs.call(this, t, f);
  }
  return t.$$set = (f) => {
    "Icon" in f && n(0, a = f.Icon), "label" in f && n(1, s = f.label), "show_label" in f && n(2, l = f.show_label), "pending" in f && n(3, u = f.pending), "size" in f && n(4, c = f.size), "padded" in f && n(5, _ = f.padded), "highlight" in f && n(6, h = f.highlight), "disabled" in f && n(7, p = f.disabled), "hasPopup" in f && n(8, b = f.hasPopup), "color" in f && n(13, y = f.color), "transparent" in f && n(9, E = f.transparent), "background" in f && n(10, $ = f.background), "border" in f && n(11, m = f.border), "$$scope" in f && n(14, o = f.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    8256 && n(12, i = h ? "var(--color-accent)" : y);
  }, [
    a,
    s,
    l,
    u,
    c,
    _,
    h,
    p,
    b,
    E,
    $,
    m,
    i,
    y,
    o,
    r,
    d
  ];
}
class ua extends Ss {
  constructor(e) {
    super(), Ps(this, e, js, Gs, Ms, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      border: 11
    });
  }
}
const {
  SvelteComponent: OF,
  append_hydration: PF,
  attr: HF,
  binding_callbacks: MF,
  children: qF,
  claim_element: UF,
  create_slot: zF,
  detach: GF,
  element: jF,
  get_all_dirty_from_scope: VF,
  get_slot_changes: XF,
  init: ZF,
  insert_hydration: WF,
  safe_not_equal: YF,
  toggle_class: QF,
  transition_in: KF,
  transition_out: JF,
  update_slot_base: eA
} = window.__gradio__svelte__internal, Vs = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], zi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Vs.reduce(
  (t, { color: e, primary: n, secondary: i }) => ({
    ...t,
    [e]: {
      primary: zi[e][n],
      secondary: zi[e][i]
    }
  }),
  {}
);
const {
  SvelteComponent: tA,
  claim_component: nA,
  create_component: iA,
  destroy_component: rA,
  init: aA,
  mount_component: oA,
  safe_not_equal: sA,
  transition_in: lA,
  transition_out: uA
} = window.__gradio__svelte__internal, { createEventDispatcher: cA } = window.__gradio__svelte__internal, {
  SvelteComponent: hA,
  append_hydration: _A,
  attr: dA,
  check_outros: fA,
  children: pA,
  claim_component: mA,
  claim_element: gA,
  claim_space: bA,
  claim_text: vA,
  create_component: yA,
  destroy_component: EA,
  detach: DA,
  element: wA,
  empty: $A,
  group_outros: FA,
  init: AA,
  insert_hydration: kA,
  mount_component: CA,
  safe_not_equal: SA,
  set_data: xA,
  space: TA,
  text: BA,
  toggle_class: IA,
  transition_in: RA,
  transition_out: LA
} = window.__gradio__svelte__internal, {
  SvelteComponent: NA,
  attr: OA,
  children: PA,
  claim_element: HA,
  create_slot: MA,
  detach: qA,
  element: UA,
  get_all_dirty_from_scope: zA,
  get_slot_changes: GA,
  init: jA,
  insert_hydration: VA,
  safe_not_equal: XA,
  toggle_class: ZA,
  transition_in: WA,
  transition_out: YA,
  update_slot_base: QA
} = window.__gradio__svelte__internal, {
  SvelteComponent: KA,
  append_hydration: JA,
  attr: ek,
  check_outros: tk,
  children: nk,
  claim_component: ik,
  claim_element: rk,
  claim_space: ak,
  create_component: ok,
  destroy_component: sk,
  detach: lk,
  element: uk,
  empty: ck,
  group_outros: hk,
  init: _k,
  insert_hydration: dk,
  listen: fk,
  mount_component: pk,
  safe_not_equal: mk,
  space: gk,
  toggle_class: bk,
  transition_in: vk,
  transition_out: yk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ek,
  attr: Dk,
  children: wk,
  claim_element: $k,
  create_slot: Fk,
  detach: Ak,
  element: kk,
  get_all_dirty_from_scope: Ck,
  get_slot_changes: Sk,
  init: xk,
  insert_hydration: Tk,
  null_to_empty: Bk,
  safe_not_equal: Ik,
  transition_in: Rk,
  transition_out: Lk,
  update_slot_base: Nk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ok,
  check_outros: Pk,
  claim_component: Hk,
  create_component: Mk,
  destroy_component: qk,
  detach: Uk,
  empty: zk,
  group_outros: Gk,
  init: jk,
  insert_hydration: Vk,
  mount_component: Xk,
  noop: Zk,
  safe_not_equal: Wk,
  transition_in: Yk,
  transition_out: Qk
} = window.__gradio__svelte__internal, { createEventDispatcher: Kk } = window.__gradio__svelte__internal, {
  SvelteComponent: Xs,
  append_hydration: Gi,
  attr: Ze,
  children: Dn,
  claim_svg_element: wn,
  detach: It,
  init: Zs,
  insert_hydration: Ws,
  noop: $n,
  safe_not_equal: Ys,
  set_style: We,
  svg_element: Fn
} = window.__gradio__svelte__internal;
function Qs(t) {
  let e, n, i;
  return {
    c() {
      e = Fn("svg"), n = Fn("g"), i = Fn("path"), this.h();
    },
    l(r) {
      e = wn(r, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        style: !0
      });
      var o = Dn(e);
      n = wn(o, "g", { transform: !0 });
      var a = Dn(n);
      i = wn(a, "path", { d: !0, style: !0 }), Dn(i).forEach(It), a.forEach(It), o.forEach(It), this.h();
    },
    h() {
      Ze(i, "d", "M12.7,24.033C12.256,24.322 11.806,24.339 11.351,24.084C10.896,23.829 10.668,23.434 10.667,22.9L10.667,9.1C10.667,8.567 10.895,8.172 11.351,7.916C11.807,7.66 12.256,7.677 12.7,7.967L23.567,14.867C23.967,15.133 24.167,15.511 24.167,16C24.167,16.489 23.967,16.867 23.567,17.133L12.7,24.033Z"), We(i, "fill", "currentColor"), We(i, "fill-rule", "nonzero"), Ze(n, "transform", "matrix(1,0,0,1,-10.6667,-7.73588)"), Ze(e, "width", "100%"), Ze(e, "height", "100%"), Ze(e, "viewBox", "0 0 14 17"), Ze(e, "version", "1.1"), We(e, "fill-rule", "evenodd"), We(e, "clip-rule", "evenodd"), We(e, "stroke-linejoin", "round"), We(e, "stroke-miterlimit", "2");
    },
    m(r, o) {
      Ws(r, e, o), Gi(e, n), Gi(n, i);
    },
    p: $n,
    i: $n,
    o: $n,
    d(r) {
      r && It(e);
    }
  };
}
class Ks extends Xs {
  constructor(e) {
    super(), Zs(this, e, null, Qs, Ys, {});
  }
}
const {
  SvelteComponent: Js,
  attr: ji,
  claim_element: el,
  detach: tl,
  element: nl,
  init: il,
  insert_hydration: rl,
  listen: Vi,
  noop: Xi,
  run_all: al,
  safe_not_equal: ol,
  toggle_class: Zi
} = window.__gradio__svelte__internal, { createEventDispatcher: sl } = window.__gradio__svelte__internal;
function ll(t) {
  let e, n, i;
  return {
    c() {
      e = nl("input"), this.h();
    },
    l(r) {
      e = el(r, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      ji(e, "type", "checkbox"), e.disabled = /*disabled*/
      t[1], ji(e, "class", "svelte-34z85b"), Zi(
        e,
        "disabled",
        /*disabled*/
        t[1] && !/*value*/
        t[0]
      );
    },
    m(r, o) {
      rl(r, e, o), e.checked = /*value*/
      t[0], n || (i = [
        Vi(
          e,
          "change",
          /*input_change_handler*/
          t[3]
        ),
        Vi(
          e,
          "input",
          /*input_handler*/
          t[4]
        )
      ], n = !0);
    },
    p(r, [o]) {
      o & /*disabled*/
      2 && (e.disabled = /*disabled*/
      r[1]), o & /*value*/
      1 && (e.checked = /*value*/
      r[0]), o & /*disabled, value*/
      3 && Zi(
        e,
        "disabled",
        /*disabled*/
        r[1] && !/*value*/
        r[0]
      );
    },
    i: Xi,
    o: Xi,
    d(r) {
      r && tl(e), n = !1, al(i);
    }
  };
}
function ul(t, e, n) {
  let { value: i } = e, { disabled: r } = e;
  const o = sl();
  function a() {
    i = this.checked, n(0, i);
  }
  const s = () => o("change", !i);
  return t.$$set = (l) => {
    "value" in l && n(0, i = l.value), "disabled" in l && n(1, r = l.disabled);
  }, [i, r, o, a, s];
}
class cl extends Js {
  constructor(e) {
    super(), il(this, e, ul, ll, ol, { value: 0, disabled: 1 });
  }
}
const hl = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20width='32'%20height='32'%20viewBox='0%200%2024%2024'%3e%3cpath%20fill='%23888888'%20d='M6%202c-1.1%200-1.99.9-1.99%202L4%2020c0%201.1.89%202%201.99%202H18c1.1%200%202-.9%202-2V8l-6-6H6zm7%207V3.5L18.5%209H13z'/%3e%3c/svg%3e", {
  SvelteComponent: _l,
  append_hydration: Ye,
  attr: Ne,
  bubble: dl,
  check_outros: Un,
  children: jt,
  claim_component: li,
  claim_element: mt,
  claim_space: Rt,
  claim_text: fl,
  create_component: ui,
  destroy_component: ci,
  destroy_each: pl,
  detach: He,
  element: gt,
  ensure_array_like: Wi,
  get_svelte_dataset: ml,
  group_outros: zn,
  init: gl,
  insert_hydration: nn,
  listen: Yi,
  mount_component: hi,
  noop: An,
  run_all: bl,
  safe_not_equal: vl,
  set_data: yl,
  space: Lt,
  stop_propagation: El,
  text: Dl,
  toggle_class: Qi,
  transition_in: we,
  transition_out: Ie
} = window.__gradio__svelte__internal, { createEventDispatcher: wl } = window.__gradio__svelte__internal;
function Ki(t, e, n) {
  const i = t.slice();
  return i[19] = e[n].type, i[20] = e[n].name, i[21] = e[n].valid, i[23] = n, i;
}
function $l(t) {
  let e, n = `<img src="${hl}" alt="file icon" class="svelte-3bvdhr"/>`;
  return {
    c() {
      e = gt("span"), e.innerHTML = n, this.h();
    },
    l(i) {
      e = mt(i, "SPAN", { class: !0, "data-svelte-h": !0 }), ml(e) !== "svelte-1mrp2xz" && (e.innerHTML = n), this.h();
    },
    h() {
      Ne(e, "class", "file-icon svelte-3bvdhr");
    },
    m(i, r) {
      nn(i, e, r);
    },
    p: An,
    i: An,
    o: An,
    d(i) {
      i && He(e);
    }
  };
}
function Fl(t) {
  let e, n, i, r, o;
  n = new Ks({});
  function a() {
    return (
      /*click_handler*/
      t[14](
        /*i*/
        t[23]
      )
    );
  }
  function s(...l) {
    return (
      /*keydown_handler*/
      t[15](
        /*i*/
        t[23],
        ...l
      )
    );
  }
  return {
    c() {
      e = gt("span"), ui(n.$$.fragment), this.h();
    },
    l(l) {
      e = mt(l, "SPAN", {
        class: !0,
        role: !0,
        "aria-label": !0,
        tabindex: !0
      });
      var u = jt(e);
      li(n.$$.fragment, u), u.forEach(He), this.h();
    },
    h() {
      Ne(e, "class", "icon svelte-3bvdhr"), Ne(e, "role", "button"), Ne(e, "aria-label", "expand directory"), Ne(e, "tabindex", "0"), Qi(e, "hidden", !/*opened_folders*/
      t[6].includes(
        /*i*/
        t[23]
      ));
    },
    m(l, u) {
      nn(l, e, u), hi(n, e, null), i = !0, r || (o = [
        Yi(e, "click", El(a)),
        Yi(e, "keydown", s)
      ], r = !0);
    },
    p(l, u) {
      t = l, (!i || u & /*opened_folders*/
      64) && Qi(e, "hidden", !/*opened_folders*/
      t[6].includes(
        /*i*/
        t[23]
      ));
    },
    i(l) {
      i || (we(n.$$.fragment, l), i = !0);
    },
    o(l) {
      Ie(n.$$.fragment, l), i = !1;
    },
    d(l) {
      l && He(e), ci(n), r = !1, bl(o);
    }
  };
}
function Ji(t) {
  let e, n;
  function i(...r) {
    return (
      /*func_1*/
      t[16](
        /*name*/
        t[20],
        ...r
      )
    );
  }
  return e = new ca({
    props: {
      path: [
        .../*path*/
        t[0],
        /*name*/
        t[20]
      ],
      selected: (
        /*selected*/
        t[1].filter(i).map(tr)
      ),
      interactive: (
        /*interactive*/
        t[2]
      ),
      ls_fn: (
        /*ls_fn*/
        t[3]
      ),
      file_count: (
        /*file_count*/
        t[4]
      ),
      valid_for_selection: (
        /*valid*/
        t[21]
      )
    }
  }), e.$on(
    "check",
    /*check_handler*/
    t[17]
  ), {
    c() {
      ui(e.$$.fragment);
    },
    l(r) {
      li(e.$$.fragment, r);
    },
    m(r, o) {
      hi(e, r, o), n = !0;
    },
    p(r, o) {
      t = r;
      const a = {};
      o & /*path, content*/
      33 && (a.path = [
        .../*path*/
        t[0],
        /*name*/
        t[20]
      ]), o & /*selected, content*/
      34 && (a.selected = /*selected*/
      t[1].filter(i).map(tr)), o & /*interactive*/
      4 && (a.interactive = /*interactive*/
      t[2]), o & /*ls_fn*/
      8 && (a.ls_fn = /*ls_fn*/
      t[3]), o & /*file_count*/
      16 && (a.file_count = /*file_count*/
      t[4]), o & /*content*/
      32 && (a.valid_for_selection = /*valid*/
      t[21]), e.$set(a);
    },
    i(r) {
      n || (we(e.$$.fragment, r), n = !0);
    },
    o(r) {
      Ie(e.$$.fragment, r), n = !1;
    },
    d(r) {
      ci(e, r);
    }
  };
}
function er(t) {
  let e, n, i, r, o, a, s, l = (
    /*name*/
    t[20] + ""
  ), u, c, _ = (
    /*type*/
    t[19] === "folder" && /*opened_folders*/
    t[6].includes(
      /*i*/
      t[23]
    )
  ), h, p;
  function b(...f) {
    return (
      /*func*/
      t[12](
        /*name*/
        t[20],
        ...f
      )
    );
  }
  function y(...f) {
    return (
      /*change_handler*/
      t[13](
        /*name*/
        t[20],
        /*type*/
        t[19],
        ...f
      )
    );
  }
  i = new cl({
    props: {
      disabled: !/*interactive*/
      t[2],
      value: (
        /*selected*/
        t[1].some(b)
      )
    }
  }), i.$on("change", y);
  const E = [Fl, $l], $ = [];
  function m(f, v) {
    return (
      /*type*/
      f[19] === "folder" ? 0 : (
        /*type*/
        f[19] === "file" ? 1 : -1
      )
    );
  }
  ~(o = m(t)) && (a = $[o] = E[o](t));
  let d = _ && Ji(t);
  return {
    c() {
      e = gt("li"), n = gt("span"), ui(i.$$.fragment), r = Lt(), a && a.c(), s = Lt(), u = Dl(l), c = Lt(), d && d.c(), h = Lt(), this.h();
    },
    l(f) {
      e = mt(f, "LI", { class: !0 });
      var v = jt(e);
      n = mt(v, "SPAN", { class: !0 });
      var g = jt(n);
      li(i.$$.fragment, g), r = Rt(g), a && a.l(g), s = Rt(g), u = fl(g, l), g.forEach(He), c = Rt(v), d && d.l(v), h = Rt(v), v.forEach(He), this.h();
    },
    h() {
      Ne(n, "class", "wrap svelte-3bvdhr"), Ne(e, "class", "svelte-3bvdhr");
    },
    m(f, v) {
      nn(f, e, v), Ye(e, n), hi(i, n, null), Ye(n, r), ~o && $[o].m(n, null), Ye(n, s), Ye(n, u), Ye(e, c), d && d.m(e, null), Ye(e, h), p = !0;
    },
    p(f, v) {
      t = f;
      const g = {};
      v & /*interactive*/
      4 && (g.disabled = !/*interactive*/
      t[2]), v & /*selected, content*/
      34 && (g.value = /*selected*/
      t[1].some(b)), i.$set(g);
      let D = o;
      o = m(t), o === D ? ~o && $[o].p(t, v) : (a && (zn(), Ie($[D], 1, 1, () => {
        $[D] = null;
      }), Un()), ~o ? (a = $[o], a ? a.p(t, v) : (a = $[o] = E[o](t), a.c()), we(a, 1), a.m(n, s)) : a = null), (!p || v & /*content*/
      32) && l !== (l = /*name*/
      t[20] + "") && yl(u, l), v & /*content, opened_folders*/
      96 && (_ = /*type*/
      t[19] === "folder" && /*opened_folders*/
      t[6].includes(
        /*i*/
        t[23]
      )), _ ? d ? (d.p(t, v), v & /*content, opened_folders*/
      96 && we(d, 1)) : (d = Ji(t), d.c(), we(d, 1), d.m(e, h)) : d && (zn(), Ie(d, 1, 1, () => {
        d = null;
      }), Un());
    },
    i(f) {
      p || (we(i.$$.fragment, f), we(a), we(d), p = !0);
    },
    o(f) {
      Ie(i.$$.fragment, f), Ie(a), Ie(d), p = !1;
    },
    d(f) {
      f && He(e), ci(i), ~o && $[o].d(), d && d.d();
    }
  };
}
function Al(t) {
  let e, n, i = Wi(
    /*content*/
    t[5]
  ), r = [];
  for (let a = 0; a < i.length; a += 1)
    r[a] = er(Ki(t, i, a));
  const o = (a) => Ie(r[a], 1, 1, () => {
    r[a] = null;
  });
  return {
    c() {
      e = gt("ul");
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      this.h();
    },
    l(a) {
      e = mt(a, "UL", { class: !0 });
      var s = jt(e);
      for (let l = 0; l < r.length; l += 1)
        r[l].l(s);
      s.forEach(He), this.h();
    },
    h() {
      Ne(e, "class", "svelte-3bvdhr");
    },
    m(a, s) {
      nn(a, e, s);
      for (let l = 0; l < r.length; l += 1)
        r[l] && r[l].m(e, null);
      n = !0;
    },
    p(a, [s]) {
      if (s & /*path, content, selected, interactive, ls_fn, file_count, opened_folders, toggle_open_folder, dispatch, path_next_to*/
      1023) {
        i = Wi(
          /*content*/
          a[5]
        );
        let l;
        for (l = 0; l < i.length; l += 1) {
          const u = Ki(a, i, l);
          r[l] ? (r[l].p(u, s), we(r[l], 1)) : (r[l] = er(u), r[l].c(), we(r[l], 1), r[l].m(e, null));
        }
        for (zn(), l = i.length; l < r.length; l += 1)
          o(l);
        Un();
      }
    },
    i(a) {
      if (!n) {
        for (let s = 0; s < i.length; s += 1)
          we(r[s]);
        n = !0;
      }
    },
    o(a) {
      r = r.filter(Boolean);
      for (let s = 0; s < r.length; s += 1)
        Ie(r[s]);
      n = !1;
    },
    d(a) {
      a && He(e), pl(r, a);
    }
  };
}
const tr = (t) => t.slice(1);
function kl(t, e, n) {
  var i = this && this.__awaiter || function(g, D, C, F) {
    function x(w) {
      return w instanceof C ? w : new C(function(L) {
        L(w);
      });
    }
    return new (C || (C = Promise))(function(w, L) {
      function re(j) {
        try {
          be(F.next(j));
        } catch (Q) {
          L(Q);
        }
      }
      function te(j) {
        try {
          be(F.throw(j));
        } catch (Q) {
          L(Q);
        }
      }
      function be(j) {
        j.done ? w(j.value) : x(j.value).then(re, te);
      }
      be((F = F.apply(g, D || [])).next());
    });
  };
  let { path: r = [] } = e, { selected: o = [] } = e, { is_selected_entirely: a = !1 } = e, { interactive: s } = e, { ls_fn: l } = e, { file_count: u = "multiple" } = e, { valid_for_selection: c } = e, _ = [], h = [];
  const p = (g) => {
    h.includes(g) ? n(6, h = h.filter((D) => D !== g)) : n(6, h = [...h, g]);
  }, b = (g, D) => g.join("/").startsWith(D.slice(0, -1).join("/")) && g.length === D.length;
  i(void 0, void 0, void 0, function* () {
    n(5, _ = yield l(r)), c && u === "multiple" && n(5, _ = [
      {
        name: "<Select all contents>",
        type: "all_content"
      },
      ..._
    ]), n(6, h = _.map((g, D) => g.type === "folder" && (a || o.some((C) => C[0] === g.name)) ? D : null).filter((g) => g !== null));
  });
  const y = wl();
  console.log("File tree selected:", o);
  const E = (g, D) => D[0] === g && D.length === 1, $ = (g, D, C) => {
    let F = C.detail;
    y("check", { path: [...r, g], checked: F, type: D }), D === "all_content" && F && _.filter((x) => b([...r, x.name], [...r, g]) && x.type !== "all_content").forEach((x) => {
      y("check", {
        path: [...r, x.name],
        checked: F,
        type: x.type
      });
    });
  }, m = (g) => p(g), d = (g, { key: D }) => {
    (D === " " || D === "Enter") && p(g);
  }, f = (g, D) => D[0] === g;
  function v(g) {
    dl.call(this, t, g);
  }
  return t.$$set = (g) => {
    "path" in g && n(0, r = g.path), "selected" in g && n(1, o = g.selected), "is_selected_entirely" in g && n(10, a = g.is_selected_entirely), "interactive" in g && n(2, s = g.interactive), "ls_fn" in g && n(3, l = g.ls_fn), "file_count" in g && n(4, u = g.file_count), "valid_for_selection" in g && n(11, c = g.valid_for_selection);
  }, t.$$.update = () => {
    t.$$.dirty & /*is_selected_entirely, content, path*/
    1057 && a && _.forEach((g) => {
      y("check", {
        path: [...r, g.name],
        checked: !0,
        type: g.type
      });
    });
  }, [
    r,
    o,
    s,
    l,
    u,
    _,
    h,
    p,
    b,
    y,
    a,
    c,
    E,
    $,
    m,
    d,
    f,
    v
  ];
}
class ca extends _l {
  constructor(e) {
    super(), gl(this, e, kl, Al, vl, {
      path: 0,
      selected: 1,
      is_selected_entirely: 10,
      interactive: 2,
      ls_fn: 3,
      file_count: 4,
      valid_for_selection: 11
    });
  }
}
const {
  SvelteComponent: Cl,
  attr: Sl,
  children: xl,
  claim_component: Tl,
  claim_element: Bl,
  create_component: Il,
  destroy_component: Rl,
  detach: nr,
  element: Ll,
  init: Nl,
  insert_hydration: Ol,
  mount_component: Pl,
  safe_not_equal: Hl,
  transition_in: Ml,
  transition_out: ql
} = window.__gradio__svelte__internal;
function Ul(t) {
  let e, n, i;
  return n = new ca({
    props: {
      path: [],
      selected: (
        /*value*/
        t[0]
      ),
      interactive: (
        /*interactive*/
        t[1]
      ),
      ls_fn: (
        /*ls_fn*/
        t[3]
      ),
      file_count: (
        /*file_count*/
        t[2]
      ),
      valid_for_selection: !1
    }
  }), n.$on(
    "check",
    /*check_handler*/
    t[7]
  ), {
    c() {
      e = Ll("div"), Il(n.$$.fragment), this.h();
    },
    l(r) {
      e = Bl(r, "DIV", { class: !0 });
      var o = xl(e);
      Tl(n.$$.fragment, o), o.forEach(nr), this.h();
    },
    h() {
      Sl(e, "class", "file-wrap svelte-h8i5yo");
    },
    m(r, o) {
      Ol(r, e, o), Pl(n, e, null), i = !0;
    },
    p(r, [o]) {
      const a = {};
      o & /*value*/
      1 && (a.selected = /*value*/
      r[0]), o & /*interactive*/
      2 && (a.interactive = /*interactive*/
      r[1]), o & /*ls_fn*/
      8 && (a.ls_fn = /*ls_fn*/
      r[3]), o & /*file_count*/
      4 && (a.file_count = /*file_count*/
      r[2]), n.$set(a);
    },
    i(r) {
      i || (Ml(n.$$.fragment, r), i = !0);
    },
    o(r) {
      ql(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && nr(e), Rl(n);
    }
  };
}
function zl(t, e, n) {
  let { interactive: i } = e, { file_count: r = "multiple" } = e, { value: o = [] } = e, { ls_fn: a } = e;
  const s = (_, h) => _.join("/") === h.join("/"), l = (_, h) => h.some((p) => s(p, _)), u = (_, h) => _.join("/").startsWith(h.slice(0, -1).join("/")) && _.length === h.length, c = (_) => {
    const { path: h, checked: p, type: b } = _.detail;
    p ? r === "single" ? n(0, o = [h]) : l(h, o) || n(0, o = [...o, h]) : b === "all_content" ? n(0, o = o.filter((y) => !u(y, h))) : n(0, o = o.filter((y) => !s(y, h)));
  };
  return t.$$set = (_) => {
    "interactive" in _ && n(1, i = _.interactive), "file_count" in _ && n(2, r = _.file_count), "value" in _ && n(0, o = _.value), "ls_fn" in _ && n(3, a = _.ls_fn);
  }, [
    o,
    i,
    r,
    a,
    s,
    l,
    u,
    c
  ];
}
class Gl extends Cl {
  constructor(e) {
    super(), Nl(this, e, zl, Ul, Hl, {
      interactive: 1,
      file_count: 2,
      value: 0,
      ls_fn: 3
    });
  }
}
function Ke(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let i = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + i;
}
function Me() {
}
function jl(t) {
  return t();
}
function Vl(t) {
  return typeof t == "function";
}
function Xl(t, ...e) {
  if (t == null) {
    for (const i of e) i(void 0);
    return Me;
  }
  const n = t.subscribe(...e);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const ha = typeof window < "u";
let ir = ha ? () => window.performance.now() : () => Date.now(), _a = ha ? (t) => requestAnimationFrame(t) : Me;
const tt = /* @__PURE__ */ new Set();
function da(t) {
  tt.forEach((e) => {
    e.c(t) || (tt.delete(e), e.f());
  }), tt.size !== 0 && _a(da);
}
function Zl(t) {
  let e;
  return tt.size === 0 && _a(da), { promise: new Promise((n) => {
    tt.add(e = { c: t, f: n });
  }), abort() {
    tt.delete(e);
  } };
}
const Qe = [];
function Wl(t, e) {
  return { subscribe: Dt(t, e).subscribe };
}
function Dt(t, e = Me) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function r(a) {
    if (l = a, ((s = t) != s ? l == l : s !== l || s && typeof s == "object" || typeof s == "function") && (t = a, n)) {
      const u = !Qe.length;
      for (const c of i) c[1](), Qe.push(c, t);
      if (u) {
        for (let c = 0; c < Qe.length; c += 2) Qe[c][0](Qe[c + 1]);
        Qe.length = 0;
      }
    }
    var s, l;
  }
  function o(a) {
    r(a(t));
  }
  return { set: r, update: o, subscribe: function(a, s = Me) {
    const l = [a, s];
    return i.add(l), i.size === 1 && (n = e(r, o) || Me), a(t), () => {
      i.delete(l), i.size === 0 && n && (n(), n = null);
    };
  } };
}
function ot(t, e, n) {
  const i = !Array.isArray(t), r = i ? [t] : t;
  if (!r.every(Boolean)) throw new Error("derived() expects stores as input, got a falsy value");
  const o = e.length < 2;
  return Wl(n, (a, s) => {
    let l = !1;
    const u = [];
    let c = 0, _ = Me;
    const h = () => {
      if (c) return;
      _();
      const b = e(i ? u[0] : u, a, s);
      o ? a(b) : _ = Vl(b) ? b : Me;
    }, p = r.map((b, y) => Xl(b, (E) => {
      u[y] = E, c &= ~(1 << y), l && h();
    }, () => {
      c |= 1 << y;
    }));
    return l = !0, h(), function() {
      p.forEach(jl), _(), l = !1;
    };
  });
}
function rr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Gn(t, e, n, i) {
  if (typeof n == "number" || rr(n)) {
    const r = i - n, o = (n - e) / (t.dt || 1 / 60), a = (o + (t.opts.stiffness * r - t.opts.damping * o) * t.inv_mass) * t.dt;
    return Math.abs(a) < t.opts.precision && Math.abs(r) < t.opts.precision ? i : (t.settled = !1, rr(n) ? new Date(n.getTime() + a) : n + a);
  }
  if (Array.isArray(n)) return n.map((r, o) => Gn(t, e[o], n[o], i[o]));
  if (typeof n == "object") {
    const r = {};
    for (const o in n) r[o] = Gn(t, e[o], n[o], i[o]);
    return r;
  }
  throw new Error(`Cannot spring ${typeof n} values`);
}
function ar(t, e = {}) {
  const n = Dt(t), { stiffness: i = 0.15, damping: r = 0.8, precision: o = 0.01 } = e;
  let a, s, l, u = t, c = t, _ = 1, h = 0, p = !1;
  function b(E, $ = {}) {
    c = E;
    const m = l = {};
    return t == null || $.hard || y.stiffness >= 1 && y.damping >= 1 ? (p = !0, a = ir(), u = E, n.set(t = c), Promise.resolve()) : ($.soft && (h = 1 / (60 * ($.soft === !0 ? 0.5 : +$.soft)), _ = 0), s || (a = ir(), p = !1, s = Zl((d) => {
      if (p) return p = !1, s = null, !1;
      _ = Math.min(_ + h, 1);
      const f = { inv_mass: _, opts: y, settled: !0, dt: 60 * (d - a) / 1e3 }, v = Gn(f, u, t, c);
      return a = d, u = t, n.set(t = v), f.settled && (s = null), !f.settled;
    })), new Promise((d) => {
      s.promise.then(() => {
        m === l && d();
      });
    }));
  }
  const y = { set: b, update: (E, $) => b(E(c, t), $), subscribe: n.subscribe, stiffness: i, damping: r, precision: o };
  return y;
}
const {
  SvelteComponent: Yl,
  append_hydration: ye,
  attr: R,
  children: he,
  claim_element: Ql,
  claim_svg_element: Ee,
  component_subscribe: or,
  detach: oe,
  element: Kl,
  init: Jl,
  insert_hydration: eu,
  noop: sr,
  safe_not_equal: tu,
  set_style: Nt,
  svg_element: De,
  toggle_class: lr
} = window.__gradio__svelte__internal, { onMount: nu } = window.__gradio__svelte__internal;
function iu(t) {
  let e, n, i, r, o, a, s, l, u, c, _, h;
  return {
    c() {
      e = Kl("div"), n = De("svg"), i = De("g"), r = De("path"), o = De("path"), a = De("path"), s = De("path"), l = De("g"), u = De("path"), c = De("path"), _ = De("path"), h = De("path"), this.h();
    },
    l(p) {
      e = Ql(p, "DIV", { class: !0 });
      var b = he(e);
      n = Ee(b, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var y = he(n);
      i = Ee(y, "g", { style: !0 });
      var E = he(i);
      r = Ee(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), he(r).forEach(oe), o = Ee(E, "path", { d: !0, fill: !0, class: !0 }), he(o).forEach(oe), a = Ee(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), he(a).forEach(oe), s = Ee(E, "path", { d: !0, fill: !0, class: !0 }), he(s).forEach(oe), E.forEach(oe), l = Ee(y, "g", { style: !0 });
      var $ = he(l);
      u = Ee($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), he(u).forEach(oe), c = Ee($, "path", { d: !0, fill: !0, class: !0 }), he(c).forEach(oe), _ = Ee($, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), he(_).forEach(oe), h = Ee($, "path", { d: !0, fill: !0, class: !0 }), he(h).forEach(oe), $.forEach(oe), y.forEach(oe), b.forEach(oe), this.h();
    },
    h() {
      R(r, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), R(r, "fill", "#FF7C00"), R(r, "fill-opacity", "0.4"), R(r, "class", "svelte-43sxxs"), R(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), R(o, "fill", "#FF7C00"), R(o, "class", "svelte-43sxxs"), R(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), R(a, "fill", "#FF7C00"), R(a, "fill-opacity", "0.4"), R(a, "class", "svelte-43sxxs"), R(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), R(s, "fill", "#FF7C00"), R(s, "class", "svelte-43sxxs"), Nt(i, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), R(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), R(u, "fill", "#FF7C00"), R(u, "fill-opacity", "0.4"), R(u, "class", "svelte-43sxxs"), R(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), R(c, "fill", "#FF7C00"), R(c, "class", "svelte-43sxxs"), R(_, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), R(_, "fill", "#FF7C00"), R(_, "fill-opacity", "0.4"), R(_, "class", "svelte-43sxxs"), R(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), R(h, "fill", "#FF7C00"), R(h, "class", "svelte-43sxxs"), Nt(l, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), R(n, "viewBox", "-1200 -1200 3000 3000"), R(n, "fill", "none"), R(n, "xmlns", "http://www.w3.org/2000/svg"), R(n, "class", "svelte-43sxxs"), R(e, "class", "svelte-43sxxs"), lr(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(p, b) {
      eu(p, e, b), ye(e, n), ye(n, i), ye(i, r), ye(i, o), ye(i, a), ye(i, s), ye(n, l), ye(l, u), ye(l, c), ye(l, _), ye(l, h);
    },
    p(p, [b]) {
      b & /*$top*/
      2 && Nt(i, "transform", "translate(" + /*$top*/
      p[1][0] + "px, " + /*$top*/
      p[1][1] + "px)"), b & /*$bottom*/
      4 && Nt(l, "transform", "translate(" + /*$bottom*/
      p[2][0] + "px, " + /*$bottom*/
      p[2][1] + "px)"), b & /*margin*/
      1 && lr(
        e,
        "margin",
        /*margin*/
        p[0]
      );
    },
    i: sr,
    o: sr,
    d(p) {
      p && oe(e);
    }
  };
}
function ru(t, e, n) {
  let i, r;
  var o = this && this.__awaiter || function(p, b, y, E) {
    function $(m) {
      return m instanceof y ? m : new y(function(d) {
        d(m);
      });
    }
    return new (y || (y = Promise))(function(m, d) {
      function f(D) {
        try {
          g(E.next(D));
        } catch (C) {
          d(C);
        }
      }
      function v(D) {
        try {
          g(E.throw(D));
        } catch (C) {
          d(C);
        }
      }
      function g(D) {
        D.done ? m(D.value) : $(D.value).then(f, v);
      }
      g((E = E.apply(p, b || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const s = ar([0, 0]);
  or(t, s, (p) => n(1, i = p));
  const l = ar([0, 0]);
  or(t, l, (p) => n(2, r = p));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 140]), l.set([-125, -140])]), yield Promise.all([s.set([-125, 140]), l.set([125, -140])]), yield Promise.all([s.set([-125, 0]), l.set([125, -0])]), yield Promise.all([s.set([125, 0]), l.set([-125, 0])]);
    });
  }
  function _() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || _();
    });
  }
  function h() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([s.set([125, 0]), l.set([-125, 0])]), _();
    });
  }
  return nu(() => (h(), () => u = !0)), t.$$set = (p) => {
    "margin" in p && n(0, a = p.margin);
  }, [a, i, r, s, l];
}
class au extends Yl {
  constructor(e) {
    super(), Jl(this, e, ru, iu, tu, { margin: 0 });
  }
}
const {
  SvelteComponent: ou,
  append_hydration: $e,
  attr: de,
  binding_callbacks: ur,
  check_outros: Vt,
  children: fe,
  claim_component: _i,
  claim_element: pe,
  claim_space: ne,
  claim_text: z,
  create_component: di,
  create_slot: fa,
  destroy_component: fi,
  destroy_each: pa,
  detach: k,
  element: me,
  empty: ge,
  ensure_array_like: Xt,
  get_all_dirty_from_scope: ma,
  get_slot_changes: ga,
  group_outros: Zt,
  init: su,
  insert_hydration: T,
  mount_component: pi,
  noop: jn,
  safe_not_equal: lu,
  set_data: ue,
  set_style: Oe,
  space: ie,
  text: G,
  toggle_class: _e,
  transition_in: ee,
  transition_out: le,
  update_slot_base: ba
} = window.__gradio__svelte__internal, { tick: uu } = window.__gradio__svelte__internal, { onDestroy: cu } = window.__gradio__svelte__internal, { createEventDispatcher: hu } = window.__gradio__svelte__internal, _u = (t) => ({}), cr = (t) => ({}), du = (t) => ({}), hr = (t) => ({});
function _r(t, e, n) {
  const i = t.slice();
  return i[43] = e[n], i[45] = n, i;
}
function dr(t, e, n) {
  const i = t.slice();
  return i[43] = e[n], i;
}
function fr(t) {
  let e, n, i, r, o, a;
  return o = new ua({
    props: {
      Icon: zr,
      label: (
        /*i18n*/
        t[2]("common.clear")
      ),
      disabled: !1,
      size: "x-small",
      background: "var(--background-fill-primary)",
      color: "var(--error-background-text)",
      border: "var(--border-color-primary)"
    }
  }), o.$on(
    "click",
    /*click_handler*/
    t[33]
  ), {
    c() {
      e = me("div"), n = G(
        /*validation_error*/
        t[1]
      ), i = ie(), r = me("button"), di(o.$$.fragment), this.h();
    },
    l(s) {
      e = pe(s, "DIV", { class: !0 });
      var l = fe(e);
      n = z(
        l,
        /*validation_error*/
        t[1]
      ), i = ne(l), r = pe(l, "BUTTON", {});
      var u = fe(r);
      _i(o.$$.fragment, u), u.forEach(k), l.forEach(k), this.h();
    },
    h() {
      de(e, "class", "validation-error svelte-vusapu");
    },
    m(s, l) {
      T(s, e, l), $e(e, n), $e(e, i), $e(e, r), pi(o, r, null), a = !0;
    },
    p(s, l) {
      (!a || l[0] & /*validation_error*/
      2) && ue(
        n,
        /*validation_error*/
        s[1]
      );
      const u = {};
      l[0] & /*i18n*/
      4 && (u.label = /*i18n*/
      s[2]("common.clear")), o.$set(u);
    },
    i(s) {
      a || (ee(o.$$.fragment, s), a = !0);
    },
    o(s) {
      le(o.$$.fragment, s), a = !1;
    },
    d(s) {
      s && k(e), fi(o);
    }
  };
}
function fu(t) {
  let e, n, i, r, o = (
    /*i18n*/
    t[2]("common.error") + ""
  ), a, s, l;
  n = new ua({
    props: {
      Icon: zr,
      label: (
        /*i18n*/
        t[2]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler_1*/
    t[35]
  );
  const u = (
    /*#slots*/
    t[32].error
  ), c = fa(
    u,
    t,
    /*$$scope*/
    t[31],
    cr
  );
  return {
    c() {
      e = me("div"), di(n.$$.fragment), i = ie(), r = me("span"), a = G(o), s = ie(), c && c.c(), this.h();
    },
    l(_) {
      e = pe(_, "DIV", { class: !0 });
      var h = fe(e);
      _i(n.$$.fragment, h), h.forEach(k), i = ne(_), r = pe(_, "SPAN", { class: !0 });
      var p = fe(r);
      a = z(p, o), p.forEach(k), s = ne(_), c && c.l(_), this.h();
    },
    h() {
      de(e, "class", "clear-status svelte-vusapu"), de(r, "class", "error svelte-vusapu");
    },
    m(_, h) {
      T(_, e, h), pi(n, e, null), T(_, i, h), T(_, r, h), $e(r, a), T(_, s, h), c && c.m(_, h), l = !0;
    },
    p(_, h) {
      const p = {};
      h[0] & /*i18n*/
      4 && (p.label = /*i18n*/
      _[2]("common.clear")), n.$set(p), (!l || h[0] & /*i18n*/
      4) && o !== (o = /*i18n*/
      _[2]("common.error") + "") && ue(a, o), c && c.p && (!l || h[1] & /*$$scope*/
      1) && ba(
        c,
        u,
        _,
        /*$$scope*/
        _[31],
        l ? ga(
          u,
          /*$$scope*/
          _[31],
          h,
          _u
        ) : ma(
          /*$$scope*/
          _[31]
        ),
        cr
      );
    },
    i(_) {
      l || (ee(n.$$.fragment, _), ee(c, _), l = !0);
    },
    o(_) {
      le(n.$$.fragment, _), le(c, _), l = !1;
    },
    d(_) {
      _ && (k(e), k(i), k(r), k(s)), fi(n), c && c.d(_);
    }
  };
}
function pu(t) {
  let e, n, i, r, o, a, s, l, u, c = (
    /*variant*/
    t[9] === "default" && /*show_eta_bar*/
    t[20] && /*show_progress*/
    t[7] === "full" && pr(t)
  );
  function _(d, f) {
    if (
      /*progress*/
      d[8]
    ) return bu;
    if (
      /*queue_position*/
      d[3] !== null && /*queue_size*/
      d[4] !== void 0 && /*queue_position*/
      d[3] >= 0
    ) return gu;
    if (
      /*queue_position*/
      d[3] === 0
    ) return mu;
  }
  let h = _(t), p = h && h(t), b = (
    /*timer*/
    t[6] && br(t)
  );
  const y = [Du, Eu], E = [];
  function $(d, f) {
    return (
      /*last_progress_level*/
      d[17] != null ? 0 : (
        /*show_progress*/
        d[7] === "full" ? 1 : -1
      )
    );
  }
  ~(o = $(t)) && (a = E[o] = y[o](t));
  let m = !/*timer*/
  t[6] && Fr(t);
  return {
    c() {
      c && c.c(), e = ie(), n = me("div"), p && p.c(), i = ie(), b && b.c(), r = ie(), a && a.c(), s = ie(), m && m.c(), l = ge(), this.h();
    },
    l(d) {
      c && c.l(d), e = ne(d), n = pe(d, "DIV", { class: !0 });
      var f = fe(n);
      p && p.l(f), i = ne(f), b && b.l(f), f.forEach(k), r = ne(d), a && a.l(d), s = ne(d), m && m.l(d), l = ge(), this.h();
    },
    h() {
      de(n, "class", "progress-text svelte-vusapu"), _e(
        n,
        "meta-text-center",
        /*variant*/
        t[9] === "center"
      ), _e(
        n,
        "meta-text",
        /*variant*/
        t[9] === "default"
      );
    },
    m(d, f) {
      c && c.m(d, f), T(d, e, f), T(d, n, f), p && p.m(n, null), $e(n, i), b && b.m(n, null), T(d, r, f), ~o && E[o].m(d, f), T(d, s, f), m && m.m(d, f), T(d, l, f), u = !0;
    },
    p(d, f) {
      /*variant*/
      d[9] === "default" && /*show_eta_bar*/
      d[20] && /*show_progress*/
      d[7] === "full" ? c ? c.p(d, f) : (c = pr(d), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), h === (h = _(d)) && p ? p.p(d, f) : (p && p.d(1), p = h && h(d), p && (p.c(), p.m(n, i))), /*timer*/
      d[6] ? b ? b.p(d, f) : (b = br(d), b.c(), b.m(n, null)) : b && (b.d(1), b = null), (!u || f[0] & /*variant*/
      512) && _e(
        n,
        "meta-text-center",
        /*variant*/
        d[9] === "center"
      ), (!u || f[0] & /*variant*/
      512) && _e(
        n,
        "meta-text",
        /*variant*/
        d[9] === "default"
      );
      let v = o;
      o = $(d), o === v ? ~o && E[o].p(d, f) : (a && (Zt(), le(E[v], 1, 1, () => {
        E[v] = null;
      }), Vt()), ~o ? (a = E[o], a ? a.p(d, f) : (a = E[o] = y[o](d), a.c()), ee(a, 1), a.m(s.parentNode, s)) : a = null), /*timer*/
      d[6] ? m && (Zt(), le(m, 1, 1, () => {
        m = null;
      }), Vt()) : m ? (m.p(d, f), f[0] & /*timer*/
      64 && ee(m, 1)) : (m = Fr(d), m.c(), ee(m, 1), m.m(l.parentNode, l));
    },
    i(d) {
      u || (ee(a), ee(m), u = !0);
    },
    o(d) {
      le(a), le(m), u = !1;
    },
    d(d) {
      d && (k(e), k(n), k(r), k(s), k(l)), c && c.d(d), p && p.d(), b && b.d(), ~o && E[o].d(d), m && m.d(d);
    }
  };
}
function pr(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[19] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = me("div"), this.h();
    },
    l(i) {
      e = pe(i, "DIV", { class: !0 }), fe(e).forEach(k), this.h();
    },
    h() {
      de(e, "class", "eta-bar svelte-vusapu"), Oe(e, "transform", n);
    },
    m(i, r) {
      T(i, e, r);
    },
    p(i, r) {
      r[0] & /*eta_level*/
      524288 && n !== (n = `translateX(${/*eta_level*/
      (i[19] || 0) * 100 - 100}%)`) && Oe(e, "transform", n);
    },
    d(i) {
      i && k(e);
    }
  };
}
function mu(t) {
  let e;
  return {
    c() {
      e = G("processing |");
    },
    l(n) {
      e = z(n, "processing |");
    },
    m(n, i) {
      T(n, e, i);
    },
    p: jn,
    d(n) {
      n && k(e);
    }
  };
}
function gu(t) {
  let e, n = (
    /*queue_position*/
    t[3] + 1 + ""
  ), i, r, o, a;
  return {
    c() {
      e = G("queue: "), i = G(n), r = G("/"), o = G(
        /*queue_size*/
        t[4]
      ), a = G(" |");
    },
    l(s) {
      e = z(s, "queue: "), i = z(s, n), r = z(s, "/"), o = z(
        s,
        /*queue_size*/
        t[4]
      ), a = z(s, " |");
    },
    m(s, l) {
      T(s, e, l), T(s, i, l), T(s, r, l), T(s, o, l), T(s, a, l);
    },
    p(s, l) {
      l[0] & /*queue_position*/
      8 && n !== (n = /*queue_position*/
      s[3] + 1 + "") && ue(i, n), l[0] & /*queue_size*/
      16 && ue(
        o,
        /*queue_size*/
        s[4]
      );
    },
    d(s) {
      s && (k(e), k(i), k(r), k(o), k(a));
    }
  };
}
function bu(t) {
  let e, n = Xt(
    /*progress*/
    t[8]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = gr(dr(t, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = ge();
    },
    l(r) {
      for (let o = 0; o < i.length; o += 1)
        i[o].l(r);
      e = ge();
    },
    m(r, o) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, o);
      T(r, e, o);
    },
    p(r, o) {
      if (o[0] & /*progress*/
      256) {
        n = Xt(
          /*progress*/
          r[8]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const s = dr(r, n, a);
          i[a] ? i[a].p(s, o) : (i[a] = gr(s), i[a].c(), i[a].m(e.parentNode, e));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && k(e), pa(i, r);
    }
  };
}
function mr(t) {
  let e, n = (
    /*p*/
    t[43].unit + ""
  ), i, r, o = " ", a;
  function s(c, _) {
    return (
      /*p*/
      c[43].length != null ? yu : vu
    );
  }
  let l = s(t), u = l(t);
  return {
    c() {
      u.c(), e = ie(), i = G(n), r = G(" | "), a = G(o);
    },
    l(c) {
      u.l(c), e = ne(c), i = z(c, n), r = z(c, " | "), a = z(c, o);
    },
    m(c, _) {
      u.m(c, _), T(c, e, _), T(c, i, _), T(c, r, _), T(c, a, _);
    },
    p(c, _) {
      l === (l = s(c)) && u ? u.p(c, _) : (u.d(1), u = l(c), u && (u.c(), u.m(e.parentNode, e))), _[0] & /*progress*/
      256 && n !== (n = /*p*/
      c[43].unit + "") && ue(i, n);
    },
    d(c) {
      c && (k(e), k(i), k(r), k(a)), u.d(c);
    }
  };
}
function vu(t) {
  let e = Ke(
    /*p*/
    t[43].index || 0
  ) + "", n;
  return {
    c() {
      n = G(e);
    },
    l(i) {
      n = z(i, e);
    },
    m(i, r) {
      T(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      256 && e !== (e = Ke(
        /*p*/
        i[43].index || 0
      ) + "") && ue(n, e);
    },
    d(i) {
      i && k(n);
    }
  };
}
function yu(t) {
  let e = Ke(
    /*p*/
    t[43].index || 0
  ) + "", n, i, r = Ke(
    /*p*/
    t[43].length
  ) + "", o;
  return {
    c() {
      n = G(e), i = G("/"), o = G(r);
    },
    l(a) {
      n = z(a, e), i = z(a, "/"), o = z(a, r);
    },
    m(a, s) {
      T(a, n, s), T(a, i, s), T(a, o, s);
    },
    p(a, s) {
      s[0] & /*progress*/
      256 && e !== (e = Ke(
        /*p*/
        a[43].index || 0
      ) + "") && ue(n, e), s[0] & /*progress*/
      256 && r !== (r = Ke(
        /*p*/
        a[43].length
      ) + "") && ue(o, r);
    },
    d(a) {
      a && (k(n), k(i), k(o));
    }
  };
}
function gr(t) {
  let e, n = (
    /*p*/
    t[43].index != null && mr(t)
  );
  return {
    c() {
      n && n.c(), e = ge();
    },
    l(i) {
      n && n.l(i), e = ge();
    },
    m(i, r) {
      n && n.m(i, r), T(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[43].index != null ? n ? n.p(i, r) : (n = mr(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && k(e), n && n.d(i);
    }
  };
}
function br(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[21]}` : ""
  ), i, r;
  return {
    c() {
      e = G(
        /*formatted_timer*/
        t[22]
      ), i = G(n), r = G("s");
    },
    l(o) {
      e = z(
        o,
        /*formatted_timer*/
        t[22]
      ), i = z(o, n), r = z(o, "s");
    },
    m(o, a) {
      T(o, e, a), T(o, i, a), T(o, r, a);
    },
    p(o, a) {
      a[0] & /*formatted_timer*/
      4194304 && ue(
        e,
        /*formatted_timer*/
        o[22]
      ), a[0] & /*eta, formatted_eta*/
      2097153 && n !== (n = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[21]}` : "") && ue(i, n);
    },
    d(o) {
      o && (k(e), k(i), k(r));
    }
  };
}
function Eu(t) {
  let e, n;
  return e = new au({
    props: { margin: (
      /*variant*/
      t[9] === "default"
    ) }
  }), {
    c() {
      di(e.$$.fragment);
    },
    l(i) {
      _i(e.$$.fragment, i);
    },
    m(i, r) {
      pi(e, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[0] & /*variant*/
      512 && (o.margin = /*variant*/
      i[9] === "default"), e.$set(o);
    },
    i(i) {
      n || (ee(e.$$.fragment, i), n = !0);
    },
    o(i) {
      le(e.$$.fragment, i), n = !1;
    },
    d(i) {
      fi(e, i);
    }
  };
}
function Du(t) {
  let e, n, i, r, o, a = `${/*last_progress_level*/
  t[17] * 100}%`, s = (
    /*progress*/
    t[8] != null && vr(t)
  );
  return {
    c() {
      e = me("div"), n = me("div"), s && s.c(), i = ie(), r = me("div"), o = me("div"), this.h();
    },
    l(l) {
      e = pe(l, "DIV", { class: !0 });
      var u = fe(e);
      n = pe(u, "DIV", { class: !0 });
      var c = fe(n);
      s && s.l(c), c.forEach(k), i = ne(u), r = pe(u, "DIV", { class: !0 });
      var _ = fe(r);
      o = pe(_, "DIV", { class: !0 }), fe(o).forEach(k), _.forEach(k), u.forEach(k), this.h();
    },
    h() {
      de(n, "class", "progress-level-inner svelte-vusapu"), de(o, "class", "progress-bar svelte-vusapu"), Oe(o, "width", a), de(r, "class", "progress-bar-wrap svelte-vusapu"), de(e, "class", "progress-level svelte-vusapu");
    },
    m(l, u) {
      T(l, e, u), $e(e, n), s && s.m(n, null), $e(e, i), $e(e, r), $e(r, o), t[34](o);
    },
    p(l, u) {
      /*progress*/
      l[8] != null ? s ? s.p(l, u) : (s = vr(l), s.c(), s.m(n, null)) : s && (s.d(1), s = null), u[0] & /*last_progress_level*/
      131072 && a !== (a = `${/*last_progress_level*/
      l[17] * 100}%`) && Oe(o, "width", a);
    },
    i: jn,
    o: jn,
    d(l) {
      l && k(e), s && s.d(), t[34](null);
    }
  };
}
function vr(t) {
  let e, n = Xt(
    /*progress*/
    t[8]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = $r(_r(t, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = ge();
    },
    l(r) {
      for (let o = 0; o < i.length; o += 1)
        i[o].l(r);
      e = ge();
    },
    m(r, o) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, o);
      T(r, e, o);
    },
    p(r, o) {
      if (o[0] & /*progress_level, progress*/
      65792) {
        n = Xt(
          /*progress*/
          r[8]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const s = _r(r, n, a);
          i[a] ? i[a].p(s, o) : (i[a] = $r(s), i[a].c(), i[a].m(e.parentNode, e));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && k(e), pa(i, r);
    }
  };
}
function yr(t) {
  let e, n, i, r, o = (
    /*i*/
    t[45] !== 0 && wu()
  ), a = (
    /*p*/
    t[43].desc != null && Er(t)
  ), s = (
    /*p*/
    t[43].desc != null && /*progress_level*/
    t[16] && /*progress_level*/
    t[16][
      /*i*/
      t[45]
    ] != null && Dr()
  ), l = (
    /*progress_level*/
    t[16] != null && wr(t)
  );
  return {
    c() {
      o && o.c(), e = ie(), a && a.c(), n = ie(), s && s.c(), i = ie(), l && l.c(), r = ge();
    },
    l(u) {
      o && o.l(u), e = ne(u), a && a.l(u), n = ne(u), s && s.l(u), i = ne(u), l && l.l(u), r = ge();
    },
    m(u, c) {
      o && o.m(u, c), T(u, e, c), a && a.m(u, c), T(u, n, c), s && s.m(u, c), T(u, i, c), l && l.m(u, c), T(u, r, c);
    },
    p(u, c) {
      /*p*/
      u[43].desc != null ? a ? a.p(u, c) : (a = Er(u), a.c(), a.m(n.parentNode, n)) : a && (a.d(1), a = null), /*p*/
      u[43].desc != null && /*progress_level*/
      u[16] && /*progress_level*/
      u[16][
        /*i*/
        u[45]
      ] != null ? s || (s = Dr(), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null), /*progress_level*/
      u[16] != null ? l ? l.p(u, c) : (l = wr(u), l.c(), l.m(r.parentNode, r)) : l && (l.d(1), l = null);
    },
    d(u) {
      u && (k(e), k(n), k(i), k(r)), o && o.d(u), a && a.d(u), s && s.d(u), l && l.d(u);
    }
  };
}
function wu(t) {
  let e;
  return {
    c() {
      e = G(" /");
    },
    l(n) {
      e = z(n, " /");
    },
    m(n, i) {
      T(n, e, i);
    },
    d(n) {
      n && k(e);
    }
  };
}
function Er(t) {
  let e = (
    /*p*/
    t[43].desc + ""
  ), n;
  return {
    c() {
      n = G(e);
    },
    l(i) {
      n = z(i, e);
    },
    m(i, r) {
      T(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      256 && e !== (e = /*p*/
      i[43].desc + "") && ue(n, e);
    },
    d(i) {
      i && k(n);
    }
  };
}
function Dr(t) {
  let e;
  return {
    c() {
      e = G("-");
    },
    l(n) {
      e = z(n, "-");
    },
    m(n, i) {
      T(n, e, i);
    },
    d(n) {
      n && k(e);
    }
  };
}
function wr(t) {
  let e = (100 * /*progress_level*/
  (t[16][
    /*i*/
    t[45]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = G(e), i = G("%");
    },
    l(r) {
      n = z(r, e), i = z(r, "%");
    },
    m(r, o) {
      T(r, n, o), T(r, i, o);
    },
    p(r, o) {
      o[0] & /*progress_level*/
      65536 && e !== (e = (100 * /*progress_level*/
      (r[16][
        /*i*/
        r[45]
      ] || 0)).toFixed(1) + "") && ue(n, e);
    },
    d(r) {
      r && (k(n), k(i));
    }
  };
}
function $r(t) {
  let e, n = (
    /*p*/
    (t[43].desc != null || /*progress_level*/
    t[16] && /*progress_level*/
    t[16][
      /*i*/
      t[45]
    ] != null) && yr(t)
  );
  return {
    c() {
      n && n.c(), e = ge();
    },
    l(i) {
      n && n.l(i), e = ge();
    },
    m(i, r) {
      n && n.m(i, r), T(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[43].desc != null || /*progress_level*/
      i[16] && /*progress_level*/
      i[16][
        /*i*/
        i[45]
      ] != null ? n ? n.p(i, r) : (n = yr(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && k(e), n && n.d(i);
    }
  };
}
function Fr(t) {
  let e, n, i, r;
  const o = (
    /*#slots*/
    t[32]["additional-loading-text"]
  ), a = fa(
    o,
    t,
    /*$$scope*/
    t[31],
    hr
  );
  return {
    c() {
      e = me("p"), n = G(
        /*loading_text*/
        t[10]
      ), i = ie(), a && a.c(), this.h();
    },
    l(s) {
      e = pe(s, "P", { class: !0 });
      var l = fe(e);
      n = z(
        l,
        /*loading_text*/
        t[10]
      ), l.forEach(k), i = ne(s), a && a.l(s), this.h();
    },
    h() {
      de(e, "class", "loading svelte-vusapu");
    },
    m(s, l) {
      T(s, e, l), $e(e, n), T(s, i, l), a && a.m(s, l), r = !0;
    },
    p(s, l) {
      (!r || l[0] & /*loading_text*/
      1024) && ue(
        n,
        /*loading_text*/
        s[10]
      ), a && a.p && (!r || l[1] & /*$$scope*/
      1) && ba(
        a,
        o,
        s,
        /*$$scope*/
        s[31],
        r ? ga(
          o,
          /*$$scope*/
          s[31],
          l,
          du
        ) : ma(
          /*$$scope*/
          s[31]
        ),
        hr
      );
    },
    i(s) {
      r || (ee(a, s), r = !0);
    },
    o(s) {
      le(a, s), r = !1;
    },
    d(s) {
      s && (k(e), k(i)), a && a.d(s);
    }
  };
}
function $u(t) {
  let e, n, i, r, o, a, s = (
    /*validation_error*/
    t[1] && /*show_validation_error*/
    t[14] && fr(t)
  );
  const l = [pu, fu], u = [];
  function c(_, h) {
    return (
      /*status*/
      _[5] === "pending" ? 0 : (
        /*status*/
        _[5] === "error" ? 1 : -1
      )
    );
  }
  return ~(i = c(t)) && (r = u[i] = l[i](t)), {
    c() {
      e = me("div"), s && s.c(), n = ie(), r && r.c(), this.h();
    },
    l(_) {
      e = pe(_, "DIV", { class: !0 });
      var h = fe(e);
      s && s.l(h), n = ne(h), r && r.l(h), h.forEach(k), this.h();
    },
    h() {
      de(e, "class", o = "wrap " + /*variant*/
      t[9] + " " + /*show_progress*/
      t[7] + " svelte-vusapu"), _e(e, "hide", (!/*status*/
      t[5] || /*status*/
      t[5] === "complete" || /*show_progress*/
      t[7] === "hidden" || /*status*/
      t[5] == "streaming") && !/*validation_error*/
      t[1]), _e(
        e,
        "translucent",
        /*variant*/
        t[9] === "center" && /*status*/
        (t[5] === "pending" || /*status*/
        t[5] === "error") || /*translucent*/
        t[12] || /*show_progress*/
        t[7] === "minimal" || /*validation_error*/
        t[1]
      ), _e(
        e,
        "generating",
        /*status*/
        t[5] === "generating" && /*show_progress*/
        t[7] === "full"
      ), _e(
        e,
        "border",
        /*border*/
        t[13]
      ), Oe(
        e,
        "position",
        /*absolute*/
        t[11] ? "absolute" : "static"
      ), Oe(
        e,
        "padding",
        /*absolute*/
        t[11] ? "0" : "var(--size-8) 0"
      );
    },
    m(_, h) {
      T(_, e, h), s && s.m(e, null), $e(e, n), ~i && u[i].m(e, null), t[36](e), a = !0;
    },
    p(_, h) {
      /*validation_error*/
      _[1] && /*show_validation_error*/
      _[14] ? s ? (s.p(_, h), h[0] & /*validation_error, show_validation_error*/
      16386 && ee(s, 1)) : (s = fr(_), s.c(), ee(s, 1), s.m(e, n)) : s && (Zt(), le(s, 1, 1, () => {
        s = null;
      }), Vt());
      let p = i;
      i = c(_), i === p ? ~i && u[i].p(_, h) : (r && (Zt(), le(u[p], 1, 1, () => {
        u[p] = null;
      }), Vt()), ~i ? (r = u[i], r ? r.p(_, h) : (r = u[i] = l[i](_), r.c()), ee(r, 1), r.m(e, null)) : r = null), (!a || h[0] & /*variant, show_progress*/
      640 && o !== (o = "wrap " + /*variant*/
      _[9] + " " + /*show_progress*/
      _[7] + " svelte-vusapu")) && de(e, "class", o), (!a || h[0] & /*variant, show_progress, status, show_progress, validation_error*/
      674) && _e(e, "hide", (!/*status*/
      _[5] || /*status*/
      _[5] === "complete" || /*show_progress*/
      _[7] === "hidden" || /*status*/
      _[5] == "streaming") && !/*validation_error*/
      _[1]), (!a || h[0] & /*variant, show_progress, variant, status, translucent, show_progress, validation_error*/
      4770) && _e(
        e,
        "translucent",
        /*variant*/
        _[9] === "center" && /*status*/
        (_[5] === "pending" || /*status*/
        _[5] === "error") || /*translucent*/
        _[12] || /*show_progress*/
        _[7] === "minimal" || /*validation_error*/
        _[1]
      ), (!a || h[0] & /*variant, show_progress, status, show_progress*/
      672) && _e(
        e,
        "generating",
        /*status*/
        _[5] === "generating" && /*show_progress*/
        _[7] === "full"
      ), (!a || h[0] & /*variant, show_progress, border*/
      8832) && _e(
        e,
        "border",
        /*border*/
        _[13]
      ), h[0] & /*absolute*/
      2048 && Oe(
        e,
        "position",
        /*absolute*/
        _[11] ? "absolute" : "static"
      ), h[0] & /*absolute*/
      2048 && Oe(
        e,
        "padding",
        /*absolute*/
        _[11] ? "0" : "var(--size-8) 0"
      );
    },
    i(_) {
      a || (ee(s), ee(r), a = !0);
    },
    o(_) {
      le(s), le(r), a = !1;
    },
    d(_) {
      _ && k(e), s && s.d(), ~i && u[i].d(), t[36](null);
    }
  };
}
var Fu = function(t, e, n, i) {
  function r(o) {
    return o instanceof n ? o : new n(function(a) {
      a(o);
    });
  }
  return new (n || (n = Promise))(function(o, a) {
    function s(c) {
      try {
        u(i.next(c));
      } catch (_) {
        a(_);
      }
    }
    function l(c) {
      try {
        u(i.throw(c));
      } catch (_) {
        a(_);
      }
    }
    function u(c) {
      c.done ? o(c.value) : r(c.value).then(s, l);
    }
    u((i = i.apply(t, e || [])).next());
  });
};
let Ot = [], kn = !1;
const Au = typeof window < "u", va = Au ? window.requestAnimationFrame : (t) => {
};
function ku(t) {
  return Fu(this, arguments, void 0, function* (e, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (Ot.push(e), !kn) kn = !0;
      else return;
      yield uu(), va(() => {
        let i = [0, 0];
        for (let r = 0; r < Ot.length; r++) {
          const a = Ot[r].getBoundingClientRect();
          (r === 0 || a.top + window.scrollY <= i[0]) && (i[0] = a.top + window.scrollY, i[1] = r);
        }
        window.scrollTo({ top: i[0] - 20, behavior: "smooth" }), kn = !1, Ot = [];
      });
    }
  });
}
function Cu(t, e, n) {
  let i, { $$slots: r = {}, $$scope: o } = e;
  const a = hu();
  let { i18n: s } = e, { eta: l = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: _ } = e, { scroll_to_output: h = !1 } = e, { timer: p = !0 } = e, { show_progress: b = "full" } = e, { message: y = null } = e, { progress: E = null } = e, { variant: $ = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: d = !0 } = e, { translucent: f = !1 } = e, { border: v = !1 } = e, { autoscroll: g } = e, { validation_error: D = null } = e, { show_validation_error: C = !0 } = e, F, x = !1, w = 0, L = 0, re = null, te = null, be = 0, j = null, Q, M = null, K = !0;
  const Fe = () => {
    n(0, l = n(29, re = n(21, Te = null))), n(27, w = performance.now()), n(28, L = 0), x = !0, A();
  };
  function A() {
    va(() => {
      n(28, L = (performance.now() - w) / 1e3), x && A();
    });
  }
  function Z() {
    n(28, L = 0), n(0, l = n(29, re = n(21, Te = null))), x && (x = !1);
  }
  cu(() => {
    x && Z();
  });
  let Te = null;
  const ae = () => n(1, D = null);
  function Ae(S) {
    ur[S ? "unshift" : "push"](() => {
      M = S, n(18, M), n(8, E), n(16, j), n(17, Q);
    });
  }
  const Re = () => {
    a("clear_status");
  };
  function je(S) {
    ur[S ? "unshift" : "push"](() => {
      F = S, n(15, F);
    });
  }
  return t.$$set = (S) => {
    "i18n" in S && n(2, s = S.i18n), "eta" in S && n(0, l = S.eta), "queue_position" in S && n(3, u = S.queue_position), "queue_size" in S && n(4, c = S.queue_size), "status" in S && n(5, _ = S.status), "scroll_to_output" in S && n(24, h = S.scroll_to_output), "timer" in S && n(6, p = S.timer), "show_progress" in S && n(7, b = S.show_progress), "message" in S && n(25, y = S.message), "progress" in S && n(8, E = S.progress), "variant" in S && n(9, $ = S.variant), "loading_text" in S && n(10, m = S.loading_text), "absolute" in S && n(11, d = S.absolute), "translucent" in S && n(12, f = S.translucent), "border" in S && n(13, v = S.border), "autoscroll" in S && n(26, g = S.autoscroll), "validation_error" in S && n(1, D = S.validation_error), "show_validation_error" in S && n(14, C = S.show_validation_error), "$$scope" in S && n(31, o = S.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    1744830465 && (l === null && n(0, l = re), l != null && re !== l && (n(30, te = (performance.now() - w) / 1e3 + l), n(21, Te = te.toFixed(1)), n(29, re = l))), t.$$.dirty[0] & /*eta_from_start, timer_diff*/
    1342177280 && n(19, be = te === null || te <= 0 || !L ? null : Math.min(L / te, 1)), t.$$.dirty[0] & /*progress*/
    256 && E != null && n(20, K = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    459008 && (E != null ? n(16, j = E.map((S) => {
      if (S.index != null && S.length != null)
        return S.index / S.length;
      if (S.progress != null)
        return S.progress;
    })) : n(16, j = null), j ? (n(17, Q = j[j.length - 1]), M && (Q === 0 ? n(18, M.style.transition = "0", M) : n(18, M.style.transition = "150ms", M))) : n(17, Q = void 0)), t.$$.dirty[0] & /*status*/
    32 && (_ === "pending" ? Fe() : Z()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    83918880 && F && h && (_ === "pending" || _ === "complete") && ku(F, g), t.$$.dirty[0] & /*status, message*/
    33554464, t.$$.dirty[0] & /*timer_diff*/
    268435456 && n(22, i = L.toFixed(1));
  }, [
    l,
    D,
    s,
    u,
    c,
    _,
    p,
    b,
    E,
    $,
    m,
    d,
    f,
    v,
    C,
    F,
    j,
    Q,
    M,
    be,
    K,
    Te,
    i,
    a,
    h,
    y,
    g,
    w,
    L,
    re,
    te,
    o,
    r,
    ae,
    Ae,
    Re,
    je
  ];
}
class Su extends ou {
  constructor(e) {
    super(), su(
      this,
      e,
      Cu,
      $u,
      lu,
      {
        i18n: 2,
        eta: 0,
        queue_position: 3,
        queue_size: 4,
        status: 5,
        scroll_to_output: 24,
        timer: 6,
        show_progress: 7,
        message: 25,
        progress: 8,
        variant: 9,
        loading_text: 10,
        absolute: 11,
        translucent: 12,
        border: 13,
        autoscroll: 26,
        validation_error: 1,
        show_validation_error: 14
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: Jk,
  SvelteComponent: eC,
  add_render_callback: tC,
  append_hydration: nC,
  attr: iC,
  bubble: rC,
  check_outros: aC,
  children: oC,
  claim_component: sC,
  claim_element: lC,
  claim_html_tag: uC,
  claim_space: cC,
  claim_text: hC,
  create_component: _C,
  create_in_transition: dC,
  create_out_transition: fC,
  destroy_component: pC,
  detach: mC,
  element: gC,
  get_svelte_dataset: bC,
  group_outros: vC,
  init: yC,
  insert_hydration: EC,
  listen: DC,
  mount_component: wC,
  run_all: $C,
  safe_not_equal: FC,
  set_data: AC,
  space: kC,
  stop_propagation: CC,
  text: SC,
  toggle_class: xC,
  transition_in: TC,
  transition_out: BC
} = window.__gradio__svelte__internal, { createEventDispatcher: IC, onMount: RC } = window.__gradio__svelte__internal, {
  SvelteComponent: LC,
  append_hydration: NC,
  attr: OC,
  bubble: PC,
  check_outros: HC,
  children: MC,
  claim_component: qC,
  claim_element: UC,
  claim_space: zC,
  component_subscribe: GC,
  create_animation: jC,
  create_component: VC,
  destroy_component: XC,
  detach: ZC,
  element: WC,
  ensure_array_like: YC,
  fix_and_outro_and_destroy_block: QC,
  fix_position: KC,
  group_outros: JC,
  init: eS,
  insert_hydration: tS,
  mount_component: nS,
  noop: iS,
  safe_not_equal: rS,
  set_style: aS,
  space: oS,
  transition_in: sS,
  transition_out: lS,
  update_keyed_each: uS
} = window.__gradio__svelte__internal, {
  SvelteComponent: cS,
  attr: hS,
  children: _S,
  claim_element: dS,
  detach: fS,
  element: pS,
  empty: mS,
  init: gS,
  insert_hydration: bS,
  noop: vS,
  safe_not_equal: yS,
  set_style: ES
} = window.__gradio__svelte__internal;
function xu(t) {
  return Tu(t) && !Bu(t);
}
function Tu(t) {
  return !!t && typeof t == "object";
}
function Bu(t) {
  var e = Object.prototype.toString.call(t);
  return e === "[object RegExp]" || e === "[object Date]" || Lu(t);
}
var Iu = typeof Symbol == "function" && Symbol.for, Ru = Iu ? Symbol.for("react.element") : 60103;
function Lu(t) {
  return t.$$typeof === Ru;
}
var Nu = xu;
function Ou(t) {
  return Array.isArray(t) ? [] : {};
}
function bt(t, e) {
  return e.clone !== !1 && e.isMergeableObject(t) ? nt(Ou(t), t, e) : t;
}
function Pu(t, e, n) {
  return t.concat(e).map(function(i) {
    return bt(i, n);
  });
}
function Hu(t, e) {
  if (!e.customMerge)
    return nt;
  var n = e.customMerge(t);
  return typeof n == "function" ? n : nt;
}
function Mu(t) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(t).filter(function(e) {
    return Object.propertyIsEnumerable.call(t, e);
  }) : [];
}
function Ar(t) {
  return Object.keys(t).concat(Mu(t));
}
function ya(t, e) {
  try {
    return e in t;
  } catch {
    return !1;
  }
}
function qu(t, e) {
  return ya(t, e) && !(Object.hasOwnProperty.call(t, e) && Object.propertyIsEnumerable.call(t, e));
}
function Uu(t, e, n) {
  var i = {};
  return n.isMergeableObject(t) && Ar(t).forEach(function(r) {
    i[r] = bt(t[r], n);
  }), Ar(e).forEach(function(r) {
    qu(t, r) || (ya(t, r) && n.isMergeableObject(e[r]) ? i[r] = Hu(r, n)(t[r], e[r], n) : i[r] = bt(e[r], n));
  }), i;
}
function nt(t, e, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || Pu, n.isMergeableObject = n.isMergeableObject || Nu, n.cloneUnlessOtherwiseSpecified = bt;
  var i = Array.isArray(e), r = Array.isArray(t), o = i === r;
  return o ? i ? n.arrayMerge(t, e, n) : Uu(t, e, n) : bt(e, n);
}
nt.all = function(e, n) {
  if (!Array.isArray(e))
    throw new Error("first argument should be an array");
  return e.reduce(function(i, r) {
    return nt(i, r, n);
  }, {});
};
var Vn = function(t, e) {
  return Vn = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, i) {
    n.__proto__ = i;
  } || function(n, i) {
    for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (n[r] = i[r]);
  }, Vn(t, e);
};
function rn(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Vn(t, e);
  function n() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (n.prototype = e.prototype, new n());
}
var N = function() {
  return N = Object.assign || function(e) {
    for (var n, i = 1, r = arguments.length; i < r; i++) {
      n = arguments[i];
      for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
    }
    return e;
  }, N.apply(this, arguments);
};
function Cn(t, e, n) {
  if (n || arguments.length === 2) for (var i = 0, r = e.length, o; i < r; i++)
    (o || !(i in e)) && (o || (o = Array.prototype.slice.call(e, 0, i)), o[i] = e[i]);
  return t.concat(o || Array.prototype.slice.call(e));
}
var B;
(function(t) {
  t[t.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", t[t.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", t[t.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", t[t.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", t[t.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", t[t.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", t[t.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", t[t.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", t[t.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", t[t.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", t[t.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", t[t.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", t[t.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", t[t.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", t[t.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", t[t.INVALID_TAG = 23] = "INVALID_TAG", t[t.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", t[t.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", t[t.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(B || (B = {}));
var U;
(function(t) {
  t[t.literal = 0] = "literal", t[t.argument = 1] = "argument", t[t.number = 2] = "number", t[t.date = 3] = "date", t[t.time = 4] = "time", t[t.select = 5] = "select", t[t.plural = 6] = "plural", t[t.pound = 7] = "pound", t[t.tag = 8] = "tag";
})(U || (U = {}));
var it;
(function(t) {
  t[t.number = 0] = "number", t[t.dateTime = 1] = "dateTime";
})(it || (it = {}));
function kr(t) {
  return t.type === U.literal;
}
function zu(t) {
  return t.type === U.argument;
}
function Ea(t) {
  return t.type === U.number;
}
function Da(t) {
  return t.type === U.date;
}
function wa(t) {
  return t.type === U.time;
}
function $a(t) {
  return t.type === U.select;
}
function Fa(t) {
  return t.type === U.plural;
}
function Gu(t) {
  return t.type === U.pound;
}
function Aa(t) {
  return t.type === U.tag;
}
function ka(t) {
  return !!(t && typeof t == "object" && t.type === it.number);
}
function Xn(t) {
  return !!(t && typeof t == "object" && t.type === it.dateTime);
}
var Ca = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, ju = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function Vu(t) {
  var e = {};
  return t.replace(ju, function(n) {
    var i = n.length;
    switch (n[0]) {
      case "G":
        e.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        e.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        e.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        e.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        e.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        e.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        e.hourCycle = "h12", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        e.hourCycle = "h23", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        e.hourCycle = "h11", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        e.hourCycle = "h24", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        e.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        e.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        e.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), e;
}
var Xu = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function Zu(t) {
  if (t.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var e = t.split(Xu).filter(function(h) {
    return h.length > 0;
  }), n = [], i = 0, r = e; i < r.length; i++) {
    var o = r[i], a = o.split("/");
    if (a.length === 0)
      throw new Error("Invalid number skeleton");
    for (var s = a[0], l = a.slice(1), u = 0, c = l; u < c.length; u++) {
      var _ = c[u];
      if (_.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: s, options: l });
  }
  return n;
}
function Wu(t) {
  return t.replace(/^(.*?)-/, "");
}
var Cr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, Sa = /^(@+)?(\+|#+)?[rs]?$/g, Yu = /(\*)(0+)|(#+)(0+)|(0+)/g, xa = /^(0+)$/;
function Sr(t) {
  var e = {};
  return t[t.length - 1] === "r" ? e.roundingPriority = "morePrecision" : t[t.length - 1] === "s" && (e.roundingPriority = "lessPrecision"), t.replace(Sa, function(n, i, r) {
    return typeof r != "string" ? (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length) : r === "+" ? e.minimumSignificantDigits = i.length : i[0] === "#" ? e.maximumSignificantDigits = i.length : (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length + (typeof r == "string" ? r.length : 0)), "";
  }), e;
}
function Ta(t) {
  switch (t) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function Qu(t) {
  var e;
  if (t[0] === "E" && t[1] === "E" ? (e = {
    notation: "engineering"
  }, t = t.slice(2)) : t[0] === "E" && (e = {
    notation: "scientific"
  }, t = t.slice(1)), e) {
    var n = t.slice(0, 2);
    if (n === "+!" ? (e.signDisplay = "always", t = t.slice(2)) : n === "+?" && (e.signDisplay = "exceptZero", t = t.slice(2)), !xa.test(t))
      throw new Error("Malformed concise eng/scientific notation");
    e.minimumIntegerDigits = t.length;
  }
  return e;
}
function xr(t) {
  var e = {}, n = Ta(t);
  return n || e;
}
function Ku(t) {
  for (var e = {}, n = 0, i = t; n < i.length; n++) {
    var r = i[n];
    switch (r.stem) {
      case "percent":
      case "%":
        e.style = "percent";
        continue;
      case "%x100":
        e.style = "percent", e.scale = 100;
        continue;
      case "currency":
        e.style = "currency", e.currency = r.options[0];
        continue;
      case "group-off":
      case ",_":
        e.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        e.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        e.style = "unit", e.unit = Wu(r.options[0]);
        continue;
      case "compact-short":
      case "K":
        e.notation = "compact", e.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        e.notation = "compact", e.compactDisplay = "long";
        continue;
      case "scientific":
        e = N(N(N({}, e), { notation: "scientific" }), r.options.reduce(function(l, u) {
          return N(N({}, l), xr(u));
        }, {}));
        continue;
      case "engineering":
        e = N(N(N({}, e), { notation: "engineering" }), r.options.reduce(function(l, u) {
          return N(N({}, l), xr(u));
        }, {}));
        continue;
      case "notation-simple":
        e.notation = "standard";
        continue;
      case "unit-width-narrow":
        e.currencyDisplay = "narrowSymbol", e.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        e.currencyDisplay = "code", e.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        e.currencyDisplay = "name", e.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        e.currencyDisplay = "symbol";
        continue;
      case "scale":
        e.scale = parseFloat(r.options[0]);
        continue;
      case "integer-width":
        if (r.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        r.options[0].replace(Yu, function(l, u, c, _, h, p) {
          if (u)
            e.minimumIntegerDigits = c.length;
          else {
            if (_ && h)
              throw new Error("We currently do not support maximum integer digits");
            if (p)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (xa.test(r.stem)) {
      e.minimumIntegerDigits = r.stem.length;
      continue;
    }
    if (Cr.test(r.stem)) {
      if (r.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      r.stem.replace(Cr, function(l, u, c, _, h, p) {
        return c === "*" ? e.minimumFractionDigits = u.length : _ && _[0] === "#" ? e.maximumFractionDigits = _.length : h && p ? (e.minimumFractionDigits = h.length, e.maximumFractionDigits = h.length + p.length) : (e.minimumFractionDigits = u.length, e.maximumFractionDigits = u.length), "";
      });
      var o = r.options[0];
      o === "w" ? e = N(N({}, e), { trailingZeroDisplay: "stripIfInteger" }) : o && (e = N(N({}, e), Sr(o)));
      continue;
    }
    if (Sa.test(r.stem)) {
      e = N(N({}, e), Sr(r.stem));
      continue;
    }
    var a = Ta(r.stem);
    a && (e = N(N({}, e), a));
    var s = Qu(r.stem);
    s && (e = N(N({}, e), s));
  }
  return e;
}
var Pt = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function Ju(t, e) {
  for (var n = "", i = 0; i < t.length; i++) {
    var r = t.charAt(i);
    if (r === "j") {
      for (var o = 0; i + 1 < t.length && t.charAt(i + 1) === r; )
        o++, i++;
      var a = 1 + (o & 1), s = o < 2 ? 1 : 3 + (o >> 1), l = "a", u = ec(e);
      for ((u == "H" || u == "k") && (s = 0); s-- > 0; )
        n += l;
      for (; a-- > 0; )
        n = u + n;
    } else r === "J" ? n += "H" : n += r;
  }
  return n;
}
function ec(t) {
  var e = t.hourCycle;
  if (e === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  t.hourCycles && // @ts-ignore
  t.hourCycles.length && (e = t.hourCycles[0]), e)
    switch (e) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = t.language, i;
  n !== "root" && (i = t.maximize().region);
  var r = Pt[i || ""] || Pt[n || ""] || Pt["".concat(n, "-001")] || Pt["001"];
  return r[0];
}
var Sn, tc = new RegExp("^".concat(Ca.source, "*")), nc = new RegExp("".concat(Ca.source, "*$"));
function I(t, e) {
  return { start: t, end: e };
}
var ic = !!String.prototype.startsWith, rc = !!String.fromCodePoint, ac = !!Object.fromEntries, oc = !!String.prototype.codePointAt, sc = !!String.prototype.trimStart, lc = !!String.prototype.trimEnd, uc = !!Number.isSafeInteger, cc = uc ? Number.isSafeInteger : function(t) {
  return typeof t == "number" && isFinite(t) && Math.floor(t) === t && Math.abs(t) <= 9007199254740991;
}, Zn = !0;
try {
  var hc = Ia("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Zn = ((Sn = hc.exec("a")) === null || Sn === void 0 ? void 0 : Sn[0]) === "a";
} catch {
  Zn = !1;
}
var Tr = ic ? (
  // Native
  function(e, n, i) {
    return e.startsWith(n, i);
  }
) : (
  // For IE11
  function(e, n, i) {
    return e.slice(i, i + n.length) === n;
  }
), Wn = rc ? String.fromCodePoint : (
  // IE11
  function() {
    for (var e = [], n = 0; n < arguments.length; n++)
      e[n] = arguments[n];
    for (var i = "", r = e.length, o = 0, a; r > o; ) {
      if (a = e[o++], a > 1114111)
        throw RangeError(a + " is not a valid code point");
      i += a < 65536 ? String.fromCharCode(a) : String.fromCharCode(((a -= 65536) >> 10) + 55296, a % 1024 + 56320);
    }
    return i;
  }
), Br = (
  // native
  ac ? Object.fromEntries : (
    // Ponyfill
    function(e) {
      for (var n = {}, i = 0, r = e; i < r.length; i++) {
        var o = r[i], a = o[0], s = o[1];
        n[a] = s;
      }
      return n;
    }
  )
), Ba = oc ? (
  // Native
  function(e, n) {
    return e.codePointAt(n);
  }
) : (
  // IE 11
  function(e, n) {
    var i = e.length;
    if (!(n < 0 || n >= i)) {
      var r = e.charCodeAt(n), o;
      return r < 55296 || r > 56319 || n + 1 === i || (o = e.charCodeAt(n + 1)) < 56320 || o > 57343 ? r : (r - 55296 << 10) + (o - 56320) + 65536;
    }
  }
), _c = sc ? (
  // Native
  function(e) {
    return e.trimStart();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(tc, "");
  }
), dc = lc ? (
  // Native
  function(e) {
    return e.trimEnd();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(nc, "");
  }
);
function Ia(t, e) {
  return new RegExp(t, e);
}
var Yn;
if (Zn) {
  var Ir = Ia("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Yn = function(e, n) {
    var i;
    Ir.lastIndex = n;
    var r = Ir.exec(e);
    return (i = r[1]) !== null && i !== void 0 ? i : "";
  };
} else
  Yn = function(e, n) {
    for (var i = []; ; ) {
      var r = Ba(e, n);
      if (r === void 0 || Ra(r) || gc(r))
        break;
      i.push(r), n += r >= 65536 ? 2 : 1;
    }
    return Wn.apply(void 0, i);
  };
var fc = (
  /** @class */
  function() {
    function t(e, n) {
      n === void 0 && (n = {}), this.message = e, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return t.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, t.prototype.parseMessage = function(e, n, i) {
      for (var r = []; !this.isEOF(); ) {
        var o = this.char();
        if (o === 123) {
          var a = this.parseArgument(e, i);
          if (a.err)
            return a;
          r.push(a.val);
        } else {
          if (o === 125 && e > 0)
            break;
          if (o === 35 && (n === "plural" || n === "selectordinal")) {
            var s = this.clonePosition();
            this.bump(), r.push({
              type: U.pound,
              location: I(s, this.clonePosition())
            });
          } else if (o === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(B.UNMATCHED_CLOSING_TAG, I(this.clonePosition(), this.clonePosition()));
          } else if (o === 60 && !this.ignoreTag && Qn(this.peek() || 0)) {
            var a = this.parseTag(e, n);
            if (a.err)
              return a;
            r.push(a.val);
          } else {
            var a = this.parseLiteral(e, n);
            if (a.err)
              return a;
            r.push(a.val);
          }
        }
      }
      return { val: r, err: null };
    }, t.prototype.parseTag = function(e, n) {
      var i = this.clonePosition();
      this.bump();
      var r = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: U.literal,
            value: "<".concat(r, "/>"),
            location: I(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var o = this.parseMessage(e + 1, n, !0);
        if (o.err)
          return o;
        var a = o.val, s = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !Qn(this.char()))
            return this.error(B.INVALID_TAG, I(s, this.clonePosition()));
          var l = this.clonePosition(), u = this.parseTagName();
          return r !== u ? this.error(B.UNMATCHED_CLOSING_TAG, I(l, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: U.tag,
              value: r,
              children: a,
              location: I(i, this.clonePosition())
            },
            err: null
          } : this.error(B.INVALID_TAG, I(s, this.clonePosition())));
        } else
          return this.error(B.UNCLOSED_TAG, I(i, this.clonePosition()));
      } else
        return this.error(B.INVALID_TAG, I(i, this.clonePosition()));
    }, t.prototype.parseTagName = function() {
      var e = this.offset();
      for (this.bump(); !this.isEOF() && mc(this.char()); )
        this.bump();
      return this.message.slice(e, this.offset());
    }, t.prototype.parseLiteral = function(e, n) {
      for (var i = this.clonePosition(), r = ""; ; ) {
        var o = this.tryParseQuote(n);
        if (o) {
          r += o;
          continue;
        }
        var a = this.tryParseUnquoted(e, n);
        if (a) {
          r += a;
          continue;
        }
        var s = this.tryParseLeftAngleBracket();
        if (s) {
          r += s;
          continue;
        }
        break;
      }
      var l = I(i, this.clonePosition());
      return {
        val: { type: U.literal, value: r, location: l },
        err: null
      };
    }, t.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !pc(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, t.prototype.tryParseQuote = function(e) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (e === "plural" || e === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(i);
        this.bump();
      }
      return Wn.apply(void 0, n);
    }, t.prototype.tryParseUnquoted = function(e, n) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (n === "plural" || n === "selectordinal") || i === 125 && e > 0 ? null : (this.bump(), Wn(i));
    }, t.prototype.parseArgument = function(e, n) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(B.EXPECT_ARGUMENT_CLOSING_BRACE, I(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(B.EMPTY_ARGUMENT, I(i, this.clonePosition()));
      var r = this.parseIdentifierIfPossible().value;
      if (!r)
        return this.error(B.MALFORMED_ARGUMENT, I(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(B.EXPECT_ARGUMENT_CLOSING_BRACE, I(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: U.argument,
              // value does not include the opening and closing braces.
              value: r,
              location: I(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(B.EXPECT_ARGUMENT_CLOSING_BRACE, I(i, this.clonePosition())) : this.parseArgumentOptions(e, n, r, i);
        default:
          return this.error(B.MALFORMED_ARGUMENT, I(i, this.clonePosition()));
      }
    }, t.prototype.parseIdentifierIfPossible = function() {
      var e = this.clonePosition(), n = this.offset(), i = Yn(this.message, n), r = n + i.length;
      this.bumpTo(r);
      var o = this.clonePosition(), a = I(e, o);
      return { value: i, location: a };
    }, t.prototype.parseArgumentOptions = function(e, n, i, r) {
      var o, a = this.clonePosition(), s = this.parseIdentifierIfPossible().value, l = this.clonePosition();
      switch (s) {
        case "":
          return this.error(B.EXPECT_ARGUMENT_TYPE, I(a, l));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var u = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var c = this.clonePosition(), _ = this.parseSimpleArgStyleIfPossible();
            if (_.err)
              return _;
            var h = dc(_.val);
            if (h.length === 0)
              return this.error(B.EXPECT_ARGUMENT_STYLE, I(this.clonePosition(), this.clonePosition()));
            var p = I(c, this.clonePosition());
            u = { style: h, styleLocation: p };
          }
          var b = this.tryParseArgumentClose(r);
          if (b.err)
            return b;
          var y = I(r, this.clonePosition());
          if (u && Tr(u == null ? void 0 : u.style, "::", 0)) {
            var E = _c(u.style.slice(2));
            if (s === "number") {
              var _ = this.parseNumberSkeletonFromString(E, u.styleLocation);
              return _.err ? _ : {
                val: { type: U.number, value: i, location: y, style: _.val },
                err: null
              };
            } else {
              if (E.length === 0)
                return this.error(B.EXPECT_DATE_TIME_SKELETON, y);
              var $ = E;
              this.locale && ($ = Ju(E, this.locale));
              var h = {
                type: it.dateTime,
                pattern: $,
                location: u.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? Vu($) : {}
              }, m = s === "date" ? U.date : U.time;
              return {
                val: { type: m, value: i, location: y, style: h },
                err: null
              };
            }
          }
          return {
            val: {
              type: s === "number" ? U.number : s === "date" ? U.date : U.time,
              value: i,
              location: y,
              style: (o = u == null ? void 0 : u.style) !== null && o !== void 0 ? o : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var d = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(B.EXPECT_SELECT_ARGUMENT_OPTIONS, I(d, N({}, d)));
          this.bumpSpace();
          var f = this.parseIdentifierIfPossible(), v = 0;
          if (s !== "select" && f.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(B.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, I(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var _ = this.tryParseDecimalInteger(B.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, B.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (_.err)
              return _;
            this.bumpSpace(), f = this.parseIdentifierIfPossible(), v = _.val;
          }
          var g = this.tryParsePluralOrSelectOptions(e, s, n, f);
          if (g.err)
            return g;
          var b = this.tryParseArgumentClose(r);
          if (b.err)
            return b;
          var D = I(r, this.clonePosition());
          return s === "select" ? {
            val: {
              type: U.select,
              value: i,
              options: Br(g.val),
              location: D
            },
            err: null
          } : {
            val: {
              type: U.plural,
              value: i,
              options: Br(g.val),
              offset: v,
              pluralType: s === "plural" ? "cardinal" : "ordinal",
              location: D
            },
            err: null
          };
        }
        default:
          return this.error(B.INVALID_ARGUMENT_TYPE, I(a, l));
      }
    }, t.prototype.tryParseArgumentClose = function(e) {
      return this.isEOF() || this.char() !== 125 ? this.error(B.EXPECT_ARGUMENT_CLOSING_BRACE, I(e, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, t.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var e = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var r = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(B.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, I(r, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            e += 1, this.bump();
            break;
          }
          case 125: {
            if (e > 0)
              e -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, t.prototype.parseNumberSkeletonFromString = function(e, n) {
      var i = [];
      try {
        i = Zu(e);
      } catch {
        return this.error(B.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: it.number,
          tokens: i,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? Ku(i) : {}
        },
        err: null
      };
    }, t.prototype.tryParsePluralOrSelectOptions = function(e, n, i, r) {
      for (var o, a = !1, s = [], l = /* @__PURE__ */ new Set(), u = r.value, c = r.location; ; ) {
        if (u.length === 0) {
          var _ = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var h = this.tryParseDecimalInteger(B.EXPECT_PLURAL_ARGUMENT_SELECTOR, B.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (h.err)
              return h;
            c = I(_, this.clonePosition()), u = this.message.slice(_.offset, this.offset());
          } else
            break;
        }
        if (l.has(u))
          return this.error(n === "select" ? B.DUPLICATE_SELECT_ARGUMENT_SELECTOR : B.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, c);
        u === "other" && (a = !0), this.bumpSpace();
        var p = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? B.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : B.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, I(this.clonePosition(), this.clonePosition()));
        var b = this.parseMessage(e + 1, n, i);
        if (b.err)
          return b;
        var y = this.tryParseArgumentClose(p);
        if (y.err)
          return y;
        s.push([
          u,
          {
            value: b.val,
            location: I(p, this.clonePosition())
          }
        ]), l.add(u), this.bumpSpace(), o = this.parseIdentifierIfPossible(), u = o.value, c = o.location;
      }
      return s.length === 0 ? this.error(n === "select" ? B.EXPECT_SELECT_ARGUMENT_SELECTOR : B.EXPECT_PLURAL_ARGUMENT_SELECTOR, I(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !a ? this.error(B.MISSING_OTHER_CLAUSE, I(this.clonePosition(), this.clonePosition())) : { val: s, err: null };
    }, t.prototype.tryParseDecimalInteger = function(e, n) {
      var i = 1, r = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var o = !1, a = 0; !this.isEOF(); ) {
        var s = this.char();
        if (s >= 48 && s <= 57)
          o = !0, a = a * 10 + (s - 48), this.bump();
        else
          break;
      }
      var l = I(r, this.clonePosition());
      return o ? (a *= i, cc(a) ? { val: a, err: null } : this.error(n, l)) : this.error(e, l);
    }, t.prototype.offset = function() {
      return this.position.offset;
    }, t.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, t.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, t.prototype.char = function() {
      var e = this.position.offset;
      if (e >= this.message.length)
        throw Error("out of bound");
      var n = Ba(this.message, e);
      if (n === void 0)
        throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, t.prototype.error = function(e, n) {
      return {
        val: null,
        err: {
          kind: e,
          message: this.message,
          location: n
        }
      };
    }, t.prototype.bump = function() {
      if (!this.isEOF()) {
        var e = this.char();
        e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
      }
    }, t.prototype.bumpIf = function(e) {
      if (Tr(this.message, e, this.offset())) {
        for (var n = 0; n < e.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, t.prototype.bumpUntil = function(e) {
      var n = this.offset(), i = this.message.indexOf(e, n);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, t.prototype.bumpTo = function(e) {
      if (this.offset() > e)
        throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (e = Math.min(e, this.message.length); ; ) {
        var n = this.offset();
        if (n === e)
          break;
        if (n > e)
          throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, t.prototype.bumpSpace = function() {
      for (; !this.isEOF() && Ra(this.char()); )
        this.bump();
    }, t.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var e = this.char(), n = this.offset(), i = this.message.charCodeAt(n + (e >= 65536 ? 2 : 1));
      return i ?? null;
    }, t;
  }()
);
function Qn(t) {
  return t >= 97 && t <= 122 || t >= 65 && t <= 90;
}
function pc(t) {
  return Qn(t) || t === 47;
}
function mc(t) {
  return t === 45 || t === 46 || t >= 48 && t <= 57 || t === 95 || t >= 97 && t <= 122 || t >= 65 && t <= 90 || t == 183 || t >= 192 && t <= 214 || t >= 216 && t <= 246 || t >= 248 && t <= 893 || t >= 895 && t <= 8191 || t >= 8204 && t <= 8205 || t >= 8255 && t <= 8256 || t >= 8304 && t <= 8591 || t >= 11264 && t <= 12271 || t >= 12289 && t <= 55295 || t >= 63744 && t <= 64975 || t >= 65008 && t <= 65533 || t >= 65536 && t <= 983039;
}
function Ra(t) {
  return t >= 9 && t <= 13 || t === 32 || t === 133 || t >= 8206 && t <= 8207 || t === 8232 || t === 8233;
}
function gc(t) {
  return t >= 33 && t <= 35 || t === 36 || t >= 37 && t <= 39 || t === 40 || t === 41 || t === 42 || t === 43 || t === 44 || t === 45 || t >= 46 && t <= 47 || t >= 58 && t <= 59 || t >= 60 && t <= 62 || t >= 63 && t <= 64 || t === 91 || t === 92 || t === 93 || t === 94 || t === 96 || t === 123 || t === 124 || t === 125 || t === 126 || t === 161 || t >= 162 && t <= 165 || t === 166 || t === 167 || t === 169 || t === 171 || t === 172 || t === 174 || t === 176 || t === 177 || t === 182 || t === 187 || t === 191 || t === 215 || t === 247 || t >= 8208 && t <= 8213 || t >= 8214 && t <= 8215 || t === 8216 || t === 8217 || t === 8218 || t >= 8219 && t <= 8220 || t === 8221 || t === 8222 || t === 8223 || t >= 8224 && t <= 8231 || t >= 8240 && t <= 8248 || t === 8249 || t === 8250 || t >= 8251 && t <= 8254 || t >= 8257 && t <= 8259 || t === 8260 || t === 8261 || t === 8262 || t >= 8263 && t <= 8273 || t === 8274 || t === 8275 || t >= 8277 && t <= 8286 || t >= 8592 && t <= 8596 || t >= 8597 && t <= 8601 || t >= 8602 && t <= 8603 || t >= 8604 && t <= 8607 || t === 8608 || t >= 8609 && t <= 8610 || t === 8611 || t >= 8612 && t <= 8613 || t === 8614 || t >= 8615 && t <= 8621 || t === 8622 || t >= 8623 && t <= 8653 || t >= 8654 && t <= 8655 || t >= 8656 && t <= 8657 || t === 8658 || t === 8659 || t === 8660 || t >= 8661 && t <= 8691 || t >= 8692 && t <= 8959 || t >= 8960 && t <= 8967 || t === 8968 || t === 8969 || t === 8970 || t === 8971 || t >= 8972 && t <= 8991 || t >= 8992 && t <= 8993 || t >= 8994 && t <= 9e3 || t === 9001 || t === 9002 || t >= 9003 && t <= 9083 || t === 9084 || t >= 9085 && t <= 9114 || t >= 9115 && t <= 9139 || t >= 9140 && t <= 9179 || t >= 9180 && t <= 9185 || t >= 9186 && t <= 9254 || t >= 9255 && t <= 9279 || t >= 9280 && t <= 9290 || t >= 9291 && t <= 9311 || t >= 9472 && t <= 9654 || t === 9655 || t >= 9656 && t <= 9664 || t === 9665 || t >= 9666 && t <= 9719 || t >= 9720 && t <= 9727 || t >= 9728 && t <= 9838 || t === 9839 || t >= 9840 && t <= 10087 || t === 10088 || t === 10089 || t === 10090 || t === 10091 || t === 10092 || t === 10093 || t === 10094 || t === 10095 || t === 10096 || t === 10097 || t === 10098 || t === 10099 || t === 10100 || t === 10101 || t >= 10132 && t <= 10175 || t >= 10176 && t <= 10180 || t === 10181 || t === 10182 || t >= 10183 && t <= 10213 || t === 10214 || t === 10215 || t === 10216 || t === 10217 || t === 10218 || t === 10219 || t === 10220 || t === 10221 || t === 10222 || t === 10223 || t >= 10224 && t <= 10239 || t >= 10240 && t <= 10495 || t >= 10496 && t <= 10626 || t === 10627 || t === 10628 || t === 10629 || t === 10630 || t === 10631 || t === 10632 || t === 10633 || t === 10634 || t === 10635 || t === 10636 || t === 10637 || t === 10638 || t === 10639 || t === 10640 || t === 10641 || t === 10642 || t === 10643 || t === 10644 || t === 10645 || t === 10646 || t === 10647 || t === 10648 || t >= 10649 && t <= 10711 || t === 10712 || t === 10713 || t === 10714 || t === 10715 || t >= 10716 && t <= 10747 || t === 10748 || t === 10749 || t >= 10750 && t <= 11007 || t >= 11008 && t <= 11055 || t >= 11056 && t <= 11076 || t >= 11077 && t <= 11078 || t >= 11079 && t <= 11084 || t >= 11085 && t <= 11123 || t >= 11124 && t <= 11125 || t >= 11126 && t <= 11157 || t === 11158 || t >= 11159 && t <= 11263 || t >= 11776 && t <= 11777 || t === 11778 || t === 11779 || t === 11780 || t === 11781 || t >= 11782 && t <= 11784 || t === 11785 || t === 11786 || t === 11787 || t === 11788 || t === 11789 || t >= 11790 && t <= 11798 || t === 11799 || t >= 11800 && t <= 11801 || t === 11802 || t === 11803 || t === 11804 || t === 11805 || t >= 11806 && t <= 11807 || t === 11808 || t === 11809 || t === 11810 || t === 11811 || t === 11812 || t === 11813 || t === 11814 || t === 11815 || t === 11816 || t === 11817 || t >= 11818 && t <= 11822 || t === 11823 || t >= 11824 && t <= 11833 || t >= 11834 && t <= 11835 || t >= 11836 && t <= 11839 || t === 11840 || t === 11841 || t === 11842 || t >= 11843 && t <= 11855 || t >= 11856 && t <= 11857 || t === 11858 || t >= 11859 && t <= 11903 || t >= 12289 && t <= 12291 || t === 12296 || t === 12297 || t === 12298 || t === 12299 || t === 12300 || t === 12301 || t === 12302 || t === 12303 || t === 12304 || t === 12305 || t >= 12306 && t <= 12307 || t === 12308 || t === 12309 || t === 12310 || t === 12311 || t === 12312 || t === 12313 || t === 12314 || t === 12315 || t === 12316 || t === 12317 || t >= 12318 && t <= 12319 || t === 12320 || t === 12336 || t === 64830 || t === 64831 || t >= 65093 && t <= 65094;
}
function Kn(t) {
  t.forEach(function(e) {
    if (delete e.location, $a(e) || Fa(e))
      for (var n in e.options)
        delete e.options[n].location, Kn(e.options[n].value);
    else Ea(e) && ka(e.style) || (Da(e) || wa(e)) && Xn(e.style) ? delete e.style.location : Aa(e) && Kn(e.children);
  });
}
function bc(t, e) {
  e === void 0 && (e = {}), e = N({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, e);
  var n = new fc(t, e).parse();
  if (n.err) {
    var i = SyntaxError(B[n.err.kind]);
    throw i.location = n.err.location, i.originalMessage = n.err.message, i;
  }
  return e != null && e.captureLocation || Kn(n.val), n.val;
}
function xn(t, e) {
  var n = e && e.cache ? e.cache : $c, i = e && e.serializer ? e.serializer : wc, r = e && e.strategy ? e.strategy : Ec;
  return r(t, {
    cache: n,
    serializer: i
  });
}
function vc(t) {
  return t == null || typeof t == "number" || typeof t == "boolean";
}
function yc(t, e, n, i) {
  var r = vc(i) ? i : n(i), o = e.get(r);
  return typeof o > "u" && (o = t.call(this, i), e.set(r, o)), o;
}
function La(t, e, n) {
  var i = Array.prototype.slice.call(arguments, 3), r = n(i), o = e.get(r);
  return typeof o > "u" && (o = t.apply(this, i), e.set(r, o)), o;
}
function Na(t, e, n, i, r) {
  return n.bind(e, t, i, r);
}
function Ec(t, e) {
  var n = t.length === 1 ? yc : La;
  return Na(t, this, n, e.cache.create(), e.serializer);
}
function Dc(t, e) {
  return Na(t, this, La, e.cache.create(), e.serializer);
}
var wc = function() {
  return JSON.stringify(arguments);
};
function mi() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
mi.prototype.get = function(t) {
  return this.cache[t];
};
mi.prototype.set = function(t, e) {
  this.cache[t] = e;
};
var $c = {
  create: function() {
    return new mi();
  }
}, Tn = {
  variadic: Dc
}, rt;
(function(t) {
  t.MISSING_VALUE = "MISSING_VALUE", t.INVALID_VALUE = "INVALID_VALUE", t.MISSING_INTL_API = "MISSING_INTL_API";
})(rt || (rt = {}));
var an = (
  /** @class */
  function(t) {
    rn(e, t);
    function e(n, i, r) {
      var o = t.call(this, n) || this;
      return o.code = i, o.originalMessage = r, o;
    }
    return e.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, e;
  }(Error)
), Rr = (
  /** @class */
  function(t) {
    rn(e, t);
    function e(n, i, r, o) {
      return t.call(this, 'Invalid values for "'.concat(n, '": "').concat(i, '". Options are "').concat(Object.keys(r).join('", "'), '"'), rt.INVALID_VALUE, o) || this;
    }
    return e;
  }(an)
), Fc = (
  /** @class */
  function(t) {
    rn(e, t);
    function e(n, i, r) {
      return t.call(this, 'Value for "'.concat(n, '" must be of type ').concat(i), rt.INVALID_VALUE, r) || this;
    }
    return e;
  }(an)
), Ac = (
  /** @class */
  function(t) {
    rn(e, t);
    function e(n, i) {
      return t.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(i, '"'), rt.MISSING_VALUE, i) || this;
    }
    return e;
  }(an)
), J;
(function(t) {
  t[t.literal = 0] = "literal", t[t.object = 1] = "object";
})(J || (J = {}));
function kc(t) {
  return t.length < 2 ? t : t.reduce(function(e, n) {
    var i = e[e.length - 1];
    return !i || i.type !== J.literal || n.type !== J.literal ? e.push(n) : i.value += n.value, e;
  }, []);
}
function Cc(t) {
  return typeof t == "function";
}
function Mt(t, e, n, i, r, o, a) {
  if (t.length === 1 && kr(t[0]))
    return [
      {
        type: J.literal,
        value: t[0].value
      }
    ];
  for (var s = [], l = 0, u = t; l < u.length; l++) {
    var c = u[l];
    if (kr(c)) {
      s.push({
        type: J.literal,
        value: c.value
      });
      continue;
    }
    if (Gu(c)) {
      typeof o == "number" && s.push({
        type: J.literal,
        value: n.getNumberFormat(e).format(o)
      });
      continue;
    }
    var _ = c.value;
    if (!(r && _ in r))
      throw new Ac(_, a);
    var h = r[_];
    if (zu(c)) {
      (!h || typeof h == "string" || typeof h == "number") && (h = typeof h == "string" || typeof h == "number" ? String(h) : ""), s.push({
        type: typeof h == "string" ? J.literal : J.object,
        value: h
      });
      continue;
    }
    if (Da(c)) {
      var p = typeof c.style == "string" ? i.date[c.style] : Xn(c.style) ? c.style.parsedOptions : void 0;
      s.push({
        type: J.literal,
        value: n.getDateTimeFormat(e, p).format(h)
      });
      continue;
    }
    if (wa(c)) {
      var p = typeof c.style == "string" ? i.time[c.style] : Xn(c.style) ? c.style.parsedOptions : i.time.medium;
      s.push({
        type: J.literal,
        value: n.getDateTimeFormat(e, p).format(h)
      });
      continue;
    }
    if (Ea(c)) {
      var p = typeof c.style == "string" ? i.number[c.style] : ka(c.style) ? c.style.parsedOptions : void 0;
      p && p.scale && (h = h * (p.scale || 1)), s.push({
        type: J.literal,
        value: n.getNumberFormat(e, p).format(h)
      });
      continue;
    }
    if (Aa(c)) {
      var b = c.children, y = c.value, E = r[y];
      if (!Cc(E))
        throw new Fc(y, "function", a);
      var $ = Mt(b, e, n, i, r, o), m = E($.map(function(v) {
        return v.value;
      }));
      Array.isArray(m) || (m = [m]), s.push.apply(s, m.map(function(v) {
        return {
          type: typeof v == "string" ? J.literal : J.object,
          value: v
        };
      }));
    }
    if ($a(c)) {
      var d = c.options[h] || c.options.other;
      if (!d)
        throw new Rr(c.value, h, Object.keys(c.options), a);
      s.push.apply(s, Mt(d.value, e, n, i, r));
      continue;
    }
    if (Fa(c)) {
      var d = c.options["=".concat(h)];
      if (!d) {
        if (!Intl.PluralRules)
          throw new an(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, rt.MISSING_INTL_API, a);
        var f = n.getPluralRules(e, { type: c.pluralType }).select(h - (c.offset || 0));
        d = c.options[f] || c.options.other;
      }
      if (!d)
        throw new Rr(c.value, h, Object.keys(c.options), a);
      s.push.apply(s, Mt(d.value, e, n, i, r, h - (c.offset || 0)));
      continue;
    }
  }
  return kc(s);
}
function Sc(t, e) {
  return e ? N(N(N({}, t || {}), e || {}), Object.keys(t).reduce(function(n, i) {
    return n[i] = N(N({}, t[i]), e[i] || {}), n;
  }, {})) : t;
}
function xc(t, e) {
  return e ? Object.keys(t).reduce(function(n, i) {
    return n[i] = Sc(t[i], e[i]), n;
  }, N({}, t)) : t;
}
function Bn(t) {
  return {
    create: function() {
      return {
        get: function(e) {
          return t[e];
        },
        set: function(e, n) {
          t[e] = n;
        }
      };
    }
  };
}
function Tc(t) {
  return t === void 0 && (t = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: xn(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.NumberFormat).bind.apply(e, Cn([void 0], n, !1)))();
    }, {
      cache: Bn(t.number),
      strategy: Tn.variadic
    }),
    getDateTimeFormat: xn(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, Cn([void 0], n, !1)))();
    }, {
      cache: Bn(t.dateTime),
      strategy: Tn.variadic
    }),
    getPluralRules: xn(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.PluralRules).bind.apply(e, Cn([void 0], n, !1)))();
    }, {
      cache: Bn(t.pluralRules),
      strategy: Tn.variadic
    })
  };
}
var Bc = (
  /** @class */
  function() {
    function t(e, n, i, r) {
      var o = this;
      if (n === void 0 && (n = t.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(a) {
        var s = o.formatToParts(a);
        if (s.length === 1)
          return s[0].value;
        var l = s.reduce(function(u, c) {
          return !u.length || c.type !== J.literal || typeof u[u.length - 1] != "string" ? u.push(c.value) : u[u.length - 1] += c.value, u;
        }, []);
        return l.length <= 1 ? l[0] || "" : l;
      }, this.formatToParts = function(a) {
        return Mt(o.ast, o.locales, o.formatters, o.formats, a, void 0, o.message);
      }, this.resolvedOptions = function() {
        return {
          locale: o.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return o.ast;
      }, this.locales = n, this.resolvedLocale = t.resolveLocale(n), typeof e == "string") {
        if (this.message = e, !t.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = t.__parse(e, {
          ignoreTag: r == null ? void 0 : r.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = e;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = xc(t.formats, i), this.formatters = r && r.formatters || Tc(this.formatterCache);
    }
    return Object.defineProperty(t, "defaultLocale", {
      get: function() {
        return t.memoizedDefaultLocale || (t.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), t.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), t.memoizedDefaultLocale = null, t.resolveLocale = function(e) {
      var n = Intl.NumberFormat.supportedLocalesOf(e);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
    }, t.__parse = bc, t.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, t;
  }()
);
function Ic(t, e) {
  if (e == null)
    return;
  if (e in t)
    return t[e];
  const n = e.split(".");
  let i = t;
  for (let r = 0; r < n.length; r++)
    if (typeof i == "object") {
      if (r > 0) {
        const o = n.slice(r, n.length).join(".");
        if (o in i) {
          i = i[o];
          break;
        }
      }
      i = i[n[r]];
    } else
      i = void 0;
  return i;
}
const Pe = {}, Rc = (t, e, n) => n && (e in Pe || (Pe[e] = {}), t in Pe[e] || (Pe[e][t] = n), n), Oa = (t, e) => {
  if (e == null)
    return;
  if (e in Pe && t in Pe[e])
    return Pe[e][t];
  const n = on(e);
  for (let i = 0; i < n.length; i++) {
    const r = n[i], o = Nc(r, t);
    if (o)
      return Rc(t, e, o);
  }
};
let gi;
const wt = Dt({});
function Lc(t) {
  return gi[t] || null;
}
function Pa(t) {
  return t in gi;
}
function Nc(t, e) {
  if (!Pa(t))
    return null;
  const n = Lc(t);
  return Ic(n, e);
}
function Oc(t) {
  if (t == null)
    return;
  const e = on(t);
  for (let n = 0; n < e.length; n++) {
    const i = e[n];
    if (Pa(i))
      return i;
  }
}
function Pc(t, ...e) {
  delete Pe[t], wt.update((n) => (n[t] = nt.all([n[t] || {}, ...e]), n));
}
ot(
  [wt],
  ([t]) => Object.keys(t)
);
wt.subscribe((t) => gi = t);
const qt = {};
function Hc(t, e) {
  qt[t].delete(e), qt[t].size === 0 && delete qt[t];
}
function Ha(t) {
  return qt[t];
}
function Mc(t) {
  return on(t).map((e) => {
    const n = Ha(e);
    return [e, n ? [...n] : []];
  }).filter(([, e]) => e.length > 0);
}
function Jn(t) {
  return t == null ? !1 : on(t).some(
    (e) => {
      var n;
      return (n = Ha(e)) == null ? void 0 : n.size;
    }
  );
}
function qc(t, e) {
  return Promise.all(
    e.map((i) => (Hc(t, i), i().then((r) => r.default || r)))
  ).then((i) => Pc(t, ...i));
}
const ct = {};
function Ma(t) {
  if (!Jn(t))
    return t in ct ? ct[t] : Promise.resolve();
  const e = Mc(t);
  return ct[t] = Promise.all(
    e.map(
      ([n, i]) => qc(n, i)
    )
  ).then(() => {
    if (Jn(t))
      return Ma(t);
    delete ct[t];
  }), ct[t];
}
const Uc = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, zc = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: Uc,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, Gc = zc;
function at() {
  return Gc;
}
const In = Dt(!1);
var jc = Object.defineProperty, Vc = Object.defineProperties, Xc = Object.getOwnPropertyDescriptors, Lr = Object.getOwnPropertySymbols, Zc = Object.prototype.hasOwnProperty, Wc = Object.prototype.propertyIsEnumerable, Nr = (t, e, n) => e in t ? jc(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, Yc = (t, e) => {
  for (var n in e || (e = {}))
    Zc.call(e, n) && Nr(t, n, e[n]);
  if (Lr)
    for (var n of Lr(e))
      Wc.call(e, n) && Nr(t, n, e[n]);
  return t;
}, Qc = (t, e) => Vc(t, Xc(e));
let ei;
const Wt = Dt(null);
function Or(t) {
  return t.split("-").map((e, n, i) => i.slice(0, n + 1).join("-")).reverse();
}
function on(t, e = at().fallbackLocale) {
  const n = Or(t);
  return e ? [.../* @__PURE__ */ new Set([...n, ...Or(e)])] : n;
}
function Ge() {
  return ei ?? void 0;
}
Wt.subscribe((t) => {
  ei = t ?? void 0, typeof window < "u" && t != null && document.documentElement.setAttribute("lang", t);
});
const Kc = (t) => {
  if (t && Oc(t) && Jn(t)) {
    const { loadingDelay: e } = at();
    let n;
    return typeof window < "u" && Ge() != null && e ? n = window.setTimeout(
      () => In.set(!0),
      e
    ) : In.set(!0), Ma(t).then(() => {
      Wt.set(t);
    }).finally(() => {
      clearTimeout(n), In.set(!1);
    });
  }
  return Wt.set(t);
}, $t = Qc(Yc({}, Wt), {
  set: Kc
}), sn = (t) => {
  const e = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const r = JSON.stringify(i);
    return r in e ? e[r] : e[r] = t(i);
  };
};
var Jc = Object.defineProperty, Yt = Object.getOwnPropertySymbols, qa = Object.prototype.hasOwnProperty, Ua = Object.prototype.propertyIsEnumerable, Pr = (t, e, n) => e in t ? Jc(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, bi = (t, e) => {
  for (var n in e || (e = {}))
    qa.call(e, n) && Pr(t, n, e[n]);
  if (Yt)
    for (var n of Yt(e))
      Ua.call(e, n) && Pr(t, n, e[n]);
  return t;
}, st = (t, e) => {
  var n = {};
  for (var i in t)
    qa.call(t, i) && e.indexOf(i) < 0 && (n[i] = t[i]);
  if (t != null && Yt)
    for (var i of Yt(t))
      e.indexOf(i) < 0 && Ua.call(t, i) && (n[i] = t[i]);
  return n;
};
const vt = (t, e) => {
  const { formats: n } = at();
  if (t in n && e in n[t])
    return n[t][e];
  throw new Error(`[svelte-i18n] Unknown "${e}" ${t} format.`);
}, eh = sn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = st(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (r = vt("number", i)), new Intl.NumberFormat(n, r);
  }
), th = sn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = st(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? r = vt("date", i) : Object.keys(r).length === 0 && (r = vt("date", "short")), new Intl.DateTimeFormat(n, r);
  }
), nh = sn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = st(e, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? r = vt("time", i) : Object.keys(r).length === 0 && (r = vt("time", "short")), new Intl.DateTimeFormat(n, r);
  }
), ih = (t = {}) => {
  var e = t, {
    locale: n = Ge()
  } = e, i = st(e, [
    "locale"
  ]);
  return eh(bi({ locale: n }, i));
}, rh = (t = {}) => {
  var e = t, {
    locale: n = Ge()
  } = e, i = st(e, [
    "locale"
  ]);
  return th(bi({ locale: n }, i));
}, ah = (t = {}) => {
  var e = t, {
    locale: n = Ge()
  } = e, i = st(e, [
    "locale"
  ]);
  return nh(bi({ locale: n }, i));
}, oh = sn(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (t, e = Ge()) => new Bc(t, e, at().formats, {
    ignoreTag: at().ignoreTag
  })
), sh = (t, e = {}) => {
  var n, i, r, o;
  let a = e;
  typeof t == "object" && (a = t, t = a.id);
  const {
    values: s,
    locale: l = Ge(),
    default: u
  } = a;
  if (l == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let c = Oa(t, l);
  if (!c)
    c = (o = (r = (i = (n = at()).handleMissingMessage) == null ? void 0 : i.call(n, { locale: l, id: t, defaultValue: u })) != null ? r : u) != null ? o : t;
  else if (typeof c != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${t}" must be of type "string", found: "${typeof c}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), c;
  if (!s)
    return c;
  let _ = c;
  try {
    _ = oh(c, l).format(s);
  } catch (h) {
    h instanceof Error && console.warn(
      `[svelte-i18n] Message "${t}" has syntax error:`,
      h.message
    );
  }
  return _;
}, lh = (t, e) => ah(e).format(t), uh = (t, e) => rh(e).format(t), ch = (t, e) => ih(e).format(t), hh = (t, e = Ge()) => Oa(t, e);
ot([$t, wt], () => sh);
ot([$t], () => lh);
ot([$t], () => uh);
ot([$t], () => ch);
ot([$t, wt], () => hh);
const {
  SvelteComponent: _h,
  add_flush_callback: dh,
  assign: fh,
  bind: ph,
  binding_callbacks: mh,
  check_outros: gh,
  claim_component: Qt,
  claim_space: Hr,
  create_component: Kt,
  destroy_component: Jt,
  detach: Rn,
  empty: Mr,
  flush: V,
  get_spread_object: bh,
  get_spread_update: vh,
  group_outros: yh,
  init: Eh,
  insert_hydration: Ln,
  mount_component: en,
  noop: Dh,
  safe_not_equal: za,
  space: qr,
  transition_in: Je,
  transition_out: et
} = window.__gradio__svelte__internal;
function Ur(t) {
  let e, n, i;
  function r(a) {
    t[23](a);
  }
  let o = {
    file_count: (
      /*file_count*/
      t[9]
    ),
    interactive: (
      /*interactive*/
      t[16]
    ),
    ls_fn: (
      /*server*/
      t[15].ls
    )
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), e = new Gl({ props: o }), mh.push(() => ph(e, "value", r)), {
      c() {
        Kt(e.$$.fragment);
      },
      l(a) {
        Qt(e.$$.fragment, a);
      },
      m(a, s) {
        en(e, a, s), i = !0;
      },
      p(a, s) {
        const l = {};
        s & /*file_count*/
        512 && (l.file_count = /*file_count*/
        a[9]), s & /*interactive*/
        65536 && (l.interactive = /*interactive*/
        a[16]), s & /*server*/
        32768 && (l.ls_fn = /*server*/
        a[15].ls), !n && s & /*value*/
        1 && (n = !0, l.value = /*value*/
        a[0], dh(() => n = !1)), e.$set(l);
      },
      i(a) {
        i || (Je(e.$$.fragment, a), i = !0);
      },
      o(a) {
        et(e.$$.fragment, a), i = !1;
      },
      d(a) {
        Jt(e, a);
      }
    }
  );
}
function wh(t) {
  let e, n, i, r, o = (
    /*rerender_key*/
    t[17]
  ), a, s;
  const l = [
    /*loading_status*/
    t[10],
    {
      autoscroll: (
        /*gradio*/
        t[14].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[14].i18n
    ) }
  ];
  let u = {};
  for (let _ = 0; _ < l.length; _ += 1)
    u = fh(u, l[_]);
  e = new Su({ props: u }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    t[22]
  ), i = new Cs({
    props: {
      show_label: (
        /*show_label*/
        t[5]
      ),
      Icon: ro,
      label: (
        /*label*/
        t[4] || "FileExplorer"
      ),
      float: !1
    }
  });
  let c = Ur(t);
  return {
    c() {
      Kt(e.$$.fragment), n = qr(), Kt(i.$$.fragment), r = qr(), c.c(), a = Mr();
    },
    l(_) {
      Qt(e.$$.fragment, _), n = Hr(_), Qt(i.$$.fragment, _), r = Hr(_), c.l(_), a = Mr();
    },
    m(_, h) {
      en(e, _, h), Ln(_, n, h), en(i, _, h), Ln(_, r, h), c.m(_, h), Ln(_, a, h), s = !0;
    },
    p(_, h) {
      const p = h & /*loading_status, gradio*/
      17408 ? vh(l, [
        h & /*loading_status*/
        1024 && bh(
          /*loading_status*/
          _[10]
        ),
        h & /*gradio*/
        16384 && {
          autoscroll: (
            /*gradio*/
            _[14].autoscroll
          )
        },
        h & /*gradio*/
        16384 && { i18n: (
          /*gradio*/
          _[14].i18n
        ) }
      ]) : {};
      e.$set(p);
      const b = {};
      h & /*show_label*/
      32 && (b.show_label = /*show_label*/
      _[5]), h & /*label*/
      16 && (b.label = /*label*/
      _[4] || "FileExplorer"), i.$set(b), h & /*rerender_key*/
      131072 && za(o, o = /*rerender_key*/
      _[17]) ? (yh(), et(c, 1, 1, Dh), gh(), c = Ur(_), c.c(), Je(c, 1), c.m(a.parentNode, a)) : c.p(_, h);
    },
    i(_) {
      s || (Je(e.$$.fragment, _), Je(i.$$.fragment, _), Je(c), s = !0);
    },
    o(_) {
      et(e.$$.fragment, _), et(i.$$.fragment, _), et(c), s = !1;
    },
    d(_) {
      _ && (Rn(n), Rn(r), Rn(a)), Jt(e, _), Jt(i, _), c.d(_);
    }
  };
}
function $h(t) {
  let e, n;
  return e = new Eo({
    props: {
      visible: (
        /*visible*/
        t[3]
      ),
      variant: (
        /*value*/
        t[0] === null ? "dashed" : "solid"
      ),
      border_mode: "base",
      padding: !1,
      elem_id: (
        /*elem_id*/
        t[1]
      ),
      elem_classes: (
        /*elem_classes*/
        t[2]
      ),
      container: (
        /*container*/
        t[11]
      ),
      scale: (
        /*scale*/
        t[12]
      ),
      min_width: (
        /*min_width*/
        t[13]
      ),
      allow_overflow: !0,
      overflow_behavior: "auto",
      height: (
        /*height*/
        t[6]
      ),
      max_height: (
        /*max_height*/
        t[8]
      ),
      min_height: (
        /*min_height*/
        t[7]
      ),
      $$slots: { default: [wh] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      Kt(e.$$.fragment);
    },
    l(i) {
      Qt(e.$$.fragment, i);
    },
    m(i, r) {
      en(e, i, r), n = !0;
    },
    p(i, [r]) {
      const o = {};
      r & /*visible*/
      8 && (o.visible = /*visible*/
      i[3]), r & /*value*/
      1 && (o.variant = /*value*/
      i[0] === null ? "dashed" : "solid"), r & /*elem_id*/
      2 && (o.elem_id = /*elem_id*/
      i[1]), r & /*elem_classes*/
      4 && (o.elem_classes = /*elem_classes*/
      i[2]), r & /*container*/
      2048 && (o.container = /*container*/
      i[11]), r & /*scale*/
      4096 && (o.scale = /*scale*/
      i[12]), r & /*min_width*/
      8192 && (o.min_width = /*min_width*/
      i[13]), r & /*height*/
      64 && (o.height = /*height*/
      i[6]), r & /*max_height*/
      256 && (o.max_height = /*max_height*/
      i[8]), r & /*min_height*/
      128 && (o.min_height = /*min_height*/
      i[7]), r & /*$$scope, rerender_key, file_count, interactive, server, value, show_label, label, loading_status, gradio*/
      17024561 && (o.$$scope = { dirty: r, ctx: i }), e.$set(o);
    },
    i(i) {
      n || (Je(e.$$.fragment, i), n = !0);
    },
    o(i) {
      et(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Jt(e, i);
    }
  };
}
function Fh(t, e, n) {
  let i, { elem_id: r = "" } = e, { elem_classes: o = [] } = e, { visible: a = !0 } = e, { value: s } = e, l, { label: u } = e, { show_label: c } = e, { height: _ } = e, { min_height: h } = e, { max_height: p } = e, { file_count: b = "multiple" } = e, { root_dir: y } = e, { glob: E } = e, { ignore_glob: $ } = e, { loading_status: m } = e, { container: d = !0 } = e, { scale: f = null } = e, { min_width: v = void 0 } = e, { gradio: g } = e, { server: D } = e, { interactive: C } = e;
  const F = () => g.dispatch("clear_status", m);
  function x(w) {
    s = w, n(0, s);
  }
  return t.$$set = (w) => {
    "elem_id" in w && n(1, r = w.elem_id), "elem_classes" in w && n(2, o = w.elem_classes), "visible" in w && n(3, a = w.visible), "value" in w && n(0, s = w.value), "label" in w && n(4, u = w.label), "show_label" in w && n(5, c = w.show_label), "height" in w && n(6, _ = w.height), "min_height" in w && n(7, h = w.min_height), "max_height" in w && n(8, p = w.max_height), "file_count" in w && n(9, b = w.file_count), "root_dir" in w && n(18, y = w.root_dir), "glob" in w && n(19, E = w.glob), "ignore_glob" in w && n(20, $ = w.ignore_glob), "loading_status" in w && n(10, m = w.loading_status), "container" in w && n(11, d = w.container), "scale" in w && n(12, f = w.scale), "min_width" in w && n(13, v = w.min_width), "gradio" in w && n(14, g = w.gradio), "server" in w && n(15, D = w.server), "interactive" in w && n(16, C = w.interactive);
  }, t.$$.update = () => {
    t.$$.dirty & /*root_dir, glob, ignore_glob*/
    1835008 && n(17, i = [y, E, $]), t.$$.dirty & /*value, old_value, gradio*/
    2113537 && JSON.stringify(s) !== JSON.stringify(l) && (n(21, l = s), g.dispatch("change"));
  }, [
    s,
    r,
    o,
    a,
    u,
    c,
    _,
    h,
    p,
    b,
    m,
    d,
    f,
    v,
    g,
    D,
    C,
    i,
    y,
    E,
    $,
    l,
    F,
    x
  ];
}
class DS extends _h {
  constructor(e) {
    super(), Eh(this, e, Fh, $h, za, {
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 0,
      label: 4,
      show_label: 5,
      height: 6,
      min_height: 7,
      max_height: 8,
      file_count: 9,
      root_dir: 18,
      glob: 19,
      ignore_glob: 20,
      loading_status: 10,
      container: 11,
      scale: 12,
      min_width: 13,
      gradio: 14,
      server: 15,
      interactive: 16
    });
  }
  get elem_id() {
    return this.$$.ctx[1];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), V();
  }
  get elem_classes() {
    return this.$$.ctx[2];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), V();
  }
  get visible() {
    return this.$$.ctx[3];
  }
  set visible(e) {
    this.$$set({ visible: e }), V();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), V();
  }
  get label() {
    return this.$$.ctx[4];
  }
  set label(e) {
    this.$$set({ label: e }), V();
  }
  get show_label() {
    return this.$$.ctx[5];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), V();
  }
  get height() {
    return this.$$.ctx[6];
  }
  set height(e) {
    this.$$set({ height: e }), V();
  }
  get min_height() {
    return this.$$.ctx[7];
  }
  set min_height(e) {
    this.$$set({ min_height: e }), V();
  }
  get max_height() {
    return this.$$.ctx[8];
  }
  set max_height(e) {
    this.$$set({ max_height: e }), V();
  }
  get file_count() {
    return this.$$.ctx[9];
  }
  set file_count(e) {
    this.$$set({ file_count: e }), V();
  }
  get root_dir() {
    return this.$$.ctx[18];
  }
  set root_dir(e) {
    this.$$set({ root_dir: e }), V();
  }
  get glob() {
    return this.$$.ctx[19];
  }
  set glob(e) {
    this.$$set({ glob: e }), V();
  }
  get ignore_glob() {
    return this.$$.ctx[20];
  }
  set ignore_glob(e) {
    this.$$set({ ignore_glob: e }), V();
  }
  get loading_status() {
    return this.$$.ctx[10];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), V();
  }
  get container() {
    return this.$$.ctx[11];
  }
  set container(e) {
    this.$$set({ container: e }), V();
  }
  get scale() {
    return this.$$.ctx[12];
  }
  set scale(e) {
    this.$$set({ scale: e }), V();
  }
  get min_width() {
    return this.$$.ctx[13];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), V();
  }
  get gradio() {
    return this.$$.ctx[14];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), V();
  }
  get server() {
    return this.$$.ctx[15];
  }
  set server(e) {
    this.$$set({ server: e }), V();
  }
  get interactive() {
    return this.$$.ctx[16];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), V();
  }
}
export {
  DS as default
};
