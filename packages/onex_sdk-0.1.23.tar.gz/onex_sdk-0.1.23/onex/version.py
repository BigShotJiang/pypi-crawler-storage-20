"""Version information for OneX SDK"""
__version__ = "0.1.23"
__author__ = "OneX AI Team"
__email__ = "shuja.ahmed@getonex.ai"
