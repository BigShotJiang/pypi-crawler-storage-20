# -*- coding: utf-8 -*-
__version__ = '1.1'
from .cacheclass import cacheclass
cache=cacheclass()