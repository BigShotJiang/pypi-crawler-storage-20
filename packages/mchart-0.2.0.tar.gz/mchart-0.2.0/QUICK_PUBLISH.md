# 快速发布指南

## 三步发布到 PyPI

### 步骤 1: 更新作者信息

编辑 `pyproject.toml`，修改第 9 行：

```toml
authors = [
    { name = "你的名字", email = "你的邮箱@example.com" }
]
```

### 步骤 2: 获取 PyPI Token

1. 访问: https://pypi.org/account/register/（如果还没账号）
2. 登录后访问: https://pypi.org/manage/account/token/
3. 创建 API Token，复制保存（格式: `pypi-...`）

### 步骤 3: 发布

```powershell
# 方式 1: 使用脚本（推荐）
.\scripts\publish.ps1

# 方式 2: 手动上传
uv run twine upload dist/*
```

输入凭据时：
- **Username**: `__token__`
- **Password**: 粘贴你的 PyPI token

---

## 完成！🎉

发布成功后：

1. 访问: https://pypi.org/project/mchart/
2. 测试安装: `pip install mchart`
3. 测试使用:
   ```python
   from mchart import MChart
   client = MChart()
   chart = client.get_chart("billboard", "hot-100")
   print(chart['entries'][0])
   ```

---

## 测试发布（推荐先做）

在正式发布前，建议先发布到 TestPyPI：

```powershell
.\scripts\publish.ps1 -test
```

或手动：

```powershell
uv run twine upload --repository testpypi dist/*
```

测试安装：

```powershell
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mchart
```

---

## 需要帮助？

查看完整文档：
- [PUBLISHING.md](PUBLISHING.md) - 详细发布指南
- [RELEASE_NOTES.md](RELEASE_NOTES.md) - 发布说明
- [docs/API.md](docs/API.md) - API 文档
