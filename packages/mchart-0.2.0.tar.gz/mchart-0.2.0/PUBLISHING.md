# 发布到 PyPI 指南

本文档介绍如何将 MChart 发布到 PyPI。

## 前提条件

### 1. PyPI 账号

如果还没有 PyPI 账号，需要先注册：

- **生产环境**: https://pypi.org/account/register/
- **测试环境**: https://test.pypi.org/account/register/

### 2. API Token

登录 PyPI 后，创建 API token：

1. 访问 https://pypi.org/manage/account/token/
2. 点击 "Add API token"
3. 设置 token 名称（如 "mchart-upload"）
4. 选择作用域（首次发布选择 "Entire account"，之后可以限制到特定项目）
5. 复制生成的 token（格式：`pypi-...`）

**重要**: Token 只显示一次，请妥善保存！

## 发布步骤

### 步骤 1: 更新项目信息

编辑 `pyproject.toml`，更新以下信息：

```toml
[project]
name = "mchart"
version = "0.2.0"  # 根据需要更新版本号
authors = [
    { name = "你的名字", email = "your.email@example.com" }  # ← 修改这里
]

[project.urls]
Homepage = "https://github.com/你的用户名/mchart"  # ← 修改这里
Documentation = "https://github.com/你的用户名/mchart#readme"
Repository = "https://github.com/你的用户名/mchart"
Issues = "https://github.com/你的用户名/mchart/issues"
```

### 步骤 2: 清理旧的构建文件

```bash
# 删除旧的构建文件（如果存在）
Remove-Item -Recurse -Force dist, build, *.egg-info -ErrorAction SilentlyContinue
```

### 步骤 3: 构建项目

#### 使用 uv（推荐）

```bash
# 构建
uv build
```

#### 或使用传统方式

```bash
# 安装构建工具
pip install build

# 构建
python -m build
```

构建成功后，会在 `dist/` 目录生成两个文件：
- `mchart-0.2.0.tar.gz` - 源代码分发包
- `mchart-0.2.0-py3-none-any.whl` - wheel 包

### 步骤 4: 检查构建产物

```bash
# 安装检查工具
pip install twine

# 检查构建的包
twine check dist/*
```

应该看到类似输出：
```
Checking dist/mchart-0.2.0.tar.gz: PASSED
Checking dist/mchart-0.2.0-py3-none-any.whl: PASSED
```

### 步骤 5: 测试安装（可选但推荐）

在发布前，先在本地测试安装：

```bash
# 创建虚拟环境测试
python -m venv test_env
test_env\Scripts\activate
pip install dist/mchart-0.2.0-py3-none-any.whl

# 测试导入
python -c "from mchart import MChart; print('Import successful!')"

# 退出虚拟环境
deactivate
```

### 步骤 6: 发布到 TestPyPI（推荐先测试）

在正式发布前，先发布到 TestPyPI 测试：

```bash
# 发布到 TestPyPI
twine upload --repository testpypi dist/*
```

输入：
- Username: `__token__`
- Password: 你的 TestPyPI token（包含 `pypi-` 前缀）

从 TestPyPI 测试安装：

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mchart
```

### 步骤 7: 发布到 PyPI（正式发布）

测试通过后，发布到正式 PyPI：

```bash
# 发布到 PyPI
twine upload dist/*
```

输入：
- Username: `__token__`
- Password: 你的 PyPI token（包含 `pypi-` 前缀）

### 步骤 8: 验证发布

发布成功后：

1. 访问 https://pypi.org/project/mchart/ 查看项目页面
2. 测试安装：
   ```bash
   pip install mchart
   python -c "from mchart import MChart; print('Success!')"
   ```

## 使用 uv 简化发布流程

如果使用 uv，可以使用以下简化命令：

```bash
# 1. 构建
uv build

# 2. 发布到 TestPyPI
uv publish --token $YOUR_TOKEN --repository testpypi

# 3. 发布到 PyPI
uv publish --token $YOUR_TOKEN
```

## 配置文件方式（避免每次输入 token）

创建 `~/.pypirc` 文件（Windows: `%USERPROFILE%\.pypirc`）：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-你的token

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-你的testpypi_token
```

**安全提示**: 
- 不要将 `.pypirc` 提交到 Git
- 设置文件权限为仅自己可读

配置后，可以直接发布：

```bash
twine upload dist/*  # 会自动使用 .pypirc 中的配置
```

## 版本管理

每次发布新版本时：

1. 更新 `pyproject.toml` 中的 `version`
2. 更新 `mchart/__init__.py` 中的 `__version__`
3. 更新 `CHANGELOG.md`（如果有）
4. 创建 git tag：
   ```bash
   git tag -a v0.2.0 -m "Release version 0.2.0"
   git push origin v0.2.0
   ```

## 版本号规范（Semantic Versioning）

遵循语义化版本：`MAJOR.MINOR.PATCH`

- **MAJOR**: 不兼容的 API 更改
- **MINOR**: 向后兼容的新功能
- **PATCH**: 向后兼容的 bug 修复

示例：
- `0.1.0` → `0.1.1`: Bug 修复
- `0.1.1` → `0.2.0`: 添加新功能
- `0.2.0` → `1.0.0`: 第一个稳定版本或重大更改

## 常见问题

### Q: 上传时提示 "File already exists"

A: PyPI 不允许覆盖已发布的版本。需要更新版本号后重新构建和上传。

### Q: 如何删除已发布的包？

A: 不建议删除。如果必须删除，可以在 PyPI 网站上操作，但该版本号将永久保留无法重用。

### Q: 如何更新已发布包的描述？

A: 需要发布新版本。PyPI 不允许修改已发布版本的元数据。

### Q: 测试安装时找不到依赖

A: TestPyPI 不包含所有 PyPI 的包。安装时添加 `--extra-index-url https://pypi.org/simple/`

## 发布检查清单

发布前检查：

- [ ] 代码已提交并推送到 Git
- [ ] 所有测试通过
- [ ] 文档已更新
- [ ] 版本号已更新（pyproject.toml 和 __init__.py）
- [ ] README.md 中的 GitHub URL 已更新
- [ ] LICENSE 文件存在
- [ ] .gitignore 配置正确（不包含敏感信息）
- [ ] 构建通过 (`uv build` 或 `python -m build`)
- [ ] 通过 `twine check dist/*` 检查
- [ ] 在 TestPyPI 测试成功

## 自动化发布（GitHub Actions）

可以创建 `.github/workflows/publish.yml` 实现自动发布：

```yaml
name: Publish to PyPI

on:
  release:
    types: [created]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    - name: Build
      run: python -m build
    - name: Publish
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*
```

在 GitHub 仓库设置中添加 secret `PYPI_API_TOKEN`。

## 相关链接

- PyPI 官网: https://pypi.org/
- TestPyPI: https://test.pypi.org/
- PyPI 帮助文档: https://packaging.python.org/
- Twine 文档: https://twine.readthedocs.io/
- UV 文档: https://docs.astral.sh/uv/

---

**祝发布顺利！** 🚀
