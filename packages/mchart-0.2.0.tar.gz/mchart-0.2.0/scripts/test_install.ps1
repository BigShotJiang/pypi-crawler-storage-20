# 测试本地安装脚本
# 在虚拟环境中测试安装构建的包

Write-Host "=== 测试 MChart 本地安装 ===" -ForegroundColor Cyan
Write-Host ""

# 检查构建文件
if (-not (Test-Path "dist\mchart-0.2.0-py3-none-any.whl")) {
    Write-Host "[错误] 找不到构建文件，请先运行 'uv build'" -ForegroundColor Red
    exit 1
}

# 创建测试环境
Write-Host "1. 创建测试虚拟环境..." -ForegroundColor Yellow
if (Test-Path "test_env") {
    Remove-Item -Recurse -Force test_env
}
python -m venv test_env
Write-Host "   [完成]" -ForegroundColor Green

# 激活环境
Write-Host ""
Write-Host "2. 安装包..." -ForegroundColor Yellow
& test_env\Scripts\pip.exe install --quiet dist\mchart-0.2.0-py3-none-any.whl
Write-Host "   [完成]" -ForegroundColor Green

# 测试导入
Write-Host ""
Write-Host "3. 测试导入..." -ForegroundColor Yellow
$result = & test_env\Scripts\python.exe -c "from mchart import MChart; print('OK')" 2>&1
if ($LASTEXITCODE -eq 0 -and $result -eq "OK") {
    Write-Host "   [完成] 导入成功" -ForegroundColor Green
} else {
    Write-Host "   [错误] 导入失败" -ForegroundColor Red
    Write-Host $result
    exit 1
}

# 测试基本功能
Write-Host ""
Write-Host "4. 测试基本功能..." -ForegroundColor Yellow
$testCode = @"
from mchart import MChart
client = MChart()
providers = client.providers
print(f'Available providers: {providers}')
if 'billboard' in providers:
    print('Billboard provider loaded successfully')
"@

$result = & test_env\Scripts\python.exe -c $testCode 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "   [完成]" -ForegroundColor Green
    Write-Host ""
    Write-Host "测试输出:" -ForegroundColor Cyan
    Write-Host $result -ForegroundColor White
} else {
    Write-Host "   [错误] 功能测试失败" -ForegroundColor Red
    Write-Host $result
    exit 1
}

# 清理
Write-Host ""
Write-Host "5. 清理测试环境..." -ForegroundColor Yellow
Remove-Item -Recurse -Force test_env
Write-Host "   [完成]" -ForegroundColor Green

Write-Host ""
Write-Host "=== 所有测试通过! ===" -ForegroundColor Green
