# MChart 发布脚本
# 使用方法: .\scripts\publish.ps1 [-test]
# -test: 发布到 TestPyPI

param(
    [switch]$test = $false
)

Write-Host "=== MChart 发布脚本 ===" -ForegroundColor Cyan
Write-Host ""

# 检查是否在项目根目录
if (-not (Test-Path "pyproject.toml")) {
    Write-Host "[错误] 请在项目根目录运行此脚本" -ForegroundColor Red
    exit 1
}

# 1. 清理旧构建
Write-Host "1. 清理旧构建文件..." -ForegroundColor Yellow
if (Test-Path "dist") {
    Remove-Item -Recurse -Force dist
}
if (Test-Path "build") {
    Remove-Item -Recurse -Force build
}
Get-ChildItem -Filter "*.egg-info" -Recurse | Remove-Item -Recurse -Force
Write-Host "   [完成] 清理完成" -ForegroundColor Green

# 2. 构建
Write-Host ""
Write-Host "2. 构建包..." -ForegroundColor Yellow
uv build
if ($LASTEXITCODE -ne 0) {
    Write-Host "   [错误] 构建失败" -ForegroundColor Red
    exit 1
}
Write-Host "   [完成] 构建成功" -ForegroundColor Green

# 3. 检查
Write-Host ""
Write-Host "3. 检查包完整性..." -ForegroundColor Yellow
uv run twine check dist/*
if ($LASTEXITCODE -ne 0) {
    Write-Host "   [错误] 包检查失败" -ForegroundColor Red
    exit 1
}
Write-Host "   [完成] 检查通过" -ForegroundColor Green

# 4. 列出构建文件
Write-Host ""
Write-Host "4. 构建产物:" -ForegroundColor Yellow
Get-ChildItem dist | ForEach-Object {
    $size = [math]::Round($_.Length / 1KB, 2)
    Write-Host "   - $($_.Name) (${size} KB)" -ForegroundColor Cyan
}

# 5. 确认发布
Write-Host ""
if ($test) {
    Write-Host "准备发布到 TestPyPI" -ForegroundColor Magenta
} else {
    Write-Host "准备发布到 PyPI (正式环境)" -ForegroundColor Magenta
}

$confirm = Read-Host "是否继续? (y/N)"
if ($confirm -ne "y" -and $confirm -ne "Y") {
    Write-Host "已取消发布" -ForegroundColor Yellow
    exit 0
}

# 6. 发布
Write-Host ""
Write-Host "5. 上传到 " -NoNewline -ForegroundColor Yellow
if ($test) {
    Write-Host "TestPyPI..." -ForegroundColor Magenta
    Write-Host ""
    Write-Host "提示: Username 输入: __token__" -ForegroundColor Cyan
    Write-Host "      Password 输入你的 TestPyPI token" -ForegroundColor Cyan
    Write-Host ""
    uv run twine upload --repository testpypi dist/*
} else {
    Write-Host "PyPI..." -ForegroundColor Magenta
    Write-Host ""
    Write-Host "提示: Username 输入: __token__" -ForegroundColor Cyan
    Write-Host "      Password 输入你的 PyPI token" -ForegroundColor Cyan
    Write-Host ""
    uv run twine upload dist/*
}

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "=== 发布成功! ===" -ForegroundColor Green
    Write-Host ""
    if ($test) {
        Write-Host "测试安装命令:" -ForegroundColor Cyan
        Write-Host "pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ mchart" -ForegroundColor White
        Write-Host ""
        Write-Host "查看项目: https://test.pypi.org/project/mchart/" -ForegroundColor Cyan
    } else {
        Write-Host "安装命令:" -ForegroundColor Cyan
        Write-Host "pip install mchart" -ForegroundColor White
        Write-Host ""
        Write-Host "查看项目: https://pypi.org/project/mchart/" -ForegroundColor Cyan
    }
} else {
    Write-Host ""
    Write-Host "=== 发布失败 ===" -ForegroundColor Red
    Write-Host "请检查错误信息并重试" -ForegroundColor Yellow
    exit 1
}
