# MChart v0.2.0 发布说明

## ✅ 构建状态

- ✅ **构建成功**: `dist/mchart-0.2.0-py3-none-any.whl` (约 25 KB)
- ✅ **源码包**: `dist/mchart-0.2.0.tar.gz`
- ✅ **包验证通过**: `twine check` 全部 PASSED

## 📦 发布前准备

### 1. 更新作者信息（必需）

编辑 `pyproject.toml` 第 9 行：

```toml
authors = [
    { name = "你的名字", email = "your.email@example.com" }
]
```

### 2. 更新 GitHub URL（可选）

如果你有 GitHub 仓库，更新第 40-43 行：

```toml
[project.urls]
Homepage = "https://github.com/你的用户名/mchart"
Repository = "https://github.com/你的用户名/mchart"
# ...
```

## 🚀 发布到 PyPI

### 方式 1: 使用发布脚本（推荐）

```powershell
# 发布到 TestPyPI（测试环境，推荐先测试）
.\scripts\publish.ps1 -test

# 发布到 PyPI（正式环境）
.\scripts\publish.ps1
```

### 方式 2: 手动发布

#### 步骤 1: 获取 PyPI Token

1. 注册/登录 PyPI: https://pypi.org/account/register/
2. 创建 API Token: https://pypi.org/manage/account/token/
3. 保存 token（格式: `pypi-...`）

#### 步骤 2: 上传到 PyPI

```powershell
# 上传
uv run twine upload dist/*
```

输入：
- **Username**: `__token__`
- **Password**: 你的 PyPI token

## 📝 发布检查清单

发布前确认：

- [ ] 更新了作者信息（pyproject.toml）
- [ ] 版本号正确（当前 0.2.0）
- [ ] 代码已提交到 Git
- [ ] README.md 完整
- [ ] 文档完整（docs/API.md）
- [ ] 示例可运行（examples/）
- [ ] LICENSE 文件存在
- [ ] 构建成功（dist/ 目录有文件）
- [ ] 包验证通过（twine check）

## 🎯 发布后验证

### 测试安装

```bash
# 创建新环境测试
python -m venv test_install
test_install\Scripts\activate
pip install mchart
python -c "from mchart import MChart; print('Success!')"
deactivate
```

### 查看项目页面

- https://pypi.org/project/mchart/

## 📊 项目统计

- **包名称**: mchart
- **当前版本**: 0.2.0
- **Python 版本**: >=3.10
- **依赖包**: 4 个（pydantic, requests, beautifulsoup4, urllib3）
- **可选依赖**: lxml（加速 HTML 解析）

## 🎉 功能亮点

### v0.2.0 (2026-01-18)

这是第一个公开发布的版本，包含：

#### ✅ 核心功能
- 统一的 MChart 客户端接口
- 灵活的 TypedDict 配置系统
- 双返回格式支持（dict/Pydantic model）
- 标准化的 Provider 接口
- 完整的类型提示

#### ✅ Billboard Provider
- 支持 7 种主要排行榜
  - Hot 100（美国最热门 100 首歌曲）
  - Billboard 200（最热门 200 张专辑）
  - Global 200（全球最热门 200 首歌曲）
  - Artist 100（最热门 100 位艺术家）
  - Streaming Songs（流媒体最热歌曲）
  - Radio Songs（电台最热播放歌曲）
  - Digital Song Sales（数字单曲销量榜）
- 完整的数据提取（排名、上周排名、在榜周数、峰值）
- 可配置的 HTML 解析器
- 自动重试机制

#### 📋 Spotify Provider
- 占位实现，等待完整开发

#### 📚 文档
- 完整的中英双语 README
- 详细的 API 文档（606 行）
- 项目结构说明
- 4 个使用示例脚本

#### 🔧 开发工具
- 示例脚本（examples/）
- 发布脚本（scripts/）
- 完整的发布指南

## 🔜 未来计划

### 短期（下个版本）
- [ ] Spotify Provider 完整实现
- [ ] 单元测试
- [ ] CI/CD 流程
- [ ] 缓存机制

### 长期
- [ ] Apple Music 支持
- [ ] YouTube Music 支持
- [ ] 更多榜单支持
- [ ] 异步 API
- [ ] CLI 工具

## 📞 支持

遇到问题？

- 查看文档: [docs/API.md](docs/API.md)
- 提交 Issue: (如果有 GitHub 仓库)
- 查看示例: [examples/](examples/)

## 🙏 致谢

感谢所有使用和贡献 MChart 的开发者！

---

**准备好发布了吗？** 🚀

1. 确认检查清单
2. 更新作者信息
3. 运行 `.\scripts\publish.ps1`
4. 享受你的开源项目！
