// Adapted from: https://github.com/rust-lang-ja/ac-library-rs/blob/0cdbc5e2ad110b688b0239e0208e275dde94a1e2/src/string.rs
use std::{cmp, mem};

use num_traits::{PrimInt, Unsigned};
use rayon::prelude::*;

fn suffix_array_naive<Element: PrimInt + Unsigned + Send + Sync>(
    data: &[Option<Element>],
) -> Vec<usize> {
    let length = data.len();

    let mut suffix_idx = (0..length).collect::<Vec<_>>();
    suffix_idx.par_sort_by(|&(mut left), &(mut right)| {
        if left == right {
            return cmp::Ordering::Equal;
        }
        while left < length && right < length {
            if data[left] != data[right] {
                return data[left].cmp(&data[right]);
            }
            left += 1;
            right += 1;
        }
        if left == length {
            cmp::Ordering::Less
        } else {
            cmp::Ordering::Greater
        }
    });

    suffix_idx
}

fn suffix_array_doubling<Element: PrimInt + Unsigned + Send + Sync>(
    data: &[Option<Element>],
) -> Vec<usize> {
    let length = data.len();

    let mut suffix_idx = (0..length).collect::<Vec<_>>();
    let mut rank = data
        .iter()
        .map(|&symbol| match symbol {
            Some(value) => value.to_usize().unwrap() + 1,
            None => 0,
        })
        .collect::<Vec<_>>();

    let mut next_rank = vec![0usize; length];
    let mut prefix_len = 1;

    while prefix_len < length {
        let compare_suffix = |&i: &usize, &j: &usize| {
            if rank[i] != rank[j] {
                return rank[i].cmp(&rank[j]);
            }
            match (i + prefix_len < length, j + prefix_len < length) {
                (false, false) => cmp::Ordering::Equal,
                (false, true) => cmp::Ordering::Less,
                (true, false) => cmp::Ordering::Greater,
                (true, true) => rank[i + prefix_len].cmp(&rank[j + prefix_len]),
            }
        };

        suffix_idx.par_sort_by(compare_suffix);

        next_rank[suffix_idx[0]] = 0;
        for i in 1..length {
            let increment =
                compare_suffix(&suffix_idx[i - 1], &suffix_idx[i]) == cmp::Ordering::Less;
            next_rank[suffix_idx[i]] = if increment {
                next_rank[suffix_idx[i - 1]] + 1
            } else {
                next_rank[suffix_idx[i - 1]]
            };
        }

        mem::swap(&mut rank, &mut next_rank);
        prefix_len *= 2;
    }

    suffix_idx
}

fn suffix_array_induced_sorting<Element: PrimInt + Unsigned + Send + Sync>(
    data: &[Option<Element>],
    alphabet_max: Option<Element>,
) -> Vec<usize> {
    let alphabet_max = match alphabet_max {
        Some(value) => value.to_usize().unwrap() + 1,
        None => 1usize,
    };
    let length = data.len();
    let mut suffix_idx = vec![0usize; length];
    let mut is_s_type = vec![false; length];
    for i in (0..length - 1).rev() {
        is_s_type[i] = if data[i] == data[i + 1] {
            is_s_type[i + 1]
        } else {
            data[i] < data[i + 1]
        };
    }

    let mut bucket_l_start = vec![0usize; alphabet_max + 1];
    let mut bucket_s_start = vec![0usize; alphabet_max + 1];
    for i in 0..length {
        let index = match data[i] {
            Some(value) => value.to_usize().unwrap() + 1,
            None => 0,
        };
        if is_s_type[i] {
            bucket_l_start[index + 1] += 1;
        } else {
            bucket_s_start[index] += 1;
        }
    }
    for i in 0..=alphabet_max {
        bucket_s_start[i] += bucket_l_start[i];
        if i < alphabet_max {
            bucket_l_start[i + 1] += bucket_s_start[i];
        }
    }

    // suffix array's origin is +1
    let induced_sort = |suffix_idx: &mut [usize], lms_positions: &[usize]| {
        suffix_idx.iter_mut().for_each(|elem| {
            *elem = 0;
        });
        let mut bucket_cursor = bucket_s_start.clone();
        for &lms_pos in lms_positions {
            if lms_pos == length {
                continue;
            }
            let index = match data[lms_pos] {
                Some(value) => value.to_usize().unwrap() + 1,
                None => 0,
            };
            let pos = bucket_cursor[index];
            bucket_cursor[index] += 1;
            suffix_idx[pos] = lms_pos + 1;
        }
        bucket_cursor.copy_from_slice(&bucket_l_start);
        let index = match data[length - 1] {
            Some(value) => value.to_usize().unwrap() + 1,
            None => 0,
        };
        let pos = bucket_cursor[index];
        bucket_cursor[index] += 1;
        suffix_idx[pos] = length;
        for i in 0..length {
            let sa_value = suffix_idx[i];
            if sa_value >= 2 && !is_s_type[sa_value - 2] {
                let index = match data[sa_value - 2] {
                    Some(value) => value.to_usize().unwrap() + 1,
                    None => 0,
                };
                let old = bucket_cursor[index];
                bucket_cursor[index] += 1;
                suffix_idx[old] = sa_value - 1;
            }
        }
        bucket_cursor.copy_from_slice(&bucket_l_start);
        for i in (0..length).rev() {
            let sa_value = suffix_idx[i];
            if sa_value >= 2 && is_s_type[sa_value - 2] {
                let index = match data[sa_value - 2] {
                    Some(value) => value.to_usize().unwrap() + 1,
                    None => 0,
                };
                bucket_cursor[index + 1] -= 1;
                let pos = bucket_cursor[index + 1];
                suffix_idx[pos] = sa_value - 1;
            }
        }
    };

    // origin of lms_index is +1
    let mut lms_index = vec![0usize; length + 1];
    let mut num_lms = 0usize;
    let mut lms_positions = vec![];
    for i in 1..length {
        if !is_s_type[i - 1] && is_s_type[i] {
            lms_index[i] = num_lms + 1;
            num_lms += 1;
            lms_positions.push(i);
        }
    }
    debug_assert_eq!(lms_positions.len(), num_lms);
    induced_sort(&mut suffix_idx, &lms_positions);

    if num_lms > 0 {
        let mut sorted_lms_positions = suffix_idx
            .iter()
            .filter_map(|&sa_value| {
                if lms_index[sa_value - 1] > 0 {
                    Some(sa_value - 1)
                } else {
                    None
                }
            })
            .collect::<Vec<_>>();
        let mut reduced_data = vec![0usize; num_lms];
        let mut reduced_alphabet_max = 0usize;
        reduced_data[lms_index[sorted_lms_positions[0]] - 1] = 0usize;
        for i in 1..num_lms {
            let mut prev_pos = sorted_lms_positions[i - 1];
            let mut curr_pos = sorted_lms_positions[i];
            let prev_end = if lms_index[prev_pos] < num_lms {
                lms_positions[lms_index[prev_pos]]
            } else {
                length
            };
            let curr_end = if lms_index[curr_pos] < num_lms {
                lms_positions[lms_index[curr_pos]]
            } else {
                length
            };
            let is_same_lms_substring = if prev_end - prev_pos != curr_end - curr_pos {
                false
            } else {
                while prev_pos < prev_end && data[prev_pos] == data[curr_pos] {
                    prev_pos += 1;
                    curr_pos += 1;
                }
                prev_pos != length && data[prev_pos] == data[curr_pos]
            };

            if !is_same_lms_substring {
                reduced_alphabet_max += 1;
            }
            reduced_data[lms_index[sorted_lms_positions[i]] - 1] = reduced_alphabet_max;
        }

        let reduced_suffix_array = suffix_array(
            &reduced_data.into_iter().map(Some).collect::<Vec<_>>(),
            Some(reduced_alphabet_max),
        );
        for i in 0..num_lms {
            sorted_lms_positions[i] = lms_positions[reduced_suffix_array[i]];
        }
        induced_sort(&mut suffix_idx, &sorted_lms_positions);
    };
    suffix_idx.iter_mut().for_each(|x| *x -= 1);
    suffix_idx
}

pub(crate) fn suffix_array<Element: PrimInt + Unsigned + Send + Sync>(
    data: &[Option<Element>],
    alphabet_max: Option<Element>,
) -> Vec<usize> {
    match data.len() {
        0..2 => (0..data.len()).collect(),
        2 => {
            if data[0] < data[1] {
                vec![0, 1]
            } else {
                vec![1, 0]
            }
        }
        3..10 => suffix_array_naive(data),
        10..40 => suffix_array_doubling(data),
        _ => suffix_array_induced_sorting(data, alphabet_max),
    }
}

#[cfg(test)]
mod tests {
    use std::iter;

    use super::*;

    fn verify_all(array: &[Option<u8>], expected_idx: &[usize]) {
        let suffix_idx_doubling = suffix_array_doubling(array);
        assert_eq!(suffix_idx_doubling, expected_idx);
        let suffix_idx_naive = suffix_array_naive(array);
        assert_eq!(suffix_idx_naive, expected_idx);
        let suffix_idx_induced_sorting = suffix_array_induced_sorting(array, Some(u8::MAX));
        assert_eq!(suffix_idx_induced_sorting, expected_idx);
        let suffix_idx = suffix_array(array, Some(u8::MAX));
        assert_eq!(suffix_idx, expected_idx);
    }

    #[test]
    fn test_suffix_array_0() {
        let array = [None, Some(0u32), Some(1), Some(2), Some(3), Some(4)];
        let suffix_idx = suffix_array_doubling(&array);
        assert_eq!(suffix_idx, [0, 1, 2, 3, 4, 5]);
    }

    #[test]
    fn test_suffix_array_1() {
        let str = "abracadabra";
        let array = str
            .bytes()
            .map(Some)
            .chain(iter::once(None))
            .collect::<Vec<_>>();
        verify_all(&array, &[11, 10, 7, 0, 3, 5, 8, 1, 4, 6, 9, 2]);
    }

    #[test]
    fn test_suffix_array_2() {
        let str = "mmiissiissiippii"; // an example taken from https://mametter.hatenablog.com/entry/20180130/p1
        let array = str
            .bytes()
            .map(Some)
            .chain(iter::once(None))
            .collect::<Vec<_>>();
        verify_all(
            &array,
            &[16, 15, 14, 10, 6, 2, 11, 7, 3, 1, 0, 13, 12, 9, 5, 8, 4],
        );
    }

    #[test]
    fn test_suffix_array_3() {
        let str = "mississippi".repeat(50);
        let array = str
            .bytes()
            .map(Some)
            .chain(iter::once(None))
            .collect::<Vec<_>>();
        verify_all(
            &array,
            &[
                550, 549, 538, 527, 516, 505, 494, 483, 472, 461, 450, 439, 428, 417, 406, 395,
                384, 373, 362, 351, 340, 329, 318, 307, 296, 285, 274, 263, 252, 241, 230, 219,
                208, 197, 186, 175, 164, 153, 142, 131, 120, 109, 98, 87, 76, 65, 54, 43, 32, 21,
                10, 546, 535, 524, 513, 502, 491, 480, 469, 458, 447, 436, 425, 414, 403, 392, 381,
                370, 359, 348, 337, 326, 315, 304, 293, 282, 271, 260, 249, 238, 227, 216, 205,
                194, 183, 172, 161, 150, 139, 128, 117, 106, 95, 84, 73, 62, 51, 40, 29, 18, 7,
                543, 532, 521, 510, 499, 488, 477, 466, 455, 444, 433, 422, 411, 400, 389, 378,
                367, 356, 345, 334, 323, 312, 301, 290, 279, 268, 257, 246, 235, 224, 213, 202,
                191, 180, 169, 158, 147, 136, 125, 114, 103, 92, 81, 70, 59, 48, 37, 26, 15, 4,
                540, 529, 518, 507, 496, 485, 474, 463, 452, 441, 430, 419, 408, 397, 386, 375,
                364, 353, 342, 331, 320, 309, 298, 287, 276, 265, 254, 243, 232, 221, 210, 199,
                188, 177, 166, 155, 144, 133, 122, 111, 100, 89, 78, 67, 56, 45, 34, 23, 12, 1,
                539, 528, 517, 506, 495, 484, 473, 462, 451, 440, 429, 418, 407, 396, 385, 374,
                363, 352, 341, 330, 319, 308, 297, 286, 275, 264, 253, 242, 231, 220, 209, 198,
                187, 176, 165, 154, 143, 132, 121, 110, 99, 88, 77, 66, 55, 44, 33, 22, 11, 0, 548,
                537, 526, 515, 504, 493, 482, 471, 460, 449, 438, 427, 416, 405, 394, 383, 372,
                361, 350, 339, 328, 317, 306, 295, 284, 273, 262, 251, 240, 229, 218, 207, 196,
                185, 174, 163, 152, 141, 130, 119, 108, 97, 86, 75, 64, 53, 42, 31, 20, 9, 547,
                536, 525, 514, 503, 492, 481, 470, 459, 448, 437, 426, 415, 404, 393, 382, 371,
                360, 349, 338, 327, 316, 305, 294, 283, 272, 261, 250, 239, 228, 217, 206, 195,
                184, 173, 162, 151, 140, 129, 118, 107, 96, 85, 74, 63, 52, 41, 30, 19, 8, 545,
                534, 523, 512, 501, 490, 479, 468, 457, 446, 435, 424, 413, 402, 391, 380, 369,
                358, 347, 336, 325, 314, 303, 292, 281, 270, 259, 248, 237, 226, 215, 204, 193,
                182, 171, 160, 149, 138, 127, 116, 105, 94, 83, 72, 61, 50, 39, 28, 17, 6, 542,
                531, 520, 509, 498, 487, 476, 465, 454, 443, 432, 421, 410, 399, 388, 377, 366,
                355, 344, 333, 322, 311, 300, 289, 278, 267, 256, 245, 234, 223, 212, 201, 190,
                179, 168, 157, 146, 135, 124, 113, 102, 91, 80, 69, 58, 47, 36, 25, 14, 3, 544,
                533, 522, 511, 500, 489, 478, 467, 456, 445, 434, 423, 412, 401, 390, 379, 368,
                357, 346, 335, 324, 313, 302, 291, 280, 269, 258, 247, 236, 225, 214, 203, 192,
                181, 170, 159, 148, 137, 126, 115, 104, 93, 82, 71, 60, 49, 38, 27, 16, 5, 541,
                530, 519, 508, 497, 486, 475, 464, 453, 442, 431, 420, 409, 398, 387, 376, 365,
                354, 343, 332, 321, 310, 299, 288, 277, 266, 255, 244, 233, 222, 211, 200, 189,
                178, 167, 156, 145, 134, 123, 112, 101, 90, 79, 68, 57, 46, 35, 24, 13, 2,
            ],
        );
    }

    #[test]
    fn test_suffix_array_4() {
        let str_list = ["banana", "ananas", "abracadabra", "mississippi"];
        let array = str_list
            .iter()
            .flat_map(|&str| str.bytes().map(Some).chain(iter::once(None)))
            .collect::<Vec<_>>();
        verify_all(
            &array,
            &[
                37, 13, 6, 25, 5, 24, 21, 14, 17, 19, 3, 1, 7, 9, 11, 0, 22, 15, 18, 20, 36, 33,
                30, 27, 26, 4, 2, 8, 10, 35, 34, 23, 16, 12, 32, 29, 31, 28,
            ],
        );
    }
}
