# **Antyx**

Version: 0.1

Antyx is an automated EDA engine designed to generate fast, structured and professional exploratory reports from any tabular dataset.

* PyPI package: https://pypi.org/project/Antyx/
* Free software: MIT License
* Documentation: https://Antix.readthedocs.io.

## Installation

Pypi

Basic dependencies:
```bash
pip install src
```

All dependencies (extras included)
```bash
pip install src[all]
```

GitHub
```bash
git clone https://github.com/DRMdata/antyx.git
cd src
pip install -e .
```

## Features

Statistical profiling

Correlation analysis

Outlier detection

Variable typing

Clean HTML reports

Pandas & Polars compatible