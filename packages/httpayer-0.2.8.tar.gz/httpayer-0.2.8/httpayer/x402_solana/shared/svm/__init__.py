"""Shared Solana utilities"""
