# RNAFlow Delivery Tool

**基于 Rust 加速的高性能生物信息数据交付系统。**

专门用于将复杂的分析流程（如 Snakemake）产生的零散结果，根据配置自动整理、过滤并交付到结构化的目标目录（本地或云端对象存储）。

## 🚀 核心特性

*   **Rust 核心驱动**: 采用 Rust 编写后端 (`data_deliver_rs`)，支持多线程并发传输与 MD5 计算，性能远超纯 Python 实现。
*   **结构化重组**: 支持通过 `pattern` 匹配文件，并利用 `dest` 将其重定向或重命名。
*   **多级校验**: 
    *   **全局校验**: 根目录生成 `delivery_manifest.md5` 包含所有文件。
    *   **目录校验**: 每个交付子目录下自动生成 `MD5.txt`，仅包含该目录内的文件。
*   **智能报告**: 生成 `delivery_manifest.json`，完美对接 Quarto 报告系统。

## 🛠️ 环境准备

```bash
# 1. 编译 Rust 后端
cd src/src/data-deliver/RNAFlow_Deliver_Tool
cargo build --release

# 2. 安装扩展
cp target/release/libdata_deliver_rs.so python/RNAFlow_Deliver/data_deliver_rs.so

# 3. 设置环境变量
export PYTHONPATH=$PYTHONPATH:$(pwd)/python
```

## ⚙️ 交付模式 (`delivery_mode`)

在配置文件中，你可以通过 `delivery_mode` 指定文件的处理方式：

| 模式 | 说明 | 优点 | 缺点 |
| :--- | :--- | :--- | :--- |
| `copy` | **物理复制**。文件会被完整拷贝到目标位置。 | 交付结果完全独立，移动或删除源码不影响交付数据。 | 耗费磁盘空间，大文件传输较慢。 |
| `symlink` | **软链接 (Symbolic Link)**。目标位置仅创建一个指向源码的快捷方式。 | 极速，不占用额外磁盘空间。 | 如果源码被移动或删除，链接会失效。 |
| `hardlink` | **硬链接 (Hard Link)**。目标位置创建一个新的文件表项指向相同的物理数据。 | 极速，不占空间，删除源码后交付数据依然有效。 | 不能跨分区（跨磁盘），不支持文件夹（工具会自动对文件夹内容进行硬链）。 |

## 📖 配置文件指南 (`full_delivery_config.yaml`)

```yaml
data_delivery:
  delivery_mode: copy        # 设置交付模式 (copy, symlink, hardlink)
  output_dir: ./full_delivery
  threads: 8
  
  include_patterns:
    # 模式 1: 放入目录 (dest 以 / 结尾)
    - pattern: "02.mapping/*.bam"
      dest: "02_Mapping/BAM/"
    
    # 模式 2: 重命名文件 (dest 不以 / 结尾)
    - pattern: "01.qc/.../multiqc_fastq_screen.txt"
      dest: "Summary/fastq_screen_result.txt"
```

## 📂 交付结果示例

```text
delivery_output/
├── 01_QC/
│   ├── Reports/
│   │   ├── sample1_report.html
│   │   └── MD5.txt              <-- 本目录文件校验和
├── delivery_manifest.json       <-- 自动化报告映射表
├── delivery_manifest.md5        <-- 全局校验文件
└── ...
```

## ☁️ 云端交付 (S3/TOS)

使用 `--cloud` 参数开启云端模式（此模式下 `delivery_mode` 将失效，始终为上传模式）。
