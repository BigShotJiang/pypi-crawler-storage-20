"""
context-cache - Extended context memory for Claude Code through swap-to-disk.

Inspired by Vannevar Bush's 1945 concept of extended memory.
"""

__version__ = "1.4.18"

from context_cache.chunker import ConversationContext, Message
from context_cache.config import Config
from context_cache.embedding_cache import EmbeddingCache
from context_cache.embeddings import (
    EmbeddingProvider,
    LocalEmbeddings,
    NoEmbeddings,
    get_embedding_provider,
)
from context_cache.retriever import Retriever
from context_cache.skill import context_cacheSkill, context_cacheStatus, create_skill
from context_cache.storage import Chunk, ChunkMetadata, Storage
from context_cache.summarizer import extract_keywords, summarize_chunk
from context_cache.swapper import Swapper
from context_cache.tokens import estimate_tokens

__all__ = [
    # Core classes
    "Config",
    "Storage",
    "Chunk",
    "ChunkMetadata",
    "Swapper",
    "Retriever",
    # Skill integration
    "context_cacheSkill",
    "context_cacheStatus",
    "create_skill",
    # Chunking
    "Message",
    "ConversationContext",
    # Embeddings
    "EmbeddingProvider",
    "EmbeddingCache",
    "NoEmbeddings",
    "LocalEmbeddings",
    "get_embedding_provider",
    # Utilities
    "estimate_tokens",
    "extract_keywords",
    "summarize_chunk",
    # Version
    "__version__",
]
