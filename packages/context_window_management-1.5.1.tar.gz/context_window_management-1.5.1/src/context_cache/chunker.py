"""Conversation chunking with safe swap detection."""

import json
from dataclasses import dataclass, field
from typing import Any

from context_cache.tokens import estimate_tokens


@dataclass
class Message:
    """Represents a single message in the conversation."""

    role: str  # "user" or "assistant"
    content: str
    tool_calls: list[dict[Any, Any]] = field(default_factory=list)
    tool_results: list[dict[Any, Any]] = field(default_factory=list)


@dataclass
class ConversationContext:
    """Represents the current state of a conversation for chunking decisions."""

    messages: list[Message]
    in_code_block: bool = False
    pending_tool_calls: bool = False
    last_message_type: str | None = None

    @property
    def token_count(self) -> int:
        """Estimate total token count of all messages."""
        total = 0
        for msg in self.messages:
            total += estimate_tokens(msg.content)
        return total


def is_safe_to_swap(context: ConversationContext) -> bool:
    """Check if we're at a safe point to swap context.

    A safe swap point is when:
    - Not mid-code-block
    - No pending tool calls
    - Last message was from assistant (completed exchange)

    Args:
        context: Current conversation context

    Returns:
        True if safe to swap, False otherwise
    """
    # Not mid-code-block
    if context.in_code_block:
        return False

    # Not mid-tool-execution
    if context.pending_tool_calls:
        return False

    # Prefer after assistant completes response
    # (complete user/assistant exchange)
    return context.last_message_type == "assistant"


def detect_code_blocks(text: str) -> bool:
    """Detect if text contains unclosed code blocks.

    Args:
        text: Text to check

    Returns:
        True if there are unclosed code blocks
    """
    # Count code fence markers (```)
    fence_count = text.count("```")
    # Odd number means unclosed block
    return fence_count % 2 != 0


def find_chunk_boundary(
    messages: list[Message], target_tokens: int, overlap_tokens: int
) -> tuple[int, int]:
    """Find optimal boundary for chunking messages.

    Attempts to find a natural break point near the target token count,
    while preserving complete user/assistant exchanges and avoiding
    mid-code-block splits.

    Args:
        messages: List of messages to chunk
        target_tokens: Target token count for chunk
        overlap_tokens: Tokens to overlap between chunks

    Returns:
        Tuple of (split_index, overlap_start_index)
        split_index: Index where to split (exclusive)
        overlap_start_index: Index where overlap begins
    """
    if not messages:
        return 0, 0

    cumulative_tokens = 0
    last_safe_split = 0
    overlap_start = 0

    for i, msg in enumerate(messages):
        msg_tokens = estimate_tokens(msg.content)
        cumulative_tokens += msg_tokens

        # Check if this is a safe split point
        is_safe = True

        # Don't split if message contains unclosed code blocks
        if detect_code_blocks(msg.content):
            is_safe = False

        # Don't split if message has pending tool calls
        if msg.tool_calls and not msg.tool_results:
            is_safe = False

        # Prefer splitting after assistant messages (complete exchange)
        if msg.role == "assistant" and is_safe:
            last_safe_split = i + 1

            # Calculate overlap start
            # Work backwards from split to find overlap start
            overlap_tokens_counted = 0
            overlap_start = last_safe_split
            for j in range(last_safe_split - 1, -1, -1):
                overlap_msg_tokens = estimate_tokens(messages[j].content)
                if overlap_tokens_counted + overlap_msg_tokens <= overlap_tokens:
                    overlap_tokens_counted += overlap_msg_tokens
                    overlap_start = j
                else:
                    break

        # If we've exceeded target, return last safe split
        if cumulative_tokens >= target_tokens and last_safe_split > 0:
            return last_safe_split, overlap_start

    # If we never reached target, return end
    return len(messages), max(0, len(messages) - 1)


def chunk_messages(
    messages: list[Message],
    chunk_size: int = 2000,
    chunk_overlap: int = 200,
    preserve_recent: int = 8000,
) -> tuple[list[list[Message]], list[Message]]:
    """Split messages into chunks, preserving recent context.

    Args:
        messages: All messages to potentially chunk
        chunk_size: Target token size for each chunk
        chunk_overlap: Overlap tokens between chunks for continuity
        preserve_recent: Minimum recent tokens to always preserve

    Returns:
        Tuple of (chunks_to_swap, messages_to_keep)
        chunks_to_swap: List of message chunks that can be swapped
        messages_to_keep: Recent messages to keep in active context
    """
    if not messages:
        return [], []

    # Calculate how many tokens we need to preserve
    total_tokens = sum(estimate_tokens(msg.content) for msg in messages)

    # If total is under preserve threshold, keep everything
    if total_tokens <= preserve_recent:
        return [], messages

    # Work backwards to find preserve boundary
    preserve_tokens = 0
    preserve_start_idx = len(messages)

    for i in range(len(messages) - 1, -1, -1):
        msg_tokens = estimate_tokens(messages[i].content)
        if preserve_tokens + msg_tokens <= preserve_recent:
            preserve_tokens += msg_tokens
            preserve_start_idx = i
        else:
            break

    # Messages to chunk (everything before preserve boundary)
    messages_to_chunk = messages[:preserve_start_idx]
    messages_to_keep = messages[preserve_start_idx:]

    # If nothing to chunk, return early
    if not messages_to_chunk:
        return [], messages

    # Split messages_to_chunk into chunks
    chunks = []
    current_idx = 0

    while current_idx < len(messages_to_chunk):
        remaining = messages_to_chunk[current_idx:]
        split_idx, overlap_idx = find_chunk_boundary(remaining, chunk_size, chunk_overlap)

        # Create chunk from current_idx to split point
        chunk = remaining[:split_idx]
        chunks.append(chunk)

        # Move to next chunk, starting from overlap point
        if split_idx < len(remaining):
            # Ensure we always advance by at least 1 to avoid infinite loop
            current_idx += max(overlap_idx, 1)
        else:
            # No more messages
            break

    return chunks, messages_to_keep


def messages_to_text(messages: list[Message]) -> str:
    """Convert messages to plain text format for storage.

    Args:
        messages: List of messages

    Returns:
        Formatted text representation
    """
    lines = []
    for msg in messages:
        lines.append(f"[{msg.role.upper()}]")
        lines.append(msg.content)

        if msg.tool_calls:
            lines.append("[TOOL_CALLS]")
            lines.append(json.dumps(msg.tool_calls, indent=2))

        if msg.tool_results:
            lines.append("[TOOL_RESULTS]")
            lines.append(json.dumps(msg.tool_results, indent=2))

        lines.append("")  # Blank line between messages

    return "\n".join(lines)
