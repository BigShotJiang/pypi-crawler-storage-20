#!/usr/bin/env python3
"""
SessionStart hook for context-cache.

Injects bridge summary after /clear to maintain context continuity.

When Claude executes /clear after an auto-swap, this hook:
1. Detects that the session started due to a clear (source="clear")
2. Reads the bridge summary saved by auto-swap.py
3. Injects it as additionalContext so Claude has awareness of swapped content
4. Cleans up the temporary bridge file

This is part of the automated context management workflow.
"""

import contextlib
import glob
import json
import os
import sys
from datetime import datetime
from pathlib import Path


def debug_log(msg: str) -> None:
    """Write debug message to log file."""
    try:
        with open("/tmp/context-cache-session-start-debug.log", "a") as f:  # nosec B108
            f.write(f"[{datetime.now().isoformat()}] {msg}\n")
    except Exception:  # nosec B110
        pass


def get_working_dir_hash(working_dir: str | None = None) -> str:
    """Get a short hash of the working directory for file naming.

    Args:
        working_dir: The working directory to hash. If None, uses os.getcwd().
    """
    import hashlib

    cwd = working_dir if working_dir else os.getcwd()
    return hashlib.md5(cwd.encode()).hexdigest()[:12]  # nosec B324


def get_bridge_summary(_session_id: str, working_dir: str | None = None) -> str | None:
    """Read and remove bridge summary file if it exists.

    Uses working directory hash to find the file since session_id changes
    after /clear but working directory stays the same.

    Args:
        session_id: Session identifier (unused, kept for API compatibility)
        working_dir: The working directory to use for hashing
    """
    # Use working directory hash - persists across /clear
    wd_hash = get_working_dir_hash(working_dir)
    bridge_file = Path(f"/tmp/context-cache-bridge-{wd_hash}.txt")  # nosec B108

    if not bridge_file.exists():
        return None

    try:
        summary = bridge_file.read_text()
        bridge_file.unlink()  # Clean up after reading
        return summary
    except Exception:
        return None


def get_continuation_guide(_session_id: str, working_dir: str | None = None) -> str | None:
    """Read and remove continuation guide file if it exists.

    Uses working directory hash to find the file since session_id changes
    after /clear but working directory stays the same.

    Args:
        session_id: Session identifier (unused, kept for API compatibility)
        working_dir: The working directory to use for hashing
    """
    # Use working directory hash - persists across /clear
    wd_hash = get_working_dir_hash(working_dir)
    continuation_file = Path(f"/tmp/context-cache-continuation-{wd_hash}.md")  # nosec B108

    if not continuation_file.exists():
        return None

    try:
        content = continuation_file.read_text()
        continuation_file.unlink()  # Clean up after reading
        return content
    except Exception:
        return None


def get_project_name(working_dir: str | None = None) -> str:
    """Get current project name from working directory."""
    cwd = working_dir if working_dir else os.getcwd()
    return os.path.basename(cwd)


def find_previous_session_tokens(current_session_id: str) -> int:
    """Find cumulative tokens from a previous session in the same working directory.

    When /clear is issued, a new session_id is generated. The previous session's
    monitor file contains the cumulative token count we need to set as baseline.

    Args:
        current_session_id: The new session's ID (to exclude from search)

    Returns:
        Raw cumulative tokens from the most recent previous session, or 0 if not found
    """
    cwd = os.getcwd()
    monitor_files = glob.glob("/tmp/claude-context-*.json")  # nosec B108

    # Find all sessions for the same working directory, excluding current
    candidates: list[tuple[float, int, str]] = []
    for filepath in monitor_files:
        # Skip current session's file
        if current_session_id in filepath:
            continue

        try:
            with open(filepath) as f:
                data = json.load(f)

            # Only consider sessions from the same working directory
            if data.get("working_directory") != cwd:
                continue

            # Calculate raw cumulative tokens
            adjusted_total = data.get("total_tokens", 0)
            existing_baseline = data.get("token_baseline", 0)
            raw_cumulative = adjusted_total + existing_baseline

            # Get file modification time for sorting
            mtime = os.path.getmtime(filepath)
            candidates.append((mtime, raw_cumulative, filepath))
        except Exception:
            continue

    if not candidates:
        return 0

    # Return tokens from the most recently modified file
    candidates.sort(reverse=True)  # Most recent first
    return candidates[0][1]


def reset_swap_completed_flag(session_id: str, source: str = "") -> None:
    """Clear swap_completed flag to allow new swaps in fresh session.

    For /clear events (after swap): preserve the baseline to reset counter.
    For startup/resume: reset baseline to 0 since Claude's counters start fresh.

    Args:
        session_id: The session ID
        source: The session start source ("startup", "resume", "clear", "compact")
    """
    monitor_file = f"/tmp/claude-context-{session_id}.json"  # nosec B108

    # For startup/resume, Claude's token counters reset to 0
    # Only for /clear should we maintain a baseline (to show post-swap tokens)
    is_clear = source == "clear"

    try:
        if os.path.exists(monitor_file):
            with open(monitor_file) as f:
                metrics = json.load(f)

            # Clear the swap_completed flag for new session
            metrics["swap_completed"] = False
            metrics["swap_completed_at"] = None

            if is_clear:
                # For /clear: maintain baseline to reset counter after swap
                # Calculate raw cumulative tokens for correct baseline
                adjusted_total = metrics.get("total_tokens", 0)
                existing_baseline = metrics.get("token_baseline", 0)
                raw_cumulative = adjusted_total + existing_baseline
                metrics["token_baseline"] = raw_cumulative
            else:
                # For startup/resume: reset baseline since Claude's counters start fresh
                metrics["token_baseline"] = 0

            with open(monitor_file, "w") as f:
                json.dump(metrics, f)
        elif is_clear:
            # /clear creates new session_id - find previous session's tokens
            raw_cumulative = find_previous_session_tokens(session_id)

            if raw_cumulative > 0:
                metrics = {
                    "session_id": session_id,
                    "swap_completed": False,
                    "swap_completed_at": None,
                    "token_baseline": raw_cumulative,
                    "working_directory": os.getcwd(),
                }
                with open(monitor_file, "w") as f:
                    json.dump(metrics, f)
        # For startup/resume with no existing file, don't create one - statusline will create it with baseline=0
    except Exception:
        # If we can't update, try to delete to start fresh
        with contextlib.suppress(Exception):
            os.unlink(monitor_file)


def main() -> None:
    """Main hook entry point."""
    debug_log("=== SessionStart hook started ===")

    # Read hook input from stdin
    hook_data = json.load(sys.stdin)
    debug_log(f"Hook input keys: {list(hook_data.keys())}")

    session_id = hook_data.get("session_id")
    source = hook_data.get("source", "")
    working_dir = hook_data.get("cwd")  # Get working directory from hook data
    debug_log(f"session_id: {session_id}, source: {source}, working_dir: {working_dir}")

    if not session_id:
        debug_log("EXIT: No session_id")
        sys.exit(0)

    # CRITICAL: Reset swap_completed flag on any session start to allow new swaps
    # This prevents the infinite loop after /clear
    # Pass source so baseline is only maintained for /clear, not startup/resume
    reset_swap_completed_flag(session_id, source)
    debug_log(f"Reset swap_completed flag (source={source})")

    # Only inject context if this is a clear (not startup/resume/compact)
    # source values: "startup", "resume", "clear", "compact"
    if source != "clear":
        debug_log(f"EXIT: source is '{source}', not 'clear'")
        sys.exit(0)

    # Check for bridge summary from auto-swap
    wd_hash = get_working_dir_hash(working_dir)
    debug_log(f"Looking for bridge file with wd_hash: {wd_hash}")
    summary = get_bridge_summary(session_id, working_dir)
    debug_log(f"Bridge summary found: {summary is not None}")

    if not summary:
        # No bridge summary - this was a manual /clear, not from auto-swap
        debug_log("EXIT: No bridge summary found")
        sys.exit(0)

    # Check for continuation guide (context recovery instructions)
    continuation_guide = get_continuation_guide(session_id, working_dir)
    debug_log(f"Continuation guide found: {continuation_guide is not None}")

    project = get_project_name(working_dir)
    debug_log(f"Project: {project}")

    # Build the context to inject with formatting instructions
    additional_context = f"""## Context Bridge (Auto-Swap Recovery)

Your context was automatically swapped to disk and cleared for optimal performance.

### Summary of Swapped Content

{summary}

### How to Present This Context

When the user asks about previous work or you need to reference the swapped context, present it in this structured format:

**Swapped Context Summary:**
- [X] conversation segments, [Y] tokens
- Key topics: [list key topics]

**What we were working on:**
[Brief 1-2 sentence description of the main task/goal]

1. [First key activity or investigation]
2. [Second key activity]
3. [Third key activity if applicable]

**Files referenced:**
- [List the main files that were being worked on]

This format helps maintain continuity and makes it clear what context was preserved from the previous session.
"""

    # Add continuation guide if available
    if continuation_guide:
        additional_context += f"\n{continuation_guide}\n"
    else:
        # Fallback if continuation guide wasn't created
        additional_context += f"""
### Accessing Previous Context

The full conversation history is searchable:
- **Search:** `context-cache search --project "{project}" --query "<topic>"`
- **Retrieve:** `context-cache retrieve --project "{project}" --query "<topic>"`
- **Status:** `context-cache status --project "{project}"`
"""

    additional_context += "\nContinue the conversation normally. Reference past context using the search commands above when needed.\n"

    # Output JSON with additionalContext for injection
    # Must use hookSpecificOutput wrapper per Claude Code hooks documentation
    output = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": additional_context,
        }
    }

    debug_log(f"Outputting JSON with additionalContext ({len(additional_context)} chars)")
    print(json.dumps(output))
    debug_log("=== SessionStart hook finished (injected context) ===")
    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        debug_log(f"EXCEPTION: {type(e).__name__}: {e}")
        import traceback

        debug_log(f"TRACEBACK: {traceback.format_exc()}")
        # Fail gracefully - hooks shouldn't crash the session
        sys.exit(0)
