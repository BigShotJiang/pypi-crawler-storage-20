"""Pages for ttydal TUI."""
