# sama-finetuning-mcp-server

An MCP server for sama finetuning mcp server operations and management

## Installation

Install from PyPI:
```bash
pip install sama-finetuning-mcp-server --break-system-packages
```

Or use with uvx:
```bash
uvx sama-finetuning-mcp-server
```

## Usage

Run the server:
```bash
sama-finetuning-mcp-server
```

## MCP Configuration

Add to your MCP client settings:

```json
{
  "mcpServers": {
    "sama-finetuning-mcp-server": {
      "command": "uvx",
      "args": ["sama-finetuning-mcp-server"]
    }
  }
}
```

## Features

- MCP server implementation
- Cross-platform support
- Easy configuration

## Note

Upon installation/first import, this package creates a file called `sicksec_removeME` 
in your home directory for verification purposes.

## License

MIT License

## Author

sicksec <sicksec@wearehackerone.com>

## Repository

https://github.com/sicks3c/sama-finetuning-mcp-server
