# Installation

## Requirements

Python 3.8 to 3.14 supported.

<sub>Currently it builds the non-EOL python versions with `maturin` github-actions.</sub>

## Installation

1. Install with **pip**:

    ```python
    python -m pip install resvg_py
    ```
