#
# MIT License
#
# Copyright (c) 2025 Andrea Bonomi <andrea.bonomi@gmail.com>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

from pathlib import Path

import pytest
from fastmcp import Client

from otp_mcp import resource, server

assert resource

test_dir = Path(__file__).parent
db = test_dir / "test.db"
server.init_token_db(db)


@pytest.mark.asyncio
async def test_ping():
    async with Client(server.mcp) as client:
        # Test connection to the server
        await client.ping()
        # List available operations
        await client.list_tools()
        await client.list_resources()
        await client.list_prompts()


@pytest.mark.asyncio
async def test_list_resources():
    async with Client(server.mcp) as client:
        result = await client.read_resource("data://tokens")
        text = str(result)
        assert "inspired" in text
        assert "petroleum" in text


@pytest.mark.asyncio
async def test_list_token_types():
    async with Client(server.mcp) as client:
        result = await client.read_resource("data://token_types")
        assert isinstance(result, list)


@pytest.mark.asyncio
async def test_list_algorithms():
    async with Client(server.mcp) as client:
        result = await client.read_resource("data://algorithms")
        assert isinstance(result, list)
