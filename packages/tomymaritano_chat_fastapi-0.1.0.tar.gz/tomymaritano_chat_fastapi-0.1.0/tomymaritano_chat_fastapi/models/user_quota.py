"""
User Quota Model (Beanie ODM)
MongoDB document for tracking user quotas and rate limiting
"""

from beanie import Document
from datetime import datetime
from pydantic import Field


class UserQuotaDocument(Document):
    """
    MongoDB document for tracking user quotas.

    Collection: user_quotas
    Used for rate limiting AI chat conversations.
    """

    user_id: str = Field(..., unique=True, description="User ID (unique)")

    chat_count_today: int = Field(default=0, ge=0, description="Chat messages sent today")

    last_reset: datetime = Field(default_factory=datetime.utcnow, description="Last quota reset")

    subscription_tier: str = Field(default="free", description="Subscription tier")

    daily_limit: int = Field(
        default=10, ge=0, description="Daily limit based on subscription tier"
    )

    class Settings:
        name = "user_quotas"
        indexes = [
            "user_id",  # Unique index for fast lookups
        ]

    def increment_usage(self) -> int:
        """
        Increment chat usage by 1 and return remaining quota.

        Returns:
            Remaining quota (daily_limit - chat_count_today)
        """
        self.chat_count_today += 1
        return max(0, self.daily_limit - self.chat_count_today)

    def reset_daily_quota(self) -> None:
        """Reset daily quota (call this once per day via cron)."""
        self.chat_count_today = 0
        self.last_reset = datetime.utcnow()

    def has_quota_remaining(self) -> bool:
        """Check if user has remaining quota."""
        return self.chat_count_today < self.daily_limit

    @classmethod
    def get_limit_for_tier(cls, tier: str) -> int:
        """
        Get daily limit for a subscription tier.

        Args:
            tier: Subscription tier (free, basic, plus, pro)

        Returns:
            Daily limit
        """
        limits = {"free": 10, "basic": 50, "plus": 200, "pro": -1}  # -1 = unlimited
        return limits.get(tier, 10)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "chat_count_today": 5,
                "last_reset": "2024-01-01T00:00:00Z",
                "subscription_tier": "free",
                "daily_limit": 10,
            }
        }
