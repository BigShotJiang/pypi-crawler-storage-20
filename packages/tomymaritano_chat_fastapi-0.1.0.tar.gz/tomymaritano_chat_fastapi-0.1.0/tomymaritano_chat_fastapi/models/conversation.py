"""
Conversation Model (Beanie ODM)
MongoDB document for storing conversation history
"""

from beanie import Document
from datetime import datetime
from pydantic import Field
from typing import Any


class ConversationDocument(Document):
    """
    MongoDB document representing a conversation.

    Collection: conversations
    """

    user_id: str = Field(..., description="User ID who owns this conversation")

    messages: list[dict[str, Any]] = Field(
        default_factory=list, description="List of messages in this conversation"
    )

    created_at: datetime = Field(default_factory=datetime.utcnow, description="Creation timestamp")

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, description="Last update timestamp"
    )

    metadata: dict[str, Any] = Field(
        default_factory=dict, description="Additional conversation metadata"
    )

    class Settings:
        name = "conversations"
        indexes = [
            "user_id",  # Index for fast user lookups
            [("user_id", 1), ("updated_at", -1)],  # Compound index
        ]

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "user123",
                "messages": [
                    {
                        "id": "msg1",
                        "role": "user",
                        "content": "Hello",
                        "timestamp": "2024-01-01T12:00:00Z",
                    },
                    {
                        "id": "msg2",
                        "role": "assistant",
                        "content": "Hi! How can I help?",
                        "timestamp": "2024-01-01T12:00:01Z",
                    },
                ],
                "created_at": "2024-01-01T12:00:00Z",
                "updated_at": "2024-01-01T12:00:01Z",
                "metadata": {"source": "web", "locale": "es-AR"},
            }
        }
