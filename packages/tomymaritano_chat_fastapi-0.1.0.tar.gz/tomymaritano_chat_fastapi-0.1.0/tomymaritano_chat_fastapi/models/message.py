"""
Message Model (Beanie ODM)
MongoDB document for individual messages (alternative to storing in Conversation)
"""

from beanie import Document
from datetime import datetime
from pydantic import Field
from typing import Literal


class MessageDocument(Document):
    """
    MongoDB document representing a single message.

    Collection: messages
    Alternative to storing messages inside ConversationDocument.
    Use this if you need to query individual messages.
    """

    conversation_id: str = Field(..., description="ID of the parent conversation")

    user_id: str = Field(..., description="User ID who sent/received this message")

    role: Literal["user", "assistant"] = Field(..., description="Message role")

    content: str = Field(..., description="Message content (markdown supported)")

    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Message timestamp")

    message_type: Literal["command", "conversation", "error"] = Field(
        default="conversation", description="Type of message"
    )

    class Settings:
        name = "messages"
        indexes = [
            "conversation_id",
            "user_id",
            [("conversation_id", 1), ("timestamp", -1)],  # Get messages by conversation, sorted
        ]

    class Config:
        json_schema_extra = {
            "example": {
                "conversation_id": "conv123",
                "user_id": "user123",
                "role": "user",
                "content": "¿Cuál es el precio del dólar?",
                "timestamp": "2024-01-01T12:00:00Z",
                "message_type": "conversation",
            }
        }
