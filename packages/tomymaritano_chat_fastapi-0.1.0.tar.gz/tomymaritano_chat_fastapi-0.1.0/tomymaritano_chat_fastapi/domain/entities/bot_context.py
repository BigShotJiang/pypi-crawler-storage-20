"""
Bot Context Entity (Domain)
Encapsulates user context for command execution
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class BotContext:
    """
    Context passed to command handlers and plugins.
    Contains user information and metadata.
    """

    user_id: str
    """User ID (from JWT or auth system)"""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional metadata (request params, session data, etc.)"""

    subscription_tier: str | None = None
    """User's subscription tier (free, basic, pro, etc.)"""

    quota_remaining: int | None = None
    """Remaining quota for rate-limited features"""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dict for serialization."""
        return {
            "user_id": self.user_id,
            "metadata": self.metadata,
            "subscription_tier": self.subscription_tier,
            "quota_remaining": self.quota_remaining,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BotContext":
        """Create BotContext from dict."""
        return cls(
            user_id=data["user_id"],
            metadata=data.get("metadata", {}),
            subscription_tier=data.get("subscription_tier"),
            quota_remaining=data.get("quota_remaining"),
        )
