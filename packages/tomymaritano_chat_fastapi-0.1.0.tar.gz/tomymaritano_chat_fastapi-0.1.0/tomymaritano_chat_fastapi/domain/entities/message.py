"""
Message Entity (Domain)
Pure domain entity - zero dependencies
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Literal


@dataclass
class Message:
    """
    Domain entity representing a chat message.
    """

    id: str
    role: Literal["user", "assistant"]
    content: str
    timestamp: datetime

    def to_dict(self) -> dict:
        """Convert to dict for serialization."""
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Message":
        """Create Message from dict."""
        return cls(
            id=data["id"],
            role=data["role"],
            content=data["content"],
            timestamp=(
                datetime.fromisoformat(data["timestamp"])
                if isinstance(data["timestamp"], str)
                else data["timestamp"]
            ),
        )
