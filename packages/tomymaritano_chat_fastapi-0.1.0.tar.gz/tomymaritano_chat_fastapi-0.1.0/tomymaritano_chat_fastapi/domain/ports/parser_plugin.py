"""
Parser Plugin Port (ABC)
Plugin interface for NLP intent detection and parsing
"""

from abc import ABC, abstractmethod
from typing import Any


class ParserPluginBase(ABC):
    """
    Base class for parser plugins (NLP intent detection).

    Example:
        class AlertParserPlugin(ParserPluginBase):
            priority = 100  # Check before other parsers

            def is_intent(self, message: str) -> bool:
                keywords = ['avisame', 'alerta', 'notificame']
                return any(kw in message.lower() for kw in keywords)

            async def parse(self, message: str) -> dict:
                # Extract indicator, condition, target value
                return {
                    "intent": "create_alert",
                    "indicator": "dolar_blue",
                    "condition": "gte",
                    "target": 1600
                }
    """

    priority: int = 50  # Higher = checked first

    @abstractmethod
    def is_intent(self, message: str) -> bool:
        """
        Detect if the message matches this parser's intent.

        Args:
            message: User message to analyze

        Returns:
            True if this parser should handle the message
        """
        pass

    @abstractmethod
    async def parse(self, message: str) -> dict[str, Any]:
        """
        Parse the message and extract structured data.

        Args:
            message: User message to parse

        Returns:
            Parsed data dict with intent-specific fields.
            Common fields:
                - intent: str (e.g., "create_alert", "search_query")
                - ... (intent-specific fields)
        """
        pass

    def get_help_text(self) -> str:
        """
        Get help text explaining how to use this parser's intent.

        Returns:
            Human-readable help text
        """
        return "No help available for this intent."
