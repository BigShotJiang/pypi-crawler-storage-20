"""
Command Handler Port (ABC)
Plugin interface for handling specific commands
"""

from abc import ABC, abstractmethod
from typing import Any


class CommandHandlerBase(ABC):
    """
    Base class for command handlers (plugin system).

    Example:
        class DolarCommandHandler(CommandHandlerBase):
            def can_handle(self, command: str) -> bool:
                return command in ['dolar', 'blue', 'mep']

            async def execute(self, command: str, args: list[str], context: dict) -> dict:
                # Fetch dolar data from your services
                return {
                    "text": f"💵 Dólar Blue: $1600",
                    "message_type": "command"
                }
    """

    @abstractmethod
    def can_handle(self, command: str) -> bool:
        """
        Check if this handler can process the given command.

        Args:
            command: Command string (e.g., "dolar", "help", "status")

        Returns:
            True if this handler can process the command, False otherwise
        """
        pass

    @abstractmethod
    async def execute(
        self, command: str, args: list[str], context: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Execute the command and return a response.

        Args:
            command: The command to execute
            args: Command arguments (parsed from message)
            context: Bot context (user_id, metadata, etc.)

        Returns:
            Response dict with:
                - text: str (response message, markdown supported)
                - message_type: str ("command" | "conversation" | "error")
                - suggestions: list[dict] (optional quick actions)
        """
        pass

    def get_suggestions(self, command: str) -> list[dict[str, str]]:
        """
        Get follow-up action suggestions for this command.

        Args:
            command: The command that was executed

        Returns:
            List of quick action dicts with:
                - id: str
                - label: str
                - command: str
                - icon: str (optional)
        """
        return []

    @property
    def priority(self) -> int:
        """
        Handler priority (higher = checked first).
        Default: 50
        """
        return 50
