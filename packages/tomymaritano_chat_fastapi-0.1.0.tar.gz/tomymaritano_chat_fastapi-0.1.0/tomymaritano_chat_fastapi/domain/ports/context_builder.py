"""
Context Builder Port (ABC)
Plugin interface for building domain context for AI conversations
"""

from abc import ABC, abstractmethod
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class ContextBuilderBase(ABC, Generic[T]):
    """
    Base class for context builders (inject domain data into AI prompts).

    Example:
        class MarketContextBuilder(ContextBuilderBase[dict]):
            async def build_context(self, user_id: str, metadata: dict) -> dict:
                # Fetch latest market data
                return {
                    "dolar_blue": 1600,
                    "dolar_oficial": 900,
                    "embi": 1450,
                    "inflation": 25.5
                }

            def format_for_prompt(self, context: dict) -> str:
                return f'''
                Datos actuales del mercado argentino:
                - Dólar Blue: ${context['dolar_blue']}
                - Dólar Oficial: ${context['dolar_oficial']}
                - Riesgo País (EMBI): {context['embi']} puntos
                - Inflación mensual: {context['inflation']}%
                '''
    """

    @abstractmethod
    async def build_context(self, user_id: str, metadata: dict[str, Any]) -> T:
        """
        Build domain-specific context for the AI conversation.

        Args:
            user_id: User ID for personalized context
            metadata: Additional metadata (request params, session data, etc.)

        Returns:
            Context data (any structure you need)
        """
        pass

    @abstractmethod
    def format_for_prompt(self, context: T) -> str:
        """
        Format context data into a string for the AI system prompt.

        Args:
            context: The context data built by build_context()

        Returns:
            Formatted string to inject into the system prompt
        """
        pass

    @property
    def priority(self) -> int:
        """
        Builder priority (higher = applied first).
        Default: 50
        """
        return 50
