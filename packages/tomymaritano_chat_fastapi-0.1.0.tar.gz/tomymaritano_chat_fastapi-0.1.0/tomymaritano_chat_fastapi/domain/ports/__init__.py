"""Domain ports (interfaces/ABCs) for plugin system."""

from tomymaritano_chat_fastapi.domain.ports.command_handler import CommandHandlerBase
from tomymaritano_chat_fastapi.domain.ports.parser_plugin import ParserPluginBase
from tomymaritano_chat_fastapi.domain.ports.context_builder import ContextBuilderBase

__all__ = ["CommandHandlerBase", "ParserPluginBase", "ContextBuilderBase"]
