"""
Chat Service (Application Layer)
Main orchestrator for chat logic - coordinates plugins, OpenAI, and routing
"""

import logging
import re
from typing import Any
from tomymaritano_chat_fastapi.infrastructure.adapters.openai_adapter import (
    OpenAIAdapter,
    DefaultSystemPromptProvider,
)
from tomymaritano_chat_fastapi.infrastructure.registry.plugin_registry import PluginRegistry
from tomymaritano_chat_fastapi.domain.entities.bot_context import BotContext

logger = logging.getLogger(__name__)


class ChatService:
    """
    Main chat service orchestrator.

    Responsibilities:
    - Route messages (command, parser intent, or AI conversation)
    - Execute command handlers
    - Run parser plugins
    - Generate AI responses with context injection
    - Return formatted responses
    """

    def __init__(
        self,
        plugin_registry: PluginRegistry,
        openai_adapter: OpenAIAdapter,
        base_system_prompt: str | None = None,
    ):
        """
        Initialize chat service.

        Args:
            plugin_registry: Plugin registry with registered handlers/parsers/builders
            openai_adapter: OpenAI adapter for AI conversations
            base_system_prompt: Optional custom system prompt (uses default if None)
        """
        self.registry = plugin_registry
        self.openai = openai_adapter
        self.base_system_prompt = base_system_prompt or DefaultSystemPromptProvider.get_default_prompt()
        logger.info("ChatService initialized")

    async def process_message(
        self,
        message: str,
        user_id: str,
        conversation_history: list[dict[str, str]] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Process incoming message and return response.

        Args:
            message: User message
            user_id: User ID (from auth)
            conversation_history: Optional conversation history
            metadata: Optional additional metadata

        Returns:
            Response dict with:
                - text: str (response message)
                - message_type: str ("command" | "conversation" | "error")
                - suggestions: list[dict] (optional quick actions)
        """
        try:
            logger.info(f"Processing message for user {user_id}: {message[:50]}...")

            # Build bot context
            bot_context = BotContext(user_id=user_id, metadata=metadata or {})

            # 1. Try command routing (e.g., "/dolar", "/help")
            if self._is_command(message):
                return await self._handle_command(message, bot_context)

            # 2. Try parser plugins (e.g., alert creation, search queries)
            parser = self.registry.get_parser(message)
            if parser:
                return await self._handle_parser_intent(message, parser, bot_context)

            # 3. Default: AI conversation
            return await self._handle_ai_conversation(
                message, user_id, conversation_history, metadata or {}
            )

        except Exception as e:
            logger.error(f"Error processing message: {e}", exc_info=True)
            return {
                "text": f"❌ Error: {str(e)}",
                "message_type": "error",
                "error": {"code": "PROCESSING_ERROR", "message": str(e)},
            }

    def _is_command(self, message: str) -> bool:
        """
        Check if message is a command (starts with /).

        Args:
            message: User message

        Returns:
            True if message is a command
        """
        return message.strip().startswith("/")

    def _parse_command(self, message: str) -> tuple[str, list[str]]:
        """
        Parse command and arguments.

        Args:
            message: User message

        Returns:
            Tuple of (command, args)
            Example: "/dolar blue" -> ("dolar", ["blue"])
        """
        parts = message.strip().split()
        command = parts[0][1:].lower()  # Remove leading "/"
        args = parts[1:] if len(parts) > 1 else []
        return command, args

    async def _handle_command(self, message: str, context: BotContext) -> dict[str, Any]:
        """
        Handle command message via registered command handlers.

        Args:
            message: User message (command)
            context: Bot context

        Returns:
            Response dict
        """
        command, args = self._parse_command(message)
        logger.debug(f"Handling command: {command}, args: {args}")

        # Find handler
        handler = self.registry.get_command_handler(command)

        if not handler:
            return {
                "text": f"❓ Comando desconocido: `{command}`\n\nUsa `/help` para ver comandos disponibles.",
                "message_type": "error",
                "error": {"code": "UNKNOWN_COMMAND", "message": f"Command not found: {command}"},
            }

        # Execute handler
        try:
            result = await handler.execute(command, args, context.to_dict())

            # Add suggestions if handler provides them
            if "suggestions" not in result:
                suggestions = handler.get_suggestions(command)
                if suggestions:
                    result["suggestions"] = suggestions

            return result

        except Exception as e:
            logger.error(f"Error executing command '{command}': {e}")
            return {
                "text": f"❌ Error ejecutando comando `{command}`: {str(e)}",
                "message_type": "error",
                "error": {"code": "COMMAND_EXECUTION_ERROR", "message": str(e)},
            }

    async def _handle_parser_intent(
        self, message: str, parser: Any, context: BotContext
    ) -> dict[str, Any]:
        """
        Handle message via parser plugin (e.g., alert creation).

        Args:
            message: User message
            parser: ParserPluginBase instance
            context: Bot context

        Returns:
            Response dict
        """
        try:
            logger.debug(f"Parsing intent with {parser.__class__.__name__}")
            parsed_result = await parser.parse(message)

            # Parser should return structured data
            # Example: {"intent": "create_alert", "indicator": "dolar_blue", "target": 1600}

            # For now, return the parsed data
            # In production, you'd dispatch to an AlertService or similar
            return {
                "text": f"✅ Intención detectada: {parsed_result.get('intent', 'unknown')}\n\n"
                f"Datos extraídos:\n```json\n{parsed_result}\n```\n\n"
                f"*Nota: Conecta este parser a tu lógica de dominio*",
                "message_type": "conversation",
            }

        except Exception as e:
            logger.error(f"Error parsing intent: {e}")
            return {
                "text": f"❌ Error procesando tu solicitud: {str(e)}",
                "message_type": "error",
                "error": {"code": "PARSER_ERROR", "message": str(e)},
            }

    async def _handle_ai_conversation(
        self,
        message: str,
        user_id: str,
        conversation_history: list[dict[str, str]] | None,
        metadata: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Handle AI conversation via OpenAI.

        Args:
            message: User message
            user_id: User ID
            conversation_history: Conversation history
            metadata: Additional metadata

        Returns:
            Response dict
        """
        try:
            # Build context from all registered context builders
            context_additions = await self.registry.build_context(user_id, metadata)

            # Build complete system prompt
            system_prompt = self.openai.build_system_prompt(
                self.base_system_prompt, context_additions if context_additions else None
            )

            logger.debug(f"System prompt length: {len(system_prompt)} chars")

            # Generate AI response
            ai_response = await self.openai.generate_response(
                message, system_prompt, conversation_history
            )

            return {"text": ai_response, "message_type": "conversation"}

        except Exception as e:
            logger.error(f"Error generating AI response: {e}")
            return {
                "text": "❌ El servicio de IA está temporalmente no disponible. Por favor, intenta más tarde.",
                "message_type": "error",
                "error": {"code": "AI_SERVICE_ERROR", "message": str(e)},
            }

    def get_registry_summary(self) -> dict[str, int]:
        """Get summary of registered plugins."""
        return self.registry.summary()
