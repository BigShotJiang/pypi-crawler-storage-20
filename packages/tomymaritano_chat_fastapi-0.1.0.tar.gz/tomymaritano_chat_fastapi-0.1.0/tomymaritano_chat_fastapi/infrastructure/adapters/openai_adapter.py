"""
OpenAI Adapter (Infrastructure)
Integrates with OpenAI API for AI conversations
"""

import logging
from openai import AsyncOpenAI
from typing import Any

logger = logging.getLogger(__name__)


class OpenAIAdapter:
    """
    Adapter for OpenAI API integration.
    Handles AI conversation generation with context injection.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        max_tokens: int = 500,
        temperature: float = 0.7,
    ):
        """
        Initialize OpenAI adapter.

        Args:
            api_key: OpenAI API key
            model: Model to use (gpt-4o-mini, gpt-4, etc.)
            max_tokens: Maximum tokens in response
            temperature: Sampling temperature (0-2)
        """
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        logger.info(f"OpenAI adapter initialized with model: {model}")

    async def generate_response(
        self,
        message: str,
        system_prompt: str,
        conversation_history: list[dict[str, str]] | None = None,
    ) -> str:
        """
        Generate AI response using OpenAI API.

        Args:
            message: User message
            system_prompt: System prompt with context injection
            conversation_history: Optional conversation history (last N messages)

        Returns:
            AI response text

        Raises:
            Exception: If OpenAI API call fails
        """
        try:
            messages: list[dict[str, str]] = [{"role": "system", "content": system_prompt}]

            # Add conversation history (if provided)
            if conversation_history:
                # Limit to last 10 messages to avoid token limits
                for msg in conversation_history[-10:]:
                    messages.append({"role": msg["role"], "content": msg["content"]})

            # Add current user message
            messages.append({"role": "user", "content": message})

            logger.debug(f"OpenAI request: {len(messages)} messages, model={self.model}")

            # Call OpenAI API
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
            )

            # Extract response text
            response_text = response.choices[0].message.content or ""

            logger.info(
                f"OpenAI response generated: {len(response_text)} chars, "
                f"tokens_used={response.usage.total_tokens if response.usage else 'unknown'}"
            )

            return response_text

        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            raise Exception(f"AI service temporarily unavailable: {str(e)}")

    async def is_available(self) -> bool:
        """
        Check if OpenAI API is available.

        Returns:
            True if API is reachable, False otherwise
        """
        try:
            # Simple test call
            await self.client.models.list()
            return True
        except Exception as e:
            logger.warning(f"OpenAI availability check failed: {e}")
            return False

    def build_system_prompt(
        self, base_prompt: str, context_additions: list[str] | None = None
    ) -> str:
        """
        Build system prompt with optional context additions.

        Args:
            base_prompt: Base system prompt
            context_additions: Optional context strings to append (from ContextBuilders)

        Returns:
            Complete system prompt
        """
        prompt_parts = [base_prompt]

        if context_additions:
            prompt_parts.extend(context_additions)

        return "\n\n".join(prompt_parts)


class DefaultSystemPromptProvider:
    """
    Provides default system prompt for AI conversations.
    Users can override this with their own prompts.
    """

    @staticmethod
    def get_default_prompt(language: str = "es") -> str:
        """
        Get default system prompt.

        Args:
            language: Language code (es, en, etc.)

        Returns:
            Default system prompt
        """
        prompts = {
            "es": """Eres un asistente conversacional experto y amigable.
Proporcionas respuestas claras, concisas y útiles.
Respondes en español con un tono profesional pero cercano.
Si no sabes algo, lo admites honestamente.""",
            "en": """You are an expert and friendly conversational assistant.
You provide clear, concise, and helpful responses.
You respond in English with a professional but approachable tone.
If you don't know something, you admit it honestly.""",
        }

        return prompts.get(language, prompts["en"])
