"""
Plugin Registry (Infrastructure)
DI Container for managing plugins (CommandHandlers, ParserPlugins, ContextBuilders)
"""

import logging
from typing import Any
from tomymaritano_chat_fastapi.domain.ports.command_handler import CommandHandlerBase
from tomymaritano_chat_fastapi.domain.ports.parser_plugin import ParserPluginBase
from tomymaritano_chat_fastapi.domain.ports.context_builder import ContextBuilderBase

logger = logging.getLogger(__name__)


class PluginRegistry:
    """
    Dependency injection container for plugins.
    Manages registration and retrieval of plugins with priority-based ordering.
    """

    def __init__(self) -> None:
        """Initialize empty plugin registry."""
        self._command_handlers: list[CommandHandlerBase] = []
        self._parsers: list[ParserPluginBase] = []
        self._context_builders: list[ContextBuilderBase] = []

    def register_command_handler(self, handler: CommandHandlerBase) -> None:
        """
        Register a command handler.

        Args:
            handler: CommandHandlerBase instance
        """
        self._command_handlers.append(handler)
        logger.info(f"Registered command handler: {handler.__class__.__name__}")

    def register_command_handlers(self, handlers: list[CommandHandlerBase]) -> None:
        """
        Register multiple command handlers at once.

        Args:
            handlers: List of CommandHandlerBase instances
        """
        for handler in handlers:
            self.register_command_handler(handler)

    def register_parser(self, parser: ParserPluginBase) -> None:
        """
        Register a parser plugin.

        Args:
            parser: ParserPluginBase instance
        """
        self._parsers.append(parser)
        # Sort parsers by priority (higher first)
        self._parsers.sort(key=lambda p: p.priority, reverse=True)
        logger.info(
            f"Registered parser: {parser.__class__.__name__} (priority={parser.priority})"
        )

    def register_parsers(self, parsers: list[ParserPluginBase]) -> None:
        """
        Register multiple parser plugins at once.

        Args:
            parsers: List of ParserPluginBase instances
        """
        for parser in parsers:
            self.register_parser(parser)

    def register_context_builder(self, builder: ContextBuilderBase) -> None:
        """
        Register a context builder.

        Args:
            builder: ContextBuilderBase instance
        """
        self._context_builders.append(builder)
        # Sort builders by priority (higher first)
        self._context_builders.sort(key=lambda b: b.priority, reverse=True)
        logger.info(
            f"Registered context builder: {builder.__class__.__name__} (priority={builder.priority})"
        )

    def register_context_builders(self, builders: list[ContextBuilderBase]) -> None:
        """
        Register multiple context builders at once.

        Args:
            builders: List of ContextBuilderBase instances
        """
        for builder in builders:
            self.register_context_builder(builder)

    def get_command_handler(self, command: str) -> CommandHandlerBase | None:
        """
        Find a command handler that can handle the given command.

        Args:
            command: Command string to handle

        Returns:
            CommandHandlerBase instance or None if no handler found
        """
        # Sort by priority and check each handler
        sorted_handlers = sorted(self._command_handlers, key=lambda h: h.priority, reverse=True)

        for handler in sorted_handlers:
            if handler.can_handle(command):
                logger.debug(f"Command '{command}' handled by {handler.__class__.__name__}")
                return handler

        logger.debug(f"No handler found for command: {command}")
        return None

    def get_parser(self, message: str) -> ParserPluginBase | None:
        """
        Find a parser that matches the message intent.

        Args:
            message: User message to parse

        Returns:
            ParserPluginBase instance or None if no parser matches
        """
        # Parsers are already sorted by priority
        for parser in self._parsers:
            if parser.is_intent(message):
                logger.debug(f"Message matched parser: {parser.__class__.__name__}")
                return parser

        logger.debug("No parser matched message intent")
        return None

    async def build_context(self, user_id: str, metadata: dict[str, Any]) -> list[str]:
        """
        Build context using all registered context builders.

        Args:
            user_id: User ID
            metadata: Additional metadata

        Returns:
            List of formatted context strings (one per builder)
        """
        context_strings: list[str] = []

        # Builders are already sorted by priority
        for builder in self._context_builders:
            try:
                context_data = await builder.build_context(user_id, metadata)
                formatted = builder.format_for_prompt(context_data)
                context_strings.append(formatted)
                logger.debug(f"Built context with {builder.__class__.__name__}")
            except Exception as e:
                logger.error(f"Error building context with {builder.__class__.__name__}: {e}")
                # Continue with other builders even if one fails

        return context_strings

    def get_all_command_handlers(self) -> list[CommandHandlerBase]:
        """Get all registered command handlers."""
        return self._command_handlers.copy()

    def get_all_parsers(self) -> list[ParserPluginBase]:
        """Get all registered parsers."""
        return self._parsers.copy()

    def get_all_context_builders(self) -> list[ContextBuilderBase]:
        """Get all registered context builders."""
        return self._context_builders.copy()

    def summary(self) -> dict[str, int]:
        """
        Get summary of registered plugins.

        Returns:
            Dict with counts of each plugin type
        """
        return {
            "command_handlers": len(self._command_handlers),
            "parsers": len(self._parsers),
            "context_builders": len(self._context_builders),
        }
