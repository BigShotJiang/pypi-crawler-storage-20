"""
tomymaritano-chat-fastapi
FastAPI backend SDK for conversational AI chatbots

Author: Tomy Maritano
License: MIT
"""

__version__ = "0.1.0"

# Main factory function
from tomymaritano_chat_fastapi.api.factory import create_chat_router

# Base classes for plugins
from tomymaritano_chat_fastapi.domain.ports.command_handler import CommandHandlerBase
from tomymaritano_chat_fastapi.domain.ports.parser_plugin import ParserPluginBase
from tomymaritano_chat_fastapi.domain.ports.context_builder import ContextBuilderBase

# Pydantic schemas
from tomymaritano_chat_fastapi.api.schemas.chat_request import ChatRequest
from tomymaritano_chat_fastapi.api.schemas.chat_response import ChatResponse, BotMessage

# Beanie models
from tomymaritano_chat_fastapi.models.conversation import ConversationDocument
from tomymaritano_chat_fastapi.models.message import MessageDocument
from tomymaritano_chat_fastapi.models.user_quota import UserQuotaDocument

__all__ = [
    # Factory
    "create_chat_router",
    # Plugin base classes
    "CommandHandlerBase",
    "ParserPluginBase",
    "ContextBuilderBase",
    # Schemas
    "ChatRequest",
    "ChatResponse",
    "BotMessage",
    # Models
    "ConversationDocument",
    "MessageDocument",
    "UserQuotaDocument",
]
