"""
Chat Request Schema (Pydantic)
Validates incoming POST /api/chat requests
"""

from pydantic import BaseModel, Field
from typing import Any


class ChatMessageSchema(BaseModel):
    """Single chat message in history."""

    id: str
    role: str = Field(..., pattern="^(user|assistant)$")
    content: str
    timestamp: int  # Unix timestamp in milliseconds


class ChatRequest(BaseModel):
    """
    Request schema for POST /api/chat endpoint.

    Example:
        {
            "message": "¿Cuál es el precio del dólar blue?",
            "context": {"source": "web"},
            "conversation_history": [...]
        }
    """

    message: str = Field(
        ..., min_length=1, max_length=1000, description="User message (1-1000 characters)"
    )

    context: dict[str, Any] | None = Field(
        None, description="Optional market/domain context data"
    )

    conversation_history: list[ChatMessageSchema] | None = Field(
        None, max_length=10, description="Optional conversation history (last N messages)"
    )

    class Config:
        json_schema_extra = {
            "example": {
                "message": "¿Cuál es el precio del dólar blue?",
                "context": {"source": "web", "user_location": "AR"},
                "conversation_history": [
                    {
                        "id": "1",
                        "role": "user",
                        "content": "Hola",
                        "timestamp": 1704067200000,
                    },
                    {
                        "id": "2",
                        "role": "assistant",
                        "content": "¡Hola! ¿En qué puedo ayudarte?",
                        "timestamp": 1704067201000,
                    },
                ],
            }
        }
