"""
Chat Response Schemas (Pydantic)
Response models for POST /api/chat endpoint
"""

from pydantic import BaseModel, Field
from typing import Literal


class QuickActionSchema(BaseModel):
    """Quick action button suggestion."""

    id: str
    label: str = Field(..., max_length=50)
    command: str
    icon: str | None = None


class ErrorDetail(BaseModel):
    """Error details for error responses."""

    code: str = Field(..., description="Error code (e.g., AUTH_REQUIRED, QUOTA_EXCEEDED)")
    message: str = Field(..., description="Human-readable error message")


class BotMessage(BaseModel):
    """
    Legacy bot message format (for backwards compatibility).
    Use ChatResponse instead for new code.
    """

    text: str
    format: Literal["text", "markdown"] = "markdown"
    buttons: list[QuickActionSchema] | None = None


class ChatResponse(BaseModel):
    """
    Response schema for POST /api/chat endpoint.

    Example:
        {
            "text": "💵 **Dólar Blue**: $1600",
            "message_type": "command",
            "suggestions": [...],
            "quota_remaining": 95
        }
    """

    text: str = Field(..., description="Bot response (markdown supported)")

    message_type: Literal["command", "conversation", "error"] = Field(
        ..., description="Type of response"
    )

    suggestions: list[QuickActionSchema] | None = Field(
        None, description="Optional follow-up action suggestions"
    )

    quota_remaining: int | None = Field(
        None, ge=0, description="Remaining quota for rate-limited features"
    )

    error: ErrorDetail | None = Field(None, description="Error details (if message_type=error)")

    class Config:
        json_schema_extra = {
            "examples": [
                {
                    "text": "💵 **Dólar Blue**: $1,600\n\n*Última actualización: hace 5 minutos*",
                    "message_type": "command",
                    "suggestions": [
                        {
                            "id": "1",
                            "label": "Ver dólar oficial",
                            "command": "/oficial",
                            "icon": "💵",
                        },
                        {"id": "2", "label": "Ver MEP", "command": "/mep", "icon": "📊"},
                    ],
                    "quota_remaining": 95,
                },
                {
                    "text": "¡Hola! Soy tu asistente financiero. ¿En qué puedo ayudarte hoy?",
                    "message_type": "conversation",
                    "quota_remaining": 94,
                },
                {
                    "text": "No tienes suficiente cuota para esta acción.",
                    "message_type": "error",
                    "error": {"code": "QUOTA_EXCEEDED", "message": "Daily limit reached"},
                    "quota_remaining": 0,
                },
            ]
        }
