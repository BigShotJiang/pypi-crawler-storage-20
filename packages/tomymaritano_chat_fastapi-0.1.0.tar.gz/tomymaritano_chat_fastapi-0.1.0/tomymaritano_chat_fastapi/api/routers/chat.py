"""
Chat Router (FastAPI)
Defines POST /api/chat endpoint
"""

import logging
from fastapi import APIRouter, HTTPException, Depends
from tomymaritano_chat_fastapi.api.schemas.chat_request import ChatRequest
from tomymaritano_chat_fastapi.api.schemas.chat_response import ChatResponse
from tomymaritano_chat_fastapi.application.chat_service import ChatService

logger = logging.getLogger(__name__)


def create_chat_router_internal(
    chat_service: ChatService,
    require_auth: bool = False,
    enable_rate_limiting: bool = False,
) -> APIRouter:
    """
    Create FastAPI router for chat endpoints.

    Args:
        chat_service: Configured ChatService instance
        require_auth: Whether to require JWT authentication
        enable_rate_limiting: Whether to enable rate limiting

    Returns:
        Configured APIRouter
    """
    router = APIRouter(tags=["chat"])

    @router.post("", response_model=ChatResponse, status_code=200)
    async def chat_endpoint(request: ChatRequest) -> ChatResponse:
        """
        Process chat message and return response.

        Request body:
            - message: User message (1-1000 chars)
            - context: Optional domain context
            - conversation_history: Optional message history

        Returns:
            ChatResponse with bot reply
        """
        try:
            logger.info(f"Chat request received: {request.message[:50]}...")

            # For now, use anonymous user
            # TODO: Add auth dependency to get real user_id
            user_id = "anonymous"

            # Build conversation history for OpenAI
            history = None
            if request.conversation_history:
                history = [
                    {"role": msg.role, "content": msg.content}
                    for msg in request.conversation_history
                ]

            # Process message via ChatService
            result = await chat_service.process_message(
                message=request.message,
                user_id=user_id,
                conversation_history=history,
                metadata=request.context or {},
            )

            # Build response
            return ChatResponse(
                text=result["text"],
                message_type=result["message_type"],
                suggestions=result.get("suggestions"),
                quota_remaining=result.get("quota_remaining"),
                error=result.get("error"),
            )

        except Exception as e:
            logger.error(f"Chat endpoint error: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=str(e))

    @router.get("/health", status_code=200)
    async def health_check() -> dict:
        """Health check endpoint."""
        summary = chat_service.get_registry_summary()
        return {
            "status": "healthy",
            "service": "tomymaritano-chat-fastapi",
            "plugins": summary,
        }

    return router
