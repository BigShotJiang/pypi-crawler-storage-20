"""
Factory Function (API Layer)
Main entry point - creates configured chat router
"""

import logging
from fastapi import APIRouter
from typing import Any
from tomymaritano_chat_fastapi.application.chat_service import ChatService
from tomymaritano_chat_fastapi.infrastructure.adapters.openai_adapter import OpenAIAdapter
from tomymaritano_chat_fastapi.infrastructure.registry.plugin_registry import PluginRegistry
from tomymaritano_chat_fastapi.domain.ports.command_handler import CommandHandlerBase
from tomymaritano_chat_fastapi.domain.ports.parser_plugin import ParserPluginBase
from tomymaritano_chat_fastapi.domain.ports.context_builder import ContextBuilderBase
from tomymaritano_chat_fastapi.api.routers.chat import create_chat_router_internal

# Setup logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def create_chat_router(
    # OpenAI Configuration (required)
    openai_api_key: str,
    openai_model: str = "gpt-4o-mini",
    openai_max_tokens: int = 500,
    openai_temperature: float = 0.7,
    # Database Configuration (optional for now)
    mongodb_url: str | None = None,
    # Auth Configuration (optional)
    jwt_secret: str | None = None,
    jwt_algorithm: str = "HS256",
    require_auth: bool = False,
    # Plugins (optional)
    command_handlers: list[CommandHandlerBase] | None = None,
    parsers: list[ParserPluginBase] | None = None,
    context_builders: list[ContextBuilderBase] | None = None,
    # System Prompt (optional)
    base_system_prompt: str | None = None,
    # Rate Limiting (optional)
    enable_rate_limiting: bool = False,
    # CORS (optional)
    cors_origins: list[str] | None = None,
    # Celery (optional)
    celery_broker_url: str | None = None,
) -> APIRouter:
    """
    Create configured FastAPI router for chat endpoints.

    This is the main entry point for the SDK. Call this function to get a
    fully configured router that you can mount in your FastAPI app.

    Example:
        ```python
        from fastapi import FastAPI
        from tomymaritano_chat_fastapi import create_chat_router

        app = FastAPI()

        chat_router = create_chat_router(
            openai_api_key="sk-...",
            mongodb_url="mongodb://localhost:27017"
        )

        app.include_router(chat_router, prefix="/api/chat")
        ```

    Args:
        openai_api_key: OpenAI API key (required)
        openai_model: OpenAI model to use (default: gpt-4o-mini)
        openai_max_tokens: Max tokens in response (default: 500)
        openai_temperature: Sampling temperature (default: 0.7)
        mongodb_url: MongoDB connection URL (optional)
        jwt_secret: JWT secret key for auth (optional)
        jwt_algorithm: JWT algorithm (default: HS256)
        require_auth: Require JWT auth for all requests (default: False)
        command_handlers: List of CommandHandler plugins (optional)
        parsers: List of Parser plugins (optional)
        context_builders: List of ContextBuilder plugins (optional)
        base_system_prompt: Custom system prompt (optional)
        enable_rate_limiting: Enable rate limiting (default: False)
        cors_origins: Allowed CORS origins (optional)
        celery_broker_url: Celery broker URL (optional)

    Returns:
        Configured FastAPI APIRouter ready to mount

    Raises:
        ValueError: If required parameters are missing
    """
    logger.info("Initializing tomymaritano-chat-fastapi...")

    # Validate required params
    if not openai_api_key:
        raise ValueError("openai_api_key is required")

    # 1. Create OpenAI adapter
    logger.info(f"Initializing OpenAI adapter (model={openai_model})...")
    openai_adapter = OpenAIAdapter(
        api_key=openai_api_key,
        model=openai_model,
        max_tokens=openai_max_tokens,
        temperature=openai_temperature,
    )

    # 2. Create plugin registry
    logger.info("Initializing plugin registry...")
    registry = PluginRegistry()

    # Register plugins
    if command_handlers:
        registry.register_command_handlers(command_handlers)
        logger.info(f"Registered {len(command_handlers)} command handlers")

    if parsers:
        registry.register_parsers(parsers)
        logger.info(f"Registered {len(parsers)} parser plugins")

    if context_builders:
        registry.register_context_builders(context_builders)
        logger.info(f"Registered {len(context_builders)} context builders")

    # Log summary
    summary = registry.summary()
    logger.info(f"Plugin registry summary: {summary}")

    # 3. Create chat service
    logger.info("Initializing chat service...")
    chat_service = ChatService(
        plugin_registry=registry,
        openai_adapter=openai_adapter,
        base_system_prompt=base_system_prompt,
    )

    # 4. Create FastAPI router
    logger.info("Creating FastAPI router...")
    router = create_chat_router_internal(
        chat_service=chat_service, require_auth=require_auth, enable_rate_limiting=enable_rate_limiting
    )

    # TODO: Initialize MongoDB connection if provided
    if mongodb_url:
        logger.info(f"MongoDB URL provided: {mongodb_url}")
        logger.warning("MongoDB integration not yet implemented - coming soon!")

    # TODO: Setup JWT auth if provided
    if jwt_secret and require_auth:
        logger.info("JWT auth enabled")
        logger.warning("JWT auth not yet implemented - coming soon!")

    # TODO: Setup rate limiting if enabled
    if enable_rate_limiting:
        logger.info("Rate limiting enabled")
        logger.warning("Rate limiting not yet implemented - coming soon!")

    # TODO: Setup CORS if provided
    if cors_origins:
        logger.info(f"CORS origins: {cors_origins}")
        logger.warning("CORS setup should be done at app level, not router level")

    # TODO: Setup Celery if provided
    if celery_broker_url:
        logger.info(f"Celery broker URL provided: {celery_broker_url}")
        logger.warning("Celery integration not yet implemented - coming soon!")

    logger.info("✅ Chat router created successfully!")
    logger.info("Endpoint available: POST /chat")
    logger.info("Health check available: GET /health")

    return router
