# MCP Tool Specification

This document defines **each MCP tool**, its purpose, and what it should return
to naturally guide the LLM into the correct next action.

The MCP server enforces workflow through **tool outputs**, not just documentation.

---

## Tool 1: ranked_solutions
Purpose

Search incidents, gather all candidate solutions, and rank them using environment similarity plus reliability and recency from solution_env_stats.

When to use

- **Always the first tool** for any new issue/error (start here before adding incidents/solutions)

Input

- query_text (string)
- env (object, required) — environment context used for bucket canonicalization and matching
- limit (optional int) — number of solutions to return (default 5)

### env object (required)

Provide a small, consistent environment fingerprint. Known keys (optional, but recommended when applicable):

- os_family (string): e.g. windows | macos | linux
- language (string): e.g. python | node | go | java
- language_major (number|null): e.g. 3 for Python 3, 20 for Node 20
- framework (string): e.g. nextjs | django | fastapi | react
- framework_major (number|null): e.g. 14 for Next.js 14
- runtime (string): e.g. local | docker | kubernetes | github-actions | lambda
- cuda_major (number|null): e.g. 12 (or null if not applicable)

Example:

```json
{
  "os_family": "windows",
  "language": "python",
  "language_major": 3,
  "framework": "fastapi",
  "framework_major": 0,
  "runtime": "local",
  "cuda_major": null
}
```

Returns

- lookup_id (string)
- incidents (array of matches from incident search)
- ranked_solutions (array, sorted by final_score)
  - best_env_bucket_match
  - env_match_score
  - reliability_score
  - recency_boost
  - final_solution_score
- recommended_solution (top-ranked solution)
- next_action (object)

### next_action behavior (all cases)

**Case: no incident matches**

```json
{
  "type": "NO_MATCH_DEBUG_THEN_ADD_INCIDENT",
  "instructions": "No relevant incidents found. Debug normally. Only call add_incident after you have a verified fix that works. If you cannot find a working fix, do not create an incident. Never add a solution you only think is likely—always verify first."
}
```

**Case: incidents found, but none have solutions**

```json
{
  "type": "NO_SOLUTIONS_ADD_ONE",
  "instructions": "Incidents were found but no solutions exist. Debug normally. Once you find a fix that works, call add_solution for the best matching incident, then record_outcome."
}
```

**Case: solutions ranked successfully**

```json
{
  "type": "TRY_SOLUTION_AND_RECORD_OUTCOME",
  "instructions": "Try the recommended solution. After attempting it, call record_outcome with worked=true or false."
}
```

---

Tool 2: record_outcome
Purpose

Record whether a solution worked or failed.

When to use

Only after `ranked_solutions` recommends a solution and you attempted it — record worked=true/false every time you try one

Input

lookup_id (optional)

solution_id

worked (boolean)

env (object)

env_bucket (optional)

notes (optional)

Returns

ok (boolean)

updated solution stats

next_action (object)

### next_action behavior (all cases)

**Case: worked = true**

```json
{
  "type": "DONE_OR_ADD_ENV_VARIANT",
  "instructions": "Done. If this fix works in another environment, add_solution to the same incident and then record_outcome."
}
```


**Case: worked = false**

```json
{
  "type": "DEBUG_FURTHER_THEN_ADD_SOLUTION_OR_INCIDENT",
  "instructions": "Debug further. If you find a new fix for the same incident, call add_solution (then record_outcome). If the root cause is different, call add_incident to create a new incident."
}
```

Tool 3: add_solution
Purpose

Add a new fix for an existing incident (including env-specific variants). This stores the proposed fix steps; evidence is added later via record_outcome.

When to use

- Same incident, new fix
- Same incident, new environment variant (even if steps are the same)

Input

- incident_id (required)
- steps (required)
- env (required)
- env_bucket (optional)
- lookup_id (optional)

Returns

- solution_id
- env_bucket
- next_action

### next_action behavior (all cases)

**Case: solution created**

```json
{
  "type": "RECORD_OUTCOME_FOR_NEW_SOLUTION",
  "instructions": "If you try this solution, call record_outcome with solution_id, worked, and env."
}
```

Tool 4: add_incident
Purpose

Create a new incident + solution + outcome. If the incident already exists, use add_solution instead.

When to use

- No matching incident exists **and you have a fix you verified works** (create new incident)
- Do **not** call `add_incident` for speculative guesses or “likely fixes” you haven’t validated

Input

title (required)

error_signature

summary

tags (optional)

lookup_id (optional)

steps (required)

env (required)

env_bucket (optional)

worked (required boolean)

notes (optional)

Returns

incident_id

solution_id

outcome_id (if returned by API)

next_action

### next_action behavior (all cases)

**Case: an incident already exists (duplicate guard triggers)**

```json
{
  "type": "USE_ADD_SOLUTION_FOR_EXISTING_INCIDENT",
  "instructions": "An incident already exists. Use add_solution with this incident_id, then record_outcome after you try it."
}
```

**Case: incident + solution + outcome created AND worked = true**

```json
{
  "type": "DONE_OR_ADD_ENV_VARIANT",
  "instructions": "Done. If this fix works in another environment, add_solution to the same incident and then record_outcome."
}
```

**Case: incident + solution + outcome created AND worked = false**

```json
{
  "type": "DEBUG_FURTHER_THEN_ADD_SOLUTION_OR_INCIDENT",
  "instructions": "Debug further. If you find a new fix for the same incident, call add_solution (then record_outcome). If the root cause is different, call add_incident to create a new incident."
}
```

---

Design Principles

Tools represent intent, not database operations

Tool outputs always suggest the next step

LLMs are guided, not trusted blindly

Evidence (outcomes) drives confidence

Summary

ranked_solutions → pick best solution

record_outcome → learn from evidence

add_solution → store a new proposed fix under an existing incident

add_incident → learn a new incident (creates incident + solution + outcome)

This keeps debug memory accurate and useful over time.