from setuptools import setup, find_packages

setup(
    name="kdrob",              # PyPI name
    version="0.1",
    author="Kalpesh Deshmukh",
    author_email="your_email@gmail.com",
    description="Robotics calculation library",
    packages=["kdrob"],        # folder name of your package
    install_requires=[],
)
