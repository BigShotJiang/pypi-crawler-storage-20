# printrgb

Print text in rainbow colors .

```python
pip install printrgb
python -c "from printrgb import printrgb; printrgb('Hello, world!', rainbow=True)"
```
