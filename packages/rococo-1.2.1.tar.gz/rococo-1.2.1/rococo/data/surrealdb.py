import logging
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import UUID
from surrealdb import Surreal

from rococo.data.base import DbAdapter


class SurrealDbAdapter(DbAdapter):
    """SurrealDB adapter for interacting with SurrealDB."""

    def __init__(
        self, endpoint: str, username: str, password: str, namespace: str, db_name: str
    ):
        """Initializes a new SurrealDB adapter."""
        self._endpoint = endpoint
        self._username = username
        self._password = password
        self._namespace = namespace
        self._db_name = db_name
        self._db = None

    def __enter__(self):
        """Context manager entry point for preparing DB connection."""
        self._db = self._prepare_db()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """Context manager exit point for closing DB connection."""
        if self._db:
            self._db.close()
        self._db = None

    def _prepare_db(self):
        """Prepares the DB connection."""
        db = Surreal(self._endpoint)
        db.signin({"username": self._username, "password": self._password})
        db.use(self._namespace, self._db_name)
        return db

    def _call_db(self, function_name, *args, **kwargs):
        """Calls a function specified by function_name argument in SurrealDB connection passing forward args and kwargs."""
        if not self._db:
            raise Exception("No connection to SurrealDB.")
        return getattr(self._db, function_name)(*args, **kwargs)

    def _build_condition_string(self, key, value):
        if isinstance(value, str):
            # If the string contains backticks, it's a record ID reference - don't add quotes
            if '`' in value:
                return f"{key}={value}"
            return f"{key}='{value}'"
        elif isinstance(value, bool):
            return f"{key}={'true' if value is True else 'false'}"
        elif type(value) in [int, float]:
            return f"{key}={value}"
        elif isinstance(value, list):
            return f"""{key} IN [{','.join(f'"{v}"' for v in value)}]"""
        elif isinstance(value, UUID):
            return f"{key}='{str(value)}'"
        else:
            raise Exception(
                f"Unsuppported type {type(value)} for condition key: {key}, value: {value}")

    def run_transaction(self, operations_list: List[Any]):
        """Executes a list of operations against the database as a transaction."""
        # TODO: Update this method when SurrealDB Python SDK supports transactions.
        for operation in operations_list:
            self._call_db(*operation)

    def get_move_entity_to_audit_table_query(self, table, entity_id):
        """Returns the operation to move entity to an audit table."""
        return ('query', f'INSERT INTO {table}_audit (SELECT *, "{entity_id}" AS entity_id, rand::uuid::v4() AS id FROM {table} WHERE id={table}:`{entity_id}`)')

    def move_entity_to_audit_table(self, table, entity_id):
        """Executes a query to move entity to audit table."""
        move_entity_op = self.get_move_entity_to_audit_table_query(
            table, entity_id)
        self._call_db(*move_entity_op)

    def execute_query(self, sql, _vars=None):
        """Executes a query against the DB."""
        if _vars is None:
            _vars = {}

        return self._call_db('query', sql, _vars)

    def parse_db_response(self, response: List[Dict[str, Any]]) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """
        Parse the response from SurrealDB.

        The blocking SDK returns results directly as a list of dictionaries.
        If the list has one item, return that item.
        If the list has multiple items, return the list.
        If the list is empty, return an empty list.
        """
        if not response or not isinstance(response, list):
            return []

        # Blocking SDK returns results directly, not wrapped in {'result': [...]}
        if len(response) == 1:
            return response[0]
        return response

    def get_one(
        self,
        table: str,
        conditions: Dict[str, Any],
        sort: List[Tuple[str, str]] = None,
        fetch_related: list = None,
        additional_fields: list = None,
        active: bool = True
    ) -> Dict[str, Any]:
        fields = ['*']
        if additional_fields:
            fields += additional_fields

        query = f"SELECT {', '.join(fields)} FROM {table}"

        condition_strs = []
        if conditions:
            condition_strs = [
                f"{self._build_condition_string(k, v)}" for k, v in conditions.items()]
        if active:
            condition_strs.append("active=true")
        query += f" WHERE {' AND '.join(condition_strs)}"

        if sort:
            sort_strs = [f"{column} {direction}" for column, direction in sort]
            query += f" ORDER BY {', '.join(sort_strs)}"
        query += " LIMIT 1"

        if fetch_related:
            query += f" FETCH {', '.join(field for field in fetch_related)}"

        db_response = self.parse_db_response(self.execute_query(query))

        return db_response

    def get_many(
        self,
        table: str,
        conditions: Dict[str, Any] = None,
        sort: List[Tuple[str, str]] = None,
        limit: int = 100,
        active: bool = True,
        fetch_related: list = None,
        additional_fields: list = None
    ) -> List[Dict[str, Any]]:

        fields = ['*']
        if additional_fields:
            fields += additional_fields

        query = f"SELECT {', '.join(fields)} FROM {table}"

        condition_strs = []
        if conditions:
            condition_strs = [
                f"{self._build_condition_string(k, v)}" for k, v in conditions.items()]
        if active:
            condition_strs.append("active=true")
        if condition_strs:
            query += f" WHERE {' AND '.join(condition_strs)}"
        if sort:
            sort_strs = [f"{column} {direction}" for column, direction in sort]
            query += f" ORDER BY {', '.join(sort_strs)}"
        query += f" LIMIT {int(limit)}"

        if fetch_related:
            query += f" FETCH {', '.join(field for field in fetch_related)}"

        db_response = self.parse_db_response(self.execute_query(query))

        return db_response

    def get_count(
        self,
        table: str,
        conditions: Dict[str, Any],
        options: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Count records in `table` matching `conditions`.
        The optional 'options' dict is supported for interface compatibility
        (e.g. a 'hint' key), but SurrealDB COUNT() doesn’t take hints here.
        """
        # Build WHERE clauses from the conditions dict
        where_clauses: List[str] = []
        if conditions:
            for key, val in conditions.items():
                where_clauses.append(self._build_condition_string(key, val))

        where_sql = f" WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
        sql = f"SELECT COUNT() AS count FROM {table}{where_sql}"

        # If someone passed a 'hint', just log it
        if options and 'hint' in options:
            # using `logging` or `self.logger` if you have one
            logging.info(
                "SurrealDbAdapter.get_count received hint=%r; ignoring for COUNT().",
                options['hint']
            )

        # run the query
        raw = self.execute_query(sql)

        # parse_db_response will unwrap the Surreal response
        parsed = self.parse_db_response(raw)

        # parsed might be a dict or a list of dicts
        if isinstance(parsed, dict) and 'count' in parsed:
            return int(parsed['count'])
        if isinstance(parsed, list) and parsed and 'count' in parsed[0]:
            return int(parsed[0]['count'])

        # fallback
        return 0

    def get_save_query(self, table: str, data: Dict[str, Any]):
        """Returns operation to save a data record in the table."""
        record_id = data['id']
        # Remove 'id' from data since upsert takes it as a separate parameter
        data_without_id = {k: v for k, v in data.items() if k != 'id'}
        return 'upsert', record_id, data_without_id

    def save(self, table: str, data: Dict[str, Any]):
        # Ensure Big 6 fields exist with defaults for backward compatibility
        # This allows queries with active=true filters to work on non-versioned models
        if 'version' not in data or data.get('version') is None:
            data['version'] = None
        if 'previous_version' not in data or data.get('previous_version') is None:
            data['previous_version'] = None
        if 'active' not in data:
            data['active'] = True  # Default to active
        if 'changed_by_id' not in data or data.get('changed_by_id') is None:
            data['changed_by_id'] = None
        if 'changed_on' not in data or data.get('changed_on') is None:
            data['changed_on'] = None

        save_op = self.get_save_query(table, data)
        db_result = self._call_db(*save_op)
        return db_result

    def delete(self, table: str, data: Dict[str, Any]) -> bool:
        # Set active = false
        data['active'] = False
        return self.save(table, data)

    def hard_delete(self, table: str, entity_id: str) -> bool:
        """Permanently deletes a record from the specified table by entity_id."""
        query = f"DELETE {table}:`{entity_id}`"
        self.execute_query(query)
        return True
