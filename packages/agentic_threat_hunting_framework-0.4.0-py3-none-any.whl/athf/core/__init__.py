"""Core ATHF functionality."""
