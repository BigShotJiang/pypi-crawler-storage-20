"""
markdown_readtime - A library to estimate reading time for Markdown content

This package provides functionality to estimate the reading time of Markdown documents,
with support for both Chinese and English texts, images, code blocks, and emojis.
"""

try:
    from .markdown_readtime import (
        estimate,
        estimate_with_speed,
        minutes,
        words,
        formatted,
        ReadSpeed,
        ReadTime,
    )
except ImportError:
    # 如果原生扩展不可用，则尝试直接导入
    from markdown_readtime import (
        estimate,
        estimate_with_speed,
        minutes,
        words,
        formatted,
        ReadSpeed,
        ReadTime,
    )

__version__ = "0.1.1"
__author__ = "hualayn"
__license__ = "MIT"

__all__ = [
    "estimate",
    "estimate_with_speed", 
    "minutes",
    "words",
    "formatted",
    "ReadSpeed",
    "ReadTime",
]