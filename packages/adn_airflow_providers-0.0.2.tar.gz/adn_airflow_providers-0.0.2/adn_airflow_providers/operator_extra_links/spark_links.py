"""Spark Kubernetes Extra Links"""
from __future__ import annotations

from typing import Any

from airflow.models import BaseOperator, TaskInstance, XCom
from airflow.models.baseoperatorlink import BaseOperatorLink
from airflow.models.taskinstancekey import TaskInstanceKey
from airflow.utils.state import TaskInstanceState

XCOM_SPARK_UI_LINK = "spark_ui_link"
XCOM_SPARK_HISTORY_LINK = "spark_history_link"
XCOM_GRAFANA_LINK = "grafana_link"


def _normalize(link: Any) -> str:
    return str(link) if link else ""


class SparkUiLink(BaseOperatorLink):
    """
    Spark UI link for ADNSparkKubernetesOperator.

    Fetches the Spark UI URL from XCom using XCOM_SPARK_UI_LINK.
    """

    name = "Spark UI"

    def get_link(self, operator: BaseOperator, *, ti_key: TaskInstanceKey) -> str:
        ti = TaskInstance.get_task_instance(
            dag_id=ti_key.dag_id,
            run_id=ti_key.run_id,
            task_id=ti_key.task_id,
            map_index=ti_key.map_index,
        )
        key = XCOM_SPARK_UI_LINK if ti and ti.state == TaskInstanceState.RUNNING else XCOM_SPARK_HISTORY_LINK

        return _normalize(XCom.get_value(ti_key=ti_key, key=key))


class GrafanaLink(BaseOperatorLink):
    """
    Grafana metrics link for ADNSparkKubernetesOperator.

    Fetches the Grafana dashboard URL from XCom using XCOM_GRAFANA_LINK.
    """

    name = "Grafana"

    def get_link(self, operator: BaseOperator, *, ti_key: TaskInstanceKey) -> str:
        return _normalize(XCom.get_value(ti_key=ti_key, key=XCOM_GRAFANA_LINK))
