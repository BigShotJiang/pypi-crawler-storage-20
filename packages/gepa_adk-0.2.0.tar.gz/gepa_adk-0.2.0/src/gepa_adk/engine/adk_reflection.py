r"""ADK-based reflection function factory.

This module provides the factory function for creating reflection functions
that use Google ADK agents. The returned function can be passed to
AsyncReflectiveMutationProposer as the adk_reflection_fn parameter.

Terminology:
    - **component_text**: The current text content of a component being evolved
    - **trial**: One performance record {feedback, trajectory}
    - **feedback**: Critic evaluation {score, feedback_text, feedback_*} (stochastic)
    - **trajectory**: Execution record {input, output, trace} (deterministic)
    - **trials**: Collection of trial records for reflection
    - **proposed_component_text**: The improved text for the same component

Attributes:
    REFLECTION_INSTRUCTION (str): Default instruction template with
        `{component_text}` and `{trials}` placeholders for ADK template
        substitution.
    SESSION_STATE_KEYS (dict[str, type]): Expected keys and types in ADK
        session state for reflection agent access.
    create_adk_reflection_fn (function): Factory that creates a ReflectionFn
        using an ADK LlmAgent for reflection.

Examples:
    Create a reflection function with custom agent:

    ```python
    from google.adk.agents import LlmAgent
    from gepa_adk.engine.adk_reflection import create_adk_reflection_fn

    agent = LlmAgent(
        name="reflector",
        model="gemini-2.5-flash",
        instruction="Improve: {component_text}\nTrials: {trials}",
    )
    reflection_fn = create_adk_reflection_fn(agent)
    ```

See Also:
    - [`gepa_adk.engine.proposer`][gepa_adk.engine.proposer]: Proposer that uses
      reflection functions.
"""

__all__ = [
    "REFLECTION_INSTRUCTION",
    "SESSION_STATE_KEYS",
    "create_adk_reflection_fn",
]

import json
from typing import Any

import structlog

from gepa_adk.engine.proposer import ReflectionFn

logger = structlog.get_logger(__name__)

# Session state schema keys for ADK reflection
SESSION_STATE_KEYS = {
    "component_text": str,
    "trials": str,  # JSON-serialized list of trial records
}
"""Expected keys and types in ADK session state for reflection.

The reflection agent accesses these keys via `{key}` template syntax
in its instruction. ADK's `inject_session_state()` automatically
substitutes placeholders with session state values.

Keys:
    component_text: The text content being evolved (str).
    trials: JSON-serialized list of trial records (str). Each trial
        contains {input, output, feedback, trajectory}.
"""

# Default reflection instruction with ADK template placeholders
REFLECTION_INSTRUCTION = """## Component Text to Improve
{component_text}

## Trials
{trials}

Propose an improved version of the component text based on the trials above.
Return ONLY the improved component text, nothing else."""
"""Default instruction template for reflection agents.

Uses ADK's native template substitution syntax (`{key}`) to inject
session state values. ADK automatically replaces these placeholders
with values from `session.state[key]` during instruction processing.

The template contains two placeholders:

- `{component_text}`: The current text being evolved (str)
- `{trials}`: JSON-serialized list of trial records (str)

The instruction is processed by ADK's `inject_session_state()` function
before being sent to the LLM.

Examples:
    Use the default instruction with a custom agent:

    ```python
    from google.adk.agents import LlmAgent
    from gepa_adk.engine.adk_reflection import REFLECTION_INSTRUCTION

    agent = LlmAgent(
        name="reflector",
        model="gemini-2.5-flash",
        instruction=REFLECTION_INSTRUCTION,
    )
    ```

Note:
    This replaces the previous workaround of embedding data in user
    messages via Python f-strings.
"""


def create_adk_reflection_fn(
    reflection_agent: Any,  # LlmAgent from google.adk.agents
    session_service: Any | None = None,  # BaseSessionService from google.adk.sessions
    output_key: str = "proposed_component_text",
) -> ReflectionFn:
    """Create a reflection function from an ADK LlmAgent.

    This factory function creates an async callable that uses the Google ADK
    framework for reflection. The returned function can be passed to
    AsyncReflectiveMutationProposer as the adk_reflection_fn parameter.

    Args:
        reflection_agent: ADK LlmAgent configured with instruction containing
            `{component_text}` and `{trials}` placeholders. The agent's
            instruction should include logic for improving text based on
            trial results.
        session_service: Optional session service for state management.
            Defaults to InMemorySessionService if None. Use custom services
            (e.g., DatabaseSessionService) for production deployments requiring
            session persistence.
        output_key: Key in session state where ADK stores the agent's output.
            Defaults to "proposed_component_text". When set, the agent's output_key
            is configured to this value, and output is retrieved from session
            state after execution. Falls back to event-based extraction if
            the output_key is not found in session state.

    Returns:
        Async callable matching ReflectionFn signature that generates proposed
        component text via the ADK agent.

    Raises:
        Exception: If ADK agent execution fails (propagated from ADK Runner).

    Examples:
        Basic usage with default session service:

        ```python
        from google.adk.agents import LlmAgent
        from gepa_adk.engine.adk_reflection import create_adk_reflection_fn

        agent = LlmAgent(
            name="InstructionReflector",
            model="gemini-2.5-flash",
            instruction=\"\"\"Improve this component text:
            {component_text}

            Based on these trials:
            {trials}

            Return proposed component text only.\"\"\"
        )

        reflection_fn = create_adk_reflection_fn(agent)
        trials = [{"input": "Hi", "output": "Hey", "feedback": {"score": 0.5}}]
        proposed = await reflection_fn("Be helpful", trials)
        ```

        With custom session service:

        ```python
        from google.adk.sessions import DatabaseSessionService

        db_service = DatabaseSessionService(db_url="sqlite:///sessions.db")
        reflection_fn = create_adk_reflection_fn(agent, session_service=db_service)
        ```

    See Also:
        - [`gepa_adk.engine.proposer`][gepa_adk.engine.proposer]: Module containing
          ReflectionFn type alias and AsyncReflectiveMutationProposer class.

    Note:
        Opens a fresh ADK session for each invocation, ensuring complete
        isolation between reflection operations. State is initialized with
        component_text (str) and trials (JSON-serialized list of trial records).
    """
    from uuid import uuid4

    from google.adk import Runner
    from google.adk.sessions import InMemorySessionService
    from google.genai.types import Content, Part

    from gepa_adk.utils.events import extract_final_output, extract_output_from_state

    # Default to InMemorySessionService if not provided
    if session_service is None:
        session_service = InMemorySessionService()

    # Configure output_key on agent if not already set
    # This enables ADK's automatic output storage to session.state
    if output_key and (
        not hasattr(reflection_agent, "output_key") or not reflection_agent.output_key
    ):
        reflection_agent.output_key = output_key
        logger.debug(
            "reflection.output_key.configured",
            output_key=output_key,
            agent_name=getattr(reflection_agent, "name", "unknown"),
        )

    async def reflect(
        component_text: str,
        trials: list[dict[str, Any]],
    ) -> str:
        """Reflect on component text using ADK agent to generate proposed version.

        Uses the configured ADK reflection agent to analyze the current component
        text and trials, then generates proposed component text based on the
        performance results.

        Args:
            component_text: The current component text to improve.
            trials: List of trial records from evaluation. Each trial contains
                input, output, feedback, and optional trajectory.

        Returns:
            Proposed component text generated by the reflection agent. Returns
            empty string if the agent produces no output.

        Raises:
            Exception: If ADK agent execution fails. The exception is logged
                and re-raised for upstream handling.

        Examples:
            Call the returned reflection function:

            ```python
            reflection_fn = create_adk_reflection_fn(agent)
            trials = [
                {"input": "Hi", "output": "Hello", "feedback": {"score": 0.8}},
            ]
            proposed = await reflection_fn("Be helpful", trials)
            ```

        Note:
            Opens a unique session with fresh state for each invocation to ensure
            isolation between reflection operations.
        """
        # Generate unique session ID for this reflection
        session_id = f"reflect_{uuid4()}"

        # Log reflection start
        logger.info(
            "reflection.start",
            session_id=session_id,
            component_text_length=len(component_text),
            trial_count=len(trials),
        )

        try:
            # Create session with initial state
            session_state: dict[str, Any] = {
                "component_text": component_text,
                "trials": json.dumps(trials),
            }

            await session_service.create_session(
                app_name="gepa_reflection",
                user_id="reflection",
                session_id=session_id,
                state=session_state,
            )

            # Create runner for this reflection
            runner = Runner(
                agent=reflection_agent,
                app_name="gepa_reflection",
                session_service=session_service,
            )

            # Log template substitution setup
            logger.debug(
                "reflection.template_state",
                session_id=session_id,
                state_keys=list(session_state.keys()),
                component_text_length=len(component_text),
                trials_length=len(session_state["trials"]),
            )

            # Simple trigger message - data is in session state via template placeholders
            # ADK's inject_session_state() will substitute {component_text} and {trials}
            # in the agent's instruction from session.state values
            user_message = (
                "Please improve the component text based on the trial results."
            )

            # Execute reflection via Runner.run_async
            events = []
            async for event in runner.run_async(
                user_id="reflection",
                session_id=session_id,
                new_message=Content(
                    role="user",
                    parts=[Part(text=user_message)],
                ),
            ):
                events.append(event)

            # Try state-based extraction first (uses output_key)
            proposed_component_text = None
            if output_key:
                session = await session_service.get_session(
                    app_name="gepa_reflection",
                    user_id="reflection",
                    session_id=session_id,
                )
                if session:
                    proposed_component_text = extract_output_from_state(
                        session.state, output_key
                    )
                    if proposed_component_text is not None:
                        logger.debug(
                            "reflection.output.from_state",
                            session_id=session_id,
                            output_key=output_key,
                        )

            # Fallback to event-based extraction
            if proposed_component_text is None:
                proposed_component_text = extract_final_output(events)
                logger.debug(
                    "reflection.output.from_events",
                    session_id=session_id,
                    fallback_reason="output_key not in state or session unavailable",
                )

            # Log reflection complete
            logger.info(
                "reflection.complete",
                session_id=session_id,
                response_length=len(proposed_component_text),
            )

            # Handle empty response - fallback to empty string
            if not proposed_component_text:
                logger.warning(
                    "reflection.empty_response",
                    session_id=session_id,
                )
                return ""

            return proposed_component_text

        except Exception as e:
            # Log error and propagate
            logger.error(
                "reflection.error",
                session_id=session_id,
                error=str(e),
                error_type=type(e).__name__,
            )
            raise

    return reflect
