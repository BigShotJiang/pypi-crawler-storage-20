"""Tests for GraphQL module."""
