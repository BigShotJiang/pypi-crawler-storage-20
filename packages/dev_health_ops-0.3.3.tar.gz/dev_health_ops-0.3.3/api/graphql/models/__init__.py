"""GraphQL models subpackage."""
