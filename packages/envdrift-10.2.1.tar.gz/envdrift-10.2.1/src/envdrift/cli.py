"""Command-line interface for envdrift."""

from __future__ import annotations

import typer

from envdrift.cli_commands.agent import agent_app
from envdrift.cli_commands.diff import diff
from envdrift.cli_commands.encryption import decrypt_cmd, encrypt_cmd
from envdrift.cli_commands.guard import guard
from envdrift.cli_commands.hook import hook
from envdrift.cli_commands.init_cmd import init as init_cmd
from envdrift.cli_commands.partial import pull_cmd as pull_partial_cmd
from envdrift.cli_commands.partial import push as push_cmd
from envdrift.cli_commands.sync import lock, pull, sync
from envdrift.cli_commands.validate import validate
from envdrift.cli_commands.vault import vault_push
from envdrift.cli_commands.version import version

app = typer.Typer(
    name="envdrift",
    help="Prevent environment variable drift with Pydantic schema validation.",
    no_args_is_help=True,
)

app.command()(validate)
app.command()(diff)
app.command("encrypt")(encrypt_cmd)
app.command("decrypt")(decrypt_cmd)
app.command("init")(init_cmd)
app.command()(guard)
app.command()(hook)
app.command()(sync)
app.command()(pull)
app.command()(lock)
app.command("vault-push")(vault_push)
app.command()(version)

# Partial encryption commands
app.command("push")(push_cmd)
app.command("pull-partial")(pull_partial_cmd)

# Agent commands
app.add_typer(agent_app, name="agent")


if __name__ == "__main__":
    app()
