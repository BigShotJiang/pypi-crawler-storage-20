# grid_samp - Grid-based image sampling toolbox
# Copyright (C) 2026 Maarten Leemans, Crhrisophe Bossens, Johan Wagemans
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

from importlib.metadata import version

__version__ = version("grid-samp")

from grid_samp.image_region import ImageRegion
from grid_samp.image_region_list import ImageRegionList

__all__ = [
    "ImageRegion",
    "ImageRegionList",
]

from grid_samp.grids.fixed_grid import FixedGrid
from grid_samp.assemble.roi import ROI 