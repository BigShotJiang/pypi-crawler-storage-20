#!/usr/bin/env python
"""
Package metadata for xblocks-contrib.
"""
import os
import re
import sys

from setuptools import find_packages, setup


def get_version(*file_paths):
    """
    Extract the version string from the file.

    Input:
     - file_paths: relative path fragments to file with
                   version string
    """
    filename = os.path.join(os.path.dirname(__file__), *file_paths)
    version_file = open(filename, encoding="utf8").read()
    version_match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]", version_file, re.M)
    if version_match:
        return version_match.group(1)
    raise RuntimeError("Unable to find version string.")


def load_requirements(*requirements_paths):
    """
    Load all requirements from the specified requirements files.

    Requirements will include any constraints from files specified
    with -c in the requirements files.
    Returns a list of requirement strings.
    """
    # e.g. {"django": "Django", "confluent-kafka": "confluent_kafka[avro]"}
    by_canonical_name = {}

    def check_name_consistent(package):
        """
        Raise exception if package is named different ways.

        This ensures that packages are named consistently so we can match
        constraints to packages. It also ensures that if we require a package
        with extras we don't constrain it without mentioning the extras (since
        that too would interfere with matching constraints.)
        """
        canonical = package.lower().replace("_", "-").split("[")[0]
        seen_spelling = by_canonical_name.get(canonical)
        if seen_spelling is None:
            by_canonical_name[canonical] = package
        elif seen_spelling != package:
            raise Exception(
                f'Encountered both "{seen_spelling}" and "{package}" in requirements '
                "and constraints files; please use just one or the other."
            )

    requirements = {}
    constraint_files = set()

    # groups "pkg<=x.y.z,..." into ("pkg", "<=x.y.z,...")
    re_package_name_base_chars = r"a-zA-Z0-9\-_."  # chars allowed in base package name
    # Two groups: name[maybe,extras], and optionally a constraint
    requirement_line_regex = re.compile(
        r"([%s]+(?:\[[%s,\s]+\])?)([<>=][^#\s]+)?"
        % (re_package_name_base_chars, re_package_name_base_chars)
    )

    def add_version_constraint_or_raise(
        current_line, current_requirements, add_if_not_present
    ):
        regex_match = requirement_line_regex.match(current_line)
        if regex_match:
            package = regex_match.group(1)
            version_constraints = regex_match.group(2)
            check_name_consistent(package)
            existing_version_constraints = current_requirements.get(package, None)
            # It's fine to add constraints to an unconstrained package,
            # but raise an error if there are already constraints in place.
            if (
                existing_version_constraints
                and existing_version_constraints != version_constraints
            ):
                raise BaseException(
                    f"Multiple constraint definitions found for {package}:"
                    f' "{existing_version_constraints}" and "{version_constraints}".'
                    f"Combine constraints into one location with {package}"
                    f"{existing_version_constraints},{version_constraints}."
                )
            if add_if_not_present or package in current_requirements:
                current_requirements[package] = version_constraints

    # Read requirements from .in files and store the path to any
    # constraint files that are pulled in.
    for path in requirements_paths:
        with open(path) as reqs:
            for line in reqs:
                if is_requirement(line):
                    add_version_constraint_or_raise(line, requirements, True)
                if line and line.startswith("-c") and not line.startswith("-c http"):
                    constraint_files.add(
                        os.path.dirname(path)
                        + "/"
                        + line.split("#")[0].replace("-c", "").strip()
                    )

    # process constraint files: add constraints to existing requirements
    for constraint_file in constraint_files:
        with open(constraint_file) as reader:
            for line in reader:
                if is_requirement(line):
                    add_version_constraint_or_raise(line, requirements, False)

    # process back into list of pkg><=constraints strings
    constrained_requirements = [
        f'{pkg}{version or ""}' for (pkg, version) in sorted(requirements.items())
    ]
    return constrained_requirements


def is_requirement(line):
    """
    Return True if the requirement line is a package requirement.

    Returns:
        bool: True if the line is not blank, a comment,
        a URL, or an included file
    """
    return (
        line and line.strip() and not line.startswith(("-r", "#", "-e", "git+", "-c"))
    )


def package_data(pkg, sub_roots):
    """
    Declare package_data based on all root directories inside `pkg`.

    All of the files under each of the sub_roots for every root directory
    inside `pkg` will be declared as package data for package `pkg`.

    """
    data = []
    roots = [d for d in os.listdir(pkg) if os.path.isdir(os.path.join(pkg, d))]

    for root in roots:
        for sub_root in sub_roots:
            for dirname, _, files in os.walk(os.path.join(pkg, root, sub_root)):
                for fname in files:
                    data.append(os.path.relpath(os.path.join(dirname, fname), pkg))

    return {pkg: data}


VERSION = get_version("xblocks_contrib", "__init__.py")

if sys.argv[-1] == "tag":
    print("Tagging the version on github:")
    os.system("git tag -a %s -m 'version %s'" % (VERSION, VERSION))
    os.system("git push --tags")
    sys.exit()

README = open(
    os.path.join(os.path.dirname(__file__), "README.rst"), encoding="utf8"
).read()
CHANGELOG = open(
    os.path.join(os.path.dirname(__file__), "CHANGELOG.rst"), encoding="utf8"
).read()

setup(
    name="xblocks-contrib",
    version=VERSION,
    description="""core xblocks""",
    long_description=README + "\n\n" + CHANGELOG,
    author="Open edX Project",
    author_email="oscm@openedx.org",
    url="https://github.com/openedx/xblocks-contrib",
    packages=find_packages(
        include=["xblocks_contrib", "xblocks_contrib.*"],
        exclude=["*tests"],
    ),
    include_package_data=True,
    install_requires=load_requirements("requirements/base.in"),
    python_requires=">=3.11",
    license="AGPL 3.0",
    zip_safe=False,
    keywords="Python edx",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: GNU Affero General Public License v3 or later (AGPLv3+)",
        "Natural Language :: English",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    entry_points={
        "xblock.v1": [
            # _extracted suffix is added for testing only.
            "_annotatable_extracted = xblocks_contrib:AnnotatableBlock",
            "_discussion_extracted = xblocks_contrib:DiscussionXBlock",
            "_html_extracted = xblocks_contrib:HtmlBlock",
            "_lti_extracted = xblocks_contrib:LTIBlock",
            "_poll_question_extracted = xblocks_contrib:PollBlock",
            "_problem_extracted = xblocks_contrib:ProblemBlock",
            "_video_extracted = xblocks_contrib:VideoBlock",
            "_word_cloud_extracted = xblocks_contrib:WordCloudBlock",
        ]
    },
    package_data=package_data("xblocks_contrib", ["static", "public", "templates"]),
)
