#pragma once

void bar();
