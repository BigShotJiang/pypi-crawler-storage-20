# Tyche Transforms

This package provides the transformation functions defined in `MARKETS_INFO.md` for Tyche market data pipelines.
The intent is to keep the same implementations between local development and the Chainlink adapter.

## Install
```bash
python3 -m pip install tyche-transforms
```

For development:
```bash
python3 -m pip install -e ".[test]"
```

## Usage
```python
import pandas as pd
from tyche_transforms.transforms import daily_average, hdd, runlen_lt

series = pd.Series([15.0, 10.0, 8.0], index=pd.date_range("2024-01-01", periods=3))
print(hdd(series))
print(runlen_lt(series, threshold=9.0))
```

## GitHub Actions
This repo includes a workflow that runs tests on every push/PR and publishes to PyPI when you push a tag
matching `v*` (for example `v0.2.0`). To enable publishing:

1) Add a repository secret named `PYPI_API_TOKEN` containing your PyPI token.
2) Push a version tag:
```bash
git tag v0.2.0
git push origin v0.2.0
```

## Transform list
- `CONVERT_M_TO_MM`: convert meters to millimeters.
- `CUMULATIVE_TO_INCREMENT`: convert cumulative totals to daily increments.
- `DAILY_AVERAGE`, `DAILY_SUM`, `DAILY_MAX`: daily resampling functions.
- `HDD`, `CDD`: heating/cooling degree days (base 18 C).
- `SUM`, `AVG`, `MAX`, `MIN`: aggregations to scalars.
- `DATE_MAX`, `DATE_FIRST`: timestamp utilities.
- `RUNLEN_LT`: longest run length below a threshold.
- `ABS`, `SUBTRACT_V`, `SUBTRACT`: scalar transforms.
