"""
    Copyright 2021 EPAM Systems, Inc.

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""
import json

from syndicate.core.transform.terraform.converter.tf_resource_converter import \
    TerraformResourceConverter


class IamPolicyConverter(TerraformResourceConverter):

    def convert(self, name, resource):
        policy = resource.get('policy_content')
        policy_content = json.dumps(policy)

        resource_template = iam_policy(
            policy_name=name,
            content=policy_content)
        self.template.add_aws_iam_policy(meta=resource_template)


def iam_policy(policy_name, content):
    resource = {
        policy_name:
            {
                "name": policy_name,
                "policy": content
            }
    }
    return resource
