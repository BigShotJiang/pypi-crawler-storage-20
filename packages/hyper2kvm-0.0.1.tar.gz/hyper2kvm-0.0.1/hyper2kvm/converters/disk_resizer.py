# SPDX-License-Identifier: LGPL-3.0-or-later
# -*- coding: utf-8 -*-
# hyper2kvm/converters/disk_resizer.py
from __future__ import annotations

from .qemu.converter import Convert
