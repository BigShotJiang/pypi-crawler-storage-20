"""hvPlot MCP Server."""
