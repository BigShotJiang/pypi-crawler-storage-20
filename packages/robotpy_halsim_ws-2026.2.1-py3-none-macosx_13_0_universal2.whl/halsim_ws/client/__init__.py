from .main import loadExtension
