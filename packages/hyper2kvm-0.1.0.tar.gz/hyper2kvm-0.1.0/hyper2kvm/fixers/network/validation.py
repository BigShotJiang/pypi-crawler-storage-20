# SPDX-License-Identifier: LGPL-3.0-or-later
# hyper2kvm/fixers/network/validation.py
"""
Network configuration fix validation.

This module validates that network configuration fixes didn't corrupt
the config files and that essential sections/keywords are preserved.
"""
from __future__ import annotations

import logging

from ...config.config_loader import YAML_AVAILABLE, yaml
from .model import IfcfgKV, NetworkConfigType


class NetworkValidation:
    """
    Network configuration fix validator.

    Validates that fixes don't corrupt configuration files by checking:
    - YAML validity for netplan
    - Essential sections preserved (systemd, NetworkManager)
    - Required keywords present (ifcfg DEVICE, interfaces iface)
    """

    def __init__(self, logger: logging.Logger):
        """
        Initialize validator.

        Args:
            logger: Logger instance
        """
        self.logger = logger

    def _has_live_section(self, text: str, header: str) -> bool:
        """
        Check if INI-style config has a non-commented section header.

        Args:
            text: Configuration file content
            header: Section header to find (e.g., "[Network]")

        Returns:
            True if section exists and is not commented out
        """
        want = header.strip().lower()
        for ln in text.splitlines():
            s = ln.strip()
            if not s or s.startswith(("#", ";")):
                continue
            if s.lower() == want:
                return True
        return False

    def validate_fix(
        self,
        original: str,
        fixed: str,
        config_type: NetworkConfigType,
    ) -> list[str]:
        """
        Validate that fix didn't corrupt configuration.

        Args:
            original: Original config content
            fixed: Fixed config content
            config_type: Configuration file type

        Returns:
            List of validation error messages (empty if valid)
        """
        errors: list[str] = []

        # Check for empty result
        if not fixed.strip():
            errors.append("Empty configuration after fix")

        # Netplan: validate YAML syntax
        if config_type == NetworkConfigType.NETPLAN and YAML_AVAILABLE:
            try:
                obj = yaml.safe_load(fixed)
                if obj is None:
                    errors.append("Netplan YAML became empty")
            except Exception as e:
                errors.append(f"Invalid YAML: {e}")

        # ifcfg-rh/wicked: check DEVICE keyword
        if config_type in (NetworkConfigType.IFCFG_RH, NetworkConfigType.WICKED_IFCFG):
            try:
                ifcfg = IfcfgKV.parse(fixed)
                dev = (ifcfg.get("DEVICE") or "").strip()
                if not dev:
                    errors.append("ifcfg missing DEVICE after fix")
            except Exception as e:
                errors.append(f"ifcfg parse failed after fix: {e}")

        # systemd-networkd: check for [Network] section
        if config_type == NetworkConfigType.SYSTEMD_NETWORK:
            if (
                self._has_live_section(fixed, "[Network]") is False
                and self._has_live_section(original, "[Network]") is True
            ):
                errors.append("Missing live [Network] section after fix")

        # systemd-netdev: check for [NetDev] section
        if config_type == NetworkConfigType.SYSTEMD_NETDEV:
            if (
                self._has_live_section(fixed, "[NetDev]") is False
                and self._has_live_section(original, "[NetDev]") is True
            ):
                errors.append("Missing live [NetDev] section after fix")

        # NetworkManager: check for [connection] section
        if config_type == NetworkConfigType.NETWORK_MANAGER:
            if (
                self._has_live_section(fixed, "[connection]") is False
                and self._has_live_section(original, "[connection]") is True
            ):
                errors.append("Missing live [connection] section after fix")

        # Debian interfaces: check for iface keyword
        if config_type == NetworkConfigType.INTERFACES:
            if "iface" in original and "iface" not in fixed:
                errors.append("Missing essential keyword: iface")

        return errors


__all__ = ["NetworkValidation"]
