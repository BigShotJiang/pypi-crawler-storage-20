class NoUsernameProvidedException(Exception):
    pass
