"""State machines package."""
