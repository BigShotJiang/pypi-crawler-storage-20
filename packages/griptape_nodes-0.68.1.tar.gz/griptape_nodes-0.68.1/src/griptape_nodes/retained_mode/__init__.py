"""Retained mode package."""
