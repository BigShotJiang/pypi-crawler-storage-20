# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.1] - 2026-01-18

### 🎉 Major Features Added

#### Conditions System
- **Complete Conditions Implementation** for D&D 5e combat
  - `Condition` class with all D&D 5e conditions
  - Automatic effects application (disadvantage, advantage, speed, etc.)
  - Save system with DC and ability checks
  - Duration tracking (rounds or until saved)
  - 9 predefined condition creators:
    * `create_restrained_condition()` - Speed 0, disadvantage on attacks
    * `create_poisoned_condition()` - Disadvantage on attacks and ability checks
    * `create_frightened_condition()` - Disadvantage while source visible
    * `create_grappled_condition()` - Speed becomes 0
    * `create_paralyzed_condition()` - Incapacitated, auto-fail STR/DEX saves
    * `create_stunned_condition()` - Incapacitated, advantage against
    * `create_prone_condition()` - Disadvantage on attacks
    * `create_blinded_condition()` - Disadvantage, attacks have advantage
    * `create_charmed_condition()` - Can't attack charmer

- **Condition Effects on Combat**:
  - `disadvantage_on_attacks` - Attack rolls with disadvantage
  - `advantage_against` - Attacks against creature have advantage  
  - `speed_zero` - Movement speed becomes 0
  - `incapacitated` - Can't take actions
  - `auto_fail_str_dex` - Auto-fail STR and DEX saves
  - `disadvantage_on_saves` - Disadvantage on saving throws
  - `disadvantage_on_ability_checks` - Disadvantage on ability checks

- **Condition Management**:
  - `apply_to_character(character)` - Apply condition
  - `remove_from_character(character)` - Remove condition
  - `should_save(round_num)` - Check if should attempt save
  - `attempt_save(character)` - Attempt saving throw
  - Source tracking (monster or spell that applied condition)

### Added
- `dnd_5e_core.combat.condition` - Complete conditions system
- `tests/test_conditions.py` - Comprehensive conditions test suite
- Conditions exported from `dnd_5e_core.combat` module
- DnD5e-Scenarios integration modules:
  - `src/utils/character_manager.py` - Character sheet display and party management
  - `src/utils/treasure_manager.py` - Treasure generation and distribution
  - `demo_complete.py` - Full integration demonstration
  - `test_magic_items_combat.py` - Combat with magic items test

### Changed
- `combat/__init__.py` - Added all condition exports
- Updated examples to show condition usage

### Documentation
- Added condition system documentation
- Test scripts demonstrate all condition features
- Character sheet display with conditions
- Party management menu system

### Examples

**Using Conditions:**
```python
from dnd_5e_core.combat import create_restrained_condition

# Apply restrained condition
restrained = create_restrained_condition(creature=spider, save_dc=11)
restrained.apply_to_character(fighter)

# Check effects
print(f"Speed zero: {restrained.speed_zero}")  # True
print(f"Disadvantage: {restrained.disadvantage_on_attacks}")  # True

# Attempt save
if restrained.attempt_save(fighter):
    restrained.remove_from_character(fighter)
```

**Character Sheet Display:**
```python
from character_manager import display_character_sheet

display_character_sheet(wizard)
# Shows: abilities, HP, AC, inventory, magic items, spells, conditions
```

**Treasure System:**
```python
from treasure_manager import generate_treasure_by_cr, distribute_treasure_to_party

treasures = generate_treasure_by_cr(challenge_rating=2.0, num_monsters=3)
distribute_treasure_to_party(treasures, party)
# Automatically distributes gold, magic items, equipment
```

## [0.2.0] - 2026-01-18

### 🎉 Major Features Added

#### Magic Items System
- **Complete Magic Items Implementation** with combat actions and character enhancements
  - `MagicItem` class with passive bonuses (AC, saving throws, ability scores)
  - `MagicItemAction` for active combat abilities (attacks, healing, defense)
  - `MagicItemEffect` for special conditions and buffs
  - Attunement system (max 3 attuned items per character)
  - Charges/uses per day with automatic recharge tracking
  - Rarity system (Common, Uncommon, Rare, Very Rare, Legendary, Artifact)
  
- **Predefined Magic Items** ready to use:
  - Ring of Protection (+1 AC, +1 saves)
  - Cloak of Protection (+1 AC, +1 saves)
  - Wand of Magic Missiles (7 charges/day)
  - Staff of Healing (10 charges/day)
  - Belt of Giant Strength (STR 21)
  - Amulet of Health (CON 19)
  - Bracers of Defense (+2 AC)
  - Necklace of Fireballs (6 beads)
  
- **Magic Item Loader**: `load_magic_item(index)` from JSON data
- **Registry System**: `get_magic_item(index)` for predefined items

#### Defensive Spells System
- **Enhanced Spell Properties** for defense and buffs:
  - `duration` (e.g., "1 round", "8 hours", "10 minutes")
  - `concentration` (boolean flag)
  - `ac_bonus` (Shield +5, Shield of Faith +2, Mage Armor +3)
  - `saving_throw_bonus` (bonuses to saves)
  - `ability_bonuses` (stat improvements)
  - `damage_resistance` / `damage_immunity`
  - `conditions_immunity`
  
- **New Spell Properties**:
  - `is_defensive` - Check if spell provides defensive bonuses
  - `is_buff` - Check if spell provides stat bonuses
  
- **Defensive Spells Parsed**:
  - Shield (Level 1, +5 AC, 1 round)
  - Mage Armor (Level 1, +3 AC, 8 hours)
  - Shield of Faith (Level 1, +2 AC, 10 minutes, concentration)
  - Protection from Energy, Protection from Evil and Good, etc.

### Added
- `dnd_5e_core.equipment.magic_item` - Complete magic items system
- `dnd_5e_core.equipment.predefined_magic_items` - 8 ready-to-use magic items
- `tests/test_magic_items_and_defense.py` - Comprehensive test suite
- Spell loader now parses defensive properties from descriptions
- Character integration: `ac_bonus` attribute properly used by magic items

### Changed
- Spell loader enhanced to detect AC bonuses, saving throw bonuses from descriptions
- Character `armor_class` property now includes `ac_bonus` from magic items
- Equipment module exports expanded with magic item classes

### Fixed
- Magic items correctly use Character's `ac_bonus` attribute (read-only `armor_class` property)
- Defensive spell properties properly initialized from JSON data

### Documentation
- Added comprehensive magic items usage examples
- Test script demonstrates all new features
- Updated README with magic items and defensive spells sections

### Examples

**Using Magic Items:**
```python
from dnd_5e_core.equipment import create_ring_of_protection
from dnd_5e_core.data.loaders import simple_character_generator

wizard = simple_character_generator(level=5, class_name='wizard')
ring = create_ring_of_protection()

ring.attune(wizard)
ring.equipped = True
ring.apply_to_character(wizard)

print(f"AC: {wizard.armor_class}")  # +1 from ring
```

**Using Defensive Spells:**
```python
from dnd_5e_core.data import load_spell

shield = load_spell("shield")
print(f"{shield.name}: +{shield.ac_bonus} AC")
print(f"Duration: {shield.duration}")
print(f"Is Defensive: {shield.is_defensive}")
```

## [0.1.9] - 2026-01-17

### Changed
- **BREAKING CHANGE: Data Loader Functions Now Return Objects** - All `load_*()` functions in `dnd_5e_core.data.loader` now return class objects instead of dictionaries:
  - `load_monster(index)` returns `Monster` object (was `Dict[str, Any]`)
  - `load_spell(index)` returns `Spell` object (was `Dict[str, Any]`)
  - `load_weapon(index)` returns `Weapon` object (was `Dict[str, Any]`)
  - `load_armor(index)` returns `Armor` object (was `Dict[str, Any]`)
  
### Added
- Helper functions `_create_monster_from_data()` and `_create_spell_from_data()` to convert JSON data to objects
- Full support for Monster special abilities, spellcasting, and multiattack from JSON
- Comprehensive type hints for all loader functions
- Updated documentation in `docs/api/data.md` with object-based examples

### Fixed
- Proficiency creation now includes proper `ProfType` determination
- Range parsing for ranged attacks now correctly extracts normal/long ranges
- Action creation handles all edge cases from D&D 5e API format
- Spell range parsing supports both numeric and string formats (e.g., "120 feet", "Self")

### Documentation
- Added `LOADER_UPDATE.md` explaining the migration from dict to object returns
- Updated all examples in `docs/api/data.md` to use object properties instead of `.get()`
- Added comprehensive usage examples showing property access and method calls

### Migration Guide
Old code (v0.1.8 and earlier):
```python
goblin = load_monster("goblin")
name = goblin.get("name")
cr = goblin.get("challenge_rating")
```

New code (v0.1.9+):
```python
goblin = load_monster("goblin")  # Returns Monster object
name = goblin.name
cr = goblin.challenge_rating
if goblin.is_alive:
    goblin.hp_roll()  # Use object methods
```

## [0.1.4] - 2026-01-05

### Added
- **Complete Implementation of All Empty Classes** - All previously empty or incomplete classes have been fully implemented:
  
  **Equipment System**:
  - `Inventory` class for managing equipment with quantities
  
  **Spell System**:
  - `SpellSlots` class for managing spell slot usage and recovery
  - `get_spell_slots_by_level()` function for spell slot progression
  - Complete cantrip system with damage scaling by character level
  - `DAMAGE_CANTRIPS` and `UTILITY_CANTRIPS` dictionaries
  - Functions: `is_cantrip()`, `get_cantrip_damage_scaling()`, `get_cantrip_damage()`, etc.
  
  **Abilities System**:
  - `SkillType` enum with all 18 D&D 5e skills
  - `Skill` class for skill proficiency and expertise
  - `get_all_skills()` function to retrieve all skills
  - `SavingThrowType` enum for all 6 saving throws
  - `SavingThrow` class for saving throw mechanics
  - `make_saving_throw()` helper function with advantage/disadvantage support
  
  **Experience & Leveling**:
  - Complete `XP_LEVELS` table for levels 1-20
  - Experience functions: `get_level_from_xp()`, `get_xp_for_level()`, `get_xp_to_next_level()`, etc.
  - `calculate_proficiency_bonus()` by level
  - `get_cr_xp()` for monster XP rewards
  - `LevelUpResult` class for level up results
  - Level up system: `calculate_hp_gain()`, `perform_level_up()`, etc.
  - Ability Score Improvement (ASI) level tracking
  
  **Challenge Rating & Encounters**:
  - `ChallengeRating` class for monster difficulty
  - `EncounterDifficulty` class for encounter balance
  - `get_xp_thresholds_for_level()` for encounter difficulty by party level
  - `calculate_encounter_difficulty()` for multi-monster encounters
  - `get_appropriate_cr_range()` for balanced encounters
  
  **Multiclassing**:
  - `MulticlassRequirements` class
  - `MULTICLASS_PREREQUISITES` dictionary with all prerequisites
  - `can_multiclass_into()` and `can_multiclass_from()` functions
  - `calculate_spell_slots_multiclass()` for combined spellcaster levels
  - `get_multiclass_proficiencies()` for gained proficiencies
  - `calculate_hit_points_multiclass()` for multiclass HP
  
  **Utility Functions** (26+ new functions):
  - Dice rolling: `roll_dice()`, `roll_with_advantage()`, `roll_with_disadvantage()`
  - Modifiers: `calculate_modifier()`, `format_modifier()`
  - Combat: `calculate_ac()`, `calculate_attack_bonus()`, `calculate_save_dc()`
  - Criticals: `is_critical_hit()`, `is_critical_fail()`
  - Damage: `apply_resistance()`, `apply_vulnerability()`
  - Spell mechanics: `calculate_spell_attack_bonus()`
  - Character creation: `get_random_ability_scores()`, `get_standard_array()`
  - Physical mechanics: `calculate_carrying_capacity()`, `calculate_jump_distance()`
  
  **Game Constants**:
  - Complete `constants.py` module with 200+ game constants
  - Ability score limits, level ranges, movement speeds
  - Conditions, damage types, spell schools
  - Armor classes, weapon properties, equipment categories
  - Languages, skills, classes, races, alignments
  - Currency conversions, creature sizes, proficiency bonuses
  
  **Data Access**:
  - `DndApiClient` class for D&D 5e API access with caching
  - Methods for all resource types (monsters, spells, classes, equipment, etc.)
  - Search functionality with filters
  - `get_default_client()` and `set_default_client()` global client management
  
  **Serialization**:
  - `DndJSONEncoder` custom JSON encoder for D&D objects
  - `to_json()` and `from_json()` conversion functions
  - `save_to_file()` and `load_from_file()` for generic data
  - Character serialization: `serialize_character()`, `save_character()`, `load_character()`
  - Monster serialization: `serialize_monster()`
  - Party management: `save_party()`, `load_party()`
  - `create_backup()` for file backups

### Changed
- Updated all module `__init__.py` files to export new classes and functions
- Enhanced main package `__init__.py` with documentation comments for submodules
- Separated UI concerns from business logic classes
- Message format standardized: methods return `(messages: List[str], result)` tuples

### Documentation
- Added `docs/IMPLEMENTED_CLASSES.md` - Complete class implementation guide
- Added `docs/IMPLEMENTATION_SUMMARY.md` - Migration summary and statistics
- Created `test_new_classes.py` - Validation script for all new features
- Updated README examples with new functionality

### Statistics
- 10 new implementation files (~2,400 lines of code)
- 6 updated `__init__.py` files (~150 lines)
- 3 documentation files (~1,000 lines)
- **Total: ~3,550 lines of production code**
- **All 28 classes from dao_classes.py successfully migrated**
- **100% test success rate**

## [0.1.3] - 2026-01-05

### Fixed
- Fixed package data inclusion: monster data files (bestiary-sublist-data.json) now correctly included in distributed package
- Updated MANIFEST.in to properly include dnd_5e_core/data directory in builds

### Changed
- Excluded monster token images from PyPI distribution to meet size limits (1.3 MB vs 107 MB)
- Token images can still be downloaded separately using the token_downloader utility

## [0.1.2] - 2026-01-05

### Added
- **Publication Guides**: Complete documentation for PyPI and GitHub publication
  - `SUMMARY_SOLUTIONS.md` - Comprehensive FAQ and solutions
  - `PUBLICATION_CHECKLIST.md` - Step-by-step publication checklist
  - `PUBLICATION_EXPLAINED.md` - Detailed publication guide
  - `GITHUB_ABOUT_SETUP.md` - GitHub configuration guide
  - `ABOUT.md` - Project "About" section content
  - `INDEX.md` - Documentation navigation guide
  - `QUICK_COMMANDS.md` - Quick reference commands

### Changed
- Updated `pyproject.toml` readme format with explicit content-type
- Improved PyPI metadata for better sidebar display

### Fixed
- Fixed TypeError in test examples by adding null checks
- Clarified egg-info directory usage (not needed for publication)

## [0.1.1] - 2026-01-03

### Added
- **PyPI Metadata**: Complete metadata for PyPI publication
  - Authors and maintainers with contact emails
  - 11 keywords for better discoverability
  - 17 detailed classifiers
  - 8 project URLs (Homepage, Documentation, Issues, Changelog, etc.)
  - Proper license format for PyPI
- **GitHub Configuration**: Files for GitHub "About" section
  - `.github/ABOUT.md` - Complete project description
  - `.github/DESCRIPTION.txt` - Short description for sidebar
  - `.github/TOPICS.md` - Recommended topics/tags
  - `.github/GITHUB_ABOUT_SETUP.md` - Setup instructions
- **Documentation**: Enhanced publication documentation
  - `METADATA_SUMMARY.md` - Complete metadata overview
  - Updated `PUBLISHING.md` with PyPI and GitHub instructions

### Changed
- Updated `pyproject.toml` with complete PyPI metadata
- Improved project discoverability on PyPI

## [0.1.0] - 2025-12-24

### Added
- **MAJOR**: Integrated D&D 5e API Collections directory (26 index files)
  - All collection indexes from DnD-5th-Edition-API migrated to dnd-5e-core
  - New `dnd_5e_core.data.collections` module for managing collections
  - Auto-detection of collections directory (no manual configuration needed)
  - Compatible `populate()` function for backward compatibility
  - Convenience functions: `get_monsters_list()`, `get_spells_list()`, etc.
  - Collections README with documentation and examples
- **MAJOR**: Integrated D&D 5e JSON data directory (8.7 MB, 2000+ files)
  - All monster, spell, weapon, armor, class, and race data now included in package
  - Auto-detection of data directory (no manual configuration needed)
  - 27 categories of D&D 5e content (monsters, spells, weapons, etc.)
- Initial package structure
- Entity system (Monster, Character, Sprite)
- Race and SubRace system
- Class system with proficiencies
- Equipment system (Weapon, Armor, Potion)
- Spellcasting system with spell slots
- Combat system with actions and special abilities
- Abilities and saving throws
- Dice mechanics
- Data loader from local JSON files (migrated from API)
- JSON serialization

### Changed
- **BREAKING**: Data loader now auto-detects `dnd-5e-core/data` directory
- **IMPROVED**: `set_data_directory()` is now optional (auto-detection first)
- **IMPROVED**: Collections loader auto-detects `dnd-5e-core/collections` directory
- Data loader priority: 1) dnd-5e-core/data, 2) DnD-5th-Edition-API/data (fallback), 3) ./data
- Collections loader priority: 1) dnd-5e-core/collections, 2) DnD-5th-Edition-API/collections (fallback), 3) ./collections

### Migration Notes
- See `DATA_MIGRATION_COMPLETE.md` for full migration documentation
- All v2 game files updated to use auto-detection
- Backward compatibility maintained with fallback to old data location

## [0.1.0] - 2025-01-XX

### Added
- First alpha release
- Core D&D 5e mechanics implementation
