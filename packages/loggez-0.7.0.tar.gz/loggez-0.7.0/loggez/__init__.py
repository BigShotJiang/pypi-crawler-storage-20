"""init file"""
from .loggez import make_logger, loggez_logger
from .loggez2 import LoggezLogger as LoggezLogger2, make_logger as make_logger2, loggez_logger as loggez_logger2
