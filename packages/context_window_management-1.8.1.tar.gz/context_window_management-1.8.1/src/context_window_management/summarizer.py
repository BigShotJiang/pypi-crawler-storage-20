"""Summary generation and keyword extraction for conversation chunks."""

import re
from dataclasses import dataclass


@dataclass
class SummarizerConfig:
    """Configuration options for the summarizer.

    These options control how summaries are generated.
    """

    max_length: int = 1000  # Maximum summary length in characters
    include_code_context: bool = True  # Include code block descriptions
    extract_questions: bool = True  # Extract user questions/requests
    min_keyword_length: int = 3  # Minimum keyword length


# Default configuration instance
DEFAULT_CONFIG = SummarizerConfig()

# Common stop words to filter from keywords
STOP_WORDS = {
    # Articles and conjunctions
    "the",
    "a",
    "an",
    "and",
    "or",
    "but",
    # Prepositions
    "in",
    "on",
    "at",
    "to",
    "for",
    "of",
    "with",
    "by",
    "from",
    "as",
    "about",
    "into",
    "through",
    "during",
    "before",
    "after",
    "above",
    "below",
    "between",
    "under",
    # Verbs (common auxiliary/linking)
    "is",
    "was",
    "are",
    "were",
    "been",
    "be",
    "have",
    "has",
    "had",
    "do",
    "does",
    "did",
    "will",
    "would",
    "could",
    "should",
    "may",
    "might",
    "can",
    # Pronouns
    "this",
    "that",
    "these",
    "those",
    "i",
    "you",
    "he",
    "she",
    "it",
    "we",
    "they",
    "me",
    "my",
    "your",
    "his",
    "her",
    "its",
    "our",
    "their",
    # Question words
    "what",
    "which",
    "who",
    "when",
    "where",
    "why",
    "how",
    # Quantifiers
    "all",
    "each",
    "every",
    "both",
    "few",
    "more",
    "most",
    "other",
    "some",
    "such",
    "no",
    "nor",
    "not",
    "only",
    "own",
    "same",
    "any",
    "many",
    "much",
    # Adverbs
    "so",
    "than",
    "too",
    "very",
    "just",
    "again",
    "further",
    "then",
    "once",
    "there",
    "here",
    "now",
    "also",
    "really",
    "still",
    "already",
    "always",
    "never",
    "often",
    # Generic conversation words (often produce poor summaries)
    "particularly",
    "interested",
    "understanding",
    "details",
    "context",
    "information",
    "something",
    "anything",
    "nothing",
    "everything",
    "thing",
    "things",
    "way",
    "ways",
    "like",
    "want",
    "need",
    "know",
    "think",
    "see",
    "look",
    "make",
    "get",
    "got",
    "going",
    "able",
    "sure",
    "good",
    "well",
    "new",
    "first",
    "last",
    "long",
    "great",
    "little",
    "right",
    "best",
    "different",
    "another",
    "even",
    "back",
    "come",
    "work",
    "use",
    "used",
    "using",
}


def extract_keywords(text: str, top_k: int = 10, min_length: int = 3) -> list[str]:
    """Extract keywords from text using frequency and position analysis.

    Filters out stop words, code-like patterns, and short words.
    Prioritizes technical terms, identifiers, domain-specific language,
    and terms appearing early in the text.

    Args:
        text: Text to extract keywords from
        top_k: Maximum number of keywords to return
        min_length: Minimum word length to consider

    Returns:
        List of extracted keywords, sorted by relevance
    """
    if not text:
        return []

    # First, extract proper nouns (capitalized words not at sentence start)
    # before lowercasing
    proper_nouns = _extract_proper_nouns(text)

    # Split text into sentences for position weighting
    sentences = re.split(r"[.!?\n]+", text)

    # Track word scores with position weighting
    word_scores: dict[str, float] = {}

    for sent_idx, sentence in enumerate(sentences):
        # Position boost: first 3 sentences get higher weight
        position_boost = 1.5 if sent_idx < 3 else 1.0

        # Normalize and extract words
        sentence_lower = sentence.lower()
        words = re.findall(r"\b[a-z_][a-z0-9_]*\b", sentence_lower)

        # Filter out stop words and short words
        for word in words:
            if word in STOP_WORDS or len(word) < min_length:
                continue

            # Calculate score with boosts
            score = position_boost

            # Boost technical terms (contains underscore)
            if "_" in word:
                score *= 1.8

            # Boost words with numbers (version2, item1)
            if re.search(r"\d", word):
                score *= 1.4

            # Boost domain-specific technical terms
            if word in TECHNICAL_TERMS:
                score *= 2.0

            # Add to cumulative score
            word_scores[word] = word_scores.get(word, 0) + score

    # Add proper nouns with high boost (they're often important names)
    for noun in proper_nouns:
        noun_lower = noun.lower()
        if noun_lower not in STOP_WORDS and len(noun_lower) >= min_length:
            word_scores[noun_lower] = word_scores.get(noun_lower, 0) + 2.5

    # Sort by score
    sorted_keywords = sorted(word_scores.items(), key=lambda x: x[1], reverse=True)

    # Return top_k unique keywords
    return [word for word, _ in sorted_keywords[:top_k]]


def _extract_proper_nouns(text: str) -> list[str]:
    """Extract proper nouns (capitalized words not at sentence start).

    Args:
        text: Text to extract from

    Returns:
        List of proper nouns found
    """
    proper_nouns = []

    # Split into sentences
    sentences = re.split(r"[.!?\n]+", text)

    for sentence in sentences:
        words = sentence.split()
        if len(words) < 2:
            continue

        # Skip first word (sentence start), check remaining for capitals
        for word in words[1:]:
            # Clean punctuation
            clean_word = re.sub(r"[^\w]", "", word)
            if not clean_word:
                continue

            # Check if it starts with uppercase, isn't all caps (acronym),
            # and isn't a common false positive
            if (
                clean_word[0].isupper()
                and not clean_word.isupper()
                and clean_word.lower() not in STOP_WORDS
            ):
                proper_nouns.append(clean_word)

    return proper_nouns


# Domain-specific technical terms that should be boosted
TECHNICAL_TERMS = {
    # Programming concepts
    "api",
    "sdk",
    "cli",
    "gui",
    "url",
    "uri",
    "json",
    "xml",
    "html",
    "css",
    "sql",
    "nosql",
    "rest",
    "graphql",
    "grpc",
    "websocket",
    "http",
    "https",
    "tcp",
    "udp",
    # Data structures
    "array",
    "list",
    "dict",
    "dictionary",
    "map",
    "set",
    "queue",
    "stack",
    "tree",
    "graph",
    "heap",
    "hash",
    "cache",
    # Software patterns
    "singleton",
    "factory",
    "observer",
    "decorator",
    "middleware",
    "handler",
    "controller",
    "model",
    "view",
    "service",
    # Operations
    "authentication",
    "authorization",
    "validation",
    "serialization",
    "encryption",
    "compression",
    "migration",
    "deployment",
    "integration",
    "configuration",
    # Testing
    "test",
    "tests",
    "unittest",
    "pytest",
    "mock",
    "stub",
    "fixture",
    "assertion",
    "coverage",
    # Languages/frameworks
    "python",
    "javascript",
    "typescript",
    "rust",
    "golang",
    "java",
    "react",
    "vue",
    "angular",
    "django",
    "flask",
    "fastapi",
    "express",
    "node",
    "npm",
    "pip",
    "poetry",
    "cargo",
    # Infrastructure
    "docker",
    "kubernetes",
    "aws",
    "gcp",
    "azure",
    "terraform",
    "ansible",
    "nginx",
    "redis",
    "postgres",
    "mongodb",
    "mysql",
    "elasticsearch",
    # Git/version control
    "git",
    "commit",
    "branch",
    "merge",
    "rebase",
    "pull",
    "push",
    "clone",
    "repository",
    # File types
    "yaml",
    "toml",
    "env",
    "dockerfile",
    "makefile",
}


def extract_code_references(text: str) -> list[str]:
    """Extract file paths, function names, and other code references.

    Args:
        text: Text to extract references from

    Returns:
        List of code references found
    """
    references = []

    # Extract file paths (various patterns)
    # Matches: src/file.py, ./config.yaml, /absolute/path.txt
    file_paths = re.findall(r"(?:\.{0,2}/)?[\w\-]+(?:/[\w\-\.]+)*\.[\w]+", text, re.IGNORECASE)
    references.extend(file_paths)

    # Extract function/class definitions
    # Matches: def function_name, class ClassName
    definitions = re.findall(r"(?:def|class)\s+(\w+)", text)
    references.extend(definitions)

    # Extract import statements
    # Matches: import module, from module import thing
    imports = re.findall(r"(?:import|from)\s+([\w\.]+)", text)
    references.extend(imports)

    return list(set(references))  # Deduplicate


def extract_user_questions(user_messages: list[str]) -> list[str]:
    """Extract questions and requests from user messages.

    Looks for interrogative patterns and request indicators.

    Args:
        user_messages: List of user message content strings

    Returns:
        List of extracted questions/requests
    """
    questions = []

    # Patterns that indicate questions or requests
    question_patterns = [
        r"^(what|how|why|when|where|which|who|can you|could you|please|help|explain|show|tell)",
        r"\?$",  # Ends with question mark
        r"^(i want|i need|i'd like|can we|let's|implement|add|create|fix|update|remove|delete)",
    ]

    for msg in user_messages:
        if not msg:
            continue

        # Clean up the message
        msg_clean = msg.strip()
        sentences = re.split(r"[.!?]+", msg_clean)

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence or len(sentence) < 10:
                continue

            sentence_lower = sentence.lower()

            # Check if it matches question/request patterns
            for pattern in question_patterns:
                if re.search(pattern, sentence_lower):
                    # Truncate long sentences
                    if len(sentence) > 200:
                        sentence = sentence[:200] + "..."
                    questions.append(sentence)
                    break

    # Return unique questions, preserving order
    seen = set()
    unique_questions = []
    for q in questions:
        if q.lower() not in seen:
            seen.add(q.lower())
            unique_questions.append(q)

    return unique_questions[:5]  # Limit to 5 most relevant


def extract_assistant_actions(assistant_messages: list[str]) -> list[str]:
    """Extract actions and work descriptions from assistant messages.

    Looks for action statements indicating what was done.

    Args:
        assistant_messages: List of assistant message content strings

    Returns:
        List of extracted action descriptions
    """
    actions = []

    # Patterns that indicate assistant actions
    action_patterns = [
        r"^(i'll|i will|let me|i'm going to|i am going to)",
        r"^(created|implemented|added|fixed|updated|modified|removed|deleted|refactored)",
        r"^(here's|here is|i've|i have|done|finished|completed)",
        r"(the file|the function|the class|the module|the test)",
    ]

    for msg in assistant_messages:
        if not msg:
            continue

        # Clean up and split into sentences
        msg_clean = msg.strip()
        sentences = re.split(r"[.!?]+", msg_clean)

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence or len(sentence) < 15:
                continue

            sentence_lower = sentence.lower()

            # Check if it matches action patterns
            for pattern in action_patterns:
                if re.search(pattern, sentence_lower):
                    # Truncate long sentences
                    if len(sentence) > 200:
                        sentence = sentence[:200] + "..."
                    actions.append(sentence)
                    break

    # Return unique actions, preserving order
    seen = set()
    unique_actions = []
    for a in actions:
        if a.lower() not in seen:
            seen.add(a.lower())
            unique_actions.append(a)

    return unique_actions[:5]  # Limit to 5 most relevant


def extract_code_block_descriptions(text: str) -> list[str]:
    """Extract descriptions from code blocks (comments, docstrings).

    Looks for meaningful descriptions within code blocks that explain
    what the code does.

    Args:
        text: Text containing code blocks

    Returns:
        List of extracted descriptions
    """
    descriptions = []

    # Find all code blocks (```...```)
    code_blocks = re.findall(r"```[\w]*\n(.*?)```", text, re.DOTALL)

    for block in code_blocks:
        # Extract Python docstrings (triple quotes)
        docstrings = re.findall(r'"""(.*?)"""', block, re.DOTALL)
        docstrings.extend(re.findall(r"'''(.*?)'''", block, re.DOTALL))
        for doc in docstrings:
            # Get first line of docstring (usually the summary)
            first_line = doc.strip().split("\n")[0].strip()
            if first_line and len(first_line) >= 10 and len(first_line) <= 200:
                descriptions.append(first_line)

        # Extract single-line comments (# ...)
        comments = re.findall(r"#\s*(.+)$", block, re.MULTILINE)
        for comment in comments:
            comment = comment.strip()
            # Filter out noise (shebang, encoding, type hints, etc.)
            if (
                len(comment) >= 15
                and len(comment) <= 150
                and not comment.startswith("!")
                and not comment.startswith("-*-")
                and not comment.lower().startswith("type:")
                and not comment.lower().startswith("noqa")
                and not comment.lower().startswith("pylint")
                and not comment.lower().startswith("nosec")
                and "TODO" not in comment.upper()
                and "FIXME" not in comment.upper()
            ):
                descriptions.append(comment)

        # Extract JS/TS/Java style comments (// ...)
        js_comments = re.findall(r"//\s*(.+)$", block, re.MULTILINE)
        for comment in js_comments:
            comment = comment.strip()
            if len(comment) >= 15 and len(comment) <= 150:
                descriptions.append(comment)

    # Deduplicate while preserving order
    seen = set()
    unique_descriptions = []
    for desc in descriptions:
        desc_lower = desc.lower()
        if desc_lower not in seen:
            seen.add(desc_lower)
            unique_descriptions.append(desc)

    return unique_descriptions[:5]  # Limit to 5 descriptions


def get_chunk_position_label(chunk_index: int | None, total_chunks: int | None) -> str | None:
    """Get a human-readable position label for a chunk.

    Args:
        chunk_index: 0-based index of the chunk (None if unknown)
        total_chunks: Total number of chunks (None if unknown)

    Returns:
        Position label like "early", "middle", "late", or None if unknown
    """
    if chunk_index is None or total_chunks is None or total_chunks <= 0:
        return None

    if total_chunks == 1:
        return None  # No position context needed for single chunk

    # Calculate relative position (0.0 to 1.0)
    position = chunk_index / (total_chunks - 1) if total_chunks > 1 else 0.5

    if position <= 0.25:
        return "early in conversation"
    elif position >= 0.75:
        return "late in conversation"
    else:
        return "middle of conversation"


def extract_first_sentences(text: str, max_sentences: int = 3) -> str:
    """Extract first meaningful sentences from text as a fallback summary.

    Args:
        text: Full text to extract from
        max_sentences: Maximum number of sentences to extract

    Returns:
        Extracted sentences as a string
    """
    # Remove common markers
    cleaned = re.sub(r"\[(USER|ASSISTANT|TOOL_CALLS|TOOL_RESULTS)\]", "", text)
    cleaned = re.sub(r"(user:|assistant:|role:)", "", cleaned, flags=re.IGNORECASE)

    # Split into sentences
    sentences = re.split(r"[.!?]+", cleaned)

    # Filter meaningful sentences
    meaningful = []
    for s in sentences:
        s = s.strip()
        # Skip very short, code-heavy, or JSON-like content
        if len(s) < 20:
            continue
        if s.startswith("{") or s.startswith("["):
            continue
        if s.count("```") > 0:
            continue
        meaningful.append(s)
        if len(meaningful) >= max_sentences:
            break

    return ". ".join(meaningful) + "." if meaningful else ""


def summarize_chunk(
    text: str,
    max_length: int | None = None,
    chunk_index: int | None = None,
    total_chunks: int | None = None,
    config: SummarizerConfig | None = None,
) -> str:
    """Generate a concise summary of a conversation chunk.

    Creates a structured summary including:
    - Chunk position context (early/middle/late)
    - What the user asked about
    - What the assistant worked on
    - Code descriptions from code blocks (if enabled)
    - Files and code referenced
    - Key topics for search

    Args:
        text: Full conversation chunk text
        max_length: Maximum summary length (overrides config if provided)
        chunk_index: 0-based index of this chunk (for position context)
        total_chunks: Total number of chunks (for position context)
        config: Summarizer configuration options

    Returns:
        Formatted summary string optimized for Claude to understand context after /clear
    """
    if not text:
        return "Empty conversation"

    # Use provided config or default
    cfg = config or DEFAULT_CONFIG

    # max_length parameter overrides config if provided
    effective_max_length = max_length if max_length is not None else cfg.max_length

    # Extract key information using config options
    keywords = extract_keywords(text, top_k=12, min_length=cfg.min_keyword_length)
    code_refs = extract_code_references(text)
    code_descriptions = extract_code_block_descriptions(text) if cfg.include_code_context else []
    position_label = get_chunk_position_label(chunk_index, total_chunks)

    # Parse conversation structure to understand user requests and assistant actions
    lines = text.split("\n")

    # Collect messages by role
    user_messages: list[str] = []
    assistant_messages: list[str] = []
    technical_details: list[str] = []

    # Look for user and assistant messages
    in_user_msg = False
    in_assistant_msg = False
    current_msg: list[str] = []

    # Define message boundary markers (order matters - check exact matches first)
    user_markers = ("[user]", "user:", "role: user", "# user")
    assistant_markers = ("[assistant]", "assistant:", "role: assistant", "# assistant")
    # Markers that indicate tool/system content to skip
    skip_markers = ("[tool_calls]", "[tool_results]", "tool_calls:", "tool_results:")

    for line in lines:
        line_stripped = line.strip()
        line_lower = line_stripped.lower()

        # Detect message boundaries
        if line_lower in user_markers or any(line_lower.startswith(m) for m in user_markers):
            # Save previous assistant message if any
            if current_msg and in_assistant_msg:
                assistant_messages.append(" ".join(current_msg))
            in_user_msg = True
            in_assistant_msg = False
            current_msg = []
        elif line_lower in assistant_markers or any(
            line_lower.startswith(m) for m in assistant_markers
        ):
            # Save previous user message if any
            if current_msg and in_user_msg:
                user_messages.append(" ".join(current_msg))
            in_assistant_msg = True
            in_user_msg = False
            current_msg = []
        elif any(line_lower.startswith(m) for m in skip_markers):
            # Save current message before skipping
            if current_msg and in_user_msg:
                user_messages.append(" ".join(current_msg))
            elif current_msg and in_assistant_msg:
                assistant_messages.append(" ".join(current_msg))
            in_user_msg = False
            in_assistant_msg = False
            current_msg = []
        elif (in_user_msg or in_assistant_msg) and line_stripped:
            current_msg.append(line_stripped[:200])

    # Add final message
    if current_msg:
        if in_user_msg:
            user_messages.append(" ".join(current_msg))
        elif in_assistant_msg:
            assistant_messages.append(" ".join(current_msg))

    # Use new extraction functions for better summaries (if enabled)
    user_questions = extract_user_questions(user_messages) if cfg.extract_questions else []
    assistant_actions = extract_assistant_actions(assistant_messages)

    # Identify key actions/topics from text
    action_indicators = [
        ("implemented", "implementation"),
        ("created", "creation"),
        ("fixed", "bug fix"),
        ("updated", "update"),
        ("added", "addition"),
        ("removed", "removal"),
        ("refactored", "refactoring"),
        ("debugging", "debugging"),
        ("tested", "testing"),
        ("optimized", "optimization"),
        ("configured", "configuration"),
        ("installed", "installation"),
        ("deployed", "deployment"),
        ("analyzed", "analysis"),
        ("reviewed", "review"),
    ]

    text_lower = text.lower()
    detected_actions = set()

    for action_word, action_noun in action_indicators:
        if action_word in text_lower:
            detected_actions.add(action_noun)

    # Extract technical context (function names, config changes, etc.)
    technical_patterns = [
        r"function[:\s]+(\w+)",
        r"class[:\s]+(\w+)",
        r"config[:\s]+(\w+)",
        r"timeout[:\s]+(\d+)",
        r"version[:\s]+([\d.]+)",
        r"port[:\s]+(\d+)",
    ]

    for pattern in technical_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        technical_details.extend(matches[:2])  # Limit per pattern

    # Build comprehensive summary with structured sections
    summary_parts = []

    # Section 0: Position context (if available)
    if position_label:
        summary_parts.append(f"[Position: {position_label}]")

    # Section 1: What user asked about (most important for retrieval)
    if user_questions:
        summary_parts.append("User asked about:")
        for q in user_questions[:3]:
            summary_parts.append(f"  - {q}")
    elif user_messages:
        # Fallback: use first sentence of user messages
        first_user = user_messages[0][:200] if user_messages else ""
        if first_user:
            summary_parts.append(f"User discussed: {first_user}")

    # Section 2: What assistant did
    if assistant_actions:
        summary_parts.append("Assistant worked on:")
        for a in assistant_actions[:3]:
            summary_parts.append(f"  - {a}")
    elif detected_actions:
        summary_parts.append(f"Actions: {', '.join(sorted(detected_actions)[:5])}")

    # Section 3: Code descriptions (from code blocks)
    if code_descriptions:
        summary_parts.append("Code context:")
        for desc in code_descriptions[:3]:
            summary_parts.append(f"  - {desc}")

    # Fallback if no structured content extracted (excluding position label)
    content_parts = [p for p in summary_parts if not p.startswith("[Position:")]
    if not content_parts:
        # Try to extract first meaningful sentences as fallback
        fallback_text = extract_first_sentences(text, max_sentences=2)
        if fallback_text:
            summary_parts.append(f"Discussion: {fallback_text}")
        elif keywords:
            summary_parts.append(f"Topics: {', '.join(keywords[:5])}")

    # Files/Output produced
    if code_refs:
        files = [ref for ref in code_refs if "." in ref]
        unique_files = list(dict.fromkeys(files))  # Preserve order, remove dupes
        if unique_files:
            summary_parts.append(f"Files referenced: {', '.join(unique_files[:5])}")

    # Technical details
    if technical_details:
        unique_details = list(dict.fromkeys(technical_details))
        summary_parts.append(f"Technical details: {', '.join(str(d) for d in unique_details[:5])}")

    # Keywords for search
    if keywords:
        summary_parts.append(f"Search keywords: {', '.join(keywords[:8])}")

    # Join and truncate if needed
    summary = "\n".join(summary_parts)
    if len(summary) > effective_max_length:
        summary = summary[:effective_max_length] + "..."

    return summary


def generate_summary_and_keywords(
    text: str,
    max_summary_length: int | None = None,
    top_k_keywords: int = 12,
    config: SummarizerConfig | None = None,
) -> tuple[str, list[str]]:
    """Generate both summary and keywords for a chunk.

    Convenience function that combines summarization and keyword extraction.

    Args:
        text: Full conversation chunk text
        max_summary_length: Maximum summary length (overrides config if provided)
        top_k_keywords: Number of keywords to extract
        config: Summarizer configuration options

    Returns:
        Tuple of (summary, keywords)
    """
    cfg = config or DEFAULT_CONFIG
    summary = summarize_chunk(text, max_length=max_summary_length, config=cfg)
    keywords = extract_keywords(text, top_k=top_k_keywords, min_length=cfg.min_keyword_length)

    # Add code references as additional keywords
    code_refs = extract_code_references(text)
    # Add unique code refs that aren't already in keywords
    for ref in code_refs[:5]:  # Limit to 5 additional
        if ref not in keywords:
            keywords.append(ref)

    return summary, keywords[: top_k_keywords + 5]  # Allow extra for code refs


def config_from_main_config(main_config: object) -> SummarizerConfig:
    """Create a SummarizerConfig from a main Config object.

    Args:
        main_config: Main config object with summarizer_* attributes

    Returns:
        SummarizerConfig instance
    """
    return SummarizerConfig(
        max_length=getattr(main_config, "summarizer_max_length", 1000),
        include_code_context=getattr(main_config, "summarizer_include_code_context", True),
        extract_questions=getattr(main_config, "summarizer_extract_questions", True),
        min_keyword_length=getattr(main_config, "summarizer_min_keyword_length", 3),
    )
