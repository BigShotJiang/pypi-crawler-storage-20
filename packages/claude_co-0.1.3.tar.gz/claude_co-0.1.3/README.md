# Claude-Co

Multi-agent coordination for Claude Code. Connect multiple AI agents working on the same codebase.

## Installation

```bash
pip install claude-co
```

## Quick Start

### 1. Install into Claude Code (one-time, automatic!)

```bash
claude-co install
```

This automatically adds claude-co to Claude Code's MCP config. You'll be prompted for your agent ID (e.g., `yourname-claude`).

**Then restart Claude Code.**

### 2. Connect to a server (per-project)

```bash
claude-co setup http://your-server:8000 sk_yourteam_... yourteam
```

Or in Claude Code, ask the agent to run:

```
setup_connection(
    url="http://your-server:8000",
    api_key="sk_yourteam_...",
    group="yourteam"
)
```

This creates a `.claude-co.json` file in your project.

### 3. Register and start collaborating

In Claude Code:

```
register_agent(name="Your Name")
```

Now you can coordinate with other agents!

## Features

- **Real-time coordination** - See what other agents are working on
- **File claims** - Prevent merge conflicts by claiming files
- **Discussions** - Resolve conflicts through structured debates
- **Status updates** - Live `status.md` file in your project
- **Learnings** - Share insights across the team

## Available Tools

### Setup
- `setup_connection()` - Connect to a server
- `register_agent()` - Join the coordination server

### Work Coordination
- `start_work()` - Declare what you're working on (checks for conflicts)
- `finish_work()` - Log completion and release file claims

### Communication
- `send_message()` - Message another agent
- `check_notifications()` - Check for new messages
- `who_is_online()` - See active team members

### File Management
- `claim_file()` - Claim a file you're editing
- `check_file()` - See if a file is claimed
- `files_being_edited()` - List all claimed files

### Discussions
- `start_discussion()` - Start a debate with other agents
- `add_to_discussion()` - Contribute to a discussion
- `request_human_input_on_discussion()` - Escalate to humans
- `resolve_discussion()` - Mark as resolved

### Awareness
- `project_summary()` - Human-readable overview
- `recent_changes()` - See recent team activity

## Configuration

The client looks for configuration in this order:

1. `.claude-co.json` in current directory (or parent directories)
2. `~/.claude-co/config.json`
3. Environment variables:
   - `COORDINATOR_URL`
   - `COORDINATOR_API_KEY`
   - `COORDINATOR_GROUP`
   - `COORDINATOR_CODEBASE`

## Setting Up a Server

See the [main repository](https://github.com/jude-hawrani/Claude-Co) for server setup instructions, including Oracle Cloud free tier deployment.

## License

MIT
