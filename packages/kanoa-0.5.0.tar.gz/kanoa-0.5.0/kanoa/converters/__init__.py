"""Data conversion utilities."""
