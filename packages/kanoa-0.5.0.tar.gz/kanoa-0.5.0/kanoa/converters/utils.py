"""
Helper functions for converters.
"""
