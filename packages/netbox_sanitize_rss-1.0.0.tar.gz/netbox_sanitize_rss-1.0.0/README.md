# NetBox Sanitize RSS

A NetBox plugin to sanitize and render HTML from RSS feeds using the [nh3](https://github.com/messense/nh3) library.

## Compatibility

| NetBox Version | Plugin Version |
|----------------|----------------|
| 4.2            | 1.0.0          |
| 4.3            | 1.0.0          |
| 4.4            | 1.0.0          |
| 4.5            | 1.0.0          |


## Installation

Install the plugin from PyPI:

```bash
pip install netbox-sanitize-rss
```

or by adding to your `local_requirements.txt` or `plugin_requirements.txt` (netbox-docker):

```bash
netbox-sanitize-rss
```

Enable the plugin in `/opt/netbox/netbox/netbox/configuration.py`,
 or if you use netbox-docker, your `/configuration/plugins.py` file :

```python
PLUGINS = [
    "netbox_sanitize_rss",
]
```

## Usage

Once installed and enabled, the plugin will automatically replace the `RSSFeedWidget` template with one that calls the `sanitize_rss` filter.

A safe subset of HTML tags are allowed. Links will have `rel="noopener noreferrer"` set.

