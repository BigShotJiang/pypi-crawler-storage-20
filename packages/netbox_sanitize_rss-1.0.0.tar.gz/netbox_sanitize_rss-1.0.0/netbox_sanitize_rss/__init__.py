from importlib.metadata import version

from netbox.plugins import PluginConfig

__version__ = version("netbox-sanitize-rss")


class SanitizeRSSConfig(PluginConfig):
    name = "netbox_sanitize_rss"
    verbose_name = "NetBox Sanitize RSS"
    version = __version__
    description = "NetBox plugin to sanitize and render HTML from RSS feeds"
    author = "Nate Cohen"
    author_email = "94263748+natecohen@users.noreply.github.com"
    min_version = "4.2.0"
    max_version = "4.5.99"

    def ready(self):
        super().ready()

        from extras.dashboard.widgets import RSSFeedWidget

        RSSFeedWidget.template_name = "netbox_sanitize_rss/rssfeed_sanitized.html"

config = SanitizeRSSConfig
