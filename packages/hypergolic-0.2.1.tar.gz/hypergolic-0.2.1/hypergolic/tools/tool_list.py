from anthropic.types import CacheControlEphemeralParam, ToolUnionParam

from hypergolic.tools.code_review.schemas import CodeReviewTool
from hypergolic.tools.command_line import CommandLineTool
from hypergolic.tools.file_explorer import FileExplorerTool
from hypergolic.tools.file_operations import FileOperationsTool
from hypergolic.tools.git import GitTool
from hypergolic.tools.merge_branch import MergeBranchTool
from hypergolic.tools.read_file import ReadFileTool
from hypergolic.tools.screenshot import ScreenshotTool
from hypergolic.tools.search_files import SearchFilesTool
from hypergolic.tools.window_management import WindowManagementTool

ALL_TOOLS: list[ToolUnionParam] = [
    CodeReviewTool,
    CommandLineTool,
    FileExplorerTool,
    FileOperationsTool,
    GitTool,
    MergeBranchTool,
    ReadFileTool,
    ScreenshotTool,
    SearchFilesTool,
    WindowManagementTool,
]
TOOL_MAP = {t["name"]: t for t in ALL_TOOLS}
CODE_REVIEW_TOOLS: list[ToolUnionParam] = [
    FileExplorerTool,
    ReadFileTool,
    SearchFilesTool,
]

EphemeralCacheControl: CacheControlEphemeralParam = {"type": "ephemeral"}
ALL_TOOLS[-1]["cache_control"] = EphemeralCacheControl
CODE_REVIEW_TOOLS[-1]["cache_control"] = EphemeralCacheControl
