"""CLI widgets for the Hypergolic TUI."""

from hypergolic.tui.widgets.diff_view import MergeDiffView
from hypergolic.tui.widgets.merge_approval import MergeApprovalScreen
from hypergolic.tui.widgets.tool_approval import (
    DenialInput,
    ParameterBox,
    ParameterDetailScreen,
    ToolApprovalResult,
    ToolApprovalScreen,
)
from hypergolic.tui.widgets.tool_status import (
    ToolCallDisplay,
    ToolDeniedStatus,
    ToolExecutingStatus,
)

__all__ = [
    # Diff/merge
    "MergeDiffView",
    "MergeApprovalScreen",
    # Tool approval
    "ToolApprovalResult",
    "ToolApprovalScreen",
    "ParameterDetailScreen",
    "ParameterBox",
    "DenialInput",
    # Tool status
    "ToolExecutingStatus",
    "ToolDeniedStatus",
    "ToolCallDisplay",
]
