import json
from datetime import datetime
from typing import Any

from rich.markup import escape
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Collapsible, Static


class ToolExecutingStatus(Static):
    DEFAULT_CSS = """
    ToolExecutingStatus {
        background: #1e2a3a;
        border: solid #22d3ee;
        padding: 0 1;
        margin: 1 0;
        height: auto;
        color: #e2e8f0;
    }
    """

    def __init__(self, tool_name: str, details: str = "", **kwargs):
        super().__init__(**kwargs)
        self.tool_name = tool_name
        self.details = details

    def render(self) -> str:
        if self.details:
            return f"⚡ Executing: {escape(self.tool_name)} - {escape(self.details)}"
        return f"⚡ Executing: {escape(self.tool_name)}"


class ToolDeniedStatus(Static):
    DEFAULT_CSS = """
    ToolDeniedStatus {
        background: #2d1f1f;
        border: solid #f87171;
        padding: 0 1;
        margin: 1 0;
        height: auto;
        color: #fca5a5;
    }
    """

    def __init__(self, tool_name: str, denial_message: str | None = None, **kwargs):
        super().__init__(**kwargs)
        self.tool_name = tool_name
        self.denial_message = denial_message

    def render(self) -> str:
        if self.denial_message:
            return f"❌ Tool denied: {escape(self.tool_name)} - {escape(self.denial_message)}"
        return f"❌ Tool denied: {escape(self.tool_name)}"


class ToolCallDisplay(Vertical):
    DEFAULT_CSS = """
    ToolCallDisplay {
        background: #1a2332;
        border: solid #4ade80;
        padding: 0 1;
        margin: 1 0;
        height: auto;
    }

    ToolCallDisplay.interrupted {
        border: solid #fbbf24;
    }

    ToolCallDisplay .tool-header {
        color: #4ade80;
        text-style: bold;
        height: 1;
        padding: 0;
    }

    ToolCallDisplay.interrupted .tool-header {
        color: #fbbf24;
    }

    ToolCallDisplay .tool-summary {
        color: #94a3b8;
        padding: 0 1;
    }

    ToolCallDisplay Collapsible {
        padding: 0;
        margin: 0;
    }

    ToolCallDisplay .tool-input {
        color: #818cf8;
        padding: 0 1;
        margin: 0;
    }

    ToolCallDisplay .tool-output {
        color: #e2e8f0;
        padding: 0 1;
        margin: 0;
        max-height: 10;
        overflow-y: auto;
    }
    """

    def __init__(
        self,
        tool_name: str,
        tool_input: dict[str, Any],
        tool_output: str,
        timestamp: datetime | None = None,
        interrupted: bool = False,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.tool_name = tool_name
        self.tool_input = tool_input
        self.tool_output = tool_output
        self.timestamp = timestamp or datetime.now()
        self.interrupted = interrupted

    def compose(self) -> ComposeResult:
        if self.interrupted:
            self.add_class("interrupted")

        time_str = self.timestamp.strftime("%I:%M:%S %p")
        icon = "⚠️" if self.interrupted else "🔧"
        yield Static(f"{icon} Tool │ {time_str}", classes="tool-header")

        summary = self._build_summary()
        yield Static(summary, classes="tool-summary")

        with Collapsible(title="Details", collapsed=True):
            input_text = self._format_input()
            yield Static(f"Input: {input_text}", classes="tool-input", markup=False)

            output_text = self._format_output()
            yield Static(f"Output: {output_text}", classes="tool-output", markup=False)

    def _build_summary(self) -> str:
        color = "yellow" if self.interrupted else "cyan"
        parts = [f"[bold {color}]{escape(self.tool_name)}[/bold {color}]"]

        if self.interrupted:
            parts.append("[yellow](interrupted)[/yellow]")

        if "cmd" in self.tool_input:
            cmd = self.tool_input["cmd"]
            if len(cmd) > 60:
                cmd = cmd[:57] + "..."
            parts.append(f"$ {escape(cmd)}")
        elif "path" in self.tool_input:
            parts.append(escape(self.tool_input["path"]))
        elif "pattern" in self.tool_input:
            parts.append(f'"{escape(self.tool_input["pattern"])}"')
        elif "operation" in self.tool_input:
            parts.append(escape(self.tool_input["operation"]))

        return " → ".join(parts)

    def _format_input(self) -> str:
        if not self.tool_input:
            return "(no parameters)"

        if len(self.tool_input) == 1:
            key, value = next(iter(self.tool_input.items()))
            if isinstance(value, str):
                return value if len(value) < 100 else value[:97] + "..."

        formatted = json.dumps(self.tool_input, indent=2)
        if len(formatted) > 200:
            formatted = formatted[:197] + "..."
        return formatted

    def _format_output(self) -> str:
        if not self.tool_output:
            return "(no output)"

        output = self.tool_output.strip()

        max_length = 500
        if len(output) > max_length:
            output = output[:max_length] + f"... ({len(self.tool_output)} chars total)"

        return output
