"""
Example: Tier-based Rate Limiting

Demonstrates how the tier system works with different user types.
"""

import vnai
import time


def example_1_check_tier():
    """Example 1: Check current tier"""
    print("\n" + "="*60)
    print("Example 1: Check Current Tier")
    print("="*60)
    
    tier_info = vnai.get_user_tier()
    print(f"\nYour tier: {tier_info['tier']}")
    print(f"Description: {tier_info['description']}")
    print(f"Rate limits:")
    print(f"  - {tier_info['limits']['per_minute']} requests/minute")
    print(f"  - {tier_info['limits']['per_hour']} requests/hour")


def example_2_rate_limiting_in_action():
    """Example 2: See rate limiting in action"""
    print("\n" + "="*60)
    print("Example 2: Rate Limiting in Action")
    print("="*60)
    
    tier_info = vnai.get_user_tier()
    limit = tier_info['limits']['per_minute']
    
    print(f"\nYour limit: {limit} requests/phút")
    print(f"Making {min(5, limit)} test requests...\n")
    
    @vnai.optimize_execution()
    def test_request(i):
        """Simulated API request"""
        time.sleep(0.01)
        return f"Request {i} completed"
    
    for i in range(min(5, limit)):
        try:
            result = test_request(i)
            print(f"  ✓ {result}")
        except Exception as e:
            print(f"  ✗ Error: {e}")
            break


def example_3_tier_comparison():
    """Example 3: Compare different tiers"""
    print("\n" + "="*60)
    print("Example 3: Tier Comparison")
    print("="*60)
    
    from vnai.beam.tier_detector import TierDetector
    
    detector = TierDetector()
    
    print("\nAll available tiers:\n")
    print(f"{'Tier':<12} {'requests/Min':<15} {'Requests/Hour':<15}")
    print("-" * 45)
    
    for tier_name, limits in detector.TIER_LIMITS.items():
        print(f"{tier_name:<12} {limits['min']:<15} {limits['hour']:<15}")
    
    current_tier = detector.get_tier()
    print(f"\n→ Your current tier: {current_tier}")


def example_4_simulate_upgrade():
    """Example 4: Simulate tier upgrade"""
    print("\n" + "="*60)
    print("Example 4: Simulate Tier Upgrade")
    print("="*60)
    
    print("\nCurrent tier:")
    tier_before = vnai.get_user_tier()
    print(f"  {tier_before['tier']} - {tier_before['limits']['per_minute']}/min")
    
    print("\n💡 To upgrade:")
    if tier_before['tier'] == 'guest':
        print("  1. Create API key at: https://vnstocks.com/account")
        print("  2. Save to ~/.vnstock/api_key.json")
        print("  3. You'll get 60 requests/minute (Free tier)")
    elif tier_before['tier'] == 'free':
        print("  1. Purchase a plan at: https://vnstocks.com/store")
        print("  2. Install vnii package")
        print("  3. Authenticate with your API key")
        print("  4. Get 120-600 requests/minute (Paid tiers)")
    else:
        print("  You're already on a paid tier!")
        print("  Consider upgrading to a higher tier for more requests.")


def example_5_manual_tier_cache():
    """Example 5: Manually write tier cache (for testing)"""
    print("\n" + "="*60)
    print("Example 5: Manual Tier Cache (Testing Only)")
    print("="*60)
    
    from vnai.beam.tier_cache_writer import write_tier_cache, read_tier_cache, clear_tier_cache
    
    print("\nCurrent cached tier:")
    cached = read_tier_cache()
    print(f"  {cached if cached else 'No cache'}")
    
    print("\n⚠️  Note: In production, vnii writes this cache automatically.")
    print("This example is for testing purposes only.\n")
    
    # Simulate writing cache
    print("Simulating premium tier cache...")
    write_tier_cache("premium", ttl_seconds=60)
    
    print("\nRefreshing tier detection...")
    vnai.refresh_tier_cache()
    
    tier_info = vnai.get_user_tier()
    print(f"Detected tier: {tier_info['tier']}")
    print(f"Limits: {tier_info['limits']['per_minute']}/min")
    
    # Clean up
    print("\nCleaning up test cache...")
    clear_tier_cache()
    vnai.refresh_tier_cache()
    
    tier_info = vnai.get_user_tier()
    print(f"Back to: {tier_info['tier']}")


def example_6_batch_processing():
    """Example 6: Batch processing with tier awareness"""
    print("\n" + "="*60)
    print("Example 6: Batch Processing with Tier Awareness")
    print("="*60)
    
    tier_info = vnai.get_user_tier()
    limit = tier_info['limits']['per_minute']
    
    print(f"\nYour limit: {limit} requests/minute")
    
    # Simulate processing many items
    items = [f"Item_{i}" for i in range(20)]
    
    @vnai.optimize_execution()
    def process_item(item):
        time.sleep(0.01)
        return f"Processed {item}"
    
    print(f"\nProcessing {len(items)} items...")
    processed = 0
    
    for item in items:
        try:
            result = process_item(item)
            processed += 1
            if processed % 5 == 0:
                print(f"  Progress: {processed}/{len(items)}")
        except Exception as e:
            print(f"\n  ⚠️  Rate limit reached after {processed} items")
            print(f"  Tip: Upgrade your tier for higher limits!")
            break
    
    print(f"\nCompleted: {processed}/{len(items)} items")


def main():
    """Run all examples"""
    print("\n" + "="*60)
    print("TIER-BASED RATE LIMITING EXAMPLES")
    print("="*60)
    
    examples = [
        example_1_check_tier,
        example_2_rate_limiting_in_action,
        example_3_tier_comparison,
        example_4_simulate_upgrade,
        example_5_manual_tier_cache,
        example_6_batch_processing,
    ]
    
    for example in examples:
        try:
            example()
            time.sleep(0.5)
        except KeyboardInterrupt:
            print("\n\nExamples interrupted by user.")
            break
        except Exception as e:
            print(f"\n✗ Example failed: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*60)
    print("Examples completed!")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
