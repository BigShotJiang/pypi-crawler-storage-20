"""
Example: API Key Setup and Tier Management

Demonstrates how to setup API key and manage user tiers.
"""

import vnai


def example_1_first_time_user():
    """Example 1: First time user (guest tier)"""
    print("\n" + "="*60)
    print("Example 1: First Time User (Guest Tier)")
    print("="*60)
    
    # Check current tier
    tier = vnai.get_user_tier()
    print(f"\nCurrent tier: {tier['tier']}")
    print(f"Description: {tier['description']}")
    print(f"Limits: {tier['limits']['per_minute']} requests/minute")
    
    if tier['tier'] == 'guest':
        print("\n💡 You're on guest tier with limited requests.")
        print("   Setup an API key to upgrade to FREE tier (60 req/min)")


def example_2_setup_api_key():
    """Example 2: Setup API key"""
    print("\n" + "="*60)
    print("Example 2: Setup API Key")
    print("="*60)
    
    # Show help
    print("\nTo get your API key:")
    print("  1. Visit: https://vnstocks.com/account")
    print("  2. Sign up or log in")
    print("  3. Copy your API key")
    
    print("\nTo setup (example):")
    print('  vnai.setup_api_key("your_api_key_here")')
    
    # Note: Don't actually setup in example
    print("\n⚠️  This is just an example. Use your real API key.")


def example_3_check_status():
    """Example 3: Check API key status"""
    print("\n" + "="*60)
    print("Example 3: Check API Key Status")
    print("="*60)
    
    status = vnai.check_api_key_status()
    
    print(f"\nHas API key: {status['has_api_key']}")
    if status['has_api_key']:
        print(f"API key preview: {status['api_key_preview']}")
    print(f"Current tier: {status['tier']}")
    print(f"Rate limits:")
    print(f"  - {status['limits']['per_minute']} requests/minute")
    print(f"  - {status['limits']['per_hour']} requests/hour")


def example_4_tier_comparison():
    """Example 4: Compare all tiers"""
    print("\n" + "="*60)
    print("Example 4: Tier Comparison")
    print("="*60)
    
    from vnai.beam.tier_detector import TierDetector
    detector = TierDetector()
    
    print("\nAll available tiers:\n")
    print(f"{'Tier':<12} {'Req/Min':<10} {'Req/Hour':<10} {'How to get':<30}")
    print("-" * 65)
    
    tier_info = {
        'guest': 'No API key',
        'free': 'Setup API key (free)',
        'starter': 'Purchase Starter plan + vnii',
        'premium': 'Purchase Premium plan + vnii',
        'enterprise': 'Purchase Enterprise plan + vnii'
    }
    
    for tier_name, limits in detector.TIER_LIMITS.items():
        how_to = tier_info.get(tier_name, '')
        print(f"{tier_name:<12} {limits['min']:<10} {limits['hour']:<10} {how_to:<30}")
    
    current = detector.get_tier()
    print(f"\n→ Your current tier: {current}")


def example_5_upgrade_path():
    """Example 5: Show upgrade path"""
    print("\n" + "="*60)
    print("Example 5: Upgrade Path")
    print("="*60)
    
    tier = vnai.get_user_tier()
    current_tier = tier['tier']
    
    print(f"\nCurrent tier: {current_tier}")
    print(f"Current limits: {tier['limits']['per_minute']} req/min")
    
    print("\n📈 Upgrade Path:")
    
    if current_tier == 'guest':
        print("\n1️⃣ GUEST → FREE (60 req/min)")
        print("   • Get API key: https://vnstocks.com/account")
        print("   • Setup: vnai.setup_api_key('your_key')")
        print("\n2️⃣ FREE → PAID (120-600 req/min)")
        print("   • Purchase plan: https://vnstocks.com/store")
        print("   • Install vnii package")
        
    elif current_tier == 'free':
        print("\n1️⃣ FREE → PAID (120-600 req/min)")
        print("   • Purchase plan: https://vnstocks.com/store")
        print("   • Install vnii package")
        print("   • Tiers: Starter (120), Premium (300), Enterprise (600)")
        
    else:
        print("\n✓ You're on a paid tier!")
        print("  Consider upgrading to a higher tier for more requests.")


def example_6_api_key_management():
    """Example 6: API key management"""
    print("\n" + "="*60)
    print("Example 6: API Key Management")
    print("="*60)
    
    # Check if has API key
    api_key = vnai.get_api_key()
    
    if api_key:
        print(f"\n✓ API key found: {api_key[:15]}...")
        print("\nManagement options:")
        print("  • View status: vnai.check_api_key_status()")
        print("  • Remove key: vnai.remove_api_key()")
    else:
        print("\n✗ No API key found")
        print("\nSetup options:")
        print("  • Setup key: vnai.setup_api_key('your_key')")
        print("  • Get help: vnai.print_api_key_help()")


def example_7_help_information():
    """Example 7: Show help information"""
    print("\n" + "="*60)
    print("Example 7: Help Information")
    print("="*60)
    
    vnai.print_api_key_help()


def main():
    """Run all examples"""
    print("\n" + "="*60)
    print("API KEY SETUP & TIER MANAGEMENT EXAMPLES")
    print("="*60)
    
    examples = [
        example_1_first_time_user,
        example_2_setup_api_key,
        example_3_check_status,
        example_4_tier_comparison,
        example_5_upgrade_path,
        example_6_api_key_management,
        example_7_help_information,
    ]
    
    for example in examples:
        try:
            example()
            input("\nPress Enter to continue...")
        except KeyboardInterrupt:
            print("\n\nExamples interrupted by user.")
            break
        except Exception as e:
            print(f"\n✗ Example failed: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*60)
    print("Examples completed!")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
