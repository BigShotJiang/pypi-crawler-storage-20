"""
API Key-based License Verification for vnai

Tích hợp với vnii để xác thực license qua API key từ file api_key.json
Hỗ trợ cả local và Google Colab (MyDrive)
"""

import json
import logging
from pathlib import Path
from typing import Optional, Dict
from datetime import datetime

logger = logging.getLogger(__name__)


class APIKeyChecker:
    """
    Kiểm tra license thông qua API key từ file api_key.json
    
    Ưu tiên tìm file:
    1. Local: ~/.vnstock/api_key.json
    2. Colab: /content/drive/MyDrive/.vnstock/api_key.json
    """
    
    _instance = None
    _lock = None
    
    def __new__(cls):
        """Singleton pattern"""
        import threading
        if cls._lock is None:
            cls._lock = threading.Lock()
            
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(APIKeyChecker, cls).__new__(cls)
                cls._instance._initialize()
            return cls._instance
    
    def _initialize(self) -> None:
        """Initialize checker"""
        self.checked = False
        self.last_check_time = None
        self.is_paid = None
        self.license_info = None
        
    def _get_vnstock_directories(self) -> list[Path]:
        """
        Lấy danh sách thư mục vnstock để tìm api_key.json
        
        Returns:
            List các Path cần kiểm tra
        """
        paths = []
        
        # 1. Local home directory
        local_path = Path.home() / ".vnstock"
        paths.append(local_path)
        
        # 2. Google Colab MyDrive
        colab_drive_path = Path('/content/drive/MyDrive/.vnstock')
        if colab_drive_path.parent.exists():
            paths.append(colab_drive_path)
        
        # 3. Dùng vnstock ggcolab nếu có
        try:
            from vnstock.core.config.ggcolab import get_vnstock_directory
            vnstock_dir = get_vnstock_directory()
            if vnstock_dir not in paths:
                paths.append(vnstock_dir)
        except ImportError:
            pass
        
        return paths
    
    def _find_api_key_file(self) -> Optional[Path]:
        """
        Tìm file api_key.json trong các thư mục vnstock
        
        Returns:
            Path đến api_key.json nếu tìm thấy, None nếu không
        """
        for vnstock_dir in self._get_vnstock_directories():
            api_key_path = vnstock_dir / "api_key.json"
            if api_key_path.exists():
                logger.debug(f"Found api_key.json at: {api_key_path}")
                return api_key_path
        
        logger.debug("api_key.json not found in any vnstock directory")
        return None
    
    def _read_api_key(self, api_key_path: Path) -> Optional[str]:
        """
        Đọc API key từ file
        
        Args:
            api_key_path: Path đến file api_key.json
            
        Returns:
            API key string hoặc None nếu lỗi
        """
        try:
            with open(api_key_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                api_key = data.get('api_key')
                
                if api_key and isinstance(api_key, str):
                    return api_key.strip()
                else:
                    logger.warning(
                        f"Invalid api_key format in {api_key_path}"
                    )
                    return None
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in {api_key_path}: {e}")
            return None
        except Exception as e:
            logger.error(f"Error reading {api_key_path}: {e}")
            return None
    
    def check_license_with_vnii(
        self,
        force: bool = False
    ) -> Dict[str, any]:
        """
        Kiểm tra license sử dụng vnii
        
        Args:
            force: Force check ngay cả khi đã check trước đó
            
        Returns:
            Dict chứa thông tin license:
            {
                'is_paid': bool,
                'status': str,
                'checked_at': str (ISO format),
                'api_key_found': bool,
                'vnii_available': bool
            }
        """
        # Nếu đã check và không force, return cache
        if self.checked and not force:
            return {
                'is_paid': self.is_paid,
                'status': 'cached',
                'checked_at': self.last_check_time,
                'api_key_found': True,
                'vnii_available': True
            }
        
        result = {
            'is_paid': False,
            'status': 'unknown',
            'checked_at': datetime.now().isoformat(),
            'api_key_found': False,
            'vnii_available': False
        }
        
        # 1. Kiểm tra vnii có available không
        try:
            from vnii import lc_init  # noqa: F401
            result['vnii_available'] = True
        except ImportError:
            logger.debug("vnii package not available")
            result['status'] = 'vnii_not_installed'
            return result
        
        # 2. Tìm file api_key.json
        api_key_path = self._find_api_key_file()
        if not api_key_path:
            logger.debug("No api_key.json found")
            result['status'] = 'no_api_key_file'
            return result
        
        # 3. Đọc API key
        api_key = self._read_api_key(api_key_path)
        if not api_key:
            logger.warning("Could not read API key from file")
            result['status'] = 'invalid_api_key_file'
            return result
        
        result['api_key_found'] = True
        
        # 4. Gọi vnii lc_init để xác thực
        try:
            # Import lại để dùng
            from vnii import lc_init
            
            # Tạm thời set env variable để vnii đọc được
            import os
            original_env = os.environ.get('VNSTOCK_API_KEY')
            os.environ['VNSTOCK_API_KEY'] = api_key
            
            try:
                license_info = lc_init(debug=False, package_name='vnai')
                
                # Parse kết quả
                status = license_info.get('status', '').lower()
                tier = license_info.get('tier', '').lower()
                
                # Xác định paid user
                is_paid = (
                    'recognized and verified' in status or
                    tier in ['bronze', 'silver', 'golden', 'gold']
                )
                
                result['is_paid'] = is_paid
                result['status'] = 'verified' if is_paid else 'free_user'
                result['license_info'] = license_info
                
                # Cache kết quả
                self.checked = True
                self.last_check_time = result['checked_at']
                self.is_paid = is_paid
                self.license_info = license_info
                
                logger.info(
                    f"License verified via vnii: "
                    f"is_paid={is_paid}, tier={tier}"
                )
                
            finally:
                # Restore env variable
                if original_env is None:
                    os.environ.pop('VNSTOCK_API_KEY', None)
                else:
                    os.environ['VNSTOCK_API_KEY'] = original_env
                    
        except SystemExit as e:
            # vnii raises SystemExit on license errors
            # Kiểm tra nếu là lỗi device limit thì vẫn coi là paid user
            # (chỉ là giới hạn số device, không phải hết license)
            error_msg = str(e)
            
            if 'device limit exceeded' in error_msg.lower():
                # Device limit nhưng vẫn là paid user
                logger.warning(f"Device limit exceeded but user is paid")
                result['status'] = 'device_limit_exceeded'
                result['is_paid'] = True  # Vẫn là paid user
                result['error'] = error_msg
                
                # Cache as paid user
                self.checked = True
                self.last_check_time = result['checked_at']
                self.is_paid = True
                self.license_info = {'status': 'Device limit', 'tier': 'paid'}
            else:
                # Lỗi license thực sự
                logger.warning(f"vnii license check failed: {e}")
                result['status'] = 'license_check_failed'
                result['error'] = error_msg
        except Exception as e:
            logger.error(f"Error calling vnii lc_init: {e}")
            result['status'] = 'error'
            result['error'] = str(e)
        
        return result
    
    def is_paid_user(self) -> Optional[bool]:
        """
        Kiểm tra xem user có phải paid user không
        
        Returns:
            - True: paid user (có license hợp lệ)
            - False: free user (không có license hoặc hết hạn)
            - None: không xác định được (chưa check hoặc lỗi)
        """
        if not self.checked:
            # Chưa check, thực hiện check
            result = self.check_license_with_vnii()
            return result.get('is_paid')
        
        return self.is_paid
    
    def get_license_info(self) -> Optional[Dict]:
        """
        Lấy thông tin chi tiết về license
        
        Returns:
            Dict chứa license info từ vnii, hoặc None nếu chưa check
        """
        return self.license_info


# Singleton instance
api_key_checker = APIKeyChecker()


def check_license_via_api_key(force: bool = False) -> Dict[str, any]:
    """
    Convenience function để check license qua API key
    
    Args:
        force: Force check ngay cả khi đã có cache
        
    Returns:
        Dict chứa kết quả check license
    """
    return api_key_checker.check_license_with_vnii(force=force)


def is_paid_user_via_api_key() -> Optional[bool]:
    """
    Convenience function để kiểm tra paid user status
    
    Returns:
        True/False/None
    """
    return api_key_checker.is_paid_user()


# License integration functions (consolidated from license_integration.py)

def check_license_status() -> Optional[bool]:
    """
    Check if user is paid using API key checker
    with graceful degradation

    Returns:
        - True if paid user
        - False if free user
        - None if cannot determine
    """
    try:
        is_paid = api_key_checker.is_paid_user()
        return is_paid
    except ImportError:
        logger.warning("API key checker not available")
        return None
    except Exception as e:
        logger.error(f"Error checking license status: {e}")
        return None


def update_license_from_vnii() -> bool:
    """
    Update license cache by checking vnii via API key

    Returns:
        True if successfully updated, False otherwise
    """
    try:
        # Force check để refresh license status
        result = api_key_checker.check_license_with_vnii(force=True)
        
        # Cập nhật cache nếu thành công
        if result.get('status') in ['verified', 'cached']:
            is_paid = result.get('is_paid', False)
            logger.info(f"License updated via API key: is_paid={is_paid}")
            return True
        else:
            logger.warning(
                f"Failed to update license: {result.get('status')}"
            )
            return False
    except Exception as e:
        logger.error(f"Error updating license from vnii: {e}")
        return False
