#!/usr/bin/env python3
"""
Test rate limit message and loop detection
"""

import sys
import time

# Test 1: Rate limit message
print("\n" + "="*60)
print("TEST 1: Rate Limit Message with Upgrade Instructions")
print("="*60)

from vnai.beam.quota import guardian, RateLimitExceeded

# Clear usage
guardian.usage_counters.clear()

# Get current tier
from vnai.beam.tier_detector import tier_detector
tier = tier_detector.get_tier(force_refresh=True)
limits = tier_detector.get_limits()

print(f"\nCurrent tier: {tier}")
print(f"Limits: {limits['min']} req/min")
print(f"\nSimulating {limits['min']} requests...")

# Make requests up to limit
for i in range(limits['min']):
    try:
        guardian.verify(f"test_{i}", "default")
        if (i + 1) % 5 == 0:
            print(f"  ✓ {i + 1} requests completed")
    except RateLimitExceeded as e:
        print(f"\n❌ Failed at request {i + 1}")
        print(str(e))
        sys.exit(1)

print(f"\n✓ All {limits['min']} requests completed")

# Try one more to trigger rate limit
print(f"\nTrying request #{limits['min'] + 1} to trigger rate limit...")
try:
    guardian.verify(f"test_{limits['min'] + 1}", "default")
    print("❌ Should have raised RateLimitExceeded!")
    sys.exit(1)
except RateLimitExceeded as e:
    print("\n✅ Rate limit triggered correctly!")
    print("\nError message:")
    print(str(e))

# Test 2: Loop detection
print("\n" + "="*60)
print("TEST 2: Loop Detection")
print("="*60)

from vnai.beam.quota import optimize

call_count = [0]

@optimize(loop_threshold=5, time_window=10, debug=True)
def test_function(i):
    call_count[0] += 1
    time.sleep(0.1)
    return f"Call {i}"

print("\nSimulating loop with 10 consecutive calls...")
print("(Should trigger loop detection after 5 calls)\n")

for i in range(10):
    result = test_function(i)
    print(f"  {i + 1}. {result}")

print(f"\n✓ Completed {call_count[0]} calls")
print("✓ Check above for loop detection messages")

print("\n" + "="*60)
print("TESTS COMPLETED")
print("="*60)
