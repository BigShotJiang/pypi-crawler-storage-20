#!/usr/bin/env python3
"""
Isolated test suite for tier system without vnii dependency.

Tests tier detection logic in isolation by mocking vnii.
"""

import os
import sys
import json
import shutil
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

sys.path.insert(0, '/Users/mrthinh/Github/vnstock_analytics/1.1. vnai - tier')

TEST_API_KEY = "vnstock_test_key_12345"


class TestEnvironment:
    """Manage isolated test environment"""
    
    def __init__(self):
        self.original_home = Path.home()
        self.temp_dir = None
        self.temp_vnstock = None
        self.original_vnstock = self.original_home / ".vnstock"
        self.backup_dir = self.original_home / ".vnstock_test_backup"
        
    def __enter__(self):
        print("\n🔧 Setting up isolated test environment...")
        
        if self.original_vnstock.exists():
            if self.backup_dir.exists():
                shutil.rmtree(self.backup_dir)
            shutil.copytree(self.original_vnstock, self.backup_dir)
            print(f"   ✓ Backed up ~/.vnstock")
        
        self.temp_dir = tempfile.mkdtemp(prefix="vnstock_test_")
        self.temp_vnstock = Path(self.temp_dir) / ".vnstock"
        self.temp_vnstock.mkdir(parents=True)
        
        if self.original_vnstock.exists():
            shutil.rmtree(self.original_vnstock)
        
        self.original_vnstock.symlink_to(self.temp_vnstock)
        print(f"   ✓ Created test .vnstock")
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print("\n🧹 Cleaning up...")
        
        if self.original_vnstock.is_symlink():
            self.original_vnstock.unlink()
        
        if self.backup_dir.exists():
            shutil.copytree(self.backup_dir, self.original_vnstock)
            shutil.rmtree(self.backup_dir)
            print(f"   ✓ Restored ~/.vnstock")
        
        if self.temp_dir and Path(self.temp_dir).exists():
            shutil.rmtree(self.temp_dir)


def test_1_guest_no_api_key():
    """Test 1: Guest tier - no API key"""
    print("\n" + "="*60)
    print("TEST 1: Guest Tier (No API Key)")
    print("="*60)
    
    # Mock vnii to not be installed
    with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
        import vnai
        from vnai.beam.tier_detector import TierDetector
        
        detector = TierDetector()
        tier = detector.get_tier(force_refresh=True)
        
        print(f"Tier: {tier}")
        assert tier == 'guest', f"Expected 'guest', got '{tier}'"
        
        tier_info = vnai.get_user_tier()
        assert tier_info['tier'] == 'guest'
        assert tier_info['limits']['per_minute'] == 10
        
    print("✅ PASSED")
    return True


def test_2_free_with_api_key():
    """Test 2: Free tier - with API key, no vnii"""
    print("\n" + "="*60)
    print("TEST 2: Free Tier (API Key, No vnii)")
    print("="*60)
    
    # Setup API key
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    api_key_file.parent.mkdir(parents=True, exist_ok=True)
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": TEST_API_KEY}, f)
    
    # Mock vnii to not be installed
    with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
        import vnai
        from vnai.beam.tier_detector import TierDetector
        
        detector = TierDetector()
        tier = detector.get_tier(force_refresh=True)
        
        print(f"Tier: {tier}")
        assert tier == 'free', f"Expected 'free', got '{tier}'"
        
        tier_info = vnai.get_user_tier()
        assert tier_info['tier'] == 'free'
        assert tier_info['limits']['per_minute'] == 60
        
    print("✅ PASSED")
    return True


def test_3_paid_with_vnii():
    """Test 3: Paid tier - with vnii installed"""
    print("\n" + "="*60)
    print("TEST 3: Paid Tier (vnii Installed)")
    print("="*60)
    
    # Setup API key
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    api_key_file.parent.mkdir(parents=True, exist_ok=True)
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": TEST_API_KEY}, f)
    
    # Mock vnii module
    mock_vnii = MagicMock()
    mock_auth = MagicMock()
    
    def mock_authenticate(vnstock_dir):
        return {
            'tier': 'premium',
            'status': 'success',
            'user': 'test_user'
        }
    
    mock_auth.authenticate = mock_authenticate
    
    with patch.dict('sys.modules', {'vnii': mock_vnii, 'vnii.auth': mock_auth}):
        import vnai
        from vnai.beam.tier_detector import TierDetector
        
        detector = TierDetector()
        tier = detector.get_tier(force_refresh=True)
        
        print(f"Tier: {tier}")
        assert tier == 'premium', f"Expected 'premium', got '{tier}'"
        
        tier_info = vnai.get_user_tier()
        assert tier_info['tier'] == 'premium'
        assert tier_info['limits']['per_minute'] == 300
        
    print("✅ PASSED")
    return True


def test_4_vnii_auth_fails():
    """Test 4: vnii installed but auth fails - fallback to free"""
    print("\n" + "="*60)
    print("TEST 4: vnii Auth Fails (Fallback to Free)")
    print("="*60)
    
    # Setup API key
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    api_key_file.parent.mkdir(parents=True, exist_ok=True)
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": TEST_API_KEY}, f)
    
    # Mock vnii that raises SystemExit
    mock_vnii = MagicMock()
    mock_auth = MagicMock()
    
    def mock_authenticate(vnstock_dir):
        raise SystemExit("Auth failed")
    
    mock_auth.authenticate = mock_authenticate
    
    with patch.dict('sys.modules', {'vnii': mock_vnii, 'vnii.auth': mock_auth}):
        import vnai
        from vnai.beam.tier_detector import TierDetector
        
        detector = TierDetector()
        tier = detector.get_tier(force_refresh=True)
        
        print(f"Tier: {tier} (fallback from failed vnii auth)")
        assert tier == 'free', f"Expected 'free', got '{tier}'"
        
    print("✅ PASSED")
    return True


def test_5_rate_limiting_guest():
    """Test 5: Rate limiting for guest (10 req/min)"""
    print("\n" + "="*60)
    print("TEST 5: Rate Limiting - Guest (10 req/min)")
    print("="*60)
    
    # Remove any API key
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    if api_key_file.exists():
        api_key_file.unlink()
    
    with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
        from vnai.beam.quota import guardian, RateLimitExceeded
        from vnai.beam.tier_detector import TierDetector
        
        # Clear usage
        guardian.usage_counters.clear()
        
        # Force guest tier
        detector = TierDetector()
        tier = detector.get_tier(force_refresh=True)
        assert tier == 'guest', f"Expected guest, got {tier}"
        
        # Test 10 requests
        success_count = 0
        for i in range(10):
            try:
                guardian.verify(f"op_{i}", "default")
                success_count += 1
            except RateLimitExceeded as e:
                print(f"Failed at request {i+1}: {e}")
                raise
        
        print(f"✓ {success_count} requests allowed")
        assert success_count == 10, f"Expected 10, got {success_count}"
        
        # 11th should fail
        try:
            guardian.verify("op_11", "default")
            assert False, "Should have raised RateLimitExceeded"
        except RateLimitExceeded as e:
            print(f"✓ 11th request blocked: {e.limit_value} limit")
            assert e.limit_value == 10, f"Expected limit 10, got {e.limit_value}"
        
    print("✅ PASSED")
    return True


def test_6_rate_limiting_free():
    """Test 6: Rate limiting for free (60 req/min)"""
    print("\n" + "="*60)
    print("TEST 6: Rate Limiting - Free (60 req/min)")
    print("="*60)
    
    # Setup API key
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    api_key_file.parent.mkdir(parents=True, exist_ok=True)
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": TEST_API_KEY}, f)
    
    with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
        from vnai.beam.quota import guardian, RateLimitExceeded
        from vnai.beam.tier_detector import TierDetector
        
        # Clear usage
        guardian.usage_counters.clear()
        
        # Force free tier
        detector = TierDetector()
        tier = detector.get_tier(force_refresh=True)
        assert tier == 'free'
        
        # Test 60 requests
        for i in range(60):
            guardian.verify(f"op_{i}", "default")
        
        print("✓ 60 requests allowed")
        
        # 61st should fail
        try:
            guardian.verify("op_61", "default")
            assert False, "Should have raised RateLimitExceeded"
        except RateLimitExceeded as e:
            print(f"✓ 61st request blocked: {e.limit_value} limit")
            assert e.limit_value == 60
        
    print("✅ PASSED")
    return True


def test_7_api_key_setup():
    """Test 7: API key setup functions"""
    print("\n" + "="*60)
    print("TEST 7: API Key Setup Functions")
    print("="*60)
    
    with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
        import vnai
        
        # Test setup
        result = vnai.setup_api_key(TEST_API_KEY)
        assert result == True
        
        api_key_file = Path.home() / ".vnstock" / "api_key.json"
        assert api_key_file.exists()
        print("✓ API key setup")
        
        # Test get
        key = vnai.get_api_key()
        assert key == TEST_API_KEY
        print("✓ API key retrieved")
        
        # Test status
        status = vnai.check_api_key_status()
        assert status['has_api_key'] == True
        assert status['tier'] == 'free'
        print("✓ Status checked")
        
        # Test remove
        result = vnai.remove_api_key()
        assert result == True
        assert not api_key_file.exists()
        print("✓ API key removed")
        
    print("✅ PASSED")
    return True


def test_8_env_var_api_key():
    """Test 8: Environment variable API key"""
    print("\n" + "="*60)
    print("TEST 8: Environment Variable API Key")
    print("="*60)
    
    os.environ['VNSTOCK_API_KEY'] = TEST_API_KEY
    
    try:
        with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
            import vnai
            from vnai.beam.tier_detector import TierDetector
            
            detector = TierDetector()
            tier = detector.get_tier(force_refresh=True)
            
            print(f"Tier: {tier}")
            assert tier == 'free', f"Expected 'free', got '{tier}'"
            
            key = vnai.get_api_key()
            assert key == TEST_API_KEY
            print("✓ Env var API key detected")
            
    finally:
        del os.environ['VNSTOCK_API_KEY']
    
    print("✅ PASSED")
    return True


def test_9_cache_mechanism():
    """Test 9: Tier cache mechanism"""
    print("\n" + "="*60)
    print("TEST 9: Cache Mechanism")
    print("="*60)
    
    import time
    
    with patch.dict('sys.modules', {'vnii': None, 'vnii.auth': None}):
        from vnai.beam.tier_detector import TierDetector
        
        detector = TierDetector()
        
        # First call
        tier1 = detector.get_tier(force_refresh=True)
        ts1 = detector._cache_timestamp
        
        # Second call (should use cache)
        time.sleep(0.1)
        tier2 = detector.get_tier(force_refresh=False)
        ts2 = detector._cache_timestamp
        
        assert ts1 == ts2, "Should use cache"
        print("✓ Cache used")
        
        # Force refresh
        time.sleep(0.1)
        tier3 = detector.get_tier(force_refresh=True)
        ts3 = detector._cache_timestamp
        
        assert ts3 > ts2, "Should refresh cache"
        print("✓ Cache refreshed")
        
    print("✅ PASSED")
    return True


def test_10_all_tiers():
    """Test 10: All tier limits"""
    print("\n" + "="*60)
    print("TEST 10: All Tier Limits")
    print("="*60)
    
    from vnai.beam.tier_detector import TierDetector
    
    detector = TierDetector()
    
    expected_tiers = {
        'guest': (10, 600),
        'free': (60, 3600),
        'golden': (120, 7200),
        'starter': (120, 7200),
        'premium': (300, 18000),
        'enterprise': (600, 36000)
    }
    
    for tier_name, (exp_min, exp_hour) in expected_tiers.items():
        limits = detector.get_limits(tier_name)
        assert limits['min'] == exp_min, f"{tier_name}: expected {exp_min}/min"
        assert limits['hour'] == exp_hour, f"{tier_name}: expected {exp_hour}/hour"
        print(f"✓ {tier_name}: {limits['min']}/min, {limits['hour']}/hour")
    
    print("✅ PASSED")
    return True


def run_all_tests():
    """Run all isolated tests"""
    print("\n" + "="*70)
    print(" "*15 + "ISOLATED TIER SYSTEM TEST SUITE")
    print("="*70)
    
    tests = [
        ("Guest Tier", test_1_guest_no_api_key),
        ("Free Tier", test_2_free_with_api_key),
        ("Paid Tier (vnii)", test_3_paid_with_vnii),
        ("vnii Auth Fails", test_4_vnii_auth_fails),
        ("Rate Limit - Guest", test_5_rate_limiting_guest),
        ("Rate Limit - Free", test_6_rate_limiting_free),
        ("API Key Setup", test_7_api_key_setup),
        ("Env Var API Key", test_8_env_var_api_key),
        ("Cache Mechanism", test_9_cache_mechanism),
        ("All Tier Limits", test_10_all_tiers),
    ]
    
    results = []
    
    with TestEnvironment():
        for name, test_func in tests:
            try:
                result = test_func()
                results.append((name, "PASSED", None))
            except AssertionError as e:
                results.append((name, "FAILED", str(e)))
                print(f"\n❌ FAILED: {e}")
            except Exception as e:
                results.append((name, "ERROR", str(e)))
                print(f"\n💥 ERROR: {e}")
                import traceback
                traceback.print_exc()
    
    # Summary
    print("\n" + "="*70)
    print(" "*25 + "TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status, _ in results if status == "PASSED")
    failed = sum(1 for _, status, _ in results if status == "FAILED")
    errors = sum(1 for _, status, _ in results if status == "ERROR")
    
    for name, status, error in results:
        icon = "✅" if status == "PASSED" else "❌" if status == "FAILED" else "💥"
        print(f"{icon} {name:<25} {status}")
        if error:
            print(f"   Error: {error}")
    
    print("\n" + "="*70)
    print(f"Total: {len(tests)} | Passed: {passed} ✅ | Failed: {failed} ❌ | Errors: {errors} 💥")
    print("="*70)
    
    return passed == len(tests)


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
