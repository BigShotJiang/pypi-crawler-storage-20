#!/usr/bin/env python3
"""
Test financial report period limiting system.

Tests:
1. Period limit enforcement (guest: 4, free: 8)
2. Period sorting (newest first)
3. Correct slicing for VCI/KBS (columns) and TCBS (index)
4. All three sources (VCI, KBS, TCBS)
"""

import sys
import pandas as pd

print("\n" + "="*80)
print("TEST: Financial Report Period Limiting")
print("="*80)

# Test 1: Period parsing and sorting
print("\n" + "-"*80)
print("TEST 1: Period Parsing and Sorting")
print("-"*80)

from vnai.beam.financial_limits import parse_period

test_periods = ['2023', '2024', '2023-Q1', '2023-Q2', '2024-Q1', '2024-Q2', '2022', '2022-Q4']

print(f"\nOriginal periods: {test_periods}")

sorted_periods = sorted(test_periods, key=parse_period, reverse=True)
print(f"Sorted (newest first): {sorted_periods}")

expected_order = ['2024', '2024-Q2', '2024-Q1', '2023', '2023-Q2', '2023-Q1', '2022', '2022-Q4']
if sorted_periods == expected_order:
    print("✅ Period sorting correct")
else:
    print(f"❌ Period sorting incorrect. Expected: {expected_order}")

# Test 2: Limit periods by columns (VCI/KBS)
print("\n" + "-"*80)
print("TEST 2: Limit Periods by Columns (VCI/KBS)")
print("-"*80)

from vnai.beam.financial_limits import limit_periods_by_columns

# Create test DataFrame with periods in columns
test_data = {
    'ticker': ['ACB', 'ACB'],
    'item': ['Total Assets', 'Current Assets'],
    '2024': [100000, 50000],
    '2024-Q2': [98000, 49000],
    '2024-Q1': [95000, 48000],
    '2023': [90000, 45000],
    '2023-Q4': [88000, 44000],
    '2023-Q3': [85000, 42000],
    '2023-Q2': [82000, 41000],
    '2023-Q1': [80000, 40000],
}
df_columns = pd.DataFrame(test_data)

print(f"\nOriginal DataFrame shape: {df_columns.shape}")
print(f"Original columns: {list(df_columns.columns)}")

# Test with 4 periods (guest tier)
df_limited_4 = limit_periods_by_columns(df_columns, max_periods=4)
print(f"\nLimited to 4 periods (guest tier):")
print(f"  Shape: {df_limited_4.shape}")
print(f"  Columns: {list(df_limited_4.columns)}")

period_cols_4 = [col for col in df_limited_4.columns if col.isdigit() or '-Q' in col]
print(f"  Period columns: {period_cols_4}")
if len(period_cols_4) == 4:
    print("  ✅ Correct number of periods")
else:
    print(f"  ❌ Wrong number of periods. Expected 4, got {len(period_cols_4)}")

# Test with 8 periods (free tier)
df_limited_8 = limit_periods_by_columns(df_columns, max_periods=8)
print(f"\nLimited to 8 periods (free tier):")
print(f"  Shape: {df_limited_8.shape}")
print(f"  Columns: {list(df_limited_8.columns)}")

period_cols_8 = [col for col in df_limited_8.columns if col.isdigit() or '-Q' in col]
print(f"  Period columns: {period_cols_8}")
if len(period_cols_8) == 8:
    print("  ✅ Correct number of periods")
else:
    print(f"  ❌ Wrong number of periods. Expected 8, got {len(period_cols_8)}")

# Test 3: Limit periods by index (TCBS)
print("\n" + "-"*80)
print("TEST 3: Limit Periods by Index (TCBS)")
print("-"*80)

from vnai.beam.financial_limits import limit_periods_by_index

# Create test DataFrame with periods in index
test_index = ['2024', '2024-Q2', '2024-Q1', '2023', '2023-Q4', '2023-Q3', '2023-Q2', '2023-Q1']
test_data_index = {
    'total_assets': [100000, 98000, 95000, 90000, 88000, 85000, 82000, 80000],
    'current_assets': [50000, 49000, 48000, 45000, 44000, 42000, 41000, 40000],
}
df_index = pd.DataFrame(test_data_index, index=test_index)
df_index.index.name = 'period'

print(f"\nOriginal DataFrame shape: {df_index.shape}")
print(f"Original index: {list(df_index.index)}")

# Test with 4 periods (guest tier)
df_limited_4_idx = limit_periods_by_index(df_index, max_periods=4)
print(f"\nLimited to 4 periods (guest tier):")
print(f"  Shape: {df_limited_4_idx.shape}")
print(f"  Index: {list(df_limited_4_idx.index)}")

if len(df_limited_4_idx) == 4:
    print("  ✅ Correct number of periods")
else:
    print(f"  ❌ Wrong number of periods. Expected 4, got {len(df_limited_4_idx)}")

# Test with 8 periods (free tier)
df_limited_8_idx = limit_periods_by_index(df_index, max_periods=8)
print(f"\nLimited to 8 periods (free tier):")
print(f"  Shape: {df_limited_8_idx.shape}")
print(f"  Index: {list(df_limited_8_idx.index)}")

if len(df_limited_8_idx) == 8:
    print("  ✅ Correct number of periods")
else:
    print(f"  ❌ Wrong number of periods. Expected 8, got {len(df_limited_8_idx)}")

# Test 4: Apply period limit (auto-detect)
print("\n" + "-"*80)
print("TEST 4: Apply Period Limit (Auto-detect)")
print("-"*80)

from vnai.beam.financial_limits import apply_period_limit

# Test with columns
df_auto_col = apply_period_limit(df_columns, by_index=False)
print(f"\nApply limit to columns-based DataFrame:")
print(f"  Original shape: {df_columns.shape}")
print(f"  Limited shape: {df_auto_col.shape}")

# Test with index
df_auto_idx = apply_period_limit(df_index, by_index=True)
print(f"\nApply limit to index-based DataFrame:")
print(f"  Original shape: {df_index.shape}")
print(f"  Limited shape: {df_auto_idx.shape}")

# Test 5: Tier-based limits
print("\n" + "-"*80)
print("TEST 5: Tier-Based Limits")
print("-"*80)

from vnai.beam.financial_limits import get_max_periods
from vnai.beam.auth import authenticator

current_tier = authenticator.get_tier()
max_periods = get_max_periods()

print(f"\nCurrent tier: {current_tier}")
print(f"Max periods allowed: {max_periods}")

if current_tier == 'guest' and max_periods == 4:
    print("✅ Guest tier limit correct (4 periods)")
elif current_tier == 'free' and max_periods == 8:
    print("✅ Free tier limit correct (8 periods)")
elif current_tier in ['bronze', 'silver', 'golden'] and max_periods is None:
    print("✅ Paid tier limit correct (unlimited)")
else:
    print(f"⚠️  Tier: {current_tier}, Max periods: {max_periods}")

# Test 6: Summary
print("\n" + "="*80)
print("TEST SUMMARY")
print("="*80)

print("\n✅ Financial Report Period Limiting Tests Completed!")
print("\nVerified:")
print("  ✓ Period parsing and sorting (newest first)")
print("  ✓ Limit periods by columns (VCI/KBS)")
print("  ✓ Limit periods by index (TCBS)")
print("  ✓ Auto-detect period location")
print("  ✓ Tier-based limits (guest: 4, free: 8, paid: unlimited)")

print("\n" + "="*80)
