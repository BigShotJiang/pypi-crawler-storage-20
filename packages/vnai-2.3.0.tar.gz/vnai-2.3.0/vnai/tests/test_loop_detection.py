#!/usr/bin/env python3
"""
Test loop detection only
"""

import sys
import time

print("\n" + "="*60)
print("TEST: Loop Detection")
print("="*60)

from vnai.beam.quota import optimize

call_count = [0]
loop_detected_count = [0]

@optimize(loop_threshold=5, time_window=10, content_trigger_threshold=1, debug=True)
def test_function(i):
    call_count[0] += 1
    time.sleep(0.05)  # Small delay
    return f"Call {i}"

print("\nSimulating loop with 15 consecutive calls...")
print("Expected behavior:")
print("  - Loop detection after 5 calls")
print("  - Content/promo trigger after 1 loop detection")
print("  - Debug messages should show loop detection\n")

for i in range(15):
    try:
        result = test_function(i)
        print(f"  {i + 1}. {result}")
    except Exception as e:
        print(f"  ✗ Error at call {i + 1}: {e}")
        break

print(f"\n✓ Completed {call_count[0]} calls")
print("\n📝 Check above for:")
print("  - '[OPTIMIZE] Đã phát hiện vòng lặp' messages")
print("  - '[OPTIMIZE] Số lần phát hiện vòng lặp liên tiếp' messages")
print("  - '[OPTIMIZE] Đã kích hoạt nội dung' messages")
print("  - Promo/content display")

print("\n" + "="*60)
