#!/usr/bin/env python3
"""
Test real scenario: User with API key (free tier) making many requests
"""

import sys
import time

print("\n" + "="*60)
print("TEST: Real Scenario - Free Tier User")
print("="*60)

from vnai.beam.quota import guardian, RateLimitExceeded
from vnai.beam.tier_detector import tier_detector

# Check current status
tier = tier_detector.get_tier(force_refresh=True)
limits = tier_detector.get_limits()

print(f"\nCurrent tier: {tier}")
print(f"Limits: {limits['min']} req/min, {limits['hour']} req/hour, {limits['day']} req/day")

# Clear usage
guardian.usage_counters.clear()

# Simulate user making 70 requests (free limit is 60)
print(f"\nSimulating 70 requests (free limit is {limits['min']} req/min)...")

success_count = 0
rate_limit_hit = False

for i in range(70):
    try:
        guardian.verify(f"request_{i}", "default")
        success_count += 1
        
        if (i + 1) % 10 == 0:
            print(f"  ✓ {i + 1} requests completed")
            
    except RateLimitExceeded as e:
        print(f"\n❌ Rate limit hit at request {i + 1}:")
        print(str(e))
        rate_limit_hit = True
        break
    except Exception as e:
        print(f"\n❌ Unexpected error at request {i + 1}: {e}")
        break

print(f"\n📊 Results:")
print(f"  • Successful requests: {success_count}")
print(f"  • Rate limit hit: {rate_limit_hit}")

if not rate_limit_hit:
    print("  ⚠️  Rate limit not hit - this might indicate:")
    print("     - Limits are higher than expected")
    print("     - Rate limiting is not enforced")
    print("     - Time window is different")

print("\n" + "="*60)
print("TEST COMPLETED")
print("="*60)
