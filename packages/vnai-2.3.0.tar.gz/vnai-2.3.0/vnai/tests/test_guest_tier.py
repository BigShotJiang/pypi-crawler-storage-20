#!/usr/bin/env python3
"""
Test Guest tier with new limits (20 req/min)
"""

import sys
import os

print("\n" + "="*60)
print("TEST: Guest Tier - New Limits")
print("="*60)

# Remove API key to force guest tier
api_key_file = os.path.expanduser("~/.vnstock/api_key.json")
if os.path.exists(api_key_file):
    os.rename(api_key_file, api_key_file + ".backup")
    print("✓ API key backed up (testing guest tier)")

from vnai.beam.quota import guardian, RateLimitExceeded
from vnai.beam.tier_detector import tier_detector

# Clear usage and force refresh
guardian.usage_counters.clear()
tier = tier_detector.get_tier(force_refresh=True)
limits = tier_detector.get_limits()

print(f"\nCurrent tier: {tier}")
print(f"Tier info: {tier_detector.get_tier_info()}")
print(f"Limits: {limits['min']} req/min, {limits['hour']} req/hour, {limits.get('day', 'N/A')} req/day")

# Make requests up to guest limit
print(f"\nMaking {limits['min']} requests...")
for i in range(limits['min']):
    try:
        guardian.verify(f"test_{i}", "default")
        if (i + 1) % 5 == 0:
            print(f"  ✓ {i + 1} requests completed")
    except RateLimitExceeded as e:
        print(f"\n❌ Failed at request {i + 1}")
        print(str(e))
        sys.exit(1)

print(f"\n✓ All {limits['min']} requests completed")

# Try one more to trigger rate limit
print(f"\nTrying request #{limits['min'] + 1} to trigger rate limit...")
try:
    guardian.verify(f"test_{limits['min'] + 1}", "default")
    print("❌ Should have raised RateLimitExceeded!")
    sys.exit(1)
except RateLimitExceeded as e:
    print("\n✅ Rate limit triggered correctly!")
    print("\n" + "="*60)
    print("ERROR MESSAGE:")
    print("="*60)
    print(str(e))

# Restore API key
if os.path.exists(api_key_file + ".backup"):
    os.rename(api_key_file + ".backup", api_key_file)
    print("\n✓ API key restored")

print("\n" + "="*60)
print("GUEST TIER TEST COMPLETED")
print("="*60)
print("\n✅ Verified:")
print("  • Guest tier: 20 requests/phút")
print("  • Correct URL: https://vnstocks.com/insiders-program")
print("  • Community-focused language")
print("  • Proper upgrade instructions")
