#!/usr/bin/env python3
"""
Comprehensive test suite for tier-based rate limiting system.

Tests all scenarios:
1. Guest tier (no API key)
2. Free tier (with API key)
3. Paid tier (with vnii - simulated)
4. API key setup/removal
5. Rate limiting enforcement
"""

import os
import sys
import json
import shutil
import tempfile
from pathlib import Path

# Add vnai to path
sys.path.insert(0, '/Users/mrthinh/Github/vnstock_analytics/1.1. vnai - tier')

TEST_API_KEY = "vnstock_a480d254cc93899a06e3ed4333e0efa9"


class TestEnvironment:
    """Manage test environment with temporary .vnstock directory"""
    
    def __init__(self):
        self.original_home = Path.home()
        self.temp_dir = None
        self.temp_vnstock = None
        self.original_vnstock = self.original_home / ".vnstock"
        self.backup_dir = self.original_home / ".vnstock_test_backup"
        
    def __enter__(self):
        """Setup test environment"""
        print("\n🔧 Setting up test environment...")
        
        # Backup original .vnstock if exists
        if self.original_vnstock.exists():
            if self.backup_dir.exists():
                shutil.rmtree(self.backup_dir)
            shutil.copytree(self.original_vnstock, self.backup_dir)
            print(f"   ✓ Backed up ~/.vnstock to {self.backup_dir}")
        
        # Create temp .vnstock for testing
        self.temp_dir = tempfile.mkdtemp(prefix="vnstock_test_")
        self.temp_vnstock = Path(self.temp_dir) / ".vnstock"
        self.temp_vnstock.mkdir(parents=True)
        
        # Remove original .vnstock temporarily
        if self.original_vnstock.exists():
            shutil.rmtree(self.original_vnstock)
        
        # Create symlink to temp .vnstock
        self.original_vnstock.symlink_to(self.temp_vnstock)
        print(f"   ✓ Created test .vnstock at {self.temp_vnstock}")
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Cleanup test environment"""
        print("\n🧹 Cleaning up test environment...")
        
        # Remove symlink
        if self.original_vnstock.is_symlink():
            self.original_vnstock.unlink()
        
        # Restore original .vnstock
        if self.backup_dir.exists():
            shutil.copytree(self.backup_dir, self.original_vnstock)
            shutil.rmtree(self.backup_dir)
            print(f"   ✓ Restored original ~/.vnstock")
        
        # Cleanup temp directory
        if self.temp_dir and Path(self.temp_dir).exists():
            shutil.rmtree(self.temp_dir)
            print(f"   ✓ Removed temp directory")


def test_1_guest_tier():
    """Test 1: Guest tier (no API key)"""
    print("\n" + "="*60)
    print("TEST 1: Guest Tier (No API Key)")
    print("="*60)
    
    import vnai
    
    # Should be guest tier
    tier_info = vnai.get_user_tier()
    
    print(f"\nTier: {tier_info['tier']}")
    print(f"Description: {tier_info['description']}")
    print(f"Limits: {tier_info['limits']}")
    
    assert tier_info['tier'] == 'guest', f"Expected 'guest', got '{tier_info['tier']}'"
    assert tier_info['limits']['per_minute'] == 10, "Guest should have 10 req/min"
    assert tier_info['limits']['per_hour'] == 600, "Guest should have 600 req/hour"
    
    # Check API key status
    status = vnai.check_api_key_status()
    assert status['has_api_key'] == False, "Guest should not have API key"
    assert status['tier'] == 'guest', "Status tier should be guest"
    
    print("\n✅ TEST 1 PASSED: Guest tier working correctly")
    return True


def test_2_setup_api_key():
    """Test 2: Setup API key"""
    print("\n" + "="*60)
    print("TEST 2: Setup API Key")
    print("="*60)
    
    import vnai
    
    # Setup API key
    print(f"\nSetting up API key: {TEST_API_KEY[:20]}...")
    result = vnai.setup_api_key(TEST_API_KEY)
    
    assert result == True, "setup_api_key should return True"
    
    # Verify file was created
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    assert api_key_file.exists(), "api_key.json should exist"
    
    # Verify content
    with open(api_key_file) as f:
        data = json.load(f)
        assert data['api_key'] == TEST_API_KEY, "API key should match"
    
    print(f"\n✓ API key file created: {api_key_file}")
    print(f"✓ Content verified")
    
    print("\n✅ TEST 2 PASSED: API key setup working correctly")
    return True


def test_3_free_tier():
    """Test 3: Free tier (with API key)"""
    print("\n" + "="*60)
    print("TEST 3: Free Tier (With API Key)")
    print("="*60)
    
    import vnai
    
    # Force refresh to detect new API key
    vnai.refresh_tier_cache()
    
    # Should be free tier now
    tier_info = vnai.get_user_tier()
    
    print(f"\nTier: {tier_info['tier']}")
    print(f"Description: {tier_info['description']}")
    print(f"Limits: {tier_info['limits']}")
    
    assert tier_info['tier'] == 'free', f"Expected 'free', got '{tier_info['tier']}'"
    assert tier_info['limits']['per_minute'] == 60, "Free should have 60 req/min"
    assert tier_info['limits']['per_hour'] == 3600, "Free should have 3600 req/hour"
    
    # Check API key status
    status = vnai.check_api_key_status()
    assert status['has_api_key'] == True, "Free should have API key"
    assert status['tier'] == 'free', "Status tier should be free"
    assert TEST_API_KEY[:15] in status['api_key_preview'], "API key preview should match"
    
    # Get API key
    api_key = vnai.get_api_key()
    assert api_key == TEST_API_KEY, "get_api_key should return correct key"
    
    print("\n✅ TEST 3 PASSED: Free tier working correctly")
    return True


def test_4_rate_limiting_guest():
    """Test 4: Rate limiting for guest tier"""
    print("\n" + "="*60)
    print("TEST 4: Rate Limiting - Guest Tier (10 req/min)")
    print("="*60)
    
    # Remove API key to become guest
    import vnai
    vnai.remove_api_key()
    vnai.refresh_tier_cache()
    
    # Verify guest tier
    tier_info = vnai.get_user_tier()
    assert tier_info['tier'] == 'guest', "Should be guest tier"
    
    print(f"\nTier: {tier_info['tier']}")
    print(f"Limit: {tier_info['limits']['per_minute']} req/min")
    
    # Test rate limiting
    from vnai.beam.quota import guardian, RateLimitExceeded
    
    # Clear any existing usage
    guardian.usage_counters.clear()
    
    print("\nTesting rate limit enforcement...")
    success_count = 0
    
    # Should allow 10 requests
    for i in range(10):
        try:
            guardian.verify(f"test_op_{i}", "default")
            success_count += 1
        except RateLimitExceeded as e:
            print(f"  ✗ Request {i+1} failed: {e}")
            break
    
    print(f"  ✓ Allowed {success_count} requests")
    assert success_count == 10, f"Should allow 10 requests, got {success_count}"
    
    # 11th request should fail
    try:
        guardian.verify("test_op_11", "default")
        assert False, "11th request should have been blocked"
    except RateLimitExceeded as e:
        print(f"  ✓ 11th request blocked: {e.limit_value} limit reached")
        assert e.limit_value == 10, "Limit should be 10"
        assert e.current_usage == 10, "Usage should be 10"
    
    print("\n✅ TEST 4 PASSED: Guest rate limiting working correctly")
    return True


def test_5_rate_limiting_free():
    """Test 5: Rate limiting for free tier"""
    print("\n" + "="*60)
    print("TEST 5: Rate Limiting - Free Tier (60 req/min)")
    print("="*60)
    
    # Setup API key to become free
    import vnai
    vnai.setup_api_key(TEST_API_KEY)
    vnai.refresh_tier_cache()
    
    # Verify free tier
    tier_info = vnai.get_user_tier()
    assert tier_info['tier'] == 'free', "Should be free tier"
    
    print(f"\nTier: {tier_info['tier']}")
    print(f"Limit: {tier_info['limits']['per_minute']} req/min")
    
    # Test rate limiting
    from vnai.beam.quota import guardian, RateLimitExceeded
    
    # Clear any existing usage
    guardian.usage_counters.clear()
    
    print("\nTesting rate limit enforcement...")
    success_count = 0
    
    # Should allow 60 requests
    for i in range(60):
        try:
            guardian.verify(f"test_op_{i}", "default")
            success_count += 1
        except RateLimitExceeded as e:
            print(f"  ✗ Request {i+1} failed: {e}")
            break
    
    print(f"  ✓ Allowed {success_count} requests")
    assert success_count == 60, f"Should allow 60 requests, got {success_count}"
    
    # 61st request should fail
    try:
        guardian.verify("test_op_61", "default")
        assert False, "61st request should have been blocked"
    except RateLimitExceeded as e:
        print(f"  ✓ 61st request blocked: {e.limit_value} limit reached")
        assert e.limit_value == 60, "Limit should be 60"
        assert e.current_usage == 60, "Usage should be 60"
    
    print("\n✅ TEST 5 PASSED: Free rate limiting working correctly")
    return True


def test_6_remove_api_key():
    """Test 6: Remove API key"""
    print("\n" + "="*60)
    print("TEST 6: Remove API Key")
    print("="*60)
    
    import vnai
    
    # Remove API key
    result = vnai.remove_api_key()
    assert result == True, "remove_api_key should return True"
    
    # Verify file was removed
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    assert not api_key_file.exists(), "api_key.json should not exist"
    
    # Verify tier downgraded to guest
    vnai.refresh_tier_cache()
    tier_info = vnai.get_user_tier()
    assert tier_info['tier'] == 'guest', "Should be guest tier after removal"
    
    print("\n✓ API key removed")
    print(f"✓ Tier downgraded to: {tier_info['tier']}")
    
    print("\n✅ TEST 6 PASSED: API key removal working correctly")
    return True


def test_7_tier_detector_logic():
    """Test 7: Tier detector internal logic"""
    print("\n" + "="*60)
    print("TEST 7: Tier Detector Internal Logic")
    print("="*60)
    
    from vnai.beam.tier_detector import TierDetector
    
    detector = TierDetector()
    
    # Test 1: No API key → guest
    print("\n1. Testing: No API key → guest")
    tier = detector.get_tier(force_refresh=True)
    print(f"   Result: {tier}")
    assert tier == 'guest', f"Expected 'guest', got '{tier}'"
    
    # Test 2: With API key → free
    print("\n2. Testing: With API key → free")
    api_key_file = detector.api_key_file
    api_key_file.parent.mkdir(parents=True, exist_ok=True)
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": TEST_API_KEY}, f)
    
    tier = detector.get_tier(force_refresh=True)
    print(f"   Result: {tier}")
    assert tier == 'free', f"Expected 'free', got '{tier}'"
    
    # Test 3: Empty API key → guest
    print("\n3. Testing: Empty API key → guest")
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": ""}, f)
    
    tier = detector.get_tier(force_refresh=True)
    print(f"   Result: {tier}")
    assert tier == 'guest', f"Expected 'guest', got '{tier}'"
    
    # Test 4: Whitespace API key → guest
    print("\n4. Testing: Whitespace API key → guest")
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": "   "}, f)
    
    tier = detector.get_tier(force_refresh=True)
    print(f"   Result: {tier}")
    assert tier == 'guest', f"Expected 'guest', got '{tier}'"
    
    # Test 5: Get limits for each tier
    print("\n5. Testing: Get limits for each tier")
    for tier_name in ['guest', 'free', 'starter', 'premium', 'enterprise']:
        limits = detector.get_limits(tier_name)
        print(f"   {tier_name}: {limits['min']}/min, {limits['hour']}/hour")
        assert 'min' in limits, f"Limits should have 'min' key"
        assert 'hour' in limits, f"Limits should have 'hour' key"
    
    print("\n✅ TEST 7 PASSED: Tier detector logic working correctly")
    return True


def test_8_cache_mechanism():
    """Test 8: Cache mechanism"""
    print("\n" + "="*60)
    print("TEST 8: Cache Mechanism")
    print("="*60)
    
    from vnai.beam.tier_detector import TierDetector
    import time
    
    detector = TierDetector()
    
    # Setup API key
    api_key_file = detector.api_key_file
    api_key_file.parent.mkdir(parents=True, exist_ok=True)
    with open(api_key_file, 'w') as f:
        json.dump({"api_key": TEST_API_KEY}, f)
    
    # First call - should detect
    print("\n1. First call (force refresh)")
    tier1 = detector.get_tier(force_refresh=True)
    timestamp1 = detector._cache_timestamp
    print(f"   Tier: {tier1}, Timestamp: {timestamp1}")
    
    # Second call - should use cache
    print("\n2. Second call (should use cache)")
    time.sleep(0.1)
    tier2 = detector.get_tier(force_refresh=False)
    timestamp2 = detector._cache_timestamp
    print(f"   Tier: {tier2}, Timestamp: {timestamp2}")
    assert timestamp1 == timestamp2, "Should use cached value"
    print("   ✓ Cache used (timestamps match)")
    
    # Third call - force refresh
    print("\n3. Third call (force refresh)")
    time.sleep(0.1)
    tier3 = detector.get_tier(force_refresh=True)
    timestamp3 = detector._cache_timestamp
    print(f"   Tier: {tier3}, Timestamp: {timestamp3}")
    assert timestamp3 > timestamp2, "Should have new timestamp"
    print("   ✓ Cache refreshed (new timestamp)")
    
    print("\n✅ TEST 8 PASSED: Cache mechanism working correctly")
    return True


def test_9_environment_variable():
    """Test 9: Environment variable API key"""
    print("\n" + "="*60)
    print("TEST 9: Environment Variable API Key")
    print("="*60)
    
    import vnai
    
    # Remove file-based API key
    api_key_file = Path.home() / ".vnstock" / "api_key.json"
    if api_key_file.exists():
        api_key_file.unlink()
    
    # Set environment variable
    os.environ['VNSTOCK_API_KEY'] = TEST_API_KEY
    
    # Should detect free tier from env var
    vnai.refresh_tier_cache()
    tier_info = vnai.get_user_tier()
    
    print(f"\nTier: {tier_info['tier']}")
    assert tier_info['tier'] == 'free', "Should be free tier with env var"
    
    # Get API key should return env var
    api_key = vnai.get_api_key()
    assert api_key == TEST_API_KEY, "Should get API key from env var"
    
    print("✓ Environment variable API key detected")
    
    # Cleanup
    del os.environ['VNSTOCK_API_KEY']
    
    print("\n✅ TEST 9 PASSED: Environment variable working correctly")
    return True


def test_10_decorator_integration():
    """Test 10: Decorator integration with tiers"""
    print("\n" + "="*60)
    print("TEST 10: Decorator Integration")
    print("="*60)
    
    import vnai
    from vnai.beam.quota import guardian
    
    # Setup as free tier
    vnai.setup_api_key(TEST_API_KEY)
    vnai.refresh_tier_cache()
    
    # Clear usage
    guardian.usage_counters.clear()
    
    # Create decorated function
    call_count = [0]
    
    @vnai.optimize_execution()
    def test_function():
        call_count[0] += 1
        return f"Call {call_count[0]}"
    
    print("\nTesting decorated function with free tier (60 req/min)...")
    
    # Should allow 60 calls
    for i in range(60):
        result = test_function()
        if (i + 1) % 10 == 0:
            print(f"  ✓ {i + 1} calls completed")
    
    assert call_count[0] == 60, f"Should have 60 calls, got {call_count[0]}"
    
    print(f"\n✓ All 60 calls completed successfully")
    print(f"✓ Decorator respecting free tier limits")
    
    print("\n✅ TEST 10 PASSED: Decorator integration working correctly")
    return True


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*70)
    print(" "*15 + "TIER SYSTEM COMPREHENSIVE TEST SUITE")
    print("="*70)
    
    tests = [
        ("Guest Tier", test_1_guest_tier),
        ("Setup API Key", test_2_setup_api_key),
        ("Free Tier", test_3_free_tier),
        ("Rate Limiting - Guest", test_4_rate_limiting_guest),
        ("Rate Limiting - Free", test_5_rate_limiting_free),
        ("Remove API Key", test_6_remove_api_key),
        ("Tier Detector Logic", test_7_tier_detector_logic),
        ("Cache Mechanism", test_8_cache_mechanism),
        ("Environment Variable", test_9_environment_variable),
        ("Decorator Integration", test_10_decorator_integration),
    ]
    
    results = []
    
    with TestEnvironment():
        for name, test_func in tests:
            try:
                result = test_func()
                results.append((name, "PASSED", None))
            except AssertionError as e:
                results.append((name, "FAILED", str(e)))
                print(f"\n❌ TEST FAILED: {e}")
            except Exception as e:
                results.append((name, "ERROR", str(e)))
                print(f"\n💥 TEST ERROR: {e}")
                import traceback
                traceback.print_exc()
    
    # Print summary
    print("\n" + "="*70)
    print(" "*25 + "TEST SUMMARY")
    print("="*70)
    
    passed = sum(1 for _, status, _ in results if status == "PASSED")
    failed = sum(1 for _, status, _ in results if status == "FAILED")
    errors = sum(1 for _, status, _ in results if status == "ERROR")
    
    for name, status, error in results:
        icon = "✅" if status == "PASSED" else "❌" if status == "FAILED" else "💥"
        print(f"{icon} {name:<30} {status}")
        if error:
            print(f"   Error: {error}")
    
    print("\n" + "="*70)
    print(f"Total: {len(tests)} tests")
    print(f"Passed: {passed} ✅")
    print(f"Failed: {failed} ❌")
    print(f"Errors: {errors} 💥")
    print("="*70)
    
    return passed == len(tests)


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
