#!/usr/bin/env python3
"""
Test message display strategy for guest and free users.

Tests:
1. Promotional message shows only for free tier (once per 24h)
2. Rate limit error always shows
3. Guest tier doesn't show promotional message
4. Message frequency control works
"""

import sys
import os
import json
import time
from pathlib import Path
from datetime import datetime, timedelta

print("\n" + "="*70)
print("TEST: Message Display Strategy")
print("="*70)

# Test 1: Message Manager Initialization
print("\n" + "-"*70)
print("TEST 1: Message Manager Initialization")
print("-"*70)

from vnai.scope.promo import manager

print(f"✓ Message manager initialized")
print(f"✓ Cache file: {manager.message_cache_file}")

# Test 2: Promotional Message for Free Tier (First Time)
print("\n" + "-"*70)
print("TEST 2: Promotional Message - Free Tier (First Time)")
print("-"*70)

# Clear cache to simulate first time
manager.message_cache = {}
manager._save_message_cache()

should_show = manager.should_show_promotional_for_rate_limit("free")
print(f"✓ Should show promotional (first time): {should_show}")
print(f"  Expected: False (need >5 min session)")

# Simulate session start
manager.message_cache["session_start"] = (datetime.now() - timedelta(minutes=10)).isoformat()
manager._save_message_cache()

should_show = manager.should_show_promotional_for_rate_limit("free")
print(f"✓ Should show promotional (after 10 min): {should_show}")
print(f"  Expected: True")

# Test 3: Promotional Message - Not Shown Again (24h Cooldown)
print("\n" + "-"*70)
print("TEST 3: Promotional Message - 24h Cooldown")
print("-"*70)

# Mark as shown
manager.mark_promotional_shown()
print(f"✓ Marked promotional as shown")

should_show = manager.should_show_promotional_for_rate_limit("free")
print(f"✓ Should show promotional (within 24h): {should_show}")
print(f"  Expected: False")

# Test 4: Promotional Message - Not Shown for Guest Tier
print("\n" + "-"*70)
print("TEST 4: Promotional Message - Guest Tier")
print("-"*70)

# Clear cache
manager.message_cache = {}
manager.message_cache["session_start"] = (datetime.now() - timedelta(minutes=10)).isoformat()
manager._save_message_cache()

should_show = manager.should_show_promotional_for_rate_limit("guest")
print(f"✓ Should show promotional (guest tier): {should_show}")
print(f"  Expected: False (guest tier never shows promotional)")

# Test 5: Promotional Message - Not Shown for Paid Tiers
print("\n" + "-"*70)
print("TEST 5: Promotional Message - Paid Tiers")
print("-"*70)

for tier in ["bronze", "silver", "golden"]:
    should_show = manager.should_show_promotional_for_rate_limit(tier)
    print(f"✓ Should show promotional ({tier}): {should_show}")
    print(f"  Expected: False (paid tiers never show promotional)")

# Test 6: Rate Limit Error with Promotional Message
print("\n" + "-"*70)
print("TEST 6: Rate Limit Error with Promotional Message")
print("-"*70)

from vnai.beam.quota import RateLimitExceeded

# Clear cache and setup for free tier
manager.message_cache = {}
manager.message_cache["session_start"] = (datetime.now() - timedelta(minutes=10)).isoformat()
manager._save_message_cache()

try:
    raise RateLimitExceeded(
        resource_type="default",
        limit_type="min",
        current_usage=60,
        limit_value=60,
        retry_after=14,
        tier="free"
    )
except RateLimitExceeded as e:
    error_msg = str(e)
    print("✓ Rate limit error with promotional message:")
    
    # Check for promotional message
    if "ĐANG BỊ CHẶN BỞI GIỚI HẠN API" in error_msg:
        print("  ✓ Promotional message included")
    else:
        print("  ✗ Promotional message NOT included")
    
    # Check for rate limit error
    if "GIỚI HẠN API ĐÃ ĐẠT TỐI ĐA" in error_msg:
        print("  ✓ Rate limit error message included")
    else:
        print("  ✗ Rate limit error message NOT included")
    
    # Check for bilingual format
    if "Rate Limit Exceeded" in error_msg:
        print("  ✓ Bilingual format (English notes)")
    else:
        print("  ✗ Bilingual format missing")

# Test 7: Rate Limit Error without Promotional (Second Time)
print("\n" + "-"*70)
print("TEST 7: Rate Limit Error - No Promotional (Second Time)")
print("-"*70)

try:
    raise RateLimitExceeded(
        resource_type="default",
        limit_type="min",
        current_usage=60,
        limit_value=60,
        retry_after=14,
        tier="free"
    )
except RateLimitExceeded as e:
    error_msg = str(e)
    print("✓ Rate limit error (second time):")
    
    # Check for promotional message (should NOT be there)
    if "ĐANG BỊ CHẶN BỞI GIỚI HẠN API" not in error_msg:
        print("  ✓ Promotional message NOT included (24h cooldown)")
    else:
        print("  ✗ Promotional message still showing (should be cooldown)")
    
    # Check for rate limit error (should still be there)
    if "GIỚI HẠN API ĐÃ ĐẠT TỐI ĐA" in error_msg:
        print("  ✓ Rate limit error message included")
    else:
        print("  ✗ Rate limit error message missing")

# Test 8: Rate Limit Error for Guest Tier (No Promotional)
print("\n" + "-"*70)
print("TEST 8: Rate Limit Error - Guest Tier (No Promotional)")
print("-"*70)

try:
    raise RateLimitExceeded(
        resource_type="default",
        limit_type="min",
        current_usage=20,
        limit_value=20,
        retry_after=14,
        tier="guest"
    )
except RateLimitExceeded as e:
    error_msg = str(e)
    print("✓ Rate limit error (guest tier):")
    
    # Check for promotional message (should NOT be there)
    if "ĐANG BỊ CHẶN BỞI GIỚI HẠN API" not in error_msg:
        print("  ✓ Promotional message NOT included (guest tier)")
    else:
        print("  ✗ Promotional message showing (guest tier should not show)")
    
    # Check for rate limit error (should still be there)
    if "GIỚI HẠN API ĐÃ ĐẠT TỐI ĐA" in error_msg:
        print("  ✓ Rate limit error message included")
    else:
        print("  ✗ Rate limit error message missing")

# Test 9: Message Content Verification
print("\n" + "-"*70)
print("TEST 9: Message Content Verification")
print("-"*70)

from vnai.scope.promo import get_promotional_message

promo_msg = get_promotional_message()
print("✓ Promotional message content:")
print(f"  - Contains '🚫 ĐANG BỊ CHẶN': {'🚫 ĐANG BỊ CHẶN' in promo_msg}")
print(f"  - Contains upgrade link: {'https://vnstocks.com/insiders-program' in promo_msg}")
print(f"  - Contains '10X tốc độ': {'10X' in promo_msg}")

# Guest tier info is managed by promo module's fallback content
print("\n✓ Guest tier info content:")
print(f"  - Managed by promo module fallback content")

# Test 10: Summary
print("\n" + "="*70)
print("TEST SUMMARY")
print("="*70)

print("\n✅ Message Strategy Tests Completed!")
print("\nVerified:")
print("  ✓ Promotional message shows only for free tier")
print("  ✓ Promotional message shows only once per 24 hours")
print("  ✓ Promotional message doesn't show for guest/paid tiers")
print("  ✓ Rate limit error always shows")
print("  ✓ Bilingual format maintained")
print("  ✓ Message content correct")
print("  ✓ Message frequency control working")

print("\n" + "="*70)
