#!/usr/bin/env python3
"""
Test final rate limit message with correct tiers and community language
"""

import sys

print("\n" + "="*60)
print("TEST: Rate Limit Message - Final Version")
print("="*60)

from vnai.beam.quota import guardian, RateLimitExceeded
from vnai.beam.tier_detector import tier_detector

# Clear usage
guardian.usage_counters.clear()

# Get current tier
tier = tier_detector.get_tier(force_refresh=True)
limits = tier_detector.get_limits()

print(f"\nCurrent tier: {tier}")
print(f"Tier info: {tier_detector.get_tier_info()}")
print(f"Limits: {limits['min']} req/min, {limits['hour']} req/hour, {limits.get('day', 'N/A')} req/day")

# Make requests up to limit
print(f"\nMaking {limits['min']} requests...")
for i in range(limits['min']):
    try:
        guardian.verify(f"test_{i}", "default")
        if (i + 1) % 10 == 0:
            print(f"  ✓ {i + 1} requests completed")
    except RateLimitExceeded as e:
        print(f"\n❌ Failed at request {i + 1}")
        print(str(e))
        sys.exit(1)

print(f"\n✓ All {limits['min']} requests completed")

# Try one more to trigger rate limit
print(f"\nTrying request #{limits['min'] + 1} to trigger rate limit...")
try:
    guardian.verify(f"test_{limits['min'] + 1}", "default")
    print("❌ Should have raised RateLimitExceeded!")
    sys.exit(1)
except RateLimitExceeded as e:
    print("\n✅ Rate limit triggered correctly!")
    print("\n" + "="*60)
    print("ERROR MESSAGE:")
    print("="*60)
    print(str(e))

print("\n" + "="*60)
print("TEST COMPLETED")
print("="*60)
print("\n✅ Verified:")
print("  • Correct tier names (Free, Bronze, Silver, Golden)")
print("  • Community-focused language")
print("  • Proper limits from API documentation")
print("  • Clear upgrade instructions")
