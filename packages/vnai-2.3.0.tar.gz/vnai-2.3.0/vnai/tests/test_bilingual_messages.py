#!/usr/bin/env python3
"""
Test all bilingual messages (Vietnamese primary + English notes)
"""

import sys
import os

print("\n" + "="*70)
print("TEST: Bilingual Messages (Tiếng Việt + English)")
print("="*70)

# Test 1: Rate Limit Message
print("\n" + "-"*70)
print("TEST 1: Rate Limit Message - Free Tier")
print("-"*70)

from vnai.beam.quota import guardian, RateLimitExceeded
from vnai.beam.tier_detector import tier_detector

# Clear and setup
guardian.usage_counters.clear()
tier = tier_detector.get_tier(force_refresh=True)
limits = tier_detector.get_limits()

print(f"\nCurrent tier: {tier}")
print(f"Limits: {limits['min']} req/min")

# Make requests to trigger rate limit
for i in range(limits['min'] + 1):
    try:
        guardian.verify(f"test_{i}", "default")
    except RateLimitExceeded as e:
        print("\n✅ Rate Limit Message:")
        print(str(e))
        break

# Test 2: Tier Info
print("\n" + "-"*70)
print("TEST 2: Tier Information")
print("-"*70)

tier_info = tier_detector.get_tier_info()
print(f"\nTier Info:")
print(f"  Tier: {tier_info['tier']}")
print(f"  Description: {tier_info['description']}")
print(f"  Limits: {tier_info['limits']}")

# Test 3: API Key Helper Functions
print("\n" + "-"*70)
print("TEST 3: API Key Helper Functions")
print("-"*70)

print("\n✅ API Key Status:")
from vnai.beam.api_key_setup import check_api_key_status
status = check_api_key_status()
print(f"  Has API key: {status['has_api_key']}")
print(f"  Tier: {status['tier']}")

print("\n✅ API Key Help:")
import vnai
vnai.print_api_key_help()

# Test 4: Guest Tier Message
print("\n" + "-"*70)
print("TEST 4: Guest Tier Rate Limit Message")
print("-"*70)

# Backup and remove API key
api_key_file = os.path.expanduser("~/.vnstock/api_key.json")
if os.path.exists(api_key_file):
    os.rename(api_key_file, api_key_file + ".backup")
    print("✓ API key backed up")

# Refresh and test guest
from importlib import reload
import vnai.beam.tier_detector
reload(vnai.beam.tier_detector)
from vnai.beam.tier_detector import tier_detector as td_guest

tier_guest = td_guest.get_tier(force_refresh=True)
limits_guest = td_guest.get_limits()

print(f"\nGuest tier: {tier_guest}")
print(f"Guest limits: {limits_guest['min']} req/min")

# Trigger rate limit for guest
guardian.usage_counters.clear()
for i in range(limits_guest['min'] + 1):
    try:
        guardian.verify(f"guest_test_{i}", "default")
    except RateLimitExceeded as e:
        print("\n✅ Guest Rate Limit Message:")
        print(str(e))
        break

# Restore API key
if os.path.exists(api_key_file + ".backup"):
    os.rename(api_key_file + ".backup", api_key_file)
    print("\n✓ API key restored")

print("\n" + "="*70)
print("TEST COMPLETED")
print("="*70)
print("\n✅ All messages verified:")
print("  • Vietnamese primary language")
print("  • English notes/translations")
print("  • Clear and user-friendly")
print("  • Proper formatting and emojis")
