# vnai/beam/fundamental.py

"""
Fundamental financial reports with tier-based period limiting.

Provides unified interface for financial reports from multiple sources (VCI, KBS, TCBS)
with automatic tier-based period limiting:
- Guest tier: 4 periods max
- Free tier: 8 periods max
- Paid tier: Unlimited

Applies limits intelligently based on data structure:
- VCI/KBS: Periods in columns (slice columns)
- TCBS: Periods in index (slice rows)
"""

import pandas as pd
from typing import Optional
from vnai.beam.auth import authenticator


# ============================================================================
# PERIOD LIMITING LOGIC
# ============================================================================

# Tier-based period limits
PERIOD_LIMITS = {
    'guest': 4,
    'free': 8,
    'bronze': None,  # Unlimited
    'silver': None,  # Unlimited
    'golden': None,  # Unlimited
}


def get_max_periods() -> Optional[int]:
    """
    Get maximum periods allowed for current tier.
    
    Returns:
        Maximum number of periods (None = unlimited)
    """
    tier = authenticator.get_tier()
    return PERIOD_LIMITS.get(tier)


def parse_period(period_str: str) -> tuple:
    """
    Parse period string to sortable tuple.
    
    Formats: '2023', '2024', '2023-Q1', '2023-Q2', etc.
    
    Returns:
        Tuple (year, quarter) for sorting
        - For years: (year, 5) - years come after quarters
        - For quarters: (year, quarter_num)
    """
    if isinstance(period_str, str):
        if '-Q' in period_str:
            year, quarter = period_str.split('-Q')
            return (int(year), int(quarter))
        elif period_str.isdigit():
            return (int(period_str), 5)  # Year comes after quarters
    
    return (0, 0)  # Fallback


def limit_periods_by_columns(df: pd.DataFrame, max_periods: Optional[int] = None) -> pd.DataFrame:
    """
    Limit periods when they are stored as columns (VCI, KBS).
    
    Args:
        df: DataFrame with period columns (e.g., '2023', '2023-Q1')
        max_periods: Maximum number of periods to keep (None = unlimited)
    
    Returns:
        DataFrame with limited periods (newest first)
    """
    if max_periods is None:
        return df
    
    # Metadata and financial column names to exclude from period detection
    metadata_cols = [
        'ticker', 'yearReport', 'lengthReport',  # VCI
        'item', 'item_en', 'item_id', 'unit', 'levels', 'row_number'  # KBS
    ]
    
    # Identify period columns (format: YYYY or YYYY-Q#)
    period_cols = []
    for col in df.columns:
        if isinstance(col, str) and col not in metadata_cols:
            # Check if it's a period column
            if col.isdigit() or (len(col) > 4 and '-Q' in col):
                period_cols.append(col)
    
    if not period_cols:
        # No period columns found, return as is
        return df
    
    # Sort periods by date (newest first)
    period_cols_sorted = sorted(period_cols, key=parse_period, reverse=True)
    
    # Keep only top N periods
    keep_periods = period_cols_sorted[:max_periods]
    
    # Get metadata and financial columns
    metadata_cols_present = [col for col in metadata_cols if col in df.columns]
    financial_cols = [col for col in df.columns if col not in metadata_cols and col not in period_cols]
    
    # Reconstruct dataframe with metadata + financial + limited periods
    final_cols = metadata_cols_present + financial_cols + keep_periods
    
    return df[final_cols]


def limit_periods_by_index(df: pd.DataFrame, max_periods: Optional[int] = None) -> pd.DataFrame:
    """
    Limit periods when they are stored as index (TCBS).
    
    Args:
        df: DataFrame with period index (e.g., '2023', '2023-Q1')
        max_periods: Maximum number of periods to keep (None = unlimited)
    
    Returns:
        DataFrame with limited periods (newest first)
    """
    if max_periods is None:
        return df
    
    # Get period index
    periods = df.index.tolist()
    
    # Sort periods by date (newest first)
    periods_sorted = sorted(periods, key=parse_period, reverse=True)
    
    # Keep only top N periods
    keep_periods = periods_sorted[:max_periods]
    
    # Filter dataframe
    return df.loc[keep_periods]


def limit_vci_periods(df: pd.DataFrame, max_periods: Optional[int] = None) -> pd.DataFrame:
    """
    Limit VCI periods by slicing rows based on yearReport + lengthReport metadata.
    
    VCI stores periods in metadata columns:
    - yearReport: 2025, 2024, 2023, ... (numeric)
    - lengthReport: 1, 2, 3, 4 (numeric quarter), or 5 (annual)
    
    API already returns data sorted by newest periods first.
    Just keep top N rows.
    
    Args:
        df: VCI DataFrame with yearReport and lengthReport columns
        max_periods: Maximum number of periods to keep (None = unlimited)
    
    Returns:
        DataFrame with limited periods (newest first)
    """
    if max_periods is None or df.empty or 'yearReport' not in df.columns:
        return df
    
    # API already returns sorted by newest periods first
    # Just keep top N rows
    df_limited = df.head(max_periods).copy()
    
    # Reset index
    df_limited = df_limited.reset_index(drop=True)
    
    return df_limited


def apply_period_limit(df: pd.DataFrame, by_index: bool = False, source: str = 'default') -> pd.DataFrame:
    """
    Apply tier-based period limit to financial DataFrame.
    
    Args:
        df: Financial report DataFrame
        by_index: If True, periods are in index (TCBS). If False, periods are in columns (VCI, KBS).
        source: Data source ('vci', 'kbs', 'tcbs', 'default')
    
    Returns:
        DataFrame with limited periods
    """
    max_periods = get_max_periods()
    
    # VCI uses metadata-based periods (yearReport, lengthReport)
    if source == 'vci' and 'yearReport' in df.columns:
        return limit_vci_periods(df, max_periods)
    elif by_index:
        return limit_periods_by_index(df, max_periods)
    else:
        return limit_periods_by_columns(df, max_periods)


# ============================================================================
# FINANCIAL REPORTS WRAPPER
# ============================================================================

class FinancialReports:
    """
    Unified financial reports interface with tier-based period limiting.
    
    Supports multiple sources: VCI, KBS, TCBS
    Automatically limits periods based on user tier.
    """
    
    def __init__(self, symbol: str, source: str = 'vci', show_log: bool = False):
        """
        Initialize financial reports wrapper.
        
        Args:
            symbol: Stock symbol (e.g., 'ACB', 'VNM')
            source: Data source ('vci', 'kbs', 'tcbs'). Default: 'vci'
            show_log: Show debug logs. Default: False
        """
        self.symbol = symbol
        self.source = source.lower()
        self.show_log = show_log
        
        # Initialize source-specific finance object (lazy import)
        if self.source == 'vci':
            from vnstock.explorer.vci import Finance as VCI_Finance
            self.finance = VCI_Finance(symbol=symbol, show_log=show_log)
            self.by_index = False  # VCI has periods in columns
        elif self.source == 'kbs':
            from vnstock.explorer.kbs import Finance as KBS_Finance
            self.finance = KBS_Finance(symbol=symbol, show_log=show_log)
            self.by_index = False  # KBS has periods in columns
        elif self.source == 'tcbs':
            from vnstock.explorer.tcbs import Finance as TCBS_Finance
            self.finance = TCBS_Finance(symbol=symbol, show_log=show_log)
            self.by_index = True  # TCBS has periods in index
        else:
            raise ValueError(f"Unsupported source: {source}. Must be 'vci', 'kbs', or 'tcbs'.")
    
    def balance_sheet(self, period: str = 'year', lang: Optional[str] = 'en', 
                     show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Get balance sheet with tier-based period limiting.
        
        Args:
            period: Report period ('year' or 'quarter'). Default: 'year'
            lang: Language ('en' or 'vi'). Default: 'en'
            show_log: Show debug logs. Default: False
        
        Returns:
            DataFrame with limited periods based on tier
        """
        # Get balance sheet from source
        if self.source == 'vci':
            df = self.finance.balance_sheet(period=period, lang=lang, show_log=show_log)
        elif self.source == 'kbs':
            df = self.finance.balance_sheet(period=period, show_log=show_log)
        elif self.source == 'tcbs':
            df = self.finance.balance_sheet(period=period, show_log=show_log)
        
        # Apply tier-based period limit
        df = apply_period_limit(df, by_index=self.by_index, source=self.source)
        
        # Show notice for guest/free users (once per session)
        if not hasattr(self, '_notice_shown'):
            self._notice_shown = False
        if not self._notice_shown:
            from vnai.beam.patching import should_show_notice, display_period_limit_notice_jupyter
            if should_show_notice():
                self._notice_shown = True
                display_period_limit_notice_jupyter()
        
        return df
    
    def income_statement(self, period: str = 'year', lang: Optional[str] = 'en',
                        show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Get income statement with tier-based period limiting.
        
        Args:
            period: Report period ('year' or 'quarter'). Default: 'year'
            lang: Language ('en' or 'vi'). Default: 'en'
            show_log: Show debug logs. Default: False
        
        Returns:
            DataFrame with limited periods based on tier
        """
        # Get income statement from source
        if self.source == 'vci':
            df = self.finance.income_statement(period=period, lang=lang, show_log=show_log)
        elif self.source == 'kbs':
            df = self.finance.income_statement(period=period, show_log=show_log)
        elif self.source == 'tcbs':
            df = self.finance.income_statement(period=period, show_log=show_log)
        
        # Apply tier-based period limit
        df = apply_period_limit(df, by_index=self.by_index, source=self.source)
        
        # Show notice for guest/free users (once per session)
        if not hasattr(self, '_notice_shown'):
            self._notice_shown = False
        if not self._notice_shown:
            from vnai.beam.patching import should_show_notice, display_period_limit_notice_jupyter
            if should_show_notice():
                self._notice_shown = True
                display_period_limit_notice_jupyter()
        
        return df
    
    def cash_flow(self, period: str = 'year', lang: Optional[str] = 'en',
                 show_log: Optional[bool] = False) -> pd.DataFrame:
        """
        Get cash flow statement with tier-based period limiting.
        
        Args:
            period: Report period ('year' or 'quarter'). Default: 'year'
            lang: Language ('en' or 'vi'). Default: 'en'
            show_log: Show debug logs. Default: False
        
        Returns:
            DataFrame with limited periods based on tier
        """
        # Get cash flow from source
        if self.source == 'vci':
            df = self.finance.cash_flow(period=period, lang=lang, show_log=show_log)
        elif self.source == 'kbs':
            df = self.finance.cash_flow(period=period, show_log=show_log)
        elif self.source == 'tcbs':
            df = self.finance.cash_flow(period=period, show_log=show_log)
        
        # Apply tier-based period limit
        df = apply_period_limit(df, by_index=self.by_index, source=self.source)
        
        # Show notice for guest/free users (once per session)
        if not hasattr(self, '_notice_shown'):
            self._notice_shown = False
        if not self._notice_shown:
            from vnai.beam.patching import should_show_notice, display_period_limit_notice_jupyter
            if should_show_notice():
                self._notice_shown = True
                display_period_limit_notice_jupyter()
        
        return df


# ============================================================================
# CONVENIENCE FUNCTIONS
# ============================================================================

def balance_sheet(symbol: str, source: str = 'vci', period: str = 'year',
                 lang: Optional[str] = 'en', show_log: bool = False) -> pd.DataFrame:
    """
    Get balance sheet with tier-based period limiting.
    
    Args:
        symbol: Stock symbol
        source: Data source ('vci', 'kbs', 'tcbs')
        period: Report period ('year' or 'quarter')
        lang: Language ('en' or 'vi')
        show_log: Show debug logs
    
    Returns:
        DataFrame with limited periods
    """
    reports = FinancialReports(symbol=symbol, source=source, show_log=show_log)
    return reports.balance_sheet(period=period, lang=lang, show_log=show_log)


def income_statement(symbol: str, source: str = 'vci', period: str = 'year',
                    lang: Optional[str] = 'en', show_log: bool = False) -> pd.DataFrame:
    """
    Get income statement with tier-based period limiting.
    
    Args:
        symbol: Stock symbol
        source: Data source ('vci', 'kbs', 'tcbs')
        period: Report period ('year' or 'quarter')
        lang: Language ('en' or 'vi')
        show_log: Show debug logs
    
    Returns:
        DataFrame with limited periods
    """
    reports = FinancialReports(symbol=symbol, source=source, show_log=show_log)
    return reports.income_statement(period=period, lang=lang, show_log=show_log)


def cash_flow(symbol: str, source: str = 'vci', period: str = 'year',
             lang: Optional[str] = 'en', show_log: bool = False) -> pd.DataFrame:
    """
    Get cash flow statement with tier-based period limiting.
    
    Args:
        symbol: Stock symbol
        source: Data source ('vci', 'kbs', 'tcbs')
        period: Report period ('year' or 'quarter')
        lang: Language ('en' or 'vi')
        show_log: Show debug logs
    
    Returns:
        DataFrame with limited periods
    """
    reports = FinancialReports(symbol=symbol, source=source, show_log=show_log)
    return reports.cash_flow(period=period, lang=lang, show_log=show_log)
