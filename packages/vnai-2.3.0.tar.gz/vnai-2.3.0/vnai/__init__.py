# vnai/__init__.py
# Main entry point for vnai package

import os
import pathlib
import json
import time
import threading
import functools
from datetime import datetime
from typing import Optional
import pandas as pd

# Lazy imports to avoid circular import issues
# These are imported only when needed, not at module level

# Constants for terms and conditions
TC_VAR = "ACCEPT_TC"
TC_VAL = "tôi đồng ý"
TC_PATH = pathlib.Path.home() / ".vnstock" / "id" / "terms_agreement.txt"

TERMS_AND_CONDITIONS = """
Khi tiếp tục sử dụng Vnstock, bạn xác nhận rằng bạn đã đọc, hiểu và đồng ý với Chính sách quyền riêng tư và Điều khoản, điều kiện về giấy phép sử dụng Vnstock.

Chi tiết:
- Giấy phép sử dụng phần mềm: https://vnstocks.com/docs/tai-lieu/giay-phep-su-dung
- Chính sách quyền riêng tư: https://vnstocks.com/docs/tai-lieu/chinh-sach-quyen-rieng-tu
"""

class Core:
    """Core functionality for system optimization"""
    
    def __init__(self):
        """Initialize core"""
        self.initialized = False
        self.webhook_url = None
        self.init_time = datetime.now().isoformat()
        self.home_dir = pathlib.Path.home()
        self.project_dir = self.home_dir / ".vnstock"
        self.id_dir = self.project_dir / 'id'
        self.terms_file_path = TC_PATH
        self.system_info = None
        
        # Create necessary directories
        self.project_dir.mkdir(exist_ok=True)
        self.id_dir.mkdir(exist_ok=True)
        
        # Auto-initialize
        self.initialize()

    def initialize(self):
        """Initialize the system"""
        if self.initialized:
            return True
            
        # Check terms acceptance
        if not self._check_terms():
            self._accept_terms()
            
        # Set up vnstock environment
        from vnai.scope.profile import inspector
        inspector.setup_vnstock_environment()
        
        # === Phase 2: Device Registration (Optimization) ===
        try:
            from vnai.scope.device import device_registry
            # Get vnstock version for re-registration detection
            vnstock_version = getattr(__import__('vnstock'),
                                      '__version__', '0.0.1')

            # Check if device needs registration
            if device_registry.needs_reregistration(vnstock_version):
                # Full system scan only on registration/version change
                system_info = inspector.examine()
                device_registry.register(system_info, vnstock_version)
                # Store for later use
                self.system_info = system_info
            else:
                # Use cached device_id (no system scan)
                self.system_info = device_registry.get_registry()
        except Exception as e:
            # Fallback: Do full system scan if device registry fails
            import logging
            logger = logging.getLogger(__name__)
            msg = f"Device registration failed: {e}. Using fallback."
            logger.warning(msg)
            self.system_info = inspector.examine()
        # === End Phase 2 ===
        
        # Display content during initialization
        from vnai.scope.promo import ContentManager
        manager = ContentManager()
        # Hiện welcome message nếu không phải paid user
        # (hoặc chưa xác định được)
        # Chỉ skip nếu chắc chắn là paid user (is_paid_user == True)
        if manager.is_paid_user is not True:
            from vnai.scope.promo import present
            present()
        
        # Record initialization
        from vnai.scope.state import record
        record("initialization", {"timestamp": datetime.now().isoformat()})
        
        # Queue system data with optimal structure
        from vnai.flow.relay import conduit
        conduit.queue({
            "type": "system_info",
            "data": {
                "commercial": inspector.detect_commercial_usage(),
                "packages": inspector.scan_packages()
            }
        }, priority="high")
        
        self.initialized = True
        
        # Trigger patching after Core initialization completes
        # This ensures period limits are enforced for direct vnstock calls
        _trigger_patching_after_init()
        
        return True

    def _check_terms(self):
        """Check if terms have been accepted"""
        return os.path.exists(self.terms_file_path)

    def _accept_terms(self):
        """Record terms acceptance"""
        # Get system information
        from vnai.scope.profile import inspector
        system_info = inspector.examine()
        
        # Auto-accept terms
        if TC_VAR in os.environ and os.environ[TC_VAR] == TC_VAL:
            os.environ[TC_VAR] = TC_VAL
        else:
            # For non-interactive environments, accept by default
            os.environ[TC_VAR] = TC_VAL
        
        # Store the acceptance with hardware info
        now = datetime.now()
        machine_id = system_info['machine_id']
        user_msg = (
            f"Người dùng có mã nhận dạng {machine_id} "
            f"đã chấp nhận "
        )
        signed_agreement = (
            f"{user_msg}"
            f"điều khoản & điều kiện sử dụng Vnstock lúc {now}\n"
            f"---\n\n"
            f"THÔNG TIN THIẾT BỊ: {json.dumps(system_info, indent=2)}\n\n"
            f"Đính kèm bản sao nội dung bạn đã đọc, "
            f"hiểu rõ và đồng ý dưới đây:\n"
            f"{TERMS_AND_CONDITIONS}"
        )
        
        # Store the acceptance
        with open(self.terms_file_path, "w", encoding="utf-8") as f:
            f.write(signed_agreement)
        
        # Create the environment.json file that vnstock expects
        env_file = self.id_dir / "environment.json"
        env_data = {
            "accepted_agreement": True,
            "timestamp": now.isoformat(),
            "machine_id": machine_id
        }
        
        with open(env_file, "w") as f:
            json.dump(env_data, f)
        
        return True

    def status(self):
        """Get system status"""
        from vnai.beam.pulse import monitor
        from vnai.scope.state import tracker
        return {
            "initialized": self.initialized,
            "health": monitor.report(),
            "metrics": tracker.get_metrics()
            # Environment information available via self.system_info
        }
    
    def configure_privacy(self, level="standard"):
        """Configure privacy settings"""
        from vnai.scope.state import tracker
        return tracker.setup_privacy(level)


# Lazy-load singleton core instance
_core_instance = None
_core_lock = threading.Lock()

def _get_core():
    """Get or create core instance (lazy loading to avoid circular imports)"""
    global _core_instance
    if _core_instance is None:
        with _core_lock:
            if _core_instance is None:
                _core_instance = Core()
    return _core_instance


# Backward support
def tc_init():
    return _get_core().initialize()


def setup():
    """Setup vnai"""
    return _get_core().initialize()


def optimize_execution(resource_type="default"):
    """Decorator for optimizing function execution"""
    from vnai.beam.quota import optimize
    return optimize(resource_type)


def agg_execution(resource_type="default"):
    """Decorator for aggregating function execution"""
    from vnai.beam.quota import optimize
    opts = optimize(resource_type, ad_cooldown=1500,
                    content_trigger_threshold=100000)
    return opts


def measure_performance(module_type="function"):
    """Decorator for measuring function performance"""
    from vnai.beam.metrics import capture
    return capture(module_type)


def accept_license_terms(terms_text=None):
    """Accept license terms and conditions"""
    if terms_text is None:
        terms_text = TERMS_AND_CONDITIONS

    # Get system information
    from vnai.scope.profile import inspector
    system_info = inspector.examine()

    # Record acceptance
    terms_file_path = (
        pathlib.Path.home() / ".vnstock" / "id" /
        "terms_agreement.txt"
    )
    os.makedirs(os.path.dirname(terms_file_path), exist_ok=True)
    
    with open(terms_file_path, "w", encoding="utf-8") as f:
        f.write(f"Terms accepted at {datetime.now().isoformat()}\n")
        f.write(f"System: {json.dumps(system_info)}\n\n")
        f.write(terms_text)
    
    return True


def accept_vnstock_terms():
    """Accept vnstock terms and create necessary files"""
    # Get system information
    from vnai.scope.profile import inspector
    system_info = inspector.examine()
    
    # Create necessary directories
    home_dir = pathlib.Path.home()
    project_dir = home_dir / ".vnstock"
    project_dir.mkdir(exist_ok=True)
    id_dir = project_dir / 'id'
    id_dir.mkdir(exist_ok=True)
    
    # Create environment.json file that vnstock looks for
    env_file = id_dir / "environment.json"
    env_data = {
        "accepted_agreement": True,
        "timestamp": datetime.now().isoformat(),
        "machine_id": system_info['machine_id']
    }
    
    try:
        with open(env_file, "w") as f:
            json.dump(env_data, f)
        print("Vnstock terms accepted successfully.")
        return True
    except Exception as e:
        print(f"Error accepting terms: {e}")
        return False


def configure_privacy(level="standard"):
    """Configure privacy level for analytics data"""
    from vnai.scope.state import tracker
    return tracker.setup_privacy(level)


def check_commercial_usage():
    """Check if running in commercial environment"""
    from vnai.scope.profile import inspector
    return inspector.detect_commercial_usage()


def authenticate_for_persistence():
    """Authenticate to Google Drive for persistent settings (Colab)"""
    from vnai.scope.profile import inspector
    return inspector.get_or_create_user_id()


def get_user_tier():
    """Get current user tier information"""
    try:
        from vnai.beam.auth import authenticator
        return authenticator.get_tier_info()
    except Exception as e:
        return {
            "tier": "guest",
            "description": "Khách (không có API key)",
            "limits": {"per_minute": 20, "per_hour": 1200},
            "error": str(e)
        }


def refresh_tier_cache():
    """Force refresh tier cache"""
    try:
        from vnai.beam.auth import authenticator
        authenticator.get_tier(force_refresh=True)
        return True
    except Exception:
        return False


def setup_api_key(api_key):
    """Setup API key for vnstock (upgrade from guest to free tier)"""
    from vnai.beam.auth import authenticator
    return authenticator.setup_api_key(api_key)


def get_api_key():
    """Get current API key if exists"""
    from vnai.beam.auth import authenticator
    return authenticator.get_api_key()


def remove_api_key():
    """Remove API key (downgrade to guest tier)"""
    from vnai.beam.auth import authenticator
    return authenticator.remove_api_key()


def check_api_key_status():
    """Check API key status and tier information"""
    from vnai.beam.auth import authenticator
    return authenticator.check_api_key_status()


def print_api_key_help():
    """Print help information about API key setup"""
    from vnai.beam.auth import authenticator
    return authenticator.print_help()


# Quota System Integration (Local Monitoring for Guest/Free Users)

def get_quota_status(api_key):
    """Get user's current quota status (local cache, no API call)
    
    Note: Only monitors guest/free users. Paid users are managed by backend.
    """
    from vnai.beam.quota_endpoint import quota_endpoint
    return quota_endpoint.get_quota_status(api_key)


def get_tier_info():
    """Get all tier information"""
    from vnai.beam.quota_endpoint import quota_endpoint
    return quota_endpoint.get_tier_info()


def check_quota_available(api_key):
    """Check if user has quota available for next request (local cache)"""
    from vnai.beam.quota_endpoint import quota_endpoint
    return quota_endpoint.check_quota(api_key)


def get_quota_metadata(api_key):
    """Get quota metadata for display (local cache, no API calls)"""
    from vnai.beam.quota_endpoint import quota_endpoint
    return quota_endpoint.get_metadata(api_key)


def record_api_usage(api_key, amount=1):
    """Record API usage for user (local cache update)"""
    from vnai.beam.quota_endpoint import quota_endpoint
    return quota_endpoint.record_usage(api_key, amount)


# Financial Reports with Tier-Based Period Limiting

def balance_sheet(symbol: str, source: str = 'vci', period: str = 'year',
                 lang: Optional[str] = 'en', show_log: bool = False) -> pd.DataFrame:
    """
    Get balance sheet with tier-based period limiting.
    
    Args:
        symbol: Stock symbol (e.g., 'SSI')
        source: Data source - 'vci' (default), 'kbs', or 'tcbs'
        period: Report period ('year' or 'quarter'). Default: 'year'
        lang: Language ('en' or 'vi'). Default: 'en'
        show_log: Show debug logs. Default: False
    
    Returns:
        DataFrame with limited periods based on tier
        - Guest tier: 4 periods max
        - Free tier: 8 periods max
        - Paid tier: Unlimited
    """
    _ensure_patches_applied()
    from vnai.beam.fundamental import balance_sheet as get_balance_sheet
    return get_balance_sheet(symbol, source=source, period=period, lang=lang, show_log=show_log)


def income_statement(symbol: str, source: str = 'vci', period: str = 'year',
                    lang: Optional[str] = 'en', show_log: bool = False) -> pd.DataFrame:
    """
    Get income statement with tier-based period limiting.
    
    Args:
        symbol: Stock symbol (e.g., 'ACB', 'VNM')
        source: Data source ('vci', 'kbs', 'tcbs'). Default: 'vci'
        period: Report period ('year' or 'quarter'). Default: 'year'
        lang: Language ('en' or 'vi'). Default: 'en'
        show_log: Show debug logs. Default: False
    
    Returns:
        DataFrame with limited periods based on tier
        - Guest tier: 4 periods max
        - Free tier: 8 periods max
        - Paid tier: Unlimited
    """
    _ensure_patches_applied()
    from vnai.beam.fundamental import income_statement as get_income_statement
    return get_income_statement(symbol, source=source, period=period, lang=lang, show_log=show_log)


def cash_flow(symbol, source='vci', period='year', lang='en', show_log=False):
    """
    Get cash flow statement with tier-based period limiting.
    
    Args:
        symbol: Stock symbol (e.g., 'ACB', 'VNM')
        source: Data source ('vci', 'kbs', 'tcbs'). Default: 'vci'
        period: Report period ('year' or 'quarter'). Default: 'year'
        lang: Language ('en' or 'vi'). Default: 'en'
        show_log: Show debug logs. Default: False
    
    Returns:
        DataFrame with limited periods based on tier
        - Guest tier: 4 periods max
        - Free tier: 8 periods max
        - Paid tier: Unlimited
    """
    _ensure_patches_applied()
    from vnai.beam.fundamental import cash_flow as get_cash_flow
    return get_cash_flow(symbol, source=source, period=period, lang=lang, show_log=show_log)


# === Patching for period limiting ===
# Patches are applied both at module load and on-demand
# This ensures period limits are enforced for both direct vnstock calls and vnai wrapper calls
_patches_initialized = False

def _ensure_patches_applied():
    """Ensure patches are applied (called on-demand from wrapper functions)."""
    global _patches_initialized
    if not _patches_initialized:
        try:
            from vnai.beam.patching import apply_all_patches
            apply_all_patches()
            _patches_initialized = True
        except Exception:
            # Silently fail if patching doesn't work
            _patches_initialized = True


# Trigger patching after Core initialization completes
# This ensures period limits are enforced even for direct vnstock calls
def _trigger_patching_after_init():
    """Trigger patching after Core initialization."""
    _ensure_patches_applied()
