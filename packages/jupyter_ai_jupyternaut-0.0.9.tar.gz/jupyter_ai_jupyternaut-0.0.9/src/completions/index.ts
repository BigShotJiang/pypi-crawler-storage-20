export { completionPlugin } from './plugin';
