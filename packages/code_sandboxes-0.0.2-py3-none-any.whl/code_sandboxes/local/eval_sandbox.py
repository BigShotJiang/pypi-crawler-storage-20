# Copyright (c) 2025-2026 Datalayer, Inc.
#
# BSD 3-Clause License

"""Local eval-based sandbox implementation.

This is a simple sandbox that uses Python's exec() for code execution.
It provides minimal isolation and is suitable for development and testing.

WARNING: This sandbox does NOT provide security isolation. Do not use
for executing untrusted code.
"""

import io
import sys
import time
import traceback
import uuid
from contextlib import redirect_stderr, redirect_stdout
from typing import Any, Optional

from ..base import Sandbox
from ..exceptions import SandboxNotStartedError, SandboxTimeoutError
from ..models import (
    Context,
    Execution,
    ExecutionError,
    Logs,
    OutputHandler,
    OutputMessage,
    Result,
    SandboxConfig,
    SandboxInfo,
)


class LocalEvalSandbox(Sandbox):
    """A simple sandbox using Python's exec() for code execution.

    This sandbox maintains separate namespaces for each context, allowing
    variable persistence between executions within the same context.

    WARNING: This provides NO security isolation. Only use for trusted code.

    Example:
        with LocalEvalSandbox() as sandbox:
            sandbox.run_code("x = 42")
            result = sandbox.run_code("print(x * 2)")  # prints 84
    """

    def __init__(self, config: Optional[SandboxConfig] = None, **kwargs):
        """Initialize the local eval sandbox.

        Args:
            config: Sandbox configuration.
            **kwargs: Additional arguments (ignored).
        """
        super().__init__(config)
        self._namespaces: dict[str, dict[str, Any]] = {}
        self._execution_count: dict[str, int] = {}
        self._sandbox_id = str(uuid.uuid4())

    def start(self) -> None:
        """Start the sandbox (initializes the default namespace)."""
        if self._started:
            return

        self._default_context = self.create_context("default")
        self._namespaces[self._default_context.id] = {"__builtins__": __builtins__}
        self._execution_count[self._default_context.id] = 0

        self._info = SandboxInfo(
            id=self._sandbox_id,
            variant="local-eval",
            status="running",
            created_at=time.time(),
            config=self.config,
        )
        self._started = True

    def stop(self) -> None:
        """Stop the sandbox (clears all namespaces)."""
        if not self._started:
            return

        self._namespaces.clear()
        self._execution_count.clear()
        self._started = False
        if self._info:
            self._info.status = "stopped"

    def create_context(self, name: Optional[str] = None) -> Context:
        """Create a new execution context with its own namespace.

        Args:
            name: Optional name for the context.

        Returns:
            A new Context object.
        """
        context = super().create_context(name)
        if context.id not in self._namespaces:
            self._namespaces[context.id] = {"__builtins__": __builtins__}
            self._execution_count[context.id] = 0
        return context

    def run_code(
        self,
        code: str,
        language: str = "python",
        context: Optional[Context] = None,
        on_stdout: Optional[OutputHandler[OutputMessage]] = None,
        on_stderr: Optional[OutputHandler[OutputMessage]] = None,
        on_result: Optional[OutputHandler[Result]] = None,
        on_error: Optional[OutputHandler[ExecutionError]] = None,
        envs: Optional[dict[str, str]] = None,
        timeout: Optional[float] = None,
    ) -> Execution:
        """Execute Python code using exec().

        Args:
            code: The Python code to execute.
            language: Must be "python" for this sandbox.
            context: Execution context (uses default if not provided).
            on_stdout: Callback for stdout messages.
            on_stderr: Callback for stderr messages.
            on_result: Callback for results.
            on_error: Callback for errors.
            envs: Environment variables (applied to os.environ temporarily).
            timeout: Timeout in seconds (not enforced in this simple implementation).

        Returns:
            Execution result.

        Raises:
            SandboxNotStartedError: If the sandbox hasn't been started.
            ValueError: If language is not "python".
        """
        if not self._started:
            raise SandboxNotStartedError()

        if language != "python":
            raise ValueError(f"LocalEvalSandbox only supports Python, got: {language}")

        # Get or create context
        ctx = context or self._default_context
        if ctx.id not in self._namespaces:
            self._namespaces[ctx.id] = {"__builtins__": __builtins__}
            self._execution_count[ctx.id] = 0

        namespace = self._namespaces[ctx.id]
        self._execution_count[ctx.id] += 1
        execution_count = self._execution_count[ctx.id]

        # Set up environment variables temporarily
        old_env = {}
        if envs:
            import os

            for key, value in envs.items():
                old_env[key] = os.environ.get(key)
                os.environ[key] = value

        # Capture stdout and stderr
        stdout_buffer = io.StringIO()
        stderr_buffer = io.StringIO()
        stdout_messages: list[OutputMessage] = []
        stderr_messages: list[OutputMessage] = []
        results: list[Result] = []
        error: Optional[ExecutionError] = None

        try:
            with redirect_stdout(stdout_buffer), redirect_stderr(stderr_buffer):
                # Try to evaluate as an expression first
                try:
                    compiled = compile(code, "<sandbox>", "eval")
                    result_value = eval(compiled, namespace)
                    if result_value is not None:
                        result = Result(
                            data={"text/plain": repr(result_value)},
                            is_main_result=True,
                        )
                        results.append(result)
                        if on_result:
                            on_result(result)
                except SyntaxError:
                    # Not an expression, execute as statements
                    exec(code, namespace)

        except Exception as e:
            # Capture the error
            tb = traceback.format_exc()
            error = ExecutionError(
                name=type(e).__name__,
                value=str(e),
                traceback=tb,
            )
            if on_error:
                on_error(error)

        finally:
            # Restore environment variables
            if envs:
                import os

                for key, old_value in old_env.items():
                    if old_value is None:
                        os.environ.pop(key, None)
                    else:
                        os.environ[key] = old_value

        # Process stdout
        stdout_content = stdout_buffer.getvalue()
        if stdout_content:
            current_time = time.time()
            for line in stdout_content.splitlines():
                msg = OutputMessage(line=line, timestamp=current_time, error=False)
                stdout_messages.append(msg)
                if on_stdout:
                    on_stdout(msg)

        # Process stderr
        stderr_content = stderr_buffer.getvalue()
        if stderr_content:
            current_time = time.time()
            for line in stderr_content.splitlines():
                msg = OutputMessage(line=line, timestamp=current_time, error=True)
                stderr_messages.append(msg)
                if on_stderr:
                    on_stderr(msg)

        return Execution(
            results=results,
            logs=Logs(stdout=stdout_messages, stderr=stderr_messages),
            error=error,
            execution_count=execution_count,
            context_id=ctx.id,
        )

    def _get_internal_variable(self, name: str, context: Optional[Context] = None) -> Any:
        """Get a variable from the namespace.

        Args:
            name: Variable name.
            context: Context to get from.

        Returns:
            The variable value.

        Raises:
            VariableNotFoundError: If variable doesn't exist.
        """
        ctx = context or self._default_context
        if ctx.id not in self._namespaces:
            from ..exceptions import VariableNotFoundError

            raise VariableNotFoundError(name)

        namespace = self._namespaces[ctx.id]
        if name not in namespace:
            from ..exceptions import VariableNotFoundError

            raise VariableNotFoundError(name)

        return namespace[name]

    def _set_internal_variable(
        self, name: str, value: Any, context: Optional[Context] = None
    ) -> None:
        """Set a variable in the namespace.

        Args:
            name: Variable name.
            value: Value to set.
            context: Context to set in.
        """
        ctx = context or self._default_context
        if ctx.id not in self._namespaces:
            self._namespaces[ctx.id] = {"__builtins__": __builtins__}

        self._namespaces[ctx.id][name] = value

    def get_variable(self, name: str, context: Optional[Context] = None) -> Any:
        """Get a variable from the sandbox.

        This is more efficient than the base class implementation as it
        directly accesses the namespace.

        Args:
            name: Variable name.
            context: Context to get from.

        Returns:
            The variable value.
        """
        return self._get_internal_variable(name, context)

    def set_variable(self, name: str, value: Any, context: Optional[Context] = None) -> None:
        """Set a variable in the sandbox.

        This is more efficient than the base class implementation as it
        directly accesses the namespace.

        Args:
            name: Variable name.
            value: Value to set.
            context: Context to set in.
        """
        self._set_internal_variable(name, value, context)
