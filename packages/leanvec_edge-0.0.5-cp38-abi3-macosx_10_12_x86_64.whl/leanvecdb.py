import uuid
import os
import leanvec_edge
import time
import math
import orjson
import struct
from typing import List, Dict, Any, Optional

class LeanVecDB:
    """
    Production-grade vector database with O(1) filtering and high-throughput operations.
    """
    
    def __init__(self, base_path: str = 'leanvec_root', auto_persist: bool = True):
        self.base_path = base_path
        self.auto_persist = auto_persist
        self.collections: Dict[str, leanvec_edge.LeanDB] = {}
        self.dimensions: Dict[str, int] = {}
        self.last_access_time = time.time()
        
        os.makedirs(base_path, exist_ok=True)
        self._load_existing_collections()
    
    def _get_col_path(self, name: str) -> str:
        return os.path.join(self.base_path, name)

    def _load_existing_collections(self):
        """Load metadata for existing collections without loading data."""
        if not os.path.exists(self.base_path):
            return
        
        for name in os.listdir(self.base_path):
            path = self._get_col_path(name)
            if os.path.isdir(path):
                cfg_path = os.path.join(path, 'config.json')
                if os.path.exists(cfg_path):
                    try:
                        with open(cfg_path, 'rb') as f:
                            config = orjson.loads(f.read())
                            self.dimensions[name] = config.get('dimension')
                    except Exception as e:
                        print(f"Warning: Could not load config for {name}: {e}")

    def _ensure_collection(self, name: str) -> leanvec_edge.LeanDB:
        """Lazy-load collection on first access."""
        self.last_access_time = time.time()
        
        if name not in self.collections:
            path = self._get_col_path(name)
            os.makedirs(path, exist_ok=True)
            
            db = leanvec_edge.LeanDB(path)
            
            # Load persisted data if exists
            self._load_persisted_data(db, name)
            
            self.collections[name] = db
        
        return self.collections[name]
    
    def _load_persisted_data(self, db: leanvec_edge.LeanDB, collection: str):
        """Load persisted vectors from disk"""
        data_path = os.path.join(self._get_col_path(collection), 'vectors.bin')
        if not os.path.exists(data_path):
            return
        
        try:
            with open(data_path, 'rb') as f:
                while True:
                    # Read ID length
                    id_len_bytes = f.read(4)
                    if not id_len_bytes or len(id_len_bytes) < 4:
                        break
                    
                    id_len = struct.unpack('I', id_len_bytes)[0]
                    doc_id = f.read(id_len).decode('utf-8')
                    
                    # Read vector length
                    vec_len = struct.unpack('I', f.read(4))[0]
                    vector_bytes = f.read(vec_len * 4)
                    vector = list(struct.unpack(f'{vec_len}f', vector_bytes))
                    
                    # Read metadata length
                    meta_len = struct.unpack('I', f.read(4))[0]
                    metadata = f.read(meta_len).decode('utf-8')
                    
                    # Read TTL
                    ttl = struct.unpack('q', f.read(8))[0]
                    ttl = ttl if ttl >= 0 else None
                    
                    # Add to database
                    db.add(doc_id, vector, metadata, ttl)
                    
        except Exception as e:
            print(f"Warning: Could not load persisted data for {collection}: {e}")
    
    def _persist_vector(self, collection: str, doc_id: str, vector: List[float], 
                       metadata: str, ttl: Optional[int] = None):
        """Append vector to persistent storage in binary format"""
        if not self.auto_persist:
            return
        
        data_path = os.path.join(self._get_col_path(collection), 'vectors.bin')
        
        try:
            id_bytes = doc_id.encode('utf-8')
            meta_bytes = metadata.encode('utf-8')
            ttl_value = ttl if ttl is not None else -1
            
            with open(data_path, 'ab') as f:
                # Write ID
                f.write(struct.pack('I', len(id_bytes)))
                f.write(id_bytes)
                
                # Write vector
                f.write(struct.pack('I', len(vector)))
                f.write(struct.pack(f'{len(vector)}f', *vector))
                
                # Write metadata
                f.write(struct.pack('I', len(meta_bytes)))
                f.write(meta_bytes)
                
                # Write TTL
                f.write(struct.pack('q', ttl_value))
        except Exception as e:
            print(f"Warning: Could not persist vector: {e}")

    def list_collections(self) -> List[str]:
        """List all available collections."""
        return list(set(list(self.collections.keys()) + list(self.dimensions.keys())))

    def store_embedding(
        self, 
        embedding: List[float], 
        metadata_dict: Optional[Dict[str, Any]] = None, 
        collection: str = "default", 
        ttl: Optional[int] = None
    ) -> str:
        """Store a single embedding with optional TTL."""
        metadatas = [metadata_dict] if metadata_dict is not None else None
        return self.store_embeddings_batch([embedding], metadatas, collection=collection, ttl=ttl)[0]

    def store_embeddings_batch(
        self, 
        embeddings: List[List[float]], 
        metadatas: Optional[List[Dict[str, Any]]] = None, 
        collection: str = "default", 
        ttl: Optional[int] = None
    ) -> List[str]:
        """Store multiple embeddings in batch."""
        if hasattr(embeddings, "tolist"):
            embeddings = embeddings.tolist()
        
        if not embeddings:
            return []
        
        db = self._ensure_collection(collection)
        input_dim = len(embeddings[0])
        
        if collection not in self.dimensions:
            self.dimensions[collection] = input_dim
            config_path = os.path.join(self._get_col_path(collection), 'config.json')
            with open(config_path, 'wb') as f:
                f.write(orjson.dumps({'dimension': input_dim}))
        elif input_dim != self.dimensions[collection]:
            raise ValueError(
                f"Dimension mismatch for collection '{collection}': "
                f"expected {self.dimensions[collection]}, got {input_dim}"
            )
        
        if metadatas is None:
            metadatas = [{} for _ in range(len(embeddings))]
        
        ids = []
        for i, vec in enumerate(embeddings):
            meta = metadatas[i] if i < len(metadatas) and metadatas[i] is not None else {}
            
            if not isinstance(meta, dict):
                meta = {}
            
            # Use integer IDs instead of UUIDs for memory efficiency
            # Only generate UUID if user explicitly provides one
            if "id" in meta or "_id" in meta:
                doc_id = str(meta.get("id") or meta.get("_id"))
            else:
                # Use sequential integer IDs (much more memory efficient)
                doc_id = str(uuid.uuid4())  # Still use UUID for external API
            
            meta["id"] = doc_id
            
            try:
                sanitized = self._sanitize_metadata(meta)
                meta_str = orjson.dumps(sanitized).decode('utf-8')
            except Exception as e:
                print(f"Warning: Failed to serialize metadata: {e}")
                meta_str = orjson.dumps({"id": doc_id}).decode('utf-8')
            
            db.add(doc_id, vec, meta_str, ttl)
            
            # Persist to disk
            self._persist_vector(collection, doc_id, vec, meta_str, ttl)
            
            ids.append(doc_id)
            
        return ids

    def _sanitize_metadata(self, meta: Any) -> Any:
        """Remove NaN/Inf values that can't be serialized."""
        if isinstance(meta, float):
            if math.isnan(meta) or math.isinf(meta):
                return None
        elif isinstance(meta, dict):
            return {k: self._sanitize_metadata(v) for k, v in meta.items()}
        elif isinstance(meta, list):
            return [self._sanitize_metadata(v) for v in meta]
        return meta
    
    def search(
        self, 
        query_embedding: List[float], 
        k: int = 5, 
        filters: Optional[Dict[str, Any]] = None, 
        collection: str = "default", 
        include_metadata: bool = True
    ) -> List[Dict[str, Any]]:
        """Search for similar vectors with optional metadata filtering."""
        db = self._ensure_collection(collection)
        
        filter_str = orjson.dumps(filters).decode('utf-8') if filters else None
        
        raw_results = db.search(query_embedding, k, filter_str, include_metadata)
        
        if include_metadata:
            return [
                {
                    "id": r[0],
                    "score": r[1],
                    "metadata": orjson.loads(r[2]) if r[2] else {}
                }
                for r in raw_results
            ]
        else:
            return [
                {"id": r[0], "score": r[1]}
                for r in raw_results
            ]

    def _calculate_autocut(self, scores: List[float]) -> Optional[int]:
        """Calculate autocut position based on score gaps"""
        if len(scores) < 2:
            return None
        
        for i in range(1, len(scores)):
            if scores[i-1] > 0:
                gap_ratio = abs(scores[i] - scores[i-1]) / scores[i-1]
                if gap_ratio > 0.2:
                    return i
        return None

    def delete(self, metadata_filter: Dict[str, Any], collection: str = "default") -> int:
        """Delete documents matching metadata filter."""
        db = self._ensure_collection(collection)
        filter_str = orjson.dumps(metadata_filter).decode('utf-8')
        return db.delete(filter_str)

    def count(self, collection: str = "default") -> int:
        """Count total documents in collection (excluding deleted)."""
        db = self._ensure_collection(collection)
        return db.count()
    
    def drop_collection(self, collection: str):
        """Delete entire collection."""
        if collection in self.collections:
            del self.collections[collection]
        if collection in self.dimensions:
            del self.dimensions[collection]
        
        import shutil
        path = self._get_col_path(collection)
        if os.path.exists(path):
            shutil.rmtree(path)