"""Application settings with environment variable support and token fallback."""

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables.

    Token fallback order: WIKI_TOKEN -> TRACKER_TOKEN
    Org ID fallback order: WIKI_ORG_ID -> TRACKER_ORG_ID
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Wiki-specific tokens (highest priority)
    wiki_token: str | None = Field(default=None, alias="WIKI_TOKEN")
    wiki_org_id: str | None = Field(default=None, alias="WIKI_ORG_ID")

    # Tracker tokens (fallback)
    tracker_token: str | None = Field(default=None, alias="TRACKER_TOKEN")
    tracker_org_id: str | None = Field(default=None, alias="TRACKER_ORG_ID")

    # API configuration
    wiki_api_base_url: str = Field(
        default="https://api.wiki.yandex.net/v1",
        alias="WIKI_API_BASE_URL",
    )
    wiki_web_base_url: str = Field(
        default="https://wiki.yandex.ru",
        alias="WIKI_WEB_BASE_URL",
    )

    # Request configuration
    request_timeout: int = Field(default=30, alias="REQUEST_TIMEOUT")

    @property
    def oauth_token(self) -> str:
        """Get OAuth token with fallback: WIKI_TOKEN -> TRACKER_TOKEN."""
        token = self.wiki_token or self.tracker_token
        if not token:
            msg = (
                "No OAuth token configured. "
                "Set WIKI_TOKEN or TRACKER_TOKEN environment variable."
            )
            raise ValueError(msg)
        return token

    @property
    def org_id(self) -> str:
        """Get organization ID with fallback: WIKI_ORG_ID -> TRACKER_ORG_ID."""
        org_id = self.wiki_org_id or self.tracker_org_id
        if not org_id:
            msg = (
                "No organization ID configured. "
                "Set WIKI_ORG_ID or TRACKER_ORG_ID environment variable."
            )
            raise ValueError(msg)
        return org_id

    @field_validator("request_timeout", mode="before")
    @classmethod
    def validate_timeout(cls, v: int | str | None) -> int:
        """Validate and convert timeout value."""
        if v is None:
            return 30
        if isinstance(v, str):
            return int(v)
        return v


# Global settings instance
_settings: Settings | None = None


def get_settings() -> Settings:
    """Get or create settings instance."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
