"""Pydantic models for Yandex Wiki page API responses."""

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class Author(BaseModel):
    """Author information for a wiki page."""

    uid: str | None = Field(default=None, description="User ID")
    login: str | None = Field(default=None, description="User login")
    display_name: str | None = Field(default=None, alias="displayName", description="Display name")


class Breadcrumb(BaseModel):
    """Breadcrumb navigation item."""

    slug: str = Field(description="Page slug/path")
    title: str = Field(description="Page title")


class PageRedirect(BaseModel):
    """Page redirect information."""

    slug: str = Field(description="Target page slug")
    is_cluster: bool = Field(default=False, alias="isCluster", description="Is cluster redirect")


class PageAttributes(BaseModel):
    """Page attributes/metadata."""

    created_at: datetime | None = Field(
        default=None, alias="createdAt", description="Creation timestamp"
    )
    modified_at: datetime | None = Field(
        default=None, alias="modifiedAt", description="Last modification timestamp"
    )
    author: Author | None = Field(default=None, description="Page author")
    modifier: Author | None = Field(default=None, description="Last modifier")
    title: str | None = Field(default=None, description="Page title")
    is_readonly: bool = Field(default=False, alias="isReadonly", description="Is read-only")


class PageInfo(BaseModel):
    """Basic page information."""

    slug: str = Field(description="Page slug/path")
    title: str | None = Field(default=None, description="Page title")


class PageResponse(BaseModel):
    """Full page response from Yandex Wiki API."""

    model_config = ConfigDict(populate_by_name=True)

    slug: str = Field(description="Page slug/path")
    title: str | None = Field(default=None, description="Page title")
    content: str | None = Field(default=None, description="Page content in markdown format")
    redirect: PageRedirect | None = Field(default=None, description="Redirect information")
    breadcrumbs: list[Breadcrumb] = Field(default_factory=list, description="Breadcrumb navigation")
    attributes: PageAttributes | None = Field(default=None, description="Page attributes")
    is_cluster: bool = Field(default=False, alias="isCluster", description="Is cluster page")
