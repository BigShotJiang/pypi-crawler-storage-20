"""Type definitions for Yandex Wiki API responses."""

from mcp_wiki.wiki.proto.types.pages import (
    Author,
    Breadcrumb,
    PageAttributes,
    PageInfo,
    PageRedirect,
    PageResponse,
)

__all__ = [
    "Author",
    "Breadcrumb",
    "PageAttributes",
    "PageInfo",
    "PageRedirect",
    "PageResponse",
]
