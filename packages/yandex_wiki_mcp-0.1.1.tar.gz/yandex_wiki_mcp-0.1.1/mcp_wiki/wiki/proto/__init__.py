"""Protocol types for Yandex Wiki API."""
