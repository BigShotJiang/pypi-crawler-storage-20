"""Wiki client module for Yandex Wiki API."""

from mcp_wiki.wiki.client import WikiClient

__all__ = ["WikiClient"]
