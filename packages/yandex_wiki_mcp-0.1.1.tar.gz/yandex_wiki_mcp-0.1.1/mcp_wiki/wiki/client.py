"""Async HTTP client for Yandex Wiki API."""

from typing import Any, ClassVar

import aiohttp
import structlog

from mcp_wiki.settings import Settings, get_settings
from mcp_wiki.wiki.proto.types.pages import PageResponse

logger = structlog.get_logger(__name__)


class WikiApiError(Exception):
    """Base exception for Wiki API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        """Initialize API error."""
        super().__init__(message)
        self.status_code = status_code


class PageNotFoundError(WikiApiError):
    """Page not found error (404)."""

    def __init__(self, slug: str, is_redirect_hint: bool = False) -> None:
        """Initialize page not found error."""
        message = f"Page not found: {slug}"
        if is_redirect_hint:
            message += (
                ". Note: Yandex Wiki API does not follow redirects automatically. "
                "The page may exist but be a redirect to another location."
            )
        super().__init__(message, status_code=404)
        self.slug = slug
        self.is_redirect_hint = is_redirect_hint


class WikiClient:
    """Async client for Yandex Wiki API.

    Uses a shared aiohttp.ClientSession for connection pooling.
    """

    _session: ClassVar[aiohttp.ClientSession | None] = None

    def __init__(self, settings: Settings | None = None) -> None:
        """Initialize Wiki client.

        Args:
            settings: Application settings. If None, uses global settings.
        """
        self._settings = settings or get_settings()
        self._log = logger.bind(component="wiki_client")

    @classmethod
    def _get_session(cls) -> aiohttp.ClientSession:
        """Get or create shared aiohttp session."""
        if cls._session is None or cls._session.closed:
            timeout = aiohttp.ClientTimeout(total=30)
            cls._session = aiohttp.ClientSession(timeout=timeout)
        return cls._session

    @classmethod
    async def close_session(cls) -> None:
        """Close the shared session."""
        if cls._session and not cls._session.closed:
            await cls._session.close()
            cls._session = None

    def _get_headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"OAuth {self._settings.oauth_token}",
            "X-Org-ID": self._settings.org_id,
            "Accept": "application/json",
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request to Wiki API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters

        Returns:
            Response JSON as dictionary

        Raises:
            WikiApiError: On API errors
            PageNotFoundError: When page is not found (404)
        """
        url = f"{self._settings.wiki_api_base_url}{endpoint}"
        session = self._get_session()

        self._log.debug("wiki_api_request", method=method, url=url, params=params)

        try:
            async with session.request(
                method=method,
                url=url,
                headers=self._get_headers(),
                params=params,
            ) as response:
                if response.status == 404:
                    slug = params.get("slug", "unknown") if params else "unknown"
                    raise PageNotFoundError(slug=str(slug), is_redirect_hint=True)

                if response.status >= 400:
                    text = await response.text()
                    self._log.error(
                        "wiki_api_error",
                        status=response.status,
                        response=text,
                    )
                    raise WikiApiError(
                        f"API request failed with status {response.status}: {text}",
                        status_code=response.status,
                    )

                data: dict[str, Any] = await response.json()
                self._log.debug("wiki_api_response", status=response.status)
                return data

        except aiohttp.ClientError as e:
            self._log.error("wiki_api_connection_error", error=str(e))
            raise WikiApiError(f"Connection error: {e}") from e

    async def get_page(
        self,
        slug: str,
        include_content: bool = True,
        include_attributes: bool = True,
        include_breadcrumbs: bool = False,
        include_redirect: bool = True,
    ) -> PageResponse:
        """Get wiki page by slug.

        Args:
            slug: Page path (e.g., 'users/homepage' or 'teams/dev/docs')
            include_content: Include page content in response
            include_attributes: Include page attributes (author, dates, etc.)
            include_breadcrumbs: Include breadcrumb navigation
            include_redirect: Include redirect information

        Returns:
            PageResponse with page data

        Raises:
            PageNotFoundError: When page is not found
            WikiApiError: On other API errors
        """
        fields: list[str] = []
        if include_content:
            fields.append("content")
        if include_attributes:
            fields.append("attributes")
        if include_breadcrumbs:
            fields.append("breadcrumbs")
        if include_redirect:
            fields.append("redirect")

        params: dict[str, str] = {"slug": slug}
        if fields:
            params["fields"] = ",".join(fields)

        self._log.info("get_page", slug=slug, fields=fields)

        data = await self._request("GET", "/pages", params=params)
        return PageResponse.model_validate(data)

    def get_page_url(self, slug: str) -> str:
        """Get web URL for a wiki page.

        Args:
            slug: Page path

        Returns:
            Full URL to the page in Yandex Wiki web interface
        """
        # Remove leading slash if present
        clean_slug = slug.lstrip("/")
        return f"{self._settings.wiki_web_base_url}/{clean_slug}"
