"""Context and dependency injection for MCP tools."""

from mcp_wiki.settings import Settings, get_settings
from mcp_wiki.wiki.client import WikiClient


def get_wiki_client(settings: Settings | None = None) -> WikiClient:
    """Get Wiki client instance.

    Args:
        settings: Optional settings override

    Returns:
        WikiClient instance
    """
    return WikiClient(settings=settings or get_settings())
