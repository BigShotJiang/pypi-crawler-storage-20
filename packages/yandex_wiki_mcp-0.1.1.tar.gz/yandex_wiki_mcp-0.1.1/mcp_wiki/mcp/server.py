"""FastMCP server with Yandex Wiki tools."""

import structlog
from fastmcp import FastMCP

from mcp_wiki.mcp.context import get_wiki_client
from mcp_wiki.mcp.errors import format_error_response
from mcp_wiki.wiki.client import WikiClient

logger = structlog.get_logger(__name__)

# Create MCP server instance
mcp = FastMCP(
    name="yandex-wiki",
    instructions=(
        "Yandex Wiki MCP Server provides read-only access to corporate wiki pages. "
        "Use page_get to fetch page content by slug (path from URL). "
        "Use page_get_url to get the web URL for a page."
    ),
)


@mcp.tool
async def page_get(
    slug: str,
    include_content: bool = True,
    include_attributes: bool = True,
    include_breadcrumbs: bool = False,
) -> str:
    """Fetch a wiki page by its slug (path).

    Args:
        slug: Page path from URL (e.g., 'users/homepage' or 'teams/dev/docs').
              Do not include leading slash.
        include_content: Include page content (markdown). Default: True.
        include_attributes: Include metadata (author, dates). Default: True.
        include_breadcrumbs: Include breadcrumb navigation. Default: False.

    Returns:
        Page content and metadata as formatted text.

    Note:
        Yandex Wiki API does not follow redirects automatically.
        If you get a 404 error, the page might be a redirect.
        Check the exact path in the Yandex Wiki web interface.
    """
    logger.info("page_get_called", slug=slug)

    try:
        client = get_wiki_client()
        page = await client.get_page(
            slug=slug,
            include_content=include_content,
            include_attributes=include_attributes,
            include_breadcrumbs=include_breadcrumbs,
        )

        # Format response
        result_parts: list[str] = []

        # Title
        title = page.title or page.slug
        result_parts.append(f"# {title}")
        result_parts.append("")

        # Web URL
        web_url = client.get_page_url(slug)
        result_parts.append(f"**URL:** {web_url}")
        result_parts.append("")

        # Attributes
        if page.attributes:
            result_parts.append("## Metadata")
            if page.attributes.author:
                author_name = page.attributes.author.display_name or page.attributes.author.login
                result_parts.append(f"- **Author:** {author_name}")
            if page.attributes.created_at:
                result_parts.append(f"- **Created:** {page.attributes.created_at.isoformat()}")
            if page.attributes.modified_at:
                result_parts.append(f"- **Modified:** {page.attributes.modified_at.isoformat()}")
            if page.attributes.modifier:
                modifier_name = (
                    page.attributes.modifier.display_name or page.attributes.modifier.login
                )
                result_parts.append(f"- **Last modified by:** {modifier_name}")
            if page.attributes.is_readonly:
                result_parts.append("- **Read-only:** Yes")
            result_parts.append("")

        # Breadcrumbs
        if include_breadcrumbs and page.breadcrumbs:
            result_parts.append("## Breadcrumbs")
            breadcrumb_path = " > ".join(b.title for b in page.breadcrumbs)
            result_parts.append(breadcrumb_path)
            result_parts.append("")

        # Redirect warning
        if page.redirect:
            result_parts.append("## Redirect")
            result_parts.append(f"This page redirects to: {page.redirect.slug}")
            result_parts.append("")

        # Content
        if page.content:
            result_parts.append("## Content")
            result_parts.append("")
            result_parts.append(page.content)

        return "\n".join(result_parts)

    except Exception as e:
        return format_error_response(e)


@mcp.tool
def page_get_url(slug: str) -> str:
    """Get the web URL for a wiki page.

    Args:
        slug: Page path from URL (e.g., 'users/homepage' or 'teams/dev/docs').
              Do not include leading slash.

    Returns:
        Full URL to the page in Yandex Wiki web interface.
    """
    logger.info("page_get_url_called", slug=slug)

    try:
        client = get_wiki_client()
        return client.get_page_url(slug)
    except Exception as e:
        return format_error_response(e)


async def cleanup() -> None:
    """Cleanup resources on shutdown."""
    await WikiClient.close_session()
