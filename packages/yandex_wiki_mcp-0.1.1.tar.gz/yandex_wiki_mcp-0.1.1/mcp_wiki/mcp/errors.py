"""Error handling utilities for MCP tools."""

import structlog

from mcp_wiki.wiki.client import PageNotFoundError, WikiApiError

logger = structlog.get_logger(__name__)


def format_error_response(error: Exception) -> str:
    """Format exception into user-friendly error message.

    Args:
        error: Exception to format

    Returns:
        Formatted error message string
    """
    if isinstance(error, PageNotFoundError):
        return (
            f"Error: Page not found - '{error.slug}'\n\n"
            "Possible reasons:\n"
            "1. The page does not exist at this path\n"
            "2. The page is a redirect (Yandex Wiki API does not follow redirects)\n"
            "3. You don't have permission to access this page\n\n"
            "Try checking the exact page path in Yandex Wiki web interface."
        )

    if isinstance(error, WikiApiError):
        if error.status_code == 401:
            return (
                "Error: Authentication failed\n\n"
                "Please check your OAuth token (WIKI_TOKEN or TRACKER_TOKEN) "
                "and organization ID (WIKI_ORG_ID or TRACKER_ORG_ID)."
            )
        if error.status_code == 403:
            return (
                "Error: Access denied\n\n"
                "You don't have permission to access this resource. "
                "Check your access rights in Yandex Wiki."
            )
        return f"Error: API request failed - {error}"

    if isinstance(error, ValueError):
        return f"Configuration error: {error}"

    logger.error("unexpected_error", error=str(error), error_type=type(error).__name__)
    return f"Unexpected error: {error}"
