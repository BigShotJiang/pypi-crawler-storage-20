"""MCP server module for Yandex Wiki."""

from mcp_wiki.mcp.server import mcp

__all__ = ["mcp"]
