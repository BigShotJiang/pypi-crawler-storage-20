"""Entry point for the Yandex Wiki MCP server."""

import asyncio
import signal
import sys
from typing import NoReturn

import structlog

from mcp_wiki.mcp.server import cleanup, mcp

# Configure structlog for clean output (compatible with PrintLogger)
structlog.configure(
    processors=[
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.dev.ConsoleRenderer(colors=False),
    ],
    wrapper_class=structlog.make_filtering_bound_logger(0),
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger(__name__)


def handle_shutdown(signum: int, frame: object) -> NoReturn:
    """Handle shutdown signals gracefully."""
    logger.info("shutdown_signal_received", signal=signum)
    asyncio.get_event_loop().run_until_complete(cleanup())
    sys.exit(0)


def main() -> None:
    """Run the MCP server."""
    # Register signal handlers for graceful shutdown
    signal.signal(signal.SIGINT, handle_shutdown)
    signal.signal(signal.SIGTERM, handle_shutdown)

    logger.info("starting_yandex_wiki_mcp_server")

    try:
        # Run the MCP server with stdio transport
        mcp.run()
    except KeyboardInterrupt:
        logger.info("server_interrupted")
    except Exception as e:
        logger.error("server_error", error=str(e))
        sys.exit(1)
    finally:
        # Cleanup on exit
        asyncio.get_event_loop().run_until_complete(cleanup())


if __name__ == "__main__":
    main()
