"""Yandex Wiki MCP Server - provides access to corporate wiki pages via Model Context Protocol."""

__version__ = "0.1.0"
