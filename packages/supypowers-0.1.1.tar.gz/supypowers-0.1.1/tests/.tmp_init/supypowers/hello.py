# /// script
# dependencies = [
#   "pydantic",
# ]
# ///

"""hello.py - a starter supypower script

This file is meant to be copied and edited.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class HelloInput(BaseModel):
    name: str = Field(..., description="Name to greet.")


class HelloOutput(BaseModel):
    greeting: str = Field(..., description="A friendly greeting.")


def hello(input: HelloInput) -> HelloOutput:
    """Say hello."""
    return HelloOutput(greeting=f"Hello, {input.name}!")
