
{
    "version": "2026.1.19",
    "target": "default",
    "variant": "cpu"
}
