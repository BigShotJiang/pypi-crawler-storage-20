"""
Core Coworker class for AI-powered assistance.
"""


class Coworker:
    """
    Your AI coworker for enhanced productivity and collaboration.
    """

    def __init__(self, name="AI Coworker"):
        """
        Initialize the Coworker.

        Args:
            name (str): The name of your AI coworker
        """
        self.name = name
        self.status = "ready"

    def assist(self, task):
        """
        Get assistance with a task.

        Args:
            task (str): Description of the task you need help with

        Returns:
            str: Assistance response
        """
        return f"{self.name} is working on: {task}"

    def get_status(self):
        """
        Get the current status of the coworker.

        Returns:
            str: Current status
        """
        return f"{self.name} status: {self.status}"

    def __repr__(self):
        return f"Coworker(name='{self.name}', status='{self.status}')"
