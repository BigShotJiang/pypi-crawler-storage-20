"""
opencowork - inprogress - your ai coworker

A Python package for AI-powered collaboration and productivity enhancement.
"""

__version__ = "0.1.0"

from .coworker import Coworker

__all__ = ["Coworker"]
