declare module 'fft.js';
