"""HTTP sink."""
from __future__ import annotations

import random
import threading
import time
from typing import Any, Dict, Iterable, List, Optional

try:
    import requests
except ImportError as exc:  # pragma: no cover - optional dependency
    requests = None
    _requests_import_error = exc
else:
    _requests_import_error = None

from .base import Sink, SinkError
from monora.circuit_breaker import CircuitBreaker, CircuitBreakerError


class HttpSink(Sink):
    """HTTP sink with circuit breaker support.

    The circuit breaker prevents cascading failures when the endpoint
    is unavailable. After a configurable number of consecutive failures,
    the circuit opens and requests fail fast without attempting the request.
    """

    def __init__(
        self,
        endpoint: str,
        headers: Dict[str, str],
        *,
        batch_size: int = 50,
        timeout_sec: float = 10.0,
        retry_attempts: int = 3,
        backoff_base_sec: float = 0.5,
        circuit_breaker: Optional[Dict[str, Any]] = None,
    ):
        if requests is None:
            raise SinkError(
                "requests is required for HttpSink. Install with monora[https]."
            ) from _requests_import_error
        self.endpoint = endpoint
        self.headers = headers
        self.batch_size = batch_size
        self.timeout = timeout_sec
        self.retries = retry_attempts
        self.backoff_base_sec = backoff_base_sec
        self.buffer: List[dict] = []
        self.lock = threading.Lock()

        # Initialize circuit breaker
        cb_config = circuit_breaker or {}
        if cb_config.get("enabled", True):
            self._circuit_breaker: Optional[CircuitBreaker] = CircuitBreaker(
                failure_threshold=cb_config.get("failure_threshold", 5),
                success_threshold=cb_config.get("success_threshold", 2),
                reset_timeout_sec=cb_config.get("reset_timeout_sec", 60.0),
                name=f"HttpSink({endpoint})",
            )
        else:
            self._circuit_breaker = None

    def emit(self, events: Iterable[dict]) -> None:
        with self.lock:
            self.buffer.extend(events)
            if len(self.buffer) >= self.batch_size:
                self._flush_internal()

    def flush(self) -> None:
        with self.lock:
            self._flush_internal()

    def close(self) -> None:
        self.flush()

    def _flush_internal(self) -> None:
        if not self.buffer:
            return

        # Check circuit breaker state
        if self._circuit_breaker and not self._circuit_breaker.can_execute():
            raise SinkError(
                f"Circuit breaker OPEN for {self.endpoint} "
                f"(state: {self._circuit_breaker.state.value})"
            )

        payload = {"events": self.buffer}
        for attempt in range(self.retries):
            try:
                response = requests.post(
                    self.endpoint,
                    json=payload,
                    headers=self.headers,
                    timeout=self.timeout,
                )
                response.raise_for_status()
                self.buffer.clear()
                # Record success with circuit breaker
                if self._circuit_breaker:
                    self._circuit_breaker.record_success()
                return
            except requests.RequestException as exc:
                if attempt == self.retries - 1:
                    # Record failure with circuit breaker
                    if self._circuit_breaker:
                        self._circuit_breaker.record_failure()
                    raise SinkError(
                        f"HTTP sink failed after {self.retries} attempts"
                    ) from exc
                backoff = self.backoff_base_sec * (2**attempt) + random.uniform(0, 0.1)
                time.sleep(backoff)
