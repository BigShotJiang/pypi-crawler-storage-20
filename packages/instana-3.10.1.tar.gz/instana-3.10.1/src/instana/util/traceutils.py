# (c) Copyright IBM Corp. 2021
# (c) Copyright Instana Inc. 2021


from typing import (
    Optional,
    Tuple,
    TYPE_CHECKING,
    Union,
    Dict,
    List,
    Any,
    Iterable,
)

from instana.log import logger
from instana.singletons import agent, get_tracer
from instana.span.span import get_current_span
from instana.span.span import InstanaSpan

if TYPE_CHECKING:
    from instana.tracer import InstanaTracer


def extract_custom_headers(
    span: "InstanaSpan",
    headers: Optional[Union[Dict[str, Any], List[Tuple[object, ...]], Iterable]] = None,
    format: Optional[bool] = False,
) -> None:
    if not (agent.options.extra_http_headers and headers):
        return
    try:
        for custom_header in agent.options.extra_http_headers:
            # Headers are available in the following formats: HTTP_X_CAPTURE_THIS, b'x-header-1', X-Capture-That
            expected_header = (
                ("HTTP_" + custom_header.upper()).replace("-", "_")
                if format
                else custom_header
            )
            for header in headers:
                if isinstance(header, tuple):
                    header_key = (
                        header[0].decode("utf-8")
                        if isinstance(header[0], bytes)
                        else header[0]
                    )
                    header_val = (
                        header[1].decode("utf-8")
                        if isinstance(header[1], bytes)
                        else header[1]
                    )
                    if header_key.lower() == expected_header.lower():
                        span.set_attribute(
                            f"http.header.{custom_header}",
                            header_val,
                        )
                elif header.lower() == expected_header.lower():
                    span.set_attribute(
                        f"http.header.{custom_header}", headers[expected_header]
                    )
    except Exception:
        logger.debug("extract_custom_headers: ", exc_info=True)


def get_tracer_tuple() -> (
    Tuple[
        Optional["InstanaTracer"],
        Optional["InstanaSpan"],
        Optional[str],
    ]
):
    """Get a tuple of (tracer, span, span_name) for the current context."""
    try:
        active_tracer = get_tracer()
        current_span = get_current_span()
        # asyncio Spans are used as NonRecording Spans solely for context propagation
        if current_span and isinstance(current_span, InstanaSpan):
            if current_span.is_recording() or current_span.name == "asyncio":
                return (active_tracer, current_span, current_span.name)
        elif agent.options.allow_exit_as_root:
            return (active_tracer, None, None)
        return (None, None, None)
    except Exception:
        # Do not try to log this with instana, as there is no active tracer and there will be an infinite loop at least
        # for PY2
        return (None, None, None)
