"""
RaySurfer Python SDK - Drop-in replacement for Claude Agent SDK with caching.

Simply swap your import:

    # Before
    from claude_agent_sdk import ClaudeSDKClient, ClaudeAgentOptions

    # After
    from raysurfer import ClaudeSDKClient, ClaudeAgentOptions

Everything else works exactly the same. Set RAYSURFER_API_KEY to enable caching.
"""

# Drop-in replacement for Claude Agent SDK
from raysurfer.sdk_client import (
    ClaudeAgentOptions,
    ClaudeSDKClient,
    # Re-export SDK types for full compatibility
    AgentDefinition,
    HookMatcher,
    AssistantMessage,
    Message,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
    UserMessage,
)

# Direct API clients (for advanced use cases)
from raysurfer.client import AsyncRaySurfer, RaySurfer

# Exceptions
from raysurfer.exceptions import APIError, AuthenticationError, RaySurferError

# Types for direct API usage
from raysurfer.sdk_types import CodeFile, GetCodeFilesResponse
from raysurfer.types import (
    AgentReview,
    AgentVerdict,
    BestMatch,
    CodeBlock,
    ExecutionIO,
    ExecutionRecord,
    ExecutionState,
    FewShotExample,
    FileWritten,
    SubmitExecutionResultResponse,
    TaskPattern,
)

__version__ = "0.3.2"

__all__ = [
    # Drop-in replacement (primary exports)
    "ClaudeSDKClient",
    "ClaudeAgentOptions",
    # SDK types (re-exported from Claude Agent SDK)
    "AgentDefinition",
    "HookMatcher",
    "Message",
    "UserMessage",
    "AssistantMessage",
    "SystemMessage",
    "ResultMessage",
    "TextBlock",
    "ThinkingBlock",
    "ToolUseBlock",
    "ToolResultBlock",
    # Direct API clients
    "RaySurfer",
    "AsyncRaySurfer",
    # Types
    "AgentReview",
    "AgentVerdict",
    "BestMatch",
    "CodeBlock",
    "CodeFile",
    "ExecutionIO",
    "ExecutionRecord",
    "ExecutionState",
    "FewShotExample",
    "FileWritten",
    "GetCodeFilesResponse",
    "SubmitExecutionResultResponse",
    "TaskPattern",
    # Exceptions
    "RaySurferError",
    "APIError",
    "AuthenticationError",
]
