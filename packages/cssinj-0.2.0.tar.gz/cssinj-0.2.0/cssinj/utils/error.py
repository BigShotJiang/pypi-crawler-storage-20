class InjectionError(Exception):
    pass
