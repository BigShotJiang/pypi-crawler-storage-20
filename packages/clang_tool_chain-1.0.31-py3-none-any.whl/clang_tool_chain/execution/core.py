"""
Core tool execution functions for clang-tool-chain.

This module provides the fundamental execution infrastructure for running
LLVM/Clang tools with proper platform detection, SDK configuration, ABI setup,
and linker management.

The main functions are:
- execute_tool(): Execute a tool and exit with its return code (does not return)
- run_tool(): Execute a tool and return its exit code (returns to caller)
- sccache_clang_main(): sccache wrapper for clang with GNU ABI
- sccache_clang_cpp_main(): sccache wrapper for clang++ with GNU ABI
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import NoReturn

from ..abi import (
    _get_gnu_target_args,
    _get_msvc_target_args,
    _should_use_gnu_abi,
    _should_use_msvc_abi,
)
from ..deployment.dll_deployer import post_link_dependency_deployment, post_link_dll_deployment
from ..interrupt_utils import handle_keyboard_interrupt_properly
from ..linker import _add_lld_linker_if_needed
from ..logging_config import configure_logging
from ..platform.detection import get_platform_info
from ..platform.paths import find_sccache_binary, find_tool_binary
from ..sdk import _add_macos_sysroot_if_needed

# Configure logging using centralized configuration
logger = configure_logging(__name__)


def _extract_deploy_dependencies_flag(args: list[str]) -> tuple[list[str], bool]:
    """
    Extract --deploy-dependencies flag from arguments.

    This flag is specific to clang-tool-chain and must be stripped before
    passing arguments to clang, as clang doesn't recognize it.

    Args:
        args: Compiler/linker arguments

    Returns:
        Tuple of (filtered_args, should_deploy)
        - filtered_args: Arguments with --deploy-dependencies removed
        - should_deploy: True if the flag was present

    Examples:
        >>> _extract_deploy_dependencies_flag(["test.cpp", "--deploy-dependencies", "-o", "test.dll"])
        (['test.cpp', '-o', 'test.dll'], True)
        >>> _extract_deploy_dependencies_flag(["test.cpp", "-o", "test.dll"])
        (['test.cpp', '-o', 'test.dll'], False)
    """
    if "--deploy-dependencies" in args:
        filtered = [arg for arg in args if arg != "--deploy-dependencies"]
        return (filtered, True)
    return (args, False)


def _extract_output_path(args: list[str], tool_name: str) -> Path | None:
    """
    Extract the output binary path from compiler/linker arguments.

    Args:
        args: Compiler/linker arguments
        tool_name: Name of the tool being executed

    Returns:
        Path to output binary (.exe or .dll), or None if not a linking operation

    Examples:
        >>> _extract_output_path(["-o", "test.exe", "test.cpp"], "clang++")
        Path('test.exe')
        >>> _extract_output_path(["-otest.exe", "test.cpp"], "clang++")
        Path('test.exe')
        >>> _extract_output_path(["-o", "test.dll", "-shared", "test.cpp"], "clang++")
        Path('test.dll')
        >>> _extract_output_path(["-c", "test.cpp"], "clang++")
        None
    """
    # Skip if compile-only flag present
    if "-c" in args:
        return None

    # Only process clang/clang++ commands
    if tool_name not in ("clang", "clang++"):
        return None

    # Look for -o flag
    i = 0
    while i < len(args):
        arg = args[i]

        # Format: -o output.exe or -o output.dll
        if arg == "-o" and i + 1 < len(args):
            output_path = Path(args[i + 1]).resolve()
            # Only deploy for .exe and .dll files (Windows linking operations)
            if output_path.suffix.lower() in (".exe", ".dll"):
                return output_path
            return None

        # Format: -ooutput.exe or -ooutput.dll
        if arg.startswith("-o") and len(arg) > 2:
            output_path = Path(arg[2:]).resolve()
            if output_path.suffix.lower() in (".exe", ".dll"):
                return output_path
            return None

        i += 1

    # No -o flag: default output is a.exe on Windows (only for linking, not compiling)
    # But we can't determine if it's a link operation without -o, so skip
    return None


def _extract_shared_library_output_path(args: list[str], tool_name: str) -> Path | None:
    """
    Extract the output shared library path from compiler/linker arguments.

    This detects shared library builds (-shared flag) and returns the output path
    for .dll, .so, or .dylib files.

    Args:
        args: Compiler/linker arguments
        tool_name: Name of the tool being executed

    Returns:
        Path to output shared library, or None if not building a shared library

    Examples:
        >>> _extract_shared_library_output_path(["-shared", "lib.cpp", "-o", "lib.dll"], "clang++")
        Path('lib.dll')
        >>> _extract_shared_library_output_path(["-shared", "lib.cpp", "-o", "lib.so"], "clang++")
        Path('lib.so')
        >>> _extract_shared_library_output_path(["lib.cpp", "-o", "lib.dll"], "clang++")
        None  # No -shared flag
    """
    # Skip if compile-only flag present
    if "-c" in args:
        return None

    # Only process clang/clang++ commands
    if tool_name not in ("clang", "clang++"):
        return None

    # Check for -shared flag (required for shared library)
    if "-shared" not in args:
        return None

    # Parse -o flag for output path
    output_path = None
    i = 0
    while i < len(args):
        arg = args[i]

        # Format: -o output.dll
        if arg == "-o" and i + 1 < len(args):
            output_path = Path(args[i + 1]).resolve()
            break

        # Format: -ooutput.dll
        if arg.startswith("-o") and len(arg) > 2:
            output_path = Path(arg[2:]).resolve()
            break

        i += 1

    if output_path is None:
        return None

    # Accept shared library extensions
    suffix = output_path.suffix.lower()
    if suffix in (".dll", ".so", ".dylib") or ".so." in output_path.name:
        return output_path

    return None


def execute_tool(tool_name: str, args: list[str] | None = None, use_msvc: bool = False) -> NoReturn:
    """
    Execute a tool with the given arguments and exit with its return code.

    This function does not return - it replaces the current process with
    the tool process (on Unix) or exits with the tool's return code (on Windows).

    Args:
        tool_name: Name of the tool to execute
        args: Arguments to pass to the tool (defaults to sys.argv[1:])
        use_msvc: If True on Windows, skip GNU ABI injection (use MSVC target)

    Raises:
        RuntimeError: If the tool cannot be found or executed

    Environment Variables:
        SDKROOT: Custom SDK path to use (macOS, standard macOS variable)
        CLANG_TOOL_CHAIN_NO_SYSROOT: Set to '1' to disable automatic -isysroot injection (macOS)
        CLANG_TOOL_CHAIN_USE_SYSTEM_LD: Set to '1' to use system linker instead of lld (macOS/Linux)
    """
    if args is None:
        args = sys.argv[1:]

    # Extract --deploy-dependencies flag (must be stripped before passing to clang)
    args, deploy_dependencies_requested = _extract_deploy_dependencies_flag(args)

    logger.info(f"Executing tool: {tool_name} with {len(args)} arguments")
    logger.debug(f"Arguments: {args}")

    try:
        tool_path = find_tool_binary(tool_name)
    except RuntimeError as e:
        logger.error(f"Failed to find tool binary: {e}")
        print(f"\n{'='*60}", file=sys.stderr)
        print("clang-tool-chain Error", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(f"{e}", file=sys.stderr)
        print(f"{'='*60}\n", file=sys.stderr)
        sys.exit(1)

    # Add macOS SDK path automatically for clang/clang++ if not already specified
    platform_name, arch = get_platform_info()
    if platform_name == "darwin" and tool_name in ("clang", "clang++"):
        logger.debug("Checking if macOS sysroot needs to be added")
        args = _add_macos_sysroot_if_needed(args)

    # Force lld linker on macOS and Linux for cross-platform consistency
    if tool_name in ("clang", "clang++"):
        args = _add_lld_linker_if_needed(platform_name, args)

    # Add Windows GNU ABI target automatically for clang/clang++ if not MSVC variant
    if not use_msvc and tool_name in ("clang", "clang++") and _should_use_gnu_abi(platform_name, args):
        try:
            gnu_args = _get_gnu_target_args(platform_name, arch, args)
            args = gnu_args + args
            logger.info(f"Using GNU ABI with args: {gnu_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            # If GNU setup fails, let the tool try anyway (may fail at compile time)
            logger.error(f"Failed to set up GNU ABI: {e}")
            print(f"\nWarning: Failed to set up Windows GNU ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Add Windows MSVC ABI target for clang/clang++ when using MSVC variant
    if use_msvc and tool_name in ("clang", "clang++") and _should_use_msvc_abi(platform_name, args):
        try:
            msvc_args = _get_msvc_target_args(platform_name, arch)
            args = msvc_args + args
            logger.info(f"Using MSVC ABI with args: {msvc_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            # If MSVC setup fails, let the tool try anyway (may fail at compile time)
            logger.error(f"Failed to set up MSVC ABI: {e}")
            print(f"\nWarning: Failed to set up Windows MSVC ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Build command
    cmd = [str(tool_path)] + args
    logger.info(f"Executing command: {tool_path} (with {len(args)} args)")

    # On Unix systems, we can use exec to replace the current process
    # On Windows, we need to use subprocess and exit with the return code
    platform_name, _ = get_platform_info()

    if platform_name == "win":
        logger.debug("Using Windows subprocess execution")
        # Windows: use subprocess
        try:
            result = subprocess.run(cmd)

            # Post-link DLL deployment (Windows GNU ABI only for .exe)
            if result.returncode == 0:
                output_exe = _extract_output_path(args, tool_name)
                if output_exe is not None:
                    use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                    try:
                        post_link_dll_deployment(output_exe, platform_name, use_gnu)
                    except KeyboardInterrupt as ke:
                        handle_keyboard_interrupt_properly(ke)
                    except Exception as e:
                        logger.warning(f"DLL deployment failed: {e}")

                # Shared library dependency deployment (when --deploy-dependencies flag used)
                if deploy_dependencies_requested:
                    shared_lib_path = _extract_shared_library_output_path(args, tool_name)
                    if shared_lib_path is not None:
                        use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                        try:
                            post_link_dependency_deployment(shared_lib_path, platform_name, use_gnu)
                        except KeyboardInterrupt as ke:
                            handle_keyboard_interrupt_properly(ke)
                        except Exception as e:
                            logger.warning(f"Dependency deployment failed: {e}")

            sys.exit(result.returncode)
        except FileNotFoundError:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Tool not found: {tool_path}", file=sys.stderr)
            print("\nThe binary exists in the package but cannot be executed.", file=sys.stderr)
            print("This may be a permission or compatibility issue.", file=sys.stderr)
            print("\nTroubleshooting:", file=sys.stderr)
            print("  - Verify the binary is compatible with your Windows version", file=sys.stderr)
            print("  - Check Windows Defender or antivirus isn't blocking it", file=sys.stderr)
            print("  - Report issue: https://github.com/zackees/clang-tool-chain/issues", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Error executing tool: {e}", file=sys.stderr)
            print(f"\nUnexpected error while running: {tool_path}", file=sys.stderr)
            print(f"Arguments: {args}", file=sys.stderr)
            print("\nPlease report this issue at:", file=sys.stderr)
            print("https://github.com/zackees/clang-tool-chain/issues", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)
    else:
        logger.debug("Using Unix exec replacement")
        # Unix: use exec to replace current process
        try:
            logger.info(f"Replacing process with: {tool_path}")
            os.execv(str(tool_path), cmd)
        except FileNotFoundError:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Tool not found: {tool_path}", file=sys.stderr)
            print("\nThe binary exists in the package but cannot be executed.", file=sys.stderr)
            print("This may be a permission or compatibility issue.", file=sys.stderr)
            print("\nTroubleshooting:", file=sys.stderr)
            print(f"  - Check file permissions: chmod +x {tool_path}", file=sys.stderr)
            print("  - Verify the binary is compatible with your system", file=sys.stderr)
            print("  - On macOS: Right-click > Open, then allow in Security settings", file=sys.stderr)
            print("  - Report issue: https://github.com/zackees/clang-tool-chain/issues", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Error executing tool: {e}", file=sys.stderr)
            print(f"\nUnexpected error while running: {tool_path}", file=sys.stderr)
            print(f"Arguments: {args}", file=sys.stderr)
            print("\nPlease report this issue at:", file=sys.stderr)
            print("https://github.com/zackees/clang-tool-chain/issues", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)


def run_tool(tool_name: str, args: list[str] | None = None, use_msvc: bool = False) -> int:
    """
    Run a tool with the given arguments and return its exit code.

    Unlike execute_tool, this function returns to the caller with the
    tool's exit code instead of exiting the process.

    Args:
        tool_name: Name of the tool to execute
        args: Arguments to pass to the tool (defaults to sys.argv[1:])
        use_msvc: If True on Windows, skip GNU ABI injection (use MSVC target)

    Returns:
        Exit code from the tool

    Raises:
        RuntimeError: If the tool cannot be found

    Environment Variables:
        SDKROOT: Custom SDK path to use (macOS, standard macOS variable)
        CLANG_TOOL_CHAIN_NO_SYSROOT: Set to '1' to disable automatic -isysroot injection (macOS)
        CLANG_TOOL_CHAIN_USE_SYSTEM_LD: Set to '1' to use system linker instead of lld (macOS/Linux)
    """
    if args is None:
        args = sys.argv[1:]

    # Extract --deploy-dependencies flag (must be stripped before passing to clang)
    args, deploy_dependencies_requested = _extract_deploy_dependencies_flag(args)

    tool_path = find_tool_binary(tool_name)

    # Add macOS SDK path automatically for clang/clang++ if not already specified
    platform_name, arch = get_platform_info()
    if platform_name == "darwin" and tool_name in ("clang", "clang++"):
        logger.debug("Checking if macOS sysroot needs to be added")
        args = _add_macos_sysroot_if_needed(args)

    # Force lld linker on macOS and Linux for cross-platform consistency
    if tool_name in ("clang", "clang++"):
        args = _add_lld_linker_if_needed(platform_name, args)

    # Add Windows GNU ABI target automatically for clang/clang++ if not MSVC variant
    if not use_msvc and tool_name in ("clang", "clang++") and _should_use_gnu_abi(platform_name, args):
        try:
            gnu_args = _get_gnu_target_args(platform_name, arch, args)
            args = gnu_args + args
            logger.info(f"Using GNU ABI with args: {gnu_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            # If GNU setup fails, let the tool try anyway (may fail at compile time)
            logger.error(f"Failed to set up GNU ABI: {e}")
            print(f"\nWarning: Failed to set up Windows GNU ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Add Windows MSVC ABI target for clang/clang++ when using MSVC variant
    if use_msvc and tool_name in ("clang", "clang++") and _should_use_msvc_abi(platform_name, args):
        try:
            msvc_args = _get_msvc_target_args(platform_name, arch)
            args = msvc_args + args
            logger.info(f"Using MSVC ABI with args: {msvc_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            # If MSVC setup fails, let the tool try anyway (may fail at compile time)
            logger.error(f"Failed to set up MSVC ABI: {e}")
            print(f"\nWarning: Failed to set up Windows MSVC ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Build command
    cmd = [str(tool_path)] + args

    # Run the tool
    try:
        result = subprocess.run(cmd)

        # Post-link DLL deployment (Windows GNU ABI only for .exe)
        if result.returncode == 0 and platform_name == "win":
            output_exe = _extract_output_path(args, tool_name)
            if output_exe is not None:
                use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                try:
                    post_link_dll_deployment(output_exe, platform_name, use_gnu)
                except KeyboardInterrupt as ke:
                    handle_keyboard_interrupt_properly(ke)
                except Exception as e:
                    logger.warning(f"DLL deployment failed: {e}")

            # Shared library dependency deployment (when --deploy-dependencies flag used)
            if deploy_dependencies_requested:
                shared_lib_path = _extract_shared_library_output_path(args, tool_name)
                if shared_lib_path is not None:
                    use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                    try:
                        post_link_dependency_deployment(shared_lib_path, platform_name, use_gnu)
                    except KeyboardInterrupt as ke:
                        handle_keyboard_interrupt_properly(ke)
                    except Exception as e:
                        logger.warning(f"Dependency deployment failed: {e}")

        return result.returncode
    except FileNotFoundError as err:
        raise RuntimeError(f"Tool not found: {tool_path}") from err
    except KeyboardInterrupt as ke:
        handle_keyboard_interrupt_properly(ke)
    except Exception as e:
        raise RuntimeError(f"Error executing tool: {e}") from e


# ============================================================================
# sccache wrapper functions
# ============================================================================


def sccache_clang_main(use_msvc: bool = False) -> NoReturn:
    """
    Entry point for sccache + clang wrapper.

    Args:
        use_msvc: If True on Windows, use MSVC ABI instead of GNU ABI

    Environment Variables:
        SCCACHE_IDLE_TIMEOUT: Set to 5 seconds to minimize file locking window
    """
    # Set sccache idle timeout to 5 seconds to minimize file locking window
    # This prevents sccache daemon from holding .venv/Scripts/sccache.exe locked
    # for extended periods, which blocks pip/uv package updates
    if "SCCACHE_IDLE_TIMEOUT" not in os.environ:
        os.environ["SCCACHE_IDLE_TIMEOUT"] = "5"

    args = sys.argv[1:]

    # Extract --deploy-dependencies flag (must be stripped before passing to clang)
    args, deploy_dependencies_requested = _extract_deploy_dependencies_flag(args)

    try:
        sccache_path = find_sccache_binary()
        clang_path = find_tool_binary("clang")
    except RuntimeError as e:
        print(f"\n{'='*60}", file=sys.stderr)
        print("clang-tool-chain Error", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(f"{e}", file=sys.stderr)
        print(f"{'='*60}\n", file=sys.stderr)
        sys.exit(1)

    # Add macOS SDK path automatically if needed
    platform_name, arch = get_platform_info()
    if platform_name == "darwin":
        args = _add_macos_sysroot_if_needed(args)

    # Force lld linker on macOS and Linux for cross-platform consistency
    args = _add_lld_linker_if_needed(platform_name, args)

    # Add Windows GNU ABI target automatically (if not using MSVC variant)
    if not use_msvc and _should_use_gnu_abi(platform_name, args):
        try:
            gnu_args = _get_gnu_target_args(platform_name, arch, args)
            args = gnu_args + args
            logger.info(f"Using GNU ABI with sccache: {gnu_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            logger.error(f"Failed to set up GNU ABI: {e}")
            print(f"\nWarning: Failed to set up Windows GNU ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Add Windows MSVC ABI target when using MSVC variant
    if use_msvc and _should_use_msvc_abi(platform_name, args):
        try:
            msvc_args = _get_msvc_target_args(platform_name, arch)
            args = msvc_args + args
            logger.info(f"Using MSVC ABI with sccache: {msvc_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            logger.error(f"Failed to set up MSVC ABI: {e}")
            print(f"\nWarning: Failed to set up Windows MSVC ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Build command: sccache <clang_path> <args>
    cmd = [sccache_path, str(clang_path)] + args

    # Execute with platform-appropriate method
    platform_name, _ = get_platform_info()

    if platform_name == "win":
        # Windows: use subprocess
        try:
            result = subprocess.run(cmd)

            # Post-link DLL deployment (Windows GNU ABI only for .exe)
            if result.returncode == 0:
                output_exe = _extract_output_path(args, "clang")
                if output_exe is not None:
                    use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                    try:
                        post_link_dll_deployment(output_exe, platform_name, use_gnu)
                    except KeyboardInterrupt as ke:
                        handle_keyboard_interrupt_properly(ke)
                    except Exception as e:
                        logger.warning(f"DLL deployment failed: {e}")

                # Shared library dependency deployment (when --deploy-dependencies flag used)
                if deploy_dependencies_requested:
                    shared_lib_path = _extract_shared_library_output_path(args, "clang")
                    if shared_lib_path is not None:
                        use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                        try:
                            post_link_dependency_deployment(shared_lib_path, platform_name, use_gnu)
                        except KeyboardInterrupt as ke:
                            handle_keyboard_interrupt_properly(ke)
                        except Exception as e:
                            logger.warning(f"Dependency deployment failed: {e}")

            sys.exit(result.returncode)
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Error executing sccache: {e}", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)
    else:
        # Unix: use exec to replace current process
        try:
            os.execv(sccache_path, cmd)
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Error executing sccache: {e}", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)


def sccache_clang_cpp_main(use_msvc: bool = False) -> NoReturn:
    """
    Entry point for sccache + clang++ wrapper.

    Args:
        use_msvc: If True on Windows, use MSVC ABI instead of GNU ABI

    Environment Variables:
        SCCACHE_IDLE_TIMEOUT: Set to 5 seconds to minimize file locking window
    """
    # Set sccache idle timeout to 5 seconds to minimize file locking window
    # This prevents sccache daemon from holding .venv/Scripts/sccache.exe locked
    # for extended periods, which blocks pip/uv package updates
    if "SCCACHE_IDLE_TIMEOUT" not in os.environ:
        os.environ["SCCACHE_IDLE_TIMEOUT"] = "5"

    args = sys.argv[1:]

    # Extract --deploy-dependencies flag (must be stripped before passing to clang)
    args, deploy_dependencies_requested = _extract_deploy_dependencies_flag(args)

    try:
        sccache_path = find_sccache_binary()
        clang_cpp_path = find_tool_binary("clang++")
    except RuntimeError as e:
        print(f"\n{'='*60}", file=sys.stderr)
        print("clang-tool-chain Error", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(f"{e}", file=sys.stderr)
        print(f"{'='*60}\n", file=sys.stderr)
        sys.exit(1)

    # Add macOS SDK path automatically if needed
    platform_name, arch = get_platform_info()
    if platform_name == "darwin":
        args = _add_macos_sysroot_if_needed(args)

    # Force lld linker on macOS and Linux for cross-platform consistency
    args = _add_lld_linker_if_needed(platform_name, args)

    # Add Windows GNU ABI target automatically (if not using MSVC variant)
    if not use_msvc and _should_use_gnu_abi(platform_name, args):
        try:
            gnu_args = _get_gnu_target_args(platform_name, arch, args)
            args = gnu_args + args
            logger.info(f"Using GNU ABI with sccache: {gnu_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            logger.error(f"Failed to set up GNU ABI: {e}")
            print(f"\nWarning: Failed to set up Windows GNU ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Add Windows MSVC ABI target when using MSVC variant
    if use_msvc and _should_use_msvc_abi(platform_name, args):
        try:
            msvc_args = _get_msvc_target_args(platform_name, arch)
            args = msvc_args + args
            logger.info(f"Using MSVC ABI with sccache: {msvc_args}")
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            logger.error(f"Failed to set up MSVC ABI: {e}")
            print(f"\nWarning: Failed to set up Windows MSVC ABI: {e}", file=sys.stderr)
            print("Continuing with default target (may fail)...\n", file=sys.stderr)

    # Build command: sccache <clang++_path> <args>
    cmd = [sccache_path, str(clang_cpp_path)] + args

    # Execute with platform-appropriate method
    platform_name, _ = get_platform_info()

    if platform_name == "win":
        # Windows: use subprocess
        try:
            result = subprocess.run(cmd)

            # Post-link DLL deployment (Windows GNU ABI only for .exe)
            if result.returncode == 0:
                output_exe = _extract_output_path(args, "clang++")
                if output_exe is not None:
                    use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                    try:
                        post_link_dll_deployment(output_exe, platform_name, use_gnu)
                    except KeyboardInterrupt as ke:
                        handle_keyboard_interrupt_properly(ke)
                    except Exception as e:
                        logger.warning(f"DLL deployment failed: {e}")

                # Shared library dependency deployment (when --deploy-dependencies flag used)
                if deploy_dependencies_requested:
                    shared_lib_path = _extract_shared_library_output_path(args, "clang++")
                    if shared_lib_path is not None:
                        use_gnu = _should_use_gnu_abi(platform_name, args) and not use_msvc
                        try:
                            post_link_dependency_deployment(shared_lib_path, platform_name, use_gnu)
                        except KeyboardInterrupt as ke:
                            handle_keyboard_interrupt_properly(ke)
                        except Exception as e:
                            logger.warning(f"Dependency deployment failed: {e}")

            sys.exit(result.returncode)
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Error executing sccache: {e}", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)
    else:
        # Unix: use exec to replace current process
        try:
            os.execv(sccache_path, cmd)
        except KeyboardInterrupt as ke:
            handle_keyboard_interrupt_properly(ke)
        except Exception as e:
            print(f"\n{'='*60}", file=sys.stderr)
            print("clang-tool-chain Error", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"Error executing sccache: {e}", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)
            sys.exit(1)
