"""Samsung NASA."""

from __future__ import annotations

from .nasa import SamsungNasa

__version__ = "1.1.1"

__all__ = ["SamsungNasa"]
