.. _coderef:

==============
Code reference
==============

.. toctree::
  :maxdepth: 2


.. _sec_code_filtering:

Filtering / Sideband isolation
==============================

.. automodule:: qpretrieve.filter
   :members:
   :inherited-members:

.. _sec_code_fourier:

Fourier transform methods
=========================

.. _sec_code_fourier_numpy:

Numpy
-----
.. automodule:: qpretrieve.fourier.ff_numpy
   :members:
   :inherited-members:

.. _sec_code_fourier_pyfftw:

PyFFTW
------
.. automodule:: qpretrieve.fourier.ff_pyfftw
   :members:
   :inherited-members:

.. _sec_code_fourier_cupy:

Cupy
----
.. automodule:: qpretrieve.fourier.ff_cupy
   :members:
   :inherited-members:


.. _sec_code_ifer:

Interference image analysis
===========================

.. _sec_code_dhm:

Off-Axis Holography (DHM)
-------------------------

.. automodule:: qpretrieve.interfere.if_oah
   :members:
   :inherited-members:

.. _sec_code_qlsi:

Quadriwave lateral shearing interferometry (QLSI)
-------------------------------------------------

.. automodule:: qpretrieve.interfere.if_qlsi
   :members:
   :inherited-members:

Data Array Layout
=================

.. _sec_code_array_layout:

.. automodule:: qpretrieve.data_array_layout
   :members:
   :inherited-members:

NDArray Backend
===============

.. _sec_code_ndarray_backend:

.. automodule:: qpretrieve._ndarray_backend
   :members:
   :inherited-members:
