import os
import hashlib
import json
import uuid
import zipfile
import shutil
import io
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

class CodePacker:
    """
    Core engine for consolidating code and assets.
    """
    def __init__(self):
        self.code_exts = {'.py', '.txt', '.js', '.html', '.css', '.json', '.sh', '.md', '.yaml', '.xml', '.c', '.cpp', '.h', '.ts', '.jsx', '.tsx'}
        self.delimiter = "#MOONSPIC_CODEPACKER#"

    def calculate_content_hash(self, directory):
        """Generates a unique hash of the directory content for integrity checks."""
        hasher = hashlib.sha512()
        base = Path(directory).resolve()
        # Sort files to ensure deterministic hashing
        for fp in sorted([f for f in base.rglob('*') if f.is_file()]):
            # Ignore hidden files and the bundle components themselves
            if any(part.startswith('.') for part in fp.parts): continue 
            if fp.name in ["CODE.txt", "META.json", "Assets.zip"] or "_BUNDLE.zip" in fp.name: continue
            
            try:
                hasher.update(str(fp.relative_to(base)).encode())
                hasher.update(fp.read_bytes())
            except:
                continue
        return hasher.hexdigest()

    def pack(self, src_path, out_dir):
        if not src_path or not out_dir: return "Error: Missing paths"
        src, out = Path(src_path).resolve(), Path(out_dir).resolve()
        stage = out / f"STAGE_{uuid.uuid4().hex[:6]}"
        stage.mkdir(parents=True, exist_ok=True)
        
        meta = {"project_name": src.name, "delimiter": self.delimiter}
        code_blocks = []
        assets_buffer = io.BytesIO()

        with zipfile.ZipFile(assets_buffer, 'w') as az:
            for r, _, files in os.walk(src):
                for f in files:
                    fp = Path(r) / f
                    if "_BUNDLE.zip" in f or "STAGE_" in str(fp): continue
                    
                    rel = str(fp.relative_to(src))
                    f_id = str(uuid.uuid4())[:8]
                    
                    if fp.suffix.lower() in self.code_exts:
                        try:
                            content = fp.read_text(encoding='utf-8', errors='ignore')
                            code_blocks.append(f"{self.delimiter} {f_id};{rel}\n{content}")
                        except:
                            az.write(fp, rel)
                    else:
                        az.write(fp, rel)

        (stage / "CODE.txt").write_text("\n".join(code_blocks), encoding='utf-8')
        (stage / "META.json").write_text(json.dumps(meta, indent=4), encoding='utf-8')
        (stage / "Assets.zip").write_bytes(assets_buffer.getvalue())

        final_zip = out / f"{src.name}_BUNDLE.zip"
        with zipfile.ZipFile(final_zip, 'w') as fz:
            for f in ["CODE.txt", "META.json", "Assets.zip"]:
                fz.write(stage / f, f)
        
        shutil.rmtree(stage)
        return str(final_zip)

    def unpack(self, zip_path, target_dir):
        base_target = Path(target_dir).resolve()
        temp = base_target / f"TEMP_{uuid.uuid4().hex[:6]}"
        temp.mkdir(parents=True, exist_ok=True)
        
        shutil.unpack_archive(zip_path, temp)
        meta = json.loads((temp / "META.json").read_text(encoding='utf-8'))
        
        proj_folder = base_target / meta.get("project_name", "restored_project")
        if proj_folder.exists(): shutil.rmtree(proj_folder)
        proj_folder.mkdir(parents=True, exist_ok=True)

        if (temp / "Assets.zip").exists():
            with zipfile.ZipFile(temp / "Assets.zip", 'r') as az:
                az.extractall(proj_folder)

        if (temp / "CODE.txt").exists():
            content = (temp / "CODE.txt").read_text(encoding='utf-8')
            parts = content.split(meta.get("delimiter", self.delimiter))
            for part in parts:
                part = part.strip()
                if not part or ";" not in part: continue
                header, body = part.split("\n", 1)
                rel_path = header.strip().split(";")[1]
                out_f = proj_folder / rel_path.strip()
                out_f.parent.mkdir(parents=True, exist_ok=True)
                out_f.write_text(body, encoding='utf-8')

        shutil.rmtree(temp)
        return str(proj_folder)

class Feeder:
    """
    Logic for segmenting code for LLM context windows.
    """
    def __init__(self, bundle_path):
        self.segments = []
        self.delimiter = "#MOONSPIC_CODEPACKER#"
        if os.path.exists(bundle_path):
            with zipfile.ZipFile(bundle_path, 'r') as z:
                content = z.read("CODE.txt").decode('utf-8', errors='ignore')
                meta = json.loads(z.read("META.json").decode('utf-8'))
                self.delimiter = meta.get("delimiter", self.delimiter)
                # Split and filter empty
                self.segments = [s.strip() for s in content.split(self.delimiter) if s.strip()]

    def get_next_segment(self):
        for i, segment in enumerate(self.segments):
            yield {
                "id": i + 1,
                "total": len(self.segments),
                "content": f"{self.delimiter}\n{segment}"
            }

class GUI:
    def __init__(self):
        self.core = CodePacker()

    def start(self):
        root = tk.Tk()
        root.title("Moonspic v10.1.0")
        root.geometry("800x700")
        
        nb = ttk.Notebook(root)
        nb.pack(expand=1, fill='both', padx=10, pady=10)
        
        t1, t2, t3, t4 = ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb)
        nb.add(t1, text=" Pack ")
        nb.add(t2, text=" Unpack ")
        nb.add(t3, text=" Integrity ")
        nb.add(t4, text=" Config ")

        # --- PACK TAB ---
        in_v, out_v = tk.StringVar(), tk.StringVar()
        tk.Label(t1, text="Source Folder:").pack(pady=5)
        tk.Entry(t1, textvariable=in_v, width=70).pack()
        tk.Button(t1, text="Browse", command=lambda: in_v.set(filedialog.askdirectory())).pack()
        tk.Label(t1, text="Output Directory:").pack(pady=5)
        tk.Entry(t1, textvariable=out_v, width=70).pack()
        tk.Button(t1, text="Browse", command=lambda: out_v.set(filedialog.askdirectory())).pack()
        
        def run_pack():
            res = self.core.pack(in_v.get(), out_v.get())
            messagebox.showinfo("Done", f"Bundle created at:\n{res}")

        tk.Button(t1, text="GENERATE BUNDLE", bg="black", fg="white", font=('Arial', 12, 'bold'), command=run_pack).pack(pady=20)

        # --- UNPACK TAB ---
        z_v, d_v = tk.StringVar(), tk.StringVar()
        tk.Label(t2, text="Bundle ZIP:").pack(pady=5)
        tk.Entry(t2, textvariable=z_v, width=70).pack()
        tk.Button(t2, text="Browse ZIP", command=lambda: z_v.set(filedialog.askopenfilename(filetypes=[("ZIP files", "*.zip")]))).pack()
        tk.Label(t2, text="Restore Destination:").pack(pady=5)
        tk.Entry(t2, textvariable=d_v, width=70).pack()
        tk.Button(t2, text="Browse", command=lambda: d_v.set(filedialog.askdirectory())).pack()

        def run_unpack():
            res = self.core.unpack(z_v.get(), d_v.get())
            messagebox.showinfo("Done", f"Project restored to:\n{res}")

        tk.Button(t2, text="RESTORE PROJECT", bg="blue", fg="white", font=('Arial', 12, 'bold'), command=run_unpack).pack(pady=20)

        # --- INTEGRITY TAB ---
        tk.Label(t3, text="Verification Suite", font=('Arial', 14, 'bold')).pack(pady=10)
        f_src = tk.StringVar()
        tk.Entry(t3, textvariable=f_src, width=70).pack()
        tk.Button(t3, text="Select Project to Verify", command=lambda: f_src.set(filedialog.askdirectory())).pack()

        def run_verify():
            path = Path(f_src.get())
            h1 = self.core.calculate_content_hash(path)
            # Self-test: Pack and Unpack to temp
            tmp = path.parent / "INTEGRITY_TEMP"
            bundle = self.core.pack(path, tmp)
            restored = self.core.unpack(bundle, tmp)
            h2 = self.core.calculate_content_hash(restored)
            
            status = "✅ MATCH" if h1 == h2 else "❌ MISMATCH"
            messagebox.showinfo("Integrity Result", f"Result: {status}\n\nOrig: {h1[:16]}\nRest: {h2[:16]}")
            if tmp.exists(): shutil.rmtree(tmp)

        tk.Button(t3, text="RUN FULL INTEGRITY CHECK", bg="green", fg="white", command=run_verify).pack(pady=20)

        # --- CONFIG TAB ---
        tk.Label(t4, text="MoonspicAI v10.1.0", font=('Arial', 16, 'bold')).pack(pady=20)
        tk.Label(t4, text=f"Active Delimiter: {self.core.delimiter}").pack()
        tk.Label(t4, text="Author: Bahaa M Izz").pack(pady=10)

        root.mainloop()

if __name__ == "__main__":
    app = GUI()
    app.start()
    