# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class ReplaceCloudGtmInstanceConfigAddressPoolResponseBody(DaraModel):
    def __init__(
        self,
        request_id: str = None,
        success: bool = None,
    ):
        # Unique request identification code.
        self.request_id = request_id
        # Indicates whether the operation was successful, with values: 
        # - true: Success. 
        # - false: Failure.
        self.success = success

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.success is not None:
            result['Success'] = self.success

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('Success') is not None:
            self.success = m.get('Success')

        return self

