"""Tests for swebench-mcp."""
