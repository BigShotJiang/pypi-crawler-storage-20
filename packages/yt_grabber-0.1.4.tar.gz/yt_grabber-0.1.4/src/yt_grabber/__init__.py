"""YouTube playlist downloader CLI tool."""

__version__ = "0.1.4"
