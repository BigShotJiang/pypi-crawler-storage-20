# README

```pyphemeris``` is meant to serve as an easily readable documentation on how the
```libaditya``` astrological calculation library works. Each function in libaditya
itself is meant to return the requested data in a way that can then be presented in some
way. Built into most ```libaditya``` classes are functions to represent themselves as
text through repr (__repr__) and ```print```, i.e., through ```__str__```.
```pyphemeris``` makes use of these in order to print the requested data to ```stdout```.



## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
- [Configuration](#configuration)
- [Options](#options)

## Installtion

```pyphemeris``` exists as a package on pypi.org, so you can install it anyway that such
packages can be installed.

```pyphemeris``` is meant to be a program to use, but now it gets installed in the lib
and the "binary" doesn't get into the path in anyway. I want to just be able to run
```pyphemeris``` after installation, but I am not sure how to do that.

### Development installation

```sh
git clone https://gitlab.com/j0sh4rp3/pyphemeris
```

if using ```uv``` then:
```
uv venv
source .venv/bin/activate
uv add .
```

This should install all necessary dependencies.

## Usage
