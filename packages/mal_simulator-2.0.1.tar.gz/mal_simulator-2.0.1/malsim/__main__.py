"""CLI to run simulations in MAL Simulator using scenario files"""

from __future__ import annotations
import argparse
import logging

from .mal_simulator import MalSimulator, MalSimulatorSettings, run_simulation, TTCMode
from .scenario.scenario import Scenario

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
logging.getLogger().setLevel(logging.INFO)


def main() -> None:
    """Entrypoint function of the MAL Toolbox CLI"""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'scenario_file',
        type=str,
        help='Can be found in https://github.com/mal-lang/malsim-scenarios/',
    )
    parser.add_argument(
        '-o',
        '--output-attack-graph',
        type=str,
        help='If set to a path, attack graph will be dumped there',
    )
    parser.add_argument(
        '-s',
        '--seed',
        type=int,
        help='If set to a seed, simulator will use it as setting',
    )
    parser.add_argument(
        '-t',
        '--ttc-mode',
        type=int,
        help=('\t\n'.join([f'{e.value}: {e.name}' for e in TTCMode])),
        default=TTCMode.DISABLED.value,
    )
    parser.add_argument(
        '-g',
        '--send-to-gui',
        action='store_true',
        default=False,
        help='If set, simulator will send actions to malsim-gui',
    )
    args = parser.parse_args()
    scenario = Scenario.load_from_file(args.scenario_file)
    sim = MalSimulator.from_scenario(
        scenario,
        MalSimulatorSettings(
            seed=args.seed,
            ttc_mode=TTCMode(args.ttc_mode),
            attack_surface_skip_unnecessary=False,
        ),
        send_to_api=args.send_to_gui,
    )

    if args.output_attack_graph:
        sim.sim_state.attack_graph.save_to_file(args.output_attack_graph)

    run_simulation(sim, scenario.agent_settings)


if __name__ == '__main__':
    main()
