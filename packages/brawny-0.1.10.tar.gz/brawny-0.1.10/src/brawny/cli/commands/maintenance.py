"""Maintenance commands."""

from __future__ import annotations

import click

from brawny.cli.helpers import get_db


@click.command()
def reconcile() -> None:
    """Run nonce reconciliation."""
    from brawny.config import get_config
    from brawny.db import create_database
    from brawny._rpc import RPCManager
    from brawny.tx.nonce import NonceManager

    click.echo("Running nonce reconciliation...")

    config = get_config()
    db = create_database(
        config.database_url,
        pool_size=config.database_pool_size,
        pool_max_overflow=config.database_pool_max_overflow,
        pool_timeout=config.database_pool_timeout_seconds,
        circuit_breaker_failures=config.db_circuit_breaker_failures,
        circuit_breaker_seconds=config.db_circuit_breaker_seconds,
    )
    db.connect()

    try:
        rpc = RPCManager.from_config(config)
        nonce_manager = NonceManager(db, rpc, config.chain_id)
        nonce_manager.reconcile()
        click.echo("Nonce reconciliation complete.")

    finally:
        db.close()


@click.command()
@click.option("--older-than", default="30d", help="Delete intents older than (e.g., 30d)")
@click.option("--config", "config_path", default=None, help="Path to config.yaml")
def cleanup(older_than: str, config_path: str | None) -> None:
    """Clean up old data."""
    if older_than.endswith("d"):
        days = int(older_than[:-1])
    else:
        days = int(older_than)

    db = get_db(config_path)
    try:
        deleted = db.cleanup_old_intents(days)
        click.echo(f"Deleted {deleted} old intents.")
    finally:
        db.close()

@click.command("audit-intents")
@click.option("--max-age-seconds", type=int, default=None, help="Max age for sending intents")
@click.option("--limit", default=100, help="Limit results")
@click.option("--config", "config_path", default=None, help="Path to config.yaml")
def audit_intents(max_age_seconds: int | None, limit: int, config_path: str | None) -> None:
    """Audit intent state invariants and report inconsistencies."""
    from brawny.config import Config
    from brawny.metrics import INTENT_STATE_INCONSISTENT, get_metrics

    if config_path:
        config = Config.from_yaml(config_path)
        config, _ = config.apply_env_overrides()
    else:
        from brawny.config import get_config

        config = get_config()

    db = get_db(config_path)
    try:
        age_seconds = max_age_seconds or config.claim_timeout_seconds
        issues = db.list_intent_inconsistencies(
            max_age_seconds=age_seconds,
            limit=limit,
            chain_id=config.chain_id,
        )
        if not issues:
            click.echo("No intent inconsistencies found.")
            return

        click.echo("\nIntent inconsistencies:")
        click.echo("-" * 90)
        click.echo(f"{'Intent ID':<38} {'Status':<12} {'Reason':<30}")
        click.echo("-" * 90)
        counts: dict[str, int] = {}
        for issue in issues:
            intent_id = str(issue["intent_id"])[:36]
            status = issue.get("status", "")
            reason = issue.get("reason", "")
            counts[reason] = counts.get(reason, 0) + 1
            click.echo(f"{intent_id:<38} {status:<12} {reason:<30}")

        metrics = get_metrics()
        for reason, count in counts.items():
            metrics.counter(INTENT_STATE_INCONSISTENT).inc(
                count,
                chain_id=config.chain_id,
                reason=reason,
            )

        click.echo(f"\n(Showing {len(issues)} of {limit} max)")
    finally:
        db.close()

def register(main) -> None:
    main.add_command(reconcile)
    main.add_command(cleanup)
    main.add_command(audit_intents)
