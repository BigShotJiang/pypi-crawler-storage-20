"""Bumpversion - Automated version number management tool."""

__version__ = "0.1.2"
