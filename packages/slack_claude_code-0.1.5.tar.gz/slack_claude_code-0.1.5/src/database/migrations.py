from pathlib import Path

import aiosqlite

SCHEMA = """
-- Sessions table (one per channel or thread)
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT NOT NULL,
    thread_ts TEXT DEFAULT NULL,
    working_directory TEXT DEFAULT '~',
    claude_session_id TEXT,
    permission_mode TEXT DEFAULT NULL,
    model TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Command history table
CREATE TABLE IF NOT EXISTS command_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    command TEXT NOT NULL,
    output TEXT,
    status TEXT DEFAULT 'pending',
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

-- Parallel jobs table
CREATE TABLE IF NOT EXISTS parallel_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    channel_id TEXT NOT NULL,
    job_type TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    config JSON,
    results JSON,
    aggregation_output TEXT,
    message_ts TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

-- Queue items for FIFO command queue
CREATE TABLE IF NOT EXISTS queue_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    channel_id TEXT NOT NULL,
    prompt TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    output TEXT,
    error_message TEXT,
    position INTEGER NOT NULL,
    message_ts TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

-- Uploaded files tracking
CREATE TABLE IF NOT EXISTS uploaded_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    slack_file_id TEXT NOT NULL,
    filename TEXT NOT NULL,
    mimetype TEXT,
    size INTEGER,
    local_path TEXT NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_referenced TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id),
    UNIQUE(session_id, slack_file_id)
);

-- File context tracking for smart context management
CREATE TABLE IF NOT EXISTS file_context (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    context_type TEXT NOT NULL,
    last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    use_count INTEGER DEFAULT 1,
    auto_include INTEGER DEFAULT 0,
    FOREIGN KEY (session_id) REFERENCES sessions(id),
    UNIQUE(session_id, file_path, context_type)
);

-- Git checkpoints for version control
CREATE TABLE IF NOT EXISTS git_checkpoints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    channel_id TEXT NOT NULL,
    name TEXT NOT NULL,
    stash_ref TEXT NOT NULL,
    stash_message TEXT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_auto BOOLEAN DEFAULT 0,
    FOREIGN KEY (session_id) REFERENCES sessions(id)
);

-- Notification settings per channel (enabled by default)
CREATE TABLE IF NOT EXISTS notification_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT NOT NULL UNIQUE,
    notify_on_completion INTEGER DEFAULT 1,
    notify_on_permission INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_sessions_channel ON sessions(channel_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_sessions_channel_thread ON sessions(channel_id, thread_ts);
CREATE INDEX IF NOT EXISTS idx_sessions_thread ON sessions(thread_ts) WHERE thread_ts IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_history_session ON command_history(session_id);
CREATE INDEX IF NOT EXISTS idx_history_created ON command_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_session ON parallel_jobs(session_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON parallel_jobs(status);
CREATE INDEX IF NOT EXISTS idx_queue_items_status ON queue_items(status);
CREATE INDEX IF NOT EXISTS idx_queue_items_channel ON queue_items(channel_id);
CREATE INDEX IF NOT EXISTS idx_queue_items_position ON queue_items(channel_id, position);
CREATE INDEX IF NOT EXISTS idx_uploaded_files_session ON uploaded_files(session_id);
CREATE INDEX IF NOT EXISTS idx_file_context_session ON file_context(session_id);
CREATE INDEX IF NOT EXISTS idx_file_context_use_count ON file_context(use_count DESC);
CREATE INDEX IF NOT EXISTS idx_git_checkpoints_channel ON git_checkpoints(channel_id);
CREATE INDEX IF NOT EXISTS idx_git_checkpoints_session ON git_checkpoints(session_id);
CREATE INDEX IF NOT EXISTS idx_notification_settings_channel ON notification_settings(channel_id);
"""


async def init_database(db_path: str) -> None:
    """Initialize the database with the schema."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(db_path) as db:
        await db.executescript(SCHEMA)
        await db.commit()
        # Run migrations for existing databases
        await _run_migrations(db)


async def _run_migrations(db: aiosqlite.Connection) -> None:
    """Run any necessary migrations for schema updates."""
    # Check if model column exists in sessions table
    cursor = await db.execute("PRAGMA table_info(sessions)")
    columns = await cursor.fetchall()
    column_names = [col[1] for col in columns]

    if "model" not in column_names:
        await db.execute("ALTER TABLE sessions ADD COLUMN model TEXT DEFAULT NULL")
        await db.commit()

    # Clean up invalid model values (timestamps that were incorrectly stored as model names)
    # Valid models are: opus, sonnet, haiku, or NULL
    await db.execute(
        """UPDATE sessions SET model = NULL
           WHERE model IS NOT NULL
           AND model NOT IN ('opus', 'sonnet', 'haiku')"""
    )
    await db.commit()


async def reset_database(db_path: str) -> None:
    """Drop all tables and reinitialize (for development)."""
    async with aiosqlite.connect(db_path) as db:
        await db.executescript(
            """
            DROP TABLE IF EXISTS notification_settings;
            DROP TABLE IF EXISTS git_checkpoints;
            DROP TABLE IF EXISTS file_context;
            DROP TABLE IF EXISTS uploaded_files;
            DROP TABLE IF EXISTS queue_items;
            DROP TABLE IF EXISTS parallel_jobs;
            DROP TABLE IF EXISTS command_history;
            DROP TABLE IF EXISTS sessions;
        """
        )
        await db.commit()

    await init_database(db_path)
