"""Examples for swiftagents."""
