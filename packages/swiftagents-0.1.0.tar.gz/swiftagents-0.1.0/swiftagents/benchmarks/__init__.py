"""Benchmarks for swiftagents."""
