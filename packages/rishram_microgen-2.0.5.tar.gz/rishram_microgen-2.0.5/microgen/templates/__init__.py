"""Initialize templates package"""
