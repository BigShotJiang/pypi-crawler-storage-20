from django.apps import AppConfig


class Config(AppConfig):
    name = "bitcaster.web.theme"
