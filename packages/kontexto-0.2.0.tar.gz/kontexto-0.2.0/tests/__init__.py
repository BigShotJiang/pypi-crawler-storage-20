"""Test suite for Kontexto."""
