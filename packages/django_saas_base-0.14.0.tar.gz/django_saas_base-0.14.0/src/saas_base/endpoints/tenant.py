from rest_framework.mixins import (
    RetrieveModelMixin,
    CreateModelMixin,
    UpdateModelMixin,
    ListModelMixin,
)
from rest_framework.request import Request
from rest_framework.permissions import IsAuthenticated
from rest_framework.settings import api_settings
from saas_base.drf.views import AuthenticatedEndpoint, TenantEndpoint
from saas_base.drf.decorators import resource_permission
from saas_base.models import get_tenant_model, Member
from saas_base.serializers.tenant import TenantSerializer, TenantUpdateSerializer

__all__ = [
    'SelectedTenantEndpoint',
    'TenantListEndpoint',
    'TenantItemEndpoint',
]


class SelectedTenantEndpoint(RetrieveModelMixin, TenantEndpoint):
    serializer_class = TenantSerializer
    queryset = get_tenant_model().objects.all()
    tenant_id_field = 'pk'

    def get_object(self):
        queryset = self.filter_queryset(self.get_queryset())
        obj = self.get_object_or_404(queryset)
        self.check_object_permissions(self.request, obj)
        return obj

    @resource_permission('org.info.view')
    def get(self, request: Request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)


class TenantListEndpoint(CreateModelMixin, ListModelMixin, AuthenticatedEndpoint):
    serializer_class = TenantSerializer
    queryset = get_tenant_model().objects.all()
    pagination_class = None
    permission_classes = [IsAuthenticated] + api_settings.DEFAULT_PERMISSION_CLASSES

    def get_queryset(self):
        return self.queryset.filter(owner=self.request.user)

    @resource_permission('user.org.view')
    def get(self, request: Request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    @resource_permission('user.org.create')
    def post(self, request: Request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)


class TenantItemEndpoint(RetrieveModelMixin, UpdateModelMixin, TenantEndpoint):
    serializer_class = TenantUpdateSerializer
    queryset = get_tenant_model().objects.all()
    filter_backends = []
    tenant_id_field = 'pk'

    @resource_permission('org.info.view')
    def get(self, request: Request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    @resource_permission('org.info.manage')
    def patch(self, request: Request, *args, **kwargs):
        return self.partial_update(request, *args, **kwargs)
