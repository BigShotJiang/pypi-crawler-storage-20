from dataclasses import asdict
from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response
from saas_base.registry import perm_registry


__all__ = ['RoleListEndpoint']


class RoleListEndpoint(APIView):
    permission_classes = []
    pagination_class = None

    def get(self, request: Request, *args, **kwargs):
        """Show all supported Roles."""
        data = [asdict(p) for p in perm_registry.get_role_list()]
        return Response(data)
