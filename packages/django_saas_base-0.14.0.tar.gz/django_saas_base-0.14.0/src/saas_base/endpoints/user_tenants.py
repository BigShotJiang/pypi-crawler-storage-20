from django.utils.translation import gettext as _
from django.db.models import OuterRef, Subquery, Count
from rest_framework.request import Request
from rest_framework.exceptions import PermissionDenied
from rest_framework.mixins import (
    ListModelMixin,
    DestroyModelMixin,
)
from saas_base.drf.filters import CurrentUserFilter, IncludeFilter
from saas_base.drf.views import AuthenticatedEndpoint
from saas_base.drf.decorators import resource_permission
from saas_base.models import Member
from saas_base.serializers.user_tenant import UserTenantSerializer

__all__ = [
    'UserTenantListEndpoint',
    'UserTenantItemEndpoint',
]


class UserTenantListEndpoint(ListModelMixin, AuthenticatedEndpoint):
    serializer_class = UserTenantSerializer
    queryset = Member.objects.select_related('tenant').all()
    pagination_class = None

    filter_backends = [CurrentUserFilter, IncludeFilter]
    include_prefetch_related_fields = ['groups']
    include_annotate_fields = ['member_count']

    def annotate_queryset(self, queryset, terms):
        if 'member_count' in terms:
            member_count_subquery = (
                Member.objects.filter(tenant=OuterRef('tenant'))
                .values('tenant')
                .annotate(count=Count('id'))
                .values('count')
            )
            queryset = queryset.annotate(member_count=Subquery(member_count_subquery))
            print(queryset.query)
        return queryset

    @resource_permission('user.org.view')
    def get(self, request: Request, *args, **kwargs):
        """List all the current user's tenants."""
        return self.list(request, *args, **kwargs)


class UserTenantItemEndpoint(DestroyModelMixin, AuthenticatedEndpoint):
    queryset = Member.objects.all()
    filter_backends = [CurrentUserFilter]
    lookup_field = 'tenant_id'

    @resource_permission('user.org.leave')
    def delete(self, request: Request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

    def perform_destroy(self, instance: Member):
        if instance.tenant.owner_id == self.request.user.pk:
            raise PermissionDenied(_('Cannot leave your own tenant.'))
        instance.delete()
