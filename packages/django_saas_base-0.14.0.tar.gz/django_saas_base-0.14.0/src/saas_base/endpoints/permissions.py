from dataclasses import asdict
from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response
from saas_base.registry import perm_registry


__all__ = ['PermissionListEndpoint']


class PermissionListEndpoint(APIView):
    permission_classes = []
    pagination_class = None

    def get(self, request: Request, *args, **kwargs):
        """Show all supported permissions."""
        data = [asdict(p) for p in perm_registry.get_permission_list()]
        return Response(data)
