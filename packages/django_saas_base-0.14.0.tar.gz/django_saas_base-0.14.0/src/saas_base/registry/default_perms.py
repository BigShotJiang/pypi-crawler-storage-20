from django.utils.translation import gettext_lazy as _
from .registry import perm_registry

# Special default role
perm_registry.register_role('OWNER', _('Owner'), _('Full organization access'))
perm_registry.assign_to_role('OWNER', '*')

# User Profile
perm_registry.register_permission(
    key='user.profile.view',
    label=_('View Profile'),
    module='User',
    description=_('Read access to basic profile details (name, avatar, bio)'),
)
perm_registry.register_permission(
    key='user.profile.update',
    label=_('Update Profile'),
    module='User',
    description=_('Write access to update own profile details'),
)

# User Emails
perm_registry.register_permission(
    key='user.email.view',
    label=_('View Emails'),
    module='User',
    description=_('List all registered email addresses'),
)
perm_registry.register_permission(
    key='user.email.manage',
    label=_('Manage Emails'),
    module='User',
    description=_('Add, delete, or verify secondary email addresses'),
)

# User Tenants
perm_registry.register_permission(
    key='user.org.view',
    label=_('View Organizations'),
    module='User',
    description=_('List all organizations you belong to'),
)
perm_registry.register_permission(
    key='user.org.create',
    label=_('Create Organizations'),
    module='User',
    description=_('Create new organizations'),
)
perm_registry.register_permission(
    key='user.or.join',
    label=_('Join Organizations'),
    module='User',
    description=_("Join any organization you're invited to"),
)
perm_registry.register_permission(
    key='user.org.leave',
    label=_('Leave Organizations'),
    module='User',
    description=_('Leave any organization you belong to'),
)

# Identity Management (IAM)
perm_registry.register_permission(
    'iam.member.view',
    _('View Members'),
    module='IAM',
    description=_('List and view member details'),
)
perm_registry.register_permission(
    'iam.member.manage',
    _('Manage Members'),
    module='IAM',
    description=_('Invite, update roles, or remove members'),
)
perm_registry.register_permission(
    'iam.group.view',
    _('View Groups'),
    module='IAM',
    description=_('View tenant groups'),
)
perm_registry.register_permission(
    'iam.group.manage',
    _('Manage Groups'),
    module='IAM',
    description=_('Create or edit tenant-specific groups'),
)
perm_registry.register_permission(
    key='iam.invitation.view',
    label=_('View Invitations'),
    module='IAM',
    description=_('List all pending invitations'),
)
perm_registry.register_permission(
    key='iam.invitation.manage',
    label='Manage Invitations',
    module='IAM',
    description=_('Invite new members to join the organization'),
)

# Organization Management
perm_registry.register_permission(
    'org.info.view',
    _('View Organization'),
    module='Organization',
    description=_('View tenant settings and info'),
)
perm_registry.register_permission(
    'org.info.update',
    _('Update Organization'),
    module='Organization',
    description=_('Update tenant name, logo, etc.'),
)
