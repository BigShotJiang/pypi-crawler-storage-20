from dataclasses import dataclass


@dataclass
class Permission:
    key: str
    label: str
    description: str
    module: str


@dataclass
class Role:
    code: str
    name: str
    description: str
    permissions: set[str]


@dataclass
class Scope:
    key: str
    label: str
    permissions: set[str]  # Internal permission patterns
    description: str = ''
    is_oidc: bool = False  # Flag for OIDC standard scopes
