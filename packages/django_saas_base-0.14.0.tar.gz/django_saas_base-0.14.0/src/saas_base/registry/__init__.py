from .registry import perm_registry

__all__ = ['perm_registry']
