from django.apps import AppConfig
from django.conf import settings

if not hasattr(settings, 'SAAS_TENANT_MODEL'):
    setattr(settings, 'SAAS_TENANT_MODEL', 'saas_base.Tenant')


class CoreConfig(AppConfig):
    name = 'saas_base'
    verbose_name = 'SaaS'

    def ready(self):
        from ._ready import setup

        setup()
