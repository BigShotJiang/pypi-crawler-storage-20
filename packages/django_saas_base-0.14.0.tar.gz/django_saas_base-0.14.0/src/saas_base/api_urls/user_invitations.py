from django.urls import path
from ..endpoints.user_invitations import (
    UserInvitationListEndpoint,
    UserInvitationAcceptEndpoint,
)

urlpatterns = [
    path('', UserInvitationListEndpoint.as_view()),
    path('<pk>/', UserInvitationAcceptEndpoint.as_view()),
]
