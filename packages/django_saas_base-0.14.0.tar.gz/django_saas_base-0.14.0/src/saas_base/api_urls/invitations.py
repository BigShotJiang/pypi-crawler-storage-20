from django.urls import path
from ..endpoints.invitations import (
    InvitationListEndpoint,
    InvitationItemEndpoint,
)

urlpatterns = [
    path('', InvitationListEndpoint.as_view()),
    path('<pk>/', InvitationItemEndpoint.as_view()),
]
