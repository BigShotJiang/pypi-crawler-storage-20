import{J as i}from"./index.qjO5OK90.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
