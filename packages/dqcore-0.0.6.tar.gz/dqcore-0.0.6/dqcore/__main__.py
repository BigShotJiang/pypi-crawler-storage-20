"""dqcore 命令行入口"""

import sys
from .core import up0

if __name__ == "__main__":
    # 获取命令行参数
    args = sys.argv[1:]  # 第一个参数是脚本名称，所以从索引1开始
    
    if not args:
        print("请指定要运行的命令，例如: python -m dqcore up0")
        sys.exit(1)
    
    command = args[0]
    
    if command == "up0":
        up0()
    else:
        print(f"未知命令: {command}")
        print("可用命令: up0")
        sys.exit(1)