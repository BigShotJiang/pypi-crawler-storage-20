# dqcore

一个简单的 Python 包演示。

## 功能

- 提供 hello_world() 函数输出 "Hello World!"

## 安装

```bash
pip install dqcore
```

## 使用

```python
import dqcore

dqcore.hello_world()
```

## 版本

0.0.1 - 初始版本
