from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="dqcore",
    version="0.0.6",
    author="Your Name",
    author_email="xu@daqid.com",
    description="一个简单的 Python 包演示 ",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/xulei8/dqcore",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
