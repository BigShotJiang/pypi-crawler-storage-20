"""Tests for runtm-shared."""
