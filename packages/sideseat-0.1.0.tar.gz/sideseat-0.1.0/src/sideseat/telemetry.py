"""SideSeat OpenTelemetry configuration with binary data handling.

Framework-agnostic telemetry setup that encodes binary data as base64.
"""

import atexit
import base64
import json
import logging
import threading
from collections.abc import Sequence
from datetime import date, datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from typing import Any

import opentelemetry.metrics as metrics_api
import opentelemetry.sdk.metrics as metrics_sdk
import opentelemetry.trace as trace_api
from opentelemetry import propagate
from opentelemetry.baggage.propagation import W3CBaggagePropagator
from opentelemetry.propagators.composite import CompositePropagator
from opentelemetry.sdk.metrics.export import (
    ConsoleMetricExporter,
    PeriodicExportingMetricReader,
)
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)
from opentelemetry.trace import format_span_id, format_trace_id
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

from sideseat._version import __version__ as sdk_version

logger = logging.getLogger(__name__)


def encode_value(value: Any) -> Any:
    """Encode value for JSON, converting binary to base64.

    Performance: Common JSON-safe types are checked first to avoid json.dumps overhead.
    """
    # Fast path for common JSON-safe primitives (no json.dumps needed)
    if value is None or isinstance(value, (str, int, float, bool)):
        return value

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    if isinstance(value, memoryview):
        value = value.tobytes()

    if isinstance(value, (bytes, bytearray)):
        return base64.b64encode(value).decode("ascii")

    if isinstance(value, dict):
        return {k: encode_value(v) for k, v in value.items()}

    if isinstance(value, set):
        # Convert sets to lists; sort only if all items are comparable
        encoded = [encode_value(item) for item in value]
        try:
            return sorted(encoded)
        except TypeError:
            # Mixed types that can't be compared - return unsorted
            return encoded

    if isinstance(value, (list, tuple)):
        return [encode_value(item) for item in value]

    # Fallback: check if JSON-serializable
    try:
        json.dumps(value)
        return value
    except (TypeError, OverflowError, ValueError):
        return f"<{type(value).__name__}>"


def _create_encoder_method() -> Any:
    """Create a method for Strands' JSONEncoder._process_value."""

    def _process_value(self: Any, value: Any) -> Any:
        return encode_value(value)

    return _process_value


def patch_strands_encoder() -> bool:
    """Patch Strands' JSONEncoder to encode binary as base64.

    Returns:
        True if patching succeeded, False if Strands is not installed.
    """
    try:
        from strands.telemetry import tracer  # type: ignore[import-not-found]

        tracer.JSONEncoder._process_value = _create_encoder_method()
        logger.debug("Patched Strands encoder for base64 binary encoding")
        return True
    except ImportError:
        logger.debug("Strands not installed, skipping encoder patch")
        return False


def _ns_to_iso8601(ns: int | None) -> str | None:
    """Convert nanoseconds to ISO8601 timestamp."""
    if ns is None:
        return None
    return datetime.fromtimestamp(ns / 1e9, tz=timezone.utc).isoformat()


def span_to_dict(span: ReadableSpan) -> dict[str, Any]:
    """Convert a ReadableSpan to a dictionary with base64-encoded binaries."""
    ctx = span.context
    parent = span.parent

    attrs = {}
    if span.attributes:
        attrs = {k: encode_value(v) for k, v in dict(span.attributes).items()}

    resource_attrs = {}
    if span.resource and span.resource.attributes:
        resource_attrs = {k: encode_value(v) for k, v in dict(span.resource.attributes).items()}

    scope = getattr(span, "instrumentation_scope", None)
    scope_dict = None
    if scope:
        scope_dict = {
            "name": scope.name,
            "version": scope.version,
            "schema_url": scope.schema_url,
        }

    status = getattr(span, "status", None)
    status_dict = None
    if status:
        status_dict = {
            "status_code": str(status.status_code),
            "description": status.description,
        }

    events = []
    for e in span.events or []:
        event_attrs = (
            {k: encode_value(v) for k, v in dict(e.attributes).items()} if e.attributes else {}
        )
        events.append(
            {
                "name": e.name,
                "timestamp": _ns_to_iso8601(e.timestamp),
                "attributes": event_attrs,
            }
        )

    links = []
    for link in span.links or []:
        link_attrs = (
            {k: encode_value(v) for k, v in dict(link.attributes).items()}
            if link.attributes
            else {}
        )
        links.append(
            {
                "trace_id": format_trace_id(link.context.trace_id),
                "span_id": format_span_id(link.context.span_id),
                "attributes": link_attrs,
            }
        )

    return {
        "name": span.name,
        "trace_id": format_trace_id(ctx.trace_id),
        "span_id": format_span_id(ctx.span_id),
        "parent_span_id": format_span_id(parent.span_id) if parent else None,
        "kind": str(span.kind),
        "start_time": _ns_to_iso8601(span.start_time),
        "end_time": _ns_to_iso8601(span.end_time),
        "duration_ms": (span.end_time - span.start_time) / 1e6
        if span.start_time is not None and span.end_time is not None
        else None,
        "attributes": attrs,
        "events": events,
        "links": links,
        "status": status_dict,
        "resource": resource_attrs,
        "scope": scope_dict,
    }


def _get_service_info() -> tuple[str, str]:
    """Get service name and version with auto-detection."""
    # Try common AI framework packages
    for pkg in ["strands-agents", "langchain", "crewai", "autogen-agentchat"]:
        try:
            return pkg, version(pkg)
        except PackageNotFoundError:
            continue
    # Fallback to default
    return "sideseat-app", "0.0.0"


def get_otel_resource(
    service_name: str | None = None,
    service_version: str | None = None,
) -> Resource:
    """Create OpenTelemetry resource with service information."""
    if service_name is None or service_version is None:
        auto_name, auto_version = _get_service_info()
        service_name = service_name or auto_name
        service_version = service_version or auto_version

    return Resource.create(
        {
            "service.name": service_name,
            "service.version": service_version,
            "telemetry.sdk.name": "sideseat",
            "telemetry.sdk.version": sdk_version,
            "telemetry.sdk.language": "python",
        }
    )


class JsonFileSpanExporter(SpanExporter):
    """Exports spans to JSONL file with base64-encoded binaries."""

    def __init__(self, path: str, mode: str = "a") -> None:
        """Initialize file exporter.

        Args:
            path: File path for JSONL output
            mode: File mode - "a" (append, default) or "w" (overwrite)
        """
        if mode not in ("a", "w"):
            raise ValueError(f"mode must be 'a' or 'w', got {mode!r}")
        self._path = path
        self._mode = mode
        self._lock = threading.Lock()
        self._closed = False
        self._fh = open(path, mode, encoding="utf-8")

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        try:
            with self._lock:
                if self._closed:
                    return SpanExportResult.FAILURE
                for span in spans:
                    self._fh.write(json.dumps(span_to_dict(span), ensure_ascii=False))
                    self._fh.write("\n")
                self._fh.flush()
            return SpanExportResult.SUCCESS
        except Exception:
            logger.exception("Failed to export spans to %s", self._path)
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._fh.flush()
            self._fh.close()
            self._closed = True

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        with self._lock:
            if self._closed:
                return False
            self._fh.flush()
        return True


class SideSeatTelemetry:
    """Framework-agnostic OpenTelemetry setup with base64 binary encoding.

    Args:
        tracer_provider: Optional pre-configured tracer provider.
        service_name: Service name for resource (auto-detected if None).
        service_version: Service version for resource (auto-detected if None).
        encode_binary_as_base64: If True (default), patches Strands encoder
            to show binary as base64 instead of '<replaced>'.

    Examples:
        >>> SideSeatTelemetry().setup_otlp_exporter()
        >>> SideSeatTelemetry().setup_file_exporter("traces.jsonl")
        >>> SideSeatTelemetry(encode_binary_as_base64=False).setup_otlp_exporter()
    """

    def __init__(
        self,
        tracer_provider: SDKTracerProvider | None = None,
        service_name: str | None = None,
        service_version: str | None = None,
        encode_binary_as_base64: bool = True,
    ) -> None:
        self._file_exporters: list[JsonFileSpanExporter] = []
        self._shutdown_registered = False
        self._shutdown_called = False
        self._shutdown_lock = threading.Lock()

        if encode_binary_as_base64:
            patch_strands_encoder()

        self.resource = get_otel_resource(service_name, service_version)

        if tracer_provider:
            self.tracer_provider = tracer_provider
        else:
            self._initialize_tracer()

    def _initialize_tracer(self) -> None:
        """Initialize the OpenTelemetry tracer."""
        self.tracer_provider = SDKTracerProvider(resource=self.resource)
        trace_api.set_tracer_provider(self.tracer_provider)

        propagate.set_global_textmap(
            CompositePropagator(
                [
                    W3CBaggagePropagator(),
                    TraceContextTextMapPropagator(),
                ]
            )
        )

    def setup_console_exporter(self, **kwargs: Any) -> "SideSeatTelemetry":
        """Set up console exporter."""
        processor = SimpleSpanProcessor(ConsoleSpanExporter(**kwargs))
        self.tracer_provider.add_span_processor(processor)
        return self

    def setup_otlp_exporter(self, **kwargs: Any) -> "SideSeatTelemetry":
        """Set up OTLP exporter."""
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter,
        )

        exporter = OTLPSpanExporter(**kwargs)
        processor = BatchSpanProcessor(exporter)
        self.tracer_provider.add_span_processor(processor)
        return self

    def setup_file_exporter(
        self, path: str = "traces.jsonl", mode: str = "a"
    ) -> "SideSeatTelemetry":
        """Set up JSONL file exporter with base64 binary encoding.

        Args:
            path: File path for JSONL output (default: traces.jsonl)
            mode: File mode - "a" (append, default) or "w" (overwrite)
        """
        exporter = JsonFileSpanExporter(path, mode)
        processor = BatchSpanProcessor(exporter)
        self.tracer_provider.add_span_processor(processor)
        self._file_exporters.append(exporter)

        # Register main shutdown only once (not per-exporter)
        if not self._shutdown_registered:
            atexit.register(self.shutdown)
            self._shutdown_registered = True
        return self

    def setup_meter(
        self,
        enable_console_exporter: bool = False,
        enable_otlp_exporter: bool = False,
    ) -> "SideSeatTelemetry":
        """Initialize the OpenTelemetry Meter."""
        readers = []

        if enable_console_exporter:
            readers.append(PeriodicExportingMetricReader(ConsoleMetricExporter()))

        if enable_otlp_exporter:
            from opentelemetry.exporter.otlp.proto.http.metric_exporter import (
                OTLPMetricExporter,
            )

            readers.append(PeriodicExportingMetricReader(OTLPMetricExporter()))

        self.meter_provider = metrics_sdk.MeterProvider(
            resource=self.resource,
            metric_readers=readers,
        )
        metrics_api.set_meter_provider(self.meter_provider)
        return self

    def shutdown(self) -> None:
        """Shutdown all exporters and providers (idempotent, thread-safe)."""
        with self._shutdown_lock:
            if self._shutdown_called:
                return
            self._shutdown_called = True

        for exporter in self._file_exporters:
            exporter.shutdown()
        if hasattr(self, "tracer_provider"):
            self.tracer_provider.shutdown()
        if hasattr(self, "meter_provider"):
            self.meter_provider.shutdown()
