"""SideSeat SDK for AI observability.

A lightweight OpenTelemetry wrapper for AI/LLM application observability.
Provides easy setup for tracing with binary data encoding support.

Example:
    from sideseat import SideSeatTelemetry

    telemetry = SideSeatTelemetry()
    telemetry.setup_otlp_exporter()
    telemetry.setup_console_exporter()
"""

from sideseat._version import __version__
from sideseat.telemetry import (
    JsonFileSpanExporter,
    SideSeatTelemetry,
    encode_value,
    get_otel_resource,
    patch_strands_encoder,
    span_to_dict,
)

__all__ = [
    "__version__",
    "JsonFileSpanExporter",
    "SideSeatTelemetry",
    "encode_value",
    "get_otel_resource",
    "patch_strands_encoder",
    "span_to_dict",
]
