"""Version information for SideSeat SDK."""

__version__ = "0.1.0"
