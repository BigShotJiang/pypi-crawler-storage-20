# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-01-13

### Added
- Initial release
- `SideSeatTelemetry` class for easy OpenTelemetry setup
- OTLP, Console, and JSONL file exporters
- Binary data encoding (base64) support
- Strands framework encoder patching
- Method chaining API
