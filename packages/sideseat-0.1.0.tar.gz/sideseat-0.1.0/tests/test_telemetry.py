"""Basic tests for SideSeat SDK."""

import os
from datetime import date, datetime, timezone

from sideseat import SideSeatTelemetry, __version__, encode_value


def test_version() -> None:
    """Version should match pyproject.toml."""
    assert __version__ == "0.1.0"


def test_encode_value_bytes() -> None:
    """Bytes should be base64 encoded."""
    result = encode_value(b"hello")
    assert result == "aGVsbG8="


def test_encode_value_string_passthrough() -> None:
    """Strings should pass through unchanged."""
    result = encode_value("hello")
    assert result == "hello"


def test_encode_value_dict_recursive() -> None:
    """Dicts should have bytes values encoded recursively."""
    result = encode_value({"key": b"value", "nested": {"inner": b"data"}})
    assert result == {"key": "dmFsdWU=", "nested": {"inner": "ZGF0YQ=="}}


def test_encode_value_list() -> None:
    """Lists should have bytes values encoded."""
    result = encode_value([b"a", "b", b"c"])
    assert result == ["YQ==", "b", "Yw=="]


def test_encode_value_set() -> None:
    """Sets should be converted to sorted lists."""
    result = encode_value({"c", "a", "b"})
    assert result == ["a", "b", "c"]


def test_encode_value_set_mixed_types() -> None:
    """Sets with mixed types should be converted to lists (unsorted)."""
    # Mixed types can't be sorted, so just check it returns a list
    result = encode_value({1, "a", None})
    assert isinstance(result, list)
    assert set(result) == {1, "a", None}


def test_encode_value_primitives() -> None:
    """Primitive types should pass through unchanged."""
    assert encode_value(None) is None
    assert encode_value(42) == 42
    assert encode_value(3.14) == 3.14
    assert encode_value(True) is True
    assert encode_value(False) is False


def test_encode_value_datetime() -> None:
    """Datetime should be converted to ISO8601."""
    dt = datetime(2024, 1, 15, 12, 30, 45, tzinfo=timezone.utc)
    result = encode_value(dt)
    assert result == "2024-01-15T12:30:45+00:00"


def test_encode_value_date() -> None:
    """Date should be converted to ISO8601."""
    d = date(2024, 1, 15)
    result = encode_value(d)
    assert result == "2024-01-15"


def test_encode_value_non_serializable() -> None:
    """Non-serializable types should return type name placeholder."""
    result = encode_value(object())
    assert result == "<object>"


def test_telemetry_init() -> None:
    """Telemetry should initialize with a tracer provider."""
    telemetry = SideSeatTelemetry()
    assert telemetry.tracer_provider is not None
    telemetry.shutdown()


def test_telemetry_chaining() -> None:
    """Exporter setup methods should return self for chaining."""
    telemetry = SideSeatTelemetry()
    result = telemetry.setup_console_exporter()
    assert result is telemetry
    telemetry.shutdown()


def test_telemetry_shutdown_idempotent() -> None:
    """Shutdown should be safe to call multiple times."""
    telemetry = SideSeatTelemetry()
    telemetry.shutdown()
    telemetry.shutdown()  # Should not raise


def test_file_exporter_append_mode(temp_trace_file: str) -> None:
    """File exporter should default to append mode."""
    # Create first telemetry instance and write
    t1 = SideSeatTelemetry()
    t1.setup_file_exporter(temp_trace_file)
    t1.shutdown()

    # Create second instance - should append, not overwrite
    t2 = SideSeatTelemetry()
    t2.setup_file_exporter(temp_trace_file)
    t2.shutdown()

    # File should still exist (not truncated)
    assert os.path.exists(temp_trace_file)
