# pysfi

Single File commands for Interactive python.

## Overview

pysfi is a Python project that provides single-file command-line utilities, designed to be lightweight and easy-to-use.

## Available Commands

- **alarmclk**: Alarm clock functionality
- **[bumpversion](sfi/bumpversion/README.md)**: Automated version number management tool
- **embedinstall**: Embed installation utilities
- **[filedate](sfi/filedate/README.md)**: A file date management tool that normalizes date prefixes in filenames
- **mkp**: Make Python project utilities
- **projectparse**: Project parsing and analysis tools
- **pyloadergen**: Python loader code generation
- **pypacker**: Python packaging utilities

## Installation

```bash
# Install using uv (recommended)
uv add pysfi

# Or using pip
pip install pysfi
```

## Development

### Requirements

- Python >= 3.8
- [uv](https://github.com/astral-sh/uv) (recommended) or pip

### Development Dependencies

```bash
uv pip install -e ".[dev]"
```

### Code Standards

The project uses Ruff for code linting and formatting:

```bash
# Check code
ruff check .

# Format code
ruff format .
```

## Project Structure

```bash
pysfi/
├── pyproject.toml          # Main project configuration
├── README.md
└── sfi/
    ├── __init__.py
    ├── alarmclock/         # alarmclk command module
    │   ├── alarmclock.py
    │   ├── pyproject.toml
    │   └── __init__.py
    ├── embedinstall/       # embedinstall command module
    │   ├── embedinstall.py
    │   ├── pyproject.toml
    │   └── __init__.py
    ├── filedate/           # filedate command module
    │   ├── filedate.py
    │   ├── pyproject.toml
    │   ├── README.md       # Detailed documentation
    │   └── __init__.py
    ├── makepython/         # mkp command module
    │   ├── makepython.py
    │   ├── pyproject.toml
    │   └── __init__.py
    ├── projectparse/       # projectparse command module
    │   ├── projectparse.py
    │   ├── pyproject.toml
    │   └── __init__.py
    ├── pyloadergen/        # pyloadergen command module
    │   ├── pyloadergen.py
    │   ├── pyproject.toml
    │   └── __init__.py
    └── pypacker/           # pypacker command module
        ├── fspacker.py
        └── pyproject.toml
```

## License

MIT License

## Contributing

Issues and Pull Requests are welcome!
