from __future__ import annotations

import argparse
import logging
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

__version__ = "0.9.30"
__build__ = "20260113"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "options",
        choices=("build", "b", "run", "r", "clean", "c", "version", "v"),
        help="Operation command",
    )
    parser.add_argument(
        "target",
        type=str,
        default=None,
        nargs="?",
        help="Target name to match, supports fuzzy matching, leave empty if only one.",
    )
    parser.add_argument(
        "directory",
        type=str,
        default=str(Path.cwd()),
        nargs="?",
        help="Project directory path",
    )

    parser.add_argument("--archive", "-a", action="store_true", help="zip packaging mode")
    parser.add_argument("--compile", "-c", action="store_true", help="compile mode")
    parser.add_argument("--debug", "-d", action="store_true", help="debug mode")
    parser.add_argument("--gui", "-g", action="store_true", help="GUI mode")
    parser.add_argument("--nsis", "-n", action="store_true", help="nsis packaging mode")
    parser.add_argument("--offline", "-o", action="store_true", help="offline mode")
    parser.add_argument("--rebuild", "-rb", action="store_true", help="rebuild mode")
    parser.add_argument("--recursive", "-r", action="store_true", default=False, help="recursive")
    parser.add_argument("--simplify", "-s", action="store_true", default=True, help="simplify mode")
    parser.add_argument("--use-mingw", "-mingw", action="store_true", help="use mingw to compile")
    parser.add_argument(
        "--use-nuitka",
        "-nuitka",
        action="store_true",
        default=True,
        help="use nuitka to compile",
    )
    parser.add_argument("--with-tk", "-tk", action="store_true", help="package tk library")
    parser.add_argument("--with-js", "-js", action="store_true", help="package js")

    args = parser.parse_args()

    # settings.mode["archive"] = args.archive
    # settings.mode["compile"] = args.compile
    # settings.mode["debug"] = args.debug
    # settings.mode["gui"] = args.gui
    # settings.mode["nsis"] = args.nsis
    # settings.mode["offline"] = args.offline
    # settings.mode["rebuild"] = args.rebuild
    # settings.mode["recursive"] = args.recursive
    # settings.mode["simplify"] = args.simplify
    # settings.mode["use_mingw"] = args.use_mingw
    # settings.mode["use_nuitka"] = args.use_nuitka
    # settings.mode["with_tk"] = args.with_tk
    # settings.mode["with_js"] = args.with_js

    if args.debug:
        logger.setLevel(logging.DEBUG)
    else:
        logger.setLevel(logging.INFO)

    # logger.show_header()

    if args.options in {"version", "v"}:
        logger.info(f"pypacker {__version__} (build {__build__})")
        return

    # manager = ProjectManager(Path(args.directory), match_name=args.target)
    # if args.options in {"build", "b"}:
    #     manager.build()
    # elif args.options in {"run", "r"}:
    #     manager.run()
    # elif args.options in {"clean", "c"}:
    #     manager.clean()

    # settings.dump()
