"""Synchronous browser session."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Callable

from cmdop.logging import get_logger
from cmdop.services.browser.base.session import BaseSession

# Module-level logger for browser actions
_log = get_logger("cmdop.browser")
from cmdop.services.browser.models import (
    BrowserCookie,
    BrowserState,
    PageInfo,
    ScrollInfo,
    ScrollResult,
    InfiniteScrollResult,
)
from cmdop.services.browser.js import (
    parse_json_result,
    build_infinite_scroll_js,
)
from cmdop.services.browser.parsing import (
    parse_html as _parse_html,
    SoupWrapper,
)

if TYPE_CHECKING:
    from bs4 import BeautifulSoup
    from cmdop.services.browser.sync.service import BrowserService


class BrowserSession(BaseSession):
    """
    Synchronous browser session with fluent API.

    Usage:
        with client.browser.create_session() as session:
            session.navigate("https://example.com")
            session.click("button.submit")
            data = session.fetch_all(urls)  # credentials + accept header by default
    """

    _service: BrowserService

    def _call_service(self, method: str, *args: Any, **kwargs: Any) -> Any:
        """Call service method synchronously."""
        return getattr(self._service, method)(self._session_id, *args, **kwargs)

    # === Navigation & Interaction ===

    def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        """Navigate to URL. Returns final URL."""
        _log.debug("[navigate] %s", url[:80])
        result = self._service.navigate(self._session_id, url, timeout_ms)
        _log.debug("[navigate] → %s", result[:80] if result else "")
        return result

    def click(
        self,
        selector: str,
        timeout_ms: int = 5000,
        move_cursor: bool = False,
    ) -> None:
        """
        Click element by CSS selector.

        Args:
            selector: CSS selector
            timeout_ms: Timeout in milliseconds
            move_cursor: If True, move cursor to element before clicking (human-like)
        """
        if move_cursor:
            _log.debug("[click] moving cursor to %s", selector[:60])
            self.hover(selector, timeout_ms)
        _log.debug("[click] %s", selector[:60])
        self._service.click(self._session_id, selector, timeout_ms)

    def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """Type text into element."""
        _log.debug("[type] %s → '%s'", selector[:40], text[:30] if len(text) <= 30 else text[:27] + "...")
        self._service.type(self._session_id, selector, text, human_like, clear_first)

    def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        """Wait for element to appear."""
        return self._service.wait_for(self._session_id, selector, timeout_ms)

    # === Extraction ===

    def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """Extract text/attributes from elements."""
        return self._service.extract(self._session_id, selector, attr, limit)

    def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """Extract data using regex pattern."""
        return self._service.extract_regex(self._session_id, pattern, from_html, limit)

    def get_html(self, selector: str | None = None) -> str:
        """Get page HTML."""
        return self._service.get_html(self._session_id, selector)

    def get_text(self, selector: str | None = None) -> str:
        """Get page text content."""
        return self._service.get_text(self._session_id, selector)

    def parse_html(self, html: str | None = None, selector: str | None = None) -> "BeautifulSoup":
        """
        Parse HTML with BeautifulSoup.

        Args:
            html: HTML string to parse. If None, fetches from page.
            selector: CSS selector to get HTML from (if html not provided).

        Returns:
            BeautifulSoup object for easy parsing.

        Raises:
            ImportError: If beautifulsoup4 not installed.

        Example:
            soup = browser.parse_html()  # Parse entire page
            soup = browser.parse_html(selector="[role='feed']")  # Parse feed only

            for item in soup.select('.item'):
                title = item.select_one('h2').get_text(strip=True)
        """
        if html is None:
            html = self.get_html(selector)
        return _parse_html(html)

    def soup(self, selector: str | None = None) -> SoupWrapper:
        """
        Get page HTML as SoupWrapper with chainable API.

        Args:
            selector: CSS selector to limit scope (optional)

        Returns:
            SoupWrapper with convenience methods

        Example:
            # Get all links
            links = browser.soup().links("a.product")

            # Get text from elements
            titles = browser.soup("[role='feed']").texts("h2")

            # Chain selects
            for item in browser.soup().select(".item"):
                title = item.select_one("h2").text()
                url = item.attr("href")
        """
        html = self.get_html(selector)
        return SoupWrapper(html=html)

    # === JavaScript Execution ===

    def execute_script(self, script: str) -> str:
        """Execute JavaScript (raw, no wrapper)."""
        return self._service.execute_script(self._session_id, script)

    def execute_js(self, code: str, raw: bool = False) -> dict | list | str | None:
        """
        Execute async JavaScript with auto-wrap.

        Code is wrapped in async IIFE with try/catch and JSON serialization.

        Args:
            code: JS code to execute (can use await)
            raw: If True, return raw JSON string. Default False (parse to dict/list).

        Example:
            result = session.execute_js('''
                const resp = await fetch('/api/data');
                return await resp.json();
            ''')
        """
        js = self._build_execute_js(code)
        result = self.execute_script(js)
        return self._parse_execute_js(result, raw)

    def fetch_json(self, url: str) -> dict | list | None:
        """Fetch JSON from URL using JS fetch()."""
        js = self._build_fetch_json(url)
        result = self.execute_script(js)
        return parse_json_result(result)

    def fetch_all(
        self,
        urls: dict[str, str],
        headers: dict[str, str] | None = None,
        credentials: bool = False,
    ) -> dict[str, Any]:
        """
        Fetch multiple URLs in parallel.

        Args:
            urls: Dict of {id: url} to fetch
            headers: Optional headers (accept: application/json by default)
            credentials: Include credentials/cookies (default False, may break CORS)

        Returns:
            Dict of {id: {data: ..., error: ...}}
        """
        if not urls:
            return {}
        js = self._build_fetch_all(urls, headers, credentials)
        result = self.execute_js(js)
        return self._parse_fetch_all(result)

    # === State & Cookies ===

    def screenshot(self, full_page: bool = False) -> bytes:
        """Take screenshot."""
        return self._service.screenshot(self._session_id, full_page)

    def get_state(self) -> BrowserState:
        """Get current browser state."""
        return self._service.get_state(self._session_id)

    def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        """Set browser cookies."""
        self._service.set_cookies(self._session_id, cookies)

    def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        """Get browser cookies."""
        return self._service.get_cookies(self._session_id, domain)

    # === Parser helpers ===

    def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        """Validate CSS selectors on page."""
        return self._service.validate_selectors(self._session_id, item, fields)

    def extract_data(self, item: str, fields_json: str, limit: int = 100) -> dict:
        """Extract structured data from page."""
        return self._service.extract_data(self._session_id, item, fields_json, limit)

    # === Mouse & Scroll (native, not JS) ===

    def mouse_move(self, x: int, y: int, steps: int = 10) -> None:
        """
        Move mouse to coordinates with human-like movement.

        Args:
            x: Target X coordinate
            y: Target Y coordinate
            steps: Number of intermediate steps (1 = instant, >1 = smooth)

        Example:
            browser.mouse_move(500, 300)  # Smooth move
            browser.mouse_move(100, 100, steps=1)  # Instant move
        """
        _log.debug("[mouse_move] x=%d, y=%d, steps=%d", x, y, steps)
        self._service.mouse_move(self._session_id, x, y, steps)

    def scroll(
        self,
        direction: str = "down",
        amount: int = 500,
        selector: str | None = None,
        smooth: bool = True,
    ) -> ScrollResult:
        """
        Scroll the page (native, not JS).

        Args:
            direction: "up", "down", "left", "right"
            amount: Pixels to scroll
            selector: If provided, scroll element into view instead
            smooth: Use smooth scroll animation (default True)

        Returns:
            ScrollResult with position info

        Example:
            # Fast scroll
            browser.scroll("down", 800)

            # Scroll element into view
            browser.scroll(selector=".target-element")
        """
        if selector:
            _log.debug("[scroll_to] %s", selector[:60])
        else:
            _log.debug("[scroll] %s %dpx", direction, amount)

        data = self._service.scroll(self._session_id, direction, amount, selector, smooth)
        scroll_result = ScrollResult(
            success=True,
            scroll_y=data.get("scroll_y", 0),
            scrolled_by=data.get("scrolled_by", 0),
            at_bottom=data.get("at_bottom", False),
        )
        _log.debug("[scroll] → y=%d, by=%d, bottom=%s", scroll_result.scroll_y, scroll_result.scrolled_by, scroll_result.at_bottom)
        return scroll_result

    # def scroll_js(
    #     self,
    #     direction: str = "down",
    #     amount: int = 500,
    #     selector: str | None = None,
    #     smooth: bool = True,
    #     human_like: bool = False,
    #     container: str | None = None,
    # ) -> ScrollResult:
    #     """Scroll the page (JS fallback)."""
    #     js = self._build_scroll(direction, amount, selector, smooth, human_like, container)
    #     result = self.execute_script(js)
    #     data = parse_json_result(result) or {}
    #     return ScrollResult(
    #         success=data.get("success", False),
    #         scroll_y=int(data.get("scrollY", 0)),
    #         scrolled_by=int(data.get("scrolledBy", 0)),
    #         at_bottom=data.get("atBottom", False),
    #         error=data.get("error"),
    #     )

    def scroll_to(self, selector: str) -> ScrollResult:
        """Scroll element into view."""
        _log.debug("[scroll_to] %s", selector[:60])
        return self.scroll(selector=selector)

    def scroll_to_bottom(self) -> ScrollResult:
        """Scroll to page bottom."""
        js = self._build_scroll_to_bottom()
        result = self.execute_script(js)
        data = parse_json_result(result) or {}
        return ScrollResult(
            success=data.get("success", False),
            scroll_y=int(data.get("scrollY", 0)),
            scrolled_by=int(data.get("scrolledBy", 0)),
            at_bottom=True,
        )

    def get_scroll_info(self) -> ScrollInfo:
        """Get current scroll position and page dimensions (JS-based)."""
        js = self._build_get_scroll_info()
        result = self.execute_script(js)
        data = parse_json_result(result) or {}
        return ScrollInfo(
            scroll_x=int(data.get("scrollX", 0)),
            scroll_y=int(data.get("scrollY", 0)),
            page_height=int(data.get("pageHeight", 0)),
            page_width=int(data.get("pageWidth", 0)),
            viewport_height=int(data.get("viewportHeight", 0)),
            viewport_width=int(data.get("viewportWidth", 0)),
            at_bottom=data.get("atBottom", False),
            at_top=data.get("atTop", True),
        )

    def get_page_info(self) -> PageInfo:
        """Get comprehensive page info (native)."""
        return self._service.get_page_info(self._session_id)

    def scroll_and_collect(
        self,
        seen_keys: set[str],
        key_selector: str = "a[href]",
        key_attr: str = "href",
        container_selector: str = "body",
    ) -> InfiniteScrollResult:
        """
        Extract new keys from page, for infinite scroll patterns.

        Args:
            seen_keys: Set of already seen keys (will be updated)
            key_selector: CSS selector for elements with keys
            key_attr: Attribute to use as key
            container_selector: Container to search in

        Returns:
            InfiniteScrollResult with new keys found
        """
        js = build_infinite_scroll_js(
            list(seen_keys), key_selector, key_attr, container_selector
        )
        result = self.execute_script(js)
        data = parse_json_result(result) or {}

        new_keys = data.get("new_keys", [])
        seen_keys.update(new_keys)

        return InfiniteScrollResult(
            new_keys=new_keys,
            at_bottom=data.get("at_bottom", False),
            total_seen=data.get("total_seen", len(seen_keys)),
            error=data.get("error"),
        )

    def infinite_scroll(
        self,
        extract_fn: Callable[[], list[Any]],
        limit: int = 100,
        max_scrolls: int = 50,
        max_no_new: int = 3,
        scroll_amount: int = 800,
        delay: float = 1.0,
    ) -> list[Any]:
        """
        Smart infinite scroll with extraction.

        Args:
            extract_fn: Function that extracts and returns new items (deduplication is caller's responsibility)
            limit: Stop after collecting this many items
            max_scrolls: Maximum scroll attempts
            max_no_new: Stop after this many scrolls with no new items
            scroll_amount: Pixels to scroll each time
            delay: Seconds to wait between scrolls

        Returns:
            List of all extracted items
        """
        all_items: list[Any] = []
        no_new_count = 0

        for _ in range(max_scrolls):
            new_items = extract_fn()

            if new_items:
                all_items.extend(new_items)
                no_new_count = 0
                if len(all_items) >= limit:
                    break
            else:
                no_new_count += 1
                if no_new_count >= max_no_new:
                    break

            self.scroll("down", scroll_amount)
            time.sleep(delay)

        return all_items[:limit]

    # === UI Interaction Helpers ===

    def hover(self, selector: str, timeout_ms: int = 5000) -> None:
        """Hover over element (native, not JS)."""
        _log.debug("[hover] %s", selector[:60])
        self._service.hover(self._session_id, selector, timeout_ms)

    # def hover_js(self, selector: str) -> bool:
    #     """Hover over element (JS fallback)."""
    #     js = self._build_hover(selector)
    #     result = self.execute_script(js)
    #     data = parse_json_result(result) or {}
    #     return data.get("success", False)

    def select(
        self,
        selector: str,
        value: str | None = None,
        text: str | None = None,
    ) -> dict:
        """
        Select option from dropdown.

        Args:
            selector: CSS selector for <select> element
            value: Option value to select
            text: Option text to select (if value not provided)

        Returns:
            Dict with selected_value and selected_text
        """
        js = self._build_select(selector, value, text)
        result = self.execute_script(js)
        return parse_json_result(result) or {}

    def close_modal(self, selectors: list[str] | None = None) -> bool:
        """
        Try to close modal/dialog.

        Args:
            selectors: Custom close button selectors to try

        Returns:
            True if modal was closed
        """
        js = self._build_close_modal(selectors)
        result = self.execute_script(js)
        data = parse_json_result(result) or {}
        return data.get("success", False)

    def wait(self, ms: int, jitter: float = 0.1) -> None:
        """
        Wait for specified milliseconds with optional jitter.

        Args:
            ms: Wait time in milliseconds
            jitter: Random variation ±jitter (default 10%, so 1000ms becomes 900-1100ms)
        """
        import random
        actual = (ms / 1000) * (1 + random.uniform(-jitter, jitter))
        time.sleep(actual)

    def wait_seconds(self, seconds: float, jitter: float = 0.1) -> None:
        """
        Wait for specified seconds with optional jitter.

        Args:
            seconds: Base wait time in seconds
            jitter: Random variation ±jitter (default 10%, so 1.0s becomes 0.9-1.1s)
        """
        self.wait(int(seconds * 1000), jitter)

    def wait_random(self, min_sec: float = 0.5, max_sec: float = 1.5) -> None:
        """Wait for random time between min and max seconds."""
        import random
        time.sleep(min_sec + random.random() * (max_sec - min_sec))

    def click_all_by_text(self, text: str, role: str = "button") -> int:
        """
        Click all elements containing specific text.

        Args:
            text: Text to match (case-insensitive)
            role: Element role to filter (default: "button")

        Returns:
            Number of elements clicked

        Example:
            browser.click_all_by_text("See more")  # Expand all posts
            browser.click_all_by_text("Load more", role="link")
        """
        _log.debug("[click_all_by_text] '%s' role=%s", text, role)
        js = self._build_click_all_by_text(text, role)
        result = self.execute_script(js)
        data = parse_json_result(result) or {}
        clicked = data.get("clicked", 0)
        _log.debug("[click_all_by_text] → clicked %d", clicked)
        return clicked

    def press_key(self, key: str, selector: str | None = None) -> bool:
        """
        Press a keyboard key.

        Args:
            key: Key to press (e.g., 'Escape', 'Enter', 'Tab', 'ArrowDown')
            selector: Optional CSS selector to target. If None, targets activeElement.

        Returns:
            True if key was pressed successfully

        Example:
            browser.press_key('Escape')  # Close modal
            browser.press_key('Enter', 'input.search')  # Submit search
            browser.press_key('Tab')  # Move focus
        """
        target = selector[:40] if selector else "activeElement"
        _log.debug("[press_key] %s → %s", key, target)
        js = self._build_press_key(key, selector)
        result = self.execute_script(js)
        data = parse_json_result(result) or {}
        return data.get("success", False)

    # === Context Manager ===

    def close(self) -> None:
        """Close browser session."""
        self._service.close_session(self._session_id)

    def __enter__(self) -> "BrowserSession":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
