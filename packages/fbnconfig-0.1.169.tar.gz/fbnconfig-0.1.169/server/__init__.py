"""fbnconfig server application module."""
