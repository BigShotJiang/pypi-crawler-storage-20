{{- define "git.branch" -}}
feature/DVPS-9546--Containerising-fbnconfig
{{- end -}}

{{- define "version.file" -}}
fbnconfig.version
{{- end -}}

{{- define "version.initial" -}}
0.0.1
{{- end -}}

{{- define "version.bump" -}}
bump: patch
{{- end -}}

