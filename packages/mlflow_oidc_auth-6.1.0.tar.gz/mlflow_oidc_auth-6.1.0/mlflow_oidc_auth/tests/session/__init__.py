"""
Session management tests package.
"""
