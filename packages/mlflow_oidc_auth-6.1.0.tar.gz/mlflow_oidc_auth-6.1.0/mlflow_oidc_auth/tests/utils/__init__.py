# Tests for utility functions
