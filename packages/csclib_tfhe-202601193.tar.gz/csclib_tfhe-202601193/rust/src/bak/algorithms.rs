use tfhe::core_crypto::prelude::*;
use crate::params::PARAMS;
use crate::print::*;
use crate::keyswitch::*;


pub fn cswap(c: &LweCiphertextOwned<u64>, x: &Vec<LweCiphertextOwned<u64>>, i: usize, j: usize,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
     -> Vec<LweCiphertextOwned<u64>> {
    let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
    // print_ctx_list(&big_lwe_sk, &x);
    
    let x_i = x[i].clone();
    let x_j = x[j].clone();
    
    // KS
    let mut c_keyswitched = LweCiphertext::new(
        0,
        PARAMS.lwe_dimension().to_lwe_size(),
        PARAMS.ciphertext_modulus(),
    );
    par_keyswitch_lwe_ciphertext(&ksk, &c, &mut c_keyswitched);
    
    // LUT の作成
    let mut accumulator = GlweCiphertext::new(
        0u64,
        PARAMS.glwe_dimension().to_glwe_size(),
        PARAMS.polynomial_size(),
        PARAMS.ciphertext_modulus(),
    );

    packing_two_lwe_into_glwe_index_0_1_bit(
        &pksk, 
        &x_i, 
        &x_j, 
        &mut accumulator,
        box_size,
    );

    // BR
    multi_bit_blind_rotate_assign(
        &c_keyswitched,
        &mut accumulator,
        &fourier_bsk,
        thread_count,
    );
      
    // SE
    let mut x_i_new = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );

    

    extract_lwe_sample_from_glwe_ciphertext(
        &accumulator,
        &mut x_i_new,
        MonomialDegree(box_size/2 as usize),
    );

    let mut x_i_plus_x_j = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );
    lwe_ciphertext_add(&mut x_i_plus_x_j, &x_i, &x_j);

    let mut x_j_new = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );
    lwe_ciphertext_sub(&mut x_j_new, &x_i_plus_x_j, &x_i_new);

    let mut x_new = x.clone();
    x_new[i] = x_i_new;
    x_new[j] = x_j_new;
    return x_new;

}

pub fn cswap_multibit(c: &LweCiphertextOwned<u64>, x: &Vec<Vec<LweCiphertextOwned<u64>>>, i: usize, j: usize,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
     -> Vec<Vec<LweCiphertextOwned<u64>>> {
    let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
    // print_ctx_list(&big_lwe_sk, &x);
    
    let x_i = x[i].clone();
    let x_j = x[j].clone();

    let mut x_i_new: Vec<LweCiphertextOwned<u64>> = Vec::new();
    let mut x_j_new: Vec<LweCiphertextOwned<u64>> = Vec::new();

    for bit in 0..x_i.len() {
        let x_i_bit = x_i[bit].clone();
        let x_j_bit = x_j[bit].clone();
        // KS
        let mut c_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &c, &mut c_keyswitched);
        
        // LUT の作成
        let mut accumulator = GlweCiphertext::new(
            0u64,
            PARAMS.glwe_dimension().to_glwe_size(),
            PARAMS.polynomial_size(),
            PARAMS.ciphertext_modulus(),
        );

        packing_two_lwe_into_glwe_index_0_1_bit(
            &pksk, 
            &x_i_bit, 
            &x_j_bit, 
            &mut accumulator,
            box_size,
        );

        // BR
        multi_bit_blind_rotate_assign(
            &c_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
          
        // SE
        let mut x_i_new_bit = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );

        

        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut x_i_new_bit,
            MonomialDegree(box_size/2 as usize),
        );

        let mut x_i_plus_x_j = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        lwe_ciphertext_add(&mut x_i_plus_x_j, &x_i_bit, &x_j_bit);

        let mut x_j_new_bit = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        lwe_ciphertext_sub(&mut x_j_new_bit, &x_i_plus_x_j, &x_i_new_bit);
        x_i_new.push(x_i_new_bit);
        x_j_new.push(x_j_new_bit);
    }
    
    let mut x_new = x.clone();
    x_new[i] = x_i_new;
    x_new[j] = x_j_new;
    return x_new;

}


pub fn cswap_two_lwe(c: &LweCiphertextOwned<u64>, x: &LweCiphertextOwned<u64>, y: &LweCiphertextOwned<u64>,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
     -> (LweCiphertextOwned<u64>, LweCiphertextOwned<u64>) {
    let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;

    // KS
    let mut c_keyswitched = LweCiphertext::new(
        0,
        PARAMS.lwe_dimension().to_lwe_size(),
        PARAMS.ciphertext_modulus(),
    );
    par_keyswitch_lwe_ciphertext(&ksk, &c, &mut c_keyswitched);
    
    // LUT の作成
    let mut accumulator = GlweCiphertext::new(
        0u64,
        PARAMS.glwe_dimension().to_glwe_size(),
        PARAMS.polynomial_size(),
        PARAMS.ciphertext_modulus(),
    );

    packing_two_lwe_into_glwe_index_0_1_bit(
        &pksk, 
        &x, 
        &y, 
        &mut accumulator,
        box_size,
    );

    // BR
    multi_bit_blind_rotate_assign(
        &c_keyswitched,
        &mut accumulator,
        &fourier_bsk,
        thread_count,
    );
      
    // SE
    let mut x_new = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );
    

    extract_lwe_sample_from_glwe_ciphertext(
        &accumulator,
        &mut x_new,
        MonomialDegree(box_size/2 + box_size * 0 as usize),
    );

    let mut x_plus_y = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );
    lwe_ciphertext_add(&mut x_plus_y, &x, &y);
    let mut y_new = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );
    lwe_ciphertext_sub(&mut y_new, &x_plus_y, &x_new);
    
    return (x_new, y_new);

}



pub fn cswap_list(c: &LweCiphertextOwned<u64>, x: &Vec<LweCiphertextOwned<u64>>, y: &Vec<LweCiphertextOwned<u64>>,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    -> (Vec<LweCiphertextOwned<u64>>, Vec<LweCiphertextOwned<u64>>) {
        let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
        let len = x.len();
        let mut x_new: Vec<LweCiphertextOwned<u64>> = Vec::new();
        let mut y_new: Vec<LweCiphertextOwned<u64>> = Vec::new();
        // KS
        let mut c_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &c, &mut c_keyswitched);
        for i in 0..len {
            let x_i = x[i].clone();
            let y_i = y[i].clone();
            // LUT の作成
            let mut accumulator = GlweCiphertext::new(
                0u64,
                PARAMS.glwe_dimension().to_glwe_size(),
                PARAMS.polynomial_size(),
                PARAMS.ciphertext_modulus(),
            );

            packing_two_lwe_into_glwe_index_0_1_bit(
                &pksk, 
                &x_i, 
                &y_i, 
                &mut accumulator,
                box_size,
            );

            // BR
            multi_bit_blind_rotate_assign(
                &c_keyswitched,
                &mut accumulator,
                &fourier_bsk,
                thread_count,
            );
            
            // SE
            let mut x_i_new = LweCiphertext::new(
                0,
                LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
                PARAMS.ciphertext_modulus(),
            );

            
            let mut y_i_new = LweCiphertext::new(
                0,
                LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
                PARAMS.ciphertext_modulus(),
            );

            extract_lwe_sample_from_glwe_ciphertext(
                &accumulator,
                &mut x_i_new,
                MonomialDegree(box_size/2 + box_size * 0 as usize),
            );

            let mut x_i_plus_y_i = LweCiphertext::new(
                0,
                LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
                PARAMS.ciphertext_modulus(),
            );
            lwe_ciphertext_add(&mut x_i_plus_y_i, &x_i, &y_i);
            lwe_ciphertext_sub(&mut y_i_new, &x_i_plus_y_i, &x_i_new);

            x_new.push(x_i_new);
            y_new.push(y_i_new);
        }
        return (x_new, y_new);
}

pub fn ifthenelse(c: &LweCiphertextOwned<u64>, t: &LweCiphertextOwned<u64>, f: &LweCiphertextOwned<u64>,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    -> LweCiphertextOwned<u64> {
    let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
    // KS
    let mut c_keyswitched = LweCiphertext::new(
        0,
        PARAMS.lwe_dimension().to_lwe_size(),
        PARAMS.ciphertext_modulus(),
    );
    par_keyswitch_lwe_ciphertext(&ksk, &c, &mut c_keyswitched);
    
    // LUT の作成
    let mut accumulator = GlweCiphertext::new(
        0u64,
        PARAMS.glwe_dimension().to_glwe_size(),
        PARAMS.polynomial_size(),
        PARAMS.ciphertext_modulus(),
    );

    packing_two_lwe_into_glwe_index_0_1_bit(
        &pksk, 
        &f, 
        &t, 
        &mut accumulator,
        box_size,
    );

    // BR
    multi_bit_blind_rotate_assign(
        &c_keyswitched,
        &mut accumulator,
        &fourier_bsk,
        thread_count,
    );
      
    // SE
    let mut x = LweCiphertext::new(
        0,
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
        PARAMS.ciphertext_modulus(),
    );

    extract_lwe_sample_from_glwe_ciphertext(
        &accumulator,
        &mut x,
        MonomialDegree(box_size/2 as usize),
    );
    return x;

}

pub fn array_read(x: &Vec<LweCiphertextOwned<u64>>, i: &LweCiphertextOwned<u64>, 
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
     -> LweCiphertextOwned<u64> {
    return ifthenelse(&i, &x[1], &x[0], &ksk, &pksk, &fourier_bsk, thread_count);
}

pub fn array_write(x: &Vec<LweCiphertextOwned<u64>>, i: &LweCiphertextOwned<u64>, v: LweCiphertextOwned<u64>, 
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
     -> Vec<LweCiphertextOwned<u64>> {
    let mut x_new = x.clone();
    x_new[0] = ifthenelse(&i, &x[0], &v, &ksk, &pksk, &fourier_bsk, thread_count);
    x_new[1] = ifthenelse(&i, &v, &x[1], &ksk, &pksk, &fourier_bsk, thread_count);
    return x_new;
}

// pub fn butterfly(x: &Vec<LweCiphertextOwned<u64>>) -> Vec<LweCiphertextOwned<u64>> {
//     let n = x.len();
//     let mut y = x.clone();
//     let k = n / 2;
//     let mut i = 0;
//     while i < k {
//         y[i] = x[2*i].clone();
//         y[i+k] = x[2*i+1].clone();
//         i += 1;
//     }
//     return y;
// }




// pub fn butterfly_vec(x: &Vec<Vec<LweCiphertextOwned<u64>>>) -> Vec<Vec<LweCiphertextOwned<u64>>> {
//     let n = x.len();
//     let mut y = x.clone();
//     let k = n / 2;
//     let mut i = 0;
//     while i < k {
//         y[i] = x[2*i].clone();
//         y[i+k] = x[2*i+1].clone();
//         i += 1;
//     }
//     return y;
// }
pub fn butterfly<T: Clone>(x: &Vec<T>) -> Vec<T> {
    let n = x.len();
    let mut y = x.clone();
    let k = n / 2;
    let mut i = 0;
    while i < k {
        y[i] = x[2*i].clone();
        y[i+k] = x[2*i+1].clone();
        i += 1;
    }
    return y;
}



// pub fn butterfly_inv(x: &Vec<LweCiphertextOwned<u64>>) -> Vec<LweCiphertextOwned<u64>> {
//     let n = x.len();
//     let mut y = x.clone();
//     let k = n / 2;
//     let mut i = 0;
//     while i < k {
//         y[2*i] = x[i].clone();
//         y[2*i+1] = x[i+k].clone();
//         i += 1;
//     }
//     return y;
// }

// pub fn butterfly_inv_vec(x: &Vec<Vec<LweCiphertextOwned<u64>>>) -> Vec<Vec<LweCiphertextOwned<u64>>> {
//     let n = x.len();
//     let mut y = x.clone();
//     let k = n / 2;
//     let mut i = 0;
//     while i < k {
//         y[2*i] = x[i].clone();
//         y[2*i+1] = x[i+k].clone();
//         i += 1;
//     }
//     return y;
// }

pub fn butterfly_inv<T: Clone>(x: &Vec<T>) -> Vec<T> {
    let n = x.len();
    let mut y = x.clone();
    let k = n / 2;
    let mut i = 0;
    while i < k {
        y[2*i] = x[i].clone();
        y[2*i+1] = x[i+k].clone();
        i += 1;
    }
    return y;
}


pub fn blog(mut x: u64) -> i32 {
    let mut l = -1;
    while x > 0 {
        x >>= 1;
        l += 1;
    }
    return l;
}

pub fn xor(a: &LweCiphertextOwned<u64>, b: &LweCiphertextOwned<u64>,ksk: &LweKeyswitchKey<Vec<u64>>, 
    pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    -> (LweCiphertextOwned<u64>) {
        let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);

        let trivial_one = allocate_and_trivially_encrypt_new_lwe_ciphertext(
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(1 * delta), PARAMS.ciphertext_modulus()
        );
        // KS
        let mut a_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &a, &mut a_keyswitched);

        // LUTの作成
        let mut lut_plaintext = PlaintextList::new(0, PlaintextCount(PARAMS.polynomial_size().0));
        for element in lut_plaintext.as_mut()[box_size..2*box_size].iter_mut() {
            *element = 1%PARAMS.message_modulus().0 as u64 * delta;
        }
        
        let mut accumulator: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
            PARAMS.glwe_dimension().to_glwe_size(), &lut_plaintext, 
            PARAMS.ciphertext_modulus()
        );
        // BR
        multi_bit_blind_rotate_assign(
            &a_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
        // SE
        let mut c = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut c,
            MonomialDegree(box_size/2),
        );
        let mut c_bar = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        lwe_ciphertext_sub(&mut c_bar, &trivial_one, &c);
        // PKS
        packing_keyswitch_for_bitwise_xor(&pksk, &c, &c_bar, box_size, &mut accumulator);
        // KS
        let mut b_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &b, &mut b_keyswitched);
        // BR
        multi_bit_blind_rotate_assign(
            &b_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
        // SE
        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut c,
            MonomialDegree(box_size/2),
        );
        return c;

}

pub fn and(a: &LweCiphertextOwned<u64>, b: &LweCiphertextOwned<u64>,ksk: &LweKeyswitchKey<Vec<u64>>, 
    pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    -> (LweCiphertextOwned<u64>) {
        let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);

        // KS
        let mut a_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &a, &mut a_keyswitched);

        // LUTの作成
        let mut lut_plaintext = PlaintextList::new(0, PlaintextCount(PARAMS.polynomial_size().0));
        for element in lut_plaintext.as_mut()[1*box_size..2*box_size].iter_mut() {
            *element = 1%PARAMS.message_modulus().0 as u64 * delta;
        }
        
        let mut accumulator: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
            PARAMS.glwe_dimension().to_glwe_size(), &lut_plaintext, 
            PARAMS.ciphertext_modulus()
        );
        // BR
        multi_bit_blind_rotate_assign(
            &a_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
        // SE
        let mut c = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut c,
            MonomialDegree(box_size/2),
        );

        // PKS
        packing_keyswitch_for_bitwise_and(&pksk, &c, box_size, &mut accumulator);
        // KS
        let mut b_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &b, &mut b_keyswitched);
        // BR
        multi_bit_blind_rotate_assign(
            &b_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
        // SE
        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut c,
            MonomialDegree(box_size/2),
        );
        return c;

}


pub fn mod2(a: &LweCiphertextOwned<u64>, ksk: &LweKeyswitchKey<Vec<u64>>, 
    pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    -> (LweCiphertextOwned<u64>) {
        let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
        
        // KS
        let mut a_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &a, &mut a_keyswitched);

        // LUTの作成
        let mut lut_plaintext = PlaintextList::new(0, PlaintextCount(PARAMS.polynomial_size().0));
        for i in 0..PARAMS.message_modulus().0/2 {
            for element in lut_plaintext.as_mut()[(2*i+1)*box_size..(2*i+2)*box_size].iter_mut() {
                *element = 1%PARAMS.message_modulus().0 as u64 * delta;
            }
            
        }
        
        let mut accumulator: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
            PARAMS.glwe_dimension().to_glwe_size(), &lut_plaintext, 
            PARAMS.ciphertext_modulus()
        );
        // BR
        multi_bit_blind_rotate_assign(
            &a_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
        // SE
        let mut a_mod2 = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut a_mod2,
            MonomialDegree(box_size/2),
        );
        return a_mod2;

}



pub fn div2(a: &LweCiphertextOwned<u64>, ksk: &LweKeyswitchKey<Vec<u64>>, 
    pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    -> (LweCiphertextOwned<u64>) {
        let box_size = PARAMS.polynomial_size().0 / (PARAMS.message_modulus().0 * PARAMS.carry_modulus().0) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
        
        // KS
        let mut a_keyswitched = LweCiphertext::new(
            0,
            PARAMS.lwe_dimension().to_lwe_size(),
            PARAMS.ciphertext_modulus(),
        );
        par_keyswitch_lwe_ciphertext(&ksk, &a, &mut a_keyswitched);

        // LUTの作成
        let mut lut_plaintext = PlaintextList::new(0, PlaintextCount(PARAMS.polynomial_size().0));
        for i in 0..PARAMS.message_modulus().0/2 {
            for element in lut_plaintext.as_mut()[i*box_size..(i+1)*box_size].iter_mut() {
                *element = ((i / 2) as usize % PARAMS.message_modulus().0) as u64 * delta;
            }
            
        }
        
        let mut accumulator: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
            PARAMS.glwe_dimension().to_glwe_size(), &lut_plaintext, 
            PARAMS.ciphertext_modulus()
        );
        // BR
        multi_bit_blind_rotate_assign(
            &a_keyswitched,
            &mut accumulator,
            &fourier_bsk,
            thread_count,
        );
        // SE
        let mut a_mod2 = LweCiphertext::new(
            0,
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1),
            PARAMS.ciphertext_modulus(),
        );
        extract_lwe_sample_from_glwe_ciphertext(
            &accumulator,
            &mut a_mod2,
            MonomialDegree(box_size/2),
        );
        return a_mod2;

}