
use tfhe::{core_crypto::prelude::*, shortint::{CarryModulus, MessageModulus}};

mod params;
use params::PARAMS;
mod print;
use print::*;
mod benes;
mod keyswitch;
use benes::*;
mod algorithms;
use algorithms::*;
//use num_complex::Complex;
//use aligned_vec::*;

pub struct TfheParam {
    small_lwe_dimension: LweDimension,
    glwe_dimension: GlweDimension,
    polynomial_size: PolynomialSize,
    lwe_modular_std_dev: StandardDev,
    glwe_modular_std_dev: StandardDev,
    pbs_base_log: DecompositionBaseLog,
    pbs_level: DecompositionLevelCount,
    ks_level: DecompositionLevelCount,
    ks_base_log: DecompositionBaseLog,
    message_modulus: MessageModulus,
    carry_modulus: CarryModulus,
    ciphertext_modulus: CiphertextModulus<u64>,
    grouping_factor: LweBskGroupingFactor,
    thread_count: ThreadCount,
    delta: u64,
    rounding_bit: u64,

    small_lwe_sk: LweSecretKey<Vec<u64>>,
    glwe_sk: GlweSecretKey<Vec<u64>>,
    big_lwe_sk: LweSecretKey<Vec<u64>>,
    secret_generator: SecretRandomGenerator<ActivatedRandomGenerator>,
    encryption_generator: EncryptionRandomGenerator<ActivatedRandomGenerator>,
    bsk: LweMultiBitBootstrapKey<Vec<u64>>,
    fourier_bsk: FourierLweMultiBitBootstrapKeyOwned,
    ksk: LweKeyswitchKey<Vec<u64>>,
    pksk: LwePackingKeyswitchKey<Vec<u64>>,
}

fn tfhe_param_new() -> TfheParam {
    let message_modulus = PARAMS.message_modulus();
    let carry_modulus = PARAMS.carry_modulus();
    let delta = (1_u64 << 63) / (message_modulus.0 as u64 * carry_modulus.0 as u64);

    let mut boxed_seeder = new_seeder();
    let seeder = boxed_seeder.as_mut();
    let mut secret_generator =
        SecretRandomGenerator::<ActivatedRandomGenerator>::new(seeder.seed());
    let mut encryption_generator =
        EncryptionRandomGenerator::<ActivatedRandomGenerator>::new(seeder.seed(), seeder);

    let small_lwe_dimension = PARAMS.lwe_dimension();
    let glwe_dimension = PARAMS.glwe_dimension();
    let polynomial_size = PARAMS.polynomial_size();


    print!("Generating keys...2");
    let small_lwe_sk =
        LweSecretKey::generate_new_binary(small_lwe_dimension, &mut secret_generator);
    let glwe_sk =
        GlweSecretKey::generate_new_binary(glwe_dimension, polynomial_size, &mut secret_generator);
    let big_lwe_sk = glwe_sk.clone().into_lwe_secret_key();

    let ks_level = PARAMS.ks_level();
    let ks_base_log = PARAMS.ks_base_log();
    let pbs_base_log = PARAMS.pbs_base_log();
    let pbs_level = PARAMS.pbs_level();

    let lwe_modular_std_dev= PARAMS.lwe_modular_std_dev();
    let glwe_modular_std_dev = PARAMS.glwe_modular_std_dev();

    let ciphertext_modulus = PARAMS.ciphertext_modulus();
    let grouping_factor = LweBskGroupingFactor(2);

    let mut bsk = LweMultiBitBootstrapKey::new(
        0u64,
        glwe_dimension.to_glwe_size(),
        polynomial_size,
        pbs_base_log,
        pbs_level,
        small_lwe_dimension,
        grouping_factor,
        ciphertext_modulus,
    );
    let mut fourier_bsk = FourierLweMultiBitBootstrapKey::new(
        bsk.input_lwe_dimension(),
        bsk.glwe_size(),
        bsk.polynomial_size(),
        bsk.decomposition_base_log(),
        bsk.decomposition_level_count(),
        bsk.grouping_factor(),
    );
    par_convert_standard_lwe_multi_bit_bootstrap_key_to_fourier(&bsk, &mut fourier_bsk);
    //drop(bsk);

    let ksk = allocate_and_generate_new_lwe_keyswitch_key(
        &big_lwe_sk,
        &small_lwe_sk,
        ks_base_log,
        ks_level,
        lwe_modular_std_dev,
        ciphertext_modulus,
        &mut encryption_generator,
    );
    let pksk = allocate_and_generate_new_lwe_packing_keyswitch_key(
        &big_lwe_sk,
        &glwe_sk,
        pbs_base_log,
        pbs_level,
        glwe_modular_std_dev,
        ciphertext_modulus,
        &mut encryption_generator,
    );


    let mut p = TfheParam {
        small_lwe_dimension: small_lwe_dimension,
        glwe_dimension: glwe_dimension,
        polynomial_size: polynomial_size,
        lwe_modular_std_dev: lwe_modular_std_dev,
        glwe_modular_std_dev: glwe_modular_std_dev,
        pbs_base_log: pbs_base_log,
        pbs_level: pbs_level,
        ks_level: ks_level,
        ks_base_log: ks_base_log,
        message_modulus: message_modulus,
        carry_modulus: carry_modulus,
        ciphertext_modulus: ciphertext_modulus,
        grouping_factor: grouping_factor,
        thread_count: ThreadCount(8),
        delta: delta, 
        rounding_bit: delta >> 1,
        small_lwe_sk: small_lwe_sk,
        glwe_sk: glwe_sk,
        big_lwe_sk: big_lwe_sk,
        secret_generator: secret_generator,
        encryption_generator: encryption_generator,
        bsk: bsk,
        fourier_bsk: fourier_bsk,
        ksk: ksk,
        pksk: pksk,
    };

    par_generate_lwe_multi_bit_bootstrap_key(
        &p.small_lwe_sk,
        &p.glwe_sk,
        &mut p.bsk,
        p.glwe_modular_std_dev,
        &mut p.encryption_generator,
    );



    return p;
}

fn lwe_array_new() -> Vec<LweCiphertextOwned<u64>> {
  let a: Vec<LweCiphertextOwned<u64>> = Vec::new();
  return a;
}

fn lwe_encrypt(tfhe_params: &mut TfheParam, x: u32) -> LweCiphertext<Vec<u64>> {
    let decomped = (x >> ((tfhe_params.message_modulus.0 as f64).log2() as usize * 0)) & 2_u32.pow((tfhe_params.message_modulus.0 as f64).log2() as u32) - 1;
    let decomped_ctx = allocate_and_encrypt_new_lwe_ciphertext(
        &tfhe_params.big_lwe_sk,
        Plaintext(decomped as u64 * tfhe_params.delta),
        tfhe_params.lwe_modular_std_dev,
        tfhe_params.ciphertext_modulus,
        &mut tfhe_params.encryption_generator,
    );
    return decomped_ctx;   
}

fn lwe_decomposed_array_new() -> Vec<Vec<LweCiphertextOwned<u64>>> {
    let a: Vec<Vec<LweCiphertextOwned<u64>>> = Vec::new();
    return a;
  }
  
fn lwe_encrypt_decomposed(tfhe_params: &mut TfheParam, x: u32, bit_size: usize) -> Vec<LweCiphertextOwned<u64>> {
  let mut value: Vec<LweCiphertextOwned<u64>> = Vec::new();
  for k in 0..bit_size {
      let decomped_k = (x >> ((tfhe_params.message_modulus.0 as f64).log2() as usize * k)) & 2_u32.pow((tfhe_params.message_modulus.0 as f64).log2() as u32) - 1;
      let decomped_ctx_k = allocate_and_encrypt_new_lwe_ciphertext(
          &tfhe_params.big_lwe_sk,
          Plaintext(decomped_k as u64 * tfhe_params.delta),
          tfhe_params.lwe_modular_std_dev,
          tfhe_params.ciphertext_modulus,
          &mut tfhe_params.encryption_generator,
      );
      value.push(decomped_ctx_k);
  }
  return value;
}

fn main() {

    // parameters
    let small_lwe_dimension = PARAMS.lwe_dimension();
    let glwe_dimension = PARAMS.glwe_dimension();
    let polynomial_size = PARAMS.polynomial_size();
    let lwe_modular_std_dev = PARAMS.lwe_modular_std_dev();
    let glwe_modular_std_dev = PARAMS.glwe_modular_std_dev();
    let pbs_base_log = PARAMS.pbs_base_log();
    let pbs_level = PARAMS.pbs_level();
    let ks_level = PARAMS.ks_level();
    let ks_base_log = PARAMS.ks_base_log();
    let message_modulus = PARAMS.message_modulus();
    let carry_modulus = PARAMS.carry_modulus();
    let ciphertext_modulus = PARAMS.ciphertext_modulus();

    // grouping factor must be divisor of lwe_dimension.
    let grouping_factor = LweBskGroupingFactor(2);
    let thread_count = ThreadCount(8);

    let delta = (1_u64 << 63) / (message_modulus.0 as u64 * carry_modulus.0 as u64); 
    let rounding_bit = delta >> 1;

    let mut tfhe_params = tfhe_param_new();
    
    let mut boxed_seeder = new_seeder();
    let seeder = boxed_seeder.as_mut();
    let mut secret_generator =
        SecretRandomGenerator::<ActivatedRandomGenerator>::new(seeder.seed());
    let mut encryption_generator =
        EncryptionRandomGenerator::<ActivatedRandomGenerator>::new(seeder.seed(), seeder);

    print!("Generating keys...3");
    let small_lwe_sk =
        LweSecretKey::generate_new_binary(small_lwe_dimension, &mut secret_generator);
    let glwe_sk =
        GlweSecretKey::generate_new_binary(glwe_dimension, polynomial_size, &mut secret_generator);
    let big_lwe_sk = glwe_sk.clone().into_lwe_secret_key();;

    let mut bsk = LweMultiBitBootstrapKey::new(
        0u64,
        glwe_dimension.to_glwe_size(),
        polynomial_size,
        pbs_base_log,
        pbs_level,
        small_lwe_dimension,
        grouping_factor,
        ciphertext_modulus,
    );

    par_generate_lwe_multi_bit_bootstrap_key(
        &small_lwe_sk,
        &glwe_sk,
        &mut bsk,
        glwe_modular_std_dev,
        &mut encryption_generator,
    );

    let mut fourier_bsk = FourierLweMultiBitBootstrapKey::new(
        bsk.input_lwe_dimension(),
        bsk.glwe_size(),
        bsk.polynomial_size(),
        bsk.decomposition_base_log(),
        bsk.decomposition_level_count(),
        bsk.grouping_factor(),
    );
    par_convert_standard_lwe_multi_bit_bootstrap_key_to_fourier(&bsk, &mut fourier_bsk);
    drop(bsk);

    let ksk = allocate_and_generate_new_lwe_keyswitch_key(
        &big_lwe_sk,
        &small_lwe_sk,
        ks_base_log,
        ks_level,
        lwe_modular_std_dev,
        ciphertext_modulus,
        &mut encryption_generator,
    );
    let pksk = allocate_and_generate_new_lwe_packing_keyswitch_key(
        &big_lwe_sk,
        &glwe_sk,
        pbs_base_log,
        pbs_level,
        glwe_modular_std_dev,
        ciphertext_modulus,
        &mut encryption_generator,
    );
    print!("done\n");


    // bit size長の配列をAに従って並び替える．
    let bit_size = 4;
    //let a_ptx = [0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1];
    //let a_ptx = [1, 0];
    let a_ptx = [0, 1, 1, 0];
    // let a_ptx = [0, 1, 0, 1];
    // let a_ptx = [1, 0, 1, 0];
    let value_ptx: Vec<u32> = (0..a_ptx.len() as u32).collect();
    let a_len = a_ptx.len();

    // encryption 
    let mut a: Vec<LweCiphertextOwned<u64>> = Vec::new();
    //let mut a = lwe_array_new();
    for j in 0..a_len {
        let decomped = (a_ptx[j] >> ((tfhe_params.message_modulus.0 as f64).log2() as usize * 0)) & 2_u32.pow((tfhe_params.message_modulus.0 as f64).log2() as u32) - 1;
        let decomped_ctx = allocate_and_encrypt_new_lwe_ciphertext(
            &big_lwe_sk,
            Plaintext(decomped as u64 * delta),
            lwe_modular_std_dev,
            ciphertext_modulus,
            &mut encryption_generator,
        );
        a.push(decomped_ctx);
        //let decomped_ctx = lwe_encrypt(&mut tfhe_params, a_ptx[j]);
        //a.push(decomped_ctx);
    }
    let mut value: Vec<Vec<LweCiphertextOwned<u64>>> = Vec::new();
    //let mut value = lwe_decomposed_array_new();
    for j in 0..a_len {
        let mut value_j: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for k in 0..bit_size {
            let decomped_k = (value_ptx[j] >> ((message_modulus.0 as f64).log2() as usize * k)) & 2_u32.pow((message_modulus.0 as f64).log2() as u32) - 1;
            let decomped_ctx_k = allocate_and_encrypt_new_lwe_ciphertext(
                &big_lwe_sk,
                Plaintext(decomped_k as u64 * delta),
                lwe_modular_std_dev,
                ciphertext_modulus,
                &mut encryption_generator,
            );
            value_j.push(decomped_ctx_k);
        }
        //let value_j = lwe_encrypt_decomposed(&mut tfhe_params, value_ptx[j], bit_size);
        value.push(value_j);
    }

    print!("A = ");
    print_ctx_list(&big_lwe_sk, &a);
    print!("value = ");
    print_ctx_list_multibit(&tfhe_params, &value);
    print!("\n");

    print!("benes\n");
    let (a_benes_new, value_benes_new) = benes(&a, &value, &tfhe_params, &ksk, &pksk, &fourier_bsk, tfhe_params.thread_count, &big_lwe_sk);
    print!("benes A : ");
    print_ctx_list(&big_lwe_sk, &a_benes_new);
    print!("benes value : ");
    print_ctx_list_multibit(&tfhe_params, &value_benes_new);


    print!("benes_construct\n");
    let network = benes_construct(&a, &ksk, &pksk, &fourier_bsk, tfhe_params.thread_count, &big_lwe_sk);
    print!("benes_apply\n");
    a = benes_apply(&a, &network, &ksk, &pksk, &fourier_bsk, tfhe_params.thread_count, &big_lwe_sk);
    print!("sorted A : ");
    print_ctx_list(&big_lwe_sk, &a);

    print!("benes_apply_multibit\n");
    let value_new = benes_apply_multibit(&value, &network, &ksk, &pksk, &fourier_bsk, tfhe_params.thread_count, &big_lwe_sk);
    print!("value : ");
    print_ctx_list_multibit(&tfhe_params, &value_new);

    print!("benes_apply_inv_multibit\n");
    let value_new_inv = benes_apply_inv_multibit(&value, &network, &tfhe_params.ksk, &tfhe_params.pksk, &tfhe_params.fourier_bsk, tfhe_params.thread_count, &tfhe_params.big_lwe_sk);
    print!("value2 : ");
    print_ctx_list_multibit(&tfhe_params, &value_new_inv);

    return;


    // // print!("A = ");
    // // print_ctx_list(&big_lwe_sk, &a_new);
    // // print!("value = ");
    // // print_ctx_list(&big_lwe_sk, &value_new);
    // // print_ctx_list(&big_lwe_sk, &value_new_inv);


    
    // // let test = func(&vec![1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4,]);
    // // print!("{}", test);

    let pi_ptx = [9,13,15,7,8,0,10,3,6,5,9,8,11,14,12,2];

    let x_ptx = [14,11,13,9,13,11,0,2,6,4,9,6,9,13,5,8];
    let x_len = x_ptx.len();
 
    // encryption 
    let mut x: Vec<Vec<LweCiphertextOwned<u64>>> = Vec::new();
    for j in 0..x_len {
        let mut x_j: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for k in 0..bit_size {
            let decomped_k = (x_ptx[j] >> ((tfhe_params.message_modulus.0 as f64).log2() as usize * k)) & 2_u32.pow((tfhe_params.message_modulus.0 as f64).log2() as u32) - 1;
            let decomped_ctx_k = allocate_and_encrypt_new_lwe_ciphertext(
                &tfhe_params.big_lwe_sk,
                Plaintext(decomped_k as u64 * tfhe_params.delta),
                tfhe_params.lwe_modular_std_dev,
                tfhe_params.ciphertext_modulus,
                &mut tfhe_params.encryption_generator,
            );
            x_j.push(decomped_ctx_k);
        }
        x.push(x_j);
    }
    let mut pi: Vec<Vec<LweCiphertextOwned<u64>>> = Vec::new();
    for j in 0..x_len {
        let mut pi_j: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for k in 0..bit_size {
            let decomped_k = (pi_ptx[j] >> ((tfhe_params.message_modulus.0 as f64).log2() as usize * k)) & 2_u32.pow((tfhe_params.message_modulus.0 as f64).log2() as u32) - 1;
            let decomped_ctx_k = allocate_and_encrypt_new_lwe_ciphertext(
                &tfhe_params.big_lwe_sk,
                Plaintext(decomped_k as u64 * tfhe_params.delta),
                tfhe_params.lwe_modular_std_dev,
                tfhe_params.ciphertext_modulus,
                &mut tfhe_params.encryption_generator,
            );
            pi_j.push(decomped_ctx_k);
        }
        pi.push(pi_j);
    }

    print!("x : ");
    print_ctx_list_multibit(&tfhe_params, &x);
    print!("pi : ");
    print_ctx_list_multibit(&tfhe_params, &pi);
    let x_new = appperm(&x, &pi, &tfhe_params.ksk, &tfhe_params.pksk, &tfhe_params.fourier_bsk, tfhe_params.thread_count, &tfhe_params.big_lwe_sk);
    print!("permutated x : ");
    print_ctx_list_multibit(&tfhe_params, &x_new);
    

    


    

}

