use lazy_static::lazy_static;
use tfhe::shortint::parameters::{PARAM_MESSAGE_1_CARRY_0_KS_PBS, ShortintParameterSet};




lazy_static! {
    pub static ref PARAMS: ShortintParameterSet = PARAM_MESSAGE_1_CARRY_0_KS_PBS.try_into().unwrap();
}
