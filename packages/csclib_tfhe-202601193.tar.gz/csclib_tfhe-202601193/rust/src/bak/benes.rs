use rayon::vec;
use tfhe::core_crypto::prelude::*;
use crate::lwe_array_new;
use crate::lwe_encrypt;
use crate::params::PARAMS;
use crate::print::*;
use crate::keyswitch::*;
use crate::algorithms::*;
use core::panic;
use std::fmt;
use crate::TfheParam;

pub struct BenesNetwork {
    pub switch_l: Option<Vec<LweCiphertextOwned<u64>>>,
    pub network1: Option<LweCiphertextOwned<u64>>,
    // network1: LweCiphertextOwned<u64>,
    pub network2: Option<LweCiphertextOwned<u64>>,
    // network2: LweCiphertextOwned<u64>,
    pub switch_r: Option<Vec<LweCiphertextOwned<u64>>>,
    // switch_r: LweCiphertextOwned<u64>,
}



pub struct  BenesNetworkNested {
    pub switch_l: Vec<LweCiphertextOwned<u64>>,
    pub network1: Box<BenesNetworkEnum>,
    // network1: Box<BenesNetworkNested>,
    pub network2: Box<BenesNetworkEnum>,
    // network2: Box<BenesNetworkNested>,
    pub switch_r: Vec<LweCiphertextOwned<u64>>,
}

pub enum BenesNetworkEnum {
    NoNest(BenesNetwork),
    Nested(BenesNetworkNested),
}



pub fn benes_sub(x: &Vec<LweCiphertextOwned<u64>>, value: &Vec<Vec<LweCiphertextOwned<u64>>>, switches: &Vec<Vec<LweCiphertextOwned<u64>>>,
    tfhe_params: &TfheParam,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> (Vec<LweCiphertextOwned<u64>>, Vec<Vec<LweCiphertextOwned<u64>>>, Vec<Vec<LweCiphertextOwned<u64>>>) {
    
    let mut x_new = x.clone();
    let mut value_new = value.clone();
    let mut switches_new = switches.clone();
    let mut oe_new = switches.clone();
//    let delta = tfhe_params.delta; 
    let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64); 
    let n = x.len();
    // let np = 2_i32.pow((blog((n - 1) as u64) + 1) as u32) as usize;
    let np = 1 << (blog((n - 1) as u64) + 1) as usize;
    // print!("n: {}", n);
    // print!("np: {}\n", np);
    print!("x = ");
    print_ctx_list(&big_lwe_sk, &x);

    if n as usize != np {
        panic!("n != np");
    }

    print!("start:x, value, oe\n");  
    print_ctx_list(&big_lwe_sk, &x);
    print_ctx_list_multibit(&tfhe_params, &value);
    for i in 0..switches.len() {
        print_ctx_list(&big_lwe_sk, &switches[i]);
    }

    if n > 2 {
        let mut rank: Vec<LweCiphertextOwned<u64>> = Vec::new();
        let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
//            LweSize(tfhe_params.polynomial_size.0*tfhe_params.glwe_dimension.0+1), Plaintext(0 * delta), tfhe_params.ciphertext_modulus
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
        );
        let trivial_one = allocate_and_trivially_encrypt_new_lwe_ciphertext(
//            LweSize(tfhe_params.polynomial_size.0*tfhe_params.glwe_dimension.0+1), Plaintext(1 * delta), tfhe_params.ciphertext_modulus
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(1 * delta), PARAMS.ciphertext_modulus()
        );
        rank.push(trivial_zero.clone());
        rank.push(trivial_zero.clone());
        let mut d = trivial_zero.clone();
        let mut group: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for _ in 0..n/2 {
            group.push(trivial_zero.clone());
        }
        let mut n0 = trivial_zero.clone();
        let mut i = 0;
        let mut n0_array = lwe_array_new();
        while i < n {
            let c0 = x[i].clone();
            let mut c0_bar = c0.clone();
            lwe_ciphertext_opposite_assign(&mut c0_bar);
            lwe_ciphertext_plaintext_add_assign(&mut c0_bar, Plaintext(1 * delta));
            n0 = xor(&n0, &c0_bar, &ksk, &pksk, &fourier_bsk, tfhe_params.thread_count);
            print!("i: {} ", i);
            print_ctx_list(&big_lwe_sk, &x);
            n0_array.push(n0.clone());
            print!("n0=");  
            print_ctx_list(&big_lwe_sk, &n0_array);
                // lwe_ciphertext_add_assign(&mut n0, &c0_bar);
            i += 1;
        }

        rank[1] = n0.clone();
        let mut switch_r: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for _ in 0..n {
            switch_r.push(trivial_zero.clone());
        }

        i = 0;
        while i < n {
            let c0 = x[i].clone();
            let mut c0_bar = c0.clone();
            lwe_ciphertext_opposite_assign(&mut c0_bar);
            lwe_ciphertext_plaintext_add_assign(&mut c0_bar, Plaintext(1 * delta));
            rank[0] = xor(&rank[0], &c0_bar, &ksk, &pksk, &fourier_bsk, thread_count);
            rank[1] = xor(&rank[1], &c0, &ksk, &pksk, &fourier_bsk, thread_count);
            // lwe_ciphertext_add_assign(&mut rank[0], &c0_bar);
            // lwe_ciphertext_add_assign(&mut rank[1], &c0);
            let r0 = array_read(&rank, &c0, ksk, pksk, fourier_bsk, thread_count);
            switch_r[i] = xor(&r0, &trivial_one.clone(), &ksk, &pksk, &fourier_bsk, thread_count);
            // lwe_ciphertext_add(&mut switch_r[i], &r0, &trivial_one);
        

            let c1 = x[i+1].clone();
            let mut c1_bar = c1.clone();
            lwe_ciphertext_opposite_assign(&mut c1_bar);
            lwe_ciphertext_plaintext_add_assign(&mut c1_bar, Plaintext(1 * delta));
            rank[0] = xor(&rank[0], &c1_bar, &ksk, &pksk, &fourier_bsk, thread_count);
            rank[1] = xor(&rank[1], &c1, &ksk, &pksk, &fourier_bsk, thread_count);
            // lwe_ciphertext_add_assign(&mut rank[0], &c1_bar);
            // lwe_ciphertext_add_assign(&mut rank[1], &c1);
            let r1 = array_read(&rank, &c1, ksk, pksk, fourier_bsk, thread_count);

            switch_r[i+1] = xor(&r1, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);
            // lwe_ciphertext_add(&mut switch_r[i/2], &r1, &trivial_one);

            let d0 = xor(&d, &c0, ksk, pksk, fourier_bsk, thread_count); 
            // let mut d0 = d.clone();
            // lwe_ciphertext_add_assign(&mut d0, &c0);

            group[i/2] = xor(&d0, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);
            // lwe_ciphertext_add(&mut group[i/2], &d0, &trivial_one);

            let d_xor_c0 = xor(&d, &c0, ksk, pksk, fourier_bsk, thread_count);
            d = xor(&d_xor_c0, &c1, ksk, pksk, fourier_bsk, thread_count);
            // let mut d_xor_c0 = d.clone();
            // lwe_ciphertext_add_assign(&mut d_xor_c0, &c0);
            // lwe_ciphertext_add(&mut d,&d_xor_c0, &c1);
            


            i += 2; 
        }

        i = 0;
        while i < n {
            x_new = cswap(&group[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            // print_ctx_list(&big_lwe_sk, &x_new);
            value_new = cswap_multibit(&group[i/2], &value_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            (switches_new[i], switches_new[i+1]) = cswap_list(&group[i/2], &switches_new[i], &switches_new[i+1], &ksk, &pksk, &fourier_bsk, thread_count);
            switch_r = cswap(&group[i/2], &switch_r, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            i += 2;
        }

        let x_tmp = butterfly(&x_new);
        let value_tmp = butterfly(&value_new);
        // let mut switches_tmp = butterfly_vec(&switches_new);
        let mut switches_tmp = butterfly(&switches_new);
        let switch_r_tmp = butterfly(&switch_r);
        i = 0;

        while i < n/2 {
            let mut switch_i_tmp: Vec<LweCiphertextOwned<u64>> = Vec::new();
            switch_i_tmp.push(switch_r_tmp[i].clone());
            for j in 0..switches_tmp[i].len() {
                switch_i_tmp.push(switches_tmp[i][j].clone());
            }
            switches_tmp[i] = switch_i_tmp;
            i += 1;
        }

        let (mut x_tmp1, mut value_tmp1, mut switch_tmp1) = benes_sub(
            &x_tmp[0..n/2].to_vec(), &value_tmp[0..n/2].to_vec(), &switches_tmp[0..n/2].to_vec(), &tfhe_params, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
        let (x_tmp2, value_tmp2, switch_tmp2) = benes_sub(
            &x_tmp[n/2..n].to_vec(), &value_tmp[n/2..n].to_vec(), &switches_tmp[n/2..n].to_vec(), &tfhe_params, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
        for i in 0..n/2 {
            x_tmp1.push(x_tmp2[i].clone());
            value_tmp1.push(value_tmp2[i].clone());
        }

        x_new = butterfly_inv(&x_tmp1);
        value_new = butterfly_inv(&value_tmp1);

        let mut switch_r: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for _ in 0..n {
            switch_r.push(trivial_zero.clone());
        }

        i = 0;
        while i < n/2 {
            let t = switch_tmp1[i].clone();
            switch_r[i] = t[0].clone();
            switch_tmp1[i] = t[1..t.len()].to_vec();
            i += 1;
        }

        for i in 0..n/2 {
            switch_tmp1.push(switch_tmp2[i].clone());
        }

        oe_new = butterfly_inv(&switch_tmp1);

        i = 0;

        let mut c = trivial_zero.clone();
        
        while i < n {
            c = switch_r[i/2].clone();
            x_new = cswap(&c, &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            value_new = cswap_multibit(&c, &value_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);


            // oe_new[i] と oe_new[i+1] のcswap
            if oe_new[i].len() != oe_new[i+1].len() {
                panic!("oe_new[i].len() != oe_new[i+1].len()");
            }
            else {
                for j in 0..oe_new[i].len() {
                    (oe_new[i][j], oe_new[i+1][j]) = cswap_two_lwe(&c, &oe_new[i][j], &oe_new[i+1][j], &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                }
            }
            
            i += 2;
        }

    }

    else {

        let mut x_1_bar = x_new[1].clone();
        lwe_ciphertext_opposite_assign(&mut x_1_bar);
        lwe_ciphertext_plaintext_add_assign(&mut x_1_bar, Plaintext(1 * delta));
        print!("x_0, x_1_bar\n");
        print_ctx(&tfhe_params, &x_new[0]);
        print_ctx(&tfhe_params, &x_1_bar);
        let c = and(&x_new[0], &x_1_bar, &ksk, &pksk, &fourier_bsk, thread_count);
        print!("swap: ");
        print_ctx(&tfhe_params, &c);
        print!("cswap\n");
        x_new = cswap(&c, &x_new, 0, 1, &tfhe_params.ksk, &tfhe_params.pksk, &tfhe_params.fourier_bsk, tfhe_params.thread_count, &tfhe_params.big_lwe_sk);
        print!("cswap\n");
        value_new = cswap_multibit(&c, &value_new, 0, 1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
        print!("cswap_list\n");
        (oe_new[0], oe_new[1]) = cswap_list(&c, &oe_new[0], &oe_new[1], &ksk, &pksk, &fourier_bsk, thread_count);
    }
    print!("benes_sub done\n");
    print!("end:x, value, oe\n");  
    print_ctx_list(&big_lwe_sk, &x_new);
    print_ctx_list_multibit(&tfhe_params, &value_new);
    for i in 0..oe_new.len() {
        print_ctx_list(&big_lwe_sk, &oe_new[i]);
    }
    print!("\n");
    return (x_new, value_new, oe_new);
}

pub fn benes(x: &Vec<LweCiphertextOwned<u64>>, value: &Vec<Vec<LweCiphertextOwned<u64>>>,
    // ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount)
    tfhe_param: &TfheParam, 
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>
    )->(Vec<LweCiphertextOwned<u64>>,Vec<Vec<LweCiphertextOwned<u64>>>) {
    let bit_size = value[0].len();
    let mut x_tmp = x.clone();
    let mut value_tmp = value.clone();
    let n = x.len();
    // let np = 2_i32.pow((blog((n - 1) as u64) + 1) as u32) as usize;
    let np = 1 << (blog((n - 1) as u64) + 1) as usize;
    let delta = tfhe_param.delta; 
    let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
        LweSize(tfhe_param.polynomial_size.0*tfhe_param.glwe_dimension.0+1), Plaintext(0 * delta), tfhe_param.ciphertext_modulus
    );
    let trivial_one = allocate_and_trivially_encrypt_new_lwe_ciphertext(
        LweSize(tfhe_param.polynomial_size.0*tfhe_param.glwe_dimension.0+1), Plaintext(1 * delta), tfhe_param.ciphertext_modulus
    );

    if np > n {
        for _ in 0..(np-n) {
            x_tmp.push(trivial_one.clone());
            let mut value_tmp_: Vec<LweCiphertextOwned<u64>> = Vec::new();
            for _ in 0..bit_size {
                value_tmp_.push(trivial_zero.clone());
            }
            value_tmp.push(value_tmp_);
        }
    }

    let mut oe: Vec<Vec<LweCiphertextOwned<u64>>> = Vec::new();
    for _ in 0..np {
        let oe_i: Vec<LweCiphertextOwned<u64>> = Vec::new();
        oe.push(oe_i); 
    }

    let (mut x_new, mut value_new, _oe_new) = benes_sub(&x_tmp, &value_tmp, &oe, &tfhe_param, &tfhe_param.ksk, &tfhe_param.pksk, &tfhe_param.fourier_bsk, tfhe_param.thread_count, &tfhe_param.big_lwe_sk); 
    if np > n {
        x_new = x_new[0..n].to_vec();
        value_new = value_new[0..n].to_vec();
    }

    return (x_new, value_new);
}







pub fn benes_construct_sub(x: &Vec<LweCiphertextOwned<u64>>, switches: &Vec<Vec<LweCiphertextOwned<u64>>>, 
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> (Vec<Vec<LweCiphertextOwned<u64>>>, BenesNetworkEnum) {
    let n = x.len();
    let np = 1 << (blog((n - 1) as u64) + 1) as usize;
    let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
    let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
    );
    let trivial_one = allocate_and_trivially_encrypt_new_lwe_ciphertext(
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(1 * delta), PARAMS.ciphertext_modulus()
    );

    let mut x_new = x.clone();
    let mut switches_new = switches.clone();

  

    if n != np {
        panic!("n != np");
    }
    if n > 2 {
        let mut rank: Vec<LweCiphertextOwned<u64>> = Vec::new();
        rank.push(trivial_zero.clone());
        rank.push(trivial_zero.clone());

        let mut d = trivial_zero.clone();

        let mut switch_l: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for _ in 0..n/2 {
            switch_l.push(trivial_zero.clone());
        }

        let mut i = 0;
        let mut n0 = trivial_zero.clone();

        while i < n {
            let c0 = x_new[i].clone();
            let mut c0_bar = c0.clone();
            lwe_ciphertext_opposite_assign(&mut c0_bar);
            lwe_ciphertext_plaintext_add_assign(&mut c0_bar, Plaintext(1 * delta));
            n0 = xor(&n0, &c0_bar, &ksk, &pksk, &fourier_bsk, thread_count);
            i += 1;
        }
        rank[1] = n0.clone();

        let mut switch_r: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for _ in 0..n {
            switch_r.push(trivial_zero.clone());
        }

        i = 0;
        while i < n {
            let c0 = x_new[i].clone();
            let mut c0_bar = c0.clone();
            lwe_ciphertext_opposite_assign(&mut c0_bar);
            lwe_ciphertext_plaintext_add_assign(&mut c0_bar, Plaintext(1 * delta));
            rank[0] = xor(&rank[0], &c0_bar, &ksk, &pksk, &fourier_bsk, thread_count);
            rank[1] = xor(&rank[1], &c0, &ksk, &pksk, &fourier_bsk, thread_count);
            let r0 = array_read(&rank, &c0, ksk, pksk, fourier_bsk, thread_count);
            switch_r[i] = xor(&r0, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);

            let c1 = x_new[i+1].clone();
            let mut c1_bar = c1.clone();
            lwe_ciphertext_opposite_assign(&mut c1_bar);
            lwe_ciphertext_plaintext_add_assign(&mut c1_bar, Plaintext(1 * delta));
            rank[0] = xor(&rank[0], &c1_bar, &ksk, &pksk, &fourier_bsk, thread_count);
            rank[1] = xor(&rank[1], &c1, &ksk, &pksk, &fourier_bsk, thread_count);
            let r1 = array_read(&rank, &c1, ksk, pksk, fourier_bsk, thread_count);
            switch_r[i+1] = xor(&r1, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);

            let d0 = xor(&d, &c0, ksk, pksk, fourier_bsk, thread_count);
            switch_l[i/2] = xor(&d0, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);

            let d_xor_c0 = xor(&d, &c0, ksk, pksk, fourier_bsk, thread_count);
            d = xor(&d_xor_c0, &c1, ksk, pksk, fourier_bsk, thread_count);

            i += 2;
        }

        // print!("switch_r time 1: ");
        // print_ctx_list(&big_lwe_sk, &switch_r);

        i = 0;
        while i < n {
            x_new = cswap(&switch_l[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            (switches_new[i], switches_new[i+1]) = cswap_list(&switch_l[i/2], &switches_new[i], &switches_new[i+1], &ksk, &pksk, &fourier_bsk, thread_count);
            switch_r = cswap(&switch_l[i/2], &switch_r, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            i += 2;
        }

        let x_tmp = butterfly(&x_new);
        let mut switches_tmp = butterfly(&switches_new);
        // let mut switches_tmp = butterfly_vec(&switches_new);

        // print!("switch_r : ");
        // print_ctx_list(&big_lwe_sk, &switch_r);
        let mut switch_r_tmp = butterfly(&switch_r);
        switch_r_tmp = switch_r_tmp[0..n/2].to_vec();

        // print!("switches_tmp time 1: \n");
        // for i in 0..switches_tmp.len() {
        //     print_ctx_list(&big_lwe_sk, &switches_tmp[i]);
        // }
        i = 0;
        while i < n/2 {
            let mut switch_i_tmp: Vec<LweCiphertextOwned<u64>> = Vec::new();

            switch_i_tmp.push(switch_r_tmp[i].clone());
            for j in 0..switches_tmp[i].len() {
                switch_i_tmp.push(switches_tmp[i][j].clone());
            }
            switches_tmp[i] = switch_i_tmp;
            i += 1;
        }


        // print!("x_tmp : ");
        // print_ctx_list(&big_lwe_sk, &x_tmp);
        // print!("switches_tmp : \n");
        // for i in 0..switches_tmp.len() {
        //     print_ctx_list(&big_lwe_sk, &switches_tmp[i]);
        // }
        let (mut switch_tmp1, network1) = benes_construct_sub(&x_tmp[0..n/2].to_vec(), &switches_tmp[0..n/2].to_vec(), 
        &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
        let (switch_tmp2, network2) = benes_construct_sub(&x_tmp[n/2..n].to_vec(), &switches_tmp[n/2..n].to_vec(),
        &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);

        let mut switch_r: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for _ in 0..n/2 {
            switch_r.push(trivial_zero.clone());
        }

        i = 0;
        while i < n/2 {
            // print!("switch_tmp1 : ");
            // print_ctx_list(&big_lwe_sk, &switch_tmp1[i]);
            let t = switch_tmp1[i].clone();
            // print!("t : ");
            // print_ctx_list(&big_lwe_sk, &t);
            switch_r[i] = t[0].clone();
            switch_tmp1[i] = t[1..t.len()].to_vec();
            i += 1;
        }

        for i in 0..n/2 {
            switch_tmp1.push(switch_tmp2[i].clone());
        }

        let mut oe_new = butterfly_inv(&switch_tmp1);
        // let mut oe_new = butterfly_inv_vec(&switch_tmp1);

        i = 0;
        // let mut c = trivial_zero.clone();
        
        while i < n {
            let c = switch_r[i/2].clone();
 
            // oe_new[i] と oe_new[i+1] のcswap
            if oe_new[i].len() != oe_new[i+1].len() {
                panic!("oe_new[i].len() != oe_new[i+1].len()");
            }
            else {
                for j in 0..oe_new[i].len() {
                    (oe_new[i][j], oe_new[i+1][j]) = cswap_two_lwe(&c, &oe_new[i][j], &oe_new[i+1][j], &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                }
            }
            
            i += 2;
        }

  
        let z = BenesNetworkNested {
            switch_l: switch_l,
            network1: Box::new(network1),
            network2: Box::new(network2),
            switch_r: switch_r,
        };
        return (oe_new.clone(), BenesNetworkEnum::Nested(z));
        // return (switches_new.clone(), BenesNetworkEnum::Nested(z));

    }

    else {
        let mut oe_new = switches_new.clone();

        let mut x_1_bar = x_new[1].clone();
        lwe_ciphertext_opposite_assign(&mut x_1_bar);
        lwe_ciphertext_plaintext_add_assign(&mut x_1_bar, Plaintext(1 * delta));
        let c = and(&x_new[0], &x_1_bar, &ksk, &pksk, &fourier_bsk, thread_count);
        (oe_new[0], oe_new[1]) = cswap_list(&c, &oe_new[0], &oe_new[1], &ksk, &pksk, &fourier_bsk, thread_count);
        let z = BenesNetwork {
            switch_l: vec![c].into(),
            network1: None,
            network2: None,
            switch_r: None,
        };
        return (oe_new.clone(), BenesNetworkEnum::NoNest(z));

    }

}


pub fn benes_construct(x: &Vec<LweCiphertextOwned<u64>>,
ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
-> BenesNetworkEnum {
    let n = x.len();
    let np = 1 << (blog((n - 1) as u64) + 1) as usize;
    let mut x_tmp = x.clone();
    let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
    let trivial_one = allocate_and_trivially_encrypt_new_lwe_ciphertext(
        LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(1 * delta), PARAMS.ciphertext_modulus()
    );
    

    if np > n {
        for _ in 0..(np-n) {
            x_tmp.push(trivial_one.clone());
        }
    }

    let mut oe: Vec<Vec<LweCiphertextOwned<u64>>> = Vec::new();
    for _ in 0..np {
        let oe_i: Vec<LweCiphertextOwned<u64>> = Vec::new();
        oe.push(oe_i); 
    }

    let (_oe_new, z) = benes_construct_sub(&x_tmp, &oe, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);

    return z;

    
}


pub fn benes_apply_sub(x: &Vec<LweCiphertextOwned<u64>>, network: &BenesNetworkEnum, inverse: bool,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> Vec<LweCiphertextOwned<u64>>{
    let n = x.len();
    let np = 1 << (blog((n - 1) as u64) + 1) as usize;
    let mut x_new = x.clone();
    
    
    if n != np {
        panic!("n != np");
    }
    else {
        match network {
            BenesNetworkEnum::Nested(network_nested) => {
                let switch_l: Vec<LweCiphertextOwned<u64>>;
                let switch_r: Vec<LweCiphertextOwned<u64>>;

                let network1 = &network_nested.network1;
                let network2 = &network_nested.network2;
                if inverse {
                    switch_l = network_nested.switch_r.clone().into();
                    switch_r = network_nested.switch_l.clone().into();
                }
                else {
                    switch_l = network_nested.switch_l.clone().into();
                    switch_r = network_nested.switch_r.clone().into();
                }

                if n <= 2 {
                    panic!("n <= 2");
                }
                let mut i = 0;
                while i < n {
                    x_new = cswap(&switch_l[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                    i += 2;
                }
                let x_tmp = butterfly(&x_new);
                let mut x_tmp1 = benes_apply_sub(&x_tmp[0..n/2].to_vec(), &network1, inverse, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);
                let x_tmp2 = benes_apply_sub(&x_tmp[n/2..n].to_vec(), &network2, inverse, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);
                
                for i in 0..x_tmp2.len() {
                    x_tmp1.push(x_tmp2[i].clone());
                }
    
                x_new = butterfly_inv(&x_tmp1);
    
                i = 0;
                while i < n {
                    x_new = cswap(&switch_r[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                    i += 2;
                }
            },
            BenesNetworkEnum::NoNest(network_nonest) => {
                // let switch_l: Option<Vec<LweCiphertextOwned<u64>>>;
                // let switch_r: Option<Vec<LweCiphertextOwned<u64>>>;

                // // let network1 = &network_nonest.network1;
                // // let network2 = &network_nonest.network2;
                // if inverse {
                //     switch_l = network_nonest.switch_r.clone();
                //     switch_r = network_nonest.switch_l.clone();
                // }
                // else {
                //     switch_l = network_nonest.switch_l.clone();
                //     switch_r = network_nonest.switch_r.clone();
                // }

                if n > 2 {
                    panic!("n > 2");
                }
                let switch_l = network_nonest.switch_l.clone(); 
            
                // x_new = cswap(&switch_l[0], &x_new, 0, 1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                // if let Some(switch_l_vec) = switch_l {
                //     print!("network00: ");
                //     print_ctx(&big_lwe_sk, &switch_l_vec[0]);
                //     x_new = cswap(&switch_l_vec[0], &x_new, 0, 1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                // } else {
                if let Some(switch_l_vec) = switch_l {
                    // print!("network00: ");
                    // print_ctx(&big_lwe_sk, &switch_l_vec[0]);
                    x_new = cswap(&switch_l_vec[0], &x_new, 0, 1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                } else {
                    panic!("switch_l is None");
                }
            },
        }
            // if n > 2 {
            //     let mut i = 0;
            //     while i < n {
            //         x_new = cswap(&switch_l[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            //         i += 2;
            //     }
            //     let x_tmp = butterfly(&x_new);
            //     let mut x_tmp1 = benes_apply_sub(&x_tmp[0..n/2].to_vec(), &network1, inverse, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);
            //     let x_tmp2 = benes_apply_sub(&x_tmp[n/2..n].to_vec(), &network2, inverse, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);
                
            //     for i in 0..x_tmp2.len() {
            //         x_tmp1.push(x_tmp2[i].clone());
            //     }

            //     let x_new = butterfly_inv(&x_tmp1);

            //     i = 0;
            //     while i < n {
            //         x_new = cswap(&switch_r[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            //         i += 2;
            //     }
            // } else {
            //     x_new = cswap(&network[0][0], &x_new, 0, 1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            // }

            // return x_new;
            return x_new;

    }
}




pub fn benes_apply_sub_multibit(x: &Vec<Vec<LweCiphertextOwned<u64>>>, network: &BenesNetworkEnum, inverse: bool,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> Vec<Vec<LweCiphertextOwned<u64>>>{
    let n = x.len();
    let np = 1 << (blog((n - 1) as u64) + 1) as usize;
    let mut x_new = x.clone();
    
    
    if n != np {
        panic!("n != np");
    }
    else {
        match network {
            BenesNetworkEnum::Nested(network_nested) => {
                let switch_l: Vec<LweCiphertextOwned<u64>>;
                let switch_r: Vec<LweCiphertextOwned<u64>>;

                let network1 = &network_nested.network1;
                let network2 = &network_nested.network2;
                if inverse {
                    switch_l = network_nested.switch_r.clone().into();
                    switch_r = network_nested.switch_l.clone().into();
                }
                else {
                    switch_l = network_nested.switch_l.clone().into();
                    switch_r = network_nested.switch_r.clone().into();
                }

                if n <= 2 {
                    panic!("n <= 2");
                }
                let mut i = 0;
                while i < n {
                    x_new = cswap_multibit(&switch_l[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                    i += 2;
                }
                let x_tmp = butterfly(&x_new);
                let mut x_tmp1 = benes_apply_sub_multibit(&x_tmp[0..n/2].to_vec(), &network1, inverse, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);
                let x_tmp2 = benes_apply_sub_multibit(&x_tmp[n/2..n].to_vec(), &network2, inverse, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);
                
                for i in 0..x_tmp2.len() {
                    x_tmp1.push(x_tmp2[i].clone());
                }
    
                x_new = butterfly_inv(&x_tmp1);
    
                i = 0;
                while i < n {
                    x_new = cswap_multibit(&switch_r[i/2], &x_new, i, i+1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                    i += 2;
                }
            },
            BenesNetworkEnum::NoNest(network_nonest) => {
                if n > 2 {
                    panic!("n > 2");
                }
                let switch_l = network_nonest.switch_l.clone(); 
            

                if let Some(switch_l_vec) = switch_l {
                    // print!("network00: ");
                    // print_ctx(&big_lwe_sk, &switch_l_vec[0]);
                    x_new = cswap_multibit(&switch_l_vec[0], &x_new, 0, 1, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                } else {
                    panic!("switch_l is None");
                }
            },
        }

            return x_new;

    }
}

pub fn benes_apply(x: &Vec<LweCiphertextOwned<u64>>, network: &BenesNetworkEnum,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> Vec<LweCiphertextOwned<u64>> {
        let mut x_tmp = x.clone();
        let n = x.len();

        let np = 1 << (blog((n - 1) as u64) + 1) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
        let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
        );
        for _ in 0..(np-n) {
            x_tmp.push(trivial_zero.clone());
        }

        let mut x_new = benes_apply_sub(&x_tmp, network, false, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);

        if np > n {
            x_new = x_new[0..n].to_vec();
        }

        return x_new;
}

pub fn benes_apply_multibit(x: &Vec<Vec<LweCiphertextOwned<u64>>>, network: &BenesNetworkEnum,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> Vec<Vec<LweCiphertextOwned<u64>>> {
        let bit_size = x[0].len();
        let mut x_tmp = x.clone();
        let n = x.len();

        let np = 1 << (blog((n - 1) as u64) + 1) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
        let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
        );
        for _ in 0..(np-n) {
            let mut x_tmp_i: Vec<LweCiphertextOwned<u64>> = Vec::new();
            for i in 0..bit_size {
                x_tmp_i.push(trivial_zero.clone());
            }
            x_tmp.push(x_tmp_i.clone());
        }

        let mut x_new = benes_apply_sub_multibit(&x_tmp, network, false, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);

        if np > n {
            x_new = x_new[0..n].to_vec();
        }

        return x_new;
}

pub fn benes_apply_inv(x: &Vec<LweCiphertextOwned<u64>>, network: &BenesNetworkEnum,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> Vec<LweCiphertextOwned<u64>> {
        let mut x_tmp = x.clone();
        let n = x.len();

        let np = 1 << (blog((n - 1) as u64) + 1) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
        let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
        );
        for _ in 0..(np-n) {
            x_tmp.push(trivial_zero.clone());
        }

        let mut x_new = benes_apply_sub(&x_tmp, network, true, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);

        if np > n {
            x_new = x_new[0..n].to_vec();
        }

        return x_new;
}


pub fn benes_apply_inv_multibit(x: &Vec<Vec<LweCiphertextOwned<u64>>>, network: &BenesNetworkEnum,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    -> Vec<Vec<LweCiphertextOwned<u64>>> {
        let mut x_tmp = x.clone();
        let n = x.len();

        let np = 1 << (blog((n - 1) as u64) + 1) as usize;
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
        let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
        );
        for _ in 0..(np-n) {
            let mut x_tmp_i: Vec<LweCiphertextOwned<u64>> = Vec::new();
            for i in 0..x[0].len() {
                x_tmp_i.push(trivial_zero.clone());
            }
            x_tmp.push(x_tmp_i.clone());
        }

        let mut x_new = benes_apply_sub_multibit(&x_tmp, network, true, ksk, pksk, fourier_bsk, thread_count, big_lwe_sk);

        if np > n {
            x_new = x_new[0..n].to_vec();
        }

        return x_new;
}


pub fn appperm(x: &Vec<Vec<LweCiphertextOwned<u64>>>, pi: &Vec<Vec<LweCiphertextOwned<u64>>>,
    ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
    ->Vec<Vec<LweCiphertextOwned<u64>>> {
        let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64); 
        let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
            LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
        );
        let n = x.len();
        let d = blog((n - 1) as u64) + 1;
        let mut j = 0;
        let mut pi_new = pi.clone();
        let mut x_new = x.clone();
        while j < d {
            let mut b: Vec<LweCiphertextOwned<u64>> = Vec::new();
            // for _ in 0..n {
            //     b.push(trivial_zero.clone());
            // }

            // let mut i = 0;
            // while i < n {
            //     b[i] = mod2(&pi_new[i], &ksk, &pksk, &fourier_bsk, thread_count);
            //     pi_new[i] = div2(&pi_new[i], &ksk, &pksk, &fourier_bsk, thread_count);
            //     i += 1;
            // }
            for i in 0..n {
                b.push(pi_new[i][j as usize].clone());
            }

  
            let network = benes_construct(&b, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            x_new = benes_apply_multibit(&x_new, &network, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            if j < d - 1{
                // // pi_new = benes_apply(&pi_new, &network, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                // let mut pi_tmp: Vec<LweCiphertextOwned<u64>> = Vec::new();
                // for k in 0..n {
                //     pi_tmp.push(pi_new[k][j as usize + 1].clone());
                // }
                // pi_tmp = benes_apply(&pi_tmp, &network, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
                // for k in 0..n {
                //     pi_new[k][j as usize + 1] = pi_tmp[k].clone();
                // }
                pi_new = benes_apply_multibit(&pi_new, &network, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
            }
            j += 1;
            // print!("j : {}\n", j);
            // print_ctx_list_multibit(&big_lwe_sk, &pi_new);
            // print_ctx_list_multibit(&big_lwe_sk, &x_new);

        }
    return x_new;
}


// pub fn applyperm(x: &Vec<LweCiphertextOwned<u64>>, pi: &Vec<LweCiphertextOwned<u64>>,
//     ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
//     ->Vec<LweCiphertextOwned<u64>> {
//         let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64); 
//         let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
//             LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
//         );
//         let n = x.len();
//         let d = blog((n - 1) as u64) + 1;
//         let mut j = 0;
//         let mut pi_new = pi.clone();
//         let mut x_new = x.clone();
//         while j < d {
//             let mut b: Vec<LweCiphertextOwned<u64>> = Vec::new();
//             for _ in 0..n {
//                 b.push(trivial_zero.clone());
//             }

//             let mut i = 0;
//             while i < n {
//                 b[i] = mod2(&pi_new[i], &ksk, &pksk, &fourier_bsk, thread_count);
//                 pi_new[i] = div2(&pi_new[i], &ksk, &pksk, &fourier_bsk, thread_count);
//                 i += 1;
//             }
//             let mut _b_tmp: Vec<LweCiphertextOwned<u64>> = Vec::new();
//             (_b_tmp, x_new) = benes(&b, &x_new, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
//             (_b_tmp, pi_new) = benes(&b, &pi_new, &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
//             j += 1;

//         }
//         return x_new;
// }

// pub fn benes_construct_sub(x: &Vec<LweCiphertextOwned<u64>>, switches: &Vec<Vec<LweCiphertextOwned<u64>>>, 
//     ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
//     -> (Vec<Vec<LweCiphertextOwned<u64>>>, Vec<Vec<LweCiphertextOwned<u64>>>) {
// // pub fn benes_construct_sub<T>(x: &Vec<LweCiphertextOwned<u64>>, switches: &Vec<Vec<LweCiphertextOwned<u64>>>, 
// //     ksk: &LweKeyswitchKey<Vec<u64>>, pksk: &LwePackingKeyswitchKey<Vec<u64>>, fourier_bsk: &FourierLweMultiBitBootstrapKeyOwned, thread_count: ThreadCount, big_lwe_sk: &LweSecretKey<Vec<u64>>)
// //     -> (Vec<Vec<LweCiphertextOwned<u64>>>, Vec<T>) {
//     let n = x.len();
//     let np = 1 << (blog((n - 1) as u64) + 1) as usize;
//     let delta = (1_u64 << 63) / (PARAMS.message_modulus().0 as u64 * PARAMS.carry_modulus().0 as u64);
//     let trivial_zero = allocate_and_trivially_encrypt_new_lwe_ciphertext(
//         LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(0 * delta), PARAMS.ciphertext_modulus()
//     );
//     let trivial_one = allocate_and_trivially_encrypt_new_lwe_ciphertext(
//         LweSize(PARAMS.polynomial_size().0*PARAMS.glwe_dimension().0+1), Plaintext(1 * delta), PARAMS.ciphertext_modulus()
//     );

//     let mut x_new = x.clone();
//     let mut switches_new = switches.clone();

//     if n != np {
//         panic!("n != np");
//     }
//     if n > 2 {
//         let mut rank: Vec<LweCiphertextOwned<u64>> = Vec::new();
//         rank.push(trivial_zero.clone());
//         rank.push(trivial_zero.clone());

//         let mut d = trivial_zero.clone();

//         let mut switch_l: Vec<LweCiphertextOwned<u64>> = Vec::new();
//         for _ in 0..n/2 {
//             switch_l.push(trivial_zero.clone());
//         }

//         let mut i = 0;
//         let mut n0 = trivial_zero.clone();

//         while i < n {
//             let c0 = x[i].clone();
//             let mut c0_bar = c0.clone();
//             lwe_ciphertext_opposite_assign(&mut c0_bar);
//             lwe_ciphertext_plaintext_add_assign(&mut c0_bar, Plaintext(1 * delta));
//             n0 = xor(&rank[0], &c0_bar, &ksk, &pksk, &fourier_bsk, thread_count);
//             i += 1;
//         }
//         rank[1] = n0.clone();

//         let mut switch_r: Vec<LweCiphertextOwned<u64>> = Vec::new();
//         for _ in 0..n {
//             switch_r.push(trivial_zero.clone());
//         }

//         let mut i = 0;
//         while i < n {
//             let c0 = x_new[i].clone();
//             let mut c0_bar = c0.clone();
//             lwe_ciphertext_opposite_assign(&mut c0_bar);
//             lwe_ciphertext_plaintext_add_assign(&mut c0_bar, Plaintext(1 * delta));
//             rank[0] = xor(&rank[0], &c0_bar, &ksk, &pksk, &fourier_bsk, thread_count);
//             rank[1] = xor(&rank[1], &c0, &ksk, &pksk, &fourier_bsk, thread_count);
//             let r0 = array_read(&rank, &c0, ksk, pksk, fourier_bsk, thread_count);
//             switch_r[i] = xor(&r0, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);

//             let c1 = x_new[i+1].clone();
//             let mut c1_bar = c1.clone();
//             lwe_ciphertext_opposite_assign(&mut c1_bar);
//             lwe_ciphertext_plaintext_add_assign(&mut c1_bar, Plaintext(1 * delta));
//             rank[0] = xor(&rank[0], &c1_bar, &ksk, &pksk, &fourier_bsk, thread_count);
//             rank[1] = xor(&rank[1], &c1, &ksk, &pksk, &fourier_bsk, thread_count);
//             let r1 = array_read(&rank, &c1, ksk, pksk, fourier_bsk, thread_count);
//             switch_r[i+1] = xor(&r1, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);

//             let d0 = xor(&d, &c0, ksk, pksk, fourier_bsk, thread_count);
//             switch_l[i/2] = xor(&d0, &trivial_one.clone(), ksk, pksk, fourier_bsk, thread_count);

//             let d_xor_c0 = xor(&d, &c0, ksk, pksk, fourier_bsk, thread_count);
//             d = xor(&d_xor_c0, &c1, ksk, pksk, fourier_bsk, thread_count);

//             i += 2;
//         }

//         let x_tmp = butterfly(&x_new);
//         let mut switches_tmp = butterfly(&switches_new);
//         // let mut switches_tmp = butterfly_vec(&switches_new);

//         let mut switch_r_tmp = butterfly(&switch_r);
//         switch_r_tmp = switch_r_tmp[0..n/2].to_vec();

//         i = 0;
//         while i < n/2 {
//             let mut switch_i_tmp: Vec<LweCiphertextOwned<u64>> = Vec::new();
//             switch_i_tmp.push(switch_r_tmp[i].clone());
//             for j in 0..switches_tmp[i].len() {
//                 switch_i_tmp.push(switches_tmp[i][j].clone());
//             }
//             switches_tmp[i] = switch_i_tmp;
//             i += 1;
//         }


//         let (mut switch_tmp1, network1) = benes_construct_sub(&x_tmp[0..n/2].to_vec(), &switches_tmp[0..n/2].to_vec(), 
//         &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
//         let (switch_tmp2, network2) = benes_construct_sub(&x_tmp[n/2..n].to_vec(), &switches_tmp[n/2..n].to_vec(),
//         &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);

//         let mut switch_r: Vec<LweCiphertextOwned<u64>> = Vec::new();
//         for _ in 0..n/2 {
//             switch_r.push(trivial_zero.clone());
//         }

//         i = 0;
//         while i < n/2 {
//             let t = switch_tmp1[i].clone();
//             switch_r[i] = t[0].clone();
//             switch_tmp1[i] = t[1..t.len()].to_vec();
//             i += 1;
//         }

//         for i in 0..n/2 {
//             switch_tmp1.push(switch_tmp2[i].clone());
//         }

//         let mut oe_new = butterfly_inv(&switch_tmp1);
//         // let mut oe_new = butterfly_inv_vec(&switch_tmp1);

//         i = 0;
//         let mut c = trivial_zero.clone();
        
//         while i < n {
//             c = switch_r[i/2].clone();
 
//             // oe_new[i] と oe_new[i+1] のcswap
//             if oe_new[i].len() != oe_new[i+1].len() {
//                 panic!("oe_new[i].len() != oe_new[i+1].len()");
//             }
//             else {
//                 for j in 0..oe_new[i].len() {
//                     (oe_new[i][j], oe_new[i+1][j]) = cswap_two_lwe(&c, &oe_new[i][j], &oe_new[i+1][j], &ksk, &pksk, &fourier_bsk, thread_count, &big_lwe_sk);
//                 }
//             }
            
//             i += 2;
//         }

//         // 構造体として書く．
//         // let z = vec![switch_l, network1, network2, switch_r];

        



//     }

//     return (switches_new.clone(), switches_new);
// }