use tfhe::core_crypto::prelude::*;
use tfhe::core_crypto::algorithms::polynomial_algorithms::polynomial_wrapping_monic_monomial_mul_assign;
use tfhe::core_crypto::algorithms::slice_algorithms::{
    slice_wrapping_add_assign,/* slice_wrapping_sub_scalar_mul_assign, */
};
use tfhe::core_crypto::entities::{
    GlweCiphertext, LweCiphertext,/* LweCiphertextList, */ LwePackingKeyswitchKey,
};

use crate::params::PARAMS;


pub fn packing_two_lwe_into_glwe_index_0_1_bit<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    ciphertext1: &LweCiphertext<InputCont>,
    ciphertext2: &LweCiphertext<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    box_size: usize,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let mut buffer1 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    let mut buffer2 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    // KS を 2回．
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &ciphertext1, &mut buffer1);
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &ciphertext2, &mut buffer2);
    for degree in 0..box_size {
        let mut buffer1_iter = buffer1.clone();
        buffer1_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + 0*box_size))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
    }
    // for degree in 0..box_size {
    //     let mut buffer1_iter = buffer1.clone();
    //     buffer1_iter
    //         .as_mut_polynomial_list()
    //         .iter_mut()
    //         .for_each(|mut poly| {
    //             polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + 2*box_size))
    //         });
    //     slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
    // }
    for degree in 0..box_size {
        let mut buffer2_iter = buffer2.clone();
        buffer2_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + 1*box_size))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer2_iter.as_ref());
    }

}

// pub fn packing_two_lwe_into_glwe_index_0_1<
//     Scalar,
//     KeyCont,
//     InputCont,
//     OutputCont,
// >(
//     lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
//     ciphertext1: &LweCiphertext<InputCont>,
//     ciphertext2: &LweCiphertext<InputCont>,
//     output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
//     box_size: usize,
// ) where
//     Scalar: UnsignedInteger,
//     KeyCont: Container<Element = Scalar>,
//     InputCont: Container<Element = Scalar>,
//     OutputCont: ContainerMut<Element = Scalar>,
// {

//     output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
//     let mut buffer1 = GlweCiphertext::new(
//         Scalar::ZERO,
//         output_glwe_ciphertext.glwe_size(),
//         output_glwe_ciphertext.polynomial_size(),
//         output_glwe_ciphertext.ciphertext_modulus(),
//     );
//     let mut buffer2 = GlweCiphertext::new(
//         Scalar::ZERO,
//         output_glwe_ciphertext.glwe_size(),
//         output_glwe_ciphertext.polynomial_size(),
//         output_glwe_ciphertext.ciphertext_modulus(),
//     );
//     // KS を 2回．
//     keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &ciphertext1, &mut buffer1);
//     keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &ciphertext2, &mut buffer2);
//     for degree in 0..box_size {
//         let mut buffer1_iter = buffer1.clone();
//         buffer1_iter
//             .as_mut_polynomial_list()
//             .iter_mut()
//             .for_each(|mut poly| {
//                 polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + 0*box_size))
//             });
//         slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
//     }
//     for degree in 0..box_size {
//         let mut buffer1_iter = buffer1.clone();
//         buffer1_iter
//             .as_mut_polynomial_list()
//             .iter_mut()
//             .for_each(|mut poly| {
//                 polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + 2*box_size))
//             });
//         slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
//     }
//     for degree in 0..box_size {
//         let mut buffer2_iter = buffer2.clone();
//         buffer2_iter
//             .as_mut_polynomial_list()
//             .iter_mut()
//             .for_each(|mut poly| {
//                 polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + 1*box_size))
//             });
//         slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer2_iter.as_ref());
//     }

// }



pub fn keyswitch_two_lwe_ciphertext_and_pack_redundantly_and_fully_in_glwe_ciphertext<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext1: &Vec<LweCiphertext<InputCont>>,
    input_ciphertext2: &Vec<LweCiphertext<InputCont>>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    box_size: usize,
    block_num: usize,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let mut buffer1 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    let mut buffer2 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    // KS を 2*block_num回だけ呼び出す．
    for i in 0..block_num {
        keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext1[i], &mut buffer1);
        keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext2[i], &mut buffer2);
        for degree in 0..box_size {
            let mut buffer1_iter = buffer1.clone();
            buffer1_iter
                .as_mut_polynomial_list()
                .iter_mut()
                .for_each(|mut poly| {
                    polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + i*box_size))
                });
            slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
        }
        for degree in 0..box_size {
            let mut buffer1_iter = buffer1.clone();
            buffer1_iter
                .as_mut_polynomial_list()
                .iter_mut()
                .for_each(|mut poly| {
                    polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + i*box_size + PARAMS.polynomial_size().0/4))
                });
            slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
        }
        for degree in 0..box_size {
            let mut buffer2_iter = buffer2.clone();
            buffer2_iter
                .as_mut_polynomial_list()
                .iter_mut()
                .for_each(|mut poly| {
                    polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + i*box_size + PARAMS.polynomial_size().0/2))
                });
            slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer2_iter.as_ref());
        }
        glwe_ciphertext_opposite_assign(&mut buffer2);
        for degree in 0..box_size {
            let mut buffer2_iter = buffer2.clone();
            buffer2_iter
                .as_mut_polynomial_list()
                .iter_mut()
                .for_each(|mut poly| {
                    polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + i*box_size + 3*PARAMS.polynomial_size().0/4))
                });
            slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer2_iter.as_ref());
        }
    }
}



pub fn keyswitch_two_lwe_ciphertexts_and_pack_redundantly_in_beginning_and_end_of_glwe_ciphertext<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext1: &LweCiphertext<InputCont>,
    input_ciphertext2: &LweCiphertext<InputCont>,
    ciphertext_count: LweCiphertextCount,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let mut buffer1 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    let mut buffer2 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    // KS を 1回だけ呼び出す．
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext1, &mut buffer1);
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext2, &mut buffer2);
    for degree in 0..ciphertext_count.0 {
        let mut buffer1_iter = buffer1.clone();
        let mut buffer2_iter = buffer2.clone();
        buffer1_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(ciphertext_count.0 + degree))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer1_iter.as_ref());
        buffer2_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(output_glwe_ciphertext.polynomial_size().0 - 1 - degree))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer2_iter.as_ref());
    }
}

pub fn keyswitch_one_lwe_ciphertext_and_pack_redundantly_in_glwe_ciphertext<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext: &LweCiphertext<InputCont>,
    // input_lwe_ciphertext: &LweCiphertextList<InputCont>,
    ciphertext_count: LweCiphertextCount,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let mut buffer = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    // KS を 1回だけ呼び出す．
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext, &mut buffer);
    for degree in 0..ciphertext_count.0 {
        let mut buffer_iter = buffer.clone();
        buffer_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
    }
}



pub fn packing_keyswitch_for_bitwise_and<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext: &LweCiphertext<InputCont>,
    // input_lwe_ciphertext: &LweCiphertextList<InputCont>,
    box_size: usize,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let mut buffer = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    // KS を 1回だけ呼び出す．
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext, &mut buffer);
    for degree in box_size..2*box_size {
        let mut buffer_iter = buffer.clone();
        buffer_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
    }
}



pub fn packing_keyswitch_for_bitwise_xor<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext1: &LweCiphertext<InputCont>,
    input_ciphertext2: &LweCiphertext<InputCont>,
    // input_lwe_ciphertext: &LweCiphertextList<InputCont>,
    box_size: usize,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let mut buffer1 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    let mut buffer2 = GlweCiphertext::new(
        Scalar::ZERO,
        output_glwe_ciphertext.glwe_size(),
        output_glwe_ciphertext.polynomial_size(),
        output_glwe_ciphertext.ciphertext_modulus(),
    );
    // KS を 2回だけ呼び出す．
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext1, &mut buffer1);
    keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext2, &mut buffer2);
    for degree in 0..box_size {
        let mut buffer_iter = buffer1.clone();
        buffer_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
    }
    for degree in box_size..2*box_size {
        let mut buffer_iter = buffer2.clone();
        buffer_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree))
            });
        slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
    }
}

pub fn keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext_list: &Vec<LweCiphertext<InputCont>>,
    // input_lwe_ciphertext: &LweCiphertextList<InputCont>,
    ciphertext_count: LweCiphertextCount,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    

    let arr_len = input_ciphertext_list.len();

    
    let mut degree = 0;
    for arr_index in 0..arr_len {
        let mut buffer = GlweCiphertext::new(
            Scalar::ZERO,
            output_glwe_ciphertext.glwe_size(),
            output_glwe_ciphertext.polynomial_size(),
            output_glwe_ciphertext.ciphertext_modulus(),
        );
        keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext_list[arr_index], &mut buffer);
        for _ in 0..ciphertext_count.0 {
            let mut buffer_iter = buffer.clone();
            buffer_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree))
            });
            slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
            degree += 1;
        }        
    }
}