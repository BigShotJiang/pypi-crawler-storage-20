use tfhe::core_crypto::prelude::*;
use crate::params::PARAMS;
use crate::{benes::*, TfheParam};

pub fn print_ctx_list (big_lwe_sk: &LweSecretKey<Vec<u64>>, lwe_list: &Vec<LweCiphertextOwned<u64>>) {
    let message_modulus = PARAMS.message_modulus();
    let carry_modulus = PARAMS.carry_modulus();
    let delta = (1_u64 << 63) / (message_modulus.0 as u64 * carry_modulus.0 as u64); 
    let rounding_bit = delta >> 1;

    let arr_len = lwe_list.len();


    for i in 0..arr_len {
        let lwe_list_plaintext: Plaintext<u64> =
            decrypt_lwe_ciphertext(&big_lwe_sk, &lwe_list[i]);
        let lwe_list_result: u64 =
            (lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % message_modulus.0 as u64;
        print!("{} ", lwe_list_result);
    }
    println!("");
}

pub fn print_ctx_list2 (tfhe_param: &TfheParam, lwe_list: &Vec<LweCiphertextOwned<u64>>) {
    let message_modulus = tfhe_param.message_modulus;
    let carry_modulus = tfhe_param.carry_modulus;
    let delta = tfhe_param.delta; 
    let rounding_bit = tfhe_param.rounding_bit;

    let arr_len = lwe_list.len();


    for i in 0..arr_len {
        let lwe_list_plaintext: Plaintext<u64> =
            decrypt_lwe_ciphertext(&tfhe_param.big_lwe_sk, &lwe_list[i]);
        let lwe_list_result: u64 =
            (lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % message_modulus.0 as u64;
        print!("{} ", lwe_list_result);
    }
    println!("");
}


pub fn print_ctx (tfhe_param: &TfheParam, lwe: &LweCiphertextOwned<u64>) {
    let message_modulus = tfhe_param.message_modulus;
    let carry_modulus = tfhe_param.carry_modulus;
    let delta = tfhe_param.delta; 
    let rounding_bit = tfhe_param.rounding_bit;

    let lwe_plaintext: Plaintext<u64> =
        decrypt_lwe_ciphertext(&tfhe_param.big_lwe_sk, &lwe);
    let lwe_result: u64 =
        (lwe_plaintext.0.wrapping_add((lwe_plaintext.0 & rounding_bit) << 1) / delta) % message_modulus.0 as u64;
    print!("{} ", lwe_result);
    println!("");
}


pub fn print_ctx_list_multibit(tfhe_param: &TfheParam, lwe_list: &Vec<Vec<LweCiphertextOwned<u64>>>) {
    let arr_len = lwe_list.len();
    let bit_size = lwe_list[0].len();
    let delta = tfhe_param.delta; 
    let rounding_bit = tfhe_param.rounding_bit;

    for i in 0..arr_len {
        let mut sum = 0;
        for j in 0..bit_size {
            let decomped_plaintext: Plaintext<u64> =
                decrypt_lwe_ciphertext(&tfhe_param.big_lwe_sk, &lwe_list[i][j]);
            let decomped_result: u64 =
                (decomped_plaintext.0.wrapping_add((decomped_plaintext.0 & rounding_bit) << 1) / delta) % tfhe_param.message_modulus.0 as u64;
            sum += decomped_result << ((tfhe_param.message_modulus.0 as f64).log2() as usize * j);
        }
        print!("{} ", sum);
    }
    print!("\n");

}


pub fn print_benes_network_enum(tfhe_param: &TfheParam, benes_network_enum: &BenesNetworkEnum) {
    match benes_network_enum {
        BenesNetworkEnum::NoNest(benes_network) => {
            // println!("BenesNetwork:");
            //print!("{:?},", benes_network.switch_l.as_ref().map(|v| print_ctx_list(&tfhe_param, &v)));
            //print!("{:?}, ", benes_network.network1.as_ref().map(|v| print_ctx(&tfhe_param, &v)));
            //print!("{:?}, ", benes_network.network2.as_ref().map(|v| print_ctx(&tfhe_param, &v)));
            //print!("{:?}, ", benes_network.switch_r.as_ref().map(|v| print_ctx_list(&tfhe_param, &v)));
            //print!("\n");
            // benes_network.switch_l.as_ref().map(|v| print_ctx_list(&big_lwe_sk, &v));
            // benes_network.network1.as_ref().map(|v| print_ctx(&big_lwe_sk, &v));
            // benes_network.network2.as_ref().map(|v| print_ctx(&big_lwe_sk, &v));
            // benes_network.switch_r.as_ref().map(|v| print_ctx_list(&big_lwe_sk, &v));
        },
        BenesNetworkEnum::Nested(benes_network_nested) => {
            // println!("BenesNetworkNested:");
            //print!("{:?}, ", print_ctx_list(&tfhe_param, &benes_network_nested.switch_l));
            // print!("[{:?}], ", print_ctx_list(&big_lwe_sk, &benes_network_nested.switch_l));
            print_benes_network_enum(&tfhe_param, &*benes_network_nested.network1);
            print_benes_network_enum(&tfhe_param, &*benes_network_nested.network2);
            //print!("{:?}, ", print_ctx_list(&tfhe_param, &benes_network_nested.switch_r));
            // print!("[{:?}], ", print_ctx_list(&big_lwe_sk, &benes_network_nested.switch_r));
            print!("\n");
        },
    }
}