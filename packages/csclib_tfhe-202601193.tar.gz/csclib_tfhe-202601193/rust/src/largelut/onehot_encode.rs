use tfhe::core_crypto::prelude::*;
//use noise_calibrate_table_lookup::*;
//use keygen::*;
//use crate::packing_keyswitch::*;

use crate::algorithms::TFHE_PARAMS;
use crate::largelut::calibration_method::{PKSK_RING_ONEHOT_KEY1, PKSK_RING_ONEHOT_KEY2, PKSK_RING_ONEHOT_KEY3, PKSK_RING_ONEHOT_KEY4};
use crate::largelut::packing_keyswitch_key_generation::is_onehot_encode_keys_available;
use crate::print;
//mod onehot_encode;
use crate::{LargeLUTparams, algorithms::TfheParam, largelut::calibration_method::LargeLUT};
use crate::largelut::packing_keyswitch::par_keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext_with_thread_count_and_section;

pub fn rotate_left_negacyclic<T>(coeffs: &mut [T], k: usize)
where
    T: UnsignedInteger, // wrapping_neg を使うため
{
    let n = coeffs.len();
    if n == 0 { return; }
    let k = k % n;
    if k == 0 { return; }

    // 左に k 回転
    coeffs.rotate_left(k);

    // 末尾 k 個を符号反転（ネガサイクリック：前から末尾に送られた分を反転）
    for c in &mut coeffs[n - k..] {
        *c = c.wrapping_neg();
    }
}


use crate::largelut::packing_keyswitch::par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode;
pub fn large_ohe_ring2ring(public_params: &LargeLUTparams, onehot_lut: &GlweCiphertext<Vec<u64>>, calibrated_selector_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> GlweCiphertext<Vec<u64>> {

    let l = public_params.w_arr.len();

    let mut onehot_lut = onehot_lut.clone();
    let mut calibrated_selector_keyswitched = calibrated_selector_keyswitched.clone();
    for i in (0..l-1).rev() {
        // x_i+1 の BR
        lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[i+1]);
        TFHE_PARAMS.with(|params| {
            let parameter_set = params.borrow();
        modulus_switch_multi_bit_blind_rotate_assign(
            &calibrated_selector_keyswitched[i+1],
            &mut onehot_lut,
            &parameter_set.multi_bit_bsk,
            public_params.thread_count,
            true,
        );
        });

        let (mut mask, mut body) = onehot_lut.get_mut_mask_and_body();
        // マスク側（k 本の多項式）
        for mut poly in mask.as_mut_polynomial_list().iter_mut() {

            // negacyclic:
            rotate_left_negacyclic::<u64>(poly.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i+1] as usize); // 正しい
            //print!("b_arr[{i}] {} {}\n", public_params.b_arr[i],public_params.b_arr[i+1]);
            //print!("d_arr[{i}] {} {}\n", public_params.d_arr[i],public_params.d_arr[i+1]);
        }

        // 本文
        rotate_left_negacyclic::<u64>(body.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i+1] as usize); // 正しい

        /////////////////////////////////////////////////////////////

        if l == 4 {
            PKSK_RING_ONEHOT_KEY4.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        } else if l == 3 {
            PKSK_RING_ONEHOT_KEY3.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        }else if l == 2 {
            PKSK_RING_ONEHOT_KEY2.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        }else if l == 1 {
            PKSK_RING_ONEHOT_KEY1.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        }

        /////////////////////////////////////////////////////////////


    }
    // x_0 の BR
    TFHE_PARAMS.with(|params| {
        let parameter_set = params.borrow();
        lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[0]);
        modulus_switch_multi_bit_blind_rotate_assign(
            &calibrated_selector_keyswitched[0],
            &mut onehot_lut,
            &parameter_set.multi_bit_bsk,
            parameter_set.thread_count,
            true,
        );
    });


    return onehot_lut;
}

use crate::largelut::lwe_ciphertext_list::lwe_ciphertext_vec_to_lwe_ciphertext_list;
pub fn large_ohe(public_params: &LargeLUTparams, onehot_lut: &GlweCiphertext<Vec<u64>>, calibrated_selector_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> GlweCiphertext<Vec<u64>> {

    let l = public_params.w_arr.len();

    let mut onehot_lut = onehot_lut.clone();
    let mut calibrated_selector_keyswitched = calibrated_selector_keyswitched.clone();
TFHE_PARAMS.with(|params| {
    let parameter_set = params.borrow();
    for i in (0..l-1).rev() {
        // x_i+1 の BR
        lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[i+1]);
        modulus_switch_multi_bit_blind_rotate_assign(
            &calibrated_selector_keyswitched[i+1],
            &mut onehot_lut,
            &parameter_set.multi_bit_bsk,
            parameter_set.thread_count,
            true,
        );

        //////////////////////////////////////////////////////////

        // S_i+1=(i+2)*2^{D_{i}}箇所のSE．前半は (i+1)*2^{D_{i}-1}箇所，後半は (i+3)*2^{D_{i}-1}箇所
        let mut candidate: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for j in 0..(i+2)*2_u32.pow(public_params.d_arr[i] as u32) as usize {
            let mut extracted_lwe = LweCiphertext::new(
                0u64,
                LweSize(parameter_set.polynomial_size.0 + 1),
                parameter_set.ciphertext_modulus,
            );
            extract_lwe_sample_from_glwe_ciphertext(
                    &onehot_lut,
                    &mut extracted_lwe,
                    // LUTとOHEでSEの位置が違う?
                    // MonomialDegree(j * public_params.b_arr[i+1] as usize + public_params.b_arr[i+1] as usize / 2), 
                    MonomialDegree(j * public_params.b_arr[i+1] as usize +(public_params.b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1), // original
                );
            if j < (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize {
                
                lwe_ciphertext_opposite_assign(&mut extracted_lwe);
            }
            candidate.push(extracted_lwe);


        }
        // candidate の PKS
        let mut candidate_glwe = GlweCiphertext::new(
            0u64,
            parameter_set.glwe_dimension.to_glwe_size(),
            parameter_set.polynomial_size,
            parameter_set.ciphertext_modulus,
        );
        let candidate_list = lwe_ciphertext_vec_to_lwe_ciphertext_list(/*&public_params,*/ &candidate);
        par_keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext_with_thread_count_and_section(
            /*&public_params,*/
            &parameter_set.pksk,
            &candidate_list,
            &mut candidate_glwe,
            parameter_set.thread_count,
            LweCiphertextCount(public_params.b_arr[i] as usize),
            0,
            false        
        );
        
        //////////////////////////////////////////////////////////

        let (mut mask, mut body) = candidate_glwe.get_mut_mask_and_body();
        // マスク側（k 本の多項式）
        for mut poly in mask.as_mut_polynomial_list().iter_mut() {

            // negacyclic:
            rotate_left_negacyclic::<u64>(poly.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i] as usize);
        }

        // 本文
        rotate_left_negacyclic::<u64>(body.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i] as usize);
        onehot_lut = candidate_glwe;


    }
    // x_0 の BR
    lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[0]);
    modulus_switch_multi_bit_blind_rotate_assign(
        &calibrated_selector_keyswitched[0],
        &mut onehot_lut,
        &parameter_set.multi_bit_bsk,
        public_params.thread_count,
        true,
    );
});

    return onehot_lut;
}


use crate::largelut::calibration_method::{make_onehot_lut, make_onehot_lut2};
use crate::largelut::calibration_method::large_lut_decomp_calibrate;
pub fn get_onehot_vector(public_params: &LargeLUTparams, message: &Vec<LweCiphertextOwned<u64>>) 
-> GlweCiphertext<Vec<u64>> {
        let ctx_onehot_vector = make_onehot_lut(&public_params);
        // let start_calibrate_time = Instant::now();
        //let message_calibrated_keyswitched = calibrate(&public_params, &message);
        let message_calibrated_keyswitched = large_lut_decomp_calibrate(&message, public_params.width, &public_params);
        // let end_calibrate_time = Instant::now();
        // print!("calibrate time:\n{:?}\n", end_calibrate_time.duration_since(start_calibrate_time));
        let l = public_params.w_arr.len();
        let ctx_onehot_vector_result = if is_onehot_encode_keys_available(l) && false {
            large_ohe_ring2ring(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched) // new
        } else {
            large_ohe(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched) // old
        };
        return ctx_onehot_vector_result;
}

pub fn get_onehot_vector2(public_params: &LargeLUTparams, message: &Vec<LweCiphertextOwned<u64>>, b: &LweCiphertextOwned<u64>) 
-> GlweCiphertext<Vec<u64>> {
        let ctx_onehot_vector = make_onehot_lut2(&public_params, b);
        // let start_calibrate_time = Instant::now();
        //let message_calibrated_keyswitched = calibrate(&public_params, &message);
        let message_calibrated_keyswitched = large_lut_decomp_calibrate(&message, public_params.width, &public_params);
        // let end_calibrate_time = Instant::now();
        // print!("calibrate time:\n{:?}\n", end_calibrate_time.duration_since(start_calibrate_time));
        let l = public_params.w_arr.len();
        let ctx_onehot_vector_result = if is_onehot_encode_keys_available(l) {
            large_ohe_ring2ring(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched) // new
        } else {
            large_ohe(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched) // old
        };
        return ctx_onehot_vector_result;
}



use crate::algorithms::glwe_sample_extract;

pub fn glwe_to_vector(public_params: &LargeLUTparams, glwe: &GlweCiphertext<Vec<u64>>) 
-> Vec<LweCiphertextOwned<u64>> {

    TFHE_PARAMS.with(|param| {
        let parameter_set = param.borrow();

        let divided_box_size = (parameter_set.polynomial_size.0 as u32 / 2_u32.pow(public_params.w_arr.iter().sum())) as usize;

        let mut extracted_lwe_list: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for i in 0..parameter_set.polynomial_size.0/divided_box_size {
            // SE
            let extracted_lwe = glwe_sample_extract(&glwe, (divided_box_size as f64 / 2 as f64).ceil() as usize + i*divided_box_size - 1);
            extracted_lwe_list.push(extracted_lwe);
        }
    
        extracted_lwe_list
    })
}

