use rayon::prelude::*;


use tfhe::core_crypto::algorithms::polynomial_algorithms::polynomial_wrapping_monic_monomial_mul_assign;
use tfhe::core_crypto::commons::parameters;
use tfhe::core_crypto::prelude::*;
//use tfhe::core_crypto::algorithms::polynomial_algorithms::*;
use tfhe::core_crypto::algorithms::slice_algorithms::*;

use crate::algorithms::TFHE_PARAMS;
use crate::largelut::calibration_method::LargeLUTparams;
//use crate::largelut::calibration_method::PublicParams;

//use keygen::*;
use crate::LargeLUT;

pub fn negacyclic_index_and_sign(i: i64, k: i64, n: usize) -> (usize, i32) {
    let t = i + k;
    let q = t.div_euclid(n as i64);           // wrap 回数（負でもOK）
    let r = t.rem_euclid(n as i64) as usize;  // 0..N-1
    let sign = if (q & 1) == 0 { 1 } else { -1 };
    (r, sign)
}

pub fn keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring<Scalar, KeyCont, InputCont, OutputCont>(
    public_params: &LargeLUTparams,
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_glwe_ciphertext: &GlweCiphertext<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    i: usize,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    
    // We reset the output
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let degree_d: usize = public_params.b_arr[i] as usize * public_params.s_arr[i-1] as usize;
    for j in 0..degree_d {
        let p_j =  (j as u64) / public_params.b_arr[i];
        // t_jは正になるはず
        // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2 + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
        let t_j: u64 = ((2 * p_j + 1) * public_params.b_arr[i-1]) / 2;
        // if i == l-1 {
        //     print!("t_j: {}\n", t_j);
        // }
        output_glwe_ciphertext.get_mut_body().as_mut()[j] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
    }

    // We instantiate a decomposer
    let decomposer = SignedDecomposer::new(
        lwe_pksk.decomposition_base_log(),
        lwe_pksk.decomposition_level_count(),
    );

    // 新しい実装
    for (element_index, keyswitch_key_block) in
        lwe_pksk.iter().enumerate()
    {
        // We decompose
        let (idx, sign) = negacyclic_index_and_sign(-1*element_index as i64, 0 as i64, input_glwe_ciphertext.polynomial_size().0);
        let mut mask_elem = input_glwe_ciphertext.as_ref()[idx];
        if sign < 0 {
            mask_elem = mask_elem.wrapping_neg();
        }
        let rounded = decomposer.closest_representable(mask_elem);
        let decomp = decomposer.decompose(rounded);

        // Loop over the number of levels:
        // We compute the multiplication of a ciphertext from the private functional
        // keyswitching key with a piece of the decomposition and subtract it to the buffer
        for (level_key_cipher, decomposed) in keyswitch_key_block.iter().zip(decomp) {
            slice_wrapping_sub_scalar_mul_assign(
                output_glwe_ciphertext.as_mut(),
                level_key_cipher.as_ref(),
                decomposed.value(),
            );
        }
    }

}



pub fn par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring<
    Scalar, KeyCont, InputCont, OutputCont
>( 
    public_params: &LargeLUTparams,
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_glwe_ciphertext: &GlweCiphertext<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    i: usize,
) where
    // 変更: 並列化のために Send + Sync を要求
    Scalar: UnsignedInteger + Send + Sync,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let degree_d: usize = public_params.b_arr[i] as usize * public_params.s_arr[i-1] as usize;
    for j in 0..degree_d {
        let p_j =  (j as u64) / public_params.b_arr[i];
        // t_jは正になるはず
        // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2 + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
        let t_j: u64 = ((2 * p_j + 1) * public_params.b_arr[i-1]) / 2;
        // if i == l-1 {
        //     print!("t_j: {}\n", t_j);
        // }
        output_glwe_ciphertext.get_mut_body().as_mut()[j] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
    }
    
    // We instantiate a decomposer
    // let decomposer: SignedDecomposer<Scalar> = SignedDecomposer::new(
    //     lwe_pksk.decomposition_base_log(),
    //     lwe_pksk.decomposition_level_count(),
    // );

    // Don't go above the current number of threads
    let thread_count = public_params.thread_count.0.min(rayon::current_num_threads());
    
    // let mut input_glwe_ciphertext_mask_reversed_negated: LweCiphertext<Vec<Scalar>> = LweCiphertext::new(
    //     Scalar::ZERO,
    //     LweSize(input_glwe_ciphertext.polynomial_size().0+1),
    //     input_glwe_ciphertext.ciphertext_modulus(),
    // );

    let mut input_glwe_ciphertext_mask_reversed_negated = GlweCiphertext::new(
            Scalar::ZERO,
            input_glwe_ciphertext.glwe_size(),
            input_glwe_ciphertext.polynomial_size(),
            input_glwe_ciphertext.ciphertext_modulus(),
    );

    
    for i in 0..input_glwe_ciphertext.polynomial_size().0 {
        // We decompose
        let (idx, sign) = negacyclic_index_and_sign(-1*i as i64, 0 as i64, input_glwe_ciphertext.polynomial_size().0);
        input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[i] = input_glwe_ciphertext.get_mask().as_ref()[idx];
        if sign < 0 {
            input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[i] = input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[i].wrapping_neg();
        }
    }

    let mut intermediate_accumulators: Vec<GlweCiphertext<Vec<Scalar>>> = Vec::with_capacity(thread_count);

    // Smallest chunk_size such that thread_count * chunk_size >= input_lwe_size
    let chunk_size = input_glwe_ciphertext_mask_reversed_negated.polynomial_size().0.div_ceil(thread_count);

  

    // lwe_pksk.par_chunks(chunk_size).zip(
    //     input_glwe_ciphertext_mask_reversed_negated
    //     .get_mask()
    //     .as_ref()
    //     .par_chunks(chunk_size),
    // ).map(|(pksk_block_chunk, input_mask_reversed_negated_element_chunk)| {
    //     let mut buffer = GlweCiphertext::new(
    //         Scalar::ZERO,
    //         input_glwe_ciphertext.glwe_size(),
    //         input_glwe_ciphertext.polynomial_size(),
    //         input_glwe_ciphertext.ciphertext_modulus(),
    //     );

    //     for (pksk_block, &input_mask_reversed_negated_element) in pksk_block_chunk.iter()
    //             .zip(input_mask_reversed_negated_element_chunk.iter())
    //         {
    //             let decomposition_iter = decomposer.decompose(input_mask_reversed_negated_element);
    //             // Loop over the levels
    //             for (level_key_ciphertext, decomposed) in
    //                 pksk_block.iter().zip(decomposition_iter)
    //             {
    //                 slice_wrapping_sub_scalar_mul_assign(
    //                     buffer.as_mut(),
    //                     level_key_ciphertext.as_ref(),
    //                     decomposed.value(),
    //                 );
    //             }
    //         }
    //     buffer
    // }).collect_into_vec(&mut intermediate_accumulators);

    // 1) KSK をブロック列に“所有化”
    let ksk_blocks: Vec<_> = lwe_pksk.iter().collect();

    // 2) 入力マスクは素のスライスに（temporary/lifetime回避）
    let mask_view = input_glwe_ciphertext_mask_reversed_negated.get_mask();
    let a_slice: &[Scalar] = mask_view.as_ref();
    
    // クロージャ外に“数値だけ”退避（これらは Copy なので Sync は要らない）
    let glwe_size    = input_glwe_ciphertext.glwe_size();
    let poly_size    = input_glwe_ciphertext.polynomial_size();
    let ct_modulus   = input_glwe_ciphertext.ciphertext_modulus();

    // decomposer も中で都度作る（または base_log/level_count だけ外に出す）
    let base_log     = lwe_pksk.decomposition_base_log();
    let level_count  = lwe_pksk.decomposition_level_count();

    ksk_blocks
    .par_chunks(chunk_size)
    .zip(a_slice.par_chunks(chunk_size))
    .map(move |(pksk_block_chunk, a_chunk)| {
        // ここで input_glwe_ciphertext を参照しない！
        let mut buffer = GlweCiphertext::new(
            Scalar::ZERO,
            glwe_size,
            poly_size,
            ct_modulus,
        );

        // スレッドローカル decomposer
        let decomposer = SignedDecomposer::<Scalar>::new(base_log, level_count);

        for (pksk_block, &a_i) in pksk_block_chunk.iter().zip(a_chunk.iter()) {
            let rounded = decomposer.closest_representable(a_i);
            let decomp  = decomposer.decompose(rounded);

            for (lvl_ct, d) in pksk_block.iter().zip(decomp) {
                slice_wrapping_sub_scalar_mul_assign(
                    buffer.as_mut(),
                    lvl_ct.as_ref(),
                    d.value(),
                );
            }
        }
        buffer
    })
    .collect_into_vec(&mut intermediate_accumulators);


    let reduced = intermediate_accumulators
    .par_iter_mut()
    .reduce_with(|lhs, rhs| {
        lhs.as_mut()
            .iter_mut()
            .zip(rhs.as_ref().iter())
            .for_each(|(dst, &src)| *dst = (*dst).wrapping_add(src));

        lhs
    })
    .unwrap();

    output_glwe_ciphertext
        .get_mut_mask()
        .as_mut()
        .copy_from_slice(reduced.get_mask().as_ref());
    // let reduced_ksed_body = *reduced.get_body().data;

    // // Add the reduced body of the keyswitch to the output body to complete the keyswitch
    // *output_glwe_ciphertext.get_mut_body().data =
    //     (*output_glwe_ciphertext.get_mut_body().data).wrapping_add(reduced_ksed_body);

    // 入力（加算元）の借用：一時を束縛して寿命を延ばす
    let in_body_view = reduced.get_body();      // <- ここが生きている間 in_body は有効
    let in_body: &[Scalar] = in_body_view.as_ref();

    // 出力（加算先）の借用：同様に束縛
    let mut out_body_view = output_glwe_ciphertext.get_mut_body();
    let out_body: &mut [Scalar] = out_body_view.as_mut();

    // 要素ごとに wrapping_add（mod 加算）
    out_body
        .iter_mut()
        .zip(in_body.iter())
        .for_each(|(dst, &src)| *dst = dst.wrapping_add(src));
}



pub fn par_keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext_with_thread_count_and_section<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    /*public_parameters: &LargeLUT,*/
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_lwe_ciphertext_list: &LweCiphertextList<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    thread_count: ThreadCount,
    ciphertext_count: LweCiphertextCount,
    first_degree: usize,
    neg_flag: bool,
    
) where
    Scalar: UnsignedInteger + Send + Sync,
    KeyCont: Container<Element = Scalar> + Sync,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{

    let output_glwe_size = output_glwe_ciphertext.glwe_size();
    let output_polynomial_size = output_glwe_ciphertext.polynomial_size();
    let output_ciphertext_modulus = output_glwe_ciphertext.ciphertext_modulus();

    // Don't go above the current number of threads
    let thread_count = thread_count.0.min(rayon::current_num_threads());

    let mut intermediate_buffers = Vec::with_capacity(thread_count);

    // Smallest chunk_size such that thread_count * chunk_size >= input_lwe_size
    // let chunk_size = divide_ceil(
    //     input_lwe_ciphertext_list.lwe_ciphertext_count().0,
    //     thread_count,
    // );
    let chunk_size = input_lwe_ciphertext_list.lwe_ciphertext_count().0.div_ceil(thread_count);

    // for each ciphertext, call mono_key_switch
    input_lwe_ciphertext_list
        .par_chunks(chunk_size)
        .enumerate()
        .map(|(chunk_idx, input_ciphertext_list_chunk)| {
            let mut buffer = GlweCiphertext::new(
                Scalar::ZERO,
                output_glwe_size,
                output_polynomial_size,
                output_ciphertext_modulus,
            );

            

            let mut input_ciphertext_chunk_vec: Vec<LweCiphertext<Vec<Scalar>>> = Vec::new();
            for i in 0..input_ciphertext_list_chunk.lwe_ciphertext_count().0 {
                let mut input_ciphertext_chunk_i = LweCiphertext::new(
                    Scalar::ZERO,
                    input_ciphertext_list_chunk.lwe_size(),
                    input_ciphertext_list_chunk.ciphertext_modulus(),
                );
                for j in 0..input_ciphertext_list_chunk.lwe_size().0 {
                    input_ciphertext_chunk_i.as_mut()[j] = input_ciphertext_list_chunk.as_ref()[i * input_ciphertext_list_chunk.lwe_size().0 + j];
                }
                if neg_flag {
                    input_ciphertext_chunk_i.as_mut()[0] = input_ciphertext_chunk_i.as_ref()[0].wrapping_neg();
                }
                input_ciphertext_chunk_vec.push(input_ciphertext_chunk_i);
            }
            // let input_ciphertext_chunk_vec = lwe_ciphertext_list_to_lwe_ciphertext_vec(&input_ciphertext_list_chunk);
            keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext(
                lwe_pksk,
                &input_ciphertext_chunk_vec,
                ciphertext_count,
                &mut buffer,
            );

            // Rotate to put the ciphertexts in the right slot
            buffer
                .as_mut_polynomial_list()
                .iter_mut()
                .for_each(|mut poly| {
                    polynomial_wrapping_monic_monomial_mul_assign(
                        &mut poly,
                        MonomialDegree(chunk_idx * chunk_size * ciphertext_count.0 + first_degree)
                        // MonomialDegree(chunk_idx * chunk_size),
                    )
                });

            buffer
        })
        .collect_into_vec(&mut intermediate_buffers);

    let result = intermediate_buffers
        .par_iter_mut()
        .reduce_with(|lhs, rhs| {
            slice_wrapping_add_assign(lhs.as_mut(), rhs.as_ref());
            lhs
        })
        .unwrap();

    output_glwe_ciphertext
        .as_mut()
        .copy_from_slice(result.as_ref());
}



pub fn keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext<
    Scalar,
    KeyCont,
    InputCont,
    OutputCont,
>(
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_ciphertext_list: &Vec<LweCiphertext<InputCont>>,
    // input_lwe_ciphertext: &LweCiphertextList<InputCont>,
    ciphertext_count: LweCiphertextCount,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    

    let arr_len = input_ciphertext_list.len();

    
    let mut degree = 0;
    for arr_index in 0..arr_len {
        let mut buffer = GlweCiphertext::new(
            Scalar::ZERO,
            output_glwe_ciphertext.glwe_size(),
            output_glwe_ciphertext.polynomial_size(),
            output_glwe_ciphertext.ciphertext_modulus(),
        );
        keyswitch_lwe_ciphertext_into_glwe_ciphertext(lwe_pksk, &input_ciphertext_list[arr_index], &mut buffer);
        for _ in 0..ciphertext_count.0 {
            let mut buffer_iter = buffer.clone();
            buffer_iter
            .as_mut_polynomial_list()
            .iter_mut()
            .for_each(|mut poly| {
                polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree))
            });
            slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
            degree += 1;
        }        
    }
}


pub fn par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode<
    Scalar, KeyCont, InputCont, OutputCont
>( 
    public_params: &LargeLUTparams,
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_glwe_ciphertext: &GlweCiphertext<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    i: usize,
) where
    // 変更: 並列化のために Send + Sync を要求
    Scalar: UnsignedInteger + Send + Sync,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    // let degree_d: usize = public_params.b_arr[i+1] as usize * public_params.s_arr[i] as usize;
    // for j in 0..degree_d {
    //     let p_j =  (j as u64) / public_params.b_arr[i+1];
    //     // t_jは正になるはず
    //     // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2 + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
    //     let t_j: u64 = ((2 * p_j + 1) * public_params.b_arr[i-1]) / 2;
    //     // if i == l-1 {
    //     //     print!("t_j: {}\n", t_j);
    //     // }
    //     output_glwe_ciphertext.get_mut_body().as_mut()[j] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
    // }

    for j in 0..((i+3)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize) {
        let t_j = j * public_params.b_arr[i+1] as usize +(public_params.b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1;
        for k in 0..public_params.b_arr[i] as usize {
            output_glwe_ciphertext.get_mut_body().as_mut()[j*public_params.b_arr[i] as usize + k] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
        }
    }

    for j in 0..((i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize) {
        TFHE_PARAMS.with(|params| {
            let parameter_set = params.borrow();
        let t_j = parameter_set.polynomial_size.0 + (j - (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize) * public_params.b_arr[i+1] as usize +(public_params.b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1;
        for k in 0..public_params.b_arr[i] as usize {
            output_glwe_ciphertext.get_mut_body().as_mut()[parameter_set.polynomial_size.0 + (j - (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize) * public_params.b_arr[i] as usize + k] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
        }
        });
    }
    
    // We instantiate a decomposer
    // let decomposer: SignedDecomposer<Scalar> = SignedDecomposer::new(
    //     lwe_pksk.decomposition_base_log(),
    //     lwe_pksk.decomposition_level_count(),
    // );

    // Don't go above the current number of threads
    let thread_count = public_params.thread_count.0.min(rayon::current_num_threads());
    
    // let mut input_glwe_ciphertext_mask_reversed_negated: LweCiphertext<Vec<Scalar>> = LweCiphertext::new(
    //     Scalar::ZERO,
    //     LweSize(input_glwe_ciphertext.polynomial_size().0+1),
    //     input_glwe_ciphertext.ciphertext_modulus(),
    // );

    let mut input_glwe_ciphertext_mask_reversed_negated = GlweCiphertext::new(
            Scalar::ZERO,
            input_glwe_ciphertext.glwe_size(),
            input_glwe_ciphertext.polynomial_size(),
            input_glwe_ciphertext.ciphertext_modulus(),
    );

    
    for j in 0..input_glwe_ciphertext.polynomial_size().0 {
        // We decompose
        let (idx, sign) = negacyclic_index_and_sign(-1*j as i64, 0 as i64, input_glwe_ciphertext.polynomial_size().0);
        input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[j] = input_glwe_ciphertext.get_mask().as_ref()[idx];
        if sign < 0 {
            input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[j] = input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[j].wrapping_neg();
        }
    }

    let mut intermediate_accumulators: Vec<GlweCiphertext<Vec<Scalar>>> = Vec::with_capacity(thread_count);

    // Smallest chunk_size such that thread_count * chunk_size >= input_lwe_size
    let chunk_size = input_glwe_ciphertext_mask_reversed_negated.polynomial_size().0.div_ceil(thread_count);

  



    // 1) KSK をブロック列に“所有化”
    let ksk_blocks: Vec<_> = lwe_pksk.iter().collect();

    // 2) 入力マスクは素のスライスに（temporary/lifetime回避）
    let mask_view = input_glwe_ciphertext_mask_reversed_negated.get_mask();
    let a_slice: &[Scalar] = mask_view.as_ref();
    
    // クロージャ外に“数値だけ”退避（これらは Copy なので Sync は要らない）
    let glwe_size    = input_glwe_ciphertext.glwe_size();
    let poly_size    = input_glwe_ciphertext.polynomial_size();
    let ct_modulus   = input_glwe_ciphertext.ciphertext_modulus();

    // decomposer も中で都度作る（または base_log/level_count だけ外に出す）
    let base_log     = lwe_pksk.decomposition_base_log();
    let level_count  = lwe_pksk.decomposition_level_count();

    ksk_blocks
    .par_chunks(chunk_size)
    .zip(a_slice.par_chunks(chunk_size))
    .map(move |(pksk_block_chunk, a_chunk)| {
        // ここで input_glwe_ciphertext を参照しない！
        let mut buffer = GlweCiphertext::new(
            Scalar::ZERO,
            glwe_size,
            poly_size,
            ct_modulus,
        );

        // スレッドローカル decomposer
        let decomposer = SignedDecomposer::<Scalar>::new(base_log, level_count);

        for (pksk_block, &a_i) in pksk_block_chunk.iter().zip(a_chunk.iter()) {
            let rounded = decomposer.closest_representable(a_i);
            let decomp  = decomposer.decompose(rounded);

            for (lvl_ct, d) in pksk_block.iter().zip(decomp) {
                slice_wrapping_sub_scalar_mul_assign(
                    buffer.as_mut(),
                    lvl_ct.as_ref(),
                    d.value(),
                );
            }
        }
        buffer
    })
    .collect_into_vec(&mut intermediate_accumulators);


    let reduced = intermediate_accumulators
    .par_iter_mut()
    .reduce_with(|lhs, rhs| {
        lhs.as_mut()
            .iter_mut()
            .zip(rhs.as_ref().iter())
            .for_each(|(dst, &src)| *dst = (*dst).wrapping_add(src));

        lhs
    })
    .unwrap();

    output_glwe_ciphertext
        .get_mut_mask()
        .as_mut()
        .copy_from_slice(reduced.get_mask().as_ref());


    // 入力（加算元）の借用：一時を束縛して寿命を延ばす
    let in_body_view = reduced.get_body();      // <- ここが生きている間 in_body は有効
    let in_body: &[Scalar] = in_body_view.as_ref();

    // 出力（加算先）の借用：同様に束縛
    let mut out_body_view = output_glwe_ciphertext.get_mut_body();
    let out_body: &mut [Scalar] = out_body_view.as_mut();

    // 要素ごとに wrapping_add（mod 加算）
    out_body
        .iter_mut()
        .zip(in_body.iter())
        .for_each(|(dst, &src)| *dst = dst.wrapping_add(src));
}

