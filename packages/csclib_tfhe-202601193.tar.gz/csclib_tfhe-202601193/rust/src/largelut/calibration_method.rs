use core::panic;
use std::time::*;

use tfhe::core_crypto::prelude::UnsignedInteger; // ← これがポイント
use tfhe::core_crypto::prelude::*;
use tfhe::shortint::parameters::v0_10::classic::gaussian::p_fail_2_minus_64::pbs_ks::V0_10_WITH_CARRY_PARAMETERS_VEC_PBS_KS;

use crate::algorithms::TFHE_PARAMS;
use crate::algorithms::TfheParam;
use crate::algorithms::trivial_const;
use crate::largelut::ioutils::*;
use crate::largelut::packing_keyswitch_key_generation::*;
use crate::largelut::sample_extract::*;
use crate::largelut::packing_keyswitch::*;
use crate::largelut::lwe_ciphertext_list::*;

//use keygen::*;

//use crate::packing_keyswitch::*;
//use crate::sample_extract::*;
//use sample_extract::*;
//use crate::lwe_ciphertext_list::*;
use crate::algorithms::lwe_encrypt;
use crate::print;
//use crate::algorithms::blog;

/* 
pub struct PublicParams<'a> {
//    pub parameter_set: &'a ClassicPBSParameters,
    pub parameter_set: &'a TfheParam,
    pub ksk: LweKeyswitchKey<Vec<u64>>,
    pub pksk: LwePackingKeyswitchKey<Vec<u64>>,
    pub pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>>,
    pub pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>>,
    pub multi_bit_bsk: FourierLweMultiBitBootstrapKeyOwned,
    pub secret_key: LweSecretKey<Vec<u64>>,
    pub l: usize,
    pub w_arr: Vec<u32>,
    pub d_arr: Vec<u64>,
    pub b_arr: Vec<u64>,
    pub s_arr: Vec<u64>,
    pub thread_count: ThreadCount,
}

impl <'a> PublicParams<'a> {
    pub fn new(
        parameter_set: &'a TfheParam,
        //ksk: &'a LweKeyswitchKey<Vec<u64>>,
        //pksk: &'a LwePackingKeyswitchKey<Vec<u64>>,
        //pksk_ring2ring_arr: &'a Vec<LwePackingKeyswitchKeyOwned<u64>>,
        //pksk_ring2ring_onehot_encode_arr: &'a Vec<LwePackingKeyswitchKeyOwned<u64>>,
        //multi_bit_bsk: &'a FourierLweMultiBitBootstrapKeyOwned,
        //secret_key: &'a LweSecretKey<Vec<u64>>,
        l: usize,
        //w_arr: Vec<u32>,
        //d_arr: Vec<u64>,
        //b_arr: Vec<u64>,
        //s_arr: Vec<u64>,
        thread_count: ThreadCount,
    ) -> Self {
        let (w_arr, d_arr, b_arr, s_arr) = compute_arrays(l, &parameter_set);
        let (pksk_ring2ring_arr, pksk_ring2ring_onehot_encode_arr) = compute_ring2ringkeys(&parameter_set, &s_arr, &b_arr, l);    
        let ksk = parameter_set.ksk.clone();
        let pksk = parameter_set.pksk.clone();
        let multi_bit_bsk = parameter_set.multi_bit_bsk.clone();
        let secret_key = parameter_set.big_lwe_sk.clone();
        let p = PublicParams {
            parameter_set: parameter_set,
            ksk: ksk.clone(),
            pksk: pksk,
            pksk_ring2ring_arr: pksk_ring2ring_arr,
            pksk_ring2ring_onehot_encode_arr: pksk_ring2ring_onehot_encode_arr,
            multi_bit_bsk: multi_bit_bsk,
            secret_key: secret_key,
            l,
            w_arr,
            d_arr,
            b_arr,
            s_arr,
            thread_count,
        };
        p
    }
}
*/

#[derive(Clone)]
pub struct LargeLUTparams {
//    pub parameter_set: &'a ClassicPBSParameters,
    //pub parameter_set: &'a TfheParam,
    //pub pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>>,
    //pub pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>>,
    pub width: usize, // テーブルの長さ
    pub w_arr: Vec<u32>,
    pub d_arr: Vec<u64>,
    pub b_arr: Vec<u64>,
    pub s_arr: Vec<u64>,
    pub thread_count: ThreadCount,
}

impl LargeLUTparams {
    pub fn new(
        //parameter_set: &TfheParam,
        width: usize,
        thread_count: ThreadCount,
    ) -> Self {
        TFHE_PARAMS.with(|param| {
            let parameter_set = param.borrow();
            let (w_arr, d_arr, b_arr, s_arr) = compute_large_lut_arrays(width, &parameter_set);
            //let l = w_arr.len();
            //let (pksk_ring2ring_arr, pksk_ring2ring_onehot_encode_arr) = compute_ring2ringkeys(&parameter_set, &s_arr, &b_arr, l);    
            let p = LargeLUTparams {
            //parameter_set: parameter_set,
            //pksk_ring2ring_arr: pksk_ring2ring_arr,
            //pksk_ring2ring_onehot_encode_arr: pksk_ring2ring_onehot_encode_arr,
                width,
                w_arr,
                d_arr,
                b_arr,
                s_arr,
                thread_count,
            };
            p
        })
    }
    pub fn get_width(&self) -> usize {
        let width = self.w_arr.iter().sum::<u32>() as usize;
        return width;
    }
    pub fn get_l(&self) -> usize {
        return self.w_arr.len(); // l と等しい
    }
}



pub fn rdiv(n: i32, d: u64) -> i32 {
    return (n as f64 / d as f64 + 0.5).floor() as i32;
}
pub fn rmod(n: i32, d: u64) -> i32 {
    return n - rdiv(n, d) * d as i32;
}


pub fn rotate_right_negacyclic<T>(coeffs: &mut [T], k: usize)
where
    T: UnsignedInteger, // ← wrapping_neg を使うための境界
{
    let n = coeffs.len();
    if n == 0 { return; }
    let k = k % n;
    if k == 0 { return; }

    coeffs.rotate_right(k);

    // 先頭 k 個を符号反転（トーラスの -x = wrapping_neg）
    for c in &mut coeffs[..k] {
        *c = c.wrapping_neg();   // ← &mut T なので *c = ...
    }
}

use crate::algorithms::{lwe_get_modulus,lwe_get_carry_modulus};
pub fn calibrate_table(public_params: &LargeLUTparams, amplitude_param: usize, period_param: usize) -> GlweCiphertext<Vec<u64>>{
    //let modulus = public_params.parameter_set.message_modulus as u64 * public_params.parameter_set.carry_modulus as u64;
    let modulus = lwe_get_modulus() as u64 * lwe_get_carry_modulus() as u64;
    let delta = (1_u64 << 63) / modulus;

TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();

    let mut calibrate_plaintext_list = PlaintextList::new(0*delta, PlaintextCount(parameter_set.polynomial_size.0));

    let l = public_params.w_arr.len();

    for i in 0..parameter_set.polynomial_size.0 {
        //print!("Calibrate table index  i {} / l {} b_arr {}\n", i, l, public_params.b_arr[l-1]);
        //let degree = (i-public_params.b_arr[l -1] as usize/2) as i32;
        let degree = (i as i64 - public_params.b_arr[l -1] as i64 / 2) as i32;
        //print!("degree {}\n", degree);
        let period = public_params.b_arr[l -1] as usize as u64 / 2_u32.pow(period_param as u32) as u64;
        let amplitude = 2_u32.pow(amplitude_param as u32) as u64;
        //let half_amplitude = 2_u32.pow(amplitude_param  as u32 - 1) as u64;
        let half_amplitude = 2_u32.pow(amplitude_param  as u32 - 1) as i64;


        calibrate_plaintext_list.as_mut()[i] 
            = ((half_amplitude - rdiv(rmod(degree, period), period / amplitude as u64) as i64) as u64 * delta) as u64;
    }
    let calibrate_lut: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
        parameter_set.glwe_dimension.to_glwe_size(), &calibrate_plaintext_list, 
        parameter_set.ciphertext_modulus
    );
    return calibrate_lut;
})
}


pub fn large_lut_calibrate(public_params: &LargeLUTparams, message: &Vec<LweCiphertextOwned<u64>>) 
-> Vec<LweCiphertextOwned<u64>> {

TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();

    //let delta = (1_u64 << 63) / (public_params.parameter_set.message_modulus.0 as u64 * public_params.parameter_set.carry_modulus.0 as u64);

    let l = public_params.w_arr.len();

    let mut message_calibrated = message.clone();
    let mut message_calibrated_keyswithced = Vec::new();
    for i in 0..l-1 {
        let mut message_i_keyswitched = LweCiphertext::new(
            0,
            parameter_set.lwe_dimension.to_lwe_size(),
            parameter_set.ciphertext_modulus,
        );
        // println!("before KS in calibrate");
        let start_ks = Instant::now();
        par_keyswitch_lwe_ciphertext(&parameter_set.ksk, &message_calibrated[i], 
            &mut message_i_keyswitched
        );
        let duration_ks = start_ks.elapsed();
        println!("Time elapsed in KS for calibrate method: {:?}", duration_ks);
        // println!("after KS in calibrate");
        message_calibrated_keyswithced.push(message_i_keyswitched.clone());
        for j in i+1..l {
            // let start_table = Instant::now();
            let mut calibrate_table = calibrate_table(public_params, public_params.w_arr[j] as usize, (public_params.d_arr[i]-public_params.d_arr[j-1]) as usize);
            // let duration_table = start_table.elapsed();
            // println!("Time elapsed in calibrate_table for calibrate method: {:?}", duration_table);

            // println!("before BR in calibrate");
            // message_i の BR
            let start_br = Instant::now();
            modulus_switch_multi_bit_blind_rotate_assign(
                &message_i_keyswitched,
                &mut calibrate_table,
                &parameter_set.multi_bit_bsk,
                public_params.thread_count,
                true,
            );
            let duration_br = start_br.elapsed();
            println!("Time elapsed in BR for calibrate method: {:?}", duration_br);
            // println!("after BR in calibrate");
            // SE
            let mut extracted_lwe = LweCiphertext::new(
                0u64,
                LweSize(parameter_set.polynomial_size.0 + 1),
                parameter_set.ciphertext_modulus,
            );
            // let start_se = Instant::now();
            // println!("before SE in calibrate");
            extract_lwe_sample_from_glwe_ciphertext(
                &calibrate_table,
                &mut extracted_lwe,
                // LUTとOHEでSEの位置が違う?
                MonomialDegree(public_params.b_arr[l -1] as usize /2),
            );
            // let duration_se = start_se.elapsed();
            // println!("Time elapsed in SE for calibrate method: {:?}", duration_se);
            
            // println!("after SE in calibrate");
            // calibrate
            lwe_ciphertext_add_assign(&mut message_calibrated[j], &extracted_lwe);
        }
    }
    // message_L-1 の KS
    let mut message_l_1_keyswitched = LweCiphertext::new(
        0,
        parameter_set.lwe_dimension.to_lwe_size(),
        parameter_set.ciphertext_modulus,
    );
    let start_ks = Instant::now();
    // println!("before KS in calibrate for L-1");
    par_keyswitch_lwe_ciphertext(&parameter_set.ksk, &message_calibrated[l-1], 
        &mut message_l_1_keyswitched
    );
    let duration_ks = start_ks.elapsed();
    println!("Time elapsed in KS for calibrate method (L-1): {:?}", duration_ks);
    // println!("after KS in calibrate for L-1");
    message_calibrated_keyswithced.push(message_l_1_keyswitched.clone());
    return message_calibrated_keyswithced;
})
}


pub fn large_lut_ring2ring(public_params: &LargeLUTparams, large_lut: &GlweCiphertext<Vec<u64>>, message_calibrated_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> LweCiphertextOwned<u64>{
    let mut large_lut = large_lut.clone();

TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();

    let l = public_params.w_arr.len();

    for i in 1..l {
        // message_i の BR
        let start_br = Instant::now();
        modulus_switch_multi_bit_blind_rotate_assign(
            &message_calibrated_keyswitched[i-1],
            &mut large_lut,
            &parameter_set.multi_bit_bsk,
            public_params.thread_count,
            true,
        );
        let duration_br = start_br.elapsed();
        println!("Time elapsed in BR for large lut: {:?}", duration_br);

        let start_rotate = Instant::now();
        let (mut mask, mut body) = large_lut.get_mut_mask_and_body();

        // マスク側（k 本の多項式）
        for mut poly in mask.as_mut_polynomial_list().iter_mut() {

            // negacyclic:
            rotate_right_negacyclic::<u64>(poly.as_mut(), i*(public_params.b_arr[l -1] as usize)/2);
        }

        // 本文
        rotate_right_negacyclic::<u64>(body.as_mut(), i*(public_params.b_arr[l -1] as usize)/2);
        let duration_rotate = start_rotate.elapsed();
        println!("Time elapsed in rotate for large lut: {:?}", duration_rotate);

        // if i == public_params.l -1 {
            // print!("{}-th ring2ring PKS :\n", i);
            // print_glwe(&public_params, &public_params.secret_key, &large_lut, 1);
        // }

        
        // keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
        //     &public_params,
        //     &public_params.pksk_ring2ring_arr[i-1],
        //     &large_lut.clone(),
        //     &mut large_lut,
        //     i,
        // );

        let start_pks = Instant::now();

        if l == 4 {
/*
            par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                &public_params,
                &PKSK_RING_KEY4.with(|p| {
                    let pksk_ring_key = p.borrow();
                    pksk_ring_key[i-1].clone() // 遅い!!!
                }),
            &large_lut.clone(),
            &mut large_lut,
                i,
            );
*/
            PKSK_RING_KEY4.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        } else if l == 3 {
            PKSK_RING_KEY3.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        } else if l == 2 {
            PKSK_RING_KEY2.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        } else if l == 1 {
            PKSK_RING_KEY1.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        }
         
        
/* 
        par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
            &public_params,
            &public_params.pksk_ring2ring_arr[i-1], // ここで使うだけ
                    &large_lut.clone(),
            &mut large_lut,
            i,
        );
*/
        let duration_pks = start_pks.elapsed();
        println!("Time elapsed in PKS for large lut: {:?}", duration_pks);




        // print_glwe(&public_params, &public_params.secret_key, &large_lut, 1);


        
    }

    let start_br = Instant::now();
    // message_L-1 の BR
    modulus_switch_multi_bit_blind_rotate_assign(
        &message_calibrated_keyswitched[l-1],
        &mut large_lut,
        &parameter_set.multi_bit_bsk,
        public_params.thread_count,
        true,
    );
    let duration_br = start_br.elapsed();
    println!("Time elapsed in BR for large lut (L-1): {:?}", duration_br);

    // let (mut mask, mut body) = large_lut.get_mut_mask_and_body();

    // // マスク側（k 本の多項式）
    // for mut poly in mask.as_mut_polynomial_list().iter_mut() {

    //     // negacyclic:
    //     rotate_right_negacyclic::<u64>(poly.as_mut(), public_params.l*(public_params.b_arr[public_params.l -1] as usize)/2);
    // }

    // // 本文
    // rotate_right_negacyclic::<u64>(body.as_mut(), public_params.l*(public_params.b_arr[public_params.l -1] as usize)/2);

    // SE
    let mut z = LweCiphertext::new(
        0u64,
        LweSize(parameter_set.polynomial_size.0 + 1),
        parameter_set.ciphertext_modulus,
    );
    extract_lwe_sample_from_glwe_ciphertext(
        &large_lut,
        &mut z,
        MonomialDegree(public_params.b_arr[l -1] as usize / 2),
    );
    // extract_lwe_sample_from_glwe_ciphertext(
    //     &large_lut,
    //     &mut z,
    //     MonomialDegree(public_params.b_arr[public_params.l -1] as usize / 2 + public_params.b_arr[public_params.l -1] as usize * ((public_params.l-1)/2) * (1u64 << public_params.w_arr[public_params.l -1]) as usize),
    // );
    return z;
})
}

pub fn large_lut_lookup_w(public_params: &LargeLUTparams, large_lut_w: &Vec<GlweCiphertext<Vec<u64>>>, message_calibrated_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> Vec<LweCiphertextOwned<u64>> {
    let mut result: Vec<LweCiphertextOwned<u64>> = Vec::new();
    for l in 0..large_lut_w.len() {
        let z = if is_ring2ring_keys_available(l) {
            large_lut_ring2ring(public_params, &large_lut_w[l], &message_calibrated_keyswitched)
        } else {
            large_lut(public_params, &large_lut_w[l], &message_calibrated_keyswitched)
        };
        result.push(z);
    }
    return result;
}

use crate::algorithms::LwePacked;
pub fn LwePacked_large_lut_lookup(public_params: &LargeLUTparams, large_lut_w: &Vec<GlweCiphertext<Vec<u64>>>, message_calibrated_keyswitched: &LwePacked, v_width: usize) -> LwePacked {
    let x = large_lut_lookup_w(public_params, large_lut_w, &message_calibrated_keyswitched.get_lwe());
    return LwePacked::set_lwe(x, v_width);    
}

use crate::algorithms::lwe_decrypt;
use crate::algorithms::lwe_bit_decomposition_int;
pub fn large_lut_decomp_calibrate(message: &Vec<LweCiphertextOwned<u64>>, width: usize, large_lut: &LargeLUTparams) -> Vec<LweCiphertextOwned<u64>> {
    let message_bit = lwe_bit_decomposition_int(message, width);
    let message_decomp = compose_bits_for_large_lut(&message_bit, &large_lut);
    let message_calibrated_keyswitched = large_lut_calibrate(large_lut, &message_decomp);
    return message_calibrated_keyswitched;
}

use crate::algorithms::LweInt;
pub fn LweInt_large_lut_decomp_calibrate(message: &LweInt, large_lut: &LargeLUTparams) -> LwePacked {
    let message_bit_short = message.to_bit();
    let message_bit: Vec<LweCiphertextOwned<u64>> = message_bit_short.iter().map(|x| x.get_lwe()).collect();
    let message_decomp = compose_bits_for_large_lut(&message_bit, &large_lut);
    let message_calibrated_keyswitched = large_lut_calibrate(large_lut, &message_decomp);
    return LwePacked::set_lwe(message_calibrated_keyswitched.clone(), message.bit_size());
}

pub fn large_lut(public_params: &LargeLUTparams, large_lut: &GlweCiphertext<Vec<u64>>, message_calibrated_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> LweCiphertextOwned<u64>{
    //let delta = (1_u64 << 63) / (public_params.parameter_set.message_modulus as u64 * public_params.parameter_set.carry_modulus as u64); 
    let mut large_lut = large_lut.clone();
    let l = public_params.w_arr.len();
TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();
    for i in 1..l {
        // message_i の BR
        modulus_switch_multi_bit_blind_rotate_assign(
            &message_calibrated_keyswitched[i-1],
            &mut large_lut,
            &parameter_set.multi_bit_bsk,
            public_params.thread_count,
            true,
        );
        // S_i=(i+1)*2^{D_{i-1}}箇所のSE．前半は i*2^{D_{i-1}-1}箇所，後半は (i+2)*2^{D_{i-1}-1}箇所
        let mut candidate: Vec<LweCiphertextOwned<u64>> = Vec::new();

        

        // SEするnth
        let mut nth_vec: Vec<usize> = Vec::new();
        for j in 0..(i+1)*2_u32.pow(public_params.d_arr[i-1] as u32) as usize {
  
            if j < i*2_u32.pow(public_params.d_arr[i-1] as u32 - 1) as usize {
                nth_vec.push(parameter_set.polynomial_size.0 - i*(public_params.b_arr[l -1] as usize)/2 + j*(public_params.b_arr[i-1] as usize) + (public_params.b_arr[i-1] as usize)/2);
            } else {
                nth_vec.push((j - i*2_u32.pow(public_params.d_arr[i-1] as u32 - 1) as usize) * public_params.b_arr[i-1] as usize + public_params.b_arr[i-1] as usize/2);
            }
        }
        // SE
        let mut extracted_samples = LweCiphertextList::new(
            0u64,
            LweDimension(parameter_set.polynomial_size.0).to_lwe_size(),
            LweCiphertextCount(parameter_set.polynomial_size.0),
            parameter_set.ciphertext_modulus,
        );

        par_glwe_to_lwe(
            &large_lut,
            &mut extracted_samples,
            public_params.thread_count,
            nth_vec.clone(),
        );


        // nth_vecで指定した箇所を取り出す
        for j in 0..(i+1)*2_u32.pow(public_params.d_arr[i-1] as u32) as usize {
            let mut extracted_lwe = LweCiphertext::new(
                0u64,
                LweSize(parameter_set.polynomial_size.0 + 1),
                parameter_set.ciphertext_modulus,
            );
            if j < i*2_u32.pow(public_params.d_arr[i-1] as u32 - 1) as usize {
                for k in 0..parameter_set.polynomial_size.0+1 {
                    extracted_lwe.as_mut()[k] = extracted_samples.as_ref()[nth_vec[j]*(parameter_set.polynomial_size.0+1)+k];
                }
                lwe_ciphertext_opposite_assign(&mut extracted_lwe);
            } else {
                for k in 0..parameter_set.polynomial_size.0+1 {
                    extracted_lwe.as_mut()[k] = extracted_samples.as_ref()[nth_vec[j]*(parameter_set.polynomial_size.0+1)+k];
                }
            }
            candidate.push(extracted_lwe);
        }

        // ==========================================




        // candidate の PKS
        let candidate_list = lwe_ciphertext_vec_to_lwe_ciphertext_list(/*public_params,*/ &candidate);
        par_keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext_with_thread_count_and_section(
            /*public_params,*/
            &parameter_set.pksk,
            &candidate_list,
            &mut large_lut,
            public_params.thread_count,
            LweCiphertextCount(public_params.b_arr[i] as usize),
            0,
            false        
        );
    }

    // message_L-1 の BR
    modulus_switch_multi_bit_blind_rotate_assign(
        &message_calibrated_keyswitched[l-1],
        &mut large_lut,
        &parameter_set.multi_bit_bsk,
        public_params.thread_count,
        true,
    );
    // SE
    let mut z = LweCiphertext::new(
        0u64,
        LweSize(parameter_set.polynomial_size.0 + 1),
        parameter_set.ciphertext_modulus,
    );
    extract_lwe_sample_from_glwe_ciphertext(
        &large_lut,
        &mut z,
        MonomialDegree(public_params.b_arr[l -1] as usize / 2),
    );
    return z;
})
}


/* 
pub fn compute_ring2ringkeys(parameter_set: &TfheParam, s_arr: &Vec<u64>, b_arr: &Vec<u64>, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>>, Vec<LwePackingKeyswitchKeyOwned<u64>>) {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    let pksk_slice: &[u64] = parameter_set.pksk.as_ref();

    let server_side_key_computing = false;
    let mut pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new(); // 今回は使わないので空でOK
    let mut pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new();
    if server_side_key_computing {
            for i in 1..l {
                let mut pksk_ring2ring_i = LwePackingKeyswitchKeyOwned::new(
                    0,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    LweDimension(parameter_set.polynomial_size.0),
                    parameter_set.glwe_dimension,
                    parameter_set.polynomial_size,
                    parameter_set.ciphertext_modulus,
                );
                {
                let pksk_ring2ring_slice: &mut [u64] = pksk_ring2ring_i.as_mut();
                let degree_d: usize = b_arr[i] as usize * s_arr[i-1] as usize;
                for block_index in 0..parameter_set.polynomial_size.0 {
                    for j in 0..degree_d {
                        let p_j =  (j as u64) / b_arr[i];
                        let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2;
                        let (idx, sign) = negacyclic_index_and_sign(block_index as i64, t_j as i64, parameter_set.polynomial_size.0);
                        for level in 0..parameter_set.ks_level.0 {
                            let start_index_mask = ((idx*parameter_set.ks_level.0 + level) * parameter_set.glwe_dimension.to_glwe_size().0 + 0) * parameter_set.polynomial_size.0;
                            let start_index_body = ((idx*parameter_set.ks_level.0 + level) * parameter_set.glwe_dimension.to_glwe_size().0 + 1) * parameter_set.polynomial_size.0;
            
                            // ★ pksk からコピーを作る（pksk 自体は変更しない）
                            let mut pksk_block_level_mask: Vec<u64> =
                                pksk_slice[start_index_mask .. start_index_mask + parameter_set.polynomial_size.0].to_vec();

                            let mut pksk_block_level_body: Vec<u64> =
                                pksk_slice[start_index_body .. start_index_body + parameter_set.polynomial_size.0].to_vec();

                            // ここから先はコピーに対して自由に変更してよい
                            rotate_right_negacyclic(&mut pksk_block_level_mask[..], j);
                            rotate_right_negacyclic(&mut pksk_block_level_body[..], j);

                            if sign < 0 {
                                for coeff in pksk_block_level_mask.iter_mut() {
                                    *coeff = coeff.wrapping_neg();
                                }
                                for coeff in pksk_block_level_body.iter_mut() {
                                    *coeff = coeff.wrapping_neg();
                                }
                            }

                
                            let base_dst = (block_index * parameter_set.ks_level.0 + level) * parameter_set.glwe_dimension.to_glwe_size().0 * parameter_set.polynomial_size.0;

                            let start_index_mask_dst = base_dst + 0 * parameter_set.polynomial_size.0;                          // glwe成分 0
                            let start_index_body_dst = base_dst + 1 * parameter_set.polynomial_size.0; // glwe成分 最後

                            for t in 0..parameter_set.polynomial_size.0 {
                                pksk_ring2ring_slice[start_index_mask_dst + t] =
                                    pksk_ring2ring_slice[start_index_mask_dst + t]
                                        .wrapping_add(pksk_block_level_mask[t]);

                                pksk_ring2ring_slice[start_index_body_dst + t] =
                                    pksk_ring2ring_slice[start_index_body_dst + t]
                                        .wrapping_add(pksk_block_level_body[t]);
                            }
                            
                        }
                    }
                }            
                }
                pksk_ring2ring_arr.push(pksk_ring2ring_i);

            }
        pksk_ring2ring_onehot_encode_arr = load_bin(
            &format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l)
        ).unwrap();
    } else {
/*
        pksk_ring2ring_arr = load_bin(
            &format!("../../keygen/keys/pksk_ring2ring_{}_{}.bin", parameter_set.message_modulus.0, l)
        ).unwrap();
        pksk_ring2ring_onehot_encode_arr = load_bin(
            &format!("../../keygen/keys/pksk_ring2ring_onehot_encode_{}_{}.bin", parameter_set.message_modulus.0, l)
        ).unwrap();
 */
        (pksk_ring2ring_arr, pksk_ring2ring_onehot_encode_arr) = generate_ring2ring_keys(&parameter_set, l);
    }
    return (pksk_ring2ring_arr, pksk_ring2ring_onehot_encode_arr);

}
*/

pub fn compute_ring2ringkeys(parameter_set: &TfheParam, s_arr: &Vec<u64>, b_arr: &Vec<u64>, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    let pksk_slice: &[u64] = parameter_set.pksk.as_ref();

    let server_side_key_computing = false;
    let mut pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new(); // 今回は使わないので空でOK
/*
        pksk_ring2ring_arr = load_bin(
            &format!("../../keygen/keys/pksk_ring2ring_{}_{}.bin", parameter_set.message_modulus.0, l)
        ).unwrap();
        pksk_ring2ring_onehot_encode_arr = load_bin(
            &format!("../../keygen/keys/pksk_ring2ring_onehot_encode_{}_{}.bin", parameter_set.message_modulus.0, l)
        ).unwrap();
 */
        pksk_ring2ring_arr = generate_ring2ring_keys(&parameter_set, l);
    return pksk_ring2ring_arr;

}

 
pub fn compute_arrays(l: usize, parameter_set: &TfheParam) -> (Vec<u32>, Vec<u64>, Vec<u64>, Vec<u64>) {
    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    let modulus = parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64;
    //let w = (parameter_set.message_modulus as f64).log2().floor() as u32;
    let w = (modulus as f64).log2().floor() as u32;
    //let w1 = (blog(modulus-1)+1) as u32;
    //if w != w1 {
    //    println!("Warning: modulus {} log2 floor {} != blog(modulus-1)+1 {}", modulus, w, w1);
    //}
    let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);

    while sum <= limit && i < l as u64 {
        //let ilog1 = (i as f64).log2().floor() as u32;
        //let ilog2 = (blog(i+1)) as u32;
        //if ilog1 != ilog2 {
        //    println!("Warning: i {} log2 floor {} != blog(i) {}", i, ilog1, ilog2);            
        //}
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        //let wi = if i == 0 { w } else { w - 1 - blog(i+1) as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }

    let mut d_arr: Vec<u64> = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }

    // b_arr = B / 2^{D_i}
    let b_arr: Vec<u64> = d_arr
        .iter()
        .map(|&di| (parameter_set.polynomial_size.0 / modulus as usize) as u64 / (1u64 << di))
        .collect();

    // s_arr = (i+1) * 2^{D_{i-1}}  （i = 1,...,L-1）
    let s_arr: Vec<u64> = (1..w_arr.len())
        .map(|i| (i as u64 + 1) * (1u64 << d_arr[i - 1]))
        .collect();
    return (w_arr, d_arr, b_arr, s_arr);
}


pub fn compute_large_lut_arrays(width: usize, parameter_set: &TfheParam) -> (Vec<u32>, Vec<u64>, Vec<u64>, Vec<u64>) {
    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    let modulus = parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64;
    //let w = (parameter_set.message_modulus as f64).log2().floor() as u32;
    let w = (modulus as f64).log2().floor() as u32;
    //let w1 = (blog(modulus-1)+1) as u32;
    //if w != w1 {
    //    println!("Warning: modulus {} log2 floor {} != blog(modulus-1)+1 {}", modulus, w, w1);
    //}
    let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);

    //let l = 0usize;
    while sum <= limit && sum < width as u64 {
        //let ilog1 = (i as f64).log2().floor() as u32;
        //let ilog2 = (blog(i+1)) as u32;
        //if ilog1 != ilog2 {
        //    println!("Warning: i {} log2 floor {} != blog(i) {}", i, ilog1, ilog2);            
        //}
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        //let wi = if i == 0 { w } else { w - 1 - blog(i+1) as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }
    if sum < width as u64 {
        panic!("Cannot decompose width {} with limit {}", width, limit);
    }
    let l = i;
    print!("Decomposed width {} into {} levels with w_arr {:?}\n", width, l, w_arr);

    let mut d_arr: Vec<u64> = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }

    // b_arr = B / 2^{D_i}
    let b_arr: Vec<u64> = d_arr
        .iter()
        .map(|&di| (parameter_set.polynomial_size.0 / modulus as usize) as u64 / (1u64 << di))
        .collect();

    // s_arr = (i+1) * 2^{D_{i-1}}  （i = 1,...,L-1）
    let s_arr: Vec<u64> = (1..w_arr.len())
        .map(|i| (i as u64 + 1) * (1u64 << d_arr[i - 1]))
        .collect();
    return (w_arr, d_arr, b_arr, s_arr);
}

//pub fn make_table(f_table: Vec<usize>, public_params: &PublicParams) -> GlweCiphertext<Vec<u64>> {
pub fn make_large_lut(f_table: &Vec<usize>, public_params: &LargeLUTparams) -> GlweCiphertext<Vec<u64>> {
TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();

    let mut table_plaintext_list = PlaintextList::new(0, PlaintextCount(parameter_set.polynomial_size.0));
    let modulus = parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64;
    //for i in 0..f_table.len() {
    let table_len = f_table.len();
    let len = parameter_set.polynomial_size.0 / public_params.b_arr[0] as usize;
    for i in 0..len {
        let index = i as usize * public_params.b_arr[0] as usize;
        for element in table_plaintext_list.as_mut()[index..index+public_params.b_arr[0] as usize].iter_mut() {
            //*element = f_table[i % table_len] as u64%modulus as u64 * parameter_set.delta;
            *element = f_table[i as usize] as u64%modulus as u64 * parameter_set.delta;
        }
    }
    let ctx_table: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
        parameter_set.glwe_dimension.to_glwe_size(), &table_plaintext_list, 
        parameter_set.ciphertext_modulus
    );
    return ctx_table;
})
}

use crate::algorithms::blog;
pub fn make_large_lut_w(f_table: &Vec<usize>, width: usize, public_params: &LargeLUTparams) -> Vec<GlweCiphertext<Vec<u64>>> {
TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();
    let modulus = parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64;
    let w = blog(modulus -1) as usize + 1;
    let mut table_arr: Vec<GlweCiphertext<Vec<u64>>> = Vec::new();
    for l in 0..(width + w -1)/w {
        let mut table_plaintext_list = PlaintextList::new(0, PlaintextCount(parameter_set.polynomial_size.0));
        for i in 0..f_table.len() {
            let index = i as usize * public_params.b_arr[0] as usize;
            let value = (f_table[i as usize] >> (l*w)) & ((1u64 << w) - 1) as usize;
            for element in table_plaintext_list.as_mut()[index..index+public_params.b_arr[0] as usize].iter_mut() {
                *element = value as u64 * parameter_set.delta;
            }
        }
        let ctx_table: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
            parameter_set.glwe_dimension.to_glwe_size(), &table_plaintext_list, 
            parameter_set.ciphertext_modulus
        );
        table_arr.push(ctx_table);
    }
    return table_arr;
})
}

pub fn make_onehot_lut(public_params: &LargeLUTparams) -> GlweCiphertext<Vec<u64>> {
TFHE_PARAMS.with(|param| {
    let parameter_set = param.borrow();

    let l = public_params.w_arr.len();
    let k = public_params.b_arr[l -1] as usize;

    let mut table_plaintext_list = PlaintextList::new(0, PlaintextCount(parameter_set.polynomial_size.0));
    for i in 0..k {
        table_plaintext_list.as_mut()[i] = 1 as u64 * parameter_set.delta;
    }
    let ctx_table: GlweCiphertext<Vec<u64>> = allocate_and_trivially_encrypt_new_glwe_ciphertext(
        parameter_set.glwe_dimension.to_glwe_size(), &table_plaintext_list, 
        parameter_set.ciphertext_modulus
    );
    return ctx_table;
})
}

use crate::algorithms::glwe_new;
use tfhe::core_crypto::algorithms::polynomial_algorithms::polynomial_wrapping_monic_monomial_mul_assign;
use tfhe::core_crypto::algorithms::slice_algorithms::slice_wrapping_add_assign;
pub fn make_onehot_lut2(public_params: &LargeLUTparams, b: &LweCiphertextOwned<u64>) -> GlweCiphertextOwned<u64> {
    TFHE_PARAMS.with(|params| {
        let tfhe_params = params.borrow();

        let l = public_params.w_arr.len();
        let k = public_params.b_arr[l -1] as usize;

        let mut output_glwe_ciphertext = glwe_new();
        let lwe_pksk: &LwePackingKeyswitchKeyOwned<u64> = &tfhe_params.pksk;

        //let table_len = table.len();
        let table_len = 1;
        //let box_size = tfhe_params.polynomial_size.0 / (tfhe_params.message_modulus * tfhe_params.carry_modulus) as usize;
        let box_size = k;


        output_glwe_ciphertext.as_mut().fill(0);
        let mut buffer = GlweCiphertext::new(
            0u64,
            output_glwe_ciphertext.glwe_size(),
            output_glwe_ciphertext.polynomial_size(),
            output_glwe_ciphertext.ciphertext_modulus(),
        );

        for i in 0..table_len {
            keyswitch_lwe_ciphertext_into_glwe_ciphertext(&lwe_pksk, &b, &mut buffer);
            for degree in 0..box_size {
                let mut buffer_iter = buffer.clone();
                buffer_iter
                    .as_mut_polynomial_list()
                    .iter_mut()
                    .for_each(|mut poly| {
                        polynomial_wrapping_monic_monomial_mul_assign(&mut poly, MonomialDegree(degree + i*box_size))
                    });
                slice_wrapping_add_assign(output_glwe_ciphertext.as_mut(), buffer_iter.as_ref());
            }
            
        }

        output_glwe_ciphertext
    })
}


pub fn decompose_message_and_encrypt(message: u64, public_params: &LargeLUTparams) -> Vec<LweCiphertextOwned<u64>> {
    let mut message_decomped: Vec<LweCiphertextOwned<u64>> = Vec::new();
    //let l = public_params.l;
    //let l = public_params.w_arr.len();
    let l = public_params.get_l();
    //let mut bit_shift = public_params.w_arr.iter().sum::<u32>() as usize;
    let mut bit_shift = public_params.get_width();
;
    for i in 0..l {
        bit_shift -= public_params.w_arr[i] as usize;
        //print!("message {} bit_shift {}\n", message, bit_shift);
        let message_i = (message >> bit_shift) & ((1u64 << public_params.w_arr[i]) - 1);
        //print!("message_{}: {}\n", i, message_i);
        message_decomped.push(lwe_encrypt(message_i as u32));
    }
    return message_decomped;
}

use crate::arith::lwe_add;
pub fn compose_bits_for_large_lut(x: &Vec<LweCiphertextOwned<u64>>, large_lut: &LargeLUTparams) -> Vec<LweCiphertextOwned<u64>> {
    let l = large_lut.w_arr.len();
    let w_arr = &large_lut.w_arr;
    //let width = w_arr.iter().sum::<u32>() as usize;
    let width = large_lut.get_width();
    let xlen = x.len();

    let mut result: Vec<LweCiphertextOwned<u64>> = Vec::new();

    let mut pos = width-1;
    for i in 0..l {
        let mut y = trivial_const(0);
        for _ in 0..w_arr[i] as usize {
            if pos >= xlen {
                pos -= 1;
                continue;
            }
            y = lwe_add(&y, &y);
            y = lwe_add(&y, &x[pos]);
            pos -= 1;
        }
        result.push(y);
    }
    return result;
}

//    pub pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>>,
//    pub pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>>,

use std::cell::RefCell;
thread_local!(
    pub static PKSK_RING_KEY4: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(4);
        RefCell::new(pksk_ring2ring_arr)
    };
);
thread_local!(
    pub static PKSK_RING_KEY3: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(3);
        RefCell::new(pksk_ring2ring_arr)
    };
);
thread_local!(
    pub static PKSK_RING_KEY2: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(2);
        RefCell::new(pksk_ring2ring_arr)
    };
);
thread_local!(
    pub static PKSK_RING_KEY1: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(1);
        RefCell::new(pksk_ring2ring_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY4: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(4);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY3: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(3);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY2: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(2);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY1: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(1);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);


#[derive(Clone)]
pub struct LargeLUT {
    pub table: Vec<GlweCiphertext<Vec<u64>>>,
    pub i_width: usize,
    pub v_width: usize,
    pub parameter_set: LargeLUTparams,
}

impl LargeLUT {
    pub fn new(f_table: &Vec<usize>, v_width: usize) -> Self {
        let i_width = blog(f_table.len() as u64 -1) as usize +1;
        let parameter_set = LargeLUTparams::new(
        //    parameter_set.parameter_set,
            i_width,
            ThreadCount(8),
        );
        let large_lut_w = make_large_lut_w(f_table, v_width, &parameter_set);
        LargeLUT {
            table: large_lut_w,
            i_width: f_table.len(),
            v_width: v_width,
            parameter_set: parameter_set,
        }
    }
    pub fn calibrate(&self, message: &LweInt) -> LwePacked {
        let message_calibrated_keyswitched = LweInt_large_lut_decomp_calibrate(message, &self.parameter_set);
        return message_calibrated_keyswitched;
    }

    pub fn lookup(&self, message_calibrated_keyswitched: &LwePacked) -> LwePacked {
        let z = LwePacked_large_lut_lookup(&self.parameter_set, &self.table, &message_calibrated_keyswitched, self.v_width);
        return z;
    }
}


pub fn make_onehot_table(parameter_set: &LargeLUTparams) -> GlweCiphertext<Vec<u64>> {
    let l = parameter_set.w_arr.len();
    return make_large_lut(&vec![1; parameter_set.b_arr[l-1] as usize], &parameter_set);
    //return make_table2(&vec![1usize], l-1, &parameter_set);
}

pub fn make_onehot_table2(parameter_set: &LargeLUTparams) -> LargeLUT {
    let l = parameter_set.w_arr.len();
    let width = parameter_set.w_arr.iter().sum::<u32>() as usize;
    let table = make_large_lut(&vec![1; parameter_set.b_arr[l-1] as usize], &parameter_set);
    let lut = LargeLUT {
        table: vec![table],
        i_width: width,
        v_width: 1,
        parameter_set: parameter_set.clone(),
    };
    return lut;
}
