use tfhe::core_crypto::prelude::*;
//use tfhe::core_crypto::commons::math::decomposition::{DecompositionLevel, DecompositionTerm};
use tfhe::core_crypto::commons::math::decomposition::{DecompositionLevel};
use tfhe::core_crypto::commons::math::random::{Distribution, Uniform};

use crate::algorithms::{TFHE_PARAMS, TfheParam};
use crate::largelut::ioutils::*;
use crate::largelut::basic::ENCRYPTION_GENERATOR;
//use crate::print;
use std::path::Path;
use crate::largelut::basic::MyDecompositionTerm as DecompositionTerm;
//use crate::largelut::calibration_method::PublicParams;

use crate::algorithms::blog;

fn negacyclic_index_and_sign(i: usize, k: i64, n: usize) -> (usize, i32) {
    let t = i as i64 + k;
    let q = t.div_euclid(n as i64);           // wrap 回数（負でもOK）
    let r = t.rem_euclid(n as i64) as usize;  // 0..N-1
    let sign = if (q & 1) == 0 { 1 } else { -1 };
    (r, sign)
}

pub fn allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    decomp_base_log: DecompositionBaseLog,
    decomp_level_count: DecompositionLevelCount,
    noise_distribution: NoiseDistribution,
    ciphertext_modulus: CiphertextModulus<Scalar>,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    s_arr: &Vec<u64>,
    i: usize,
) -> LwePackingKeyswitchKeyOwned<Scalar>
where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    let mut new_lwe_packing_keyswitch_key = LwePackingKeyswitchKeyOwned::new(
        Scalar::ZERO,
        decomp_base_log,
        decomp_level_count,
        input_lwe_sk.lwe_dimension(),
        output_glwe_sk.glwe_dimension(),
        output_glwe_sk.polynomial_size(),
        ciphertext_modulus,
    );

    generate_lwe_packing_keyswitch_key_ring2ring(
        input_lwe_sk,
        output_glwe_sk,
        &mut new_lwe_packing_keyswitch_key,
        noise_distribution,
        generator,
        b_arr,
        s_arr,
        i
    );

    new_lwe_packing_keyswitch_key
}


pub fn generate_lwe_packing_keyswitch_key_ring2ring<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    KSKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    lwe_packing_keyswitch_key: &mut LwePackingKeyswitchKey<KSKeyCont>,
    noise_distribution: NoiseDistribution,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    s_arr: &Vec<u64>,
    i: usize,
) where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    KSKeyCont: ContainerMut<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    assert!(
        lwe_packing_keyswitch_key.input_key_lwe_dimension() == input_lwe_sk.lwe_dimension(),
        "The destination LwePackingKeyswitchKey input LweDimension is not equal \
    to the input LweSecretKey LweDimension. Destination: {:?}, input: {:?}",
        lwe_packing_keyswitch_key.input_key_lwe_dimension(),
        input_lwe_sk.lwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_glwe_dimension() == output_glwe_sk.glwe_dimension(),
        "The destination LwePackingKeyswitchKey output LweDimension is not equal \
    to the output GlweSecretKey GlweDimension. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_glwe_dimension(),
        output_glwe_sk.glwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_polynomial_size() == output_glwe_sk.polynomial_size(),
        "The destination LwePackingKeyswitchKey output PolynomialSize is not equal \
        to the output GlweSecretKey PolynomialSize. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_polynomial_size(),
        output_glwe_sk.polynomial_size()
    );

    let decomp_base_log = lwe_packing_keyswitch_key.decomposition_base_log();
    let decomp_level_count = lwe_packing_keyswitch_key.decomposition_level_count();
    let polynomial_size = lwe_packing_keyswitch_key.output_polynomial_size();
    let ciphertext_modulus = lwe_packing_keyswitch_key.ciphertext_modulus();
    assert!(ciphertext_modulus.is_compatible_with_native_modulus());

    // The plaintexts used to encrypt a key element will be stored in this buffer
    let mut decomposition_plaintexts_buffer = PlaintextListOwned::new(
        Scalar::ZERO,
        PlaintextCount(decomp_level_count.0 * polynomial_size.0),
    );

    // 新実装
    //print!("b_arr={}, s_arr={}\n", b_arr.len(), s_arr.len());
    let degree_d: usize = b_arr[i] as usize * s_arr[i-1] as usize;

    for (element_index, mut packing_keyswitch_key_block) in lwe_packing_keyswitch_key.iter_mut().enumerate() {
        for (level, mut messages) in (1..=decomp_level_count.0)
            .map(DecompositionLevel)
            .rev()
            .zip(decomposition_plaintexts_buffer.chunks_exact_mut(polynomial_size.0))
        {
            // まず全係数ゼロ
            for c in messages.iter_mut() {
                *c.0 = Scalar::ZERO;
            }
            for j in 0..degree_d {
                let p_j =  (j as u64) / b_arr[i];
                // t_jは正になるはず
                // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2  + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
                let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2;
                let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
                let sk_elem = input_lwe_sk.as_ref()[idx];
                // if i == l-1 {
                //     // if element_index == 0{
                //         print!("j={}, p_j={}, t_j={}, idx={}, sign={}\n", j, p_j, t_j, idx, sign);
                //     // }
                // }

                //let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                    .to_recomposition_summand()
                    .wrapping_div(
                        ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                    );


                // nega-cyclic の符号（奇数回 wrap → 負）
                if sign < 0 {
                    val = val.wrapping_neg();
                }
                *messages.get_mut(j).0 = val; // X^j の係数へ
            }
        }

        // 暗号化はそのまま
        encrypt_glwe_ciphertext_list(
            output_glwe_sk,
            &mut packing_keyswitch_key_block,
            &decomposition_plaintexts_buffer,
            noise_distribution,
            generator,
        );
    }


}



pub fn allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring_onehot_encode<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    decomp_base_log: DecompositionBaseLog,
    decomp_level_count: DecompositionLevelCount,
    noise_distribution: NoiseDistribution,
    ciphertext_modulus: CiphertextModulus<Scalar>,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    //s_arr: &Vec<u64>,
    d_arr: &Vec<u64>,
    i: usize,
) -> LwePackingKeyswitchKeyOwned<Scalar>
where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    let mut new_lwe_packing_keyswitch_key = LwePackingKeyswitchKeyOwned::new(
        Scalar::ZERO,
        decomp_base_log,
        decomp_level_count,
        input_lwe_sk.lwe_dimension(),
        output_glwe_sk.glwe_dimension(),
        output_glwe_sk.polynomial_size(),
        ciphertext_modulus,
    );

    generate_lwe_packing_keyswitch_key_ring2ring_onehot_encode(
        input_lwe_sk,
        output_glwe_sk,
        &mut new_lwe_packing_keyswitch_key,
        noise_distribution,
        generator,
        b_arr,
        //s_arr, // 正しい?
        d_arr,
        i
    );

    new_lwe_packing_keyswitch_key
}


pub fn generate_lwe_packing_keyswitch_key_ring2ring_onehot_encode<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    KSKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    lwe_packing_keyswitch_key: &mut LwePackingKeyswitchKey<KSKeyCont>,
    noise_distribution: NoiseDistribution,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    d_arr: &Vec<u64>,
    i: usize,
) where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    KSKeyCont: ContainerMut<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    assert!(
        lwe_packing_keyswitch_key.input_key_lwe_dimension() == input_lwe_sk.lwe_dimension(),
        "The destination LwePackingKeyswitchKey input LweDimension is not equal \
    to the input LweSecretKey LweDimension. Destination: {:?}, input: {:?}",
        lwe_packing_keyswitch_key.input_key_lwe_dimension(),
        input_lwe_sk.lwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_glwe_dimension() == output_glwe_sk.glwe_dimension(),
        "The destination LwePackingKeyswitchKey output LweDimension is not equal \
    to the output GlweSecretKey GlweDimension. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_glwe_dimension(),
        output_glwe_sk.glwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_polynomial_size() == output_glwe_sk.polynomial_size(),
        "The destination LwePackingKeyswitchKey output PolynomialSize is not equal \
        to the output GlweSecretKey PolynomialSize. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_polynomial_size(),
        output_glwe_sk.polynomial_size()
    );

    let decomp_base_log = lwe_packing_keyswitch_key.decomposition_base_log();
    let decomp_level_count = lwe_packing_keyswitch_key.decomposition_level_count();
    let polynomial_size = lwe_packing_keyswitch_key.output_polynomial_size();
    let ciphertext_modulus = lwe_packing_keyswitch_key.ciphertext_modulus();
    assert!(ciphertext_modulus.is_compatible_with_native_modulus());

    // The plaintexts used to encrypt a key element will be stored in this buffer
    let mut decomposition_plaintexts_buffer = PlaintextListOwned::new(
        Scalar::ZERO,
        PlaintextCount(decomp_level_count.0 * polynomial_size.0),
    );

    // 新実装


    for (element_index, mut packing_keyswitch_key_block) in lwe_packing_keyswitch_key.iter_mut().enumerate() {
    for (level, mut messages) in (1..=decomp_level_count.0)
        .map(DecompositionLevel)
        .rev()
        .zip(decomposition_plaintexts_buffer.chunks_exact_mut(polynomial_size.0))
    {
        // まず全係数ゼロ
        for c in messages.iter_mut() {
            *c.0 = Scalar::ZERO;
        }
        // for j in 0..degree_d {
        //     let p_j =  (j as u64) / b_arr[i];
        //     // t_jは正になるはず
        //     // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2  + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
        //     let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2;
        //     let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
        //     let sk_elem = input_lwe_sk.as_ref()[idx];

        //     let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
        //         .to_recomposition_summand()
        //         .wrapping_div(
        //             ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
        //         );


        //     // nega-cyclic の符号（奇数回 wrap → 負）
        //     if sign < 0 {
        //         val = val.wrapping_neg();
        //     }
        //     *messages.get_mut(j).0 = val; // X^j の係数へ
        // }
        //for j in 0..((i+3)*2_u32.pow(d_arr[i] as u32 - 1) as usize) {
        for j in 0..((i+3)*(1<<(d_arr[i] as u32 - 1)) as usize) {
            //print!("i={}, d_arr[i]={} j={}\n", i, d_arr[i], j);
            let t_j = j * b_arr[i+1] as usize +(b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1;
            for k in 0..b_arr[i] as usize {
                let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
                let sk_elem = input_lwe_sk.as_ref()[idx];


                let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                    .to_recomposition_summand()
                    .wrapping_div(
                        ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                );


                // nega-cyclic の符号（奇数回 wrap → 負）
                if sign < 0 {
                    val = val.wrapping_neg();
                }
                *messages.get_mut(j*b_arr[i] as usize + k).0 = val; // X^j の係数へ
            }
        }

        for j in 0..((i+1)*2_u32.pow(d_arr[i] as u32 - 1) as usize) {
            let t_j = polynomial_size.0 + (j - (i+1)*2_u32.pow(d_arr[i] as u32 - 1) as usize) * b_arr[i+1] as usize +(b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1;
            for k in 0..b_arr[i] as usize {
                let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
                let sk_elem = input_lwe_sk.as_ref()[idx];


                let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                    .to_recomposition_summand()
                    .wrapping_div(
                        ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                );


                // nega-cyclic の符号（奇数回 wrap → 負）
                if sign < 0 {
                    val = val.wrapping_neg();
                }
                *messages.get_mut(polynomial_size.0 + (j - (i+1)*2_u32.pow(d_arr[i] as u32 - 1) as usize) * b_arr[i] as usize + k).0 = val; // X^j の係数へ
            }
        }
    }

    // 暗号化はそのまま
    encrypt_glwe_ciphertext_list(
        output_glwe_sk,
        &mut packing_keyswitch_key_block,
        &decomposition_plaintexts_buffer,
        noise_distribution,
        generator,
    );
}


}


pub fn allocate_and_generate_new_lwe_packing_keyswitch_key_prefixsum<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    decomp_base_log: DecompositionBaseLog,
    decomp_level_count: DecompositionLevelCount,
    noise_distribution: NoiseDistribution,
    ciphertext_modulus: CiphertextModulus<Scalar>,
    generator: &mut EncryptionRandomGenerator<Gen>,
    ohe_size: usize,
) -> LwePackingKeyswitchKeyOwned<Scalar>
where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    let mut new_lwe_packing_keyswitch_key = LwePackingKeyswitchKeyOwned::new(
        Scalar::ZERO,
        decomp_base_log,
        decomp_level_count,
        input_lwe_sk.lwe_dimension(),
        output_glwe_sk.glwe_dimension(),
        output_glwe_sk.polynomial_size(),
        ciphertext_modulus,
    );

    generate_lwe_packing_keyswitch_key_prefixsum(
        input_lwe_sk,
        output_glwe_sk,
        &mut new_lwe_packing_keyswitch_key,
        noise_distribution,
        generator,
        ohe_size,
    );

    new_lwe_packing_keyswitch_key
}


pub fn generate_lwe_packing_keyswitch_key_prefixsum<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    KSKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    lwe_packing_keyswitch_key: &mut LwePackingKeyswitchKey<KSKeyCont>,
    noise_distribution: NoiseDistribution,
    generator: &mut EncryptionRandomGenerator<Gen>,
    ohe_size: usize,
) where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    KSKeyCont: ContainerMut<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    assert!(
        lwe_packing_keyswitch_key.input_key_lwe_dimension() == input_lwe_sk.lwe_dimension(),
        "The destination LwePackingKeyswitchKey input LweDimension is not equal \
    to the input LweSecretKey LweDimension. Destination: {:?}, input: {:?}",
        lwe_packing_keyswitch_key.input_key_lwe_dimension(),
        input_lwe_sk.lwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_glwe_dimension() == output_glwe_sk.glwe_dimension(),
        "The destination LwePackingKeyswitchKey output LweDimension is not equal \
    to the output GlweSecretKey GlweDimension. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_glwe_dimension(),
        output_glwe_sk.glwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_polynomial_size() == output_glwe_sk.polynomial_size(),
        "The destination LwePackingKeyswitchKey output PolynomialSize is not equal \
        to the output GlweSecretKey PolynomialSize. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_polynomial_size(),
        output_glwe_sk.polynomial_size()
    );

    let decomp_base_log = lwe_packing_keyswitch_key.decomposition_base_log();
    let decomp_level_count = lwe_packing_keyswitch_key.decomposition_level_count();
    let polynomial_size = lwe_packing_keyswitch_key.output_polynomial_size();
    let ciphertext_modulus = lwe_packing_keyswitch_key.ciphertext_modulus();
    assert!(ciphertext_modulus.is_compatible_with_native_modulus());

    // The plaintexts used to encrypt a key element will be stored in this buffer
    let mut decomposition_plaintexts_buffer = PlaintextListOwned::new(
        Scalar::ZERO,
        PlaintextCount(decomp_level_count.0 * polynomial_size.0),
    );

    // 新実装
    let box_size = polynomial_size.0 / ohe_size;


    for (element_index, mut packing_keyswitch_key_block) in lwe_packing_keyswitch_key.iter_mut().enumerate() {
    for (level, mut messages) in (1..=decomp_level_count.0)
        .map(DecompositionLevel)
        .rev()
        .zip(decomposition_plaintexts_buffer.chunks_exact_mut(polynomial_size.0))
    {
        // まず全係数ゼロ
        for c in messages.iter_mut() {
            *c.0 = Scalar::ZERO;
        }
        // for j in 0..polynomial_size.0 {
        //     let p_j =  (j as u64) / b_arr[l];
        //     let t_j: u64 = ((2 * p_j + 1) * b_arr[l-1]) / 2;
        //     let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
        //     let sk_elem = input_lwe_sk.as_ref()[idx];


        //     let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
        //         .to_recomposition_summand()
        //         .wrapping_div(
        //             ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
        //         );


        //     // nega-cyclic の符号（奇数回 wrap → 負）
        //     if sign < 0 {
        //         val = val.wrapping_neg();
        //     }
        //     *messages.get_mut(j).0 = val; // X^j の係数へ
        // }
        for j in 0..ohe_size {
            let extracted_degree_j = (box_size as f64 / 2 as f64).ceil() as usize + j*box_size - 1;
            for k in j+1..ohe_size {
                for l in 0..box_size {
                    let (idx, sign) = negacyclic_index_and_sign(element_index, extracted_degree_j as i64, input_lwe_sk.lwe_dimension().0);
                    let sk_elem = input_lwe_sk.as_ref()[idx];


                    let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                        .to_recomposition_summand()
                        .wrapping_div(
                            ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                        );


                    // nega-cyclic の符号（奇数回 wrap → 負）
                    if sign < 0 {
                        val = val.wrapping_neg();
                    }
                    let tmp = messages.get_mut(k*box_size+l).0.clone();
                    *messages.get_mut(k*box_size+l).0 = tmp + val; // X^j の係数へ
                }
            }
        }
    }

    // 暗号化はそのまま
    encrypt_glwe_ciphertext_list(
        output_glwe_sk,
        &mut packing_keyswitch_key_block,
        &decomposition_plaintexts_buffer,
        noise_distribution,
        generator,
    );
}


}

use crate::largelut::calibration_method::compute_arrays;
pub fn generate_ring2ring_keys(parameter_set: &TfheParam, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;

    if l == 1 {
        let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, 1);
        let path = Path::new(&s);
        let pksk_ring2ring_arr =
        if path.is_file() == false {
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new();
            save_bin(&s, &pksk_ring2ring_arr).unwrap();

            pksk_ring2ring_arr
        } else {
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();

            pksk_ring2ring_arr            
        };
        return pksk_ring2ring_arr
    }

    let w = (blog(modulus-1)+1) as u32;
    //let delta = (1_u64 << 63) / (parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64);
    //let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);
    let limit = ((1u64 << w) - 1).min((blog(parameter_set.polynomial_size.0 as u64 -1)+1) as u64);

    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    while sum <= limit && i < l as u64 {
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }


    let mut d_arr = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }


    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    // b_arr = B / 2^{D_i}
    let b_arr: Vec<u64> = d_arr
        .iter()
        .map(|&di| (parameter_set.polynomial_size.0 / modulus as usize) as u64 / (1u64 << di))
        .collect();

    // s_arr = (i+1) * 2^{D_{i-1}}  （i = 1,...,L-1）
    let s_arr: Vec<u64> = (1..w_arr.len())
        .map(|i| (i as u64 + 1) * (1u64 << d_arr[i - 1]))
        .collect();

    ENCRYPTION_GENERATOR.with(|g| {
        let mut encryption_generator = g.borrow_mut();
        let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        let x =
        if path.is_file() == false {
            print!("Generating ring2ring keys for {}...\n", l);
            //print!("b_arr={:?}, s_arr={:?}\n", b_arr, s_arr);
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = (1..l).map(|i| {
                allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring(
                    &parameter_set.big_lwe_sk,
                    &parameter_set.glwe_sk,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    parameter_set.glwe_noise_distribution,
                    parameter_set.ciphertext_modulus,
                    &mut encryption_generator,
                    &b_arr,
                    &s_arr,
                    i,
                )
            }).collect();

            let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
            if save_bin(&s,&pksk_ring2ring_arr,).is_err() {
                panic!("Failed to save ring2ring keys");
            }

            pksk_ring2ring_arr
        } else {
            print!("Loading ring2ring keys for {} {}...\n", modulus, l);
            let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();

            pksk_ring2ring_arr
        };
        x
    })
}

pub fn generate_ring2ring_onehot_encode_keys(parameter_set: &TfheParam, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    if l == 1 {
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, 1);
        let path = Path::new(&s);
        let pksk_ring2ring_onehot_encode_arr =
        if path.is_file() == false {
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new();
            save_bin(&s,&pksk_ring2ring_onehot_encode_arr).unwrap();
            pksk_ring2ring_onehot_encode_arr
        } else {
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();
            pksk_ring2ring_onehot_encode_arr            
        };
        return pksk_ring2ring_onehot_encode_arr
    }

    let w = (blog(modulus-1)+1) as u32;
    //let delta = (1_u64 << 63) / (parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64);
    //let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);
    let limit = ((1u64 << w) - 1).min((blog(parameter_set.polynomial_size.0 as u64 -1)+1) as u64);

    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    while sum <= limit && i < l as u64 {
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }


    let mut d_arr = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }


    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    // b_arr = B / 2^{D_i}
    let b_arr: Vec<u64> = d_arr
        .iter()
        .map(|&di| (parameter_set.polynomial_size.0 / modulus as usize) as u64 / (1u64 << di))
        .collect();

    // s_arr = (i+1) * 2^{D_{i-1}}  （i = 1,...,L-1）
    let s_arr: Vec<u64> = (1..w_arr.len())
        .map(|i| (i as u64 + 1) * (1u64 << d_arr[i - 1]))
        .collect();

    ENCRYPTION_GENERATOR.with(|g| {
        let mut encryption_generator = g.borrow_mut();
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        let x =
        if path.is_file() == false {
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = (0..l-1).map(|i| {
                allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring_onehot_encode(
                    &parameter_set.big_lwe_sk,
                    &parameter_set.glwe_sk,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    parameter_set.glwe_noise_distribution,
                    parameter_set.ciphertext_modulus,
                    &mut encryption_generator,
                    &b_arr,
                    &d_arr,
                    i,
                )
            }).collect();

            save_bin(&s,&pksk_ring2ring_onehot_encode_arr,).unwrap();
            pksk_ring2ring_onehot_encode_arr
        } else {
            print!("Loading ring2ring keys for {} {}...\n", modulus, l);
            let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l);
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();
            pksk_ring2ring_onehot_encode_arr
        };
        x
    })
}

pub fn generate_ring2ring_keys2(l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    TFHE_PARAMS.with(|params| {
        let parameter_set = &params.borrow();
        generate_ring2ring_keys(parameter_set, l)
    })
}

pub fn generate_ring2ring_prefixsum_keys(/*parameter_set: &TfheParam,*/ l: usize) -> LwePackingKeyswitchKeyOwned<u64> {
    print!("ring2ring prefixsum key for {}...\n", l);
TFHE_PARAMS.with(|params| {
    let parameter_set = &params.borrow();
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    let w = (parameter_set.message_modulus as f64).log2().floor() as u32;
    //let w = (blog(modulus-1)+1) as u32;
    //let delta = (1_u64 << 63) / (parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64);
    let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);

    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    while sum <= limit && i < l as u64 {
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }


    let mut d_arr = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }

    let s = format!("keys/pksk_prefixsum_{}_{}.bin", modulus, l);
    let path = Path::new(&s);
    let pksk_prefixsum = if path.is_file() == false {
        ENCRYPTION_GENERATOR.with(|g| {
            let mut encryption_generator = g.borrow_mut();
            let pksk_prefixsum: LwePackingKeyswitchKeyOwned<u64> =  allocate_and_generate_new_lwe_packing_keyswitch_key_prefixsum(
                &parameter_set.big_lwe_sk,
                &parameter_set.glwe_sk,
                parameter_set.ks_base_log, // default is 3
                parameter_set.ks_level,
                // DecompositionLevelCount(9), // default is 5
                parameter_set.glwe_noise_distribution,
                parameter_set.ciphertext_modulus,
                &mut encryption_generator,
                2_u32.pow(w_arr.iter().sum::<u32>()) as usize,
            );
            save_bin(&s, &pksk_prefixsum).unwrap();
            pksk_prefixsum
        })
    } else {
        load_bin(&s).unwrap()
    };
    pksk_prefixsum
})
}

use crate::{LargeLUTparams, print};
pub fn generate_ring2ring_prefixsum_keys2(/*public_params: &LargeLUTparams,*/ l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    print!("generating ring2ring prefixsum key for {}...\n", l);
TFHE_PARAMS.with(|params| {
    let parameter_set = &params.borrow();
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;

    let (w_arr, d_arr, b_arr, s_arr) = compute_arrays(l, &parameter_set);

    ENCRYPTION_GENERATOR.with(|g| {
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l); // !!!
        let path = Path::new(&s);
        if path.is_file() == false {
            print!("Generating ring2ring onehot encode keys for {}...\n", l);
            let mut encryption_generator = g.borrow_mut();
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = (0..l-1).map(|i| {
                allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring_onehot_encode(
                    &parameter_set.big_lwe_sk,
                    &parameter_set.glwe_sk,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    parameter_set.glwe_noise_distribution,
                    parameter_set.ciphertext_modulus,
                    &mut encryption_generator,
                    &b_arr,
                    &d_arr,
                    i,
                )
            }).collect();
            save_bin(&s,&pksk_ring2ring_onehot_encode_arr,).unwrap();
            pksk_ring2ring_onehot_encode_arr
        } else {
            print!("loading ring2ring onehot encode keys for {}...\n", l);
            let pksk_ring2ring_onehot_encode_arr = load_bin(&s).unwrap();
            pksk_ring2ring_onehot_encode_arr
        }
    })
})
}

pub fn is_ring2ring_keys_available(l: usize) -> bool {
    TFHE_PARAMS.with(|params| {
        let parameter_set = &params.borrow();
        let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
        let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        if path.is_file() == true {
            true
        } else {
            false
        }
    })
}

pub fn is_onehot_encode_keys_available(l: usize) -> bool {
    TFHE_PARAMS.with(|params| {
        let parameter_set = &params.borrow();
        let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        if path.is_file() == true {
            true
        } else {
            false
        }
    })
}
