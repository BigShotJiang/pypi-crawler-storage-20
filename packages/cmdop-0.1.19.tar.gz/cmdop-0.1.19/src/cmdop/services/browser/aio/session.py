"""Asynchronous browser session."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import asyncio

from cmdop.services.browser.base.session import BaseSession
from cmdop.services.browser.models import (
    BrowserCookie,
    BrowserState,
    PageInfo,
    ScrollInfo,
    ScrollResult,
)
from cmdop.services.browser.js import parse_json_result
from cmdop.services.browser.parsing import parse_html as _parse_html, SoupWrapper

if TYPE_CHECKING:
    from cmdop.services.browser.aio.service import AsyncBrowserService


class AsyncBrowserSession(BaseSession):
    """
    Asynchronous browser session with fluent API.

    Usage:
        async with client.browser.create_session() as session:
            await session.navigate("https://example.com")
            await session.click("button.submit")
            data = await session.fetch_all(urls)  # credentials + accept header by default
    """

    _service: AsyncBrowserService

    def _call_service(self, method: str, *args: Any, **kwargs: Any) -> Any:
        """Not used in async - methods call service directly with await."""
        raise NotImplementedError("Use async methods directly")

    # === Navigation & Interaction ===

    async def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        """Navigate to URL. Returns final URL."""
        return await self._service.navigate(self._session_id, url, timeout_ms)

    async def click(
        self,
        selector: str,
        timeout_ms: int = 5000,
        move_cursor: bool = False,
    ) -> None:
        """
        Click element by CSS selector.

        Args:
            selector: CSS selector
            timeout_ms: Timeout in milliseconds
            move_cursor: If True, move cursor to element before clicking (human-like)
        """
        if move_cursor:
            await self.hover(selector, timeout_ms)
        await self._service.click(self._session_id, selector, timeout_ms)

    async def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """Type text into element."""
        await self._service.type(
            self._session_id, selector, text, human_like, clear_first
        )

    async def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        """Wait for element to appear."""
        return await self._service.wait_for(self._session_id, selector, timeout_ms)

    # === Extraction ===

    async def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """Extract text/attributes from elements."""
        return await self._service.extract(self._session_id, selector, attr, limit)

    async def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """Extract data using regex pattern."""
        return await self._service.extract_regex(
            self._session_id, pattern, from_html, limit
        )

    async def get_html(self, selector: str | None = None) -> str:
        """Get page HTML."""
        return await self._service.get_html(self._session_id, selector)

    async def get_text(self, selector: str | None = None) -> str:
        """Get page text content."""
        return await self._service.get_text(self._session_id, selector)

    # === JavaScript Execution ===

    async def execute_script(self, script: str) -> str:
        """Execute JavaScript (raw, no wrapper)."""
        return await self._service.execute_script(self._session_id, script)

    async def execute_js(self, code: str, raw: bool = False) -> dict | list | str | None:
        """
        Execute async JavaScript with auto-wrap.

        Code is wrapped in async IIFE with try/catch and JSON serialization.

        Args:
            code: JS code to execute (can use await)
            raw: If True, return raw JSON string. Default False (parse to dict/list).
        """
        js = self._build_execute_js(code)
        result = await self.execute_script(js)
        return self._parse_execute_js(result, raw)

    async def fetch_json(self, url: str) -> dict | list | None:
        """Fetch JSON from URL using JS fetch()."""
        js = self._build_fetch_json(url)
        result = await self.execute_script(js)
        return parse_json_result(result)

    async def fetch_all(
        self,
        urls: dict[str, str],
        headers: dict[str, str] | None = None,
        credentials: bool = False,
    ) -> dict[str, Any]:
        """
        Fetch multiple URLs in parallel.

        Args:
            urls: Dict of {id: url} to fetch
            headers: Optional headers (accept: application/json by default)
            credentials: Include credentials/cookies (default False, may break CORS)

        Returns:
            Dict of {id: {data: ..., error: ...}}
        """
        if not urls:
            return {}
        js = self._build_fetch_all(urls, headers, credentials)
        result = await self.execute_js(js)
        return self._parse_fetch_all(result)

    # === State & Cookies ===

    async def screenshot(self, full_page: bool = False) -> bytes:
        """Take screenshot."""
        return await self._service.screenshot(self._session_id, full_page)

    async def get_state(self) -> BrowserState:
        """Get current browser state."""
        return await self._service.get_state(self._session_id)

    async def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        """Set browser cookies."""
        await self._service.set_cookies(self._session_id, cookies)

    async def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        """Get browser cookies."""
        return await self._service.get_cookies(self._session_id, domain)

    # === Parser helpers ===

    async def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        """Validate CSS selectors on page."""
        return await self._service.validate_selectors(self._session_id, item, fields)

    async def extract_data(self, item: str, fields_json: str, limit: int = 100) -> dict:
        """Extract structured data from page."""
        return await self._service.extract_data(
            self._session_id, item, fields_json, limit
        )

    # === HTML Parsing ===

    async def parse_html(self, html: str | None = None, selector: str | None = None) -> "BeautifulSoup":
        """Parse HTML with BeautifulSoup."""
        if html is None:
            html = await self.get_html(selector)
        return _parse_html(html)

    async def soup(self, selector: str | None = None) -> SoupWrapper:
        """Get page HTML as SoupWrapper."""
        html = await self.get_html(selector)
        return SoupWrapper(html=html)

    # === Mouse & Scroll (native, not JS) ===

    async def mouse_move(self, x: int, y: int, steps: int = 10) -> None:
        """
        Move mouse to coordinates with human-like movement.

        Args:
            x: Target X coordinate
            y: Target Y coordinate
            steps: Number of intermediate steps (1 = instant, >1 = smooth)

        Example:
            await browser.mouse_move(500, 300)  # Smooth move
            await browser.mouse_move(100, 100, steps=1)  # Instant move
        """
        await self._service.mouse_move(self._session_id, x, y, steps)

    async def scroll(
        self,
        direction: str = "down",
        amount: int = 500,
        selector: str | None = None,
        smooth: bool = True,
    ) -> ScrollResult:
        """
        Scroll the page (native, not JS).

        Args:
            direction: "up", "down", "left", "right"
            amount: Pixels to scroll
            selector: If provided, scroll element into view instead
            smooth: Use smooth scroll animation (default True)

        Returns:
            ScrollResult with position info

        Example:
            # Fast scroll
            await browser.scroll("down", 800)

            # Scroll element into view
            await browser.scroll(selector=".target-element")
        """
        result = await self._service.scroll(self._session_id, direction, amount, selector or "", smooth)
        return result

    async def scroll_to(self, selector: str) -> ScrollResult:
        """Scroll element into view."""
        return await self.scroll(selector=selector)

    async def scroll_to_bottom(self) -> ScrollResult:
        """Scroll to page bottom."""
        js = self._build_scroll_to_bottom()
        result = await self.execute_script(js)
        data = parse_json_result(result) or {}
        return ScrollResult(
            success=data.get("success", False),
            scroll_y=int(data.get("scrollY", 0)),
            scrolled_by=int(data.get("scrolledBy", 0)),
            at_bottom=True,
        )

    async def get_scroll_info(self) -> ScrollInfo:
        """Get current scroll position and page dimensions (JS-based)."""
        js = self._build_get_scroll_info()
        result = await self.execute_script(js)
        data = parse_json_result(result) or {}
        return ScrollInfo(
            scroll_x=int(data.get("scrollX", 0)),
            scroll_y=int(data.get("scrollY", 0)),
            page_height=int(data.get("pageHeight", 0)),
            page_width=int(data.get("pageWidth", 0)),
            viewport_height=int(data.get("viewportHeight", 0)),
            viewport_width=int(data.get("viewportWidth", 0)),
            at_bottom=data.get("atBottom", False),
            at_top=data.get("atTop", True),
        )

    async def get_page_info(self) -> PageInfo:
        """Get comprehensive page info (native)."""
        return await self._service.get_page_info(self._session_id)

    # === UI Interaction Helpers ===

    async def hover(self, selector: str, timeout_ms: int = 5000) -> None:
        """Hover over element (native)."""
        await self._service.hover(self._session_id, selector, timeout_ms)

    async def select(self, selector: str, value: str | None = None, text: str | None = None) -> dict:
        """Select option from dropdown."""
        js = self._build_select(selector, value, text)
        result = await self.execute_script(js)
        return parse_json_result(result) or {}

    async def close_modal(self, selectors: list[str] | None = None) -> bool:
        """Try to close modal/dialog."""
        js = self._build_close_modal(selectors)
        result = await self.execute_script(js)
        data = parse_json_result(result) or {}
        return data.get("success", False)

    async def wait_seconds(self, seconds: float) -> None:
        """Wait for specified seconds."""
        await asyncio.sleep(seconds)

    async def wait_random(self, min_sec: float = 0.5, max_sec: float = 1.5) -> None:
        """Wait for random time between min and max seconds."""
        import random
        await asyncio.sleep(min_sec + random.random() * (max_sec - min_sec))

    async def click_all_by_text(self, text: str, role: str = "button") -> int:
        """Click all elements containing specific text."""
        js = self._build_click_all_by_text(text, role)
        result = await self.execute_script(js)
        data = parse_json_result(result) or {}
        return data.get("clicked", 0)

    async def press_key(self, key: str, selector: str | None = None) -> bool:
        """
        Press a keyboard key.

        Args:
            key: Key to press (e.g., 'Escape', 'Enter', 'Tab', 'ArrowDown')
            selector: Optional CSS selector to target. If None, targets activeElement.

        Returns:
            True if key was pressed successfully
        """
        js = self._build_press_key(key, selector)
        result = await self.execute_script(js)
        data = parse_json_result(result) or {}
        return data.get("success", False)

    # === Context Manager ===

    async def close(self) -> None:
        """Close browser session."""
        await self._service.close_session(self._session_id)

    async def __aenter__(self) -> "AsyncBrowserSession":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
