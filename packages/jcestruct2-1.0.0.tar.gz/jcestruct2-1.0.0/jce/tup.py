"""TUP (Tars Uni-Protocol) 协议定义.

TUP 是基于 JCE 编码的应用层协议,用于 Tars 框架的远程调用.
"""

from jce import JceField, JceStruct
from jce.types import BYTES, MAP

# TUP 返回值常量
TAFSERVERSUCCESS = 0  # 服务器端处理成功
TAFSERVERDECODEERR = -1  # 服务器端解码异常
TAFSERVERENCODEERR = -2  # 服务器端编码异常
TAFSERVERNOFUNCERR = -3  # 服务器端没有该函数
TAFSERVERNOSERVANTERR = -4  # 服务器端没有该Servant对象
TAFSERVERRESETGRID = -5  # 服务器端灰度状态不一致
TAFSERVERQUEUETIMEOUT = -6  # 服务器队列超过限制
TAFASYNCCALLTIMEOUT = -7  # 异步调用超时
TAFINVOKETIMEOUT = -7  # 调用超时
TAFPROXYCONNECTERR = -8  # 代理链接异常
TAFSERVEROVERLOAD = -9  # 服务器过载, 超过队列长度
TAFADAPTERNULL = -10  # 客户端路由为空, 服务不存在或所有服务下线
TAFINVOKEBYINVALIDESET = -11  # 客户端按set规则调用非法
TAFCLIENTDECODEERR = -12  # 客户端解码异常
TAFSERVERUNKNOWNERR = -99  # 服务器端位置异常


class RequestPacket(JceStruct):
    """TUP 请求包结构."""

    iVersion: int = JceField(jce_id=1, default=0)
    cPacketType: int = JceField(jce_id=2, default=0)
    iMessageType: int = JceField(jce_id=3, default=0)
    iRequestId: int = JceField(jce_id=4, default=0)
    sServantName: str = JceField(jce_id=5, default="")
    sFuncName: str = JceField(jce_id=6, default="")
    sBuffer: bytes = JceField(jce_id=7, jce_type=BYTES, default=b"")
    iTimeout: int = JceField(jce_id=8, default=0)
    context: dict[str, str] = JceField(jce_id=9, jce_type=MAP, default_factory=dict)
    status: dict[str, str] = JceField(jce_id=10, jce_type=MAP, default_factory=dict)


class ResponsePacket(JceStruct):
    """TUP 响应包结构."""

    iVersion: int = JceField(jce_id=1, default=0)
    cPacketType: int = JceField(jce_id=2, default=0)
    iRequestId: int = JceField(jce_id=3, default=0)
    iMessageType: int = JceField(jce_id=4, default=0)
    iRet: int = JceField(jce_id=5, default=0)
    sBuffer: bytes = JceField(jce_id=6, jce_type=BYTES, default=b"")
    status: dict[str, str] = JceField(jce_id=7, jce_type=MAP, default_factory=dict)
    sResultDesc: str = JceField(jce_id=8, default="")
