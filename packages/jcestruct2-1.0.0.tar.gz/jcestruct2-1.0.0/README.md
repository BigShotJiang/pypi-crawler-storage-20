# JceStruct

[![PyPI version](https://img.shields.io/pypi/v/jcestruct2)](https://pypi.org/project/jcestruct2/)
[![Python](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Pydantic v2](https://img.shields.io/badge/pydantic-v2-blue.svg)](https://docs.pydantic.dev/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

**JceStruct** 是一个现代化的 Python JCE (Jce Encoding) 协议实现, 基于 Pydantic v2 构建。JCE 是腾讯 Tars 框架使用的高效二进制序列化协议。

## 特性

- **类型安全**: 基于 Pydantic v2, 完整的类型提示和运行时验证
- **高性能**: 智能整数压缩、零值优化、字节数组优化、零拷贝读取
- **灵活性**: 支持 Schema (JceStruct) 和无 Schema (dict) 两种模式
- **泛型支持**: 完整支持 Python Generic 类型系统
- **TUP 协议**: 内置 Tars TUP 协议包结构 (RequestPacket/ResponsePacket)
- **CLI 工具**: 基于 Click 的强大命令行工具，支持文件读写和格式化输出
- **安全防护**: 递归深度限制、容器大小限制, 防止 DoS 攻击
- **纯 Python**: 无需编译 C 扩展，易于安装和跨平台使用

## 安装

### 使用 pip

```bash
pip install jcestruct2
# 安装 CLI 支持
pip install "jcestruct2[cli]"
```

### 使用 uv

```bash
uv add jcestruct2
# 安装 CLI 支持
uv add "jcestruct2[cli]"
```

### 从源码安装

```bash
# 从 GitHub 仓库安装
pip install git+https://github.com/L-1124/JceStruct.git
# 或使用 uv
uv pip install -e .
```

### 本地开发安装

```bash
git clone https://github.com/L-1124/JceStruct.git
cd JceStruct
uv sync
```

## 快速开始

### 基础示例

```python
from jce import JceField, JceStruct, dumps, loads, types

# 定义数据模型
class User(JceStruct):
    uid: int = JceField(jce_id=0, jce_type=types.INT)
    name: str = JceField(jce_id=1, jce_type=types.STRING)

# 序列化
user = User(uid=1001, name="Alice")
encoded = dumps(user)
print(f"Encoded hex: {encoded.hex()}")

# 反序列化
restored = loads(encoded, User)
assert restored.name == "Alice"
```

## 功能演示

### 1. 复杂嵌套结构

JceStruct 完美处理嵌套结构和泛型列表。

```python
class Server(JceStruct):
    host: str = JceField(jce_id=1)
    port: int = JceField(jce_id=2)

class ServerList(JceStruct):
    # 支持泛型类型提示
    servers: list[Server] = JceField(jce_id=2, jce_type=types.LIST)

# 自动编码嵌套对象
payload = ServerList(servers=[
    Server(host="192.168.1.1", port=8080),
    Server(host="192.168.1.2", port=8081)
]).encode()

# 解码回对象
data = ServerList.decode(payload)
print(f"Server 1: {data.servers[0].host}:{data.servers[0].port}")
```

### 2. 命令行调试工具

内置 CLI 工具方便快速查看十六进制 JCE 数据的结构。需要安装 `[cli]` 选项。

```bash
# 直接解码 Hex 字符串
$ jce "160472636e62211f40860472636e62"

# 输出结果 (pretty print)
{
    1: 'rcnb',
    2: 8000,
    8: 'rcnb'
}

# 从文件读取并输出为 JSON
$ jce -f data.hex --format json

# 将结果保存到文件
$ jce "160472636e62" -o output.json --format json

# 详细模式 (显示调试信息)
$ jce "160472636e62" -v
```

### 3. 无模式 (Dict) 编解码

无需定义 `JceStruct` 模型, 直接处理原始字典数据, 适用于动态结构或快速原型。

```python
from jce import dumps, loads

# 编码: 使用字典, 键为 JCE Tag ID (int)
raw_data = {
    0: 123,
    1: "JceStruct",
    2: [1, 2, 3],
    3: {"inner_tag": "inner_value"}
}
encoded = dumps(raw_data)

# 解码: 指定 target=dict (默认为 dict)
# 库会自动尝试将嵌套的字节/SimpleList 转换为可读字典或字符串
decoded = loads(encoded, target=dict)

print(decoded[0])  # 123
print(decoded[1])  # "JceStruct"
```

### 4. Dict 到 JceStruct 的转换

直接将原始字典转换为类型化的 JceStruct 对象, 利用 Pydantic 的验证能力。

```python
from jce import JceField, JceStruct, types

class SsoServerInfo(JceStruct):
    server: str = JceField(jce_id=1, default="")
    port: int = JceField(jce_id=2, default=0)

# 从字典创建结构化对象 (支持 Tag ID 或字段名作为键)
dict_data = {1: "example.com", 2: 8080}
# 或者
dict_data = {"server": "example.com", "port": 8080}

# 方式一: 使用 model_validate (推荐)
server_info = SsoServerInfo.model_validate(dict_data)
assert server_info.server == "example.com"
assert server_info.port == 8080

# 方式二: 使用字典解包
server_info = SsoServerInfo(**dict_data)

# 完整循环: Dict → 对象 → 字节 → 对象 → Dict
encoded = server_info.encode()
restored = SsoServerInfo.decode(encoded)
```

### 5. 泛型支持

JceStruct 支持 Python 的泛型系统 (Generic), 允许定义可重用的通用结构体。

```python
from typing import TypeVar, Generic
from jce import JceStruct, JceField

DataT = TypeVar("DataT")

class Response(JceStruct, Generic[DataT]):
    code: int = JceField(jce_id=0, default=0)
    # 泛型字段会自动根据实例化类型推断 JCE 类型
    data: DataT = JceField(jce_id=1)

# 1. 使用基本类型
resp_str = Response[str](data="hello")
encoded = resp_str.encode()

# 反序列化时必须使用具体的泛型类
decoded = Response[str].decode(encoded)
assert decoded.data == "hello"

# 2. 使用结构体类型
class User(JceStruct):
    uid: int = JceField(jce_id=0)

resp_user = Response[User](data=User(uid=1001))
```

### 6. Tars TUP 协议支持

内置 TUP (Tars Uni-Protocol) 协议包结构定义, 方便构建 Tars 客户端或服务端。

```python
from jce.tup import RequestPacket, ResponsePacket, TAFSERVERSUCCESS

# 构建请求包
req = RequestPacket(
    iVersion=3,
    iRequestId=1,
    sServantName="TestApp.TestServer.TestObj",
    sFuncName="echo",
    sBuffer=b"hello",
)
encoded_req = req.encode()

# 解码响应包
decoded_resp = ResponsePacket.decode(encoded_resp_bytes)
if decoded_resp.iRet == TAFSERVERSUCCESS:
    print(f"Success: {decoded_resp.sBuffer}")
```

### 7. 编码选项

JceStruct 提供多种选项来控制序列化行为:

```python
from jce import dumps, loads
from jce.options import (
    OPT_LITTLE_ENDIAN,   # 小端字节序 (非标准 JCE)
    OPT_STRICT_MAP,      # 严格 MAP 标签验证
    OPT_OMIT_DEFAULT,    # 省略默认值字段
)

# 省略默认值 - 减少数据大小
class Config(JceStruct):
    a: int = JceField(jce_id=0, default=100)
    b: str = JceField(jce_id=1, default="default")

config = Config()  # 使用所有默认值
encoded = dumps(config, option=OPT_OMIT_DEFAULT)
# encoded 为空, 因为所有字段都是默认值

# 小端模式 (用于特定场景)
encoded_le = dumps(data, option=OPT_LITTLE_ENDIAN)
decoded = loads(encoded_le, target=dict, option=OPT_LITTLE_ENDIAN)
```

## 核心 API

### 主要函数

| 函数                       | 说明                                           |
| -------------------------- | ---------------------------------------------- |
| `dumps(data, option=0)`    | 序列化为二进制 (支持 `JceStruct` 和 `dict`)    |
| `loads(data, target, option=0)` | 反序列化二进制 (返回指定类型或 `dict`)    |

### JceStruct 方法

| 方法                  | 说明                               |
| --------------------- | ---------------------------------- |
| `encode(option=0)`    | 序列化为二进制                     |
| `decode(data, option=0)` | 类方法, 从二进制反序列化        |
| `model_validate(obj)` | Pydantic 方法, 从字典/对象创建实例 |

### 编码选项

| 选项                    | 值     | 说明                                |
| ----------------------- | ------ | ----------------------------------- |
| `OPT_NETWORK_BYTE_ORDER`| 0x0000 | 默认: 网络字节序 (大端)             |
| `OPT_LITTLE_ENDIAN`     | 0x0001 | 小端字节序 (非标准 JCE)             |
| `OPT_STRICT_MAP`        | 0x0002 | 严格 MAP 标签: key=0, value=1       |
| `OPT_SERIALIZE_NONE`    | 0x0004 | 序列化 None 值                      |
| `OPT_ZERO_COPY`         | 0x0010 | 零拷贝模式 (返回 memoryview)        |
| `OPT_OMIT_DEFAULT`      | 0x0020 | 省略等于默认值的字段                |

### 类型支持

支持完整的 JCE 类型系统:

```python
from jce import types

types.BYTE          # 单字节
types.BOOL          # 布尔值
types.INT           # 32 位整数
types.LONG          # 64 位整数
types.FLOAT         # 32 位浮点
types.DOUBLE        # 64 位浮点
types.STRING        # 字符串
types.LIST          # 列表/数组
types.MAP           # 字典/映射
types.STRUCT        # 嵌套结构
```

## 异常处理

```python
from jce import JceDecodeError, JceEncodeError

try:
    data = loads(malformed_bytes, MyStruct)
except JceDecodeError as e:
    print(f"解码失败: {e}")

try:
    encoded = dumps(invalid_data)
except JceEncodeError as e:
    print(f"编码失败: {e}")
```

## 安全特性

JceStruct 内置多项安全防护措施:

- **递归深度限制**: 防止深层嵌套导致栈溢出
- **容器大小限制**: 防止恶意构造的超大列表/映射
- **字符串长度限制**: 防止内存耗尽攻击
- **负数长度检查**: 拒绝无效的负数长度字段

## 开发与贡献

本项目采用现代 Python 工具链进行开发：

- **依赖管理**: 使用 `uv`。
- **代码风格**: 使用 `ruff` 进行 lint 和 format。
- **测试**: 使用 `pytest` 编写函数式测试。

### 运行测试

```bash
uv run pytest tests/ -v
```

### 代码检查

```bash
uv run ruff check .
uv run ruff format .
```

## 协议文档

详细的 JCE 协议规范请参阅 [JCE_PROTOCOL.md](JCE_PROTOCOL.md)。

## 许可

本项目采用 **MIT 许可证** - 详情请参阅 [LICENSE](LICENSE) 文件。
