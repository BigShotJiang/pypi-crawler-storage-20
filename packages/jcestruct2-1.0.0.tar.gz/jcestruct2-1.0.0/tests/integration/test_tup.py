"""测试 TUP 协议的 RequestPacket 和 ResponsePacket 编解码."""

from jce.decoder import DataReader, GenericDecoder
from jce.tup import TAFSERVERSUCCESS, RequestPacket, ResponsePacket


def test_request_packet_encoding():
    """测试 RequestPacket 编码和解码的完整性."""
    req = RequestPacket(
        iVersion=3,
        cPacketType=0,
        iMessageType=0,
        iRequestId=123,
        sServantName="TestApp.TestServer.TestObj",
        sFuncName="echo",
        sBuffer=b"hello",
        iTimeout=1000,
        context={"client": "test"},
        status={"grid": "1"},
    )

    encoded = req.encode()
    decoded = RequestPacket.decode(encoded)

    assert decoded.iVersion == 3
    assert decoded.iRequestId == 123
    assert decoded.sServantName == "TestApp.TestServer.TestObj"
    assert decoded.sBuffer == b"hello"
    assert decoded.context == {"client": "test"}

    # Verify sBuffer is encoded as SIMPLE_LIST
    # Decode using GenericDecoder to check internal structure
    reader = DataReader(encoded)
    decoder = GenericDecoder(reader)
    decoded_dict = decoder.decode()

    # Tag 7 is sBuffer
    # In GenericDecoder, SIMPLE_LIST (13) is decoded as bytes
    assert decoded_dict[7] == b"hello"


def test_response_packet_encoding():
    """测试 ResponsePacket 编码和解码的完整性."""
    resp = ResponsePacket(
        iVersion=3,
        cPacketType=0,
        iRequestId=123,
        iMessageType=0,
        iRet=TAFSERVERSUCCESS,
        sBuffer=b"world",
        status={"k": "v"},
        sResultDesc="ok",
    )

    encoded = resp.encode()
    decoded = ResponsePacket.decode(encoded)

    assert decoded.iRet == 0
    assert decoded.sBuffer == b"world"
    assert decoded.sResultDesc == "ok"
