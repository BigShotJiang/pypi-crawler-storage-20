"""测试 OPT_OMIT_DEFAULT 选项的编解码行为."""

from jce import JceField, JceStruct, dumps, loads
from jce.options import OPT_OMIT_DEFAULT


class Config(JceStruct):
    """测试用配置结构体, 包含带默认值的字段."""

    a: int = JceField(jce_id=0, default=100)
    b: str = JceField(jce_id=1, default="default")
    c: int = JceField(jce_id=2, default=0)  # 0 often default but we set explicit


def test_omit_default():
    """测试 OPT_OMIT_DEFAULT 选项: 默认值字段应被省略."""
    # 1. Without option (default behavior: always encode)
    c = Config()
    encoded = dumps(c)
    # Should contain all fields
    decoded = Config.decode(encoded, option=0)
    assert decoded.a == 100
    assert decoded.b == "default"
    assert decoded.c == 0

    # Check length/content manually
    # Tag 0: INT1/2 (100)
    # Tag 1: STRING ("default")
    # Tag 2: ZERO_TAG (0)
    # It should not be empty
    assert len(encoded) > 0

    # 2. With OPT_OMIT_DEFAULT
    encoded_omit = dumps(c, option=OPT_OMIT_DEFAULT)
    # Since all fields match default, output should be empty!
    assert len(encoded_omit) == 0

    # Decode empty bytes should result in defaults
    decoded_omit = loads(encoded_omit, Config)
    assert decoded_omit.a == 100
    assert decoded_omit.b == "default"
    assert decoded_omit.c == 0


def test_omit_partial():
    """测试部分字段修改时的 OPT_OMIT_DEFAULT 行为."""
    # Modify one field
    c = Config(a=200)
    encoded = dumps(c, option=OPT_OMIT_DEFAULT)

    # Should only contain field 'a' (Tag 0)
    # Tag 0, Val 200 (INT2) -> 0x01 0x00 0xC8 (assuming big endian)
    # INT2 is type 1. Tag 0 Type 1 -> 0x01.
    # 200 -> 00 C8.
    # Expected: 01 00 C8

    assert len(encoded) == 3
    assert encoded == bytes([0x01, 0x00, 0xC8])

    decoded = Config.decode(encoded)
    assert decoded.a == 200
    assert decoded.b == "default"
    assert decoded.c == 0
