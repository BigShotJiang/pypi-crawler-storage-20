from jce.decoder import GenericDecoder, DataReader


def test_freeze_key_coverage():
    """Test _freeze_key method for coverage."""
    reader = DataReader(b"")
    decoder = GenericDecoder(reader)

    # Test basic types (should return as is)
    assert decoder._freeze_key(1) == 1
    assert decoder._freeze_key("a") == "a"
    assert decoder._freeze_key(b"b") == b"b"
    assert decoder._freeze_key(None) is None

    # Test list (should convert to tuple)
    lst = [1, 2, 3]
    frozen_lst = decoder._freeze_key(lst)
    assert frozen_lst == (1, 2, 3)
    assert isinstance(frozen_lst, tuple)

    # Test dict (should convert to sorted tuple of items)
    dct = {"b": 2, "a": 1}
    frozen_dct = decoder._freeze_key(dct)
    assert frozen_dct == (("a", 1), ("b", 2))

    # Test nesting
    nested = {"k": [1, 2]}
    frozen_nested = decoder._freeze_key(nested)
    assert frozen_nested == (("k", (1, 2)),)

    # Test caching (coverage for cache hit)
    # Call again with SAME object (id checks)
    frozen_lst_2 = decoder._freeze_key(lst)
    assert frozen_lst_2 is frozen_lst  # Should imply cache hit logic was traversed
