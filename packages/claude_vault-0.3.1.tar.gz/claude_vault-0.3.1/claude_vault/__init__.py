"""Claude Vault - Sync Claude conversations to Obsidian markdown files"""

__version__ = "0.3.1"
