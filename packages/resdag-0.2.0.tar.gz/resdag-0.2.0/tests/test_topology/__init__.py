"""Tests for topology module."""
