"""Tests for readwise-sdk."""
