class ImageCollection:
    def __init__(self, client):
        self.client = client

    def pull(self, image):
        # SkyPilot handles image pulling in task definition (e.g., in resources or setup)
        # For a drop-in replacement, we can just return the image name or a dummy Image object
        return image
