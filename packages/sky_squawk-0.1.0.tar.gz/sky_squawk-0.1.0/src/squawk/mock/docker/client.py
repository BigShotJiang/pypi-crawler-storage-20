from .containers import ContainerCollection
from .images import ImageCollection

class DockerClient:
    def __init__(self):
        self.containers = ContainerCollection(self)
        self.images = ImageCollection(self)

def from_env():
    return DockerClient()
