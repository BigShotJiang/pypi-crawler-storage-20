import sky
import uuid
import os
import io
import sys
import contextlib
import time
import shlex
from typing import Optional, Dict, List

@contextlib.contextmanager
def silent_fd():
    """Aggressively suppress all stdout/stderr at the FD level (FD 1 and 2)."""
    try:
        stdout_fd = sys.stdout.fileno()
        stderr_fd = sys.stderr.fileno()
    except (AttributeError, io.UnsupportedOperation):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            yield
        return

    saved_stdout_fd = os.dup(stdout_fd)
    saved_stderr_fd = os.dup(stderr_fd)
    try:
        with open(os.devnull, 'w') as fnull:
            null_fd = fnull.fileno()
            os.dup2(null_fd, stdout_fd)
            os.dup2(null_fd, stderr_fd)
        yield
    finally:
        os.dup2(saved_stdout_fd, stdout_fd)
        os.dup2(saved_stderr_fd, stderr_fd)
        os.close(saved_stdout_fd)
        os.close(saved_stderr_fd)

def sky_safe_get(request_id):
    """Safely calls sky.get() and handles prefix collisions by returning None if ambiguous."""
    if request_id is None:
        return None
    with silent_fd():
        try:
            return sky.get(request_id)
        except Exception as e:
            if "Multiple requests found" in str(e):
                return None
            raise e

def resolve_job_id(cluster_name: str) -> Optional[int]:
    """Polls the cluster queue to find the latest job ID, avoiding RequestID ambiguity."""
    for _ in range(10): # Try for ~20 seconds
        with silent_fd():
            try:
                # We try to get the queue. If sky.queue(cluster) is ambiguous, we're in trouble,
                # but usually cluster-specific calls are fresher.
                jobs_req = sky.queue(cluster_name)
                jobs = sky.get(jobs_req)
                if jobs:
                    return jobs[-1]['job_id']
            except:
                pass
        time.sleep(2)
    return None

class Container:
    def __init__(self, cluster_name, status=None, job_id=None):
        self.name = cluster_name
        self.id = cluster_name
        self.status = status
        self.job_id = job_id

    def stop(self):
        with silent_fd():
            sky_safe_get(sky.stop(self.name))

    def remove(self, force=False):
        with silent_fd():
            sky_safe_get(sky.down(self.name))

    def wait(self):
        """Waits for the container's job to complete."""
        if self.job_id is None:
            return {"StatusCode": 0}
            
        while True:
            with silent_fd():
                try:
                    jobs = sky.get(sky.queue(self.name))
                    job = next((j for j in jobs if j['job_id'] == self.job_id), None)
                    if job and job['status'].is_terminal():
                        return {"StatusCode": 0}
                except:
                    pass
            time.sleep(2)

    def logs(self, stream=False):
        """Fetches the command stdout as plain text."""
        if self.job_id is None:
            return ""

        if stream:
            def log_generator():
                return self.logs(stream=False)
            return log_generator()

        try:
            with silent_fd():
                # The user indicated that download_logs might return a dict directly in their env
                res = sky.download_logs(self.name, job_ids=[str(self.job_id)])
                if isinstance(res, dict):
                    job_log_object = res
                else:
                    # Fallback to resolving if it's a RequestId
                    job_log_object = sky.get(res)
                
                log_path = job_log_object.get(str(self.job_id))
            
            if log_path:
                full_log_path = os.path.expanduser(f"{log_path}/run.log")
                if os.path.exists(full_log_path):
                    with open(full_log_path, 'r') as f:
                        return f.read()
            return "Logs not available."
        except Exception as e:
            return f"Error retrieving logs: {e}"

class ContainerCollection:
    def __init__(self, client):
        self.client = client

    def run(
        self, 
        image: str, 
        command: Optional[str] = None, 
        detach: bool = False, 
        name: Optional[str] = None,
        timeout: Optional[int] = None,
        volumes: Optional[Dict[str, str]] = None,
        infra: str = "kubernetes",
        **kwargs
    ):
        cluster_name = name or f"squawk-{uuid.uuid4()}"
        resources = sky.Resources(cpus=4, memory=8, accelerators=None, infra=infra)
        
        if timeout:
            quoted_command = shlex.quote(command) if command else ""
            run_command = f"timeout {timeout} sh -c {quoted_command}"
        else:
            run_command = command

        task = sky.Task(run=run_command)
        task.set_resources(resources)
        if volumes:
            task.set_file_mounts(volumes)

        # 1. Launch. Ignore the RequestID ambiguity error if it happens.
        with silent_fd():
            try:
                sky_safe_get(sky.launch(task, cluster_name=cluster_name, down=False))
            except:
                pass

        # 2. Identify the job ID by polling the cluster queue
        job_id = resolve_job_id(cluster_name)
        container = Container(cluster_name, status="running", job_id=job_id)

        if detach:
            return container
        else:
            try:
                container.wait()
                return container.logs()
            finally:
                container.remove()

    def list(self, all=False):
        with silent_fd():
            try:
                clusters = sky.get(sky.status())
                return [Container(c['name'], status=c['status'].value) for c in clusters]
            except:
                return []

    def get(self, id_or_name):
        with silent_fd():
            try:
                clusters = sky.get(sky.status())
                for c in clusters:
                    if c['name'] == id_or_name:
                        return Container(c['name'], status=c['status'].value)
            except:
                pass
        raise Exception(f"Container {id_or_name} not found")
