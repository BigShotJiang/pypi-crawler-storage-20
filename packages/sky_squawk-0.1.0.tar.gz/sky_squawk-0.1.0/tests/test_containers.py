import pytest
from unittest.mock import MagicMock, patch, mock_open
import squawk.mock.docker as docker
import sky

@pytest.fixture
def client():
    return docker.from_env()

def test_client_init(client):
    assert hasattr(client, 'containers')
    assert hasattr(client, 'images')

@patch('sky.get')
@patch('sky.launch')
@patch('sky.Resources')
@patch('sky.Task')
@patch('sky.queue')
def test_container_run_basic(mock_queue, mock_task, mock_resources, mock_launch, mock_get, client):
    # Setup mocks
    mock_resources_instance = MagicMock()
    mock_resources.return_value = mock_resources_instance
    # 1. launch get(), 2. queue get() in resolve_job_id
    mock_get.side_effect = [(1, MagicMock()), [{'job_id': 1}]]
    
    # Run
    container = client.containers.run("ubuntu:20.04", "echo hello", name="test-container", detach=True)
    
    # Verify Launch called
    args, kwargs = mock_launch.call_args
    assert kwargs['down'] is False
    assert kwargs['cluster_name'] == "test-container"
    assert container.job_id == 1

@patch('sky.get')
@patch('sky.launch')
@patch('sky.down')
@patch('sky.download_logs')
@patch('sky.queue')
@patch('builtins.open', new_callable=mock_open, read_data="hello world")
@patch('os.path.exists')
def test_container_run_sync_returns_logs_and_cleans_up(mock_exists, mock_file, mock_queue, mock_download, mock_down, mock_launch, mock_get, client):
    terminal_status = MagicMock()
    terminal_status.is_terminal.return_value = True
    
    mock_get.side_effect = [
        (1, MagicMock()), # launch
        [{'job_id': 1}],  # resolve_job_id
        [{'job_id': 1, 'status': terminal_status}], # wait()
        {"1": "/tmp/logs"}, # download_logs
        None              # remove
    ]
    mock_exists.return_value = True
    
    result = client.containers.run("ubuntu", "echo hello", detach=False)
    assert result == "hello world"
    # Verify manual down was called for sync run
    mock_down.assert_called_once()

@patch('sky.get')
@patch('sky.download_logs')
@patch('builtins.open', new_callable=mock_open, read_data="test logs")
@patch('os.path.exists')
def test_container_logs_method(mock_exists, mock_file, mock_download, mock_get):
    mock_get.return_value = {"123": "/tmp/logs"}
    # mock_exists and open are patched
    mock_exists.return_value = True
    container = docker.containers.Container("c1", job_id=123)
    logs = container.logs()
    assert logs == "test logs"
    mock_download.assert_called_once_with("c1", job_ids=["123"])

@patch('sky.get')
@patch('sky.status')
def test_container_list(mock_status, mock_get, client):
    mock_get.return_value = [
        {'name': 'c1', 'status': MagicMock(value='UP')},
        {'name': 'c2', 'status': MagicMock(value='STOPPED')}
    ]
    
    containers = client.containers.list()
    assert len(containers) == 2

@patch('sky.get')
@patch('sky.stop')
def test_container_stop(mock_stop, mock_get, client):
    container = docker.containers.Container("test-c")
    container.stop()
    mock_stop.assert_called_once_with("test-c")

@patch('sky.get')
@patch('sky.down')
def test_container_remove(mock_down, mock_get, client):
    container = docker.containers.Container("test-c")
    container.remove()
    mock_down.assert_called_once_with("test-c")
