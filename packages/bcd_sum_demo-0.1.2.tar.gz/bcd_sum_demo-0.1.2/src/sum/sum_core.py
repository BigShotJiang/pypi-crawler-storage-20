from fastapi import APIRouter
from pydantic import BaseModel

# Python object = auto-exported (no cdef needed!)
router = APIRouter(tags=["sum"])

class SumRequest(BaseModel):
    a: float
    b: float

class SumResponse(BaseModel):
    result: float

@router.post("/sum", response_model=SumResponse)
def sum_two_numbers(payload: SumRequest):
    return SumResponse(result=payload.a + payload.b)
