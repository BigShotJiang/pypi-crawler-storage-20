"""Logical Data Structures."""
