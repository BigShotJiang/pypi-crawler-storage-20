"""Logical Algorithms."""
