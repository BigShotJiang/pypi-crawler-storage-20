"""scDistill: 2-Phase batch correction via knowledge distillation.

scDistill corrects batch effects in scRNA-seq data while preserving
biological variation (e.g., age effects, treatment effects).

Architecture (2-Phase):
    Phase 1: X → Encoder → Z,  Loss = ||Z - Z*||
    Phase 2: Z* → Decoder → X_corrected → Encoder(fixed) → Z',  Loss = ||Z' - Z*||

Where Z* is the teacher's (e.g., Harmony) batch-corrected embeddings.

Quick Start
-----------
>>> from scdistill import Distiller
>>>
>>> model = Distiller(adata, batch_key='batch')
>>> model.train()
>>> Z_student = model.latent.student
>>> Z_teacher = model.latent.teacher
>>> X_corrected = model.corrected_expression()

Using Different Teachers
------------------------
>>> from scdistill.teachers import CombatTeacher
>>> model = Distiller(adata, batch_key='batch', teacher=CombatTeacher())
>>> model.train()
"""

from .distiller import Distiller
from .nn import Encoder, Decoder
from .cache import CacheConfig
from . import teachers

__version__ = "0.3.1"
__all__ = [
    "Distiller",
    "Encoder",
    "Decoder",
    "CacheConfig",
    "teachers",
]
