use super::IndexedRanges;
use crate::storage::ByteRange;
use crate::types::Region;
use crate::{Error, Result};
use noodles::bgzf;
use noodles::core::Position;
use noodles::core::region::Interval;
use noodles::csi::binning_index::BinningIndex;
use noodles::csi::binning_index::index::reference_sequence::bin::Chunk;
use noodles::tabix;
use noodles::vcf;
use std::path::Path;
use tokio::fs::File;

pub struct VcfIndexReader;

impl VcfIndexReader {
    /// Read tabix index and compute byte ranges for given regions
    pub async fn query_ranges(
        vcf_path: &Path,
        index_path: &Path,
        regions: &[Region],
    ) -> Result<IndexedRanges> {
        // Read the tabix index
        let index = tabix::r#async::read(index_path)
            .await
            .map_err(|e| Error::Internal(format!("failed to read tabix index: {}", e)))?;

        // Compute header byte range
        let header_range = Self::header_range(vcf_path).await?;

        // If no regions specified, return empty data_ranges (caller should serve whole file)
        if regions.is_empty() {
            return Ok(IndexedRanges {
                header_range,
                data_ranges: vec![],
            });
        }

        // Get reference sequence names from tabix header
        let tabix_header = index.header().ok_or_else(|| {
            Error::Internal("tabix index missing header with reference names".to_string())
        })?;
        let ref_names = tabix_header.reference_sequence_names();

        // Query index for each region
        let mut chunks: Vec<Chunk> = Vec::new();

        for region in regions {
            // Map reference name to reference sequence ID
            let ref_id = ref_names
                .iter()
                .position(|name| name == &region.reference_name)
                .ok_or_else(|| {
                    Error::NotFound(format!(
                        "reference sequence not found: {}",
                        region.reference_name
                    ))
                })?;

            // Build interval from region coordinates
            // htsget uses 0-based half-open coordinates, noodles uses 1-based closed
            let start = region
                .start
                .map(|s| Position::try_from(s as usize + 1))
                .transpose()
                .map_err(|e| Error::InvalidRange(format!("invalid start position: {}", e)))?
                .unwrap_or(Position::MIN);

            let end = region
                .end
                .map(|e| Position::try_from(e as usize))
                .transpose()
                .map_err(|e| Error::InvalidRange(format!("invalid end position: {}", e)))?
                .unwrap_or(Position::MAX);

            let interval = Interval::from(start..=end);

            // Query the index for chunks overlapping this region
            let region_chunks = index
                .query(ref_id, interval)
                .map_err(|e| Error::Internal(format!("index query failed: {}", e)))?;

            chunks.extend(region_chunks);
        }

        // Convert chunks to byte ranges
        let mut data_ranges: Vec<ByteRange> = chunks
            .into_iter()
            .map(|chunk| ByteRange {
                start: chunk.start().compressed(),
                end: Some(chunk.end().compressed()),
            })
            .collect();

        // Merge overlapping/adjacent ranges for efficiency
        data_ranges = Self::merge_ranges(data_ranges);

        Ok(IndexedRanges {
            header_range,
            data_ranges,
        })
    }

    /// Compute the header byte range by reading the VCF file
    pub async fn header_range(vcf_path: &Path) -> Result<ByteRange> {
        let file = File::open(vcf_path)
            .await
            .map_err(|e| Error::Internal(format!("failed to open VCF file: {}", e)))?;

        let mut reader = vcf::r#async::io::Reader::new(bgzf::r#async::Reader::new(file));

        // Read header to advance position past it
        reader
            .read_header()
            .await
            .map_err(|e| Error::Internal(format!("failed to read VCF header: {}", e)))?;

        // Get the virtual position after the header
        let header_end = reader.get_ref().virtual_position();

        Ok(ByteRange {
            start: 0,
            end: Some(header_end.compressed()),
        })
    }

    /// Merge overlapping or adjacent byte ranges
    fn merge_ranges(mut ranges: Vec<ByteRange>) -> Vec<ByteRange> {
        if ranges.is_empty() {
            return ranges;
        }

        // Sort by start position
        ranges.sort_by_key(|r| r.start);

        let mut merged = Vec::with_capacity(ranges.len());
        let mut current = ranges[0].clone();

        for range in ranges.into_iter().skip(1) {
            let current_end = current.end.unwrap_or(u64::MAX);

            // Check if ranges overlap or are adjacent (within 64KB is considered adjacent for BGZF)
            if range.start <= current_end + 65536 {
                // Extend current range
                current.end = match (current.end, range.end) {
                    (Some(a), Some(b)) => Some(a.max(b)),
                    _ => None,
                };
            } else {
                merged.push(current);
                current = range;
            }
        }
        merged.push(current);

        merged
    }
}
