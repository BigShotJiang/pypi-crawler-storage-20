import pqlattice as pq


def test_hnf_scaling(benchmark, sage_lattice):
    benchmark.pedantic(pq.linalg.hnf, args=(sage_lattice,), rounds=1, iterations=1, warmup_rounds=0)