# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

from sqlalchemy.orm import relationship
from sqlalchemy import Column, Float, ForeignKey, Integer, String

from discord_shared_db.base import Base

class RawPack(Base):
    __tablename__ = "raw_packs"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    cost = Column(Integer, nullable=False)
    total_cards = Column(Integer, nullable=False)

    slots = relationship("RawPackSlot", back_populates="pack")

class RawPackSlot(Base):
    __tablename__ = "raw_pack_slots"

    id = Column(Integer, primary_key=True)
    pack_id = Column(String, ForeignKey("raw_packs.id"), nullable=False)
    slot_index = Column(Integer, nullable=False)

    pack = relationship("RawPack", back_populates="slots")
    probabilities = relationship(
        "RawPackSlotRarity", 
        back_populates="slot",
        cascade="all, delete-orphan",
    )
    allowed_types = relationship(
        "RawPackSlotType",
        back_populates="slot",
        cascade="all, delete-orphan",
    )

class RawPackSlotType(Base):
    __tablename__ = "raw_pack_slot_types"

    id = Column(Integer, primary_key=True)
    slot_id = Column(Integer, ForeignKey("raw_pack_slots.id"), nullable=False)

    card_type = Column(String, nullable=False) 

    slot = relationship("RawPackSlot", back_populates="allowed_types")


class RawPackSlotRarity(Base):
    __tablename__ = "raw_pack_slot_rarities"

    id = Column(Integer, primary_key=True)
    slot_id = Column(Integer, ForeignKey("raw_pack_slots.id"), nullable=False)

    rarity = Column(String, nullable=False)  # "common", "uncommon", "rare"
    weight = Column(Float, nullable=False)   # normalized or raw weight

    slot = relationship("RawPackSlot", back_populates="probabilities")


class RawPackCard(Base):
    __tablename__ = "raw_pack_cards"

    pack_id = Column(String, ForeignKey("raw_packs.id"), primary_key=True)
    card_id = Column(String, ForeignKey("raw_cards.id"), primary_key=True)



'''
name 


total amount of cards

possible_container_cards: list (list of all cards that could be contained in the pack)


'''