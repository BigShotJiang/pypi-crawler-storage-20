# This file is part of discord-shared-db
#
# Copyright (C) 2026 CouchComfy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""Utility decorators for async functions.

Provides decorators for logging, timing, and other common function
decorations used throughout the application.
"""

import logging
from datetime import datetime
from functools import wraps

def log_time(message="Function completed in"):
    """Decorator to log function execution time.
    
    Logs when a function starts execution and how long it takes to complete.
    Useful for performance monitoring and debugging.
    
    Args:
        message: Custom message prefix for the completion log. Defaults to
            "Function completed in".
    
    Returns:
        Decorator function for async functions.
        
    Example:
        @log_time("Processing took")
        async def process_data():
            # function body
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            logging.info(f"⏳ Starting: {func.__name__}")
            start_time = datetime.now()
            result = await func(*args, **kwargs)
            end_time = datetime.now()
            total_time = (end_time - start_time).total_seconds()
            logging.info(f"{message} {total_time:.3f} seconds")
            return result
        return wrapper
    return decorator