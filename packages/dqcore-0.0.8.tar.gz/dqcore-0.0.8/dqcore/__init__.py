"""dqcore - 一个简单的 Python 包演示"""

from .core import hello_world

__version__ = "0.0.8"

__all__ = ["hello_world", "__version__", "up0", "up1"]
