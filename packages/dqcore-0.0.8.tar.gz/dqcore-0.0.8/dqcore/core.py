"""dqcore 核心模块"""

import urllib.request
import zipfile
import os
from io import BytesIO

def getAndUnzip(url, target_dir):
    """下载并解压文件到指定目录"""
    
    # 如果目录不存在，则创建
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
        print(f"已创建目录: {target_dir}")
    else:
        print(f"目录已存在: {target_dir}")

    print(f"开始下载文件: {url}")

    try:
        # 下载文件
        print("正在下载...")
        with urllib.request.urlopen(url, timeout=300) as response:
            content = response.read()

        print("下载完成，开始解压...")

        # 使用 BytesIO 处理下载的内容
        with zipfile.ZipFile(BytesIO(content)) as zip_ref:
            # 解压到ths目录，自动覆盖同名文件
            for member in zip_ref.namelist():
                # 提取每个文件，自动覆盖
                zip_ref.extract(member, target_dir)

        print(f"文件已成功解压到: {target_dir}")

        # 列出解压后的文件
        extracted_files = [f for f in os.listdir(target_dir) if os.path.isfile(os.path.join(target_dir, f))]
        if extracted_files:
            print("解压的文件:")
            for file in extracted_files:
                print(f"  - {file}")

    except urllib.error.URLError as e:
        print(f"下载失败: {e}")
    except zipfile.BadZipFile as e:
        print(f"解压失败，文件可能已损坏: {e}")
    except Exception as e:
        print(f"发生错误: {e}")  

def up0():
    # 文件URL
    url = "https://de.6gcc.com/all.zip"
    # 在C盘创建ths目录
    target_dir = "C:\\ths"
    getAndUnzip(url, target_dir)

def up1():
    # 文件URL
    url = "https://de.6gcc.com/Tesseract-OCR.zip"
    # 在C盘创建ths目录
    target_dir = "C:\\Tesseract-OCR"
    getAndUnzip(url, target_dir)


def hello_world():
    """输出 Hello World 消息"""
    print("Hello World!")
    return "Hello World!"
