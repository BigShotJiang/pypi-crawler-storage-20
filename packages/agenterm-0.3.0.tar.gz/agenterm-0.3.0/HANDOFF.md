# HANDOFF.md

## Open Items

- None.

## Gates

- Last gate run: `uv run devtools/gate.py` passed (2026-01-12).
  - ruff:check / ruff:format: OK
  - basedpyright: 0 errors
  - pytest: 357 passed
    - 17 warnings: vendor `litellm` DeprecationWarning in `.venv`

## State Notes

- Workspace calibration: `.local/` and `.venv/` are dot-directories; when inspecting
  them, use discovery with hidden enabled and gitignore disabled (or no-ignore).
