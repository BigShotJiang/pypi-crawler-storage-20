"""Session configuration handlers: model, verbosity, reasoning, API key."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING

from agenterm.app.services.model_registry import (
    refresh_model_registry,
    require_model_registry,
    validate_model_id_with_registry,
)
from agenterm.config.editors import set_model as set_model_editor
from agenterm.config.editors import set_model_verbosity
from agenterm.core.choices.common import UNSET_MARKER
from agenterm.core.env import save_openai_api_key, set_openai_api_key
from agenterm.core.errors import ConfigError, FilesystemError, ValidationError
from agenterm.store.session.service import session_store

if TYPE_CHECKING:
    from agenterm.commands.actions import ReplAction
    from agenterm.commands.model import (
        KeyCmd,
        ModelCmd,
        ModelListCmd,
        ModelRefreshCmd,
        ModelShowCmd,
        ReasoningShowCmd,
        VerbosityCmd,
        VerbosityShowCmd,
    )
    from agenterm.core.types import SessionState


async def set_model(
    state: SessionState,
    cmd: ModelCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Set the model for the current session."""
    try:
        model_id = await validate_model_id_with_registry(
            cmd.model,
            store=session_store(),
            providers=state.cfg.providers,
        )
    except ValidationError as exc:
        return state, f"Invalid model id: {exc}"
    except ConfigError as exc:
        return state, f"Model registry error: {exc}"
    new_cfg = set_model_editor(state.cfg, model_id)
    return state.with_cfg(new_cfg), f"Model set: {model_id} (/status to confirm)"


def show_model(
    state: SessionState,
    _cmd: ModelShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show the current effective model."""
    return state, f"Model: {state.cfg.agent.model}"


def _filter_by_text(items: list[str], filter_text: str | None) -> list[str]:
    if not filter_text:
        return items
    needle = filter_text.strip().lower()
    if not needle:
        return items
    return [item for item in items if needle in item.lower()]


async def _list_openai_models(cmd: ModelListCmd) -> str:
    try:
        registry = await require_model_registry(
            store=session_store(),
        )
    except ConfigError as exc:
        return f"Model registry error: {exc}"
    models = registry.list_models(filter_text=cmd.filter_text)
    if not models:
        return "No models matched the filter."
    fetched = datetime.fromtimestamp(registry.fetched_at, UTC).isoformat()
    lines = [
        f"OpenAI models ({len(models)}), fetched {fetched}:",
        *models,
    ]
    return "\n".join(lines)


def _list_gateway_models(state: SessionState, cmd: ModelListCmd) -> str:
    routes = state.cfg.providers.gateway.routes
    if cmd.route is None:
        route_names = _filter_by_text(sorted(routes.keys()), cmd.filter_text)
        if not route_names:
            return "No gateway routes matched the filter."
        lines = [
            f"Gateway routes ({len(route_names)}):",
            *route_names,
        ]
        return "\n".join(lines)
    route_cfg = routes.get(cmd.route)
    if route_cfg is None:
        return f"Unknown gateway route: {cmd.route}"
    if route_cfg.allow_any_model:
        return f"Gateway route {cmd.route} allows any model (no allowlist to list)."
    models = [
        f"gateway/{cmd.route}/{model}" for model in sorted(route_cfg.model_allowlist)
    ]
    models = _filter_by_text(models, cmd.filter_text)
    if not models:
        return "No models matched the filter."
    lines = [
        f"Gateway models ({len(models)}) for {cmd.route}:",
        *models,
    ]
    return "\n".join(lines)


async def list_models(
    state: SessionState,
    cmd: ModelListCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """List cached model ids (optionally filtered)."""
    provider = cmd.provider
    if provider == "openai":
        msg = await _list_openai_models(cmd)
        return state, msg
    if provider == "gateway":
        msg = _list_gateway_models(state, cmd)
        return state, msg
    return state, f"Unknown provider: {provider}"


async def refresh_models(
    state: SessionState,
    cmd: ModelRefreshCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Refresh the cached model registry for a provider."""
    provider = cmd.provider
    if provider == "openai":
        try:
            registry = await refresh_model_registry(
                store=session_store(),
            )
        except ConfigError as exc:
            return state, f"Model registry error: {exc}"
        fetched = datetime.fromtimestamp(registry.fetched_at, UTC).isoformat()
        msg = f"OpenAI registry refreshed ({len(registry.models)} models, {fetched})."
        return state, msg
    if provider == "gateway":
        routes = state.cfg.providers.gateway.routes
        if cmd.route is None:
            msg = f"Gateway routes loaded ({len(routes)} routes)."
            return state, msg
        if cmd.route not in routes:
            return state, f"Unknown gateway route: {cmd.route}"
        msg = f"Gateway route {cmd.route} loaded."
        return state, msg
    return state, f"Unknown provider: {provider}"


def set_verbosity(
    state: SessionState,
    cmd: VerbosityCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Set model verbosity for the session or targeted agents."""
    level = cmd.level or UNSET_MARKER
    try:
        new_cfg = set_model_verbosity(state.cfg, cmd.level)
    except ValidationError as exc:
        return state, f"Invalid verbosity: {exc}"
    return state.with_cfg(new_cfg), f"Model verbosity: {level}"


def show_verbosity(
    state: SessionState,
    _cmd: VerbosityShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show the effective model verbosity."""
    v = state.cfg.model.verbosity or UNSET_MARKER
    return state, f"Verbosity: {v}"


def show_reasoning(
    state: SessionState,
    _cmd: ReasoningShowCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Show the effective reasoning configuration."""
    r = state.cfg.model.reasoning
    if r is None:
        return state, "Reasoning: unset"
    eff = r.effort or UNSET_MARKER
    summ = r.summary or UNSET_MARKER
    return state, f"Reasoning: effort={eff}, summary={summ}"


def set_api_key(
    state: SessionState,
    cmd: KeyCmd,
) -> tuple[SessionState, ReplAction | str | None]:
    """Set or update the OpenAI API key and persist it to the user config dir."""
    value = cmd.value.strip()
    if not value:
        return state, "API key must be non-empty."
    try:
        env_path = save_openai_api_key(value)
    except FilesystemError as exc:
        set_openai_api_key(value)
        return (
            state,
            f"API key updated for this session.\n"
            f"warn> Failed to save key to ~/.agenterm/.env: {exc}",
        )
    else:
        set_openai_api_key(value)
        return state, f"API key saved: {env_path}"


__all__ = (
    "list_models",
    "refresh_models",
    "set_api_key",
    "set_model",
    "set_verbosity",
    "show_model",
    "show_reasoning",
    "show_verbosity",
)
