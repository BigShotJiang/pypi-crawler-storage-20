"""Inspect handlers for REPL slash commands."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.core.errors import DatabaseError, FilesystemError, ValidationError
from agenterm.core.json_codec import as_bool, as_str, dumps_pretty
from agenterm.store.session.service import session_store
from agenterm.ui.tool_events import shorten_line

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.commands.model import InspectAgentRunCmd
    from agenterm.core.json_types import JSONValue
    from agenterm.core.types import SessionState


def _parse_int_mapping(raw: JSONValue | None) -> dict[str, int] | None:
    if not isinstance(raw, dict):
        return None
    out: dict[str, int] = {}
    for key, value in raw.items():
        if not isinstance(value, int) or isinstance(value, bool):
            return None
        out[key] = int(value)
    return out


def _summary_map(raw: JSONValue | None) -> str | None:
    parsed = _parse_int_mapping(raw)
    if not parsed:
        return None
    parts = [
        f"{name} x{count}" if count > 1 else name
        for name, count in sorted(parsed.items())
    ]
    return ", ".join(parts) if parts else None


def _summary_list(raw: JSONValue | None, *, limit: int) -> str | None:
    if not isinstance(raw, list):
        return None
    items = [item for item in raw if isinstance(item, str) and item]
    if not items:
        return None
    return shorten_line(", ".join(items), limit=limit)


def _format_agent_run_report(
    report_id: str,
    report: Mapping[str, JSONValue],
) -> str:
    model = as_str(report.get("model")) or "-"
    created_at = as_str(report.get("created_at")) or "-"
    trace_id = as_str(report.get("trace_id")) or "-"
    response_id = as_str(report.get("response_id")) or "-"
    truncated = as_bool(report.get("truncated"))
    tool_counts = _summary_map(report.get("tool_counts")) or "-"
    usage = _summary_map(report.get("usage")) or "-"
    tools_available = _summary_list(report.get("tools_available"), limit=200) or "-"
    tools_used = _summary_list(report.get("tools_used"), limit=200) or "-"
    warnings = _summary_list(report.get("warnings"), limit=200) or "-"
    input_text = shorten_line(as_str(report.get("input")) or "", limit=160)
    instructions = shorten_line(as_str(report.get("instructions")) or "", limit=160)
    output_text = shorten_line(as_str(report.get("output_text")) or "", limit=200)
    input_items = report.get("input_items")
    output_items = report.get("output_items")
    response_ids = report.get("response_ids")
    response_count = len(response_ids) if isinstance(response_ids, list) else None
    input_items_count = len(input_items) if isinstance(input_items, list) else None
    output_items_count = len(output_items) if isinstance(output_items, list) else None
    output_items_value = (
        str(output_items_count) if output_items_count is not None else "-"
    )
    output_items_label = f"- output_items: {output_items_value}"
    lines = [
        f"agent_run report: {report_id}",
        f"- model: {model}",
        f"- created_at: {created_at}",
        f"- trace_id: {trace_id}",
        f"- response_id: {response_id}",
        f"- responses: {response_count if response_count is not None else '-'}",
        f"- truncated: {'true' if truncated else 'false'}",
        f"- tools: {tool_counts}",
        f"- tools_available: {tools_available}",
        f"- tools_used: {tools_used}",
        f"- warnings: {warnings}",
        f"- usage: {usage}",
        f"- input: {input_text or '-'}",
        f"- instructions: {instructions or '-'}",
        f"- output: {output_text or '-'}",
        f"- input_items: {input_items_count if input_items_count is not None else '-'}",
        output_items_label,
        "Tip: add --json for the full report.",
    ]
    return "\n".join(lines)


async def inspect_agent_run_cmd(
    state: SessionState,
    cmd: InspectAgentRunCmd,
) -> tuple[SessionState, str | None]:
    """Inspect an agent_run report stored in the artifact vault."""
    try:
        report = await load_agent_run_report(
            store=session_store(),
            artifact_id=cmd.report_id,
        )
    except (DatabaseError, FilesystemError, ValidationError) as exc:
        return state, f"Inspect: failed to load agent_run report ({exc})."
    if report is None:
        return state, f"Inspect: no agent_run report with id {cmd.report_id!r}."
    if cmd.json_output:
        return state, dumps_pretty(
            report,
            sort_keys=True,
            ensure_ascii=False,
            context="inspect.agent_run.report",
        )
    return state, _format_agent_run_report(cmd.report_id, report)


__all__ = ("inspect_agent_run_cmd",)
