"""Builders for REPL SessionState."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.include import DEFAULT_RESPONSE_INCLUDE
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.types import SessionState, SessionToolsState, SessionUiState
from agenterm.workflow.run.build_state import ConfigInputs, build_config_bundle

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.model import AppConfig
    from agenterm.core.choices.approvals import ApprovalMode
    from agenterm.core.tool_selection import ToolCatalog, ToolSelection


@dataclass(frozen=True)
class ReplConfigInputs:
    """Flag-derived inputs required to build REPL state."""

    config: Path | None
    agent_name: str | None
    model: str | None
    no_tools: bool
    trace_enabled: bool | None
    trace_id: str | None
    trace_group: str | None
    trace_metadata: list[str] | None
    store_override: bool | None
    approvals_mode: ApprovalMode | None
    allow_dangerous: bool


@dataclass(frozen=True)
class InitialStateInputs:
    """Inputs required to assemble the initial SessionState."""

    cfg: AppConfig
    tools_enabled: bool
    tools: ToolCatalog
    selection: ToolSelection
    include_base: tuple[str, ...]
    config_path: Path | None
    approvals_mode: ApprovalMode


def build_initial_state(inputs: InitialStateInputs) -> SessionState:
    """Construct the initial SessionState from config and CLI flags."""
    sel = inputs.selection
    tools = inputs.tools
    ux = inputs.cfg.repl.ux
    ui = inputs.cfg.repl.ui
    return SessionState(
        cfg=inputs.cfg,
        config_path=inputs.config_path,
        ui=SessionUiState(
            render_markdown=bool(ux.markdown),
            verbosity=ux.verbosity,
            stream_mode=ux.stream,
            reasoning_mode=ux.reasoning,
            reasoning_summary_max_chars=ux.reasoning_summary_max_chars,
            diffs_mode=ux.diffs,
            theme=ui.theme,
            color_depth=ui.color_depth,
            editing_mode=ui.editing_mode,
            mouse=bool(ui.mouse),
            completion=ui.completion,
        ),
        tools=SessionToolsState(
            enabled=bool(inputs.tools_enabled),
            tools_map=tools.tools_map or {},
            bundles_map=tools.bundles_map or {},
            default_bundles=list(tools.default_bundles or []),
            selection=sel,
            include_base=inputs.include_base,
            startup_selection=sel,
        ),
        approvals=ApprovalsContext(mode=inputs.approvals_mode),
    )


def build_repl_state_from_flags(
    inputs: ReplConfigInputs,
) -> SessionState:
    """Build a fully-initialized SessionState from CLI flags and config."""
    cfg_bundle = build_config_bundle(
        ConfigInputs(
            config=inputs.config,
            agent_name=inputs.agent_name,
            model=inputs.model,
            trace_enabled=inputs.trace_enabled,
            trace_id=inputs.trace_id,
            trace_group=inputs.trace_group,
            trace_metadata=inputs.trace_metadata,
            store_override=inputs.store_override,
            allow_dangerous=inputs.allow_dangerous,
            hosted_mode=False,
            background_flag=None,
            tool_select=None,
        ),
    )
    cfg_upd = cfg_bundle.cfg
    tools_ctx = cfg_bundle.tools
    sel = cfg_bundle.selection
    include_base = tuple(str(k) for k in DEFAULT_RESPONSE_INCLUDE)
    approvals_mode = (
        inputs.approvals_mode
        if inputs.approvals_mode is not None
        else cfg_upd.repl.approvals.mode
    )
    initial_inputs = InitialStateInputs(
        cfg=cfg_upd,
        tools_enabled=not bool(inputs.no_tools),
        tools=tools_ctx,
        selection=sel,
        include_base=include_base,
        config_path=cfg_bundle.config_path,
        approvals_mode=approvals_mode,
    )
    return build_initial_state(initial_inputs)


__all__ = (
    "InitialStateInputs",
    "ReplConfigInputs",
    "build_initial_state",
    "build_repl_state_from_flags",
)
