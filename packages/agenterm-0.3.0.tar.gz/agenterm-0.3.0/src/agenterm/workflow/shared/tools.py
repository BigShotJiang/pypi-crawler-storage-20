"""Tool selection and context assembly shared by run and REPL builders."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.tools_catalog import build_tool_catalog_from_config
from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.model_id import model_plane
from agenterm.core.tool_selection import (
    ToolCatalog,
    ToolSelection,
    filter_selection_specs,
    resolve_selection,
    selection_from_flags,
    split_cli_selection_tokens,
)

if TYPE_CHECKING:
    from agenterm.config.model import AppConfig
    from agenterm.core.toolspec import ToolSpec


def build_tools_context(
    cfg: AppConfig,
    *,
    tool_select: list[str] | None,
    allow_dangerous: bool,
    hosted_mode: bool,
) -> tuple[ToolCatalog, ToolSelection, list[ToolSpec] | None]:
    """Derive tool metadata and selection for a session or run."""
    tools_map, bundles_map, default_bundles = build_tool_catalog_from_config(cfg)
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(default_bundles),
    )
    cli_bundles: list[str] | None = None
    cli_keys: list[str] | None = None
    if tool_select is not None:
        cli_bundles, cli_keys = split_cli_selection_tokens(
            tool_select,
            catalog=catalog,
        )
    sel = selection_from_flags(
        default_bundles=catalog.default_bundles,
        cli_bundles=cli_bundles,
        cli_keys=cli_keys,
    )
    resolved = resolve_selection(sel, catalog=catalog)
    if resolved.error is not None:
        raise ConfigError(resolved.error)
    selected = resolved.specs
    if selected:
        plane = model_plane(cfg.agent.model)
        try:
            selected = filter_selection_specs(
                selected,
                allow_dangerous=allow_dangerous,
                hosted_mode=hosted_mode,
                model_plane=plane,
            )
        except ValidationError as exc:
            raise ConfigError(str(exc)) from exc
    return catalog, sel, list(selected) if selected else None


__all__ = ("build_tools_context",)
