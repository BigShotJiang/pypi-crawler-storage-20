"""Config-file helpers used by edges (CLI/REPL)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.config.runtime import load_app_config

if TYPE_CHECKING:
    from pathlib import Path

    from agenterm.config.model import AppConfig


def load_base_config(
    path: Path | None,
    *,
    agent_name: str | None = None,
) -> AppConfig:
    """Load and validate the base AppConfig.

    This helper does not print or exit; callers (edges) are responsible for
    mapping config errors into their user-facing envelopes.
    """
    return load_app_config(path, agent_name=agent_name)


__all__ = ("load_base_config",)
