"""Shared helpers for per-run status persistence."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.model_id import model_plane
from agenterm.store.history import history_store
from agenterm.store.runs.repo import (
    insert_run_start,
    next_run_number,
    update_run_status,
)
from agenterm.store.session.service import current_branch_turn_number, session_store

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.runs.models import RunStatus
    from agenterm.workflow.run.model import RunExecutionContext


@dataclass(frozen=True)
class RunStatusHandle:
    """Handle for updating a persisted run status row."""

    store: AsyncStore
    run_id: str
    session_id: str
    branch_id: str
    run_number: int
    branch_turn_base: int | None


async def start_run_status(
    ctx: RunExecutionContext,
) -> RunStatusHandle | None:
    """Insert a running run record when a session is available."""
    session_id = ctx.session_id
    if not isinstance(session_id, str) or not session_id:
        return None
    branch_id = ctx.branch_id or "main"
    store = session_store()
    history = history_store()
    run_number = await next_run_number(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    branch_turn_base = await current_branch_turn_number(
        history,
        session_id=session_id,
        branch_id=branch_id,
    )
    record = await insert_run_start(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number,
        trace_id=ctx.cfg.run.trace_id,
    )
    return RunStatusHandle(
        store=store,
        run_id=record.run_id,
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number,
        branch_turn_base=branch_turn_base,
    )


async def start_compression_status(
    *,
    session_id: str,
    branch_id: str,
    trace_id: str | None,
) -> RunStatusHandle:
    """Insert a running run record for a compression-only workflow."""
    store = session_store()
    history = history_store()
    run_number = await next_run_number(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    branch_turn_base = await current_branch_turn_number(
        history,
        session_id=session_id,
        branch_id=branch_id,
    )
    record = await insert_run_start(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number,
        trace_id=trace_id,
    )
    return RunStatusHandle(
        store=store,
        run_id=record.run_id,
        session_id=session_id,
        branch_id=branch_id,
        run_number=run_number,
        branch_turn_base=branch_turn_base,
    )


async def update_run_status_record(
    handle: RunStatusHandle | None,
    *,
    status: RunStatus,
    response_id: str | None,
    error_json: Mapping[str, JSONValue] | None,
    branch_turn_start: int | None,
    branch_turn_end: int | None,
) -> None:
    """Update the persisted run status if a handle is present."""
    if handle is None:
        return
    await update_run_status(
        store=handle.store,
        run_id=handle.run_id,
        status=status,
        response_id=response_id,
        error_json=error_json,
        branch_turn_start=branch_turn_start,
        branch_turn_end=branch_turn_end,
    )


def error_envelope_json(
    exc: Exception,
    *,
    ctx: RunExecutionContext,
    operation: str,
) -> dict[str, JSONValue]:
    """Convert an exception into the canonical error envelope JSON."""
    provider_label = model_plane(ctx.cfg.agent.model)
    report = build_error_report(
        exc,
        context=ErrorContext(
            operation=operation,
            resource=ctx.workflow_name,
            trace_id=ctx.cfg.run.trace_id,
        ),
        extra_details={"provider": provider_label},
    )
    return report.to_envelope().to_json()


__all__ = (
    "RunStatusHandle",
    "error_envelope_json",
    "start_compression_status",
    "start_run_status",
    "update_run_status_record",
)
