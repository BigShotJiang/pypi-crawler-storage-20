"""Canonical agent-run execution workflows.

This package provides the single shared execution path for agent runs across:

- CLI `agenterm run` (streamed + background)
- REPL runs (streamed)

The workflows in this package own run orchestration and end-of-run invariants
(usage persistence, request ledger, and session metadata updates).
Surfaces provide rendering policy; execution/persistence semantics are shared.
"""

from __future__ import annotations

__all__ = ()
