"""Helpers for streamed run persistence and recorders."""

from __future__ import annotations

import asyncio
from dataclasses import replace
from typing import TYPE_CHECKING

from agenterm.constants.limits import (
    RUN_EVENT_BATCH_CLOSE_TIMEOUT_SECONDS,
    RUN_POSTPROCESS_TIMEOUT_SECONDS,
)
from agenterm.workflow.run.event_ledger import RunEventBatcher, RunEventRecorder
from agenterm.workflow.run.model import (
    RunExecutionContext,
    RunPostprocessResult,
    StreamedRunRequest,
)
from agenterm.workflow.run.postprocess import postprocess_run
from agenterm.workflow.run.status import RunStatusHandle, update_run_status_record
from agenterm.workflow.run.turn_attempts import TurnAttemptRecorder

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agents.result import RunResultStreaming

    from agenterm.core.json_types import JSONValue
    from agenterm.store.runs.models import RunStatus


def fallback_postprocess_result(
    *,
    streaming: RunResultStreaming,
    branch_id: str | None,
    run_number: int | None,
    emit_line: Callable[[str], None] | None,
    reason: str,
) -> RunPostprocessResult:
    """Return a minimal postprocess result and emit a warning when needed."""
    if emit_line is not None:
        emit_line(f"warn> {reason}")
    response_id = streaming.last_response_id
    if not isinstance(response_id, str):
        response_id = None
    return RunPostprocessResult(
        response_id=response_id,
        branch_id=branch_id,
        run_number=run_number,
        usage_total=None,
        usage_compact=None,
        last_request_input_tokens=None,
        last_request_count=None,
    )


async def close_event_batcher(
    event_batcher: RunEventBatcher | None,
    *,
    emit_line: Callable[[str], None] | None,
) -> None:
    """Flush and close the event batcher with a bounded timeout."""
    if event_batcher is None:
        return
    try:
        async with asyncio.timeout(RUN_EVENT_BATCH_CLOSE_TIMEOUT_SECONDS):
            await event_batcher.close()
    except TimeoutError:
        if emit_line is not None:
            emit_line("warn> Run event flush timed out; ledger may be incomplete.")


async def postprocess_streamed_run(
    *,
    streaming: RunResultStreaming,
    run_ctx: RunExecutionContext,
    request: StreamedRunRequest,
    handle: RunStatusHandle | None,
) -> RunPostprocessResult:
    """Run postprocess persistence with a timeout and fallback."""
    try:
        async with asyncio.timeout(RUN_POSTPROCESS_TIMEOUT_SECONDS):
            return await postprocess_run(
                streaming,
                session=run_ctx.session,
                session_id=run_ctx.session_id,
                branch_id=run_ctx.branch_id,
                store_enabled=run_ctx.store_enabled,
                model=run_ctx.cfg.agent.model,
                run_number=handle.run_number if handle is not None else None,
                emit_line=request.postprocess_emit_line,
            )
    except TimeoutError:
        return fallback_postprocess_result(
            streaming=streaming,
            branch_id=run_ctx.branch_id,
            run_number=handle.run_number if handle is not None else None,
            emit_line=request.postprocess_emit_line,
            reason="Run postprocess timed out; usage persistence was skipped.",
        )


async def update_run_status_safe(
    handle: RunStatusHandle | None,
    *,
    status: RunStatus,
    response_id: str | None,
    error_json: Mapping[str, JSONValue] | None,
    branch_turn_start: int | None,
    branch_turn_end: int | None,
    emit_line: Callable[[str], None] | None,
) -> None:
    """Update the run status record without blocking indefinitely."""
    try:
        async with asyncio.timeout(RUN_POSTPROCESS_TIMEOUT_SECONDS):
            await update_run_status_record(
                handle,
                status=status,
                response_id=response_id,
                error_json=error_json,
                branch_turn_start=branch_turn_start,
                branch_turn_end=branch_turn_end,
            )
    except TimeoutError:
        if emit_line is not None:
            emit_line("warn> Run status update timed out; run ledger may be stale.")


def apply_run_handle(
    ctx: RunExecutionContext,
    request: StreamedRunRequest,
    handle: RunStatusHandle | None,
) -> RunExecutionContext:
    """Propagate run handle identifiers to run refs and tool context."""
    if handle is not None and request.run_ref is not None:
        request.run_ref.run_id = handle.run_id
        request.run_ref.run_number = handle.run_number
        request.run_ref.session_id = handle.session_id
        request.run_ref.branch_id = handle.branch_id
    if handle is None or ctx.tool_context is None:
        return ctx
    return replace(
        ctx,
        tool_context=replace(
            ctx.tool_context,
            run_number=handle.run_number,
        ),
    )


async def build_run_recorders(
    *,
    handle: RunStatusHandle | None,
    run_ctx: RunExecutionContext,
    emit_line: Callable[[str], None] | None,
) -> tuple[RunEventBatcher | None, TurnAttemptRecorder | None]:
    """Construct the event batcher and turn attempt recorder for a run."""
    event_recorder = RunEventRecorder.from_status_handle(
        handle=handle,
        session_id=run_ctx.session_id,
        branch_id=run_ctx.branch_id,
        model=run_ctx.cfg.agent.model,
        trace_id=run_ctx.cfg.run.trace_id,
        emit_line=emit_line,
    )
    event_batcher = (
        RunEventBatcher(event_recorder) if event_recorder is not None else None
    )
    attempt_recorder = await TurnAttemptRecorder.from_status_handle(
        handle=handle,
        session_id=run_ctx.session_id,
        branch_id=run_ctx.branch_id,
        emit_line=emit_line,
    )
    return event_batcher, attempt_recorder


__all__ = (
    "apply_run_handle",
    "build_run_recorders",
    "close_event_batcher",
    "fallback_postprocess_result",
    "postprocess_streamed_run",
    "update_run_status_safe",
)
