"""Turn attempt ledger recording helpers."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import TYPE_CHECKING

from openai.types.responses.response_created_event import ResponseCreatedEvent

from agenterm.core.errors import ConfigError, DatabaseError
from agenterm.core.response_items import serialize_input_item
from agenterm.store.turn_attempts import (
    clear_turn_attempt,
    insert_turn_attempt_item,
    mark_turn_attempt_cancelled,
    start_turn_attempt,
)
from agenterm.workflow.run.postprocess_store import warn_or_raise_store_error
from agenterm.workflow.run.spool import (
    RunIdentity,
    append_turn_attempt_items,
    append_turn_attempt_status,
    start_turn_attempt_spool,
)

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from agents.items import RunItem, TResponseStreamEvent

    from agenterm.core.json_types import JSONMapping, JSONValue
    from agenterm.store.async_db import AsyncStore
    from agenterm.workflow.run.status import RunStatusHandle


@dataclass
class TurnAttemptRecorder:
    """Persist in-flight turn items for cancelled run recovery."""

    store: AsyncStore
    run_id: str | None
    session_id: str
    branch_id: str
    run_number: int
    emit_line: Callable[[str], None] | None

    _started: bool = False
    _item_seq: int = 0
    _spool_path: Path | None = None

    @classmethod
    async def from_status_handle(
        cls,
        *,
        handle: RunStatusHandle | None,
        session_id: str | None,
        branch_id: str | None,
        emit_line: Callable[[str], None] | None,
    ) -> TurnAttemptRecorder | None:
        """Build and initialize a recorder for the active run, if possible."""
        if handle is None:
            return None
        if not isinstance(session_id, str) or not session_id:
            return None
        branch = branch_id or "main"
        recorder = cls(
            store=handle.store,
            run_id=handle.run_id,
            session_id=session_id,
            branch_id=branch,
            run_number=handle.run_number,
            emit_line=emit_line,
        )
        await recorder.reset()
        return recorder

    def _spool_item_record(
        self,
        *,
        item_seq: int,
        item_type: str,
        item: JSONMapping,
        seen_by_model: bool,
    ) -> dict[str, JSONValue]:
        return {
            "schema_version": 1,
            "kind": "turn_attempt",
            "record_type": "item",
            "item_seq": int(item_seq),
            "item_type": str(item_type),
            "item": dict(item),
            "seen_by_model": bool(seen_by_model),
        }

    async def _ensure_spool(self, *, exc: Exception) -> Path:
        if self._spool_path is None:
            run = RunIdentity(
                run_id=self.run_id,
                session_id=self.session_id,
                branch_id=self.branch_id,
                run_number=self.run_number,
            )
            self._spool_path = await start_turn_attempt_spool(
                store=self.store,
                run=run,
                emit_line=self.emit_line,
            )
            if self.emit_line is not None:
                self.emit_line(
                    "warn> Turn attempt persistence failed; spooling to "
                    f"{self._spool_path}: {exc}"
                )
        return self._spool_path

    async def reset(self) -> None:
        """Initialize or reset the attempt ledger for this run."""
        if self._spool_path is not None:
            self._started = False
            self._item_seq = 0
            return
        try:
            await start_turn_attempt(
                store=self.store,
                session_id=self.session_id,
                branch_id=self.branch_id,
                run_number=self.run_number,
            )
        except ConfigError:
            raise
        except (OSError, sqlite3.Error, DatabaseError) as exc:
            warn_or_raise_store_error(
                exc,
                emit_line=self.emit_line,
                context="Failed to initialize turn attempt ledger",
            )
            await self._ensure_spool(exc=exc)
            return
        self._started = False
        self._item_seq = 0

    async def record_raw_event(self, event: TResponseStreamEvent) -> None:
        """Observe raw response events for request boundaries."""
        if not isinstance(event, ResponseCreatedEvent):
            return
        if self._started:
            await self.reset()
        else:
            self._started = True

    async def record_run_item(self, item: RunItem) -> None:
        """Record a new run item as unseen-by-model input."""
        try:
            input_item = item.to_input_item()
            payload = serialize_input_item(
                input_item,
                context="turn_attempt.item",
            )
        except ConfigError as exc:
            warn_or_raise_store_error(
                exc,
                emit_line=self.emit_line,
                context="Failed to serialize turn attempt item",
            )
            return
        item_type = payload.get("type")
        item_type_str = item_type if isinstance(item_type, str) else str(item.type)
        if self._spool_path is not None:
            record = self._spool_item_record(
                item_seq=self._item_seq,
                item_type=item_type_str,
                item=payload,
                seen_by_model=False,
            )
            await append_turn_attempt_items(path=self._spool_path, items=[record])
            self._item_seq += 1
            return
        try:
            await insert_turn_attempt_item(
                store=self.store,
                session_id=self.session_id,
                branch_id=self.branch_id,
                run_number=self.run_number,
                item_seq=self._item_seq,
                item_type=item_type_str,
                item=payload,
                seen_by_model=False,
            )
        except ConfigError:
            raise
        except (OSError, sqlite3.Error, DatabaseError) as exc:
            warn_or_raise_store_error(
                exc,
                emit_line=self.emit_line,
                context="Failed to persist turn attempt item",
            )
            path = await self._ensure_spool(exc=exc)
            record = self._spool_item_record(
                item_seq=self._item_seq,
                item_type=item_type_str,
                item=payload,
                seen_by_model=False,
            )
            await append_turn_attempt_items(path=path, items=[record])
            return
        self._item_seq += 1

    async def mark_cancelled(self, *, reason: str | None) -> None:
        """Mark this turn attempt as cancelled."""
        if self._spool_path is not None:
            await append_turn_attempt_status(
                path=self._spool_path,
                status="cancelled",
                cancel_reason=reason,
            )
            return
        try:
            await mark_turn_attempt_cancelled(
                store=self.store,
                session_id=self.session_id,
                branch_id=self.branch_id,
                run_number=self.run_number,
                cancel_reason=reason,
            )
        except ConfigError:
            raise
        except (OSError, sqlite3.Error, DatabaseError) as exc:
            warn_or_raise_store_error(
                exc,
                emit_line=self.emit_line,
                context="Failed to mark turn attempt cancelled",
            )
            path = await self._ensure_spool(exc=exc)
            await append_turn_attempt_status(
                path=path,
                status="cancelled",
                cancel_reason=reason,
            )

    async def finalize_completed(self) -> None:
        """Clear the attempt ledger on successful completion."""
        if self._spool_path is not None:
            return
        try:
            await clear_turn_attempt(
                store=self.store,
                session_id=self.session_id,
                branch_id=self.branch_id,
                run_number=self.run_number,
            )
        except ConfigError:
            raise
        except (OSError, sqlite3.Error, DatabaseError) as exc:
            warn_or_raise_store_error(
                exc,
                emit_line=self.emit_line,
                context="Failed to clear turn attempt ledger",
            )
            await self._ensure_spool(exc=exc)


__all__ = ("TurnAttemptRecorder",)
