"""Streaming event consumption helpers."""

from __future__ import annotations

import asyncio
from contextlib import suppress
from typing import TYPE_CHECKING, Protocol

from agents.stream_events import (
    RawResponsesStreamEvent,
    RunItemStreamEvent,
    StreamEvent,
)
from openai.types.responses.response_reasoning_summary_text_delta_event import (
    ResponseReasoningSummaryTextDeltaEvent,
)
from openai.types.responses.response_text_delta_event import ResponseTextDeltaEvent

from agenterm.core.errors import OperationTimeoutError

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable

    from agents.items import RunItem, TResponseStreamEvent
    from agents.result import RunResultStreaming

    from agenterm.workflow.run.model import RunRef, StreamEventCallbacks


class RawEventRecorder(Protocol):
    """Protocol for run event ledger sinks."""

    async def record_raw_event(self, event: TResponseStreamEvent) -> None:
        """Persist a raw Responses stream event."""


class AttemptRecorder(Protocol):
    """Protocol for turn attempt ledger sinks."""

    async def record_raw_event(self, event: TResponseStreamEvent) -> None:
        """Persist a raw Responses stream event."""

    async def record_run_item(self, item: RunItem) -> None:
        """Persist a completed run item."""


_SKIP_RAW_EVENT_TYPES: frozenset[str] = frozenset(
    {
        "response.output_text.delta",
        "response.output_text.done",
        "response.reasoning_summary_text.delta",
    },
)

_STREAM_CANCEL_TIMEOUT_SECONDS = 10.0
_STREAM_CANCEL_JOIN_SECONDS = 1.0


def _handle_raw_event(
    data: TResponseStreamEvent,
    *,
    stream_text_deltas: bool,
    on_text_delta: Callable[[str], None] | None,
    on_reasoning_summary_delta: Callable[[str], None] | None,
    on_raw_event_type: Callable[[str], None] | None,
) -> tuple[bool, bool]:
    saw_text = False
    saw_reasoning = False
    if (
        stream_text_deltas
        and on_text_delta is not None
        and isinstance(data, ResponseTextDeltaEvent)
    ):
        delta = data.delta
        if delta:
            on_text_delta(delta)
            saw_text = True
    elif (
        stream_text_deltas
        and on_reasoning_summary_delta is not None
        and isinstance(data, ResponseReasoningSummaryTextDeltaEvent)
    ):
        delta = data.delta
        if delta:
            on_reasoning_summary_delta(delta)
            saw_reasoning = True
    elif on_raw_event_type is not None:
        type_str = data.type
        if type_str not in _SKIP_RAW_EVENT_TYPES:
            on_raw_event_type(type_str)
    return saw_text, saw_reasoning


def handle_raw_event_for_test(
    data: TResponseStreamEvent,
    *,
    stream_text_deltas: bool,
    on_text_delta: Callable[[str], None] | None,
    on_reasoning_summary_delta: Callable[[str], None] | None,
    on_raw_event_type: Callable[[str], None] | None,
) -> tuple[bool, bool]:
    """Public wrapper for testing raw event handling behavior."""
    return _handle_raw_event(
        data,
        stream_text_deltas=stream_text_deltas,
        on_text_delta=on_text_delta,
        on_reasoning_summary_delta=on_reasoning_summary_delta,
        on_raw_event_type=on_raw_event_type,
    )


def _process_stream_event(
    event: StreamEvent,
    *,
    callbacks: StreamEventCallbacks,
    stream_text_deltas: bool,
    run_ref: RunRef | None,
) -> tuple[bool, bool]:
    if run_ref is not None and run_ref.suppress_output:
        return False, False
    if isinstance(event, RawResponsesStreamEvent):
        return _handle_raw_event(
            event.data,
            stream_text_deltas=stream_text_deltas,
            on_text_delta=callbacks.on_text_delta,
            on_reasoning_summary_delta=callbacks.on_reasoning_summary_delta,
            on_raw_event_type=callbacks.on_raw_event_type,
        )
    if isinstance(event, RunItemStreamEvent):
        if callbacks.on_run_item is not None:
            callbacks.on_run_item(event.item)
        return False, False
    if callbacks.on_agent_updated is not None:
        callbacks.on_agent_updated(event.new_agent)
    return False, False


def _cancel_stream_on_timeout(
    streaming: RunResultStreaming,
    *,
    run_ref: RunRef | None,
) -> None:
    if run_ref is not None:
        run_ref.request_cancel(mode="immediate", suppress_output=True, reason="timeout")
        return
    streaming.cancel(mode="immediate")


def _finalize_stream_deltas(
    *,
    callbacks: StreamEventCallbacks,
    stream_text_deltas: bool,
    run_ref: RunRef | None,
    saw_text_delta: bool,
    saw_reasoning_delta: bool,
) -> None:
    if run_ref is not None and run_ref.suppress_output:
        return
    if stream_text_deltas and saw_text_delta and callbacks.on_text_delta is not None:
        callbacks.on_text_delta("\n")
    if (
        stream_text_deltas
        and saw_reasoning_delta
        and callbacks.on_reasoning_summary_delta is not None
    ):
        callbacks.on_reasoning_summary_delta("\n")


async def _drain_stream_after_cancel(streaming: RunResultStreaming) -> None:
    with suppress(asyncio.CancelledError, TimeoutError):
        async with asyncio.timeout(_STREAM_CANCEL_TIMEOUT_SECONDS):
            async for _ in streaming.stream_events():
                pass


async def _next_stream_event_or_cancel(
    stream_iter: AsyncIterator[StreamEvent],
    *,
    streaming: RunResultStreaming,
    run_ref: RunRef | None,
    idle_timeout_seconds: float | None,
) -> tuple[StreamEvent | None, bool]:
    cancel_task: asyncio.Task[None] | None = None

    async def _next_event() -> StreamEvent:
        return await stream_iter.__anext__()

    event_task: asyncio.Task[StreamEvent] = asyncio.create_task(_next_event())
    tasks: set[asyncio.Task[object]] = {event_task}
    if run_ref is not None:
        cancel_task = asyncio.create_task(run_ref.cancel_token.wait())
        tasks.add(cancel_task)
    done, pending = await asyncio.wait(
        tasks,
        timeout=idle_timeout_seconds,
        return_when=asyncio.FIRST_COMPLETED,
    )
    if not done:
        for task in pending:
            task.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        _cancel_stream_on_timeout(streaming, run_ref=run_ref)
        await _drain_stream_after_cancel(streaming)
        msg = f"Stream idle timeout after {idle_timeout_seconds} seconds without events"
        raise OperationTimeoutError(msg)
    if cancel_task is not None and cancel_task in done:
        event_task.cancel()
        with suppress(asyncio.CancelledError, StopAsyncIteration, TimeoutError):
            async with asyncio.timeout(_STREAM_CANCEL_JOIN_SECONDS):
                await event_task
        await _drain_stream_after_cancel(streaming)
        return None, True
    if cancel_task is not None:
        cancel_task.cancel()
    try:
        event: StreamEvent = await event_task
    except StopAsyncIteration:
        return None, False
    return event, False


async def consume_stream_events_with_idle_timeout(
    streaming: RunResultStreaming,
    *,
    callbacks: StreamEventCallbacks,
    stream_text_deltas: bool,
    run_ref: RunRef | None,
    idle_timeout_seconds: float | None,
    event_recorder: RawEventRecorder | None = None,
    attempt_recorder: AttemptRecorder | None = None,
) -> None:
    """Consume stream events, enforcing a no-events idle timeout when configured."""
    saw_text_delta = False
    saw_reasoning_delta = False
    stream_iter = streaming.stream_events()
    while True:
        event, cancelled = await _next_stream_event_or_cancel(
            stream_iter,
            streaming=streaming,
            run_ref=run_ref,
            idle_timeout_seconds=idle_timeout_seconds,
        )
        if cancelled:
            return
        if event is None:
            break
        if isinstance(event, RawResponsesStreamEvent):
            if event_recorder is not None:
                await event_recorder.record_raw_event(event.data)
            if attempt_recorder is not None:
                await attempt_recorder.record_raw_event(event.data)
        saw_text, saw_reasoning = _process_stream_event(
            event,
            callbacks=callbacks,
            stream_text_deltas=stream_text_deltas,
            run_ref=run_ref,
        )
        if attempt_recorder is not None and isinstance(event, RunItemStreamEvent):
            await attempt_recorder.record_run_item(event.item)
        saw_text_delta = saw_text_delta or saw_text
        saw_reasoning_delta = saw_reasoning_delta or saw_reasoning
    _finalize_stream_deltas(
        callbacks=callbacks,
        stream_text_deltas=stream_text_deltas,
        run_ref=run_ref,
        saw_text_delta=saw_text_delta,
        saw_reasoning_delta=saw_reasoning_delta,
    )


__all__ = (
    "AttemptRecorder",
    "RawEventRecorder",
    "consume_stream_events_with_idle_timeout",
    "handle_raw_event_for_test",
)
