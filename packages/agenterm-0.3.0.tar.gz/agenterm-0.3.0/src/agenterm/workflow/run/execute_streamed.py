"""Streamed agent-run execution (single-path orchestration)."""

from __future__ import annotations

import asyncio
import sqlite3
from contextlib import asynccontextmanager
from dataclasses import replace
from typing import TYPE_CHECKING

import httpx
from agents.exceptions import AgentsException, MaxTurnsExceeded
from openai import APIError

from agenterm.core.errors import AgentermError, OperationTimeoutError, PipelineError
from agenterm.core.model_id import model_plane
from agenterm.core.retry import RetryDecision, RetryNotice, retry_async
from agenterm.engine.mcp_bridge import wrap_mcp_servers
from agenterm.engine.mcp_function_tools import (
    build_mcp_function_tools,
    merge_mcp_function_tools,
)
from agenterm.engine.mcp_pool import McpServerPool
from agenterm.engine.result_summary import extract_final_text
from agenterm.engine.run import run_streamed
from agenterm.engine.tool_output_clamp import ToolOutputClamp
from agenterm.store.history import history_store
from agenterm.store.session.service import current_branch_turn_number
from agenterm.workflow.run.model import (
    RunExecutionContext,
    RunRef,
    StreamedRunRequest,
    StreamedRunResult,
)
from agenterm.workflow.run.pipeline import RunPipelinePlan, build_run_pipeline
from agenterm.workflow.run.postprocess import (
    postprocess_cancelled_run,
)
from agenterm.workflow.run.resume import apply_resume
from agenterm.workflow.run.retry_policy import (
    provider_retry_decision,
    provider_retry_exceptions,
    provider_retry_notice,
    retry_policy_from_config,
)
from agenterm.workflow.run.status import (
    RunStatusHandle,
    error_envelope_json,
    start_run_status,
    update_run_status_record,
)
from agenterm.workflow.run.stream_events import (
    RawEventRecorder,
    consume_stream_events_with_idle_timeout,
    handle_raw_event_for_test,
)
from agenterm.workflow.run.streamed_helpers import (
    apply_run_handle,
    build_run_recorders,
    close_event_batcher,
    postprocess_streamed_run,
    update_run_status_safe,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from agents.items import TResponseInputItem
    from agents.result import RunResultStreaming

    from agenterm.config.model import AppConfig
    from agenterm.workflow.run.turn_attempts import TurnAttemptRecorder


@asynccontextmanager
async def _lease_mcp_pool(
    cfg: AppConfig,
    *,
    existing_pool: McpServerPool | None,
) -> AsyncIterator[McpServerPool | None]:
    if existing_pool is not None:
        yield existing_pool
        return
    async with McpServerPool.from_config(cfg) as pool:
        yield pool


def _set_run_ref(run_ref: RunRef | None, streaming: RunResultStreaming) -> None:
    if run_ref is None:
        return
    run_ref.streaming = streaming
    if run_ref.cancel_mode is not None:
        run_ref.streaming.cancel(mode=run_ref.cancel_mode)


def _cancelled_by_user(run_ref: RunRef | None) -> bool:
    return run_ref is not None and run_ref.cancel_reason == "user"


_RUN_FAILURE_EXCEPTIONS: tuple[type[Exception], ...] = (
    AgentermError,
    AgentsException,
    APIError,
    httpx.HTTPError,
    sqlite3.Error,
    OSError,
)


async def _compute_branch_turn_range(
    handle: RunStatusHandle | None,
) -> tuple[int | None, int | None]:
    if handle is None:
        return None, None
    store = history_store()
    branch_turn_end = await current_branch_turn_number(
        store,
        session_id=handle.session_id,
        branch_id=handle.branch_id,
    )
    base = handle.branch_turn_base
    if base is None or branch_turn_end <= base:
        return None, None
    return base + 1, branch_turn_end


async def _finalize_user_cancelled_run(
    *,
    streaming: RunResultStreaming,
    run_ctx: RunExecutionContext,
    request: StreamedRunRequest,
    handle: RunStatusHandle | None,
) -> StreamedRunResult:
    post = await postprocess_cancelled_run(
        session_id=run_ctx.session_id,
        branch_id=run_ctx.branch_id,
        store_enabled=run_ctx.store_enabled,
        run_number=handle.run_number if handle is not None else None,
        emit_line=request.postprocess_emit_line,
    )
    response_id = (
        streaming.last_response_id
        if isinstance(streaming.last_response_id, str)
        else None
    )
    branch_turn_start, branch_turn_end = await _compute_branch_turn_range(handle)
    await update_run_status_record(
        handle,
        status="cancelled",
        response_id=response_id,
        error_json=None,
        branch_turn_start=branch_turn_start,
        branch_turn_end=branch_turn_end,
    )
    return StreamedRunResult(
        streaming=streaming,
        last_agent=streaming.last_agent,
        final_text=extract_final_text(streaming) or "",
        post=post,
    )


async def _handle_streamed_run_error(
    exc: BaseException,
    *,
    attempt_recorder: TurnAttemptRecorder | None,
    handle: RunStatusHandle | None,
    run_ctx: RunExecutionContext,
) -> None:
    if isinstance(exc, MaxTurnsExceeded):
        if attempt_recorder is not None:
            await attempt_recorder.finalize_completed()
        status = "failed"
        error_json = error_envelope_json(
            exc,
            ctx=run_ctx,
            operation="run.streamed",
        )
    elif isinstance(exc, asyncio.CancelledError):
        if attempt_recorder is not None:
            await attempt_recorder.mark_cancelled(reason="user")
        status = "cancelled"
        error_json = None
    else:
        if attempt_recorder is not None:
            reason = "timeout" if isinstance(exc, OperationTimeoutError) else "error"
            await attempt_recorder.mark_cancelled(reason=reason)
        status = "timeout" if isinstance(exc, OperationTimeoutError) else "failed"
        if not isinstance(exc, Exception):
            raise exc
        error_json = error_envelope_json(
            exc,
            ctx=run_ctx,
            operation="run.streamed",
        )
    branch_turn_start, branch_turn_end = await _compute_branch_turn_range(handle)
    await update_run_status_record(
        handle,
        status=status,
        response_id=None,
        error_json=error_json,
        branch_turn_start=branch_turn_start,
        branch_turn_end=branch_turn_end,
    )


async def _run_stream_and_finalize(
    run_ctx: RunExecutionContext,
    request: StreamedRunRequest,
    plan: RunPipelinePlan,
    *,
    event_recorder: RawEventRecorder | None,
    attempt_recorder: TurnAttemptRecorder | None,
    handle: RunStatusHandle | None,
) -> StreamedRunResult:
    streaming = await _execute_streamed_run_with_retries(
        run_ctx,
        request,
        plan,
        event_recorder=event_recorder,
        attempt_recorder=attempt_recorder,
    )
    if _cancelled_by_user(request.run_ref):
        if attempt_recorder is not None:
            await attempt_recorder.mark_cancelled(reason="user")
        return await _finalize_user_cancelled_run(
            streaming=streaming,
            run_ctx=run_ctx,
            request=request,
            handle=handle,
        )
    if attempt_recorder is not None:
        await attempt_recorder.finalize_completed()
    post = await postprocess_streamed_run(
        streaming=streaming,
        run_ctx=run_ctx,
        request=request,
        handle=handle,
    )
    result = StreamedRunResult(
        streaming=streaming,
        last_agent=streaming.last_agent,
        final_text=extract_final_text(streaming) or "",
        post=post,
    )
    branch_turn_start, branch_turn_end = await _compute_branch_turn_range(handle)
    await update_run_status_safe(
        handle,
        status="completed",
        response_id=result.post.response_id,
        error_json=None,
        branch_turn_start=branch_turn_start,
        branch_turn_end=branch_turn_end,
        emit_line=request.postprocess_emit_line,
    )
    return result


async def _run_once(
    ctx: RunExecutionContext,
    request: StreamedRunRequest,
    plan: RunPipelinePlan,
    *,
    input_items: str | list[TResponseInputItem],
    event_recorder: RawEventRecorder | None,
    attempt_recorder: TurnAttemptRecorder | None,
) -> RunResultStreaming:
    async with _lease_mcp_pool(ctx.cfg, existing_pool=ctx.mcp_pool) as pool:
        servers = pool.servers if pool is not None else []
        plane = model_plane(ctx.cfg.agent.model)
        output_clamp = ToolOutputClamp(ctx.cfg.tools.max_chars)
        cancel_token = ctx.tool_context.cancel_token if ctx.tool_context else None
        if servers and plane == "gateway":
            mcp_tools = await build_mcp_function_tools(
                servers=servers,
                approvals=ctx.approvals.mcp,
                bridge_cfg=ctx.cfg.mcp.bridge,
                output_clamp=output_clamp,
                convert_schemas_to_strict=ctx.cfg.mcp.convert_schemas_to_strict,
                run_context=ctx.tool_context,
                agent=ctx.agent,
            )
            tools = merge_mcp_function_tools(
                existing_tools=list(ctx.agent.tools),
                mcp_tools=mcp_tools,
            )
            agent = ctx.agent.clone(tools=tools, mcp_servers=[])
        else:
            if servers:
                servers = wrap_mcp_servers(
                    servers,
                    approvals=ctx.approvals.mcp,
                    bridge_cfg=ctx.cfg.mcp.bridge,
                    output_clamp=output_clamp,
                    cancel_token=cancel_token,
                )
            agent = ctx.agent.clone(mcp_servers=servers)
        streaming = run_streamed(agent, input_items, opts=plan.run_options)
        _set_run_ref(request.run_ref, streaming)

        await consume_stream_events_with_idle_timeout(
            streaming,
            callbacks=request.callbacks,
            stream_text_deltas=(request.stream_mode == "live"),
            run_ref=request.run_ref,
            idle_timeout_seconds=ctx.cfg.run.timeout_seconds,
            event_recorder=event_recorder,
            attempt_recorder=attempt_recorder,
        )
    return streaming


async def _execute_streamed_run_with_retries(
    ctx: RunExecutionContext,
    request: StreamedRunRequest,
    plan: RunPipelinePlan,
    *,
    event_recorder: RawEventRecorder | None,
    attempt_recorder: TurnAttemptRecorder | None,
) -> RunResultStreaming:
    """Execute a streamed run with retry handling."""
    input_items = request.input_items
    policy_cfg = request.retry_policy or ctx.cfg.retries.provider
    policy = retry_policy_from_config(policy_cfg)
    retry_on = provider_retry_exceptions()

    async def _call() -> RunResultStreaming:
        return await _run_once(
            ctx,
            request,
            plan,
            input_items=input_items,
            event_recorder=event_recorder,
            attempt_recorder=attempt_recorder,
        )

    def _classify(exc: Exception) -> RetryDecision:
        return provider_retry_decision(exc)

    def _on_retry(notice: RetryNotice) -> None:
        if request.retry_emit_line is None:
            return
        request.retry_emit_line(provider_retry_notice(notice))

    try:
        return await retry_async(
            _call,
            policy=policy,
            retry_on=retry_on,
            classify=_classify,
            on_retry=_on_retry,
        )
    except retry_on as exc:
        msg = "streamed agent run failed"
        raise PipelineError(msg) from exc
    except (TypeError, ValueError) as exc:
        msg = "streamed agent run failed"
        raise PipelineError(msg) from exc


async def execute_streamed_run(
    ctx: RunExecutionContext,
    request: StreamedRunRequest,
) -> StreamedRunResult:
    """Execute a streamed agent run and fully consume the event stream.

    Retries apply only to transient transport/status errors with exponential
    backoff + jitter, honoring Retry-After when present.
    """
    handle = await start_run_status(ctx)
    run_ctx = apply_run_handle(ctx, request, handle)
    input_items, _resumed = await apply_resume(
        run_ctx,
        request.input_items,
        emit_line=request.postprocess_emit_line,
    )
    request = replace(request, input_items=input_items)
    event_batcher, attempt_recorder = await build_run_recorders(
        handle=handle,
        run_ctx=run_ctx,
        emit_line=request.postprocess_emit_line,
    )
    plan = build_run_pipeline(
        run_ctx,
        background=False,
        emit_line=request.postprocess_emit_line,
    )
    try:
        result = await _run_stream_and_finalize(
            run_ctx,
            request,
            plan,
            event_recorder=event_batcher,
            attempt_recorder=attempt_recorder,
            handle=handle,
        )
    except asyncio.CancelledError as exc:
        await _handle_streamed_run_error(
            exc,
            attempt_recorder=attempt_recorder,
            handle=handle,
            run_ctx=run_ctx,
        )
        raise
    except _RUN_FAILURE_EXCEPTIONS as exc:
        await _handle_streamed_run_error(
            exc,
            attempt_recorder=attempt_recorder,
            handle=handle,
            run_ctx=run_ctx,
        )
        raise
    finally:
        await close_event_batcher(
            event_batcher,
            emit_line=request.postprocess_emit_line,
        )
    return result


__all__ = ("execute_streamed_run", "handle_raw_event_for_test")
