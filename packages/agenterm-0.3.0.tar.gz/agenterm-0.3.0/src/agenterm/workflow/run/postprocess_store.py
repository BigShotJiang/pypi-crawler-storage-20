"""Store persistence helpers for run postprocessing."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from agenterm.core.errors import AgentermError, ConfigError, DatabaseError
from agenterm.store.branch.repo import update_branch_store

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.store.async_db import AsyncStore


def warn_or_raise_store_error(
    exc: Exception,
    *,
    emit_line: Callable[[str], None] | None,
    context: str,
) -> None:
    """Emit a warning or raise for store persistence failures."""
    if emit_line is not None:
        emit_line(f"warn> {context}: {exc}")
        return
    msg = f"{context}: {exc}"
    raise AgentermError(msg) from exc


async def persist_branch_store(
    *,
    store: AsyncStore | None,
    session_id: str | None,
    branch_id: str | None,
    store_enabled: bool,
    last_response_id: str | None,
    emit_line: Callable[[str], None] | None,
) -> None:
    """Persist provider storage metadata for a branch when possible."""
    if store is None or not (isinstance(session_id, str) and session_id):
        return
    if not (isinstance(branch_id, str) and branch_id):
        return
    try:
        await update_branch_store(
            store=store,
            session_id=session_id,
            branch_id=branch_id,
            store_enabled=store_enabled,
            last_response_id=last_response_id,
        )
    except ConfigError:
        raise
    except (OSError, sqlite3.Error, DatabaseError) as exc:
        warn_or_raise_store_error(
            exc,
            emit_line=emit_line,
            context="Failed to persist branch store metadata",
        )


__all__ = ("persist_branch_store", "warn_or_raise_store_error")
