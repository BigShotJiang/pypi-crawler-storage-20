"""Spool parsing helpers for run recovery."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import FilesystemError, ValidationError
from agenterm.core.json_codec import parse_json_object
from agenterm.workflow.run.spool_models import RunIdentity, SpoolKind

if TYPE_CHECKING:
    from collections.abc import Sequence
    from pathlib import Path

    from agenterm.core.json_types import JSONMapping, JSONValue


def require_spool_text(value: JSONValue, *, field: str) -> str:
    """Return a required non-empty string or raise ValidationError."""
    if isinstance(value, str) and value:
        return value
    msg = f"Spool field {field} must be a non-empty string."
    raise ValidationError(msg)


def require_spool_int(value: JSONValue, *, field: str) -> int:
    """Return a required integer or raise ValidationError."""
    if isinstance(value, int):
        return int(value)
    msg = f"Spool field {field} must be an integer."
    raise ValidationError(msg)


def load_spool_lines(path: Path) -> list[dict[str, JSONValue]]:
    """Load and parse JSONL spool records from disk."""
    try:
        raw_lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        msg = f"Failed to read spool file {path}: {exc}"
        raise FilesystemError(msg) from exc
    rows: list[dict[str, JSONValue]] = []
    for raw in raw_lines:
        if not raw.strip():
            continue
        parsed = parse_json_object(raw)
        if parsed is None:
            msg = f"Invalid JSON in spool file {path}"
            raise ValidationError(msg)
        rows.append(parsed)
    if not rows:
        msg = f"Spool file is empty: {path}"
        raise ValidationError(msg)
    return rows


def parse_spool_header(row: JSONMapping) -> tuple[SpoolKind, RunIdentity]:
    """Parse the spool header record into kind + identity."""
    kind = row.get("kind")
    if kind not in ("run_events", "turn_attempt"):
        msg = f"Spool header has invalid kind: {kind!r}"
        raise ValidationError(msg)
    if row.get("record_type") != "header":
        msg = "Spool header missing record_type=header"
        raise ValidationError(msg)
    run_raw = row.get("run")
    if not isinstance(run_raw, dict):
        msg = "Spool header missing run metadata"
        raise ValidationError(msg)
    run_id = run_raw.get("run_id")
    run_identity = RunIdentity(
        run_id=str(run_id) if isinstance(run_id, str) and run_id else None,
        session_id=require_spool_text(
            run_raw.get("session_id"),
            field="run.session_id",
        ),
        branch_id=require_spool_text(run_raw.get("branch_id"), field="run.branch_id"),
        run_number=require_spool_int(run_raw.get("run_number"), field="run.run_number"),
    )
    return kind, run_identity


def parse_event_row(
    row: JSONMapping,
) -> tuple[int, int, str, str | None, str, str] | None:
    """Parse a spool event row into insert tuple or return None."""
    if row.get("record_type") != "event":
        return None
    event = row.get("event")
    if not isinstance(event, dict):
        msg = "Spool event record missing event payload"
        raise ValidationError(msg)
    request_index = require_spool_int(
        event.get("request_index"),
        field="event.request_index",
    )
    event_seq = require_spool_int(event.get("event_seq"), field="event.event_seq")
    event_type = require_spool_text(event.get("event_type"), field="event.event_type")
    model = require_spool_text(event.get("model"), field="event.model")
    event_json = event.get("event_json")
    if not isinstance(event_json, str) or not event_json:
        msg = "Spool event record missing event_json"
        raise ValidationError(msg)
    response_id_val = event.get("response_id")
    response_id = (
        str(response_id_val)
        if isinstance(response_id_val, str) and response_id_val
        else None
    )
    return (request_index, event_seq, event_type, response_id, model, event_json)


def parse_turn_attempt_rows(
    rows: Sequence[JSONMapping],
) -> tuple[list[JSONMapping], str | None, str | None]:
    """Split turn-attempt rows into items + status metadata."""
    items: list[JSONMapping] = []
    status: str | None = None
    cancel_reason: str | None = None
    for row in rows:
        record_type = row.get("record_type")
        if record_type == "item":
            items.append(row)
            continue
        if record_type == "status":
            status_val = row.get("status")
            status = str(status_val) if isinstance(status_val, str) else None
            reason_val = row.get("cancel_reason")
            cancel_reason = str(reason_val) if isinstance(reason_val, str) else None
    return items, status, cancel_reason


__all__ = (
    "load_spool_lines",
    "parse_event_row",
    "parse_spool_header",
    "parse_turn_attempt_rows",
    "require_spool_int",
    "require_spool_text",
)
