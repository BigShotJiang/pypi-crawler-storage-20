"""Agents-based engine entrypoints for agenterm.

This package exposes the public engine contracts used by the CLI and REPL:

- build_agent_from_config: construct an Agents Agent from AppConfig.
- build_mcp_servers: construct MCPServer instances from AppConfig.
- run_once / run_streamed: thin wrappers around Agents Runner methods.
"""

from __future__ import annotations

from agenterm.engine.agent_factory import build_agent_from_config
from agenterm.engine.mcp_factory import build_mcp_servers
from agenterm.engine.result_summary import (
    extract_final_text,
    summarize_tools,
    summarize_tools_counts,
    summarize_usage,
    summarize_usage_details,
)
from agenterm.engine.run import run_once, run_streamed

__all__ = (
    "build_agent_from_config",
    "build_mcp_servers",
    "extract_final_text",
    "run_once",
    "run_streamed",
    "summarize_tools",
    "summarize_tools_counts",
    "summarize_usage",
    "summarize_usage_details",
)
