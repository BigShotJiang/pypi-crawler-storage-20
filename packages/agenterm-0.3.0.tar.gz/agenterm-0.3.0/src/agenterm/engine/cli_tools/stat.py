"""stat local CLI tool implementation."""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from datetime import UTC, datetime
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Literal

from agents.tool import FunctionTool

from agenterm.constants.limits import (
    SAFE_OFFSET_MAX,
    SAFE_OFFSET_MIN,
    STAT_MAX_PATHS_MAX,
    STAT_MAX_PATHS_MIN,
)
from agenterm.core.json_codec import as_bool, as_str_list, parse_json_object
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    build_safe_env,
    count_text_lines_checked,
    error_output,
    path_error_kind,
    reason_details,
    resolve_path_checked,
    run_command,
    success_output,
)
from agenterm.engine.schema_validation import validate_strict_schema

if TYPE_CHECKING:
    from collections.abc import Sequence

    from agents.tool_context import ToolContext

    from agenterm.config.tools_policy import StatToolConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONMapping, JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_STAT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "stat path metadata parameters.",
    "properties": {
        "paths": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": STAT_MAX_PATHS_MIN,
            "maxItems": STAT_MAX_PATHS_MAX,
            "description": "Workspace-relative file or directory paths.",
        },
        "include_lines": {
            "type": ["boolean", "null"],
            "description": "Include line counts (files and directory totals).",
            "default": True,
        },
    },
    "required": ["paths"],
    "additionalProperties": False,
}

_STAT_FIELD_COUNT = 4


@dataclass(frozen=True)
class StatArgs:
    """Parsed stat arguments."""

    paths: list[str]
    include_lines: bool


def _stat_error(message: str) -> str:
    return error_output("stat", kind=INVALID_INPUT_KIND, message=message)


def _parse_stat_args(raw: str) -> tuple[StatArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _stat_error("Invalid stat payload.")
    if set(payload) - {"paths", "include_lines"}:
        return None, _stat_error("Invalid stat payload.")
    paths = as_str_list(payload.get("paths"), drop_empty=True)
    if paths is None or not paths:
        return None, _stat_error("stat requires paths.")
    if len(paths) < STAT_MAX_PATHS_MIN or len(paths) > STAT_MAX_PATHS_MAX:
        return None, _stat_error("Invalid stat paths length.")
    include_lines_raw = payload.get("include_lines")
    if include_lines_raw is None:
        include_lines = True
    else:
        include_lines = as_bool(include_lines_raw)
        if include_lines is None:
            return None, _stat_error("Invalid stat include_lines flag.")
    return StatArgs(paths=paths, include_lines=include_lines), None


def _raise_if_cancelled(cancel_token: CancelToken | None) -> None:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()


def _prune_symlink_dirs(root: Path, dirnames: list[str]) -> None:
    """Mutate dirnames in-place to prevent os.walk from following symlink dirs."""
    dirnames[:] = [name for name in dirnames if not (root / name).is_symlink()]


def _non_symlink_file_paths(root: Path, filenames: list[str]) -> list[Path]:
    """Return non-symlink file paths for a single os.walk root."""
    return [root / name for name in filenames if not (root / name).is_symlink()]


async def _line_increments_for_file(
    file_path: Path,
    *,
    cancel_token: CancelToken | None,
) -> tuple[int, int, int]:
    """Return (lines_add, binary_add, unreadable_add) for one file path."""
    _raise_if_cancelled(cancel_token)
    lines_count, kind = await asyncio.to_thread(count_text_lines_checked, file_path)
    if kind == "binary":
        return 0, 1, 0
    if kind == "unreadable":
        return 0, 0, 1
    if lines_count is None:
        return 0, 0, 0
    return int(lines_count), 0, 0


def _format_mode(mode_int: int) -> str:
    """Return zero-padded permission bits (e.g., 0644)."""
    return format(mode_int & 0o7777, "04o")


def _clean_type_label(label: str | None) -> str | None:
    if label is None:
        return None
    cleaned = label.strip()
    return cleaned or None


async def _detect_stat_flavor(
    *,
    cancel_token: CancelToken | None,
) -> Literal["gnu", "bsd"]:
    exit_code, _stdout, _stderr = await run_command(
        ["stat", "--version"],
        cwd=".",
        env=build_safe_env(),
        cancel_token=cancel_token,
    )
    return "gnu" if exit_code == 0 else "bsd"


async def _stat_fields(
    *,
    rel_path: str,
    workspace_root: Path,
    flavor: Literal["gnu", "bsd"],
    cancel_token: CancelToken | None,
) -> tuple[
    str | None,
    int | None,
    int | None,
    int | None,
]:
    if flavor == "gnu":
        cmd = ["stat", "--printf", "%F|%s|%Y|%a", rel_path]
    else:
        cmd = ["stat", "-f", "%HT|%z|%m|%p", rel_path]
    exit_code, stdout_text, _stderr_text = await run_command(
        cmd,
        cwd=str(workspace_root),
        env=build_safe_env(),
        cancel_token=cancel_token,
    )
    if exit_code != 0:
        return None, None, None, None
    parts = stdout_text.strip().split("|")
    if len(parts) != _STAT_FIELD_COUNT:
        return None, None, None, None
    type_label, size_str, mtime_str, mode_str = parts
    typ = _clean_type_label(type_label)
    try:
        size_val = int(size_str)
        mtime_val = int(mtime_str)
    except ValueError:
        return typ, None, None, None
    try:
        mode_val = int(mode_str, 8)
    except ValueError:
        mode_val = None
    return typ, size_val, mtime_val, mode_val


def _iso_timestamp(epoch_seconds: int | None) -> str | None:
    if epoch_seconds is None:
        return None
    try:
        return datetime.fromtimestamp(epoch_seconds, tz=UTC).isoformat()
    except (OverflowError, OSError, ValueError):
        return None


async def _stat_file_entry(
    *,
    abs_path: Path,
    rel_path: str,
    flavor: Literal["gnu", "bsd"],
    include_lines: bool,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> dict[str, JSONValue]:
    type_label, size_val, mtime_val, mode_val = await _stat_fields(
        rel_path=rel_path,
        workspace_root=workspace_root,
        flavor=flavor,
        cancel_token=cancel_token,
    )
    binary = False
    lines_count = None
    if include_lines:
        _raise_if_cancelled(cancel_token)
        lines_count, kind = await asyncio.to_thread(count_text_lines_checked, abs_path)
        if kind == "binary":
            binary = True
            lines_count = None
    payload: dict[str, JSONValue] = {
        "path": rel_path,
        "type": type_label,
    }
    if size_val is not None:
        payload["bytes"] = int(size_val)
    if binary:
        payload["binary"] = True
    if lines_count is not None:
        payload["lines"] = int(lines_count)
    iso_ts = _iso_timestamp(mtime_val)
    if iso_ts is not None:
        payload["modified"] = iso_ts
    if mode_val is not None:
        payload["mode"] = _format_mode(mode_val)
    return payload


async def _stat_directory_entry(
    *,
    abs_path: Path,
    rel_path: str,
    flavor: Literal["gnu", "bsd"],
    include_lines: bool,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> dict[str, JSONValue]:
    type_label, _size_val, mtime_val, mode_val = await _stat_fields(
        rel_path=rel_path,
        workspace_root=workspace_root,
        flavor=flavor,
        cancel_token=cancel_token,
    )
    entries = 0
    files = 0
    dirs = 0
    total_bytes = 0
    total_lines = 0
    binary_files = 0
    unreadable_files = 0
    for root, dirnames, filenames in os.walk(abs_path, followlinks=False):
        _raise_if_cancelled(cancel_token)
        root_path = Path(root)
        _prune_symlink_dirs(root_path, dirnames)
        file_paths = _non_symlink_file_paths(root_path, filenames)
        entries += len(dirnames) + len(file_paths)
        dirs += len(dirnames)
        files += len(file_paths)
        for file_path in file_paths:
            try:
                st = file_path.stat(follow_symlinks=False)
            except OSError:
                continue
            total_bytes += int(st.st_size)
            if include_lines:
                lines_add, binary_add, unreadable_add = await _line_increments_for_file(
                    file_path,
                    cancel_token=cancel_token,
                )
                total_lines += lines_add
                binary_files += binary_add
                unreadable_files += unreadable_add
    payload: dict[str, JSONValue] = {
        "path": rel_path,
        "type": type_label,
        "entries": int(entries),
        "files": int(files),
        "dirs": int(dirs),
        "total_bytes": int(total_bytes),
    }
    if include_lines:
        payload["total_lines"] = int(total_lines)
        if binary_files:
            payload["binary_files"] = int(binary_files)
        if unreadable_files:
            payload["unreadable_files"] = int(unreadable_files)
    iso_ts = _iso_timestamp(mtime_val)
    if iso_ts is not None:
        payload["modified"] = iso_ts
    if mode_val is not None:
        payload["mode"] = _format_mode(mode_val)
    return payload


async def _stat_entry(
    *,
    abs_path: Path,
    rel_path: str,
    flavor: Literal["gnu", "bsd"],
    include_lines: bool,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> dict[str, JSONValue]:
    if abs_path.is_dir():
        return await _stat_directory_entry(
            abs_path=abs_path,
            rel_path=rel_path,
            flavor=flavor,
            include_lines=include_lines,
            workspace_root=workspace_root,
            cancel_token=cancel_token,
        )
    return await _stat_file_entry(
        abs_path=abs_path,
        rel_path=rel_path,
        flavor=flavor,
        include_lines=include_lines,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )


def _resolve_path(
    workspace_root: Path,
    raw: str,
) -> tuple[tuple[Path, str] | None, str | None]:
    return resolve_path_checked(workspace_root, raw, expect="any")


def _clamp_paths(paths: list[str]) -> list[str]:
    """Protect against runaway lists even after schema validation."""
    if len(paths) > SAFE_OFFSET_MAX:
        return paths[:SAFE_OFFSET_MAX]
    if len(paths) < SAFE_OFFSET_MIN:
        return []
    return paths


def _stat_payload(results: Sequence[JSONMapping]) -> dict[str, JSONValue]:
    return {"results": [dict(item) for item in results]}


async def _stat_payload_from_args(
    *,
    args: StatArgs,
    workspace_root: Path,
    cancel_token: CancelToken | None,
) -> tuple[dict[str, JSONValue] | None, str | None]:
    clamped_paths = _clamp_paths(args.paths)
    if not clamped_paths:
        return None, _stat_error("stat requires paths.")

    resolved_paths: list[tuple[Path, str]] = []
    for raw_path in clamped_paths:
        resolved, reason = await asyncio.to_thread(
            _resolve_path,
            workspace_root,
            raw_path,
        )
        _raise_if_cancelled(cancel_token)
        if resolved is None:
            return None, error_output(
                "stat",
                kind=path_error_kind(reason),
                message="Invalid stat path.",
                details=reason_details(reason, field="paths"),
            )
        abs_path, rel_path = resolved
        resolved_paths.append((abs_path, rel_path))

    flavor = await _detect_stat_flavor(cancel_token=cancel_token)
    results: list[dict[str, JSONValue]] = []
    for abs_path, rel_path in resolved_paths:
        entry = await _stat_entry(
            abs_path=abs_path,
            rel_path=rel_path,
            flavor=flavor,
            include_lines=args.include_lines,
            workspace_root=workspace_root,
            cancel_token=cancel_token,
        )
        results.append(entry)

    return _stat_payload(results), None


async def _invoke_stat(
    ctx: ToolContext[ToolRuntimeContext],
    raw: str,
    *,
    workspace_root: Path,
) -> str:
    cancel_token = ctx.context.cancel_token
    _raise_if_cancelled(cancel_token)
    args, error = _parse_stat_args(raw)
    if error is not None:
        return error
    if args is None:
        return _stat_error("Invalid stat payload.")
    payload, error = await _stat_payload_from_args(
        args=args,
        workspace_root=workspace_root,
        cancel_token=cancel_token,
    )
    if error is not None:
        return error
    if payload is None:
        return _stat_error("Invalid stat payload.")
    return success_output("stat", payload)


def build_stat_tool(
    cfg: StatToolConfig | None,
    *,
    workspace_root: Path,
) -> FunctionTool | None:
    """Build the stat tool when configured."""
    if cfg is None:
        return None
    validate_strict_schema("stat", _STAT_SCHEMA)

    return FunctionTool(
        name="stat",
        description=(
            "Return file or directory metadata; use for size/mtime/line stats.\n"
            "Inputs: paths (workspace-relative), include_lines.\n"
            "Outputs: results array with per-path metadata; "
            "directories include totals.\n"
            "Errors: invalid_input for bad payload/paths; not_found for missing paths."
        ),
        params_json_schema=_STAT_SCHEMA,
        on_invoke_tool=partial(_invoke_stat, workspace_root=workspace_root),
        strict_json_schema=True,
    )


__all__ = ("build_stat_tool",)
