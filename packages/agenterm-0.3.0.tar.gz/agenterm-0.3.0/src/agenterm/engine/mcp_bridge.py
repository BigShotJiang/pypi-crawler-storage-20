"""MCP bridge wrapper for structured output envelopes and approvals."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agents.mcp import MCPServer
from mcp import types as mtypes
from mcp.shared.exceptions import McpError

from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import (
    JSONLike,
    dumps_compact,
    require_json_value,
)
from agenterm.core.tool_output_envelope import (
    McpToolContent,
    McpToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.mcp_namespacing import NamespacedMcpServer

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.agent import AgentBase
    from agents.run_context import RunContextWrapper

    from agenterm.config.model import McpBridgeConfig
    from agenterm.core.approvals import McpApprovalManager
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.engine.tool_output_clamp import ToolOutputClamp

_APPROVAL_REJECTED_KIND = "approval_rejected"
_MCP_ERROR_KIND = "mcp_error"
_TOOL_ERROR_KIND = "tool_error"
_RESULT_ERROR_KIND = "mcp_call_error"


def _content_text_and_truncation(
    items: Sequence[mtypes.ContentBlock],
    *,
    max_items: int,
) -> tuple[str, bool]:
    truncated = False
    blocks = list(items)
    if max_items > 0 and len(blocks) > max_items:
        blocks = blocks[:max_items]
        truncated = True
    parts: list[str] = []
    for item in blocks:
        if isinstance(item, mtypes.TextContent):
            parts.append(item.text)
        else:
            dumped = item.model_dump(by_alias=True, exclude_none=True)
            parts.append(
                dumps_compact(
                    require_json_value(
                        value=dumped,
                        context="mcp.bridge.content_block",
                    ),
                    ensure_ascii=True,
                    context="mcp.bridge.content_block",
                )
            )
    return "\n".join(parts), truncated


def _structured_data_and_text(
    structured: JSONLike | None,
) -> tuple[JSONValue | None, str | None]:
    if structured is None:
        return None, None
    return (
        require_json_value(
            value=structured,
            context="mcp.bridge.structured_content",
        ),
        None,
    )


def _resolve_original_tool_name(server: MCPServer, tool_name: str) -> str:
    if isinstance(server, NamespacedMcpServer):
        return server.resolve_original_tool_name(tool_name)
    return tool_name


def _approval_denied_result(
    *,
    server_key: str,
    tool_name: str,
    reason: str | None,
    output_clamp: ToolOutputClamp,
) -> mtypes.CallToolResult:
    details: dict[str, JSONValue] = {}
    if reason:
        details["reason"] = reason
    error = ToolOutputError(
        kind=_APPROVAL_REJECTED_KIND,
        message="MCP tool execution rejected by user.",
        details=details,
    )
    env = McpToolOutputEnvelope(
        server_key=server_key,
        tool_name=tool_name,
        ok=False,
        truncated=False,
        error=error,
    )
    env = output_clamp.clamp_mcp_envelope(env)
    return _call_result_from_envelope(env)


def _error_result(
    *,
    server_key: str,
    tool_name: str,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
    output_clamp: ToolOutputClamp,
) -> mtypes.CallToolResult:
    error = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = McpToolOutputEnvelope(
        server_key=server_key,
        tool_name=tool_name,
        ok=False,
        truncated=False,
        error=error,
    )
    env = output_clamp.clamp_mcp_envelope(env)
    return _call_result_from_envelope(env)


def _call_result_from_envelope(env: McpToolOutputEnvelope) -> mtypes.CallToolResult:
    text = ""
    if env.content is not None:
        text = env.content.text
    elif env.error is not None:
        text = env.error.message
    content: list[mtypes.ContentBlock] = [mtypes.TextContent(type="text", text=text)]
    return mtypes.CallToolResult(
        content=content,
        structuredContent=env.to_json(),
        isError=not env.ok,
    )


@dataclass
class BridgeMcpServer(MCPServer):
    """MCPServer wrapper that enforces approvals and output envelopes."""

    server_key: str
    inner: MCPServer
    approvals: McpApprovalManager
    output_clamp: ToolOutputClamp
    max_content_items: int
    cancel_token: CancelToken | None = None

    def __post_init__(self) -> None:
        """Initialize the MCP server with structured content enabled."""
        super().__init__(use_structured_content=True)

    @property
    def name(self) -> str:
        """Return the server's display name."""
        return self.inner.name

    async def connect(self) -> None:
        """Connect the inner MCP server."""
        await self.inner.connect()

    async def cleanup(self) -> None:
        """Cleanup resources for the inner MCP server."""
        await self.inner.cleanup()

    async def list_tools(
        self,
        run_context: RunContextWrapper | None = None,
        agent: AgentBase | None = None,
    ) -> list[mtypes.Tool]:
        """List tools from the inner MCP server."""
        return await self.inner.list_tools(run_context=run_context, agent=agent)

    async def call_tool(
        self,
        tool_name: str,
        arguments: Mapping[str, JSONValue] | None,
    ) -> mtypes.CallToolResult:
        """Call an MCP tool with approvals and envelope normalization."""
        original_name = _resolve_original_tool_name(self.inner, tool_name)
        args_dict = dict(arguments) if arguments is not None else None
        args_json = dumps_compact(
            args_dict or {},
            ensure_ascii=True,
            context="mcp.bridge.arguments",
        )
        if self.cancel_token is not None:
            self.cancel_token.raise_if_cancelled()
        approval_item = self.approvals.register(
            server_label=self.server_key,
            tool_name=original_name,
            arguments_json=args_json,
        )
        decision = await self.approvals.wait(
            approval_item.id,
            cancel_token=self.cancel_token,
        )
        if not decision.approved:
            return _approval_denied_result(
                server_key=self.server_key,
                tool_name=original_name,
                reason=decision.reason,
                output_clamp=self.output_clamp,
            )
        if self.cancel_token is not None:
            self.cancel_token.raise_if_cancelled()
        try:
            result = await self.inner.call_tool(tool_name, args_dict)
        except McpError as exc:
            details: dict[str, JSONValue] = {"code": int(exc.error.code)}
            if exc.error.data is not None:
                details["data"] = require_json_value(
                    value=exc.error.data,
                    context="mcp.bridge.error.data",
                )
            return _error_result(
                server_key=self.server_key,
                tool_name=original_name,
                kind=_MCP_ERROR_KIND,
                message=exc.error.message,
                details=details,
                output_clamp=self.output_clamp,
            )
        except AgentermError as exc:
            return _error_result(
                server_key=self.server_key,
                tool_name=original_name,
                kind=_TOOL_ERROR_KIND,
                message=str(exc),
                output_clamp=self.output_clamp,
            )

        if result.isError:
            text, _ = _content_text_and_truncation(
                result.content,
                max_items=self.max_content_items,
            )
            message = text or "MCP tool returned an error."
            return _error_result(
                server_key=self.server_key,
                tool_name=original_name,
                kind=_RESULT_ERROR_KIND,
                message=message,
                output_clamp=self.output_clamp,
            )

        text, truncated = _content_text_and_truncation(
            result.content,
            max_items=self.max_content_items,
        )
        data, extra_text = _structured_data_and_text(result.structuredContent)
        if extra_text:
            text = f"{text}\n{extra_text}" if text else extra_text
        content = McpToolContent(text=text, data=data)
        env = McpToolOutputEnvelope(
            server_key=self.server_key,
            tool_name=original_name,
            ok=True,
            truncated=truncated,
            content=content,
        )
        env = self.output_clamp.clamp_mcp_envelope(env)
        return _call_result_from_envelope(env)

    async def list_prompts(self) -> mtypes.ListPromptsResult:
        """List prompts from the inner MCP server."""
        return await self.inner.list_prompts()

    async def get_prompt(
        self,
        name: str,
        arguments: Mapping[str, JSONValue] | None = None,
    ) -> mtypes.GetPromptResult:
        """Fetch a prompt from the inner MCP server."""
        args_dict = dict(arguments) if arguments is not None else None
        return await self.inner.get_prompt(name, args_dict)


def wrap_mcp_servers(
    servers: Sequence[MCPServer],
    *,
    approvals: McpApprovalManager,
    bridge_cfg: McpBridgeConfig,
    output_clamp: ToolOutputClamp,
    cancel_token: CancelToken | None = None,
) -> list[MCPServer]:
    """Wrap MCP servers with the bridge when not already wrapped."""
    out: list[MCPServer] = []
    for server in servers:
        if isinstance(server, BridgeMcpServer):
            if server.cancel_token is cancel_token:
                out.append(server)
            else:
                out.append(
                    BridgeMcpServer(
                        server_key=server.server_key,
                        inner=server.inner,
                        approvals=approvals,
                        output_clamp=output_clamp,
                        max_content_items=bridge_cfg.max_content_items,
                        cancel_token=cancel_token,
                    )
                )
            continue
        server_key = server.name
        if isinstance(server, NamespacedMcpServer):
            server_key = server.server_key
            out.append(
                BridgeMcpServer(
                    server_key=server_key,
                    inner=server,
                    approvals=approvals,
                    output_clamp=output_clamp,
                    max_content_items=bridge_cfg.max_content_items,
                    cancel_token=cancel_token,
                )
            )
    return out


__all__ = ("BridgeMcpServer", "wrap_mcp_servers")
