"""History packing and session input callback helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agenterm.core.errors import AgentermError, ConfigError
from agenterm.core.model_id import model_plane
from agenterm.core.path_utils import parse_db_path
from agenterm.engine.history_packing_helpers import (
    CompressionThreshold,
    HistoryPackingOptions,
    PackedItem,
    PackingBudget,
    await_compression_approval,
    compress_prompt,
    dedupe_new_packed_items,
    drop_prompt,
    flatten_turns,
    instructions_size,
    items_size,
    resolve_budget,
    resolve_compression_threshold,
    trim_by_chars,
)
from agenterm.engine.history_packing_io import (
    count_openai_tokens,
    parse_packed_items,
    serialize_packed_items,
)
from agenterm.engine.history_view import HistoryView, load_history_view
from agenterm.engine.provider_capabilities import resolve_provider_capabilities
from agenterm.steward.tasks import run_compress_policy
from agenterm.store.async_db import AsyncStore
from agenterm.store.session.service import session_store

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.items import TResponseInputItem
    from agents.memory import SessionInputCallback

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


@dataclass(frozen=True)
class PackingState:
    """Computed packing state for a single pass."""

    budget: PackingBudget
    threshold: CompressionThreshold
    new_items: list[PackedItem]
    prefix: list[PackedItem]
    turns: list[list[PackedItem]]
    combined: list[PackedItem]
    combined_chars: int
    instructions: str | None
    token_count: int | None
    over_budget: bool
    over_threshold: bool


async def _compress_and_reload(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    model_id: str,
    run_number: int | None,
    origin_branch_id: str | None,
    cancel_token: CancelToken | None,
    emit_line: Callable[[str], None] | None,
) -> list[TResponseInputItem]:
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    await run_compress_policy(
        cfg=cfg,
        session=session,
        store=store,
        session_id=session.session_id,
        branch_id=session.current_branch_id,
        trigger="auto",
        turn_range=None,
        emit_line=emit_line,
        model_override=model_id,
        run_number=run_number,
        origin_branch_id=origin_branch_id,
        cancel_token=cancel_token,
    )
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    return await session.get_items()


async def _trim_by_openai_tokens(
    *,
    model_id: str,
    combined: list[PackedItem],
    prefix: list[PackedItem],
    remaining_turns: list[list[PackedItem]],
    new_items: list[PackedItem],
    instructions: str | None,
    budget_tokens: int,
) -> tuple[Literal["ok", "failed", "over"], list[PackedItem]]:
    token_count = await count_openai_tokens(
        model_id=model_id,
        input_items=parse_packed_items(
            combined,
            context="history_packing.openai_input",
        ),
        instructions=instructions,
    )
    if token_count is None:
        return "failed", combined
    while token_count > budget_tokens:
        if not remaining_turns:
            return "over", combined
        remaining_turns = remaining_turns[1:]
        combined = [*prefix, *flatten_turns(remaining_turns), *new_items]
        token_count = await count_openai_tokens(
            model_id=model_id,
            input_items=parse_packed_items(
                combined,
                context="history_packing.openai_input",
            ),
            instructions=instructions,
        )
        if token_count is None:
            return "failed", combined
    return "ok", combined


def _budget_error_message(
    *,
    model_id: str,
    budget: PackingBudget,
    size_chars: int,
    size_tokens: int | None,
    compress_error: AgentermError | None,
) -> str:
    token_clause = f", size_tokens={size_tokens}" if size_tokens is not None else ""
    msg = (
        "Packed history exceeds input budget "
        f"(model={model_id!r}, budget_tokens={budget.input_tokens}, "
        f"budget_chars={budget.input_chars}, size_chars={size_chars}{token_clause})."
    )
    if compress_error is not None:
        msg = f"{msg} Compression failed: {compress_error}"
    return msg


async def _drop_to_fit(
    *,
    model_id: str,
    prefix: list[PackedItem],
    turns: list[list[PackedItem]],
    new_items: list[PackedItem],
    instructions: str | None,
    budget: PackingBudget,
) -> list[PackedItem]:
    combined, remaining_turns = trim_by_chars(
        prefix=prefix,
        turns=turns,
        new_items=new_items,
        budget_chars=budget.input_chars,
        instructions=instructions,
    )
    plane = model_plane(model_id)
    if plane == "openai":
        status, combined = await _trim_by_openai_tokens(
            model_id=model_id,
            combined=combined,
            prefix=prefix,
            remaining_turns=remaining_turns,
            new_items=new_items,
            instructions=instructions,
            budget_tokens=budget.input_tokens,
        )
        if status == "ok":
            return combined
        if status == "over":
            current_chars = items_size(combined) + instructions_size(instructions)
            msg = _budget_error_message(
                model_id=model_id,
                budget=budget,
                size_chars=current_chars,
                size_tokens=None,
                compress_error=None,
            )
            raise ConfigError(msg)
        return combined
    return combined


async def _build_packing_state(
    *,
    cfg: AppConfig,
    history_items: Sequence[PackedItem],
    new_items: Sequence[PackedItem],
    model_id: str,
    session: AgentermSQLiteSession | None,
) -> PackingState:
    budget = resolve_budget(cfg)
    threshold = resolve_compression_threshold(cfg, budget=budget)
    instructions = cfg.agent.instructions
    view = await _history_view(
        history_items=history_items,
        session=session,
    )
    prefix, turns = view.prefix, view.turns
    new_items_list = list(new_items)
    combined = [*prefix, *flatten_turns(turns), *new_items_list]
    combined_chars = items_size(combined) + instructions_size(instructions)
    token_count: int | None = None
    if model_plane(model_id) == "openai":
        token_count = await count_openai_tokens(
            model_id=model_id,
            input_items=parse_packed_items(
                combined,
                context="history_packing.openai_input",
            ),
            instructions=instructions,
        )
    over_budget = (
        token_count > budget.input_tokens
        if token_count is not None
        else combined_chars > budget.input_chars
    )
    over_threshold = (
        token_count >= threshold.threshold_tokens
        if token_count is not None
        else combined_chars >= threshold.threshold_chars
    )
    return PackingState(
        budget=budget,
        threshold=threshold,
        new_items=new_items_list,
        prefix=prefix,
        turns=turns,
        combined=combined,
        combined_chars=combined_chars,
        instructions=instructions,
        token_count=token_count,
        over_budget=over_budget,
        over_threshold=over_threshold,
    )


async def _history_view(
    *,
    history_items: Sequence[PackedItem],
    session: AgentermSQLiteSession | None,
) -> HistoryView:
    if session is None:
        return HistoryView(prefix=list(history_items), turns=[])
    session_id = session.session_id
    if not session_id:
        return HistoryView(prefix=list(history_items), turns=[])
    db_path = parse_db_path(session.db_path)
    if db_path is None:
        return HistoryView(prefix=list(history_items), turns=[])
    return await load_history_view(
        store=AsyncStore(db_path),
        session_id=session_id,
        branch_id=session.current_branch_id,
    )


def _compression_prompt_mode(cfg: AppConfig, *, model_id: str) -> str:
    caps = resolve_provider_capabilities(cfg, model_id=model_id)
    strategy = cfg.compression.strategy
    if strategy == "snapshot":
        return "snapshot"
    if strategy == "compaction_if_supported":
        return "compaction" if caps.supports_compaction else "snapshot"
    if strategy == "both_if_supported":
        if not caps.supports_compaction:
            return "snapshot"
        return f"both(primary={cfg.compression.primary_branch})"
    return strategy


async def _maybe_compress(
    *,
    cfg: AppConfig,
    state: PackingState,
    session: AgentermSQLiteSession | None,
    store: AsyncStore | None,
    model_id: str,
    allow_compress: bool,
    options: HistoryPackingOptions,
) -> tuple[list[PackedItem] | None, AgentermError | None]:
    if not allow_compress or not (state.over_budget or state.over_threshold):
        return None, None
    if session is None or store is None or not state.turns:
        return None, None
    if options.cancel_token is not None:
        options.cancel_token.raise_if_cancelled()
    approved = True
    if cfg.compression.trigger == "ask":
        approved = await await_compression_approval(
            options=options,
            action="compress",
            message=compress_prompt(
                mode=_compression_prompt_mode(cfg, model_id=model_id),
                threshold=state.threshold,
                token_count=state.token_count,
                char_count=state.combined_chars,
            ),
        )
    if not approved:
        return None, None
    try:
        compressed_history = await _compress_and_reload(
            cfg=cfg,
            session=session,
            store=store,
            model_id=model_id,
            run_number=options.run_number,
            origin_branch_id=options.origin_branch_id,
            cancel_token=options.cancel_token,
            emit_line=options.emit_line,
        )
    except AgentermError as exc:
        return None, exc
    return serialize_packed_items(
        compressed_history,
        context="history_packing.compressed",
    ), None


async def _drop_or_error(
    *,
    cfg: AppConfig,
    state: PackingState,
    model_id: str,
    options: HistoryPackingOptions,
    compress_error: AgentermError | None,
) -> list[PackedItem]:
    drop_policy = cfg.compression.drop_policy
    if drop_policy == "allow":
        return await _drop_to_fit(
            model_id=model_id,
            prefix=state.prefix,
            turns=state.turns,
            new_items=state.new_items,
            instructions=state.instructions,
            budget=state.budget,
        )
    if drop_policy == "ask" and await await_compression_approval(
        options=options,
        action="drop",
        message=drop_prompt(
            budget=state.budget,
            token_count=state.token_count,
            char_count=state.combined_chars,
        ),
    ):
        return await _drop_to_fit(
            model_id=model_id,
            prefix=state.prefix,
            turns=state.turns,
            new_items=state.new_items,
            instructions=state.instructions,
            budget=state.budget,
        )
    msg = _budget_error_message(
        model_id=model_id,
        budget=state.budget,
        size_chars=state.combined_chars,
        size_tokens=state.token_count,
        compress_error=compress_error,
    )
    raise ConfigError(msg)


async def _pack_once(
    *,
    cfg: AppConfig,
    history_items: Sequence[PackedItem],
    new_items: Sequence[PackedItem],
    model_id: str,
    session: AgentermSQLiteSession | None,
    store: AsyncStore | None,
    allow_compress: bool,
    options: HistoryPackingOptions,
) -> list[PackedItem]:
    state = await _build_packing_state(
        cfg=cfg,
        history_items=history_items,
        new_items=new_items,
        model_id=model_id,
        session=session,
    )
    compressed, compress_error = await _maybe_compress(
        cfg=cfg,
        state=state,
        session=session,
        store=store,
        model_id=model_id,
        allow_compress=allow_compress,
        options=options,
    )
    if compressed is not None:
        return await _pack_once(
            cfg=cfg,
            history_items=compressed,
            new_items=new_items,
            model_id=model_id,
            session=session,
            store=store,
            allow_compress=False,
            options=options,
        )
    if not state.over_budget:
        return state.combined
    return await _drop_or_error(
        cfg=cfg,
        state=state,
        model_id=model_id,
        options=options,
        compress_error=compress_error,
    )


async def pack_history_items(
    *,
    cfg: AppConfig,
    history_items: Sequence[TResponseInputItem],
    new_items: Sequence[TResponseInputItem],
    model_id: str,
    session: AgentermSQLiteSession | None,
    store: AsyncStore | None,
    options: HistoryPackingOptions,
) -> list[TResponseInputItem]:
    """Return packed history items for a single run."""
    if options.cancel_token is not None:
        options.cancel_token.raise_if_cancelled()
    history_packed = serialize_packed_items(
        history_items,
        context="history_packing.history_items",
    )
    new_packed = serialize_packed_items(
        new_items,
        context="history_packing.new_items",
    )
    new_packed = dedupe_new_packed_items(history_packed, new_packed)
    packed = await _pack_once(
        cfg=cfg,
        history_items=history_packed,
        new_items=new_packed,
        model_id=model_id,
        session=session,
        store=store,
        allow_compress=True,
        options=options,
    )
    return parse_packed_items(packed, context="history_packing.output")


def build_session_input_callback(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    model_id: str,
    options: HistoryPackingOptions,
) -> SessionInputCallback:
    """Return a per-run session input callback that packs session history.

    Session history refers to SDK turns persisted in the local session store.
    """
    store = session_store()

    async def _callback(
        history_items: list[TResponseInputItem],
        new_items: list[TResponseInputItem],
    ) -> list[TResponseInputItem]:
        return await pack_history_items(
            cfg=cfg,
            history_items=history_items,
            new_items=new_items,
            model_id=model_id,
            session=session,
            store=store,
            options=options,
        )

    return _callback


__all__ = (
    "HistoryPackingOptions",
    "build_session_input_callback",
    "pack_history_items",
)
