"""RunConfig construction helpers for Agents runner."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.run import RunConfig

from agenterm.core.guardrails_loader import prime_guardrails
from agenterm.core.guardrails_registry import (
    resolve_input_guardrails,
    resolve_output_guardrails,
)
from agenterm.engine.model_provider import build_model_provider, gateway_route_for_model
from agenterm.store.session.service import DEFAULT_SESSION_INPUT_CALLBACK

if TYPE_CHECKING:
    from agents.model_settings import ModelSettings

    from agenterm.config.model import AppConfig


def build_run_config(
    cfg: AppConfig,
    *,
    workflow_name: str,
    model_id: str | None = None,
    model_settings_override: ModelSettings | None = None,
) -> RunConfig:
    """Construct a RunConfig from AppConfig run and tracing settings."""
    run_cfg = cfg.run
    model_settings = cfg.to_model_settings()
    effective_model = model_id or cfg.agent.model
    route_info = gateway_route_for_model(cfg.providers, model_id=effective_model)
    if route_info is not None:
        _, route_cfg = route_info
        extra_args = dict(model_settings.extra_args or {})
        extra_args["max_retries"] = 0
        extra_args["num_retries"] = 0
        model_settings.extra_args = extra_args
        if route_cfg.headers:
            merged = dict(route_cfg.headers)
            if model_settings.extra_headers:
                extra = {
                    key: value
                    for key, value in model_settings.extra_headers.items()
                    if isinstance(value, str)
                }
                merged.update(extra)
            model_settings.extra_headers = merged
    if model_settings_override is not None:
        model_settings = model_settings.resolve(model_settings_override)
    prime_guardrails(cfg.guardrails)
    input_guardrails = (
        resolve_input_guardrails(cfg.guardrails.input) if cfg.guardrails.input else None
    )
    output_guardrails = (
        resolve_output_guardrails(cfg.guardrails.output)
        if cfg.guardrails.output
        else None
    )
    trace_meta = dict(run_cfg.trace_metadata) if run_cfg.trace_metadata else None
    return RunConfig(
        model=effective_model,
        model_settings=model_settings,
        model_provider=build_model_provider(cfg.providers),
        input_guardrails=input_guardrails,
        output_guardrails=output_guardrails,
        tracing_disabled=not bool(run_cfg.trace_enabled),
        trace_include_sensitive_data=bool(run_cfg.trace_include_sensitive_data),
        workflow_name=workflow_name,
        trace_id=run_cfg.trace_id,
        group_id=run_cfg.group_id,
        trace_metadata=trace_meta,
        session_input_callback=DEFAULT_SESSION_INPUT_CALLBACK,
    )


__all__ = ("build_run_config",)
