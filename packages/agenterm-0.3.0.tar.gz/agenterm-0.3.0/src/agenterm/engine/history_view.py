"""History view construction based on vendor message structure."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.json_types import JSONValue
from agenterm.core.response_items import (
    normalize_input_item_json,
    serialize_input_item,
)
from agenterm.store.history import ensure_history_tables

if TYPE_CHECKING:
    import aiosqlite

    from agenterm.store.async_db import AsyncStore

type PackedItem = dict[str, JSONValue]


@dataclass(frozen=True)
class HistoryView:
    """History split into a prefix and per-turn buckets."""

    prefix: list[PackedItem]
    turns: list[list[PackedItem]]


async def load_history_view(
    *,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
) -> HistoryView:
    """Load history items for a branch and split into prefix + turns."""

    async def _op(
        conn: aiosqlite.Connection,
    ) -> list[tuple[int | None, str | None]]:
        await ensure_history_tables(
            conn,
            tables=("message_structure", "agent_messages"),
        )
        cur = await conn.execute(
            """
            SELECT ms.branch_turn_number, am.message_data
            FROM message_structure ms
            JOIN agent_messages am ON ms.message_id = am.id
            WHERE ms.session_id = ? AND ms.branch_id = ?
            ORDER BY ms.sequence_number ASC
            """,
            (str(session_id), str(branch_id)),
        )
        rows = await cur.fetchall()
        return [(row[0], row[1]) for row in rows]

    rows = await store.run(_op)
    prefix: list[PackedItem] = []
    turns: list[list[PackedItem]] = []
    current_turn: list[PackedItem] = []
    current_turn_number: int | None = None
    for raw_turn, raw_json in rows:
        if not isinstance(raw_json, str) or not raw_json:
            msg = "History item payload is missing from message store."
            raise ConfigError(msg)
        parsed = parse_json_object(raw_json)
        if parsed is None:
            msg = "History item payload is not valid JSON."
            raise ConfigError(msg)
        normalized = normalize_input_item_json(parsed, context="history_view.item")
        item = serialize_input_item(normalized, context="history_view.item")
        turn_number = int(raw_turn) if isinstance(raw_turn, int) else 0
        if turn_number <= 0:
            if current_turn:
                turns.append(current_turn)
                current_turn = []
                current_turn_number = None
            prefix.append(item)
            continue
        if current_turn_number is None or turn_number != current_turn_number:
            if current_turn:
                turns.append(current_turn)
            current_turn = [item]
            current_turn_number = turn_number
        else:
            current_turn.append(item)
    if current_turn:
        turns.append(current_turn)
    return HistoryView(prefix=prefix, turns=turns)


__all__ = ("HistoryView", "load_history_view")
