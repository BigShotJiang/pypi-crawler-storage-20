"""Tool policy and auxiliary tool config types."""

from __future__ import annotations

from dataclasses import dataclass, field

from agenterm.constants.limits import (
    PARALLEL_MAX_CALLS_DEFAULT,
    PARALLEL_MAX_CONCURRENCY_DEFAULT,
)


@dataclass(frozen=True)
class UpdatePlanToolConfig:
    """Local update_plan tool configuration."""


@dataclass(frozen=True)
class GetPlanToolConfig:
    """Local get_plan tool configuration."""


@dataclass(frozen=True)
class FdToolConfig:
    """Local fd tool configuration (read-only)."""


@dataclass(frozen=True)
class BatToolConfig:
    """Local bat tool configuration (read-only)."""


@dataclass(frozen=True)
class TreeToolConfig:
    """Local tree tool configuration (read-only)."""


@dataclass(frozen=True)
class StatToolConfig:
    """Local stat tool configuration (read-only)."""


@dataclass(frozen=True)
class RgToolConfig:
    """Local rg tool configuration (read-only)."""


@dataclass(frozen=True)
class ParallelToolConfig:
    """Local parallel tool configuration (read-only aggregator)."""

    max_calls: int = PARALLEL_MAX_CALLS_DEFAULT
    max_concurrency: int = PARALLEL_MAX_CONCURRENCY_DEFAULT


@dataclass(frozen=True)
class AgentRunToolConfig:
    """Local agent_run tool configuration (ephemeral delegation)."""

    bundle: str = "handoff"


@dataclass(frozen=True)
class AgentRunReportToolConfig:
    """Local agent_run_report tool configuration (report retrieval)."""


@dataclass(frozen=True)
class DangerousToolsConfig:
    """Overrides for dangerous tool labels."""

    add: list[str] = field(default_factory=list)
    remove: list[str] = field(default_factory=list)


__all__ = (
    "AgentRunReportToolConfig",
    "AgentRunToolConfig",
    "BatToolConfig",
    "DangerousToolsConfig",
    "FdToolConfig",
    "GetPlanToolConfig",
    "ParallelToolConfig",
    "RgToolConfig",
    "StatToolConfig",
    "TreeToolConfig",
    "UpdatePlanToolConfig",
)
