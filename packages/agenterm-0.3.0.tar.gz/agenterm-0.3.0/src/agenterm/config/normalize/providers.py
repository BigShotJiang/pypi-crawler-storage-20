"""Normalize providers section."""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import TYPE_CHECKING

from agenterm.config.model import (
    GatewayProviderConfig,
    GatewayRouteConfig,
    OpenAIProviderConfig,
    ProvidersConfig,
)
from agenterm.config.normalize.validators import (
    bool_field,
    str_map_or_none,
    str_or_none,
    validate_allowed_keys,
)
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import as_str_list

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue


_OPENAI_KEYS: set[str] = {"base_url"}
_GATEWAY_KEYS: set[str] = {"routes"}
_ROUTE_KEYS: set[str] = {
    "provider",
    "base_url",
    "api_key_env",
    "headers",
    "model_allowlist",
    "allow_any_model",
    "supports_compaction",
    "supports_file_id",
    "supports_image_url",
    "allow_inline_data_url",
}

_ENV_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _trimmed_nonempty(raw: str, *, prefix: str) -> str:
    value = raw.strip()
    if not value:
        msg = f"{prefix} must be a non-empty string"
        raise ConfigError(msg)
    return value


def _optional_trimmed_str(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: str | None,
    prefix: str,
) -> str | None:
    raw = str_or_none(node, key=key, default=default, prefix=prefix)
    if raw is None:
        return None
    return _trimmed_nonempty(raw, prefix=prefix)


def _required_str(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    prefix: str,
) -> str:
    raw = node.get(key)
    if not isinstance(raw, str):
        msg = f"{prefix} must be a string"
        raise ConfigError(msg)
    return _trimmed_nonempty(raw, prefix=prefix)


def _normalize_route_key(raw_key: str) -> str:
    name = raw_key.strip()
    if not name:
        msg = "providers.gateway.routes contains an empty route name"
        raise ConfigError(msg)
    if "/" in name:
        msg = "providers.gateway.routes route names must not contain '/' characters"
        raise ConfigError(msg)
    if any(ch.isspace() for ch in name):
        msg = "providers.gateway.routes route names must not contain whitespace"
        raise ConfigError(msg)
    return name


def _normalize_api_key_env(
    node: Mapping[str, JSONValue],
    *,
    key: str,
    default: str | None,
    prefix: str,
) -> str | None:
    value = _optional_trimmed_str(node, key=key, default=default, prefix=prefix)
    if value is None:
        return None
    if not _ENV_NAME_RE.match(value):
        msg = f"{prefix} must be a valid environment variable name"
        raise ConfigError(msg)
    return value


def _normalize_openai(
    raw: JSONValue | None,
    *,
    base: OpenAIProviderConfig,
) -> OpenAIProviderConfig:
    if raw is None:
        return base
    if not isinstance(raw, Mapping):
        msg = "providers.openai must be a mapping when provided"
        raise ConfigError(msg)
    validate_allowed_keys(raw, allowed=_OPENAI_KEYS, prefix="providers.openai")
    base_url = _optional_trimmed_str(
        raw,
        key="base_url",
        default=base.base_url,
        prefix="providers.openai.base_url",
    )
    return OpenAIProviderConfig(base_url=base_url)


def _normalize_route(
    raw: Mapping[str, JSONValue],
    *,
    base: GatewayRouteConfig | None,
    prefix: str,
) -> GatewayRouteConfig:
    validate_allowed_keys(raw, allowed=_ROUTE_KEYS, prefix=prefix)
    provider = _required_str(raw, key="provider", prefix=f"{prefix}.provider")
    base_url = _optional_trimmed_str(
        raw,
        key="base_url",
        default=(base.base_url if base is not None else None),
        prefix=f"{prefix}.base_url",
    )
    api_key_env = _normalize_api_key_env(
        raw,
        key="api_key_env",
        default=(base.api_key_env if base is not None else None),
        prefix=f"{prefix}.api_key_env",
    )
    headers = str_map_or_none(
        raw,
        key="headers",
        default=(base.headers if base is not None else None),
        prefix=f"{prefix}.headers",
    )
    allow_any_model = bool_field(
        raw,
        key="allow_any_model",
        default=(base.allow_any_model if base is not None else False),
        prefix=f"{prefix}.allow_any_model",
    )
    supports_compaction = bool_field(
        raw,
        key="supports_compaction",
        default=(base.supports_compaction if base is not None else False),
        prefix=f"{prefix}.supports_compaction",
    )
    supports_file_id = bool_field(
        raw,
        key="supports_file_id",
        default=(base.supports_file_id if base is not None else False),
        prefix=f"{prefix}.supports_file_id",
    )
    supports_image_url = bool_field(
        raw,
        key="supports_image_url",
        default=(base.supports_image_url if base is not None else False),
        prefix=f"{prefix}.supports_image_url",
    )
    allow_inline_data_url = bool_field(
        raw,
        key="allow_inline_data_url",
        default=(base.allow_inline_data_url if base is not None else False),
        prefix=f"{prefix}.allow_inline_data_url",
    )
    allowlist_default = base.model_allowlist if base is not None else ()
    allowlist_raw = raw.get("model_allowlist", allowlist_default)
    if allowlist_raw is None:
        model_allowlist = ()
    elif isinstance(allowlist_raw, tuple):
        model_allowlist = allowlist_raw
    else:
        allowlist = as_str_list(allowlist_raw)
        if allowlist is None:
            msg = f"{prefix}.model_allowlist must be a list of strings"
            raise ConfigError(msg)
        model_allowlist = tuple(allowlist)
    return GatewayRouteConfig(
        provider=provider,
        base_url=base_url,
        api_key_env=api_key_env,
        headers=headers,
        model_allowlist=model_allowlist,
        allow_any_model=allow_any_model,
        supports_compaction=supports_compaction,
        supports_file_id=supports_file_id,
        supports_image_url=supports_image_url,
        allow_inline_data_url=allow_inline_data_url,
    )


def _normalize_gateway(
    raw: JSONValue | None,
    *,
    base: GatewayProviderConfig,
) -> GatewayProviderConfig:
    if raw is None:
        return base
    if not isinstance(raw, Mapping):
        msg = "providers.gateway must be a mapping when provided"
        raise ConfigError(msg)
    validate_allowed_keys(raw, allowed=_GATEWAY_KEYS, prefix="providers.gateway")

    routes_raw = raw.get("routes")
    if routes_raw is None:
        return base
    if not isinstance(routes_raw, Mapping):
        msg = "providers.gateway.routes must be a mapping when provided"
        raise ConfigError(msg)

    routes: dict[str, GatewayRouteConfig] = {}
    for key, value in routes_raw.items():
        route_name = _normalize_route_key(str(key))
        if not isinstance(value, Mapping):
            msg = (
                f"providers.gateway.routes.{route_name} must be a mapping when provided"
            )
            raise ConfigError(msg)
        base_route = base.routes.get(route_name)
        routes[route_name] = _normalize_route(
            value,
            base=base_route,
            prefix=f"providers.gateway.routes.{route_name}",
        )
    return GatewayProviderConfig(routes=routes)


def normalize_providers(
    node: Mapping[str, JSONValue] | None,
    base: ProvidersConfig,
) -> ProvidersConfig:
    """Normalize the providers section into typed config."""
    if node is None:
        return base
    validate_allowed_keys(node, allowed={"openai", "gateway"}, prefix="providers")
    openai_cfg = _normalize_openai(node.get("openai"), base=base.openai)
    gateway_cfg = _normalize_gateway(node.get("gateway"), base=base.gateway)
    return ProvidersConfig(openai=openai_cfg, gateway=gateway_cfg)


__all__ = ("normalize_providers",)
