"""Steward task execution and orchestration."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import AgentermError, ConfigError, OperationCancelledError
from agenterm.engine.provider_capabilities import resolve_provider_capabilities
from agenterm.steward.compaction import (
    compaction_input_items,
    serialize_compaction_input_items,
)
from agenterm.steward.schema import (
    StewardCompactionTaskInput,
    StewardSnapshotTaskInput,
    TurnRange,
)
from agenterm.steward.task_runtime import (
    StewardTaskResult,
    effective_steward_model,
    ensure_task_branch,
    execute_compaction_task,
    execute_snapshot_task,
    new_task_id,
)
from agenterm.store.steward.repo import (
    StewardTaskTrigger,
    count_pending_steward_tasks,
    insert_steward_task,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from agenterm.config.compression import (
        CompressionPrimaryBranch,
        CompressionStrategy,
    )
    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.store.async_db import AsyncStore
    from agenterm.store.session.agenterm_session import AgentermSQLiteSession


def _emit_warn(emit_line: Callable[[str], None] | None, message: str) -> None:
    if emit_line is not None:
        emit_line(message)


def _emit_info(emit_line: Callable[[str], None] | None, message: str) -> None:
    if emit_line is not None:
        emit_line(message)


def _compression_order(
    *,
    primary_branch: CompressionPrimaryBranch,
) -> tuple[str, str]:
    if primary_branch == "snapshot":
        return ("compaction", "snapshot")
    return ("snapshot", "compaction")


async def _run_both_if_supported(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    turn_range: TurnRange | None,
    emit_line: Callable[[str], None] | None,
    model_override: str | None,
    instructions_override: str | None,
    primary_branch: CompressionPrimaryBranch,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    first, second = _compression_order(primary_branch=primary_branch)
    snapshot_result: StewardTaskResult | None = None
    compaction_result: StewardTaskResult | None = None
    errors: list[AgentermError] = []

    for kind in (first, second):
        try:
            if kind == "compaction":
                compaction_result = await run_compaction_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    model_override=model_override,
                    instructions_override=instructions_override,
                    emit_line=emit_line,
                    run_number=run_number,
                    origin_branch_id=origin_branch_id,
                    cancel_token=cancel_token,
                )
            else:
                snapshot_result = await run_snapshot_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    turn_range=turn_range,
                    model_override=model_override,
                    emit_line=emit_line,
                    run_number=run_number,
                    origin_branch_id=origin_branch_id,
                    cancel_token=cancel_token,
                )
        except AgentermError as exc:
            errors.append(exc)
            _emit_warn(emit_line, f"warn> Steward {kind} failed: {exc}")

    if compaction_result is None and snapshot_result is None:
        msg = "Steward compression failed to produce a snapshot or compaction."
        raise AgentermError(msg)

    if primary_branch == "snapshot":
        if snapshot_result is not None:
            return snapshot_result
        if compaction_result is not None:
            return compaction_result
    else:
        if compaction_result is not None:
            return compaction_result
        if snapshot_result is not None:
            return snapshot_result
    msg = "Steward compression result resolution failed."
    raise AgentermError(msg)


async def run_compress_policy(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    turn_range: TurnRange | None,
    emit_line: Callable[[str], None] | None,
    model_override: str | None = None,
    instructions_override: str | None = None,
    strategy_override: CompressionStrategy | None = None,
    primary_branch_override: CompressionPrimaryBranch | None = None,
    run_number: int | None = None,
    origin_branch_id: str | None = None,
    cancel_token: CancelToken | None = None,
) -> StewardTaskResult:
    """Run Steward compression based on the configured mode."""
    model_id = model_override or cfg.agent.model
    strategy = strategy_override or cfg.compression.strategy
    primary_branch = primary_branch_override or cfg.compression.primary_branch
    caps = resolve_provider_capabilities(cfg, model_id=model_id)
    origin_branch = origin_branch_id or branch_id
    run_label = f"run={run_number}" if run_number is not None else "run=manual"
    supports_compaction = caps.supports_compaction
    try:
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        _emit_info(
            emit_line,
            "info> Compression starting "
            f"(trigger={trigger}, strategy={strategy}, {run_label}).",
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        if strategy == "snapshot" or not supports_compaction:
            result = await run_snapshot_task(
                cfg=cfg,
                session=session,
                store=store,
                session_id=session_id,
                branch_id=branch_id,
                trigger=trigger,
                turn_range=turn_range,
                model_override=model_override,
                emit_line=emit_line,
                run_number=run_number,
                origin_branch_id=origin_branch,
                cancel_token=cancel_token,
            )
        elif strategy == "both_if_supported":
            result = await _run_both_if_supported(
                cfg=cfg,
                session=session,
                store=store,
                session_id=session_id,
                branch_id=branch_id,
                trigger=trigger,
                turn_range=turn_range,
                emit_line=emit_line,
                model_override=model_override,
                instructions_override=instructions_override,
                primary_branch=primary_branch,
                run_number=run_number,
                origin_branch_id=origin_branch,
                cancel_token=cancel_token,
            )
        else:
            try:
                result = await run_compaction_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    model_override=model_override,
                    instructions_override=instructions_override,
                    emit_line=emit_line,
                    run_number=run_number,
                    origin_branch_id=origin_branch,
                    cancel_token=cancel_token,
                )
            except AgentermError as exc:
                warn_msg = f"warn> Compaction failed; falling back to summary: {exc}"
                _emit_warn(emit_line, warn_msg)
                result = await run_snapshot_task(
                    cfg=cfg,
                    session=session,
                    store=store,
                    session_id=session_id,
                    branch_id=branch_id,
                    trigger=trigger,
                    turn_range=turn_range,
                    model_override=model_override,
                    emit_line=emit_line,
                    run_number=run_number,
                    origin_branch_id=origin_branch,
                    cancel_token=cancel_token,
                )
    except OperationCancelledError:
        _emit_info(emit_line, "info> Compression cancelled.")
        raise

    return result


async def run_snapshot_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    turn_range: TurnRange | None,
    model_override: str | None,
    emit_line: Callable[[str], None] | None,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    """Execute a steward.snapshot task inline."""
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    await ensure_task_branch(session=session, branch_id=branch_id)
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    max_pending = cfg.steward.tasks.max_pending
    pending = await count_pending_steward_tasks(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    if pending >= max_pending:
        msg = "Steward task limit reached; snapshot refused."
        raise ConfigError(msg)

    task_input = StewardSnapshotTaskInput(
        session_id=session_id,
        branch_id=branch_id,
        turn_range=turn_range,
        model=model_override,
    )
    task_record = await insert_steward_task(
        store=store,
        task_id=new_task_id(),
        session_id=session_id,
        branch_id=branch_id,
        kind="snapshot",
        trigger=trigger,
        status="queued",
        model=effective_steward_model(cfg=cfg, override=model_override),
        input_payload=task_input.to_json(),
        trace_id=cfg.run.trace_id,
    )
    return await execute_snapshot_task(
        cfg=cfg,
        session=session,
        store=store,
        task=task_record,
        task_input=task_input,
        trigger=trigger,
        emit_line=emit_line,
        run_number=run_number,
        origin_branch_id=origin_branch_id,
        cancel_token=cancel_token,
    )


async def run_compaction_task(
    *,
    cfg: AppConfig,
    session: AgentermSQLiteSession,
    store: AsyncStore,
    session_id: str,
    branch_id: str,
    trigger: StewardTaskTrigger,
    model_override: str | None,
    instructions_override: str | None,
    emit_line: Callable[[str], None] | None,
    run_number: int | None,
    origin_branch_id: str,
    cancel_token: CancelToken | None,
) -> StewardTaskResult:
    """Execute a steward.compaction task inline."""
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    await ensure_task_branch(session=session, branch_id=branch_id)
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    max_pending = cfg.steward.tasks.max_pending
    pending = await count_pending_steward_tasks(
        store=store,
        session_id=session_id,
        branch_id=branch_id,
    )
    if pending >= max_pending:
        msg = "Steward task limit reached; compaction refused."
        raise ConfigError(msg)

    input_items = await compaction_input_items(
        session=session,
        branch_id=branch_id,
    )
    serialized_items = serialize_compaction_input_items(input_items)
    model_id = model_override or cfg.agent.model
    instructions = instructions_override or cfg.agent.instructions
    caps = resolve_provider_capabilities(cfg, model_id=model_id)
    if not caps.supports_compaction:
        msg = f"Compaction not supported for model {model_id!r}"
        raise ConfigError(msg)
    task_input = StewardCompactionTaskInput(
        session_id=session_id,
        branch_id=branch_id,
        model=model_id,
        instructions=instructions,
        input_items=serialized_items,
    )
    task_record = await insert_steward_task(
        store=store,
        task_id=new_task_id(),
        session_id=session_id,
        branch_id=branch_id,
        kind="compaction",
        trigger=trigger,
        status="queued",
        model=model_id,
        input_payload=task_input.to_json(),
        trace_id=cfg.run.trace_id,
    )
    return await execute_compaction_task(
        cfg=cfg,
        session=session,
        store=store,
        task=task_record,
        task_input=task_input,
        emit_line=emit_line,
        run_number=run_number,
        origin_branch_id=origin_branch_id,
        cancel_token=cancel_token,
    )


__all__ = (
    "StewardTaskResult",
    "run_compaction_task",
    "run_compress_policy",
    "run_snapshot_task",
)
