"""Canonical tool output envelopes for portable FunctionTools and MCP."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Final, Literal

from agenterm.core.json_codec import (
    as_json_object,
    dumps_compact,
    is_json_value,
    parse_json_object,
    require_json_object,
    require_json_value,
)

if TYPE_CHECKING:
    from agenterm.core.json_types import JSONValue

TOOL_OUTPUT_SCHEMA_VERSION: Final[int] = 1


@dataclass(frozen=True)
class ToolOutputError:
    """Typed error payload for tool output envelopes."""

    kind: str
    message: str
    details: dict[str, JSONValue] = field(default_factory=dict)

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this error."""
        details_json = require_json_object(
            value=self.details,
            context="tool_output.error.details",
        )
        return {
            "kind": self.kind,
            "message": self.message,
            "details": details_json,
        }


@dataclass(frozen=True)
class FunctionToolOutputEnvelope:
    """Envelope for portable FunctionTool outputs."""

    tool: str
    ok: bool
    truncated: bool = False
    limit_reason: str | None = None
    payload: dict[str, JSONValue] = field(default_factory=dict)
    error: ToolOutputError | None = None
    schema_version: int = TOOL_OUTPUT_SCHEMA_VERSION

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this envelope."""
        payload_json = require_json_object(
            value=self.payload,
            context=f"tool_output.payload.{self.tool}",
        )
        out: dict[str, JSONValue] = {
            "schema_version": self.schema_version,
            "tool": self.tool,
            "ok": self.ok,
            "truncated": self.truncated,
            "payload": payload_json,
        }
        if self.limit_reason is not None:
            out["limit_reason"] = self.limit_reason
        if not self.ok and self.error is not None:
            out["error"] = self.error.to_json()
        return out

    def to_json_string(self) -> str:
        """Return the compact JSON string for this envelope."""
        return dumps_compact(
            self.to_json(),
            ensure_ascii=True,
            context=f"tool_output.envelope.{self.tool}",
        )


@dataclass(frozen=True)
class McpToolContent:
    """Structured MCP tool output content."""

    text: str
    data: JSONValue | None = None

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this content."""
        out: dict[str, JSONValue] = {"text": self.text}
        if self.data is not None:
            out["data"] = require_json_value(
                value=self.data,
                context="tool_output.mcp.content.data",
            )
        return out


@dataclass(frozen=True)
class McpToolOutputEnvelope:
    """Envelope for MCP tool outputs serialized via structuredContent."""

    server_key: str
    tool_name: str
    ok: bool
    truncated: bool
    limit_reason: str | None = None
    content: McpToolContent | None = None
    error: ToolOutputError | None = None
    schema_version: int = TOOL_OUTPUT_SCHEMA_VERSION

    def to_json(self) -> dict[str, JSONValue]:
        """Return a JSON-safe mapping for this envelope."""
        out: dict[str, JSONValue] = {
            "schema_version": self.schema_version,
            "ok": self.ok,
            "server_key": self.server_key,
            "tool_name": self.tool_name,
            "truncated": self.truncated,
        }
        if self.limit_reason is not None:
            out["limit_reason"] = self.limit_reason
        if self.ok and self.content is not None:
            out["content"] = self.content.to_json()
        elif not self.ok and self.error is not None:
            out["error"] = self.error.to_json()
        return out


def _parse_error(raw: JSONValue | None) -> ToolOutputError | None:
    if not isinstance(raw, dict):
        return None
    kind = raw.get("kind")
    message = raw.get("message")
    details_raw = raw.get("details")
    if not isinstance(kind, str) or not isinstance(message, str):
        return None
    details = as_json_object(details_raw)
    if details is None:
        if details_raw is not None:
            return None
        details = {}
    return ToolOutputError(kind=kind, message=message, details=details)


def _parse_payload_map(payload_raw: JSONValue | None) -> dict[str, JSONValue] | None:
    if payload_raw is None:
        return {}
    payload = as_json_object(payload_raw)
    if payload is None:
        return None
    return payload


def _parse_mcp_content(
    content_raw: JSONValue | None,
) -> McpToolContent | None | Literal["invalid"]:
    if content_raw is None:
        return None
    if not isinstance(content_raw, dict):
        return "invalid"
    text = content_raw.get("text")
    if not isinstance(text, str):
        return "invalid"
    data_raw = content_raw.get("data")
    if data_raw is not None and not is_json_value(value=data_raw):
        return "invalid"
    return McpToolContent(text=text, data=data_raw)


def _parse_limit_reason(value: JSONValue | None) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    return None


def parse_function_tool_output_envelope(
    payload: str,
) -> FunctionToolOutputEnvelope | None:
    """Parse a FunctionTool output envelope from a JSON string."""
    parsed = parse_json_object(payload)
    if parsed is None or parsed.get("schema_version") != TOOL_OUTPUT_SCHEMA_VERSION:
        return None
    tool = parsed.get("tool")
    ok = parsed.get("ok")
    if not isinstance(tool, str) or not isinstance(ok, bool):
        return None
    truncated_raw = parsed.get("truncated")
    if not isinstance(truncated_raw, bool):
        return None
    truncated = truncated_raw
    limit_reason = _parse_limit_reason(parsed.get("limit_reason"))
    payload_map = _parse_payload_map(parsed.get("payload"))
    if payload_map is None:
        return None
    error = _parse_error(parsed.get("error"))
    if not ok and error is None:
        return None
    return FunctionToolOutputEnvelope(
        tool=tool,
        ok=ok,
        truncated=truncated,
        limit_reason=limit_reason,
        payload=payload_map,
        error=error,
        schema_version=TOOL_OUTPUT_SCHEMA_VERSION,
    )


def parse_mcp_tool_output_envelope(payload: str) -> McpToolOutputEnvelope | None:
    """Parse an MCP tool output envelope from a JSON string."""
    parsed = parse_json_object(payload)
    if parsed is None:
        return None
    schema_version = parsed.get("schema_version")
    if schema_version != TOOL_OUTPUT_SCHEMA_VERSION:
        return None
    ok = parsed.get("ok")
    server_key = parsed.get("server_key")
    tool_name = parsed.get("tool_name")
    truncated = parsed.get("truncated")
    if (
        not isinstance(ok, bool)
        or not isinstance(server_key, str)
        or not isinstance(tool_name, str)
        or not isinstance(truncated, bool)
    ):
        return None
    limit_reason = _parse_limit_reason(parsed.get("limit_reason"))
    content = _parse_mcp_content(parsed.get("content"))
    error = _parse_error(parsed.get("error"))
    if content == "invalid" or (ok and content is None) or (not ok and error is None):
        return None
    return McpToolOutputEnvelope(
        server_key=server_key,
        tool_name=tool_name,
        ok=ok,
        truncated=truncated,
        limit_reason=limit_reason,
        content=content,
        error=error,
        schema_version=TOOL_OUTPUT_SCHEMA_VERSION,
    )


__all__ = (
    "TOOL_OUTPUT_SCHEMA_VERSION",
    "FunctionToolOutputEnvelope",
    "McpToolContent",
    "McpToolOutputEnvelope",
    "ToolOutputError",
    "parse_function_tool_output_envelope",
    "parse_mcp_tool_output_envelope",
)
