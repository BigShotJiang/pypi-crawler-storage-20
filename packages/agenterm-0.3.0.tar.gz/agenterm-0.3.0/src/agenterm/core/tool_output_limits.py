"""Shared output-length clamps for tool output envelopes."""

from __future__ import annotations

from dataclasses import replace
from typing import TYPE_CHECKING, TypeVar

from agenterm.core.json_codec import json_size
from agenterm.core.tool_output_payload_clamp import limit_payload_to_fit

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.core.tool_output_envelope import (
        FunctionToolOutputEnvelope,
        McpToolOutputEnvelope,
    )

_TEnv = TypeVar("_TEnv")
_ELLIPSIS = "..."
_ELLIPSIS_LEN = len(_ELLIPSIS)


def _truncate_text_to_fit(
    env: _TEnv,
    *,
    max_chars: int,
    text: str,
    apply_text: Callable[[_TEnv, str], _TEnv],
    length: Callable[[_TEnv], int],
) -> str:
    if max_chars <= 0:
        return ""
    low = 0
    high = min(len(text), max_chars)
    best = ""
    while low <= high:
        mid = (low + high) // 2
        candidate = limit_tool_output_text(text, max_chars=mid)
        if length(apply_text(env, candidate)) <= max_chars:
            best = candidate
            low = mid + 1
        else:
            high = mid - 1
    return best


def limit_tool_output_text(text: str, *, max_chars: int) -> str:
    """Return a truncated text tool output within max_chars."""
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    if max_chars <= _ELLIPSIS_LEN:
        return "." * max_chars
    remaining = max_chars - _ELLIPSIS_LEN
    head = remaining // 2
    tail = remaining - head
    if head <= 0:
        return f"{_ELLIPSIS}{text[-tail:]}" if tail > 0 else _ELLIPSIS
    if tail <= 0:
        return f"{text[:head]}{_ELLIPSIS}"
    return f"{text[:head]}{_ELLIPSIS}{text[-tail:]}"


def _function_env_size(env: FunctionToolOutputEnvelope) -> int:
    return json_size(env.to_json())


def _with_payload(
    env: FunctionToolOutputEnvelope,
    payload: Mapping[str, JSONValue],
) -> FunctionToolOutputEnvelope:
    return replace(env, payload=dict(payload))


def _with_function_error_message(
    env: FunctionToolOutputEnvelope,
    message: str,
) -> FunctionToolOutputEnvelope:
    if env.error is None:
        return env
    return replace(env, error=replace(env.error, message=message))


def _truncate_function_ok(
    env: FunctionToolOutputEnvelope,
    *,
    max_chars: int,
) -> FunctionToolOutputEnvelope:
    baseline = _with_payload(env, {})
    if _function_env_size(baseline) > max_chars:
        return baseline

    def _size(candidate_payload: Mapping[str, JSONValue]) -> int:
        return _function_env_size(_with_payload(env, candidate_payload))

    def _limit_text(text: str, max_len: int) -> str:
        return limit_tool_output_text(text, max_chars=max_len)

    payload = limit_payload_to_fit(
        payload=env.payload,
        max_chars=max_chars,
        size=_size,
        limit_text=_limit_text,
    )
    return _with_payload(env, payload)


def _truncate_function_error(
    env: FunctionToolOutputEnvelope,
    *,
    max_chars: int,
) -> FunctionToolOutputEnvelope:
    error = env.error
    if error is None:
        return env
    if error.details:
        trimmed = replace(env, error=replace(error, details={}))
        if _function_env_size(trimmed) <= max_chars:
            return trimmed
        env = trimmed
        error = env.error
        if error is None:
            return env
    if error.message:
        fitted = _truncate_text_to_fit(
            env,
            max_chars=max_chars,
            text=error.message,
            apply_text=_with_function_error_message,
            length=_function_env_size,
        )
        return _with_function_error_message(env, fitted)
    return env


def limit_function_tool_output(
    env: FunctionToolOutputEnvelope,
    *,
    max_chars: int,
) -> FunctionToolOutputEnvelope:
    """Clamp a FunctionTool output envelope to max_chars."""
    if max_chars <= 0:
        return env
    if _function_env_size(env) <= max_chars:
        return env
    truncated_env = replace(env, truncated=True, limit_reason="char_limit")
    if truncated_env.ok:
        return _truncate_function_ok(truncated_env, max_chars=max_chars)
    return _truncate_function_error(truncated_env, max_chars=max_chars)


def _mcp_env_size(env: McpToolOutputEnvelope) -> int:
    return json_size(env.to_json())


def _with_mcp_content_text(
    env: McpToolOutputEnvelope,
    text: str,
) -> McpToolOutputEnvelope:
    if env.content is None:
        return env
    return replace(env, content=replace(env.content, text=text))


def _with_mcp_error_message(
    env: McpToolOutputEnvelope,
    message: str,
) -> McpToolOutputEnvelope:
    if env.error is None:
        return env
    return replace(env, error=replace(env.error, message=message))


def _truncate_mcp_ok(
    env: McpToolOutputEnvelope,
    *,
    max_chars: int,
) -> McpToolOutputEnvelope:
    content = env.content
    if content is None:
        return env
    if content.data is not None:
        trimmed = replace(env, content=replace(content, data=None))
        if _mcp_env_size(trimmed) <= max_chars:
            return trimmed
        env = trimmed
        content = env.content
        if content is None:
            return env
    text = content.text
    if text:
        fitted = _truncate_text_to_fit(
            env,
            max_chars=max_chars,
            text=text,
            apply_text=_with_mcp_content_text,
            length=_mcp_env_size,
        )
        return _with_mcp_content_text(env, fitted)
    return env


def _truncate_mcp_error(
    env: McpToolOutputEnvelope,
    *,
    max_chars: int,
) -> McpToolOutputEnvelope:
    error = env.error
    if error is None:
        return env
    if error.details:
        trimmed = replace(env, error=replace(error, details={}))
        if _mcp_env_size(trimmed) <= max_chars:
            return trimmed
        env = trimmed
        error = env.error
        if error is None:
            return env
    if error.message:
        fitted = _truncate_text_to_fit(
            env,
            max_chars=max_chars,
            text=error.message,
            apply_text=_with_mcp_error_message,
            length=_mcp_env_size,
        )
        return _with_mcp_error_message(env, fitted)
    return env


def limit_mcp_tool_output(
    env: McpToolOutputEnvelope,
    *,
    max_chars: int,
) -> McpToolOutputEnvelope:
    """Clamp an MCP output envelope to max_chars."""
    if max_chars <= 0:
        return env
    if _mcp_env_size(env) <= max_chars:
        return env
    truncated_env = replace(env, truncated=True, limit_reason="char_limit")
    if truncated_env.ok:
        return _truncate_mcp_ok(truncated_env, max_chars=max_chars)
    return _truncate_mcp_error(truncated_env, max_chars=max_chars)


__all__ = (
    "limit_function_tool_output",
    "limit_mcp_tool_output",
    "limit_tool_output_text",
)
