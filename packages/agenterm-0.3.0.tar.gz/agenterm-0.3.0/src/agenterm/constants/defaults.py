"""Default identifiers and values shared across config surfaces."""

from __future__ import annotations

from typing import Final

DEFAULT_MODEL_ID: Final[str] = "openai/gpt-5.2"

__all__ = ("DEFAULT_MODEL_ID",)
