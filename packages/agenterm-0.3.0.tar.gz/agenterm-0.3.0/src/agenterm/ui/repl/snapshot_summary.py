"""Rendering helpers for Steward summary snapshots."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import (
    as_json_list,
    as_json_object,
    as_str,
    parse_json_object,
)
from agenterm.core.response_items import serialize_input_item
from agenterm.steward.schema import (
    MemorySnapshot,
    MemorySnapshotFile,
    parse_memory_snapshot,
)

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue


_SNAPSHOT_PREFIX = "memory_snapshot_json:"
_SNAPSHOT_ROLES: tuple[str, ...] = ("developer", "assistant")
_SNAPSHOT_PART_TYPES: tuple[str, ...] = ("input_text", "output_text")


def _message_parts(
    msg: Mapping[str, JSONValue],
) -> list[dict[str, JSONValue]]:
    parts_obj = as_json_list(msg.get("content"))
    if parts_obj is None:
        return []
    out: list[dict[str, JSONValue]] = []
    for raw in parts_obj:
        m = as_json_object(raw)
        if m is not None:
            out.append(m)
    return out


def _to_json_object(item: TResponseInputItem) -> dict[str, JSONValue] | None:
    try:
        return serialize_input_item(item, context="snapshot_summary.item")
    except ConfigError:
        return None


def _extract_snapshot(items: Sequence[TResponseInputItem]) -> MemorySnapshot | None:
    for item in items:
        obj = _to_json_object(item)
        if obj is None:
            continue
        if obj.get("type") != "message":
            continue
        role = obj.get("role")
        if not isinstance(role, str) or role not in _SNAPSHOT_ROLES:
            continue
        for part in _message_parts(obj):
            part_type = part.get("type")
            if not isinstance(part_type, str) or part_type not in _SNAPSHOT_PART_TYPES:
                continue
            text = as_str(part.get("text"))
            if not text or not text.startswith(_SNAPSHOT_PREFIX):
                continue
            payload_str = text[len(_SNAPSHOT_PREFIX) :].lstrip()
            payload = parse_json_object(payload_str)
            if payload is None:
                msg = "Snapshot payload is not valid JSON"
                raise ConfigError(msg)
            return parse_memory_snapshot(payload)
    return None


def _render_list(label: str, items: Sequence[str]) -> list[str]:
    if not items:
        return [f"{label}: none"]
    return [label, *[f"- {item}" for item in items]]


def _render_surfaces(items: Sequence[MemorySnapshotFile]) -> list[str]:
    if not items:
        return ["Surfaces: none"]
    lines = ["Surfaces:"]
    lines.extend([f"- {item.path}: {item.note}" for item in items])
    return lines


def format_memory_snapshot_lines(
    items: Sequence[TResponseInputItem],
) -> list[str] | None:
    """Return summary lines for a MemorySnapshot payload."""
    snapshot = _extract_snapshot(items)
    if snapshot is None:
        return None
    lines: list[str] = [
        "snapshot> last summary",
        f"- summary: {snapshot.summary}",
        "",
    ]
    lines.extend(_render_list("Learnings:", snapshot.learnings))
    lines.append("")
    lines.extend(_render_list("Pending:", snapshot.pending))
    lines.append("")
    lines.extend(_render_list("Calibrations:", snapshot.calibrations))
    lines.append("")
    lines.extend(_render_surfaces(snapshot.surfaces))
    return lines


__all__ = ("format_memory_snapshot_lines",)
