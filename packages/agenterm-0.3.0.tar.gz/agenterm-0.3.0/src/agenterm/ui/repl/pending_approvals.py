"""REPL helpers for resolving pending approvals."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenterm.core.approvals import ApprovalsContext
    from agenterm.ui.repl.phase_state import ReplHudLevel


def has_pending_approvals(approvals: ApprovalsContext) -> bool:
    """Return True when any approval manager has pending items."""
    return bool(
        approvals.compress.pending()
        or approvals.shell.pending()
        or approvals.patch.pending()
        or approvals.mcp.pending(),
    )


def resolve_next_pending(
    approvals: ApprovalsContext,
    *,
    approved: bool,
) -> str | None:
    """Resolve the next pending approval and return its id (or None)."""
    return resolve_next_pending_with_reason(
        approvals,
        approved=approved,
        reason=None,
    )


def resolve_next_pending_with_reason(
    approvals: ApprovalsContext,
    *,
    approved: bool,
    reason: str | None,
) -> str | None:
    """Resolve the next pending approval and return its id (or None)."""
    compress_mgr = approvals.compress
    pending_compress = compress_mgr.pending()
    if pending_compress:
        item = pending_compress[0]
        compress_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    shell_mgr = approvals.shell
    pending_shell = shell_mgr.pending()
    if pending_shell:
        item = pending_shell[0]
        shell_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    patch_mgr = approvals.patch
    pending_patch = patch_mgr.pending()
    if pending_patch:
        item = pending_patch[0]
        patch_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    mcp_mgr = approvals.mcp
    pending_mcp = mcp_mgr.pending()
    if pending_mcp:
        item = pending_mcp[0]
        mcp_mgr.resolve(item.id, approved=approved, reason=reason)
        return item.id

    return None


def handle_running_run_input(
    *,
    stripped: str,
    approvals: ApprovalsContext,
) -> tuple[str, ReplHudLevel]:
    """Handle a REPL line entered while a run is running.

    Returns:
      A short HUD notice to surface in the TUI and its level.

    """
    tokens = (stripped or "").split(maxsplit=1)
    head = tokens[0].lower() if tokens else ""
    tail = tokens[1].strip() if len(tokens) > 1 else ""

    if head in ("y", "yes"):
        ident = resolve_next_pending_with_reason(
            approvals,
            approved=True,
            reason=None,
        )
        if ident is None:
            return "No pending approvals.", "info"
        return f"Approved: {ident}", "info"
    if head in ("n", "no"):
        ident = resolve_next_pending_with_reason(
            approvals,
            approved=False,
            reason=(tail or None),
        )
        if ident is None:
            return "No pending approvals.", "info"
        return f"Rejected: {ident}", "warn"
    if has_pending_approvals(approvals):
        return "Approval pending - type y/n or n <reason> (or /approvals list).", "warn"
    return "Run running - ESC/Ctrl+C cancels.", "info"
