"""FunctionTool call parsing helpers for transcript rendering.

The OpenAI Responses API represents function tool calls as `function_call` items
with JSON-encoded `arguments`. agenterm owns several FunctionTools whose call
arguments we want to render with bounded details and/or index as artifacts.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.json_codec import (
    as_json_object,
    as_str,
    parse_json_object,
)
from agenterm.core.text import shorten_line
from agenterm.ui.transcript.diffs import (
    DIFF_HINT_LINE,
    format_unified_diff_lines,
)

if TYPE_CHECKING:
    from openai.types.responses.response_function_tool_call import (
        ResponseFunctionToolCall,
    )

    from agenterm.core.json_types import JSONValue
    from agenterm.ui.transcript.model import TranscriptPolicy


def _parse_call_payload(
    call: ResponseFunctionToolCall,
) -> dict[str, JSONValue] | None:
    raw_args = call.arguments or ""
    return parse_json_object(raw_args) if raw_args else None


def apply_patch_function_call_artifact(
    call: ResponseFunctionToolCall,
) -> tuple[str, str, str | None] | None:
    """Return (op_type, path, diff) for apply_patch calls or None when not parseable."""
    if call.name != "apply_patch":
        return None
    payload = _parse_call_payload(call)
    if payload is None:
        return None
    operation = as_json_object(payload.get("operation"))
    if operation is None:
        return None
    op_type = as_str(operation.get("type"))
    path = as_str(operation.get("path"))
    if not op_type or not path:
        return None
    diff = as_str(operation.get("diff"))
    return op_type, path, diff


def apply_patch_function_call_detail_lines(
    call: ResponseFunctionToolCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    """Render bounded transcript detail lines for an apply_patch FunctionTool call."""
    parsed = apply_patch_function_call_artifact(call)
    if parsed is None:
        return []
    op_type, path, diff = parsed
    lines: list[str] = [f"- op: {op_type}", f"- path: {path}"]
    if policy.verbosity == "quiet" or policy.diffs_mode == "off":
        return lines
    if not diff:
        return lines
    diff_lines = format_unified_diff_lines(diff)
    if not diff_lines:
        return lines
    lines.append("- diff:")
    lines.extend(
        [f"  {line}" for line in diff_lines[: policy.tool_detail_max_lines]],
    )
    if len(diff_lines) > policy.tool_detail_max_lines:
        lines.append("  …")
        lines.append(f"  {DIFF_HINT_LINE}")
    return lines


def shell_function_call_detail_lines(
    call: ResponseFunctionToolCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    """Render bounded transcript detail lines for a shell FunctionTool call."""
    if call.name != "shell":
        return []
    payload = _parse_call_payload(call)
    if payload is None:
        return []

    cmds_raw = payload.get("commands")
    cmds: list[str] = []
    if isinstance(cmds_raw, list):
        cmds.extend([cmd for cmd in cmds_raw if isinstance(cmd, str) and cmd])

    lines: list[str] = []
    cwd = as_str(payload.get("cwd"))
    if cwd:
        lines.append(f"- cwd: {cwd}")
    if cmds:
        lines.append("- commands:")
    lines.extend(
        [
            f"  {shorten_line(cmd, limit=policy.tool_detail_max_chars)}"
            for cmd in cmds[: policy.tool_detail_max_lines]
        ],
    )
    if len(cmds) > policy.tool_detail_max_lines:
        lines.append("  …")

    timeout = payload.get("timeout_ms")
    if isinstance(timeout, int) and not isinstance(timeout, bool):
        lines.append(f"- timeout_ms: {timeout}")
    max_out = payload.get("max_output_length")
    if isinstance(max_out, int) and not isinstance(max_out, bool):
        lines.append(f"- max_output_length: {max_out}")
    return lines


def parallel_function_call_detail_lines(
    call: ResponseFunctionToolCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    """Render bounded transcript detail lines for a parallel FunctionTool call."""
    if call.name != "parallel":
        return []
    payload = _parse_call_payload(call)
    if payload is None:
        return []
    calls_raw = payload.get("calls")
    if not isinstance(calls_raw, list):
        return []
    lines: list[str] = [f"- calls: {len(calls_raw)}"]
    tool_names: list[str] = []
    for entry in calls_raw:
        if not isinstance(entry, dict):
            continue
        name = as_str(entry.get("tool"))
        if name:
            tool_names.append(name)
    if tool_names:
        preview = ", ".join(tool_names[: policy.tool_detail_max_lines])
        lines.append(
            f"- tools: {shorten_line(preview, limit=policy.tool_detail_max_chars)}"
        )
        if len(tool_names) > policy.tool_detail_max_lines:
            lines.append("  …")
    return lines


__all__ = (
    "apply_patch_function_call_artifact",
    "apply_patch_function_call_detail_lines",
    "parallel_function_call_detail_lines",
    "shell_function_call_detail_lines",
)
