"""Tool call detail line helpers for transcript blocks.

These helpers take raw tool call items and render bounded, deterministic detail
lines. This module is intentionally "pure" (no printing) so it can be reused
across CLI/REPL renderers.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.text import shorten_line

if TYPE_CHECKING:
    from agents.items import MCPApprovalRequestItem
    from openai.types.responses.response_output_item import (
        ImageGenerationCall,
        McpCall,
    )

    from agenterm.ui.transcript.model import TranscriptPolicy


def image_generation_call_detail_lines(
    call: ImageGenerationCall,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Return bounded detail lines for an image_generation tool call."""
    lines: list[str] = [
        f"- status: {call.status}",
        f"- id: {shorten_line(call.id, limit=policy.tool_detail_max_chars)}",
    ]
    if isinstance(call.result, str) and call.result:
        lines.append(f"- result: (base64, {len(call.result)} chars)")
    return tuple(lines)


def mcp_call_detail_lines(
    call: McpCall,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Return bounded detail lines for an MCP tool call."""
    lines: list[str] = [f"- server: {call.server_label}", f"- tool: {call.name}"]
    args = call.arguments or ""
    if args:
        preview = shorten_line(args, limit=policy.mcp_args_preview_max_chars)
        lines.append(f"- args: {preview}")
    return tuple(lines)


def mcp_approval_request_detail_lines(
    item: MCPApprovalRequestItem,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Return bounded detail lines for an MCP approval request item."""
    req = item.raw_item
    lines: list[str] = [
        f"- request_id: {req.id}",
        f"- server: {req.server_label}",
        f"- tool: {req.name}",
    ]
    args = req.arguments or ""
    if args:
        preview = shorten_line(args, limit=policy.mcp_args_preview_max_chars)
        lines.append(f"- args: {preview}")
    return tuple(lines)


__all__ = (
    "image_generation_call_detail_lines",
    "mcp_approval_request_detail_lines",
    "mcp_call_detail_lines",
)
