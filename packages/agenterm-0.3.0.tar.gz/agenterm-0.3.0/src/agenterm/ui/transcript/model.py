"""Typed view model for transcript rendering policy (shared across surfaces)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.constants.display import (
    TRANSCRIPT_ATTACHMENTS_MAX_LINES_DEFAULT,
    TRANSCRIPT_ATTACHMENTS_PATH_MAX_CHARS_DEFAULT,
    TRANSCRIPT_MCP_ARGS_PREVIEW_MAX_CHARS_DEFAULT,
    TRANSCRIPT_SHELL_PREVIEW_MAX_CHARS_DEFAULT,
    TRANSCRIPT_TOOL_DETAIL_MAX_CHARS_DEFAULT,
    TRANSCRIPT_TOOL_DETAIL_MAX_LINES_DEFAULT,
    TRANSCRIPT_TOOL_OUTPUT_MAX_LINES_DEFAULT,
)
from agenterm.constants.limits import TOOL_OUTPUT_MAX_CHARS_DEFAULT

if TYPE_CHECKING:
    from agenterm.core.choices.repl import (
        ReplDiffsMode,
        ReplReasoningMode,
        ReplVerbosity,
    )


@dataclass(frozen=True)
class TranscriptPolicy:
    """Policy controlling what the transcript renders and how it is bounded.

    This policy is a UI concern: it must be deterministic and bounded, but it
    must not mutate engine or session behavior.
    """

    verbosity: ReplVerbosity = "normal"
    reasoning_mode: ReplReasoningMode = "summary"
    diffs_mode: ReplDiffsMode = "summary"

    shell_preview_max_chars: int = TRANSCRIPT_SHELL_PREVIEW_MAX_CHARS_DEFAULT
    tool_output_max_lines: int = TRANSCRIPT_TOOL_OUTPUT_MAX_LINES_DEFAULT
    tool_output_max_chars: int = TOOL_OUTPUT_MAX_CHARS_DEFAULT
    reasoning_summary_max_chars: int = 0
    tool_detail_max_lines: int = TRANSCRIPT_TOOL_DETAIL_MAX_LINES_DEFAULT
    tool_detail_max_chars: int = TRANSCRIPT_TOOL_DETAIL_MAX_CHARS_DEFAULT
    mcp_args_preview_max_chars: int = TRANSCRIPT_MCP_ARGS_PREVIEW_MAX_CHARS_DEFAULT
    attachments_max_lines: int = TRANSCRIPT_ATTACHMENTS_MAX_LINES_DEFAULT
    attachments_path_max_chars: int = TRANSCRIPT_ATTACHMENTS_PATH_MAX_CHARS_DEFAULT


__all__ = ("TranscriptPolicy",)
