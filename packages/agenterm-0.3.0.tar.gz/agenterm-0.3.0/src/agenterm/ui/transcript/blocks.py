"""Typed transcript blocks derived from streamed run items.

The transcript is the operator's truth surface. To keep it deterministic and
inspectable, we first map each `RunItem` into a typed block model (with bounded
detail lines) and only then render it to the console.

The REPL may additionally index extracted artifacts (e.g., apply_patch diffs)
from these blocks without re-parsing printed output.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from agents.items import (
    MCPApprovalRequestItem,
    MCPApprovalResponseItem,
    ReasoningItem,
    RunItem,
    ToolCallItem,
    ToolCallOutputItem,
)
from openai.types.responses.response_file_search_tool_call import (
    ResponseFileSearchToolCall,
)
from openai.types.responses.response_function_tool_call import (
    ResponseFunctionToolCall,
)
from openai.types.responses.response_function_web_search import (
    ResponseFunctionWebSearch,
)
from openai.types.responses.response_output_item import (
    ImageGenerationCall,
    McpCall,
)

from agenterm.core.reasoning import extract_reasoning_data
from agenterm.core.tool_output_envelope import (
    parse_function_tool_output_envelope,
    parse_mcp_tool_output_envelope,
)
from agenterm.ui.tool_events import (
    label_for_tool_type,
    raw_item_type,
    shorten_line,
)
from agenterm.ui.transcript.function_tool_calls import (
    apply_patch_function_call_artifact,
    apply_patch_function_call_detail_lines,
    parallel_function_call_detail_lines,
    shell_function_call_detail_lines,
)
from agenterm.ui.transcript.mcp_failures import (
    mcp_call_failed,
    mcp_failure_detail_lines,
)
from agenterm.ui.transcript.search_details import (
    file_search_detail_lines,
    web_search_detail_lines,
)
from agenterm.ui.transcript.tool_call_details import (
    image_generation_call_detail_lines,
    mcp_approval_request_detail_lines,
    mcp_call_detail_lines,
)
from agenterm.ui.transcript.tool_output_envelope import (
    function_tool_envelope_lines,
    mcp_envelope_lines,
)

if TYPE_CHECKING:
    from agenterm.ui.transcript.model import TranscriptPolicy


@dataclass(frozen=True)
class ApplyPatchCallArtifact:
    """The last apply_patch tool call as a typed artifact.

    This captures the raw tool call operation and diff text so REPL commands
    can re-render it with different boundedness policies than the live transcript
    without re-parsing printed output.
    """

    op_type: str
    path: str
    diff: str | None


@dataclass(frozen=True)
class TranscriptArtifacts:
    """Typed artifacts extracted while building transcript blocks."""

    apply_patch_call: ApplyPatchCallArtifact | None = None


@dataclass(frozen=True)
class ReasoningBlock:
    """Transcript block for reasoning items.

    Fields:
        summary_text: Brief summary (always present, may be empty).
        content_text: Full thinking text (when provider supplies it).
        has_real_thinking: True if content or encrypted_content exists.
    """

    kind: Literal["reasoning"]
    summary_text: str | None
    content_text: str | None
    has_real_thinking: bool

    @property
    def display_text(self) -> str | None:
        """Return text for display: prefers content over summary."""
        return self.content_text if self.content_text else self.summary_text


@dataclass(frozen=True)
class ToolCallBlock:
    """Transcript block for tool call items."""

    kind: Literal["tool_call"]
    label: str
    detail_lines: tuple[str, ...]


@dataclass(frozen=True)
class ToolOutputBlock:
    """Transcript block for tool output items."""

    kind: Literal["tool_output"]
    label: str
    success: bool | None
    detail_lines: tuple[str, ...]


@dataclass(frozen=True)
class ImageArtifactBlock:
    """Transcript block for a generated image artifact."""

    kind: Literal["artifact_image"]
    artifact_id: str
    path: str
    mime: str
    size_bytes: int


type TranscriptBlock = (
    ReasoningBlock | ToolCallBlock | ToolOutputBlock | ImageArtifactBlock
)


@dataclass(frozen=True)
class TranscriptBuild:
    """Result of mapping one RunItem into a transcript block + extracted artifacts."""

    block: TranscriptBlock | None
    artifacts: TranscriptArtifacts


def _build_reasoning_block(
    item: ReasoningItem,
    *,
    policy: TranscriptPolicy,
) -> ReasoningBlock:
    """Build a ReasoningBlock from a ReasoningItem."""
    data = extract_reasoning_data(item)
    summary = data.summary_text
    content = data.content_text
    limit = policy.reasoning_summary_max_chars
    if limit > 0:
        if summary and len(summary) > limit:
            summary = f"{summary[: limit - 1]}…"
        if content and len(content) > limit:
            content = f"{content[: limit - 1]}…"
    return ReasoningBlock(
        kind="reasoning",
        summary_text=summary,
        content_text=content,
        has_real_thinking=data.has_real_thinking,
    )


def _mcp_approval_response_block(
    item: MCPApprovalResponseItem,
    *,
    policy: TranscriptPolicy,
) -> ToolOutputBlock:
    raw = item.raw_item
    approval_request_id = raw.get("approval_request_id", "")
    approve_val = raw.get("approve", False)
    reason = raw.get("reason")
    lines: list[str] = [
        f"- request_id: {approval_request_id}",
        f"- approve: {approve_val}",
    ]
    if reason:
        lines.append(
            f"- reason: {shorten_line(reason, limit=policy.tool_detail_max_chars)}",
        )
    return ToolOutputBlock(
        kind="tool_output",
        label="mcp approval",
        success=approve_val,
        detail_lines=tuple(lines),
    )


def _function_tool_call_detail_lines(
    call: ResponseFunctionToolCall,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    if call.name == "apply_patch":
        return tuple(apply_patch_function_call_detail_lines(call, policy=policy))
    if call.name == "parallel":
        return tuple(parallel_function_call_detail_lines(call, policy=policy))
    if call.name == "shell":
        return tuple(shell_function_call_detail_lines(call, policy=policy))
    return ()


def _tool_call_detail_lines(
    item: ToolCallItem,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    raw_obj = item.raw_item
    lines: tuple[str, ...] = ()
    if isinstance(raw_obj, ResponseFunctionToolCall):
        lines = _function_tool_call_detail_lines(raw_obj, policy=policy)
    elif isinstance(raw_obj, ResponseFileSearchToolCall):
        lines = tuple(file_search_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, ResponseFunctionWebSearch):
        lines = tuple(web_search_detail_lines(raw_obj, policy=policy))
    elif isinstance(raw_obj, McpCall):
        lines = mcp_call_detail_lines(raw_obj, policy=policy)
    elif isinstance(raw_obj, ImageGenerationCall):
        lines = image_generation_call_detail_lines(raw_obj, policy=policy)
    return lines


def build_transcript_item(
    item: RunItem,
    *,
    policy: TranscriptPolicy,
) -> TranscriptBuild:
    """Convert a RunItem to a typed transcript block (and extracted artifacts)."""
    artifacts = _build_transcript_artifacts(item)
    block = _build_transcript_block(item, policy=policy)
    return TranscriptBuild(block=block, artifacts=artifacts)


def _build_transcript_artifacts(item: RunItem) -> TranscriptArtifacts:
    if not isinstance(item, ToolCallItem):
        return TranscriptArtifacts()
    raw = item.raw_item
    if isinstance(raw, ResponseFunctionToolCall):
        parsed = apply_patch_function_call_artifact(raw)
        if parsed is not None:
            op_type, path, diff = parsed
            return TranscriptArtifacts(
                apply_patch_call=ApplyPatchCallArtifact(
                    op_type=op_type,
                    path=path,
                    diff=diff,
                ),
            )
    return TranscriptArtifacts()


def _build_tool_call_block(
    item: ToolCallItem,
    *,
    policy: TranscriptPolicy,
) -> TranscriptBlock:
    raw = item.raw_item
    if isinstance(raw, ResponseFunctionToolCall):
        label = raw.name
    else:
        label = label_for_tool_type(raw_item_type(raw), is_output=False)
    details = _tool_call_detail_lines(item, policy=policy)
    return ToolCallBlock(kind="tool_call", label=label, detail_lines=details)


def _build_tool_output_block(
    item: ToolCallOutputItem,
    *,
    policy: TranscriptPolicy,
) -> ToolOutputBlock:
    label = label_for_tool_type(raw_item_type(item.raw_item), is_output=True)
    details: tuple[str, ...] = ()
    success: bool | None = True
    out = item.output
    if isinstance(out, str):
        fn_env = parse_function_tool_output_envelope(out)
        if fn_env is not None:
            label = fn_env.tool
            success = fn_env.ok
            details = function_tool_envelope_lines(fn_env, policy=policy)
        else:
            mcp_env = parse_mcp_tool_output_envelope(out)
            if mcp_env is not None:
                label = "mcp"
                success = mcp_env.ok
                details = mcp_envelope_lines(mcp_env, policy=policy)
    return ToolOutputBlock(
        kind="tool_output",
        label=label,
        success=success,
        detail_lines=details,
    )


def _build_transcript_block(
    item: RunItem,
    *,
    policy: TranscriptPolicy,
) -> TranscriptBlock | None:
    block: TranscriptBlock | None
    if isinstance(item, ReasoningItem):
        if policy.reasoning_mode != "off" and policy.verbosity != "quiet":
            block = _build_reasoning_block(item, policy=policy)
        else:
            block = ReasoningBlock(
                kind="reasoning",
                summary_text=None,
                content_text=None,
                has_real_thinking=False,
            )
    elif isinstance(item, MCPApprovalRequestItem):
        block = ToolCallBlock(
            kind="tool_call",
            label="mcp approval",
            detail_lines=mcp_approval_request_detail_lines(item, policy=policy),
        )
    elif isinstance(item, MCPApprovalResponseItem):
        block = _mcp_approval_response_block(item, policy=policy)
    elif isinstance(item, ToolCallItem):
        raw = item.raw_item
        if isinstance(raw, McpCall) and mcp_call_failed(raw):
            block = ToolOutputBlock(
                kind="tool_output",
                label=label_for_tool_type(raw_item_type(raw), is_output=True),
                success=False,
                detail_lines=mcp_failure_detail_lines(raw, policy=policy),
            )
        else:
            block = _build_tool_call_block(item, policy=policy)
    elif isinstance(item, ToolCallOutputItem):
        block = _build_tool_output_block(item, policy=policy)
    else:
        block = None
    return block


__all__ = (
    "ApplyPatchCallArtifact",
    "ImageArtifactBlock",
    "ReasoningBlock",
    "ToolCallBlock",
    "ToolOutputBlock",
    "TranscriptArtifacts",
    "TranscriptBlock",
    "TranscriptBuild",
    "build_transcript_item",
)
