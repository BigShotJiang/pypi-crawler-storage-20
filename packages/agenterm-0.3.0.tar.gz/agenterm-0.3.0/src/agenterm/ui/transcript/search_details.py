"""Detail-line builders for search tool call transcript blocks.

These helpers keep `agenterm.ui.transcript.blocks` focused on typed block mapping while
providing a single place to evolve stable, bounded formatting for search tool
calls.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.json_codec import is_json_value
from agenterm.ui.tool_events import BoundedLineWriter, shorten_line

if TYPE_CHECKING:
    from openai.types.responses.response_file_search_tool_call import (
        ResponseFileSearchToolCall,
    )
    from openai.types.responses.response_file_search_tool_call import (
        Result as FileSearchResult,
    )
    from openai.types.responses.response_function_web_search import (
        ResponseFunctionWebSearch,
    )

    from agenterm.core.json_types import JSONValue
    from agenterm.ui.transcript.model import TranscriptPolicy


def _bounded_tool_detail_lines(
    items: list[str],
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    writer = BoundedLineWriter(max_lines=policy.tool_detail_max_lines, lines=[])
    for item in items:
        if not writer.append(item):
            break
    writer.ensure_truncation_marker("  …")
    return writer.lines


def _file_search_result_line(
    result: FileSearchResult,
    *,
    policy: TranscriptPolicy,
) -> str:
    filename = result.filename or result.file_id or "(file)"
    rendered = filename
    if isinstance(result.score, (int, float)):
        rendered += f" (score={float(result.score):.3f})"
    snippet_src = (result.text or "").strip()
    snippet = snippet_src.splitlines()[0].strip() if snippet_src else ""
    if snippet:
        rendered += " | " + shorten_line(snippet, limit=policy.tool_detail_max_chars)
    return shorten_line(rendered, limit=policy.tool_detail_max_chars)


def file_search_detail_lines(
    call: ResponseFileSearchToolCall,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    """Render bounded detail lines for a `file_search_call` tool item."""
    lines: list[str] = []

    queries = list(call.queries or [])
    if queries:
        lines.append("- queries:")
        lines.extend(
            _bounded_tool_detail_lines(
                [
                    f"  {shorten_line(q, limit=policy.tool_detail_max_chars)}"
                    for q in queries
                ],
                policy=policy,
            ),
        )

    results = call.results
    if results is not None:
        lines.append(f"- results: {len(results)}")
        lines.extend(
            _bounded_tool_detail_lines(
                [f"  {_file_search_result_line(r, policy=policy)}" for r in results],
                policy=policy,
            ),
        )

    return lines


def _safe_action_text(
    value: str | None,
    *,
    limit: int,
    fallback: str,
) -> str:
    if value:
        return shorten_line(value, limit=limit)
    return fallback


def _web_search_action_lines(
    call: ResponseFunctionWebSearch,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    action = call.action
    if action.type == "search":
        query = _safe_action_text(
            action.query,
            limit=policy.tool_detail_max_chars,
            fallback="(missing query)",
        )
        return [
            f"- search: {query}",
        ]
    if action.type == "open_page":
        url = _safe_action_text(
            action.url,
            limit=policy.tool_detail_max_chars,
            fallback="(missing url)",
        )
        return [
            f"- open: {url}",
        ]
    if action.type == "find":
        pattern = _safe_action_text(
            action.pattern,
            limit=policy.tool_detail_max_chars,
            fallback="(missing pattern)",
        )
        url = _safe_action_text(
            action.url,
            limit=policy.tool_detail_max_chars,
            fallback="(missing url)",
        )
        return [
            f"- find: {pattern}",
            f"- url: {url}",
        ]
    return []


def _web_search_result_preview(result: JSONValue, *, policy: TranscriptPolicy) -> str:
    if isinstance(result, str):
        return shorten_line(result, limit=policy.tool_detail_max_chars)
    if isinstance(result, dict):
        title_obj = result.get("title")
        url_obj = result.get("url") or result.get("link")
        snippet_obj = (
            result.get("snippet")
            or result.get("description")
            or result.get("text")
            or result.get("content")
        )
        title = title_obj if isinstance(title_obj, str) else ""
        url = url_obj if isinstance(url_obj, str) else ""
        snippet_src = snippet_obj if isinstance(snippet_obj, str) else ""
        snippet_src = snippet_src.strip()
        snippet = snippet_src.splitlines()[0].strip() if snippet_src else ""

        parts: list[str] = []
        if title:
            parts.append(title)
        if url and url not in parts:
            parts.append(url)
        if snippet:
            parts.append(snippet)
        rendered = " | ".join(parts) if parts else url or "(result)"
        return shorten_line(rendered, limit=policy.tool_detail_max_chars)
    return "(result)"


def _web_search_results_lines(
    call: ResponseFunctionWebSearch,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    extras = call.model_extra or {}
    results_obj = extras.get("results")
    if results_obj is None or not is_json_value(value=results_obj):
        return []
    if not isinstance(results_obj, list):
        return []
    lines: list[str] = [f"- results: {len(results_obj)}"]
    if not results_obj:
        return lines
    lines.extend(
        _bounded_tool_detail_lines(
            [f"  {_web_search_result_preview(r, policy=policy)}" for r in results_obj],
            policy=policy,
        ),
    )
    return lines


def web_search_detail_lines(
    call: ResponseFunctionWebSearch,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    """Render bounded detail lines for a `web_search_call` tool item."""
    lines = _web_search_action_lines(call, policy=policy)
    lines.extend(_web_search_results_lines(call, policy=policy))
    return lines


__all__ = ("file_search_detail_lines", "web_search_detail_lines")
