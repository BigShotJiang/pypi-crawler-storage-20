"""Helpers for surfacing MCP tool call failures in transcripts."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.tool_events import shorten_line

if TYPE_CHECKING:
    from openai.types.responses.response_output_item import McpCall

    from agenterm.ui.transcript.model import TranscriptPolicy


def mcp_call_failed(call: McpCall) -> bool:
    """Return True when an MCP call is explicitly failed or errored."""
    if isinstance(call.error, str) and call.error:
        return True
    return call.status == "failed"


def mcp_failure_detail_lines(
    call: McpCall,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Return bounded detail lines for a failed MCP tool call."""
    lines: list[str] = [f"- server: {call.server_label}", f"- tool: {call.name}"]
    if call.status:
        lines.append(f"- status: {call.status}")
    error = call.error or ""
    if error:
        lines.append(
            f"- error: {shorten_line(error, limit=policy.tool_detail_max_chars)}",
        )
        return tuple(lines)
    output = call.output or ""
    if output:
        lines.append(
            f"- output: {shorten_line(output, limit=policy.tool_detail_max_chars)}",
        )
    return tuple(lines)


__all__ = ("mcp_call_failed", "mcp_failure_detail_lines")
