"""Rich/Plain transcript rendering for streamed run items."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from agents.items import ToolCallOutputItem

from agenterm.ui.render_artifacts import render_image_artifact
from agenterm.ui.renderer import render_plan_update, render_reasoning, render_tool_block
from agenterm.ui.transcript.blocks import (
    ImageArtifactBlock,
    ReasoningBlock,
    ToolCallBlock,
    ToolOutputBlock,
    TranscriptBuild,
    build_transcript_item,
)

if TYPE_CHECKING:
    from agents.items import RunItem

    from agenterm.core.plan import PlanSnapshot
    from agenterm.ui.transcript.model import TranscriptPolicy

type TranscriptBuildSink = Callable[[TranscriptBuild], None]
type PlanSnapshotLoader = Callable[[str], PlanSnapshot | None]


def _render_block(
    block: ReasoningBlock | ToolCallBlock | ToolOutputBlock | ImageArtifactBlock,
    *,
    policy: TranscriptPolicy,
) -> None:
    if isinstance(block, ReasoningBlock):
        render_reasoning(block.display_text)
        return
    if isinstance(block, ToolCallBlock):
        render_tool_block(
            "tool call",
            block.label,
            detail_lines=(
                block.detail_lines if policy.verbosity in {"normal", "debug"} else ()
            ),
        )
        return
    if isinstance(block, ImageArtifactBlock):
        render_image_artifact(
            artifact_id=block.artifact_id,
            path=block.path,
            mime=block.mime,
            size_bytes=block.size_bytes,
            inline_preview=True,
        )
        return
    render_tool_block(
        "tool output",
        block.label,
        success=block.success,
        detail_lines=(
            block.detail_lines if policy.verbosity in {"normal", "debug"} else ()
        ),
    )


def _maybe_render_plan_update(
    item: ToolCallOutputItem,
    *,
    plan_snapshot_loader: PlanSnapshotLoader,
) -> bool:
    """Render plan update if item is from update_plan tool.

    FunctionCallOutput is a TypedDict (dict at runtime) with
    type="function_call_output". ToolCallOutputTypes is always dict-like.
    """
    raw = item.raw_item
    if raw.get("type") != "function_call_output":
        return False
    call_id = raw.get("call_id")
    if not isinstance(call_id, str):
        return False
    snapshot = plan_snapshot_loader(call_id)
    if snapshot is None:
        return False
    render_plan_update(explanation=snapshot.explanation, steps=snapshot.steps)
    return True


def render_run_item(
    item: RunItem,
    *,
    policy: TranscriptPolicy,
    sink: TranscriptBuildSink | None = None,
    plan_snapshot_loader: PlanSnapshotLoader | None = None,
) -> None:
    """Render a single streamed run item to the transcript.

    Args:
      item: Streamed Agents `RunItem`.
      policy: Transcript boundedness policy.
      sink: Optional callback to receive the built block/artifacts before rendering.
      plan_snapshot_loader: Optional snapshot loader for update_plan rendering.

    """
    if (
        plan_snapshot_loader is not None
        and isinstance(item, ToolCallOutputItem)
        and _maybe_render_plan_update(item, plan_snapshot_loader=plan_snapshot_loader)
    ):
        return
    build = build_transcript_item(item, policy=policy)
    if sink is not None:
        sink(build)
    if build.block is None:
        return
    _render_block(build.block, policy=policy)


__all__ = (
    "TranscriptBuildSink",
    "render_run_item",
)
