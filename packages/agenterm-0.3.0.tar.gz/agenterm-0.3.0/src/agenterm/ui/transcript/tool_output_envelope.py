"""Tool output envelope rendering helpers for transcripts."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from agents.editor import ApplyPatchResult
from agents.tool import ShellCallOutcome, ShellCommandOutput, ShellResult

from agenterm.core.json_codec import as_str
from agenterm.ui.tool_events import (
    BoundedLineWriter,
    ToolOutputSummaryPolicy,
    shorten_line,
    tool_output_summary_lines,
)
from agenterm.ui.transcript.tool_output_lines import (
    agent_run_lines,
    bat_lines,
    fd_lines,
    parallel_lines,
    rg_lines,
    stat_lines,
    tree_lines,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.core.tool_output_envelope import (
        FunctionToolOutputEnvelope,
        McpToolOutputEnvelope,
        ToolOutputError,
    )
    from agenterm.ui.transcript.model import TranscriptPolicy


def _apply_patch_status(
    value: JSONValue | None,
) -> Literal["completed", "failed"] | None:
    if value == "completed":
        return "completed"
    if value == "failed":
        return "failed"
    return None


def _output_truncation_warning(policy: TranscriptPolicy) -> str:
    max_chars = max(0, int(policy.tool_output_max_chars))
    if max_chars > 0:
        return f"warn> tool output truncated to {max_chars} chars"
    return "warn> tool output truncated"


def _shell_result_from_payload(
    payload: Mapping[str, JSONValue],
) -> ShellResult | None:
    outputs_raw = payload.get("outputs")
    if not isinstance(outputs_raw, list):
        return None
    outputs: list[ShellCommandOutput] = []
    for entry in outputs_raw:
        if not isinstance(entry, dict):
            return None
        command = as_str(entry.get("command")) or ""
        stdout = as_str(entry.get("stdout")) or ""
        stderr = as_str(entry.get("stderr")) or ""
        outcome_raw = entry.get("outcome")
        outcome = ShellCallOutcome(type="exit", exit_code=None)
        if isinstance(outcome_raw, dict):
            typ = outcome_raw.get("type")
            exit_code = outcome_raw.get("exit_code")
            if typ == "exit":
                exit_val = exit_code if isinstance(exit_code, int) else None
                outcome = ShellCallOutcome(type="exit", exit_code=exit_val)
            elif typ == "timeout":
                exit_val = exit_code if isinstance(exit_code, int) else None
                outcome = ShellCallOutcome(type="timeout", exit_code=exit_val)
        outputs.append(
            ShellCommandOutput(
                command=command,
                stdout=stdout,
                stderr=stderr,
                outcome=outcome,
            )
        )
    max_out_raw = payload.get("max_output_length")
    max_output_length = (
        int(max_out_raw)
        if isinstance(max_out_raw, int) and not isinstance(max_out_raw, bool)
        else None
    )
    provider_data: dict[str, JSONValue] | None = None
    wd = payload.get("working_directory")
    if isinstance(wd, str) and wd:
        provider_data = {"working_directory": wd}
    return ShellResult(
        output=outputs,
        max_output_length=max_output_length,
        provider_data=provider_data,
    )


def _apply_patch_result_from_payload(
    payload: Mapping[str, JSONValue],
) -> ApplyPatchResult | None:
    status = _apply_patch_status(payload.get("status"))
    output_raw = payload.get("output")
    output = output_raw if isinstance(output_raw, str) else None
    return ApplyPatchResult(status=status, output=output)


def _error_detail_lines(
    error: ToolOutputError,
    policy: TranscriptPolicy,
    *,
    truncated: bool,
) -> tuple[str, ...]:
    max_lines = max(0, int(policy.tool_output_max_lines))
    writer = BoundedLineWriter(max_lines=max_lines, lines=[])
    if truncated and not writer.append(_output_truncation_warning(policy)):
        return tuple(writer.lines)
    writer.append(f"- error: {error.kind}")
    msg = shorten_line(error.message, limit=policy.tool_detail_max_chars)
    writer.append(f"- message: {msg}")
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


def _shell_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    result = _shell_result_from_payload(payload)
    if result is None:
        return ()
    summary_policy = ToolOutputSummaryPolicy(
        max_lines=policy.tool_output_max_lines,
        shell_preview_max_chars=policy.shell_preview_max_chars,
    )
    return tool_output_summary_lines(
        result,
        policy=summary_policy,
        include_apply_patch_excerpt=False,
    )


def _apply_patch_lines(
    payload: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    result = _apply_patch_result_from_payload(payload)
    if result is None:
        return ()
    summary_policy = ToolOutputSummaryPolicy(
        max_lines=policy.tool_output_max_lines,
        shell_preview_max_chars=policy.shell_preview_max_chars,
    )
    return tool_output_summary_lines(
        result,
        policy=summary_policy,
        include_apply_patch_excerpt=policy.diffs_mode != "off",
    )


def _prepend_output_truncated(
    lines: tuple[str, ...],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    max_lines = max(0, int(policy.tool_output_max_lines))
    writer = BoundedLineWriter(max_lines=max_lines, lines=[])
    if not writer.append(_output_truncation_warning(policy)):
        return tuple(writer.lines)
    for line in lines:
        if not writer.append(line):
            break
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


_TOOL_LINE_HANDLERS: dict[
    str,
    Callable[[Mapping[str, JSONValue], TranscriptPolicy], tuple[str, ...]],
] = {
    "parallel": parallel_lines,
    "shell": _shell_lines,
    "apply_patch": _apply_patch_lines,
    "rg": rg_lines,
    "fd": fd_lines,
    "bat": bat_lines,
    "tree": tree_lines,
    "stat": stat_lines,
    "agent_run": agent_run_lines,
}


def function_tool_envelope_lines(
    env: FunctionToolOutputEnvelope,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript lines for a FunctionTool output envelope."""
    if not env.ok and env.error is not None:
        return _error_detail_lines(env.error, policy=policy, truncated=env.truncated)
    handler = _TOOL_LINE_HANDLERS.get(env.tool)
    if handler is None:
        return ()
    payload = env.payload
    lines = handler(payload, policy)
    if env.truncated:
        return _prepend_output_truncated(lines, policy=policy)
    return lines


def mcp_envelope_lines(
    env: McpToolOutputEnvelope,
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    """Render transcript lines for an MCP output envelope."""
    max_lines = max(0, int(policy.tool_output_max_lines))
    writer = BoundedLineWriter(max_lines=max_lines, lines=[])
    writer.append(f"- server: {env.server_key}")
    writer.append(f"- tool: {env.tool_name}")
    if env.truncated and not writer.append(_output_truncation_warning(policy)):
        return tuple(writer.lines)
    if not env.ok and env.error is not None:
        msg = shorten_line(env.error.message, limit=policy.tool_detail_max_chars)
        writer.append(f"- error: {env.error.kind}")
        writer.append(f"- message: {msg}")
        writer.ensure_truncation_marker("…")
        return tuple(writer.lines)
    if env.content is not None:
        preview_source = env.content.text.strip()
        if preview_source:
            first_line = preview_source.splitlines()[0]
            preview = shorten_line(first_line, limit=policy.tool_detail_max_chars)
            writer.append(f"- output: {preview}")
    writer.ensure_truncation_marker("…")
    return tuple(writer.lines)


__all__ = ("function_tool_envelope_lines", "mcp_envelope_lines")
