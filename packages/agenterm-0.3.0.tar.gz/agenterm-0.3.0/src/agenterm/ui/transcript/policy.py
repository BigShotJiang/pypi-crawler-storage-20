"""Helpers to derive transcript policies from configuration/state."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.ui.transcript.model import TranscriptPolicy

if TYPE_CHECKING:
    from agenterm.config.model import ReplTranscriptConfig
    from agenterm.core.choices.repl import (
        ReplDiffsMode,
        ReplReasoningMode,
        ReplVerbosity,
    )
    from agenterm.core.types import SessionState


def transcript_policy_from_config(
    *,
    verbosity: ReplVerbosity,
    reasoning_mode: ReplReasoningMode,
    diffs_mode: ReplDiffsMode,
    reasoning_summary_max_chars: int,
    tool_output_max_chars: int,
    transcript_cfg: ReplTranscriptConfig,
) -> TranscriptPolicy:
    """Build a deterministic TranscriptPolicy from resolved settings.

    Callers are responsible for validating the token choices at ingress
    (CLI flags or `/ux` commands). This helper only constructs the typed policy.
    """
    return TranscriptPolicy(
        verbosity=verbosity,
        reasoning_mode=reasoning_mode,
        diffs_mode=diffs_mode,
        reasoning_summary_max_chars=reasoning_summary_max_chars,
        shell_preview_max_chars=transcript_cfg.shell_preview_max_chars,
        tool_output_max_lines=transcript_cfg.tool_output_max_lines,
        tool_output_max_chars=tool_output_max_chars,
        tool_detail_max_lines=transcript_cfg.tool_detail_max_lines,
        tool_detail_max_chars=transcript_cfg.tool_detail_max_chars,
        mcp_args_preview_max_chars=transcript_cfg.mcp_args_preview_max_chars,
        attachments_max_lines=transcript_cfg.attachments_max_lines,
        attachments_path_max_chars=transcript_cfg.attachments_path_max_chars,
    )


def transcript_policy_for_state(state: SessionState) -> TranscriptPolicy:
    """Build a TranscriptPolicy from the current SessionState."""
    return transcript_policy_from_config(
        verbosity=state.ui.verbosity,
        reasoning_mode=state.ui.reasoning_mode,
        diffs_mode=state.ui.diffs_mode,
        reasoning_summary_max_chars=state.ui.reasoning_summary_max_chars,
        tool_output_max_chars=state.cfg.tools.max_chars,
        transcript_cfg=state.cfg.repl.transcript,
    )


__all__ = ("transcript_policy_for_state", "transcript_policy_from_config")
