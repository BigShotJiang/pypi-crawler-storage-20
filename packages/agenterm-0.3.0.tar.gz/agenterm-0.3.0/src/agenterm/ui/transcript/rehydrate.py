"""Transcript rehydration for stored Responses input items."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.json_codec import as_json_list, as_str
from agenterm.core.response_items import serialize_input_item
from agenterm.core.text import shorten_line
from agenterm.engine.artifacts import resolve_image_artifacts
from agenterm.ui.transcript.blocks import (
    ImageArtifactBlock,
    ReasoningBlock,
    TranscriptArtifacts,
    TranscriptBuild,
)
from agenterm.ui.transcript.rehydrate_tools import (
    TOOL_CALL_TYPES,
    TOOL_OUTPUT_TYPES,
    build_tool_call,
    build_tool_output,
    mcp_call_failed,
    mcp_failure_block,
)
from agenterm.ui.tui.state import TranscriptEntry, TranscriptTextEntry

if TYPE_CHECKING:
    from collections.abc import Callable, Sequence

    from agents.items import TResponseInputItem

    from agenterm.core.json_types import JSONValue
    from agenterm.store.async_db import AsyncStore
    from agenterm.ui.transcript.model import TranscriptPolicy
    from agenterm.ui.tui.state import TranscriptRole


@dataclass(frozen=True)
class TranscriptRehydrateResult:
    """Rehydrated transcript entries plus their build artifacts."""

    entries: tuple[TranscriptEntry, ...]
    builds: tuple[TranscriptBuild, ...]


@dataclass(frozen=True)
class _RehydrateState:
    entries: list[TranscriptEntry]
    builds: list[TranscriptBuild]
    policy: TranscriptPolicy
    records_map: Mapping[str, ImageArtifactBlock]


def _parse_item(
    item: TResponseInputItem,
) -> dict[str, JSONValue]:
    return serialize_input_item(item, context="transcript.rehydrate.item")


def _message_role(role_raw: str | None) -> TranscriptRole:
    if role_raw == "user":
        return "user"
    if role_raw == "assistant":
        return "assistant"
    return "system"


def _input_image_line(
    part: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> str:
    file_id = as_str(part.get("file_id"))
    image_url = as_str(part.get("image_url"))
    detail = ""
    if file_id and image_url:
        detail = f"file_id={file_id} url={image_url}"
    elif file_id:
        detail = f"file_id={file_id}"
    elif image_url:
        detail = f"url={image_url}"
    if detail:
        detail = shorten_line(detail, limit=policy.attachments_path_max_chars)
        return f"[image] {detail}"
    return "[image]"


def _input_file_line(
    part: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> str:
    filename = as_str(part.get("filename"))
    file_id = as_str(part.get("file_id"))
    file_url = as_str(part.get("file_url"))
    detail = filename or file_id or file_url
    if detail:
        detail = shorten_line(detail, limit=policy.attachments_path_max_chars)
        return f"[file] {detail}"
    return "[file]"


def _message_part_line(
    part: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> str | None:
    part_type = as_str(part.get("type"))
    if part_type in {"input_text", "output_text"}:
        text = as_str(part.get("text"))
        return text or None
    if part_type == "refusal":
        refusal = as_str(part.get("refusal"))
        return f"[refusal] {refusal}" if refusal else None
    if part_type == "input_image":
        return _input_image_line(part, policy=policy)
    if part_type == "input_file":
        return _input_file_line(part, policy=policy)
    return None


def _message_lines(
    content: JSONValue | None,
    *,
    policy: TranscriptPolicy,
) -> list[str]:
    if isinstance(content, str):
        return [content] if content else []
    content_list = as_json_list(content)
    if content_list is None:
        return []
    lines: list[str] = []
    for part in content_list:
        if not isinstance(part, Mapping):
            continue
        line = _message_part_line(part, policy=policy)
        if line:
            lines.append(line)
    return lines


def _message_entry(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> TranscriptTextEntry | None:
    role_raw = as_str(item.get("role"))
    role = _message_role(role_raw)
    lines = _message_lines(item.get("content"), policy=policy)
    if not lines:
        return None
    return TranscriptTextEntry(role=role, text="\n".join(lines))


def _extract_text_parts(parts_list: list[JSONValue] | None) -> str | None:
    """Extract text from a list of {text: ...} parts."""
    if not parts_list:
        return None
    texts: list[str] = []
    for entry in parts_list:
        if isinstance(entry, dict):
            text = as_str(entry.get("text"))
            if text:
                texts.append(text)
    joined = "\n".join(texts).strip()
    return joined if joined else None


def _truncate_text(text: str | None, limit: int) -> str | None:
    """Truncate text to limit chars with ellipsis."""
    if not text or limit <= 0 or len(text) <= limit:
        return text
    return f"{text[: limit - 1]}…"


def _build_reasoning_block_from_stored(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> ReasoningBlock:
    """Build ReasoningBlock from stored reasoning item dict."""
    if policy.reasoning_mode == "off" or policy.verbosity == "quiet":
        return ReasoningBlock(
            kind="reasoning",
            summary_text=None,
            content_text=None,
            has_real_thinking=False,
        )

    summary = _extract_text_parts(as_json_list(item.get("summary")))
    content = _extract_text_parts(as_json_list(item.get("content")))
    encrypted = as_str(item.get("encrypted_content"))

    limit = policy.reasoning_summary_max_chars
    return ReasoningBlock(
        kind="reasoning",
        summary_text=_truncate_text(summary, limit),
        content_text=_truncate_text(content, limit),
        has_real_thinking=bool(content or encrypted),
    )


def _compaction_entry(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> TranscriptTextEntry:
    compaction_id = as_str(item.get("id"))
    label = (
        shorten_line(compaction_id, limit=policy.tool_detail_max_chars)
        if compaction_id
        else None
    )
    text = "[compaction]"
    if label:
        text += f" id={label}"
    text += " (encrypted_content redacted)"
    return TranscriptTextEntry(role="system", text=text)


async def rehydrate_transcript_items(
    items: Sequence[TResponseInputItem],
    *,
    policy: TranscriptPolicy,
    store: AsyncStore | None,
) -> TranscriptRehydrateResult:
    """Return transcript entries reconstructed from stored input items."""
    if not items:
        return TranscriptRehydrateResult(entries=(), builds=())

    records_map: dict[str, ImageArtifactBlock] = {}
    if store is not None:
        resolution = await resolve_image_artifacts(store=store, items=items)
        for rec in resolution.records:
            records_map[rec.source_id] = ImageArtifactBlock(
                kind="artifact_image",
                artifact_id=rec.artifact_id,
                path=rec.path,
                mime=rec.mime,
                size_bytes=rec.size_bytes,
            )

    state = _RehydrateState(
        entries=[],
        builds=[],
        policy=policy,
        records_map=records_map,
    )
    for raw_item in items:
        item = _parse_item(raw_item)
        _dispatch_item(state, item)

    return TranscriptRehydrateResult(
        entries=tuple(state.entries),
        builds=tuple(state.builds),
    )


def _dispatch_item(
    state: _RehydrateState,
    item: Mapping[str, JSONValue],
) -> None:
    item_type = as_str(item.get("type"))
    if item_type is None:
        if _append_role_item(state, item):
            return
        _append_output_preview(state, item)
        return
    handler = _ITEM_DISPATCH_TABLE.get(item_type)
    if handler is not None:
        handler(state, item)
        return
    if item_type in TOOL_CALL_TYPES:
        _append_tool_call_item(state, item_type, item)
        return
    if item_type in TOOL_OUTPUT_TYPES:
        _append_tool_output_item(state, item_type, item)
        return
    if _append_role_item(state, item):
        return
    _append_output_preview(state, item)


def _append_message_item(
    state: _RehydrateState,
    item: Mapping[str, JSONValue],
) -> None:
    entry = _message_entry(item, policy=state.policy)
    if entry is not None:
        state.entries.append(entry)


def _append_reasoning_item(
    state: _RehydrateState,
    item: Mapping[str, JSONValue],
) -> None:
    block = _build_reasoning_block_from_stored(item, policy=state.policy)
    build = TranscriptBuild(block=block, artifacts=TranscriptArtifacts())
    state.entries.append(block)
    state.builds.append(build)


def _append_compaction_item(
    state: _RehydrateState,
    item: Mapping[str, JSONValue],
) -> None:
    state.entries.append(_compaction_entry(item, policy=state.policy))


def _append_tool_call_item(
    state: _RehydrateState,
    item_type: str,
    item: Mapping[str, JSONValue],
) -> None:
    if item_type == "mcp_call" and mcp_call_failed(item):
        build = mcp_failure_block(item, policy=state.policy)
        if build.block is not None:
            state.entries.append(build.block)
            state.builds.append(build)
        return
    build = build_tool_call(item_type, item, policy=state.policy)
    if build.block is not None:
        state.entries.append(build.block)
        state.builds.append(build)
    if item_type == "image_generation_call":
        call_id = as_str(item.get("id"))
        if call_id and call_id in state.records_map:
            state.entries.append(state.records_map[call_id])


def _append_tool_output_item(
    state: _RehydrateState,
    item_type: str,
    item: Mapping[str, JSONValue],
) -> None:
    block = build_tool_output(item_type, item, policy=state.policy)
    build = TranscriptBuild(block=block, artifacts=TranscriptArtifacts())
    state.entries.append(block)
    state.builds.append(build)


def _append_role_item(
    state: _RehydrateState,
    item: Mapping[str, JSONValue],
) -> bool:
    role = as_str(item.get("role"))
    if role is None:
        return False
    entry = _message_entry(item, policy=state.policy)
    if entry is not None:
        state.entries.append(entry)
    return True


def _append_output_preview(
    state: _RehydrateState,
    item: Mapping[str, JSONValue],
) -> None:
    output_str = as_str(item.get("output"))
    if output_str:
        preview = shorten_line(output_str, limit=state.policy.tool_detail_max_chars)
        state.entries.append(
            TranscriptTextEntry(role="system", text=f"[output] {preview}"),
        )


_ITEM_DISPATCH_TABLE: dict[
    str,
    Callable[[_RehydrateState, Mapping[str, JSONValue]], None],
] = {
    "message": _append_message_item,
    "reasoning": _append_reasoning_item,
    "compaction": _append_compaction_item,
}


__all__ = ("TranscriptRehydrateResult", "rehydrate_transcript_items")
