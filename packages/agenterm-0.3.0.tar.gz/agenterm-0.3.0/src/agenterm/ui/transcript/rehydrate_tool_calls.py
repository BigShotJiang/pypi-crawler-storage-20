"""Tool call rehydration helpers for transcripts."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agenterm.core.json_codec import (
    as_int,
    as_json_list,
    as_json_object,
    as_str,
    parse_json_object,
)
from agenterm.core.text import shorten_line
from agenterm.ui.tool_events import BoundedLineWriter, label_for_tool_type
from agenterm.ui.transcript.blocks import (
    ApplyPatchCallArtifact,
    ToolCallBlock,
    ToolOutputBlock,
    TranscriptArtifacts,
    TranscriptBuild,
)
from agenterm.ui.transcript.diffs import DIFF_HINT_LINE, format_unified_diff_lines

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping

    from agenterm.core.json_types import JSONValue
    from agenterm.ui.transcript.model import TranscriptPolicy

TOOL_CALL_TYPES: set[str] = {
    "computer_call",
    "custom_tool_call",
    "file_search_call",
    "function_call",
    "image_generation_call",
    "mcp_approval_request",
    "mcp_call",
    "mcp_list_tools",
    "web_search_call",
    "code_interpreter_call",
}


def _apply_patch_artifact(
    operation: Mapping[str, JSONValue] | None,
) -> ApplyPatchCallArtifact | None:
    if operation is None:
        return None
    op_type = as_str(operation.get("type"))
    path = as_str(operation.get("path"))
    if not op_type or not path:
        return None
    diff = as_str(operation.get("diff"))
    return ApplyPatchCallArtifact(op_type=op_type, path=path, diff=diff)


def _apply_patch_call_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    operation = as_json_object(item.get("operation"))
    if operation is None:
        return ()
    op_type = as_str(operation.get("type")) or "(unknown)"
    path = as_str(operation.get("path")) or "(unknown)"
    lines: list[str] = [f"- op: {op_type}", f"- path: {path}"]
    if policy.verbosity == "quiet" or policy.diffs_mode == "off":
        return tuple(lines)
    diff = as_str(operation.get("diff"))
    if not diff:
        return tuple(lines)
    diff_lines = format_unified_diff_lines(diff)
    if not diff_lines:
        return tuple(lines)
    lines.append("- diff:")
    lines.extend([f"  {line}" for line in diff_lines[: policy.tool_detail_max_lines]])
    if len(diff_lines) > policy.tool_detail_max_lines:
        lines.append("  …")
        lines.append(f"  {DIFF_HINT_LINE}")
    return tuple(lines)


def _apply_patch_operation_from_function_call(
    item: Mapping[str, JSONValue],
) -> Mapping[str, JSONValue] | None:
    args = as_str(item.get("arguments")) or ""
    payload = parse_json_object(args) if args else None
    if payload is None:
        return None
    return as_json_object(payload.get("operation"))


def _function_call_apply_patch_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    operation = _apply_patch_operation_from_function_call(item)
    if operation is None:
        return ()
    return _apply_patch_call_detail_lines({"operation": dict(operation)}, policy)


def _function_call_shell_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    args = as_str(item.get("arguments")) or ""
    payload = parse_json_object(args) if args else None
    if payload is None:
        return ()
    commands = as_json_list(payload.get("commands")) or []
    lines: list[str] = []
    cwd = as_str(payload.get("cwd"))
    if cwd:
        lines.append(f"- cwd: {cwd}")
    if commands:
        lines.append("- commands:")
        for cmd in commands[: policy.tool_detail_max_lines]:
            if not isinstance(cmd, str) or not cmd:
                continue
            preview = shorten_line(cmd, limit=policy.tool_detail_max_chars)
            lines.append(f"  {preview}")
        if len(commands) > policy.tool_detail_max_lines:
            lines.append("  …")
    timeout = as_int(payload.get("timeout_ms"))
    if timeout is not None:
        lines.append(f"- timeout_ms: {timeout}")
    max_out = as_int(payload.get("max_output_length"))
    if max_out is not None:
        lines.append(f"- max_output_length: {max_out}")
    return tuple(lines)


def _function_call_parallel_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    args = as_str(item.get("arguments")) or ""
    payload = parse_json_object(args) if args else None
    if payload is None:
        return ()
    calls = payload.get("calls")
    if not isinstance(calls, list):
        return ()
    lines: list[str] = [f"- calls: {len(calls)}"]
    tool_names: list[str] = []
    for entry in calls:
        if not isinstance(entry, dict):
            continue
        name = as_str(entry.get("tool"))
        if name:
            tool_names.append(name)
    if tool_names:
        preview = ", ".join(tool_names[: policy.tool_detail_max_lines])
        lines.append(
            f"- tools: {shorten_line(preview, limit=policy.tool_detail_max_chars)}",
        )
        if len(tool_names) > policy.tool_detail_max_lines:
            lines.append("  …")
    return tuple(lines)


def _function_call_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    name = as_str(item.get("name"))
    if name == "apply_patch":
        return _function_call_apply_patch_detail_lines(item, policy)
    if name == "shell":
        return _function_call_shell_detail_lines(item, policy)
    if name == "parallel":
        return _function_call_parallel_detail_lines(item, policy)
    return ()


def _file_search_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    lines: list[str] = []
    queries = as_json_list(item.get("queries")) or []
    if queries:
        lines.append("- queries:")
        writer = BoundedLineWriter(
            max_lines=policy.tool_detail_max_lines,
            lines=[],
        )
        for entry in queries:
            if not isinstance(entry, str) or not entry:
                continue
            query = entry
            if not writer.append(
                f"  {shorten_line(query, limit=policy.tool_detail_max_chars)}",
            ):
                break
        writer.ensure_truncation_marker("  …")
        lines.extend(writer.lines)
    results = as_json_list(item.get("results"))
    if results is not None:
        lines.append(f"- results: {len(results)}")
    return tuple(lines)


def _web_search_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    action = as_json_object(item.get("action"))
    if action is None:
        return ()
    action_type = as_str(action.get("type"))
    if action_type == "search":
        query = as_str(action.get("query")) or "(missing query)"
        return (f"- search: {shorten_line(query, limit=policy.tool_detail_max_chars)}",)
    if action_type == "open_page":
        url = as_str(action.get("url")) or "(missing url)"
        return (f"- open: {shorten_line(url, limit=policy.tool_detail_max_chars)}",)
    if action_type == "find":
        pattern = as_str(action.get("pattern")) or "(missing pattern)"
        url = as_str(action.get("url")) or "(missing url)"
        return (
            f"- find: {shorten_line(pattern, limit=policy.tool_detail_max_chars)}",
            f"- url: {shorten_line(url, limit=policy.tool_detail_max_chars)}",
        )
    return ()


def _mcp_call_detail_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    server = as_str(item.get("server_label")) or "(server)"
    tool = as_str(item.get("name")) or "(tool)"
    lines: list[str] = [f"- server: {server}", f"- tool: {tool}"]
    args = as_str(item.get("arguments"))
    if args:
        preview = shorten_line(args, limit=policy.mcp_args_preview_max_chars)
        lines.append(f"- args: {preview}")
    return tuple(lines)


def _mcp_approval_request_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    request_id = as_str(item.get("id")) or "(request)"
    server = as_str(item.get("server_label")) or "(server)"
    tool = as_str(item.get("name")) or "(tool)"
    lines: list[str] = [
        f"- request_id: {request_id}",
        f"- server: {server}",
        f"- tool: {tool}",
    ]
    args = as_str(item.get("arguments"))
    if args:
        preview = shorten_line(args, limit=policy.mcp_args_preview_max_chars)
        lines.append(f"- args: {preview}")
    return tuple(lines)


def _mcp_list_tools_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    server = as_str(item.get("server_label")) or "(server)"
    lines: list[str] = [f"- server: {server}"]
    tools = as_json_list(item.get("tools"))
    if tools is not None:
        lines.append(f"- tools: {len(tools)}")
    error = as_str(item.get("error"))
    if error:
        lines.append(
            f"- error: {shorten_line(error, limit=policy.tool_detail_max_chars)}",
        )
    return tuple(lines)


def _image_generation_call_lines(
    item: Mapping[str, JSONValue],
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    lines: list[str] = []
    status = as_str(item.get("status"))
    if status:
        lines.append(f"- status: {status}")
    call_id = as_str(item.get("id"))
    if call_id:
        lines.append(
            f"- id: {shorten_line(call_id, limit=policy.tool_detail_max_chars)}",
        )
    result = as_str(item.get("result"))
    if result:
        lines.append(f"- result: (base64, {len(result)} chars)")
    return tuple(lines)


_DETAIL_LINE_BUILDERS: dict[
    str,
    Callable[[Mapping[str, JSONValue], TranscriptPolicy], tuple[str, ...]],
] = {
    "function_call": _function_call_detail_lines,
    "file_search_call": _file_search_detail_lines,
    "web_search_call": _web_search_detail_lines,
    "mcp_call": _mcp_call_detail_lines,
    "mcp_approval_request": _mcp_approval_request_lines,
    "mcp_list_tools": _mcp_list_tools_lines,
    "image_generation_call": _image_generation_call_lines,
}


def _tool_call_detail_lines(
    item_type: str,
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> tuple[str, ...]:
    builder = _DETAIL_LINE_BUILDERS.get(item_type)
    if builder is None:
        return ()
    return builder(item, policy)


def _tool_call_label(
    item_type: str,
    item: Mapping[str, JSONValue],
) -> str:
    if item_type in {"function_call", "custom_tool_call"}:
        name = as_str(item.get("name"))
        if name:
            return name
    return label_for_tool_type(item_type, is_output=False)


def build_tool_call(
    item_type: str,
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> TranscriptBuild:
    """Return the transcript build for a tool call input item."""
    label = _tool_call_label(item_type, item)
    details = _tool_call_detail_lines(item_type, item, policy=policy)
    artifacts = TranscriptArtifacts()
    if item_type == "function_call" and as_str(item.get("name")) == "apply_patch":
        operation = _apply_patch_operation_from_function_call(item)
        artifact = _apply_patch_artifact(operation)
        if artifact is not None:
            artifacts = TranscriptArtifacts(apply_patch_call=artifact)
    block = ToolCallBlock(kind="tool_call", label=label, detail_lines=details)
    return TranscriptBuild(block=block, artifacts=artifacts)


def mcp_call_failed(item: Mapping[str, JSONValue]) -> bool:
    """Return True when an MCP call is explicitly failed or errored."""
    error = as_str(item.get("error"))
    if error:
        return True
    status = as_str(item.get("status"))
    return status == "failed"


def mcp_failure_block(
    item: Mapping[str, JSONValue],
    *,
    policy: TranscriptPolicy,
) -> TranscriptBuild:
    """Return a tool output block describing a failed MCP call."""
    server = as_str(item.get("server_label")) or "(server)"
    tool = as_str(item.get("name")) or "(tool)"
    lines: list[str] = [f"- server: {server}", f"- tool: {tool}"]
    status = as_str(item.get("status"))
    if status:
        lines.append(f"- status: {status}")
    error = as_str(item.get("error"))
    if error:
        lines.append(
            f"- error: {shorten_line(error, limit=policy.tool_detail_max_chars)}",
        )
    else:
        output = as_str(item.get("output"))
        if output:
            lines.append(
                f"- output: {shorten_line(output, limit=policy.tool_detail_max_chars)}",
            )
    block = ToolOutputBlock(
        kind="tool_output",
        label=label_for_tool_type("mcp_call", is_output=True),
        success=False,
        detail_lines=tuple(lines),
    )
    return TranscriptBuild(block=block, artifacts=TranscriptArtifacts())


__all__ = (
    "TOOL_CALL_TYPES",
    "build_tool_call",
    "mcp_call_failed",
    "mcp_failure_block",
)
