"""Typed view model for the REPL TUI status bar and HUD."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from agenterm.core.choices.approvals import ApprovalMode
from agenterm.core.errors import ValidationError
from agenterm.core.model_id import model_plane, openai_model_requires_reasoning
from agenterm.core.tool_selection import (
    ToolCatalog,
    filter_selection_specs,
    resolve_selection,
)

if TYPE_CHECKING:
    from agenterm.core.choices.repl import ReplVerbosity
    from agenterm.core.types import McpDiscoveryStatus, SessionState
    from agenterm.ui.repl.phase_state import ReplHudLevel, ReplPhaseState

type ApprovalsMode = ApprovalMode


def _tool_bundle_label(state: SessionState) -> str:
    sel = state.tools.selection
    if not state.tools.enabled:
        return "off"
    if sel.selected_bundles:
        bundle = sel.selected_bundles[0]
        extra = len(sel.selected_bundles) - 1
        return f"{bundle}+{extra}" if extra > 0 else bundle
    defaults = list(state.tools.default_bundles or ())
    if defaults:
        bundle = defaults[0]
        extra = len(defaults) - 1
        return f"{bundle}+{extra}" if extra > 0 else bundle
    return "none"


def _effective_reasoning_effort(state: SessionState) -> str | None:
    reasoning = state.cfg.model.reasoning
    if reasoning is not None and reasoning.effort is not None:
        return str(reasoning.effort)
    try:
        if model_plane(
            state.cfg.agent.model
        ) == "openai" and openai_model_requires_reasoning(state.cfg.agent.model):
            return "low"
    except ValidationError:
        return None
    return None


def _has_dangerous_tools(state: SessionState) -> bool:
    if not state.tools.enabled:
        return False
    tools_map = state.tools.tools_map or {}
    bundles_map = state.tools.bundles_map or {}
    if not tools_map or not bundles_map:
        return False
    catalog = ToolCatalog(
        tools_map=tools_map,
        bundles_map=bundles_map,
        default_bundles=list(state.tools.default_bundles or []),
    )
    resolved = resolve_selection(state.tools.selection, catalog=catalog)
    if resolved.error:
        return False
    try:
        specs = filter_selection_specs(
            resolved.specs,
            allow_dangerous=True,
            hosted_mode=False,
            model_plane=model_plane(state.cfg.agent.model),
        )
    except ValidationError:
        return False
    return any(spec.dangerous for spec in specs)


@dataclass(frozen=True)
class ApprovalsSnapshot:
    """Snapshot of pending approvals and approval posture."""

    mode: ApprovalsMode
    shell_pending: int
    patch_pending: int
    mcp_pending: int

    @property
    def total_pending(self) -> int:
        """Total number of pending approvals across all tool families."""
        return self.shell_pending + self.patch_pending + self.mcp_pending


@dataclass(frozen=True)
class ReplTuiModel:
    """Single typed snapshot used by TUI renderers."""

    phase: str
    agent_name: str
    model: str
    reasoning_effort: str | None
    tools_enabled: bool
    tools_bundle_label: str
    tools_has_dangerous: bool
    approvals: ApprovalsSnapshot
    hud_notice: str | None
    hud_notice_level: ReplHudLevel
    mcp_status: McpDiscoveryStatus
    mcp_server_count: int
    mcp_tool_count: int
    context_window: int | None
    last_request_input_tokens: int | None
    last_request_count: int | None
    last_event_hint: str
    verbosity: ReplVerbosity
    error_count: int
    error_truncated: bool


def build_repl_tui_model(
    *,
    state: SessionState,
    phase_state: ReplPhaseState,
    approvals: ApprovalsSnapshot,
) -> ReplTuiModel:
    """Build a TUI view model snapshot from REPL state."""
    mcp_servers = state.cfg.mcp.servers or ()
    return ReplTuiModel(
        phase=phase_state.phase,
        agent_name=state.cfg.agent.name,
        model=state.cfg.agent.model,
        reasoning_effort=_effective_reasoning_effort(state),
        tools_enabled=state.tools.enabled,
        tools_bundle_label=_tool_bundle_label(state),
        tools_has_dangerous=_has_dangerous_tools(state),
        approvals=approvals,
        hud_notice=(phase_state.hud_notice or "").strip() or None,
        hud_notice_level=phase_state.hud_notice_level,
        mcp_status=state.mcp.discovery_status,
        mcp_server_count=len(mcp_servers),
        mcp_tool_count=len(state.mcp.tool_names),
        context_window=state.cfg.model.context_window,
        last_request_input_tokens=phase_state.last_request_input_tokens,
        last_request_count=phase_state.last_request_count,
        last_event_hint=phase_state.last_event_hint,
        verbosity=state.ui.verbosity,
        error_count=phase_state.error_count,
        error_truncated=phase_state.error_truncated,
    )


__all__ = (
    "ApprovalsMode",
    "ApprovalsSnapshot",
    "ReplTuiModel",
    "build_repl_tui_model",
)
