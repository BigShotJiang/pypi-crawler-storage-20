"""Prompt-toolkit Application wiring for the REPL TUI."""

from __future__ import annotations

import asyncio
import os
import sys
from typing import TYPE_CHECKING, Final

from prompt_toolkit.application import Application
from prompt_toolkit.application.current import get_app
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.enums import EditingMode
from prompt_toolkit.filters import Condition, has_completions, is_done
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.history import FileHistory
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import (
    ConditionalContainer,
    Float,
    FloatContainer,
    HSplit,
    ScrollOffsets,
    Window,
)
from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.layout.menus import CompletionsMenuControl
from prompt_toolkit.layout.processors import (
    AfterInput,
    AppendAutoSuggestion,
    ConditionalProcessor,
    DisplayMultipleCursors,
    HighlightIncrementalSearchProcessor,
    HighlightSelectionProcessor,
)
from prompt_toolkit.output.color_depth import ColorDepth
from prompt_toolkit.patch_stdout import patch_stdout

from agenterm.ui.auto_suggest import HistoryAutoSuggest
from agenterm.ui.completion import CommandCompleter, NullCompleter
from agenterm.ui.repl.prompt_history import history_file_path
from agenterm.ui.tui.animation import AnimationConfig, AnimationController
from agenterm.ui.tui.format import (
    format_activity_indicator,
    format_bottom_toolbar,
    format_placeholder,
    format_prompt_message,
)
from agenterm.ui.tui.keymap import build_repl_key_bindings
from agenterm.ui.tui.margins import PaddingMargin
from agenterm.ui.tui.modals import ApprovalsModalControl
from agenterm.ui.tui.model import ApprovalsSnapshot, build_repl_tui_model
from agenterm.ui.tui.state import ModalChangedEvent, UiStore
from agenterm.ui.tui.stderr_capture import StderrCaptureProxy
from agenterm.ui.tui.style import tui_style
from agenterm.ui.tui.transcript import TranscriptControl

if TYPE_CHECKING:
    from collections.abc import Callable

    from prompt_toolkit.completion import Completer
    from prompt_toolkit.layout.processors import Processor

    from agenterm.core.approvals import ApprovalsContext
    from agenterm.core.types import SessionState
    from agenterm.ui.repl.phase_state import ReplPhaseState


_COMPOSER_MAX_HEIGHT: Final[int] = 8
_APPROVALS_MODAL_HEIGHT: Final[int] = 4
_COMPLETION_MENU_MAX_HEIGHT: Final[int] = 10
_PADDING_MARGIN_WIDTH: Final[int] = 1


def _prompt_color_depth(depth: str) -> ColorDepth | None:
    if depth == "auto":
        return _auto_color_depth()
    if depth == "mono":
        return ColorDepth.DEPTH_1_BIT
    if depth == "ansi":
        return ColorDepth.DEPTH_4_BIT
    if depth == "default":
        return ColorDepth.DEPTH_8_BIT
    if depth == "truecolor":
        return ColorDepth.DEPTH_24_BIT
    return None


def _auto_color_depth() -> ColorDepth | None:
    if _supports_truecolor():
        return ColorDepth.DEPTH_24_BIT
    return None


def _supports_truecolor() -> bool:
    colorterm = os.environ.get("COLORTERM", "").lower()
    if "truecolor" in colorterm or "24bit" in colorterm:
        return True
    term = os.environ.get("TERM", "").lower()
    if "truecolor" in term or "24bit" in term or "direct" in term:
        return True
    term_program = os.environ.get("TERM_PROGRAM", "")
    return term_program in {"Apple_Terminal", "iTerm.app"}


class ReplTui:
    """Full-screen prompt-toolkit application for the REPL."""

    def __init__(
        self,
        *,
        state_provider: Callable[[], SessionState],
        phase_state: ReplPhaseState,
        store: UiStore,
        cancel_current_run: Callable[[], None],
        cancel_available: Callable[[], bool],
        stderr_handler: Callable[[str], None] | None = None,
    ) -> None:
        """Initialize the TUI with shared REPL state and callbacks."""
        self._state_provider = state_provider
        self._phase_state = phase_state
        self._store = store
        self._cancel_current_run = cancel_current_run
        self._cancel_available = cancel_available
        self._stderr_handler = stderr_handler
        self._queue: asyncio.Queue[str | None] = asyncio.Queue()
        self._buffer = self._build_buffer()
        self._app = self._build_application()
        self._store.on_change += self._invalidate

        # Animation controller for waveform during running phase
        verbosity = state_provider().ui.verbosity
        self._animation = AnimationController(
            self._invalidate,
            AnimationConfig(fps=60, enabled=verbosity != "quiet"),
        )

    @property
    def app(self) -> Application[None]:
        """Expose the underlying prompt-toolkit application."""
        return self._app

    def _invalidate(self, _store: UiStore | None = None) -> None:
        if self._app.is_running:
            self._app.invalidate()

    def _snapshot_approvals(self, state: SessionState) -> ApprovalsSnapshot:
        approvals = state.approvals
        return ApprovalsSnapshot(
            mode=approvals.mode,
            shell_pending=len(approvals.shell.pending()),
            patch_pending=len(approvals.patch.pending()),
            mcp_pending=len(approvals.mcp.pending()),
        )

    def _build_placeholder(self) -> Callable[[], FormattedText]:
        def _placeholder() -> FormattedText:
            state = self._state_provider()
            approvals = self._snapshot_approvals(state)
            vm = build_repl_tui_model(
                state=state,
                phase_state=self._phase_state,
                approvals=approvals,
            )
            return format_placeholder(vm)

        return _placeholder

    def _build_bottom_toolbar(self) -> Callable[[], FormattedText]:
        def _terminal_width() -> int | None:
            try:
                return get_app().output.get_size().columns
            except (RuntimeError, AttributeError):
                return None

        def _bottom_toolbar() -> FormattedText:
            state = self._state_provider()
            approvals = self._snapshot_approvals(state)
            vm = build_repl_tui_model(
                state=state,
                phase_state=self._phase_state,
                approvals=approvals,
            )
            return format_bottom_toolbar(vm, width=_terminal_width())

        return _bottom_toolbar

    def _build_completer(self) -> Completer:
        state = self._state_provider()
        completion_mode = state.ui.completion
        if completion_mode == "off":
            return NullCompleter()
        return CommandCompleter(self._state_provider)

    def _build_auto_suggest(self) -> HistoryAutoSuggest | None:
        state = self._state_provider()
        if state.ui.completion != "full":
            return None
        return HistoryAutoSuggest()

    def _accept_handler(self, buffer: Buffer) -> bool:
        text = buffer.text
        if not text.strip():
            return False
        self._queue.put_nowait(text)
        return False

    def _build_buffer(self) -> Buffer:
        history = FileHistory(str(history_file_path()))
        return Buffer(
            history=history,
            completer=self._build_completer(),
            auto_suggest=self._build_auto_suggest(),
            multiline=True,
            complete_while_typing=False,
            accept_handler=self._accept_handler,
        )

    def _input_processors(self) -> list[Processor]:
        @Condition
        def _display_placeholder() -> bool:
            return self._buffer.text == ""

        placeholder = self._build_placeholder()
        return [
            HighlightIncrementalSearchProcessor(),
            HighlightSelectionProcessor(),
            DisplayMultipleCursors(),
            AppendAutoSuggestion(),
            ConditionalProcessor(AfterInput(placeholder), filter=_display_placeholder),
        ]

    def _prompt_prefix(self, line_number: int, wrap_count: int) -> FormattedText:
        _ = wrap_count
        state = self._state_provider()
        approvals = self._snapshot_approvals(state)
        vm = build_repl_tui_model(
            state=state,
            phase_state=self._phase_state,
            approvals=approvals,
        )
        if line_number == 0:
            return format_prompt_message(vm)
        return FormattedText([("class:prompt.chevron", "... ")])

    def _build_completion_menu(self) -> ConditionalContainer:
        @Condition
        def _enabled() -> bool:
            return self._state_provider().ui.completion != "off"

        return ConditionalContainer(
            content=Window(
                content=CompletionsMenuControl(),
                width=Dimension(min=8),
                height=Dimension(min=1, max=_COMPLETION_MENU_MAX_HEIGHT),
                scroll_offsets=ScrollOffsets(top=1, bottom=1),
                dont_extend_height=True,
                style="class:completion-menu",
            ),
            filter=_enabled & has_completions & ~is_done,
        )

    def _build_transcript_window(self) -> Window:
        def _render_config() -> tuple[bool, str]:
            state = self._state_provider()
            render_markdown = bool(
                state.ui.render_markdown and state.ui.stream_mode == "final"
            )
            return render_markdown, state.ui.color_depth

        control = TranscriptControl(
            self._store,
            render_config=_render_config,
        )
        return Window(
            control,
            # TranscriptControl pre-wraps lines; disable prompt_toolkit wrapping.
            wrap_lines=False,
            get_vertical_scroll=control.get_vertical_scroll,
            scroll_offsets=ScrollOffsets(top=0, bottom=0),
            left_margins=[PaddingMargin(_PADDING_MARGIN_WIDTH)],
            right_margins=[
                PaddingMargin(_PADDING_MARGIN_WIDTH),
            ],
            style="class:transcript",
            dont_extend_height=False,
        )

    def _build_composer_window(self) -> Window:
        control = BufferControl(
            buffer=self._buffer,
            input_processors=self._input_processors(),
            include_default_input_processors=False,
        )

        return Window(
            control,
            height=Dimension(min=1, max=_COMPOSER_MAX_HEIGHT),
            wrap_lines=True,
            left_margins=[
                PaddingMargin(_PADDING_MARGIN_WIDTH, style="class:input-area"),
            ],
            right_margins=[
                PaddingMargin(_PADDING_MARGIN_WIDTH, style="class:input-area"),
            ],
            style="class:input-area",
            get_line_prefix=self._prompt_prefix,
            dont_extend_height=True,
        )

    def _build_status_bar(self) -> Window:
        return Window(
            FormattedTextControl(self._build_bottom_toolbar()),
            height=Dimension.exact(1),
            style="class:transcript",  # Same bg as transcript, not separate toolbar
            dont_extend_height=True,
        )

    def _build_spacer(self, *, style: str = "class:prompt.spacer") -> Window:
        return Window(
            FormattedTextControl([("", " ")]),
            height=Dimension.exact(1),
            style=style,
            dont_extend_height=True,
        )

    def _build_activity_indicator(self) -> Window:
        def _terminal_width() -> int | None:
            try:
                # Subtract padding margins (1 char each side)
                return get_app().output.get_size().columns - 2 * _PADDING_MARGIN_WIDTH
            except (RuntimeError, AttributeError):
                return None

        def _indicator_content() -> FormattedText:
            state = self._state_provider()
            approvals = self._snapshot_approvals(state)
            vm = build_repl_tui_model(
                state=state,
                phase_state=self._phase_state,
                approvals=approvals,
            )
            return format_activity_indicator(vm, width=_terminal_width())

        return Window(
            FormattedTextControl(_indicator_content),
            height=Dimension.exact(1),
            left_margins=[
                PaddingMargin(_PADDING_MARGIN_WIDTH, style="class:transcript"),
            ],
            right_margins=[
                PaddingMargin(_PADDING_MARGIN_WIDTH, style="class:transcript"),
            ],
            style="class:indicator",
            dont_extend_height=True,
        )

    def _build_approvals_modal(self) -> ConditionalContainer:
        def _approvals_provider() -> ApprovalsContext:
            return self._state_provider().approvals

        control = ApprovalsModalControl(_approvals_provider)
        window = Window(
            control,
            height=Dimension(preferred=_APPROVALS_MODAL_HEIGHT + 3),
            style="class:modal",
            wrap_lines=True,
        )

        @Condition
        def _visible() -> bool:
            return self._store.state.modal == "approvals"

        return ConditionalContainer(window, filter=_visible)

    def _build_application(self) -> Application[None]:
        transcript = self._build_transcript_window()
        composer = self._build_composer_window()
        status_bar = self._build_status_bar()
        completion_menu = self._build_completion_menu()
        spacer_top = self._build_spacer()
        spacer_bottom = self._build_spacer()
        activity_indicator = self._build_activity_indicator()
        body = HSplit([transcript, completion_menu, spacer_top, composer])

        root = FloatContainer(
            HSplit([body, spacer_bottom, activity_indicator, status_bar]),
            floats=[
                Float(
                    content=self._build_approvals_modal(),
                    top=2,
                    left=4,
                    right=4,
                ),
            ],
        )
        layout = Layout(container=root, focused_element=composer)
        return Application(
            layout=layout,
            key_bindings=build_repl_key_bindings(
                cancel_current_run=self._cancel_current_run,
                cancel_available=self._cancel_available,
                request_exit=self.request_exit,
            ),
            style=tui_style(self._state_provider),
            full_screen=True,
            mouse_support=Condition(lambda: bool(self._state_provider().ui.mouse)),
            color_depth=lambda: _prompt_color_depth(
                self._state_provider().ui.color_depth,
            ),
            editing_mode=(
                EditingMode.VI
                if self._state_provider().ui.editing_mode == "vi"
                else EditingMode.EMACS
            ),
            # Use default coalescing (0.01s) and no global refresh.
            # Animation is driven by AnimationController.start_animation().
        )

    async def run(self) -> None:
        """Run the prompt-toolkit application."""
        try:
            with patch_stdout(raw=True):
                stderr_proxy: StderrCaptureProxy | None = None
                if self._stderr_handler is not None:
                    stderr_proxy = StderrCaptureProxy(
                        loop=asyncio.get_running_loop(),
                        handle_line=self._stderr_handler,
                        forward=sys.stderr,
                    )
                    sys.stderr = stderr_proxy
                try:
                    await self._app.run_async()
                finally:
                    if stderr_proxy is not None:
                        stderr_proxy.flush()
                        sys.stderr = stderr_proxy.forward
        finally:
            self._queue.put_nowait(None)

    def request_exit(self) -> None:
        """Request the TUI to exit."""
        if self._app.is_running:
            self._app.exit()
        self._queue.put_nowait(None)

    async def next_input(self) -> str | None:
        """Await the next submitted input line (None indicates exit)."""
        return await self._queue.get()

    def sync_approvals_modal(self) -> None:
        """Open/close the approvals modal based on pending approvals."""
        approvals = self._state_provider().approvals
        pending = (
            approvals.shell.pending()
            or approvals.patch.pending()
            or approvals.mcp.pending()
        )
        if approvals.mode == "prompt" and pending:
            self._store.dispatch(ModalChangedEvent(modal="approvals"))
        elif self._store.state.modal == "approvals":
            self._store.dispatch(ModalChangedEvent(modal="none"))
        self._app.invalidate()

    def set_buffer_text(self, text: str) -> None:
        """Replace the main input buffer contents."""
        self._buffer.text = text
        self._buffer.cursor_position = len(text)
        self._app.invalidate()

    def refresh_completion_mode(self) -> None:
        """Refresh the completer based on the current state."""
        self._buffer.completer = self._build_completer()
        self._buffer.auto_suggest = self._build_auto_suggest()

    def refresh_editing_mode(self) -> None:
        """Refresh the editing mode based on the current state."""
        self._app.editing_mode = (
            EditingMode.VI
            if self._state_provider().ui.editing_mode == "vi"
            else EditingMode.EMACS
        )

    def invalidate(self) -> None:
        """Public invalidate hook for external state changes."""
        self._invalidate()

    def start_animation(self) -> None:
        """Start the animation loop for the running phase."""
        self._animation.start()

    def stop_animation(self) -> None:
        """Stop the animation loop when the run completes."""
        self._animation.stop()


__all__ = ("ReplTui",)
