"""Self-invalidating animation controller for the REPL TUI."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from asyncio import Task
    from collections.abc import Callable


@dataclass(frozen=True)
class AnimationConfig:
    """Configuration for the animation loop."""

    fps: int = 60
    enabled: bool = True


class AnimationController:
    """Self-invalidating animation loop tied to REPL phase state.

    Calls the invalidate callback at the configured FPS while running.
    Start/stop are idempotent and thread-safe from the event loop.
    """

    __slots__ = ("_config", "_invalidate", "_task")

    def __init__(
        self,
        invalidate: Callable[[], None],
        config: AnimationConfig,
    ) -> None:
        """Initialize the animation controller.

        Args:
            invalidate: Callback to trigger UI refresh.
            config: Animation configuration (FPS, enabled flag).

        """
        self._invalidate = invalidate
        self._config = config
        self._task: Task[None] | None = None

    def start(self) -> None:
        """Start the animation loop (idempotent).

        If already running or disabled, this is a no-op.
        """
        if self._task is not None or not self._config.enabled:
            return
        self._task = asyncio.create_task(self._run())

    def stop(self) -> None:
        """Stop the animation loop (idempotent).

        If not running, this is a no-op.
        """
        if self._task is None:
            return
        self._task.cancel()
        self._task = None

    @property
    def running(self) -> bool:
        """Return True if the animation loop is currently running."""
        return self._task is not None

    async def _run(self) -> None:
        """Run the animation loop: sleep, then invalidate."""
        interval = 1.0 / self._config.fps
        try:
            while True:
                await asyncio.sleep(interval)
                self._invalidate()
        except asyncio.CancelledError:
            pass


__all__ = ("AnimationConfig", "AnimationController")
