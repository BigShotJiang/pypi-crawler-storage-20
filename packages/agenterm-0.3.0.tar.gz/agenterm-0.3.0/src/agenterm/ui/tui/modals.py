"""Modal UI controls for the REPL TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.layout.controls import UIContent, UIControl

from agenterm.core.text import shorten_line

if TYPE_CHECKING:
    from collections.abc import Callable

    from prompt_toolkit.formatted_text import StyleAndTextTuples

    from agenterm.core.approvals import (
        ApprovalsContext,
        CompressionApprovalItem,
        McpApprovalItem,
        PatchApprovalItem,
        ShellApprovalItem,
    )


type Fragments = StyleAndTextTuples


def _shell_summary(item: ShellApprovalItem) -> str:
    head = item.commands[0] if item.commands else "(no command)"
    extra = len(item.commands) - 1
    summary = shorten_line(head, limit=72)
    if item.description:
        desc = shorten_line(item.description, limit=72)
        summary = shorten_line(f"{desc} — {summary}", limit=78)
    if extra > 0:
        summary = shorten_line(f"{summary} (+{extra})", limit=78)
    if item.cwd:
        return shorten_line(f"{summary} (cwd={item.cwd})", limit=88)
    return summary


def _patch_summary(item: PatchApprovalItem) -> str:
    base = f"{item.operation_type} {item.path}"
    if item.description:
        base = f"{item.description} — {base}"
    return shorten_line(base, limit=88)


def _mcp_summary(item: McpApprovalItem) -> str:
    return shorten_line(f"{item.server_label} {item.tool_name}", limit=88)


def _compress_summary(item: CompressionApprovalItem) -> str:
    return shorten_line(item.message, limit=88)


def _approval_lines(approvals: ApprovalsContext) -> list[str]:
    lines = [
        f"- {item.id}: {_compress_summary(item)}"
        for item in approvals.compress.pending()
    ]
    lines.extend(
        f"- {item.id}: {_shell_summary(item)}" for item in approvals.shell.pending()
    )
    lines.extend(
        f"- {item.id}: {_patch_summary(item)}" for item in approvals.patch.pending()
    )
    lines.extend(
        f"- {item.id}: {_mcp_summary(item)}" for item in approvals.mcp.pending()
    )
    return lines


def _modal_lines(approvals: ApprovalsContext) -> list[Fragments]:
    compress_pending = len(approvals.compress.pending())
    shell_pending = len(approvals.shell.pending())
    patch_pending = len(approvals.patch.pending())
    mcp_pending = len(approvals.mcp.pending())
    total = compress_pending + shell_pending + patch_pending + mcp_pending

    header = f"Approvals pending ({total})"
    lines: list[Fragments] = [[("class:modal.title", header)]]
    counts = (
        f"compress={compress_pending} shell={shell_pending} "
        f"patch={patch_pending} mcp={mcp_pending}"
    )
    lines.append([("class:modal.dim", counts)])

    if total == 0:
        lines.append([("class:modal.dim", "No pending approvals.")])
    else:
        lines.extend(
            [[("class:modal", line)] for line in _approval_lines(approvals)],
        )

    lines.append(
        [
            ("class:modal.key", "y approve"),
            ("class:modal.dim", " | "),
            ("class:modal.key", "n reject"),
            ("class:modal.dim", " | "),
            ("class:modal.key", "/approvals list"),
        ],
    )
    return lines


class ApprovalsModalControl(UIControl):
    """UIControl that renders the approvals modal."""

    def __init__(self, approvals_provider: Callable[[], ApprovalsContext]) -> None:
        """Initialize with a live approvals provider."""
        self._approvals_provider = approvals_provider

    def create_content(self, width: int, height: int) -> UIContent:
        """Build UIContent for the approvals modal."""
        _ = width
        lines = _modal_lines(self._approvals_provider())

        if height > 0 and len(lines) < height:
            while len(lines) < height:
                lines.append([("", "")])

        def _get_line(i: int) -> StyleAndTextTuples:
            return lines[i]

        return UIContent(get_line=_get_line, line_count=len(lines))

    def is_focusable(self) -> bool:
        """Return False; modal is not focusable."""
        return False


__all__ = ("ApprovalsModalControl",)
