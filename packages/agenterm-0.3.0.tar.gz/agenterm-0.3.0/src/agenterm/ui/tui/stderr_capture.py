"""stderr capture proxy for prompt_toolkit REPL."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import asyncio
    from collections.abc import Callable
    from typing import TextIO


class StderrCaptureProxy:
    """File-like proxy that forwards stderr and emits complete lines."""

    def __init__(
        self,
        *,
        loop: asyncio.AbstractEventLoop,
        handle_line: Callable[[str], None],
        forward: TextIO,
    ) -> None:
        """Initialize the proxy with a handler and forward stream."""
        self._loop = loop
        self._handle_line = handle_line
        self._forward = forward
        self._buffer = ""
        self._lock = threading.Lock()

    def _enqueue_line(self, line: str) -> None:
        self._loop.call_soon_threadsafe(self._handle_line, line)

    def write(self, data: str) -> int:
        """Write data to the forward stream and queue complete lines."""
        if not data:
            return 0
        normalized = data.replace("\r\n", "\n").replace("\r", "\n")
        with self._lock:
            self._forward.write(data)
            self._buffer += normalized
            chunks = self._buffer.split("\n")
            self._buffer = chunks.pop()
        for line in chunks:
            self._enqueue_line(line)
        return len(data)

    def flush(self) -> None:
        """Flush the forward stream and emit any buffered remainder."""
        with self._lock:
            self._forward.flush()
            remainder = self._buffer
            self._buffer = ""
        if remainder:
            self._enqueue_line(remainder)

    def fileno(self) -> int:
        """Return the underlying file descriptor."""
        return self._forward.fileno()

    def isatty(self) -> bool:
        """Return True if the forward stream is a TTY."""
        return self._forward.isatty()

    @property
    def encoding(self) -> str | None:
        """Return the encoding for the forward stream."""
        return self._forward.encoding

    @property
    def errors(self) -> str | None:
        """Return the error handling policy for the forward stream."""
        return self._forward.errors

    @property
    def forward(self) -> TextIO:
        """Return the wrapped stderr stream."""
        return self._forward


__all__ = ("StderrCaptureProxy",)
