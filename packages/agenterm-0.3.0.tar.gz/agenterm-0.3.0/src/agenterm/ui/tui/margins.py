"""Padding margins for prompt-toolkit windows."""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.layout.margins import Margin

if TYPE_CHECKING:
    from collections.abc import Callable

    from prompt_toolkit.formatted_text import StyleAndTextTuples
    from prompt_toolkit.layout.containers import WindowRenderInfo
    from prompt_toolkit.layout.controls import UIContent


class PaddingMargin(Margin):
    """Fixed-width padding margin used to keep text off terminal edges."""

    def __init__(self, width: int, *, style: str = "") -> None:
        """Store margin width and style."""
        self._width = max(0, int(width))
        self._style = style

    def get_width(self, get_ui_content: Callable[[], UIContent]) -> int:
        """Return the fixed margin width."""
        _ = get_ui_content
        return self._width

    def create_margin(
        self,
        window_render_info: WindowRenderInfo,
        width: int,
        height: int,
    ) -> StyleAndTextTuples:
        """Return repeated padding fragments for the margin area."""
        _ = window_render_info
        if width <= 0 or height <= 0:
            return []
        pad = " " * width
        result: StyleAndTextTuples = []
        for _ in range(height):
            result.append((self._style, pad))
            result.append(("", "\n"))
        return result


__all__ = ("PaddingMargin",)
