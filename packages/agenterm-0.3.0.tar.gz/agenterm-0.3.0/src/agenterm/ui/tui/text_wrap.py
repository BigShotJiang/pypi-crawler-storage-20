"""Fragment wrapping helpers for prompt-toolkit transcript rendering.

prompt-toolkit supports wrapping at the Window level, but that path computes
wrap layout on every repaint (including scroll). For the REPL transcript we
pre-wrap once per width and keep Window(wrap_lines=False) so scrolling is
immediate and deterministic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.utils import get_cwidth

if TYPE_CHECKING:
    from prompt_toolkit.formatted_text import OneStyleAndTextTuple, StyleAndTextTuples

type Fragments = StyleAndTextTuples

_FRAGMENT_TUPLE_LEN_NO_HANDLER = 2


def _fragment_parts(frag: OneStyleAndTextTuple) -> tuple[str, str]:
    if len(frag) == _FRAGMENT_TUPLE_LEN_NO_HANDLER:
        style, text = frag
        return style, text
    style, text, _handler = frag
    return style, text


def _make_fragment(style: str, text: str) -> OneStyleAndTextTuple:
    return (style, text)


def _append_fragment_text(
    line: Fragments,
    *,
    style: str,
    text: str,
) -> None:
    if not text:
        return
    if not line:
        line.append(_make_fragment(style, text))
        return
    last_frag = line[-1]
    last_style, last_text = _fragment_parts(last_frag)
    if last_style == style:
        line[-1] = _make_fragment(style, last_text + text)
        return
    line.append(_make_fragment(style, text))


def wrap_fragments(fragments: Fragments, *, width: int) -> list[Fragments]:
    """Wrap a fragment list into multiple lines, preserving styles."""
    if width <= 0:
        return [list(fragments)]

    lines: list[Fragments] = []
    current: Fragments = []
    current_width = 0

    for frag in fragments:
        style, text = _fragment_parts(frag)

        # Zero-width escapes should not contribute to width, but must be preserved
        # in-order in the output stream.
        if style == "[ZeroWidthEscape]":
            _append_fragment_text(current, style=style, text=text)
            continue

        if not text:
            continue

        for ch in text:
            ch_width = get_cwidth(ch)
            if current and current_width + ch_width > width:
                lines.append(current)
                current = []
                current_width = 0

            _append_fragment_text(
                current,
                style=style,
                text=ch,
            )
            current_width += ch_width

            # If a single character consumes the whole width (or more), flush it
            # to avoid getting stuck on subsequent characters.
            if current_width >= width and current:
                lines.append(current)
                current = []
                current_width = 0

    if current:
        lines.append(current)

    if not lines:
        return [[("", "")]]
    return lines


__all__ = ("wrap_fragments",)
