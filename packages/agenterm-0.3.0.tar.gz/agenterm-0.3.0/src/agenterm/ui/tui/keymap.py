"""Key bindings for the REPL TUI."""

from __future__ import annotations

from typing import TYPE_CHECKING

from prompt_toolkit.filters import Condition
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import ALL_KEYS, KEY_ALIASES

if TYPE_CHECKING:
    from collections.abc import Callable

    from prompt_toolkit.buffer import Buffer
    from prompt_toolkit.key_binding.key_processor import KeyPressEvent


def _supports_shift_enter() -> bool:
    return "s-enter" in ALL_KEYS or "s-enter" in KEY_ALIASES


def _slash_command(text: str) -> bool:
    return text.lstrip().startswith("/")


def _apply_completion(buf: Buffer) -> bool:
    state = buf.complete_state
    if state is None:
        return False
    if state.current_completion is None and state.completions:
        buf.go_to_completion(0)
        state = buf.complete_state
    if state is None or state.current_completion is None:
        return False
    buf.apply_completion(state.current_completion)
    return True


def _handle_enter(
    event: KeyPressEvent,
) -> None:
    buf: Buffer = event.app.current_buffer
    if _apply_completion(buf):
        return
    if not buf.text.strip():
        return
    buf.validate_and_handle()


def _handle_shift_enter(
    event: KeyPressEvent,
) -> None:
    _handle_newline(event)


def _handle_ctrl_j(event: KeyPressEvent) -> None:
    _handle_newline(event)


def _handle_ctrl_c(
    event: KeyPressEvent,
    *,
    cancel_current_run: Callable[[], None],
    cancel_available: Callable[[], bool],
) -> None:
    if cancel_available():
        cancel_current_run()
        return
    buf: Buffer = event.app.current_buffer
    if not buf.text:
        return
    buf.reset()


def _handle_newline(event: KeyPressEvent) -> None:
    buf: Buffer = event.app.current_buffer
    if _apply_completion(buf):
        return
    if _slash_command(buf.text):
        if not buf.text.strip():
            return
        buf.validate_and_handle()
        return
    buf.newline()


def _handle_tab(event: KeyPressEvent) -> None:
    buf: Buffer = event.app.current_buffer
    if not buf.text.strip():
        return
    if not _slash_command(buf.text):
        suggestion = buf.suggestion
        if (
            suggestion is not None
            and suggestion.text
            and buf.document.is_cursor_at_the_end
        ):
            buf.insert_text(suggestion.text)
        return
    state = buf.complete_state
    if state is not None:
        buf.complete_next()
        return
    buf.start_completion(select_first=True)


def _handle_escape(
    _event: KeyPressEvent,
    *,
    cancel_current_run: Callable[[], None],
) -> None:
    cancel_current_run()


def _handle_ctrl_d(
    _event: KeyPressEvent,
    *,
    request_exit: Callable[[], None],
) -> None:
    request_exit()


def build_repl_key_bindings(
    *,
    cancel_current_run: Callable[[], None],
    cancel_available: Callable[[], bool],
    request_exit: Callable[[], None],
) -> KeyBindings:
    """Return REPL key bindings for the TUI."""
    kb = KeyBindings()
    cancel_filter = Condition(cancel_available)

    def _on_enter(event: KeyPressEvent) -> None:
        _handle_enter(event)

    def _on_shift_enter(event: KeyPressEvent) -> None:
        _handle_shift_enter(event)

    def _on_ctrl_j(event: KeyPressEvent) -> None:
        _handle_ctrl_j(event)

    def _on_ctrl_c(event: KeyPressEvent) -> None:
        _handle_ctrl_c(
            event,
            cancel_current_run=cancel_current_run,
            cancel_available=cancel_available,
        )

    def _on_tab(event: KeyPressEvent) -> None:
        _handle_tab(event)

    def _on_ctrl_d(event: KeyPressEvent) -> None:
        _handle_ctrl_d(event, request_exit=request_exit)

    def _on_escape(event: KeyPressEvent) -> None:
        _handle_escape(event, cancel_current_run=cancel_current_run)

    kb.add("enter")(_on_enter)
    if _supports_shift_enter():
        kb.add("s-enter")(_on_shift_enter)
    kb.add("c-j")(_on_ctrl_j)
    kb.add("c-c")(_on_ctrl_c)
    kb.add("tab")(_on_tab)
    kb.add("c-d")(_on_ctrl_d)
    kb.add("escape", filter=cancel_filter, eager=True)(_on_escape)
    return kb


__all__ = ("build_repl_key_bindings",)
