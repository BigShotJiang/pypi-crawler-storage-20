"""Prompt-toolkit TUI package for the REPL."""

from __future__ import annotations

__all__: tuple[str, ...] = ()
