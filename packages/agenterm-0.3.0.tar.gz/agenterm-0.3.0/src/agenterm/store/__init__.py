"""Persistence layer abstractions."""

from __future__ import annotations

__all__ = ()
