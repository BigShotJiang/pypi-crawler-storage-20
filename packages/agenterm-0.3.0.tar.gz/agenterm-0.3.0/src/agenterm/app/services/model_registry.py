"""Provider-scoped model registry refresh/validation."""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from openai import AsyncOpenAI, OpenAIError

from agenterm.config.editors import validate_model_id
from agenterm.constants.limits import MODEL_REGISTRY_TTL_SECONDS
from agenterm.core.errors import ConfigError, ValidationError
from agenterm.core.json_codec import dumps_compact, loads_json_value
from agenterm.core.openai_client import get_openai_client
from agenterm.store.model_registry import (
    ModelRegistryRow,
    get_model_registry_row,
    upsert_model_registry_row,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from openai.types import Model

    from agenterm.config.model import ProvidersConfig
    from agenterm.store.async_db import AsyncStore
_MODEL_REGISTRY_SOURCE = "openai/models"


@dataclass(frozen=True)
class ModelRegistry:
    """Cached model registry snapshot from OpenAI."""

    models: frozenset[str]
    fetched_at: int
    source: str

    def is_stale(self, *, now: int, ttl_seconds: int) -> bool:
        """Return True when the registry age exceeds ttl_seconds."""
        return (now - self.fetched_at) > ttl_seconds

    def list_models(self, *, filter_text: str | None = None) -> list[str]:
        """Return sorted model ids, optionally filtered by substring."""
        models = sorted(self.models)
        if filter_text is None:
            return models
        needle = filter_text.strip().lower()
        if not needle:
            return models
        return [m for m in models if needle in m.lower()]


@dataclass(frozen=True)
class ParsedModelId:
    """Parsed model identifier parts."""

    prefix: str
    route: str | None
    model: str


class ModelRegistryClient(Protocol):
    """Protocol for model registry sources."""

    async def list_model_ids(self) -> list[str]:
        """Return known model identifiers."""
        ...


@dataclass(frozen=True)
class OpenAIModelRegistryClient:
    """Adapter for fetching model ids from the OpenAI SDK client."""

    client: AsyncOpenAI

    async def list_model_ids(self) -> list[str]:
        """Fetch model ids using the OpenAI `/models` endpoint."""
        page = await self.client.models.list()
        items: Sequence[Model] = page.data
        return _collect_model_ids(items)


def _collect_model_ids(raw: Sequence[Model]) -> list[str]:
    out: list[str] = []
    for item in raw:
        model_id = item.id
        if model_id:
            out.append(_prefix_openai_model_id(model_id))
    return out


def _prefix_openai_model_id(model_id: str) -> str:
    trimmed = model_id.strip()
    if not trimmed:
        return trimmed
    if trimmed.startswith("openai/"):
        return trimmed
    if "/" in trimmed:
        return trimmed
    return f"openai/{trimmed}"


def _parse_model_id(model_id: str) -> ParsedModelId:
    prefix, rest = model_id.split("/", 1)
    prefix_norm = prefix.lower()
    if prefix_norm == "openai":
        return ParsedModelId(prefix=prefix_norm, route=None, model=rest)
    if prefix_norm == "gateway":
        route, model = rest.split("/", 1)
        return ParsedModelId(prefix=prefix_norm, route=route, model=model)
    msg = "Model id prefix must be openai/ or gateway/."
    raise ValidationError(msg)


def _decode_registry_models(payload: str) -> list[str]:
    try:
        parsed = loads_json_value(payload)
    except (TypeError, ValueError) as exc:
        msg = "Model registry cache is corrupted (invalid JSON)."
        raise ConfigError(msg) from exc
    if not isinstance(parsed, list):
        msg = "Model registry cache is corrupted (expected list of strings)."
        raise ConfigError(msg)
    models: list[str] = []
    for item in parsed:
        if not isinstance(item, str):
            msg = "Model registry cache is corrupted (expected list of strings)."
            raise ConfigError(msg)
        if item:
            models.append(_prefix_openai_model_id(item))
    return models


async def load_model_registry(*, store: AsyncStore) -> ModelRegistry | None:
    """Load the cached model registry from SQLite, if present."""
    row = await get_model_registry_row(store)
    if row is None:
        return None
    models = _decode_registry_models(row.models_json)
    if not models:
        msg = "Model registry cache is empty."
        raise ConfigError(msg)
    return ModelRegistry(
        models=frozenset(models),
        fetched_at=int(row.fetched_at),
        source=row.source,
    )


async def refresh_model_registry(
    *,
    store: AsyncStore,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
    now: int | None = None,
) -> ModelRegistry:
    """Refresh the cached model registry from OpenAI."""
    registry_client = client or OpenAIModelRegistryClient(get_openai_client())
    if isinstance(registry_client, AsyncOpenAI):
        registry_client = OpenAIModelRegistryClient(registry_client)
    try:
        models = await registry_client.list_model_ids()
    except OpenAIError as exc:
        msg = f"Failed to fetch OpenAI model list: {exc}"
        raise ConfigError(msg) from exc
    if not models:
        msg = "OpenAI model list returned no model ids."
        raise ConfigError(msg)
    models_sorted = sorted({_prefix_openai_model_id(m) for m in models if m})
    fetched_at = int(time.time() if now is None else now)
    row = ModelRegistryRow(
        source=_MODEL_REGISTRY_SOURCE,
        fetched_at=fetched_at,
        models_json=dumps_compact(
            models_sorted,
            ensure_ascii=True,
            context="model_registry.models_json",
        ),
    )
    await upsert_model_registry_row(store=store, row=row)
    return ModelRegistry(
        models=frozenset(models_sorted),
        fetched_at=fetched_at,
        source=row.source,
    )


async def require_model_registry(
    *,
    store: AsyncStore,
    ttl_seconds: int = MODEL_REGISTRY_TTL_SECONDS,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
    now: int | None = None,
) -> ModelRegistry:
    """Return a fresh registry snapshot or raise on refresh failure."""
    effective_now = int(time.time() if now is None else now)
    registry = await load_model_registry(store=store)
    if registry is None or registry.is_stale(
        now=effective_now,
        ttl_seconds=ttl_seconds,
    ):
        return await refresh_model_registry(
            store=store,
            client=client,
            now=effective_now,
        )
    return registry


async def validate_model_id_with_registry(
    model_id: str,
    *,
    store: AsyncStore,
    providers: ProvidersConfig,
    ttl_seconds: int = MODEL_REGISTRY_TTL_SECONDS,
    client: ModelRegistryClient | AsyncOpenAI | None = None,
) -> str:
    """Validate a model id against provider registries."""
    cleaned = validate_model_id(model_id)
    parsed = _parse_model_id(cleaned)
    if parsed.prefix == "openai":
        registry = await require_model_registry(
            store=store,
            ttl_seconds=ttl_seconds,
            client=client,
        )
        cleaned = _prefix_openai_model_id(cleaned)
        if cleaned not in registry.models:
            msg = (
                "Model id is not in the cached OpenAI /models list. "
                "Use `/model list openai` or `/model refresh openai` to inspect "
                "available models."
            )
            raise ValidationError(msg)
        return cleaned

    route = parsed.route
    if route is None:
        msg = "Gateway model ids must be gateway/<route>/<model>."
        raise ValidationError(msg)
    route_cfg = providers.gateway.routes.get(route)
    if route_cfg is None:
        msg = f"Unknown gateway route: {route}"
        raise ValidationError(msg)
    if route_cfg.api_key_env and not os.environ.get(route_cfg.api_key_env):
        msg = (
            f"Missing environment variable {route_cfg.api_key_env} for "
            f"gateway route {route}."
        )
        raise ConfigError(msg)
    if not route_cfg.allow_any_model and parsed.model not in route_cfg.model_allowlist:
        msg = (
            f"Model id is not allowed for gateway route {route}. "
            "Set providers.gateway.routes.<route>.model_allowlist or "
            "allow_any_model=true."
        )
        raise ValidationError(msg)
    return cleaned


__all__ = (
    "ModelRegistry",
    "ModelRegistryClient",
    "OpenAIModelRegistryClient",
    "load_model_registry",
    "refresh_model_registry",
    "require_model_registry",
    "validate_model_id_with_registry",
)
