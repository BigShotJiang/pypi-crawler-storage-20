# Examples

Examples are runnable demos and test assets. Canonical behavior and contracts
live in `README.md` and `ARCH.md`. Reference-only material lives in `docs/ref/`.

## Assets

- `assets/expression.jpeg` - math expression image for vision tests
  (prompt: "simplify this expression").
- `assets/agents_guide.pdf` - long-form PDF for attachment and file-search tests.

## Config

- `config/compression_percent.yaml` - compression percent-threshold example.
- `config/gateway_routes.yaml` - gateway route example.
- `config/context_window.yaml` - local-only context window example.
- `config/overrides.yaml` - per-run override example.
- `config/image_generation.yaml` - image tool bundle example.

## Structured output

- `structured/answer_schema.yaml` - JSON schema example for `model.text_format_file`.
- `structured/schema.weather.json` + `structured/instructions.weather.txt` -
  minimal structured-output demo.
- `structured/doc-check.instructions.md` + `structured/doc-check.schema.json` -
  doc consistency audit demo.

## Guardrails

- `guardrails/no_pii_input.py` - example input guardrail.
