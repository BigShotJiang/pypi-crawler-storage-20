"""Contract tests for CLI error kind classification."""

from __future__ import annotations

import httpx
from agents.exceptions import AgentsException
from litellm.exceptions import BadRequestError as LiteLLMBadRequestError
from openai import APIStatusError

from agenterm.core.error_report import ErrorContext, build_error_report
from agenterm.core.errors import ConfigError, McpConnectError, ToolExecutionError


def test_error_kind_maps_agenterm_exceptions_to_documented_kinds() -> None:
    context = ErrorContext(operation="test", resource="test", trace_id=None)
    assert build_error_report(ConfigError("bad config"), context=context).kind == "config_error"
    assert build_error_report(McpConnectError("mcp failed"), context=context).kind == "mcp_error"
    assert build_error_report(ToolExecutionError("tool failed"), context=context).kind == "tool_error"


def test_agents_exception_message_is_preserved() -> None:
    context = ErrorContext(operation="test", resource="test", trace_id=None)
    report = build_error_report(AgentsException("tool failed"), context=context)
    assert report.kind == "agents_error"
    assert "tool failed" in report.message


def test_openai_status_error_includes_details() -> None:
    context = ErrorContext(operation="test", resource="test", trace_id=None)
    request = httpx.Request("POST", "https://api.openai.com/v1/responses")
    response = httpx.Response(
        400,
        request=request,
        headers={"x-request-id": "req_123"},
        json={
            "error": {
                "message": "Invalid input format.",
                "type": "invalid_request_error",
                "param": "input",
                "code": "bad_request",
            },
        },
    )
    exc = APIStatusError("bad request", response=response, body=response.json())
    report = build_error_report(exc, context=context)
    assert report.kind == "provider_error"
    assert "status 400" in report.message
    assert "code=bad_request" in report.message
    assert "param=input" in report.message
    assert "Invalid input format" in report.message
    assert report.details.get("status_code") == 400
    assert report.details.get("request_id") == "req_123"
    assert report.details.get("code") == "bad_request"
    assert report.details.get("param") == "input"
    assert report.details.get("type") == "invalid_request_error"
    assert report.details.get("provider") == "openai"


def test_litellm_gateway_error_includes_provider_details() -> None:
    context = ErrorContext(operation="test", resource="test", trace_id=None)
    exc = LiteLLMBadRequestError(
        "bad request",
        model="claude-3-7",
        llm_provider="anthropic",
    )
    report = build_error_report(
        exc,
        context=context,
        extra_details={"provider": "gateway"},
    )
    assert report.kind == "provider_error"
    assert report.details.get("llm_provider") == "anthropic"
    assert report.details.get("model") == "claude-3-7"
    assert report.details.get("status_code") == 400
    assert report.details.get("provider") == "gateway"
    assert "anthropic" in report.message
