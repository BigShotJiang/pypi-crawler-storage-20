"""Contract tests for binary file handling in local CLI tools."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest
from agents.tool import FunctionTool
from agents.tool_context import ToolContext

import agenterm.engine.cli_tools.bat as bat_tool
import agenterm.engine.cli_tools.stat as stat_tool
from agenterm.config.tools_policy import BatToolConfig, StatToolConfig
from agenterm.core.cancellation import CancelToken
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import parse_function_tool_output_envelope


def _tool_context(tmp_path: Path) -> ToolRuntimeContext:
    return ToolRuntimeContext(
        db_path=tmp_path / "store.sqlite3",
        session_id=None,
        branch_id=None,
        run_number=None,
        trace_id=None,
        plan_cache={},
        cancel_token=None,
    )


def _invoke(tool: FunctionTool, *, ctx: ToolContext[ToolRuntimeContext], payload: str) -> str:
    async def _run() -> str:
        value = await tool.on_invoke_tool(ctx, payload)
        assert isinstance(value, str)
        return value

    return asyncio.run(_run())


def test_bat_rejects_binary_file(tmp_path: Path) -> None:
    (tmp_path / "bin.dat").write_bytes(b"\x00\xff\x00\x10abc")

    tool = bat_tool.build_bat_tool(BatToolConfig(), workspace_root=tmp_path)
    assert tool is not None
    tool_context = _tool_context(tmp_path)

    payload = json.dumps({"path": "bin.dat"}, ensure_ascii=True)
    ctx = ToolContext(
        context=tool_context,
        tool_name="bat",
        tool_call_id="call-1",
        tool_arguments=payload,
        tool_call=None,
    )
    out = _invoke(tool, ctx=ctx, payload=payload)
    env = parse_function_tool_output_envelope(out)
    assert env is not None
    assert env.ok is False
    assert env.error is not None
    assert env.error.kind == "invalid_input"
    assert isinstance(env.error.details, dict)
    assert env.error.details.get("reason") == "binary_file"


def test_stat_skips_lines_for_binary_files(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    (tmp_path / "bin.dat").write_bytes(b"\x00\xff\x00\x10abc")

    async def _stub_run_command(
        cmd: Sequence[str],
        *,
        cwd: str,
        env: Mapping[str, str],
        cancel_token: CancelToken | None = None,
    ) -> tuple[int, str, str]:
        _ = (cwd, env, cancel_token)
        if cmd == ["stat", "--version"]:
            return 0, "stat (GNU coreutils) 9.0", ""
        if cmd[:3] == ["stat", "--printf", "%F|%s|%Y|%a"]:
            rel_path = cmd[3]
            if rel_path == "bin.dat":
                return 0, "regular file|6|1700000000|0644", ""
            if rel_path == "dir":
                return 0, "directory|0|1700000000|0755", ""
        return 1, "", "unexpected command"

    monkeypatch.setattr(stat_tool, "run_command", _stub_run_command)

    tool = stat_tool.build_stat_tool(StatToolConfig(), workspace_root=tmp_path)
    assert tool is not None
    tool_context = _tool_context(tmp_path)

    payload = json.dumps(
        {"paths": ["bin.dat"], "include_lines": True},
        ensure_ascii=True,
    )
    ctx = ToolContext(
        context=tool_context,
        tool_name="stat",
        tool_call_id="call-1",
        tool_arguments=payload,
        tool_call=None,
    )
    out = _invoke(tool, ctx=ctx, payload=payload)
    env = parse_function_tool_output_envelope(out)
    assert env is not None and env.ok is True

    results = env.payload.get("results")
    assert isinstance(results, list) and len(results) == 1
    entry = results[0]
    assert isinstance(entry, dict)
    assert entry.get("binary") is True
    assert "lines" not in entry


def test_stat_directory_total_lines_excludes_binary_files(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    root = tmp_path / "dir"
    root.mkdir(parents=True)
    (root / "t.txt").write_text("a\nb\n", encoding="utf-8")
    (root / "b.bin").write_bytes(b"\x00\xff\x00\x10abc")

    async def _stub_run_command(
        cmd: Sequence[str],
        *,
        cwd: str,
        env: Mapping[str, str],
        cancel_token: CancelToken | None = None,
    ) -> tuple[int, str, str]:
        _ = (cwd, env, cancel_token)
        if cmd == ["stat", "--version"]:
            return 0, "stat (GNU coreutils) 9.0", ""
        if cmd[:3] == ["stat", "--printf", "%F|%s|%Y|%a"]:
            rel_path = cmd[3]
            if rel_path == "dir":
                return 0, "directory|0|1700000000|0755", ""
        return 1, "", "unexpected command"

    monkeypatch.setattr(stat_tool, "run_command", _stub_run_command)

    tool = stat_tool.build_stat_tool(StatToolConfig(), workspace_root=tmp_path)
    assert tool is not None
    tool_context = _tool_context(tmp_path)

    payload = json.dumps(
        {"paths": ["dir"], "include_lines": True},
        ensure_ascii=True,
    )
    ctx = ToolContext(
        context=tool_context,
        tool_name="stat",
        tool_call_id="call-1",
        tool_arguments=payload,
        tool_call=None,
    )
    out = _invoke(tool, ctx=ctx, payload=payload)
    env = parse_function_tool_output_envelope(out)
    assert env is not None and env.ok is True

    results = env.payload.get("results")
    assert isinstance(results, list) and len(results) == 1
    entry = results[0]
    assert isinstance(entry, dict)
    assert entry.get("total_lines") == 2
    assert entry.get("binary_files") == 1
