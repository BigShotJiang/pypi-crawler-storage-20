"""Unit tests for history packing."""

from __future__ import annotations

import asyncio
import json
from dataclasses import replace
from pathlib import Path

import pytest

from agents.items import TResponseInputItem

from agenterm.config.model import AppConfig, GatewayProviderConfig, GatewayRouteConfig
from agenterm.constants.limits import CONTEXT_WINDOW_CHARS_PER_TOKEN
from agenterm.core.errors import ConfigError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.response_items import serialize_input_item
from agenterm.engine.history_packing import HistoryPackingOptions, pack_history_items
from agenterm.engine.history_packing_io import parse_packed_items
from agenterm.store.session.agenterm_session import AgentermSQLiteSession


def _json_size(item: TResponseInputItem) -> int:
    jsonable = serialize_input_item(item, context="test_history_packing.item")
    raw = json.dumps(jsonable, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return len(raw)


def _items_size(items: list[TResponseInputItem]) -> int:
    return sum(_json_size(item) for item in items)


def _budget_tokens_between(min_chars: int, max_chars: int) -> int:
    if min_chars >= max_chars:
        raise AssertionError("min_chars must be < max_chars")
    target = (min_chars + max_chars) // 2
    tokens = max(1, int(target / CONTEXT_WINDOW_CHARS_PER_TOKEN))
    budget_chars = int(tokens * CONTEXT_WINDOW_CHARS_PER_TOKEN)
    if budget_chars <= min_chars:
        tokens = int((min_chars / CONTEXT_WINDOW_CHARS_PER_TOKEN) + 1)
        budget_chars = int(tokens * CONTEXT_WINDOW_CHARS_PER_TOKEN)
    if budget_chars >= max_chars:
        tokens = max(1, int((max_chars - 1) / CONTEXT_WINDOW_CHARS_PER_TOKEN))
    budget_chars = int(tokens * CONTEXT_WINDOW_CHARS_PER_TOKEN)
    assert min_chars < budget_chars < max_chars
    return tokens


def _user(text: str) -> TResponseInputItem:
    return {
        "type": "message",
        "role": "user",
        "content": [{"type": "input_text", "text": text}],
    }


def _assistant(text: str) -> TResponseInputItem:
    return {
        "type": "message",
        "id": f"assistant_{len(text)}",
        "role": "assistant",
        "status": "completed",
        "content": [{"type": "output_text", "text": text, "annotations": []}],
    }


def _assistant_with_id(text: str, item_id: str) -> TResponseInputItem:
    return {
        "type": "message",
        "id": item_id,
        "role": "assistant",
        "status": "completed",
        "content": [{"type": "output_text", "text": text, "annotations": []}],
    }


def _snapshot_item(text: str) -> TResponseInputItem:
    return {
        "type": "message",
        "role": "developer",
        "content": [
            {
                "type": "input_text",
                "text": f"memory_snapshot_json:\n{text}",
            }
        ],
    }


def _compaction_item(ciphertext: str) -> TResponseInputItem:
    return {
        "type": "compaction",
        "id": f"compaction_{len(ciphertext)}",
        "encrypted_content": ciphertext,
    }


def _make_session(tmp_path: Path) -> AgentermSQLiteSession:
    return AgentermSQLiteSession(
        session_id="sess",
        db_path=str(tmp_path / "history.sqlite3"),
        create_tables=True,
    )


def _history_from_session(
    session: AgentermSQLiteSession,
    *,
    items: list[TResponseInputItem],
) -> list[TResponseInputItem]:
    asyncio.run(session.add_items(items))
    return list(asyncio.run(session.get_items()))


def test_parse_packed_items_normalizes_iterables() -> None:
    items: list[TResponseInputItem] = [
        {
            "type": "reasoning",
            "id": "rs_1",
            "summary": [{"type": "summary_text", "text": "summary"}],
        },
        {
            "type": "message",
            "id": "msg_1",
            "role": "assistant",
            "status": "completed",
            "content": [{"type": "output_text", "text": "ok", "annotations": []}],
        },
    ]
    packed = [serialize_input_item(item, context="test_history_packing.pack") for item in items]
    parsed = parse_packed_items(packed, context="test_history_packing.parse")
    for item in parsed:
        json.dumps(item, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    summary = parsed[0].get("summary")
    assert isinstance(summary, list)


def _with_gateway_route(cfg: AppConfig, *, route: str = "test") -> AppConfig:
    route_cfg = GatewayRouteConfig(
        provider="mock",
        base_url=None,
        api_key_env=None,
        headers=None,
        model_allowlist=(),
        allow_any_model=True,
        supports_compaction=False,
        supports_file_id=False,
        supports_image_url=False,
        allow_inline_data_url=False,
    )
    providers = replace(
        cfg.providers,
        gateway=GatewayProviderConfig(routes={route: route_cfg}),
    )
    return replace(cfg, providers=providers)


def _flatten_text(items: list[TResponseInputItem]) -> str:
    parts: list[str] = []
    for item in items:
        jsonable = serialize_input_item(item, context="test_history_packing.item")
        raw = json.dumps(jsonable, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        parsed = parse_json_object(raw)
        if parsed is None:
            continue
        content = parsed.get("content")
        if not isinstance(content, list):
            continue
        for part in content:
            if not isinstance(part, dict):
                continue
            text_val = part.get("text")
            if isinstance(text_val, str):
                parts.append(text_val)
    return "\n".join(parts)


def test_pack_history_dedupes_duplicate_ids() -> None:
    history_items = [_assistant_with_id("history", "dup_1")]
    new_items: list[TResponseInputItem] = [
        _assistant_with_id("duplicate", "dup_1"),
        _user("fresh"),
    ]
    packed = asyncio.run(
        pack_history_items(
            cfg=AppConfig(),
            history_items=history_items,
            new_items=new_items,
            model_id="openai/gpt-5.2",
            session=None,
            store=None,
            options=HistoryPackingOptions(
                interactive=False,
                approvals=None,
            ),
        )
    )
    dup_count = sum(1 for item in packed if item.get("id") == "dup_1")
    assert dup_count == 1
    assert any(item.get("role") == "user" for item in packed)


def test_pack_history_trims_oldest_turns(tmp_path: Path) -> None:
    session = _make_session(tmp_path)
    history: list[TResponseInputItem] = [
        _user("turn1-user-" + ("a" * 800)),
        _assistant("turn1-assistant-" + ("b" * 800)),
        _user("turn2-user-" + ("c" * 40)),
        _assistant("turn2-assistant-" + ("d" * 40)),
    ]
    new_items: list[TResponseInputItem] = [_user("new-user-" + ("e" * 40))]
    history_items = _history_from_session(session, items=history)
    size_full = _items_size(history_items + new_items)
    size_trimmed = _items_size(history_items[2:] + new_items)
    budget_tokens = _budget_tokens_between(size_trimmed, size_full)

    cfg = AppConfig()
    cfg = replace(
        cfg,
        model=replace(
            cfg.model,
            context_window=budget_tokens,
            max_output_tokens=None,
        ),
        compression=replace(cfg.compression, drop_policy="allow"),
    )
    cfg = _with_gateway_route(cfg)

    packed = asyncio.run(
        pack_history_items(
            cfg=cfg,
            history_items=history_items,
            new_items=new_items,
            model_id="gateway/test/model",
            session=session,
            store=None,
            options=HistoryPackingOptions(
                interactive=False,
                approvals=None,
            ),
        )
    )
    text = _flatten_text(packed)
    assert "turn1-user-" not in text
    assert "turn2-user-" in text
    assert "new-user-" in text


def test_pack_history_preserves_snapshot_prefix(tmp_path: Path) -> None:
    session = _make_session(tmp_path)
    snapshot = _snapshot_item("{}")
    history: list[TResponseInputItem] = [
        snapshot,
        _user("old-user-" + ("a" * 400)),
        _assistant("old-assistant-" + ("b" * 400)),
    ]
    new_items: list[TResponseInputItem] = [_user("fresh-user-" + ("c" * 40))]
    history_items = _history_from_session(session, items=history)
    size_full = _items_size(history_items + new_items)
    size_trimmed = _items_size([history_items[0], *new_items])
    budget_tokens = _budget_tokens_between(size_trimmed, size_full)

    cfg = AppConfig()
    cfg = replace(
        cfg,
        model=replace(
            cfg.model,
            context_window=budget_tokens,
            max_output_tokens=None,
        ),
        compression=replace(cfg.compression, drop_policy="allow"),
    )
    cfg = _with_gateway_route(cfg)

    packed = asyncio.run(
        pack_history_items(
            cfg=cfg,
            history_items=history_items,
            new_items=new_items,
            model_id="gateway/test/model",
            session=session,
            store=None,
            options=HistoryPackingOptions(
                interactive=False,
                approvals=None,
            ),
        )
    )
    text = _flatten_text(packed)
    assert "memory_snapshot_json:" in text
    assert "old-user-" not in text


def test_pack_history_preserves_compaction_prefix(tmp_path: Path) -> None:
    session = _make_session(tmp_path)
    compaction = _compaction_item("ciphertext")
    history: list[TResponseInputItem] = [
        compaction,
        _user("old-user-" + ("b" * 400)),
        _assistant("old-assistant-" + ("c" * 400)),
    ]
    new_items: list[TResponseInputItem] = [_user("fresh-user-" + ("d" * 40))]
    history_items = _history_from_session(session, items=history)
    size_full = _items_size(history_items + new_items)
    size_trimmed = _items_size([history_items[0], *new_items])
    budget_tokens = _budget_tokens_between(size_trimmed, size_full)

    cfg = AppConfig()
    cfg = replace(
        cfg,
        model=replace(
            cfg.model,
            context_window=budget_tokens,
            max_output_tokens=None,
        ),
        compression=replace(cfg.compression, drop_policy="allow"),
    )
    cfg = _with_gateway_route(cfg)

    packed = asyncio.run(
        pack_history_items(
            cfg=cfg,
            history_items=history_items,
            new_items=new_items,
            model_id="gateway/test/model",
            session=session,
            store=None,
            options=HistoryPackingOptions(
                interactive=False,
                approvals=None,
            ),
        )
    )
    assert any(item.get("type") == "compaction" for item in packed)
    text = _flatten_text(packed)
    assert "fresh-user-" in text
    assert "old-user-" not in text


def test_pack_history_raises_when_oversize() -> None:
    history: list[TResponseInputItem] = []
    new_items: list[TResponseInputItem] = [_user("big-" + ("x" * 2000))]
    size_new = _items_size(new_items)
    budget_tokens = _budget_tokens_between(1, size_new)

    cfg = AppConfig()
    cfg = replace(
        cfg,
        model=replace(
            cfg.model,
            context_window=budget_tokens,
            max_output_tokens=None,
        ),
    )

    with pytest.raises(ConfigError):
        asyncio.run(
            pack_history_items(
                cfg=cfg,
                history_items=history,
                new_items=new_items,
                model_id="gateway/test/model",
                session=None,
                store=None,
                options=HistoryPackingOptions(
                    interactive=False,
                    approvals=None,
                ),
            )
        )
