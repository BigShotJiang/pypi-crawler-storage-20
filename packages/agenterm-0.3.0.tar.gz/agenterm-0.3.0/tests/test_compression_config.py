"""Unit tests for compression config normalization."""

from __future__ import annotations

import pytest

from agenterm.config.compression import CompressionConfig
from agenterm.config.normalize.compression import normalize_compression
from agenterm.core.errors import ConfigError


def test_normalize_compression_allows_nulls() -> None:
    base = CompressionConfig()
    cfg = normalize_compression(
        {
            "strategy": None,
            "trigger": None,
            "threshold_percent": None,
            "primary_branch": None,
            "drop_policy": None,
        },
        base,
    )
    assert cfg.strategy == "snapshot"
    assert cfg.trigger == "ask"
    assert cfg.threshold_percent == 0.5
    assert cfg.primary_branch == "snapshot"
    assert cfg.drop_policy == "deny"


def test_normalize_compression_rejects_invalid_strategy() -> None:
    base = CompressionConfig()
    with pytest.raises(ConfigError, match="compression\\.strategy"):
        normalize_compression({"strategy": "fast"}, base)


def test_normalize_compression_rejects_invalid_threshold() -> None:
    base = CompressionConfig()
    with pytest.raises(ConfigError, match="compression\\.threshold_percent"):
        normalize_compression({"threshold_percent": 1.2}, base)
