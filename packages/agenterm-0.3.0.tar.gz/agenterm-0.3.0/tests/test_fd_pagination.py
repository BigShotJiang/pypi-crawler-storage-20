"""Contract tests for fd tool pagination determinism."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Mapping, Sequence
from pathlib import Path

import pytest
from agents.tool import FunctionTool
from agents.tool_context import ToolContext

import agenterm.engine.cli_tools.fd as fd_tool
from agenterm.config.tools_policy import FdToolConfig
from agenterm.core.cancellation import CancelToken
from agenterm.core.json_codec import as_str_list
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.tool_output_envelope import parse_function_tool_output_envelope


def _tool_context(tmp_path: Path) -> ToolRuntimeContext:
    return ToolRuntimeContext(
        db_path=tmp_path / "store.sqlite3",
        session_id=None,
        branch_id=None,
        run_number=None,
        trace_id=None,
        plan_cache={},
        cancel_token=None,
    )


def _invoke(tool: FunctionTool, *, ctx: ToolContext[ToolRuntimeContext], payload: str) -> str:
    async def _run() -> str:
        value = await tool.on_invoke_tool(ctx, payload)
        assert isinstance(value, str)
        return value

    return asyncio.run(_run())


def test_fd_pagination_is_disjoint_even_when_fd_output_is_unsorted(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Simulate fd emitting results in a non-lexicographic traversal order.
    # This specific order triggers overlap when a pager is implemented as:
    #   max_results = offset + limit
    #   stable = sorted(set(first max_results lines))
    #   return stable[offset:offset+limit]
    #
    # Our contract requires stable, disjoint pages for a stable workspace snapshot.
    unsorted = ["z.py", "y.py", "a.py", "b.py"]

    async def _stub_run_command(
        cmd: Sequence[str],
        *,
        cwd: str,
        env: Mapping[str, str],
        cancel_token: CancelToken | None = None,
    ) -> tuple[int, str, str]:
        cmd_list = list(cmd)
        idx = cmd_list.index("--max-results") + 1
        max_results = int(cmd_list[idx])
        stdout_text = "\n".join(unsorted[:max_results]) + "\n"
        return 0, stdout_text, ""

    monkeypatch.setattr(fd_tool, "run_command", _stub_run_command)

    tool = fd_tool.build_fd_tool(FdToolConfig(), workspace_root=tmp_path)
    assert tool is not None
    tool_context = _tool_context(tmp_path)

    payload_page1 = json.dumps({"offset": 0, "limit": 2}, ensure_ascii=True)
    ctx1 = ToolContext(
        context=tool_context,
        tool_name="fd",
        tool_call_id="call-1",
        tool_arguments=payload_page1,
        tool_call=None,
    )
    out1 = _invoke(tool, ctx=ctx1, payload=payload_page1)
    env1 = parse_function_tool_output_envelope(out1)
    assert env1 is not None and env1.ok is True

    matches1 = as_str_list(env1.payload.get("matches"))
    assert matches1 is not None
    assert matches1 == ["a.py", "b.py"]
    page1 = env1.payload.get("page")
    assert isinstance(page1, dict)
    assert page1.get("has_more") is True
    assert page1.get("next_cursor") == 2
    coverage1 = env1.payload.get("coverage")
    assert isinstance(coverage1, dict)
    assert coverage1.get("complete") is True
    assert coverage1.get("limit_reason") is None

    payload_page2 = json.dumps({"offset": 2, "limit": 2}, ensure_ascii=True)
    ctx2 = ToolContext(
        context=tool_context,
        tool_name="fd",
        tool_call_id="call-2",
        tool_arguments=payload_page2,
        tool_call=None,
    )
    out2 = _invoke(tool, ctx=ctx2, payload=payload_page2)
    env2 = parse_function_tool_output_envelope(out2)
    assert env2 is not None and env2.ok is True

    matches2 = as_str_list(env2.payload.get("matches"))
    assert matches2 is not None
    assert matches2 == ["y.py", "z.py"]
    assert set(matches1).isdisjoint(set(matches2))


def test_fd_scan_cap_does_not_leak_sentinel_entry(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # When there are more than FD_OUTPUT_MAX_ITEMS_MAX matches, the tool requests
    # one extra entry (sentinel) to detect truncation and must *not* leak that
    # extra entry into paged results.
    #
    # This test uses exactly (cap + 1) results.
    paths = [f"{idx:04d}.py" for idx in range(fd_tool.FD_OUTPUT_MAX_ITEMS_MAX + 1)]

    async def _stub_run_command(
        cmd: Sequence[str],
        *,
        cwd: str,
        env: Mapping[str, str],
        cancel_token: CancelToken | None = None,
    ) -> tuple[int, str, str]:
        cmd_list = list(cmd)
        idx = cmd_list.index("--max-results") + 1
        max_results = int(cmd_list[idx])
        stdout_text = "\n".join(paths[:max_results]) + "\n"
        return 0, stdout_text, ""

    monkeypatch.setattr(fd_tool, "run_command", _stub_run_command)

    tool = fd_tool.build_fd_tool(FdToolConfig(), workspace_root=tmp_path)
    assert tool is not None
    tool_context = _tool_context(tmp_path)

    payload_first = json.dumps({"offset": 0, "limit": 1}, ensure_ascii=True)
    ctx1 = ToolContext(
        context=tool_context,
        tool_name="fd",
        tool_call_id="call-1",
        tool_arguments=payload_first,
        tool_call=None,
    )
    out1 = _invoke(tool, ctx=ctx1, payload=payload_first)
    env1 = parse_function_tool_output_envelope(out1)
    assert env1 is not None and env1.ok is True
    coverage1 = env1.payload.get("coverage")
    assert isinstance(coverage1, dict)
    assert coverage1.get("complete") is False
    assert coverage1.get("limit_reason") == "result_cap"

    # Offset at the cap must yield an empty page (the sentinel is not returned).
    payload_beyond = json.dumps(
        {"offset": fd_tool.FD_OUTPUT_MAX_ITEMS_MAX, "limit": 1},
        ensure_ascii=True,
    )
    ctx2 = ToolContext(
        context=tool_context,
        tool_name="fd",
        tool_call_id="call-2",
        tool_arguments=payload_beyond,
        tool_call=None,
    )
    out2 = _invoke(tool, ctx=ctx2, payload=payload_beyond)
    env2 = parse_function_tool_output_envelope(out2)
    assert env2 is not None and env2.ok is True
    assert as_str_list(env2.payload.get("matches")) == []