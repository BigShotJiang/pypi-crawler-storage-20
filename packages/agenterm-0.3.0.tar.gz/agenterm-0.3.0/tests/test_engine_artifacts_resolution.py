from __future__ import annotations

from pathlib import Path

from openai.types.responses.response_input_item_param import ResponseInputItemParam

from agenterm.artifacts.repo import ArtifactRecord, insert_artifact
from agenterm.engine.artifacts import (
    image_artifacts_for_image_generation_calls,
    image_generation_call_ids_from_input_items,
)
import asyncio

from agenterm.store.async_db import AsyncStore
from agenterm.store.schema import ensure_store_schema


def test_image_generation_call_ids_from_input_items_dedup_and_order() -> None:
    items: list[ResponseInputItemParam] = [
        {"type": "function_call_output", "call_id": "call-1", "output": "ok"},
        {
            "type": "image_generation_call",
            "id": "img-1",
            "status": "completed",
            "result": None,
        },
        {
            "type": "image_generation_call",
            "id": "img-2",
            "status": "completed",
            "result": None,
        },
        {
            "type": "image_generation_call",
            "id": "img-1",
            "status": "completed",
            "result": None,
        },
        {
            "type": "image_generation_call",
            "id": "",
            "status": "completed",
            "result": None,
        },
    ]
    assert image_generation_call_ids_from_input_items(items) == ("img-1", "img-2")


def test_image_artifacts_for_image_generation_calls_resolves_records(
    tmp_path: Path,
) -> None:
    db = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db))
    store = AsyncStore(db)

    rec = ArtifactRecord(
        artifact_id="a1",
        kind="image",
        mime="image/png",
        path="/tmp/any.png",
        size_bytes=123,
        content_hash="hash-a1",
        created_at=None,
        source_type="image_generation_call",
        source_id="img-1",
        session_id="sess-1",
    )
    asyncio.run(insert_artifact(store=store, record=rec))

    out = asyncio.run(
        image_artifacts_for_image_generation_calls(
            store=store,
            call_ids=("img-1", "img-2", "img-1"),
        )
    )
    assert len(out) == 1
    got = out[0]
    assert got.artifact_id == rec.artifact_id
    assert got.kind == rec.kind
    assert got.mime == rec.mime
    assert got.path == rec.path
    assert got.size_bytes == rec.size_bytes
    assert got.source_type == rec.source_type
    assert got.source_id == rec.source_id
    assert got.session_id == rec.session_id
    assert isinstance(got.created_at, str) and got.created_at
