"""Contract tests for baseline status detection and save operations."""

from __future__ import annotations

from pathlib import Path

import pytest

from agenterm.config.baseline import (
    BaselineSaveResult,
    BaselineStatus,
    check_baseline_status,
    save_baseline,
)
from agenterm.core.errors import ConfigError


# -- BaselineStatus tests --


def test_baseline_status_both_missing() -> None:
    status = BaselineStatus(config_missing=True, agent_bundled=True)
    assert status.needs_prompt is True


def test_baseline_status_config_only_missing() -> None:
    status = BaselineStatus(config_missing=True, agent_bundled=False)
    assert status.needs_prompt is True


def test_baseline_status_agent_only_bundled() -> None:
    status = BaselineStatus(config_missing=False, agent_bundled=True)
    assert status.needs_prompt is True


def test_baseline_status_neither_missing() -> None:
    status = BaselineStatus(config_missing=False, agent_bundled=False)
    assert status.needs_prompt is False


# -- check_baseline_status tests --


def test_check_baseline_status_detects_missing_config() -> None:
    status = check_baseline_status(config_path=None, agent_source="local")
    assert status.config_missing is True
    assert status.agent_bundled is False


def test_check_baseline_status_detects_bundled_agent() -> None:
    status = check_baseline_status(
        config_path=Path(".agenterm/config.yaml"),
        agent_source="bundled",
    )
    assert status.config_missing is False
    assert status.agent_bundled is True


def test_check_baseline_status_detects_both_missing() -> None:
    status = check_baseline_status(config_path=None, agent_source="bundled")
    assert status.config_missing is True
    assert status.agent_bundled is True
    assert status.needs_prompt is True


def test_check_baseline_status_detects_neither_missing() -> None:
    status = check_baseline_status(
        config_path=Path(".agenterm/config.yaml"),
        agent_source="global",
    )
    assert status.config_missing is False
    assert status.agent_bundled is False
    assert status.needs_prompt is False


# -- save_baseline tests --


def test_save_baseline_writes_both_when_both_missing(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    status = BaselineStatus(config_missing=True, agent_bundled=True)
    result = save_baseline(scope="global", status=status, model="openai/gpt-5.2-pro")

    assert isinstance(result, BaselineSaveResult)
    assert result.config is not None
    assert result.agents is not None
    assert result.saved_any is True

    cfg_path = home / ".agenterm" / "config.yaml"
    default_path = home / ".agenterm" / "agents" / "default.md"
    coding_path = home / ".agenterm" / "agents" / "coding_agent.md"
    assert cfg_path.is_file()
    assert default_path.is_file()
    assert coding_path.is_file()


def test_save_baseline_writes_config_only_when_agents_exist(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    status = BaselineStatus(config_missing=True, agent_bundled=False)
    result = save_baseline(scope="global", status=status, model="openai/gpt-5.2-pro")

    assert result.config is not None
    assert result.agents is None

    cfg_path = home / ".agenterm" / "config.yaml"
    assert cfg_path.is_file()


def test_save_baseline_writes_agents_only_when_config_exists(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    status = BaselineStatus(config_missing=False, agent_bundled=True)
    result = save_baseline(scope="global", status=status, model="openai/gpt-5.2-pro")

    assert result.config is None
    assert result.agents is not None

    default_path = home / ".agenterm" / "agents" / "default.md"
    coding_path = home / ".agenterm" / "agents" / "coding_agent.md"
    assert default_path.is_file()
    assert coding_path.is_file()


def test_save_baseline_local_scope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    status = BaselineStatus(config_missing=True, agent_bundled=True)
    result = save_baseline(scope="local", status=status, model="openai/gpt-5.2-pro")

    assert result.config is not None
    assert result.agents is not None

    cfg_path = tmp_path / ".agenterm" / "config.yaml"
    default_path = tmp_path / ".agenterm" / "agents" / "default.md"
    coding_path = tmp_path / ".agenterm" / "agents" / "coding_agent.md"
    assert cfg_path.is_file()
    assert default_path.is_file()
    assert coding_path.is_file()


def test_save_baseline_global_scope(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    status = BaselineStatus(config_missing=True, agent_bundled=True)
    result = save_baseline(scope="global", status=status, model="openai/gpt-5.2-pro")

    assert result.config is not None
    assert result.agents is not None

    cfg_path = home / ".agenterm" / "config.yaml"
    default_path = home / ".agenterm" / "agents" / "default.md"
    coding_path = home / ".agenterm" / "agents" / "coding_agent.md"
    assert cfg_path.is_file()
    assert default_path.is_file()
    assert coding_path.is_file()


def test_save_baseline_returns_empty_when_nothing_missing(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    status = BaselineStatus(config_missing=False, agent_bundled=False)
    result = save_baseline(scope="global", status=status, model="openai/gpt-5.2-pro")

    assert result.config is None
    assert result.agents is None
    assert result.saved_any is False


def test_save_baseline_raises_on_existing_file(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    cfg_dir = home / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text("existing: config\n", encoding="utf-8")

    status = BaselineStatus(config_missing=True, agent_bundled=False)
    with pytest.raises(ConfigError, match="config"):
        save_baseline(scope="global", status=status, model="openai/gpt-5.2-pro")
