"""Contract tests for schema-derived config template rendering."""

from __future__ import annotations

from agenterm.config.model import AppConfig
from agenterm.config.template import render_config_template, validate_template_docs


def test_template_docs_cover_schema() -> None:
    validate_template_docs()


def test_generated_template_has_core_sections() -> None:
    model = AppConfig().agent.model
    generated = render_config_template(model=model)
    assert "agenterm Configuration (config.yaml)" in generated
    assert "\nagent:" in generated
    assert "\nmodel:" in generated
    assert "\ntools:" in generated
    assert "\nmcp:" in generated
    assert "Sampling parameters" in generated
