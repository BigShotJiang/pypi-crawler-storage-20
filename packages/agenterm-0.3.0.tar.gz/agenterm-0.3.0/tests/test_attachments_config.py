"""Unit tests for attachments config normalization."""

from __future__ import annotations

import pytest

from agenterm.config.attachments import AttachmentsConfig
from agenterm.config.normalize.attachments import normalize_attachments
from agenterm.core.errors import ConfigError


def test_normalize_attachments_accepts_inline_mode_when_enabled() -> None:
    base = AttachmentsConfig()
    cfg = normalize_attachments(
        {
            "image_input_mode": "allow_inline_data_url",
            "allow_inline_data_url": True,
            "max_inline_bytes": 1024,
        },
        base,
    )
    assert cfg.image_input_mode == "allow_inline_data_url"
    assert cfg.allow_inline_data_url is True
    assert cfg.max_inline_bytes == 1024


def test_normalize_attachments_rejects_mismatched_inline_mode() -> None:
    base = AttachmentsConfig()
    with pytest.raises(ConfigError, match="attachments\\.image_input_mode"):
        normalize_attachments(
            {
                "image_input_mode": "allow_inline_data_url",
                "allow_inline_data_url": False,
            },
            base,
        )
