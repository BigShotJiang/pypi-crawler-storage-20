"""Contract tests for background-mode tool filtering."""

from __future__ import annotations

from dataclasses import replace

from agenterm.config.model import (
    AppConfig,
    McpConnectorConfig,
    McpServerConfig,
    McpServerStdioConfig,
)
from agenterm.workflow.shared.tools import build_tools_context


def test_background_mode_strips_client_plane_tools() -> None:
    cfg = AppConfig()

    _tools_ctx, _sel, selected = build_tools_context(
        cfg,
        tool_select=["fn:apply_patch", "hosted:openai:web_search"],
        allow_dangerous=True,
        hosted_mode=True,
    )

    assert selected is not None
    assert [spec.key for spec in selected] == ["hosted:openai:web_search"]


def test_background_mode_drops_hosted_mcp_connector_unless_allow_dangerous() -> None:
    base = AppConfig()
    cfg = replace(
        base,
        mcp=replace(
            base.mcp,
            connectors=[
                McpConnectorConfig(
                    name="my-mcp",
                    server_url="https://mcp.example.com",
                ),
            ],
        ),
    )

    _tools_ctx, _sel, selected = build_tools_context(
        cfg,
        tool_select=["hosted:mcp:my-mcp"],
        allow_dangerous=False,
        hosted_mode=True,
    )

    assert selected is None


def test_background_mode_allows_hosted_mcp_connector_with_allow_dangerous() -> None:
    base = AppConfig()
    cfg = replace(
        base,
        mcp=replace(
            base.mcp,
            connectors=[
                McpConnectorConfig(
                    name="my-mcp",
                    server_url="https://mcp.example.com",
                ),
            ],
        ),
    )

    _tools_ctx, _sel, selected = build_tools_context(
        cfg,
        tool_select=["hosted:mcp:my-mcp"],
        allow_dangerous=True,
        hosted_mode=True,
    )

    assert selected is not None
    assert [spec.key for spec in selected] == ["hosted:mcp:my-mcp"]


def test_background_mode_drops_selected_local_mcp_servers() -> None:
    server = McpServerConfig(
        key="example",
        kind="stdio",
        stdio=McpServerStdioConfig(command="cat"),
    )
    base = AppConfig()
    cfg = replace(base, mcp=replace(base.mcp, servers=[server]))

    _tools_ctx, _sel, selected = build_tools_context(
        cfg,
        tool_select=["mcp:example"],
        allow_dangerous=True,
        hosted_mode=True,
    )

    assert selected is None
