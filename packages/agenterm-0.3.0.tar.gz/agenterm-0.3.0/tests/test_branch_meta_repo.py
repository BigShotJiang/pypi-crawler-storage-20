"""Contract tests for branch metadata repository CRUD."""

from __future__ import annotations

import asyncio
from dataclasses import replace
from pathlib import Path

from agenterm.store.async_db import AsyncStore
from agenterm.store.branch.repo import (
    BranchMetaUpsert,
    delete_branch_meta,
    get_branch_meta,
    list_branch_meta,
    update_branch_agent,
    update_branch_store,
    upsert_branch_meta,
)
from agenterm.store.schema import ensure_store_schema
from agenterm.store.session.repo import SessionMetadataUpsert, upsert_session_metadata


def _payload(
    session_id: str,
    branch_id: str,
    *,
    agent_path: Path | None,
) -> BranchMetaUpsert:
    return BranchMetaUpsert(
        session_id=session_id,
        branch_id=branch_id,
        kind="main",
        title=None,
        pinned=False,
        created_reason=None,
        parent_branch_id=None,
        fork_run_number=None,
        agent_name="default",
        agent_path=agent_path,
        agent_sha256=None,
        store_enabled=True,
        last_response_id=None,
    )


def _seed_session(store: AsyncStore, *, session_id: str, cwd: Path) -> None:
    asyncio.run(
        upsert_session_metadata(
            store=store,
            payload=SessionMetadataUpsert(
                session_id=session_id,
                kind="repl",
                cwd=cwd,
                config_path=None,
                model="openai/gpt-5.2",
                tools_enabled=True,
                trace_id=None,
                group_id=None,
                head_branch_id="main",
            ),
        ),
    )


def test_branch_meta_upsert_and_get_updates_fields(tmp_path: Path) -> None:
    db = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db))
    store = AsyncStore(db)

    _seed_session(store, session_id="sess-1", cwd=tmp_path)
    payload = _payload("sess-1", "main", agent_path=None)
    asyncio.run(upsert_branch_meta(store=store, payload=payload))

    row = asyncio.run(get_branch_meta(store, "sess-1", "main"))
    assert row is not None
    assert row.branch_id == "main"
    assert row.agent_name == "default"
    assert row.store_enabled is True

    updated = replace(
        payload,
        kind="fork",
        pinned=True,
        agent_name="agent-two",
        last_response_id="resp-1",
    )
    asyncio.run(upsert_branch_meta(store=store, payload=updated))
    row = asyncio.run(get_branch_meta(store, "sess-1", "main"))
    assert row is not None
    assert row.kind == "fork"
    assert row.pinned is True
    assert row.agent_name == "agent-two"
    assert row.last_response_id == "resp-1"


def test_branch_meta_list_update_and_delete(tmp_path: Path) -> None:
    db = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db))
    store = AsyncStore(db)

    _seed_session(store, session_id="sess-1", cwd=tmp_path)
    asyncio.run(
        upsert_branch_meta(
            store=store,
            payload=_payload("sess-1", "main", agent_path=None),
        )
    )
    asyncio.run(
        upsert_branch_meta(
            store=store,
            payload=_payload("sess-1", "branch-2", agent_path=None),
        )
    )

    rows = asyncio.run(list_branch_meta(store, "sess-1"))
    ids = {row.branch_id for row in rows}
    assert {"main", "branch-2"}.issubset(ids)

    asyncio.run(
        update_branch_store(
            store=store,
            session_id="sess-1",
            branch_id="main",
            store_enabled=False,
            last_response_id=None,
        )
    )
    row = asyncio.run(get_branch_meta(store, "sess-1", "main"))
    assert row is not None
    assert row.store_enabled is False

    agent_path = tmp_path / "agent.py"
    agent_path.write_text("pass\n", encoding="utf-8")
    asyncio.run(
        update_branch_agent(
            store=store,
            session_id="sess-1",
            branch_id="main",
            agent_name="agent-x",
            agent_path=agent_path,
            agent_sha256="sha-1",
        )
    )
    row = asyncio.run(get_branch_meta(store, "sess-1", "main"))
    assert row is not None
    assert row.agent_name == "agent-x"
    assert row.agent_path == str(agent_path)
    assert row.agent_sha256 == "sha-1"

    assert asyncio.run(delete_branch_meta(store, "sess-1", "branch-2")) is True
    assert asyncio.run(delete_branch_meta(store, "sess-1", "branch-2")) is False
