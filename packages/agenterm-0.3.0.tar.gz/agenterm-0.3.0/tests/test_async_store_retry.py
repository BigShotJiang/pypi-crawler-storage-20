"""Contract tests for AsyncStore retry/backoff behavior."""

from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path

import pytest

from agenterm.core.retry import RetryPolicy
from agenterm.store.async_db import AsyncStore, get_store_retry_policy, set_store_retry_policy


def test_async_store_retries_on_locked_database(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_path = tmp_path / "store.sqlite3"
    store = AsyncStore(db_path)
    attempts = {"count": 0}
    sleep_calls: list[float] = []

    async def _op(_conn: object) -> str:
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise sqlite3.OperationalError("database is locked")
        return "ok"

    async def _sleep(delay: float) -> None:
        sleep_calls.append(delay)

    monkeypatch.setattr("agenterm.core.retry.asyncio.sleep", _sleep)

    previous = get_store_retry_policy()
    set_store_retry_policy(
        RetryPolicy(
            max_retries=1,
            base_backoff_seconds=0.5,
            max_backoff_seconds=0.5,
            jitter_ratio=0.0,
            retry_after_max_seconds=None,
        ),
    )

    try:
        result = asyncio.run(store.run(_op))
        assert result == "ok"
        assert attempts["count"] == 2
        assert sleep_calls == [0.5]
    finally:
        set_store_retry_policy(previous)
