"""Contract tests for artifact repository CRUD helpers."""

from __future__ import annotations

import asyncio
from pathlib import Path

from agenterm.artifacts.repo import (
    ArtifactRecord,
    assign_artifact_session_id_by_source,
    get_artifact_by_id,
    get_artifact_by_source,
    insert_artifact,
    list_artifacts_recent,
)

from agenterm.store.async_db import AsyncStore
from agenterm.store.schema import ensure_store_schema
from agenterm.store.session.repo import SessionMetadataUpsert, upsert_session_metadata


def _record(
    *,
    artifact_id: str,
    source_id: str,
    session_id: str | None,
) -> ArtifactRecord:
    return ArtifactRecord(
        artifact_id=artifact_id,
        kind="image",
        mime="image/png",
        path="/tmp/any.png",
        size_bytes=10,
        content_hash=f"hash-{artifact_id}",
        created_at=None,
        source_type="image_generation_call",
        source_id=source_id,
        session_id=session_id,
    )


def test_artifact_repo_get_and_assign(tmp_path: Path) -> None:
    db = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db))
    store = AsyncStore(db)

    record = _record(artifact_id="a1", source_id="call-1", session_id=None)
    asyncio.run(insert_artifact(store=store, record=record))

    by_id = asyncio.run(get_artifact_by_id(store=store, artifact_id="a1"))
    assert by_id is not None
    assert by_id.artifact_id == "a1"
    assert by_id.session_id is None

    by_source = asyncio.run(
        get_artifact_by_source(
            store=store,
            source_type="image_generation_call",
            source_id="call-1",
        )
    )
    assert by_source is not None
    assert by_source.artifact_id == "a1"

    asyncio.run(
        assign_artifact_session_id_by_source(
            store=store,
            source_type="image_generation_call",
            source_id="call-1",
            session_id="sess-1",
        )
    )
    by_id = asyncio.run(get_artifact_by_id(store=store, artifact_id="a1"))
    assert by_id is not None
    assert by_id.session_id == "sess-1"

    asyncio.run(
        assign_artifact_session_id_by_source(
            store=store,
            source_type="image_generation_call",
            source_id="call-1",
            session_id="sess-2",
        )
    )
    by_id = asyncio.run(get_artifact_by_id(store=store, artifact_id="a1"))
    assert by_id is not None
    assert by_id.session_id == "sess-1"


def test_artifact_repo_list_recent_respects_limit(tmp_path: Path) -> None:
    db = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db))
    store = AsyncStore(db)

    asyncio.run(
        insert_artifact(
            store=store,
            record=_record(artifact_id="a1", source_id="c1", session_id="s1"),
        )
    )
    asyncio.run(
        insert_artifact(
            store=store,
            record=_record(artifact_id="a2", source_id="c2", session_id="s2"),
        )
    )

    recent = asyncio.run(list_artifacts_recent(store=store, limit=1))
    assert len(recent) == 1
    assert recent[0].artifact_id in {"a1", "a2"}


def test_artifact_repo_list_filters_by_session_and_trace(tmp_path: Path) -> None:
    db = tmp_path / "store.sqlite3"
    asyncio.run(ensure_store_schema(db))
    store = AsyncStore(db)

    asyncio.run(
        upsert_session_metadata(
            store=store,
            payload=SessionMetadataUpsert(
                session_id="s1",
                kind="run",
                cwd=tmp_path,
                config_path=None,
                model="openai/gpt-5.2",
                tools_enabled=True,
                trace_id="trace_1",
                group_id=None,
                head_branch_id="main",
            ),
        )
    )
    asyncio.run(
        upsert_session_metadata(
            store=store,
            payload=SessionMetadataUpsert(
                session_id="s2",
                kind="run",
                cwd=tmp_path,
                config_path=None,
                model="openai/gpt-5.2",
                tools_enabled=True,
                trace_id="trace_2",
                group_id=None,
                head_branch_id="main",
            ),
        )
    )
    asyncio.run(
        insert_artifact(
            store=store,
            record=_record(artifact_id="a1", source_id="c1", session_id="s1"),
        )
    )
    asyncio.run(
        insert_artifact(
            store=store,
            record=_record(artifact_id="a2", source_id="c2", session_id="s2"),
        )
    )
    asyncio.run(
        insert_artifact(
            store=store,
            record=_record(artifact_id="a3", source_id="c3", session_id=None),
        )
    )

    by_session = asyncio.run(
        list_artifacts_recent(store=store, limit=10, session_id="s1")
    )
    assert {row.artifact_id for row in by_session} == {"a1"}

    by_trace = asyncio.run(
        list_artifacts_recent(store=store, limit=10, trace_id="trace_2")
    )
    assert {row.artifact_id for row in by_trace} == {"a2"}
