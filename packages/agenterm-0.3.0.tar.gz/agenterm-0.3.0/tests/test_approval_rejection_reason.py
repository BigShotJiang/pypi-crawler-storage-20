"""Contract tests for rejection reasons in tool approvals.

These tests assert that user-provided rejection reasons are forwarded to the
model via tool-shaped refusal outputs (rather than exceptions).
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from agents.editor import ApplyPatchOperation
from agents.run_context import RunContextWrapper
from agents.tool import ShellActionRequest, ShellCallData, ShellCommandRequest

from agenterm.config.model import ShellToolConfig
from agenterm.core.approvals import (
    PatchApprovalItem,
    PatchApprovalManager,
    ShellApprovalItem,
    ShellApprovalManager,
)
from agenterm.engine.apply_patch_editor import WorkspaceEditor
from agenterm.engine.shell_executor import run_shell_sandboxed


def test_apply_patch_rejection_reason_is_returned(tmp_path: Path) -> None:
    root = tmp_path / "ws"
    root.mkdir(parents=True)
    mgr_ref: list[PatchApprovalManager] = []

    def _on_register(item: PatchApprovalItem) -> None:
        mgr_ref[0].resolve(item.id, approved=False, reason="not touching files")

    approvals = PatchApprovalManager(on_register=_on_register)
    mgr_ref.append(approvals)
    editor = WorkspaceEditor(root, approvals)

    op = ApplyPatchOperation(type="create_file", path="hello.txt", diff="+x\n")
    result = asyncio.run(editor.create_file(op))
    assert result is not None
    assert result.status == "failed"
    assert result.output is not None
    assert "Apply patch operation rejected by user." in result.output
    assert "Reason: not touching files" in result.output


def test_shell_rejection_reason_is_returned(tmp_path: Path) -> None:
    mgr_ref: list[ShellApprovalManager] = []

    def _on_register(item: ShellApprovalItem) -> None:
        mgr_ref[0].resolve(item.id, approved=False, reason="unsafe")

    approvals = ShellApprovalManager(on_register=_on_register)
    mgr_ref.append(approvals)
    request = ShellCommandRequest(
        ctx_wrapper=RunContextWrapper(context=None),
        data=ShellCallData(
            call_id="c",
            action=ShellActionRequest(commands=["echo hi"]),
        ),
    )

    async def _run() -> str:
        result = await run_shell_sandboxed(
            request=request,
            tool_cfg=ShellToolConfig(),
            workspace_root=tmp_path,
            approvals=approvals,
            cancel_token=None,
        )
        assert len(result.output) == 1
        return result.output[0].stderr

    stderr = asyncio.run(_run())
    assert "Shell command execution rejected by user." in stderr
    assert "Reason: unsafe" in stderr
