"""Contract tests for image artifact persistence from base64 payloads."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from agenterm.artifacts.image_generation import persist_image_generation_call
from agenterm.store.async_db import AsyncStore

_ONE_BY_ONE_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/5+hHgAFgwJ/"
    "lcC2WQAAAABJRU5ErkJggg=="
)


def test_persist_image_generation_call_accepts_wrapped_base64(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    db_path = tmp_path / "store.sqlite3"
    wrapped = f"{_ONE_BY_ONE_PNG_B64[:40]}\n{_ONE_BY_ONE_PNG_B64[40:]}\n"

    rec = asyncio.run(
        persist_image_generation_call(
            store=AsyncStore(db_path),
            session_id="sess_1",
            call_id="call_1",
            result_b64=wrapped,
        )
    )
    assert rec is not None
    assert rec.mime == "image/png"
    assert Path(rec.path).is_file()


def test_persist_image_generation_call_accepts_data_url_base64(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    db_path = tmp_path / "store.sqlite3"
    data_url = f"data:image/png;base64,{_ONE_BY_ONE_PNG_B64}"

    rec = asyncio.run(
        persist_image_generation_call(
            store=AsyncStore(db_path),
            session_id="sess_1",
            call_id="call_1",
            result_b64=data_url,
        )
    )
    assert rec is not None
    assert rec.mime == "image/png"
    assert Path(rec.path).is_file()


def test_persist_image_generation_call_accepts_urlsafe_no_padding(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    db_path = tmp_path / "store.sqlite3"
    urlsafe = _ONE_BY_ONE_PNG_B64.replace("+", "-").replace("/", "_").rstrip("=")

    rec = asyncio.run(
        persist_image_generation_call(
            store=AsyncStore(db_path),
            session_id="sess_1",
            call_id="call_1",
            result_b64=urlsafe,
        )
    )
    assert rec is not None
    assert rec.mime == "image/png"
    assert Path(rec.path).is_file()
