"""Contract tests for config.yaml loading and save behavior."""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from agenterm.cli import app
from agenterm.config.bootstrap import write_starter_config
from agenterm.config.runtime import load_app_config
from agenterm.core.errors import ConfigError


def test_cli_config_subcommands_are_reachable() -> None:
    runner = CliRunner()
    result = runner.invoke(app, ["config", "--help"])
    assert result.exit_code == 0
    assert "show" in result.output
    assert "path" in result.output
    assert "save" in result.output


def test_write_starter_config_writes_config_only(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    cfg_path = home / ".agenterm" / "config.yaml"
    write_starter_config(cfg_path, model="openai/gpt-5.2-pro", force=False)
    assert cfg_path.is_file()

    cfg = load_app_config(cfg_path)
    assert cfg.agent.model == "openai/gpt-5.2-pro"
    assert cfg.tools.image_generation is not None
    assert cfg.tools.image_generation.model == "gpt-image-1.5"


def test_cli_config_save_global() -> None:
    runner = CliRunner()
    with runner.isolated_filesystem():
        home = Path.cwd() / "home"
        home.mkdir(parents=True, exist_ok=True)

        result = runner.invoke(
            app,
            ["config", "save", "--scope", "global", "--model", "openai/gpt-5.2-pro"],
            env={"HOME": str(home)},
        )
        assert result.exit_code == 0, result.output

        cfg_path = home / ".agenterm" / "config.yaml"
        assert cfg_path.is_file()


def test_cli_config_save_local(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["config", "save", "--scope", "local", "--model", "openai/gpt-5.2-pro"],
    )
    assert result.exit_code == 0, result.output

    cfg_path = tmp_path / ".agenterm" / "config.yaml"
    assert cfg_path.is_file()


def test_config_save_rejects_overwrite_without_force(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    cfg_dir = home / ".agenterm"
    cfg_dir.mkdir()
    cfg_path = cfg_dir / "config.yaml"
    cfg_path.write_text("existing: config\n", encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["config", "save", "--scope", "global", "--model", "openai/gpt-5.2-pro"],
        env={"HOME": str(home)},
    )
    assert result.exit_code != 0
    assert "exists" in result.output.lower() or "error" in result.output.lower()


def test_config_save_allows_overwrite_with_force(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    home = tmp_path / "home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("HOME", str(home))

    cfg_dir = home / ".agenterm"
    cfg_dir.mkdir()
    cfg_path = cfg_dir / "config.yaml"
    cfg_path.write_text("existing: config\n", encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(
        app,
        ["config", "save", "--scope", "global", "--model", "openai/gpt-5.2-pro", "--force"],
        env={"HOME": str(home)},
    )
    assert result.exit_code == 0, result.output
    assert cfg_path.is_file()
    content = cfg_path.read_text(encoding="utf-8")
    assert "existing: config" not in content


def test_config_loader_rejects_unknown_top_level_sections(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text("unknown_section: {}\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        load_app_config(None)


def test_model_defaults_preserved_when_model_section_partial(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "model:\n  verbosity: low\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.model.verbosity == "low"
    assert cfg.model.temperature == 1.0
    assert cfg.model.max_output_tokens == 32000


def test_tools_defaults_preserved_when_tools_section_partial(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "tools:\n  default_bundles: [edit]\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.tools.file_search is not None
    assert cfg.tools.web_search is not None
    assert cfg.tools.shell is not None
    assert cfg.tools.apply_patch is not None
    assert cfg.tools.update_plan is not None
    assert cfg.tools.get_plan is not None
    assert cfg.tools.rg is not None
    assert cfg.tools.fd is not None
    assert cfg.tools.bat is not None
    assert cfg.tools.tree is not None
    assert cfg.tools.stat is not None
    assert cfg.tools.agent_run is not None
    assert cfg.tools.agent_run_report is not None
    assert cfg.tools.image_generation is not None
    assert cfg.tools.image_generation.model == "gpt-image-1.5"
    assert "inspect" in cfg.tools.bundles
    assert "handoff" in cfg.tools.bundles


def test_mcp_convert_schemas_to_strict_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "mcp:\n  convert_schemas_to_strict: true\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.mcp.convert_schemas_to_strict is True


def test_mcp_expose_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "mcp:\n"
        "  expose:\n"
        "    enabled: true\n"
        "    transport: stdio\n"
        "    host: 127.0.0.1\n"
        "    port: 8123\n"
        "    allow_dangerous: true\n"
        "    bundles: [inspect]\n"
        "    tools: [\"fn:update_plan\"]\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    expose = cfg.mcp.expose
    assert expose.enabled is True
    assert expose.transport == "stdio"
    assert expose.host == "127.0.0.1"
    assert expose.port == 8123
    assert expose.allow_dangerous is True
    assert expose.bundles == ["inspect"]
    assert expose.tools == ["fn:update_plan"]


def test_mcp_expose_port_rejects_out_of_range(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "mcp:\n"
        "  expose:\n"
        "    enabled: true\n"
        "    port: 70000\n",
        encoding="utf-8",
    )

    with pytest.raises(ConfigError, match="mcp\\.expose\\.port"):
        load_app_config(None)


def test_mcp_expose_tools_rejects_unknown_key(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "mcp:\n"
        "  expose:\n"
        "    enabled: true\n"
        "    tools: [\"fn:does_not_exist\"]\n",
        encoding="utf-8",
    )

    with pytest.raises(ConfigError, match="mcp\\.expose\\.tools"):
        load_app_config(None)


def test_tools_dangerous_overrides_are_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "tools:\n"
        "  dangerous:\n"
        "    add: [\"hosted:openai:web_search\"]\n"
        "    remove: [\"fn:apply_patch\"]\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.tools.dangerous.add == ["hosted:openai:web_search"]
    assert cfg.tools.dangerous.remove == ["fn:apply_patch"]


def test_repl_ux_verbosity_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "repl:\n  ux:\n    verbosity: debug\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.repl.ux.verbosity == "debug"


def test_repl_ux_verbosity_rejects_invalid_value(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "repl:\n  ux:\n    verbosity: loud\n",
        encoding="utf-8",
    )

    with pytest.raises(ConfigError, match="repl\\.ux\\.verbosity"):
        load_app_config(None)


def test_repl_ux_stream_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "repl:\n  ux:\n    stream: live\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.repl.ux.stream == "live"


def test_repl_ux_stream_rejects_invalid_value(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "repl:\n  ux:\n    stream: turbo\n",
        encoding="utf-8",
    )

    with pytest.raises(ConfigError, match="repl\\.ux\\.stream"):
        load_app_config(None)


def test_repl_ui_color_depth_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "repl:\n  ui:\n    color_depth: truecolor\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.repl.ui.color_depth == "truecolor"


def test_repl_ui_editing_mode_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "repl:\n  ui:\n    editing_mode: vi\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.repl.ui.editing_mode == "vi"


def test_model_context_window_is_loadable(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "model:\n  context_window: 200000\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.model.context_window == 200000


def test_model_reasoning_effort_accepts_xhigh(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    cfg_dir = tmp_path / ".agenterm"
    cfg_dir.mkdir()
    (cfg_dir / "config.yaml").write_text(
        "model:\n  reasoning:\n    effort: xhigh\n",
        encoding="utf-8",
    )

    cfg = load_app_config(None)
    assert cfg.model.reasoning is not None
    assert cfg.model.reasoning.effort == "xhigh"
