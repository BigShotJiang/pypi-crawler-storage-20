"""Unit tests for core/reasoning.py."""

from __future__ import annotations

from unittest.mock import MagicMock

from agents.items import ReasoningItem
from openai.types.responses.response_reasoning_item import (
    Content,
    ResponseReasoningItem,
    Summary,
)

from agenterm.core.reasoning import (
    extract_reasoning_data,
    extract_reasoning_for_compressor,
    extract_reasoning_for_display,
    filter_reasoning_for_model,
    filter_reasoning_for_steward,
    has_real_thinking,
)


def _make_reasoning_item(
    *,
    summary_texts: list[str] | None = None,
    content_texts: list[str] | None = None,
    encrypted_content: str | None = None,
) -> ReasoningItem:
    """Create a ReasoningItem with specified fields."""
    summary_parts: list[Summary] = []
    if summary_texts:
        for text in summary_texts:
            summary_parts.append(Summary(text=text, type="summary_text"))

    content_parts: list[Content] | None = None
    if content_texts:
        content_parts = [Content(text=t, type="reasoning_text") for t in content_texts]

    raw = ResponseReasoningItem(
        id="reasoning_001",
        type="reasoning",
        summary=summary_parts,
        content=content_parts,
        encrypted_content=encrypted_content,
    )
    # ReasoningItem requires an agent field; use a mock
    mock_agent = MagicMock()
    return ReasoningItem(agent=mock_agent, raw_item=raw)


# -----------------------------------------------------------------------------
# extract_reasoning_data tests
# -----------------------------------------------------------------------------


def test_extract_reasoning_data_summary_only() -> None:
    """DeepSeek case: summary only, has_real_thinking=False."""
    item = _make_reasoning_item(summary_texts=["This is summary reasoning."])
    data = extract_reasoning_data(item)

    assert data.summary_text == "This is summary reasoning."
    assert data.content_text is None
    assert data.encrypted_content is None
    assert data.has_real_thinking is False


def test_extract_reasoning_data_full() -> None:
    """Anthropic case: summary + content + encrypted, has_real_thinking=True."""
    item = _make_reasoning_item(
        summary_texts=["Summary part."],
        content_texts=["Full thinking content."],
        encrypted_content="encrypted_token_abc123",
    )
    data = extract_reasoning_data(item)

    assert data.summary_text == "Summary part."
    assert data.content_text == "Full thinking content."
    assert data.encrypted_content == "encrypted_token_abc123"
    assert data.has_real_thinking is True


def test_extract_reasoning_data_content_only() -> None:
    """Content without encrypted, has_real_thinking=True."""
    item = _make_reasoning_item(
        summary_texts=["Summary."],
        content_texts=["The full thinking."],
    )
    data = extract_reasoning_data(item)

    assert data.content_text == "The full thinking."
    assert data.has_real_thinking is True


def test_extract_reasoning_data_encrypted_only() -> None:
    """Encrypted without content text, has_real_thinking=True."""
    item = _make_reasoning_item(
        summary_texts=["Summary."],
        encrypted_content="opaque_token",
    )
    data = extract_reasoning_data(item)

    assert data.content_text is None
    assert data.encrypted_content == "opaque_token"
    assert data.has_real_thinking is True


def test_extract_reasoning_data_empty_summary() -> None:
    """Empty summary list returns None for summary_text."""
    item = _make_reasoning_item(summary_texts=[])
    data = extract_reasoning_data(item)

    assert data.summary_text is None
    assert data.has_real_thinking is False


def test_extract_reasoning_data_multipart_content() -> None:
    """Multiple content parts are joined with newlines."""
    item = _make_reasoning_item(
        summary_texts=["Sum."],
        content_texts=["Part one.", "Part two.", "Part three."],
    )
    data = extract_reasoning_data(item)

    assert data.content_text == "Part one.\nPart two.\nPart three."


# -----------------------------------------------------------------------------
# extract_reasoning_for_display tests
# -----------------------------------------------------------------------------


def test_extract_for_display_prefers_content() -> None:
    """Display returns content when available."""
    item = _make_reasoning_item(
        summary_texts=["Summary."],
        content_texts=["Full content."],
    )
    text = extract_reasoning_for_display(item)
    assert text == "Full content."


def test_extract_for_display_falls_back_to_summary() -> None:
    """Display returns summary when no content."""
    item = _make_reasoning_item(summary_texts=["Only summary."])
    text = extract_reasoning_for_display(item)
    assert text == "Only summary."


def test_extract_for_display_none_when_empty() -> None:
    """Display returns None when both are empty."""
    item = _make_reasoning_item(summary_texts=[])
    text = extract_reasoning_for_display(item)
    assert text is None


# -----------------------------------------------------------------------------
# extract_reasoning_for_compressor tests
# -----------------------------------------------------------------------------


def test_extract_for_compressor_same_as_display() -> None:
    """Compressor uses same logic as display."""
    item = _make_reasoning_item(
        summary_texts=["Sum."],
        content_texts=["Content."],
    )
    assert extract_reasoning_for_compressor(item) == extract_reasoning_for_display(item)


# -----------------------------------------------------------------------------
# has_real_thinking tests
# -----------------------------------------------------------------------------


def test_has_real_thinking_true_when_content() -> None:
    """has_real_thinking=True when content exists."""
    item = _make_reasoning_item(
        summary_texts=["Sum."],
        content_texts=["Real thinking."],
    )
    assert has_real_thinking(item) is True


def test_has_real_thinking_true_when_encrypted() -> None:
    """has_real_thinking=True when encrypted exists."""
    item = _make_reasoning_item(
        summary_texts=["Sum."],
        encrypted_content="token",
    )
    assert has_real_thinking(item) is True


def test_has_real_thinking_false_when_summary_only() -> None:
    """has_real_thinking=False for DeepSeek-style items."""
    item = _make_reasoning_item(summary_texts=["Summary only."])
    assert has_real_thinking(item) is False


# -----------------------------------------------------------------------------
# filter_reasoning_for_model tests
# -----------------------------------------------------------------------------


def test_filter_for_model_strips_summary_when_content_exists() -> None:
    """Model continuation strips redundant summaries."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {
            "type": "reasoning",
            "id": "r1",
            "summary": [{"type": "summary_text", "text": "Redundant."}],
            "content": [{"type": "reasoning_text", "text": "Full."}],
        },
    ]
    filtered = filter_reasoning_for_model(items)  # type: ignore[arg-type]

    assert len(filtered) == 1
    # Serialize back to dict for comparison
    r = serialize_input_item(filtered[0], context="test")
    assert r.get("summary") == []  # Empty, not absent
    assert r.get("content") == [{"type": "reasoning_text", "text": "Full."}]


def test_filter_for_model_strips_summary_when_encrypted_exists() -> None:
    """Model continuation strips summary when encrypted exists."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {
            "type": "reasoning",
            "id": "r1",
            "summary": [{"type": "summary_text", "text": "Redundant."}],
            "encrypted_content": "token123",
        },
    ]
    filtered = filter_reasoning_for_model(items)  # type: ignore[arg-type]

    r = serialize_input_item(filtered[0], context="test")
    assert r.get("summary") == []
    assert r.get("encrypted_content") == "token123"


def test_filter_for_model_preserves_summary_only_items() -> None:
    """DeepSeek items preserved (summary IS the reasoning)."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {
            "type": "reasoning",
            "id": "r1",
            "summary": [{"type": "summary_text", "text": "DeepSeek reasoning."}],
        },
    ]
    filtered = filter_reasoning_for_model(items)  # type: ignore[arg-type]

    # Serialize and compare
    r = serialize_input_item(filtered[0], context="test")
    assert r.get("type") == "reasoning"
    assert r.get("id") == "r1"
    assert r.get("summary") == [{"type": "summary_text", "text": "DeepSeek reasoning."}]


def test_filter_for_model_passes_non_reasoning_items() -> None:
    """Non-reasoning items pass through unchanged."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {"type": "message", "role": "user", "content": "Hello"},
    ]
    filtered = filter_reasoning_for_model(items)  # type: ignore[arg-type]

    r = serialize_input_item(filtered[0], context="test")
    assert r.get("type") == "message"
    assert r.get("role") == "user"


# -----------------------------------------------------------------------------
# filter_reasoning_for_steward tests
# -----------------------------------------------------------------------------


def test_filter_for_steward_converts_reasoning_to_message() -> None:
    """Reasoning items converted to user messages with thinking text."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {
            "type": "reasoning",
            "id": "rs_69639ca4a00c8190912a1e32e033bd95",
            "summary": [{"type": "summary_text", "text": "Sum."}],
            "content": [{"type": "reasoning_text", "text": "Full thinking."}],
            "encrypted_content": "secret_token",
        },
    ]
    filtered = filter_reasoning_for_steward(items)  # type: ignore[arg-type]

    r = serialize_input_item(filtered[0], context="test")
    assert r.get("type") == "message"
    assert r.get("role") == "user"
    content = r.get("content")
    assert isinstance(content, list) and len(content) == 1
    first = content[0]
    assert isinstance(first, dict)
    assert first.get("text") == "[assistant thinking]\nFull thinking."


def test_filter_for_steward_prefers_content_over_summary() -> None:
    """Conversion uses content when available, else summary."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {
            "type": "reasoning",
            "id": "r1",
            "summary": [{"type": "summary_text", "text": "Summary only."}],
        },
    ]
    filtered = filter_reasoning_for_steward(items)  # type: ignore[arg-type]

    r = serialize_input_item(filtered[0], context="test")
    assert r.get("type") == "message"
    content = r.get("content")
    assert isinstance(content, list) and len(content) == 1
    first = content[0]
    assert isinstance(first, dict)
    assert first.get("text") == "[assistant thinking]\nSummary only."


def test_filter_for_steward_skips_empty_reasoning() -> None:
    """Empty reasoning items are dropped."""
    items: list[dict[str, object]] = [
        {
            "type": "reasoning",
            "id": "r1",
            "summary": [],
        },
    ]
    filtered = filter_reasoning_for_steward(items)  # type: ignore[arg-type]
    assert len(filtered) == 0


def test_filter_for_steward_passes_non_reasoning_items() -> None:
    """Non-reasoning items pass through unchanged."""
    from agenterm.core.response_items import serialize_input_item

    items: list[dict[str, object]] = [
        {"type": "message", "role": "assistant", "content": "Response"},
    ]
    filtered = filter_reasoning_for_steward(items)  # type: ignore[arg-type]

    r = serialize_input_item(filtered[0], context="test")
    assert r.get("type") == "message"
    assert r.get("role") == "assistant"
