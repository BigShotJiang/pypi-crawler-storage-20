"""Regression test for compaction model normalization."""

from __future__ import annotations

import asyncio
from dataclasses import replace

import pytest

from agents.items import TResponseInputItem
from openai.types.responses.compacted_response import CompactedResponse

from agenterm.core.json_types import JSONValue
from agenterm.core.response_items import parse_input_item
from agenterm.core.token_usage import TokenUsage
from agenterm.engine import compaction as compaction_module
from agenterm.config.model import AppConfig, GatewayProviderConfig, GatewayRouteConfig


def _user_message(text: str) -> TResponseInputItem:
    payload: dict[str, JSONValue] = {
        "type": "message",
        "role": "user",
        "content": [{"type": "input_text", "text": text}],
    }
    return parse_input_item(payload, context="test.compaction.input")


def _snapshot_items(_resp: CompactedResponse) -> list[TResponseInputItem]:
    return []


def _usage(_resp: CompactedResponse) -> TokenUsage | None:
    return None


def test_compact_strips_openai_prefix(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, str] = {}

    class _DummyResponses:
        async def compact(
            self,
            *,
            model: str,
            input: list[dict[str, JSONValue]],
            instructions: str | None,
        ) -> object:
            captured["model"] = model
            return type("_Resp", (), {"id": "resp_compact"})()

    class _DummyClient:
        responses = _DummyResponses()

    def _dummy_openai_client() -> _DummyClient:
        return _DummyClient()

    monkeypatch.setattr(compaction_module, "get_openai_client", _dummy_openai_client)
    monkeypatch.setattr(
        compaction_module,
        "snapshot_items_from_compacted_response",
        _snapshot_items,
    )
    monkeypatch.setattr(compaction_module, "usage_from_compacted_response", _usage)

    asyncio.run(
        compaction_module.compact(
            input_items=[_user_message("hi")],
            cfg=AppConfig(),
            model_id="openai/gpt-5.2",
            instructions=None,
        )
    )

    assert captured["model"] == "gpt-5.2"


def test_compact_normalizes_gateway_route_model(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, str] = {}

    class _DummyResponses:
        async def compact(
            self,
            *,
            model: str,
            input: list[dict[str, JSONValue]],
            instructions: str | None,
        ) -> object:
            captured["model"] = model
            return type("_Resp", (), {"id": "resp_compact"})()

    class _DummyClient:
        responses = _DummyResponses()

    def _dummy_gateway_client(
        *,
        route: str,
        route_cfg: GatewayRouteConfig,
    ) -> _DummyClient:
        return _DummyClient()

    monkeypatch.setattr(compaction_module, "get_gateway_client", _dummy_gateway_client)
    monkeypatch.setattr(
        compaction_module,
        "snapshot_items_from_compacted_response",
        _snapshot_items,
    )
    monkeypatch.setattr(compaction_module, "usage_from_compacted_response", _usage)

    cfg = replace(
        AppConfig(),
        providers=replace(
            AppConfig().providers,
            gateway=GatewayProviderConfig(
                routes={
                    "route": GatewayRouteConfig(
                        provider="openrouter",
                        base_url=None,
                        api_key_env=None,
                        headers=None,
                        model_allowlist=(),
                        allow_any_model=True,
                        supports_compaction=True,
                        supports_file_id=False,
                        supports_image_url=False,
                        allow_inline_data_url=False,
                    )
                }
            ),
        ),
    )

    asyncio.run(
        compaction_module.compact(
            input_items=[_user_message("hi")],
            cfg=cfg,
            model_id="gateway/route/model",
            instructions=None,
        )
    )

    assert captured["model"] == "openrouter/model"
