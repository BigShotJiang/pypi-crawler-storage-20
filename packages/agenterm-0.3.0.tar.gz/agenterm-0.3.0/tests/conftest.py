"""Shared pytest fixtures for store lifecycle cleanup."""

from __future__ import annotations

import asyncio
from collections.abc import Iterator

import pytest

from agenterm.store.async_db import close_store_registry


@pytest.fixture(autouse=True)
def close_store_registry_fixture() -> Iterator[None]:
    yield
    asyncio.run(close_store_registry())


__all__ = ("close_store_registry_fixture",)
