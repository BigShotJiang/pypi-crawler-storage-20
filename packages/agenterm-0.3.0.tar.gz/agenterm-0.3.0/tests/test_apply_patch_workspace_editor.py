"""Contract tests for apply_patch workspace confinement."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from agents.editor import ApplyPatchOperation

from agenterm.core.approvals import PatchApprovalItem, PatchApprovalManager
from agenterm.core.errors import ToolExecutionError
from agenterm.engine.apply_patch_editor import WorkspaceEditor


def _auto_approve_all() -> PatchApprovalManager:
    mgr_ref: list[PatchApprovalManager] = []

    def _on_register(item: PatchApprovalItem) -> None:
        mgr_ref[0].resolve(item.id, approved=True)

    mgr = PatchApprovalManager(on_register=_on_register)
    mgr_ref.append(mgr)
    return mgr


def test_create_file_writes_within_workspace(tmp_path: Path) -> None:
    root = tmp_path / "ws"
    root.mkdir(parents=True)
    approvals = _auto_approve_all()
    editor = WorkspaceEditor(root, approvals)

    op = ApplyPatchOperation(
        type="create_file",
        path="hello.txt",
        diff="+hello\n+world\n",
    )

    result = asyncio.run(editor.create_file(op))
    assert result is not None
    assert (root / "hello.txt").read_text(encoding="utf-8") == "hello\nworld"


def test_rejects_path_escape(tmp_path: Path) -> None:
    root = tmp_path / "ws"
    root.mkdir(parents=True)
    approvals = _auto_approve_all()
    editor = WorkspaceEditor(root, approvals)

    op = ApplyPatchOperation(type="create_file", path="../escape.txt", diff="+x\n")
    with pytest.raises(ToolExecutionError, match="Operation outside workspace"):
        asyncio.run(editor.create_file(op))


def test_rejects_symlink_escape(tmp_path: Path) -> None:
    root = tmp_path / "ws"
    root.mkdir(parents=True)
    outside = tmp_path / "outside.txt"
    outside.write_text("outside", encoding="utf-8")

    link = root / "link.txt"
    link.symlink_to(outside)

    approvals = _auto_approve_all()
    editor = WorkspaceEditor(root, approvals)

    op = ApplyPatchOperation(type="update_file", path="link.txt", diff="@@\n-outside\n+oops\n")
    with pytest.raises(ToolExecutionError, match="Operation outside workspace"):
        asyncio.run(editor.update_file(op))


def test_create_file_output_is_simple(tmp_path: Path) -> None:
    root = tmp_path / "ws"
    root.mkdir(parents=True)
    approvals = _auto_approve_all()
    editor = WorkspaceEditor(root, approvals)

    op = ApplyPatchOperation(
        type="create_file",
        path="hello.txt",
        diff="+hello\n+world\n",
    )

    result = asyncio.run(editor.create_file(op))
    assert result is not None
    assert result.output is not None
    assert result.output == "Created hello.txt"


def test_update_file_invalid_diff_returns_failed_result(tmp_path: Path) -> None:
    root = tmp_path / "ws"
    root.mkdir(parents=True)
    target = root / "note.txt"
    target.write_text("line one\nline two\n", encoding="utf-8")
    approvals = _auto_approve_all()
    editor = WorkspaceEditor(root, approvals)

    op = ApplyPatchOperation(
        type="update_file",
        path="note.txt",
        diff="@@\n-line two!\n+line two?\n",
    )

    result = asyncio.run(editor.update_file(op))
    assert result is not None
    assert result.status == "failed"
    assert result.output is not None
    assert "Invalid Context" in result.output
    assert target.read_text(encoding="utf-8") == "line one\nline two\n"
