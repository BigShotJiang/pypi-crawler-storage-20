"""Contract tests for compaction snapshot replay items."""

from __future__ import annotations

from typing import TypeGuard

import pytest
from agents.items import TResponseInputItem
from openai.types.responses.compacted_response import CompactedResponse
from openai.types.responses.response_compaction_item import ResponseCompactionItem
from openai.types.responses.response_compaction_item_param_param import (
    ResponseCompactionItemParamParam,
)
from openai.types.responses.response_input_item_param import Message as InputMessageParam
from openai.types.responses.response_output_message import ResponseOutputMessage
from openai.types.responses.response_output_message_param import ResponseOutputMessageParam
from openai.types.responses.response_output_refusal import ResponseOutputRefusal
from openai.types.responses.response_output_text import AnnotationURLCitation, ResponseOutputText
from openai.types.responses.response_usage import (
    InputTokensDetails,
    OutputTokensDetails,
    ResponseUsage,
)

from agenterm.core.errors import AgentermError
from agenterm.engine.compaction import snapshot_items_from_compacted_response


def _is_output_message_param(item: TResponseInputItem) -> TypeGuard[ResponseOutputMessageParam]:
    if item.get("type") != "message":
        return False
    if item.get("role") != "assistant":
        return False
    if not isinstance(item.get("id"), str):
        return False
    content = item.get("content")
    if not isinstance(content, (list, tuple)):
        return False
    status = item.get("status")
    if status not in {"in_progress", "completed", "incomplete"}:
        return False
    return True


def _is_compaction_param(item: TResponseInputItem) -> TypeGuard[ResponseCompactionItemParamParam]:
    if item.get("type") != "compaction":
        return False
    return isinstance(item.get("encrypted_content"), str)


def _is_input_message_param(item: TResponseInputItem) -> TypeGuard[InputMessageParam]:
    if item.get("type") != "message":
        return False
    role = item.get("role")
    if role not in {"user", "system", "developer"}:
        return False
    content = item.get("content")
    return isinstance(content, (list, tuple))


def _usage() -> ResponseUsage:
    return ResponseUsage(
        input_tokens=1,
        input_tokens_details=InputTokensDetails(cached_tokens=0),
        output_tokens=1,
        output_tokens_details=OutputTokensDetails(reasoning_tokens=0),
        total_tokens=2,
    )


def test_snapshot_items_encode_assistant_messages_as_output_message_params() -> None:
    output_message = ResponseOutputMessage(
        id="msg_1",
        type="message",
        role="assistant",
        status="completed",
        content=[
            ResponseOutputText(
                type="output_text",
                text="hello",
                annotations=[],
            ),
        ],
    )
    compaction_item = ResponseCompactionItem(
        id="cmp_1",
        type="compaction",
        encrypted_content="ENC",
    )
    resp = CompactedResponse(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[output_message, compaction_item],
        usage=_usage(),
    )

    items = snapshot_items_from_compacted_response(resp)
    assert len(items) == 2

    assistant_msg = items[0]
    assert _is_output_message_param(assistant_msg)
    assert assistant_msg["type"] == "message"
    assert assistant_msg["role"] == "assistant"

    content0 = list(assistant_msg["content"])[0]
    if content0["type"] != "output_text":
        raise AssertionError("Expected output_text content")
    assert content0["annotations"] == []

    compaction = items[-1]
    assert _is_compaction_param(compaction)
    assert compaction["type"] == "compaction"
    assert compaction["encrypted_content"] == "ENC"


def test_snapshot_items_preserve_refusals_as_refusal_content() -> None:
    output_message = ResponseOutputMessage(
        id="msg_1",
        type="message",
        role="assistant",
        status="completed",
        content=[
            ResponseOutputRefusal(
                type="refusal",
                refusal="no",
            ),
        ],
    )
    compaction_item = ResponseCompactionItem(
        id="cmp_1",
        type="compaction",
        encrypted_content="ENC",
    )
    resp = CompactedResponse(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[output_message, compaction_item],
        usage=_usage(),
    )

    items = snapshot_items_from_compacted_response(resp)
    first = items[0]
    assert _is_output_message_param(first)
    content0 = list(first["content"])[0]
    if content0["type"] != "refusal":
        raise AssertionError("Expected refusal content")
    assert content0["refusal"] == "no"


def test_snapshot_items_convert_output_text_annotations() -> None:
    citation = AnnotationURLCitation(
        type="url_citation",
        start_index=0,
        end_index=5,
        title="Example",
        url="https://example.com",
    )
    output_message = ResponseOutputMessage(
        id="msg_1",
        type="message",
        role="assistant",
        status="completed",
        content=[
            ResponseOutputText(
                type="output_text",
                text="hello",
                annotations=[citation],
            ),
        ],
    )
    compaction_item = ResponseCompactionItem(
        id="cmp_1",
        type="compaction",
        encrypted_content="ENC",
    )
    resp = CompactedResponse(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[output_message, compaction_item],
        usage=_usage(),
    )

    items = snapshot_items_from_compacted_response(resp)
    first = items[0]
    assert _is_output_message_param(first)
    content0 = list(first["content"])[0]
    if content0["type"] != "output_text":
        raise AssertionError("Expected output_text content")
    anns = list(content0["annotations"])
    assert len(anns) == 1
    if anns[0]["type"] != "url_citation":
        raise AssertionError("Expected url_citation annotation")
    assert anns[0]["url"] == "https://example.com"


def test_snapshot_items_convert_user_message_input_text_parts() -> None:
    # Compaction can return "message" items that represent user messages, but the
    # SDK parses them as ResponseOutputMessage/ResponseOutputText due to loose
    # construction and union fallback (see ARCH 1.9.4).
    input_text = ResponseOutputText.construct(type="input_text", text="hello")
    user_message = ResponseOutputMessage.construct(
        id="msg_user",
        type="message",
        role="user",
        status="completed",
        content=[input_text],
    )
    compaction_item = ResponseCompactionItem(
        id="cmp_1",
        type="compaction",
        encrypted_content="ENC",
    )
    resp = CompactedResponse.construct(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[user_message, compaction_item],
        usage=_usage(),
    )

    items = snapshot_items_from_compacted_response(resp)
    assert len(items) == 2

    first = items[0]
    assert _is_input_message_param(first)
    assert first["role"] == "user"
    content0 = first["content"][0]
    if content0["type"] != "input_text":
        raise AssertionError("Expected input_text content")
    assert content0["text"] == "hello"


def test_snapshot_items_tolerate_missing_output_text_annotations() -> None:
    output_message = ResponseOutputMessage.construct(
        id="msg_1",
        type="message",
        role="assistant",
        status="completed",
        content=[ResponseOutputText.construct(type="output_text", text="hello")],
    )
    compaction_item = ResponseCompactionItem(
        id="cmp_1",
        type="compaction",
        encrypted_content="ENC",
    )
    resp = CompactedResponse(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[output_message, compaction_item],
        usage=_usage(),
    )

    items = snapshot_items_from_compacted_response(resp)
    first = items[0]
    assert _is_output_message_param(first)
    content0 = list(first["content"])[0]
    if content0["type"] != "output_text":
        raise AssertionError("Expected output_text content")
    assert content0["annotations"] == []


def test_snapshot_items_coerce_assistant_input_text_to_output_text() -> None:
    output_message = ResponseOutputMessage.construct(
        id="msg_1",
        type="message",
        role="assistant",
        status="completed",
        content=[ResponseOutputText.construct(type="input_text", text="hello")],
    )
    compaction_item = ResponseCompactionItem(
        id="cmp_1",
        type="compaction",
        encrypted_content="ENC",
    )
    resp = CompactedResponse(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[output_message, compaction_item],
        usage=_usage(),
    )

    items = snapshot_items_from_compacted_response(resp)
    first = items[0]
    assert _is_output_message_param(first)
    content0 = list(first["content"])[0]
    if content0["type"] != "output_text":
        raise AssertionError("Expected output_text content")
    assert content0["text"] == "hello"


def test_snapshot_items_require_compaction_item() -> None:
    output_message = ResponseOutputMessage(
        id="msg_1",
        type="message",
        role="assistant",
        status="completed",
        content=[
            ResponseOutputText(
                type="output_text",
                text="hello",
                annotations=[],
            ),
        ],
    )
    resp = CompactedResponse(
        id="resp_compact",
        created_at=0,
        object="response.compaction",
        output=[output_message],
        usage=_usage(),
    )
    with pytest.raises(AgentermError, match="compaction item"):
        snapshot_items_from_compacted_response(resp)
