"""
TurboVision Package
"""

from .main import Turbo

__version__ = "0.1.7"
__all__ = ["Turbo"]

