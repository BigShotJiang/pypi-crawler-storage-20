"""SkillForge test suite."""
