"""
Bloxchaser Python SDK - Main Client

Usage:
    # Async (recommended)
    async with Bloxchaser("bc_live_xxx") as client:
        swaps = await client.swaps.get(chain="solana", limit=100)
        tokens = await client.tokens.list(limit=10)
        health = await client.health()

    # Sync
    with BloxchaserSync("bc_live_xxx") as client:
        swaps = client.swaps.get(chain="solana", limit=100)
        tokens = client.tokens.list(limit=10)
        health = client.health()
"""

from typing import Optional
from bloxchaser._http import HTTPClient, DEFAULT_BASE_URL, DEFAULT_TIMEOUT
from bloxchaser.endpoints.swaps import SwapsEndpoint
from bloxchaser.endpoints.tokens import TokensEndpoint
from bloxchaser.endpoints.quotes import QuotesEndpoint
from bloxchaser.models.stats import HealthResponse, UsageResponse


class Bloxchaser:
    """Async Bloxchaser client (recommended)."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
    ):
        """
        Initialize Bloxchaser client.

        Args:
            api_key: Your Bloxchaser API key (bc_live_...)
            base_url: API base URL (default: https://api.bloxchaser.com)
            timeout: Request timeout in seconds
            max_retries: Max retry attempts for failed requests
        """
        self._http = HTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        # Endpoint namespaces
        self.swaps = SwapsEndpoint(self._http)
        self.tokens = TokensEndpoint(self._http)
        self.quotes = QuotesEndpoint(self._http)

    async def __aenter__(self) -> "Bloxchaser":
        await self._http.__aenter__()
        return self

    async def __aexit__(self, *args) -> None:
        await self._http.__aexit__(*args)

    async def health(self) -> HealthResponse:
        """Check API health status."""
        data = await self._http.get("/health")
        return HealthResponse(**data)

    async def usage(self) -> UsageResponse:
        """Get your API usage statistics."""
        data = await self._http.get("/v1/auth/usage")
        return UsageResponse(**data)

    @property
    def rate_limit_remaining(self) -> Optional[int]:
        """Remaining requests in current rate limit window."""
        return self._http._rate_limit_remaining


class BloxchaserSync:
    """Sync Bloxchaser client wrapper.

    Note: Do not use BloxchaserSync from within an async context (e.g., Jupyter notebooks
    with running event loops). Use the async Bloxchaser client instead.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 3,
    ):
        import asyncio
        self._loop = asyncio.new_event_loop()
        self._async_client = Bloxchaser(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._swaps = _SyncSwapsEndpoint(self._async_client.swaps, self._loop)
        self._tokens = _SyncTokensEndpoint(self._async_client.tokens, self._loop)
        self._quotes = _SyncQuotesEndpoint(self._async_client.quotes, self._loop)

    @property
    def swaps(self) -> "_SyncSwapsEndpoint":
        return self._swaps

    @property
    def tokens(self) -> "_SyncTokensEndpoint":
        return self._tokens

    @property
    def quotes(self) -> "_SyncQuotesEndpoint":
        return self._quotes

    def __enter__(self) -> "BloxchaserSync":
        self._loop.run_until_complete(self._async_client.__aenter__())
        return self

    def __exit__(self, *args) -> None:
        try:
            self._loop.run_until_complete(self._async_client.__aexit__(*args))
        finally:
            self._loop.close()

    def health(self) -> HealthResponse:
        """Check API health status."""
        return self._loop.run_until_complete(self._async_client.health())

    def usage(self) -> UsageResponse:
        """Get your API usage statistics."""
        return self._loop.run_until_complete(self._async_client.usage())

    @property
    def rate_limit_remaining(self) -> Optional[int]:
        """Remaining requests in current rate limit window."""
        return self._async_client.rate_limit_remaining


class _SyncSwapsEndpoint:
    """Sync wrapper for SwapsEndpoint."""

    def __init__(self, async_endpoint: SwapsEndpoint, loop):
        self._async = async_endpoint
        self._loop = loop

    def get(self, **kwargs):
        return self._loop.run_until_complete(self._async.get(**kwargs))

    def by_token(self, token_address: str, **kwargs):
        return self._loop.run_until_complete(self._async.by_token(token_address, **kwargs))

    def by_pool(self, pool_address: str, **kwargs):
        return self._loop.run_until_complete(self._async.by_pool(pool_address, **kwargs))

    def stats(self, **kwargs):
        return self._loop.run_until_complete(self._async.stats(**kwargs))

    def chains(self):
        return self._loop.run_until_complete(self._async.chains())

    def ohlcv(self, token_address: str, **kwargs):
        return self._loop.run_until_complete(self._async.ohlcv(token_address, **kwargs))


class _SyncTokensEndpoint:
    """Sync wrapper for TokensEndpoint."""

    def __init__(self, async_endpoint: TokensEndpoint, loop):
        self._async = async_endpoint
        self._loop = loop

    def list(self, **kwargs):
        return self._loop.run_until_complete(self._async.list(**kwargs))

    def get(self, address: str):
        return self._loop.run_until_complete(self._async.get(address))

    def price(self, address: str):
        return self._loop.run_until_complete(self._async.price(address))

    def price_history(self, address: str, **kwargs):
        return self._loop.run_until_complete(self._async.price_history(address, **kwargs))


class _SyncQuotesEndpoint:
    """Sync wrapper for QuotesEndpoint."""

    def __init__(self, async_endpoint: QuotesEndpoint, loop):
        self._async = async_endpoint
        self._loop = loop

    def get(self, pool: str, amount: int, input_token: str, **kwargs):
        return self._loop.run_until_complete(self._async.get(pool, amount, input_token, **kwargs))


__all__ = ["Bloxchaser", "BloxchaserSync"]
