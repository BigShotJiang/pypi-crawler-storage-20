"""HTTP client with retry logic and rate limit handling."""

import asyncio
import time
from typing import Any, Optional
import httpx

from bloxchaser.exceptions import (
    BloxchaserError,
    AuthenticationError,
    RateLimitError,
    APIError,
    NetworkError,
)

DEFAULT_BASE_URL = "https://api.bloxchaser.com"
DEFAULT_TIMEOUT = 30.0
MAX_RETRIES = 3
RETRY_BACKOFF_FACTOR = 2.0
RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}


class HTTPClient:
    """Async HTTP client with retry and rate limit handling."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: Optional[httpx.AsyncClient] = None

        # Rate limit tracking
        self._rate_limit_remaining: Optional[int] = None
        self._rate_limit_reset: Optional[float] = None

    async def __aenter__(self) -> "HTTPClient":
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
            headers={
                "X-API-Key": self.api_key,
                "User-Agent": "bloxchaser-python/0.1.0",
                "Accept": "application/json",
            },
        )
        return self

    async def __aexit__(self, *args) -> None:
        if self._client:
            await self._client.aclose()

    def _update_rate_limits(self, headers: httpx.Headers) -> None:
        """Extract rate limit info from response headers."""
        if "X-RateLimit-Remaining" in headers:
            try:
                self._rate_limit_remaining = int(headers["X-RateLimit-Remaining"])
            except ValueError:
                pass
        if "X-RateLimit-Reset" in headers:
            try:
                self._rate_limit_reset = float(headers["X-RateLimit-Reset"])
            except ValueError:
                pass

    async def _wait_for_rate_limit(self) -> None:
        """Wait if rate limited."""
        if self._rate_limit_remaining == 0 and self._rate_limit_reset:
            wait_time = self._rate_limit_reset - time.time()
            if wait_time > 0:
                await asyncio.sleep(min(wait_time, 60))  # Cap at 60s

    async def request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
    ) -> Any:
        """Make HTTP request with retry logic."""
        if not self._client:
            raise BloxchaserError("Client not initialized. Use 'async with' context.")

        # Wait if rate limited
        await self._wait_for_rate_limit()

        last_error: Optional[Exception] = None

        for attempt in range(self.max_retries + 1):
            try:
                response = await self._client.request(
                    method=method,
                    url=path,
                    params=params,
                    json=json,
                )

                # Update rate limit tracking
                self._update_rate_limits(response.headers)

                # Handle errors
                if response.status_code == 401:
                    raise AuthenticationError("Invalid or missing API key")

                if response.status_code == 429:
                    # Rate limited - extract retry time
                    retry_after = float(response.headers.get("Retry-After", 60))
                    raise RateLimitError(
                        f"Rate limit exceeded. Retry after {retry_after}s",
                        retry_after=retry_after,
                    )

                if response.status_code >= 400:
                    data = response.json()
                    # Handle both {"error": {...}} and {"detail": "..."} formats
                    if "error" in data:
                        error = data["error"]
                        raise APIError(
                            code=error.get("code", "UNKNOWN"),
                            message=error.get("message", response.text),
                            status_code=response.status_code,
                        )
                    else:
                        raise APIError(
                            code="API_ERROR",
                            message=data.get("detail", response.text),
                            status_code=response.status_code,
                        )

                return response.json()

            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_error = NetworkError(f"Network error: {e}")

            except RateLimitError as e:
                last_error = e
                await asyncio.sleep(e.retry_after)
                continue

            except (AuthenticationError, APIError):
                raise

            # Exponential backoff for retries
            if attempt < self.max_retries:
                wait = RETRY_BACKOFF_FACTOR ** attempt
                await asyncio.sleep(wait)

        raise last_error or BloxchaserError("Request failed after retries")

    async def get(self, path: str, **params: Any) -> Any:
        """GET request."""
        # Filter out None values
        filtered_params = {k: v for k, v in params.items() if v is not None}
        return await self.request("GET", path, params=filtered_params if filtered_params else None)

    async def post(self, path: str, **json_data: Any) -> Any:
        """POST request."""
        return await self.request("POST", path, json=json_data)
