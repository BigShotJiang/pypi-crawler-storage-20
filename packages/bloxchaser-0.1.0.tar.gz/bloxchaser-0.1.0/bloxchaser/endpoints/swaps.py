"""Swaps endpoint."""

from typing import Optional, Literal
from bloxchaser._http import HTTPClient
from bloxchaser.models.swaps import (
    SwapsResponse,
    SwapsByTokenResponse,
    SwapsByPoolResponse,
    ChainStatsDetail,
    ChainsSummaryResponse,
    OHLCVResponse,
)

Chain = Literal["solana", "base", "arbitrum", "bnb"]
Interval = Literal["1m", "5m", "15m", "1h", "4h", "1d"]
Quote = Literal["sol", "usdc", "usdt"]


class SwapsEndpoint:
    """Swap data endpoints."""

    def __init__(self, http: HTTPClient):
        self._http = http

    async def get(
        self,
        chain: Chain = "solana",
        dex: Optional[str] = None,
        token: Optional[str] = None,
        pool: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> SwapsResponse:
        """
        Get recent swaps across chains.

        Args:
            chain: Blockchain (solana, base, arbitrum, bnb)
            dex: Filter by DEX (e.g., raydium, uniswap_v3)
            token: Filter by token address
            pool: Filter by pool address
            limit: Number of results (1-1000)
            offset: Pagination offset

        Returns:
            SwapsResponse with list of swaps
        """
        data = await self._http.get(
            "/v1/swaps",
            chain=chain,
            dex=dex,
            token=token,
            pool=pool,
            limit=limit,
            offset=offset,
        )
        return SwapsResponse(**data)

    async def by_token(
        self,
        token_address: str,
        chain: Chain = "solana",
        limit: int = 100,
        offset: int = 0,
    ) -> SwapsByTokenResponse:
        """Get all swaps involving a specific token."""
        data = await self._http.get(
            f"/v1/swaps/by-token/{token_address}",
            chain=chain,
            limit=limit,
            offset=offset,
        )
        return SwapsByTokenResponse(**data)

    async def by_pool(
        self,
        pool_address: str,
        chain: Chain = "solana",
        limit: int = 100,
        offset: int = 0,
    ) -> SwapsByPoolResponse:
        """Get all swaps for a specific liquidity pool."""
        data = await self._http.get(
            f"/v1/swaps/by-pool/{pool_address}",
            chain=chain,
            limit=limit,
            offset=offset,
        )
        return SwapsByPoolResponse(**data)

    async def stats(self, chain: Optional[Chain] = None) -> dict[str, ChainStatsDetail]:
        """Get swap statistics by chain.

        Returns:
            Dict mapping chain names to their statistics.
        """
        data = await self._http.get("/v1/swaps/stats", chain=chain)
        # Parse each chain's stats into ChainStatsDetail
        return {k: ChainStatsDetail(**v) for k, v in data.items()}

    async def chains(self) -> ChainsSummaryResponse:
        """Get summary of all supported chains."""
        data = await self._http.get("/v1/swaps/chains")
        return ChainsSummaryResponse(**data)

    async def ohlcv(
        self,
        token_address: str,
        quote: Quote = "sol",
        interval: Interval = "1h",
        limit: int = 100,
    ) -> OHLCVResponse:
        """
        Get OHLCV candlestick data for a Solana token.

        Args:
            token_address: Solana token mint address
            quote: Quote token (sol, usdc, usdt)
            interval: Candle interval (1m, 5m, 15m, 1h, 4h, 1d)
            limit: Number of candles (1-500)

        Returns:
            OHLCVResponse with candlestick data
        """
        data = await self._http.get(
            f"/v1/swaps/ohlcv/{token_address}",
            quote=quote,
            interval=interval,
            limit=limit,
        )
        return OHLCVResponse(**data)
