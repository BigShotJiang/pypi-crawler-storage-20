"""Quotes endpoint."""

from typing import Optional, Literal
from bloxchaser._http import HTTPClient
from bloxchaser.models.quotes import QuoteResponse

Chain = Literal["solana", "base", "arbitrum", "bnb"]


class QuotesEndpoint:
    """Swap quote endpoints."""

    def __init__(self, http: HTTPClient):
        self._http = http

    async def get(
        self,
        pool: str,
        amount: int,
        input_token: str,
        chain: Chain = "solana",
        dex: Optional[str] = None,
    ) -> QuoteResponse:
        """
        Get a swap quote with slippage estimate.

        Args:
            pool: Pool address
            amount: Input amount (in smallest units, e.g., lamports for SOL)
            input_token: Input token address
            chain: Blockchain (solana, base, arbitrum, bnb)
            dex: DEX type (auto-detected if not provided)

        Returns:
            QuoteResponse with output amount and price impact
        """
        data = await self._http.get(
            "/v1/quote",
            pool=pool,
            amount=amount,
            input_token=input_token,
            chain=chain,
            dex=dex,
        )
        return QuoteResponse(**data)
