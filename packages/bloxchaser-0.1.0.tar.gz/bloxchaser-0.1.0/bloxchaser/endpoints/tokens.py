"""Tokens endpoint."""

from typing import List
from bloxchaser._http import HTTPClient
from bloxchaser.models.tokens import (
    TokenInfo,
    TokenPrice,
    PriceHistoryResponse,
)


class TokensEndpoint:
    """Token data endpoints (Solana)."""

    def __init__(self, http: HTTPClient):
        self._http = http

    async def list(self, limit: int = 100, offset: int = 0) -> List[TokenInfo]:
        """
        List popular Solana tokens from Raydium pools.

        Args:
            limit: Number of results (1-1000)
            offset: Pagination offset

        Returns:
            List of TokenInfo objects
        """
        data = await self._http.get("/v1/tokens", limit=limit, offset=offset)
        return [TokenInfo(**t) for t in data]

    async def get(self, address: str) -> TokenInfo:
        """
        Get Solana token metadata by address.

        Args:
            address: Token mint address

        Returns:
            TokenInfo with token details
        """
        data = await self._http.get(f"/v1/tokens/{address}")
        return TokenInfo(**data)

    async def price(self, address: str) -> TokenPrice:
        """
        Get current USD price for a Solana token.

        Args:
            address: Token mint address

        Returns:
            TokenPrice with current price and source
        """
        data = await self._http.get(f"/v1/tokens/{address}/price")
        return TokenPrice(**data)

    async def price_history(
        self, address: str, limit: int = 100
    ) -> PriceHistoryResponse:
        """
        Get historical USD price snapshots.

        Args:
            address: Token mint address
            limit: Number of price points (1-1000)

        Returns:
            PriceHistoryResponse with historical prices
        """
        data = await self._http.get(
            f"/v1/tokens/{address}/price/history", limit=limit
        )
        return PriceHistoryResponse(**data)
