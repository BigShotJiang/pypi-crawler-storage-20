"""Custom exceptions for Bloxchaser SDK."""


class BloxchaserError(Exception):
    """Base exception for all SDK errors."""
    pass


class AuthenticationError(BloxchaserError):
    """Invalid or missing API key."""
    pass


class RateLimitError(BloxchaserError):
    """Rate limit exceeded."""

    def __init__(self, message: str, retry_after: float = 60):
        super().__init__(message)
        self.retry_after = retry_after


class APIError(BloxchaserError):
    """API returned an error."""

    def __init__(self, code: str, message: str, status_code: int):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message
        self.status_code = status_code


class NetworkError(BloxchaserError):
    """Network or connection error."""
    pass


class ValidationError(BloxchaserError):
    """Request validation failed."""
    pass
