"""
Bloxchaser Python SDK - Multi-chain DEX Data API

Usage:
    # Async (recommended)
    async with Bloxchaser("bc_live_xxx") as client:
        swaps = await client.swaps.get(chain="solana", limit=100)

    # Sync
    with BloxchaserSync("bc_live_xxx") as client:
        swaps = client.swaps.get(chain="solana", limit=100)
"""

from bloxchaser.client import Bloxchaser, BloxchaserSync
from bloxchaser.exceptions import (
    BloxchaserError,
    AuthenticationError,
    RateLimitError,
    APIError,
    NetworkError,
    ValidationError,
)

__version__ = "0.1.0"
__all__ = [
    "Bloxchaser",
    "BloxchaserSync",
    "BloxchaserError",
    "AuthenticationError",
    "RateLimitError",
    "APIError",
    "NetworkError",
    "ValidationError",
]
