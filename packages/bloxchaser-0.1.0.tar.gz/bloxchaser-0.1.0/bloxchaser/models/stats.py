"""Health and usage response models."""

from pydantic import BaseModel


class HealthResponse(BaseModel):
    """API health check response."""
    status: str
    timestamp: str
    service: str
    version: str


class UsageResponse(BaseModel):
    """API usage statistics response."""
    plan_tier: str
    rate_limit_per_minute: int
    monthly_quota: int
    requests_this_month: int
    quota_remaining: int
    quota_reset_at: str
    requests_last_24h: int
    avg_response_time_ms: float
    created_at: str
    email_verified: bool
