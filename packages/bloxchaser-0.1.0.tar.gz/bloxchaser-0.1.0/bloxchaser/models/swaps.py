"""Swap data models."""

from typing import List, Optional, Dict
from pydantic import BaseModel


class Swap(BaseModel):
    """Individual swap transaction."""
    id: str
    chain: str
    block: int
    tx_hash: str
    timestamp: str
    dex: str
    pool: Optional[str] = None
    token_in: str
    amount_in: str
    sender: Optional[str] = None
    token_out: str
    amount_out: str
    recipient: Optional[str] = None


class SwapsResponse(BaseModel):
    """Response containing list of swaps."""
    chain: str
    count: int
    swaps: List[Swap]


class SwapsByTokenResponse(BaseModel):
    """Response for token-filtered swaps."""
    chain: str
    token: str
    count: int
    swaps: List[Swap]


class SwapsByPoolResponse(BaseModel):
    """Response for pool-filtered swaps."""
    chain: str
    pool: str
    count: int
    swaps: List[Swap]


class DexStats(BaseModel):
    """Statistics for a single DEX."""
    dex: str
    total_swaps: int
    percentage: float


class ChainStatsDetail(BaseModel):
    """Detailed statistics for a single chain."""
    chain: str
    total_swaps: int
    by_dex: Optional[Dict] = None
    computed_at: Optional[str] = None
    cached_at: Optional[str] = None
    latest_swap: Optional[str] = None
    earliest_swap: Optional[str] = None


# Stats response is a dict with chain names as keys
SwapStatsResponse = Dict[str, ChainStatsDetail]


class ChainSummary(BaseModel):
    """Summary statistics for a chain."""
    total_swaps: int


class ChainsSummaryResponse(BaseModel):
    """Summary of all supported chains."""
    chains: List[str]
    stats: Dict[str, ChainSummary]
    total_swaps_all_chains: int


class OHLCVCandle(BaseModel):
    """Single OHLCV candlestick."""
    timestamp: int
    datetime: str
    open: float
    high: float
    low: float
    close: float
    volume: int
    trades: int


class OHLCVResponse(BaseModel):
    """OHLCV candlestick response."""
    token: str
    quote: str
    interval: str
    count: int
    candles: List[OHLCVCandle]
