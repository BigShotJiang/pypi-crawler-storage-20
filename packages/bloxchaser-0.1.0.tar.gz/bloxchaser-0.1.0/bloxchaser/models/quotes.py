"""Quote data models."""

from typing import Optional, Dict, Any
from pydantic import BaseModel


class QuoteResponse(BaseModel):
    """Swap quote response."""
    pool: str
    chain: str
    dex: str
    input_token: str
    input_amount: str
    output_token: str
    output_amount: str
    price_impact: str
    execution_price: str
    mid_price: str
    reserves: Optional[Dict[str, Any]] = None
