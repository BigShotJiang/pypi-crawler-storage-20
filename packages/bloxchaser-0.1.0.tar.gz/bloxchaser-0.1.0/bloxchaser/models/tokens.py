"""Token data models."""

from typing import Optional, List
from pydantic import BaseModel


class TokenInfo(BaseModel):
    """Token information."""
    address: str
    symbol: str
    name: str
    decimals: int
    price_usd: Optional[float] = None
    volume_24h: Optional[float] = None
    market_cap: Optional[float] = None


class TokenPrice(BaseModel):
    """Token price response."""
    address: str
    symbol: str
    price_usd: float
    timestamp: str
    source: str


class PricePoint(BaseModel):
    """Historical price point."""
    timestamp: str
    price_usd: float


class PriceHistoryResponse(BaseModel):
    """Price history response."""
    address: str
    prices: List[PricePoint]
    count: int
