"""Tests for Pydantic models."""

import pytest
from bloxchaser.models.swaps import (
    Swap,
    SwapsResponse,
    ChainStatsDetail,
    DexStats,
    OHLCVCandle,
)


def test_swap_model():
    """Test Swap model."""
    swap = Swap(
        id="0319872345-000123-00001",
        chain="solana",
        block=319872345,
        tx_hash="5xKj8mNvR2qJYhGb3TfKpWn9xZuAcDsEfLmY7HjN4oPq",
        timestamp="2025-02-08T12:00:00Z",
        dex="raydium",
        pool="7XawhbbxtsRcQA8KTkHT9f9nc6d69UwqCDh6U5EEbEmX",
        token_in="So11111111111111111111111111111111111111112",
        amount_in="1000000000",
        sender="9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
        token_out="EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        amount_out="150000000",
        recipient="9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM",
    )
    assert swap.chain == "solana"
    assert swap.dex == "raydium"
    assert swap.block == 319872345


def test_swap_optional_fields():
    """Test Swap with optional fields as None."""
    swap = Swap(
        id="test-id",
        chain="base",
        block=12345,
        tx_hash="0x123",
        timestamp="2025-01-01T00:00:00Z",
        dex="uniswap_v3",
        token_in="0xabc",
        amount_in="1000",
        token_out="0xdef",
        amount_out="500",
    )
    assert swap.pool is None
    assert swap.sender is None
    assert swap.recipient is None


def test_swaps_response():
    """Test SwapsResponse model."""
    response = SwapsResponse(
        chain="solana",
        count=1,
        swaps=[
            Swap(
                id="test-id",
                chain="solana",
                block=12345,
                tx_hash="abc123",
                timestamp="2025-01-01T00:00:00Z",
                dex="raydium",
                token_in="token1",
                amount_in="1000",
                token_out="token2",
                amount_out="500",
            )
        ],
    )
    assert response.count == 1
    assert len(response.swaps) == 1


def test_chain_stats_detail():
    """Test ChainStatsDetail model."""
    stats = ChainStatsDetail(
        chain="solana",
        total_swaps=1000000,
        by_dex={"raydium": 800000, "orca": 200000},
        computed_at="2026-01-11T12:00:00",
    )
    assert stats.total_swaps == 1000000
    assert stats.chain == "solana"


def test_ohlcv_candle():
    """Test OHLCVCandle model."""
    candle = OHLCVCandle(
        timestamp=1739127600,
        datetime="2025-02-09T19:00:00+00:00",
        open=0.000873,
        high=0.000875,
        low=0.000871,
        close=0.000872,
        volume=12156407026884,
        trades=16,
    )
    assert candle.open == 0.000873
    assert candle.close == 0.000872
    assert candle.trades == 16
