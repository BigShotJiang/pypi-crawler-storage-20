"""Pytest configuration and fixtures."""

import pytest


@pytest.fixture
def api_key():
    """Test API key."""
    return "bc_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"


@pytest.fixture
def base_url():
    """Test base URL."""
    return "https://api.bloxchaser.com"
