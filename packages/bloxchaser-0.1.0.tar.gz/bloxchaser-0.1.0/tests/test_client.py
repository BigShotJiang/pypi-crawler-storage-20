"""Tests for Bloxchaser client."""

import pytest
from bloxchaser import Bloxchaser, BloxchaserSync


def test_client_init(api_key, base_url):
    """Test client initialization."""
    client = Bloxchaser(api_key=api_key, base_url=base_url)
    assert client._http.api_key == api_key
    assert client._http.base_url == base_url


def test_sync_client_init(api_key, base_url):
    """Test sync client initialization."""
    client = BloxchaserSync(api_key=api_key, base_url=base_url)
    assert client._async_client._http.api_key == api_key


def test_client_has_swaps_endpoint(api_key):
    """Test that client has swaps endpoint."""
    client = Bloxchaser(api_key=api_key)
    assert hasattr(client, "swaps")
    assert client.swaps is not None
