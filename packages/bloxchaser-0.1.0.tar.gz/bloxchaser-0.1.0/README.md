# Bloxchaser Python SDK

Official Python SDK for [Bloxchaser](https://bloxchaser.com) - Multi-chain DEX swap data API.

## Installation

```bash
pip install bloxchaser
```

## Quick Start

```python
import asyncio
from bloxchaser import Bloxchaser

async def main():
    async with Bloxchaser("bc_live_your_key") as client:
        # Get recent Solana swaps
        swaps = await client.swaps.get(chain="solana", limit=100)
        print(f"Found {swaps.count} swaps")

        # Get OHLCV for BONK
        ohlcv = await client.swaps.ohlcv(
            "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
            interval="4h"
        )
        for candle in ohlcv.candles[:5]:
            print(f"{candle.datetime}: {candle.close}")

asyncio.run(main())
```

### Sync Usage

```python
from bloxchaser import BloxchaserSync

with BloxchaserSync("bc_live_your_key") as client:
    swaps = client.swaps.get(chain="base", dex="aerodrome")
    print(f"Found {swaps.count} Base swaps")
```

## Features

- **Async-first** with sync wrappers
- **Full type hints** with Pydantic models
- **Automatic retry** with exponential backoff
- **Rate limit handling** with smart throttling
- **Multi-chain support**: Solana, Base, Arbitrum, BNB

## API Reference

### Swaps

```python
# Get recent swaps
swaps = await client.swaps.get(
    chain="solana",      # solana, base, arbitrum, bnb
    dex="raydium",       # optional DEX filter
    limit=100,
    offset=0
)

# Swaps by token
swaps = await client.swaps.by_token("So111...", chain="solana")

# Swaps by pool
swaps = await client.swaps.by_pool("7Xawh...", chain="solana")

# Chain statistics
stats = await client.swaps.stats(chain="solana")

# All chains summary
summary = await client.swaps.chains()

# OHLCV candles (Solana)
ohlcv = await client.swaps.ohlcv(
    "DezXAZ...",
    quote="sol",         # sol, usdc, usdt
    interval="4h",       # 1m, 5m, 15m, 1h, 4h, 1d
    limit=100
)
```

### Tokens (Solana)

```python
# List tokens
tokens = await client.tokens.list(limit=100)

# Get token info
token = await client.tokens.get("DezXAZ...")

# Get current price
price = await client.tokens.price("DezXAZ...")

# Price history
history = await client.tokens.price_history("DezXAZ...", limit=60)
```

### Quotes

```python
# Get swap quote
quote = await client.quotes.get(
    pool="7Xawh...",
    amount=1_000_000_000,  # 1 SOL in lamports
    input_token="So111...",
    chain="solana"
)
print(f"Output: {quote.output_amount}, Impact: {quote.price_impact}")
```

### Health & Usage

```python
# Check API health
health = await client.health()
print(f"Status: {health.status}, Version: {health.version}")

# Get your usage stats
usage = await client.usage()
print(f"Requests today: {usage.requests_today}/{usage.monthly_quota}")
```

## Error Handling

```python
from bloxchaser import (
    Bloxchaser,
    AuthenticationError,
    RateLimitError,
    APIError,
)

try:
    async with Bloxchaser("invalid_key") as client:
        await client.swaps.get()
except AuthenticationError:
    print("Invalid API key")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after}s")
except APIError as e:
    print(f"API error: [{e.code}] {e.message}")
```

## Get an API Key

1. Visit [bloxchaser.com/signup](https://bloxchaser.com/signup)
2. Enter your email
3. Save your API key (shown only once!)

## Links

- [API Documentation](https://api.bloxchaser.com/docs)
- [Website](https://bloxchaser.com)
- [Support](mailto:hello@bloxchaser.com)

## License

MIT
