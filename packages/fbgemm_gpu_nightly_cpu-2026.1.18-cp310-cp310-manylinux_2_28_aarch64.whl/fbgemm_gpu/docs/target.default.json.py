
{
    "version": "2026.1.18",
    "target": "default",
    "variant": "cpu"
}
