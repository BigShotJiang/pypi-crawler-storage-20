## Bundled Assets Package

This package demonstrates how to include data files in a Python package so that they can be distributed via PyPI and accessed at runtime.  It uses [`importlib.resources`](https://docs.python.org/3/library/importlib.resources.html) to read text and binary files from within the installed package.

After installing this package with `pip install`, you can use the helper functions in `bundled_assets.assets` to load the bundled data files.  See the docstrings in `assets.py` for more information.
