from cg.constants import Workflow

IMPLEMENTED_FASTQ_WORKFLOWS = [
    Workflow.BALSAMIC,
    Workflow.MICROSALT,
    Workflow.MIP_DNA,
    Workflow.RAREDISEASE,
    Workflow.RNAFUSION,
    Workflow.TAXPROFILER,
    Workflow.TOMTE,
]

BAM_WORKFLOWS = [Workflow.NALLO]
