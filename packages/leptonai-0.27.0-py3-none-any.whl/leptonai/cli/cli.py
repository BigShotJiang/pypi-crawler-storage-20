from datetime import datetime
import time
from pathlib import Path

import click
import sys
import webbrowser

from leptonai.api.v2.utils import (
    WorkspaceUnauthorizedError,
    WorkspaceNotFoundError,
    WorkspaceForbiddenError,
)
from .util import console
from leptonai.api.v2.workspace_record import WorkspaceRecord
from loguru import logger

import leptonai
from . import deployment, node
from . import job
from . import kv
from . import objectstore
from . import photon
from . import pod
from . import queue
from . import secret
from . import storage
from . import workspace
from . import ingress
from . import log
from . import raycluster
from . import template
from . import finetune

from .util import click_group

CONTEXT_SETTINGS = dict(help_option_names=["-h", "--help"])
LOGIN_LOGO = """
                            [#76B900]N V I D I A[/]

                        [white] D G X  C L O U D[/]

        [#76B900]██╗     ███████╗██████╗ ████████╗ ██████╗ ███╗   ██╗[/]
        [#76B900]██║     ██╔════╝██╔══██╗╚══██╔══╝██╔═══██╗████╗  ██║[/]
        [#76B900]██║     █████╗  ██████╔╝   ██║   ██║   ██║██╔██╗ ██║[/]
        [#76B900]██║     ██╔══╝  ██╔═══╝    ██║   ██║   ██║██║╚██╗██║[/]
        [#76B900]███████╗███████╗██║        ██║   ╚██████╔╝██║ ╚████║[/]
        [#76B900]╚══════╝╚══════╝╚═╝        ╚═╝    ╚═════╝ ╚═╝  ╚═══╝[/]

"""


@click.version_option(leptonai.__version__, "-v", "--version")
@click_group(context_settings=CONTEXT_SETTINGS)
def lep():
    """
    Lep is the main entry point for the DGX Cloud Lepton commandline interface. It provides
    a set of commands to create and develop photons locally, and deploy them to the
    DGX Cloud Lepton. It also provides a set of commands to manage resources on the
    cloud, such as workspaces, deployments, secrets, and storage. To install it, run

    `pip install -U leptonai`
    """
    try:
        check_lepton_version()
    except Exception:
        pass


# Add subcommands
deployment.add_command(lep)
job.add_command(lep)
kv.add_command(lep)
objectstore.add_command(lep)
photon.add_command(lep)
pod.add_command(lep)
queue.add_command(lep)
secret.add_command(lep)
storage.add_command(lep)
workspace.add_command(lep)
node.add_command(lep)

ingress.add_command(lep)
log.add_command(lep)
raycluster.add_command(lep)
template.add_command(lep)
finetune.add_command(lep)


@lep.command()
@click.option(
    "--credentials",
    "-c",
    help="The credentials of the lepton login info.",
    default=None,
)
@click.option(
    "--workspace-url",
    "-u",
    help="The url of the workspace to login to.",
    default=None,
)
@click.option(
    "--lepton-classic",
    "-l",
    is_flag=True,
    help="Login to the classic Lepton AI workspace.",
)
@click.option(
    "--workspace-origin-url",
    "-o",
    help="The origin url of the workspace to login to.",
    hidden=True,
    default=None,
)
def login(credentials, workspace_url, lepton_classic, workspace_origin_url):
    """
    Login to the DGX Cloud Lepton. This will open a browser window to the Lepton
    login page if credentials are not given. You will be redirected to a page with
    the credentials string. Copy the string and paste it into the terminal, and
    you will be logged in.
    """
    console.print(LOGIN_LOGO)
    need_further_login = False
    if credentials:
        workspace_id, auth_token = credentials.split(":", 1)
        WorkspaceRecord.set_or_exit(
            workspace_id,
            auth_token=auth_token,
            url=workspace_url,
            workspace_origin_url=workspace_origin_url,
            is_lepton_classic=lepton_classic,
            could_be_new_token=True,
        )
    else:
        if workspace_url or lepton_classic or workspace_origin_url:
            console.print(
                "[bold red]Invalid usage:[/bold red] --workspace-url,"
                " --workspace-origin-url, and --lepton-classic must be used together"
                " with --credentials.\n[white]Either provide credentials or remove"
                " these options to avoid misconfiguring local"
                " workspaces.[/white]\n[yellow]Example:[/yellow] [#76B900]lep login -c"
                " <workspace_id>:<auth_token> [--workspace-url <url>]"
                " [--workspace-origin-url <url>] [--lepton-classic][/]\n"
            )
            sys.exit(1)
        if WorkspaceRecord.current():
            # Already logged in. Notify the user the login status.
            current_ws = WorkspaceRecord.current()
            # Note: Set LOGURU_LEVEL=TRACE to see these debug logs
            logger.trace(
                f"Current workspace info:\n  id: {current_ws.id_}\n  url:"
                f" {current_ws.url}\n  display_name: {current_ws.display_name}\n "
                " auth_token:"
                f" {current_ws.auth_token[:2]}****{current_ws.auth_token[-2:] if current_ws.auth_token else None}\n"
                f"  workspace_origin_url: {current_ws.workspace_origin_url}\n "
                f" is_lepton_classic: {current_ws.is_lepton_classic}"
            )
        else:
            candidates = WorkspaceRecord.workspaces()
            if len(candidates) == 0:
                need_further_login = True
            elif len(candidates) == 1:
                # Only one workspace, so we will simply log in to that one.
                ws = candidates[0]
                WorkspaceRecord.set_or_exit(ws.id_, ws.auth_token, ws.url, ws.workspace_origin_url, ws.is_lepton_classic)  # type: ignore
            else:
                # multiple workspaces. login to one of them.
                console.print("You have multiple workspaces. Please select one:")
                for i, ws in enumerate(candidates):
                    console.print(f"{i+1}. {ws.id_} ({ws.display_name})")
                choice = None
                while not choice:
                    choice = input("choice: ")
                try:
                    choice = int(choice) - 1
                except ValueError:
                    console.print("Invalid choice. Please enter a number.")
                    sys.exit(1)
                WorkspaceRecord.set_or_exit(
                    candidates[choice].id_,  # type: ignore
                    candidates[choice].auth_token,
                    candidates[choice].url,
                    candidates[choice].workspace_origin_url,
                    candidates[choice].is_lepton_classic,
                )
                console.print(
                    "[dim]Note: If you have multiple workspaces, you can pick the one"
                    " you want\nto log in via `lep workspace login -i"
                    " workspace_id`.[/dim]"
                )
    if need_further_login:
        # there is no credentials, and no current workspace. Will need to ask the
        # user to login interactively.
        # obtain credentials first.
        console.print(
            "\n[bold]Welcome to [#76B900]DGX Cloud Lepton[/][/bold]\n"
            "We will open a browser for you to obtain your login credentials.\n"
            "Please log in with your registered account.\n"
        )
        console.print(
            "[bold]Instructions:[/bold]\n"
            "1. A browser window will open to the workspace credentials page\n"
            "2. If you have multiple workspaces, select the one you want to log in to\n"
            "3. Copy the credential and paste it here\n"
            "4. The credential should be in the format:"
            " [#76B900]<workspace_id>:<auth_token>[/]\n"
        )
        input("Press Enter to continue...")

        credentials_page_url = "https://dashboard.dgxc-lepton.nvidia.com/credentials"
        if lepton_classic:
            credentials_page_url = "https://dashboard.lepton.ai/credentials"

        success = webbrowser.open(credentials_page_url)
        if not success:
            console.print(
                "It seems that you are running in a non-GUI environment. You can"
                " manually obtain credentials from"
                f" [green]{credentials_page_url}[/] and copy it"
                r" over, or use `lep login -c \[credentials]` to log in."  # noqa: W605
            )
        while not credentials:
            credentials = input("Credential: ")
            if ":" not in credentials:
                credentials = None
                console.print(
                    "[red]A credential should be formatted as"
                    " <workspace_id>:<auth_token>[/]"
                )
        workspace_id, auth_token = credentials.split(":", 1)
        WorkspaceRecord.set_or_exit(
            workspace_id, auth_token=auth_token, could_be_new_token=True
        )
    # Try to login and print the info.
    api_client = WorkspaceRecord.client()

    try:
        # Retry info() in case the new token is not yet propagated.
        retries = 20
        while True:
            try:
                if retries == 16:
                    console.print("[bold]Loading workspace...[/bold]")
                info = api_client.info()
                ws_name = info.workspace_name
                tier = info.workspace_tier

                indent = " " * 17  # match logo's left margin for alignment
                console.print(f"{indent}{'Workspace':>12}: [#76B900]{ws_name}[/]")
                console.print(f"{indent}{'Tier':>12}: {tier}")
                WorkspaceRecord.refresh_token_expires_at(skip_if_token_exists=True)
                version_info_list = api_client.version(info)
                if version_info_list is not None:
                    version = ".".join(str(v) for v in version_info_list)
                    console.print(f"{indent}{'Version':>12}: {version}\n")
                break
            except WorkspaceUnauthorizedError:
                retries -= 1
                if retries <= 0:
                    raise
                time.sleep(3)
                continue

    except WorkspaceUnauthorizedError as e:
        console.print("\n", e)
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        console.print(f"""
        [bold]Invalid Workspace Access Detected[/]
        [white]Workspace ID:[/white] {e.workspace_id}

        [#76B900]If you are logging in with a fresh token, please wait for 2-3 minutes and try again.[/#76B900]

        [white]Note: If you are trying to login to a Lepton classic workspace, please use:[/white]
        [#76B900]'lep login -c <workspace-id>:<token> --lepton-classic'[/#76B900]
        [white]Make sure to include the --lepton-classic or -l flag. (Ignore if you are DGXC User)[/white]

        [bold]To resolve this issue:[/bold]
            1. [#76B900]Verify your login credentials above.[/#76B900]

        [white]If using 'lep login' and encountering this error, you might be logging in with
        an invalid local credential.[/white]
            2. [white]To directly login, use:[/white]
                [#76B900]'lep login -c <workspace_id>:<auth_token>'[/#76B900]

            3. [white]Or list and remove the invalid local workspace credential with:[/white]
                [#76B900]'lep workspace list'[/#76B900]
                [#76B900]'lep workspace remove -i <workspace_id>'[/#76B900]
                [white]Then, log in again with:[/white]
                [#76B900]'lep login'[/#76B900]

            4. [#76B900]If the workspace was just created, please wait for 5 - 10 minutes.[/#76B900]
            [red]Contact us if the workspace remains unavailable after 10 minutes.[/red]
            (Current Time: [bold]{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}[/bold])
        """)
        sys.exit(1)

    except WorkspaceNotFoundError as e:
        console.print("\n", e)

        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        console.print(f"""
        [red bold]Workspace Not Found[/]
        [red]Workspace ID:[/red] {e.workspace_id}

        [bold]To resolve this issue:[/bold]
        1. [green]If the workspace was just created, please wait for 10 minutes. [/green]
           [yellow]Contact us if the workspace remains unavailable after 10 minutes.[/yellow]
           (Current Time: [bold blue]{current_time}[/bold blue])
        2. [green]Please check the login info you just used above[/green]
        3. [yellow]Login to the workspace with valid credentials:[/yellow]
           [green]lep workspace login -i <valid_workspace_id> -t <valid_workspace_token>[/green]
        """)
        sys.exit(1)

    except WorkspaceForbiddenError as e:
        console.print("\n", e)

        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        console.print(f"""
        [red bold]Workspace Forbidden access[/]
        [red]Workspace ID:[/red] {e.workspace_id}
        
        [red]You may using an invalid token or the token is expired.[/red]
        [red]Please re-issue a new token and run `lep workspace login` again.[/red]
        """)
        sys.exit(1)


@lep.command()
@click.option(
    "--purge", is_flag=True, help="Purge the credentials of the lepton login info."
)
def logout(purge):
    """
    Logout of the DGX Cloud Lepton.
    """
    try:
        WorkspaceRecord.logout(purge=purge)
        console.print("[green]Logged out[/]")
    except RuntimeError as e:
        console.print(f"[yellow]{e}[/]")


def check_lepton_version():
    """Notify user if a newer leptonai release is available on PyPI."""

    from leptonai.config import VERSION_CHECK_FILE, VERSION_CHECK_INTERVAL_SEC

    interval_sec = VERSION_CHECK_INTERVAL_SEC
    cache_file: Path = VERSION_CHECK_FILE

    def _read_last() -> float:
        try:
            return float(cache_file.read_text()) if cache_file.exists() else 0.0
        except Exception:
            return 0.0

    def _write_now() -> None:
        try:
            cache_file.parent.mkdir(parents=True, exist_ok=True)
            cache_file.write_text(str(time.time()))
        except Exception:
            pass

    if time.time() - _read_last() < interval_sec:
        return

    # Local package version
    try:
        from importlib.metadata import version as _v

        local_ver = _v("leptonai")
    except Exception:
        local_ver = getattr(leptonai, "__version__", "0.0.0")

    # Remote latest version
    try:
        import requests

        resp = requests.get("https://pypi.org/pypi/leptonai/json", timeout=2)
        resp.raise_for_status()
        latest_ver = resp.json()["info"]["version"]
    except Exception:
        return  # silent if network / PyPI unreachable

    try:
        from packaging.version import Version

        logger.trace(f"Local version: {local_ver}, latest version: {latest_ver}")
        if Version(local_ver) < Version(latest_ver):
            console.print(
                f"[yellow]A newer version of leptonai ({latest_ver}) is available. You"
                f" are using {local_ver}. Run `pip install -U leptonai` to upgrade.[/]"
            )
    except Exception:
        pass

    _write_now()


if __name__ == "__main__":
    lep()
