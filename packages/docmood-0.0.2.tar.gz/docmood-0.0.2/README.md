## docmood

Minimal demo Python package that installs a CLI called `docmood`.

### Install

From PyPI:

```bash
python -m pip install docmood
```

### Usage

Run:

```bash
docmood
```

Or as a module:

```bash
python -m docmood
```

## Development

Development instructions live in `CONTRIBUTING.md`.
