__version__ = "0.0.2"

def hello() -> None:
    print("docmood: hello from the package v0.0.2!")

__all__ = ["__version__", "hello"]
