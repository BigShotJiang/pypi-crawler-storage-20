# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from limitry import Limitry, AsyncLimitry
from tests.utils import assert_matches_type
from limitry.types import (
    Quota,
    QuotaListResponse,
    QuotaCheckResponse,
    QuotaDeleteResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestQuotas:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: Limitry) -> None:
        quota = client.quotas.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Limitry) -> None:
        quota = client.quotas.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
            alert_thresholds=[1],
            dimension_filters={"foo": "string"},
            period_anchor_day=0,
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Limitry) -> None:
        response = client.quotas.with_raw_response.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = response.parse()
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Limitry) -> None:
        with client.quotas.with_streaming_response.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = response.parse()
            assert_matches_type(Quota, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Limitry) -> None:
        quota = client.quotas.retrieve(
            "id",
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Limitry) -> None:
        response = client.quotas.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = response.parse()
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Limitry) -> None:
        with client.quotas.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = response.parse()
            assert_matches_type(Quota, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.quotas.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: Limitry) -> None:
        quota = client.quotas.update(
            id="id",
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Limitry) -> None:
        quota = client.quotas.update(
            id="id",
            alert_thresholds=[1],
            dimension_filters={"foo": "string"},
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
            period_anchor_day=0,
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Limitry) -> None:
        response = client.quotas.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = response.parse()
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Limitry) -> None:
        with client.quotas.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = response.parse()
            assert_matches_type(Quota, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.quotas.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: Limitry) -> None:
        quota = client.quotas.list()
        assert_matches_type(QuotaListResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Limitry) -> None:
        quota = client.quotas.list(
            cursor="cursor",
            limit=1,
        )
        assert_matches_type(QuotaListResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Limitry) -> None:
        response = client.quotas.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = response.parse()
        assert_matches_type(QuotaListResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Limitry) -> None:
        with client.quotas.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = response.parse()
            assert_matches_type(QuotaListResponse, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: Limitry) -> None:
        quota = client.quotas.delete(
            "id",
        )
        assert_matches_type(QuotaDeleteResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Limitry) -> None:
        response = client.quotas.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = response.parse()
        assert_matches_type(QuotaDeleteResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Limitry) -> None:
        with client.quotas.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = response.parse()
            assert_matches_type(QuotaDeleteResponse, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.quotas.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_check(self, client: Limitry) -> None:
        quota = client.quotas.check()
        assert_matches_type(QuotaCheckResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_check_with_all_params(self, client: Limitry) -> None:
        quota = client.quotas.check(
            body={"foo": "bar"},
        )
        assert_matches_type(QuotaCheckResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_check(self, client: Limitry) -> None:
        response = client.quotas.with_raw_response.check()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = response.parse()
        assert_matches_type(QuotaCheckResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_check(self, client: Limitry) -> None:
        with client.quotas.with_streaming_response.check() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = response.parse()
            assert_matches_type(QuotaCheckResponse, quota, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncQuotas:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
            alert_thresholds=[1],
            dimension_filters={"foo": "string"},
            period_anchor_day=0,
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLimitry) -> None:
        response = await async_client.quotas.with_raw_response.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = await response.parse()
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLimitry) -> None:
        async with async_client.quotas.with_streaming_response.create(
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = await response.parse()
            assert_matches_type(Quota, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.retrieve(
            "id",
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLimitry) -> None:
        response = await async_client.quotas.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = await response.parse()
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLimitry) -> None:
        async with async_client.quotas.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = await response.parse()
            assert_matches_type(Quota, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.quotas.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.update(
            id="id",
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.update(
            id="id",
            alert_thresholds=[1],
            dimension_filters={"foo": "string"},
            limit_value=1,
            metric="total_tokens",
            name="x",
            period="hour",
            period_anchor_day=0,
        )
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLimitry) -> None:
        response = await async_client.quotas.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = await response.parse()
        assert_matches_type(Quota, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLimitry) -> None:
        async with async_client.quotas.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = await response.parse()
            assert_matches_type(Quota, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.quotas.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.list()
        assert_matches_type(QuotaListResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.list(
            cursor="cursor",
            limit=1,
        )
        assert_matches_type(QuotaListResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLimitry) -> None:
        response = await async_client.quotas.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = await response.parse()
        assert_matches_type(QuotaListResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLimitry) -> None:
        async with async_client.quotas.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = await response.parse()
            assert_matches_type(QuotaListResponse, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.delete(
            "id",
        )
        assert_matches_type(QuotaDeleteResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncLimitry) -> None:
        response = await async_client.quotas.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = await response.parse()
        assert_matches_type(QuotaDeleteResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncLimitry) -> None:
        async with async_client.quotas.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = await response.parse()
            assert_matches_type(QuotaDeleteResponse, quota, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.quotas.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_check(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.check()
        assert_matches_type(QuotaCheckResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_check_with_all_params(self, async_client: AsyncLimitry) -> None:
        quota = await async_client.quotas.check(
            body={"foo": "bar"},
        )
        assert_matches_type(QuotaCheckResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_check(self, async_client: AsyncLimitry) -> None:
        response = await async_client.quotas.with_raw_response.check()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        quota = await response.parse()
        assert_matches_type(QuotaCheckResponse, quota, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_check(self, async_client: AsyncLimitry) -> None:
        async with async_client.quotas.with_streaming_response.check() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            quota = await response.parse()
            assert_matches_type(QuotaCheckResponse, quota, path=["response"])

        assert cast(Any, response.is_closed) is True
