# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Literal

import httpx

from ..types import rate_limit_list_params, rate_limit_check_params, rate_limit_create_params, rate_limit_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.rate_limit import RateLimit
from ..types.rate_limit_list_response import RateLimitListResponse
from ..types.rate_limit_check_response import RateLimitCheckResponse
from ..types.rate_limit_delete_response import RateLimitDeleteResponse

__all__ = ["RateLimitsResource", "AsyncRateLimitsResource"]


class RateLimitsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> RateLimitsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return RateLimitsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> RateLimitsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return RateLimitsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        limit_value: int,
        name: str,
        window: Literal["second", "minute", "hour"],
        dimension_filters: Dict[str, str] | Omit = omit,
        enabled: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimit:
        """
        Create a new rate limit with dimension filters.

        Rate limits control how many requests can be made within a time window. You can
        apply rate limits to specific customers, models, event types, or any combination
        using dimension filters.

        Args:
          limit_value: Maximum number of requests allowed in the time window

          name: Human-readable name for the rate limit

          window: Sliding time window for rate limit calculation: "second" = rolling 1s window,
              "minute" = rolling 60s window, "hour" = rolling 3600s window

          dimension_filters: Key-value pairs to filter or scope the rule. Keys must be alphanumeric with
              underscores (max 64 chars). Values are strings (max 256 chars).

          enabled: Whether the rate limit is enabled

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/rate-limits",
            body=maybe_transform(
                {
                    "limit_value": limit_value,
                    "name": name,
                    "window": window,
                    "dimension_filters": dimension_filters,
                    "enabled": enabled,
                },
                rate_limit_create_params.RateLimitCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimit,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimit:
        """
        Get a specific rate limit by ID.

        Args:
          id: Unique identifier for the rate limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/rate-limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimit,
        )

    def update(
        self,
        id: str,
        *,
        dimension_filters: Dict[str, str] | Omit = omit,
        enabled: bool | Omit = omit,
        limit_value: int | Omit = omit,
        name: str | Omit = omit,
        window: Literal["second", "minute", "hour"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimit:
        """
        Update an existing rate limit.

        Args:
          id: Unique identifier for the rate limit

          dimension_filters: Dimension filters that determine which requests match this rate limit

          enabled: Whether the rate limit is enabled

          limit_value: Maximum number of requests allowed in the time window

          name: Human-readable name for the rate limit

          window: Sliding time window for rate limit calculation: "second" = rolling 1s window,
              "minute" = rolling 60s window, "hour" = rolling 3600s window

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/rate-limits/{id}",
            body=maybe_transform(
                {
                    "dimension_filters": dimension_filters,
                    "enabled": enabled,
                    "limit_value": limit_value,
                    "name": name,
                    "window": window,
                },
                rate_limit_update_params.RateLimitUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimit,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimitListResponse:
        """
        List all rate limits for the project.

        Args:
          cursor: Pagination cursor from the previous response

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/rate-limits",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    rate_limit_list_params.RateLimitListParams,
                ),
            ),
            cast_to=RateLimitListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimitDeleteResponse:
        """
        Delete a rate limit by ID.

        Args:
          id: Unique identifier for the rate limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._delete(
            f"/rate-limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimitDeleteResponse,
        )

    def check(
        self,
        *,
        body: Dict[str, Optional[object]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimitCheckResponse:
        """
        Check current rate limit status for the given dimensions without consuming a
        request.

        This endpoint allows you to query rate limit status without actually counting
        against the limit. Useful for:

        - Pre-flight checks before processing requests
        - Displaying rate limit status to users
        - Monitoring rate limit consumption

        **Dimension Matching:** Rate limits are matched based on dimension filters. Pass
        dimensions like:

        - `customer_id`: Filter by customer
        - `event_type`: Filter by event type
        - `model`: Filter by model
        - `provider`: Filter by provider
        - Any custom dimension from event properties

        Args:
          body: Dimensions object for rate limit matching (e.g., {"customer_id": "cust_123"})

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/rate-limits/check",
            body=maybe_transform(body, rate_limit_check_params.RateLimitCheckParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimitCheckResponse,
        )


class AsyncRateLimitsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncRateLimitsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncRateLimitsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncRateLimitsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncRateLimitsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        limit_value: int,
        name: str,
        window: Literal["second", "minute", "hour"],
        dimension_filters: Dict[str, str] | Omit = omit,
        enabled: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimit:
        """
        Create a new rate limit with dimension filters.

        Rate limits control how many requests can be made within a time window. You can
        apply rate limits to specific customers, models, event types, or any combination
        using dimension filters.

        Args:
          limit_value: Maximum number of requests allowed in the time window

          name: Human-readable name for the rate limit

          window: Sliding time window for rate limit calculation: "second" = rolling 1s window,
              "minute" = rolling 60s window, "hour" = rolling 3600s window

          dimension_filters: Key-value pairs to filter or scope the rule. Keys must be alphanumeric with
              underscores (max 64 chars). Values are strings (max 256 chars).

          enabled: Whether the rate limit is enabled

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/rate-limits",
            body=await async_maybe_transform(
                {
                    "limit_value": limit_value,
                    "name": name,
                    "window": window,
                    "dimension_filters": dimension_filters,
                    "enabled": enabled,
                },
                rate_limit_create_params.RateLimitCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimit,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimit:
        """
        Get a specific rate limit by ID.

        Args:
          id: Unique identifier for the rate limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/rate-limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimit,
        )

    async def update(
        self,
        id: str,
        *,
        dimension_filters: Dict[str, str] | Omit = omit,
        enabled: bool | Omit = omit,
        limit_value: int | Omit = omit,
        name: str | Omit = omit,
        window: Literal["second", "minute", "hour"] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimit:
        """
        Update an existing rate limit.

        Args:
          id: Unique identifier for the rate limit

          dimension_filters: Dimension filters that determine which requests match this rate limit

          enabled: Whether the rate limit is enabled

          limit_value: Maximum number of requests allowed in the time window

          name: Human-readable name for the rate limit

          window: Sliding time window for rate limit calculation: "second" = rolling 1s window,
              "minute" = rolling 60s window, "hour" = rolling 3600s window

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/rate-limits/{id}",
            body=await async_maybe_transform(
                {
                    "dimension_filters": dimension_filters,
                    "enabled": enabled,
                    "limit_value": limit_value,
                    "name": name,
                    "window": window,
                },
                rate_limit_update_params.RateLimitUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimit,
        )

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimitListResponse:
        """
        List all rate limits for the project.

        Args:
          cursor: Pagination cursor from the previous response

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/rate-limits",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    rate_limit_list_params.RateLimitListParams,
                ),
            ),
            cast_to=RateLimitListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimitDeleteResponse:
        """
        Delete a rate limit by ID.

        Args:
          id: Unique identifier for the rate limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._delete(
            f"/rate-limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimitDeleteResponse,
        )

    async def check(
        self,
        *,
        body: Dict[str, Optional[object]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> RateLimitCheckResponse:
        """
        Check current rate limit status for the given dimensions without consuming a
        request.

        This endpoint allows you to query rate limit status without actually counting
        against the limit. Useful for:

        - Pre-flight checks before processing requests
        - Displaying rate limit status to users
        - Monitoring rate limit consumption

        **Dimension Matching:** Rate limits are matched based on dimension filters. Pass
        dimensions like:

        - `customer_id`: Filter by customer
        - `event_type`: Filter by event type
        - `model`: Filter by model
        - `provider`: Filter by provider
        - Any custom dimension from event properties

        Args:
          body: Dimensions object for rate limit matching (e.g., {"customer_id": "cust_123"})

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/rate-limits/check",
            body=await async_maybe_transform(body, rate_limit_check_params.RateLimitCheckParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=RateLimitCheckResponse,
        )


class RateLimitsResourceWithRawResponse:
    def __init__(self, rate_limits: RateLimitsResource) -> None:
        self._rate_limits = rate_limits

        self.create = to_raw_response_wrapper(
            rate_limits.create,
        )
        self.retrieve = to_raw_response_wrapper(
            rate_limits.retrieve,
        )
        self.update = to_raw_response_wrapper(
            rate_limits.update,
        )
        self.list = to_raw_response_wrapper(
            rate_limits.list,
        )
        self.delete = to_raw_response_wrapper(
            rate_limits.delete,
        )
        self.check = to_raw_response_wrapper(
            rate_limits.check,
        )


class AsyncRateLimitsResourceWithRawResponse:
    def __init__(self, rate_limits: AsyncRateLimitsResource) -> None:
        self._rate_limits = rate_limits

        self.create = async_to_raw_response_wrapper(
            rate_limits.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            rate_limits.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            rate_limits.update,
        )
        self.list = async_to_raw_response_wrapper(
            rate_limits.list,
        )
        self.delete = async_to_raw_response_wrapper(
            rate_limits.delete,
        )
        self.check = async_to_raw_response_wrapper(
            rate_limits.check,
        )


class RateLimitsResourceWithStreamingResponse:
    def __init__(self, rate_limits: RateLimitsResource) -> None:
        self._rate_limits = rate_limits

        self.create = to_streamed_response_wrapper(
            rate_limits.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            rate_limits.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            rate_limits.update,
        )
        self.list = to_streamed_response_wrapper(
            rate_limits.list,
        )
        self.delete = to_streamed_response_wrapper(
            rate_limits.delete,
        )
        self.check = to_streamed_response_wrapper(
            rate_limits.check,
        )


class AsyncRateLimitsResourceWithStreamingResponse:
    def __init__(self, rate_limits: AsyncRateLimitsResource) -> None:
        self._rate_limits = rate_limits

        self.create = async_to_streamed_response_wrapper(
            rate_limits.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            rate_limits.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            rate_limits.update,
        )
        self.list = async_to_streamed_response_wrapper(
            rate_limits.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            rate_limits.delete,
        )
        self.check = async_to_streamed_response_wrapper(
            rate_limits.check,
        )
