# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import (
    usage_list_params,
    usage_check_usage_params,
    usage_get_summary_params,
    usage_batch_record_params,
    usage_record_usage_params,
    usage_get_breakdown_params,
    usage_get_timeseries_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.usage_list_response import UsageListResponse
from ..types.usage_check_usage_response import UsageCheckUsageResponse
from ..types.usage_get_summary_response import UsageGetSummaryResponse
from ..types.usage_batch_record_response import UsageBatchRecordResponse
from ..types.usage_record_usage_response import UsageRecordUsageResponse
from ..types.usage_get_breakdown_response import UsageGetBreakdownResponse
from ..types.usage_get_timeseries_response import UsageGetTimeseriesResponse

__all__ = ["UsageResource", "AsyncUsageResource"]


class UsageResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> UsageResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return UsageResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> UsageResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return UsageResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        limit: int | Omit = omit,
        model: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageListResponse:
        """
        Retrieve a paginated list of usage events with optional filtering.

        Use cursor-based pagination by passing the `nextCursor` from the previous
        response. You can filter events by customer, event type, or model.

        **Pagination:**

        - Use the `cursor` parameter from the previous response's `nextCursor` field
        - The `hasMore` field indicates if there are more results
        - Maximum limit is 100 events per request

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter events by customer ID

          event_type: Filter events by type (e.g., "chat_completion", "embedding")

          limit: Maximum number of items to return (1-100, default: 50)

          model: Filter events by model name (e.g., "gpt-4", "claude-3")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/usage",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "limit": limit,
                        "model": model,
                    },
                    usage_list_params.UsageListParams,
                ),
            ),
            cast_to=UsageListResponse,
        )

    def batch_record(
        self,
        *,
        events: Iterable[usage_batch_record_params.Event],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageBatchRecordResponse:
        """
        Record multiple usage events in a single request for efficient bulk ingestion.

        **Idempotency:** Send an `Idempotency-Key` header with a unique value (e.g.,
        UUID) to ensure duplicate requests return the same response. Keys are valid for
        24 hours.

        **Limits:**

        - Maximum 1000 events per batch
        - All events must be valid or the entire batch will be rejected

        **Use cases:**

        - Bulk import of historical data
        - Batch processing of events
        - Migrating data from other systems

        For real-time usage tracking with enforcement, use `POST /v1/usage/check` and
        `POST /v1/usage/record` instead.

        Args:
          events: Array of events to ingest (max 1000)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/usage/batch",
            body=maybe_transform({"events": events}, usage_batch_record_params.UsageBatchRecordParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UsageBatchRecordResponse,
        )

    def check_usage(
        self,
        *,
        customer_id: str,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageCheckUsageResponse:
        """
        Pre-flight check to determine if a request should be allowed based on rate
        limits and quotas.

        **Call this BEFORE making your LLM/AI call** to enforce limits and prevent
        overages.

        **Important:** This endpoint performs rate limit enforcement - calling it
        increments the rate limit counter. Only call it when you intend to proceed with
        the actual operation if allowed.

        **Two-Call Pattern:**

        1. Call `POST /usage/check` before your AI operation
        2. If `allowed: true`, proceed with your AI call
        3. Call `POST /usage/record` after to log actual token usage

        **Returns:**

        - `allowed: true` with 200 status if the request can proceed
        - `allowed: false` with 429 status if a rate limit or quota is exceeded

        Args:
          customer_id: Customer ID to check limits for

          event_type: Event type dimension for filtering

          model: Model dimension for filtering

          provider: Provider dimension for filtering

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/usage/check",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "event_type": event_type,
                    "model": model,
                    "provider": provider,
                },
                usage_check_usage_params.UsageCheckUsageParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UsageCheckUsageResponse,
        )

    def get_breakdown(
        self,
        *,
        end_date: Union[str, datetime],
        group_by: Literal["model", "customer_id", "event_type", "provider"],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageGetBreakdownResponse:
        """
        Retrieve usage metrics grouped by a specific dimension.

        This endpoint provides detailed breakdowns of usage data, allowing you to see
        how usage is distributed across different dimensions like models, customers,
        event types, or providers.

        **Use Cases:**

        - See which models consume the most tokens
        - Identify top customers by usage
        - Compare usage across different event types
        - Analyze provider-specific consumption

        Args:
          end_date: End of the date range (ISO 8601 format)

          group_by: Dimension to group usage by

          start_date: Start of the date range (ISO 8601 format)

          customer_id: Filter usage by customer ID before grouping

          event_type: Filter usage by event type before grouping

          model: Filter usage by model name before grouping

          provider: Filter usage by provider before grouping (e.g., "openai", "anthropic")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/usage/breakdown",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "group_by": group_by,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "model": model,
                        "provider": provider,
                    },
                    usage_get_breakdown_params.UsageGetBreakdownParams,
                ),
            ),
            cast_to=UsageGetBreakdownResponse,
        )

    def get_summary(
        self,
        *,
        end_date: Union[str, datetime],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageGetSummaryResponse:
        """
        Retrieve aggregated usage metrics for the project.

        Returns totals for events, tokens, and costs within the specified date range.
        You can filter by customer, event type, or model to get specific subsets of
        data.

        **Metrics Included:**

        - Total events count
        - Total tokens (input + output)
        - Total input tokens
        - Total output tokens
        - Total cost in cents

        Args:
          end_date: End of the date range (ISO 8601 format)

          start_date: Start of the date range (ISO 8601 format)

          customer_id: Filter usage by customer ID

          event_type: Filter usage by event type (e.g., "model_call", "embedding")

          model: Filter usage by model name (e.g., "gpt-4", "claude-3")

          provider: Filter usage by provider (e.g., "openai", "anthropic")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/usage/summary",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "model": model,
                        "provider": provider,
                    },
                    usage_get_summary_params.UsageGetSummaryParams,
                ),
            ),
            cast_to=UsageGetSummaryResponse,
        )

    def get_timeseries(
        self,
        *,
        end_date: Union[str, datetime],
        interval: Literal["hour", "day", "week"],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageGetTimeseriesResponse:
        """
        Retrieve usage metrics bucketed by time interval.

        Returns time-series data showing how usage changes over time. Useful for
        creating charts, identifying trends, and monitoring usage patterns.

        **Intervals:**

        - `hour`: Bucket data by hour
        - `day`: Bucket data by day
        - `week`: Bucket data by week

        Each data point includes the timestamp and all usage metrics for that time
        period.

        Args:
          end_date: End of the date range (ISO 8601 format)

          interval: Time interval for bucketing data

          start_date: Start of the date range (ISO 8601 format)

          customer_id: Filter usage by customer ID

          event_type: Filter usage by event type

          model: Filter usage by model name

          provider: Filter usage by provider (e.g., "openai", "anthropic")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/usage/timeseries",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "interval": interval,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "model": model,
                        "provider": provider,
                    },
                    usage_get_timeseries_params.UsageGetTimeseriesParams,
                ),
            ),
            cast_to=UsageGetTimeseriesResponse,
        )

    def record_usage(
        self,
        *,
        customer_id: str,
        event_type: str,
        cost_cents: float | Omit = omit,
        input_tokens: int | Omit = omit,
        latency_ms: int | Omit = omit,
        model: str | Omit = omit,
        output_tokens: int | Omit = omit,
        properties: Dict[str, Optional[object]] | Omit = omit,
        provider: str | Omit = omit,
        timestamp: Union[str, datetime] | Omit = omit,
        total_tokens: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageRecordUsageResponse:
        """
        Record actual usage after an operation completes.

        **Call this AFTER your LLM/AI call** to log the actual token consumption and
        costs.

        **Two-Call Pattern:**

        1. Call `POST /usage/check` before your AI operation
        2. If `allowed: true`, proceed with your AI call
        3. Call `POST /usage/record` after to log actual token usage

        The recorded data is used for:

        - Quota tracking (e.g., daily token limits)
        - Usage analytics and reporting
        - Cost monitoring
        - Customer billing

        **Idempotency:** This endpoint supports idempotency keys via the
        `Idempotency-Key` header to prevent duplicate recordings.

        Args:
          customer_id: Customer ID that generated the usage

          event_type: Type of event (e.g., "chat_completion", "embedding")

          cost_cents: Cost in cents

          input_tokens: Number of input/prompt tokens

          latency_ms: Latency in milliseconds

          model: Model used (e.g., "gpt-4", "claude-3")

          output_tokens: Number of output/completion tokens

          properties: Additional custom properties

          provider: Provider (e.g., "openai", "anthropic")

          timestamp: Event timestamp (defaults to now)

          total_tokens: Total tokens (if not providing input/output separately)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/usage/record",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "event_type": event_type,
                    "cost_cents": cost_cents,
                    "input_tokens": input_tokens,
                    "latency_ms": latency_ms,
                    "model": model,
                    "output_tokens": output_tokens,
                    "properties": properties,
                    "provider": provider,
                    "timestamp": timestamp,
                    "total_tokens": total_tokens,
                },
                usage_record_usage_params.UsageRecordUsageParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UsageRecordUsageResponse,
        )


class AsyncUsageResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncUsageResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncUsageResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncUsageResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncUsageResourceWithStreamingResponse(self)

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        limit: int | Omit = omit,
        model: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageListResponse:
        """
        Retrieve a paginated list of usage events with optional filtering.

        Use cursor-based pagination by passing the `nextCursor` from the previous
        response. You can filter events by customer, event type, or model.

        **Pagination:**

        - Use the `cursor` parameter from the previous response's `nextCursor` field
        - The `hasMore` field indicates if there are more results
        - Maximum limit is 100 events per request

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter events by customer ID

          event_type: Filter events by type (e.g., "chat_completion", "embedding")

          limit: Maximum number of items to return (1-100, default: 50)

          model: Filter events by model name (e.g., "gpt-4", "claude-3")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/usage",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "limit": limit,
                        "model": model,
                    },
                    usage_list_params.UsageListParams,
                ),
            ),
            cast_to=UsageListResponse,
        )

    async def batch_record(
        self,
        *,
        events: Iterable[usage_batch_record_params.Event],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageBatchRecordResponse:
        """
        Record multiple usage events in a single request for efficient bulk ingestion.

        **Idempotency:** Send an `Idempotency-Key` header with a unique value (e.g.,
        UUID) to ensure duplicate requests return the same response. Keys are valid for
        24 hours.

        **Limits:**

        - Maximum 1000 events per batch
        - All events must be valid or the entire batch will be rejected

        **Use cases:**

        - Bulk import of historical data
        - Batch processing of events
        - Migrating data from other systems

        For real-time usage tracking with enforcement, use `POST /v1/usage/check` and
        `POST /v1/usage/record` instead.

        Args:
          events: Array of events to ingest (max 1000)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/usage/batch",
            body=await async_maybe_transform({"events": events}, usage_batch_record_params.UsageBatchRecordParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UsageBatchRecordResponse,
        )

    async def check_usage(
        self,
        *,
        customer_id: str,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageCheckUsageResponse:
        """
        Pre-flight check to determine if a request should be allowed based on rate
        limits and quotas.

        **Call this BEFORE making your LLM/AI call** to enforce limits and prevent
        overages.

        **Important:** This endpoint performs rate limit enforcement - calling it
        increments the rate limit counter. Only call it when you intend to proceed with
        the actual operation if allowed.

        **Two-Call Pattern:**

        1. Call `POST /usage/check` before your AI operation
        2. If `allowed: true`, proceed with your AI call
        3. Call `POST /usage/record` after to log actual token usage

        **Returns:**

        - `allowed: true` with 200 status if the request can proceed
        - `allowed: false` with 429 status if a rate limit or quota is exceeded

        Args:
          customer_id: Customer ID to check limits for

          event_type: Event type dimension for filtering

          model: Model dimension for filtering

          provider: Provider dimension for filtering

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/usage/check",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "event_type": event_type,
                    "model": model,
                    "provider": provider,
                },
                usage_check_usage_params.UsageCheckUsageParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UsageCheckUsageResponse,
        )

    async def get_breakdown(
        self,
        *,
        end_date: Union[str, datetime],
        group_by: Literal["model", "customer_id", "event_type", "provider"],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageGetBreakdownResponse:
        """
        Retrieve usage metrics grouped by a specific dimension.

        This endpoint provides detailed breakdowns of usage data, allowing you to see
        how usage is distributed across different dimensions like models, customers,
        event types, or providers.

        **Use Cases:**

        - See which models consume the most tokens
        - Identify top customers by usage
        - Compare usage across different event types
        - Analyze provider-specific consumption

        Args:
          end_date: End of the date range (ISO 8601 format)

          group_by: Dimension to group usage by

          start_date: Start of the date range (ISO 8601 format)

          customer_id: Filter usage by customer ID before grouping

          event_type: Filter usage by event type before grouping

          model: Filter usage by model name before grouping

          provider: Filter usage by provider before grouping (e.g., "openai", "anthropic")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/usage/breakdown",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "group_by": group_by,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "model": model,
                        "provider": provider,
                    },
                    usage_get_breakdown_params.UsageGetBreakdownParams,
                ),
            ),
            cast_to=UsageGetBreakdownResponse,
        )

    async def get_summary(
        self,
        *,
        end_date: Union[str, datetime],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageGetSummaryResponse:
        """
        Retrieve aggregated usage metrics for the project.

        Returns totals for events, tokens, and costs within the specified date range.
        You can filter by customer, event type, or model to get specific subsets of
        data.

        **Metrics Included:**

        - Total events count
        - Total tokens (input + output)
        - Total input tokens
        - Total output tokens
        - Total cost in cents

        Args:
          end_date: End of the date range (ISO 8601 format)

          start_date: Start of the date range (ISO 8601 format)

          customer_id: Filter usage by customer ID

          event_type: Filter usage by event type (e.g., "model_call", "embedding")

          model: Filter usage by model name (e.g., "gpt-4", "claude-3")

          provider: Filter usage by provider (e.g., "openai", "anthropic")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/usage/summary",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "model": model,
                        "provider": provider,
                    },
                    usage_get_summary_params.UsageGetSummaryParams,
                ),
            ),
            cast_to=UsageGetSummaryResponse,
        )

    async def get_timeseries(
        self,
        *,
        end_date: Union[str, datetime],
        interval: Literal["hour", "day", "week"],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        model: str | Omit = omit,
        provider: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageGetTimeseriesResponse:
        """
        Retrieve usage metrics bucketed by time interval.

        Returns time-series data showing how usage changes over time. Useful for
        creating charts, identifying trends, and monitoring usage patterns.

        **Intervals:**

        - `hour`: Bucket data by hour
        - `day`: Bucket data by day
        - `week`: Bucket data by week

        Each data point includes the timestamp and all usage metrics for that time
        period.

        Args:
          end_date: End of the date range (ISO 8601 format)

          interval: Time interval for bucketing data

          start_date: Start of the date range (ISO 8601 format)

          customer_id: Filter usage by customer ID

          event_type: Filter usage by event type

          model: Filter usage by model name

          provider: Filter usage by provider (e.g., "openai", "anthropic")

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/usage/timeseries",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "interval": interval,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "model": model,
                        "provider": provider,
                    },
                    usage_get_timeseries_params.UsageGetTimeseriesParams,
                ),
            ),
            cast_to=UsageGetTimeseriesResponse,
        )

    async def record_usage(
        self,
        *,
        customer_id: str,
        event_type: str,
        cost_cents: float | Omit = omit,
        input_tokens: int | Omit = omit,
        latency_ms: int | Omit = omit,
        model: str | Omit = omit,
        output_tokens: int | Omit = omit,
        properties: Dict[str, Optional[object]] | Omit = omit,
        provider: str | Omit = omit,
        timestamp: Union[str, datetime] | Omit = omit,
        total_tokens: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> UsageRecordUsageResponse:
        """
        Record actual usage after an operation completes.

        **Call this AFTER your LLM/AI call** to log the actual token consumption and
        costs.

        **Two-Call Pattern:**

        1. Call `POST /usage/check` before your AI operation
        2. If `allowed: true`, proceed with your AI call
        3. Call `POST /usage/record` after to log actual token usage

        The recorded data is used for:

        - Quota tracking (e.g., daily token limits)
        - Usage analytics and reporting
        - Cost monitoring
        - Customer billing

        **Idempotency:** This endpoint supports idempotency keys via the
        `Idempotency-Key` header to prevent duplicate recordings.

        Args:
          customer_id: Customer ID that generated the usage

          event_type: Type of event (e.g., "chat_completion", "embedding")

          cost_cents: Cost in cents

          input_tokens: Number of input/prompt tokens

          latency_ms: Latency in milliseconds

          model: Model used (e.g., "gpt-4", "claude-3")

          output_tokens: Number of output/completion tokens

          properties: Additional custom properties

          provider: Provider (e.g., "openai", "anthropic")

          timestamp: Event timestamp (defaults to now)

          total_tokens: Total tokens (if not providing input/output separately)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/usage/record",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "event_type": event_type,
                    "cost_cents": cost_cents,
                    "input_tokens": input_tokens,
                    "latency_ms": latency_ms,
                    "model": model,
                    "output_tokens": output_tokens,
                    "properties": properties,
                    "provider": provider,
                    "timestamp": timestamp,
                    "total_tokens": total_tokens,
                },
                usage_record_usage_params.UsageRecordUsageParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=UsageRecordUsageResponse,
        )


class UsageResourceWithRawResponse:
    def __init__(self, usage: UsageResource) -> None:
        self._usage = usage

        self.list = to_raw_response_wrapper(
            usage.list,
        )
        self.batch_record = to_raw_response_wrapper(
            usage.batch_record,
        )
        self.check_usage = to_raw_response_wrapper(
            usage.check_usage,
        )
        self.get_breakdown = to_raw_response_wrapper(
            usage.get_breakdown,
        )
        self.get_summary = to_raw_response_wrapper(
            usage.get_summary,
        )
        self.get_timeseries = to_raw_response_wrapper(
            usage.get_timeseries,
        )
        self.record_usage = to_raw_response_wrapper(
            usage.record_usage,
        )


class AsyncUsageResourceWithRawResponse:
    def __init__(self, usage: AsyncUsageResource) -> None:
        self._usage = usage

        self.list = async_to_raw_response_wrapper(
            usage.list,
        )
        self.batch_record = async_to_raw_response_wrapper(
            usage.batch_record,
        )
        self.check_usage = async_to_raw_response_wrapper(
            usage.check_usage,
        )
        self.get_breakdown = async_to_raw_response_wrapper(
            usage.get_breakdown,
        )
        self.get_summary = async_to_raw_response_wrapper(
            usage.get_summary,
        )
        self.get_timeseries = async_to_raw_response_wrapper(
            usage.get_timeseries,
        )
        self.record_usage = async_to_raw_response_wrapper(
            usage.record_usage,
        )


class UsageResourceWithStreamingResponse:
    def __init__(self, usage: UsageResource) -> None:
        self._usage = usage

        self.list = to_streamed_response_wrapper(
            usage.list,
        )
        self.batch_record = to_streamed_response_wrapper(
            usage.batch_record,
        )
        self.check_usage = to_streamed_response_wrapper(
            usage.check_usage,
        )
        self.get_breakdown = to_streamed_response_wrapper(
            usage.get_breakdown,
        )
        self.get_summary = to_streamed_response_wrapper(
            usage.get_summary,
        )
        self.get_timeseries = to_streamed_response_wrapper(
            usage.get_timeseries,
        )
        self.record_usage = to_streamed_response_wrapper(
            usage.record_usage,
        )


class AsyncUsageResourceWithStreamingResponse:
    def __init__(self, usage: AsyncUsageResource) -> None:
        self._usage = usage

        self.list = async_to_streamed_response_wrapper(
            usage.list,
        )
        self.batch_record = async_to_streamed_response_wrapper(
            usage.batch_record,
        )
        self.check_usage = async_to_streamed_response_wrapper(
            usage.check_usage,
        )
        self.get_breakdown = async_to_streamed_response_wrapper(
            usage.get_breakdown,
        )
        self.get_summary = async_to_streamed_response_wrapper(
            usage.get_summary,
        )
        self.get_timeseries = async_to_streamed_response_wrapper(
            usage.get_timeseries,
        )
        self.record_usage = async_to_streamed_response_wrapper(
            usage.record_usage,
        )
