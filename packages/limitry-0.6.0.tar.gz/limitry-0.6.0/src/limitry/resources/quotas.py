# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal

import httpx

from ..types import quota_list_params, quota_check_params, quota_create_params, quota_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..types.quota import Quota
from .._base_client import make_request_options
from ..types.quota_list_response import QuotaListResponse
from ..types.quota_check_response import QuotaCheckResponse
from ..types.quota_delete_response import QuotaDeleteResponse

__all__ = ["QuotasResource", "AsyncQuotasResource"]


class QuotasResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> QuotasResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return QuotasResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> QuotasResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return QuotasResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        limit_value: int,
        metric: Literal["total_tokens", "total_events", "total_cost_cents"],
        name: str,
        period: Literal["hour", "day", "week", "month"],
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Quota:
        """
        Create a new usage quota with dimension filters.

        Quotas allow you to limit usage based on metrics like total tokens, cost, or
        event count. You can apply quotas to specific customers, models, event types, or
        any combination using dimension filters.

        Args:
          limit_value: Quota limit value

          metric: Metric being tracked

          name: Human-readable name for the quota

          period: Time period for the quota

          alert_thresholds: Alert thresholds as percentages (e.g., [80, 100]). Null or omitted means inherit
              from project defaults. Empty array disables alerts.

          dimension_filters: Key-value pairs to filter or scope the rule. Keys must be alphanumeric with
              underscores (max 64 chars). Values are strings (max 256 chars).

          period_anchor_day: Period anchor day. For monthly: 1-31 (day of month to reset). For weekly: 0-6
              (0=Sunday, 1=Monday, ...). Null or omitted uses defaults (1st for monthly,
              Monday for weekly).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/quotas",
            body=maybe_transform(
                {
                    "limit_value": limit_value,
                    "metric": metric,
                    "name": name,
                    "period": period,
                    "alert_thresholds": alert_thresholds,
                    "dimension_filters": dimension_filters,
                    "period_anchor_day": period_anchor_day,
                },
                quota_create_params.QuotaCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Quota,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Quota:
        """
        Get a specific quota by ID.

        Args:
          id: Unique identifier for the quota

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/quotas/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Quota,
        )

    def update(
        self,
        id: str,
        *,
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        limit_value: int | Omit = omit,
        metric: Literal["total_tokens", "total_events", "total_cost_cents"] | Omit = omit,
        name: str | Omit = omit,
        period: Literal["hour", "day", "week", "month"] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Quota:
        """
        Update an existing quota.

        Args:
          id: Unique identifier for the quota

          alert_thresholds: Alert thresholds as percentages. Null means inherit from project defaults. Empty
              array disables alerts.

          dimension_filters: Dimension filters that determine which events match this quota

          limit_value: Quota limit value

          metric: Metric being tracked

          name: Human-readable name for the quota

          period: Time period for the quota

          period_anchor_day: Period anchor day. For monthly: 1-31. For weekly: 0-6. Null resets to default.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/quotas/{id}",
            body=maybe_transform(
                {
                    "alert_thresholds": alert_thresholds,
                    "dimension_filters": dimension_filters,
                    "limit_value": limit_value,
                    "metric": metric,
                    "name": name,
                    "period": period,
                    "period_anchor_day": period_anchor_day,
                },
                quota_update_params.QuotaUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Quota,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuotaListResponse:
        """
        List all quotas for the project.

        Args:
          cursor: Pagination cursor from the previous response

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/quotas",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    quota_list_params.QuotaListParams,
                ),
            ),
            cast_to=QuotaListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuotaDeleteResponse:
        """
        Delete a quota by ID.

        Args:
          id: Unique identifier for the quota

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._delete(
            f"/quotas/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuotaDeleteResponse,
        )

    def check(
        self,
        *,
        body: Dict[str, Optional[object]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuotaCheckResponse:
        """
        Check usage against all matching quotas for the given dimensions without
        consuming quota.

        This endpoint allows you to query quota status without actually recording usage.
        Useful for:

        - Pre-flight checks before processing requests
        - Displaying quota status to users
        - Monitoring quota consumption

        **Dimension Matching:** Quotas are matched based on dimension filters. Pass
        dimensions like:

        - `customer_id`: Filter by customer
        - `event_type`: Filter by event type
        - `model`: Filter by model
        - `provider`: Filter by provider
        - Any custom dimension from event properties

        Args:
          body:
              Dimensions object for quota matching (e.g., {"customer_id": "cust_123", "model":
              "gpt-4"})

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/quotas/check",
            body=maybe_transform(body, quota_check_params.QuotaCheckParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuotaCheckResponse,
        )


class AsyncQuotasResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncQuotasResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncQuotasResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncQuotasResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncQuotasResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        limit_value: int,
        metric: Literal["total_tokens", "total_events", "total_cost_cents"],
        name: str,
        period: Literal["hour", "day", "week", "month"],
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Quota:
        """
        Create a new usage quota with dimension filters.

        Quotas allow you to limit usage based on metrics like total tokens, cost, or
        event count. You can apply quotas to specific customers, models, event types, or
        any combination using dimension filters.

        Args:
          limit_value: Quota limit value

          metric: Metric being tracked

          name: Human-readable name for the quota

          period: Time period for the quota

          alert_thresholds: Alert thresholds as percentages (e.g., [80, 100]). Null or omitted means inherit
              from project defaults. Empty array disables alerts.

          dimension_filters: Key-value pairs to filter or scope the rule. Keys must be alphanumeric with
              underscores (max 64 chars). Values are strings (max 256 chars).

          period_anchor_day: Period anchor day. For monthly: 1-31 (day of month to reset). For weekly: 0-6
              (0=Sunday, 1=Monday, ...). Null or omitted uses defaults (1st for monthly,
              Monday for weekly).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/quotas",
            body=await async_maybe_transform(
                {
                    "limit_value": limit_value,
                    "metric": metric,
                    "name": name,
                    "period": period,
                    "alert_thresholds": alert_thresholds,
                    "dimension_filters": dimension_filters,
                    "period_anchor_day": period_anchor_day,
                },
                quota_create_params.QuotaCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Quota,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Quota:
        """
        Get a specific quota by ID.

        Args:
          id: Unique identifier for the quota

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/quotas/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Quota,
        )

    async def update(
        self,
        id: str,
        *,
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        limit_value: int | Omit = omit,
        metric: Literal["total_tokens", "total_events", "total_cost_cents"] | Omit = omit,
        name: str | Omit = omit,
        period: Literal["hour", "day", "week", "month"] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Quota:
        """
        Update an existing quota.

        Args:
          id: Unique identifier for the quota

          alert_thresholds: Alert thresholds as percentages. Null means inherit from project defaults. Empty
              array disables alerts.

          dimension_filters: Dimension filters that determine which events match this quota

          limit_value: Quota limit value

          metric: Metric being tracked

          name: Human-readable name for the quota

          period: Time period for the quota

          period_anchor_day: Period anchor day. For monthly: 1-31. For weekly: 0-6. Null resets to default.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/quotas/{id}",
            body=await async_maybe_transform(
                {
                    "alert_thresholds": alert_thresholds,
                    "dimension_filters": dimension_filters,
                    "limit_value": limit_value,
                    "metric": metric,
                    "name": name,
                    "period": period,
                    "period_anchor_day": period_anchor_day,
                },
                quota_update_params.QuotaUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Quota,
        )

    async def list(
        self,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuotaListResponse:
        """
        List all quotas for the project.

        Args:
          cursor: Pagination cursor from the previous response

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/quotas",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    quota_list_params.QuotaListParams,
                ),
            ),
            cast_to=QuotaListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuotaDeleteResponse:
        """
        Delete a quota by ID.

        Args:
          id: Unique identifier for the quota

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._delete(
            f"/quotas/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuotaDeleteResponse,
        )

    async def check(
        self,
        *,
        body: Dict[str, Optional[object]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> QuotaCheckResponse:
        """
        Check usage against all matching quotas for the given dimensions without
        consuming quota.

        This endpoint allows you to query quota status without actually recording usage.
        Useful for:

        - Pre-flight checks before processing requests
        - Displaying quota status to users
        - Monitoring quota consumption

        **Dimension Matching:** Quotas are matched based on dimension filters. Pass
        dimensions like:

        - `customer_id`: Filter by customer
        - `event_type`: Filter by event type
        - `model`: Filter by model
        - `provider`: Filter by provider
        - Any custom dimension from event properties

        Args:
          body:
              Dimensions object for quota matching (e.g., {"customer_id": "cust_123", "model":
              "gpt-4"})

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/quotas/check",
            body=await async_maybe_transform(body, quota_check_params.QuotaCheckParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=QuotaCheckResponse,
        )


class QuotasResourceWithRawResponse:
    def __init__(self, quotas: QuotasResource) -> None:
        self._quotas = quotas

        self.create = to_raw_response_wrapper(
            quotas.create,
        )
        self.retrieve = to_raw_response_wrapper(
            quotas.retrieve,
        )
        self.update = to_raw_response_wrapper(
            quotas.update,
        )
        self.list = to_raw_response_wrapper(
            quotas.list,
        )
        self.delete = to_raw_response_wrapper(
            quotas.delete,
        )
        self.check = to_raw_response_wrapper(
            quotas.check,
        )


class AsyncQuotasResourceWithRawResponse:
    def __init__(self, quotas: AsyncQuotasResource) -> None:
        self._quotas = quotas

        self.create = async_to_raw_response_wrapper(
            quotas.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            quotas.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            quotas.update,
        )
        self.list = async_to_raw_response_wrapper(
            quotas.list,
        )
        self.delete = async_to_raw_response_wrapper(
            quotas.delete,
        )
        self.check = async_to_raw_response_wrapper(
            quotas.check,
        )


class QuotasResourceWithStreamingResponse:
    def __init__(self, quotas: QuotasResource) -> None:
        self._quotas = quotas

        self.create = to_streamed_response_wrapper(
            quotas.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            quotas.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            quotas.update,
        )
        self.list = to_streamed_response_wrapper(
            quotas.list,
        )
        self.delete = to_streamed_response_wrapper(
            quotas.delete,
        )
        self.check = to_streamed_response_wrapper(
            quotas.check,
        )


class AsyncQuotasResourceWithStreamingResponse:
    def __init__(self, quotas: AsyncQuotasResource) -> None:
        self._quotas = quotas

        self.create = async_to_streamed_response_wrapper(
            quotas.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            quotas.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            quotas.update,
        )
        self.list = async_to_streamed_response_wrapper(
            quotas.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            quotas.delete,
        )
        self.check = async_to_streamed_response_wrapper(
            quotas.check,
        )
