# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import TypedDict

__all__ = ["QuotaCheckParams"]


class QuotaCheckParams(TypedDict, total=False):
    body: Dict[str, Optional[object]]
    """
    Dimensions object for quota matching (e.g., {"customer_id": "cust_123", "model":
    "gpt-4"})
    """
