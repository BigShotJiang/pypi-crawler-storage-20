# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["UsageGetTimeseriesResponse", "Data"]


class Data(BaseModel):
    timestamp: datetime
    """Timestamp for this data point"""

    total_cost_cents: float = FieldInfo(alias="totalCostCents")
    """Total cost in cents"""

    total_events: float = FieldInfo(alias="totalEvents")
    """Total events in this time bucket"""

    total_input_tokens: float = FieldInfo(alias="totalInputTokens")
    """Total input tokens"""

    total_output_tokens: float = FieldInfo(alias="totalOutputTokens")
    """Total output tokens"""

    total_tokens: float = FieldInfo(alias="totalTokens")
    """Total tokens in this time bucket"""


class UsageGetTimeseriesResponse(BaseModel):
    data: List[Data]
    """Array of usage data over time"""
