# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["UsageGetSummaryResponse"]


class UsageGetSummaryResponse(BaseModel):
    total_cost_cents: float = FieldInfo(alias="totalCostCents")
    """Total cost in cents across all events"""

    total_events: float = FieldInfo(alias="totalEvents")
    """Total number of events in the time range"""

    total_input_tokens: float = FieldInfo(alias="totalInputTokens")
    """Total input tokens consumed"""

    total_output_tokens: float = FieldInfo(alias="totalOutputTokens")
    """Total output tokens generated"""

    total_tokens: float = FieldInfo(alias="totalTokens")
    """Total tokens consumed across all events"""
