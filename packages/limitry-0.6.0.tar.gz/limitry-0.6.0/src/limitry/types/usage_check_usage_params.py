# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageCheckUsageParams"]


class UsageCheckUsageParams(TypedDict, total=False):
    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Customer ID to check limits for"""

    event_type: Annotated[str, PropertyInfo(alias="eventType")]
    """Event type dimension for filtering"""

    model: str
    """Model dimension for filtering"""

    provider: str
    """Provider dimension for filtering"""
