# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageGetSummaryParams"]


class UsageGetSummaryParams(TypedDict, total=False):
    end_date: Required[Annotated[Union[str, datetime], PropertyInfo(alias="endDate", format="iso8601")]]
    """End of the date range (ISO 8601 format)"""

    start_date: Required[Annotated[Union[str, datetime], PropertyInfo(alias="startDate", format="iso8601")]]
    """Start of the date range (ISO 8601 format)"""

    customer_id: Annotated[str, PropertyInfo(alias="customerId")]
    """Filter usage by customer ID"""

    event_type: Annotated[str, PropertyInfo(alias="eventType")]
    """Filter usage by event type (e.g., "model_call", "embedding")"""

    model: str
    """Filter usage by model name (e.g., "gpt-4", "claude-3")"""

    provider: str
    """Filter usage by provider (e.g., "openai", "anthropic")"""
