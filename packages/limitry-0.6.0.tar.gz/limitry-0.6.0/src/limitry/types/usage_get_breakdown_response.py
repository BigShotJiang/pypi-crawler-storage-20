# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["UsageGetBreakdownResponse", "Data"]


class Data(BaseModel):
    total_cost_cents: float = FieldInfo(alias="totalCostCents")
    """Total cost in cents"""

    total_events: float = FieldInfo(alias="totalEvents")
    """Total events for this dimension"""

    total_input_tokens: float = FieldInfo(alias="totalInputTokens")
    """Total input tokens"""

    total_output_tokens: float = FieldInfo(alias="totalOutputTokens")
    """Total output tokens"""

    total_tokens: float = FieldInfo(alias="totalTokens")
    """Total tokens for this dimension"""

    dimension: Optional[str] = None
    """Dimension value (e.g., model name, customer ID)"""


class UsageGetBreakdownResponse(BaseModel):
    data: List[Data]
    """Array of usage breakdown by dimension"""
