# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageListParams"]


class UsageListParams(TypedDict, total=False):
    cursor: str
    """Pagination cursor from the previous response"""

    customer_id: Annotated[str, PropertyInfo(alias="customerId")]
    """Filter events by customer ID"""

    event_type: Annotated[str, PropertyInfo(alias="eventType")]
    """Filter events by type (e.g., "chat_completion", "embedding")"""

    limit: int
    """Maximum number of items to return (1-100, default: 50)"""

    model: str
    """Filter events by model name (e.g., "gpt-4", "claude-3")"""
