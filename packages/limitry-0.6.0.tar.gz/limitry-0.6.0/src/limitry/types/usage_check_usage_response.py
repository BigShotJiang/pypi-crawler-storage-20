# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["UsageCheckUsageResponse", "Quota", "RateLimit"]


class Quota(BaseModel):
    id: str
    """Quota ID"""

    exceeded: bool
    """Whether this quota was exceeded"""

    limit: float
    """Maximum allowed for the period"""

    metric: str
    """Metric being measured (total_tokens, total_events, total_cost_cents)"""

    name: str
    """Quota name"""

    period: str
    """Quota period (hour, day, week, month)"""

    remaining: float
    """Remaining allowance"""

    reset: float
    """Unix timestamp when the period resets"""

    used: float
    """Current usage in the period"""


class RateLimit(BaseModel):
    id: str
    """Rate limit ID"""

    exceeded: bool
    """Whether this rate limit was exceeded"""

    limit: float
    """Maximum requests allowed in the window"""

    name: str
    """Rate limit name"""

    remaining: float
    """Remaining requests in current window"""

    reset: float
    """Unix timestamp when the window resets"""

    window: str
    """Rate limit window (second, minute, hour)"""


class UsageCheckUsageResponse(BaseModel):
    allowed: bool
    """Whether the request is allowed to proceed"""

    quotas: List[Quota]
    """Status of all matching quotas"""

    rate_limits: List[RateLimit] = FieldInfo(alias="rateLimits")
    """Status of all matching rate limits"""

    error: Optional[str] = None
    """Error message if not allowed"""
