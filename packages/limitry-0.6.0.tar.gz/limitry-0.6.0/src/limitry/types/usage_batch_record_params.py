# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageBatchRecordParams", "Event"]


class UsageBatchRecordParams(TypedDict, total=False):
    events: Required[Iterable[Event]]
    """Array of events to ingest (max 1000)"""


class Event(TypedDict, total=False):
    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Your customer's identifier (e.g., user ID, tenant ID)"""

    event_type: Required[Annotated[str, PropertyInfo(alias="eventType")]]
    """Type of event (e.g., "model_call", "embedding", "tool_call")"""

    cost_cents: Annotated[int, PropertyInfo(alias="costCents")]
    """Cost in cents (e.g., 25 = $0.25)"""

    idempotency_key: Annotated[str, PropertyInfo(alias="idempotencyKey")]
    """Unique key for deduplication (prevents duplicate events)"""

    input_tokens: Annotated[int, PropertyInfo(alias="inputTokens")]
    """Number of input tokens consumed"""

    latency_ms: Annotated[int, PropertyInfo(alias="latencyMs")]
    """Request latency in milliseconds"""

    model: str
    """Model used (e.g., "gpt-4", "claude-3-opus", "gpt-3.5-turbo")"""

    output_tokens: Annotated[int, PropertyInfo(alias="outputTokens")]
    """Number of output tokens generated"""

    properties: Dict[str, Optional[object]]
    """Custom dimensions for filtering and grouping"""

    provider: str
    """Provider name (e.g., "openai", "anthropic", "google")"""

    timestamp: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """ISO 8601 timestamp (defaults to current time if not provided)"""

    total_tokens: Annotated[int, PropertyInfo(alias="totalTokens")]
    """Total tokens (auto-calculated if not provided)"""
