# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import TypedDict

__all__ = ["RateLimitCheckParams"]


class RateLimitCheckParams(TypedDict, total=False):
    body: Dict[str, Optional[object]]
    """Dimensions object for rate limit matching (e.g., {"customer_id": "cust_123"})"""
