# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["CustomerRetrieveUsageResponse"]


class CustomerRetrieveUsageResponse(BaseModel):
    customer_id: str = FieldInfo(alias="customerId")
    """Customer identifier"""

    total_cost_cents: float = FieldInfo(alias="totalCostCents")
    """Total cost in cents for this customer"""

    total_events: float = FieldInfo(alias="totalEvents")
    """Total number of events for this customer"""

    total_input_tokens: float = FieldInfo(alias="totalInputTokens")
    """Total input tokens consumed"""

    total_output_tokens: float = FieldInfo(alias="totalOutputTokens")
    """Total output tokens generated"""

    total_tokens: float = FieldInfo(alias="totalTokens")
    """Total tokens consumed by this customer"""
