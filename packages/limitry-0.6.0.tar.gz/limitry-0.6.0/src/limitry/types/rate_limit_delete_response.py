# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["RateLimitDeleteResponse"]


class RateLimitDeleteResponse(BaseModel):
    success: bool
    """Whether the rate limit was successfully deleted"""
