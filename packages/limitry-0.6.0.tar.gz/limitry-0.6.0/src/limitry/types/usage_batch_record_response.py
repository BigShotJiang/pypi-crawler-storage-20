# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["UsageBatchRecordResponse"]


class UsageBatchRecordResponse(BaseModel):
    count: float
    """Number of events successfully ingested"""
