# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["QuotaDeleteResponse"]


class QuotaDeleteResponse(BaseModel):
    success: bool
    """Whether the quota was successfully deleted"""
