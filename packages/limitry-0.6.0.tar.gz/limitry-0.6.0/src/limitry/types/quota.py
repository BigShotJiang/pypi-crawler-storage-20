# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Quota"]


class Quota(BaseModel):
    id: str
    """Unique identifier for the quota"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp when the quota was created"""

    dimension_filters: Dict[str, str] = FieldInfo(alias="dimensionFilters")
    """
    Dimension filters that determine which events match this quota (e.g.,
    {"customer_id": "cust_123", "model": "gpt-4"})
    """

    limit_value: float = FieldInfo(alias="limitValue")
    """Quota limit value"""

    metric: str
    """Metric being tracked (e.g., "total_tokens", "cost_cents", "total_events")"""

    name: str
    """Human-readable name for the quota"""

    period: str
    """Time period for the quota (e.g., "day", "month", "year")"""

    project_id: str = FieldInfo(alias="projectId")
    """ID of the project that owns this quota"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """ISO 8601 timestamp when the quota was last updated"""

    alert_thresholds: Optional[List[int]] = FieldInfo(alias="alertThresholds", default=None)
    """Alert thresholds as percentages (e.g., [80, 100]).

    Null means inherit from project defaults. Empty array disables alerts.
    """

    period_anchor_day: Optional[int] = FieldInfo(alias="periodAnchorDay", default=None)
    """Period anchor day.

    For monthly: 1-31 (day of month to reset, null=1st). For weekly: 0-6 (0=Sunday,
    1=Monday, ..., null=Monday). Ignored for hour/day periods.
    """
