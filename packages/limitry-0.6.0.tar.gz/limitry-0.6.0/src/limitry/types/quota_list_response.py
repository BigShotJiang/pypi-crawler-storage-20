# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .quota import Quota
from .pagination_cursor import PaginationCursor

__all__ = ["QuotaListResponse"]


class QuotaListResponse(PaginationCursor):
    data: List[Quota]
