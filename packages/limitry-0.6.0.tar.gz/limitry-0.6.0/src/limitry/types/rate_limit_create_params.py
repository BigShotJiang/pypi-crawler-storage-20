# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["RateLimitCreateParams"]


class RateLimitCreateParams(TypedDict, total=False):
    limit_value: Required[Annotated[int, PropertyInfo(alias="limitValue")]]
    """Maximum number of requests allowed in the time window"""

    name: Required[str]
    """Human-readable name for the rate limit"""

    window: Required[Literal["second", "minute", "hour"]]
    """
    Sliding time window for rate limit calculation: "second" = rolling 1s window,
    "minute" = rolling 60s window, "hour" = rolling 3600s window
    """

    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Key-value pairs to filter or scope the rule.

    Keys must be alphanumeric with underscores (max 64 chars). Values are strings
    (max 256 chars).
    """

    enabled: bool
    """Whether the rate limit is enabled"""
