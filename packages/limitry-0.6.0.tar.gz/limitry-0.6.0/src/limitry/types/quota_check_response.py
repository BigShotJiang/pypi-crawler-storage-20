# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel

__all__ = ["QuotaCheckResponse", "Quota"]


class Quota(BaseModel):
    id: str
    """Unique identifier for the quota"""

    exceeded: bool
    """Whether the quota has been exceeded"""

    limit: float
    """Quota limit value"""

    metric: str
    """Metric being tracked"""

    name: str
    """Human-readable name of the quota"""

    period: str
    """Time period for the quota"""

    remaining: float
    """Remaining quota (limit - used)"""

    used: float
    """Current usage value"""


class QuotaCheckResponse(BaseModel):
    allowed: bool
    """Whether the quota check passed"""

    quotas: List[Quota]
    """Status of all matching quotas"""
