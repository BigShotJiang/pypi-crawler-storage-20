# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .rate_limit import RateLimit
from .pagination_cursor import PaginationCursor

__all__ = ["RateLimitListResponse"]


class RateLimitListResponse(PaginationCursor):
    data: List[RateLimit]
