# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .pagination_cursor import PaginationCursor

__all__ = ["UsageListResponse", "UsageListResponseData"]


class UsageListResponseData(BaseModel):
    id: str
    """Unique identifier for the event"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp when the event was created"""

    customer_id: str = FieldInfo(alias="customerId")
    """Customer identifier associated with the event"""

    event_type: str = FieldInfo(alias="eventType")
    """Type of event that was recorded"""

    properties: Dict[str, Optional[object]]
    """Custom properties/dimensions associated with the event"""

    cost_cents: Optional[float] = FieldInfo(alias="costCents", default=None)
    """Cost in cents (if provided)"""

    input_tokens: Optional[float] = FieldInfo(alias="inputTokens", default=None)
    """Input tokens consumed (if provided)"""

    latency_ms: Optional[float] = FieldInfo(alias="latencyMs", default=None)
    """Request latency in milliseconds (if provided)"""

    model: Optional[str] = None
    """Model name used (if provided)"""

    output_tokens: Optional[float] = FieldInfo(alias="outputTokens", default=None)
    """Output tokens generated (if provided)"""

    provider: Optional[str] = None
    """Provider name (if provided)"""

    total_tokens: Optional[float] = FieldInfo(alias="totalTokens", default=None)
    """Total tokens for the event"""


class UsageListResponse(PaginationCursor):
    data: List[UsageListResponseData]
