# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["QuotaCreateParams"]


class QuotaCreateParams(TypedDict, total=False):
    limit_value: Required[Annotated[int, PropertyInfo(alias="limitValue")]]
    """Quota limit value"""

    metric: Required[Literal["total_tokens", "total_events", "total_cost_cents"]]
    """Metric being tracked"""

    name: Required[str]
    """Human-readable name for the quota"""

    period: Required[Literal["hour", "day", "week", "month"]]
    """Time period for the quota"""

    alert_thresholds: Annotated[Optional[Iterable[int]], PropertyInfo(alias="alertThresholds")]
    """Alert thresholds as percentages (e.g., [80, 100]).

    Null or omitted means inherit from project defaults. Empty array disables
    alerts.
    """

    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Key-value pairs to filter or scope the rule.

    Keys must be alphanumeric with underscores (max 64 chars). Values are strings
    (max 256 chars).
    """

    period_anchor_day: Annotated[Optional[int], PropertyInfo(alias="periodAnchorDay")]
    """Period anchor day.

    For monthly: 1-31 (day of month to reset). For weekly: 0-6 (0=Sunday, 1=Monday,
    ...). Null or omitted uses defaults (1st for monthly, Monday for weekly).
    """
