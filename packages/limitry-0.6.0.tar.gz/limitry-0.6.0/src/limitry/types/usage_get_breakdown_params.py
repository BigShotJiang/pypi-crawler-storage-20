# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageGetBreakdownParams"]


class UsageGetBreakdownParams(TypedDict, total=False):
    end_date: Required[Annotated[Union[str, datetime], PropertyInfo(alias="endDate", format="iso8601")]]
    """End of the date range (ISO 8601 format)"""

    group_by: Required[
        Annotated[Literal["model", "customer_id", "event_type", "provider"], PropertyInfo(alias="groupBy")]
    ]
    """Dimension to group usage by"""

    start_date: Required[Annotated[Union[str, datetime], PropertyInfo(alias="startDate", format="iso8601")]]
    """Start of the date range (ISO 8601 format)"""

    customer_id: Annotated[str, PropertyInfo(alias="customerId")]
    """Filter usage by customer ID before grouping"""

    event_type: Annotated[str, PropertyInfo(alias="eventType")]
    """Filter usage by event type before grouping"""

    model: str
    """Filter usage by model name before grouping"""

    provider: str
    """Filter usage by provider before grouping (e.g., "openai", "anthropic")"""
