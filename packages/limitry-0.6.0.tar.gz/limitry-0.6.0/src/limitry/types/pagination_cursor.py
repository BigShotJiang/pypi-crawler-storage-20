# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaginationCursor"]


class PaginationCursor(BaseModel):
    has_more: bool = FieldInfo(alias="hasMore")
    """Whether there are more results available"""

    next_cursor: Optional[str] = FieldInfo(alias="nextCursor", default=None)
    """Cursor for the next page of results. Null if there are no more results."""
