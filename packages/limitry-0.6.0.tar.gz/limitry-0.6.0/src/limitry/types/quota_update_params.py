# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["QuotaUpdateParams"]


class QuotaUpdateParams(TypedDict, total=False):
    alert_thresholds: Annotated[Optional[Iterable[int]], PropertyInfo(alias="alertThresholds")]
    """Alert thresholds as percentages.

    Null means inherit from project defaults. Empty array disables alerts.
    """

    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Dimension filters that determine which events match this quota"""

    limit_value: Annotated[int, PropertyInfo(alias="limitValue")]
    """Quota limit value"""

    metric: Literal["total_tokens", "total_events", "total_cost_cents"]
    """Metric being tracked"""

    name: str
    """Human-readable name for the quota"""

    period: Literal["hour", "day", "week", "month"]
    """Time period for the quota"""

    period_anchor_day: Annotated[Optional[int], PropertyInfo(alias="periodAnchorDay")]
    """Period anchor day. For monthly: 1-31. For weekly: 0-6. Null resets to default."""
