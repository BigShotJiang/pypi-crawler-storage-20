# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["RateLimitUpdateParams"]


class RateLimitUpdateParams(TypedDict, total=False):
    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Dimension filters that determine which requests match this rate limit"""

    enabled: bool
    """Whether the rate limit is enabled"""

    limit_value: Annotated[int, PropertyInfo(alias="limitValue")]
    """Maximum number of requests allowed in the time window"""

    name: str
    """Human-readable name for the rate limit"""

    window: Literal["second", "minute", "hour"]
    """
    Sliding time window for rate limit calculation: "second" = rolling 1s window,
    "minute" = rolling 60s window, "hour" = rolling 3600s window
    """
