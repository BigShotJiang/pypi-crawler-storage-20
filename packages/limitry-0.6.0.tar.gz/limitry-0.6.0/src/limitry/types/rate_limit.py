# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["RateLimit"]


class RateLimit(BaseModel):
    id: str
    """Unique identifier for the rate limit"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp when the rate limit was created"""

    dimension_filters: Dict[str, str] = FieldInfo(alias="dimensionFilters")
    """
    Dimension filters that determine which requests match this rate limit (e.g.,
    {"customer_id": "cust_123"})
    """

    enabled: bool
    """Whether the rate limit is currently enabled"""

    limit_value: float = FieldInfo(alias="limitValue")
    """Maximum number of requests allowed in the time window"""

    name: str
    """Human-readable name for the rate limit"""

    project_id: str = FieldInfo(alias="projectId")
    """ID of the project that owns this rate limit"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """ISO 8601 timestamp when the rate limit was last updated"""

    window: str
    """Time window for the rate limit (e.g., "1m", "1h", "1d")"""
