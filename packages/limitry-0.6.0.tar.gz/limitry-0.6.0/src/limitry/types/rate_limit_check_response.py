# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["RateLimitCheckResponse", "RateLimit"]


class RateLimit(BaseModel):
    id: str
    """Unique identifier for the rate limit"""

    exceeded: bool
    """Whether the rate limit has been exceeded"""

    limit: float
    """Maximum requests allowed in the window"""

    name: str
    """Human-readable name of the rate limit"""

    remaining: float
    """Number of requests remaining in the current window"""

    reset: float
    """Unix timestamp when the rate limit window resets"""

    window: str
    """Time window for the rate limit"""


class RateLimitCheckResponse(BaseModel):
    allowed: bool
    """Whether the rate limit check passed"""

    rate_limits: List[RateLimit] = FieldInfo(alias="rateLimits")
    """Status of all matching rate limits"""
