# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ParsedBlock", "BoundingBox"]


class BoundingBox(BaseModel):
    """
    The normalized bounding box of the block, as relative percentages of the page width and height
    """

    x0: float
    """The x-coordinate of the top-left corner of the bounding box"""

    x1: float
    """The x-coordinate of the bottom-right corner of the bounding box"""

    y0: float
    """The y-coordinate of the top-left corner of the bounding box"""

    y1: float
    """The y-coordinate of the bottom-right corner of the bounding box"""


class ParsedBlock(BaseModel):
    """One logical block of content from a parsed page."""

    id: str
    """Unique ID of the block"""

    bounding_box: BoundingBox
    """
    The normalized bounding box of the block, as relative percentages of the page
    width and height
    """

    markdown: str
    """The Markdown representation of the block"""

    type: Literal["heading", "text", "table", "figure"]
    """The type of the block"""

    confidence_level: Optional[Literal["low", "medium", "high"]] = None
    """The confidence level of this block categorized as 'low', 'medium', or 'high'.

    Only available for blocks of type 'table' currently.
    """

    hierarchy_level: Optional[int] = None
    """
    The level of the block in the document hierarchy, starting at 0 for the
    root-level title block. Only present if `enable_document_hierarchy` was set to
    true in the request.
    """

    page_index: Optional[int] = None
    """The page (0-indexed) that this block belongs to.

    Only set for heading blocks that are returned in the table of contents.
    """

    parent_ids: Optional[List[str]] = None
    """
    The IDs of the parent in the document hierarchy, sorted from root-level to
    bottom. For root-level heading blocks, this will be an empty list. Only present
    if `enable_document_hierarchy` was set to true in the request.
    """
