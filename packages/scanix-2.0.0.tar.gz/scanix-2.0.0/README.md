# ⚡ Scanix - Static Code Security Scanner

![Version](https://img.shields.io/badge/version-2.0.0-blue.svg)
![Python](https://img.shields.io/badge/python-3.8+-green.svg)
![License](https://img.shields.io/badge/license-MIT-orange.svg)
![OWASP](https://img.shields.io/badge/OWASP-Top%2010%202021-red.svg)
![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey.svg)

**Scanner de vulnérabilités statique rapide - Détecte 25+ failles de sécurité OWASP**

Développé par **[Riyad ODJOUADE (Ore)](https://github.com/Ore2025)** • riyadodjouade@gmail.com

---

## 🚀 Installation

### 📦 Méthode 1 : Avec pip/pipx (Recommandé - Simple)

```bash
# Installation globale avec pipx (recommandé)
pipx install scanix

# Ou avec pip
pip install scanix

# Lancement
scanix
```

**Avantages** :
- ✅ Installation en une commande
- ✅ Pas de gestion de dépendances
- ✅ Mises à jour faciles : `pipx upgrade scanix`
- ✅ Désinstallation propre : `pipx uninstall scanix`

---

### 💻 Méthode 2 : Depuis GitHub (Développeurs)

#### Windows

```cmd
REM Cloner le projet
git clone https://github.com/Ore2025/scanix.git
cd scanix

REM Installer avec le script
install.bat

REM Lancer
scanix
```

#### Linux / macOS

```bash
# Cloner le projet
git clone https://github.com/Ore2025/scanix.git
cd scanix

# Installer avec le script
chmod +x install.sh
./install.sh

# Lancer
./scanix
```

**Le script `install.sh` fait automatiquement** :
- Crée un environnement virtuel
- Installe toutes les dépendances
- Crée un lanceur `./scanix` pratique

---

### 🔧 Méthode 3 : Installation Manuelle

#### Avec Environnement Virtuel (Recommandé)

```bash
# Cloner
git clone https://github.com/Ore2025/scanix.git
cd scanix

# Créer l'environnement virtuel
python3 -m venv venv

# Activer
# Linux/macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# Installer les dépendances
pip install -r requirements.txt

# Lancer
python run.py
```

#### Sans Environnement Virtuel (Kali Linux / Debian)

```bash
# Cloner
git clone https://github.com/Ore2025/scanix.git
cd scanix

# Installer directement (Kali/Debian uniquement)
pip install -r requirements.txt --break-system-packages

# Lancer
python3 run.py
```

⚠️ **Note** : `--break-system-packages` contourne la protection PEP 668 de Kali Linux. Utilisez avec précaution.

---

### 🖥️ Méthode 4 : Mode VM / Test Rapide (Usage Temporaire)

**Parfait pour tester sur une VM ou machine temporaire** :

```bash
# Cloner et tester rapidement
git clone https://github.com/Ore2025/scanix.git
cd scanix

# Créer venv temporaire
python3 -m venv .venv
source .venv/bin/activate

# Installer et lancer
pip install -r requirements.txt
python run.py

# Après utilisation, quitter et nettoyer
deactivate
cd ..
rm -rf scanix  # Supprime tout (code + venv)
```

**Avantages** :
- ✅ Installation isolée
- ✅ Aucune trace après suppression
- ✅ Idéal pour tests ponctuels
- ✅ Pas d'impact sur le système

---

## 📊 Comparaison des Méthodes

| Méthode | Difficulté | Rapidité | Usage |
|---------|-----------|----------|-------|
| **pipx** | ⭐ Facile | ⚡ Rapide | Production, usage quotidien |
| **Script install** | ⭐⭐ Moyen | ⚡⚡ Moyen | Développement, contribution |
| **Manuelle venv** | ⭐⭐⭐ Avancé | ⚡⚡ Moyen | Contrôle total |
| **Sans venv (Kali)** | ⭐⭐ Moyen | ⚡ Rapide | Kali Linux uniquement |
| **VM/Temporaire** | ⭐⭐ Moyen | ⚡⚡ Moyen | Tests ponctuels, VMs |

---

## 📸 Aperçu

### Interface Principale
![Welcome Screen](assets/screenshots/1-welcome.png)

### Résultats d'Analyse
![Results](assets/screenshots/4-results.png)

<details>
<summary><b>Plus de captures d'écran</b></summary>

![File Selection](assets/screenshots/2-file-select.png)
![Scanning](assets/screenshots/3-scanning.png)
![Export](assets/screenshots/5-export.png)

</details>

---

## ✨ Fonctionnalités

### 🔍 Deux Modes de Scan

| Mode | Vitesse | Détections | Usage |
|------|---------|------------|-------|
| 🚀 **Rapide** | 2s/fichier | 6 vulnérabilités critiques | Check quotidien |
| 🔬 **Complet** | 5s/fichier | 25+ catégories OWASP | Audit complet |

### 🛡️ Détections

**Mode Rapide** (6 critiques) :
- Injection SQL
- XSS (Cross-Site Scripting)
- Secrets exposés (API keys, passwords)
- Injection de commandes OS
- Path Traversal
- CSRF

**Mode Complet** (25+) : Tout le rapide + 
- Injection NoSQL/LDAP/XML (XXE)
- Désérialisation non sécurisée
- Cryptographie faible (MD5, SHA1)
- Upload de fichiers dangereux
- Configuration dangereuse
- Authentification faible
- Et 15+ autres catégories...

### 🌐 Langages Supportés

Python • JavaScript/TypeScript • PHP • Java • C/C++ • Go • Ruby • HTML • SQL • YAML • XML

### 💾 Formats d'Export

📄 **JSON** • 🌐 **HTML** • 📝 **TXT** • 📊 **CSV**

**Emplacement des exports** :
- Windows : `C:\Users\VotreNom\SecureCode_Exports\`
- Linux/macOS : `~/SecureCode_Exports/`

---

## 📖 Utilisation

### Démarrage

```bash
# Si installé avec pip/pipx
scanix

# Si cloné depuis GitHub
./scanix
# ou
python run.py
```

### Navigation

```
Menu Principal :
  1 → Scanner un fichier
  2 → Scanner un dossier
  3 → À propos
  Q → Quitter

Raccourcis :
  Ctrl+Q : Quitter
  Escape : Retour
  Ctrl+A : Tout sélectionner
  Ctrl+D : Tout désélectionner
  ↑↓     : Naviguer
```

### Workflow Type

```bash
# 1. Lancer Scanix
scanix

# 2. Choisir "Scanner un dossier" (option 2)
# 3. Naviguer jusqu'à votre projet
# 4. Sélectionner les fichiers (Espace ou Ctrl+A)
# 5. Choisir le mode (Rapide ou Complet)
# 6. Consulter les résultats
# 7. Exporter en HTML/JSON si besoin
```

---

## 📊 Exemples de Détection

### 1. Injection SQL (CWE-89)

```python
# ❌ VULNÉRABLE
query = f"SELECT * FROM users WHERE id = {user_id}"
db.execute(query)

# ✅ SÉCURISÉ
query = "SELECT * FROM users WHERE id = ?"
db.execute(query, (user_id,))
```

### 2. Secrets en Dur (CWE-798)

```python
# ❌ VULNÉRABLE
API_KEY = "sk_live_abc123xyz789"
PASSWORD = "admin123"

# ✅ SÉCURISÉ
import os
API_KEY = os.getenv('API_KEY')
PASSWORD = os.getenv('DB_PASSWORD')
```

### 3. XSS (CWE-79)

```javascript
// ❌ VULNÉRABLE
element.innerHTML = userInput;

// ✅ SÉCURISÉ
element.textContent = userInput;
```

### 4. Path Traversal (CWE-22)

```python
# ❌ VULNÉRABLE
filename = request.GET['file']
with open(f"uploads/{filename}") as f:
    content = f.read()

# ✅ SÉCURISÉ
from pathlib import Path
base_dir = Path("uploads").resolve()
file_path = (base_dir / filename).resolve()
if not str(file_path).startswith(str(base_dir)):
    raise ValueError("Path traversal detected")
with open(file_path) as f:
    content = f.read()
```

---

## 🎯 Cas d'Usage

### ✅ Développement Quotidien

```bash
# Check rapide avant commit
scanix
# Mode Rapide → ~10 secondes
```

### ✅ Code Review

```bash
# Audit avant merge
scanix
# Mode Complet → Export HTML pour l'équipe
```

### ✅ Audit de Sécurité

```bash
# Scan complet du projet
scanix
# Mode Complet → Export JSON + HTML
```

### ✅ Intégration CI/CD

#### GitHub Actions

```yaml
name: Security Scan
on: [push, pull_request]

jobs:
  security:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
      - name: Install Scanix
        run: pip install scanix
      - name: Run Scan
        run: scanix --mode quick --fail-on-critical
```

---

## 🔒 Vulnérabilités Détectées

<details>
<summary><b>Liste complète des 25+ catégories</b></summary>

### 🔴 Critiques (5)
- Secrets en Dur (CWE-798)
- Injection SQL (CWE-89)
- Injection Commande OS (CWE-78)
- Injection Code (CWE-94)
- Désérialisation (CWE-502)

### 🟠 Élevées (6)
- XSS (CWE-79)
- XXE - XML External Entity (CWE-611)
- Path Traversal (CWE-22)
- Cryptographie Faible (CWE-327)
- Injection NoSQL (CWE-943)
- Injection LDAP (CWE-90)

### 🟡 Moyennes (7)
- CSRF (CWE-352)
- Upload Dangereux (CWE-434)
- Authentification Faible (CWE-287)
- Open Redirect (CWE-601)
- Session Fixation (CWE-384)
- Clickjacking (CWE-1021)
- CORS Mal Configuré (CWE-942)

### 🟢 Faibles (7+)
- Info Sensible en Logs (CWE-532)
- Mode Debug Activé (CWE-489)
- Permissions Fichiers (CWE-732)
- Random Faible (CWE-330)
- Et 3+ autres...

**Total : 25+ catégories OWASP**

</details>

---

## ❓ FAQ

**Q : Compatible Windows/Linux/Mac ?**  
R : Oui, fonctionne sur les 3 plateformes.

**Q : Python requis ?**  
R : Oui, Python 3.8+ nécessaire.

**Q : Gratuit ?**  
R : Oui, 100% gratuit et open-source (MIT License).

**Q : Remplace un audit professionnel ?**  
R : Non, c'est un outil d'aide. Un audit manuel reste essentiel.

**Q : Fonctionne hors ligne ?**  
R : Oui, une fois installé, fonctionne sans connexion internet.

**Q : Données envoyées quelque part ?**  
R : Non, tout reste local. Aucune donnée n'est transmise.

---

## 🔧 Configuration Système

### Prérequis

| OS | Python | Installation Python |
|----|--------|---------------------|
| **Windows 10/11** | 3.8+ | https://www.python.org/downloads/ |
| **Ubuntu/Debian** | 3.8+ | `sudo apt install python3 python3-pip` |
| **Kali Linux** | 3.8+ | Déjà installé |
| **macOS** | 3.8+ | `brew install python3` ou déjà installé |

### Vérifier Python

```bash
# Vérifier la version
python3 --version
# Doit afficher: Python 3.8.x ou supérieur

# Si python3 non trouvé (Windows)
python --version
```

---

## 🐛 Problèmes Courants

### Windows - "python not found"
```cmd
py --version
py -m pip install scanix
```

### Linux - Permission denied
```bash
chmod +x install.sh scanix run.py
```

### Kali - externally-managed-environment
```bash
# Solution 1 : pipx (recommandé)
pipx install scanix

# Solution 2 : venv
python3 -m venv venv
source venv/bin/activate
pip install scanix
```

### macOS - SSL Certificate Error
```bash
/Applications/Python\ 3.x/Install\ Certificates.command
```

---

## 📄 Licence

MIT License - Libre d'utilisation et modification

---

## 👤 Auteur

**Riyad ODJOUADE (Ore)**

- 🌐 GitHub: [@Ore2025](https://github.com/Ore2025)
- 📧 Email: riyadodjouade@gmail.com
- 📦 PyPI: [scanix](https://pypi.org/project/scanix/)

---

## 🙏 Remerciements

- **OWASP** pour les standards de sécurité
- **Textual** pour le framework TUI
- **Rich** pour le rendu terminal
- La communauté Python

---

## ⭐ Support

Si Scanix vous aide :
1. ⭐ **Star** le projet sur GitHub
2. 📢 **Partagez** avec vos collègues
3. 💬 **Feedback** via [Issues](https://github.com/Ore2025/scanix/issues)

```bash
pip install scanix
```

---

<div align="center">

**Fait avec ❤️ pour la sécurité du code**

[![GitHub](https://img.shields.io/badge/GitHub-Ore2025-181717?style=for-the-badge&logo=github)](https://github.com/Ore2025)
[![PyPI](https://img.shields.io/pypi/v/scanix?style=for-the-badge)](https://pypi.org/project/scanix/)
[![Downloads](https://img.shields.io/pypi/dm/scanix?style=for-the-badge)](https://pypi.org/project/scanix/)

**⚡ Scanix v2.0** • Fast • Powerful • OWASP

</div>