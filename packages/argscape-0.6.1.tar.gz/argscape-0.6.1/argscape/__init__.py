"""
Argscape package initialization.
""" 

__version__ = "0.6.1"
