#!/usr/bin/env python3
"""
Quick script to create a 3-population msprime simulation for testing.
All nodes will have population assignments.
"""

import msprime
import tskit

# Simulation parameters - kept small for testing
num_samples_per_pop = 5  # Only 5 samples per population = 15 total
sequence_length = 10000  # Very short sequence = fewer trees
recombination_rate = 0  # No recombination = single tree (or very few trees)
mutation_rate = 1e-7  # Higher mutation rate to get some mutations in short sequence

# Create a 3-population demographic model
demography = msprime.Demography()
demography.add_population(name="pop0", initial_size=1000)  # Smaller population sizes
demography.add_population(name="pop1", initial_size=1000)
demography.add_population(name="pop2", initial_size=1000)

# Add migration between populations
demography.add_migration_rate_change(time=0, rate=1e-5, source="pop0", dest="pop1")
demography.add_migration_rate_change(time=0, rate=1e-5, source="pop1", dest="pop0")
demography.add_migration_rate_change(time=0, rate=1e-5, source="pop0", dest="pop2")
demography.add_migration_rate_change(time=0, rate=1e-5, source="pop2", dest="pop0")
demography.add_migration_rate_change(time=0, rate=1e-5, source="pop1", dest="pop2")
demography.add_migration_rate_change(time=0, rate=1e-5, source="pop2", dest="pop1")

# Simulate the tree sequence
print("Simulating tree sequence with 3 populations...")
ts = msprime.sim_ancestry(
    samples={
        "pop0": num_samples_per_pop,
        "pop1": num_samples_per_pop,
        "pop2": num_samples_per_pop,
    },
    demography=demography,
    sequence_length=sequence_length,
    recombination_rate=recombination_rate,
    random_seed=42,
)

# Add mutations
print("Adding mutations...")
ts = msprime.sim_mutations(
    ts,
    rate=mutation_rate,
    random_seed=42,
)

# Verify population assignments
print("\nVerifying population assignments...")
pop_counts = {}
for node in ts.nodes():
    if node.population != tskit.NULL:
        pop_id = node.population
        pop_counts[pop_id] = pop_counts.get(pop_id, 0) + 1

print(f"Total nodes: {ts.num_nodes}")
print(f"Total samples: {ts.num_samples}")
print(f"Number of populations: {ts.num_populations}")
print(f"Population assignments:")
for pop_id, count in sorted(pop_counts.items()):
    print(f"  Population {pop_id}: {count} nodes")

# Check if all nodes have populations
nodes_without_pop = sum(1 for node in ts.nodes() if node.population == tskit.NULL)
if nodes_without_pop > 0:
    print(f"\n⚠️  Warning: {nodes_without_pop} nodes do not have population assignments")
    print("   (This is normal for internal nodes in msprime simulations)")
    print("   The inference logic should handle this.")
else:
    print("\n✓ All nodes have population assignments")

# Save to file
output_file = "test_3pop.trees"
print(f"\nSaving to {output_file}...")
ts.dump(output_file)
print(f"✓ Saved {output_file}")
print(f"  File size: {ts.num_bytes / 1024:.2f} KB")
print(f"  Sequence length: {ts.sequence_length:,.0f} bp")
print(f"  Number of trees: {ts.num_trees}")
print(f"  Number of edges: {ts.num_edges}")
print(f"  Number of mutations: {ts.num_mutations}")

