import threading

from pilot.job.impl.base_job import BaseJob

from pilot.conver.converfileEncodding import nkf_convert


class EncodingTransformerJob(BaseJob):
    _begin_file_lock = threading.Lock()
    def run(self):
        with self._begin_file_lock:
            if not self.change_current_trg_to_begin():
                return
        nkf_args = ['-w', '--overwrite']
        nkf_convert(self.file_path, nkf_args)
        super().run()