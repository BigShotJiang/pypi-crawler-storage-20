use pyo3::prelude::*;
use pmxt_test_market::TestMarket as RustTestMarket;
use pmxt_core::{Exchange, OrderSide};
use rust_decimal::prelude::*;
use std::collections::HashMap;

// --- Typed Python Models ---

#[pyclass]
#[derive(Clone)]
pub struct Market {
    #[pyo3(get)]
    pub id: String,
    #[pyo3(get)]
    pub symbol: String,
    #[pyo3(get)]
    pub title: String,
    #[pyo3(get)]
    pub description: Option<String>,
    #[pyo3(get)]
    pub outcomes: Vec<String>,
    #[pyo3(get)]
    pub active: bool,
}

#[pyclass]
#[derive(Clone)]
pub struct Order {
    #[pyo3(get)]
    pub id: String,
    #[pyo3(get)]
    pub market_id: String,
    #[pyo3(get)]
    pub outcome_id: String,
    #[pyo3(get)]
    pub price: f64,
    #[pyo3(get)]
    pub amount: f64,
    #[pyo3(get)]
    pub side: String,
    #[pyo3(get)]
    pub status: String,
}

#[pyclass]
#[derive(Clone)]
pub struct Balance {
    #[pyo3(get)]
    pub currency: String,
    #[pyo3(get)]
    pub free: f64,
    #[pyo3(get)]
    pub used: f64,
    #[pyo3(get)]
    pub total: f64,
}

#[pyclass]
#[derive(Clone)]
pub struct Position {
    #[pyo3(get)]
    pub market_id: String,
    #[pyo3(get)]
    pub outcome_id: String,
    #[pyo3(get)]
    pub amount: f64,
    #[pyo3(get)]
    pub entry_price: f64,
}

#[pyclass]
#[derive(Clone)]
pub struct Ticker {
    #[pyo3(get)]
    pub market_id: String,
    #[pyo3(get)]
    pub outcome_id: String,
    #[pyo3(get)]
    pub price: f64,
    #[pyo3(get)]
    pub bid: Option<f64>,
    #[pyo3(get)]
    pub ask: Option<f64>,
}

#[pyclass]
#[derive(Clone)]
pub struct Credentials {
    #[pyo3(get, set)]
    pub api_key: String,
    #[pyo3(get, set)]
    pub api_secret: Option<String>,
    #[pyo3(get, set)]
    pub private_key: Option<String>,
}

// --- Main Exchange Wrappers ---

#[pyclass]
struct TestMarket {
    inner: RustTestMarket,
}

#[pymethods]
impl TestMarket {
    #[new]
    fn new(is_amm: bool) -> Self {
        TestMarket {
            inner: RustTestMarket::new(is_amm),
        }
    }

    fn has_capability(&self, cap: String) -> bool {
        let cap_list = self.inner.capabilities();
        let cap_str = cap.to_lowercase();
        cap_list.iter().any(|c| format!("{:?}", c).to_lowercase() == cap_str)
    }

    fn load_markets<'a>(&self, py: Python<'a>) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        pyo3_asyncio::tokio::future_into_py(py, async move {
            let markets = client.load_markets().await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            let py_markets: Vec<Market> = markets.into_iter().map(|m| Market {
                id: m.id,
                symbol: m.symbol,
                title: m.title,
                description: m.description,
                outcomes: m.outcomes.into_iter().map(|o| o.name).collect(),
                active: m.active,
            }).collect();
            Ok(py_markets)
        })
    }

    fn create_order<'a>(&self, py: Python<'a>, market_id: String, outcome_id: String, side: String, amount: f64, price: f64) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        let side_enum = match side.to_lowercase().as_str() {
            "buy" => OrderSide::Buy,
            "sell" => OrderSide::Sell,
            _ => return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid side")),
        };

        let d_amount = Decimal::from_f64(amount).ok_or_else(|| PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid amount"))?;
        let d_price = Decimal::from_f64(price).ok_or_else(|| PyErr::new::<pyo3::exceptions::PyValueError, _>("Invalid price"))?;

        pyo3_asyncio::tokio::future_into_py(py, async move {
            let order = client.create_order(&market_id, &outcome_id, side_enum, d_amount, Some(d_price))
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            Ok(Order {
                id: order.id,
                market_id: order.market_id,
                outcome_id: order.outcome_id,
                price: order.price.to_f64().unwrap_or(0.0),
                amount: order.amount.to_f64().unwrap_or(0.0),
                side: format!("{:?}", order.side),
                status: format!("{:?}", order.status),
            })
        })
    }

    fn fetch_balance<'a>(&self, py: Python<'a>) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        pyo3_asyncio::tokio::future_into_py(py, async move {
            let balances = client.fetch_balance().await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            let py_balances: Vec<Balance> = balances.into_iter().map(|b| Balance {
                currency: b.currency,
                free: b.free.to_f64().unwrap_or(0.0),
                used: b.used.to_f64().unwrap_or(0.0),
                total: b.total.to_f64().unwrap_or(0.0),
            }).collect();
            Ok(py_balances)
        })
    }

    fn fetch_positions<'a>(&self, py: Python<'a>) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        pyo3_asyncio::tokio::future_into_py(py, async move {
            let positions = client.fetch_positions().await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            let py_positions: Vec<Position> = positions.into_iter().map(|p| Position {
                market_id: p.market_id,
                outcome_id: p.outcome_id,
                amount: p.amount.to_f64().unwrap_or(0.0),
                entry_price: p.entry_price.to_f64().unwrap_or(0.0),
            }).collect();
            Ok(py_positions)
        })
    }

    fn fetch_order_book<'a>(&self, py: Python<'a>, market_id: String, outcome_id: String) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        pyo3_asyncio::tokio::future_into_py(py, async move {
            let book = client.fetch_order_book(&market_id, &outcome_id).await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            let bids: Vec<(f64, f64)> = book.bids.iter().map(|(p, s)| (p.to_f64().unwrap(), s.to_f64().unwrap())).collect();
            let asks: Vec<(f64, f64)> = book.asks.iter().map(|(p, s)| (p.to_f64().unwrap(), s.to_f64().unwrap())).collect();
            
            Ok((bids, asks))
        })
    }

    fn fetch_amm_state<'a>(&self, py: Python<'a>, market_id: String) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        pyo3_asyncio::tokio::future_into_py(py, async move {
            let state = client.fetch_amm_state(&market_id).await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            Python::with_gil(|py| {
                let dict = pythonize::pythonize(py, &state)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
                Ok(dict)
            })
        })
    }

    fn watch_tickers<'a>(&self, py: Python<'a>) -> PyResult<&'a PyAny> {
        let client = self.inner.clone();
        pyo3_asyncio::tokio::future_into_py(py, async move {
            let ticker = client.watch_tickers().await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
            
            Ok(Ticker {
                market_id: ticker.market_id,
                outcome_id: ticker.outcome_id,
                price: ticker.price.to_f64().unwrap_or(0.0),
                bid: ticker.bid.map(|b| b.to_f64().unwrap_or(0.0)),
                ask: ticker.ask.map(|a| a.to_f64().unwrap_or(0.0)),
            })
        })
    }
}

#[pyfunction]
#[pyo3(signature = (exchange_id, api_key=None, api_secret=None, private_key=None, config=None))]
fn create(
    exchange_id: String, 
    api_key: Option<String>, 
    api_secret: Option<String>, 
    private_key: Option<String>,
    config: Option<HashMap<String, String>>
) -> PyResult<PyObject> {
    Python::with_gil(|py| {
        let is_amm = config.as_ref().map(|c| c.get("type").map(|t| t == "amm").unwrap_or(false)).unwrap_or(false);
        
        let _creds = Credentials {
            api_key: api_key.unwrap_or_default(),
            api_secret,
            private_key,
        };

        match exchange_id.to_lowercase().as_str() {
            "test" | "test-market" => {
                let inst = TestMarket { inner: RustTestMarket::new(is_amm) };
                Ok(inst.into_py(py))
            },
            _ => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Unknown exchange: {}", exchange_id))),
        }
    })
}

#[pymodule]
fn pmxt(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(create, m)?)?;
    m.add_class::<TestMarket>()?;
    m.add_class::<Market>()?;
    m.add_class::<Order>()?;
    m.add_class::<Balance>()?;
    m.add_class::<Position>()?;
    m.add_class::<Ticker>()?;
    m.add_class::<Credentials>()?;
    Ok(())
}
