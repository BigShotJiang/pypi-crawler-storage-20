use async_trait::async_trait;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use rust_decimal::Decimal;

/// Universal Market Identifier
pub type MarketId = String;
/// Order Identifier
pub type OrderId = String;
/// Outcome Identifier (could be "0", "1", or specific asset ID)
pub type OutcomeId = String;

#[derive(Error, Debug)]
pub enum PMXTError {
    #[error("API Error: {0}")]
    ApiError(String),
    #[error("Network Error: {0}")]
    NetworkError(String),
    #[error("Insufficient Funds")]
    InsufficientFunds,
    #[error("Market Closed")]
    MarketClosed,
    #[error("Order Not Found")]
    OrderNotFound,
    #[error("Not Implemented")]
    NotImplemented,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Outcome {
    pub id: OutcomeId,
    pub name: String, // "Yes", "No", "Trump", "Biden"
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Market {
    pub id: MarketId,
    pub symbol: String, // Standardized symbol ex "TRUMP-2024"
    pub title: String,
    pub description: Option<String>,
    pub outcomes: Vec<Outcome>, // Categorical-first design
    pub active: bool,
    pub end_time: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OrderBook {
    pub bids: Vec<(Decimal, Decimal)>, // (Price, Size)
    pub asks: Vec<(Decimal, Decimal)>, // (Price, Size)
    pub timestamp: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Order {
    pub id: OrderId,
    pub market_id: MarketId,
    pub outcome_id: OutcomeId,
    pub price: Decimal,
    pub amount: Decimal,
    pub side: OrderSide,
    pub status: OrderStatus,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum OrderSide {
    Buy,
    Sell,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum OrderType {
    Limit,
    Market,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum OrderStatus {
    Open,
    Closed,
    Canceled,
    Failed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ticker {
    pub market_id: MarketId,
    pub outcome_id: OutcomeId,
    pub price: Decimal, // Last traded price or mid
    pub bid: Option<Decimal>,
    pub ask: Option<Decimal>,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Balance {
    pub currency: String,
    pub free: Decimal,
    pub used: Decimal,
    pub total: Decimal,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq)]
pub enum Capability {
    OrderBook,
    AMM,
    MarketOrders,
    LimitOrders,
    CancelOrders,
    FetchBalance,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AMMState {
    pub market_id: MarketId,
    pub curve_type: String, // "CPMM", "LMSR", etc
    pub k: Decimal,         // Constant product
    pub liquidity: Decimal,
    pub pool_balances: std::collections::HashMap<OutcomeId, Decimal>,
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Position {
    pub market_id: MarketId,
    pub outcome_id: OutcomeId,
    pub amount: Decimal,
    pub entry_price: Decimal,
    pub unrealized_pnl: Option<Decimal>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Credentials {
    pub api_key: String,
    pub api_secret: Option<String>,
    pub private_key: Option<String>, // For crypto markets like Polymarket
}

/// IMPORTANT NOTE: All prediction markets must bow to this interface.
#[async_trait]
pub trait Exchange: Send + Sync {
    /// The name of the exchange (e.g. "Polymarket")
    fn id(&self) -> &'static str;

    /// Return the list of capabilities supported by this exchange
    fn capabilities(&self) -> Vec<Capability>;

    /// Helper to check if a specific capability is supported
    fn has_capability(&self, cap: Capability) -> bool {
        self.capabilities().contains(&cap)
    }

    /// Initialize dependencies (load markets, etc)
    async fn load_markets(&self) -> Result<Vec<Market>, PMXTError>;

    /// Fetch order book for a specific market outcome.
    /// For AMM-based exchanges, this should return a Synthetic Order Book.
    async fn fetch_order_book(&self, market_id: &str, outcome_id: &str) -> Result<OrderBook, PMXTError>;

    /// Fetch raw AMM state (only for AMM-based exchanges)
    async fn fetch_amm_state(&self, market_id: &str) -> Result<AMMState, PMXTError>;

    /// Fetch all available tickers/prices
    async fn fetch_tickers(&self) -> Result<Vec<Ticker>, PMXTError>;

    /// Place an order
    async fn create_order(
        &self,
        market_id: &str,
        outcome_id: &str,
        side: OrderSide,
        amount: Decimal,
        price: Option<Decimal>,
    ) -> Result<Order, PMXTError>;

    /// Cancel an order
    async fn cancel_order(&self, order_id: &str) -> Result<(), PMXTError>;

    /// Fetch current open orders
    async fn fetch_open_orders(&self, market_id: Option<&str>) -> Result<Vec<Order>, PMXTError>;

    /// Fetch account balance
    async fn fetch_balance(&self) -> Result<Vec<Balance>, PMXTError>;

    /// Fetch current positions
    async fn fetch_positions(&self) -> Result<Vec<Position>, PMXTError>;

    /// Watch tickers (Streaming)
    /// Returns a message every time a trade happens or price moves.
    async fn watch_tickers(&self) -> Result<Ticker, PMXTError>;

    /// Watch order book (Streaming)
    async fn watch_order_book(&self, market_id: &str, outcome_id: &str) -> Result<OrderBook, PMXTError>;
}
