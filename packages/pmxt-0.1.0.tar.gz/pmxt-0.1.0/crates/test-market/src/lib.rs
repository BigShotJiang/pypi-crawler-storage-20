use async_trait::async_trait;
use pmxt_core::{
    Balance, Exchange, Market, Order, OrderBook, OrderSide, OrderStatus, Outcome, PMXTError, Ticker, Position
};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use chrono::Utc;
use rust_decimal::Decimal;
use rust_decimal_macros::dec;

/// A simple in-memory exchange for testing logic
#[derive(Clone)]
pub struct TestMarket {
    /// In-memory state: Orders
    orders: Arc<Mutex<HashMap<String, Order>>>,
    /// In-memory state: Balances
    balances: Arc<Mutex<Vec<Balance>>>,
    /// In-memory state: Positions
    positions: Arc<Mutex<Vec<Position>>>,
    /// In-memory state: Markets
    markets: Vec<Market>,
    /// Toggle for AMM behavior
    pub is_amm: bool,
}

impl TestMarket {
    pub fn new(is_amm: bool) -> Self {
        // Create a fake market
        let trump_market = Market {
            id: "market-1".to_string(),
            symbol: "TEST-TRUMP".to_string(),
            title: "Test: Will Trump Win?".to_string(),
            description: Some("A test market for development".to_string()),
            outcomes: vec![
                Outcome { id: "0".to_string(), name: "Yes".to_string() },
                Outcome { id: "1".to_string(), name: "No".to_string() },
            ],
            active: true,
            end_time: Some(Utc::now() + chrono::Duration::days(30)),
        };

        let initial_balance = Balance {
            currency: "USD".to_string(),
            free: dec!(100000.0),
            used: dec!(0.0),
            total: dec!(100000.0),
        };

        Self {
            orders: Arc::new(Mutex::new(HashMap::new())),
            balances: Arc::new(Mutex::new(vec![initial_balance])),
            positions: Arc::new(Mutex::new(vec![])),
            markets: vec![trump_market],
            is_amm,
        }
    }

    /// Calculate a synthetic order book for an AMM
    fn calculate_synthetic_book(&self) -> OrderBook {
        let mid_price = dec!(0.50);
        let mut bids = Vec::new();
        let mut asks = Vec::new();

        // Generate 10 levels of synthetic depth
        for i in 1..=10 {
            let offset = Decimal::from(i) * dec!(0.01);
            let size = dec!(100.0) * Decimal::from(i);
            
            bids.push((mid_price - offset, size));
            asks.push((mid_price + offset, size));
        }

        OrderBook {
            bids,
            asks,
            timestamp: Some(Utc::now()),
        }
    }
}

#[async_trait]
impl Exchange for TestMarket {
    fn id(&self) -> &'static str {
        "test-market"
    }

    fn capabilities(&self) -> Vec<pmxt_core::Capability> {
        if self.is_amm {
            vec![
                pmxt_core::Capability::AMM,
                pmxt_core::Capability::MarketOrders,
                pmxt_core::Capability::FetchBalance,
            ]
        } else {
            vec![
                pmxt_core::Capability::OrderBook,
                pmxt_core::Capability::LimitOrders,
                pmxt_core::Capability::CancelOrders,
                pmxt_core::Capability::FetchBalance,
            ]
        }
    }

    async fn load_markets(&self) -> Result<Vec<Market>, PMXTError> {
        Ok(self.markets.clone())
    }

    async fn fetch_order_book(
        &self,
        _market_id: &str,
        _outcome_id: &str,
    ) -> Result<OrderBook, PMXTError> {
        if self.is_amm {
            Ok(self.calculate_synthetic_book())
        } else {
            Ok(OrderBook {
                bids: vec![(dec!(0.50), dec!(100.0)), (dec!(0.49), dec!(500.0))],
                asks: vec![(dec!(0.52), dec!(200.0)), (dec!(0.55), dec!(300.0))],
                timestamp: Some(Utc::now()),
            })
        }
    }

    async fn fetch_amm_state(&self, market_id: &str) -> Result<pmxt_core::AMMState, PMXTError> {
        if !self.is_amm {
            return Err(PMXTError::NotImplemented);
        }

        let mut balances = HashMap::new();
        balances.insert("0".to_string(), dec!(50000.0));
        balances.insert("1".to_string(), dec!(50000.0));

        Ok(pmxt_core::AMMState {
            market_id: market_id.to_string(),
            curve_type: "CPMM".to_string(),
            k: dec!(2500000000.0),
            liquidity: dec!(100000.0),
            pool_balances: balances,
            timestamp: Utc::now(),
        })
    }

    async fn fetch_tickers(&self) -> Result<Vec<Ticker>, PMXTError> {
        Ok(vec![Ticker {
            market_id: "market-1".to_string(),
            outcome_id: "0".to_string(),
            price: dec!(0.51),
            bid: Some(dec!(0.50)),
            ask: Some(dec!(0.52)),
            timestamp: Utc::now(),
        }])
    }

    async fn create_order(
        &self,
        market_id: &str,
        outcome_id: &str,
        side: OrderSide,
        amount: Decimal,
        price: Option<Decimal>,
    ) -> Result<Order, PMXTError> {
        // Verify market exists
        if !self.markets.iter().any(|m| m.id == market_id) {
            return Err(PMXTError::ApiError("Market not found".to_string()));
        }

        let execution_price = price.unwrap_or(dec!(0.51));
        let cost = amount * execution_price;

        // Update Balance
        {
            let mut balances = self.balances.lock().unwrap();
            if let Some(bal) = balances.iter_mut().find(|b| b.currency == "USD") {
                if bal.free < cost {
                    return Err(PMXTError::InsufficientFunds);
                }
                bal.free -= cost;
                bal.used += cost; // Simplified: actually used represents open orders or locked capital
            }
        }

        let order_id = uuid::Uuid::new_v4().to_string();
        let order = Order {
            id: order_id.clone(),
            market_id: market_id.to_string(),
            outcome_id: outcome_id.to_string(),
            price: execution_price,
            amount,
            side,
            status: OrderStatus::Open,
            timestamp: Utc::now(),
        };

        // If it's a market-like order in our test env, let's auto-fill it and create a position
        let mut filled_order = order.clone();
        filled_order.status = OrderStatus::Closed;

        self.orders.lock().unwrap().insert(order_id.clone(), filled_order);

        // Update Position
        {
            let mut positions = self.positions.lock().unwrap();
            let pos = positions.iter_mut().find(|p| p.market_id == market_id && p.outcome_id == outcome_id);
            if let Some(p) = pos {
                if side == OrderSide::Buy {
                    p.amount += amount;
                } else {
                    p.amount -= amount;
                }
            } else if side == OrderSide::Buy {
                positions.push(pmxt_core::Position {
                    market_id: market_id.to_string(),
                    outcome_id: outcome_id.to_string(),
                    amount,
                    entry_price: execution_price,
                    unrealized_pnl: Some(dec!(0.0)),
                });
            }
        }

        Ok(order)
    }

    async fn cancel_order(&self, order_id: &str) -> Result<(), PMXTError> {
        let mut orders = self.orders.lock().unwrap();
        if let Some(order) = orders.get_mut(order_id) {
            order.status = OrderStatus::Canceled;
            Ok(())
        } else {
            Err(PMXTError::OrderNotFound)
        }
    }

    async fn fetch_open_orders(&self, market_id: Option<&str>) -> Result<Vec<Order>, PMXTError> {
        let orders = self.orders.lock().unwrap();
        Ok(orders.values()
            .filter(|o| o.status == OrderStatus::Open)
            .filter(|o| market_id.map(|mid| o.market_id == mid).unwrap_or(true))
            .cloned()
            .collect())
    }

    async fn fetch_balance(&self) -> Result<Vec<Balance>, PMXTError> {
        Ok(self.balances.lock().unwrap().clone())
    }

    async fn fetch_positions(&self) -> Result<Vec<Position>, PMXTError> {
        Ok(self.positions.lock().unwrap().clone())
    }

    async fn watch_tickers(&self) -> Result<Ticker, PMXTError> {
        // Simulate a delay for "real-time" feel
        tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
        
        Ok(Ticker {
            market_id: "market-1".to_string(),
            outcome_id: "0".to_string(),
            price: dec!(0.52), // "Price update"
            bid: Some(dec!(0.51)),
            ask: Some(dec!(0.53)),
            timestamp: Utc::now(),
        })
    }

    async fn watch_order_book(&self, market_id: &str, outcome_id: &str) -> Result<OrderBook, PMXTError> {
        tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
        self.fetch_order_book(market_id, outcome_id).await
    }
}
