# PMXT: The ccxt for Prediction Markets

PMXT is a unified endpoint for trading on prediction markets (Polymarket, Kalshi, etc.), written in Rust for performance with native bindings for Python and Node.js.

## Architecture

This project is organized as a Cargo Workspace:

- **`crates/core`**: Defines the shared `Exchange` trait and data models (`Market`, `Order`, `Ticker`).
- **`crates/polymarket`**: The implementation for Polymarket.
- **`bindings/python`**: The native Python extension (using PyO3).

## Development

### Prerequisites

- Rust (cargo)
- Python 3.9+
- `maturin` (for building Python bindings) -> `pip install maturin`

### Building Python Bindings

To build and install the python library into your current environment:

```bash
cd bindings/python
maturin develop
```

### Usage (Python)

```python
import pmxt
import asyncio

async def main():
    exchange = pmxt.Polymarket(api_key="your_key")
    markets = await exchange.load_markets()
    print(markets)

asyncio.run(main())
```

## Contributing

1. Implement `Exchange` trait for a new market in `crates/new_market`.
2. Register it in `bindings/python/src/lib.rs`.
