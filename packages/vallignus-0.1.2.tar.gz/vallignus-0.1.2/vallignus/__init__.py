"""Vallignus - Agent Firewall Proxy"""

__version__ = "0.1.2"
