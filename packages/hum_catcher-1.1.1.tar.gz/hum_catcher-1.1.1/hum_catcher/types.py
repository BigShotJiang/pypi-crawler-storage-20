import dataclasses
from datetime import datetime, timedelta
from typing import List, Optional, Tuple, Any
import numpy as np

@dataclasses.dataclass
class Signal:
    """An ENF signal with its associated attributes."""
    network_frequency: float
    signal_frequency: float
    signal: np.ma.masked_array 
    begins_at: Optional[datetime] = None

    @property
    def signal_sampling_rate(self) -> timedelta:
        return timedelta(seconds=1.0 / self.signal_frequency)

    @property
    def duration(self) -> timedelta:
        return self.signal_sampling_rate * len(self.signal)

    @property
    def ends_at(self) -> Optional[datetime]:
        if self.begins_at is not None:
            return self.begins_at + self.duration
        return None

    def quality(self) -> float:
        return 1.0 - np.mean(self.signal.mask)

@dataclasses.dataclass
class Match:
    """A single result of a time matching comparison between two ENF signals."""
    offset: timedelta
    duration: timedelta
    corr_coeff: float
    rmse: float
    score: float

@dataclasses.dataclass
class AnalysisResult:
    """The result of the detection of an ENF signal from an audio file."""
    enf: Signal
    spectrum: Tuple[np.ndarray, np.ndarray, np.ndarray] 
    snr: np.ndarray
    frequency_harmonic: int
    extra_frequency_harmonics: List[int] = dataclasses.field(default_factory=list)