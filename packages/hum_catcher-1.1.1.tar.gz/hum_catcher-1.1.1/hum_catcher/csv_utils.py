import sys
import csv
import numpy as np
import scipy.interpolate
from datetime import datetime, timezone, timedelta
from tqdm import tqdm
from . import ui

try:
    from dateutil import parser as date_parser
    HAS_DATEUTIL = True
except ImportError:
    HAS_DATEUTIL = False

def _parse_datetime_universal(dt_str):
    if HAS_DATEUTIL:
        try:
            return date_parser.parse(dt_str)
        except Exception:
            pass
    
    formats = [
        "%d.%m.%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S",
        "%d/%m/%Y %H:%M:%S", "%Y/%m/%d %H:%M:%S",
        "%d-%m-%Y %H:%M:%S", "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%SZ", "%d.%m.%Y %H:%M",
        "%Y-%m-%d %H:%M",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(dt_str, fmt)
        except ValueError:
            continue
    raise ValueError(f"Could not parse datetime: {dt_str}")

def configure_csv_parsing(filepath):
    print(f"\n--- CSV Configuration: {filepath} ---")
    print("  (Type 'q', 'quit' or 'exit' at any prompt to exit)")
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            sample = f.read(4096)
            f.seek(0)
            total_rows = sum(1 for _ in f)
            f.seek(0)
            raw_lines = []
            for _ in range(5):
                line = f.readline()
                if not line: break
                raw_lines.append(line.rstrip('\n'))
    except Exception as e:
        print(f"Error reading CSV: {e}")
        sys.exit(1)

    print(f"  > Total Rows: {total_rows}")
    print("\n  > Raw File Content (First 5 lines):")
    for i, line in enumerate(raw_lines):
        print(f"    Line {i}: {line}")

    try:
        sniff_dialect = csv.Sniffer().sniff(sample)
        default_delimiter = sniff_dialect.delimiter
        has_header_sniffed = csv.Sniffer().has_header(sample)
    except csv.Error:
        default_delimiter = ';'
        has_header_sniffed = True

    print(f"\n  > Detected Header: {'Yes' if has_header_sniffed else 'No'}")
    has_header = ui.ask_bool("  > Does the CSV have a header?", default=has_header_sniffed)

    print(f"\n  > Detected Separator: '{default_delimiter}'")
    u_delim = ui.ask_input(f"  > Enter separator (e.g. , or ; or \\t) [default: '{default_delimiter}']: ")
    if u_delim == '\\t' or u_delim.lower() == 'tab':
        delimiter = '\t'
    elif u_delim:
        delimiter = u_delim
    else:
        delimiter = default_delimiter
        
    if len(delimiter) != 1:
        print(f"  > Warning: Separator '{delimiter}' is invalid. Using default '{default_delimiter}'.")
        delimiter = default_delimiter

    rows = []
    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.reader(f, delimiter=delimiter)
        for i, row in enumerate(reader):
            if i >= 5: break
            rows.append(row)
            
    num_cols = len(rows[0]) if rows else 0
    print(f"\n  > Parsed Data Preview (using separator '{delimiter}'):")
    print(f"  > Detected Columns: {num_cols}")
    for i, row in enumerate(rows):
        print(f"    Row {i}: {row}")

    print("\n  > Select Date/Time Format:")
    print("    1. Date and Time in the SAME column (e.g., '2025-01-01 12:00:00' or Unix Timestamp)")
    print("    2. Date and Time in SEPARATED columns")
    while True:
        mode_input = ui.ask_input("  > Choice [1/2]: ").strip()
        if mode_input in ['1', '2']:
            break
        print("  > Error: Please enter '1' or '2'.")

    config = {
        'has_header': has_header,
        'delimiter': delimiter,
        'mode': 'combined' if mode_input == '1' else 'separated',
        'total_rows': total_rows
    }
    
    def get_col_idx(prompt):
        while True:
            try:
                val_str = ui.ask_input(prompt)
                val = int(val_str)
                if 0 <= val < num_cols:
                    return val
                print(f"    Error: Column index must be between 0 and {num_cols-1}")
            except ValueError:
                print(f"    Error: Please enter a number between 0 and {num_cols-1}.")

    if config['mode'] == 'combined':
        config['dt_col'] = get_col_idx("  > Enter Column Index for Date/Time (0-based): ")
        config['freq_col'] = get_col_idx("  > Enter Column Index for Frequency (0-based): ")
        
        is_likely_unix = False
        try:
            check_row_idx = 1 if has_header and len(rows) > 1 else 0
            if len(rows) > check_row_idx:
                sample_val = rows[check_row_idx][config['dt_col']].strip().strip('"\'')
                float_val = float(sample_val)
                if 100_000_000 < float_val < 10_000_000_000:
                    is_likely_unix = True
        except (ValueError, IndexError):
            pass

        if is_likely_unix:
            print("  > Detected likely Unix timestamp format.")
        config['is_unix'] = ui.ask_bool("  > Is this a Unix/Epoch timestamp?", default=is_likely_unix)
    else:
        config['date_col'] = get_col_idx("  > Enter Column Index for Date (0-based): ")
        config['time_col'] = get_col_idx("  > Enter Column Index for Time (0-based): ")
        config['freq_col'] = get_col_idx("  > Enter Column Index for Frequency (0-based): ")
        config['is_unix'] = False

    sample_data_row = rows[1] if has_header and len(rows) > 1 else rows[0]
    detected_tz = None
    if not config['is_unix']:
        try:
            if config['mode'] == 'combined':
                dt_str = sample_data_row[config['dt_col']]
            else:
                dt_str = f"{sample_data_row[config['date_col']]} {sample_data_row[config['time_col']]}"
            dt = _parse_datetime_universal(dt_str)
            if dt.tzinfo is not None:
                detected_tz = dt.tzinfo
        except Exception:
            pass

    if detected_tz:
        print(f"\n  > Detected Timezone in data: {detected_tz}")
        if ui.ask_bool("  > Use this timezone?", default=True):
            config['timezone'] = detected_tz
        else:
            config['timezone'] = ui.get_timezone_from_user()
    elif config['is_unix']:
        print("\n  > Unix timestamp detected.")
        config['timezone'] = ui.get_timezone_from_user()
    else:
        print("\n  > No timezone detected in data.")
        config['timezone'] = ui.get_timezone_from_user()
    return config

def parse_csv_grid_data(filepath, config, network_frequency=50.0):
    total_rows = config['total_rows']
    timestamps = np.empty(total_rows, dtype=np.float64)
    freqs = np.empty(total_rows, dtype=np.float32)
    
    valid_count = 0

    with open(filepath, 'r', encoding='utf-8') as f:
        reader = csv.reader(f, delimiter=config['delimiter'])
        if config['has_header']:
            next(reader, None)

        for row in tqdm(reader, total=total_rows, desc="Parsing CSV", unit="rows"):
            if not row: continue
            try:
                freq_str = row[config['freq_col']]
                freq = float(freq_str.replace(',', '.'))
                deviation = freq - network_frequency
                dt = None
                if config['mode'] == 'combined':
                    val = row[config['dt_col']]
                    if config['is_unix']:
                        timestamp = float(val)
                    else:
                        dt = _parse_datetime_universal(val)
                        if dt.tzinfo is None and config['timezone']:
                            dt = dt.replace(tzinfo=config['timezone'])
                        timestamp = dt.timestamp()
                else:
                    date_str = row[config['date_col']]
                    time_str = row[config['time_col']]
                    dt_str = f"{date_str} {time_str}"
                    dt = _parse_datetime_universal(dt_str)
                    if dt.tzinfo is None and config['timezone']:
                        dt = dt.replace(tzinfo=config['timezone'])
                    timestamp = dt.timestamp()
                
                timestamps[valid_count] = timestamp
                freqs[valid_count] = deviation
                valid_count += 1
            except (ValueError, IndexError):
                continue
    
    timestamps = timestamps[:valid_count]
    freqs = freqs[:valid_count]
    
    sort_idxs = np.argsort(timestamps)
    return timestamps[sort_idxs], freqs[sort_idxs]

def resample_with_progress(sparse_data, frequency):
    timestamps, values = sparse_data
    
    if len(timestamps) == 0:
         return np.ma.empty(0), None

    t0_ts = timestamps[0]
    begins_at_dt = datetime.fromtimestamp(t0_ts, tz=timezone.utc)

    def round_datetime(dt: datetime) -> datetime:
        if dt.microsecond < 500_000:
            return dt.replace(microsecond=0)
        else:
            return dt.replace(microsecond=0) + timedelta(seconds=1)

    begins_at = round_datetime(begins_at_dt)
    t_end_ts = timestamps[-1]
    
    sampling_interval = 1.0 / frequency
    
    start_offset = t0_ts - begins_at.timestamp() 
    
    duration_sec = t_end_ts - begins_at.timestamp()
    n_samples = int(duration_sec * frequency)
    
    x_src = timestamps - begins_at.timestamp()
    y_src = values
    
    kind = 'cubic' if len(x_src) > 3 else 'linear'
    interpolator = scipy.interpolate.interp1d(
        x_src, y_src, kind=kind, bounds_error=False, fill_value=np.nan,
        copy=False, assume_sorted=True
    )
    
    y_dst = np.empty(n_samples, dtype=np.float32)
    chunk_size = 1_000_000
    
    with tqdm(total=n_samples, desc="Resampling Grid", unit="samples") as pbar:
        for i in range(0, n_samples, chunk_size):
            chunk_end = min(i + chunk_size, n_samples)
            x_dst_chunk = np.arange(i, chunk_end, dtype=np.float64) * sampling_interval
            y_dst[i:chunk_end] = interpolator(x_dst_chunk)
            pbar.update(chunk_end - i)

    gap_threshold = 4.0 * sampling_interval
    src_diffs = np.diff(x_src)
    gap_indices = np.where(src_diffs > gap_threshold)[0]
    
    if len(gap_indices) > 0:
        mask_margin = 2.0 * sampling_interval
        for i in gap_indices:
            t_gap_start = x_src[i] + mask_margin
            t_gap_end = x_src[i+1] - mask_margin
            idx_start = int(np.ceil(t_gap_start * frequency))
            idx_end = int(np.floor(t_gap_end * frequency))
            idx_start = max(0, idx_start)
            idx_end = min(n_samples, idx_end)
            if idx_start < idx_end:
                y_dst[idx_start:idx_end] = np.nan

    mask = np.isnan(y_dst)
    signal = np.ma.masked_array(y_dst, mask=mask)
    return signal, begins_at