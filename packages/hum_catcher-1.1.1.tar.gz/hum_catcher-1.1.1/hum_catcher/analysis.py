import math
import enum
import numpy as np
import scipy.signal
import scipy.ndimage
import audiofile
import ffmpeg
import tempfile
import os
from datetime import timedelta
from typing import List, Tuple, Optional
from .types import AnalysisResult, Signal

Spectrum = Tuple[np.ndarray, np.ndarray, np.ndarray]

def read_audio(path: str) -> Tuple[np.ndarray, float]:
    try:
        data, frequency = audiofile.read(path, always_2d=True)
        return np.mean(data, axis=0), float(frequency)
    except Exception:
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            tmp_path = tmp.name
        
        try:
            (
                ffmpeg
                .input(path)
                .output(tmp_path, ac=1, vn=None, loglevel="quiet")
                .overwrite_output()
                .run()
            )
            data, frequency = audiofile.read(tmp_path, always_2d=True)
            return np.mean(data, axis=0), float(frequency)
        except ffmpeg.Error as e:
            raise RuntimeError(f"FFmpeg error: {e.stderr.decode() if e.stderr else str(e)}")
        finally:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)

MIN_DECIMATED_FREQUENCY = 1000.0
SPECTRUM_BAND_SIZE = 0.25
STFT_WINDOW_SIZE = timedelta(seconds=16)
NORMALIZE_WINDOW_SIZE = timedelta(seconds=24)
ENF_OUTPUT_FREQUENCY = 1.0
ENF_GAUSSIAN_SIGMA = 3.5
ENF_HIGH_SNR_THRES = 2.85
ENF_HIGH_SNR_MIN_DURATION = timedelta(seconds=8)
ENF_LOW_SNR_THRES = 1.6
ENF_MAX_GRADIENT = 0.0025
ENF_ARTIFACT_MAX_DURATION = timedelta(seconds=0)
ENF_HARMONIC_MIN_QUALITY = 0.075
ENF_HARMONIC_MIN_CORR_COEFF = 0.5
ENF_HARMONIC_MIN_MATCH_LENGTH = 0.05

def compute_enf(
    signal: np.ndarray, signal_frequency: float, network_frequency: float = 50.0,
    frequency_harmonics: List[int] = [1, 2, 3, 4, 5, 6, 7, 8],
) -> Optional[AnalysisResult]:
    
    duration_seconds = len(signal) / signal_frequency
    required_seconds = STFT_WINDOW_SIZE.total_seconds()
    
    if duration_seconds < required_seconds:
        print(f"Error: Media file is too short ({duration_seconds:.2f}s < {required_seconds}s).")
        return None

    decimated_signal, decimated_frequency = _signal_decimate(signal, signal_frequency)

    spectrums = _signal_spectrums(
        decimated_signal, decimated_frequency, network_frequency, frequency_harmonics
    )

    results = [
        _detect_enf(harmonic_spectrum, network_frequency, frequency_harmonic)
        for frequency_harmonic, harmonic_spectrum in zip(frequency_harmonics, spectrums)
    ]

    valid_results = [
        (result, spectrum)
        for result, spectrum in zip(results, spectrums)
        if result.enf.quality() >= ENF_HARMONIC_MIN_QUALITY
    ]

    if len(valid_results) == 0:
        return None
    else:
        return _combined_harmonics_result(network_frequency, valid_results)

def _signal_decimate(signal: np.ndarray, signal_frequency: float) -> Tuple[np.ndarray, float]:
    if signal_frequency <= MIN_DECIMATED_FREQUENCY:
        return signal, signal_frequency

    decimation_q = int(signal_frequency // MIN_DECIMATED_FREQUENCY)
    if decimation_q <= 1:
        return signal, signal_frequency

    downsampled_frequency = signal_frequency / decimation_q
    assert downsampled_frequency >= MIN_DECIMATED_FREQUENCY

    return scipy.signal.decimate(signal, decimation_q, ftype="fir", n=16), downsampled_frequency

def _signal_spectrums(
    signal: np.ndarray, signal_frequency: float, network_frequency: float,
    frequency_harmonics: List[int],
) -> List[Spectrum]:
    lo_hi_cuts = [
        (
            harmonic * (network_frequency - SPECTRUM_BAND_SIZE),
            harmonic * (network_frequency + SPECTRUM_BAND_SIZE)
        )
        for harmonic in frequency_harmonics
    ]
    filtered_data = _bandpass_filter(signal, signal_frequency, lo_hi_cuts, order=10)
    return _stft(filtered_data, signal_frequency, lo_hi_cuts)

def _bandpass_filter(
    signal: np.ndarray, frequency: float, lo_hi_cuts: List[Tuple[int, int]], order: int
) -> np.ndarray:
    filtered_data = None
    for lo_cut, hi_cut in lo_hi_cuts:
        nyq = 0.5 * frequency
        low = lo_cut / nyq
        high = hi_cut / nyq
        sos = scipy.signal.butter(order, [low, high], analog=False, btype='band', output='sos')
        harmonic_filtered_data = scipy.signal.sosfilt(sos, signal)
        if filtered_data is None:
            filtered_data = harmonic_filtered_data
        else:
            filtered_data += harmonic_filtered_data
    return filtered_data

def _stft(
    signal: np.ndarray, frequency: float, lo_hi_cuts: List[Tuple[int, int]],
) -> List[Spectrum]:
    STFT_CHUNK_SIZE = 256
    signal_duration = len(signal) / frequency
    window_size_seconds = min(signal_duration, STFT_WINDOW_SIZE.total_seconds())
    n_perseg = int(frequency * window_size_seconds)
    n_overlap = int(frequency * window_size_seconds - frequency / ENF_OUTPUT_FREQUENCY)

    ts = []
    Zxxs = []
    hopsize = n_perseg - n_overlap
    output_len = math.ceil(len(signal) / hopsize) + 1
    window_half_size = n_perseg // 2

    for chunk_begin in range(0, output_len, STFT_CHUNK_SIZE):
        chunk_end = chunk_begin + STFT_CHUNK_SIZE
        signal_begin = max(
            0,
            int(chunk_begin / ENF_OUTPUT_FREQUENCY * frequency - window_half_size)
        )
        signal_end = int(chunk_end / ENF_OUTPUT_FREQUENCY * frequency + window_half_size)
        chunk = signal[signal_begin:signal_end]

        if len(chunk) < n_perseg:
            break

        if signal_begin == 0:
            output_begin = 0
        else:
            output_begin = int(window_half_size / frequency * ENF_OUTPUT_FREQUENCY)

        f, t, Zxx = scipy.signal.stft(chunk, frequency, nperseg=n_perseg, noverlap=n_overlap, scaling="psd")
        Zxx = abs(Zxx)**2
        band_f_idxs = None

        for lo_cut, hi_cut in lo_hi_cuts:
            harmonic_f_idxs = (f >= lo_cut) & (f <= hi_cut)
            if band_f_idxs is None:
                band_f_idxs = harmonic_f_idxs
            else:
                band_f_idxs |= harmonic_f_idxs

        f = f[band_f_idxs]
        ts.append(t[output_begin:output_begin+STFT_CHUNK_SIZE] + chunk_begin / ENF_OUTPUT_FREQUENCY)
        Zxxs.append(Zxx[band_f_idxs, output_begin:output_begin+STFT_CHUNK_SIZE])

    t = np.concatenate(ts)
    Zxx = np.concatenate(Zxxs, axis=1)

    return [
        (f[(f >= lo_cut) & (f <= hi_cut)], t, Zxx[(f >= lo_cut) & (f <= hi_cut)])
        for lo_cut, hi_cut in lo_hi_cuts
    ]

def _spectrum_normalize(spectrum: Spectrum, signal_frequency: float) -> Spectrum:
    f, t, Zxx = spectrum
    if NORMALIZE_WINDOW_SIZE is None:
        mean = np.mean(Zxx)
        std = np.std(Zxx)
        return np.abs((Zxx - mean) / std)

    window_size = round(NORMALIZE_WINDOW_SIZE.total_seconds() * signal_frequency)
    Zxx = np.abs(Zxx).transpose()
    normalized = np.empty(Zxx.shape)

    for i in range(0, len(Zxx)):
        window_begin = max(0, i - window_size // 2)
        window_end = min(len(Zxx), i + window_size // 2)
        window = Zxx[window_begin:window_end]
        mean = np.mean(window)
        std = np.std(window)
        if std == 0.0:
            normalized[i] = 0.0
        else:
            normalized[i] = (Zxx[i] - mean) / std

    return f, t, np.abs(normalized).transpose()

def _detect_enf(
    spectrum: Spectrum, network_frequency: float, frequency_harmonic: int,
    extra_frequency_harmonics: List[int] = [],
) -> AnalysisResult:
    normalized_spectrum = _spectrum_normalize(spectrum, ENF_OUTPUT_FREQUENCY)
    f, t, Zxx = normalized_spectrum

    if len(f) < 2 or len(t) < 1:
        duration = timedelta(seconds=t[-1] - t[0])
        raise ValueError(f"unable to compute spectrum on signal of duration {duration}.")

    bin_size = f[1] - f[0]
    enf = np.empty(len(t), dtype=np.float16)
    snrs = np.empty(len(t), dtype=np.float32)

    for i, sub_spectrum in enumerate(Zxx.transpose()):
        max_amp = np.amax(sub_spectrum)
        max_amp_idx = np.where(sub_spectrum == max_amp)[0][0]
        max_amp_freq = f[0] + _quadratic_interpolation(sub_spectrum, max_amp_idx, bin_size)
        enf[i] = max_amp_freq / frequency_harmonic - network_frequency
        sub_spectrum_mean = np.mean(sub_spectrum)
        if sub_spectrum_mean == 0.0:
            snrs[i] = 0
        else:
            snrs[i] = max_amp / sub_spectrum_mean

    enf = _post_process_enf(enf, snrs)
    enf_signal = Signal(
        network_frequency=network_frequency,
        signal=enf,
        signal_frequency=ENF_OUTPUT_FREQUENCY,
    )
    return AnalysisResult(
        enf=enf_signal,
        spectrum=normalized_spectrum,
        snr=snrs,
        frequency_harmonic=frequency_harmonic,
        extra_frequency_harmonics=extra_frequency_harmonics,
    )

def _quadratic_interpolation(spectrum, max_amp_idx, bin_size):
    center = spectrum[max_amp_idx]
    left = spectrum[max_amp_idx - 1] if max_amp_idx > 0 else center
    right = spectrum[max_amp_idx + 1] if max_amp_idx + 1 < len(spectrum) else center
    denominator = left - 2 * center + right
    if denominator == 0.0:
        return center
    p = 0.5 * (left - right) / denominator
    interpolated = (max_amp_idx + p) * bin_size
    return interpolated

def _post_process_enf(enf: np.ndarray, snrs: np.ndarray) -> np.ma.masked_array:
    smoothed = _gaussian_filter_enf(enf)
    clipped = np.ma.masked_where(
        (smoothed < -SPECTRUM_BAND_SIZE) | (smoothed > SPECTRUM_BAND_SIZE),
        smoothed
    )
    clipped.fill_value = np.nan
    thresholded = _threshold_enf(clipped, snrs)
    return thresholded

def _gaussian_filter_enf(enf: np.ma.masked_array) -> np.ma.masked_array:
    if ENF_GAUSSIAN_SIGMA is None:
        return enf
    return scipy.ndimage.gaussian_filter1d(
        enf.astype(np.float64), sigma=ENF_GAUSSIAN_SIGMA
    ).astype(np.float16)

def _threshold_enf(enf: np.ma.masked_array, snrs: np.ndarray) -> np.ma.masked_array:
    min_section_len = ENF_OUTPUT_FREQUENCY * ENF_HIGH_SNR_MIN_DURATION.total_seconds()
    max_artifact_len = ENF_OUTPUT_FREQUENCY * ENF_ARTIFACT_MAX_DURATION.total_seconds()
    max_gradient = ENF_MAX_GRADIENT / ENF_OUTPUT_FREQUENCY

    def clipped(i: int) -> bool:
        return np.ma.is_masked(enf) and enf.mask[i]
    def above_low_threshold(i: int) -> bool:
        return snrs[i] >= ENF_LOW_SNR_THRES
    def above_high_threshold(i: int) -> bool:
        return snrs[i] >= ENF_HIGH_SNR_THRES
    def above_min_section_duration(section_duration: int) -> bool:
        return section_duration >= min_section_len
    
    gradient = np.abs(np.gradient(enf))
    def below_max_gradient(i: int) -> bool:
        return gradient[i] <= max_gradient

    class FilterState(enum.Enum):
        SEARCHING = 1
        ABOVE_HIGH_THRESHOLD = 2
        IN_VALID_SECTION = 3
        IN_ARTIFACT = 4

    state = FilterState.SEARCHING
    section_len = None
    artifact_len = None
    artifact_total_gradient = None
    thres_mask = np.ma.masked_all(len(enf)).mask
    i = 0
    while i < len(enf):
        if state == FilterState.SEARCHING:
            if not clipped(i) and above_high_threshold(i) and below_max_gradient(i):
                section_len = 1
                state = FilterState.ABOVE_HIGH_THRESHOLD
        elif state == FilterState.ABOVE_HIGH_THRESHOLD:
            if not clipped(i) and above_high_threshold(i) and below_max_gradient(i):
                section_len += 1
                if above_min_section_duration(section_len):
                    state = FilterState.IN_VALID_SECTION
                    thres_mask[i] = False
                    artifact_len = 0
                    artifact_total_gradient = 0
                    j = i - 1
                    while j >= 0 and thres_mask[j] and artifact_len <= max_artifact_len:
                        artifact_len += 1
                        artifact_total_gradient += gradient[i]
                        if (not clipped(j) and above_low_threshold(j) and below_max_gradient(j) and
                            artifact_total_gradient / artifact_len < max_gradient):
                            thres_mask[j] = False
                            artifact_len = 0
                            artifact_total_gradient = 0
                        j -= 1
            else:
                state = FilterState.SEARCHING
        elif state == FilterState.IN_VALID_SECTION:
            if not clipped(i) and above_low_threshold(i) and below_max_gradient(i):
                thres_mask[i] = False
            else:
                state = FilterState.IN_ARTIFACT
                artifact_len = 1
                artifact_total_gradient = gradient[i]
        elif state == FilterState.IN_ARTIFACT:
            if (not clipped(i) and above_low_threshold(i) and below_max_gradient(i) and
                (artifact_total_gradient / artifact_len < max_gradient or above_high_threshold(i))):
                thres_mask[i] = False
                state = FilterState.IN_VALID_SECTION
            else:
                artifact_len += 1
                artifact_total_gradient += gradient[i]
                if artifact_len > max_artifact_len:
                    thres_mask[i] = False
                    state = FilterState.SEARCHING
        i += 1
    return np.ma.array(enf, mask=enf.mask | thres_mask, fill_value=np.nan)

def _combined_harmonics_result(
    network_frequency: float,
    results: List[Tuple[AnalysisResult, Spectrum]]
) -> AnalysisResult:
    from .match import _corr_coeff
    if len(results) < 1:
        raise ValueError("at least one harmonic analysis result is required.")
    sorted_results = sorted(results, key=lambda result: result[0].frequency_harmonic)
    output_result, output_spectrum = sorted_results[0]
    output_extra_harmonics = []
    
    for result, spectrum in sorted_results[1:]:
        corr_coeff, length = _corr_coeff(output_result.enf.signal, result.enf.signal)
        match_length = length / len(output_result.enf.signal)
        if corr_coeff < ENF_HARMONIC_MIN_CORR_COEFF or match_length < ENF_HARMONIC_MIN_MATCH_LENGTH:
            continue
        combined_spectrum = _combine_spectrums(
            spectrum, result.frequency_harmonic,
            output_spectrum, output_result.frequency_harmonic,
        )
        combined_extra_harmonics = output_extra_harmonics + [result.frequency_harmonic]
        combined_result = _detect_enf(
            combined_spectrum, network_frequency, output_result.frequency_harmonic,
            combined_extra_harmonics,
        )
        if combined_result.enf.quality() > output_result.enf.quality():
            output_result = combined_result
            combined_extra_harmonics = combined_extra_harmonics 
    return output_result

def _combine_spectrums(
    source: Spectrum, source_harmonic: int,
    target: Spectrum, target_harmonic: int,
) -> Spectrum:
    source_f, source_t, source_Zxx = source
    target_f, target_t, target_Zxx = target
    source_f = source_f / source_harmonic
    target_f = target_f / target_harmonic
    combined_Zxx = target_Zxx.transpose()
    for t, _ in enumerate(source_t):
        combined_Zxx[t] = combined_Zxx[t] + np.interp(target_f, source_f, source_Zxx[:,t])
    return target[0], target_t, combined_Zxx.transpose()