import argparse
import sys
import threading
import numpy as np
from datetime import timedelta, timezone
from typing import Optional

from . import analysis, match, csv_utils, ui
from .types import Signal
from .match import MatchBackend

def main():
    parser = argparse.ArgumentParser(description="Match media ENF against CSV grid data.")
    
    parser.add_argument("media_file", nargs='?', help="Path to the target media file (audio or video)")
    parser.add_argument("csv_file", nargs='?', help="Path to the reference CSV grid frequency file")
    
    parser.add_argument("--frequency", "-f", type=float, default=50.0, help="Network frequency (default: 50.0)")
    parser.add_argument("--backend", "-b", choices=["numpy", "opencl"], default="numpy", help="Matching backend (default: numpy)")
    parser.add_argument("--max-matches", "-m", type=int, default=10, help="Number of top matches to display")
    parser.add_argument("--plot-match", "-pm", action="store_true", help="Plot the best match result")
    parser.add_argument("--plot-target", "-pt", nargs='?', const=True, help="Plot the extracted target ENF signal")
    parser.add_argument("--plot-reference", "-pr", nargs='?', const=True, help="Plot the reference ENF signal from CSV")
    parser.add_argument("--exhaustive", "-e", action="store_true", help="Perform exhaustive search (slower but more accurate, skips approximation)")
    parser.add_argument("--no-partial", "-np", action="store_true", help="Filter out matches that do not fully overlap with the grid data")
    
    args = parser.parse_args()

    do_plot_target = bool(args.plot_target)
    do_plot_reference = bool(args.plot_reference)
    do_plot_match = args.plot_match
    is_matching_requested = do_plot_match

    if not (do_plot_target or do_plot_reference or do_plot_match):
        parser.error("At least one action flag is required: -pt (target), -pr (reference), or -pm (match).")
        
    media_file_path = None
    csv_file_path = None

    if isinstance(args.plot_target, str):
        media_file_path = args.plot_target
    if isinstance(args.plot_reference, str):
        csv_file_path = args.plot_reference

    positionals = [p for p in [args.media_file, args.csv_file] if p is not None]
    
    target_needs_input = do_plot_target or is_matching_requested
    
    if target_needs_input and media_file_path is None and len(positionals) > 0:
        media_file_path = positionals.pop(0)

    reference_needs_input = do_plot_reference or is_matching_requested
    
    if reference_needs_input and csv_file_path is None and len(positionals) > 0:
        csv_file_path = positionals.pop(0)

    
    if not media_file_path and not csv_file_path:
        parser.print_help()
        sys.exit(0)

    target_signal = None
    ref_signal = None

    if media_file_path:
        should_process_media = do_plot_target or is_matching_requested
        if should_process_media:
            print(f"Loading and analyzing media: {media_file_path}...")
            try:
                audio_data, audio_rate = analysis.read_audio(media_file_path)
                enf_result = analysis.compute_enf(audio_data, audio_rate, network_frequency=args.frequency)
                
                if enf_result is None:
                    print("Error: No ENF signal detected in the audio file.")
                    if is_matching_requested: sys.exit(1)
                else:
                    target_signal = enf_result.enf
                    print(f"  > Detected ENF signal (Quality: {target_signal.quality():.2%}, Duration: {target_signal.duration})")
                    
                    t_valid = target_signal.signal.compressed() + target_signal.network_frequency
                    if len(t_valid) > 0:
                        print(f"  > Target Stats: Min={np.min(t_valid):.3f}Hz Max={np.max(t_valid):.3f}Hz Med={np.median(t_valid):.3f}Hz Mean={np.mean(t_valid):.3f}Hz")

                    if do_plot_target:
                        ui.save_signal_plot(target_signal, "plot_target.png", "Target ENF Signal")
            except Exception as e:
                print(f"Error reading media: {e}")
                if is_matching_requested: sys.exit(1)
    elif do_plot_target:
        print("Error: --plot-target requires a media file argument or positional media argument.")
        sys.exit(1)

    if csv_file_path:
        should_process_csv = do_plot_reference or is_matching_requested
        if should_process_csv:
            csv_config = csv_utils.configure_csv_parsing(csv_file_path)
            
            print(f"\nLoading grid data from CSV: {csv_file_path}...")
            print("  (Press 'q' to abort processing at any time)")
            
            monitor_thread = threading.Thread(target=ui.monitor_quit_key, daemon=True)
            monitor_thread.start()

            sparse_grid_data = csv_utils.parse_csv_grid_data(csv_file_path, csv_config, args.frequency)
            
            if len(sparse_grid_data[0]) == 0:
                print("Error: No valid data found in CSV.")
                if is_matching_requested: sys.exit(1)
            else:
                target_freq = target_signal.signal_frequency if target_signal else 1.0

                ref_signal_values, ref_begins_at = csv_utils.resample_with_progress(
                    sparse_grid_data, 
                    target_freq 
                )
                
                ref_signal = Signal(
                    network_frequency=args.frequency,
                    signal_frequency=target_freq,
                    signal=ref_signal_values,
                    begins_at=ref_begins_at
                )
                
                display_tz = csv_config.get('timezone', timezone.utc)
                
                if ref_signal.begins_at:
                    ref_start_display = ref_signal.begins_at.astimezone(display_tz)
                    ref_end_display = ref_signal.ends_at.astimezone(display_tz)
                    print(f"  > Grid signal loaded (Start: {ref_start_display}, End: {ref_end_display}, Duration: {ref_signal.duration})")
                else:
                     print(f"  > Grid signal loaded (Duration: {ref_signal.duration})")

                r_valid = ref_signal.signal.compressed() + ref_signal.network_frequency
                if len(r_valid) > 0:
                    print(f"  > Reference Stats: Min={np.min(r_valid):.3f}Hz Max={np.max(r_valid):.3f}Hz Med={np.median(r_valid):.3f}Hz Mean={np.mean(r_valid):.3f}Hz")

                if do_plot_reference:
                    ui.save_signal_plot(ref_signal, "plot_reference.png", "Reference ENF Signal")
    elif do_plot_reference:
        print("Error: --plot-reference requires a CSV file argument or positional CSV argument.")
        sys.exit(1)

    if is_matching_requested:
        if not target_signal:
            print("Error: Cannot match without valid media ENF signal.")
            sys.exit(1)
        if not ref_signal:
            print("Error: Cannot match without valid grid reference signal.")
            sys.exit(1)
            
        print("\nMatching signals...")
        backend_enum = MatchBackend(args.backend)
        
        matches = match.match_signals(
            ref_signal, 
            target_signal, 
            max_matches=args.max_matches, 
            backend=backend_enum,
            exhaustive=args.exhaustive
        )

        if args.no_partial:
            original_count = len(matches)
            matches = [
                m for m in matches 
                if m.offset >= timedelta(0) and (m.offset + target_signal.duration) <= ref_signal.duration
            ]
            filtered_count = original_count - len(matches)
            if filtered_count > 0:
                print(f"  > Note: {filtered_count} matches were found but filtered out by --no-partial.")

        if not matches:
            print("No matches found.")
        else:
            if 'display_tz' not in locals():
                display_tz = timezone.utc
            
            tz_name = str(display_tz)
            print(f"\nFound {len(matches)} matches:")
            print(f"{f'START TIME ({tz_name})':<35} {f'END TIME ({tz_name})':<35} {'START (UNIX)':<15} {'END (UNIX)':<15} {'CORR':<10} {'RMSE':<10}")
            print("-" * 120)
            for m in matches:
                match_start_utc = ref_signal.begins_at + m.offset
                match_end_utc = match_start_utc + target_signal.duration
                match_start_display = match_start_utc.astimezone(display_tz)
                match_end_display = match_end_utc.astimezone(display_tz)
                start_unix = match_start_utc.timestamp()
                end_unix = match_end_utc.timestamp()
                
                print(f"{str(match_start_display):<35} {str(match_end_display):<35} {start_unix:<15.3f} {end_unix:<15.3f} {m.corr_coeff:<10.4f} {m.rmse:<10.4f}")

            if do_plot_match:
                print("\nPlotting matches...")
                for i, m in enumerate(matches):
                    match_time_utc = ref_signal.begins_at + m.offset
                    match_time_display = match_time_utc.astimezone(display_tz)
                    timestamp_str = match_time_display.strftime("%Y-%m-%d_%H-%M-%S")
                    filename = f"match_{i+1}_{timestamp_str}.png"
                    title = f"Match {i+1}: {match_time_display} (Corr: {m.corr_coeff:.4f})"
                    ui.save_match_plot(m, ref_signal, target_signal, filename, title)

if __name__ == "__main__":
    main()
