
import inspect

program1 = """

PROGRAM 1 — Image Split (Corrected & Clean)

clc; clear; close all;

img = imread('1.jpg');   % use relative path
figure, imshow(img), title('Original Image');

[rows, cols, ~] = size(img);
mid_row = floor(rows/2);
mid_col = floor(cols/2);

quad1 = img(1:mid_row, 1:mid_col, :);          % Top-Left
quad2 = img(1:mid_row, mid_col+1:end, :);      % Top-Right
quad3 = img(mid_row+1:end, 1:mid_col, :);      % Bottom-Left
quad4 = img(mid_row+1:end, mid_col+1:end, :);  % Bottom-Right

figure;
subplot(2,2,1), imshow(quad1), title('Top-Left');
subplot(2,2,2), imshow(quad2), title('Top-Right');
subplot(2,2,3), imshow(quad3), title('Bottom-Left');
subplot(2,2,4), imshow(quad4), title('Bottom-Right');


"""

program2 = """

PROGRAM 2 — Rotation, Scaling, Translation

clc; clear; close all;

I = imread('image1.png');

figure;
subplot(2,2,1), imshow(I), title('Original Image');

% Scaling
scaledImg = imresize(I, 0.5);
subplot(2,2,2), imshow(scaledImg), title('Scaled Image');

% Rotation
rotatedImg = imrotate(I, 30);
subplot(2,2,3), imshow(rotatedImg), title('Rotated Image (30°)');

% Translation
translatedImg = imtranslate(I, [15 25]);
subplot(2,2,4), imshow(translatedImg), title('Translated Image');



"""

program3 = """

PROGRAM 3 — Erosion vs Dilation Edge Difference

clc; clear; close all;

I = imread('cat.jpg');
if size(I,3)==3
    I = rgb2gray(I);
end

se = strel('disk',2);

eroded = imerode(I,se);
edgeE = imsubtract(I, eroded);

dilated = imdilate(I,se);
edgeD = imsubtract(dilated, I);

figure;
subplot(2,3,1), imshow(I), title('Original');
subplot(2,3,2), imshow(eroded), title('Eroded');
subplot(2,3,3), imshow(edgeE), title('Edge (Erosion)');
subplot(2,3,4), imshow(I), title('Original');
subplot(2,3,5), imshow(dilated), title('Dilated');
subplot(2,3,6), imshow(edgeD), title('Edge (Dilation)');



"""

program4 = """

PROGRAM 4 — Low-Level Features (Edges + Texture)

clc; clear; close all;

I = imread('2.png');
if size(I,3)==3
    I = rgb2gray(I);
end
I = im2double(I);

edgeS = edge(I,'sobel');
edgeP = edge(I,'prewitt');
edgeC = edge(I,'canny');

lap = imfilter(I, fspecial('laplacian',0.2), 'replicate');
gauss = imfilter(I, fspecial('gaussian',[5 5],1), 'replicate');
[Gx,Gy] = imgradientxy(I,'sobel');
gradMag = hypot(Gx,Gy);

figure;
subplot(3,3,1), imshow(I), title('Original');
subplot(3,3,2), imshow(edgeS), title('Sobel');
subplot(3,3,3), imshow(edgeP), title('Prewitt');
subplot(3,3,4), imshow(edgeC), title('Canny');
subplot(3,3,5), imshow(lap,[]), title('Laplacian');
subplot(3,3,6), imshow(gauss), title('Gaussian');
subplot(3,3,7), imshow(gradMag,[]), title('Gradient Magnitude');



"""

program5 = """

PROGRAM 5 — Enhancement + Segmentation

clc; clear; close all;

I = imread('2.png');
if size(I,3)==3
    I = rgb2gray(I);
end

figure, imshow(I), title('Low Contrast Image');

% Contrast Scaling
bright = uint8(min(I*1.5,255));
dark   = uint8(I*0.7);

figure;
subplot(1,3,1), imshow(I), title('Original');
subplot(1,3,2), imshow(bright), title('Brightened');
subplot(1,3,3), imshow(dark), title('Darkened');

% Histogram Equalization
figure, imshow(histeq(I)), title('Histogram Equalization');
figure, imshow(adapthisteq(I)), title('CLAHE');

% Spatial Transforms
neg = 255 - I;
logImg = uint8(255 * log(1+double(I)) / log(256));
gammaImg = im2double(I).^1.1;

figure;
subplot(1,3,1), imshow(neg), title('Negative');
subplot(1,3,2), imshow(logImg), title('Log');
subplot(1,3,3), imshow(gammaImg), title('Power Law');

% Filtering
I2 = im2double(I);
figure;
subplot(2,3,1), imshow(imfilter(I2, fspecial('average',[3 3]),'replicate')), title('Mean');
subplot(2,3,2), imshow(imfilter(I2, ones(5)/25,'replicate')), title('Box');
subplot(2,3,3), imshow(imfilter(I2, fspecial('gaussian',[5 5],1),'replicate')), title('Gaussian');
subplot(2,3,4), imshow(medfilt2(I2,[3 3])), title('Median');
subplot(2,3,5), imshow(ordfilt2(I2,1,ones(3))), title('Min');
subplot(2,3,6), imshow(ordfilt2(I2,9,ones(3))), title('Max');

% Segmentation
BW = imbinarize(adapthisteq(I), graythresh(I));
figure, imshow(BW), title('Otsu Segmentation');

edges = edge(I,'canny');
figure, imshow(edges), title('Edge Segmentation');



"""

program6 = """


"""

program_all = (
    program1
    + "\n\n"
    + program2
    + "\n\n"
    + program3
    + "\n\n"
    + program4
    + "\n\n"
    + program5
    + "\n\n"
    + program6
)


# ============================================================
# PRINT FUNCTIONS
# ============================================================

def print_program1():
    print(program1)

def print_program2():
    print(program2)

def print_program3():
    print(program3)

def print_program4():
    print(program4)

def print_program5():
    print(program5)

def print_program6():
    print(program6)

def print_programall():
    print(program_all)
