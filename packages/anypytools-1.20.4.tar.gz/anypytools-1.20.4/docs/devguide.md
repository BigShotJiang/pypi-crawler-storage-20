(devguide)=

```{include} ../CONTRIBUTING.md
```