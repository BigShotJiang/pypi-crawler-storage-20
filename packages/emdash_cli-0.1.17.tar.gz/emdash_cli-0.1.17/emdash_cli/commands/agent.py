"""Agent CLI commands."""

import click
from enum import Enum
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from ..client import EmdashClient
from ..server_manager import get_server_manager
from ..sse_renderer import SSERenderer

console = Console()


class AgentMode(Enum):
    """Agent operation modes."""
    PLAN = "plan"
    TASKS = "tasks"
    CODE = "code"


# Slash commands available in interactive mode
SLASH_COMMANDS = {
    # Mode switching
    "/plan": "Switch to plan mode (explore codebase, create specs)",
    "/tasks": "Switch to tasks mode (generate task lists)",
    "/code": "Switch to code mode (execute file changes)",
    "/mode": "Show current mode",
    # Generation commands
    "/pr [url]": "Review a pull request",
    "/projectmd": "Generate PROJECT.md for the codebase",
    "/research [goal]": "Deep research on a topic",
    # Status commands
    "/status": "Show index and PROJECT.md status",
    # Session management
    "/spec": "Show current specification",
    "/reset": "Reset session state",
    "/save": "Save current spec to disk",
    "/help": "Show available commands",
    "/quit": "Exit the agent",
}


@click.group()
def agent():
    """AI agent commands."""
    pass


@agent.command("code")
@click.argument("task", required=False)
@click.option("--model", "-m", default=None, help="Model to use")
@click.option("--mode", type=click.Choice(["plan", "tasks", "code"]), default="code",
              help="Starting mode")
@click.option("--quiet", "-q", is_flag=True, help="Less verbose output")
@click.option("--max-iterations", default=20, help="Max agent iterations")
@click.option("--no-graph-tools", is_flag=True, help="Skip graph exploration tools")
@click.option("--save", is_flag=True, help="Save specs to specs/<feature>/")
def agent_code(
    task: str | None,
    model: str | None,
    mode: str,
    quiet: bool,
    max_iterations: int,
    no_graph_tools: bool,
    save: bool,
):
    """Start the coding agent.

    With TASK: Run single task and exit
    Without TASK: Start interactive REPL mode

    MODES:
      plan   - Explore codebase and create specifications
      tasks  - Generate implementation task lists
      code   - Execute code changes (default)

    SLASH COMMANDS (in interactive mode):
      /plan   - Switch to plan mode
      /tasks  - Switch to tasks mode
      /code   - Switch to code mode
      /help   - Show available commands
      /reset  - Reset session

    Examples:
        emdash                                         # Interactive code mode
        emdash agent code                              # Same as above
        emdash agent code --mode plan                  # Start in plan mode
        emdash agent code "Fix the login bug"          # Single task
    """
    # Get server URL (starts server if needed)
    server = get_server_manager()
    base_url = server.get_server_url()

    client = EmdashClient(base_url)
    renderer = SSERenderer(console=console, verbose=not quiet)

    options = {
        "mode": mode,
        "no_graph_tools": no_graph_tools,
        "save": save,
    }

    if task:
        # Single task mode
        _run_single_task(client, renderer, task, model, max_iterations, options)
    else:
        # Interactive REPL mode
        _run_interactive(client, renderer, model, max_iterations, options)


def _get_clarification_response(clarification: dict) -> str | None:
    """Get user response for clarification with options.

    Args:
        clarification: Dict with question, context, and options

    Returns:
        User's selected option or typed response, or None if cancelled
    """
    from prompt_toolkit import PromptSession

    options = clarification.get("options", [])

    session = PromptSession()
    console.print("[dim]Enter number or type response:[/dim]")

    try:
        response = session.prompt("choice > ").strip()

        if not response:
            return None

        # Map number to option
        if response.isdigit():
            idx = int(response) - 1
            if 0 <= idx < len(options):
                return options[idx]

        return response
    except (KeyboardInterrupt, EOFError):
        return None


def _show_spec_approval_menu() -> tuple[str, str]:
    """Show spec approval menu with arrow-key selection.

    Returns:
        Tuple of (choice, feedback) where feedback is only set for 'refine'
    """
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    options = [
        ("tasks", "Generate implementation tasks"),
        ("code", "Start coding directly"),
        ("refine", "Provide feedback to improve"),
        ("abort", "Cancel and discard"),
    ]

    selected_index = [0]  # Use list to allow mutation in closure
    result = [None]

    # Key bindings
    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(options)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(options)

    @kb.add("enter")
    def select(event):
        result[0] = options[selected_index[0]][0]
        event.app.exit()

    @kb.add("1")
    def select_1(event):
        result[0] = "tasks"
        event.app.exit()

    @kb.add("2")
    def select_2(event):
        result[0] = "code"
        event.app.exit()

    @kb.add("3")
    def select_3(event):
        result[0] = "refine"
        event.app.exit()

    @kb.add("4")
    def select_4(event):
        result[0] = "abort"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    @kb.add("escape")
    def cancel(event):
        result[0] = "abort"
        event.app.exit()

    def get_formatted_options():
        lines = [("class:title", "What would you like to do with this spec?\n\n")]
        for i, (key, desc) in enumerate(options):
            if i == selected_index[0]:
                lines.append(("class:selected", f"  ❯ {key:8} "))
                lines.append(("class:selected-desc", f"- {desc}\n"))
            else:
                lines.append(("class:option", f"    {key:8} "))
                lines.append(("class:desc", f"- {desc}\n"))
        lines.append(("class:hint", "\n↑/↓ to move, Enter to select, q to cancel"))
        return lines

    # Style
    style = Style.from_dict({
        "title": "#00ccff bold",
        "selected": "#00cc66 bold",
        "selected-desc": "#00cc66",
        "option": "#888888",
        "desc": "#666666",
        "hint": "#444444 italic",
    })

    # Layout
    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_options),
                height=8,
            ),
        ])
    )

    # Application
    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        result[0] = "abort"

    choice = result[0] or "abort"

    # Get feedback if refine was chosen
    feedback = ""
    if choice == "refine":
        from prompt_toolkit import PromptSession
        console.print()
        console.print("[dim]What changes would you like?[/dim]")
        try:
            session = PromptSession()
            feedback = session.prompt("feedback > ").strip()
        except (KeyboardInterrupt, EOFError):
            return "abort", ""

    return choice, feedback


def _show_tasks_approval_menu() -> tuple[str, str]:
    """Show tasks approval menu with arrow-key selection.

    Returns:
        Tuple of (choice, feedback) where feedback is only set for 'refine'
    """
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    options = [
        ("code", "Start implementing these tasks"),
        ("refine", "Refine tasks with more details"),
        ("export", "Export tasks to file"),
        ("abort", "Cancel and discard"),
    ]

    selected_index = [0]  # Use list to allow mutation in closure
    result = [None]

    # Key bindings
    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(options)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(options)

    @kb.add("enter")
    def select(event):
        result[0] = options[selected_index[0]][0]
        event.app.exit()

    @kb.add("1")
    def select_1(event):
        result[0] = "code"
        event.app.exit()

    @kb.add("2")
    def select_2(event):
        result[0] = "refine"
        event.app.exit()

    @kb.add("3")
    def select_3(event):
        result[0] = "export"
        event.app.exit()

    @kb.add("4")
    def select_4(event):
        result[0] = "abort"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    @kb.add("escape")
    def cancel(event):
        result[0] = "abort"
        event.app.exit()

    def get_formatted_options():
        lines = [("class:title", "What would you like to do with these tasks?\n\n")]
        for i, (key, desc) in enumerate(options):
            if i == selected_index[0]:
                lines.append(("class:selected", f"  ❯ {key:8} "))
                lines.append(("class:selected-desc", f"- {desc}\n"))
            else:
                lines.append(("class:option", f"    {key:8} "))
                lines.append(("class:desc", f"- {desc}\n"))
        lines.append(("class:hint", "\n↑/↓ to move, Enter to select, q to cancel"))
        return lines

    # Style
    style = Style.from_dict({
        "title": "#cc66ff bold",  # Purple for tasks
        "selected": "#cc66ff bold",
        "selected-desc": "#cc66ff",
        "option": "#888888",
        "desc": "#666666",
        "hint": "#444444 italic",
    })

    # Layout
    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_options),
                height=8,
            ),
        ])
    )

    # Application
    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        result[0] = "abort"

    choice = result[0] or "abort"

    # Get feedback if refine was chosen
    feedback = ""
    if choice == "refine":
        from prompt_toolkit import PromptSession
        console.print()
        console.print("[dim]What changes would you like to the tasks?[/dim]")
        try:
            session = PromptSession()
            feedback = session.prompt("feedback > ").strip()
        except (KeyboardInterrupt, EOFError):
            return "abort", ""

    return choice, feedback


def _run_single_task(
    client: EmdashClient,
    renderer: SSERenderer,
    task: str,
    model: str | None,
    max_iterations: int,
    options: dict,
):
    """Run a single agent task."""
    try:
        stream = client.agent_chat_stream(
            message=task,
            model=model,
            max_iterations=max_iterations,
            options=options,
        )
        renderer.render_stream(stream)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise click.Abort()


def _run_slash_command_task(
    client: EmdashClient,
    renderer: SSERenderer,
    model: str | None,
    max_iterations: int,
    task: str,
    options: dict,
):
    """Run a task from a slash command."""
    try:
        stream = client.agent_chat_stream(
            message=task,
            model=model,
            max_iterations=max_iterations,
            options=options,
        )
        renderer.render_stream(stream)
        console.print()
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


def _run_interactive(
    client: EmdashClient,
    renderer: SSERenderer,
    model: str | None,
    max_iterations: int,
    options: dict,
):
    """Run interactive REPL mode with slash commands."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.styles import Style
    from prompt_toolkit.key_binding import KeyBindings
    from pathlib import Path

    # Current mode
    current_mode = AgentMode(options.get("mode", "code"))
    session_id = None
    current_spec = None

    # Style for prompt
    PROMPT_STYLE = Style.from_dict({
        "prompt.mode.plan": "#ffcc00 bold",
        "prompt.mode.tasks": "#cc66ff bold",
        "prompt.mode.code": "#00cc66 bold",
        "prompt.prefix": "#888888",
        "completion-menu": "bg:#1a1a2e #ffffff",
        "completion-menu.completion": "bg:#1a1a2e #ffffff",
        "completion-menu.completion.current": "bg:#4a4a6e #ffffff bold",
        "completion-menu.meta.completion": "bg:#1a1a2e #888888",
        "completion-menu.meta.completion.current": "bg:#4a4a6e #aaaaaa",
        "command": "#00ccff bold",
    })

    class SlashCommandCompleter(Completer):
        """Completer for slash commands."""

        def get_completions(self, document, complete_event):
            text = document.text_before_cursor
            if not text.startswith("/"):
                return
            for cmd, description in SLASH_COMMANDS.items():
                # Extract base command (e.g., "/pr" from "/pr [url]")
                base_cmd = cmd.split()[0]
                if base_cmd.startswith(text):
                    yield Completion(
                        base_cmd,
                        start_position=-len(text),
                        display=cmd,
                        display_meta=description,
                    )

    # Setup history file
    history_file = Path.home() / ".emdash" / "cli_history"
    history_file.parent.mkdir(parents=True, exist_ok=True)
    history = FileHistory(str(history_file))

    # Key bindings: Enter submits, Alt+Enter inserts newline
    # Note: Shift+Enter is indistinguishable from Enter in most terminals
    kb = KeyBindings()

    @kb.add("enter")
    def submit_on_enter(event):
        """Submit on Enter."""
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")  # Alt+Enter (Escape then Enter)
    @kb.add("c-j")  # Ctrl+J as alternative for newline
    def insert_newline_alt(event):
        """Insert a newline character with Alt+Enter or Ctrl+J."""
        event.current_buffer.insert_text("\n")

    session = PromptSession(
        history=history,
        completer=SlashCommandCompleter(),
        style=PROMPT_STYLE,
        complete_while_typing=True,
        multiline=True,
        prompt_continuation="... ",
        key_bindings=kb,
    )

    def get_prompt():
        """Get formatted prompt based on current mode."""
        mode_colors = {
            AgentMode.PLAN: "class:prompt.mode.plan",
            AgentMode.TASKS: "class:prompt.mode.tasks",
            AgentMode.CODE: "class:prompt.mode.code",
        }
        mode_name = current_mode.value
        color_class = mode_colors.get(current_mode, "class:prompt.mode.code")
        return [(color_class, f"[{mode_name}]"), ("", " "), ("class:prompt.prefix", "> ")]

    def show_help():
        """Show available commands."""
        console.print()
        console.print("[bold cyan]Available Commands[/bold cyan]")
        console.print()
        for cmd, desc in SLASH_COMMANDS.items():
            console.print(f"  [cyan]{cmd:12}[/cyan] {desc}")
        console.print()
        console.print("[dim]Type your task or question to interact with the agent.[/dim]")
        console.print()

    def handle_slash_command(cmd: str) -> bool:
        """Handle a slash command. Returns True if should continue, False to exit."""
        nonlocal current_mode, session_id, current_spec

        cmd_parts = cmd.strip().split(maxsplit=1)
        command = cmd_parts[0].lower()
        args = cmd_parts[1] if len(cmd_parts) > 1 else ""

        if command == "/quit" or command == "/exit" or command == "/q":
            return False

        elif command == "/help":
            show_help()

        elif command == "/plan":
            current_mode = AgentMode.PLAN
            console.print("[yellow]Switched to plan mode[/yellow]")

        elif command == "/tasks":
            current_mode = AgentMode.TASKS
            console.print("[magenta]Switched to tasks mode[/magenta]")

        elif command == "/code":
            current_mode = AgentMode.CODE
            console.print("[green]Switched to code mode[/green]")

        elif command == "/mode":
            console.print(f"Current mode: [bold]{current_mode.value}[/bold]")

        elif command == "/reset":
            session_id = None
            current_spec = None
            console.print("[dim]Session reset[/dim]")

        elif command == "/spec":
            if current_spec:
                console.print(Panel(Markdown(current_spec), title="Current Spec"))
            else:
                console.print("[dim]No spec available. Use plan mode to create one.[/dim]")

        elif command == "/save":
            if current_spec:
                # TODO: Save spec via API
                console.print("[yellow]Save not implemented yet[/yellow]")
            else:
                console.print("[dim]No spec to save[/dim]")

        elif command == "/pr":
            # PR review
            if not args:
                console.print("[yellow]Usage: /pr <pr-url-or-number>[/yellow]")
                console.print("[dim]Example: /pr 123 or /pr https://github.com/org/repo/pull/123[/dim]")
            else:
                console.print(f"[cyan]Reviewing PR: {args}[/cyan]")
                _run_slash_command_task(
                    client, renderer, model, max_iterations,
                    f"Review this pull request and provide feedback: {args}",
                    {"mode": "code"}
                )

        elif command == "/projectmd":
            # Generate PROJECT.md
            console.print("[cyan]Generating PROJECT.md...[/cyan]")
            _run_slash_command_task(
                client, renderer, model, max_iterations,
                "Analyze this codebase and generate a comprehensive PROJECT.md file that describes the architecture, main components, how to get started, and key design decisions.",
                {"mode": "code"}
            )

        elif command == "/research":
            # Deep research
            if not args:
                console.print("[yellow]Usage: /research <goal>[/yellow]")
                console.print("[dim]Example: /research How does authentication work in this codebase?[/dim]")
            else:
                console.print(f"[cyan]Researching: {args}[/cyan]")
                _run_slash_command_task(
                    client, renderer, model, 50,  # More iterations for research
                    f"Conduct deep research on: {args}\n\nExplore the codebase thoroughly, analyze relevant code, and provide a comprehensive answer with references to specific files and functions.",
                    {"mode": "plan"}  # Use plan mode for research
                )

        elif command == "/status":
            # Show index and PROJECT.md status
            from datetime import datetime

            console.print("\n[bold cyan]Status[/bold cyan]\n")

            # Index status
            console.print("[bold]Index Status[/bold]")
            try:
                status = client.index_status(str(Path.cwd()))
                is_indexed = status.get("is_indexed", False)
                console.print(f"  Indexed: {'[green]Yes[/green]' if is_indexed else '[yellow]No[/yellow]'}")

                if is_indexed:
                    console.print(f"  Files: {status.get('file_count', 0)}")
                    console.print(f"  Functions: {status.get('function_count', 0)}")
                    console.print(f"  Classes: {status.get('class_count', 0)}")
                    console.print(f"  Communities: {status.get('community_count', 0)}")
                    if status.get("last_indexed"):
                        console.print(f"  Last indexed: {status.get('last_indexed')}")
                    if status.get("last_commit"):
                        console.print(f"  Last commit: {status.get('last_commit')}")
            except Exception as e:
                console.print(f"  [red]Error fetching index status: {e}[/red]")

            console.print()

            # PROJECT.md status
            console.print("[bold]PROJECT.md Status[/bold]")
            projectmd_path = Path.cwd() / "PROJECT.md"
            if projectmd_path.exists():
                stat = projectmd_path.stat()
                modified_time = datetime.fromtimestamp(stat.st_mtime)
                size_kb = stat.st_size / 1024
                console.print(f"  Exists: [green]Yes[/green]")
                console.print(f"  Path: {projectmd_path}")
                console.print(f"  Size: {size_kb:.1f} KB")
                console.print(f"  Last modified: {modified_time.strftime('%Y-%m-%d %H:%M:%S')}")
            else:
                console.print(f"  Exists: [yellow]No[/yellow]")
                console.print("[dim]  Run /projectmd to generate it[/dim]")

            console.print()

        else:
            console.print(f"[yellow]Unknown command: {command}[/yellow]")
            console.print("[dim]Type /help for available commands[/dim]")

        return True

    # Show welcome message
    from .. import __version__
    import subprocess

    # Get current working directory
    cwd = Path.cwd()

    # Get git repo name (if in a git repo)
    git_repo = None
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, cwd=cwd
        )
        if result.returncode == 0:
            git_repo = Path(result.stdout.strip()).name
    except Exception:
        pass

    console.print()
    console.print(f"[bold cyan]EmDash Agent[/bold cyan] [dim]v{__version__}[/dim]")
    console.print(f"Mode: [bold]{current_mode.value}[/bold] | Model: [dim]{model or 'default'}[/dim]")
    if git_repo:
        console.print(f"Repo: [bold green]{git_repo}[/bold green] | Path: [dim]{cwd}[/dim]")
    else:
        console.print(f"Path: [dim]{cwd}[/dim]")
    console.print("Type your task or [cyan]/help[/cyan] for commands. Use Ctrl+C to exit.")
    console.print()

    while True:
        try:
            # Get user input
            user_input = session.prompt(get_prompt()).strip()

            if not user_input:
                continue

            # Handle slash commands
            if user_input.startswith("/"):
                if not handle_slash_command(user_input):
                    break
                continue

            # Handle quit shortcuts
            if user_input.lower() in ("quit", "exit", "q"):
                break

            # Build options with current mode
            request_options = {
                **options,
                "mode": current_mode.value,
            }

            # Run agent with current mode
            try:
                if session_id:
                    stream = client.agent_continue_stream(session_id, user_input)
                else:
                    stream = client.agent_chat_stream(
                        message=user_input,
                        model=model,
                        max_iterations=max_iterations,
                        options=request_options,
                    )

                # Render the stream and capture any spec output
                result = renderer.render_stream(stream)

                # Check if we got a session ID back
                if result and result.get("session_id"):
                    session_id = result["session_id"]

                # Check for spec output
                if result and result.get("spec"):
                    current_spec = result["spec"]

                # Handle clarification with options (interactive selection)
                clarification = result.get("clarification")
                if clarification and clarification.get("options") and session_id:
                    response = _get_clarification_response(clarification)
                    if response:
                        # Continue session with user's choice
                        stream = client.agent_continue_stream(session_id, response)
                        result = renderer.render_stream(stream)

                        # Update mode if user chose tasks or code
                        if "tasks" in response.lower():
                            current_mode = AgentMode.TASKS
                        elif "code" in response.lower():
                            current_mode = AgentMode.CODE

                # Handle plan mode completion (show approval menu)
                # In plan mode, show menu after any substantial response
                content = result.get("content", "")
                should_show_plan_menu = (
                    current_mode == AgentMode.PLAN and
                    session_id and
                    len(content) > 100  # Has substantial content
                )
                if should_show_plan_menu:
                    choice, feedback = _show_spec_approval_menu()

                    if choice == "tasks":
                        current_mode = AgentMode.TASKS
                        # Include the spec content explicitly in the message
                        tasks_prompt = f"""Generate implementation tasks from this approved specification.

## Approved Specification

{content}

## Your Task

Use your tools to explore the codebase and create implementation tasks:

1. **Explore**: Use semantic_search and code graph tools to find:
   - Existing related code to modify
   - Patterns and conventions used in the codebase
   - Files that will need changes

2. **Generate Tasks**: Create detailed tasks that include:
   - Task ID (T1, T2, T3...)
   - Description of what to implement
   - Specific files to modify (based on your exploration)
   - Dependencies on other tasks
   - Complexity estimate (S/M/L)
   - Acceptance criteria

3. **Order**: Arrange tasks in implementation order, starting with foundational changes.

Output a comprehensive task list that a developer can follow step-by-step."""
                        stream = client.agent_continue_stream(
                            session_id,
                            tasks_prompt
                        )
                        result = renderer.render_stream(stream)
                        # After generating tasks, show tasks menu
                        content = result.get("content", "")
                    elif choice == "code":
                        current_mode = AgentMode.CODE
                        stream = client.agent_continue_stream(
                            session_id,
                            "Start implementing the approved spec."
                        )
                        renderer.render_stream(stream)
                    elif choice == "refine":
                        stream = client.agent_continue_stream(
                            session_id,
                            f"Please update the spec based on this feedback: {feedback}"
                        )
                        renderer.render_stream(stream)
                    elif choice == "abort":
                        console.print("[dim]Spec discarded[/dim]")
                        session_id = None
                        current_spec = None

                # Handle tasks mode completion (show tasks approval menu)
                should_show_tasks_menu = (
                    current_mode == AgentMode.TASKS and
                    session_id and
                    len(content) > 100  # Has substantial content
                )
                if should_show_tasks_menu:
                    choice, feedback = _show_tasks_approval_menu()

                    if choice == "code":
                        current_mode = AgentMode.CODE
                        stream = client.agent_continue_stream(
                            session_id,
                            "Start implementing the first task from the task list."
                        )
                        renderer.render_stream(stream)
                    elif choice == "refine":
                        stream = client.agent_continue_stream(
                            session_id,
                            f"Please update the tasks based on this feedback: {feedback}"
                        )
                        renderer.render_stream(stream)
                    elif choice == "export":
                        console.print("[dim]Exporting tasks...[/dim]")
                        # TODO: Implement export functionality
                        console.print("[yellow]Export not implemented yet[/yellow]")
                    elif choice == "abort":
                        console.print("[dim]Tasks discarded[/dim]")
                        session_id = None

                console.print()

            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")

        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted[/dim]")
            break
        except EOFError:
            break


@agent.command("sessions")
def list_sessions():
    """List active agent sessions."""
    server = get_server_manager()
    base_url = server.get_server_url()

    client = EmdashClient(base_url)
    sessions = client.list_sessions()

    if not sessions:
        console.print("[dim]No active sessions[/dim]")
        return

    for s in sessions:
        console.print(
            f"  {s['session_id'][:8]}... "
            f"[dim]({s.get('model', 'unknown')}, "
            f"{s.get('message_count', 0)} messages)[/dim]"
        )
