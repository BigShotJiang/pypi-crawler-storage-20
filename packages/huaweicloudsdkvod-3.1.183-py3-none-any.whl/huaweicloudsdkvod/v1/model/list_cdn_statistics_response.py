# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListCdnStatisticsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'start_time': 'str',
        'interval': 'int',
        'result': 'dict(str, list[int])'
    }

    attribute_map = {
        'start_time': 'start_time',
        'interval': 'interval',
        'result': 'result'
    }

    def __init__(self, start_time=None, interval=None, result=None):
        r"""ListCdnStatisticsResponse

        The model defined in huaweicloud sdk

        :param start_time: 统计起始时间 
        :type start_time: str
        :param interval: 采样时间间隔 
        :type interval: int
        :param result: cdn数据查询结果 
        :type result: dict(str, list[int])
        """
        
        super().__init__()

        self._start_time = None
        self._interval = None
        self._result = None
        self.discriminator = None

        if start_time is not None:
            self.start_time = start_time
        if interval is not None:
            self.interval = interval
        if result is not None:
            self.result = result

    @property
    def start_time(self):
        r"""Gets the start_time of this ListCdnStatisticsResponse.

        统计起始时间 

        :return: The start_time of this ListCdnStatisticsResponse.
        :rtype: str
        """
        return self._start_time

    @start_time.setter
    def start_time(self, start_time):
        r"""Sets the start_time of this ListCdnStatisticsResponse.

        统计起始时间 

        :param start_time: The start_time of this ListCdnStatisticsResponse.
        :type start_time: str
        """
        self._start_time = start_time

    @property
    def interval(self):
        r"""Gets the interval of this ListCdnStatisticsResponse.

        采样时间间隔 

        :return: The interval of this ListCdnStatisticsResponse.
        :rtype: int
        """
        return self._interval

    @interval.setter
    def interval(self, interval):
        r"""Sets the interval of this ListCdnStatisticsResponse.

        采样时间间隔 

        :param interval: The interval of this ListCdnStatisticsResponse.
        :type interval: int
        """
        self._interval = interval

    @property
    def result(self):
        r"""Gets the result of this ListCdnStatisticsResponse.

        cdn数据查询结果 

        :return: The result of this ListCdnStatisticsResponse.
        :rtype: dict(str, list[int])
        """
        return self._result

    @result.setter
    def result(self, result):
        r"""Sets the result of this ListCdnStatisticsResponse.

        cdn数据查询结果 

        :param result: The result of this ListCdnStatisticsResponse.
        :type result: dict(str, list[int])
        """
        self._result = result

    def to_dict(self):
        import warnings
        warnings.warn("ListCdnStatisticsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListCdnStatisticsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
