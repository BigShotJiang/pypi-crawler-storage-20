__version__ = "0.4.2"

from .core.engine import MimaEngine as MimaEngine
from .core.mode_engine import MimaModeEngine as MimaModeEngine
