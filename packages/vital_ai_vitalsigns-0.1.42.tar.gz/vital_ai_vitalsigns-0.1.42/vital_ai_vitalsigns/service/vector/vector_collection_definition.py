

class VitalVectorCollectionDefinition:
    pass

