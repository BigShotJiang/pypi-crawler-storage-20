#
import pytest
from load_one_data import dump_diff, one_dump_test

# from ArWikiCats import resolve_arabic_category_label
from ArWikiCats.new_resolvers.bys_new import resolve_by_labels

data0 = {
    "by year": "حسب السنة",
    "decade": "العقد",
    "election": "الانتخابات",
    "by non-profit organizations by country": "حسب المنظمات غير الربحية حسب البلد",
    "non-profit organizations by continent": "المنظمات غير الربحية حسب القارة",
    "non-profit organizations by country": "المنظمات غير الربحية حسب البلد",
    "non-profit organizations by type": "المنظمات غير الربحية حسب الفئة",
    "non-profit organizations": "المنظمات غير الربحية",
    "non-profit publishers": "ناشرون غير ربحيون",
    "organized crime": "بواسطة الجريمة المنظمة",
    "populated place": "المكان المأهول",
    "sport": "الرياضة",
}

data1 = {
    "by academic discipline": "حسب التخصص الأكاديمي",
    "by architectural style": "حسب الطراز المعماري",
    "by artist nationality": "حسب جنسية الفنان",
    "by athletic event": "حسب حدث ألعاب القوى",
    "by audience": "حسب الجمهور",
    "by autonomous community": "حسب الحكم الذاتي",
    "by branch": "حسب الفرع",
    "by century and nationality": "حسب القرن والجنسية",
    "by century and occupation": "حسب القرن والمهنة",
    "by century of disestablishment": "حسب قرن الانحلال",
    "by century of establishment": "حسب قرن التأسيس",
    "by century of formal description": "حسب قرن الوصف",
    "by century": "حسب القرن",
    "by city of location": "حسب مدينة الموقع",
    "by city of setting": "حسب مدينة الأحداث",
    "by city": "حسب المدينة",
    "by club or team": "حسب النادي أو الفريق",
    "by club": "حسب النادي",
    "by competition": "حسب المنافسة",
    "by conflict": "حسب النزاع",
    "by continent of setting": "حسب قارة الأحداث",
    "by continent": "حسب القارة",
    "by country": "حسب البلد",
    "by country-of-residence": "حسب بلد الإقامة",
    "by county": "حسب المقاطعة",
    "by culture": "حسب الثقافة",
    "by date": "حسب التاريخ",
    "by decade of establishment": "حسب عقد التأسيس",
    "by decade": "حسب العقد",
    "by dependent territory": "حسب الأقاليم التابعة",
    "by diocese": "حسب الأبرشية",
    "by director": "حسب المخرج",
    "by educational affiliation": "حسب الانتماء التعليمي",
    "by educational institution": "حسب الهيئة التعليمية",
    "by ethnic or national origin": "حسب الأصل العرقي أو الوطني",
    "by ethnicity": "حسب المجموعة العرقية",
    "by firing squad": "رميا بالرصاص",
    "by format": "حسب التنسيق",
    "by former country": "حسب البلد السابق",
    "by genre": "حسب النوع الفني",
    "by geographic setting": "حسب الموقع الجغرافي للأحداث",
    "by hamlet": "حسب القرية",
    "by hanging": "بالشنق",
    "by high school": "حسب المدرسة الثانوية",
    "by industry": "حسب الصناعة",
    "by instrument": "حسب الآلة",
    "by interest": "حسب الاهتمام",
    "by issue": "حسب القضية",
    "by language": "حسب اللغة",
    "by law enforcement officers": "بواسطة ضباط إنفاذ القانون",
    "by league": "حسب الدوري",
    "by line": "حسب الخط",
    "by location and occupation": "حسب الموقع والمهنة",
    "by location": "حسب الموقع",
    "by material": "حسب المادة",
    "by medium": "حسب الوسط",
    "by millennium": "حسب الألفية",
    "by mission country": "حسب بلد البعثة",
    "by month": "حسب الشهر",
    "by movement": "حسب الحركة",
    "by municipality": "حسب البلدية",
    "by nation and year": "حسب الموطن والسنة",
    "by national amateur team": "حسب المنتخب الوطني للهواة",
    "by national team": "حسب المنتخب الوطني",
    "by national women's team": "حسب منتخب السيدات الوطني",
    "by national youth team": "حسب المنتخب الوطني للشباب",
    "by nationality and century": "حسب الجنسية والقرن",
    "by nationality and competition": "حسب الجنسية والمنافسة",
    "by nationality and occupation": "حسب الجنسية والمهنة",
    "by nationality and status": "حسب الجنسية والحالة",
    "by nationality": "حسب الجنسية",
    "by newspaper": "حسب الصحيفة",
    "by occupation and century": "حسب المهنة والقرن",
    "by occupation and region": "حسب المهنة والمنطقة",
    "by occupation": "حسب المهنة",
    "by organization": "حسب المنظمة",
    "by parish": "حسب الأبرشية",
    "by party": "حسب الحزب",
    "by period by state": "حسب الحقبة حسب الولاية",
    "by period of introduction": "حسب حقبة الاستحداث",
    "by period": "حسب الحقبة",
    "by person": "حسب الشخص",
    "by populated place and occupation": "حسب المكان المأهول والمهنة",
    "by populated place": "حسب المكان المأهول",
    "by position": "حسب المركز",
    "by producer": "حسب المنتج",
    "by production location": "حسب موقع الإنتاج",
    "by province or territory": "حسب المقاطعة أو الإقليم",
    "by province": "حسب المقاطعة",
    "by publication": "حسب المؤسسة",
    "by region": "حسب المنطقة",
    "by religion": "حسب الدين",
    "by school": "حسب المدرسة",
    "by series": "حسب السلسلة",
    "by setting location": "حسب موقع الأحداث",
    "by shooting location": "حسب موقع التصوير",
    "by source": "حسب المصدر",
    "by specialty and nationality": "حسب التخصص والجنسية",
    "by sport and year": "حسب الرياضة والسنة",
    "by sport by state": "حسب الرياضة حسب الولاية",
    "by sport": "حسب الرياضة",
    "by stabbing": "بالطعن",
    "by state or region": "حسب الولاية أو المنطقة",
    "by state or territory": "حسب الولاية أو الإقليم",
    "by state or union territory": "حسب الولاية أو الإقليم الاتحادي",
    "by state": "حسب الولاية",
    "by status": "حسب الحالة",
    "by studio": "حسب استوديو الإنتاج",
    "by subfield": "حسب الحقل الفرعي",
    "by subgenre": "حسب النوع الفرعي",
    "by subject": "حسب الموضوع",
    "by team": "حسب الفريق",
    "by technology": "حسب التقانة",
    "by term": "حسب الفترة",
    "by time": "حسب الوقت",
    "by topic": "حسب الموضوع",
    "by town": "حسب البلدة",
    "by type": "حسب الفئة",
    "by under-20 national team": "حسب المنتخب الوطني تحت 20 سنة",
    "by under-21 national team": "حسب المنتخب الوطني تحت 21 سنة",
    "by under-23 national team": "حسب المنتخب الوطني تحت 23 سنة",
    "by university or college": "حسب الجامعة أو الكلية",
    "by village": "حسب القرية",
    "by violence": "بسبب العنف",
    "by war": "حسب الحرب",
    "by women's under-20 national team": "حسب المنتخب الوطني للسيدات تحت 20 سنة",
    "by women's under-21 national team": "حسب المنتخب الوطني للسيدات تحت 21 سنة",
    "by women's under-23 national team": "حسب المنتخب الوطني للسيدات تحت 23 سنة",
    "by writer": "حسب الكاتب",
    "by year and continent": "حسب السنة والقارة",
    "by year of disestablishment": "حسب سنة الانحلال",
    "by year of establishment": "حسب سنة التأسيس",
    "by year of formal description": "حسب سنة الوصف",
    "by year of introduction": "حسب سنة الاستحداث",
}

data2 = {
    "by century of closing": "حسب قرن الاغلاق",
    "by country of origin": "حسب البلد الأصل",
    "by organization": "حسب المنظمة",
    "by nonprofit organization": "حسب المنظمات غير الربحية",
    "by organization or nonprofit organization": "حسب المنظمة أو المنظمات غير الربحية",
    "by organization by nonprofit organization": "حسب المنظمة حسب المنظمات غير الربحية",
    "by organization and nonprofit organization": "حسب المنظمة والمنظمات غير الربحية",
}

to_test = [
    ("test_by_table_get", data1, resolve_by_labels),
    ("test_resolve_by_labels_1", data1, resolve_by_labels),
]


@pytest.mark.parametrize("category, expected", data1.items(), ids=data1.keys())
@pytest.mark.fast
def test_by_table_get(category: str, expected: str) -> None:
    label = resolve_by_labels(category)
    assert label == expected


@pytest.mark.parametrize("category, expected", data2.items(), ids=data2.keys())
@pytest.mark.fast
def test_by_table_get_2(category: str, expected: str) -> None:
    label2 = resolve_by_labels(category)
    assert label2 == expected


@pytest.mark.parametrize("name,data,callback", to_test)
@pytest.mark.dump
def test_dump_it(name: str, data: dict[str, str], callback) -> None:
    expected, diff_result = one_dump_test(data, callback)
    dump_diff(diff_result, name)
    assert diff_result == expected, f"Differences found: {len(diff_result):,}, len all :{len(data):,}"
