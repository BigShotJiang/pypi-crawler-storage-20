import json
import logging
from typing import Any, Iterable, Optional, List, Union, Dict, Tuple
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd
    import vertica_python
    from mattermostdriver import Driver

from mnemosynecore.vault import get_secret
from airflow.operators.python import get_current_context
from airflow import DAG
from airflow.utils.task_group import TaskGroup
from airflow.operators.dummy import DummyOperator
from os import listdir, path


def load_sql_tasks_from_dir(dir_sql: str, vertica_conn_id: str) -> Dict[str, Any]:
    """
    Создаёт словарь VerticaOperator из всех SQL файлов в папке,
    автоматически используя текущий DAG из контекста.

    Args:
        dir_sql (str): Путь к директории с SQL файлами
        vertica_conn_id (str): ID подключения к Vertica

    Returns:
        Dict[str, Any]: Словарь задач VerticaOperator

    Raises:
        FileNotFoundError: Если директория не существует
        ValueError: Если нет SQL файлов в директории
        Exception: При ошибках создания задач

    Example:
        >>> tasks = load_sql_tasks_from_dir("/path/to/sql", "VERTICA_CONN_ID")
        >>> # Использование в DAG
        >>> with TaskGroup("vertica_tasks") as vertica_group:
        ...     for task in tasks.values():
        ...         task
    """
    try:
        from o3_vertica.airflow.operator import VerticaOperator

        context = get_current_context()
        dag = context['dag']  # берём текущий DAG

        tasks = {}
        files_list = listdir(dir_sql)

        if not files_list:
            logging.warning(f"Директория {dir_sql} пуста")
            return tasks

        for filename in files_list:
            if not filename.endswith(".sql"):
                continue
            path_file = path.join(dir_sql, filename)
            sql = read_sql_file(path_file)
            if sql:
                sql_statements = sql.split(';')
                task_name = 'task_' + filename.replace('.sql', '_vertica')
                tasks[task_name] = VerticaOperator(
                    sql=sql_statements,
                    task_id=task_name,
                    vertica_conn_id=vertica_conn_id,
                    dag=dag,
                )
        return tasks

    except Exception as e:
        logging.error(f"Ошибка при создании SQL задач из директории {dir_sql}: {e}")
        raise


def read_sql_file(file_path: str) -> Optional[str]:
    """
    Читает SQL файл и возвращает его содержимое.

    Args:
        file_path (str): Путь к SQL файлу

    Returns:
        Optional[str]: Содержимое файла или None при ошибке

    Raises:
        FileNotFoundError: Если файл не найден
        PermissionError: Если нет прав на чтение файла

    Example:
        >>> sql_content = read_sql_file("/path/to/query.sql")
        >>> if sql_content:
        ...     print("SQL загружен успешно")
    """
    try:
        if not path.exists(file_path):
            logging.error(f'Ошибка: файл {file_path} не найден')
            return None

        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()

    except Exception as e:
        logging.error(f"Ошибка чтения SQL файла {file_path}: {e}")
        return None


def vertica_dedupe(
        table_name: str,
        unique_keys: Union[str, List[str]],
        conn: Optional['vertica_python.Connection'] = None,
        conn_id: Optional[str] = None,
        date_col: Optional[str] = None,
        keep: str = "last",
        commit: bool = True
) -> None:
    """
    Удаляет дубликаты из таблицы Vertica, оставляя только уникальные строки.

    Args:
        table_name (str): Полное имя таблицы (schema.table)
        unique_keys (Union[str, List[str]]): Столбец или список столбцов для уникальности
        conn (Optional[vertica_python.Connection]): Готовое соединение с Vertica
        conn_id (Optional[str]): ID подключения/секрета (если conn не передан)
        date_col (Optional[str]): Столбец с датой для определения последней строки при дубликатах
        keep (str): 'last' или 'first' — какая запись остаётся среди дубликатов
        commit (bool): Выполнить commit после удаления

    Returns:
        None

    Raises:
        ValueError: Если не указано conn или conn_id
        Exception: При ошибках выполнения SQL

    Example:
        >>> vertica_dedupe(
        ...     table_name="schema.table",
        ...     unique_keys=["id", "date"],
        ...     conn_id="VERTICA_CONN_ID",
        ...     date_col="created_at",
        ...     keep="last"
        ... )
    """
    try:
        if isinstance(unique_keys, str):
            unique_keys = [unique_keys]

        if not unique_keys:
            raise ValueError("Не указаны ключи уникальности")

        close_conn = False
        if conn is None:
            if not conn_id:
                raise ValueError("Нужно указать conn или conn_id")
            conn = vertica_conn(conn_id)
            close_conn = True

        # Выбираем строки, которые нужно оставить
        order_clause = f"ORDER BY {date_col} DESC" if date_col and keep == "last" else ""
        unique_cols = ", ".join(unique_keys)

        dedupe_sql = f"""
            DELETE FROM {table_name} t
            USING (
                SELECT {unique_cols}, ROW_NUMBER() OVER (PARTITION BY {unique_cols} {order_clause}) AS rn
                FROM {table_name}
            ) x
            WHERE t.{unique_keys[0]} = x.{unique_keys[0]}
              AND x.rn > 1
        """

        vertica_sql(conn=conn, sql=dedupe_sql, commit=commit)

        if close_conn:
            conn.close()

        logging.info(f"Удаление дубликатов из {table_name} завершено по ключам: {unique_keys}")

    except Exception as e:
        logging.error(f"Ошибка при удалении дубликатов из {table_name}: {e}")
        if 'conn' in locals() and close_conn:
            try:
                conn.rollback()
            except:
                pass
        raise


def vertica_upsert(
        df: 'pd.DataFrame',
        table_name: str,
        unique_keys: Union[str, List[str]],
        conn: Optional['vertica_python.Connection'] = None,
        date_col: Optional[str] = None,
        days_back: Optional[int] = None,
        commit: bool = True
) -> None:
    """
    Эффективно обновляет данные в Vertica:
    - вставляет новые строки,
    - обновляет существующие,
    - удаляет дубликаты.

    Args:
        df ('pd.DataFrame'): DataFrame с новыми данными
        table_name (str): имя таблицы с полным путем (schema.table)
        unique_keys (Union[str, List[str]]): столбец или список столбцов для уникальности
        conn (Optional[vertica_python.Connection]): подключение к Vertica (если None, создается новое)
        date_col (Optional[str]): если указано, фильтруем по последним `days_back` дням
        days_back (Optional[int]): число дней для подгрузки (используется с date_col)
        commit (bool): выполнять commit после вставки/мержа

    Returns:
        None

    Raises:
        ValueError: Если DataFrame пустой или неправильно указаны параметры
        Exception: При ошибках выполнения SQL

    Example:
        >>> vertica_upsert(
        ...     df=df_new,
        ...     table_name="schema.table",
        ...     unique_keys=["id", "add_column"],
        ...     conn=conn,
        ...     date_col="date_column",
        ...     days_back=3
        ... )
    """
    try:
        if df.empty:
            logging.warning("Нет данных для обновления.")
            return

        if isinstance(unique_keys, str):
            unique_keys = [unique_keys]

        if not unique_keys:
            raise ValueError("Не указаны ключи уникальности")

        # Создаем соединение, если не передано
        close_conn = False
        if conn is None:
            conn = vertica_conn()
            close_conn = True

        # Создаем временную таблицу
        temp_table = f"{table_name}_tmp"
        create_temp_sql = f"""
            DROP TABLE IF EXISTS {temp_table};
            CREATE LOCAL TEMP TABLE {temp_table} AS
            SELECT * FROM {table_name} WHERE 1=0;
        """
        vertica_sql(conn, create_temp_sql, commit=False)

        # Вставляем данные во временную таблицу
        rows = [tuple(x) for x in df.to_numpy()]
        cols = ", ".join(df.columns)
        placeholders = ", ".join(["%s"] * len(df.columns))

        insert_sql = f"INSERT INTO {temp_table} ({cols}) VALUES ({placeholders})"
        vertica_sql(conn, insert_sql, params=rows, many=True, commit=False)

        # Удаляем старые данные по date_col, если указано
        if date_col and days_back:
            delete_sql = f"""
                DELETE FROM {table_name}
                WHERE {date_col} >= CURRENT_DATE - INTERVAL '{days_back} day';
            """
            vertica_sql(conn, delete_sql, commit=False)

        # MERGE с основной таблицей по уникальным ключам
        merge_conditions = " AND ".join([f"t.{k} = s.{k}" for k in unique_keys])
        update_assignments = ", ".join([f"{c} = s.{c}" for c in df.columns if c not in unique_keys])

        merge_sql = f"""
            MERGE INTO {table_name} t
            USING {temp_table} s
            ON {merge_conditions}
            WHEN MATCHED THEN UPDATE SET {update_assignments}
            WHEN NOT MATCHED THEN INSERT ({cols}) VALUES ({cols});
        """
        vertica_sql(conn, merge_sql, commit=False)

        # Финальный commit
        if commit:
            conn.commit()

        if close_conn:
            conn.close()

        logging.info(f"Обновление таблицы {table_name} завершено. {len(df)} строк обработано.")

    except Exception as e:
        logging.error(f"Ошибка при обновлении таблицы {table_name}: {e}")
        if 'conn' in locals() and close_conn:
            try:
                conn.rollback()
            except:
                pass
        raise


def vertica_conn(conn_id: str) -> 'vertica_python.Connection':
    """
    Создаёт подключение к Vertica через Vault / Airflow Connection.

    Args:
        conn_id (str): ID секрета (Vault / Airflow)

    Returns:
        vertica_python.Connection: Подключение к Vertica

    Raises:
        ValueError: Если секрет не найден или некорректен
        Exception: При ошибках подключения к Vertica

    Example:
        >>> conn = vertica_conn("VERTICA_CONN_ID")
        >>> result = vertica_sql(conn=conn, sql="SELECT * FROM table")
        >>> conn.close()
    """
    try:
        cfg = get_secret(conn_id)

        return vertica_python.connect(
            host=cfg["host"],
            port=int(cfg["port"]),
            user=cfg["login"],
            password=cfg["password"],
            database=cfg.get("schema") or cfg.get("database"),
            autocommit=False,
        )
    except Exception as e:
        logging.error(f"Ошибка подключения к Vertica с ID {conn_id}: {e}")
        raise


def vertica_sql(
        *,
        conn_id: Optional[str] = None,
        conn: Optional['vertica_python.Connection'] = None,
        sql: str,
        params: Optional[Iterable[Any]] = None,
        many: bool = False,
        commit: bool = True
) -> None:
    """
    Выполняет SQL-запрос в Vertica.

    Можно передать либо conn_id, либо готовое соединение.

    Args:
        conn_id (Optional[str]): ID подключения к Vertica
        conn (Optional[vertica_python.Connection]): Готовое соединение
        sql (str): SQL запрос
        params (Optional[Iterable[Any]]): Параметры для запроса
        many (bool): Выполнять executemany вместо execute
        commit (bool): Выполнять commit после запроса

    Returns:
        None

    Raises:
        ValueError: Если не указано conn или conn_id
        Exception: При ошибках выполнения SQL

    Example:
        >>> vertica_sql(
        ...     conn_id="VERTICA_CONN_ID",
        ...     sql="SELECT * FROM table WHERE id = %s",
        ...     params=[123]
        ... )
    """
    try:
        if not conn and not conn_id:
            raise ValueError("Нужно указать conn или conn_id")

        close_conn = False
        if not conn:
            conn = vertica_conn(conn_id)
            close_conn = True

        try:
            with conn.cursor() as cur:
                if many:
                    cur.executemany(sql, params)
                else:
                    cur.execute(sql, params)

            if commit:
                conn.commit()

        except Exception as e:
            conn.rollback()
            logging.exception("Ошибка выполнения SQL в Vertica")
            raise

        finally:
            if close_conn:
                conn.close()

    except Exception as e:
        logging.error(f"Ошибка выполнения SQL: {e}")
        raise


def vertica_select(
        *,
        conn_id: Optional[str] = None,
        conn: Optional['vertica_python.Connection'] = None,
        sql: str,
        params: Optional[Iterable[Any]] = None
) -> 'pd.DataFrame':
    """
    Выполняет SELECT-запрос и возвращает pandas DataFrame.

    Args:
        conn_id (Optional[str]): ID подключения к Vertica
        conn (Optional[vertica_python.Connection]): Готовое соединение
        sql (str): SQL запрос
        params (Optional[Iterable[Any]]): Параметры для запроса

    Returns:
        pd.DataFrame: Результат запроса в виде DataFrame

    Raises:
        ValueError: Если не указано conn или conn_id
        Exception: При ошибках выполнения SQL

    Example:
        >>> df = vertica_select(
        ...     conn_id="VERTICA_CONN_ID",
        ...     sql="SELECT * FROM table WHERE id = %s",
        ...     params=[123]
        ... )
        >>> print(df.head())
    """
    try:
        if not conn and not conn_id:
            raise ValueError("Нужно указать conn или conn_id")

        close_conn = False
        if not conn:
            conn = vertica_conn(conn_id)
            close_conn = True

        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                columns = [desc[0] for desc in cur.description]
                rows = cur.fetchall()

            return pd.DataFrame(rows, columns=columns)

        finally:
            if close_conn:
                conn.close()

    except Exception as e:
        logging.error(f"Ошибка выполнения SELECT запроса: {e}")
        raise