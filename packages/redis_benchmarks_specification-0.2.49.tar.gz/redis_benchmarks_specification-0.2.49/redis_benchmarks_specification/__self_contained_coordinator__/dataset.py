import logging
import os
import tempfile
import time
from urllib.request import urlopen
from urllib.error import URLError, HTTPError
import redis


def download_dataset(dataset_url, temporary_dir, dataset_load_timeout_secs=1000):
    """
    Download an RDB dataset from a URL to a temporary directory.
    
    Args:
        dataset_url (str): URL to download the RDB file from
        temporary_dir (str): Directory to save the downloaded file
        dataset_load_timeout_secs (int): Timeout for the download operation
        
    Returns:
        tuple: (success: bool, local_file_path: str, error_message: str)
    """
    if not dataset_url:
        return False, None, "No dataset URL provided"
        
    try:
        logging.info(f"Starting dataset download from {dataset_url}")
        start_time = time.time()
        
        # Extract filename from URL or use default
        filename = os.path.basename(dataset_url)
        if not filename or '.' not in filename:
            filename = "dataset.rdb"
        
        local_file_path = os.path.join(temporary_dir, filename)
        
        # Download the file with timeout
        response = urlopen(dataset_url, timeout=dataset_load_timeout_secs)
        
        with open(local_file_path, 'wb') as f:
            chunk_size = 8192
            total_size = 0
            while True:
                chunk = response.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                total_size += len(chunk)
                
                # Check timeout
                if time.time() - start_time > dataset_load_timeout_secs:
                    raise TimeoutError(f"Download timeout after {dataset_load_timeout_secs} seconds")
        
        download_time = time.time() - start_time
        file_size_mb = total_size / (1024 * 1024)
        
        logging.info(
            f"Successfully downloaded dataset: {file_size_mb:.2f} MB in {download_time:.2f} seconds "
            f"({file_size_mb/download_time:.2f} MB/s) to {local_file_path}"
        )
        
        return True, local_file_path, None
        
    except (URLError, HTTPError) as e:
        error_msg = f"Failed to download dataset from {dataset_url}: {str(e)}"
        logging.error(error_msg)
        return False, None, error_msg
        
    except TimeoutError as e:
        error_msg = f"Dataset download timeout: {str(e)}"
        logging.error(error_msg)
        return False, None, error_msg
        
    except Exception as e:
        error_msg = f"Unexpected error downloading dataset: {str(e)}"
        logging.error(error_msg)
        return False, None, error_msg


def load_rdb_into_redis_container(rdb_file_path, redis_container, dataset_load_timeout_secs=1000):
    """
    Load an RDB file into a Redis container by copying it and restarting the container.

    Args:
        rdb_file_path (str): Path to the RDB file to load
        redis_container: Docker container object for Redis
        dataset_load_timeout_secs (int): Timeout for the load operation

    Returns:
        tuple: (success: bool, error_message: str)
    """
    if not os.path.exists(rdb_file_path):
        return False, f"RDB file not found: {rdb_file_path}"

    try:
        logging.info(f"Loading RDB file {rdb_file_path} into Redis container {redis_container.id[:12]}")
        start_time = time.time()

        # Copy RDB file into the container
        container_rdb_path = "/mnt/redis/dump.rdb"

        # Read the RDB file and copy it to the container
        with open(rdb_file_path, 'rb') as f:
            rdb_data = f.read()

        # Put the file into the container
        import tarfile
        import io

        # Create a tar archive in memory with the RDB file
        tar_stream = io.BytesIO()
        tar = tarfile.TarFile(fileobj=tar_stream, mode='w')

        # Add the RDB file to the tar
        tarinfo = tarfile.TarInfo(name='dump.rdb')
        tarinfo.size = len(rdb_data)
        tar.addfile(tarinfo, io.BytesIO(rdb_data))
        tar.close()

        # Copy the tar to the container
        tar_stream.seek(0)
        redis_container.put_archive('/mnt/redis/', tar_stream.getvalue())

        logging.info(f"Copied RDB file to container at {container_rdb_path}")

        # Restart the container to load the RDB file
        logging.info("Restarting Redis container to load dataset...")
        redis_container.restart(timeout=dataset_load_timeout_secs)

        # Wait for Redis to be ready
        max_wait = 30
        wait_time = 0
        while wait_time < max_wait:
            try:
                # Try to connect to verify Redis is ready
                import redis
                r = redis.StrictRedis(host='127.0.0.1', port=6379, socket_connect_timeout=5)
                r.ping()
                break
            except:
                time.sleep(1)
                wait_time += 1

        if wait_time >= max_wait:
            return False, "Redis container did not become ready after restart"

        load_time = time.time() - start_time
        logging.info(f"Successfully loaded RDB file in {load_time:.2f} seconds")

        return True, None

    except Exception as e:
        error_msg = f"Unexpected error loading RDB file into container: {str(e)}"
        logging.error(error_msg)
        return False, error_msg


def validate_dataset_keyspace(redis_host="127.0.0.1", redis_port=6379, redis_password=None,
                             expected_keyspace_len=None):
    """
    Validate that the loaded dataset has the expected number of keys.

    Args:
        redis_host (str): Redis host
        redis_port (int): Redis port
        redis_password (str): Redis password (optional)
        expected_keyspace_len (int): Expected number of keys (optional)

    Returns:
        tuple: (success: bool, actual_keyspace_len: int, error_message: str)
    """
    try:
        r = redis.StrictRedis(host=redis_host, port=redis_port, password=redis_password)

        # Get the actual keyspace length
        actual_keyspace_len = r.dbsize()

        logging.info(f"Dataset validation: found {actual_keyspace_len} keys in Redis")

        if expected_keyspace_len is not None:
            if actual_keyspace_len != expected_keyspace_len:
                error_msg = f"Keyspace validation failed: expected {expected_keyspace_len} keys, found {actual_keyspace_len}"
                logging.error(error_msg)
                return False, actual_keyspace_len, error_msg
            else:
                logging.info(f"Keyspace validation passed: {actual_keyspace_len} keys as expected")

        return True, actual_keyspace_len, None

    except Exception as e:
        error_msg = f"Error validating dataset keyspace: {str(e)}"
        logging.error(error_msg)
        return False, 0, error_msg


def validate_dataset_config(benchmark_config):
    """
    Validate dataset configuration before attempting to load.

    Args:
        benchmark_config (dict): Benchmark configuration containing dbconfig

    Returns:
        tuple: (is_valid: bool, error_message: str)
    """
    try:
        dbconfig = benchmark_config.get('dbconfig', {})

        # Check if dataset is specified
        dataset_url = dbconfig.get('dataset')
        if not dataset_url:
            return True, None  # No dataset to validate

        # Validate URL format
        if not dataset_url.startswith(('http://', 'https://')):
            return False, f"Invalid dataset URL format: {dataset_url}. Must start with http:// or https://"

        # Validate timeout
        dataset_load_timeout_secs = dbconfig.get('dataset_load_timeout_secs', 1000)
        if not isinstance(dataset_load_timeout_secs, (int, float)) or dataset_load_timeout_secs <= 0:
            return False, f"Invalid dataset_load_timeout_secs: {dataset_load_timeout_secs}. Must be a positive number"

        # Validate keyspace check if present
        if 'check' in dbconfig and 'keyspacelen' in dbconfig['check']:
            expected_keyspace_len = dbconfig['check']['keyspacelen']
            if not isinstance(expected_keyspace_len, int) or expected_keyspace_len < 0:
                return False, f"Invalid keyspacelen: {expected_keyspace_len}. Must be a non-negative integer"

        return True, None

    except Exception as e:
        return False, f"Error validating dataset config: {str(e)}"


def handle_dataset_loading(benchmark_config, redis_container, temporary_dir,
                          redis_host="127.0.0.1", redis_port=6379, redis_password=None):
    """
    Complete dataset handling: download, load, and validate.

    Args:
        benchmark_config (dict): Benchmark configuration containing dbconfig
        redis_container: Docker container object for Redis
        temporary_dir (str): Directory for temporary files
        redis_host (str): Redis host
        redis_port (int): Redis port
        redis_password (str): Redis password (optional)

    Returns:
        tuple: (success: bool, error_message: str)
    """
    try:
        # Step 0: Validate configuration
        is_valid, validation_error = validate_dataset_config(benchmark_config)
        if not is_valid:
            return False, f"Dataset configuration validation failed: {validation_error}"

        dbconfig = benchmark_config.get('dbconfig', {})

        # Check if dataset is specified
        dataset_url = dbconfig.get('dataset')
        if not dataset_url:
            return True, None  # No dataset to load

        # Get configuration parameters
        dataset_load_timeout_secs = dbconfig.get('dataset_load_timeout_secs', 1000)
        expected_keyspace_len = None

        if 'check' in dbconfig and 'keyspacelen' in dbconfig['check']:
            expected_keyspace_len = dbconfig['check']['keyspacelen']

        dataset_name = dbconfig.get('dataset_name', 'unknown')

        logging.info(f"Starting dataset loading for '{dataset_name}' from {dataset_url}")
        logging.info(f"Dataset timeout: {dataset_load_timeout_secs}s, Expected keyspace: {expected_keyspace_len}")

        # Track dataset loading metrics
        dataset_start_time = time.time()

        # Step 1: Download the dataset
        logging.info(f"Step 1/3: Downloading dataset from {dataset_url}")
        download_start_time = time.time()
        success, rdb_file_path, error_msg = download_dataset(
            dataset_url, temporary_dir, dataset_load_timeout_secs
        )
        download_time = time.time() - download_start_time

        if not success:
            logging.error(f"Dataset download failed after {download_time:.2f}s: {error_msg}")
            return False, f"Dataset download failed: {error_msg}"
        else:
            logging.info(f"Dataset download completed in {download_time:.2f}s")

        # Step 2: Load the RDB file into Redis container
        logging.info(f"Step 2/3: Loading RDB file into Redis container")
        load_start_time = time.time()
        success, error_msg = load_rdb_into_redis_container(
            rdb_file_path, redis_container, dataset_load_timeout_secs
        )
        load_time = time.time() - load_start_time

        if not success:
            logging.error(f"Dataset loading failed after {load_time:.2f}s: {error_msg}")
            return False, f"Dataset loading failed: {error_msg}"
        else:
            logging.info(f"Dataset loading completed in {load_time:.2f}s")

        # Step 3: Validate the keyspace if expected length is specified
        logging.info(f"Step 3/3: Validating dataset keyspace")
        validation_start_time = time.time()
        if expected_keyspace_len is not None:
            success, actual_len, error_msg = validate_dataset_keyspace(
                redis_host, redis_port, redis_password, expected_keyspace_len
            )
            validation_time = time.time() - validation_start_time

            if not success:
                logging.error(f"Dataset validation failed after {validation_time:.2f}s: {error_msg}")
                return False, f"Dataset validation failed: {error_msg}"
            else:
                logging.info(f"Dataset validation passed in {validation_time:.2f}s: {actual_len} keys match expected {expected_keyspace_len}")
        else:
            # Still log the actual keyspace size for informational purposes
            success, actual_len, _ = validate_dataset_keyspace(
                redis_host, redis_port, redis_password, None
            )
            validation_time = time.time() - validation_start_time
            if success:
                logging.info(f"Dataset loaded successfully with {actual_len} keys (no validation required) - checked in {validation_time:.2f}s")

        # Log overall dataset loading metrics
        total_time = time.time() - dataset_start_time
        logging.info(f"Successfully loaded and validated dataset '{dataset_name}' in {total_time:.2f}s total")
        logging.info(f"Dataset loading breakdown - Download: {download_time:.2f}s, Load: {load_time:.2f}s, Validation: {validation_time:.2f}s")

        # Log metrics in a structured format for potential monitoring integration
        metrics = {
            'dataset_name': dataset_name,
            'dataset_url': dataset_url,
            'total_time_seconds': total_time,
            'download_time_seconds': download_time,
            'load_time_seconds': load_time,
            'validation_time_seconds': validation_time,
            'keyspace_size': actual_len if 'actual_len' in locals() else 0,
            'expected_keyspace_size': expected_keyspace_len,
            'validation_required': expected_keyspace_len is not None,
            'success': True
        }
        logging.info(f"Dataset loading metrics: {metrics}")

        return True, None

    except Exception as e:
        error_msg = f"Unexpected error in dataset handling: {str(e)}"
        logging.error(error_msg)

        # Log error metrics for monitoring
        error_metrics = {
            'dataset_name': dataset_name if 'dataset_name' in locals() else 'unknown',
            'dataset_url': dataset_url if 'dataset_url' in locals() else 'unknown',
            'error_type': type(e).__name__,
            'error_message': str(e),
            'success': False
        }
        logging.error(f"Dataset loading error metrics: {error_metrics}")

        return False, error_msg
