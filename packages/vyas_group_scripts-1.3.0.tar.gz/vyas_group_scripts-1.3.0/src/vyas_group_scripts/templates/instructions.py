import os
water_xyz ="""3

O   0.0000   0.0000   0.0626
H  -0.7920   0.0000  -0.4973
H   0.7920   0.0000  -0.4973"""

water_g16 = """# hf/def2svp

HELLO WATER!

0 1
O   0.0000   0.0000   0.0626
H  -0.7920   0.0000  -0.4973
H   0.7920   0.0000  -0.4973

"""

water_orca = """!HF DEF2-SVP

# HELLO WATER!!!

* xyz 0 1
O   0.0000   0.0000   0.0626
H  -0.7920   0.0000  -0.4973
H   0.7920   0.0000  -0.4973
*"""

setup_instructions = """# Welcome to the vyas-group-scripts utility!

There are a few core utilities that you will be introduced to in this folder,
but first you need to do a little set up so the scripts will run smoothly.


A note on this set up and introduction, when you see text that is in backticks
i.e. `grep "HELLO WATER" water*`  and are asked to copy and paste it in
to the terminal or in to a file do not include the backticks that wrap it.
Additionally, if you see something inclosed in greater than  and less than signs
you are meant to replace that section and remove the wrapping greater than and less
than symbols. For example 'myname="<yourname>"' would turn in to `myname="Jimmy Neutron"`

# Setting environment variables
vyas_group_scripts uses environment variables to customize your configuration. To
there are a couple ways to change or set environment variables, we are just going to
add them to your bashrc.

To check what environment variables are available in vyas_group_scripts you can run
the command `vgs_env_var` in your terminal.

To open your bashrc in VSCode put `code ~/.bashrc` in a VSCode terminal and VSCode
will open it up. We do not want to change much we are just going to add a few lines.
Each environment variable must be set on their own lines.

## Required Environment Variables

### ACTNUM
ACTNUM is the account number that will get submitted in batch scripts. If you are 
using wendian you can check all of the possible account numbers by running 
`sacctmgr show Account` in the terminal. This can be narrowed down by using your
advisors name with the grep command. `sacctmgr show Account | grep <advisor>` i.e.
`sacctmgr show Account | grep svyas`. Then on a new line you will take one of those
numbers on the left associated with the accounts and place the following text on its
own line in your bashrc.

`ACTNUM=<your_account_number>`

If you have multiple you may have to try running a few jobs and trying a few options
to get the right one. Templates can be found in the folder you found this
document to make this easy.

## Optional Environment Variables

These environment variables have defaults built in to vyas_group_scripts but can be
by modifying and copying the line in backticks in to your bashrc

### DEFAULT_DFT_TIME

`DEFAULT_DFT_TIME="<HH:MM:DD>"`

This variable sets the default ammount of time a DFT job is alotted to run. It has a
default value of 0:59:00.

### DEFAULT_DFT_PROCESSORS

`DEFAULT_DFT_PROCESSORS=<num_processors>`

This is the default number of processors for a DFT job. It has a default value
of 36.

# Testing the command line utilities

vyas_group_scripts has a few command line utilities. The core functionality is in
pygab and pyrab. Go ahead and navigate the the directory that holds this file in
the terminal and look at the files that are present. You should see three files
for water molecules the .inp extension is an orca job, .gjf extension is for gaussian
jobs, and .xyz is a common molecule file format with xyz data.

Now run `pygab` in the terminal and look at the files that are created. You will notice that
a new .inp file was created that has the same base as the .xyz file. This is an orca job that
will use the .xyz as a starting geometry. You will also notics that there is not a .s file 
that matches each .gjf and .inp file. These are the batch files to submit jobs to slurm.
They don't get submitted immediately because you may want to make changes to some of them 
before hand. Feel free to go through some of these files and try to understand what they do.
Feel free to use an LLM to help parse it out. For now we shouldn't need to make any edits.

The next core function is to submit the jobs using `pyrab`. This will run all of the
batch files.

These tools have more functionality to them, and you can check it out in the documentation or
by passing the `-h` flag as an argument when calling the commands
"""

def check_env_var():
    req_env_vars = {
        "ACTNUM" : None
    }
    opt_env_vars = {
        "DEFAULT_DFT_TIME":"0:59:00",
        "DEFAULT_DFT_PROCESSORS":36,
    }

    print("REQUIRED ENVIRONMENT VARIABLES:")
    for i in req_env_vars.keys():
        req_env_vars[i] = os.environ.get(i)
        if req_env_vars[i] == None:
            print(i," !!! No variable set")
        else:
            print(f"{i}: {req_env_vars[i]}")
    
    for i in opt_env_vars.keys():
        if os.environ.get(i) == None:
            print(f"{i}: None set, default is {opt_env_vars[i]}")
        else:
            print(f"{i}: {opt_env_vars[i]}")
        
def make_test_files():
    base_folder = ("vgs_tests")
    ammend = 1
    while os.path.isdir(base_folder):
        base_folder = f"vgs_tests{ammend}"
        ammend +=1
    os.mkdir(base_folder)
    os.chdir(base_folder)
    with open("water_g16.gjf","w") as file:
        file.write(water_g16)
    with open("water_orca.inp","w") as file:
        file.write(water_orca)
    with open("water_xyz.xyz","w") as file:
        file.write(water_xyz)
    with open("INTRODUCTION.md","w") as file:
        file.write(setup_instructions)