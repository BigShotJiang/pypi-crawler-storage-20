"""
SketchGoblin Parameters - Generic parameter system for AI image generation
All parameter names are abstracted to hide implementation details
"""

# === STYLE PRESETS ===
# Generic style names that map to internal style modifiers
STYLES = {
    # General Styles
    "default": {"prompt": "", "negative": ""},
    "cinematic": {
        "prompt": "cinematic shot, dynamic lighting, 75mm, Technicolor, Panavision, sharp focus, fine details, 8k, HDR, film still, depth of field",
        "negative": "bad lighting, low-quality, deformed, text, poorly drawn, bad art, bad angle, boring, low-resolution, worst quality"
    },
    "digital-art": {
        "prompt": "digital art, highly detailed, vibrant colors, sharp focus, artstation trending, 4k",
        "negative": "blurry, low quality, bad anatomy, deformed"
    },
    "oil-painting": {
        "prompt": "oil painting, masterpiece, classical art style, rich textures, brush strokes visible, museum quality",
        "negative": "digital, modern, low quality, blurry"
    },
    "watercolor": {
        "prompt": "watercolor painting, soft edges, flowing colors, artistic, delicate, paper texture",
        "negative": "digital, harsh lines, low quality"
    },
    "anime": {
        "prompt": "anime style, detailed anime art, vibrant, clean lines, studio quality",
        "negative": "realistic, photograph, blurry, bad anatomy"
    },
    "anime-soft": {
        "prompt": "soft anime style, pastel colors, gentle lighting, cute, kawaii",
        "negative": "harsh, dark, realistic, low quality"
    },
    "manga": {
        "prompt": "manga style, black and white, detailed linework, dramatic shading",
        "negative": "color, blurry, low quality"
    },
    "ghibli": {
        "prompt": "studio ghibli style, miyazaki, hand-drawn animation, whimsical, detailed backgrounds",
        "negative": "3d, realistic, low quality"
    },
    "photo": {
        "prompt": "professional photograph, DSLR, sharp focus, natural lighting, high resolution",
        "negative": "drawing, painting, cartoon, blurry, low quality"
    },
    "portrait": {
        "prompt": "professional portrait photography, studio lighting, sharp focus, detailed skin texture",
        "negative": "blurry, deformed, bad anatomy, low quality"
    },
    "vintage": {
        "prompt": "vintage photography, film grain, retro aesthetic, nostalgic, warm tones",
        "negative": "modern, digital, sharp, clean"
    },
    "cyberpunk": {
        "prompt": "cyberpunk aesthetic, neon lights, futuristic, high tech, rain, night city",
        "negative": "natural, daylight, low quality, blurry"
    },
    "fantasy": {
        "prompt": "fantasy art, magical, epic, detailed, concept art, dramatic lighting",
        "negative": "modern, realistic, low quality"
    },
    "pixel": {
        "prompt": "pixel art, 8-bit, retro game style, crisp pixels, nostalgic",
        "negative": "blurry, smooth, realistic, high resolution"
    },
    "3d-render": {
        "prompt": "3D render, octane render, highly detailed, professional 3D art, realistic lighting",
        "negative": "2d, flat, low quality, blurry"
    },
    "concept-art": {
        "prompt": "concept art, professional, detailed, artstation, industry standard",
        "negative": "amateur, low quality, blurry"
    },
    "sketch": {
        "prompt": "pencil sketch, detailed drawing, artistic, hand-drawn, shading",
        "negative": "color, blurry, low quality"
    },
    "neon": {
        "prompt": "neon aesthetic, glowing, vibrant colors, dark background, synthwave",
        "negative": "natural, daylight, muted colors"
    },
    "dark": {
        "prompt": "dark aesthetic, moody lighting, shadows, dramatic, noir",
        "negative": "bright, cheerful, overexposed"
    },
    "pastel": {
        "prompt": "pastel colors, soft, gentle, dreamy, light aesthetic",
        "negative": "dark, harsh, saturated"
    },
}

# === QUALITY PRESETS ===
QUALITY_PRESETS = {
    "standard": {"prompt": "", "negative": ""},
    "high": {
        "prompt": "high quality, detailed, sharp focus, professional",
        "negative": "low quality, blurry, amateur"
    },
    "ultra": {
        "prompt": "masterpiece, best quality, ultra detailed, 8k, professional, sharp focus, intricate details",
        "negative": "worst quality, low quality, blurry, jpeg artifacts, watermark, text, deformed"
    },
    "maximum": {
        "prompt": "masterpiece, best quality, ultra detailed, 8k UHD, professional photography, sharp focus, intricate details, award winning",
        "negative": "worst quality, low quality, normal quality, blurry, jpeg artifacts, watermark, text, logo, deformed, bad anatomy, extra limbs"
    }
}

# === LIGHTING PRESETS ===
LIGHTING_PRESETS = {
    "auto": {"prompt": "", "negative": ""},
    "natural": {"prompt": "natural lighting, soft light", "negative": "artificial lighting"},
    "studio": {"prompt": "studio lighting, professional lighting, softbox", "negative": "natural light"},
    "golden-hour": {"prompt": "golden hour lighting, warm sunlight, sunset", "negative": "cold lighting"},
    "blue-hour": {"prompt": "blue hour, twilight, cool tones", "negative": "warm lighting"},
    "dramatic": {"prompt": "dramatic lighting, strong shadows, high contrast", "negative": "flat lighting"},
    "rim": {"prompt": "rim lighting, backlit, edge light", "negative": "flat lighting"},
    "neon": {"prompt": "neon lighting, colorful lights, glowing", "negative": "natural light"},
    "cinematic": {"prompt": "cinematic lighting, movie lighting, volumetric", "negative": "flat lighting"},
    "low-key": {"prompt": "low key lighting, dark, moody, shadows", "negative": "bright, overexposed"},
    "high-key": {"prompt": "high key lighting, bright, clean, minimal shadows", "negative": "dark, shadows"},
}

# === CAMERA PRESETS (for realistic models) ===
CAMERA_PRESETS = {
    "auto": {"prompt": "", "negative": ""},
    "portrait-85mm": {"prompt": "85mm lens, f/1.8, shallow depth of field, bokeh, portrait lens", "negative": ""},
    "portrait-135mm": {"prompt": "135mm lens, f/2.0, telephoto portrait, compressed background", "negative": ""},
    "wide-35mm": {"prompt": "35mm lens, wide angle, environmental, street photography", "negative": ""},
    "standard-50mm": {"prompt": "50mm lens, natural perspective, classic", "negative": ""},
    "macro": {"prompt": "macro photography, extreme close-up, detailed", "negative": ""},
    "telephoto": {"prompt": "telephoto lens, 200mm, compressed perspective, distant", "negative": ""},
    "fisheye": {"prompt": "fisheye lens, ultra wide, distorted", "negative": ""},
}

# === POSE/COMPOSITION PRESETS ===
COMPOSITION_PRESETS = {
    "auto": {"prompt": "", "negative": ""},
    "closeup": {"prompt": "close-up shot, detailed face, head and shoulders", "negative": "full body"},
    "medium": {"prompt": "medium shot, waist up, balanced composition", "negative": ""},
    "full-body": {"prompt": "full body shot, entire figure visible, head to toe", "negative": "close-up"},
    "wide": {"prompt": "wide shot, environmental, context, surroundings visible", "negative": "close-up"},
    "birds-eye": {"prompt": "bird's eye view, top down, aerial perspective", "negative": ""},
    "low-angle": {"prompt": "low angle shot, looking up, dramatic", "negative": ""},
    "dutch": {"prompt": "dutch angle, tilted frame, dynamic", "negative": ""},
    "over-shoulder": {"prompt": "over the shoulder shot, perspective", "negative": ""},
}

# === EXPRESSION PRESETS (for character models) ===
EXPRESSION_PRESETS = {
    "auto": {"prompt": "", "negative": ""},
    "happy": {"prompt": "happy expression, smiling, joyful", "negative": "sad, angry"},
    "serious": {"prompt": "serious expression, focused, determined", "negative": "smiling, laughing"},
    "sad": {"prompt": "sad expression, melancholic, emotional", "negative": "happy, smiling"},
    "angry": {"prompt": "angry expression, fierce, intense", "negative": "happy, calm"},
    "surprised": {"prompt": "surprised expression, shocked, wide eyes", "negative": "calm"},
    "shy": {"prompt": "shy expression, blushing, timid", "negative": "confident"},
    "confident": {"prompt": "confident expression, proud, self-assured", "negative": "shy, nervous"},
    "mysterious": {"prompt": "mysterious expression, enigmatic, subtle smile", "negative": "obvious"},
    "neutral": {"prompt": "neutral expression, calm, relaxed", "negative": "exaggerated"},
}

# === RESOLUTION PRESETS ===
RESOLUTIONS = {
    "square": "768x768",
    "square-sm": "512x512",
    "square-lg": "1024x1024",
    "portrait": "512x768",
    "portrait-lg": "768x1024",
    "landscape": "768x512",
    "landscape-lg": "1024x768",
    "wide": "896x512",
    "tall": "512x896",
}


def get_style(style_name: str) -> dict:
    """Get style modifiers by name"""
    return STYLES.get(style_name, STYLES["default"])


def get_quality(quality_name: str) -> dict:
    """Get quality modifiers by name"""
    return QUALITY_PRESETS.get(quality_name, QUALITY_PRESETS["standard"])


def get_lighting(lighting_name: str) -> dict:
    """Get lighting modifiers by name"""
    return LIGHTING_PRESETS.get(lighting_name, LIGHTING_PRESETS["auto"])


def get_camera(camera_name: str) -> dict:
    """Get camera modifiers by name"""
    return CAMERA_PRESETS.get(camera_name, CAMERA_PRESETS["auto"])


def get_composition(comp_name: str) -> dict:
    """Get composition modifiers by name"""
    return COMPOSITION_PRESETS.get(comp_name, COMPOSITION_PRESETS["auto"])


def get_expression(expr_name: str) -> dict:
    """Get expression modifiers by name"""
    return EXPRESSION_PRESETS.get(expr_name, EXPRESSION_PRESETS["auto"])


def get_resolution(shape: str) -> str:
    """Get resolution string from shape name"""
    return RESOLUTIONS.get(shape, RESOLUTIONS["square"])


def build_prompt(
    base_prompt: str,
    style: str = "default",
    quality: str = "standard",
    lighting: str = "auto",
    camera: str = "auto",
    composition: str = "auto",
    expression: str = "auto",
) -> tuple[str, str]:
    """
    Build final prompt and negative prompt with all modifiers applied.

    Returns:
        tuple: (enhanced_prompt, enhanced_negative_prompt)
    """
    # Collect all prompt additions
    prompt_parts = [base_prompt]
    negative_parts = []

    # Add style
    s = get_style(style)
    if s["prompt"]:
        prompt_parts.append(s["prompt"])
    if s["negative"]:
        negative_parts.append(s["negative"])

    # Add quality
    q = get_quality(quality)
    if q["prompt"]:
        prompt_parts.append(q["prompt"])
    if q["negative"]:
        negative_parts.append(q["negative"])

    # Add lighting
    l = get_lighting(lighting)
    if l["prompt"]:
        prompt_parts.append(l["prompt"])
    if l["negative"]:
        negative_parts.append(l["negative"])

    # Add camera
    c = get_camera(camera)
    if c["prompt"]:
        prompt_parts.append(c["prompt"])
    if c["negative"]:
        negative_parts.append(c["negative"])

    # Add composition
    comp = get_composition(composition)
    if comp["prompt"]:
        prompt_parts.append(comp["prompt"])
    if comp["negative"]:
        negative_parts.append(comp["negative"])

    # Add expression
    e = get_expression(expression)
    if e["prompt"]:
        prompt_parts.append(e["prompt"])
    if e["negative"]:
        negative_parts.append(e["negative"])

    return ", ".join(prompt_parts), ", ".join(negative_parts)


def list_styles() -> list:
    """List all available styles"""
    return list(STYLES.keys())


def list_quality_presets() -> list:
    """List all quality presets"""
    return list(QUALITY_PRESETS.keys())


def list_lighting() -> list:
    """List all lighting presets"""
    return list(LIGHTING_PRESETS.keys())


def list_cameras() -> list:
    """List all camera presets"""
    return list(CAMERA_PRESETS.keys())


def list_compositions() -> list:
    """List all composition presets"""
    return list(COMPOSITION_PRESETS.keys())


def list_expressions() -> list:
    """List all expression presets"""
    return list(EXPRESSION_PRESETS.keys())


def list_resolutions() -> list:
    """List all resolution presets"""
    return list(RESOLUTIONS.keys())


# Export all available options
AVAILABLE_OPTIONS = {
    "styles": list_styles(),
    "quality": list_quality_presets(),
    "lighting": list_lighting(),
    "camera": list_cameras(),
    "composition": list_compositions(),
    "expression": list_expressions(),
    "resolution": list_resolutions(),
}
