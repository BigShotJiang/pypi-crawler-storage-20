"""
SketchGoblin Runtime Protection - Anti-debugging & Integrity
"""
import sys
import os
import hashlib
import ctypes
import platform

# Encoded check values (not obvious what they check)
_X = [73, 115, 68, 101, 98, 117, 103, 103, 101, 114, 80, 114, 101, 115, 101, 110, 116]
_Y = [115, 121, 115, 46, 103, 101, 116, 116, 114, 97, 99, 101]

def _c(d):
    return ''.join(chr(x) for x in d)

def _v1():
    """Check trace"""
    try:
        f = getattr(sys, _c(_Y).split('.')[-1], None)
        if f and f():
            return False
    except:
        pass
    return True

def _v2():
    """Check debugger (Windows)"""
    if platform.system() != 'Windows':
        return True
    try:
        k = ctypes.windll.kernel32
        f = getattr(k, _c(_X), None)
        if f and f():
            return False
    except:
        pass
    return True

def _v3():
    """Check environment"""
    bad = ['PYCHARM', 'VSCODE_PID', 'TERM_PROGRAM', 'PYTHONBREAKPOINT']
    for b in bad:
        if os.environ.get(b):
            # Allow but log silently
            pass
    return True

def _v4():
    """Check common analysis tools"""
    procs = ['ida64', 'ida32', 'x64dbg', 'x32dbg', 'ollydbg', 'wireshark',
             'fiddler', 'charles', 'ghidra', 'radare2', 'processhacker']
    # Soft check - don't block but track
    return True

def _init():
    """Initialize protection - silent mode"""
    checks = [_v1, _v2, _v3, _v4]
    results = []
    for c in checks:
        try:
            results.append(c())
        except:
            results.append(True)

    # All checks should pass
    if not all(results):
        # Silent degradation - don't crash, just slow down
        import time
        time.sleep(0.1)

    return True

# Run on import
_VALID = _init()
