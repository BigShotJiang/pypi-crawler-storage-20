"""
Goblin FastAPI Server - Full Parameter Support
"""
import os
from typing import Optional, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.responses import Response, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .generator import Goblin
from .models import MODELS, CATEGORIES, list_models, get_model, get_model_styles, get_model_params
from .parameters import AVAILABLE_OPTIONS, STYLES, RESOLUTIONS


class GenerateRequestModel(BaseModel):
    """Full generation request with all parameters"""
    prompt: str = Field(..., description="Text description of the image to generate")
    negative_prompt: Optional[str] = Field(default="", description="Things to avoid")
    model: Optional[str] = Field(default="goblin-sd", description="Model ID (34 models available)")

    # Shape/Resolution
    shape: Optional[str] = Field(
        default="square",
        description="Image shape: square, portrait, landscape, square-lg, portrait-lg, landscape-lg"
    )

    # Core parameters
    seed: Optional[int] = Field(default=-1, description="Seed for reproducibility (-1 for random)")
    guidance_scale: Optional[float] = Field(
        default=None, ge=1, le=30,
        description="How strictly to follow prompt (None = use model default)"
    )

    # Style parameters
    style: Optional[str] = Field(
        default="default",
        description="Art style preset: cinematic, anime, photo, digital-art, oil-painting, etc."
    )
    quality: Optional[str] = Field(
        default="standard",
        description="Quality preset: standard, high, ultra, maximum"
    )

    # Advanced parameters
    lighting: Optional[str] = Field(
        default="auto",
        description="Lighting preset: natural, studio, golden-hour, neon, cinematic, etc."
    )
    camera: Optional[str] = Field(
        default="auto",
        description="Camera preset (for photo models): portrait-85mm, wide-35mm, macro, etc."
    )
    composition: Optional[str] = Field(
        default="auto",
        description="Shot composition: closeup, medium, full-body, wide, birds-eye, etc."
    )
    expression: Optional[str] = Field(
        default="auto",
        description="Character expression: happy, serious, sad, confident, mysterious, etc."
    )

    # Extra options
    style_strength: Optional[float] = Field(
        default=1.0, ge=0.0, le=1.0,
        description="How strongly to apply style (0.0-1.0)"
    )
    remove_background: Optional[bool] = Field(
        default=False,
        description="Attempt to generate transparent PNG"
    )


_generator: Optional[Goblin] = None


def create_app(static_dir: str = None) -> FastAPI:
    """Create FastAPI application"""

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        global _generator
        print("Starting Goblin Server...")
        print(f"Loading {len(MODELS)} models...")
        _generator = Goblin()
        await _generator.start()
        print(f"Ready! {len(MODELS)} models available")
        yield
        print("Shutting down...")
        await _generator.close()

    app = FastAPI(
        title="Goblin Image API",
        description="Free AI image generation with 34 models and full parameter support",
        version="2.0.0",
        lifespan=lifespan
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    if static_dir and os.path.exists(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")

        @app.get("/")
        async def root():
            index_path = os.path.join(static_dir, "index.html")
            if os.path.exists(index_path):
                return FileResponse(index_path)
            return {"message": "Goblin API", "docs": "/docs"}
    else:
        @app.get("/")
        async def root():
            return {
                "message": "Goblin API",
                "version": "2.0.0",
                "docs": "/docs",
                "models": "/models",
                "options": "/options"
            }

    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "models_loaded": len(MODELS),
            "ready": _generator is not None
        }

    # === Models Endpoints ===

    @app.get("/models")
    async def get_models():
        """Get all 34 models grouped by category"""
        return list_models()

    @app.get("/models/{model_id}")
    async def get_model_info(model_id: str):
        """Get detailed info for a specific model including supported parameters"""
        model = get_model(model_id)
        if not model:
            raise HTTPException(404, f"Model '{model_id}' not found")
        return {
            "id": model_id,
            **model,
            "supported_params": get_model_params(model_id),
            "supported_styles": get_model_styles(model_id)
        }

    @app.get("/models/{model_id}/styles")
    async def get_styles_for_model(model_id: str):
        """Get styles supported by a specific model"""
        model = get_model(model_id)
        if not model:
            raise HTTPException(404, f"Model '{model_id}' not found")
        return {
            "model": model_id,
            "styles": get_model_styles(model_id)
        }

    # === Options Endpoints ===

    @app.get("/options")
    async def get_all_options():
        """Get all available parameter options"""
        return AVAILABLE_OPTIONS

    @app.get("/options/styles")
    async def get_styles():
        """Get all available style presets"""
        return {"styles": list(STYLES.keys())}

    @app.get("/options/resolutions")
    async def get_resolutions():
        """Get all available resolution/shape options"""
        return {"resolutions": RESOLUTIONS}

    # === Generation Endpoints ===

    @app.post("/generate")
    async def generate(request: GenerateRequestModel):
        """Generate an image with full parameter support"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            image_data = await _generator.generate(
                prompt=request.prompt,
                negative_prompt=request.negative_prompt or "",
                model=request.model or "goblin-sd",
                shape=request.shape or "square",
                seed=request.seed if request.seed is not None else -1,
                guidance_scale=request.guidance_scale,
                style=request.style or "default",
                quality=request.quality or "standard",
                lighting=request.lighting or "auto",
                camera=request.camera or "auto",
                composition=request.composition or "auto",
                expression=request.expression or "auto",
                style_strength=request.style_strength or 1.0,
                remove_background=request.remove_background or False
            )

            return Response(
                content=image_data,
                media_type="image/jpeg",
                headers={
                    "X-Model": request.model or "goblin-sd",
                    "X-Style": request.style or "default",
                    "X-Quality": request.quality or "standard"
                }
            )

        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(500, str(e))

    @app.post("/generate/base64")
    async def generate_base64(request: GenerateRequestModel):
        """Generate image and return as base64 JSON"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            b64 = await _generator.generate_base64(
                prompt=request.prompt,
                negative_prompt=request.negative_prompt or "",
                model=request.model or "goblin-sd",
                shape=request.shape or "square",
                seed=request.seed if request.seed is not None else -1,
                guidance_scale=request.guidance_scale,
                style=request.style or "default",
                quality=request.quality or "standard",
                lighting=request.lighting or "auto",
                camera=request.camera or "auto",
                composition=request.composition or "auto",
                expression=request.expression or "auto",
                style_strength=request.style_strength or 1.0,
                remove_background=request.remove_background or False
            )

            return {
                "model": request.model or "goblin-sd",
                "prompt": request.prompt,
                "style": request.style or "default",
                "quality": request.quality or "standard",
                "image_base64": b64,
                "format": "jpeg"
            }

        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(500, str(e))

    @app.post("/generate/metadata")
    async def generate_with_metadata(request: GenerateRequestModel):
        """Generate image and return metadata (image_id, enhanced prompt, etc.)"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            result = await _generator.generate(
                prompt=request.prompt,
                negative_prompt=request.negative_prompt or "",
                model=request.model or "goblin-sd",
                shape=request.shape or "square",
                seed=request.seed if request.seed is not None else -1,
                guidance_scale=request.guidance_scale,
                style=request.style or "default",
                quality=request.quality or "standard",
                lighting=request.lighting or "auto",
                camera=request.camera or "auto",
                composition=request.composition or "auto",
                expression=request.expression or "auto",
                style_strength=request.style_strength or 1.0,
                remove_background=request.remove_background or False,
                return_bytes=False  # Return metadata instead
            )

            return result

        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(500, str(e))

    # === Convenience Endpoints ===

    @app.post("/generate/photo")
    async def generate_photo(
        prompt: str,
        camera: str = "portrait-85mm",
        lighting: str = "natural",
        model: str = "goblin-photo"
    ):
        """Quick endpoint for photo generation"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            image_data = await _generator.generate_photo(
                prompt=prompt,
                camera=camera,
                lighting=lighting,
                model=model
            )
            return Response(content=image_data, media_type="image/jpeg")
        except Exception as e:
            raise HTTPException(500, str(e))

    @app.post("/generate/anime")
    async def generate_anime(
        prompt: str,
        style: str = "anime",
        expression: str = "auto",
        model: str = "goblin-anime"
    ):
        """Quick endpoint for anime generation"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            image_data = await _generator.generate_anime(
                prompt=prompt,
                style=style,
                expression=expression,
                model=model
            )
            return Response(content=image_data, media_type="image/jpeg")
        except Exception as e:
            raise HTTPException(500, str(e))

    @app.post("/generate/portrait")
    async def generate_portrait(
        prompt: str,
        expression: str = "neutral",
        model: str = "goblin-portrait"
    ):
        """Quick endpoint for portrait generation"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            image_data = await _generator.generate_portrait(
                prompt=prompt,
                expression=expression,
                model=model
            )
            return Response(content=image_data, media_type="image/jpeg")
        except Exception as e:
            raise HTTPException(500, str(e))

    @app.post("/generate/cinematic")
    async def generate_cinematic(prompt: str, model: str = "goblin-sd"):
        """Quick endpoint for cinematic style generation"""
        if not _generator:
            raise HTTPException(503, "Generator not ready")

        try:
            image_data = await _generator.generate_cinematic(prompt=prompt, model=model)
            return Response(content=image_data, media_type="image/jpeg")
        except Exception as e:
            raise HTTPException(500, str(e))

    return app


def run_server(host: str = "0.0.0.0", port: int = 8000, static_dir: str = None):
    """Run the Goblin server"""
    import uvicorn
    app = create_app(static_dir)
    uvicorn.run(app, host=host, port=port)
