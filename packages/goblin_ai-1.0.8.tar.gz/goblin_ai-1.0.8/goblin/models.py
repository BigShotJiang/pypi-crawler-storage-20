"""
SketchGoblin Model Catalog - 34 Professional AI Image Generation Models
Each model includes supported parameters and optimal settings
"""

# === PARAMETER DEFINITIONS ===
# These define what parameters each category of models supports

PARAM_BASIC = ["style", "quality", "shape"]
PARAM_STANDARD = PARAM_BASIC + ["lighting", "composition"]
PARAM_PHOTO = PARAM_STANDARD + ["camera", "aperture", "focal_length"]
PARAM_CHARACTER = PARAM_STANDARD + ["expression", "pose"]
PARAM_ANIME = PARAM_STANDARD + ["expression", "style_mix"]
PARAM_FURRY = PARAM_CHARACTER + ["species_style"]
PARAM_FLUX = PARAM_STANDARD + ["performance_mode"]  # Flux has different CFG defaults

# === STYLE OPTIONS PER CATEGORY ===
CATEGORY_STYLES = {
    "general": [
        "default", "cinematic", "digital-art", "photo", "oil-painting",
        "watercolor", "concept-art", "fantasy", "cyberpunk", "3d-render"
    ],
    "flux": [
        "default", "cinematic", "photo", "digital-art", "concept-art",
        "realistic", "artistic", "neon", "vintage"
    ],
    "anime": [
        "default", "anime", "anime-soft", "manga", "ghibli",
        "vintage-anime", "painted-anime", "neon", "cyberpunk"
    ],
    "realistic": [
        "default", "photo", "portrait", "cinematic", "vintage",
        "professional", "casual", "dramatic", "soft"
    ],
    "nsfw": [
        "default", "realistic", "anime", "artistic", "cinematic"
    ],
    "furry": [
        "default", "cinematic", "painted", "toony", "kemono",
        "digital-art", "oil-painting", "3d-render"
    ],
    "art": [
        "default", "digital-art", "oil-painting", "watercolor", "concept-art",
        "fantasy", "cyberpunk", "pixel", "sketch", "neon"
    ],
}


MODELS = {
    # === GENERAL PURPOSE ===
    "goblin-sd": {
        "name": "Goblin SD",
        "channel": "ai-text-to-image-generator",
        "category": "general",
        "description": "Flagship Stable Diffusion model. Versatile and balanced for any style.",
        "tags": ["versatile", "balanced", "general"],
        "params": PARAM_STANDARD,
        "styles": CATEGORY_STYLES["general"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-sd-v2": {
        "name": "Goblin SD V2",
        "channel": "ai-image-generator",
        "category": "general",
        "description": "Second generation with improved coherence and detail.",
        "tags": ["versatile", "improved", "general"],
        "params": PARAM_STANDARD,
        "styles": CATEGORY_STYLES["general"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-pro": {
        "name": "Goblin Pro",
        "channel": "image-generator-professional",
        "category": "general",
        "description": "Professional-grade generator with all parameters unlocked.",
        "tags": ["high-quality", "detailed", "professional"],
        "params": PARAM_PHOTO + ["style_mix", "style_strength"],
        "styles": CATEGORY_STYLES["general"] + ["mix"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },

    # === FLUX MODELS ===
    "goblin-flux": {
        "name": "Goblin Flux",
        "channel": "flux-ai",
        "category": "flux",
        "description": "Flux.1 Schnell - Fast 12B parameter model with excellent prompt adherence.",
        "tags": ["fast", "high-quality", "12B", "text-render"],
        "params": PARAM_FLUX,
        "styles": CATEGORY_STYLES["flux"],
        "defaults": {"guidance_scale": 3.5, "quality": "maximum", "shape": "square-lg"},  # Flux uses lower CFG
        "notes": "Best for text rendering. Use natural language prompts, avoid weighting syntax."
    },
    "goblin-flux-dev": {
        "name": "Goblin Flux Dev",
        "channel": "flux-image-generator",
        "category": "flux",
        "description": "Flux model optimized for creative development.",
        "tags": ["creative", "experimental", "flux"],
        "params": PARAM_FLUX,
        "styles": CATEGORY_STYLES["flux"],
        "defaults": {"guidance_scale": 4, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-flux-pro": {
        "name": "Goblin Flux Pro",
        "channel": "flux-schnell",
        "category": "flux",
        "description": "Enhanced Flux with improved speed and quality balance.",
        "tags": ["fast", "optimized", "flux"],
        "params": PARAM_FLUX + ["performance_mode"],
        "styles": CATEGORY_STYLES["flux"],
        "defaults": {"guidance_scale": 1, "quality": "maximum", "shape": "square-lg"},  # Schnell optimized for CFG=1
        "notes": "Technically optimized for guidance_scale=1. Higher values may look over-saturated."
    },
    "goblin-laia": {
        "name": "Goblin LAIA",
        "channel": "laia",
        "category": "flux",
        "description": "LAIA - Professional Flux-based model for stunning visuals.",
        "tags": ["professional", "flux-based", "stunning"],
        "params": PARAM_FLUX,
        "styles": CATEGORY_STYLES["flux"],
        "defaults": {"guidance_scale": 4, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-laia-pro": {
        "name": "Goblin LAIA Pro",
        "channel": "laia-professional",
        "category": "flux",
        "description": "LAIA Pro - Maximum quality Flux-based generation.",
        "tags": ["maximum-quality", "professional", "flux"],
        "params": PARAM_FLUX + ["style_strength"],
        "styles": CATEGORY_STYLES["flux"],
        "defaults": {"guidance_scale": 4, "quality": "maximum", "shape": "square-lg"},
    },

    # === ANIME MODELS ===
    "goblin-anime": {
        "name": "Goblin Anime",
        "channel": "anime-image-generator",
        "category": "anime",
        "description": "Classic anime style generator for characters and scenes.",
        "tags": ["anime", "manga", "japanese"],
        "params": PARAM_ANIME,
        "styles": CATEGORY_STYLES["anime"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "anime"},
    },
    "goblin-anime-xl": {
        "name": "Goblin Anime XL",
        "channel": "advanced-anime-image-generator",
        "category": "anime",
        "description": "Advanced anime with fine-tuned details, style mixing, and more styles.",
        "tags": ["anime", "detailed", "advanced"],
        "params": PARAM_ANIME + ["style_mix", "additional_details"],
        "styles": CATEGORY_STYLES["anime"] + ["mix"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "painted-anime"},
        "notes": "Supports style mixing. Use weighting syntax like (keyword:1.2)."
    },
    "goblin-anime-v2": {
        "name": "Goblin Anime V2",
        "channel": "ai-anime-generator",
        "category": "anime",
        "description": "Second generation anime model with improved faces and hands.",
        "tags": ["anime", "improved", "v2"],
        "params": PARAM_ANIME,
        "styles": CATEGORY_STYLES["anime"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-anime-character": {
        "name": "Goblin Anime Character",
        "channel": "anime-character-generator",
        "category": "anime",
        "description": "Specialized for creating anime characters and OCs.",
        "tags": ["anime", "character", "oc"],
        "params": PARAM_CHARACTER + ["hair_style", "hair_color", "eye_color", "outfit", "personality"],
        "styles": CATEGORY_STYLES["anime"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "composition": "portrait"},
        "notes": "Includes character-specific options like hair, eyes, outfit presets."
    },

    # === REALISTIC / PHOTO MODELS ===
    "goblin-realistic": {
        "name": "Goblin Realistic",
        "channel": "ai-realistic-image-generator",
        "category": "realistic",
        "description": "Photorealistic image generation with lifelike details.",
        "tags": ["photorealistic", "lifelike", "detailed"],
        "params": PARAM_PHOTO,
        "styles": CATEGORY_STYLES["realistic"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "photo"},
    },
    "goblin-photo": {
        "name": "Goblin Photo",
        "channel": "ai-photo-generator",
        "category": "realistic",
        "description": "Camera-quality photos with natural lighting and lens options.",
        "tags": ["photo", "natural", "camera"],
        "params": PARAM_PHOTO + ["lens", "film_style"],
        "styles": CATEGORY_STYLES["realistic"] + ["1990s", "1980s", "film"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "professional"},
        "notes": "Supports lens specifications like '85mm portrait lens' and film styles."
    },
    "goblin-portrait": {
        "name": "Goblin Portrait",
        "channel": "ai-portrait-generator",
        "category": "realistic",
        "description": "Specialized portrait generator for faces and headshots.",
        "tags": ["portrait", "face", "headshot"],
        "params": PARAM_PHOTO + ["expression", "ethnicity"],
        "styles": CATEGORY_STYLES["realistic"] + ["studio", "environmental"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "composition": "closeup"},
    },
    "goblin-portrait-v2": {
        "name": "Goblin Portrait V2",
        "channel": "portrait-generator",
        "category": "realistic",
        "description": "Enhanced portrait model with better expressions.",
        "tags": ["portrait", "expressions", "v2"],
        "params": PARAM_PHOTO + ["expression"],
        "styles": CATEGORY_STYLES["realistic"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-portrait-hd": {
        "name": "Goblin Portrait HD",
        "channel": "realistic-portrait-generator",
        "category": "realistic",
        "description": "Ultra-realistic portrait photography style with skin texture details.",
        "tags": ["ultra-realistic", "portrait", "photography"],
        "params": PARAM_PHOTO + ["expression", "skin_detail"],
        "styles": CATEGORY_STYLES["realistic"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
        "notes": "Use 'skin pores', 'micro-expressions' for extra realism."
    },
    "goblin-human": {
        "name": "Goblin Human",
        "channel": "realistic-human-generator",
        "category": "realistic",
        "description": "Full-body realistic human generation.",
        "tags": ["human", "full-body", "realistic"],
        "params": PARAM_PHOTO + ["pose", "body_type"],
        "styles": CATEGORY_STYLES["realistic"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "composition": "full-body"},
    },
    "goblin-portrait-pro": {
        "name": "Goblin Portrait Pro",
        "channel": "ai-generated-realistic-portraits",
        "category": "realistic",
        "description": "Professional-grade realistic portrait generation.",
        "tags": ["professional", "portrait", "pro"],
        "params": PARAM_PHOTO + ["expression", "style_strength"],
        "styles": CATEGORY_STYLES["realistic"] + ["lora_realistic_vision"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },

    # === NSFW MODELS (18+) ===
    "goblin-uncensored": {
        "name": "Goblin Uncensored",
        "channel": "ai-image-generator-nsfw",
        "category": "nsfw",
        "description": "Uncensored realistic generation for adult content.",
        "tags": ["uncensored", "adult", "18+"],
        "nsfw": True,
        "params": PARAM_PHOTO + ["pose"],
        "styles": CATEGORY_STYLES["nsfw"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-uncensored-v2": {
        "name": "Goblin Uncensored V2",
        "channel": "nsfw-ai-image-generator",
        "category": "nsfw",
        "description": "Enhanced uncensored model with better anatomy.",
        "tags": ["uncensored", "enhanced", "18+"],
        "nsfw": True,
        "params": PARAM_PHOTO + ["pose"],
        "styles": CATEGORY_STYLES["nsfw"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-uncensored-v3": {
        "name": "Goblin Uncensored V3",
        "channel": "ai-nsfw-generator",
        "category": "nsfw",
        "description": "Latest uncensored model with improved quality.",
        "tags": ["uncensored", "latest", "18+"],
        "nsfw": True,
        "params": PARAM_PHOTO + ["pose", "style_strength"],
        "styles": CATEGORY_STYLES["nsfw"] + ["stronger"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-anime-uncensored": {
        "name": "Goblin Anime Uncensored",
        "channel": "anime-image-generator-nsfw",
        "category": "nsfw",
        "description": "Uncensored anime-style adult content generator.",
        "tags": ["anime", "uncensored", "18+"],
        "nsfw": True,
        "params": PARAM_ANIME + ["pose"],
        "styles": CATEGORY_STYLES["nsfw"] + CATEGORY_STYLES["anime"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "anime"},
    },

    # === FURRY MODELS ===
    "goblin-furry": {
        "name": "Goblin Furry",
        "channel": "ai-furry-generator",
        "category": "furry",
        "description": "Anthropomorphic art generator for furry characters.",
        "tags": ["furry", "anthropomorphic", "fursona"],
        "params": PARAM_FURRY + ["quality_score"],
        "styles": CATEGORY_STYLES["furry"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
        "notes": "Supports Pony Diffusion quality scores (6-9)."
    },
    "goblin-furry-v2": {
        "name": "Goblin Furry V2",
        "channel": "furry-image-generator",
        "category": "furry",
        "description": "Enhanced furry model with more species options.",
        "tags": ["furry", "enhanced", "species"],
        "params": PARAM_FURRY + ["species", "fur_color", "pattern"],
        "styles": CATEGORY_STYLES["furry"] + ["kemono", "pony"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-fursona": {
        "name": "Goblin Fursona",
        "channel": "furry-persona-generator-v1",
        "category": "furry",
        "description": "Specialized fursona and OC creation tool.",
        "tags": ["fursona", "oc", "creator"],
        "params": PARAM_FURRY + ["species", "fur_color", "pattern", "accessories"],
        "styles": CATEGORY_STYLES["furry"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },

    # === ART STYLE MODELS ===
    "goblin-digital": {
        "name": "Goblin Digital Art",
        "channel": "digital-art-generator",
        "category": "art",
        "description": "Modern digital art style with vibrant colors.",
        "tags": ["digital", "vibrant", "modern"],
        "params": PARAM_STANDARD,
        "styles": CATEGORY_STYLES["art"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "digital-art"},
    },
    "goblin-concept": {
        "name": "Goblin Concept Art",
        "channel": "concept-art-generator",
        "category": "art",
        "description": "Professional concept art for games and films.",
        "tags": ["concept", "professional", "games"],
        "params": PARAM_STANDARD + ["theme", "mood"],
        "styles": CATEGORY_STYLES["art"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "concept-art"},
        "notes": "Includes randomized concept generators for creatures, environments, characters."
    },
    "goblin-fantasy": {
        "name": "Goblin Fantasy",
        "channel": "fantasy-image-generator",
        "category": "art",
        "description": "Epic fantasy scenes, creatures, and characters.",
        "tags": ["fantasy", "epic", "magical"],
        "params": PARAM_STANDARD + ["creature_type", "setting"],
        "styles": CATEGORY_STYLES["art"] + ["medieval", "magical"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "fantasy"},
    },
    "goblin-cyberpunk": {
        "name": "Goblin Cyberpunk",
        "channel": "cyberpunk-image-generator",
        "category": "art",
        "description": "Neon-lit cyberpunk aesthetics and sci-fi.",
        "tags": ["cyberpunk", "neon", "sci-fi"],
        "params": PARAM_STANDARD,
        "styles": ["cyberpunk", "neon", "synthwave", "dark", "futuristic"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "cyberpunk", "lighting": "neon"},
    },
    "goblin-pixel": {
        "name": "Goblin Pixel Art",
        "channel": "pixel-art-generator",
        "category": "art",
        "description": "Retro pixel art style for games and nostalgia.",
        "tags": ["pixel", "retro", "8bit"],
        "params": PARAM_BASIC + ["palette", "resolution_style"],
        "styles": ["pixel", "8bit", "16bit", "gameboy", "nes"],
        "defaults": {"guidance_scale": 7, "quality": "standard", "shape": "square-lg", "style": "pixel"},
    },
    "goblin-oil": {
        "name": "Goblin Oil Painting",
        "channel": "oil-painting-generator",
        "category": "art",
        "description": "Classical oil painting style with rich textures.",
        "tags": ["oil", "classical", "painting"],
        "params": PARAM_STANDARD + ["brush_style", "era"],
        "styles": ["oil-painting", "realism", "impressionist", "old-master", "painterly"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg", "style": "oil-painting"},
        "notes": "Use 'heavy impasto', 'visible brushstrokes', 'canvas texture' for better results."
    },
    "goblin-creative": {
        "name": "Goblin Creative",
        "channel": "ai-art-generator",
        "category": "art",
        "description": "Creative AI art with unique interpretations.",
        "tags": ["creative", "unique", "ai"],
        "params": PARAM_STANDARD + ["randomize"],
        "styles": CATEGORY_STYLES["art"] + ["surreal", "abstract"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
    },
    "goblin-character": {
        "name": "Goblin Character",
        "channel": "character-image-generator",
        "category": "art",
        "description": "Character design for games, comics, and animation.",
        "tags": ["character", "design", "comics"],
        "params": PARAM_CHARACTER + ["outfit", "weapon", "pose"],
        "styles": CATEGORY_STYLES["art"] + ["game-art", "comic", "3d-disney"],
        "defaults": {"guidance_scale": 7, "quality": "maximum", "shape": "square-lg"},
        "notes": "Supports BREAK syntax to separate character from background descriptions."
    },
}

CATEGORIES = {
    "general": {
        "name": "General Purpose",
        "description": "Versatile models for any style",
        "default_params": PARAM_STANDARD,
    },
    "flux": {
        "name": "Flux Models",
        "description": "High-quality 12B parameter models with text rendering",
        "default_params": PARAM_FLUX,
        "notes": "Use natural language prompts. Lower CFG (1-5) recommended."
    },
    "anime": {
        "name": "Anime & Manga",
        "description": "Japanese anime and manga styles",
        "default_params": PARAM_ANIME,
    },
    "realistic": {
        "name": "Realistic & Photo",
        "description": "Photorealistic and portrait generation",
        "default_params": PARAM_PHOTO,
    },
    "nsfw": {
        "name": "NSFW (18+)",
        "description": "Uncensored adult content",
        "default_params": PARAM_PHOTO,
        "age_restricted": True,
    },
    "furry": {
        "name": "Furry",
        "description": "Anthropomorphic and furry art",
        "default_params": PARAM_FURRY,
    },
    "art": {
        "name": "Art Styles",
        "description": "Specific artistic styles",
        "default_params": PARAM_STANDARD,
    },
}


def get_model(model_id: str) -> dict:
    """Get model info by ID"""
    return MODELS.get(model_id)


def get_model_params(model_id: str) -> list:
    """Get supported parameters for a model"""
    model = MODELS.get(model_id)
    if model:
        return model.get("params", PARAM_STANDARD)
    return PARAM_STANDARD


def get_model_styles(model_id: str) -> list:
    """Get supported styles for a model"""
    model = MODELS.get(model_id)
    if model:
        return model.get("styles", ["default"])
    return ["default"]


def get_model_defaults(model_id: str) -> dict:
    """Get default settings for a model"""
    model = MODELS.get(model_id)
    if model:
        return model.get("defaults", {})
    return {}


def list_models() -> dict:
    """List all models grouped by category"""
    models_by_category = {}
    for model_id, model_info in MODELS.items():
        category = model_info["category"]
        if category not in models_by_category:
            models_by_category[category] = {
                "info": CATEGORIES.get(category, {}),
                "models": []
            }
        models_by_category[category]["models"].append({
            "id": model_id,
            "name": model_info["name"],
            "description": model_info["description"],
            "tags": model_info.get("tags", []),
            "nsfw": model_info.get("nsfw", False),
            "params": model_info.get("params", PARAM_STANDARD),
            "styles": model_info.get("styles", ["default"]),
        })
    return {"total_models": len(MODELS), "categories": models_by_category}


def get_all_params() -> dict:
    """Get all available parameter types"""
    return {
        "basic": PARAM_BASIC,
        "standard": PARAM_STANDARD,
        "photo": PARAM_PHOTO,
        "character": PARAM_CHARACTER,
        "anime": PARAM_ANIME,
        "furry": PARAM_FURRY,
        "flux": PARAM_FLUX,
    }
