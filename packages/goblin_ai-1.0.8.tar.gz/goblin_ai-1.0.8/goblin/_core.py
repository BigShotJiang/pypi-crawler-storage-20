"""
SketchGoblin Core - Compiled native extension
This file will be compiled with Nuitka to a .pyd binary
"""
import asyncio
import random
import base64 as b64
from typing import Literal

# Encrypted strings (double-encoded)
_X = lambda s: b64.b64decode(b64.b64decode(s)).decode()
_A = "YVcxaFoyVXRaMlZ1WlhKaGRHbHZiaTV3WlhKamFHRnVZMlV1YjNKbg=="  # domain
_B = "TDJGd2FTOHc="  # path

class _C:
    """Cloudscraper wrapper with obfuscated init"""
    def __init__(self):
        import cloudscraper as cs
        self._s = cs.create_scraper()
    def g(self, u): return self._s.get(u)
    def p(self, u, j): return self._s.post(u, json=j)

class NexusCore:
    def __init__(self):
        self._c = None
        self._k = None

    async def init(self):
        self._c = _C()

    def _u(self):
        return f"https://{_X(_A)}{_X(_B)}"

    def _gk(self):
        r = self._c.g(f"{self._u()}verifyUser?thread=0&__cacheBust={random.random()}")
        d = r.json()
        if d.get("userKey"):
            self._k = d["userKey"]
            return self._k
        raise Exception("Auth failed")

    async def gen(self, prompt: str, ch: str, neg: str = "", seed: int = -1,
                  res: str = "768x768", gs: float = 7.0) -> dict:
        if not self._c:
            await self.init()

        for _ in range(3):
            try:
                if not self._k:
                    self._gk()

                url = f"{self._u()}generate?userKey={self._k}&requestId=gen{random.randint(0,2**30)}&__cacheBust={random.random()}"
                body = {
                    "generatorName": "ai-image-generator",
                    "channel": ch,
                    "subChannel": "public",
                    "prompt": prompt,
                    "negativePrompt": neg,
                    "seed": seed,
                    "resolution": res,
                    "guidanceScale": gs
                }
                r = self._c.p(url, body)
                d = r.json()

                if d.get("imageId"):
                    return d

                s = d.get("status", "")
                if s == "waiting_for_prev_request_to_finish":
                    await asyncio.sleep(2)
                    continue
                elif "invalid" in s.lower():
                    self._k = None
                    continue
                else:
                    raise Exception(f"Failed: {d}")
            except Exception as e:
                self._k = None
                await asyncio.sleep(1)

        raise Exception("Gen failed")

    async def dl(self, img_id: str) -> bytes:
        url = f"{self._u()}downloadTemporaryImage?imageId={img_id}"
        for _ in range(3):
            r = self._c.g(url)
            if r.status_code == 200:
                return r.content
            await asyncio.sleep(1)
        raise Exception("DL failed")
