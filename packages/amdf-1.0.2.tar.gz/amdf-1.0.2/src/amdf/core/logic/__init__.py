# Core logic module
