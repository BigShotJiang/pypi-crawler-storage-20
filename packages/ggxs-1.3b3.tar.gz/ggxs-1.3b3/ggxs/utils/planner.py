"""
Planner

Asynchronous priority-based job scheduler built on top of asyncio.

This planner runs jobs sequentially (one at a time) with:
- priority ordering (lower value = higher priority)
- optional rate limiting between jobs
- optional "urgent" bypass for priority == 0
- retries with delay on failure/timeout
- basic runtime metrics
- graceful shutdown + reset helpers

Designed for long-running asyncio apps (bots, workers, rate-limited pipelines).
"""

import asyncio
import time
import random
import math
from typing import Any, Dict, Optional, List, Callable, Awaitable
from dataclasses import dataclass, field
from loguru import logger
from contextlib import asynccontextmanager


@dataclass(order=True)
class _QueuedJob:
    """
    Internal representation of a job ready for execution.

    Ordering:
        1) priority (lower first)
        2) run_at_monotonic (earlier first)
        3) seq (stable FIFO tie-breaker)
    """

    priority: int
    run_at_monotonic: float
    seq: int
    key: str = field(compare=False)
    payload: Dict[str, Any] = field(compare=False)


class Planner:
    """
    Sequential, priority-based asyncio job scheduler.

    Execution model:
        schedule_* -> timer sleeps -> job is enqueued into a PriorityQueue -> worker executes job.

    Notes:
        - No preemption: a running job is never interrupted by a newer one.
        - "Urgent" means priority == urgent_bypass_priority (default 0) and bypasses interval delay.
    """

    __slots__ = (
        "on_expire",
        "min_interval",
        "max_interval",
        "jitter_enabled",
        "urgent_bypass_priority",
        "process_interval",
        "job_timeout",
        "max_retries",
        "retry_delay",
        "_job_queue",
        "_timer_tasks",
        "_run_at",
        "_payloads",
        "_priorities",
        "_worker_task",
        "_running",
        "_shutdown",
        "_seq",
        "_last_job_done_time",
        "_lock",
        "_metrics",
        "_active_count",
    )

    def __init__(
        self,
        on_expire: Callable[[str, Dict[str, Any]], Awaitable[None]],
        *,
        process_interval: float = 4.0,
        min_interval: float = 4.0,
        max_interval: float = 10.0,
        jitter_enabled: bool = True,
        urgent_bypass_priority: int = 0,
        job_timeout: Optional[float] = 30.0,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        max_queue_size: int = 10_000,
    ):
        """
        Create a Planner.

        Args:
            on_expire:
                Async callback executed for each job.
                Signature: `async def on_expire(key: str, payload: dict) -> None`

            process_interval:
                Minimum delay (seconds) between *non-urgent* job starts.

            min_interval, max_interval:
                Bounds used when clamping the interval and applying jitter.

            jitter_enabled:
                If True, adds a small random variation to the enforced delay.

            urgent_bypass_priority:
                Jobs with priority == urgent_bypass_priority bypass the interval (default: 0).
                Set to -1 to effectively disable urgent bypass behavior.

            job_timeout:
                If provided, each job execution is wrapped in asyncio.wait_for(timeout).

            max_retries:
                Maximum number of retries on failure/timeout.

            retry_delay:
                Delay (seconds) before scheduling a retry.

            max_queue_size:
                Maximum size of the READY priority queue.
        """
        if not asyncio.iscoroutinefunction(on_expire):
            raise TypeError("on_expire must be an async function")

        self.on_expire = on_expire

        self.min_interval = float(min_interval)
        self.max_interval = float(max_interval)
        self.jitter_enabled = bool(jitter_enabled)
        self.urgent_bypass_priority = int(urgent_bypass_priority)

        self.job_timeout = float(job_timeout) if job_timeout is not None else None
        self.max_retries = max(0, int(max_retries))
        self.retry_delay = max(0.0, float(retry_delay))

        self._job_queue: asyncio.PriorityQueue[_QueuedJob] = asyncio.PriorityQueue(
            maxsize=int(max_queue_size)
        )

        self._timer_tasks: Dict[str, asyncio.Task] = {}
        self._run_at: Dict[str, float] = {}
        self._payloads: Dict[str, Dict[str, Any]] = {}
        self._priorities: Dict[str, int] = {}

        self._worker_task: Optional[asyncio.Task] = None
        self._running = False
        self._shutdown = False

        self._seq = 0
        self._last_job_done_time = 0.0
        self._lock = asyncio.Lock()
        self._active_count = 0

        self._metrics = {
            "jobs_processed": 0,
            "jobs_failed": 0,
            "jobs_retried": 0,
            "jobs_timed_out": 0,
            "total_processing_time": 0.0,
            "max_processing_time": 0.0,
            "last_error": None,
            "last_error_time": 0.0,
        }

        self.set_interval(process_interval)

    # ───────────────────────── Context manager ─────────────────────────

    async def __aenter__(self):
        """Start the planner when entering an async context."""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc, tb):
        """Gracefully stop the planner when leaving an async context."""
        await self.close()
        return False

    @asynccontextmanager
    async def session(self):
        """
        Convenience async context manager.

        Equivalent to:
            await start()
            try: ...
            finally: await close()
        """
        await self.start()
        try:
            yield self
        finally:
            await self.close()

    # ───────────────────────── Properties ─────────────────────────

    @property
    def running(self) -> bool:
        """True while the planner is running and not shutting down."""
        return self._running and not self._shutdown

    @property
    def stopped(self) -> bool:
        """True once close() has been initiated/completed."""
        return self._shutdown

    @property
    def pending_count(self) -> int:
        """
        Number of jobs still pending.

        Includes:
            - scheduled timers not yet enqueued
            - ready jobs waiting in the queue
        Does not include:
            - a currently executing job (see active_count)
        """
        return len(self._timer_tasks) + self._job_queue.qsize()

    @property
    def active_count(self) -> int:
        """Number of jobs currently executing."""
        return self._active_count

    @property
    def is_healthy(self) -> bool:
        """Basic health indicator (worker exists and not done)."""
        return self.running and self._worker_task is not None and not self._worker_task.done()

    # ───────────────────────── Public API ─────────────────────────

    def set_interval(self, interval: float) -> float:
        """
        Set the enforced interval between non-urgent job starts.

        The value is validated and clamped to [min_interval, max_interval],
        except 0 which means "no interval delay".
        """
        v = float(interval)
        if not math.isfinite(v):
            raise ValueError("process_interval must be finite")
        if v < 0:
            v = 0.0
        if v > 0:
            v = max(self.min_interval, min(v, self.max_interval))
        self.process_interval = v
        return v

    def has_job(self, key: str) -> bool:
        """Return True if a scheduled timer exists for this key."""
        return key in self._timer_tasks

    def get_job(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Return metadata for a scheduled job (timed, not yet enqueued).

        Returns None if the job is not scheduled.
        """
        if key not in self._timer_tasks:
            return None
        now = time.monotonic()
        return {
            "key": key,
            "run_at": self._run_at[key],
            "eta": max(0.0, self._run_at[key] - now),
            "priority": self._priorities.get(key, 10),
            "payload": self._payloads.get(key),
        }

    def list_jobs(self) -> List[Dict[str, Any]]:
        """
        List all scheduled jobs (timers only), sorted by ETA then priority.
        """
        now = time.monotonic()
        jobs = [
            {
                "key": k,
                "run_at": self._run_at[k],
                "eta": max(0.0, self._run_at[k] - now),
                "priority": self._priorities.get(k, 10),
                "payload": self._payloads.get(k),
            }
            for k in self._timer_tasks
        ]
        return sorted(jobs, key=lambda j: (j["run_at"], j["priority"]))

    def get_stats(self) -> Dict[str, Any]:
        """Return operational stats useful for logging/monitoring."""
        now = time.monotonic()
        return {
            "running": self.running,
            "healthy": self.is_healthy,
            "pending": self.pending_count,
            "active": self.active_count,
            "timers": len(self._timer_tasks),
            "queue": self._job_queue.qsize(),
            "interval": self.process_interval,
            "jitter": self.jitter_enabled,
            "last_job_done_time": self._last_job_done_time,
            "time_since_last_done": (now - self._last_job_done_time) if self._last_job_done_time else 0.0,
            "metrics": self._metrics.copy(),
        }

    def get_metrics(self) -> Dict[str, Any]:
        """Return a copy of the internal metrics dictionary."""
        return self._metrics.copy()

    async def wait_for_all(self, timeout: Optional[float] = None):
        """
        Wait until there are no pending jobs and no active job executing.

        Raises:
            asyncio.TimeoutError: if timeout is exceeded.
        """
        start = time.monotonic()
        while self.pending_count > 0 or self.active_count > 0:
            elapsed = time.monotonic() - start
            if timeout is not None and elapsed > timeout:
                raise asyncio.TimeoutError(
                    f"Timeout waiting for jobs (pending={self.pending_count}, active={self.active_count})"
                )

            dt = 0.25 if timeout is None else max(0.0, min(0.25, timeout - elapsed))
            await asyncio.sleep(dt)

    # ───────────────────────── Lifecycle ─────────────────────────

    async def start(self):
        """
        Start the planner worker loop.

        Note:
            A planner instance is not restartable after close().
        """
        if self._running:
            logger.warning("Planner already running")
            return
        if self._shutdown:
            raise RuntimeError("Cannot restart a stopped planner. Create a new instance.")

        self._running = True
        self._shutdown = False
        self._last_job_done_time = time.monotonic()

        self._worker_task = asyncio.create_task(self._worker_loop(), name="planner-worker")
        logger.info("Planner started")
        await asyncio.sleep(0)

    async def close(self):
        """
        Gracefully stop the planner.

        Behavior:
            - cancels all scheduled timers and awaits them
            - drains the ready queue
            - stops the worker
        """
        if self._shutdown:
            return

        logger.info("Planner closing.")
        self._shutdown = True
        self._running = False

        # Cancel timers and await them (avoid pending task warnings)
        timer_tasks = list(self._timer_tasks.values())
        self._timer_tasks.clear()

        self._run_at.clear()
        self._payloads.clear()
        self._priorities.clear()

        for t in timer_tasks:
            t.cancel()
        if timer_tasks:
            await asyncio.gather(*timer_tasks, return_exceptions=True)

        # Drain queue
        while not self._job_queue.empty():
            try:
                self._job_queue.get_nowait()
                self._job_queue.task_done()
            except asyncio.QueueEmpty:
                break

        # Stop worker by sentinel (non-blocking if queue is full)
        if self._worker_task and not self._worker_task.done():
            self._seq += 1
            try:
                self._job_queue.put_nowait(
                    _QueuedJob(10**9, time.monotonic(), self._seq, "__STOP__", {})
                )
            except asyncio.QueueFull:
                logger.warning("Queue full during close; cancelling worker directly")
                self._worker_task.cancel()

            try:
                await asyncio.wait_for(self._worker_task, timeout=5.0)
            except asyncio.TimeoutError:
                logger.warning("Worker did not stop gracefully; cancelling")
                self._worker_task.cancel()
                try:
                    await asyncio.wait_for(self._worker_task, timeout=1.0)
                except (asyncio.TimeoutError, asyncio.CancelledError):
                    pass
            except asyncio.CancelledError:
                pass

        self._worker_task = None
        logger.info("Planner closed")

    # ───────────────────────── Reset ─────────────────────────

    async def reset(self):
        """
        Cancel all scheduled and queued jobs.

        Note:
            Does NOT interrupt the currently executing job (if any).
        """
        async with self._lock:
            logger.info("Resetting planner.")

            timer_tasks = list(self._timer_tasks.values())
            self._timer_tasks.clear()
            self._run_at.clear()
            self._payloads.clear()
            self._priorities.clear()

            for t in timer_tasks:
                t.cancel()
            if timer_tasks:
                await asyncio.gather(*timer_tasks, return_exceptions=True)

            while not self._job_queue.empty():
                try:
                    self._job_queue.get_nowait()
                    self._job_queue.task_done()
                except asyncio.QueueEmpty:
                    break

            logger.info("Planner reset (jobs cleared)")

    async def full_reset(self):
        """
        Reset scheduled/queued jobs and also reset internal counters/metrics.

        Note:
            This still does not cancel a currently running job. Use close()
            if you need a hard stop, or implement a job-level cancellation.
        """
        await self.reset()
        async with self._lock:
            self._seq = 0
            self._last_job_done_time = time.monotonic()
            self._metrics = {
                "jobs_processed": 0,
                "jobs_failed": 0,
                "jobs_retried": 0,
                "jobs_timed_out": 0,
                "total_processing_time": 0.0,
                "max_processing_time": 0.0,
                "last_error": None,
                "last_error_time": 0.0,
            }
            logger.info("Planner full reset (state reinitialized)")

    # ───────────────────────── Scheduling ─────────────────────────

    async def schedule_after_last(
        self,
        key: str,
        payload: Dict[str, Any],
        *,
        interval: float,
        priority: int = 10,
        replace_existing: bool = True,
        retry_on_failure: bool = True,
    ) -> bool:
        """
        Schedule a job to run `interval` seconds after the last finished job.

        "Finished" means the previous job ended (success, failure, or timeout).

        Args:
            key: Unique identifier for cancellation/replacement.
            payload: Arbitrary data passed to on_expire.
            interval: Delay in seconds relative to the last finished job.
            priority: Lower values run first (negative values are clamped to 0).
            replace_existing: If True, replaces an existing scheduled job with same key.
            retry_on_failure: If True, retry on exception/timeout up to max_retries.

        Returns:
            True if scheduled; False if rejected (shutdown or replace_existing=False).
        """
        if self._shutdown:
            logger.warning(f"Cannot schedule job {key}: planner is shutting down")
            return False

        if key in self._timer_tasks:
            if not replace_existing:
                logger.debug(f"Job {key} exists and replace_existing=False")
                return False
            await self.cancel_job(key)

        iv = float(interval)
        if not math.isfinite(iv):
            raise ValueError("interval must be a finite number")
        if iv < 0:
            iv = 0.0

        pr = max(0, int(priority))

        enhanced_payload = {
            **payload,
            "__retry_on_failure": bool(retry_on_failure),
            "__retry_count": int(payload.get("__retry_count", 0)),
            "__original_key": payload.get("__original_key", key),
            "__priority": pr,
        }

        base = max(time.monotonic(), self._last_job_done_time)
        run_at = base + iv

        self._run_at[key] = run_at
        self._payloads[key] = enhanced_payload
        self._priorities[key] = pr

        self._timer_tasks[key] = asyncio.create_task(
            self._timer_task(key),
            name=f"planner-timer-{key}",
        )
        return True

    async def cancel_job(self, key: str) -> bool:
        """
        Cancel a scheduled job by key.

        Returns:
            True if a scheduled timer existed and was cancelled; False otherwise.
        """
        t = self._timer_tasks.pop(key, None)
        self._run_at.pop(key, None)
        self._payloads.pop(key, None)
        self._priorities.pop(key, None)
        if t:
            t.cancel()
            logger.debug(f"Cancelled job {key}")
            return True
        return False

    async def cancel_all(self):
        """Cancel all scheduled jobs."""
        for key in list(self._timer_tasks.keys()):
            await self.cancel_job(key)

    # ───────────────────────── Internals ─────────────────────────

    async def _timer_task(self, key: str):
        """
        Timer task for a scheduled job.

        Sleeps until run_at, then enqueues the job into the priority queue.
        """
        try:
            if key not in self._run_at:
                return

            delay = self._run_at[key] - time.monotonic()
            if delay > 0:
                await asyncio.sleep(delay)

            if key not in self._run_at or self._shutdown:
                return

            self._timer_tasks.pop(key, None)

            payload = self._payloads.get(key, {})
            priority = self._priorities.get(key, 10)
            run_at = self._run_at.get(key, time.monotonic())

            # Remove scheduling metadata once enqueued
            self._run_at.pop(key, None)
            self._payloads.pop(key, None)
            self._priorities.pop(key, None)

            self._seq += 1
            await self._job_queue.put(
                _QueuedJob(priority=priority, run_at_monotonic=run_at, seq=self._seq, key=key, payload=payload)
            )

        except asyncio.CancelledError:
            # Best-effort cleanup
            self._timer_tasks.pop(key, None)
            self._run_at.pop(key, None)
            self._payloads.pop(key, None)
            self._priorities.pop(key, None)
        except Exception as e:
            logger.error(f"Timer task error for {key}: {e}")
            self._timer_tasks.pop(key, None)
            self._run_at.pop(key, None)
            self._payloads.pop(key, None)
            self._priorities.pop(key, None)

    async def _execute_job(self, key: str, payload: Dict[str, Any]) -> bool:
        """
        Execute a single job with timeout and retry logic.

        Returns:
            True if the job completed successfully, False otherwise.
        """
        meta = dict(payload)

        retry_on_failure = bool(meta.pop("__retry_on_failure", True))
        retry_count = int(meta.pop("__retry_count", 0))
        original_key = meta.pop("__original_key", key)
        saved_priority = int(meta.pop("__priority", 10))

        start_time = time.monotonic()
        self._active_count += 1

        try:
            if self.job_timeout is not None:
                await asyncio.wait_for(self.on_expire(original_key, meta), timeout=self.job_timeout)
            else:
                await self.on_expire(original_key, meta)

            processing_time = time.monotonic() - start_time
            self._metrics["jobs_processed"] += 1
            self._metrics["total_processing_time"] += processing_time
            self._metrics["max_processing_time"] = max(self._metrics["max_processing_time"], processing_time)
            return True

        except asyncio.TimeoutError:
            self._metrics["jobs_timed_out"] += 1
            self._metrics["last_error"] = f"Job {key} timed out"
            self._metrics["last_error_time"] = time.monotonic()
            logger.error(f"Job {key} timed out after {self.job_timeout}s")

            if retry_on_failure and retry_count < self.max_retries:
                logger.info(f"Retrying job {key} ({retry_count + 1}/{self.max_retries})")
                await asyncio.sleep(self.retry_delay)
                self._metrics["jobs_retried"] += 1
                await self.schedule_after_last(
                    key=key,
                    payload={
                        **meta,
                        "__retry_on_failure": retry_on_failure,
                        "__retry_count": retry_count + 1,
                        "__original_key": original_key,
                        "__priority": saved_priority,
                    },
                    interval=0.0,
                    priority=saved_priority,
                    replace_existing=True,
                    retry_on_failure=retry_on_failure,
                )
            return False

        except Exception as e:
            self._metrics["jobs_failed"] += 1
            self._metrics["last_error"] = f"Job {key} failed: {str(e)[:100]}"
            self._metrics["last_error_time"] = time.monotonic()
            logger.error(f"Job {key} failed: {e}")

            if retry_on_failure and retry_count < self.max_retries:
                logger.info(f"Retrying job {key} ({retry_count + 1}/{self.max_retries})")
                await asyncio.sleep(self.retry_delay)
                self._metrics["jobs_retried"] += 1
                await self.schedule_after_last(
                    key=key,
                    payload={
                        **meta,
                        "__retry_on_failure": retry_on_failure,
                        "__retry_count": retry_count + 1,
                        "__original_key": original_key,
                        "__priority": saved_priority,
                    },
                    interval=0.0,
                    priority=saved_priority,
                    replace_existing=True,
                    retry_on_failure=retry_on_failure,
                )
            return False

        finally:
            self._last_job_done_time = time.monotonic()
            self._active_count = max(0, self._active_count - 1)

    async def _worker_loop(self):
        """
        Worker loop that drains the priority queue and executes jobs.

        Responsibilities:
            - picks the next READY job by priority
            - enforces process_interval for non-urgent jobs
            - executes the job with timeout/retry handling
        """
        logger.info("Worker started")

        try:
            while self._running and not self._shutdown:
                try:
                    job = await asyncio.wait_for(self._job_queue.get(), timeout=1.0)

                    if job.key == "__STOP__":
                        self._job_queue.task_done()
                        break

                    async with self._lock:
                        elapsed = time.monotonic() - self._last_job_done_time
                        urgent = (self.urgent_bypass_priority >= 0 and job.priority == self.urgent_bypass_priority)

                        if (not urgent) and self.process_interval > 0 and elapsed < self.process_interval:
                            wait = self.process_interval - elapsed
                            if self.jitter_enabled:
                                wait = max(self.min_interval, wait + random.uniform(-0.5, 0.5))
                            await asyncio.sleep(wait)

                    await self._execute_job(job.key, job.payload)
                    self._job_queue.task_done()

                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    logger.info("Worker cancelled")
                    break
                except Exception as e:
                    logger.error(f"Unexpected error in worker loop: {e}")
                    await asyncio.sleep(1.0)

        except Exception as e:
            logger.error(f"Fatal error in worker loop: {e}")

        logger.info("Worker stopped")
