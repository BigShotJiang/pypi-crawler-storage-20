"""
Comprehensive function lister for UniversalMath
Dynamically discovers and documents ALL available functions
FIXED: Uses unified counting to match generate_docs.py
"""

import sys
import textwrap
import inspect

# Add parent directory to path
sys.path.insert(0, '.')

import universalmath as mk

def get_function_signature(func):
    """Get function signature as string."""
    try:
        sig = inspect.signature(func)
        return str(sig)
    except:
        return "()"

def get_function_doc(func):
    """Get first line of docstring."""
    doc = inspect.getdoc(func)
    if doc:
        return doc.split('\n')[0].strip()
    return "No description available"

def generate_example(name, func):
    """Try to generate a simple example for the function."""
    try:
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())
        
        # Simple heuristics for common patterns
        if name in ['sqrt', 'factorial', 'sin', 'cos', 'exp', 'log']:
            return f"mk.{name}(4)"
        elif name == 'mean':
            return f"mk.{name}([1, 2, 3])"
        elif name in ['gcd', 'lcm']:
            return f"mk.{name}(12, 18)"
        elif name == 'is_prime':
            return f"mk.{name}(17)"
        elif name == 'fibonacci':
            return f"mk.{name}(10)"
        elif name.startswith('np_array'):
            return f"mk.{name}([1, 2, 3])"
        elif len(params) == 1:
            return f"mk.{name}(value)"
        elif len(params) == 2:
            return f"mk.{name}(a, b)"
        else:
            return f"mk.{name}(...)"
    except:
        return f"mk.{name}(...)"

def categorize_function(name):
    """Categorize a function by its name - MUST MATCH generate_docs.py logic."""
    # Check prefixes first (most specific to least specific)
    if name.startswith('np_linalg_'):
        return 'numpy.linalg'
    elif name.startswith('np_random_'):
        return 'numpy.random'
    elif name.startswith('np_fft_'):
        return 'numpy.fft'
    elif name.startswith('np_'):
        return 'numpy'
    elif name.startswith('sp_stats_'):
        return 'scipy.stats'
    elif name.startswith('sp_linalg_'):
        return 'scipy.linalg'
    elif name.startswith('sp_optimize_'):
        return 'scipy.optimize'
    elif name.startswith('sp_integrate_'):
        return 'scipy.integrate'
    elif name.startswith('sp_interpolate_'):
        return 'scipy.interpolate'
    elif name.startswith('sp_signal_'):
        return 'scipy.signal'
    elif name.startswith('sp_fft_'):
        return 'scipy.fft'
    elif name.startswith('sp_special_'):
        return 'scipy.special'
    elif name.startswith('sp_sparse_'):
        return 'scipy.sparse'
    elif name.startswith('sym_'):
        return 'sympy'
    elif name.startswith('pd_'):
        return 'pandas'
    elif name.startswith('pypynum_arrays_'):
        return 'pypynum.arrays'
    elif name.startswith('pypynum_equations_'):
        return 'pypynum.equations'
    elif name.startswith('pypynum_graphs_'):
        return 'pypynum.graphs'
    elif name.startswith('pypynum_logic_'):
        return 'pypynum.logic'
    elif name.startswith('pypynum_matrices_'):
        return 'pypynum.matrices'
    elif name.startswith('pypynum_maths_'):
        return 'pypynum.maths'
    elif name.startswith('pypynum_multiprec_'):
        return 'pypynum.multiprec'
    elif name.startswith('pypynum_quats_'):
        return 'pypynum.quats'
    elif name.startswith('pypynum_random_'):
        return 'pypynum.random'
    elif name.startswith('pypynum_regs_'):
        return 'pypynum.regs'
    elif name.startswith('pypynum_stattest_'):
        return 'pypynum.stattest'
    elif name.startswith('pypynum_symbols_'):
        return 'pypynum.symbols'
    elif name.startswith('pypynum_tensors_'):
        return 'pypynum.tensors'
    elif name.startswith('pypynum_tools_'):
        return 'pypynum.tools'
    elif name.startswith('pypynum_vectors_'):
        return 'pypynum.vectors'
    elif name.startswith('pypynum_'):
        return 'pypynum'
    elif name in ['Decimal', 'getcontext', 'Context', 'ROUND_HALF_UP', 'ROUND_DOWN', 
                'ROUND_UP', 'ROUND_CEILING', 'ROUND_FLOOR']:
        return 'decimal'
    elif name in ['Fraction']:
        return 'fractions'
    elif name in ['random', 'randint', 'choice', 'shuffle', 'seed', 'uniform', 'gauss', 'sample',
                  'Random', 'SystemRandom', 'betavariate', 'binomialvariate', 'expovariate',
                  'gammavariate', 'lognormvariate', 'normalvariate', 'paretovariate',
                  'triangular', 'vonmisesvariate', 'weibullvariate', 'choices', 'randbytes',
                  'getrandbits', 'getstate', 'setstate', 'randrange',
                  'BPF', 'LOG4', 'NV_MAGICCONST', 'RECIP_BPF', 'SG_MAGICCONST', 'TWOPI']:
        return 'random'
    elif name in ['is_prime', 'primes_up_to', 'fibonacci', 'fibonacci_nth', 
                  'prime_factors', 'totient', 'modular_inverse', 
                  'chinese_remainder_theorem', 'permutations_with_repetition',
                  'combinations_with_repetition', 'stirling_second_kind',
                  'lerp', 'inverse_lerp', 'remap', 'clamp', 'normalize', 'smoothstep',
                  'moving_average', 'weighted_average', 'z_score', 'standard_error',
                  'percentage_change', 'sigfigs', 'compound_interest', 'present_value',
                  'future_value', 'annuity_payment', 'annuity_present_value',
                  'newton_raphson', 'bisection', 'numerical_derivative',
                  'numerical_integral_simpson', 'numerical_integral_trapezoidal',
                  'celsius_to_fahrenheit', 'fahrenheit_to_celsius', 'celsius_to_kelvin',
                  'kelvin_to_celsius', 'fahrenheit_to_kelvin', 'kelvin_to_fahrenheit',
                  'degrees_to_radians_precise', 'radians_to_dms',
                  'distance_2d', 'distance_3d', 'polygon_area', 'circle_area',
                  'circle_circumference', 'triangle_area_heron', 'triangle_area_base_height',
                  'sphere_volume', 'sphere_surface_area', 'cylinder_volume',
                  'cylinder_surface_area', 'cone_volume', 'cone_surface_area',
                  'rectangular_prism_volume', 'rectangular_prism_surface_area',
                  'manhattan_distance', 'dot_product', 'cross_product_2d', 'cross_product_3d',
                  'vector_magnitude', 'angle_between_vectors', 'vector_normalize',
                  'vector_projection', 'pythagorean', 'pythagorean_triple_check',
                  'quadratic_formula', 'binomial_coefficient', 'harmonic_number',
                  'matrix', 'solve_linear_system', 'eigenvalues', 'eigenvectors',
                  'parse_math_expression']:
        return 'universalmath.utils'
    elif name in ['info', '_cli_help', '_cli_list_functions', '_cli_main']:
        return 'universalmath.cli'
    elif name.startswith('c') and len(name) > 1:
        # Check if it's from cmath
        cmath_module = mk._lazy_import_module('cmath')
        actual_name = name[1:]
        if cmath_module and hasattr(cmath_module, actual_name):
            return 'cmath'
        else:
            # Check math
            math_module = mk._lazy_import_module('math')
            if math_module and hasattr(math_module, name):
                return 'math'
            return 'other'
    else:
        # Check statistics
        stats_module = mk._lazy_import_module('statistics')
        if stats_module and hasattr(stats_module, name):
            return 'statistics'
        else:
            # Default to math
            math_module = mk._lazy_import_module('math')
            if math_module and hasattr(math_module, name):
                return 'math'
            return 'other'

def list_all_functions():
    """List all functions with descriptions."""
    print("=" * 100)
    print("  UniversalMath Function Reference - Complete List")
    print("=" * 100)
    print()
    
    # Categorize functions using unified logic
    categories = {}
    seen_names = set()  # Track duplicates
    
    # Gather all functions
    for name in sorted(mk.__all__):
        if name.startswith('_'):
            continue
        
        # Skip duplicates
        if name in seen_names:
            continue
        seen_names.add(name)
        
        func = getattr(mk, name, None)
        if func is None:
            continue
        
        # Skip non-callable unless it's a class or constant
        if not callable(func) and not isinstance(func, type) and not isinstance(func, (int, float, complex)):
            continue
        
        # Categorize using unified logic
        category = categorize_function(name)
        
        if category not in categories:
            categories[category] = []
        
        # Get info
        sig = get_function_signature(func) if callable(func) else ""
        doc = get_function_doc(func) if callable(func) else str(type(func).__name__)
        example = generate_example(name, func) if callable(func) else ""
        
        categories[category].append({
            'name': name,
            'signature': sig,
            'doc': doc,
            'example': example,
            'callable': callable(func)
        })
    
    # Print by category with pagination
    counter = 1
    lines_printed = 0
    page_size = 50
    
    for category_name in sorted(categories.keys()):
        if not categories[category_name]:
            continue
        
        print(f"\n{'─' * 100}")
        print(f"  {category_name} ({len(categories[category_name])} items)")
        print(f"{'─' * 100}\n")
        lines_printed += 4
        
        for item in sorted(categories[category_name], key=lambda x: x['name']):
            # Print function
            print(f"{counter:4d}. {item['name']}{item['signature']}")
            lines_printed += 1
            
            # Wrap and print description
            wrapped = textwrap.fill(item['doc'], width=90, 
                                   initial_indent='       ',
                                   subsequent_indent='       ')
            print(wrapped)
            lines_printed += len(wrapped.split('\n'))
            
            # Print example if available
            if item['example'] and item['callable']:
                print(f"       Example: {item['example']}")
                lines_printed += 1
            
            print()
            lines_printed += 1
            counter += 1
            
            # Pagination
            if lines_printed >= page_size:
                try:
                    input(f"\n--- Press Enter for next page (Ctrl+C to exit) ---\n")
                    lines_printed = 0
                except KeyboardInterrupt:
                    print("\n\nExiting...")
                    return
    
    print("=" * 100)
    print(f"Total: {counter - 1} functions")
    print("=" * 100)
    
    # Print summary by category
    print("\nSummary by Module/Category:")
    print("-" * 100)
    for category in sorted(categories.keys()):
        print(f"  {category:<30} {len(categories[category]):>5} functions")
    print("-" * 100)
    print(f"  {'TOTAL':<30} {counter - 1:>5} functions")
    print("=" * 100)
    
    print("\nFor detailed help:")
    print("  import universalmath as mk")
    print("  help(mk.function_name)")

if __name__ == '__main__':
    try:
        list_all_functions()
    except KeyboardInterrupt:
        print("\n\nExiting...")