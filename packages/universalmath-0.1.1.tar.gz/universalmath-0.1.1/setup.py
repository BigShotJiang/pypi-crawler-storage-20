"""
Setup script for UniversalMath - The Ultimate Unified Mathematics Module
"""

from setuptools import setup, find_packages
import os

# Read README for long description
readme_path = os.path.join(os.path.dirname(__file__), "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = "UniversalMath - The Ultimate Unified Mathematics Module"

setup(
    name="universalmath",
    version="0.1.1",
    author="Tulika Thampi",
    description="The ultimate unified mathematics module - 3000+ functions from math, numpy, scipy, sympy and more in one import with lazy loading",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tech-dragoness/universalmath",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Education",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
    ],
    python_requires=">=3.7",
    install_requires=[
        # No required dependencies - all are optional
        # Standard library modules only
    ],
    keywords=[
        "math", "mathematics", "statistics", "numpy", "scipy", "sympy",
        "scientific computing", "numerical methods", "linear algebra",
        "calculus", "symbolic math", "unified", "all-in-one"
    ],
    project_urls={
        "Bug Reports": "https://github.com/tech-dragoness/universalmath/issues",
        "Source": "https://github.com/tech-dragoness/universalmath",
        "Documentation": "https://universalmath.readthedocs.io/",
    },
    entry_points={
        "console_scripts": [
            "universalmath-info=universalmath:info",
        ],
    },
)