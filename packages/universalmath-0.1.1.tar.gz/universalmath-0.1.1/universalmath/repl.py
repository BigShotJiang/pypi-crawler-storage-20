"""
UniversalMath Interactive REPL
A unique interactive mathematics environment
"""

import sys
import universalmath as um

class MathREPL:
    """Interactive Math Read-Eval-Print Loop."""
    
    def __init__(self):
        self.variables = {}
        self.history = []
    
    def evaluate(self, expression):
        """Evaluate a mathematical expression."""
        try:
            # Allow access to universalmath functions
            local_vars = {**um.__dict__, **self.variables}
            result = eval(expression, {"__builtins__": {}}, local_vars)
            return result
        except Exception as e:
            return f"Error: {e}"
    
    def run(self):
        """Run the interactive REPL."""
        print("="*70)
        print("  UniversalMath Interactive REPL")
        print("="*70)
        print("\nType mathematical expressions using universalmath functions.")
        print("You can use either Python syntax or natural language!")
        print("\nPython syntax examples:")
        print("  sqrt(16)")
        print("  sin(pi/2)")
        print("  x = 5")
        print("  fibonacci(10)")
        print("\nNatural language examples:")
        print("  what is the square root of 16")
        print("  is 17 prime")
        print("  calculate sin of pi over 2")
        print("\nType 'help' for more info, 'exit' to quit.\n")
        
        while True:
            try:
                # Get input
                expr = input(">>> ")
                
                # Handle special commands
                if expr.lower() in ['exit', 'quit', 'q']:
                    print("Goodbye!")
                    break
                
                if expr.lower() == 'help':
                    self.show_help()
                    continue
                
                if expr.lower() == 'vars':
                    self.show_variables()
                    continue
                
                if expr.lower() == 'history':
                    self.show_history()
                    continue
                
                if not expr.strip():
                    continue
                
                # Check for variable assignment
                if '=' in expr and not any(op in expr for op in ['==', '!=', '<=', '>=']):
                    var_name, var_expr = expr.split('=', 1)
                    var_name = var_name.strip()
                    result = self.evaluate(var_expr.strip())
                    self.variables[var_name] = result
                    print(f"{var_name} = {result}")
                else:
                    # Try regular evaluation first
                    result = self.evaluate(expr)
                    
                    # If evaluation returns an error and the expression looks like natural language,
                    # try parse_math_expression
                    if isinstance(result, str) and result.startswith("Error:"):
                        # Check if it might be a natural language query
                        natural_keywords = ['what', 'is', 'calculate', 'find', 'prime', 'sqrt', 'square root', 
                                          'sin', 'cos', 'tan', 'factorial', 'fibonacci']
                        if any(keyword in expr.lower() for keyword in natural_keywords):
                            result = self.evaluate("parse_math_expression('" + expr + "')")
                    
                    print(result)
                
                # Save to history
                self.history.append((expr, result))
                
            except KeyboardInterrupt:
                print("\n\nInterrupted. Type 'exit' to quit.")
            except EOFError:
                print("\nGoodbye!")
                break
    
    def show_help(self):
        """Show help information."""
        print("\nUniversalMath REPL Commands:")
        print("  help     - Show this help")
        print("  vars     - Show defined variables")
        print("  history  - Show command history")
        print("  exit     - Exit REPL")
        print("\nAll universalmath functions are available:")
        print("  sqrt, sin, cos, tan, log, exp, ...")
        print("  fibonacci, is_prime, ...")
        print("  np_array (if NumPy installed)")
        print("\nNatural Language Support:")
        print("  You can also type questions in plain English!")
        print("  Examples:")
        print("    'what is the square root of 144'")
        print("    'is 23 prime'")
        print("    'fibonacci 8'")
        print("    'factorial of 5'")
        print()
    
    def show_variables(self):
        """Show defined variables."""
        if not self.variables:
            print("No variables defined.")
        else:
            print("\nDefined variables:")
            for name, value in self.variables.items():
                print(f"  {name} = {value}")
        print()
    
    def show_history(self):
        """Show command history."""
        if not self.history:
            print("No history.")
        else:
            print("\nCommand history:")
            for i, (expr, result) in enumerate(self.history, 1):
                print(f"  {i}. {expr} → {result}")
        print()


def start_repl():
    """Start the UniversalMath REPL."""
    repl = MathREPL()
    repl.run()


if __name__ == '__main__':
    start_repl()