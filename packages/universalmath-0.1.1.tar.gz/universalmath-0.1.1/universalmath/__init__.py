"""
UniversalMath - The Ultimate Unified Mathematics Module
Version 3.0 - Complete implementation with lazy loading and 100% coverage

Features:
- Lazy loading: Modules imported only when needed
- 100% coverage of ALL functions from each module
- Legacy support: Works even if some modules are unavailable
- Dynamic function detection and routing
- 3600+ mathematical functions from one import
"""

import sys
from typing import Any, Callable

__version__ = "0.1.1"
__all__ = []

# ============================================================================
# PYTHON BUILT-INS (commonly used math functions)
# ============================================================================
# Add commonly used built-in functions
__all__.extend(['abs', 'round', 'min', 'max', 'sum', 'pow'])
# Note: These are already available globally, but we add them to __all__ for completeness

# ============================================================================
# MODULE AVAILABILITY TRACKING
# ============================================================================
_module_cache = {}
_function_registry = {}  # Maps function names to their source modules

# ============================================================================
# LAZY IMPORT SYSTEM
# ============================================================================

def _lazy_import_module(module_name: str):
    """Lazily import a module and cache it."""
    if module_name in _module_cache:
        return _module_cache[module_name]
    
    try:
        if module_name == 'math':
            import math
            _module_cache['math'] = math
            return math
        elif module_name == 'cmath':
            import cmath
            _module_cache['cmath'] = cmath
            return cmath
        elif module_name == 'statistics':
            import statistics
            _module_cache['statistics'] = statistics
            return statistics
        elif module_name == 'decimal':
            import decimal
            _module_cache['decimal'] = decimal
            return decimal
        elif module_name == 'fractions':
            import fractions
            _module_cache['fractions'] = fractions
            return fractions
        elif module_name == 'random':
            import random
            _module_cache['random'] = random
            return random
        elif module_name == 'numpy':
            import numpy
            _module_cache['numpy'] = numpy
            return numpy
        elif module_name == 'numpy.linalg':
            import numpy.linalg
            _module_cache['numpy.linalg'] = numpy.linalg
            return numpy.linalg
        elif module_name == 'numpy.random':
            import numpy.random
            _module_cache['numpy.random'] = numpy.random
            return numpy.random
        elif module_name == 'numpy.fft':
            import numpy.fft
            _module_cache['numpy.fft'] = numpy.fft
            return numpy.fft
        elif module_name == 'scipy.stats':
            from scipy import stats
            _module_cache['scipy.stats'] = stats
            return stats
        elif module_name == 'scipy.linalg':
            from scipy import linalg
            _module_cache['scipy.linalg'] = linalg
            return linalg
        elif module_name == 'scipy.optimize':
            from scipy import optimize
            _module_cache['scipy.optimize'] = optimize
            return optimize
        elif module_name == 'scipy.integrate':
            from scipy import integrate
            _module_cache['scipy.integrate'] = integrate
            return integrate
        elif module_name == 'scipy.interpolate':
            from scipy import interpolate
            _module_cache['scipy.interpolate'] = interpolate
            return interpolate
        elif module_name == 'scipy.signal':
            from scipy import signal
            _module_cache['scipy.signal'] = signal
            return signal
        elif module_name == 'scipy.fft':
            from scipy import fft
            _module_cache['scipy.fft'] = fft
            return fft
        elif module_name == 'scipy.special':
            from scipy import special
            _module_cache['scipy.special'] = special
            return special
        elif module_name == 'scipy.sparse':
            from scipy import sparse
            _module_cache['scipy.sparse'] = sparse
            return sparse
        elif module_name == 'sympy':
            import sympy
            _module_cache['sympy'] = sympy
            return sympy
        elif module_name == 'pandas':
            import pandas
            _module_cache['pandas'] = pandas
            return pandas
    except ImportError:
        _module_cache[module_name] = None
        return None

# ============================================================================
# DYNAMIC FUNCTION ROUTER
# ============================================================================

def _create_lazy_function(module_name: str, func_name: str, prefix: str = ''):
    """Create a lazy-loading wrapper for a function."""
    def lazy_wrapper(*args, **kwargs):
        module = _lazy_import_module(module_name)
        if module is None:
            raise ImportError(f"Module '{module_name}' is not available. Install it to use this function.")
        
        # Get the actual function
        actual_func = getattr(module, func_name)
        
        # Special handling for isclose with complex numbers
        if func_name == 'isclose' and module_name == 'math':
            # Check if any argument is complex
            if any(isinstance(arg, complex) for arg in args):
                # Use cmath.isclose instead
                cmath_module = _lazy_import_module('cmath')
                if cmath_module is not None:
                    actual_func = getattr(cmath_module, func_name)
        
        return actual_func(*args, **kwargs)
    
    # Copy name and documentation from original function
    lazy_wrapper.__name__ = f"{prefix}{func_name}" if prefix else func_name
    
    # Try to get the original docstring
    try:
        module = _lazy_import_module(module_name)
        if module and hasattr(module, func_name):
            original_func = getattr(module, func_name)
            lazy_wrapper.__doc__ = getattr(original_func, '__doc__', None)
    except:
        lazy_wrapper.__doc__ = None
    
    return lazy_wrapper

def _register_module_functions(module_name: str, prefix: str = '', skip_private: bool = True):
    """Register all functions from a module for lazy loading."""
    try:
        module = _lazy_import_module(module_name)
        if module is None:
            return
        
        for attr_name in dir(module):
            if skip_private and attr_name.startswith('_'):
                continue
            
            attr = getattr(module, attr_name)
            
            # Include callables and type objects (classes)
            if callable(attr) or isinstance(attr, type):
                func_name = f"{prefix}{attr_name}" if prefix else attr_name
                
                # Create lazy wrapper
                if callable(attr):
                    globals()[func_name] = _create_lazy_function(module_name, attr_name, prefix)
                else:
                    # For classes, create a lazy loader
                    def make_class_loader(mod_name, cls_name, pref):
                        def load_class():
                            mod = _lazy_import_module(mod_name)
                            if mod is None:
                                raise ImportError(f"Module '{mod_name}' not available")
                            return getattr(mod, cls_name)
                        return load_class
                    
                    globals()[func_name] = make_class_loader(module_name, attr_name, prefix)()
                
                __all__.append(func_name)
                _function_registry[func_name] = module_name
            
            # Also include numeric constants
            elif isinstance(attr, (int, float, complex)):
                func_name = f"{prefix}{attr_name}" if prefix else attr_name
                globals()[func_name] = attr
                __all__.append(func_name)
                _function_registry[func_name] = module_name
                
    except Exception as e:
        # Silently skip modules that can't be loaded
        pass

# ============================================================================
# REGISTER ALL MODULES
# ============================================================================

# Core modules (always attempt to load)
_register_module_functions('math')
_register_module_functions('cmath', prefix='c')
_register_module_functions('statistics')
_register_module_functions('random')

# Decimal and Fractions - special handling for classes and constants
try:
    from decimal import Decimal, getcontext, Context, ROUND_HALF_UP, ROUND_DOWN, ROUND_UP, ROUND_CEILING, ROUND_FLOOR
    globals()['Decimal'] = Decimal
    globals()['getcontext'] = getcontext
    globals()['Context'] = Context
    globals()['ROUND_HALF_UP'] = ROUND_HALF_UP
    globals()['ROUND_DOWN'] = ROUND_DOWN
    globals()['ROUND_UP'] = ROUND_UP
    globals()['ROUND_CEILING'] = ROUND_CEILING
    globals()['ROUND_FLOOR'] = ROUND_FLOOR
    __all__.extend(['Decimal', 'getcontext', 'Context', 'ROUND_HALF_UP', 'ROUND_DOWN', 
                    'ROUND_UP', 'ROUND_CEILING', 'ROUND_FLOOR'])
except ImportError:
    pass

try:
    from fractions import Fraction
    globals()['Fraction'] = Fraction
    __all__.append('Fraction')
except ImportError:
    pass

# Optional modules (lazy load)
_register_module_functions('numpy', prefix='np_')
_register_module_functions('numpy.linalg', prefix='np_linalg_')
_register_module_functions('numpy.random', prefix='np_random_')
_register_module_functions('numpy.fft', prefix='np_fft_')

_register_module_functions('scipy.stats', prefix='sp_stats_')
_register_module_functions('scipy.linalg', prefix='sp_linalg_')
_register_module_functions('scipy.optimize', prefix='sp_optimize_')
_register_module_functions('scipy.integrate', prefix='sp_integrate_')
_register_module_functions('scipy.interpolate', prefix='sp_interpolate_')
_register_module_functions('scipy.signal', prefix='sp_signal_')
_register_module_functions('scipy.fft', prefix='sp_fft_')
_register_module_functions('scipy.special', prefix='sp_special_')
_register_module_functions('scipy.sparse', prefix='sp_sparse_')

_register_module_functions('sympy', prefix='sym_')
_register_module_functions('pandas', prefix='pd_')

# ============================================================================
# PYPYNUM MODULE - Pure Python scientific computing
# ============================================================================
try:
    import pypynum
    PYPYNUM_AVAILABLE = True
except ImportError:
    PYPYNUM_AVAILABLE = False

if PYPYNUM_AVAILABLE:
    # Start with empty modules dict
    _pypynum_modules = {}
    
    # Try to import each submodule individually (don't fail if one is missing)
    submodule_names = ['arrays', 'equations', 'graphs', 'matrices', 'maths', 
                       'multiprec', 'quats', 'random', 'regs', 'stattest', 
                       'symbols', 'tensors', 'tools', 'vectors']
    
    for submod_name in submodule_names:
        try:
            submod = __import__(f'pypynum.{submod_name}', fromlist=[submod_name])
            _pypynum_modules[f'pypynum_{submod_name}_'] = submod
        except ImportError:
            # This submodule doesn't exist, skip it
            pass
    
    # Also add the main pypynum module
    _pypynum_modules['pypynum_'] = pypynum
    
    # NOW register all functions from successfully imported modules
    for prefix, module in _pypynum_modules.items():
        for attr_name in dir(module):
            if attr_name.startswith('_'):
                continue
            
            try:
                attr = getattr(module, attr_name)
                prefixed_name = f'{prefix}{attr_name}'
                
                # Register functions, classes, and constants
                if callable(attr) or isinstance(attr, type):
                    globals()[prefixed_name] = attr
                    __all__.append(prefixed_name)
                    _function_registry[prefixed_name] = 'pypynum'
                elif isinstance(attr, (int, float, complex)):
                    globals()[prefixed_name] = attr
                    __all__.append(prefixed_name)
                    _function_registry[prefixed_name] = 'pypynum'
            except Exception:
                # Skip problematic attributes
                continue

# ============================================================================
# UTILITY FUNCTIONS - Eagerly loaded
# ============================================================================

# Import sqrt for utilities (will be lazy loaded)
def _get_sqrt():
    """Get sqrt function lazily."""
    import math
    return math.sqrt

# NUMBER THEORY
def is_prime(n: int) -> bool:
    """Check if a number is prime."""
    if n < 2:
        return False
    if n == 2:
        return True
    if n % 2 == 0:
        return False
    sqrt_func = _get_sqrt()
    for i in range(3, int(sqrt_func(n)) + 1, 2):
        if n % i == 0:
            return False
    return True

def primes_up_to(n: int) -> list:
    """Generate all prime numbers up to n using Sieve of Eratosthenes."""
    if n < 2:
        return []
    sieve = [True] * (n + 1)
    sieve[0] = sieve[1] = False
    sqrt_func = _get_sqrt()
    for i in range(2, int(sqrt_func(n)) + 1):
        if sieve[i]:
            for j in range(i*i, n + 1, i):
                sieve[j] = False
    return [i for i in range(n + 1) if sieve[i]]

def fibonacci(n: int) -> list:
    """Generate the first n Fibonacci numbers."""
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    fib = [0, 1]
    for i in range(2, n):
        fib.append(fib[-1] + fib[-2])
    return fib

def fibonacci_nth(n: int) -> int:
    """Get the nth Fibonacci number (0-indexed)."""
    if n == 0:
        return 0
    elif n == 1:
        return 1
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def prime_factors(n: int) -> list:
    """Return the prime factorization of n."""
    factors = []
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 1
    if n > 1:
        factors.append(n)
    return factors

def totient(n: int) -> int:
    """Euler's totient function - count of integers up to n that are coprime to n."""
    result = n
    p = 2
    while p * p <= n:
        if n % p == 0:
            while n % p == 0:
                n //= p
            result -= result // p
        p += 1
    if n > 1:
        result -= result // n
    return result

def modular_inverse(a: int, m: int) -> int:
    """Find modular multiplicative inverse of a modulo m using Extended Euclidean Algorithm."""
    def extended_gcd(a, b):
        if a == 0:
            return b, 0, 1
        gcd, x1, y1 = extended_gcd(b % a, a)
        x = y1 - (b // a) * x1
        y = x1
        return gcd, x, y
    
    gcd, x, _ = extended_gcd(a % m, m)
    if gcd != 1:
        raise ValueError("Modular inverse does not exist")
    return (x % m + m) % m

def chinese_remainder_theorem(remainders: list, moduli: list) -> int:
    """Solve system of congruences using Chinese Remainder Theorem."""
    if len(remainders) != len(moduli):
        raise ValueError("Remainders and moduli must have same length")
    
    total = 0
    prod = 1
    for m in moduli:
        prod *= m
    
    for r, m in zip(remainders, moduli):
        p = prod // m
        total += r * modular_inverse(p, m) * p
    
    return total % prod

# COMBINATORICS
def permutations_with_repetition(n: int, r: int) -> int:
    """Number of r-permutations of n objects with repetition allowed."""
    return n ** r

def combinations_with_repetition(n: int, r: int) -> int:
    """Number of r-combinations of n objects with repetition allowed."""
    import math
    return math.comb(n + r - 1, r)

def stirling_second_kind(n: int, k: int) -> int:
    """Stirling numbers of the second kind - ways to partition n objects into k non-empty subsets."""
    if n == 0 and k == 0:
        return 1
    if n == 0 or k == 0:
        return 0
    if k > n:
        return 0
    
    # Dynamic programming approach
    dp = [[0] * (k + 1) for _ in range(n + 1)]
    dp[0][0] = 1
    
    for i in range(1, n + 1):
        for j in range(1, min(i, k) + 1):
            dp[i][j] = j * dp[i-1][j] + dp[i-1][j-1]
    
    return dp[n][k]

# INTERPOLATION & MAPPING
def clamp(value: float, min_value: float, max_value: float) -> float:
    """Clamp a value between min and max."""
    return max(min_value, min(value, max_value))

def lerp(a: float, b: float, t: float) -> float:
    """Linear interpolation between a and b by factor t."""
    return a + (b - a) * t

def inverse_lerp(a: float, b: float, value: float) -> float:
    """Inverse linear interpolation - find t where lerp(a, b, t) = value."""
    if a == b:
        return 0
    return (value - a) / (b - a)

def remap(value: float, from_min: float, from_max: float, to_min: float, to_max: float) -> float:
    """Remap a value from one range to another."""
    t = inverse_lerp(from_min, from_max, value)
    return lerp(to_min, to_max, t)

def normalize(values: list) -> list:
    """Normalize a list of values to 0-1 range."""
    min_val = min(values)
    max_val = max(values)
    range_val = max_val - min_val
    if range_val == 0:
        return [0.5] * len(values)
    return [(v - min_val) / range_val for v in values]

def smoothstep(edge0: float, edge1: float, x: float) -> float:
    """Smooth interpolation (ease-in-out) between edge0 and edge1."""
    t = clamp((x - edge0) / (edge1 - edge0), 0.0, 1.0)
    return t * t * (3 - 2 * t)

# STATISTICS
def moving_average(data: list, window_size: int) -> list:
    """Calculate moving average with given window size."""
    import statistics
    if window_size > len(data):
        return [statistics.mean(data)]
    return [statistics.mean(data[i:i+window_size]) for i in range(len(data) - window_size + 1)]

def weighted_average(values: list, weights: list) -> float:
    """Calculate weighted average."""
    if len(values) != len(weights):
        raise ValueError("Values and weights must have same length")
    return sum(v * w for v, w in zip(values, weights)) / sum(weights)

def sigfigs(x: float, n: int) -> float:
    """Round x to n significant figures."""
    if x == 0:
        return 0
    import math
    return round(x, -int(math.floor(math.log10(abs(x)))) + (n - 1))

def percentage_change(old_value: float, new_value: float) -> float:
    """Calculate percentage change between two values."""
    if old_value == 0:
        return float('inf') if new_value != 0 else 0
    return ((new_value - old_value) / old_value) * 100

def z_score(x: float, mean: float, std: float) -> float:
    """Calculate z-score (standard score)."""
    return (x - mean) / std

def standard_error(data: list) -> float:
    """Calculate standard error of the mean."""
    import statistics
    import math
    return statistics.stdev(data) / math.sqrt(len(data))

# NUMERICAL METHODS
def newton_raphson(f: Callable, df: Callable, x0: float, tol: float = 1e-6, max_iter: int = 100) -> float:
    """Find root using Newton-Raphson method."""
    x = x0
    for _ in range(max_iter):
        fx = f(x)
        if abs(fx) < tol:
            return x
        x = x - fx / df(x)
    raise ValueError("Newton-Raphson did not converge")

def bisection(f: Callable, a: float, b: float, tol: float = 1e-6, max_iter: int = 100) -> float:
    """Find root using bisection method."""
    if f(a) * f(b) > 0:
        raise ValueError("f(a) and f(b) must have opposite signs")
    
    for _ in range(max_iter):
        c = (a + b) / 2
        fc = f(c)
        if abs(fc) < tol:
            return c
        if f(a) * fc < 0:
            b = c
        else:
            a = c
    return (a + b) / 2

def numerical_derivative(f: Callable, x: float, h: float = 1e-5) -> float:
    """Calculate numerical derivative using central difference."""
    return (f(x + h) - f(x - h)) / (2 * h)

def numerical_integral_simpson(f: Callable, a: float, b: float, n: int = 1000) -> float:
    """Numerical integration using Simpson's rule."""
    if n % 2 == 1:
        n += 1
    h = (b - a) / n
    x = [a + i * h for i in range(n + 1)]
    y = [f(xi) for xi in x]
    return h / 3 * (y[0] + y[-1] + 4 * sum(y[i] for i in range(1, n, 2)) + 2 * sum(y[i] for i in range(2, n, 2)))

def numerical_integral_trapezoidal(f: Callable, a: float, b: float, n: int = 1000) -> float:
    """Numerical integration using trapezoidal rule."""
    h = (b - a) / n
    return h * (0.5 * f(a) + sum(f(a + i * h) for i in range(1, n)) + 0.5 * f(b))

# FINANCE
def compound_interest(principal: float, rate: float, time: float, n: int = 1) -> float:
    """Calculate compound interest."""
    return principal * pow(1 + rate/n, n * time)

def present_value(future_value: float, rate: float, time: float) -> float:
    """Calculate present value given future value."""
    return future_value / pow(1 + rate, time)

def future_value(present_value: float, rate: float, time: float) -> float:
    """Calculate future value given present value."""
    return present_value * pow(1 + rate, time)

def annuity_payment(principal: float, rate: float, periods: int) -> float:
    """Calculate annuity payment (loan payment)."""
    if rate == 0:
        return principal / periods
    return principal * rate * pow(1 + rate, periods) / (pow(1 + rate, periods) - 1)

def annuity_present_value(payment: float, rate: float, periods: int) -> float:
    """Calculate present value of annuity."""
    if rate == 0:
        return payment * periods
    return payment * (1 - pow(1 + rate, -periods)) / rate

# ALGEBRA
def quadratic_formula(a: float, b: float, c: float) -> tuple:
    """Solve quadratic equation ax^2 + bx + c = 0."""
    import math
    import cmath
    discriminant = b**2 - 4*a*c
    if discriminant >= 0:
        x1 = (-b + math.sqrt(discriminant)) / (2*a)
        x2 = (-b - math.sqrt(discriminant)) / (2*a)
        return (x1, x2)
    else:
        x1 = (-b + cmath.sqrt(discriminant)) / (2*a)
        x2 = (-b - cmath.sqrt(discriminant)) / (2*a)
        return (x1, x2)

def binomial_coefficient(n: int, k: int) -> int:
    """Calculate binomial coefficient C(n, k)."""
    import math
    return math.comb(n, k)

def harmonic_number(n: int) -> float:
    """Calculate nth harmonic number."""
    return sum(1/i for i in range(1, n + 1))

# UNIT CONVERSIONS - Temperature
def celsius_to_fahrenheit(c: float) -> float:
    """Convert Celsius to Fahrenheit."""
    return c * 9/5 + 32

def fahrenheit_to_celsius(f: float) -> float:
    """Convert Fahrenheit to Celsius."""
    return (f - 32) * 5/9

def celsius_to_kelvin(c: float) -> float:
    """Convert Celsius to Kelvin."""
    return c + 273.15

def kelvin_to_celsius(k: float) -> float:
    """Convert Kelvin to Celsius."""
    return k - 273.15

def fahrenheit_to_kelvin(f: float) -> float:
    """Convert Fahrenheit to Kelvin."""
    return celsius_to_kelvin(fahrenheit_to_celsius(f))

def kelvin_to_fahrenheit(k: float) -> float:
    """Convert Kelvin to Fahrenheit."""
    return celsius_to_fahrenheit(kelvin_to_celsius(k))

# UNIT CONVERSIONS - Angle
def degrees_to_radians_precise(degrees: float, minutes: float = 0, seconds: float = 0) -> float:
    """Convert degrees/minutes/seconds to radians."""
    import math
    total_degrees = degrees + minutes/60 + seconds/3600
    return math.radians(total_degrees)

def radians_to_dms(radians: float) -> tuple:
    """Convert radians to (degrees, minutes, seconds)."""
    import math
    total_degrees = math.degrees(radians)
    degrees = int(total_degrees)
    minutes_float = (total_degrees - degrees) * 60
    minutes = int(minutes_float)
    seconds = (minutes_float - minutes) * 60
    return (degrees, minutes, seconds)

# GEOMETRY 2D
def distance_2d(x1: float, y1: float, x2: float, y2: float) -> float:
    """Calculate Euclidean distance between two 2D points."""
    import math
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def polygon_area(vertices: list) -> float:
    """Calculate area of polygon given vertices as list of (x, y) tuples."""
    n = len(vertices)
    area = 0
    for i in range(n):
        j = (i + 1) % n
        area += vertices[i][0] * vertices[j][1]
        area -= vertices[j][0] * vertices[i][1]
    return abs(area) / 2

def circle_area(radius: float) -> float:
    """Calculate area of circle."""
    import math
    return math.pi * radius ** 2

def circle_circumference(radius: float) -> float:
    """Calculate circumference of circle."""
    import math
    return 2 * math.pi * radius

def triangle_area_heron(a: float, b: float, c: float) -> float:
    """Calculate triangle area using Heron's formula."""
    import math
    s = (a + b + c) / 2
    return math.sqrt(s * (s - a) * (s - b) * (s - c))

def triangle_area_base_height(base: float, height: float) -> float:
    """Calculate triangle area from base and height."""
    return 0.5 * base * height

# GEOMETRY 3D
def distance_3d(x1: float, y1: float, z1: float, x2: float, y2: float, z2: float) -> float:
    """Calculate Euclidean distance between two 3D points."""
    import math
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)

def sphere_volume(radius: float) -> float:
    """Calculate volume of sphere."""
    import math
    return (4/3) * math.pi * radius ** 3

def sphere_surface_area(radius: float) -> float:
    """Calculate surface area of sphere."""
    import math
    return 4 * math.pi * radius ** 2

def cylinder_volume(radius: float, height: float) -> float:
    """Calculate volume of cylinder."""
    import math
    return math.pi * radius ** 2 * height

def cylinder_surface_area(radius: float, height: float) -> float:
    """Calculate surface area of cylinder."""
    import math
    return 2 * math.pi * radius * (radius + height)

def cone_volume(radius: float, height: float) -> float:
    """Calculate volume of cone."""
    import math
    return (1/3) * math.pi * radius ** 2 * height

def cone_surface_area(radius: float, height: float) -> float:
    """Calculate surface area of cone."""
    import math
    slant_height = math.sqrt(radius**2 + height**2)
    return math.pi * radius * (radius + slant_height)

def rectangular_prism_volume(length: float, width: float, height: float) -> float:
    """Calculate volume of rectangular prism."""
    return length * width * height

def rectangular_prism_surface_area(length: float, width: float, height: float) -> float:
    """Calculate surface area of rectangular prism."""
    return 2 * (length * width + width * height + height * length)

# VECTOR OPERATIONS
def manhattan_distance(p1: list, p2: list) -> float:
    """Calculate Manhattan distance between two points."""
    return sum(abs(a - b) for a, b in zip(p1, p2))

def dot_product(v1: list, v2: list) -> float:
    """Calculate dot product of two vectors."""
    return sum(a * b for a, b in zip(v1, v2))

def cross_product_2d(v1: tuple, v2: tuple) -> float:
    """Calculate 2D cross product (returns scalar)."""
    return v1[0] * v2[1] - v1[1] * v2[0]

def cross_product_3d(v1: tuple, v2: tuple) -> tuple:
    """Calculate 3D cross product."""
    return (
        v1[1] * v2[2] - v1[2] * v2[1],
        v1[2] * v2[0] - v1[0] * v2[2],
        v1[0] * v2[1] - v1[1] * v2[0]
    )

def vector_magnitude(v: list) -> float:
    """Calculate magnitude of a vector."""
    import math
    return math.sqrt(sum(x**2 for x in v))

def angle_between_vectors(v1: list, v2: list) -> float:
    """Calculate angle between two vectors in radians."""
    import math
    dot = dot_product(v1, v2)
    mag1 = vector_magnitude(v1)
    mag2 = vector_magnitude(v2)
    return math.acos(dot / (mag1 * mag2))

def vector_normalize(v: list) -> list:
    """Normalize a vector to unit length."""
    mag = vector_magnitude(v)
    return [x / mag for x in v]

def vector_projection(v: list, onto: list) -> list:
    """Project vector v onto vector 'onto'."""
    scalar = dot_product(v, onto) / dot_product(onto, onto)
    return [scalar * x for x in onto]

# CLASSIC FORMULAS
def pythagorean(a: float, b: float) -> float:
    """Calculate hypotenuse using Pythagorean theorem."""
    import math
    return math.sqrt(a**2 + b**2)

def pythagorean_triple_check(a: int, b: int, c: int) -> bool:
    """Check if three numbers form a Pythagorean triple."""
    sides = sorted([a, b, c])
    return sides[0]**2 + sides[1]**2 == sides[2]**2

# NUMPY-BASED FUNCTIONS (lazy loaded)
def matrix(data):
    """Create a numpy matrix from nested lists."""
    np = _lazy_import_module('numpy')
    if np is None:
        raise ImportError("NumPy is required for matrix operations")
    return np.array(data)

def solve_linear_system(A, b):
    """Solve system of linear equations Ax = b."""
    np = _lazy_import_module('numpy')
    if np is None:
        raise ImportError("NumPy is required for linear system solving")
    return np.linalg.solve(np.array(A), np.array(b))

def eigenvalues(A):
    """Calculate eigenvalues of matrix A."""
    np = _lazy_import_module('numpy')
    if np is None:
        raise ImportError("NumPy is required for eigenvalue computation")
    return np.linalg.eigvals(np.array(A))

def eigenvectors(A):
    """Calculate eigenvalues and eigenvectors of matrix A."""
    np = _lazy_import_module('numpy')
    if np is None:
        raise ImportError("NumPy is required for eigenvector computation")
    return np.linalg.eig(np.array(A))

def parse_math_expression(text):
    """
    Parse natural language math expressions with enhanced understanding.
    Examples:
        "what is the square root of 16" → 4.0
        "calculate sin of pi over 2" → 1.0
        "is 17 prime" → True
        "is 23 not prime" → False
        "23 is not prime" → False
        "calculate factorial of 5" → 120
        "fibonacci 10" → [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
    """
    import math
    import re
    
    text = text.lower().strip()
    
    # Check for negation keywords
    is_negated = any(keyword in text for keyword in ['not prime', 'not a prime', "isn't prime", "is not prime"])
    
    # Square root
    if 'square root' in text or 'sqrt' in text:
        match = re.search(r'(\d+\.?\d*)', text)
        if match:
            num = float(match.group(1))
            return math.sqrt(num)
    
    # Trigonometric functions
    trig_funcs = {
        'sin': math.sin,
        'sine': math.sin,
        'cos': math.cos,
        'cosine': math.cos,
        'tan': math.tan,
        'tangent': math.tan,
        'asin': math.asin,
        'arcsin': math.asin,
        'acos': math.acos,
        'arccos': math.acos,
        'atan': math.atan,
        'arctan': math.atan,
    }
    
    for trig_name, trig_func in trig_funcs.items():
        if trig_name in text:
            if 'pi' in text:
                # Handle common pi fractions
                if any(pattern in text for pattern in ['over 2', '/ 2', '/2', 'divided by 2']):
                    return trig_func(math.pi/2)
                elif any(pattern in text for pattern in ['over 3', '/ 3', '/3', 'divided by 3']):
                    return trig_func(math.pi/3)
                elif any(pattern in text for pattern in ['over 4', '/ 4', '/4', 'divided by 4']):
                    return trig_func(math.pi/4)
                elif any(pattern in text for pattern in ['over 6', '/ 6', '/6', 'divided by 6']):
                    return trig_func(math.pi/6)
                else:
                    return trig_func(math.pi)
            # Try to extract numeric value
            match = re.search(r'(\d+\.?\d*)', text)
            if match:
                return trig_func(float(match.group(1)))
    
    # Prime check
    if 'prime' in text:
        match = re.search(r'(\d+)', text)
        if match:
            result = is_prime(int(match.group(1)))
            # Apply negation if present
            return not result if is_negated else result
    
    # Factorial
    if 'factorial' in text:
        match = re.search(r'(\d+)', text)
        if match:
            return math.factorial(int(match.group(1)))
    
    # Fibonacci
    if 'fibonacci' in text or 'fib' in text:
        match = re.search(r'(\d+)', text)
        if match:
            n = int(match.group(1))
            # Check if they want the nth number or the sequence
            if 'nth' in text or 'number' in text:
                return fibonacci_nth(n)
            return fibonacci(n)
    
    # Power/exponent
    if 'power' in text or 'to the' in text or '^' in text or '**' in text:
        numbers = re.findall(r'(\d+\.?\d*)', text)
        if len(numbers) >= 2:
            base = float(numbers[0])
            exp = float(numbers[1])
            return math.pow(base, exp)
    
    # GCD/LCM
    if 'gcd' in text or 'greatest common divisor' in text:
        numbers = re.findall(r'(\d+)', text)
        if len(numbers) >= 2:
            return math.gcd(int(numbers[0]), int(numbers[1]))
    
    if 'lcm' in text or 'least common multiple' in text:
        numbers = re.findall(r'(\d+)', text)
        if len(numbers) >= 2:
            a, b = int(numbers[0]), int(numbers[1])
            return abs(a * b) // math.gcd(a, b)
    
    # Absolute value
    if 'absolute' in text or 'abs' in text:
        match = re.search(r'(-?\d+\.?\d*)', text)
        if match:
            return abs(float(match.group(1)))
    
    # Logarithms
    if 'log' in text or 'logarithm' in text:
        if 'natural' in text or 'ln' in text:
            match = re.search(r'(\d+\.?\d*)', text)
            if match:
                return math.log(float(match.group(1)))
        elif 'log10' in text or 'log 10' in text or 'base 10' in text:
            match = re.search(r'(\d+\.?\d*)', text)
            if match:
                return math.log10(float(match.group(1)))
        else:
            # Default to natural log
            match = re.search(r'(\d+\.?\d*)', text)
            if match:
                return math.log(float(match.group(1)))
    
    # Basic arithmetic operations
    if '+' in text or 'plus' in text or 'add' in text:
        numbers = re.findall(r'(\d+\.?\d*)', text)
        if len(numbers) >= 2:
            return sum(float(n) for n in numbers)
    
    if '-' in text or 'minus' in text or 'subtract' in text:
        numbers = re.findall(r'(-?\d+\.?\d*)', text)
        if len(numbers) >= 2:
            result = float(numbers[0])
            for n in numbers[1:]:
                result -= float(n)
            return result
    
    if '*' in text or 'times' in text or 'multiply' in text:
        numbers = re.findall(r'(\d+\.?\d*)', text)
        if len(numbers) >= 2:
            result = 1
            for n in numbers:
                result *= float(n)
            return result
    
    if '/' in text or 'divide' in text:
        numbers = re.findall(r'(\d+\.?\d*)', text)
        if len(numbers) >= 2:
            return float(numbers[0]) / float(numbers[1])
    
    return "Could not parse expression. Try using direct function calls or rephrasing your question."

# Add all utility functions to __all__
__all__.extend([
    # Number theory
    'is_prime', 'primes_up_to', 'fibonacci', 'fibonacci_nth', 'prime_factors',
    'totient', 'modular_inverse', 'chinese_remainder_theorem',
    
    # Combinatorics
    'permutations_with_repetition', 'combinations_with_repetition', 'stirling_second_kind',
    
    # Interpolation & mapping
    'clamp', 'lerp', 'inverse_lerp', 'remap', 'normalize', 'smoothstep',
    
    # Statistics
    'moving_average', 'weighted_average', 'sigfigs', 'percentage_change',
    'z_score', 'standard_error',
    
    # Numerical methods
    'newton_raphson', 'bisection', 'numerical_derivative',
    'numerical_integral_simpson', 'numerical_integral_trapezoidal',
    
    # Finance
    'compound_interest', 'present_value', 'future_value', 'annuity_payment',
    'annuity_present_value',
    
    # Algebra
    'quadratic_formula', 'binomial_coefficient', 'harmonic_number',
    
    # Unit conversions - Temperature
    'celsius_to_fahrenheit', 'fahrenheit_to_celsius', 'celsius_to_kelvin',
    'kelvin_to_celsius', 'fahrenheit_to_kelvin', 'kelvin_to_fahrenheit',
    
    # Unit conversions - Angle
    'degrees_to_radians_precise', 'radians_to_dms',
    
    # Geometry 2D
    'distance_2d', 'polygon_area', 'circle_area', 'circle_circumference',
    'triangle_area_heron', 'triangle_area_base_height',
    
    # Geometry 3D
    'distance_3d', 'sphere_volume', 'sphere_surface_area',
    'cylinder_volume', 'cylinder_surface_area', 'cone_volume', 'cone_surface_area',
    'rectangular_prism_volume', 'rectangular_prism_surface_area',
    
    # Vector operations
    'manhattan_distance', 'dot_product', 'cross_product_2d', 'cross_product_3d',
    'vector_magnitude', 'angle_between_vectors', 'vector_normalize', 'vector_projection',
    
    # Classic formulas
    'pythagorean', 'pythagorean_triple_check',
    
    # Linear algebra
    'matrix', 'solve_linear_system', 'eigenvalues', 'eigenvectors',
    
    # For parsing and giving answer to user entered questions
    'parse_math_expression'
])

# ============================================================================
# MODULE INFO
# ============================================================================

def info():
    """Print comprehensive information about UniversalMath."""
    print(f"UniversalMath v{__version__} - The Ultimate Unified Mathematics Module")
    print(f"Python {sys.version.split()[0]}")
    print(f"\n{'='*80}")
    print(f"{'MODULE':<25} {'STATUS':<20} {'FUNCTIONS'}")
    print(f"{'='*80}")
    
    modules_to_check = [
        ('math', 'math', 'Real number mathematics'),
        ('cmath', 'cmath', 'Complex mathematics (c* prefix)'),
        ('statistics', 'statistics', 'Statistical functions'),
        ('decimal', 'decimal', 'High-precision arithmetic'),
        ('fractions', 'fractions', 'Rational numbers'),
        ('random', 'random', 'Random number generation'),
        ('numpy', 'numpy', 'Arrays & matrices (np_* prefix)'),
        ('scipy.stats', 'scipy.stats', 'Statistical distributions (sp_stats_*)'),
        ('scipy.linalg', 'scipy.linalg', 'Linear algebra (sp_linalg_*)'),
        ('scipy.optimize', 'scipy.optimize', 'Optimization (sp_optimize_*)'),
        ('scipy.integrate', 'scipy.integrate', 'Integration (sp_integrate_*)'),
        ('scipy.signal', 'scipy.signal', 'Signal processing (sp_signal_*)'),
        ('sympy', 'sympy', 'Symbolic math (sym_* prefix)'),
        ('pandas', 'pandas', 'Data analysis (pd_* prefix)'),
    ]
    
    loaded = 0
    total = len(modules_to_check)
    
    for display_name, module_name, description in modules_to_check:
        module = _lazy_import_module(module_name)
        if module is not None:
            status = "✓ Available (lazy)"
            loaded += 1
            func_count = len([x for x in dir(module) if not x.startswith('_')])
            desc = f"{description} [{func_count} items]"
        else:
            status = "✗ Not installed"
            desc = description
        
        print(f"{display_name:<25} {status:<20} {desc}")
    
    print(f"{'='*80}")
    print(f"\nModules available: {loaded}/{total}")
    print(f"Total exported names: {len(__all__)}")
    print(f"\n⚡ LAZY LOADING: Modules imported only when functions are called")
    print(f"   This reduces memory usage and import time!")
    
    print(f"\n{'='*80}")
    print(f"UTILITY FUNCTIONS (70+ custom helpers)")
    print(f"{'='*80}")
    
    categories = [
        ("Number Theory (7)", "is_prime, primes_up_to, fibonacci, prime_factors,\n" + 
                              " " * 24 + "totient, modular_inverse, chinese_remainder_theorem"),
        ("Combinatorics (3)", "permutations_with_repetition, combinations_with_repetition,\n" +
                              " " * 24 + "stirling_second_kind"),
        ("Interpolation (6)", "lerp, inverse_lerp, remap, normalize, clamp, smoothstep"),
        ("Statistics (6)", "moving_average, weighted_average, percentage_change,\n" +
                          " " * 24 + "z_score, standard_error, sigfigs"),
        ("Numerical Methods (5)", "newton_raphson, bisection, numerical_derivative,\n" +
                                  " " * 24 + "numerical_integral_simpson, numerical_integral_trapezoidal"),
        ("Finance (5)", "compound_interest, present_value, future_value,\n" +
                       " " * 24 + "annuity_payment, annuity_present_value"),
        ("Algebra (3)", "quadratic_formula, binomial_coefficient, harmonic_number"),
        ("Temperature (6)", "celsius_to_fahrenheit, fahrenheit_to_celsius,\n" +
                           " " * 24 + "celsius_to_kelvin, kelvin_to_celsius, etc."),
        ("Angle Units (2)", "degrees_to_radians_precise, radians_to_dms"),
        ("2D Geometry (6)", "distance_2d, polygon_area, circle_area,\n" +
                           " " * 24 + "circle_circumference, triangle_area_heron, etc."),
        ("3D Geometry (8)", "distance_3d, sphere_volume, sphere_surface_area,\n" +
                           " " * 24 + "cylinder_volume, cone_volume, rectangular_prism_*, etc."),
        ("Vectors (8)", "dot_product, cross_product_3d, vector_magnitude,\n" +
                       " " * 24 + "angle_between_vectors, vector_normalize, etc."),
        ("Linear Algebra (4)", "matrix, solve_linear_system, eigenvalues, eigenvectors"),
        ("Misc (2)", "pythagorean, pythagorean_triple_check"),
    ]
    
    for category, funcs in categories:
        print(f"  {category:<20} {funcs}")
    
    print(f"\n{'='*80}")
    print(f"QUICK START:")
    print(f"{'='*80}")
    print(f"  import universalmath as um")
    print(f"  ")
    print(f"  # Standard math")
    print(f"  um.sqrt(16)                    # 4.0")
    print(f"  um.sin(um.pi/2)                # 1.0")
    print(f"  ")
    print(f"  # Statistics")
    print(f"  um.mean([1, 2, 3, 4, 5])       # 3.0")
    print(f"  um.stdev([1, 2, 3, 4, 5])      # Standard deviation")
    print(f"  ")
    print(f"  # Utilities")
    print(f"  um.is_prime(17)                # True")
    print(f"  um.fibonacci(10)               # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]")
    print(f"  um.lerp(0, 100, 0.5)           # 50.0")
    print(f"  ")
    print(f"  # Finance")
    print(f"  um.compound_interest(1000, 0.05, 10)  # Compound interest")
    print(f"  ")
    
    if _lazy_import_module('numpy') is not None:
        print(f"  # NumPy (lazy loaded)")
        print(f"  um.np_array([1, 2, 3])         # Create array")
        print(f"  um.matrix([[1,2],[3,4]])       # Create matrix")
        print(f"  ")
    
    if _lazy_import_module('scipy.stats') is not None:
        print(f"  # SciPy (lazy loaded)")
        print(f"  um.sp_stats_norm.pdf(0)        # Normal distribution PDF")
        print(f"  um.sp_optimize_minimize(...)   # Optimization")
        print(f"  ")
    
    print(f"{'='*80}\n")

__all__.append('info')

# ============================================================================
# COMMAND LINE INTERFACE
# ============================================================================

def _cli_help():
    """Command-line help interface with pagination."""
    import sys
    
    help_text = f"""
╔══════════════════════════════════════════════════════════════════════════╗
║                        UniversalMath v{__version__}                      ║
║              The Ultimate Unified Mathematics Module                     ║
╚══════════════════════════════════════════════════════════════════════════╝

USAGE:
    import universalmath as um

QUICK START:
    um.sqrt(16)                    # 4.0
    um.sin(um.pi/2)                # 1.0
    um.mean([1, 2, 3])             # 2.0
    um.is_prime(17)                # True
    um.fibonacci(10)               # [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

INSTALLATION:
    pip install universalmath            # Basic (standard library only)
    pip install universalmath[full]      # With numpy, scipy, sympy, pandas

MODULES AVAILABLE (lazy loaded):
    ✓ math          - 50+ real number functions
    ✓ cmath         - 30 complex number functions (c* prefix)
    ✓ statistics    - 30+ statistical functions
    ✓ decimal       - High-precision arithmetic
    ✓ fractions     - Rational numbers
    ✓ random        - Random number generation
    
    Optional (install with [full]):
    ○ numpy         - 400+ array & matrix functions (np_* prefix)
    ○ scipy         - 1000+ scientific computing functions (sp_* prefix)
    ○ sympy         - 800+ symbolic math functions (sym_* prefix)
    ○ pandas        - 100+ data analysis functions (pd_* prefix)

UTILITIES (70+ custom functions):
    • Number Theory: is_prime, fibonacci, prime_factors, totient, ...
    • Interpolation: lerp, remap, clamp, smoothstep, ...
    • Finance: compound_interest, annuity_payment, ...
    • Geometry: circle_area, sphere_volume, polygon_area, ...
    • Vectors: dot_product, cross_product_3d, vector_magnitude, ...
    • Numerical: newton_raphson, numerical_integral_simpson, ...

COMMANDS:
    python -m universalmath --help       # Show this help
    python -m universalmath --info       # Show detailed module info
    python -m universalmath --list       # List all available functions
    python -c "import universalmath as um; um.info()"  # From Python

DOCUMENTATION:
    help(universalmath)                  # Full documentation
    help(um.function_name)         # Help for specific function

EXAMPLES:
    # Statistics
    import universalmath as um
    data = [1, 2, 3, 4, 5]
    print(um.mean(data))           # 3.0
    print(um.stdev(data))          # 1.58...
    
    # Finance
    payment = um.compound_interest(1000, 0.05, 10)
    print(f"Future value: ${{payment:.2f}}")
    
    # Linear Algebra (requires numpy)
    A = um.matrix([[1, 2], [3, 4]])
    det = um.np_linalg_det(A)
    print(f"Determinant: {{det}}")

PROJECT:
    GitHub: https://github.com/tech-dragoness/universalmath
    PyPI:   https://pypi.org/project/universalmath/
    
"""
    
    print(help_text)
    
    try:
        input("\nPress Enter or Cntrl+C to exit...")
    except KeyboardInterrupt:
        print("\n\nExiting...")
        sys.exit(0)

def _cli_list_functions():
    """List all available functions with pagination."""
    import sys
    import textwrap
    
    print(f"\n{'='*80}")
    print(f"  UniversalMath v{__version__} - Complete Function List")
    print(f"{'='*80}\n")
    
    # Gather all functions
    functions_by_category = {}
    
    # Core modules
    for name in __all__:
        if name in ['info', '_cli_help', '_cli_list_functions']:
            continue
        
        func = globals().get(name)
        if func is None:
            continue
        
        # Categorize
        if name.startswith('np_'):
            category = "NumPy"
        elif name.startswith('sp_'):
            category = "SciPy"
        elif name.startswith('sym_'):
            category = "SymPy"
        elif name.startswith('pd_'):
            category = "Pandas"
        elif name.startswith('c') and name[1:] in dir(_lazy_import_module('cmath') or {}):
            category = "Complex Math (cmath)"
        elif name in ['is_prime', 'fibonacci', 'prime_factors', 'primes_up_to', 
                      'totient', 'modular_inverse', 'chinese_remainder_theorem',
                      'fibonacci_nth']:
            category = "Number Theory (Utilities)"
        elif name in ['lerp', 'clamp', 'remap', 'normalize', 'inverse_lerp', 'smoothstep']:
            category = "Interpolation (Utilities)"
        elif name in ['moving_average', 'weighted_average', 'z_score', 'standard_error',
                      'percentage_change', 'sigfigs']:
            category = "Statistics (Utilities)"
        elif name in ['compound_interest', 'present_value', 'future_value', 
                      'annuity_payment', 'annuity_present_value']:
            category = "Finance (Utilities)"
        elif name in ['newton_raphson', 'bisection', 'numerical_derivative',
                      'numerical_integral_simpson', 'numerical_integral_trapezoidal']:
            category = "Numerical Methods (Utilities)"
        elif 'area' in name or 'volume' in name or 'circumference' in name or 'distance' in name:
            category = "Geometry (Utilities)"
        elif 'vector' in name or 'dot_product' in name or 'cross_product' in name:
            category = "Vectors (Utilities)"
        elif name in ['Decimal', 'Fraction', 'getcontext', 'Context']:
            category = "Precision Arithmetic"
        else:
            category = "Core Math"
        
        if category not in functions_by_category:
            functions_by_category[category] = []
        
        # Get description
        doc = getattr(func, '__doc__', '') or ''
        first_line = doc.split('\n')[0].strip() if doc else 'No description'
        
        functions_by_category[category].append((name, first_line))
    
    # Print with pagination
    lines = []
    counter = 1
    
    for category in sorted(functions_by_category.keys()):
        lines.append(f"\n{'─'*80}")
        lines.append(f"  {category}")
        lines.append(f"{'─'*80}")
        
        for name, desc in sorted(functions_by_category[category]):
            # Wrap description
            desc_wrapped = textwrap.fill(desc, width=60, 
                                        initial_indent='', 
                                        subsequent_indent=' ' * 8)
            lines.append(f"  {counter:3d}. {name}")
            lines.append(f"       {desc_wrapped}")
            counter += 1
    
    lines.append(f"\n{'='*80}")
    lines.append(f"Total: {counter - 1} functions")
    lines.append(f"{'='*80}\n")
    
    # Paginate
    page_size = 40
    for i in range(0, len(lines), page_size):
        page = lines[i:i + page_size]
        print('\n'.join(page))
        
        if i + page_size < len(lines):
            try:
                response = input(f"\n--- Page {i//page_size + 1} (Press Enter for next page, Ctrl+C to exit) ---\n")
            except KeyboardInterrupt:
                print("\n\nExiting...")
                sys.exit(0)
    
    print("\nFor detailed help on any function:")
    print("  import universalmath as um")
    print("  help(um.function_name)")

def _cli_main():
    """Main CLI entry point."""
    import sys
    
    if len(sys.argv) <= 1 or '--help' in sys.argv or '-h' in sys.argv:
        _cli_help()
    elif '--info' in sys.argv or '-i' in sys.argv:
        info()
    elif '--list' in sys.argv or '-l' in sys.argv:
        _cli_list_functions()
    elif '--repl' in sys.argv or '-r' in sys.argv:
        try:
            from universalmath.repl import start_repl  # Fixed path
            start_repl()
        except ImportError:
            print("Error: REPL module not found. Make sure repl.py is in the universalmath package.")
            sys.exit(1)
    else:
        print(f"Unknown command. Use --help for usage.")
        sys.exit(1)

__all__.extend(['_cli_help', '_cli_list_functions', '_cli_main'])

# ============================================================================
# DYNAMIC ATTRIBUTE ACCESS (for even better lazy loading)
# ============================================================================

def __getattr__(name):
    """
    Fallback for attribute access - enables truly dynamic lazy loading.
    If a function hasn't been registered yet, try to find and load it.
    """
    # Check if it's a Python built-in first
    if name in ['abs', 'round', 'min', 'max', 'sum', 'pow', 'len', 'sorted', 'reversed']:
        import builtins
        return getattr(builtins, name)
    
    # Check if it's in our registry
    if name in _function_registry:
        module_name = _function_registry[name]
        module = _lazy_import_module(module_name)
        if module is not None:
            # Extract the actual function name (remove prefix)
            if name.startswith('np_linalg_'):
                actual_name = name[10:]
            elif name.startswith('np_random_'):
                actual_name = name[10:]
            elif name.startswith('np_fft_'):
                actual_name = name[7:]
            elif name.startswith('np_'):
                actual_name = name[3:]
            elif name.startswith('sp_stats_'):
                actual_name = name[9:]
            elif name.startswith('sp_linalg_'):
                actual_name = name[10:]
            elif name.startswith('sp_optimize_'):
                actual_name = name[12:]
            elif name.startswith('sp_integrate_'):
                actual_name = name[13:]
            elif name.startswith('sp_interpolate_'):
                actual_name = name[15:]
            elif name.startswith('sp_signal_'):
                actual_name = name[10:]
            elif name.startswith('sp_fft_'):
                actual_name = name[7:]
            elif name.startswith('sp_special_'):
                actual_name = name[11:]
            elif name.startswith('sp_sparse_'):
                actual_name = name[10:]
            elif name.startswith('sym_'):
                actual_name = name[4:]
            elif name.startswith('pd_'):
                actual_name = name[3:]
            elif name.startswith('c'):
                actual_name = name[1:]
            else:
                actual_name = name
            
            if hasattr(module, actual_name):
                return getattr(module, actual_name)
    
    raise AttributeError(f"module 'universalmath' has no attribute '{name}'")