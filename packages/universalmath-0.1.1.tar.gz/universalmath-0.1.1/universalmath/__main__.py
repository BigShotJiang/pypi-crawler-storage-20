"""
Command-line interface for UniversalMath
Allows running: python -m universalmath --help
"""

from universalmath import _cli_main

if __name__ == '__main__':
    _cli_main()