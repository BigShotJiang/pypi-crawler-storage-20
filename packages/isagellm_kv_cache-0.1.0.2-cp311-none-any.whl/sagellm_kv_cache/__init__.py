"""sagellm-kv-cache: KV Cache Management Module for sageLLM."""

from __future__ import annotations

__version__ = "0.1.0.2"

# Public API will be defined here after Task2.1-2.3 implementation
# Expected exports:
# - KVCacheManager
# - EvictionPolicy
# - PrefixCache
# - MemoryPool

__all__ = [
    "__version__",
]
