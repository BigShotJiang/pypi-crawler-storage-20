"""Tests for uruwat package."""
