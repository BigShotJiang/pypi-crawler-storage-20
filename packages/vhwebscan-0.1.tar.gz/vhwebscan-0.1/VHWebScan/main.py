def hello():
    print("Hello from vhwebscan")