---
title: "ABSESpy"
description: "Agent-Based Social-ecological systems Modelling Framework in Python"
# status: new
---
![ABSES_banner](https://songshgeo-picgo-1302043007.cos.ap-beijing.myqcloud.com/uPic/CleanShot%202023-10-19%20at%2019.08.12@2x.png)

<!-- Language: [English Readme](#) | [简体中文](README_ch) -->

**Date**: October. 29, 2025, **Version**: 0.8.x

**Useful links**: [Install](home/Installation.md) | [Source Repository](https://github.com/SongshGeoLab/ABSESpy) | [Issues & Ideas](https://github.com/SongshGeoLab/ABSESpy/issues) | [Q&A Support](https://github.com/SongshGeoLab/ABSESpy/discussions)

`ABSESpy` is an agent-based framework that makes modeling social-ecological systems easier.

<div class="grid cards" markdown>

-   :octicons-question-24:{ .lg .middle } __The thing for me?__

    ---

    Still wondering if `ABSESpy` is the right tool?
    We have a checklist for you guidance.

    [:material-check-all: Guidance checklist](home/guide_checklist.md)

-   :material-clock-fast:{ .lg .middle } __Set up in 5 minutes__

    ---

    [Install `ABSESpy`](home/Installation.md) with `pip`, then checkout our quick start tutorial.

    [:material-run-fast: Getting started](home/get_started.md)

-   :material-scale-balance:{ .lg .middle } __Start modeling__

    ---

    We provide detailed tutorials for users to begin developing their own ABMs.

    [:material-book: Tutorials](tutorial/tutorial.md)

-   :material-api:{ .lg .middle } __API documentation__

    ---

    For advanced users, check out source codes.

    [:material-api: API References](api/api.md)

</div>

## Keep in touch with us

[Mailing group :fontawesome-solid-paper-plane:](https://groups.google.com/g/absespy){ .md-button }

<!-- links -->
