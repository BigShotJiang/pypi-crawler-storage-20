# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned

- Web-based monitoring dashboard
- Data export to additional formats (Parquet)

## [0.1.3] - 2026-01-15

### Added

- **DuckLake Architecture**: Transitioned to a multi-layer storage strategy combining DuckDB with partitioned Parquet files.
- **Parquet Storage**: Structured records (PNORS, PNORC, etc.) are now exported to compressed Parquet files in `data/parquet/{prefix}/date={YYYY-MM-DD}/`.
- **FastAPI Data Access**: Introduced a REST API for programmatic access to records, errors, and DuckLake data.
- **Analysis Dashboard**: Integrated a Streamlit-based dashboard for real-time visualization of ADCP profiles, sensor trends, and error analytics.
- **DuckDB Parquet Views**: Automatic creation of DuckDB views (`view_{prefix}`) pointing to Parquet data for seamless querying.

### Changed

- Updated `FileWriter` to coordinate concurrent text (NMEA), binary, and Parquet export.
- Refactored `DatabaseManager` to initialize DuckLake views on startup.
- Enhanced `SerialConsumer` to route structured data to both the database and Parquet storage.

## [0.1.2] - 2026-01-15

### Changed

- **Windows Service now uses Servy**: Replaced pywin32-based Windows service with [Servy](https://github.com/aelassas/servy), a full-featured Windows service wrapper
- Windows service installation now uses `servy-cli install` command with automatic health monitoring, log rotation, and recovery actions
- Simplified Windows installation - no more pywin32 post-install configuration required

### Removed

- Removed pywin32 optional dependency (`[win]` extras no longer needed)
- Deleted `adcp_recorder/service/win_service.py` (pywin32-based service)
- Deleted `scripts/fix-windows-service.bat` and `scripts/test-pywin32.bat` (legacy pywin32 scripts)

### Breaking Changes

> **Windows users upgrading from 0.1.1**: You must uninstall the existing pywin32-based service before upgrading. Then reinstall using the new Servy-based installation scripts.
>
> Upgrade steps:
>
> 1. Stop and remove old service: `sc stop ADCPRecorder && sc delete ADCPRecorder`
> 2. Install Servy: `winget install -e --id aelassas.Servy`
> 3. Run the new `install-windows.bat` as Administrator

### Added

- Servy-based service management with health checks, log rotation, and automatic recovery
- Service logs now written to `C:\ADCP_Data\logs\stdout.log` and `stderr.log` with daily rotation

## [0.1.1] - 2026-01-15

### Changed

- **Python 3.13+ required**: Updated minimum Python version to 3.13 for improved performance and modern features
- Windows installation script now auto-installs Python 3.13+ via `winget` if needed
- Linux installation script provides clearer upgrade guidance for Python version

### Fixed

- NMEA telemetry format specification alignment audit
- Various CI/CD improvements and dependency updates
- Windows file handle cleanup timing for better reliability
- Performance test stability improvements for system load variations

### Infrastructure

- Updated GitHub Actions dependencies (checkout v6, setup-python v6, upload-artifact v6, codecov v5, action-gh-release v2)
- Enhanced Windows installer with Visual C++ Redistributable checks
- Improved `pywin32` post-installation configuration

## [0.1.0] - 2026-01-12

### Added

- Initial release of ADCP Recorder
- Support for 21 NMEA message types (PNORI, PNORS, PNORC, PNORH, PNORA, PNORW, PNORB, PNORE, PNORF, PNORWD families)
- Asynchronous serial communication with automatic reconnection
- DuckDB backend for data persistence
- Daily CSV file export per message type
- CLI interface with 5 commands (list-ports, configure, status, start, generate-service)
- Cross-platform support (Linux and Windows)
- Systemd service support (Linux)
- Windows Service support
- Comprehensive NMEA protocol validation and checksum verification
- Binary data detection and error logging
- Health monitoring and graceful shutdown
- Complete user documentation (Installation, Configuration, Usage, Examples)
- Production deployment guide
- Automated installation scripts for Linux and Windows
- Build and packaging scripts
- 100% test coverage for core components
- Performance testing suite
- Integration tests for full pipeline

### Documentation

- Installation guide with platform-specific instructions
- Configuration guide with all parameters documented
- Usage guide with CLI reference and workflows
- Examples guide with 20 practical scenarios
- Deployment guide for production environments
- Architecture documentation
- NMEA protocol specifications
- Database schema documentation

### Infrastructure

- Automated build script with testing and checksums
- Linux installation/uninstallation scripts
- Windows installation/uninstallation scripts
- Enhanced systemd service template with security hardening
- PowerShell service installer for Windows
- GitHub repository setup
- MIT License

## [0.0.1] - Development

### Added

- Initial project structure
- Core NMEA parsing framework
- Basic serial communication
- DuckDB integration

---

[Unreleased]: https://github.com/vpatrinica/adcp-recorder/compare/v0.1.2...HEAD
[0.1.2]: https://github.com/vpatrinica/adcp-recorder/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/vpatrinica/adcp-recorder/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/vpatrinica/adcp-recorder/releases/tag/v0.1.0
