#!/usr/bin/env python3
"""
Stealerlo.gs MCP Server - Python Implementation
Model Context Protocol server for Stealerlo.gs API

All endpoints use API key authentication (X-API-Key header).
Get your API key from https://search.stealerlo.gs
"""

import asyncio
import json
import os
import signal
import sys
from typing import Any, Dict, List, Optional

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
import httpx


API_BASE_URL = os.getenv("STEALERLO_API_URL", "https://api.stealerlo.gs")

# Create server instance
server = Server("stealerlogs-mcp-server")


def format_results(data: Any, max_items: int = 10) -> str:
    """Format API results for readable output"""
    if isinstance(data, dict):
        return json.dumps(data, indent=2, default=str)
    return str(data)


def get_headers(api_key: str) -> Dict[str, str]:
    """Get standard headers with API key"""
    return {
        "X-API-Key": api_key,
        "Content-Type": "application/json",
    }


# =============================================================================
# TOOL DEFINITIONS
# =============================================================================

@server.list_tools()
async def list_tools() -> list[Tool]:
    """List all available tools"""
    return [
        # --- Core Search ---
        Tool(
            name="search",
            description="""Search the Stealerlo.gs database (12B+ records) for breach data.

Supports searching by: email, username, password, domain/site, phone, IP, name, uuid.
Returns credentials, machine data, and breach information.

Examples:
- Email: query="user@example.com", type="email"
- Domain: query="example.com", type="domain" 
- Password: query="password123", type="password"
- Wildcard: query="*@company.com", type="email", wildcard=true""",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (email, username, password, domain, IP, phone, name, uuid)",
                    },
                    "type": {
                        "type": "string",
                        "enum": ["email", "username", "password", "site", "website", "domain", "phone", "ip", "name", "uuid"],
                        "description": "Type of search",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key (format: slgs_...)",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Maximum results (default: 100, max: 1000)",
                        "default": 100,
                    },
                    "offset": {
                        "type": "integer",
                        "description": "Result offset for pagination",
                        "default": 0,
                    },
                    "useRegex": {
                        "type": "boolean",
                        "description": "Enable regex pattern matching",
                        "default": False,
                    },
                    "wildcard": {
                        "type": "boolean",
                        "description": "Enable wildcard pattern matching",
                        "default": False,
                    },
                    "dateFrom": {
                        "type": "string",
                        "description": "Filter from date (YYYY-MM-DD)",
                    },
                    "dateTo": {
                        "type": "string",
                        "description": "Filter to date (YYYY-MM-DD)",
                    },
                },
                "required": ["query", "type", "apiKey"],
            },
        ),
        
        # --- OSINT Proxy ---
        Tool(
            name="osint_search",
            description="""Search external OSINT providers through Stealerlo.gs proxy.

Providers:
- snusbase: Leak data and credential intelligence
- osintdog: Multiple OSINT services (HackCheck, BreachBase, etc.)
- shodan: Internet-wide scanning & host intelligence
- intelx: Intelligence X (requires Enterprise plan)

Examples:
- Snusbase email: provider="snusbase", action="search", query={"email": "user@example.com"}
- Snusbase domain: provider="snusbase", action="search", query={"domain": "example.com"}
- Shodan host: provider="shodan", action="host", query={"ip": "8.8.8.8"}
- OSINTDog: provider="osintdog", action="database", query={"query": "user@example.com", "search_type": "email"}""",
            inputSchema={
                "type": "object",
                "properties": {
                    "provider": {
                        "type": "string",
                        "enum": ["snusbase", "osintdog", "shodan", "intelx"],
                        "description": "OSINT provider to query",
                    },
                    "action": {
                        "type": "string",
                        "description": "Provider-specific action (e.g., 'search', 'host', 'database')",
                    },
                    "query": {
                        "type": "object",
                        "description": "Provider-specific query payload",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["provider", "action", "query", "apiKey"],
            },
        ),
        
        # --- Hash Search ---
        Tool(
            name="hash_search",
            description="""Search for hash plaintexts. Supports MD5, SHA1, SHA256, NTLM.
Batch search up to 100 hashes per request.

Example: terms=["5d41402abc4b2a76b9719d911017c592"]""",
            inputSchema={
                "type": "object",
                "properties": {
                    "terms": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Array of hashes to search (max 100)",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["terms", "apiKey"],
            },
        ),
        
        # --- IP Lookup ---
        Tool(
            name="ip_lookup",
            description="""Get geolocation and network information for IP addresses.
Batch lookup up to 100 IPs. Returns: city, country, ISP, AS, coordinates, timezone.

Example: terms=["8.8.8.8", "1.1.1.1"]""",
            inputSchema={
                "type": "object",
                "properties": {
                    "terms": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Array of IP addresses (max 100)",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["terms", "apiKey"],
            },
        ),
        
        # --- Phone Lookup ---
        Tool(
            name="phone_lookup",
            description="""Reverse phone number lookup. Get caller name, carrier, location, phone type.
Batch lookup up to 10 numbers. Supports international numbers.

Example: terms=["+19739833179"]""",
            inputSchema={
                "type": "object",
                "properties": {
                    "terms": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Array of phone numbers (max 10)",
                    },
                    "countryCode": {
                        "type": "string",
                        "description": "Optional country code for disambiguation (e.g., '1' for US)",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["terms", "apiKey"],
            },
        ),
        
        # --- Machine Info ---
        Tool(
            name="machine_info",
            description="""Get comprehensive system information for a machine by UUID.
Returns: hardware specs, OS, network info, installed software, processes.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "uuid": {
                        "type": "string",
                        "description": "Machine UUID from search results",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["uuid", "apiKey"],
            },
        ),
        
        # --- Machine Files ---
        Tool(
            name="machine_files",
            description="""Get files from a machine by UUID.

File types:
- all_passwords: All password/credential files
- all_txt_files: All txt files from the machine
- passwords: Single password file (if only one exists)
- common_files: Download compressed Common Files archive""",
            inputSchema={
                "type": "object",
                "properties": {
                    "machine_id": {
                        "type": "string",
                        "description": "Machine UUID",
                    },
                    "file_type": {
                        "type": "string",
                        "enum": ["all_passwords", "all_txt_files", "passwords", "common_files"],
                        "description": "Type of files to retrieve",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["machine_id", "file_type", "apiKey"],
            },
        ),
        
        # --- Social Media Analysis ---
        Tool(
            name="analyze",
            description="""Find social media accounts across platforms for a username or email.
Groups results by platform and returns account details.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Username or email to analyze",
                    },
                    "platform": {
                        "type": "string",
                        "description": "Filter by platform (default: 'all')",
                        "default": "all",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["query", "apiKey"],
            },
        ),
        
        # --- Count ---
        Tool(
            name="count",
            description="""Get count of results for a search query without fetching full results.
Useful for estimating result size before running full search.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "type": {
                        "type": "string",
                        "enum": ["email", "username", "password", "site", "website", "domain", "phone", "ip", "name", "uuid"],
                        "description": "Type of search",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["query", "type", "apiKey"],
            },
        ),
        
        # --- Domain Employee Search ---
        Tool(
            name="search_domain_employees",
            description="""Search for employees/emails from a specific domain and filter by file types.
Finds machines associated with domain emails and returns credential files.

Example: domain="samsung.com", fileTypes=["password", "cookies"]""",
            inputSchema={
                "type": "object",
                "properties": {
                    "domain": {
                        "type": "string",
                        "description": "Domain to search (e.g., 'samsung.com')",
                    },
                    "fileTypes": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "File types to filter (e.g., ['password', 'cookies'])",
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max emails to search (1-500)",
                        "default": 100,
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["domain", "apiKey"],
            },
        ),
        
        # --- TruffleHog Secret Scan ---
        Tool(
            name="scan_secrets",
            description="""Scan content for exposed secrets, API keys, passwords using TruffleHog.
Detects 750+ secret types including AWS keys, GitHub tokens, database credentials.""",
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {
                        "type": "string",
                        "description": "Text content to scan for secrets",
                    },
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["content", "apiKey"],
            },
        ),
        
        # --- Health Check ---
        Tool(
            name="health",
            description="Check API health status. No authentication required.",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        
        # --- Database Stats ---
        Tool(
            name="stats",
            description="Get total record count in the database.",
            inputSchema={
                "type": "object",
                "properties": {
                    "apiKey": {
                        "type": "string",
                        "description": "Your Stealerlo.gs API key",
                    },
                },
                "required": ["apiKey"],
            },
        ),
    ]


# =============================================================================
# TOOL HANDLERS - Return list[TextContent] for MCP SDK
# =============================================================================

async def handle_search(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle search tool"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required. Get one at https://search.stealerlo.gs")]
    
    payload = {
        "query": args.get("query"),
        "type": args.get("type"),
    }
    
    # Optional parameters
    for key in ["limit", "offset", "useRegex", "wildcard", "dateFrom", "dateTo"]:
        if key in args and args[key] is not None:
            payload[key] = args[key]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/search",
            headers=get_headers(api_key),
            json=payload
        )
        response.raise_for_status()
        data = response.json()
        
        # Format results nicely
        total = data.get("total", 0)
        results = data.get("results", [])
        took = data.get("took", 0)
        
        output = f"## Search Results\n\n"
        output += f"**Query:** `{args.get('query')}` (type: {args.get('type')})\n"
        output += f"**Total:** {total} results | **Returned:** {len(results)} | **Time:** {took}ms\n\n"
        
        if results:
            output += "### Results\n\n"
            for i, result in enumerate(results[:20], 1):
                output += f"**{i}.** "
                if result.get("email"):
                    output += f"Email: `{result['email']}` "
                if result.get("username"):
                    output += f"User: `{result['username']}` "
                if result.get("password"):
                    output += f"Pass: `{result['password']}` "
                if result.get("site"):
                    output += f"Site: `{result['site']}` "
                if result.get("source", {}).get("machine_id"):
                    output += f"Machine: `{result['source']['machine_id']}`"
                output += "\n"
            
            if len(results) > 20:
                output += f"\n... and {len(results) - 20} more results\n"
        else:
            output += "No results found.\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_osint_search(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle OSINT proxy search"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    payload = {
        "provider": args.get("provider"),
        "action": args.get("action"),
        "query": args.get("query"),
    }
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/source",
            headers=get_headers(api_key),
            json=payload,
            timeout=60.0
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## OSINT Search Results\n\n"
        output += f"**Provider:** {args.get('provider')} | **Action:** {args.get('action')}\n\n"
        output += "```json\n"
        output += json.dumps(data, indent=2, default=str)[:5000]
        output += "\n```\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_hash_search(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle hash search"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/hashsearch",
            headers=get_headers(api_key),
            json={"terms": args.get("terms", [])}
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Hash Search Results\n\n"
        output += f"**Searched:** {len(args.get('terms', []))} hashes | **Time:** {data.get('took', 0)}ms\n\n"
        
        results = data.get("results", {})
        if results:
            output += "### Found\n\n"
            for hash_val, info in results.items():
                plaintext = info.get("plaintext", "Not found")
                hash_type = info.get("type", "unknown")
                output += f"- `{hash_val[:20]}...` ({hash_type}) → `{plaintext}`\n"
        else:
            output += "No plaintexts found.\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_ip_lookup(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle IP geolocation lookup"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/iplookup",
            headers=get_headers(api_key),
            json={"terms": args.get("terms", [])}
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## IP Lookup Results\n\n"
        
        results = data.get("results", {})
        for ip, info in results.items():
            output += f"### {ip}\n"
            output += f"- **Location:** {info.get('city', 'N/A')}, {info.get('country', 'N/A')}\n"
            output += f"- **ISP:** {info.get('isp', 'N/A')}\n"
            output += f"- **AS:** {info.get('as', 'N/A')}\n"
            output += f"- **Coords:** {info.get('lat', 'N/A')}, {info.get('lon', 'N/A')}\n"
            output += f"- **Timezone:** {info.get('timezone', 'N/A')}\n\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_phone_lookup(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle phone number lookup"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    payload = {"terms": args.get("terms", [])}
    if args.get("countryCode"):
        payload["countryCode"] = args["countryCode"]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/phonelookup",
            headers=get_headers(api_key),
            json=payload
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Phone Lookup Results\n\n"
        
        results = data.get("results", {})
        for phone, info in results.items():
            output += f"### {info.get('formatted_number', phone)}\n"
            output += f"- **Name:** {info.get('name', 'Unknown')}\n"
            output += f"- **Location:** {info.get('location', 'N/A')}\n"
            output += f"- **Type:** {info.get('phone_type', 'N/A')}\n"
            carriers = info.get("carriers", [])
            if carriers:
                output += f"- **Carrier:** {carriers[0].get('company', 'N/A')}\n"
            output += "\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_machine_info(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle machine info lookup"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.get(
            f"{API_BASE_URL}/machineinfo",
            headers=get_headers(api_key),
            params={"uuid": args.get("uuid")}
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Machine Information\n\n"
        output += f"**UUID:** `{args.get('uuid')}`\n\n"
        output += f"- **Computer:** {data.get('computerName', 'N/A')}\n"
        output += f"- **User:** {data.get('userName', 'N/A')}\n"
        output += f"- **OS:** {data.get('osVersion', 'N/A')}\n"
        output += f"- **IP:** {data.get('ipAddress', 'N/A')}\n"
        output += f"- **CPU:** {data.get('cpu', 'N/A')}\n"
        output += f"- **RAM:** {data.get('ram', 'N/A')}\n"
        output += f"- **GPU:** {data.get('gpu', 'N/A')}\n"
        
        apps = data.get("installedApps", [])
        if apps:
            output += f"\n**Installed Apps:** {len(apps)} apps\n"
            for app in apps[:10]:
                output += f"  - {app}\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_machine_files(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle machine files retrieval"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.get(
            f"{API_BASE_URL}/machine-files",
            headers=get_headers(api_key),
            params={
                "machine_id": args.get("machine_id"),
                "type": args.get("file_type")
            }
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Machine Files\n\n"
        output += f"**Machine:** `{args.get('machine_id')}`\n"
        output += f"**Type:** {args.get('file_type')}\n\n"
        
        files = data.get("files", [])
        output += f"**Found:** {len(files)} files\n\n"
        
        for f in files[:10]:
            output += f"### {f.get('file_name', 'Unknown')}\n"
            output += f"Path: `{f.get('file_path', 'N/A')}`\n"
            content = f.get("content", "")
            if content:
                output += f"```\n{content[:1000]}\n```\n"
            output += "\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_analyze(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle social media analysis"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    payload = {"query": args.get("query")}
    if args.get("platform"):
        payload["platform"] = args["platform"]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/analyze",
            headers=get_headers(api_key),
            json=payload
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Social Media Analysis\n\n"
        output += f"**Query:** `{args.get('query')}`\n\n"
        
        platforms = data.get("platforms", [])
        for p in platforms:
            if p.get("found"):
                output += f"### {p.get('platform', 'Unknown')}\n"
                output += f"Username: `{p.get('username', 'N/A')}`\n"
                output += f"Accounts: {p.get('accountCount', 0)}\n\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_count(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle count query"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/count",
            headers=get_headers(api_key),
            json={
                "query": args.get("query"),
                "type": args.get("type")
            }
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Count Results\n\n"
        output += f"**Query:** `{args.get('query')}` (type: {args.get('type')})\n"
        output += f"**Count:** {data.get('count', 0):,} results\n"
        output += f"**Time:** {data.get('took', 0)}ms\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_domain_employees(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle domain employee search"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    payload = {
        "domain": args.get("domain"),
        "async": False,  # Synchronous mode for MCP
        "limit": args.get("limit", 50),
    }
    if args.get("fileTypes"):
        payload["fileTypes"] = args["fileTypes"]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/search-domain-files",
            headers=get_headers(api_key),
            json=payload,
            timeout=120.0
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Domain Employee Search\n\n"
        output += f"**Domain:** `{args.get('domain')}`\n"
        output += f"**File Types:** {args.get('fileTypes', ['all'])}\n\n"
        
        results = data.get("results", [])
        output += f"**Found:** {len(results)} machines with matching employees\n\n"
        
        for r in results[:10]:
            output += f"### Machine: `{r.get('machine_id', 'N/A')[:12]}...`\n"
            emails = r.get("emails", [])
            for e in emails[:5]:
                output += f"- `{e.get('email')}` : `{e.get('password', 'N/A')}`\n"
            files = r.get("files", [])
            if files:
                output += f"Files: {len(files)} matching\n"
            output += "\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_scan_secrets(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle TruffleHog secret scanning"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.post(
            f"{API_BASE_URL}/trufflehog",
            headers=get_headers(api_key),
            json={"content": args.get("content")}
        )
        response.raise_for_status()
        data = response.json()
        
        output = f"## Secret Scan Results\n\n"
        output += f"**Secrets Found:** {data.get('secretsFound', 0)}\n\n"
        
        results = data.get("results", [])
        for r in results:
            output += f"### {r.get('detectorName', 'Unknown')}\n"
            output += f"- **Verified:** {'✅' if r.get('verified') else '❌'}\n"
            output += f"- **Redacted:** `{r.get('redacted', 'N/A')}`\n"
            output += f"- **Line:** {r.get('line', 'N/A')}\n\n"
        
        return [TextContent(type="text", text=output)]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_health(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle health check"""
    try:
        response = await client.get(f"{API_BASE_URL}/health")
        response.raise_for_status()
        data = response.json()
        
        return [TextContent(
            type="text",
            text=f"## API Health\n\n**Status:** {data.get('status', 'unknown')}\n**Timestamp:** {data.get('timestamp', 'N/A')}"
        )]
        
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


async def handle_stats(client: httpx.AsyncClient, args: Dict[str, Any]) -> list[TextContent]:
    """Handle database stats"""
    api_key = args.get("apiKey")
    if not api_key:
        return [TextContent(type="text", text="Error: apiKey is required")]
    
    try:
        response = await client.get(
            f"{API_BASE_URL}/count",
            headers=get_headers(api_key)
        )
        response.raise_for_status()
        data = response.json()
        
        count = data.get("count", 0)
        return [TextContent(
            type="text",
            text=f"## Database Statistics\n\n**Total Records:** {count:,}"
        )]
        
    except httpx.HTTPStatusError as e:
        return [TextContent(type="text", text=f"Error: HTTP {e.response.status_code}: {e.response.text}")]
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {str(e)}")]


# =============================================================================
# TOOL ROUTER
# =============================================================================

@server.call_tool()
async def call_tool(name: str, arguments: Dict[str, Any]) -> list[TextContent]:
    """Route tool calls to handlers"""
    async with httpx.AsyncClient(timeout=60.0) as client:
        handlers = {
            "search": handle_search,
            "osint_search": handle_osint_search,
            "hash_search": handle_hash_search,
            "ip_lookup": handle_ip_lookup,
            "phone_lookup": handle_phone_lookup,
            "machine_info": handle_machine_info,
            "machine_files": handle_machine_files,
            "analyze": handle_analyze,
            "count": handle_count,
            "search_domain_employees": handle_domain_employees,
            "scan_secrets": handle_scan_secrets,
            "health": handle_health,
            "stats": handle_stats,
        }
        
        handler = handlers.get(name)
        if handler:
            return await handler(client, arguments)
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]


# =============================================================================
# SERVER ENTRY POINT
# =============================================================================

async def _run_server():
    """Async server runner"""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def main():
    """Main entry point for the MCP server (console script)"""
    def signal_handler(signum, frame):
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        asyncio.run(_run_server())
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
