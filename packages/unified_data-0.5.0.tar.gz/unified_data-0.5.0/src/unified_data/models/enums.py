from enum import StrEnum

class MarketType(StrEnum):
    CRYPTO = "crypto"
    STOCK = "stock"
    FUTURES = "futures"

class Columns(StrEnum):
    """Standardized column names for the output DataFrame."""
    TIMESTAMP = "ts"
    OPEN = "open"
    HIGH = "high"
    LOW = "low"
    CLOSE = "close"
    VOLUME = "vol"
    SYMBOL = "symbol"
    EXCHANGE = "exchange"  # Useful when aggregating multiple sources

class Exchange(StrEnum):
    """Supported exchanges / sources."""
    BINANCE = "binance"
    CCXT = "ccxt"  # As a generic fallback or specific source
    YFINANCE = "yfinance"
    AKSHARE = "akshare"
    TQSDK = "tqsdk"
    COINBASE = "coinbase"

class CcxtExchange(StrEnum):
    """Supported CCXT exchanges."""
    BINANCE = "binance"
    COINBASE = "coinbase"

class TimeFramePeriod(StrEnum):
    """Standardized time frame periods."""
    D1 = "1d"
    W1 = "1w"
    M1 = "1M"

class Status(StrEnum):
    OK = "OK"
    FAILED = "FAILED"

class Market(StrEnum):
    HK = "HK"
    A_SHARE = "A-SHARE"
    UNKNOWN = "UNKNOWN"
