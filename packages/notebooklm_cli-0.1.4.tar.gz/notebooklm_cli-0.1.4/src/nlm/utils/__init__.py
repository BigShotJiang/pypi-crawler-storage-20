"""Utility functions for NLM."""
