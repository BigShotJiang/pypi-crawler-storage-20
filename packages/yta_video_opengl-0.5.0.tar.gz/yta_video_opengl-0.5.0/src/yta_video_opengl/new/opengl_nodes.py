"""
TODO: These nodes are here because they must
be moved to the 'yta_editor_nodes_gpu'.
"""
from yta_video_opengl.new.node import _OpenGLNode
from yta_validation.parameter import ParameterValidator
from typing import Union

import moderngl


# TODO: We need to create the specific _OpenGLNode
# implementations that assign the pipelines and
# contexts specifically and ask for the uniforms it
# can use directly as parameters. But we also need
# the specific _OpenGLPipeline that include the
# shaders we want to apply for a specific purpose

# TODO: This is just an example below and shouldn't
# be in this proyect but in 'yta_editor_nodes_gpu'    
class _SingleTextureOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a single texture called
    `base_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.
    """

    def _get_textures_map(
        self,
        input: moderngl.Texture
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'base_texture': input
        }
    
    def process(
        self,
        input: moderngl.Texture,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `input` provided and get an output
        of the given `output_size` by using the
        `**dynamic_uniforms` if needed.
        """
        # This one is exactly the same than the parent
        return super().process(
            input = input,
            output_size = output_size,
            **dynamic_uniforms
        )
# TODO: Create the other types but in the
# 'yta_editor_nodes_gpu' library
        
class _BaseAndOverlayTexturesOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a base texture called
    `base_texture` and an overlay texture named as
    `overlay_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.
    """

    def _get_textures_map(
        self,
        base_input: moderngl.Texture,
        overlay_input: moderngl.Texture
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'base_texture': base_input,
            'overlay_texture': overlay_input
        }
    
    def process(
        self,
        base_input: moderngl.Texture,
        overlay_input: moderngl.Texture,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `base_input` and `ovelray_input`
        provided and get an output of the given
        `output_size` by using the `**dynamic_uniforms`
        if needed.
        """
        ParameterValidator.validate_mandatory_instance_of('base_input', base_input, moderngl.Texture)
        ParameterValidator.validate_mandatory_instance_of('overlay_input', overlay_input, moderngl.Texture)

        textures_map = self._get_textures_map(
            base_input = base_input,
            overlay_input = overlay_input
        )

        return self._process_common(
            textures_map = textures_map,
            output_size = output_size,
            **dynamic_uniforms
        )
    
class _FirstAndSecondTexturesOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a first texture called
    `first_texture` and a second texture named as
    `second_texture` in the shaders. This class must 
    be inherited by the specific nodes that use this
    single texture to make changes.

    This is more specific for transitions or changes
    in which we go from a first texture to a second
    one somehow.
    """

    def _get_textures_map(
        self,
        first_input: moderngl.Texture,
        second_input: moderngl.Texture
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'first_texture': first_input,
            'second_texture': second_input
        }
    
    def process(
        self,
        first_input: moderngl.Texture,
        second_input: moderngl.Texture,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `first_input` and `second_input`
        provided and get an output of the given
        `output_size` by using the `**dynamic_uniforms`
        if needed.
        """
        ParameterValidator.validate_mandatory_instance_of('first_input', first_input, moderngl.Texture)
        ParameterValidator.validate_mandatory_instance_of('second_input', second_input, moderngl.Texture)

        textures_map = self._get_textures_map(
            first_input = first_input,
            second_input = second_input
        )

        return self._process_common(
            textures_map = textures_map,
            output_size = output_size,
            **dynamic_uniforms
        )
    
class _OriginalProcessedSelectionOpenGLNode(_OpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses one texture called
    `original_texture` and a second texture named as
    `processed_texture`, with also another one called
    `selection_mask_texture`, in the shaders. This
    class must be inherited by the specific nodes that
    use this single texture to make changes.

    This is specific for applying the selection mask
    to mix the `processed_texture` with the original
    one.
    """

    def _get_textures_map(
        self,
        original_input: moderngl.Texture,
        processed_input: moderngl.Texture,
        selection_mask_input: moderngl.Texture,
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        return {
            'original_texture': original_input,
            'processed_texture': processed_input,
            'selection_mask_texture': selection_mask_input
        }
    
    def process(
        self,
        original_input: moderngl.Texture,
        processed_input: moderngl.Texture,
        selection_mask_input: moderngl.Texture,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `original_input`, `processed_input` and
        `selection_mask_input` provided and get an output of
        the given `output_size` by using the `**dynamic_uniforms`
        if needed.
        """
        ParameterValidator.validate_mandatory_instance_of('original_input', original_input, moderngl.Texture)
        ParameterValidator.validate_mandatory_instance_of('processed_input', processed_input, moderngl.Texture)
        ParameterValidator.validate_mandatory_instance_of('selection_mask_input', selection_mask_input, moderngl.Texture)

        textures_map = self._get_textures_map(
            original_input = original_input,
            processed_input = processed_input,
            selection_mask_input = selection_mask_input
        )

        return self._process_common(
            textures_map = textures_map,
            output_size = output_size,
            **dynamic_uniforms
        )