from yta_video_opengl.new.pipeline import _OpenGLPipeline
from yta_video_opengl.new.opengl_nodes import _SingleTextureOpenGLNode


"""
TODO: This below is an example of how easy would
declaring a new node would be.
"""
class _ColorContrastOpenGLPipeline(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to modify the color contrast
    of the textures we receive as input.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330

            uniform sampler2D base_texture;
            uniform float factor;
            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                vec4 color = texture(base_texture, v_uv);
                vec3 mean = vec3(0.5);
                color.rgb = (color.rgb - mean) * factor + mean;
                output_color = vec4(clamp(color.rgb, 0.0, 1.0), color.a);
            }
            '''
        )
    
class ColorContrastOpenGLNode(_SingleTextureOpenGLNode):
    """
    A node to modify the color contrast of the
    textures that come as inputs.
    """

    def __init__(
        self,
        # TODO: Maybe provide a context (?)
        factor: float = 1.5
    ):
        super().__init__(
            opengl_pipeline = _ColorContrastOpenGLPipeline(
                opengl_context = None
            ),
            factor = factor
        )
"""
TODO: This above is an example of how easy
declaring a new node would be.
"""