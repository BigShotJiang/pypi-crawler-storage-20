from dataclasses import dataclass
from typing import Union

import moderngl


"""
TODO: This '_OpenGLTextureBinded' and '_Textures'
classes will be @deprecated soon...
"""
@dataclass
class _OpenGLTextureBinded:
    """
    *For internal use only*

    Texture to use within an OpenGL class, binding
    a location and simplifying the way we handle
    it.
    """

    def __init__(
        self,
        # Can I pass the object that holds this (?)
        # opengl_context: moderngl.Context,
        uniforms: 'Uniforms',
        name: str,
        unit: int,
    ):
        # TODO: Validate parameters (?)

        self.name: str = name
        """
        The name of the uniform associated with this
        texture.
        """
        self.unit: int = unit
        """
        The unit (or location) of this texture within
        the OpenGL context.
        """
        # No longer being used as we don't accept numpys
        # self._handler: _OpenGLTextureHandler = _OpenGLTextureHandler(self._node.context)
        # """
        # The handler of this texture.
        # """

        # Assign the unit to the uniform
        uniforms.set(self.name, self.unit)

    def update(
        self,
        input: moderngl.Texture
    ) -> '_OpenGLTextureBinded':
        """
        Update the content of the texture and set it to be
        used in its unit.
        """
        # We are no longer accepting 'ndarray'
        # input = (
        #     self._handler.update(input)
        #     if PythonValidator.is_numpy_array(input) else
        #     input
        # )
        # This sets the 'input' texture in the unit
        input.use(location = self.unit)

        return self

class _Textures:
    """
    *For internal use only*

    Class to wrap the functionality related to
    handling the opengl program textures.
    """

    @property
    def textures(
        self
    ) -> dict:
        """
        The internal dictionary to handle the different
        textures, mapping them by their names.
        """
        if not hasattr(self, '_textures'):
            self._textures = {}

        return self._textures

    def __init__(
        self,
        # opengl_context: moderngl.Context,
        uniforms: 'Uniforms'
    ):
        # self._opengl_context: moderngl.Context = opengl_context
        # """
        # The context that will be used for this instance.
        # """
        self._uniforms: 'Uniforms' = uniforms
        """
        The uniforms we need to associate the textures with.
        """
        # Force creation
        self.textures

    def get(
        self,
        name: str
    ) -> Union[_OpenGLTextureBinded, None]:
        """
        Get the texture with the given `name`.
        """
        return self.textures.get(name, None)
    
    def add(
        self,
        name: str,
        unit: Union[int, None] = None
    ) -> '_Textures':
        """
        Add a new texture binded to the internal dict. This
        will replace and old texture if the `name` provided
        was previously stored.
        """
        unit = (
            len(self.textures)
            if unit is None else
            unit
        )

        self._textures[name] = _OpenGLTextureBinded(
            # opengl_context = self._opengl_context,
            uniforms = self._uniforms,
            name = name,
            unit = unit
        )

        return self
    
    def update(
        self,
        name: str,
        input: moderngl.Texture
    ) -> '_Textures':
        """
        Update the content of the texture with the given
        `name` by setting the provided `input` and set
        it to be used in its unit (location).
        """
        self.get(name).update(input)

        return self
    



# The new classes I will preserve
@dataclass
class _PipelineTexture:
    """
    *For internal use only*

    *Dataclass*

    Dataclass to store a texture and the name associated
    that must be used to set it in the program through
    the pipeline.
    """
    
    def __init__(
        self,
        name: str,
        opengl_texture: Union[moderngl.Texture, None]
    ):
        self.name: str = name
        """
        The name of the texture that is being used in the
        shaders.
        """
        self.opengl_texture: Union[moderngl.Texture, None] = opengl_texture
        """
        The `moderngl.Texture` texture itself.
        """

@dataclass
class PipelineTextures:
    """
    *Dataclass*

    A dataclass to pass the textures to the pipeline
    to be able to render them properly, including the
    name and the texture itself.
    """
    
    def __init__(
        self,
        textures: list[_PipelineTexture] = []
    ):
        self.textures: list[_PipelineTexture] = textures
        """
        Our list of textures to handle them easy.
        """

    def get(
        self,
        name: str
    ) -> Union[_PipelineTexture, None]:
        """
        Gete the texture with the given `name` if
        existing.
        """
        return next(
            (
                texture
                for texture in self.textures
                if texture.name == name
            ),
            None
        )
    
    def set(
        self,
        name: str,
        opengl_texture: moderngl.Texture
    ) -> 'PipelineTextures':
        """
        Set the `texture` provided as the one to be
        used in the location of the registered
        texture with the `name` provided.

        The code:
        - `texture.use(location = self._textures[name])`
        """
        texture_object = self.get(name)

        if texture_object is not None:
            texture_object.opengl_texture = opengl_texture
        else:
            self.textures.append(_PipelineTexture(
                    name = name,
                    opengl_texture = opengl_texture
                )
            )

        return self