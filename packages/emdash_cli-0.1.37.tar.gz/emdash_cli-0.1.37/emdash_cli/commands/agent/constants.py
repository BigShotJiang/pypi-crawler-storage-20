"""Constants and enums for the agent CLI."""

from enum import Enum


class AgentMode(Enum):
    """Agent operation modes."""
    PLAN = "plan"
    CODE = "code"


# Slash commands available in interactive mode
SLASH_COMMANDS = {
    # Mode switching
    "/plan": "Switch to plan mode (explore codebase, create plans)",
    "/code": "Switch to code mode (execute file changes)",
    "/mode": "Show current mode",
    # Generation commands
    "/pr [url]": "Review a pull request",
    "/projectmd": "Generate PROJECT.md for the codebase",
    "/research [goal]": "Deep research on a topic",
    # Status commands
    "/status": "Show index and PROJECT.md status",
    "/agents": "Manage agents (interactive menu, or /agents [create|show|edit|delete] <name>)",
    # Todo management
    "/todos": "Show current agent todo list",
    "/todo-add [title]": "Add a todo item for the agent (e.g., /todo-add Fix tests)",
    # Session management
    "/session": "Save, load, or list sessions (e.g., /session save my-task)",
    "/spec": "Show current specification",
    "/reset": "Reset session state",
    # Hooks
    "/hooks": "Manage hooks (list, add, remove, toggle)",
    # Rules
    "/rules": "Manage rules (list, add, delete)",
    # MCP
    "/mcp": "Manage global MCP servers (list, edit)",
    # Auth
    "/auth": "GitHub authentication (login, logout, status)",
    # Context
    "/context": "Show current context frame (tokens, reranked items)",
    "/help": "Show available commands",
    "/quit": "Exit the agent",
}
