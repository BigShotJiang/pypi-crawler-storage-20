"""Handler for /todos and /todo-add commands."""

from rich.console import Console

console = Console()


def handle_todos(args: str, client, session_id: str | None, pending_todos: list[str]) -> None:
    """Handle /todos command.

    Args:
        args: Command arguments (unused)
        client: EmdashClient instance
        session_id: Current session ID
        pending_todos: List of pending todos (before session starts)
    """
    if not session_id:
        if pending_todos:
            console.print("\n[bold cyan]Pending Todos[/bold cyan] [dim](will be added when session starts)[/dim]\n")
            for i, todo in enumerate(pending_todos, 1):
                console.print(f"  [dim]⬚[/dim] {todo}")
            console.print()
        else:
            console.print("\n[dim]No todos yet. Start a conversation and the agent will track its tasks here.[/dim]\n")
    else:
        try:
            result = client.get_todos(session_id)
            todos = result.get("todos", [])
            summary = result.get("summary", {})

            if not todos:
                console.print("\n[dim]No todos in current session.[/dim]\n")
            else:
                console.print("\n[bold cyan]Agent Todo List[/bold cyan]\n")

                # Status icons
                icons = {
                    "pending": "[dim]⬚[/dim]",
                    "in_progress": "[yellow]🔄[/yellow]",
                    "completed": "[green]✓[/green]",
                }

                for todo in todos:
                    icon = icons.get(todo["status"], "?")
                    title = todo["title"]
                    status = todo["status"]

                    if status == "completed":
                        console.print(f"  {icon} [dim strikethrough]{title}[/dim strikethrough]")
                    elif status == "in_progress":
                        console.print(f"  {icon} [bold]{title}[/bold]")
                    else:
                        console.print(f"  {icon} {title}")

                    if todo.get("description"):
                        desc = todo["description"]
                        if len(desc) > 60:
                            console.print(f"      [dim]{desc[:60]}...[/dim]")
                        else:
                            console.print(f"      [dim]{desc}[/dim]")

                console.print()
                console.print(
                    f"[dim]Total: {summary.get('total', 0)} | "
                    f"Pending: {summary.get('pending', 0)} | "
                    f"In Progress: {summary.get('in_progress', 0)} | "
                    f"Completed: {summary.get('completed', 0)}[/dim]"
                )
                console.print()

        except Exception as e:
            console.print(f"[red]Error fetching todos: {e}[/red]")


def handle_todo_add(args: str, client, session_id: str | None, pending_todos: list[str]) -> None:
    """Handle /todo-add command.

    Args:
        args: Todo title to add
        client: EmdashClient instance
        session_id: Current session ID
        pending_todos: List of pending todos (before session starts)
    """
    if not args:
        console.print("[yellow]Usage: /todo-add <title>[/yellow]")
        console.print("[dim]Example: /todo-add Fix the failing tests[/dim]")
    elif not session_id:
        pending_todos.append(args)
        console.print(f"[green]Todo noted:[/green] {args}")
        console.print("[dim]This will be added to the agent's context when you start a conversation.[/dim]")
    else:
        try:
            result = client.add_todo(session_id, args)
            task = result.get("task", {})
            console.print(f"[green]Added todo #{task.get('id')}: {task.get('title')}[/green]")
            console.print(f"[dim]Total tasks: {result.get('total_tasks', 0)}[/dim]")
        except Exception as e:
            console.print(f"[red]Error adding todo: {e}[/red]")
