"""Handler for /agents command."""

import os
import subprocess
from pathlib import Path

from rich.console import Console
from rich.panel import Panel

from ..menus import show_agents_interactive_menu, prompt_agent_name, confirm_delete

console = Console()


def create_agent(name: str) -> bool:
    """Create a new agent with the given name."""
    agents_dir = Path.cwd() / ".emdash" / "agents"
    agent_file = agents_dir / f"{name}.md"

    if agent_file.exists():
        console.print(f"[yellow]Agent '{name}' already exists[/yellow]")
        return False

    agents_dir.mkdir(parents=True, exist_ok=True)

    template = f'''---
description: Custom agent for specific tasks
tools: [grep, glob, read_file, semantic_search]
---

# System Prompt

You are a specialized assistant for {name.replace("-", " ")} tasks.

## Your Mission

Describe what this agent should accomplish:
- Task 1
- Task 2
- Task 3

## Approach

1. **Step One**
   - Details about the first step

2. **Step Two**
   - Details about the second step

## Output Format

Describe how the agent should format its responses.
'''
    agent_file.write_text(template)
    console.print(f"[green]Created agent: {name}[/green]")
    console.print(f"[dim]File: {agent_file}[/dim]")
    return True


def show_agent_details(name: str) -> None:
    """Show detailed view of an agent."""
    from emdash_core.agent.toolkits import get_custom_agent

    builtin_agents = ["Explore", "Plan"]

    console.print()
    console.print("[dim]─" * 50 + "[/dim]")
    console.print()
    if name in builtin_agents:
        console.print(f"[bold cyan]{name}[/bold cyan] [dim](built-in)[/dim]\n")
        if name == "Explore":
            console.print("[bold]Description:[/bold] Fast codebase exploration (read-only)")
            console.print("[bold]Tools:[/bold] glob, grep, read_file, list_files, semantic_search")
        elif name == "Plan":
            console.print("[bold]Description:[/bold] Design implementation plans")
            console.print("[bold]Tools:[/bold] glob, grep, read_file, list_files, semantic_search")
        console.print("\n[dim]Built-in agents cannot be edited or deleted.[/dim]")
    else:
        agent = get_custom_agent(name, Path.cwd())
        if agent:
            console.print(f"[bold cyan]{agent.name}[/bold cyan] [dim](custom)[/dim]\n")

            # Show description
            if agent.description:
                console.print(f"[bold]Description:[/bold] {agent.description}")

            # Show model
            if agent.model:
                console.print(f"[bold]Model:[/bold] {agent.model}")

            # Show tools
            if agent.tools:
                console.print(f"[bold]Tools:[/bold] {', '.join(agent.tools)}")

            # Show MCP servers
            if agent.mcp_servers:
                console.print(f"\n[bold]MCP Servers:[/bold]")
                for server in agent.mcp_servers:
                    status = "[green]enabled[/green]" if server.enabled else "[dim]disabled[/dim]"
                    console.print(f"  [cyan]{server.name}[/cyan] ({status})")
                    console.print(f"    [dim]{server.command} {' '.join(server.args)}[/dim]")

            # Show file path
            if agent.file_path:
                console.print(f"\n[bold]File:[/bold] {agent.file_path}")

            # Show system prompt preview
            if agent.system_prompt:
                console.print(f"\n[bold]System Prompt Preview:[/bold]")
                preview = agent.system_prompt[:300]
                if len(agent.system_prompt) > 300:
                    preview += "..."
                console.print(Panel(preview, border_style="dim"))
        else:
            console.print(f"[yellow]Agent '{name}' not found[/yellow]")
    console.print()
    console.print("[dim]─" * 50 + "[/dim]")


def delete_agent(name: str) -> bool:
    """Delete a custom agent."""
    agents_dir = Path.cwd() / ".emdash" / "agents"
    agent_file = agents_dir / f"{name}.md"

    if not agent_file.exists():
        console.print(f"[yellow]Agent file not found: {agent_file}[/yellow]")
        return False

    if confirm_delete(name):
        agent_file.unlink()
        console.print(f"[green]Deleted agent: {name}[/green]")
        return True
    else:
        console.print("[dim]Cancelled[/dim]")
        return False


def edit_agent(name: str) -> None:
    """Open agent file in editor."""
    agents_dir = Path.cwd() / ".emdash" / "agents"
    agent_file = agents_dir / f"{name}.md"

    if not agent_file.exists():
        console.print(f"[yellow]Agent file not found: {agent_file}[/yellow]")
        return

    # Try to open in editor
    editor = os.environ.get("EDITOR", "")
    if not editor:
        # Try common editors
        for ed in ["code", "vim", "nano", "vi"]:
            try:
                subprocess.run(["which", ed], capture_output=True, check=True)
                editor = ed
                break
            except (subprocess.CalledProcessError, FileNotFoundError):
                continue

    if editor:
        console.print(f"[dim]Opening {agent_file} in {editor}...[/dim]")
        try:
            subprocess.run([editor, str(agent_file)])
        except Exception as e:
            console.print(f"[red]Failed to open editor: {e}[/red]")
            console.print(f"[dim]Edit manually: {agent_file}[/dim]")
    else:
        console.print(f"[yellow]No editor found. Edit manually:[/yellow]")
        console.print(f"  {agent_file}")


def chat_edit_agent(name: str, client, renderer, model, max_iterations, render_with_interrupt) -> None:
    """Start a chat session to edit an agent with AI assistance."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.styles import Style

    agents_dir = Path.cwd() / ".emdash" / "agents"
    agent_file = agents_dir / f"{name}.md"

    if not agent_file.exists():
        console.print(f"[yellow]Agent file not found: {agent_file}[/yellow]")
        return

    # Read current content
    content = agent_file.read_text()

    console.print()
    console.print(f"[bold cyan]Chat: Editing agent '{name}'[/bold cyan]")
    console.print("[dim]What would you like to change? Type 'done' to finish, Ctrl+C to cancel[/dim]")
    console.print()

    chat_style = Style.from_dict({
        "prompt": "#00cc66 bold",
    })

    ps = PromptSession(style=chat_style)
    chat_session_id = None
    first_message = True

    # Chat loop
    while True:
        try:
            user_input = ps.prompt([("class:prompt", "› ")]).strip()

            if not user_input:
                continue

            if user_input.lower() in ("done", "quit", "exit", "q"):
                console.print("[dim]Finished editing agent[/dim]")
                break

            # First message includes agent context
            if first_message:
                message_with_context = f"""I want to edit my custom agent "{name}".

**File:** `{agent_file}`

**Current content:**
```markdown
{content}
```

**My request:** {user_input}

Please make the requested changes using the Edit tool."""
                stream = client.agent_chat_stream(
                    message=message_with_context,
                    model=model,
                    max_iterations=max_iterations,
                    options={"mode": "code"},
                )
                first_message = False
            elif chat_session_id:
                stream = client.agent_continue_stream(
                    chat_session_id, user_input
                )
            else:
                stream = client.agent_chat_stream(
                    message=user_input,
                    model=model,
                    max_iterations=max_iterations,
                    options={"mode": "code"},
                )

            result = render_with_interrupt(renderer, stream)
            if result and result.get("session_id"):
                chat_session_id = result["session_id"]

        except (KeyboardInterrupt, EOFError):
            console.print()
            console.print("[dim]Finished editing agent[/dim]")
            break
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")


def handle_agents(args: str, client, renderer, model, max_iterations, render_with_interrupt) -> None:
    """Handle /agents command."""
    from prompt_toolkit import PromptSession

    # Handle subcommands for backward compatibility
    if args:
        subparts = args.split(maxsplit=1)
        subcommand = subparts[0].lower()
        subargs = subparts[1] if len(subparts) > 1 else ""

        if subcommand == "create" and subargs:
            create_agent(subargs.strip().lower().replace(" ", "-"))
        elif subcommand == "show" and subargs:
            show_agent_details(subargs.strip())
        elif subcommand == "delete" and subargs:
            delete_agent(subargs.strip())
        elif subcommand == "edit" and subargs:
            edit_agent(subargs.strip())
        else:
            console.print("[yellow]Usage: /agents [create|show|delete|edit] <name>[/yellow]")
            console.print("[dim]Or just /agents for interactive menu[/dim]")
    else:
        # Interactive menu
        while True:
            action, agent_name = show_agents_interactive_menu()

            if action == "cancel":
                break
            elif action == "view":
                show_agent_details(agent_name)
                # After viewing, show options based on agent type
                is_custom = agent_name not in ("Explore", "Plan")
                try:
                    if is_custom:
                        console.print("[dim]'c' chat • 'e' edit • Enter back[/dim]", end="")
                    else:
                        console.print("[dim]Press Enter to go back...[/dim]", end="")
                    ps = PromptSession()
                    resp = ps.prompt(" ").strip().lower()
                    if is_custom and resp == 'c':
                        chat_edit_agent(agent_name, client, renderer, model, max_iterations, render_with_interrupt)
                    elif is_custom and resp == 'e':
                        edit_agent(agent_name)
                    console.print()  # Add spacing before menu reappears
                except (KeyboardInterrupt, EOFError):
                    break
            elif action == "create":
                new_name = prompt_agent_name()
                if new_name:
                    if create_agent(new_name):
                        # Ask if they want to edit it
                        console.print("[dim]Press 'e' to edit, or Enter to continue...[/dim]")
                        try:
                            ps = PromptSession()
                            resp = ps.prompt("> ")
                            if resp.strip().lower() == 'e':
                                edit_agent(new_name)
                        except (KeyboardInterrupt, EOFError):
                            pass
                else:
                    console.print("[dim]Cancelled[/dim]")
            elif action == "delete":
                delete_agent(agent_name)
            elif action == "edit":
                edit_agent(agent_name)
                break  # Exit menu after editing
