"""Handlers for miscellaneous slash commands."""

from datetime import datetime
from pathlib import Path

from rich.console import Console

console = Console()


def handle_status(client) -> None:
    """Handle /status command.

    Args:
        client: EmdashClient instance
    """
    console.print("\n[bold cyan]Status[/bold cyan]\n")

    # Index status
    console.print("[bold]Index Status[/bold]")
    try:
        status = client.index_status(str(Path.cwd()))
        is_indexed = status.get("is_indexed", False)
        console.print(f"  Indexed: {'[green]Yes[/green]' if is_indexed else '[yellow]No[/yellow]'}")

        if is_indexed:
            console.print(f"  Files: {status.get('file_count', 0)}")
            console.print(f"  Functions: {status.get('function_count', 0)}")
            console.print(f"  Classes: {status.get('class_count', 0)}")
            console.print(f"  Communities: {status.get('community_count', 0)}")
            if status.get("last_indexed"):
                console.print(f"  Last indexed: {status.get('last_indexed')}")
            if status.get("last_commit"):
                console.print(f"  Last commit: {status.get('last_commit')}")
    except Exception as e:
        console.print(f"  [red]Error fetching index status: {e}[/red]")

    console.print()

    # PROJECT.md status
    console.print("[bold]PROJECT.md Status[/bold]")
    projectmd_path = Path.cwd() / "PROJECT.md"
    if projectmd_path.exists():
        stat = projectmd_path.stat()
        modified_time = datetime.fromtimestamp(stat.st_mtime)
        size_kb = stat.st_size / 1024
        console.print(f"  Exists: [green]Yes[/green]")
        console.print(f"  Path: {projectmd_path}")
        console.print(f"  Size: {size_kb:.1f} KB")
        console.print(f"  Last modified: {modified_time.strftime('%Y-%m-%d %H:%M:%S')}")
    else:
        console.print(f"  Exists: [yellow]No[/yellow]")
        console.print("[dim]  Run /projectmd to generate it[/dim]")

    console.print()


def handle_pr(args: str, run_slash_command_task, client, renderer, model, max_iterations) -> None:
    """Handle /pr command.

    Args:
        args: PR URL or number
        run_slash_command_task: Function to run slash command tasks
        client: EmdashClient instance
        renderer: SSERenderer instance
        model: Current model
        max_iterations: Max iterations
    """
    if not args:
        console.print("[yellow]Usage: /pr <pr-url-or-number>[/yellow]")
        console.print("[dim]Example: /pr 123 or /pr https://github.com/org/repo/pull/123[/dim]")
    else:
        console.print(f"[cyan]Reviewing PR: {args}[/cyan]")
        run_slash_command_task(
            client, renderer, model, max_iterations,
            f"Review this pull request and provide feedback: {args}",
            {"mode": "code"}
        )


def handle_projectmd(run_slash_command_task, client, renderer, model, max_iterations) -> None:
    """Handle /projectmd command.

    Args:
        run_slash_command_task: Function to run slash command tasks
        client: EmdashClient instance
        renderer: SSERenderer instance
        model: Current model
        max_iterations: Max iterations
    """
    console.print("[cyan]Generating PROJECT.md...[/cyan]")
    run_slash_command_task(
        client, renderer, model, max_iterations,
        "Analyze this codebase and generate a comprehensive PROJECT.md file that describes the architecture, main components, how to get started, and key design decisions.",
        {"mode": "code"}
    )


def handle_research(args: str, run_slash_command_task, client, renderer, model) -> None:
    """Handle /research command.

    Args:
        args: Research goal
        run_slash_command_task: Function to run slash command tasks
        client: EmdashClient instance
        renderer: SSERenderer instance
        model: Current model
    """
    if not args:
        console.print("[yellow]Usage: /research <goal>[/yellow]")
        console.print("[dim]Example: /research How does authentication work in this codebase?[/dim]")
    else:
        console.print(f"[cyan]Researching: {args}[/cyan]")
        run_slash_command_task(
            client, renderer, model, 50,  # More iterations for research
            f"Conduct deep research on: {args}\n\nExplore the codebase thoroughly, analyze relevant code, and provide a comprehensive answer with references to specific files and functions.",
            {"mode": "plan"}  # Use plan mode for research
        )


def handle_context(renderer) -> None:
    """Handle /context command.

    Args:
        renderer: SSERenderer instance with _last_context_frame attribute
    """
    context_data = getattr(renderer, '_last_context_frame', None)
    if not context_data:
        console.print("\n[dim]No context frame available yet. Run a query first.[/dim]\n")
    else:
        adding = context_data.get("adding") or {}
        reading = context_data.get("reading") or {}

        # Get stats
        step_count = adding.get("step_count", 0)
        entities_found = adding.get("entities_found", 0)
        context_tokens = adding.get("context_tokens", 0)
        context_breakdown = adding.get("context_breakdown", {})

        console.print()
        console.print("[bold cyan]Context Frame[/bold cyan]")
        console.print()

        # Show total context
        if context_tokens > 0:
            console.print(f"[bold]Total:[/bold] {context_tokens:,} tokens")

        # Show breakdown
        if context_breakdown:
            console.print(f"\n[bold]Breakdown:[/bold]")
            for key, tokens in context_breakdown.items():
                if tokens > 0:
                    console.print(f"  {key}: {tokens:,}")

        # Show stats
        if step_count > 0 or entities_found > 0:
            console.print(f"\n[bold]Stats:[/bold]")
            if step_count > 0:
                console.print(f"  Steps: {step_count}")
            if entities_found > 0:
                console.print(f"  Entities: {entities_found}")

        # Show reranking query
        query = reading.get("query")
        if query:
            console.print(f"\n[bold]Reranking Query:[/bold]")
            console.print(f"  [yellow]{query}[/yellow]")

        # Show reranked items
        items = reading.get("items", [])
        if items:
            console.print(f"\n[bold]Reranked Items ({len(items)}):[/bold]")
            for i, item in enumerate(items, 1):
                name = item.get("name", "?")
                item_type = item.get("type", "?")
                score = item.get("score")
                file_path = item.get("file", "")
                description = item.get("description", "")
                touch_count = item.get("touch_count", 0)
                neighbors = item.get("neighbors", [])

                score_str = f"[cyan]{score:.3f}[/cyan]" if score is not None else "[dim]n/a[/dim]"
                touch_str = f"[magenta]×{touch_count}[/magenta]" if touch_count > 1 else ""

                console.print(f"\n  [bold white]{i}.[/bold white] [dim]{item_type}[/dim] [bold]{name}[/bold]")
                console.print(f"     Score: {score_str} {touch_str}")
                if file_path:
                    console.print(f"     File: [dim]{file_path}[/dim]")
                if description:
                    desc_preview = description[:100] + "..." if len(description) > 100 else description
                    console.print(f"     Desc: [dim]{desc_preview}[/dim]")
                if neighbors:
                    console.print(f"     Neighbors: [dim]{', '.join(neighbors)}[/dim]")
        else:
            debug_info = reading.get("debug", "")
            if debug_info:
                console.print(f"\n[dim]No reranked items: {debug_info}[/dim]")
            else:
                console.print(f"\n[dim]No reranked items yet. Items appear after exploration (file reads, searches).[/dim]")
        console.print()
