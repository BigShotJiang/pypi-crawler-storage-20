"""Optimization module tests."""
