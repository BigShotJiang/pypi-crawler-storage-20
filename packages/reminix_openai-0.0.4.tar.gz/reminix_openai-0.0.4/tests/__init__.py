"""Tests for reminix-openai."""
