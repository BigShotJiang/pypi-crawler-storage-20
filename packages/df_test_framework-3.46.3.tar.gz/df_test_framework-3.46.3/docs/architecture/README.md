# 架构设计文档

深入了解 DF Test Framework 架构设计和实现原理。

> 当前版本：v3.43.0

## 📚 v3.43 架构文档（当前版本）

### 核心文档
1. **[架构总览](OVERVIEW_V3.17.md)** ⭐ - 五层架构 + 事件驱动 + 统一可观测性
   - 五层架构详解（Layer 0-4）
   - EventBus 事件驱动
   - 中间件系统（洋葱模型）
   - 测试隔离机制

2. **[配置驱动架构设计](config-driven-design.md)** 🆕 ⭐⭐⭐⭐ - 配置驱动模式全面解析
   - 设计理念：为什么需要配置驱动？
   - 核心架构：五层架构中的职责划分
   - Provider 模式：SingletonProvider、ProviderRegistry
   - 配置体系：FrameworkSettings、HTTPConfig、WebConfig
   - 设计权衡：HTTP vs Web、配置驱动 vs 直接实例化
   - 最佳实践：配置文件组织、测试编写模式
   - 演进路线：v3.42.0 现状和未来规划

3. **[Provider 模式深度剖析](provider-pattern-deep-dive.md)** 🆕 ⭐⭐⭐⭐⭐ - Provider 实现技术深度解析
   - 设计动机：问题域、设计目标、架构角色
   - 核心实现：Provider 协议、SingletonProvider、ProviderRegistry
   - 线程安全性：双重检查锁定、GIL 分析、竞态条件测试
   - 性能优化：快速路径优化、延迟初始化、内存优化
   - 测试策略：单元测试、集成测试、端到端测试
   - 边界案例：配置缺失、工厂异常、实例清理失败
   - 扩展与定制：自定义 Provider、条件 Provider、缓存 Provider

4. **[依赖管理策略](DI_STRATEGY.md)** - 混合 DI 模式设计
   - Provider 模式（重量级资源）
   - Settings 绑定（轻量级服务）
   - pytest fixtures（测试依赖）
   - 扩展新服务指南

5. **[插件系统架构](PLUGIN_SYSTEM_V3.37.md)** - pytest 插件现代化实现
   - pytest11 Entry Points 自动发现
   - pytest 9.0 原生 TOML 配置
   - config 对象属性存储
   - Hook 执行顺序与状态管理
   - 测试隔离机制

6. **[可观测性架构](observability-architecture.md)** - 三大支柱 + EventBus
   - Logging (Loguru)
   - Tracing (OpenTelemetry)
   - Metrics (Prometheus)
   - EventBus 集成

7. **[EventBus 集成分析](eventbus-integration-analysis.md)** - 模块集成状态
   - 已集成 EventBus 的模块
   - 改进路线图

8. **[HTTP vs Web 架构对比](http-vs-web-comparison.md)** 🆕 ⭐⭐⭐ - 架构差异深度分析
   - 架构对比：HTTP Clients vs Web Drivers
   - 常见误解澄清：封装方式、工厂模式
   - 真实差异分析：目录层级深度原因
   - 架构设计原则：业务逻辑分层、架构一致性
   - 纠正错误建议：为什么 Web 不需要协议层

---

## 📚 基础架构设计（历史参考）

### 能力层设计
- **[V3 架构设计](V3_ARCHITECTURE.md)** - v3.0 核心架构方案（基础）
- **[V3 实施指南](V3_IMPLEMENTATION.md)** - v3.0 实施步骤
- **[v2 → v3 迁移指南](../migration/v2-to-v3.md)** - 用户迁移文档

### 质量保证
- **[架构审计报告](ARCHITECTURE_AUDIT.md)** - 文档与代码一致性审计
- **[未来增强功能](FUTURE_ENHANCEMENTS.md)** - 后续增强规划

### 归档
- **[archive/](archive/)** - 架构演进过程文档（已归档）
- **[overview.md](overview.md)** - v2 架构总览（历史参考）

## 🏗️ 架构原则

### 1. 五层架构（v3.16+）

框架采用清晰的五层设计：

```
Layer 4 ─── bootstrap/          # 引导层：框架组装和初始化
Layer 3 ─── testing/ + cli/     # 门面层：Fixtures、调试工具、CLI
Layer 2 ─── capabilities/       # 能力层：clients/drivers/databases/messengers/storages
Layer 1 ─── infrastructure/     # 基础设施：config/logging/telemetry/events/plugins
Layer 0 ─── core/               # 核心层：纯抽象（middleware/context/events/protocols）
横切 ───── plugins/             # 插件：MonitoringPlugin、AllurePlugin
```

**依赖规则**:
- Layer 4 → 可依赖 Layer 0-3 全部
- Layer 3 → 可依赖 Layer 0-2
- Layer 2 → 可依赖 Layer 0-1
- Layer 1 → 只能依赖 Layer 0
- Layer 0 → 无依赖（最底层）

### 2. 核心设计模式

- **Middleware（中间件）**: 洋葱模型请求处理链（签名、认证、重试、日志）
- **EventBus（事件驱动）**: 发布/订阅模式，模块解耦
- **Factory（工厂）**: 测试数据生成
- **Repository（仓储）**: 数据访问抽象
- **Provider（提供者）**: 依赖注入
- **Plugin（插件）**: 功能扩展（Pluggy）

### 3. 设计原则

- **单一职责**: 每个模块只负责一件事
- **依赖倒置**: 依赖抽象而非具体实现
- **开闭原则**: 对扩展开放，对修改关闭
- **接口隔离**: 使用协议和抽象基类
- **显式优于隐式**: 配置和行为明确可见

## 🔑 核心概念

### Bootstrap 启动流程（v3.37）

```python
from df_test_framework.bootstrap import Bootstrap
from df_test_framework.infrastructure.config import get_config

# v3.37.0: 使用 get_config() 加载配置（自动识别 config/ 目录）
settings = get_config(env="staging")  # 加载 config/environments/staging.yaml

# Bootstrap 启动
Bootstrap()
  .with_settings(settings)       # 1. 加载配置
  .with_providers(providers)     # 2. 注册提供者
  .with_event_bus(event_bus)     # 3. 事件总线
  .with_extensions(extensions)   # 4. 加载扩展
  .build()                       # 5. 构建应用
  .run()                         # 6. 创建运行时

# v3.37.0: pytest 插件中使用 config 对象属性
# env_plugin 自动调用 get_config() 并存储到 config._df_settings
# core.py 使用 config._df_runtime 存储 RuntimeContext
```

### RuntimeContext 依赖管理

```python
runtime.http_client()    # 获取HTTP客户端（含中间件）
runtime.database()       # 获取数据库连接
runtime.redis_client()   # 获取Redis客户端
runtime.event_bus        # 获取事件总线
```

### 中间件系统（v3.14+）

洋葱模型请求处理：

```python
from df_test_framework import HttpClient
from df_test_framework.capabilities.clients.http.middleware import (
    SignatureMiddleware,
    BearerTokenMiddleware,
    RetryMiddleware,
)

client = HttpClient(
    base_url="https://api.example.com",
    middlewares=[
        RetryMiddleware(max_retries=3),
        SignatureMiddleware(secret="xxx"),
        BearerTokenMiddleware(token="token"),
    ]
)
```

## 📊 模块依赖关系

```
┌─────────────────────────────────────────────────────────────┐
│                    Layer 4: Bootstrap                        │
│         ┌─────────────────────────────────────┐             │
│         │  Bootstrap → Providers → Runtime    │             │
│         └─────────────────────────────────────┘             │
├─────────────────────────────────────────────────────────────┤
│                Layer 3: Testing + CLI                        │
│    ┌──────────────┐      ┌──────────────┐                   │
│    │   Fixtures   │      │   CLI Tools  │                   │
│    └──────────────┘      └──────────────┘                   │
├─────────────────────────────────────────────────────────────┤
│               Layer 2: Capabilities                          │
│  ┌────────┐ ┌────────┐ ┌──────────┐ ┌──────────────┐        │
│  │ HTTP   │ │ gRPC   │ │ Database │ │  Messengers  │        │
│  │ Client │ │ Client │ │ + Redis  │ │ Kafka/MQ/RMQ │        │
│  └────────┘ └────────┘ └──────────┘ └──────────────┘        │
├─────────────────────────────────────────────────────────────┤
│              Layer 1: Infrastructure                         │
│  ┌────────┐ ┌─────────┐ ┌───────────┐ ┌──────────┐          │
│  │ Config │ │ Logging │ │ Telemetry │ │ EventBus │          │
│  └────────┘ └─────────┘ └───────────┘ └──────────┘          │
├─────────────────────────────────────────────────────────────┤
│                  Layer 0: Core                               │
│  ┌────────────┐ ┌─────────┐ ┌──────────┐ ┌───────────┐      │
│  │ Middleware │ │ Context │ │  Events  │ │ Protocols │      │
│  └────────────┘ └─────────┘ └──────────┘ └───────────┘      │
└─────────────────────────────────────────────────────────────┘
```

## 🎯 技术选型

### 核心依赖

- **httpx**: 现代异步HTTP客户端
- **pydantic**: 数据验证和配置管理
- **sqlalchemy**: 数据库ORM
- **redis**: Redis客户端
- **loguru**: 结构化日志
- **pluggy**: 插件系统
- **pytest**: 测试框架

### 为什么选择这些技术？

- **httpx vs requests**: 支持异步、HTTP/2、更现代的API
- **pydantic**: 类型安全、自动验证、环境变量支持
- **loguru**: 简单易用、结构化日志、自动颜色
- **pluggy**: pytest使用的插件系统，成熟稳定

## 🔗 相关资源

- [架构总览](overview.md)
- [API参考](../api-reference/README.md)
- [用户指南](../user-guide/README.md)

---

**返回**: [文档首页](../README.md)
