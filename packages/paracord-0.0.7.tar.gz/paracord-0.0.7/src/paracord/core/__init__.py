"""Paracord CLI core functionality."""
