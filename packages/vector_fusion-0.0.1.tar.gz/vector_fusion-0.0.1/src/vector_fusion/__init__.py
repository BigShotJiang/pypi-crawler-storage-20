"""
vector-fusion - Hybrid vector search microservice

Coming soon! This package is under active development.

Features (planned):
- Multi-collection hybrid search (vector + sparse)
- Reciprocal Rank Fusion (RRF) merge strategies
- Temporal filtering (hard/soft modes)
- Gemini embeddings support
- FastAPI-based REST API

GitHub: https://github.com/LifeAiTools/vector-fusion
"""

__version__ = "0.0.1"
__author__ = "LifeAiTools"

def coming_soon():
    """Placeholder for future functionality."""
    print("vector-fusion is coming soon! Stay tuned.")
    print("GitHub: https://github.com/LifeAiTools/vector-fusion")
