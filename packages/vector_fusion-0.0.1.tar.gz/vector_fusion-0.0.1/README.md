# vector-fusion

> Hybrid vector search microservice with RRF fusion and temporal filtering

## 🚧 Coming Soon

This package is under active development. Stay tuned!

## Planned Features

- **Multi-collection hybrid search** - Vector + sparse retrieval
- **RRF merge strategies** - Reciprocal Rank Fusion for result combination
- **Temporal filtering** - Hard/soft modes for time-based queries
- **Gemini embeddings** - Native support for Google's embedding models
- **FastAPI REST API** - Production-ready microservice

## Installation (future)

```bash
pip install vector-fusion
```

## Links

- GitHub: https://github.com/LifeAiTools/vector-fusion
- PyPI: https://pypi.org/project/vector-fusion/

## License

Apache-2.0
