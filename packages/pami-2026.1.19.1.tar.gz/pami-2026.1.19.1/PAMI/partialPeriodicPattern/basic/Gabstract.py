from abc import ABC as _ABC, abstractmethod as _abstractmethod
import time as _time
import math as _math
import csv as _csv
import pandas as _pd
from collections import defaultdict as _defaultdict
from itertools import combinations as _combinations
import os as _os
import os.path as _ospath
import psutil as _psutil
import sys as _sys
import validators as _validators
from urllib.request import urlopen as _urlopen
from typing import Union

class _partialPeriodicPatterns(_ABC):
    """
    :Description:   This abstract base class defines the variables and methods that every frequent pattern mining algorithm must
                    employ in PAMI

    :Attributes:

        iFile : str
            Input file name or path of the input file
        minPS: float
            UserSpecified minimum period-support value. It has to be given in terms of count of total number of transactions
            in the input database/file
        startTime:float
            To record the start time of the algorithm
        endTime:float
            To record the completion time of the algorithm
        finalPatterns: dict
            Storing the complete set of patterns in a dictionary variable
        oFile : str
            Name of the output file to store complete set of frequent patterns
        memoryUSS : float
            To store the total amount of USS memory consumed by the program
        memoryRSS : float
            To store the total amount of RSS memory consumed by the program

    :Methods:

        mine()
            Mining process will start from here
        getFrequentPatterns()
            Complete set of patterns will be retrieved with this function
        save(oFile)
            Complete set of frequent patterns will be loaded in to a output file
        getPatternsAsDataFrame()
            Complete set of frequent patterns will be loaded in to data frame
        getMemoryUSS()
            Total amount of USS memory consumed by the program will be retrieved from this function
        getMemoryRSS()
            Total amount of RSS memory consumed by the program will be retrieved from this function
        getRuntime()
            Total amount of runtime taken by the program will be retrieved from this function
    """

    def __init__(self, iFile: str, minPS: Union[int, float, str], period: Union[int, float, str], relativePS: bool, sep: str='\t') -> None:
        """
        :param iFile: Input file name or path of the input file
        :type iFile: str
        :param minPS: UserSpecified minimum period-support value. It has to be given in terms of count of total number of
        transactions in the input database/file
        :type minPS: float
        """

        self._iFile = iFile
        self._minPS = minPS
        self._period = period
        self._relativePS = relativePS
        self._sep = sep
        self._finalPatterns = {}
        self._oFile = str()
        self._startTime = float()
        self._endTime = float()
        self._memoryUSS = float()
        self._memoryRSS = float()

    @_abstractmethod
    def startMine(self) -> None:
        """Code for the mining process will start from this function"""

        pass

    @_abstractmethod
    def getPatterns(self) -> dict:
        """Complete set of frequent patterns generated will be retrieved from this function"""

        pass

    @_abstractmethod
    def save(self, oFile) -> None:
        """Complete set of frequent patterns will be saved in to an output file from this function

        :param oFile: Name of the output csvFile
        :type oFile: file
        """

        pass

    @_abstractmethod
    def getPatternsAsDataFrame(self) -> _pd.DataFrame:
        """Complete set of frequent patterns will be loaded in to data frame from this function"""

        pass

    @_abstractmethod
    def getMemoryUSS(self) -> float:
        """Total amount of USS memory consumed by the program will be retrieved from this function"""

        pass

    @_abstractmethod
    def getMemoryRSS(self) -> float:
        """Total amount of RSS memory consumed by the program will be retrieved from this function"""
        pass

    @_abstractmethod
    def getRuntime(self) -> float:
        """Total amount of runtime taken by the program will be retrieved from this function"""

        pass
