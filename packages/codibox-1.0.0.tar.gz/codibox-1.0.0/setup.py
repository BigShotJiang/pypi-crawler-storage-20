"""
Setup script for Codibox package
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="codibox",
    version="1.0.0",
    author="Your Name",
    author_email="your.email@example.com",
    description="A reusable package for executing Python code in Docker containers and extracting charts/images",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/codibox",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/codibox/issues",
        "Source": "https://github.com/yourusername/codibox",
        "Documentation": "https://github.com/yourusername/codibox#readme",
    },
    packages=find_packages(),
    package_data={
        "codibox": ["docker/*"],
    },
    include_package_data=True,
    keywords="docker, code-execution, sandbox, jupyter, notebook, matplotlib, charts, images, python-execution",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: Build Tools",
        "Topic :: System :: Systems Administration",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.10",
    install_requires=[
        # No external dependencies - uses subprocess and standard library
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
    },
)
