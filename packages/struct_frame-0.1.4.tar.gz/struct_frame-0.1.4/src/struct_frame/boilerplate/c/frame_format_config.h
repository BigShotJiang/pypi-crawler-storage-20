/* Struct-frame boilerplate: frame parser */

#pragma once

#include "frame_base.h"

/*===========================================================================
 * FrameFormatConfig Frame Format
 *===========================================================================*/

/* FrameFormatConfig constants */
#define FRAME_FORMAT_CONFIG_START_BYTE1    0x90
#define FRAME_FORMAT_CONFIG_START_BYTE2    0x71
#define FRAME_FORMAT_CONFIG_HEADER_SIZE    2  /* start_byte1 + start_byte2 + msg_id */
#define FRAME_FORMAT_CONFIG_FOOTER_SIZE    1  /* crc(1 bytes) */
#define FRAME_FORMAT_CONFIG_OVERHEAD       (FRAME_FORMAT_CONFIG_HEADER_SIZE + FRAME_FORMAT_CONFIG_FOOTER_SIZE)

/* FrameFormatConfig parser states */
typedef enum frame_format_config_parser_state {
    FRAME_FORMAT_CONFIG_LOOKING_FOR_START1 = 0,
    FRAME_FORMAT_CONFIG_LOOKING_FOR_START2 = 1,
    FRAME_FORMAT_CONFIG_GETTING_MSG_ID = 2,
    FRAME_FORMAT_CONFIG_GETTING_PAYLOAD = 3
} frame_format_config_parser_state_t;

/* FrameFormatConfig parser state structure */
typedef struct frame_format_config_parser {
    frame_format_config_parser_state_t state;
    uint8_t* buffer;
    size_t buffer_max_size;
    size_t buffer_index;
    size_t packet_size;
    uint8_t msg_id;
    /* User-provided function to get message length from msg_id (for non-length frames) */
    bool (*get_msg_length)(uint8_t msg_id, size_t* length);
} frame_format_config_parser_t;

/* FrameFormatConfig encode buffer structure */
typedef struct frame_format_config_encode_buffer {
    uint8_t* data;
    size_t max_size;
    size_t size;
    bool in_progress;
    size_t reserved_msg_size;
} frame_format_config_encode_buffer_t;

/**
 * Initialize a FrameFormatConfig parser
 */
static inline void frame_format_config_parser_init(frame_format_config_parser_t* parser,
                                        uint8_t* buffer, size_t buffer_size,
                                        bool (*get_msg_length)(uint8_t msg_id, size_t* length)) {
    parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START1;
    parser->buffer = buffer;
    parser->buffer_max_size = buffer_size;
    parser->buffer_index = 0;
    parser->packet_size = 0;
    parser->msg_id = 0;
    parser->get_msg_length = get_msg_length;
}

/**
 * Reset FrameFormatConfig parser state
 */
static inline void frame_format_config_parser_reset(frame_format_config_parser_t* parser) {
    parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START1;
    parser->buffer_index = 0;
    parser->packet_size = 0;
    parser->msg_id = 0;
}

/**
 * Parse a single byte with FrameFormatConfig format
 * Returns frame_msg_info_t with valid=true when a complete valid message is received
 */
static inline frame_msg_info_t frame_format_config_parse_byte(frame_format_config_parser_t* parser, uint8_t byte) {
    frame_msg_info_t result = {false, 0, 0, NULL};

    switch (parser->state) {
        case FRAME_FORMAT_CONFIG_LOOKING_FOR_START1:
            if (byte == FRAME_FORMAT_CONFIG_START_BYTE1) {
                parser->buffer[0] = byte;
                parser->buffer_index = 1;
                parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START2;
            }
            break;

        case FRAME_FORMAT_CONFIG_LOOKING_FOR_START2:
            if (byte == FRAME_FORMAT_CONFIG_START_BYTE2) {
                parser->buffer[1] = byte;
                parser->buffer_index = 2;
                parser->state = FRAME_FORMAT_CONFIG_GETTING_MSG_ID;
            } else if (byte == FRAME_FORMAT_CONFIG_START_BYTE1) {
                parser->buffer[0] = byte;
                parser->buffer_index = 1;
                parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START2;
            } else {
                parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START1;
            }
            break;

        case FRAME_FORMAT_CONFIG_GETTING_MSG_ID:
            parser->buffer[parser->buffer_index++] = byte;
            parser->msg_id = byte;
            {
                size_t msg_length = 0;
                if (parser->get_msg_length && parser->get_msg_length(byte, &msg_length)) {
                    parser->packet_size = FRAME_FORMAT_CONFIG_OVERHEAD + msg_length;
                    if (parser->packet_size <= parser->buffer_max_size) {
                        parser->state = FRAME_FORMAT_CONFIG_GETTING_PAYLOAD;
                    } else {
                        parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START1;
                    }
                } else {
                    parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START1;
                }
            }
            break;

        case FRAME_FORMAT_CONFIG_GETTING_PAYLOAD:
            if (parser->buffer_index < parser->buffer_max_size) {
                parser->buffer[parser->buffer_index++] = byte;
            }

            if (parser->buffer_index >= parser->packet_size) {
                /* Use shared payload validation with CRC */
                result = frame_validate_payload_with_crc(
                    parser->buffer, parser->packet_size,
                    FRAME_FORMAT_CONFIG_HEADER_SIZE, 0, 2);
                parser->state = FRAME_FORMAT_CONFIG_LOOKING_FOR_START1;
            }
            break;
    }

    return result;
}

/**
 * Encode a message with FrameFormatConfig format
 * Returns the number of bytes written, or 0 on failure
 */
static inline size_t frame_format_config_encode(uint8_t* buffer, size_t buffer_size,
                                     uint8_t msg_id, const uint8_t* msg, size_t msg_size) {
    size_t total_size = FRAME_FORMAT_CONFIG_OVERHEAD + msg_size;
    if (buffer_size < total_size) {
        return 0;
    }

    buffer[0] = FRAME_FORMAT_CONFIG_START_BYTE1;
    buffer[1] = FRAME_FORMAT_CONFIG_START_BYTE2;

    /* Use shared payload encoding with CRC */
    frame_encode_payload_with_crc(
        buffer + 2, msg_id, msg, msg_size,
        0, buffer + 2);

    return total_size;
}

/**
 * Validate a complete FrameFormatConfig packet in a buffer
 */
static inline frame_msg_info_t frame_format_config_validate_packet(const uint8_t* buffer, size_t length) {
    if (length < FRAME_FORMAT_CONFIG_OVERHEAD) {
        return (frame_msg_info_t){false, 0, 0, NULL};
    }

    if (buffer[0] != FRAME_FORMAT_CONFIG_START_BYTE1) {
        return (frame_msg_info_t){false, 0, 0, NULL};
    }
    if (buffer[1] != FRAME_FORMAT_CONFIG_START_BYTE2) {
        return (frame_msg_info_t){false, 0, 0, NULL};
    }

    /* Use shared payload validation with CRC */
    return frame_validate_payload_with_crc(
        buffer, length, FRAME_FORMAT_CONFIG_HEADER_SIZE, 0, 2);
}

