#!/usr/bin/env python3
# kate: replace-tabs on; indent-width 4;
"""
TypeScript code generator for struct-frame.

This module generates TypeScript code for struct serialization using
ES6 module syntax (import/export).
"""

from struct_frame import version, NamingStyleC
from struct_frame.ts_js_base import (
    common_types,
    common_typed_array_methods,
    ts_array_types,
    BaseFieldGen,
    BaseEnumGen,
    # New class-based generation utilities
    TYPE_SIZES,
    TS_TYPE_ANNOTATIONS,
    TS_ARRAY_TYPE_ANNOTATIONS,
    READ_METHODS,
    WRITE_METHODS,
    READ_ARRAY_METHODS,
    WRITE_ARRAY_METHODS,
    calculate_field_layout,
    FieldInfo,
)
import time

StyleC = NamingStyleC()

# Use shared type mappings
ts_types = common_types
ts_typed_array_methods = common_typed_array_methods


class EnumTsGen():
    @staticmethod
    def generate(field, packageName):
        leading_comment = field.comments
        result = ''
        if leading_comment:
            for c in leading_comment:
                result = '%s\n' % c

        result += 'export enum %s%s' % (packageName,
                                        StyleC.enum_name(field.name))

        result += ' {\n'

        enum_length = len(field.data)
        enum_values = []
        for index, (d) in enumerate(field.data):
            leading_comment = field.data[d][1]

            if leading_comment:
                for c in leading_comment:
                    enum_values.append(c)

            comma = ","
            if index == enum_length - 1:
                # last enum member should not end with a comma
                comma = ""

            enum_value = "    %s = %d%s" % (
                StyleC.enum_entry(d), field.data[d][0], comma)

            enum_values.append(enum_value)

        result += '\n'.join(enum_values)
        result += '\n}'

        return result


class FieldTsGen():
    """TypeScript field generator using shared base logic."""

    @staticmethod
    def generate(field, packageName):
        """Generate TypeScript field definition using shared base."""
        return BaseFieldGen.generate(
            field, packageName, ts_types, ts_typed_array_methods
        )


# ---------------------------------------------------------------------------
#                   Generation of messages (structures)
# ---------------------------------------------------------------------------


class MessageTsGen():
    @staticmethod
    def generate(msg, packageName, package=None):
        leading_comment = msg.comments

        result = ''
        if leading_comment:
            for c in msg.comments:
                result = '%s\n' % c

        package_msg_name = '%s_%s' % (packageName, msg.name)

        result += 'export const %s = new Struct(\'%s\')' % (
            package_msg_name, package_msg_name)
        
        # Add message ID if present
        if msg.id:
            result += '.msgId(%d)' % msg.id

        result += '\n'

        size = 1
        if not msg.fields and not msg.oneofs:
            # Empty structs are not allowed in C standard.
            # Therefore add a dummy field if an empty message occurs.
            result += '    .UInt8(\'dummy_field\');'
        else:
            size = msg.size

        # Generate regular fields
        result += '\n'.join([FieldTsGen.generate(f, packageName)
                            for key, f in msg.fields.items()])
        
        # Generate oneofs - add discriminator and allocate union size
        for key, oneof in msg.oneofs.items():
            if oneof.auto_discriminator:
                # Always use UInt16LE since message IDs can be up to 65535
                result += f'\n    .UInt16LE(\'{oneof.name}_discriminator\')'
            # Allocate space for the union (largest member size)
            # Use a byte array to represent the union storage
            result += f'\n    .ByteArray(\'{oneof.name}_data\', {oneof.size})'
        
        result += '\n    .compile();\n'
        return result + '\n'

    @staticmethod
    def get_initializer(msg, null_init):
        if not msg.fields:
            return '{0}'

        parts = []
        for field in msg.fields:
            parts.append(field.get_initializer(null_init))
        return '{' + ', '.join(parts) + '}'


class MessageTsClassGen():
    """Generate TypeScript message classes that extend MessageBase."""
    
    @staticmethod
    def generate(msg, packageName, package, packages):
        """Generate a class-based message definition."""
        leading_comment = msg.comments
        result = ''
        if leading_comment:
            for c in msg.comments:
                result = '%s\n' % c

        package_msg_name = '%s_%s' % (packageName, msg.name)
        
        # Calculate field layout with offsets
        fields = calculate_field_layout(msg, package, packages)
        total_size = msg.size
        
        # Generate init interface for this message (only if there are fields)
        if fields:
            result += MessageTsClassGen._generate_init_interface(package_msg_name, fields)
        
        # Generate class declaration
        result += f'export class {package_msg_name} extends MessageBase {{\n'
        
        # Static properties
        result += f'  static readonly _size: number = {total_size};\n'
        if msg.id:
            result += f'  static readonly _msgid: number = {msg.id};\n'
        result += '\n'
        
        # Generate constructor that supports init object (only reference Init type if fields exist)
        if fields:
            result += f'  constructor(bufferOrInit?: Buffer | {package_msg_name}Init) {{\n'
            result += f'    super(Buffer.isBuffer(bufferOrInit) ? bufferOrInit : undefined);\n'
            result += f'    if (bufferOrInit && !Buffer.isBuffer(bufferOrInit)) {{\n'
            result += f'      this._applyInit(bufferOrInit as Record<string, unknown>);\n'
            result += f'    }}\n'
            result += f'  }}\n\n'
        else:
            result += f'  constructor(buffer?: Buffer) {{\n'
            result += f'    super(buffer);\n'
            result += f'  }}\n\n'
        
        # Generate getters and setters for each field
        for field_info in fields:
            result += MessageTsClassGen._generate_field_accessors(field_info, package_msg_name, packages)
        
        # Static getSize method
        result += f'  static getSize(): number {{\n'
        result += f'    return {total_size};\n'
        result += f'  }}\n'
        
        result += '}\n'
        return result + '\n'
    
    @staticmethod
    def _generate_init_interface(class_name, fields):
        """Generate the Init interface for a message class."""
        result = f'export interface {class_name}Init {{\n'
        
        for field_info in fields:
            ts_type = MessageTsClassGen._get_ts_type_for_field(field_info)
            result += f'  {field_info.name}?: {ts_type};\n'
        
        result += '}\n\n'
        return result
    
    @staticmethod
    def _get_ts_type_for_field(field_info):
        """Get the TypeScript type annotation for a field."""
        field_type = field_info.field_type
        
        if field_info.is_array:
            if field_info.is_nested:
                return f'({field_info.nested_type} | Record<string, unknown>)[]'
            elif field_type == "string":
                return 'string[]'
            else:
                if field_info.is_enum:
                    field_type = "uint8"
                ts_elem_type = TS_ARRAY_TYPE_ANNOTATIONS.get(field_type, "number")
                return f'{ts_elem_type}[]'
        elif field_type == "string":
            return 'string'
        else:
            if field_info.is_enum:
                field_type = "uint8"
            return TS_TYPE_ANNOTATIONS.get(field_type, "number")
    
    @staticmethod
    def _generate_field_accessors(field_info, class_name, packages):
        """Generate getter and setter for a single field."""
        name = field_info.name
        offset = field_info.offset
        field_type = field_info.field_type
        result = ''
        
        # Add comments if present
        for comment in field_info.comments:
            result += f'{comment}\n'
        
        if field_info.is_array:
            result += MessageTsClassGen._generate_array_accessors(field_info)
        elif field_type == "string":
            result += MessageTsClassGen._generate_string_accessors(field_info)
        elif field_info.is_enum or field_type in TYPE_SIZES:
            result += MessageTsClassGen._generate_primitive_accessors(field_info)
        
        return result
    
    @staticmethod
    def _generate_primitive_accessors(field_info):
        """Generate accessors for primitive types."""
        name = field_info.name
        offset = field_info.offset
        field_type = field_info.field_type
        
        # Handle enum as uint8
        if field_info.is_enum:
            field_type = "uint8"
        
        ts_type = TS_TYPE_ANNOTATIONS.get(field_type, "number")
        read_method = READ_METHODS.get(field_type, "_readUInt8")
        write_method = WRITE_METHODS.get(field_type, "_writeUInt8")
        
        result = f'  get {name}(): {ts_type} {{\n'
        result += f'    return this.{read_method}({offset});\n'
        result += f'  }}\n'
        result += f'  set {name}(value: {ts_type}) {{\n'
        result += f'    this.{write_method}({offset}, value);\n'
        result += f'  }}\n\n'
        
        return result
    
    @staticmethod
    def _generate_string_accessors(field_info):
        """Generate accessors for string types."""
        name = field_info.name
        offset = field_info.offset
        size = field_info.element_size or field_info.size
        
        result = f'  get {name}(): string {{\n'
        result += f'    return this._readString({offset}, {size});\n'
        result += f'  }}\n'
        result += f'  set {name}(value: string) {{\n'
        result += f'    this._writeString({offset}, {size}, value);\n'
        result += f'  }}\n\n'
        
        return result
    
    @staticmethod
    def _generate_array_accessors(field_info):
        """Generate accessors for array types."""
        name = field_info.name
        offset = field_info.offset
        field_type = field_info.field_type
        length = field_info.array_length
        elem_size = field_info.element_size
        
        if field_info.is_nested:
            # Struct array
            nested_type = field_info.nested_type
            result = f'  get {name}(): {nested_type}[] {{\n'
            result += f'    return this._readStructArray({offset}, {length}, {nested_type});\n'
            result += f'  }}\n'
            result += f'  set {name}(value: ({nested_type} | Record<string, unknown>)[]) {{\n'
            result += f'    this._writeStructArray({offset}, {length}, {elem_size}, value, {nested_type});\n'
            result += f'  }}\n\n'
        elif field_type == "string":
            # String array using struct array internally (for fixed strings)
            # This is a special case handled by StructArray
            result = f'  get {name}(): string[] {{\n'
            result += f'    // String array - internal struct array representation\n'
            result += f'    const result: string[] = [];\n'
            result += f'    for (let i = 0; i < {length}; i++) {{\n'
            result += f'      result.push(this._readString({offset} + i * {elem_size}, {elem_size}));\n'
            result += f'    }}\n'
            result += f'    return result;\n'
            result += f'  }}\n'
            result += f'  set {name}(value: string[]) {{\n'
            result += f'    const arr = value || [];\n'
            result += f'    for (let i = 0; i < {length}; i++) {{\n'
            result += f'      this._writeString({offset} + i * {elem_size}, {elem_size}, i < arr.length ? arr[i] : \'\');\n'
            result += f'    }}\n'
            result += f'  }}\n\n'
        else:
            # Primitive array
            if field_info.is_enum:
                field_type = "uint8"
            
            ts_elem_type = TS_ARRAY_TYPE_ANNOTATIONS.get(field_type, "number")
            read_method = READ_ARRAY_METHODS.get(field_type, "_readUInt8Array")
            write_method = WRITE_ARRAY_METHODS.get(field_type, "_writeUInt8Array")
            
            result = f'  get {name}(): {ts_elem_type}[] {{\n'
            result += f'    return this.{read_method}({offset}, {length});\n'
            result += f'  }}\n'
            result += f'  set {name}(value: {ts_elem_type}[]) {{\n'
            result += f'    this.{write_method}({offset}, {length}, value);\n'
            result += f'  }}\n\n'
        
        return result


class FileTsGen():
    @staticmethod
    def generate(package, use_class_based=False, packages=None):
        yield '/* Automatically generated struct frame header */\n'
        yield '/* Generated by %s at %s. */\n\n' % (version, time.asctime())

        # Only import MessageBase/Struct if there are messages
        if package.messages:
            if use_class_based:
                yield "import { MessageBase } from './struct_base';\n"
            else:
                yield "import { Struct, ExtractType } from './struct_base';\n"
        
        # Collect cross-package type dependencies
        external_types = {}  # {package_name: set of type names}
        if package.messages:
            for key, msg in package.messages.items():
                for field_name, field in msg.fields.items():
                    type_package = getattr(field, 'type_package', None)
                    # Only track types from other packages that aren't enums
                    if type_package and type_package != package.name and not field.isEnum:
                        if type_package not in external_types:
                            external_types[type_package] = set()
                        external_types[type_package].add(field.fieldType)
        
        # Generate import statements for cross-package types
        for ext_package, type_names in sorted(external_types.items()):
            # Use the type name directly (as it appears in msg.name) - don't convert case
            imports = ', '.join('%s_%s' % (ext_package, t) for t in sorted(type_names))
            yield "import { %s } from './%s.sf';\n" % (imports, ext_package)
        
        yield "\n"

        # Add package ID constant if present
        if package.package_id is not None:
            yield f'/* Package ID for extended message IDs */\n'
            yield f'export const PACKAGE_ID = {package.package_id};\n\n'

        # include additional header files here if available in the future

        if package.enums:
            yield '/* Enum definitions */\n'
            for key, enum in package.enums.items():
                yield EnumTsGen.generate(enum, package.name) + '\n\n'

        if package.messages:
            if use_class_based:
                yield '/* Message class definitions */\n'
                for key, msg in package.sortedMessages().items():
                    yield MessageTsClassGen.generate(msg, package.name, package, packages or {}) + '\n'
            else:
                yield '/* Struct definitions */\n'
                for key, msg in package.sortedMessages().items():
                    yield MessageTsGen.generate(msg, package.name, package) + '\n'
            yield '\n'

        if package.messages:
            # Only generate get_message_length if there are messages with IDs
            messages_with_id = [
                msg for key, msg in package.sortedMessages().items() if msg.id]
            if messages_with_id:
                if package.package_id is not None:
                    # When using package ID, message ID is 16-bit (package_id << 8 | msg_id)
                    yield 'export function get_message_length(msg_id: number) {\n'
                    yield '    // Extract package ID and message ID from 16-bit message ID\n'
                    yield '    const pkg_id = (msg_id >> 8) & 0xFF;\n'
                    yield '    const local_msg_id = msg_id & 0xFF;\n'
                    yield '    \n'
                    yield '    // Check if this is our package\n'
                    yield '    if (pkg_id !== PACKAGE_ID) {\n'
                    yield '        return 0;\n'
                    yield '    }\n'
                    yield '    \n'
                    yield '    switch (local_msg_id) {\n'
                else:
                    # Flat namespace mode: 8-bit message ID
                    yield 'export function get_message_length(msg_id: number) {\n'
                    yield '    switch (msg_id) {\n'
                
                for msg in messages_with_id:
                    package_msg_name = '%s_%s' % (package.name, msg.name)
                    yield '        case %s._msgid: return %s._size;\n' % (package_msg_name, package_msg_name)

                yield '        default: break;\n'
                yield '    }\n'
                yield '    return 0;\n'
                yield '}\n'
            yield '\n'
