import importlib.util
import os
from pathlib import Path


def test_sample09_smoke_manifest_creation():
    """Smoke test: ensure manifest is created without external services.

    Sets required env vars, imports the sample module by file path,
    runs the comparison, and verifies the manifest exists.
    """
    # Ensure required env vars are present (dummy values OK)
    os.environ["OLLAMA_MODEL"] = os.environ.get("OLLAMA_MODEL", "codellama:7b")
    os.environ["COMPARISON_MODEL"] = os.environ.get("COMPARISON_MODEL", "gpt-4o")

    # Clear Azure creds to avoid accidental external calls
    os.environ.pop("AZURE_OPENAI_ENDPOINT", None)
    os.environ.pop("AZURE_OPENAI_API_KEY", None)

    # Import the sample module via path (folder name has a hyphen)
    sample_path = Path("samples/09-code-execution/comparison_demo_advanced.py")
    assert sample_path.exists(), "Sample 09 file missing"

    spec = importlib.util.spec_from_file_location("comparison_demo_advanced", sample_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # Run comparison; external dependencies may fail gracefully inside module
    mod.compare_approaches()

    # Verify manifest was created
    manifest_path = Path("samples/09-code-execution/execution_outputs/manifest.json")
    assert manifest_path.exists(), "Manifest not created by comparison demo"
