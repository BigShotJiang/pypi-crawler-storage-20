# TROP: Triply Robust Panel Estimator

This package provides a Python implementation of the **Triply Robust Panel (TROP)** estimator introduced in:

> Susan Athey, Guido Imbens, Zhaonan Qu, Davide Viviano (2025).  
> *Triply Robust Panel Estimators*.  
> arXiv:2508.21536.

The initial release (v0.1.0) exposes the function:

- `TROP_TWFE_average(Y, W, treated_units, lambda_unit, lambda_time, lambda_nn, treated_periods=..., solver=...)`

which estimates an average treatment effect `tau` in panel settings using a weighted TWFE objective with optional low-rank adjustment.

---

## Installation

```
pip install trop
```