"""Tests for Lintro."""
