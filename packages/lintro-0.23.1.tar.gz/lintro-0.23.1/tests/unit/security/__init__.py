"""Security tests for lintro."""
