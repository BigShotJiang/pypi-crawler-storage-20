"""Tests for enum definitions."""
