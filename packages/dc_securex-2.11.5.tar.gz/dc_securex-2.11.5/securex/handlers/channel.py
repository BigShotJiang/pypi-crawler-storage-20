"""
Channel protection handler for SecureX SDK.
"""
import discord
import asyncio
from datetime import datetime, timedelta


class ChannelHandler:
    """Handles channel protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized (owner or whitelisted)"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_channel_create(self, channel: discord.abc.GuildChannel):
        """Delete unauthorized channel creations"""
        try:
            guild = channel.guild
            
            # Get or create lock for this guild
            if guild.id not in self.sdk._spam_locks:
                self.sdk._spam_locks[guild.id] = asyncio.Lock()
            
            # Only ONE handler processes spam at a time
            async with self.sdk._spam_locks[guild.id]:
                # Wait briefly for spam to finish
                await asyncio.sleep(0.5)
                
                # Get audit logs for last 30 seconds (timezone-aware)
                from datetime import timezone
                cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
                
                unauthorized_channels = []
                
                async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.channel_create):
                    if entry.created_at < cutoff_time:
                        break
                    
                    if not await self._is_authorized(guild, entry.user.id):
                        created_channel = guild.get_channel(entry.target.id)
                        if created_channel:
                            unauthorized_channels.append(created_channel)
                
                # Batch delete unauthorized channels
                if unauthorized_channels:
                    for spam_channel in unauthorized_channels:
                        try:
                            await spam_channel.delete(reason="SecureX: Unauthorized channel creation")
                        except (discord.errors.NotFound, discord.errors.Forbidden):
                            pass
                        except Exception:
                            pass
                
        except Exception:
            pass
    
    async def on_channel_delete(self, channel: discord.abc.GuildChannel):
        """Restore unauthorized channel deletions"""
        try:
            guild = channel.guild
            await asyncio.sleep(1)
            
            # Check audit logs from last 30 seconds
            from datetime import timezone
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.channel_delete):
                if entry.created_at < cutoff_time:
                    break
                    
                if entry.target.id == channel.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Restore the channel
                        new_channel = await self.backup_manager.restore_channel(guild, channel)
                        
                        # If this was a category, restore its children too
                        if new_channel and isinstance(channel, discord.CategoryChannel):
                            await self.backup_manager.restore_category_children(
                                guild, 
                                channel.id,
                                new_channel.id
                            )
                    break
        except Exception:
            pass
    
    async def on_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        """Restore unauthorized channel permission changes"""
        try:
            # Only check permission or position changes
            if (before.overwrites == after.overwrites and 
                before.position == after.position):
                return
            
            guild = after.guild
            await asyncio.sleep(0.5)
            
            # Check audit logs from last 30 seconds
            from datetime import timezone
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, oldest_first=False):
                if entry.created_at < cutoff_time:
                    break
                    
                if entry.action == discord.AuditLogAction.channel_update:
                    if entry.target and entry.target.id == after.id:
                        if not await self._is_authorized(guild, entry.user.id):
                            await self.backup_manager.restore_channel_permissions(guild, after.id)
                        break
        except Exception:
            pass
