"""
Role protection handler for SecureX SDK.
"""
import discord
import asyncio
from datetime import datetime, timedelta


class RoleHandler:
    """Handles role protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_role_create(self, role: discord.Role):
        """Delete unauthorized role creations"""
        try:
            guild = role.guild
            
            # Get or create lock for this guild
            if guild.id not in self.sdk._spam_locks:
                self.sdk._spam_locks[guild.id] = asyncio.Lock()
            
            # Only ONE handler processes spam at a time
            async with self.sdk._spam_locks[guild.id]:
                # Get audit logs for last 30 seconds (timezone-aware)
                from datetime import timezone
                cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
                
                unauthorized_roles = []
                
                async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.role_create):
                    if entry.created_at < cutoff_time:
                        break
                    
                    if not await self._is_authorized(guild, entry.user.id):
                        created_role = guild.get_role(entry.target.id)
                        if created_role:
                            unauthorized_roles.append(created_role)
                
                # Batch delete unauthorized roles
                if unauthorized_roles:
                    for spam_role in unauthorized_roles:
                        try:
                            await spam_role.delete(reason="SecureX: Unauthorized role creation")
                        except (discord.errors.NotFound, discord.errors.Forbidden):
                            pass
                        except Exception:
                            pass
                
        except Exception:
            pass
    
    async def on_role_delete(self, role: discord.Role):
        """Restore unauthorized role deletions"""
        try:
            guild = role.guild
            await asyncio.sleep(1)
            
            # Check audit logs from last 30 seconds
            from datetime import timezone
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.role_delete):
                if entry.created_at < cutoff_time:
                    break
                    
                if entry.target.id == role.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        await self.backup_manager.restore_role(guild, role.id)
                    break
        except Exception:
            pass
    
    async def on_role_update(self, before: discord.Role, after: discord.Role):
        """Restore unauthorized role permission changes"""
        try:
            # Only check if position or permissions changed
            if before.position == after.position and before.permissions == after.permissions:
                return
            
            guild = after.guild
            await asyncio.sleep(0.3)
            
            # Check audit logs from last 30 seconds
            from datetime import timezone
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, oldest_first=False):
                if entry.created_at < cutoff_time:
                    break
                    
                if entry.action == discord.AuditLogAction.role_update:
                    if entry.target.id == after.id:
                        if not await self._is_authorized(guild, entry.user.id):
                            await self.backup_manager.restore_role_permissions(guild, after.id)
                        break
        except Exception:
            pass
