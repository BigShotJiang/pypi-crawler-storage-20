"""
Upgrade Prompt Messages for RepliMap.

These messages are shown when users hit plan limits.
Designed to be helpful, not annoying - show value first, then ask for upgrade.

Core Principle: Users have experienced the value, now they need to pay to "take it home"

Pricing (v3.2):
- Solo: $49/mo (Annual: $490/yr - 2 months free)
- Pro: $99/mo (Annual: $990/yr)
- Team: $199/mo (Annual: $1990/yr)
- Enterprise: From $500/mo
"""

from __future__ import annotations

from typing import Any

# =============================================================================
# UPGRADE PROMPTS (v3.2 Pricing)
# =============================================================================

UPGRADE_PROMPTS: dict[str, str] = {
    # =========================================================================
    # SCAN LIMITS
    # =========================================================================
    "scan_monthly_limit": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📊 Monthly Scan Limit Reached                                               │
│                                                                               │
│  You've used {used}/{limit} free scans this month.                           │
│  Next reset: {reset_date}                                                    │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  Your previous scans are still available.                               │ │
│  │  You can still view graphs, preview code, and see audit summaries.      │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  Upgrade to Solo ($49/mo) for unlimited scans:                               │
│  → replimap upgrade solo                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # CLONE LIMITS
    # =========================================================================
    "clone_download_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📦 Terraform Code Generated Successfully!                                    │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  Resources scanned:    {resource_count:,}                                │ │
│  │  Lines of code:        {lines_count:,}                                   │ │
│  │  Files generated:      {file_count}                                      │ │
│  │  Estimated time saved: {hours_saved} hours (~${money_saved} value)       │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  🔒 FREE PLAN: Preview only (first {preview_lines} lines shown)              │
│                                                                               │
│  To download the complete Terraform code:                                    │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  Solo Plan: $49/month                                                    │ │
│  │                                                                          │ │
│  │  ✓ Download unlimited Terraform code                                     │ │
│  │  ✓ Full audit reports with remediation steps                             │ │
│  │  ✓ Graph exports without watermark                                       │ │
│  │  ✓ Local caching with SQLite + Zstd compression                          │ │
│  │  ✓ Email support (48h SLA)                                               │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  → replimap upgrade solo                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
│  💡 At $49/mo, that's less than 30 minutes of your hourly rate.              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "clone_preview_truncated": """
# ─────────────────────────────────────────────────────────────────────────────
# ... {remaining_lines:,} more lines hidden ...
#
# 🔒 FREE PLAN: Preview only ({preview_lines} of {total_lines:,} lines)
#
# Generated: {resource_count:,} resources in {file_count} files
# Estimated time saved: {hours_saved} hours
#
# → replimap upgrade solo  (Download complete code)
# ─────────────────────────────────────────────────────────────────────────────
""",
    # =========================================================================
    # AUDIT LIMITS
    # =========================================================================
    "audit_limited_view": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🛡️ Security Audit Complete                                                  │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │                                                                          │ │
│  │  Security Score:  {score}/100  Grade: {grade}                           │ │
│  │                                                                          │ │
│  │  Issues Found:                                                           │ │
│  │  ├── 🔴 CRITICAL:  {critical_count}                                      │ │
│  │  ├── 🟠 HIGH:      {high_count}                                          │ │
│  │  ├── 🟡 MEDIUM:    {medium_count}                                        │ │
│  │  └── 🔵 LOW:       {low_count}                                           │ │
│  │                                                                          │ │
│  │  TOTAL: {total_count} security issues detected                          │ │
│  │                                                                          │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  🔒 FREE PLAN: All {total_count} issue titles visible                        │
│  First CRITICAL shown with 2-line remediation preview                        │
│                                                                               │
│  💊 You can see the problems. Now get the cure.                              │
│                                                                               │
│  Upgrade to Solo ($49/mo) to unlock:                                         │
│  ✓ Complete remediation steps for all {total_count} issues                   │
│  ✓ Affected resource lists                                                   │
│  ✓ Terraform/AWS CLI fix commands                                            │
│  ✓ Exportable HTML reports                                                   │
│                                                                               │
│  → replimap upgrade solo                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_export_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📄 Report Export Requires Solo Plan                                         │
│                                                                               │
│  FREE plan includes:                                                         │
│  ✓ Full security scanning                                                    │
│  ✓ Summary scores and counts                                                 │
│  ✓ All issue titles visible                                                  │
│  ✓ First CRITICAL with 2-line remediation preview                            │
│                                                                               │
│  Solo plan ($49/mo) adds:                                                    │
│  ✓ Export to HTML report                                                     │
│  ✓ Complete remediation details for all issues                               │
│  ✓ Affected resources list                                                   │
│  ✓ Terraform fix suggestions                                                 │
│                                                                               │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_ci_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 CI/CD Mode Requires Pro Plan                                             │
│                                                                               │
│  The --fail-on-high flag is a Pro feature.                                   │
│                                                                               │
│  Pro plan ($99/mo) includes:                                                 │
│  ✓ CI/CD integration (--fail-on-high, --fail-on-score)                       │
│  ✓ Drift detection                                                           │
│  ✓ HTML + PDF report exports                                                 │
│  ✓ 3 AWS accounts                                                            │
│  ✓ 24h email support SLA                                                     │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_fix_blocked": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 Auto-Remediation Requires Solo Plan                                      │
│                                                                               │
│  The --fix flag generates Terraform code to fix security issues.             │
│                                                                               │
│  Solo plan ($49/mo) includes:                                                │
│  ✓ Auto-remediation code generation (--fix)                                  │
│  ✓ View all audit findings with full remediation                             │
│  ✓ Export HTML reports                                                       │
│  ✓ Unlimited scans                                                           │
│  ✓ Local caching + snapshots                                                 │
│                                                                               │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # DRIFT LIMITS
    # =========================================================================
    "drift_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Drift Detection is a Pro Feature                                         │
│                                                                               │
│  Drift detection helps you:                                                  │
│  • Find unauthorized changes in AWS                                          │
│  • Ensure Terraform state stays in sync                                      │
│  • Meet SOC2 CC8.1 Change Management requirements                            │
│  • Catch "console cowboys" who bypass IaC                                    │
│                                                                               │
│  Pro plan ($99/mo) includes:                                                 │
│  ✓ Drift detection                                                           │
│  ✓ CI/CD integration (--fail-on)                                             │
│  ✓ HTML + PDF report exports                                                 │
│  ✓ 3 AWS accounts                                                            │
│  ✓ Remediate beta access                                                     │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "drift_watch_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  👁️ Drift Watch Mode is a Team Feature                                       │
│                                                                               │
│  Watch mode provides:                                                        │
│  • Continuous drift monitoring                                               │
│  • Slack/Teams alerts when drift detected                                    │
│  • Scheduled scans                                                           │
│                                                                               │
│  Team plan ($199/mo) includes:                                               │
│  ✓ Drift watch mode                                                          │
│  ✓ Alert notifications                                                       │
│  ✓ Trust Center for audit logging                                            │
│  ✓ Dependency exploration                                                    │
│  ✓ 10 AWS accounts                                                           │
│  ✓ 5 team members                                                            │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # OTHER FEATURE LIMITS
    # =========================================================================
    "cost_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💰 Full Cost Estimation is a Solo Feature                                   │
│                                                                               │
│  Cost estimation helps you:                                                  │
│  • Know how much your staging will cost before cloning                       │
│  • Find cost optimization opportunities                                      │
│  • Plan infrastructure budgets                                               │
│                                                                               │
│  FREE plan includes basic cost estimates.                                    │
│                                                                               │
│  Solo plan ($49/mo) adds:                                                    │
│  ✓ Full cost breakdown                                                       │
│  ✓ Cost diff comparison                                                      │
│  ✓ Right-Sizer optimization                                                  │
│                                                                               │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "cost_diff_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💰 Cost Diff is a Solo Feature                                              │
│                                                                               │
│  Cost diff (replimap cost --diff) compares infrastructure costs:             │
│  • Before vs after changes                                                   │
│  • Production vs staging estimates                                           │
│  • Identify cost drivers                                                     │
│                                                                               │
│  Solo plan ($49/mo) includes:                                                │
│  ✓ Cost diff comparison                                                      │
│  ✓ Full cost breakdown                                                       │
│  ✓ Right-Sizer optimization                                                  │
│                                                                               │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "right_sizer_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  ⚡ Right-Sizer is a Solo+ Feature                                           │
│                                                                               │
│  Right-Sizer automatically optimizes production resources for dev/staging:   │
│                                                                               │
│  • EC2: m5.2xlarge → t3.large (80%+ savings)                                 │
│  • RDS: db.r5.xlarge → db.t3.large, Multi-AZ → Single-AZ                     │
│  • ElastiCache: cache.r6g.xlarge → cache.t3.medium                           │
│  • Storage: io1/gp2 → gp3 (cost-effective)                                   │
│                                                                               │
│  Architecture-safe recommendations (no x86↔ARM issues)                       │
│  Generates right-sizer.auto.tfvars for easy overrides                        │
│                                                                               │
│  Solo plan ($49/mo) includes:                                                │
│  ✓ Right-Sizer optimization                                                  │
│  ✓ Unlimited scans                                                           │
│  ✓ Full code downloads                                                       │
│  ✓ Complete audit reports                                                    │
│  ✓ Local caching + snapshots                                                 │
│                                                                               │
│  → replimap upgrade solo                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "deps_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Dependency Explorer is a Team Feature                                    │
│                                                                               │
│  Dependency Explorer helps you understand:                                   │
│  • What resources may be affected by changes                                 │
│  • AWS API-detected dependency chains                                        │
│  • Suggested order for reviewing changes                                     │
│                                                                               │
│  Note: Only AWS API-visible dependencies are detected.                       │
│  Application-level dependencies are not detected.                            │
│                                                                               │
│  → replimap upgrade team ($199/mo)                                           │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # Backward compatibility alias
    "blast_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔍 Dependency Explorer is a Team Feature                                    │
│                                                                               │
│  Dependency Explorer helps you understand:                                   │
│  • What resources may be affected by changes                                 │
│  • AWS API-detected dependency chains                                        │
│  • Suggested order for reviewing changes                                     │
│                                                                               │
│  Note: Only AWS API-visible dependencies are detected.                       │
│  Application-level dependencies are not detected.                            │
│                                                                               │
│  → replimap upgrade team ($199/mo)                                           │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "multi_account_limit": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔐 Multiple AWS Accounts Require Upgrade                                    │
│                                                                               │
│  You're trying to use {current_count} AWS accounts.                          │
│  Your current plan allows {limit} account(s).                                │
│                                                                               │
│  Upgrade to {upgrade_plan} (${upgrade_price}/mo) for more accounts.          │
│                                                                               │
│  → replimap upgrade {upgrade_plan_lower}                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # GRAPH WATERMARK
    # =========================================================================
    "graph_watermark_notice": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📊 Graph Exported (with watermark)                                          │
│                                                                               │
│  Your architecture graph has been exported.                                  │
│  FREE plan exports include a RepliMap watermark.                             │
│                                                                               │
│  Upgrade to Solo ($49/mo) for watermark-free exports.                        │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # OUTPUT FORMAT LIMITS
    # =========================================================================
    "cloudformation_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  ☁️ CloudFormation Output Requires Pro Plan                                  │
│                                                                               │
│  FREE/Solo plans include Terraform output.                                   │
│                                                                               │
│  Pro plan ($99/mo) adds:                                                     │
│  ✓ CloudFormation YAML output                                                │
│  ✓ Pulumi Python output                                                      │
│  ✓ Drift detection                                                           │
│  ✓ 3 AWS accounts                                                            │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "pulumi_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 Pulumi Output Requires Pro Plan                                          │
│                                                                               │
│  FREE/Solo plans include Terraform output.                                   │
│                                                                               │
│  Pro plan ($99/mo) adds:                                                     │
│  ✓ Pulumi Python output                                                      │
│  ✓ CloudFormation YAML output                                                │
│  ✓ Drift detection                                                           │
│  ✓ 3 AWS accounts                                                            │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "cdk_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔧 CDK Output Requires Team Plan                                            │
│                                                                               │
│  Team plan ($199/mo) includes:                                               │
│  ✓ AWS CDK output                                                            │
│  ✓ All IaC formats (Terraform, CloudFormation, Pulumi)                       │
│  ✓ Drift watch mode with alerts                                              │
│  ✓ Trust Center for audit logging                                            │
│  ✓ Dependency exploration                                                    │
│  ✓ 10 AWS accounts                                                           │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # STORAGE LAYER LIMITS (Solo+)
    # =========================================================================
    "local_cache_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💾 Local Caching is a Solo Feature                                          │
│                                                                               │
│  Local caching with SQLite + Zstd provides:                                  │
│  • 5x+ compression for AWS configs                                           │
│  • Lazy loading - topology first, config on-demand                           │
│  • Fast subsequent scans                                                     │
│                                                                               │
│  Solo plan ($49/mo) includes:                                                │
│  ✓ Local SQLite cache                                                        │
│  ✓ Zstd compression (5x+)                                                    │
│  ✓ 5 historical snapshots                                                    │
│  ✓ 7 days retention                                                          │
│                                                                               │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "snapshot_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📸 Snapshots is a Solo Feature                                              │
│                                                                               │
│  Snapshots let you:                                                          │
│  • Save infrastructure state at a point in time                              │
│  • Compare changes over time                                                 │
│  • Track infrastructure evolution                                            │
│                                                                               │
│  Solo plan ($49/mo) includes:                                                │
│  ✓ 5 historical snapshots                                                    │
│  ✓ 7 days retention                                                          │
│                                                                               │
│  Pro plan ($99/mo) includes:                                                 │
│  ✓ 15 snapshots, 30 days retention                                           │
│                                                                               │
│  → replimap upgrade solo                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "snapshot_limit_reached": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📸 Snapshot Limit Reached                                                   │
│                                                                               │
│  You have {current}/{limit} snapshots stored.                                │
│                                                                               │
│  Options:                                                                    │
│  • Delete older snapshots: replimap snapshot delete <name>                   │
│  • Upgrade for more snapshots                                                │
│                                                                               │
│  Pro plan ($99/mo): 15 snapshots, 30 days retention                          │
│  Team plan ($199/mo): 30 snapshots, 90 days retention                        │
│  Enterprise: Unlimited snapshots, 1 year retention                           │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # TRUST CENTER LIMITS (Team+)
    # =========================================================================
    "trust_center_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔒 Trust Center is a Team Feature                                           │
│                                                                               │
│  Trust Center provides audit logging for compliance:                         │
│  • API call recording                                                        │
│  • Session history                                                           │
│  • Audit log retention                                                       │
│  • Exportable reports                                                        │
│                                                                               │
│  Team plan ($199/mo) includes:                                               │
│  ✓ Trust Center with basic logging                                           │
│  ✓ Last 100 API calls recorded                                               │
│  ✓ 10 session history                                                        │
│  ✓ 7 days retention                                                          │
│  ✓ JSON export                                                               │
│                                                                               │
│  Enterprise (from $500/mo) adds:                                             │
│  ✓ Unlimited recordings                                                      │
│  ✓ 1 year retention                                                          │
│  ✓ Digital signatures (SHA256)                                               │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  → replimap upgrade team                                                     │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "trust_export_format_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📄 {format} Export Requires Enterprise                                      │
│                                                                               │
│  Team plan includes JSON export only.                                        │
│                                                                               │
│  Enterprise (from $500/mo) includes:                                         │
│  ✓ JSON, CSV, and PDF exports                                                │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident reports                                                    │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "trust_verify_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🔐 Trust Verify is an Enterprise Feature                                    │
│                                                                               │
│  Trust verify provides digital signatures for audit reports:                 │
│  • SHA256 signed reports                                                     │
│  • Tamper-evident verification                                               │
│  • Compliance attestation                                                    │
│                                                                               │
│  Enterprise (from $500/mo) includes:                                         │
│  ✓ Digital signatures (SHA256)                                               │
│  ✓ Tamper-evident reports                                                    │
│  ✓ APRA CPS 234 / RBNZ BS11 compliance mapping                               │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "trust_compliance_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📋 Compliance Reports is an Enterprise Feature                              │
│                                                                               │
│  Compliance reports provide tamper-evident audit trails for:                 │
│  • APRA CPS 234 (Australia)                                                  │
│  • Essential Eight (Australia)                                               │
│  • RBNZ BS11 (New Zealand)                                                   │
│  • NZISM (New Zealand)                                                       │
│                                                                               │
│  Enterprise (from $500/mo) includes all compliance features.                 │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # REGIONAL COMPLIANCE LIMITS (Enterprise only)
    # =========================================================================
    "compliance_apra_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇦🇺 APRA CPS 234 Mapping is an Enterprise Feature                           │
│                                                                               │
│  APRA CPS 234 compliance mapping helps Australian financial institutions     │
│  meet information security capability requirements.                          │
│                                                                               │
│  Enterprise (from $500/mo) includes:                                         │
│  ✓ APRA CPS 234 control mapping                                              │
│  ✓ Essential Eight assessment                                                │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "compliance_e8_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇦🇺 Essential Eight Assessment is an Enterprise Feature                     │
│                                                                               │
│  Essential Eight assessment helps Australian organizations meet              │
│  ASD's top mitigation strategies.                                            │
│                                                                               │
│  Enterprise (from $500/mo) includes:                                         │
│  ✓ Essential Eight assessment                                                │
│  ✓ APRA CPS 234 control mapping                                              │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "compliance_rbnz_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇳🇿 RBNZ BS11 Mapping is an Enterprise Feature                              │
│                                                                               │
│  RBNZ BS11 compliance mapping helps New Zealand financial institutions       │
│  meet cyber resilience requirements.                                         │
│                                                                               │
│  Enterprise (from $500/mo) includes:                                         │
│  ✓ RBNZ BS11 compliance mapping                                              │
│  ✓ NZISM alignment                                                           │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "compliance_nzism_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🇳🇿 NZISM Alignment is an Enterprise Feature                                │
│                                                                               │
│  NZISM alignment helps New Zealand organizations meet                        │
│  government security requirements.                                           │
│                                                                               │
│  Enterprise (from $500/mo) includes:                                         │
│  ✓ NZISM alignment                                                           │
│  ✓ RBNZ BS11 compliance mapping                                              │
│  ✓ Digital signatures                                                        │
│  ✓ Tamper-evident compliance reports                                         │
│                                                                               │
│  Contact sales for Enterprise pricing.                                       │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # AUDIT EXPORT FORMAT LIMITS
    # =========================================================================
    "audit_export_format_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  📄 {format} Audit Export Requires Upgrade                                   │
│                                                                               │
│  Current plan exports: Limited formats                                       │
│                                                                               │
│  Solo ($49/mo): HTML only                                                    │
│  Pro ($99/mo): HTML + PDF                                                    │
│  Team ($199/mo): HTML + PDF + JSON                                           │
│  Enterprise: All formats including CSV                                       │
│                                                                               │
│  → replimap upgrade                                                          │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # REMEDIATE BETA LIMITS
    # =========================================================================
    "remediate_not_available": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🚀 Remediate Beta is a Pro+ Feature                                         │
│                                                                               │
│  Remediate automatically fixes security issues in your infrastructure.       │
│                                                                               │
│  Pro plan ($99/mo): Priority beta access                                     │
│  Team plan ($199/mo): Priority beta access                                   │
│  Enterprise: First access to new features                                    │
│                                                                               │
│  → replimap upgrade pro                                                      │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    # =========================================================================
    # FOMO DESIGN PROMPTS (v3.2)
    # =========================================================================
    "audit_fomo_unlock": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  💊 You can see the problems. Now get the cure.                              │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  All {total_count} issue titles shown above.                            │ │
│  │  {hidden_count} remediation details hidden.                             │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  Upgrade to Solo ($49/mo) to unlock:                                         │
│                                                                               │
│  ✓ Complete remediation steps for all {total_count} issues                   │
│  ✓ Affected resource lists with exact file locations                         │
│  ✓ Terraform/AWS CLI fix commands                                            │
│  ✓ Exportable HTML reports                                                   │
│  ✓ Local caching with SQLite + Zstd compression                              │
│                                                                               │
│  → replimap upgrade solo                                                     │
│  → https://replimap.com/pricing                                              │
│                                                                               │
│  💡 At $49/mo, that's less than 30 minutes of your hourly rate.              │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
    "audit_fomo_first_critical": """
     ┌─ Remediation Preview (First CRITICAL) ─────────────────────────────────┐
     │                                                                         │
     │  {preview_code}                                                        │
     │                                                                         │
     │  ... {remaining_lines} more lines hidden                                │
     │                                                                         │
     │  🔒 Upgrade to Solo ($49/mo) for full remediation code                  │
     │                                                                         │
     └─────────────────────────────────────────────────────────────────────────┘
""",
    "audit_fomo_summary": """
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                               │
│  🛡️ Security Audit Complete                                                  │
│                                                                               │
│  Security Score:  {score}/100  Grade: {grade}                                │
│                                                                               │
│  Issues Found:                                                               │
│  ├── 🔴 CRITICAL:  {critical_count}                                          │
│  ├── 🟠 HIGH:      {high_count}                                              │
│  ├── 🟡 MEDIUM:    {medium_count}                                            │
│  └── 🔵 LOW:       {low_count}                                               │
│                                                                               │
│  TOTAL: {total_count} security issues detected                               │
│                                                                               │
│  ─────────────────────────────────────────────────────────────────────────── │
│                                                                               │
│  🔒 FREE PLAN: All {total_count} issue titles visible                        │
│  First CRITICAL shown with 2-line remediation preview                        │
│                                                                               │
│  💡 You know what's broken. Upgrade to fix it.                               │
│                                                                               │
└──────────────────────────────────────────────────────────────────────────────┘
""",
}


def get_upgrade_prompt(key: str, params: dict[str, Any] | None = None) -> str:
    """
    Get an upgrade prompt with parameters filled in.

    Args:
        key: The prompt key from UPGRADE_PROMPTS
        params: Dictionary of parameters to format into the prompt

    Returns:
        Formatted upgrade prompt string
    """
    prompt = UPGRADE_PROMPTS.get(key, "")
    if params:
        try:
            prompt = prompt.format(**params)
        except KeyError:
            # If some params are missing, just return what we can
            pass
    return prompt


def format_scan_limit_prompt(used: int, limit: int, reset_date: str) -> str:
    """Format the scan limit reached prompt."""
    return get_upgrade_prompt(
        "scan_monthly_limit",
        {
            "used": used,
            "limit": limit,
            "reset_date": reset_date,
        },
    )


def format_clone_blocked_prompt(
    resource_count: int,
    lines_count: int,
    file_count: int,
    preview_lines: int = 100,
) -> str:
    """Format the clone download blocked prompt."""
    hours_saved = max(1, resource_count // 10)
    money_saved = hours_saved * 100  # $100/hour estimate

    return get_upgrade_prompt(
        "clone_download_blocked",
        {
            "resource_count": resource_count,
            "lines_count": lines_count,
            "file_count": file_count,
            "preview_lines": preview_lines,
            "hours_saved": hours_saved,
            "money_saved": money_saved,
        },
    )


def format_clone_preview_footer(
    remaining_lines: int,
    preview_lines: int,
    total_lines: int,
    resource_count: int,
    file_count: int,
) -> str:
    """Format the footer to append to truncated clone output."""
    hours_saved = max(1, resource_count // 10)

    return get_upgrade_prompt(
        "clone_preview_truncated",
        {
            "remaining_lines": remaining_lines,
            "preview_lines": preview_lines,
            "total_lines": total_lines,
            "resource_count": resource_count,
            "file_count": file_count,
            "hours_saved": hours_saved,
        },
    )


def format_audit_limited_prompt(
    score: int,
    grade: str,
    critical_count: int,
    high_count: int,
    medium_count: int,
    low_count: int,
    shown_count: int,
    total_count: int,
    hidden_critical: int,
) -> str:
    """Format the audit limited findings prompt."""
    return get_upgrade_prompt(
        "audit_limited_view",
        {
            "score": score,
            "grade": grade,
            "critical_count": critical_count,
            "high_count": high_count,
            "medium_count": medium_count,
            "low_count": low_count,
            "shown_count": shown_count,
            "total_count": total_count,
            "hidden_critical": hidden_critical,
        },
    )


def format_multi_account_prompt(
    current_count: int,
    limit: int,
    upgrade_plan: str,
    upgrade_price: int,
) -> str:
    """Format the multi-account limit prompt."""
    return get_upgrade_prompt(
        "multi_account_limit",
        {
            "current_count": current_count,
            "limit": limit,
            "upgrade_plan": upgrade_plan,
            "upgrade_price": upgrade_price,
            "upgrade_plan_lower": upgrade_plan.lower(),
        },
    )


def format_snapshot_limit_prompt(current_count: int, limit: int) -> str:
    """Format the snapshot limit reached prompt."""
    return get_upgrade_prompt(
        "snapshot_limit_reached",
        {
            "current": current_count,
            "limit": limit,
        },
    )


def format_audit_fomo_unlock(total_count: int, hidden_count: int) -> str:
    """
    Format the FOMO unlock prompt for audit findings.

    Shown when FREE users have hidden remediation details.

    Args:
        total_count: Total number of findings
        hidden_count: Number of findings with hidden remediation
    """
    return get_upgrade_prompt(
        "audit_fomo_unlock",
        {
            "total_count": total_count,
            "hidden_count": hidden_count,
        },
    )


def format_audit_fomo_summary(
    score: int,
    grade: str,
    critical_count: int,
    high_count: int,
    medium_count: int,
    low_count: int,
    total_count: int,
) -> str:
    """
    Format the FOMO summary for audit findings.

    Shows score and severity breakdown with upgrade hints.

    Args:
        score: Security score (0-100)
        grade: Letter grade (A-F)
        critical_count: Number of CRITICAL findings
        high_count: Number of HIGH findings
        medium_count: Number of MEDIUM findings
        low_count: Number of LOW findings
        total_count: Total number of findings
    """
    return get_upgrade_prompt(
        "audit_fomo_summary",
        {
            "score": score,
            "grade": grade,
            "critical_count": critical_count,
            "high_count": high_count,
            "medium_count": medium_count,
            "low_count": low_count,
            "total_count": total_count,
        },
    )


def format_audit_fomo_first_critical(
    preview_code: str,
    remaining_lines: int,
) -> str:
    """
    Format the first CRITICAL remediation preview.

    Shows 2 lines of remediation code as a teaser.

    Args:
        preview_code: First 2 lines of remediation code
        remaining_lines: Number of lines hidden
    """
    return get_upgrade_prompt(
        "audit_fomo_first_critical",
        {
            "preview_code": preview_code,
            "remaining_lines": remaining_lines,
        },
    )
