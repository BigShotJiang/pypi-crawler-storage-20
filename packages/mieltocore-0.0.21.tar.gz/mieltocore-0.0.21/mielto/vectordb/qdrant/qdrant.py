from hashlib import md5
from typing import Any, Dict, List, Optional

try:
    from qdrant_client import AsyncQdrantClient, QdrantClient  # noqa: F401
    from qdrant_client.http import models
except ImportError:
    raise ImportError(
        "The `qdrant-client` package is not installed. Please install it via `pip install qdrant-client`."
    )

from mielto.knowledge.document import Document
from mielto.knowledge.embedder import Embedder
from mielto.knowledge.reranker.base import Reranker
from mielto.utils.log import log_debug, log_error, log_info, log_warning
from mielto.vectordb.base import VectorDb
from mielto.vectordb.distance import Distance
from mielto.vectordb.search import SearchType
from mielto.utils.common import generate_prefix_ulid

DEFAULT_DENSE_VECTOR_NAME = "dense"
DEFAULT_SPARSE_VECTOR_NAME = "sparse"
DEFAULT_SPARSE_MODEL = "Qdrant/bm25"


class Qdrant(VectorDb):
    """Vector DB implementation powered by Qdrant - https://qdrant.tech/"""

    def __init__(
        self,
        collection: str,
        embedder: Optional[Embedder] = None,
        distance: Distance = Distance.cosine,
        location: Optional[str] = None,
        url: Optional[str] = None,
        port: Optional[int] = 6333,
        grpc_port: int = 6334,
        prefer_grpc: bool = False,
        https: Optional[bool] = None,
        api_key: Optional[str] = None,
        prefix: Optional[str] = None,
        timeout: Optional[float] = None,
        host: Optional[str] = None,
        path: Optional[str] = None,
        reranker: Optional[Reranker] = None,
        search_type: SearchType = SearchType.vector,
        dense_vector_name: str = DEFAULT_DENSE_VECTOR_NAME,
        sparse_vector_name: str = DEFAULT_SPARSE_VECTOR_NAME,
        hybrid_fusion_strategy: models.Fusion = models.Fusion.RRF,
        fastembed_kwargs: Optional[dict] = None,
        **kwargs,
    ):
        """
        Args:
            collection (str): Name of the Qdrant collection.
            embedder (Optional[Embedder]): Optional embedder for automatic vector generation.
            distance (Distance): Distance metric to use (default: cosine).
            location (Optional[str]): `":memory:"` for in-memory, or str used as `url`. If `None`, use default host/port.
            url (Optional[str]): Full URL (scheme, host, port, prefix). Overrides host/port if provided.
            port (Optional[int]): REST API port (default: 6333).
            grpc_port (int): gRPC interface port (default: 6334).
            prefer_grpc (bool): Prefer gRPC over REST if True.
            https (Optional[bool]): Use HTTPS if True.
            api_key (Optional[str]): API key for Qdrant Cloud authentication.
            prefix (Optional[str]): URL path prefix (e.g., "service/v1").
            timeout (Optional[float]): Request timeout (REST: default 5s, gRPC: unlimited).
            host (Optional[str]): Qdrant host (default: "localhost" if not specified).
            path (Optional[str]): Path for local persistence (QdrantLocal).
            reranker (Optional[Reranker]): Optional reranker for result refinement.
            search_type (SearchType): Whether to use vector, keyword or hybrid search.
            dense_vector_name (str): Dense vector name.
            sparse_vector_name (str): Sparse vector name.
            hybrid_fusion_strategy (models.Fusion): Strategy for hybrid fusion.
            fastembed_kwargs (Optional[dict]): Keyword args for `fastembed.SparseTextEmbedding.__init__()`.
            **kwargs: Keyword args for `qdrant_client.QdrantClient.__init__()`.
        """
        # Collection attributes
        self.collection: str = collection

        # Embedder for embedding the document contents
        if embedder is None:
            from mielto.knowledge.embedder.openai import OpenAIEmbedder

            embedder = OpenAIEmbedder()
            log_info("Embedder not provided, using OpenAIEmbedder as default.")

        self.embedder: Embedder = embedder
        self.dimensions: Optional[int] = self.embedder.dimensions

        # Distance metric
        self.distance: Distance = distance

        # Qdrant client instance
        self._client: Optional[QdrantClient] = None

        # Qdrant async client instance
        self._async_client: Optional[AsyncQdrantClient] = None

        # Qdrant client arguments
        self.location: Optional[str] = location
        self.url: Optional[str] = url
        self.port: Optional[int] = port
        self.grpc_port: int = grpc_port
        self.prefer_grpc: bool = prefer_grpc
        self.https: Optional[bool] = https
        self.api_key: Optional[str] = api_key
        self.prefix: Optional[str] = prefix
        self.timeout: Optional[float] = timeout
        self.host: Optional[str] = host
        self.path: Optional[str] = path

        # Reranker instance
        self.reranker: Optional[Reranker] = reranker

        # Qdrant client kwargs
        self.kwargs = kwargs

        self.search_type = search_type
        self.dense_vector_name = dense_vector_name
        self.sparse_vector_name = sparse_vector_name
        self.hybrid_fusion_strategy = hybrid_fusion_strategy

        # TODO(v2.0.0): Remove backward compatibility for unnamed vectors
        # TODO(v2.0.0): Make named vectors mandatory and simplify the codebase
        self.use_named_vectors = search_type in [SearchType.hybrid]

        if self.search_type in [SearchType.keyword, SearchType.hybrid]:
            try:
                from fastembed import SparseTextEmbedding  # type: ignore

                default_kwargs = {"model_name": DEFAULT_SPARSE_MODEL}
                if fastembed_kwargs:
                    default_kwargs.update(fastembed_kwargs)

                self.sparse_encoder = SparseTextEmbedding(**default_kwargs)

            except ImportError as e:
                raise ImportError(
                    "To use keyword/hybrid search, install the `fastembed` extra with `pip install fastembed`."
                ) from e

    @property
    def client(self) -> QdrantClient:
        if self._client is None:
            log_debug("Creating Qdrant Client")
            self._client = QdrantClient(
                location=self.location,
                url=self.url,
                port=self.port,
                grpc_port=self.grpc_port,
                prefer_grpc=self.prefer_grpc,
                https=self.https,
                api_key=self.api_key,
                prefix=self.prefix,
                timeout=int(self.timeout) if self.timeout is not None else None,
                host=self.host,
                path=self.path,
                **self.kwargs,
            )
        return self._client

    @property
    def async_client(self) -> AsyncQdrantClient:
        """Get or create the async Qdrant client."""
        if self._async_client is None:
            log_debug("Creating Async Qdrant Client")
            self._async_client = AsyncQdrantClient(
                location=self.location,
                url=self.url,
                port=self.port,
                grpc_port=self.grpc_port,
                prefer_grpc=self.prefer_grpc,
                https=self.https,
                api_key=self.api_key,
                prefix=self.prefix,
                timeout=int(self.timeout) if self.timeout is not None else None,
                host=self.host,
                path=self.path,
                **self.kwargs,
            )
        return self._async_client

    def create(self) -> None:
        _distance = models.Distance.COSINE
        if self.distance == Distance.l2:
            _distance = models.Distance.EUCLID
        elif self.distance == Distance.max_inner_product:
            _distance = models.Distance.DOT

        if not self.exists():
            log_debug(f"Creating collection: {self.collection}")

            # Configure vectors based on search type
            if self.search_type == SearchType.vector:
                # Maintain backward compatibility with unnamed vectors
                vectors_config = models.VectorParams(size=self.dimensions, distance=_distance)
            else:
                # Use named vectors for hybrid search
                vectors_config = {self.dense_vector_name: models.VectorParams(size=self.dimensions, distance=_distance)}  # type: ignore

            self.client.create_collection(
                collection_name=self.collection,
                vectors_config=vectors_config,
                sparse_vectors_config={self.sparse_vector_name: models.SparseVectorParams()}
                if self.search_type in [SearchType.keyword, SearchType.hybrid]
                else None,
            )

            indexes = ["workspace_id", "collection_id", "content_id", "content_hash", "user_id"]
            for index in indexes:
                self.client.create_payload_index(
                    collection_name=self.collection,
                    field_name=index,
                    field_schema="keyword",
                )

    async def async_create(self) -> None:
        """Create the collection asynchronously."""
        # Collection distance
        _distance = models.Distance.COSINE
        if self.distance == Distance.l2:
            _distance = models.Distance.EUCLID
        elif self.distance == Distance.max_inner_product:
            _distance = models.Distance.DOT

        if not await self.async_exists():
            log_debug(f"Creating collection asynchronously: {self.collection}")

            # Configure vectors based on search type
            if self.search_type == SearchType.vector:
                # Maintain backward compatibility with unnamed vectors
                vectors_config = models.VectorParams(size=self.dimensions, distance=_distance)
            else:
                # Use named vectors for hybrid search
                vectors_config = {self.dense_vector_name: models.VectorParams(size=self.dimensions, distance=_distance)}  # type: ignore

            await self.async_client.create_collection(
                collection_name=self.collection,
                vectors_config=vectors_config,
                sparse_vectors_config={self.sparse_vector_name: models.SparseVectorParams()}
                if self.search_type in [SearchType.keyword, SearchType.hybrid]
                else None,
            )

            indexes = ["workspace_id", "collection_id", "content_id", "content_hash", "user_id"]
            for index in indexes:
                await self.async_client.create_payload_index(
                    collection_name=self.collection,
                    field_name=index,
                    field_schema="keyword",
                )

    def doc_exists(self, document: Document) -> bool:
        """
        Validating if the document exists or not

        Args:
            document (Document): Document to validate
        """
        if self.client:
            cleaned_content = document.content.replace("\x00", "\ufffd")
            doc_id = md5(cleaned_content.encode()).hexdigest()
            collection_points = self.client.retrieve(
                collection_name=self.collection,
                ids=[doc_id],
            )
            return len(collection_points) > 0
        return False

    async def async_doc_exists(self, document: Document) -> bool:
        """Check if a document exists asynchronously."""
        cleaned_content = document.content.replace("\x00", "\ufffd")
        doc_id = md5(cleaned_content.encode()).hexdigest()
        collection_points = await self.async_client.retrieve(
            collection_name=self.collection,
            ids=[doc_id],
        )
        return len(collection_points) > 0

    def name_exists(self, name: str) -> bool:
        """
        Validates if a document with the given name exists in the collection.

        Args:
            name (str): The name of the document to check.

        Returns:
            bool: True if a document with the given name exists, False otherwise.
        """
        if self.client:
            scroll_result = self.client.scroll(
                collection_name=self.collection,
                scroll_filter=models.Filter(
                    must=[models.FieldCondition(key="name", match=models.MatchValue(value=name))]
                ),
                limit=1,
            )
            return len(scroll_result[0]) > 0
        return False

    async def async_name_exists(self, name: str) -> bool:
        """
        Asynchronously validates if a document with the given name exists in the collection.

        Args:
            name (str): The name of the document to check.

        Returns:
            bool: True if a document with the given name exists, False otherwise.
        """
        if self.async_client:
            scroll_result = await self.async_client.scroll(
                collection_name=self.collection,
                scroll_filter=models.Filter(
                    must=[models.FieldCondition(key="name", match=models.MatchValue(value=name))]
                ),
                limit=1,
            )
            return len(scroll_result[0]) > 0
        return False

    def insert(
        self,
        content_hash: str,
        documents: List[Document],
        filters: Optional[Dict[str, Any]] = None,
        batch_size: int = 10,
    ) -> None:
        """
        Insert documents into the database.

        Args:
            documents (List[Document]): List of documents to insert
            filters (Optional[Dict[str, Any]]): Filters to apply while inserting documents
            batch_size (int): Batch size for inserting documents
        """
        log_debug(f"Inserting {len(documents)} documents")
        points = []
        for document in documents:
            cleaned_content = document.content.replace("\x00", "\ufffd")
            doc_id = md5(cleaned_content.encode()).hexdigest()

            # TODO(v2.0.0): Remove conditional vector naming logic
            if self.use_named_vectors:
                vector = {self.dense_vector_name: document.embedding}
            else:
                vector = document.embedding  # type: ignore

            if self.search_type == SearchType.vector:
                # For vector search, maintain backward compatibility with unnamed vectors
                document.embed(embedder=self.embedder)
                vector = document.embedding  # type: ignore
            else:
                # For other search types, use named vectors
                vector = {}
                if self.search_type in [SearchType.hybrid]:
                    document.embed(embedder=self.embedder)
                    vector[self.dense_vector_name] = document.embedding

                if self.search_type in [SearchType.keyword, SearchType.hybrid]:
                    vector[self.sparse_vector_name] = next(self.sparse_encoder.embed([document.content])).as_object()

            # Create payload with document properties
            payload = {
                "name": document.name,
                "meta_data": document.meta_data,
                "content": cleaned_content,
                "usage": document.usage,
                "content_id": document.content_id,
                "content_hash": content_hash,
            }

            # Add filters as metadata if provided
            if filters:
                # Merge filters with existing metadata
                if "meta_data" not in payload:
                    payload["meta_data"] = {}
                payload["meta_data"].update(filters)  # type: ignore

            points.append(
                models.PointStruct(
                    id=doc_id,
                    vector=vector,
                    payload=payload,
                )
            )
            log_debug(f"Inserted document: {document.name} ({document.meta_data})")
        if len(points) > 0:
            self.client.upsert(collection_name=self.collection, wait=False, points=points)
        log_debug(f"Upsert {len(points)} documents")

    async def async_insert(
        self, content_hash: str, documents: List[Document], filters: Optional[Dict[str, Any]] = None, 
        collection_id: Optional[str] = None, workspace_id: Optional[str] = None
    ) -> None:
        """
        Insert documents asynchronously.

        Args:
            documents (List[Document]): List of documents to insert
            filters (Optional[Dict[str, Any]]): Filters to apply while inserting documents
        """
        log_debug(f"Inserting {len(documents)} documents asynchronously")

        async def process_document(document):
            cleaned_content = document.content.replace("\x00", "\ufffd")
            doc_id = str(md5(cleaned_content.encode()).hexdigest())

            if self.search_type == SearchType.vector:
                # For vector search, maintain backward compatibility with unnamed vectors
                document.embed(embedder=self.embedder)
                vector = document.embedding
            else:
                # For other search types, use named vectors
                vector = {}
                if self.search_type in [SearchType.hybrid]:
                    document.embed(embedder=self.embedder)
                    vector[self.dense_vector_name] = document.embedding

                if self.search_type in [SearchType.keyword, SearchType.hybrid]:
                    vector[self.sparse_vector_name] = next(self.sparse_encoder.embed([document.content])).as_object()

            if self.search_type in [SearchType.keyword, SearchType.hybrid]:
                vector[self.sparse_vector_name] = next(self.sparse_encoder.embed([document.content])).as_object()

            # Create payload with document properties
            payload = {
                "name": document.name,
                "meta_data": document.meta_data,
                "content": cleaned_content,
                "usage": document.usage,
                "content_id": document.content_id,
                "content_hash": content_hash,
                "collection_id": collection_id,
                "workspace_id": workspace_id,
            }

            # Add filters as metadata if provided
            if filters:
                # Merge filters with existing metadata
                if "meta_data" not in payload:
                    payload["meta_data"] = {}
                payload["meta_data"].update(filters)

            log_debug(f"Inserted document asynchronously: {document.name} ({document.meta_data})")
            return models.PointStruct(
                id=doc_id,
                vector=vector,
                payload=payload,
            )

        import asyncio

        # Process all documents in parallel
        points = await asyncio.gather(*[process_document(doc) for doc in documents])

        if len(points) > 0:
            await self.async_client.upsert(collection_name=self.collection, wait=False, points=points)
        log_debug(f"Upserted {len(points)} documents asynchronously")

    def upsert(self, content_hash: str, documents: List[Document], filters: Optional[Dict[str, Any]] = None) -> None:
        """
        Upsert documents into the database.

        Args:
            documents (List[Document]): List of documents to upsert
            filters (Optional[Dict[str, Any]]): Filters to apply while upserting
        """
        log_debug("Redirecting the request to insert")
        if self.content_hash_exists(content_hash):
            self._delete_by_content_hash(content_hash)
        self.insert(content_hash=content_hash, documents=documents, filters=filters)

    async def async_upsert(
        self, content_hash: str, documents: List[Document], filters: Optional[Dict[str, Any]] = None
    ) -> None:
        """Upsert documents asynchronously."""
        log_debug("Redirecting the async request to async_insert")
        await self.async_insert(content_hash=content_hash, documents=documents, filters=filters)

    def search(self, query: str, limit: int = 5, filters: Optional[Dict[str, Any]] = None, collection_id: Optional[str] = None, workspace_id: Optional[str] = None, score_threshold: Optional[float] = None) -> List[Document]:
        """
        Search for documents in the collection.

        Args:
            query (str): Query to search for
            limit (int): Number of search results to return
            filters (Optional[Dict[str, Any]]): Filters to apply while searching
            collection_id (Optional[str]): Collection ID to filter by
            workspace_id (Optional[str]): Workspace ID to filter by
            score_threshold (Optional[float]): Minimum score threshold to filter results
        """
        filters = filters or {}

       
        if workspace_id:
            filters["workspace_id"] = workspace_id

        filters = self._format_filters(filters or {}, metadata_only=False) # type: ignore

        if self.search_type == SearchType.vector:
            results = self._run_vector_search_sync(query, limit, filters, score_threshold)
        elif self.search_type == SearchType.keyword:
            results = self._run_keyword_search_sync(query, limit, filters, score_threshold)
        elif self.search_type == SearchType.hybrid:
            results = self._run_hybrid_search_sync(query, limit, filters, score_threshold)
        else:
            raise ValueError(f"Unsupported search type: {self.search_type}")

        return self._build_search_results(results, query, score_threshold)

    async def async_search(
        self, query: str, limit: int = 5, filters: Optional[Dict[str, Any]] = None, collection_id: Optional[str] = None, workspace_id: Optional[str] = None, score_threshold: Optional[float] = None
    ) -> List[Document]:

        filters = filters or {}

        if workspace_id:
            filters["workspace_id"] = workspace_id

        filters = self._format_filters(filters or {}, metadata_only=False) # type: ignore

        if self.search_type == SearchType.vector:
            results = await self._run_vector_search_async(query, limit, filters, score_threshold)
        elif self.search_type == SearchType.keyword:
            results = await self._run_keyword_search_async(query, limit, filters, score_threshold)
        elif self.search_type == SearchType.hybrid:
            results = await self._run_hybrid_search_async(query, limit, filters, score_threshold)
        else:
            raise ValueError(f"Unsupported search type: {self.search_type}")

        return self._build_search_results(results, query, score_threshold)

    def _run_hybrid_search_sync(
        self,
        query: str,
        limit: int,
        filters: Optional[Dict[str, Any]],
        score_threshold: Optional[float] = None,
    ) -> List[models.ScoredPoint]:
        dense_embedding = self.embedder.get_embedding(query)
        sparse_embedding = next(self.sparse_encoder.embed([query])).as_object()
        query_kwargs = {
            "collection_name": self.collection,
            "prefetch": [
                models.Prefetch(
                    query=models.SparseVector(**sparse_embedding),
                    limit=limit,
                    using=self.sparse_vector_name,
                ),
                models.Prefetch(query=dense_embedding, limit=limit, using=self.dense_vector_name),
            ],
            "query": models.FusionQuery(fusion=self.hybrid_fusion_strategy),
            "with_vectors": True,
            "with_payload": True,
            "limit": limit,
            "query_filter": filters,
        }
        if score_threshold is not None:
            query_kwargs["score_threshold"] = score_threshold
        call = self.client.query_points(**query_kwargs)
        return call.points

    def _run_vector_search_sync(
        self,
        query: str,
        limit: int,
        filters: Optional[Dict[str, Any]],
        score_threshold: Optional[float] = None,
    ) -> List[models.ScoredPoint]:
        dense_embedding = self.embedder.get_embedding(query)

        query_kwargs = {
            "collection_name": self.collection,
            "query": dense_embedding,
            "with_vectors": True,
            "with_payload": True,
            "limit": limit,
            "query_filter": filters,
        }
        if score_threshold is not None:
            query_kwargs["score_threshold"] = score_threshold

        # TODO(v2.0.0): Remove this conditional and always use named vectors
        if self.use_named_vectors:
            query_kwargs["using"] = self.dense_vector_name
        
        call = self.client.query_points(**query_kwargs)
        return call.points

    def _run_keyword_search_sync(
        self,
        query: str,
        limit: int,
        filters: Optional[Dict[str, Any]],
        score_threshold: Optional[float] = None,
    ) -> List[models.ScoredPoint]:
        sparse_embedding = next(self.sparse_encoder.embed([query])).as_object()
        query_kwargs = {
            "collection_name": self.collection,
            "query": models.SparseVector(**sparse_embedding),
            "with_vectors": True,
            "with_payload": True,
            "limit": limit,
            "using": self.sparse_vector_name,
            "query_filter": filters,
        }
        if score_threshold is not None:
            query_kwargs["score_threshold"] = score_threshold
        call = self.client.query_points(**query_kwargs)
        return call.points

    async def _run_vector_search_async(
        self,
        query: str,
        limit: int,
        filters: Optional[Dict[str, Any]],
        score_threshold: Optional[float] = None,
    ) -> List[models.ScoredPoint]:
        dense_embedding = self.embedder.get_embedding(query)

        query_kwargs = {
            "collection_name": self.collection,
            "query": dense_embedding,
            "with_vectors": True,
            "with_payload": True,
            "limit": limit,
            "query_filter": filters,
        }
        if score_threshold is not None:
            query_kwargs["score_threshold"] = score_threshold

        # TODO(v2.0.0): Remove this conditional and always use named vectors
        if self.use_named_vectors:
            query_kwargs["using"] = self.dense_vector_name
        
        call = await self.async_client.query_points(**query_kwargs)
        return call.points

    async def _run_keyword_search_async(
        self,
        query: str,
        limit: int,
        filters: Optional[Dict[str, Any]],
        score_threshold: Optional[float] = None,
    ) -> List[models.ScoredPoint]:
        sparse_embedding = next(self.sparse_encoder.embed([query])).as_object()
        query_kwargs = {
            "collection_name": self.collection,
            "query": models.SparseVector(**sparse_embedding),
            "with_vectors": True,
            "with_payload": True,
            "limit": limit,
            "using": self.sparse_vector_name,
            "query_filter": filters,
        }
        if score_threshold is not None:
            query_kwargs["score_threshold"] = score_threshold
        call = await self.async_client.query_points(**query_kwargs)
        return call.points

    async def _run_hybrid_search_async(
        self,
        query: str,
        limit: int,
        filters: Optional[Dict[str, Any]],
        score_threshold: Optional[float] = None,
    ) -> List[models.ScoredPoint]:
        dense_embedding = self.embedder.get_embedding(query)
        sparse_embedding = next(self.sparse_encoder.embed([query])).as_object()
        query_kwargs = {
            "collection_name": self.collection,
            "prefetch": [
                models.Prefetch(
                    query=models.SparseVector(**sparse_embedding),
                    limit=limit,
                    using=self.sparse_vector_name,
                ),
                models.Prefetch(query=dense_embedding, limit=limit, using=self.dense_vector_name),
            ],
            "query": models.FusionQuery(fusion=self.hybrid_fusion_strategy),
            "with_vectors": True,
            "with_payload": True,
            "limit": limit,
            "query_filter": filters,
        }
        if score_threshold is not None:
            query_kwargs["score_threshold"] = score_threshold
        call = await self.async_client.query_points(**query_kwargs)
        return call.points

    def _build_search_results(self, results, query: str, score_threshold: Optional[float] = None) -> List[Document]:
        search_results: List[Document] = []

        for result in results:
            if result.payload is None:
                continue
            
            # Extract score from ScoredPoint
            score_value = getattr(result, 'score', None)
            
            # Filter by score_threshold if provided
            if score_threshold is not None and score_value is not None:
                if score_value < score_threshold:
                    continue
            
            metadata = result.payload.get("meta_data", {})
            if score_value is not None:
                metadata['score'] = float(score_value)
            
            search_results.append(
                Document(
                    name=result.payload["name"],
                    meta_data=metadata,
                    content=result.payload["content"],
                    embedder=self.embedder,
                    embedding=result.vector,  # type: ignore
                    usage=result.payload.get("usage"),
                    content_id=result.payload.get("content_id"),
                    score=float(score_value) if score_value is not None else None,
                    # collection_id=result.payload.get("collection_id"),
                    # workspace_id=result.payload.get("workspace_id"),
                )
            )

        if self.reranker:
            search_results = self.reranker.rerank(query=query, documents=search_results)

        log_info(f"Found {len(search_results)} documents")
        return search_results

    def _format_filters(self, filters: Optional[Dict[str, Any]], metadata_only: bool = True) -> Optional[models.Filter]:
        print(filters, "FILTERS")
        if filters:
            filter_conditions = []
            for key, value in filters.items():
                # If key contains a dot already, assume it's in the correct format
                # Otherwise, assume it's a metadata field and add the prefix
                if "." not in key and not key.startswith("meta_data.") and metadata_only:
                    # This is a simple field name, assume it's metadata
                    key = f"meta_data.{key}"

                if isinstance(value, dict):
                    # Handle nested dictionaries
                    for sub_key, sub_value in value.items():
                        filter_conditions.append(
                            models.FieldCondition(key=f"{key}.{sub_key}", match=models.MatchValue(value=sub_value))
                        )
                else:
                    # Handle direct key-value pairs
                    filter_conditions.append(models.FieldCondition(key=key, match=models.MatchValue(value=value)))

            if filter_conditions:
                return models.Filter(must=filter_conditions)

        return None

    def optimize(self) -> None:
        pass

    def drop(self) -> None:
        if self.exists():
            log_debug(f"Deleting collection: {self.collection}")
            self.client.delete_collection(self.collection)

    async def async_drop(self) -> None:
        """Drop the collection asynchronously."""
        if await self.async_exists():
            log_debug(f"Deleting collection asynchronously: {self.collection}")
            await self.async_client.delete_collection(self.collection)

    def exists(self) -> bool:
        """Check if the collection exists."""
        return self.client.collection_exists(collection_name=self.collection)

    async def async_exists(self) -> bool:
        """Check if the collection exists asynchronously."""
        return await self.async_client.collection_exists(collection_name=self.collection)

    def get_count(self) -> int:
        count_result: models.CountResult = self.client.count(collection_name=self.collection, exact=True)
        return count_result.count

    def point_exists(self, id: str) -> bool:
        """Check if a point with the given ID exists in the collection."""
        try:
            log_info(f"Checking if point with ID '{id}' (type: {type(id)}) exists in collection '{self.collection}'")
            points = self.client.retrieve(
                collection_name=self.collection, ids=[id], with_payload=False, with_vectors=False
            )
            log_info(f"Retrieved {len(points)} points for ID '{id}'")
            if len(points) > 0:
                log_info(f"Found point with ID: {points[0].id} (type: {type(points[0].id)})")
            return len(points) > 0
        except Exception as e:
            log_info(f"Error checking if point {id} exists: {e}")
            return False

    def delete(self) -> bool:
        return self.client.delete_collection(collection_name=self.collection)

    def delete_by_id(self, id: str) -> bool:
        try:
            # Check if point exists before deletion
            if not self.point_exists(id):
                log_warning(f"Point with ID {id} does not exist")
                return True

            self.client.delete(
                collection_name=self.collection,
                points_selector=models.PointIdsList(points=[id]),
                wait=True,  # Wait for the operation to complete
            )
            return True

        except Exception as e:
            log_info(f"Error deleting point with ID {id}: {e}")
            return False

    def delete_by_name(self, name: str) -> bool:
        """Delete all points that have the specified name in their payload (precise match)."""
        try:
            log_info(f"Attempting to delete all points with name: {name}")

            # Create a filter to find all points with the specified name (precise match)
            filter_condition = models.Filter(
                must=[models.FieldCondition(key="name", match=models.MatchValue(value=name))]
            )

            # First, count how many points will be deleted
            count_result = self.client.count(collection_name=self.collection, count_filter=filter_condition, exact=True)

            if count_result.count == 0:
                log_warning(f"No points found with name: {name}")
                return True

            log_info(f"Found {count_result.count} points to delete with name: {name}")

            # Delete all points matching the filter
            result = self.client.delete(
                collection_name=self.collection,
                points_selector=filter_condition,
                wait=True,  # Wait for the operation to complete
            )

            # Check if the deletion was successful
            if result.status == models.UpdateStatus.COMPLETED:
                log_info(f"Successfully deleted {count_result.count} points with name: {name}")
                return True
            else:
                log_warning(f"Deletion failed for name {name}. Status: {result.status}")
                return False

        except Exception as e:
            log_warning(f"Error deleting points with name {name}: {e}")
            return False

    def delete_by_metadata(self, metadata: Dict[str, Any]) -> bool:
        """Delete all points where the given metadata is contained in the meta_data payload field."""
        try:
            log_info(f"Attempting to delete all points with metadata: {metadata}")

            # Create filter conditions for each metadata key-value pair
            filter_conditions = []
            for key, value in metadata.items():
                # Use the meta_data prefix since that's how metadata is stored in the payload
                filter_conditions.append(
                    models.FieldCondition(key=f"meta_data.{key}", match=models.MatchValue(value=value))
                )

            # Create a filter that requires ALL metadata conditions to match
            filter_condition = models.Filter(must=filter_conditions)

            # First, count how many points will be deleted
            count_result = self.client.count(collection_name=self.collection, count_filter=filter_condition, exact=True)

            if count_result.count == 0:
                log_warning(f"No points found with metadata: {metadata}")
                return True

            log_info(f"Found {count_result.count} points to delete with metadata: {metadata}")

            # Delete all points matching the filter
            result = self.client.delete(
                collection_name=self.collection,
                points_selector=filter_condition,
                wait=True,  # Wait for the operation to complete
            )

            # Check if the deletion was successful
            if result.status == models.UpdateStatus.COMPLETED:
                log_info(f"Successfully deleted {count_result.count} points with metadata: {metadata}")
                return True
            else:
                log_warning(f"Deletion failed for metadata {metadata}. Status: {result.status}")
                return False

        except Exception as e:
            log_warning(f"Error deleting points with metadata {metadata}: {e}")
            return False

    def delete_by_content_id(self, content_id: str) -> bool:
        """Delete all points that have the specified content_id in their payload."""
        try:
            log_info(f"Attempting to delete all points with content_id: {content_id}")

            # Create a filter to find all points with the specified content_id
            filter_condition = models.Filter(
                must=[models.FieldCondition(key="content_id", match=models.MatchValue(value=content_id))]
            )

            # First, count how many points will be deleted
            count_result = self.client.count(collection_name=self.collection, count_filter=filter_condition, exact=True)

            if count_result.count == 0:
                log_warning(f"No points found with content_id: {content_id}")
                return True

            log_info(f"Found {count_result.count} points to delete with content_id: {content_id}")

            # Delete all points matching the filter
            result = self.client.delete(
                collection_name=self.collection,
                points_selector=filter_condition,
                wait=True,  # Wait for the operation to complete
            )

            # Check if the deletion was successful
            if result.status == models.UpdateStatus.COMPLETED:
                log_info(f"Successfully deleted {count_result.count} points with content_id: {content_id}")
                return True
            else:
                log_warning(f"Deletion failed for content_id {content_id}. Status: {result.status}")
                return False

        except Exception as e:
            log_warning(f"Error deleting points with content_id {content_id}: {e}")
            return False

    def delete_by_collection_id(self, collection_id: str) -> bool:
        """
        Delete content by collection ID.
        """
        return self.delete()

    def delete_by_workspace_id(self, workspace_id: str) -> bool:
        """
        Delete content by workspace ID.
        """
        try:
            log_info(f"Attempting to delete all points with workspace_id: {workspace_id}")

            # Create a filter to find all points with the specified content_id
            filter_condition = models.Filter(
                must=[models.FieldCondition(key="workspace_id", match=models.MatchValue(value=workspace_id))]
            )

            # First, count how many points will be deleted
            count_result = self.client.count(collection_name=self.collection, count_filter=filter_condition, exact=True)

            if count_result.count == 0:
                log_warning(f"No points found with workspace_id: {workspace_id}")
                return True

            log_info(f"Found {count_result.count} points to delete with workspace_id: {workspace_id}")

            # Delete all points matching the filter
            result = self.client.delete(
                collection_name=self.collection,
                points_selector=filter_condition,
                wait=True,  # Wait for the operation to complete
            )

            # Check if the deletion was successful
            if result.status == models.UpdateStatus.COMPLETED:
                log_info(f"Successfully deleted {count_result.count} points with workspace_id: {workspace_id}")
                return True
            else:
                log_warning(f"Deletion failed for workspace_id {workspace_id}. Status: {result.status}")
                return False

        except Exception as e:
            log_warning(f"Error deleting points with workspace_id {workspace_id}: {e}")
            return False

    def id_exists(self, id: str) -> bool:
        """Check if a point with the given ID exists in the collection.

        Args:
            id (str): The ID to check.

        Returns:
            bool: True if the point exists, False otherwise.
        """
        try:
            points = self.client.retrieve(
                collection_name=self.collection, ids=[id], with_payload=False, with_vectors=False
            )
            return len(points) > 0
        except Exception as e:
            log_info(f"Error checking if point {id} exists: {e}")
            return False

    def content_hash_exists(self, content_hash: str, collection_id: Optional[str] = None, workspace_id: Optional[str] = None) -> bool:
        """Check if any points with the given content hash exist in the collection.

        Args:
            content_hash (str): The content hash to check.

        Returns:
            bool: True if points with the content hash exist, False otherwise.
        """
        try:
            # Create a filter to find points with the specified content_hash
            filter_conditions = []
            filter_conditions.append(models.FieldCondition(key="content_hash", match=models.MatchValue(value=content_hash)))
            if collection_id:
                filter_conditions.append(models.FieldCondition(key="collection_id", match=models.MatchValue(value=collection_id)))
            if workspace_id:
                filter_conditions.append(models.FieldCondition(key="workspace_id", match=models.MatchValue(value=workspace_id)))
            filter_condition = models.Filter(must=filter_conditions)

            # Count how many points match the filter
            count_result = self.client.count(collection_name=self.collection, count_filter=filter_condition, exact=True)
            return count_result.count > 0
        except Exception as e:
            log_info(f"Error checking if content_hash {content_hash} exists: {e}")
            return False

    def _delete_by_content_hash(self, content_hash: str) -> bool:
        """Delete all points that have the specified content_hash in their payload.

        Args:
            content_hash (str): The content hash to delete.

        Returns:
            bool: True if points were deleted successfully, False otherwise.
        """
        try:
            log_info(f"Attempting to delete all points with content_hash: {content_hash}")

            # Create a filter to find all points with the specified content_hash
            filter_condition = models.Filter(
                must=[models.FieldCondition(key="content_hash", match=models.MatchValue(value=content_hash))]
            )

            # First, count how many points will be deleted
            count_result = self.client.count(collection_name=self.collection, count_filter=filter_condition, exact=True)

            if count_result.count == 0:
                log_warning(f"No points found with content_hash: {content_hash}")
                return True

            log_info(f"Found {count_result.count} points to delete with content_hash: {content_hash}")

            # Delete all points matching the filter
            result = self.client.delete(
                collection_name=self.collection,
                points_selector=filter_condition,
                wait=True,  # Wait for the operation to complete
            )

            # Check if the deletion was successful
            if result.status == models.UpdateStatus.COMPLETED:
                log_info(f"Successfully deleted {count_result.count} points with content_hash: {content_hash}")
                return True
            else:
                log_warning(f"Deletion failed for content_hash {content_hash}. Status: {result.status}")
                return False

        except Exception as e:
            log_warning(f"Error deleting points with content_hash {content_hash}: {e}")
            return False

    def update_metadata(self, content_id: str, metadata: Dict[str, Any]) -> None:
        """
        Update the metadata for documents with the given content_id.

        Args:
            content_id (str): The content ID to update
            metadata (Dict[str, Any]): The metadata to update
        """
        try:
            if not self.client:
                log_error("Client not initialized")
                return

            # Create filter for content_id
            filter_condition = models.Filter(
                must=[models.FieldCondition(key="content_id", match=models.MatchValue(value=content_id))]
            )

            # Search for points with the given content_id
            search_result = self.client.scroll(
                collection_name=self.collection,
                scroll_filter=filter_condition,
                limit=10000,  # Get all matching points
                with_payload=True,
                with_vectors=False,
            )

            if not search_result[0]:  # search_result is a tuple (points, next_page_offset)
                log_error(f"No documents found with content_id: {content_id}")
                return

            points = search_result[0]
            update_operations = []

            # Prepare update operations for each point
            for point in points:
                point_id = point.id
                current_payload = point.payload or {}

                # Merge existing metadata with new metadata
                updated_payload = current_payload.copy()
                updated_payload.update(metadata)

                if "filters" not in updated_payload:
                    updated_payload["filters"] = {}
                if isinstance(updated_payload["filters"], dict):
                    updated_payload["filters"].update(metadata)
                else:
                    updated_payload["filters"] = metadata

                # Create set payload operation
                update_operations.append(models.SetPayload(payload=updated_payload, points=[point_id]))

            # Execute all updates
            for operation in update_operations:
                self.client.set_payload(
                    collection_name=self.collection, payload=operation.payload, points=operation.points
                )

            log_debug(f"Updated metadata for {len(update_operations)} documents with content_id: {content_id}")

        except Exception as e:
            log_error(f"Error updating metadata for content_id '{content_id}': {e}")
            raise

    def close(self) -> None:
        """Close the Qdrant client connections."""
        if self._client is not None:
            try:
                self._client.close()
                log_debug("Qdrant client closed successfully")
            except Exception as e:
                log_debug(f"Error closing Qdrant client: {e}")
            finally:
                self._client = None

    async def async_close(self) -> None:
        """Close the Qdrant client connections asynchronously."""
        if self._async_client is not None:
            try:
                await self._async_client.close()
                log_debug("Async Qdrant client closed successfully")
            except Exception as e:
                log_debug(f"Error closing async Qdrant client: {e}")
            finally:
                self._async_client = None


    
    def get_chunk(self, vector_id: str, include_embedding: bool = False) -> Optional[Dict[str, Any]]:
        """
        Get a chunk by vector ID.
        
        Args:
            vector_id (str): The ID of the vector/chunk to retrieve.
            include_embedding (bool): Whether to include the embedding vector.
            
        Returns:
            Optional[Dict[str, Any]]: Standardized chunk dictionary, or None if not found.
                Contains: id, content_id, collection_id, workspace_id, name, content, 
                         embedding (optional), metadata, created_at
        """
        try:
            points = self.client.retrieve(
                collection_name=self.collection, 
                ids=[vector_id], 
                with_payload=True, 
                with_vectors=include_embedding
            )
            
            if not points or len(points) == 0:
                log_debug(f"No chunk found with vector ID '{vector_id}'")
                return None
            
            point = points[0]
            payload = dict(point.payload) if point.payload else {}
            
            # Extract embedding if requested
            embedding = None
            if include_embedding and point.vector:
                if isinstance(point.vector, dict):
                    # Handle named vectors - use dense vector by default
                    embedding = point.vector.get(self.dense_vector_name)
                else:
                    # Handle unnamed vector (backward compatibility)
                    embedding = point.vector
            
            # Return standardized format
            return {
                "id": str(point.id),
                "content_id": payload.get("content_id"),
                "collection_id": payload.get("collection_id"),
                "workspace_id": payload.get("workspace_id"),
                "name": payload.get("name"),
                "content": payload.get("content"),
                "embedding": embedding,
                "metadata": payload.get("meta_data", {}),
                "created_at": payload.get("created_at"),
            }
            
        except Exception as e:
            log_error(f"Error getting chunk for vector ID '{vector_id}': {e}")
            return None

    def _format_chunk(self, point, include_embedding: bool = False) -> Dict[str, Any]:
        """
        Format a Qdrant point into standardized chunk format.
        
        Args:
            point: Qdrant point object
            include_embedding: Whether to include embedding vector
            
        Returns:
            Standardized chunk dictionary
        """
        payload = dict(point.payload) if point.payload else {}
        
        # Extract embedding if requested
        embedding = None
        if include_embedding and point.vector:
            if isinstance(point.vector, dict):
                # Handle named vectors - use dense vector by default
                embedding = point.vector.get(self.dense_vector_name)
            else:
                # Handle unnamed vector (backward compatibility)
                embedding = point.vector
        
        # Return standardized format
        return {
            "id": str(point.id),
            "content_id": payload.get("content_id"),
            "collection_id": payload.get("collection_id"),
            "workspace_id": payload.get("workspace_id"),
            "name": payload.get("name"),
            "content": payload.get("content"),
            "embedding": embedding,
            "metadata": payload.get("meta_data", {}),
            "created_at": payload.get("created_at"),
        }

    def list_chunks(
        self, 
        content_id: str = None, 
        filters: Optional[Dict[str, Any]] = None, 
        include_embedding: bool = False,
        limit: Optional[int] = None,
        cursor: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        List chunks with metadata using cursor-based pagination.
        
        Args:
            content_id (str, optional): Filter by content ID.
            filters (Dict[str, Any], optional): Additional metadata filters.
                Supports: workspace_id, collection_id, or custom metadata filters.
            include_embedding (bool): Whether to include embedding vectors.
            limit (int, optional): Maximum number of chunks to return (default: 50).
            cursor (str, optional): Pagination cursor (Qdrant Point ID from previous response).
            
        Returns:
            Dict[str, Any]: Dictionary containing chunks, next_cursor, and has_more flag
        """
        try:
            # Build filter conditions
            filter_conditions = []
            
            # Add content_id filter if provided
            if content_id:
                filter_conditions.append(
                    models.FieldCondition(key="content_id", match=models.MatchValue(value=content_id))
                )
            
            # Add additional filters if provided
            if filters:
                for key, value in filters.items():
                    # Handle workspace_id and collection_id at top level
                    if key in ["workspace_id", "collection_id", "content_hash"]:
                        filter_conditions.append(
                            models.FieldCondition(key=key, match=models.MatchValue(value=value))
                        )
                    else:
                        # For other keys, assume metadata field
                        if "." not in key and not key.startswith("meta_data."):
                            key = f"meta_data.{key}"
                        
                        if isinstance(value, dict):
                            # Handle nested dictionaries
                            for sub_key, sub_value in value.items():
                                filter_conditions.append(
                                    models.FieldCondition(key=f"{key}.{sub_key}", match=models.MatchValue(value=sub_value))
                                )
                        else:
                            # Handle direct key-value pairs
                            filter_conditions.append(
                                models.FieldCondition(key=key, match=models.MatchValue(value=value))
                            )
            
            # Create filter object if there are any conditions
            scroll_filter = models.Filter(must=filter_conditions) if filter_conditions else None
            
            # Use native Qdrant cursor-based pagination
            # The cursor is a Qdrant Point ID, not a numeric offset
            scroll_cursor = cursor  # Start from cursor (Point ID) or None for first page
            
            # Default limit to 50 if not specified
            fetch_limit = limit if limit is not None else 50
            
            # Fetch one extra to determine if there are more pages
            fetch_limit_plus_one = fetch_limit + 1
            
            # Scroll through points
            scroll_result = self.client.scroll(
                collection_name=self.collection,
                scroll_filter=scroll_filter,
                limit=fetch_limit_plus_one,
                offset=scroll_cursor,  # Qdrant Point ID cursor
                with_payload=True,
                with_vectors=include_embedding,
            )
            
            points, next_scroll_cursor = scroll_result
            
            # Convert points to standardized format
            chunks = []
            for i, point in enumerate(points):
                # Only include up to 'limit' chunks
                if i >= fetch_limit:
                    break
                chunks.append(self._format_chunk(point, include_embedding))
            
            # Determine if there are more pages
            has_more = len(points) > fetch_limit
            
            # Set next_cursor for pagination
            # Use the last point's ID as the cursor for the next page
            next_cursor = None
            if has_more and chunks:
                # Use Qdrant's next_offset if available, otherwise use last point's ID
                next_cursor = str(next_scroll_cursor) if next_scroll_cursor else str(points[fetch_limit - 1].id)
            
            log_info(f"Retrieved {len(chunks)} chunks from collection '{self.collection}'" + 
                    (f" (limit={limit}, cursor={cursor[:20] + '...' if cursor and len(cursor) > 20 else cursor})" if limit or cursor else ""))
            
            return {
                "chunks": chunks,
                "next_cursor": next_cursor,
                "has_more": has_more
            }
            
        except Exception as e:
            log_error(f"Error listing chunks: {e}")
            return []
