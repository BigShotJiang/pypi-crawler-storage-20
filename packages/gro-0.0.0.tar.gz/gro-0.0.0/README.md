# gro

**gro** is a strict OpenAPI compiler that grows APIs into fully typed Python SDKs.

The documentation is still under construction, but the core ideas and direction of the project are already clear.

---

## What is gro?

gro takes an OpenAPI specification and turns it into a **clean, strongly typed, Pythonic SDK**.

Unlike traditional generators, gro is **strict by default**.
If your API specification is underspecified or loosely typed, gro will tell you — instead of guessing.

This makes gro suitable for teams that care about:
- correctness
- type safety
- long-term maintainability
- predictable SDK behavior

---

## Philosophy

gro follows a few simple principles:

- **Strict by default**
  Untyped or free-form schemas are rejected unless explicitly allowed.

- **No guessing**
  If the spec is ambiguous, gro fails fast and explains why.

- **Python-first output**
  Generated SDKs should feel natural to use in Python, with proper typing and structure.

- **Opt-in looseness**
  You can allow untyped parts when needed, but only by choice.

---

## Current status

The project is under active development.

Right now, gro focuses on:
- validating OpenAPI specs
- enforcing strict typing rules
- generating fully typed Python SDKs

More features (async clients, customization hooks, richer docs) will come after the core is solid.

---

## Getting started (soon)

Once available, the basic workflow will look like:

```bash
gro check openapi.yaml
gro generate openapi.yaml
```

Until then, consider this documentation a living draft.

---

## A note

gro is intentionally opinionated.

If you want a generator that “just works” on any spec, gro may feel strict.
If you want your SDKs to be **correct**, **typed**, and **boring in the best way**, you’re in the right place 🌱
