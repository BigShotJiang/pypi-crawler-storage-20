"""Main entry point for the gro package."""

from . import main

if __name__ == "__main__":
    main()
