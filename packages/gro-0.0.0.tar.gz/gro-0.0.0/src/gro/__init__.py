"""Initialize the create_agentverse_agent package."""

from importlib.metadata import version


def main() -> None:
    """Main entry point for CLI."""
    print(
        "gro: A tool for generating and managing agents.\n"
        "Visit https://gro.tejusgupta.dev for more information."
    )


__all__ = ["main"]
__version__ = version("gro")
