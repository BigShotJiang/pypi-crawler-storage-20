"""Tests for beads-mcp."""
