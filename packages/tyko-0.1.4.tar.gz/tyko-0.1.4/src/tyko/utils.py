import random


def generate_random_run_name() -> str:
    """Generate a random name for a run.

    A name is a combination of three words, two adjectives and a noun, joined by a hyphen.
    The first adjective describes characteristics/personality, while the second describes
    physical attributes or qualities, ensuring they combine naturally.

    Returns:
        A random string to be used as a run name (e.g., "brave-mighty-lion").

    Example:
        >>> name = _random_run_name()
        >>> print(name)
        gentle-swift-falcon
    """

    # Personality/behavioral adjectives
    adjective_personality = [
        "agile",
        "brave",
        "calm",
        "clever",
        "eager",
        "fierce",
        "gentle",
        "happy",
        "jolly",
        "keen",
        "loyal",
        "noble",
        "proud",
        "quiet",
        "swift",
        "wise",
        "zen",
    ]

    # Physical/quality adjectives (that won't contradict personality traits)
    adjective_quality = [
        "ancient",
        "bold",
        "bright",
        "crimson",
        "crystal",
        "golden",
        "grand",
        "mighty",
        "radiant",
        "royal",
        "silent",
        "silver",
        "soaring",
        "steady",
        "strong",
        "sturdy",
        "valiant",
        "wild",
    ]

    # Animals and creatures
    nouns = [
        "badger",
        "bear",
        "cheetah",
        "dragon",
        "eagle",
        "falcon",
        "fox",
        "hawk",
        "leopard",
        "lion",
        "owl",
        "panther",
        "phoenix",
        "raven",
        "tiger",
        "wolf",
        "wolverine",
    ]

    personality = random.choice(adjective_personality)
    quality = random.choice(adjective_quality)
    animal = random.choice(nouns)

    return f"{personality}-{quality}-{animal}"
