"""Tests for the Tyko client."""

from unittest.mock import patch

import pytest
from pytest_httpx import HTTPXMock

from tyko import Experiment, Project, Run
from tyko.client import TykoClient


@pytest.fixture(autouse=True)
def default_api_key():
    """Set default environment variables for tests."""
    with patch.dict("os.environ", {"TYKO_API_KEY": "test-api-key"}):
        yield "test-api-key"


def test_client_uses_default_endpoint(default_api_key: str):
    """Test that the client uses the default API endpoint."""
    client = TykoClient()
    assert client.api_url == "https://api.tyko-labs.com"
    assert client.api_key == default_api_key


def test_client_uses_env_vars():
    """Test that the client uses environment variables for configuration."""
    with patch.dict("os.environ", {"TYKO_API_URL": "http://localhost:8000"}):
        client = TykoClient()
        assert client.api_url == "http://localhost:8000"


def test_start_run_with_project(httpx_mock: HTTPXMock):
    """Test starting a run with just a project name."""

    httpx_mock.add_response(
        method="POST",
        url="https://api.tyko-labs.com/runs",
        json={
            "project": {"name": "my-project"},
            "experiment": {"name": "default"},
            "name": "run-1234",
        },
    )

    client = TykoClient()

    with client.start_run(project="my-project") as run:
        assert isinstance(run, Run)
        assert isinstance(run.experiment, Experiment)
        assert isinstance(run.project, Project)
        assert run.project.name == "my-project"
        assert run.experiment.name == "default"
        assert run.name == "run-1234"

    request = httpx_mock.get_request()

    assert request is not None
    assert request.url == "https://api.tyko-labs.com/runs"
    assert request.headers["Authorization"] == "Bearer test-api-key"


# def test_start_run_with_experiment():
#     """Test starting a run with project and experiment names."""
#     client = TykoClient()
#     with client.start_run(project="my-project", experiment="baseline") as run:
#         assert run.project.name == "my-project"
#         assert run.experiment.name == "baseline"


# def test_start_run_with_custom_name():
#     """Test starting a run with a custom run name."""
#     client = TykoClient()
#     with client.start_run(project="my-project", name="run-v1") as run:
#         assert run.name == "run-v1"


# def test_run_generates_random_name():
#     """Test that runs generate random names when not provided."""
#     client = TykoClient()
#     with client.start_run(project="my-project") as run:
#         assert run.name is not None
#         assert len(run.name) > 0
