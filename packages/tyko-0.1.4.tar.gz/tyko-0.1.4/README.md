# Tyko Client - Python SDK

Official Python SDK for Tyko Labs.

Track experiments, manage models, and version datasets with a simple, intuitive API.

## Hierarchy

Tyko uses a three-level hierarchy to organize your ML work:

```
Project → Experiment → Run
```

- **Project**: Top-level container for your ML project (e.g., "mnist-classifier")
- **Experiment**: Groups related runs for comparison (e.g., "hyperparameter-search")
- **Run**: A single training execution with parameters, metrics, and artifacts

## Installation

Install via pip:

```bash
pip install tyko
```

## Quick Start

```python
from tyko import TykoClient

client = TykoClient()

# Simplest usage - just project name (uses "default" experiment)
with client.start_run(project="my-ml-project") as run:
    run.log_params({"learning_rate": 0.001})
    run.log_metric("accuracy", 0.95)

# With experiment name for organized work
with client.start_run(project="my-ml-project", experiment="hyperparameter-search") as run:
    run.log_params({"learning_rate": 0.01, "batch_size": 64})
    run.log_metric("accuracy", 0.97)

# With custom run name
with client.start_run(project="my-ml-project", name="baseline-v1") as run:
    run.log_metric("accuracy", 0.95)
```

## Advanced Usage

For more control, create projects and experiments explicitly:

```python
project = client.create_project("my-ml-model")
experiment = project.create_experiment("fine-tuning")

with experiment.start_run() as run:
    run.log_metric("loss", 0.15)
```
