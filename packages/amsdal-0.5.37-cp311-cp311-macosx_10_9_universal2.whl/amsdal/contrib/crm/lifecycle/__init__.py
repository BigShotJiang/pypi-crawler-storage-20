"""CRM Lifecycle Consumers."""
