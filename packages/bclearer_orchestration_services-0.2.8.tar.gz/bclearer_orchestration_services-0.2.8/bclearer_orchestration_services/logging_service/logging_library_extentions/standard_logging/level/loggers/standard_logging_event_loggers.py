class StandardLoggingEventLoggers:
    pass
