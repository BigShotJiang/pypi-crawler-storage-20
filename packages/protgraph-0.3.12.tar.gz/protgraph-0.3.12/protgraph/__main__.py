import protgraph

protgraph.main()
