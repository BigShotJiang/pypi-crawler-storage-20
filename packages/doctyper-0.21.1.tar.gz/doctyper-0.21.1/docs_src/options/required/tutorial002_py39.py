import doctyper

app = doctyper.Typer()


@app.command()
def main(name: str, lastname: str = doctyper.Option(default=...)):
    print(f"Hello {name} {lastname}")


if __name__ == "__main__":
    app()
