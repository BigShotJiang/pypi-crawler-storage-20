from __future__ import annotations
from pydantic import BaseModel
from typing import Any, Literal

class RunnerRequest(BaseModel):
    action: Literal["describe", "invoke"]
    kind: str | None = None     # tool|agent|flow|http|mcp
    name: str | None = None
    payload: dict[str, Any] | None = None

class RunnerResponse(BaseModel):
    ok: bool
    result: Any | None = None
    error: dict[str, Any] | None = None
