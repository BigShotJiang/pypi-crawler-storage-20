from pip._vendor import pkg_resources
from pip_upgrade.version_checker import version_check, not_equal_check
from pip_upgrade.store import Store

from packaging.utils import canonicalize_name


class DependenciesBase:
    def __init__(self):
        self.self_check = False

        self.packages = [dist.project_name for dist in pkg_resources.working_set]
        self.be_upgraded = {}
        self.wont_upgrade = {}

        self.dict = self.create_dict(self.packages)
        self.outdated = None

    def create_dict(self, packages):
        """
        Creates a dict of Stores class for packages
        """
        return {canonicalize_name(x): Store(x) for x in packages}

    def get_dependencies(self):
        """
        The main func for getting dependencies and comparing them to output a final list
        """

        self.retrieve_dependencies()

        for pkg_dict in self.outdated:
            pkg_name = pkg_dict["name"]
            current_version = pkg_dict["version"]
            latest_version = pkg_dict["latest_version"]

            pkg_store = self.dict[canonicalize_name(pkg_name)]

            pkg_store.current_version = current_version
            pkg_store.latest_version = latest_version

            self.compare_deps(pkg_store)

    def compare_deps(self, pkg_store):
        """
        Compares dependencies in a list and decides what packages' final version should be
        """
        result = []
        done = False

        for key in ["==", "~=", "<", "<="]:
            if len(pkg_store.data[key]) > 0:
                result = [key, min(pkg_store.data[key])]
                done = True
                break
        if not done:
            for key in [">", ">="]:
                if len(pkg_store.data[key]) > 0:
                    result = [key, max(pkg_store.data[key])]
                    done = True
                    break
            #  Nonequal Check
            for item in pkg_store.data["!="]:
                not_equal_check(item, pkg_store.latest_version)
                result = ["!=", pkg_store.latest_version]

        if version_check(result, pkg_store.latest_version):
            self.be_upgraded[pkg_store.name] = result

    def retrieve_dependencies(self):
        """
        Retrieves dependencies pkg_main requires, and puts all dependent packages in self.dict with their version.
        """
        for pkg_main in self.packages:
            dep_list = pkg_resources.working_set.by_key[pkg_main.lower()].requires()

            for i in dep_list:
                name = i.name  # Name of dependency
                specs = i.specs  # Specs of dependency

                if len(specs) != 0:
                    canonical_name = canonicalize_name(name)
                    if canonical_name in self.dict:
                        self.dict[canonical_name] += specs

