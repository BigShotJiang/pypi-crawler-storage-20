from .ris import *
from collections import namedtuple

Author = namedtuple('Author', ['first, last, suffix'], [None, None, None])

import copy

class Record:

    _implemented = {'JOUR', 'GEN'}

    def __init__(self, ref):
        self.raw = copy.deepcopy(ref)
        if not check_conforms(ref):
            raise ValueError("Reference not compliant")
        
        self._pubtype = get_pubtype(ref)
        self._authors = [Author(*[parse_author(au) for au in get_authors(ref)])]
        self._title = get_title(ref)
        if self.is_journal():
            self._journal = get_journal(ref)
            self._volume = get_volume(ref)
            self._spage = get_startpage(ref)
            self._epage = get_endpage(ref)
            self._issue = get_issue(ref)

    def is_journal(self):
        return self._pubtype == 'JOUR' or self._pubtype == 'EJOUR'

    @property
    def pubtype(self):
        return self._pubtype
    
