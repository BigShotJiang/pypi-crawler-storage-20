import inspect

# 定义要保护的核心函数
def get_class_info(model):
    """
    获取类的源码和初始化参数（核心逻辑，会被编译为二进制）
    """
    src = inspect.getsource(model.__class__)
    parameters = []
    for para in inspect.signature(model.__class__.__init__).parameters.values():
        parameters.append(para.name)
    return src, parameters