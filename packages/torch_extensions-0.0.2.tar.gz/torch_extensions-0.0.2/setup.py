from setuptools import setup, Extension
import os
import sys


def main():

    # 创建扩展模块，简化配置
    extensions = [
        # Extension(
        #     "torch.extensions.extension",  # 模块名称与初始化函数匹配
        #     sources=["torch/extensions/extension.c"],
        #     extra_compile_args=["-g", "-O2"],
        #     language="c",  # 使用C编译
        # ),
        Extension(
            "torch.extensions.extension",  # 模块名称与初始化函数匹配
            sources=["torch/extensions/extension.pyx"],
            extra_compile_args=(
                ["-O3"] if sys.platform != "win32" else ["/O2"]
            ),  # 优化编译
            language="c",  # 使用C编译
        ),
    ]

    setup(
        name="torch-extensions",
        version="0.0.2",
        description="pytorch通用模型导出",
        author="zhumingwu",
        author_email="zhumingwu@126.com",
        packages=["torch.extensions"],
        ext_modules=extensions,
        install_requires=[
            "torch>=2.9.1",
            "cython>=0.29.0",
            "setuptools>=61.0.0",
        ],
        python_requires=">=3.9",
    )


if __name__ == "__main__":
    main()
