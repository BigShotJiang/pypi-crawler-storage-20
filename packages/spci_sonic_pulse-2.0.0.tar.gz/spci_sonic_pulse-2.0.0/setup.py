from setuptools import setup, find_packages

setup(
    name='spci-sonic-pulse',
    version='2.0.0', # Updated to match version in src/spci/mp.py
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=[
        'typer',
        'rich',
        'requests',
        'yt-dlp',
        'python-vlc',
        'ytmusicapi',
        'tinydb'
    ],
    entry_points={
        'console_scripts': [
            'spci=spci.mp:app',
        ],
    },
)