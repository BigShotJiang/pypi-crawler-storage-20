# TOPSIS-Python

## Project Overview
This project implements the **TOPSIS** (Technique for Order of Preference by Similarity to Ideal Solution) algorithm. It is a multi-criteria decision analysis method used to rank a finite number of alternatives based on their distance from the "ideal best" and "ideal worst" solutions.

This package provides a command-line tool to perform the analysis on any CSV dataset containing numerical data.

## Installation
To run this project, ensure you have **Python** installed along with the following libraries:

    pip install pandas numpy matplotlib

## Methodology
The algorithm follows these standard steps:
1.  **Data Validation:** Checks for missing values and ensures all input columns are numeric.
2.  **Vector Normalization:** Reduces all criteria to the same scale.
3.  **Weighting:** Multiplies the normalized matrix by the user-assigned weights.
4.  **Ideal Best & Worst:** Identifies the ideal best and ideal worst values for each criterion.
5.  **Euclidean Distance:** Calculates the distance of each alternative from the best and worst solutions.
6.  **Performance Score:** Calculates a score (0 to 1) and ranks the alternatives (Higher Score = Better Rank).

## Usage
The script is designed to be run from the command line.

    python topsis.py <InputDataFile> <Weights> <Impacts> <ResultFileName>

### Parameters
* **InputDataFile**: Path to the input CSV file.
* **Weights**: Comma-separated numbers (e.g., "1,1,1,1").
* **Impacts**: Comma-separated signs ("+" or "-").
* **ResultFileName**: Name of the output CSV file.

## Example Execution
Below is a demonstration of the tool using the sample data provided in this assignment.

### 1. Command Used

    python topsis.py data.csv "1,1,1,1,1" "+,+,-,+,-" result.csv

### 2. Output Results
The program calculates the TOPSIS Score and Rank for each fund.

| Fund Name | Topsis Score | Rank |
| :--- | :--- | :--- |
| M1 | 0.4435 | 6 |
| M2 | 0.4851 | 5 |
| M3 | 0.2834 | 7 |
| M4 | 0.5362 | 3 |
| M5 | 0.2281 | 8 |
| M6 | 0.6973 | 1 |
| M7 | 0.5891 | 2 |
| M8 | 0.5342 | 4 |

## License
This project is open-source and available for educational purposes.