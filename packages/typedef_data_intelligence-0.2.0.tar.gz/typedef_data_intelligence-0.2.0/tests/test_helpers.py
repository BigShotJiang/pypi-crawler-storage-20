"""Helper functions for tests."""
from pathlib import Path

from lineage.ingest.static_loaders.dbt.dbt_loader import (
    ChecksumInfo,
    DbtColumn,
    DbtMacroNode,
    DbtModelNode,
    RawDbtArtifacts,
)


def create_mock_model(
    unique_id: str,
    checksum: str | None = "abc123",
    name: str | None = None,
    compiled_sql: str = "SELECT 1",
    materialization: str = "table",
    depends_on_nodes: list[str] | None = None,
    depends_on_sources: list[str] | None = None,
    depends_on_macros: list[str] | None = None,
    columns: dict[str, DbtColumn] | None = None,
) -> DbtModelNode:
    """Create a mock DbtModelNode for testing."""
    if name is None:
        # Extract name from unique_id (e.g., "model.test.fct_orders" -> "fct_orders")
        name = unique_id.split(".")[-1]
    
    return DbtModelNode(
        unique_id=unique_id,
        name=name,
        resource_type="model",
        description=None,
        tags=[],
        meta={},
        database="test_db",
        schema="test_schema",
        alias=name,
        relation_name=f"test_schema.{name}",
        materialization=materialization,
        depends_on_nodes=depends_on_nodes or [],
        depends_on_sources=depends_on_sources or [],
        depends_on_macros=depends_on_macros or [],
        compiled_sql=compiled_sql,
        columns=columns or {},
        checksum=ChecksumInfo(name="sha256", checksum=checksum) if checksum else None,
    )


def create_mock_macro(
    unique_id: str,
    name: str | None = None,
    package_name: str = "test",
    macro_sql: str = "{% macro example() %}select 1{% endmacro %}",
    depends_on_macros: list[str] | None = None,
) -> DbtMacroNode:
    """Create a mock DbtMacroNode for testing."""
    if name is None:
        name = unique_id.split(".")[-1]
    return DbtMacroNode(
        unique_id=unique_id,
        name=name,
        resource_type="macro",
        description=None,
        tags=[],
        meta={},
        package_name=package_name,
        original_path=f"macros/{name}.sql",
        source_path=f"/tmp/{name}.sql",
        macro_sql=macro_sql,
        depends_on_macros=depends_on_macros or [],
    )


def create_mock_artifacts(
    models: list[DbtModelNode], macros: list[DbtMacroNode] | None = None
) -> RawDbtArtifacts:
    """Create mock DbtArtifacts from a list of models."""
    # Create minimal manifest structure
    manifest = {
        "metadata": {
            "project_name": "test_project",
            "adapter_type": "duckdb",
            "target_name": "dev",
        },
        "nodes": {
            model.unique_id: {
                "resource_type": model.resource_type,
                "name": model.name,
                "original_file_path": f"models/{model.name}.sql",
                "compiled_sql": model.compiled_sql,
                "database": model.database,
                "schema": model.schema,
                "alias": model.alias,
                "relation_name": model.relation_name,
                "columns": {
                    col_name: {
                        "description": (col.description or ""),
                    }
                    for col_name, col in (model.columns or {}).items()
                },
                "config": {
                    "materialized": model.materialization,
                },
                "depends_on": {
                    "nodes": model.depends_on_nodes,
                    "sources": model.depends_on_sources,
                    "macros": getattr(model, "depends_on_macros", []) or [],
                },
                "checksum": {
                    "name": model.checksum.name if model.checksum else "sha256",
                    "checksum": model.checksum.checksum if model.checksum else "",
                } if model.checksum else None,
            }
            for model in models
        },
        "macros": {
            macro.unique_id: {
                "resource_type": "macro",
                "name": macro.name,
                "package_name": macro.package_name,
                "original_file_path": macro.original_path,
                "macro_sql": macro.macro_sql,
                "depends_on": {
                    "macros": macro.depends_on_macros,
                },
            }
            for macro in (macros or [])
        },
    }
    
    catalog = {
        "nodes": {
            model.unique_id: {
                "columns": {
                    col_name: {
                        "type": (col.data_type or "unknown"),
                    }
                    for col_name, col in (model.columns or {}).items()
                }
            }
            for model in models
        }
    }
    
    # Create minimal config
    from lineage.ingest.static_loaders.dbt.config import DbtArtifactsConfig
    config = DbtArtifactsConfig()
    config.target_path = Path("/tmp/test_target")
    
    return RawDbtArtifacts(
        config=config,
        manifest=manifest,
        catalog=catalog,
        run_results={},
    )

