"""Tests for static loaders."""

