"""Regression tests for SemanticLoader domain extraction handling."""

from __future__ import annotations

from typing import Any

from lineage.ingest.static_loaders.semantic.loader import SemanticLoader


class _DummyStorage:
    def bulk_load(self, *_args: Any, **_kwargs: Any) -> None:  # pragma: no cover
        return None


def test_collect_semantic_analysis_handles_model_domains_none() -> None:
    """`model_domains=None` should not crash and should produce empty domains."""
    loader = SemanticLoader(storage=_DummyStorage())

    nodes: list[Any] = []
    edges: list[Any] = []

    semantic_model = loader._collect_semantic_analysis(
        model_id="model.test.some_model",
        results={
            "analysis_summary": "summary",
            "model_domains": None,
        },
        all_nodes=nodes,
        all_edges=edges,
    )

    assert semantic_model.domains == []


def test_collect_semantic_analysis_handles_model_domains_wrong_shape() -> None:
    """Non-list `domains` should be treated as empty."""
    loader = SemanticLoader(storage=_DummyStorage())

    nodes: list[Any] = []
    edges: list[Any] = []

    semantic_model = loader._collect_semantic_analysis(
        model_id="model.test.some_model",
        results={
            "analysis_summary": "summary",
            "model_domains": {"domains": None},
        },
        all_nodes=nodes,
        all_edges=edges,
    )

    assert semantic_model.domains == []


