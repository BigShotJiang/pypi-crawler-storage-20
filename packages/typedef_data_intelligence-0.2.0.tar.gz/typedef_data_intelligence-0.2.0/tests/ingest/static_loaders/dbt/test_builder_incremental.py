"""Tests for incremental graph loading functionality.

Tests cover:
- LineageBuilder.write_incremental method
- Column lineage incremental updates
"""
# ruff: noqa: I001

import json
from pathlib import Path

import pytest

from lineage.backends.lineage.models import DerivesFrom
from lineage.backends.lineage.protocol import LineageStorage
from lineage.backends.types import NodeLabel
from lineage.ingest.progress import ProgressTracker
from lineage.ingest.static_loaders.change_detection import ChangeDetector, ModelChangeSet
from lineage.ingest.static_loaders.dbt.builder import LineageBuilder
from lineage.backends.lineage.models import DbtColumn as GraphDbtColumn
from lineage.ingest.static_loaders.dbt.dbt_loader import DbtColumn, FilteredDbtArtifacts

from tests.test_helpers import create_mock_artifacts, create_mock_macro, create_mock_model


@pytest.mark.integration
class TestIncrementalGraphLoading:
    """Tests for LineageBuilder.write_incremental."""

    def test_sqlglot_schema_returns_defensive_copy(self) -> None:
        """Mutating a returned SQLGlot schema dict should not corrupt cached state."""
        columns = {"id": DbtColumn(name="id", description="", data_type="int")}
        model = create_mock_model("model.test.model1", checksum="abc123", columns=columns)
        artifacts = create_mock_artifacts([model])

        # Raw artifacts schema.to_dict() should return a fresh copy safe to mutate.
        raw_schema = artifacts.sqlglot_schema().to_dict()
        raw_schema["test_db"]["test_schema"]["model1"]["id"] = "text"
        assert artifacts.sqlglot_schema().to_dict()["test_db"]["test_schema"]["model1"]["id"] == "int"

        # Filtered view schema should be safe to mutate as well.
        filtered = FilteredDbtArtifacts(artifacts, model_ids={"model.test.model1"})
        filtered_schema = filtered.sqlglot_schema().to_dict()
        filtered_schema["test_db"]["test_schema"]["model1"]["id"] = "text"
        assert filtered.sqlglot_schema().to_dict()["test_db"]["test_schema"]["model1"]["id"] == "int"

    def test_write_incremental_added_models(self, falkordblite_storage: LineageStorage, tmp_path: Path) -> None:
        """Load only new models."""
        # Initial load: model1
        models_v1 = [
            create_mock_model("model.test.model1", checksum="abc123"),
        ]
        artifacts_v1 = create_mock_artifacts(models_v1)
        
        # Create artifacts directory structure with proper manifest
        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        manifest_v1 = artifacts_v1.manifest
        (artifacts_dir / "manifest.json").write_text(json.dumps(manifest_v1))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts_v1.catalog))
        
        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)
        
        # Incremental load: add model2
        change_set = ModelChangeSet(
            added=["model.test.model2"],
            modified=[],
            removed=[],
            unchanged=["model.test.model1"],
        )
        
        models_v2 = [
            create_mock_model("model.test.model1", checksum="abc123"),
            create_mock_model("model.test.model2", checksum="def456"),
        ]
        artifacts_v2 = create_mock_artifacts(models_v2)
        
        # Update builder's artifacts directly
        builder._artifacts = artifacts_v2
        
        builder.write_incremental(falkordblite_storage, change_set)
        
        # Verify both models exist
        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN m.id AS id ORDER BY m.id"
        )
        assert result.count == 2
        ids = [row["id"] for row in result.rows]
        assert "model.test.model1" in ids
        assert "model.test.model2" in ids

    def test_write_incremental_removed_models(self, falkordblite_storage: LineageStorage, tmp_path: Path) -> None:
        """Delete removed models with cascade."""
        # Initial load: model1 and model2
        models_v1 = [
            create_mock_model("model.test.model1", checksum="abc123"),
            create_mock_model("model.test.model2", checksum="def456"),
        ]
        artifacts_v1 = create_mock_artifacts(models_v1)
        
        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts_v1.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts_v1.catalog))
        
        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)
        
        # Incremental load: remove model2
        change_set = ModelChangeSet(
            added=[],
            modified=[],
            removed=["model.test.model2"],
            unchanged=["model.test.model1"],
        )
        
        models_v2 = [
            create_mock_model("model.test.model1", checksum="abc123"),
        ]
        artifacts_v2 = create_mock_artifacts(models_v2)
        builder.loader._artifacts = artifacts_v2
        
        builder.write_incremental(falkordblite_storage, change_set)
        
        # Verify only model1 exists
        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN m.id AS id"
        )
        assert result.count == 1
        assert result.rows[0]["id"] == "model.test.model1"

    def test_write_incremental_no_changes(self, falkordblite_storage: LineageStorage, tmp_path: Path) -> None:
        """Skip processing when no changes."""
        # Initial load
        models = [
            create_mock_model("model.test.model1", checksum="abc123"),
        ]
        artifacts = create_mock_artifacts(models)
        
        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))
        
        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)
        
        # Incremental load with no changes
        change_set = ModelChangeSet(
            added=[],
            modified=[],
            removed=[],
            unchanged=["model.test.model1"],
        )
        
        builder.write_incremental(falkordblite_storage, change_set)
        
        # Verify model still exists (no errors)
        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN m.id AS id"
        )
        assert result.count == 1

    def test_write_incremental_clears_stale_dependency_edges(
        self,
        falkordblite_storage: LineageStorage,
        tmp_path: Path,
    ) -> None:
        """Incremental updates must not leave stale DEPENDS_ON / USES_MACRO edges.

        Regression:
        - v1: model.a depends on model.b and uses macro.m1
        - v2: model.a depends on model.c and uses macro.m2
        If we preserve the DbtModel node during incremental updates, we must still
        clear outgoing dependency edges for model.a or the graph will accumulate
        incorrect/stale relationships.
        """
        macros = [
            create_mock_macro("macro.test.m1"),
            create_mock_macro("macro.test.m2"),
        ]

        # Initial load: a -> b, a -> m1
        models_v1 = [
            create_mock_model(
                "model.test.a",
                checksum="a_v1",
                depends_on_nodes=["model.test.b"],
                depends_on_macros=["macro.test.m1"],
            ),
            create_mock_model("model.test.b", checksum="b_v1"),
            create_mock_model("model.test.c", checksum="c_v1"),
        ]
        artifacts_v1 = create_mock_artifacts(models_v1, macros=macros)

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts_v1.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts_v1.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        assert (
            falkordblite_storage.execute_raw_query(
                "MATCH (:DbtModel {id: 'model.test.a'})-[:DEPENDS_ON]->(:DbtModel {id: 'model.test.b'}) RETURN 1"
            ).count
            == 1
        )
        assert (
            falkordblite_storage.execute_raw_query(
                "MATCH (:DbtModel {id: 'model.test.a'})-[:USES_MACRO]->(:DbtMacro {id: 'macro.test.m1'}) RETURN 1"
            ).count
            == 1
        )

        # Incremental update: a -> c, a -> m2
        models_v2 = [
            create_mock_model(
                "model.test.a",
                checksum="a_v2",
                depends_on_nodes=["model.test.c"],
                depends_on_macros=["macro.test.m2"],
            ),
            create_mock_model("model.test.b", checksum="b_v1"),  # unchanged
            create_mock_model("model.test.c", checksum="c_v1"),  # unchanged
        ]
        artifacts_v2 = create_mock_artifacts(models_v2, macros=macros)

        change_set = ModelChangeSet(
            added=[],
            modified=["model.test.a"],
            removed=[],
            unchanged=["model.test.b", "model.test.c"],
        )

        builder._artifacts = artifacts_v2
        builder.write_incremental(falkordblite_storage, change_set)

        # Old edges must be gone
        assert (
            falkordblite_storage.execute_raw_query(
                "MATCH (:DbtModel {id: 'model.test.a'})-[:DEPENDS_ON]->(:DbtModel {id: 'model.test.b'}) RETURN 1"
            ).count
            == 0
        )
        assert (
            falkordblite_storage.execute_raw_query(
                "MATCH (:DbtModel {id: 'model.test.a'})-[:USES_MACRO]->(:DbtMacro {id: 'macro.test.m1'}) RETURN 1"
            ).count
            == 0
        )

        # New edges must exist
        assert (
            falkordblite_storage.execute_raw_query(
                "MATCH (:DbtModel {id: 'model.test.a'})-[:DEPENDS_ON]->(:DbtModel {id: 'model.test.c'}) RETURN 1"
            ).count
            == 1
        )
        assert (
            falkordblite_storage.execute_raw_query(
                "MATCH (:DbtModel {id: 'model.test.a'})-[:USES_MACRO]->(:DbtMacro {id: 'macro.test.m2'}) RETURN 1"
            ).count
            == 1
        )

    def test_physical_columns_exist_without_macros(self) -> None:
        """Physical columns should be created even when no macros are present."""
        cols = {
            "derived": DbtColumn(name="derived", description="", data_type="int")
        }
        model = create_mock_model(
            "model.test.model1",
            checksum="abc123",
            columns=cols,
        )
        artifacts = create_mock_artifacts([model])

        builder = LineageBuilder()
        tracker = ProgressTracker()
        nodes, _ = builder._collect_nodes_and_edges(
            artifacts,
            create_physical_nodes=True,
            tracker=tracker,
        )

        physical_columns = [
            node for node in nodes if node.node_label == NodeLabel.PHYSICAL_COLUMN
        ]
        assert len(physical_columns) == len(cols)

    def test_incremental_column_lineage_resolves_upstream(self) -> None:
        """Incremental lineage keeps upstream model lookup even when filtered."""
        upstream_columns = {
            "upstream_col": DbtColumn(name="upstream_col", description="", data_type="int")
        }
        upstream = create_mock_model(
            "model.test.upstream",
            checksum="abc123",
            columns=upstream_columns,
        )
        derived_columns = {
            "derived": DbtColumn(name="derived", description="", data_type="int")
        }
        changed = create_mock_model(
            "model.test.changed",
            checksum="def456",
            compiled_sql="SELECT upstream_col AS derived FROM test_schema.upstream",
            columns=derived_columns,
        )

        artifacts = create_mock_artifacts([upstream, changed])
        filtered_artifacts = FilteredDbtArtifacts(
            artifacts,
            model_ids={"model.test.changed"},
        )

        builder = LineageBuilder()
        tracker = ProgressTracker()
        _, edges = builder._collect_nodes_and_edges(
            filtered_artifacts,
            create_physical_nodes=False,
            tracker=tracker,
        )

        target_column_id = GraphDbtColumn.identifier("model.test.changed", "derived").id
        source_column_id = GraphDbtColumn.identifier("model.test.upstream", "upstream_col").id

        derivations = [
            (from_node, to_node, edge)
            for from_node, to_node, edge in edges
            if isinstance(edge, DerivesFrom)
            and from_node.id == target_column_id
            and to_node.id == source_column_id
        ]

        assert derivations

    def test_change_detector_agrees_with_builder_fingerprint(
        self,
        falkordblite_storage: LineageStorage,
        tmp_path: Path,
    ) -> None:
        """ChangeDetector should see no changes when builder fingerprint matches."""
        columns = {
            "derived": DbtColumn(name="derived", description="", data_type="int")
        }
        model = create_mock_model(
            "model.test.model1",
            checksum="abc123",
            columns=columns,
        )
        artifacts = create_mock_artifacts([model])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        def dialect_resolver(model_id: str) -> str | None:
            return builder.config.sqlglot.per_model_dialects.get(
                model_id, builder.config.sqlglot.default_dialect
            )
        detector = ChangeDetector()
        change_set = detector.detect_changes(
            artifacts,
            falkordblite_storage,
            dialect_resolver=dialect_resolver,
        )

        assert change_set.has_changes is False
        assert change_set.unchanged == ["model.test.model1"]
    def test_write_incremental_checksum_preserved(self, falkordblite_storage: LineageStorage, tmp_path: Path) -> None:
        """Verify checksums stored correctly."""
        models = [
            create_mock_model("model.test.model1", checksum="abc123"),
        ]
        artifacts = create_mock_artifacts(models)
        
        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))
        
        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        
        change_set = ModelChangeSet(
            added=["model.test.model1"],
            modified=[],
            removed=[],
            unchanged=[],
        )
        
        builder.write_incremental(falkordblite_storage, change_set)
        
        # Verify checksum stored
        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel {id: 'model.test.model1'}) RETURN m.checksum AS checksum"
        )
        assert result.count == 1
        assert result.rows[0]["checksum"] == "abc123"


@pytest.mark.integration
class TestColumnLineageIncremental:
    """Tests for column lineage extraction for changed models only."""

    def test_column_lineage_only_changed_models(self, falkordblite_storage: LineageStorage, tmp_path: Path) -> None:
        """Extract lineage only for changed models."""
        # This test would require models with actual SQL that has column dependencies
        # For now, we test that the filtering mechanism exists
        models = [
            create_mock_model("model.test.model1", checksum="abc123", compiled_sql="SELECT col1 FROM source1"),
        ]
        artifacts = create_mock_artifacts(models)
        
        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))
        
        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        
        change_set = ModelChangeSet(
            added=["model.test.model1"],
            modified=[],
            removed=[],
            unchanged=[],
        )
        
        # This should work - column lineage extraction will be called with filtered models
        builder.write_incremental(falkordblite_storage, change_set)
        
        # Verify model was loaded
        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN m.id AS id"
        )
        assert result.count == 1

    def test_column_lineage_cleanup_before_extraction(self, falkordblite_storage: LineageStorage) -> None:
        """Verify old child nodes deleted for modified models via delete_model_cascade."""
        # This test verifies that delete_model_cascade with preserve_model=True works correctly.
        # The method is now called on the storage adapter, not on the builder.
        # For empty case, it should be a no-op
        result = falkordblite_storage.delete_model_cascade("model.test.nonexistent", preserve_model=True)
        assert result == 0  # No nodes deleted for non-existent model


    def test_write_incremental_modified_model_column_removed(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """Verify old columns are deleted when model is modified to remove a column."""
        # Initial load: model with columns A, B, C
        cols_v1 = {
            "col_a": DbtColumn(name="col_a", description="", data_type="string"),
            "col_b": DbtColumn(name="col_b", description="", data_type="int"),
            "col_c": DbtColumn(name="col_c", description="", data_type="bool"),
        }
        model_v1 = create_mock_model(
            "model.test.model1",
            checksum="v1_checksum",
            compiled_sql="SELECT a AS col_a, b AS col_b, c AS col_c FROM source",
            columns=cols_v1,
        )
        artifacts_v1 = create_mock_artifacts([model_v1])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts_v1.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts_v1.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # Verify all 3 columns exist
        result = falkordblite_storage.execute_raw_query(
            "MATCH (c:DbtColumn) WHERE c.parent_id = 'model.test.model1' RETURN c.name AS name ORDER BY c.name"
        )
        assert result.count == 3
        names_v1 = [row["name"] for row in result.rows]
        assert names_v1 == ["col_a", "col_b", "col_c"]

        # Modify model: remove col_c, keep A and B
        cols_v2 = {
            "col_a": DbtColumn(name="col_a", description="", data_type="string"),
            "col_b": DbtColumn(name="col_b", description="", data_type="int"),
        }
        model_v2 = create_mock_model(
            "model.test.model1",
            checksum="v2_checksum",
            compiled_sql="SELECT a AS col_a, b AS col_b FROM source",
            columns=cols_v2,
        )
        artifacts_v2 = create_mock_artifacts([model_v2])

        # Incremental load with model marked as modified
        change_set = ModelChangeSet(
            added=[],
            modified=["model.test.model1"],
            removed=[],
            unchanged=[],
        )

        builder._artifacts = artifacts_v2
        builder.write_incremental(falkordblite_storage, change_set)

        # Verify only 2 columns exist (col_c should be deleted)
        result = falkordblite_storage.execute_raw_query(
            "MATCH (c:DbtColumn) WHERE c.parent_id = 'model.test.model1' RETURN c.name AS name ORDER BY c.name"
        )
        assert result.count == 2
        names_v2 = [row["name"] for row in result.rows]
        assert names_v2 == ["col_a", "col_b"]
        assert "col_c" not in names_v2


@pytest.mark.integration
class TestSourceFingerprinting:
    """Tests for source fingerprint computation."""

    def test_source_fingerprint_computed_on_load(
        self, falkordblite_storage: LineageStorage, tmp_path: Path
    ) -> None:
        """Verify source fingerprints are computed and stored during load."""
        from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
            FingerprintType,
        )

        # Create a source with columns
        model = create_mock_model("model.test.model1", checksum="abc123")
        artifacts = create_mock_artifacts([model])

        # Add a source to the manifest
        artifacts.manifest["sources"] = {
            "source.test.raw.orders": {
                "resource_type": "source",
                "name": "orders",
                "source_name": "raw",
                "source_description": "",
                "database": "analytics",
                "schema": "raw",
                "identifier": "orders_table",
                "loader": "fivetran",
                "columns": {
                    "id": {"description": "Primary key"},
                    "amount": {"description": "Order amount"},
                },
            }
        }
        artifacts.catalog["sources"] = {
            "source.test.raw.orders": {
                "columns": {
                    "id": {"type": "integer"},
                    "amount": {"type": "decimal"},
                }
            }
        }

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # Verify source exists with fingerprint
        result = falkordblite_storage.execute_raw_query(
            "MATCH (s:DbtSource {id: 'source.test.raw.orders'}) "
            "RETURN s.source_fingerprint AS fp, s.fingerprint_type AS fp_type"
        )
        assert result.count == 1
        row = result.rows[0]
        assert row["fp"] is not None
        # Fingerprint is hash-only (no prefix); type is stored separately
        assert row["fp_type"] == FingerprintType.SOURCE

    def test_source_fingerprint_deterministic(self) -> None:
        """Verify source fingerprint is deterministic for same inputs."""
        from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
            compute_source_fingerprint,
        )

        fp1 = compute_source_fingerprint(
            database="analytics",
            schema="raw",
            identifier="orders",
            columns={"id": "integer", "amount": "decimal"},
        )
        fp2 = compute_source_fingerprint(
            database="analytics",
            schema="raw",
            identifier="orders",
            columns={"id": "integer", "amount": "decimal"},
        )
        assert fp1.hash == fp2.hash

    def test_source_fingerprint_detects_column_changes(self) -> None:
        """Verify source fingerprint changes when columns change."""
        from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
            compute_source_fingerprint,
        )

        fp_original = compute_source_fingerprint(
            database="analytics",
            schema="raw",
            identifier="orders",
            columns={"id": "integer", "amount": "decimal"},
        )

        # Add a column
        fp_added = compute_source_fingerprint(
            database="analytics",
            schema="raw",
            identifier="orders",
            columns={"id": "integer", "amount": "decimal", "status": "string"},
        )
        assert fp_original.hash != fp_added.hash

        # Change a type
        fp_changed_type = compute_source_fingerprint(
            database="analytics",
            schema="raw",
            identifier="orders",
            columns={"id": "bigint", "amount": "decimal"},  # id changed from integer
        )
        assert fp_original.hash != fp_changed_type.hash

    def test_source_fingerprint_detects_schema_changes(self) -> None:
        """Verify source fingerprint changes when schema location changes."""
        from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
            compute_source_fingerprint,
        )

        fp_original = compute_source_fingerprint(
            database="analytics",
            schema="raw",
            identifier="orders",
            columns={"id": "integer"},
        )

        # Different schema
        fp_different_schema = compute_source_fingerprint(
            database="analytics",
            schema="staging",  # Changed
            identifier="orders",
            columns={"id": "integer"},
        )
        assert fp_original.hash != fp_different_schema.hash


@pytest.mark.integration
class TestMacroIngest:
    """Tests for dbt macro ingest and macro dependency edges."""

    def test_model_uses_macro_edge(self, falkordblite_storage: LineageStorage, tmp_path: Path) -> None:
        """Ingest macro nodes and create `USES_MACRO` edges from models."""
        macro = create_mock_macro("macro.test.generate_columns")
        model = create_mock_model(
            "model.test.model1",
            checksum="abc123",
            compiled_sql="select 1",
            depends_on_macros=[macro.unique_id],
        )
        artifacts = create_mock_artifacts([model], macros=[macro])

        artifacts_dir = tmp_path / "target"
        artifacts_dir.mkdir()
        (artifacts_dir / "manifest.json").write_text(json.dumps(artifacts.manifest))
        (artifacts_dir / "catalog.json").write_text(json.dumps(artifacts.catalog))

        builder = LineageBuilder.from_dbt_artifacts(artifacts_dir)
        builder.write_typed(falkordblite_storage)

        # Macro node exists
        res = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtMacro {id: 'macro.test.generate_columns'}) RETURN m.id AS id"
        )
        assert res.count == 1

        # Edge exists: model -> macro
        res = falkordblite_storage.execute_raw_query(
            "MATCH (:DbtModel {id: 'model.test.model1'})-[:USES_MACRO]->(:DbtMacro {id: 'macro.test.generate_columns'}) RETURN 1 AS ok"
        )
        assert res.count == 1

