"""Tests for change detection."""

