"""Tests for change detection functionality.

Tests cover:
- ModelChangeSet dataclass properties
- ChangeDetector change detection logic
"""
from unittest.mock import Mock

from lineage.backends.lineage.protocol import RawLineageQueryResult
from lineage.ingest.static_loaders.change_detection import (
    ChangeDetector,
    ModelChangeSet,
)
from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
    compute_model_fingerprint_result,
)

from tests.test_helpers import create_mock_artifacts, create_mock_model


def get_fingerprint_hash(model_id: str, sql: str, dialect: str = "duckdb") -> str:
    """Get the hash-only fingerprint for a model's SQL.

    Uses compute_model_fingerprint_result and extracts just the hash,
    matching how ChangeDetector and the graph store fingerprints.
    """
    result = compute_model_fingerprint_result(
        resource_type="model",
        compiled_sql=sql,
        checksum=None,
        dialect=dialect,
        model_id=model_id,
    )
    assert result is not None, f"Failed to compute fingerprint for {model_id}"
    return result.hash


def setup_mock_storage_for_changes(
    mock_storage: Mock, fingerprint_rows: list[dict]
) -> None:
    """Helper to setup mock storage for change detection tests.

    Sets up the combined fingerprint + model ID query to return results.
    The query returns both id and model_fingerprint, with fingerprint being
    None for models that don't have one yet.
    """
    def mock_query(query: str):  # type: ignore[no-untyped-def]
        if "RETURN m.id AS id, m.model_fingerprint AS model_fingerprint" in query:
            # Combined query returns both id and fingerprint
            return RawLineageQueryResult(
                rows=fingerprint_rows,
                count=len(fingerprint_rows),
                query=query
            )
        return RawLineageQueryResult(rows=[], count=0, query=query)

    mock_storage.execute_raw_query.side_effect = mock_query


# ============================================================================
# Test ModelChangeSet (Unit Tests)
# ============================================================================


class TestModelChangeSet:
    """Tests for ModelChangeSet dataclass properties and methods."""

    def test_has_changes_true_when_added(self) -> None:
        """Verify has_changes returns True when models added."""
        change_set = ModelChangeSet(
            added=["model.test.new_model"],
            modified=[],
            removed=[],
            unchanged=[],
        )
        assert change_set.has_changes is True

    def test_has_changes_true_when_modified(self) -> None:
        """Verify has_changes returns True when models modified."""
        change_set = ModelChangeSet(
            added=[],
            modified=["model.test.modified_model"],
            removed=[],
            unchanged=[],
        )
        assert change_set.has_changes is True

    def test_has_changes_true_when_removed(self) -> None:
        """Verify has_changes returns True when models removed."""
        change_set = ModelChangeSet(
            added=[],
            modified=[],
            removed=["model.test.removed_model"],
            unchanged=[],
        )
        assert change_set.has_changes is True

    def test_has_changes_false_when_unchanged(self) -> None:
        """Verify has_changes returns False when all unchanged."""
        change_set = ModelChangeSet(
            added=[],
            modified=[],
            removed=[],
            unchanged=["model.test.existing_model"],
        )
        assert change_set.has_changes is False

    def test_models_to_process(self) -> None:
        """Verify models_to_process returns added + modified models."""
        change_set = ModelChangeSet(
            added=["model.test.new1", "model.test.new2"],
            modified=["model.test.modified1"],
            removed=["model.test.removed1"],
            unchanged=["model.test.unchanged1"],
        )
        result = change_set.models_to_process
        assert len(result) == 3
        assert "model.test.new1" in result
        assert "model.test.new2" in result
        assert "model.test.modified1" in result
        assert "model.test.removed1" not in result
        assert "model.test.unchanged1" not in result

    def test_empty_changeset(self) -> None:
        """Verify empty changeset properties."""
        change_set = ModelChangeSet(
            added=[],
            modified=[],
            removed=[],
            unchanged=[],
        )
        assert change_set.has_changes is False
        assert len(change_set.models_to_process) == 0


# ============================================================================
# Fingerprint helper (Unit Tests)
# ============================================================================


class TestModelFingerprint:
    """Tests for stable compiled-SQL fingerprinting."""

    def test_model_fingerprint_canonicalization_is_stable(self) -> None:
        """Whitespace/casing differences should canonicalize to the same fingerprint."""
        fp1 = get_fingerprint_hash("test.model.1", "select  1", dialect="duckdb")
        fp2 = get_fingerprint_hash("test.model.1", "SELECT 1", dialect="duckdb")
        assert fp1 == fp2


# ============================================================================
# Test ChangeDetector (Unit Tests)
# ============================================================================


class TestChangeDetector:
    """Tests for change detection logic with mock storage."""

    def test_detect_changes_added(self, mock_storage: Mock) -> None:
        """Detect new models not in graph."""
        # Graph is empty
        setup_mock_storage_for_changes(mock_storage, [])
        
        # Manifest has 2 new models
        models = [
            create_mock_model("model.test.model1", compiled_sql="select 1"),
            create_mock_model("model.test.model2", compiled_sql="select 2"),
        ]
        artifacts = create_mock_artifacts(models)
        
        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)
        
        assert len(change_set.added) == 2
        assert len(change_set.modified) == 0
        assert len(change_set.removed) == 0
        assert change_set.has_changes is True

    def test_detect_changes_modified(self, mock_storage: Mock) -> None:
        """Detect models with different fingerprints."""
        # Graph has model1 with old fingerprint (hash-only)
        old_fp = get_fingerprint_hash("model.test.model1", "select 1", dialect="duckdb")
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.model1", "model_fingerprint": old_fp},
        ])
        
        # Manifest has model1 with new fingerprint
        models = [
            create_mock_model("model.test.model1", compiled_sql="select 2"),
        ]
        artifacts = create_mock_artifacts(models)
        
        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)
        
        assert len(change_set.added) == 0
        assert len(change_set.modified) == 1
        assert "model.test.model1" in change_set.modified
        assert len(change_set.removed) == 0

    def test_detect_changes_removed(self, mock_storage: Mock) -> None:
        """Detect models in graph but not in manifest."""
        # Graph has model1
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.model1", "model_fingerprint": "deadbeef"},
        ])
        
        # Manifest is empty
        artifacts = create_mock_artifacts([])
        
        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)
        
        assert len(change_set.added) == 0
        assert len(change_set.modified) == 0
        assert len(change_set.removed) == 1
        assert "model.test.model1" in change_set.removed

    def test_detect_changes_unchanged(self, mock_storage: Mock) -> None:
        """Detect models with same fingerprint."""
        fp = get_fingerprint_hash("model.test.model1", "select 1", dialect="duckdb")
        # Graph has model1 with fingerprint (hash-only)
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.model1", "model_fingerprint": fp},
        ])
        
        # Manifest has model1 with same fingerprint (after canonicalization)
        models = [
            create_mock_model("model.test.model1", compiled_sql="SELECT 1"),
        ]
        artifacts = create_mock_artifacts(models)
        
        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)
        
        assert len(change_set.added) == 0
        assert len(change_set.modified) == 0
        assert len(change_set.removed) == 0
        assert len(change_set.unchanged) == 1
        assert "model.test.model1" in change_set.unchanged

    def test_detect_changes_mixed(self, mock_storage: Mock) -> None:
        """Detect combination of added/modified/removed/unchanged."""
        fp1 = get_fingerprint_hash("model.test.model1", "select 1", dialect="duckdb")
        # Graph has model1 (unchanged) and model2 (will be removed)
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.model1", "model_fingerprint": fp1},
            {"id": "model.test.model2", "model_fingerprint": "deadbeef"},
        ])
        
        # Manifest has model1 (unchanged), model3 (new), model4 (new)
        models = [
            create_mock_model("model.test.model1", compiled_sql="SELECT 1"),  # unchanged
            create_mock_model("model.test.model3", compiled_sql="select 3"),  # new
            create_mock_model("model.test.model4", compiled_sql="select 4"),  # new
        ]
        artifacts = create_mock_artifacts(models)
        
        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)
        
        assert len(change_set.added) == 2  # model3 and model4
        assert len(change_set.modified) == 0
        assert len(change_set.removed) == 1  # model2
        assert len(change_set.unchanged) == 1  # model1

    def test_detect_changes_no_checksum_in_graph(self, mock_storage: Mock) -> None:
        """Handle models in graph without fingerprint.

        When a model exists in the graph but has no fingerprint (e.g., from
        a previous load before fingerprinting was implemented), it should
        be treated as modified to ensure it gets reprocessed.
        """
        # Model exists in graph but has no fingerprint (None)
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.model1", "model_fingerprint": None},
        ])

        # Manifest has model1 with compiled SQL
        models = [
            create_mock_model("model.test.model1", compiled_sql="select 1"),
        ]
        artifacts = create_mock_artifacts(models)

        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)

        # Model without fingerprint in graph should be treated as modified
        assert len(change_set.modified) == 1

    def test_detect_changes_no_checksum_in_manifest(self, mock_storage: Mock) -> None:
        """Handle models in manifest without compiled SQL fingerprint.

        Models without compiled_sql (empty string or None) cannot produce a
        fingerprint. This happens for:
        - Seeds (CSV data, no SQL)
        - Analyses that haven't been compiled
        - Models that failed dbt compilation

        These models are treated conservatively:
        - If not in graph: treated as "added" (processed as new)
        - If in graph: treated as "modified" (reprocessed for safety)

        This ensures correctness over efficiency - we'd rather reprocess
        a model unnecessarily than miss a change.
        """
        # Graph is empty
        setup_mock_storage_for_changes(mock_storage, [])

        # Manifest has model1 without compiled SQL (no fingerprint possible)
        models = [
            create_mock_model("model.test.model1", compiled_sql=""),
        ]
        artifacts = create_mock_artifacts(models)

        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)

        # Model without fingerprint should be treated as added (graph empty)
        assert len(change_set.added) == 1

    def test_detect_changes_no_checksum_in_manifest_existing_model(self, mock_storage: Mock) -> None:
        """Models without compiled_sql that exist in graph are treated as modified.

        See test_detect_changes_no_checksum_in_manifest for background on why
        models without compiled_sql cannot produce fingerprints.
        """
        # Graph has the model with a fingerprint from a previous load
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.model1", "model_fingerprint": "previous_fingerprint"},
        ])

        # Manifest has model1 but without compiled SQL (e.g., compilation failed this time)
        models = [
            create_mock_model("model.test.model1", compiled_sql=""),
        ]
        artifacts = create_mock_artifacts(models)

        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)

        # Model without fingerprint in manifest but exists in graph -> modified (safe)
        assert len(change_set.modified) == 1
        assert "model.test.model1" in change_set.modified

    def test_detect_changes_empty_graph(self, mock_storage: Mock) -> None:
        """First load (empty graph)."""
        # Graph is empty
        setup_mock_storage_for_changes(mock_storage, [])
        
        # Manifest has models
        models = [
            create_mock_model("model.test.model1", compiled_sql="select 1"),
            create_mock_model("model.test.model2", compiled_sql="select 2"),
        ]
        artifacts = create_mock_artifacts(models)
        
        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)
        
        assert len(change_set.added) == 2
        assert len(change_set.modified) == 0
        assert len(change_set.removed) == 0

    def test_detect_changes_query_failure(self, mock_storage: Mock) -> None:
        """Handle storage query failures gracefully."""
        # Storage query fails
        mock_storage.execute_raw_query.side_effect = Exception("Query failed")

        models = [
            create_mock_model("model.test.model1", compiled_sql="select 1"),
        ]
        artifacts = create_mock_artifacts(models)

        detector = ChangeDetector()
        change_set = detector.detect_changes(artifacts, mock_storage)

        # Should treat all models as new when query fails
        assert len(change_set.added) == 1

    def test_detect_changes_with_custom_dialect_resolver(self, mock_storage: Mock) -> None:
        """Custom dialect_resolver overrides artifacts.adapter_type for fingerprinting.

        This is useful when:
        - Different models use different SQL dialects
        - The manifest adapter_type doesn't match the actual SQL dialect
        - Testing with a specific dialect regardless of manifest metadata
        """
        # Graph is empty - all models will be added
        setup_mock_storage_for_changes(mock_storage, [])

        # Create models - the SQL is dialect-agnostic for this test
        models = [
            create_mock_model("model.test.snowflake_model", compiled_sql="select 1"),
            create_mock_model("model.test.duckdb_model", compiled_sql="select 2"),
        ]
        artifacts = create_mock_artifacts(models)

        # Track which dialects were requested for each model
        dialect_calls: dict[str, str] = {}

        def custom_dialect_resolver(model_id: str) -> str:
            """Return different dialects based on model naming convention."""
            if "snowflake" in model_id:
                dialect = "snowflake"
            else:
                dialect = "duckdb"
            dialect_calls[model_id] = dialect
            return dialect

        detector = ChangeDetector()
        change_set = detector.detect_changes(
            artifacts, mock_storage, dialect_resolver=custom_dialect_resolver
        )

        # Verify the resolver was called for each model
        assert len(dialect_calls) == 2
        assert dialect_calls["model.test.snowflake_model"] == "snowflake"
        assert dialect_calls["model.test.duckdb_model"] == "duckdb"

        # Both models should be detected as added (empty graph)
        assert len(change_set.added) == 2

    def test_detect_changes_dialect_resolver_affects_fingerprint(self, mock_storage: Mock) -> None:
        """Dialect affects fingerprint canonicalization, so resolver choice matters.

        Different dialects may canonicalize SQL differently, leading to different
        fingerprints for the same SQL string. This test verifies that using a
        consistent dialect_resolver produces consistent fingerprints.
        """
        # Compute fingerprint with duckdb dialect for the graph state
        fp_duckdb = get_fingerprint_hash("model.test.m1", "select 1", dialect="duckdb")

        # Graph has the model with a duckdb-computed fingerprint
        setup_mock_storage_for_changes(mock_storage, [
            {"id": "model.test.m1", "model_fingerprint": fp_duckdb},
        ])

        models = [
            create_mock_model("model.test.m1", compiled_sql="select 1"),
        ]
        artifacts = create_mock_artifacts(models)

        detector = ChangeDetector()

        # Using duckdb dialect should show unchanged (same fingerprint)
        change_set_duckdb = detector.detect_changes(
            artifacts, mock_storage, dialect_resolver=lambda _: "duckdb"
        )
        assert len(change_set_duckdb.unchanged) == 1
        assert len(change_set_duckdb.modified) == 0

        # Using snowflake dialect may show modified if fingerprints differ
        # (This depends on whether sqlglot produces different canonical forms)
        change_set_snowflake = detector.detect_changes(
            artifacts, mock_storage, dialect_resolver=lambda _: "snowflake"
        )
        # The model is either unchanged (same canonical form) or modified (different)
        # We just verify the resolver was used by checking the model was categorized
        assert (
            len(change_set_snowflake.unchanged) == 1 or len(change_set_snowflake.modified) == 1
        )

