"""Test YAML escaping in typedef config template."""
import yaml
from lineage.templates import render_typedef_config


def test_template_handles_windows_paths():
    """Test that Windows paths with backslashes are properly escaped."""
    result = render_typedef_config(
        project_name="test_project",
        dbt_path=r"C:\Users\test\project",
        graph_db_path=r"C:\Users\test\.typedef\graph.db",
        typedef_home=r"C:\Users\test\.typedef",
        snowflake_account="test",
        snowflake_user="test",
        snowflake_warehouse="test",
        snowflake_role="test",
        snowflake_database="test",
        snowflake_schema="PUBLIC",
        snowflake_private_key_path=r"C:\Users\test\keys\rsa_key.p8",
        profile_name="dev",
    )
    
    # Should be valid YAML
    config = yaml.safe_load(result)
    assert config["projects"]["test_project"]["dbt_path"] == r"C:\Users\test\project"


def test_template_handles_quotes_in_values():
    """Test that values with double quotes are properly escaped."""
    result = render_typedef_config(
        project_name="test_project",
        dbt_path="/path/to/project",
        graph_db_path="/path/to/graph.db",
        typedef_home="/path/to/.typedef",
        snowflake_account='test"account',
        snowflake_user="test",
        snowflake_warehouse="test",
        snowflake_role="test",
        snowflake_database="test",
        snowflake_schema="PUBLIC",
        snowflake_private_key_path="/path/to/key",
        profile_name="dev",
    )
    
    # Should be valid YAML
    config = yaml.safe_load(result)
    assert config["data"]["account"] == 'test"account'


def test_template_handles_colons_in_project_name():
    """Test that project names with colons are properly quoted as YAML keys."""
    result = render_typedef_config(
        project_name="project:with:colons",
        dbt_path="/path/to/project",
        graph_db_path="/path/to/graph.db",
        typedef_home="/path/to/.typedef",
        snowflake_account="test",
        snowflake_user="test",
        snowflake_warehouse="test",
        snowflake_role="test",
        snowflake_database="test",
        snowflake_schema="PUBLIC",
        snowflake_private_key_path="/path/to/key",
        profile_name="dev",
    )
    
    # Should be valid YAML
    config = yaml.safe_load(result)
    assert "project:with:colons" in config["projects"]


def test_template_handles_project_env_vars_with_special_chars():
    """Test that project_env_vars with special characters are properly escaped."""
    result = render_typedef_config(
        project_name="test_project",
        dbt_path="/path/to/project",
        graph_db_path="/path/to/graph.db",
        typedef_home="/path/to/.typedef",
        snowflake_account="test",
        snowflake_user="test",
        snowflake_warehouse="test",
        snowflake_role="test",
        snowflake_database="test",
        snowflake_schema="PUBLIC",
        snowflake_private_key_path="/path/to/key",
        profile_name="dev",
        project_env_vars={
            "PATH": r"C:\Users\test\bin;C:\Program Files\app",
            "QUOTED": 'value with "quotes"',
            "NEWLINE": "line1\nline2",
            "COLON:KEY": "value:with:colons",
        },
    )
    
    # Should be valid YAML
    config = yaml.safe_load(result)
    env_vars = config["projects"]["test_project"]["env"]
    assert env_vars["PATH"] == r"C:\Users\test\bin;C:\Program Files\app"
    assert env_vars["QUOTED"] == 'value with "quotes"'
    assert env_vars["NEWLINE"] == "line1\nline2"
    assert "COLON:KEY" in env_vars


def test_template_handles_newlines_in_values():
    """Test that values with newlines are properly escaped."""
    result = render_typedef_config(
        project_name="test_project",
        dbt_path="/path/to/project",
        graph_db_path="/path/to/graph.db",
        typedef_home="/path/to/.typedef",
        snowflake_account="test",
        snowflake_user="test",
        snowflake_warehouse="test",
        snowflake_role="test",
        snowflake_database="test",
        snowflake_schema="PUBLIC",
        snowflake_private_key_path="/path/to/key",
        profile_name="dev",
        default_database="db\nwith\nnewlines",
    )
    
    # Should be valid YAML
    config = yaml.safe_load(result)
    assert config["projects"]["test_project"]["default_database"] == "db\nwith\nnewlines"

