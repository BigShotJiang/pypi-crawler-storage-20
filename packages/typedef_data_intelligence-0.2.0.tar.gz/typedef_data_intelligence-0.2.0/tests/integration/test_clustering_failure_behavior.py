"""Tests for the clustering failure behavior."""
from __future__ import annotations

from unittest.mock import Mock

import pytest

import lineage.integration as integration_mod
from lineage.ingest.config import (
    ClusteringConfig,
    ProfilingConfig,
    SemanticAnalysisConfig,
    SemanticViewLoaderConfig,
)
from lineage.integration import LineageIntegration


class _FailingClusteringOrchestrator:
    def __init__(self, storage):  # type: ignore[no-untyped-def]
        self.storage = storage

    async def cluster_and_analyze(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        raise RuntimeError("boom")


def _make_integration(mock_storage, clustering_config: ClusteringConfig) -> LineageIntegration:
    return LineageIntegration(
        storage=mock_storage,
        semantic_config=SemanticAnalysisConfig(enabled=False),
        profiling_config=ProfilingConfig(enabled=False),
        clustering_config=clustering_config,
        semantic_view_config=SemanticViewLoaderConfig(enabled=False),
        data_backend=None,
    )


def test_run_clustering_is_best_effort_by_default(
    mock_storage, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Clustering failures should be logged but not abort the sync by default."""
    monkeypatch.setattr(
        integration_mod, "ClusteringOrchestrator", _FailingClusteringOrchestrator
    )
    integration = _make_integration(mock_storage, ClusteringConfig())

    ok = integration._run_clustering(session=Mock(), verbose=False)
    assert ok is False


def test_run_clustering_fail_fast_raises(
    mock_storage, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Opt-in fail-fast mode should propagate clustering exceptions."""
    monkeypatch.setattr(
        integration_mod, "ClusteringOrchestrator", _FailingClusteringOrchestrator
    )
    integration = _make_integration(mock_storage, ClusteringConfig(fail_fast=True))

    with pytest.raises(RuntimeError, match="boom"):
        integration._run_clustering(session=Mock(), verbose=False)


