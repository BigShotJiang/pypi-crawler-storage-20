"""TUI wizards for typedef setup and configuration."""




