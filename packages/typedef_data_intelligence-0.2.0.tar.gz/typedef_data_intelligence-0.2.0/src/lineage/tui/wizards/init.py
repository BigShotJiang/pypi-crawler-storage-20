"""Init wizard for typedef setup.

This module provides a full-screen TUI wizard for the `typedef init` command.
"""
import logging
import re
import subprocess  # nosec B404 - only used for CalledProcessError type
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional

from rich.markup import escape as escape_markup
from textual import work
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.widgets import (
    Button,
    Input,
    Label,
    LoadingIndicator,
    Select,
    SelectionList,
    Static,
)
from textual.widgets.selection_list import Selection

from lineage.tui.wizards.base import (
    AsyncStepMixin,
    BaseWizardApp,
    StepState,
    WizardScreen,
    WizardStep,
)
from lineage.utils.dbt import run_dbt_command
from lineage.utils.gitignore import ensure_gitignore_contains
from lineage.utils.git import clone_repo, is_valid_git_url
from lineage.utils.snowflake import (
    list_snowflake_databases,
    validate_snowflake_read_access,
)

logger = logging.getLogger(__name__)

# Regex to match ANSI escape sequences (colors, formatting, etc.)
ANSI_ESCAPE_PATTERN = re.compile(r'\x1b\[[0-9;]*m')


def strip_ansi_codes(text: str) -> str:
    r"""Strip ANSI escape codes from text.

    Rich's escape_markup() only escapes Rich markup syntax like [bold],
    but ANSI codes like \\x1b[0m contain literal [ characters that Rich
    interprets as markup. This function removes them entirely.

    Args:
        text: Text potentially containing ANSI escape codes

    Returns:
        Text with ANSI codes removed
    """
    return ANSI_ESCAPE_PATTERN.sub('', text)


# =============================================================================
# Shared Helpers for Background Workers
# =============================================================================


def create_ui_updater(step: WizardStep) -> Callable[[str, str], None]:
    """Create a UI update helper for background threads.

    Args:
        step: The wizard step containing the widgets

    Returns:
        A function that updates a Static widget by selector
    """
    def update_ui(selector: str, text: str) -> None:
        try:
            widget = step.query_one(selector, Static)
            widget.update(text)
        except NoMatches:
            pass
    return update_ui


def create_spinner_toggle(step: WizardStep, spinner_id: str) -> Callable[[bool], None]:
    """Create a spinner toggle helper for background threads.

    Args:
        step: The wizard step containing the spinner
        spinner_id: The ID of the LoadingIndicator widget

    Returns:
        A function that shows/hides the spinner
    """
    def show_spinner(visible: bool) -> None:
        try:
            spinner = step.query_one(f"#{spinner_id}", LoadingIndicator)
            spinner.display = visible
        except NoMatches:
            pass
    return show_spinner


def run_dbt_deps(
    project_path: Path,
    app: App,
    update_ui: Callable[[str, str], None],
    status_selector: str = "#clone-status",
    output_selector: str = "#dbt-output",
) -> None:
    """Run dbt deps for a project (doesn't require profiles.yml).

    Args:
        project_path: Path to the dbt project
        app: The Textual app (for call_from_thread)
        update_ui: UI update helper function
        status_selector: CSS selector for status widget
        output_selector: CSS selector for output widget
    """
    app.call_from_thread(update_ui, status_selector, "⏳ Running dbt deps...")
    try:
        stdout, _stderr = run_dbt_command(["deps"], project_path, profiles_dir=project_path)
        if stdout:
            # Strip ANSI codes to prevent Rich markup parsing errors
            clean_output = strip_ansi_codes(stdout[-500:])
            app.call_from_thread(update_ui, output_selector, f"dbt deps:\n{clean_output}")
        app.call_from_thread(update_ui, status_selector, "✅ dbt deps complete")
    except subprocess.CalledProcessError as e:
        error_msg = f"⚠️ dbt deps failed (exit {e.returncode})"
        if e.stderr:
            # Strip ANSI codes from stderr as well
            clean_stderr = strip_ansi_codes(e.stderr[-500:])
            error_msg += f"\n{clean_stderr}"
        app.call_from_thread(update_ui, output_selector, error_msg)
        # Continue anyway


def run_dbt_docs_generate(
    project_path: Path,
    app: App,
    update_ui: Callable[[str, str], None],
    status_selector: str = "#clone-status",
    output_selector: str = "#dbt-output",
) -> None:
    """Run dbt docs generate for a project (requires profiles.yml).

    Args:
        project_path: Path to the dbt project
        app: The Textual app (for call_from_thread)
        update_ui: UI update helper function
        status_selector: CSS selector for status widget
        output_selector: CSS selector for output widget
    """
    app.call_from_thread(update_ui, status_selector, "⏳ Running dbt docs generate...")
    try:
        run_dbt_command(["docs", "generate"], project_path, profiles_dir=project_path)
        app.call_from_thread(update_ui, status_selector, "✅ dbt docs generate complete!")
    except subprocess.CalledProcessError as e:
        error_msg = f"⚠️ dbt docs failed (exit {e.returncode})"
        if e.stdout:
            # Strip ANSI codes to prevent Rich markup parsing errors
            clean_stdout = strip_ansi_codes(e.stdout[-500:])
            error_msg += f"\n{clean_stdout}"
        logger.error(f"dbt docs generate failed: {e.stdout} {e.stderr}")
        app.call_from_thread(update_ui, output_selector, error_msg)
        # Continue anyway - manifest might already exist

def get_dbt_profile_name(project_path: Path) -> Optional[str]:
    """Extract the profile name from dbt_project.yml.

    Args:
        project_path: Path to directory containing dbt_project.yml

    Returns:
        Profile name if found, None otherwise
    """
    import yaml

    dbt_project_file = project_path / "dbt_project.yml"
    if not dbt_project_file.exists():
        return None

    try:
        with open(dbt_project_file) as f:
            config = yaml.safe_load(f)
        return config.get("profile")
    except (OSError, yaml.YAMLError):
        return None


def find_dbt_projects(root_path: Path, max_depth: int = 3) -> list[Path]:
    """Find all dbt_project.yml files within a directory tree.

    Args:
        root_path: Root directory to search from
        max_depth: Maximum depth to search (default 3)

    Returns:
        List of paths to directories containing dbt_project.yml
    """
    projects = []

    def search(path: Path, depth: int):
        if depth > max_depth:
            return
        try:
            for item in path.iterdir():
                if item.is_file() and item.name == "dbt_project.yml":
                    projects.append(item.parent)
                elif item.is_dir() and not item.name.startswith(".") and not item.name.startswith("dbt_packages"):
                    search(item, depth + 1)
        except (PermissionError, OSError):
            pass

    search(root_path, 0)
    return sorted(projects)


# =============================================================================
# Thread-Safe UI Update Helpers
# =============================================================================


def update_status(widget_id: str, message: str, app: App) -> None:
    """Thread-safe status widget update.

    Args:
        widget_id: CSS selector for widget (with or without #)
        message: Text to display
        app: The Textual app for call_from_thread
    """
    selector = f"#{widget_id}" if not widget_id.startswith("#") else widget_id

    def _update():
        try:
            widget = app.query_one(selector, Static)
            widget.update(message)
        except NoMatches:
            pass

    app.call_from_thread(_update)


def show_spinner(message: str, status_id: str, app: App) -> None:
    """Show spinner with message."""
    update_status(status_id, f"⏳ {message}", app)


def show_success(message: str, status_id: str, app: App) -> None:
    """Show success checkmark with message."""
    update_status(status_id, f"✅ {message}", app)


def show_error(message: str, status_id: str, app: App) -> None:
    """Show error message."""
    update_status(status_id, f"❌ {message}", app)


def set_button_disabled(button_id: str, disabled: bool, app: App) -> None:
    """Thread-safe button disabled state change."""
    selector = f"#{button_id}" if not button_id.startswith("#") else button_id

    def _update():
        try:
            btn = app.query_one(selector, Button)
            btn.disabled = disabled
        except NoMatches:
            pass

    app.call_from_thread(_update)


def focus_button(button_id: str, app: App) -> None:
    """Thread-safe button focus."""
    selector = f"#{button_id}" if not button_id.startswith("#") else button_id

    def _update():
        try:
            btn = app.query_one(selector, Button)
            btn.focus()
        except NoMatches:
            pass

    app.call_from_thread(_update)


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class SnowflakeCredentials:
    """Container for Snowflake connection credentials (key-based auth)."""

    account: str
    user: str
    role: str
    warehouse: str
    private_key_path: str
    database: str = ""
    schema: str = ""

    def validate_required(self) -> tuple[bool, str]:
        """Check all required fields are present.

        Returns:
            tuple: (is_valid, error_message)
        """
        if not self.account:
            return False, "Account identifier is required"
        if not self.user:
            return False, "Username is required"
        if not self.private_key_path:
            return False, "Private key path is required"
        # Validate key file exists
        key_path = Path(self.private_key_path).expanduser()
        if not key_path.exists():
            return False, f"Private key not found: {key_path}"
        return True, ""

    def to_dict(self) -> dict[str, str]:
        """Convert to dict for passing to Snowflake functions."""
        return {
            "account": self.account,
            "user": self.user,
            "role": self.role,
            "warehouse": self.warehouse,
            "private_key_path": self.private_key_path,
        }


@dataclass
class DbtProjectInfo:
    """Resolved dbt project information."""

    root_path: Path
    target_path: Path
    profile_name: str
    is_monorepo: bool
    subprojects: list[Path]
    was_cloned: bool
    needs_profile_generation: bool

    @classmethod
    def from_path(cls, path: str, was_cloned: bool = False) -> "DbtProjectInfo":
        """Resolve dbt project from path.

        Args:
            path: Path to dbt project directory
            was_cloned: Whether this project was cloned from git

        Returns:
            DbtProjectInfo with resolved paths and metadata
        """
        root = Path(path).expanduser().resolve()

        # Check for monorepo (multiple projects or no project at root)
        subprojects = find_dbt_projects(root, max_depth=3)
        has_root_project = (root / "dbt_project.yml").exists()
        is_monorepo = not has_root_project and len(subprojects) > 0

        # Get profile name from dbt_project.yml
        profile_name = get_dbt_profile_name(root) or "dev"

        # Check if profiles.yml exists
        needs_profile = not (root / "profiles.yml").exists()

        return cls(
            root_path=root,
            target_path=root / "target",
            profile_name=profile_name,
            is_monorepo=is_monorepo,
            subprojects=subprojects,
            was_cloned=was_cloned,
            needs_profile_generation=needs_profile,
        )


# =============================================================================
# Wizard Steps
# =============================================================================


class ProjectNameStep(WizardStep):
    """Step 1: Project name."""

    def __init__(self):
        """Initialize project name step."""
        super().__init__(
            title="Project Name",
            description="What would you like to call this project?",
            step_id="project-name",
        )
        self.input: Input

    def get_content(self) -> ComposeResult:
        """Get step content."""
        yield Label("Project name:")
        self.input = Input(
            placeholder="my_analytics",
            id="project-name-input",
        )
        yield self.input
        yield Static(
            "Use letters, numbers, hyphens, and underscores only",
            classes="wizard-hint",
        )

    async def validate(self) -> tuple[bool, str]:
        """Validate project name."""
        value = self.input.value.strip()
        if not value:
            return False, "Project name is required"
        if not value.replace("_", "").replace("-", "").isalnum():
            return False, "Use only letters, numbers, hyphens, and underscores"
        if value.startswith("-") or value.startswith("_"):
            return False, "Project name cannot start with - or _"
        return True, ""

    def get_data(self) -> dict[str, Any]:
        """Get project name data."""
        return {"project_name": self.input.value.strip()}


class DbtPathStep(WizardStep):
    """Step 2: dbt project path or git repository."""

    def __init__(self):
        """Initialize dbt path step."""
        super().__init__(
            title="dbt Project Location",
            description="Provide a local path OR a Git repository URL.",
            step_id="dbt-path",
        )
        self.input: Input
        self.is_git_url: bool = False
        self.was_git_clone: bool = False  # Persists after input is updated to local path
        self.project_name: str = ""
        self.work_complete: bool = False
        self.work_in_progress: bool = False
        self.work_error: Optional[str] = None
        self._work_lock = threading.Lock()  # Protects work_in_progress flag

    def get_content(self) -> ComposeResult:
        """Get step content."""
        yield Label("Local path OR Git URL:")

        # Try to default to current directory
        default_path = str(Path.cwd())
        self.input = Input(
            placeholder=default_path,
            value=default_path,
            id="dbt-path-input",
        )
        yield self.input

        yield Static(
            "• Local path: /path/to/dbt_project (Data Engineer Copilot will operate in this directory)\n"
            "• Git URL: https://github.com/org/repo.git (a fresh clone will be created. Data Engineer Copilot will operate in this clone)",
            classes="wizard-hint",
        )

        yield Static(id="clone-status", classes="wizard-hint")

        spinner = LoadingIndicator(id="clone-spinner")
        spinner.display = False
        yield spinner

        # Output display for dbt commands
        yield Static(id="dbt-output", classes="wizard-hint")

    async def validate(self) -> tuple[bool, str]:
        """Validate dbt path or git URL."""
        value = self.input.value.strip()
        if not value:
            return False, "Path or URL is required"

        # Update project name from wizard data
        if self.screen and hasattr(self.screen, "wizard_data"):
            self.project_name = self.screen.wizard_data.get("project_name", "default_project")

        self.is_git_url = is_valid_git_url(value)

        if self.is_git_url:
            # Remember this was a git clone (persists after input is updated to local path)
            self.was_git_clone = True

            # Git URL path - need to clone and run dbt
            if self.work_error:
                return False, self.work_error

            if not self.work_complete:
                # Start the work if not already in progress
                if not self.work_in_progress:
                    self.run_git_and_dbt_work(value)
                # Work is in progress - button is disabled, just return True
                # (button will be re-enabled when work completes)
                return False, ""

            # Work is complete
            return True, ""
        else:
            # Local path validation (synchronous, fast)
            path = Path(value).expanduser().resolve()
            if not path.exists():
                return False, f"Path does not exist: {path}"
            if not path.is_dir():
                return False, f"Path is not a directory: {path}"

            # Check if dbt_project.yml exists at root
            has_root_project = (path / "dbt_project.yml").exists()

            if not has_root_project:
                # Check for subprojects (monorepo case)
                subprojects = find_dbt_projects(path, max_depth=3)
                if not subprojects:
                    return False, "No dbt_project.yml found in this directory or subdirectories"
                # Store detected subprojects for next step
                if self.screen and hasattr(self.screen, "wizard_data"):
                    self.screen.wizard_data["detected_subprojects"] = [str(p) for p in subprojects]

            # Check for profiles.yml
            has_profile = (path / "profiles.yml").exists()
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["needs_profile_generation"] = not has_profile

            return True, ""

    @work(thread=True)
    def run_git_and_dbt_work(self, git_url: str) -> None:
        """Clone repo and run dbt commands in background thread."""
        # Use lock to prevent race condition when clicking rapidly
        with self._work_lock:
            if self.work_in_progress or self.work_complete:
                return
            self.work_in_progress = True
            self.work_error = None

        # Create UI helpers
        update_ui = create_ui_updater(self)
        show_spinner = create_spinner_toggle(self, "clone-spinner")

        # Disable Next button while working
        if self.screen:
            self.app.call_from_thread(
                lambda: setattr(self.screen.query_one("#next-btn", Button), "disabled", True)
            )

        # Show spinner and update status
        self.app.call_from_thread(show_spinner, True)
        clone_dir = Path.home() / ".typedef" / "projects" / self.project_name
        self.app.call_from_thread(
            update_ui,
            "#clone-status",
            f"⏳ Cloning {git_url} to {clone_dir}..."
        )

        try:
            # Clone repository (or use existing)
            if clone_dir.exists() and any(clone_dir.iterdir()):
                # Directory exists with contents - check if it's a valid project or monorepo
                has_root_project = (clone_dir / "dbt_project.yml").exists()
                has_subprojects = bool(find_dbt_projects(clone_dir, max_depth=3))

                if not has_root_project and not has_subprojects:
                    self.work_error = f"Directory {clone_dir} exists but contains no dbt projects"
                    self.work_in_progress = False
                    self.app.call_from_thread(show_spinner, False)
                    self.app.call_from_thread(update_ui, "#clone-status", f"❌ {self.work_error}")
                    return
                # Already exists and valid - skip clone
                self.app.call_from_thread(update_ui, "#clone-status", f"✅ Using existing clone at {clone_dir}")
            else:
                # Clone fresh
                clone_repo(git_url, clone_dir)
                self.app.call_from_thread(update_ui, "#clone-status", f"✅ Cloned to {clone_dir}")

            # Update input to local path
            self.app.call_from_thread(lambda: setattr(self.input, "value", str(clone_dir)))

            # Check for profiles.yml
            has_profile = (clone_dir / "profiles.yml").exists()
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["needs_profile_generation"] = not has_profile

            # Check if this is a monorepo (no dbt_project.yml at root)
            has_root_project = (clone_dir / "dbt_project.yml").exists()

            if not has_root_project:
                # Monorepo - scan for subprojects
                subprojects = find_dbt_projects(clone_dir, max_depth=3)
                if subprojects:
                    self.app.call_from_thread(
                        update_ui,
                        "#clone-status",
                        f"✅ Clone complete. Found {len(subprojects)} dbt project(s) - select one in next step."
                    )
                    # Store subprojects for next step
                    if self.screen and hasattr(self.screen, "wizard_data"):
                        self.screen.wizard_data["detected_subprojects"] = [str(p) for p in subprojects]
                    # Skip dbt commands - will be run after subproject selection
                else:
                    self.work_error = "No dbt_project.yml found in cloned repository"
                    self.work_in_progress = False
                    self.app.call_from_thread(show_spinner, False)
                    self.app.call_from_thread(update_ui, "#clone-status", f"❌ {self.work_error}")
                    return
            else:
                # Single project at root - run dbt deps only (docs generate needs profile)
                run_dbt_deps(
                    clone_dir, self.app, update_ui,
                    status_selector="#clone-status",
                    output_selector="#dbt-output"
                )

            # Mark work as complete
            self.work_complete = True
            self.work_in_progress = False

            # Hide spinner and re-enable Next button
            self.app.call_from_thread(show_spinner, False)
            if self.screen:
                def enable_next():
                    btn = self.screen.query_one("#next-btn", Button)
                    btn.disabled = False
                    btn.focus()
                self.app.call_from_thread(enable_next)

        except Exception as e:
            # Strip ANSI codes from error message (command output may contain them)
            self.work_error = f"Clone failed: {strip_ansi_codes(str(e))}"
            self.work_in_progress = False
            self.work_complete = False
            self.app.call_from_thread(show_spinner, False)
            self.app.call_from_thread(update_ui, "#clone-status", f"❌ {self.work_error}")
            # Re-enable Next so user can fix and retry
            if self.screen:
                self.app.call_from_thread(
                    lambda: setattr(self.screen.query_one("#next-btn", Button), "disabled", False)
                )

    def get_data(self) -> dict[str, Any]:
        """Get dbt path data."""
        # If input was a URL, it was updated to the local path during validate
        path = Path(self.input.value.strip()).expanduser().resolve()
        return {
            "dbt_path": str(path),
            "is_git_clone": self.was_git_clone  # Use persisted flag, not current URL check
        }


class DbtSubProjectStep(WizardStep):
    """Step 2b: Select dbt sub-project if multiple found."""

    def __init__(self):
        """Initialize dbt sub-project selection step."""
        super().__init__(
            title="Select dbt Project",
            description="Multiple dbt projects found. Select the one to use.",
            step_id="dbt-subproject",
        )
        self.project_select: Select | None = None
        self.manual_input: Input | None = None
        self.projects: list[Path] = []
        self.base_path: Path = Path()
        self.skip_step: bool = False
        self.needs_dbt_setup: bool = False  # True if we need to run dbt commands
        self.dbt_setup_complete: bool = False
        self.dbt_setup_in_progress: bool = False
        self.dbt_setup_error: Optional[str] = None

    def get_content(self) -> ComposeResult:
        """Get step content."""
        # Scan for projects first (before rendering UI)
        if self.screen and hasattr(self.screen, "wizard_data"):
            dbt_path_str = self.screen.wizard_data.get("dbt_path", "")
            self.base_path = Path(dbt_path_str).expanduser().resolve()

            # Check if subprojects were detected during clone (monorepo case)
            detected = self.screen.wizard_data.get("detected_subprojects", [])
            is_git_clone = self.screen.wizard_data.get("is_git_clone", False)
            if detected:
                self.projects = [Path(p) for p in detected]
                # Only need dbt setup for git clones (local projects likely have manifest)
                self.needs_dbt_setup = is_git_clone
            else:
                # Scan for dbt projects
                self.projects = find_dbt_projects(self.base_path, max_depth=3)

            # If exactly one project at root, skip this step
            if len(self.projects) == 1 and self.projects[0] == self.base_path:
                self.skip_step = True
                if self.screen:
                    self.screen.wizard_data["dbt_project_root"] = str(self.base_path)

        if self.skip_step:
            yield Static("✅ Single dbt project found at repository root", classes="wizard-hint")
            return

        if len(self.projects) > 1:
            yield Label(f"Found {len(self.projects)} dbt projects:")

            # Show relative paths
            options = []
            for proj in self.projects:
                try:
                    rel_path = proj.relative_to(self.base_path)
                    display = str(rel_path) if str(rel_path) != "." else "(root)"
                except ValueError:
                    display = str(proj)
                options.append((display, str(proj)))

            self.project_select = Select(
                options=options,
                prompt="Select dbt project root",
                id="project-select",
            )
            yield self.project_select

            # Status for dbt setup
            yield Static(id="subproject-status", classes="wizard-hint")
            spinner = LoadingIndicator(id="subproject-spinner")
            spinner.display = False
            yield spinner
            yield Static(id="subproject-output", classes="wizard-hint")

        elif len(self.projects) == 1:
            # Single subproject found (not at root)
            yield Label(f"Found dbt project at: {self.projects[0]}")
            yield Static(id="subproject-status", classes="wizard-hint")
            spinner = LoadingIndicator(id="subproject-spinner")
            spinner.display = False
            yield spinner
            yield Static(id="subproject-output", classes="wizard-hint")

            # Auto-select it
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["dbt_project_root"] = str(self.projects[0])

        elif len(self.projects) == 0:
            yield Static("⚠️ No dbt_project.yml found in repository", classes="wizard-hint")
            yield Label("Enter the relative path to your dbt project:")
            self.manual_input = Input(
                placeholder="path/to/dbt_project",
                id="manual-subproject-input",
            )
            yield self.manual_input

    async def validate(self) -> tuple[bool, str]:
        """Validate selection."""
        if self.skip_step:
            return True, ""

        selected_path: Optional[Path] = None

        if len(self.projects) > 1:
            if not self.project_select or not self.project_select.value:
                return False, "Please select a dbt project"
            selected_path = Path(self.project_select.value)
            if not (selected_path / "dbt_project.yml").exists():
                return False, f"No dbt_project.yml found at {selected_path}"
            # Store the selected project root
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["dbt_project_root"] = str(selected_path)

        elif len(self.projects) == 1:
            selected_path = self.projects[0]
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["dbt_project_root"] = str(selected_path)

        elif len(self.projects) == 0:
            if not self.manual_input or not self.manual_input.value.strip():
                return False, "Please enter the path to your dbt project"

            manual_path = self.base_path / self.manual_input.value.strip()
            if not manual_path.exists():
                return False, f"Path does not exist: {manual_path}"
            if not (manual_path / "dbt_project.yml").exists():
                return False, f"No dbt_project.yml found at {manual_path}"

            selected_path = manual_path
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["dbt_project_root"] = str(manual_path)

        # If we need to run dbt setup (monorepo case)
        if self.needs_dbt_setup and selected_path:
            if self.dbt_setup_error:
                return False, self.dbt_setup_error

            if not self.dbt_setup_complete:
                if not self.dbt_setup_in_progress:
                    self.run_dbt_setup(selected_path)
                return False, ""  # Wait for setup to complete

        return True, ""

    @work(thread=True)
    def run_dbt_setup(self, project_path: Path) -> None:
        """Run dbt deps and docs generate for selected subproject."""
        if self.dbt_setup_in_progress or self.dbt_setup_complete:
            return

        self.dbt_setup_in_progress = True
        self.dbt_setup_error = None

        # Create UI helpers
        update_ui = create_ui_updater(self)
        show_spinner = create_spinner_toggle(self, "subproject-spinner")

        # Disable Next button
        if self.screen:
            self.app.call_from_thread(
                lambda: setattr(self.screen.query_one("#next-btn", Button), "disabled", True)
            )

        self.app.call_from_thread(show_spinner, True)

        try:
            # Run dbt deps only (docs generate needs profile which comes later)
            run_dbt_deps(
                project_path, self.app, update_ui,
                status_selector="#subproject-status",
                output_selector="#subproject-output"
            )

            self.dbt_setup_complete = True
            self.dbt_setup_in_progress = False

            self.app.call_from_thread(show_spinner, False)
            if self.screen:
                def enable_next():
                    btn = self.screen.query_one("#next-btn", Button)
                    btn.disabled = False
                    btn.focus()
                self.app.call_from_thread(enable_next)

        except Exception as e:
            # Strip ANSI codes from error (dbt output may contain them)
            self.dbt_setup_error = f"dbt setup failed: {strip_ansi_codes(str(e))}"
            self.dbt_setup_in_progress = False
            self.app.call_from_thread(show_spinner, False)
            self.app.call_from_thread(update_ui, "#subproject-status", f"❌ {self.dbt_setup_error}")
            if self.screen:
                self.app.call_from_thread(
                    lambda: setattr(self.screen.query_one("#next-btn", Button), "disabled", False)
                )

    def get_data(self) -> dict[str, Any]:
        """Get selected project data."""
        if self.skip_step:
            return {}

        # Project root already stored in wizard_data during validate
        return {}


class SnowflakeConnectionStep(WizardStep, AsyncStepMixin):
    """Step 3: Snowflake connection configuration with async validation."""

    def __init__(self):
        """Initialize Snowflake connection step."""
        super().__init__(
            title="Snowflake Connection",
            description="Configure your Snowflake connection details.",
            step_id="snowflake-connection",
        )
        self.init_async_state()  # Initialize AsyncStepMixin state
        self.account_input: Input
        self.user_input: Input
        self.role_input: Input
        self.warehouse_input: Input
        self.key_path_input: Input
        self.schema_input: Input
        self.profile_name_input: Input
        self.env_vars_input: Input
        self.db_list: list[str] = []
        self.required_profile_name: Optional[str] = None  # From dbt_project.yml

    def get_content(self) -> ComposeResult:
        """Get step content with 2-column layout for paired fields."""
        # Add environment loading button
        yield Button("Load from Environment", id="load-env-btn", variant="default")

        # Determine profile name from dbt_project.yml
        if self.screen and hasattr(self.screen, "wizard_data"):
            # Use dbt_project_root if available (for subprojects), otherwise dbt_path
            dbt_path = Path(self.screen.wizard_data.get(
                "dbt_project_root",
                self.screen.wizard_data.get("dbt_path", "")
            ))
            self.required_profile_name = get_dbt_profile_name(dbt_path)

        # Check if we need to generate profile
        if self.screen and hasattr(self.screen, "wizard_data"):
            if self.screen.wizard_data.get("needs_profile_generation"):
                if self.required_profile_name:
                    yield Label(
                        f"We'll generate profiles.yml with profile '{self.required_profile_name}' (from dbt_project.yml)",
                        classes="wizard-hint"
                    )
                else:
                    yield Label("We'll use these details to generate your profiles.yml", classes="wizard-hint")

        # Row 1: Account + User (2-column)
        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("Account (e.g., abc123.us-west-2):")
                self.account_input = Input(
                    placeholder="abc123.us-west-2",
                    id="snowflake-account-input",
                )
                yield self.account_input
            with Vertical(classes="form-field"):
                yield Label("User:")
                self.user_input = Input(placeholder="username", id="snowflake-user-input")
                yield self.user_input

        # Row 2: Role + Warehouse (2-column)
        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("Role:")
                self.role_input = Input(placeholder="ANALYST", value="ANALYST", id="snowflake-role-input")
                yield self.role_input
            with Vertical(classes="form-field"):
                yield Label("Warehouse:")
                self.warehouse_input = Input(placeholder="COMPUTE_WH", value="COMPUTE_WH", id="snowflake-warehouse-input")
                yield self.warehouse_input

        # Row 3: Private key path + dbt target environment (2-column)
        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("Private key path:")
                default_key = str(Path.home() / ".ssh" / "snowflake_rsa_key.p8")
                self.key_path_input = Input(
                    placeholder=default_key,
                    value=default_key,
                    id="snowflake-key-input",
                )
                yield self.key_path_input
            with Vertical(classes="form-field"):
                yield Label("dbt target environment:")
                self.dbt_target_input = Input(
                    placeholder="prod",
                    value="prod",
                    id="dbt-target-input",
                )
                yield self.dbt_target_input

        # Row 4: Profile name + Env vars (2-column)
        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("Profile name:")
                default_profile = self.required_profile_name or "dev"
                self.profile_name_input = Input(
                    placeholder=default_profile,
                    value=default_profile,
                    id="profile-name-input",
                    disabled=bool(self.required_profile_name),
                )
                yield self.profile_name_input
            with Vertical(classes="form-field"):
                yield Label("Env vars (key=val,...):")
                self.env_vars_input = Input(
                    placeholder="DBT_ENV=prod",
                    id="env-vars-input",
                )
                yield self.env_vars_input

        # Check if profile exists
        has_profile = False
        if self.screen and hasattr(self.screen, "wizard_data"):
            has_profile = not self.screen.wizard_data.get("needs_profile_generation", True)

        if has_profile:
            yield Static("Existing profiles.yml found - will not be overwritten", classes="wizard-hint")
        elif self.required_profile_name:
            yield Static(f"Profile name '{self.required_profile_name}' is required by dbt_project.yml", classes="wizard-hint")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "load-env-btn":
            self._load_from_env()

    def _load_from_env(self):
        """Load credentials from environment variables."""
        import os

        from lineage.utils.env import load_env_file

        # Ensure environment is loaded
        load_env_file()

        loaded_count = 0

        # Account
        account = os.getenv("SNOWFLAKE_ACCOUNT")
        if account:
            self.account_input.value = account
            loaded_count += 1

        # User
        user = os.getenv("SNOWFLAKE_USER")
        if user:
            self.user_input.value = user
            loaded_count += 1

        # Role
        role = os.getenv("SNOWFLAKE_ROLE")
        if role:
            self.role_input.value = role
            loaded_count += 1

        # Warehouse
        warehouse = os.getenv("SNOWFLAKE_WAREHOUSE")
        if warehouse:
            self.warehouse_input.value = warehouse
            loaded_count += 1

        # Key path
        key_path = os.getenv("SNOWFLAKE_PRIVATE_KEY_PATH")
        if key_path:
            self.key_path_input.value = key_path
            loaded_count += 1

        # dbt target (optional - check DBT_TARGET env var)
        dbt_target = os.getenv("DBT_TARGET")
        if dbt_target:
            self.dbt_target_input.value = dbt_target
            loaded_count += 1

        try:
            status = self.query_one("#step-status", Static)
            if loaded_count > 0:
                status.update(f"✅ Loaded {loaded_count} values from environment")
            else:
                status.update("⚠️  No SNOWFLAKE_* variables found in environment")
        except NoMatches:
            pass

    def _on_state_changed(self) -> None:
        """Update UI when state changes (called on main thread)."""
        try:
            status = self.query_one("#step-status", Static)
            if self.state == StepState.VALIDATING:
                status.update("⏳ Testing connection and listing databases...")
            elif self.state == StepState.VALID:
                status.update(f"✅ Connection successful! Found {len(self.db_list)} databases.")
            elif self.state == StepState.INVALID:
                status.update(f"❌ {self._error_message}")
        except NoMatches:
            pass

    @work(thread=True)
    def _validate_connection(self) -> None:
        """Background worker to test Snowflake connection."""
        self.set_state(StepState.VALIDATING)

        # Disable Next button while validating
        set_button_disabled("next-btn", True, self.app)

        # Read credentials (safe to read from worker thread)
        account = self.account_input.value.strip()
        user = self.user_input.value.strip()
        role = self.role_input.value.strip()
        warehouse = self.warehouse_input.value.strip()
        key_path = self.key_path_input.value.strip()

        try:
            self.db_list = list_snowflake_databases(
                account=account,
                user=user,
                role=role,
                warehouse=warehouse,
                private_key_path=key_path,
            )

            # Store db list in wizard data for next step
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.screen.wizard_data["available_databases"] = self.db_list

            self.set_state(StepState.VALID)

            # Re-enable and focus Next button
            set_button_disabled("next-btn", False, self.app)
            focus_button("next-btn", self.app)

        except Exception as e:
            # Escape error to prevent Rich markup parsing errors
            self.set_state(StepState.INVALID, f"Connection failed: {escape_markup(str(e))}")
            # Re-enable Next so user can retry after fixing
            set_button_disabled("next-btn", False, self.app)

    async def validate(self) -> tuple[bool, str]:
        """Validate inputs and test connection using state machine."""
        # First check required fields (synchronous validation)
        account = self.account_input.value.strip()
        user = self.user_input.value.strip()
        role = self.role_input.value.strip()
        warehouse = self.warehouse_input.value.strip()
        key_path = self.key_path_input.value.strip()

        if not all([account, user, role, warehouse, key_path]):
            return False, "All fields are required"

        if not Path(key_path).expanduser().exists():
            return False, f"Private key file not found: {key_path}"

        # State machine for async connection test
        if self.state == StepState.IDLE:
            # Start background validation
            self._validate_connection()
            return False, ""  # Signal "in progress" - no error message

        # Check async state
        return self.check_async_state()

    def get_data(self) -> dict[str, Any]:
        """Get connection data."""
        # Parse env vars from comma-separated key=value format
        env_vars = {}
        env_vars_str = self.env_vars_input.value.strip()
        if env_vars_str:
            for pair in env_vars_str.split(","):
                pair = pair.strip()
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    if key:  # Only add if key is non-empty
                        env_vars[key] = value

        # Use required profile name if set (from dbt_project.yml), otherwise user input
        profile_name = self.required_profile_name or self.profile_name_input.value.strip() or "dev"

        return {
            "snowflake_account": self.account_input.value.strip(),
            "snowflake_user": self.user_input.value.strip(),
            "snowflake_role": self.role_input.value.strip(),
            "snowflake_warehouse": self.warehouse_input.value.strip(),
            "snowflake_private_key_path": self.key_path_input.value.strip(),
            "dbt_target": self.dbt_target_input.value.strip() or "prod",
            "profile_name": profile_name,
            "project_env_vars": env_vars,
        }


class DatabaseSelectionStep(WizardStep):
    """Step 5: Database and schema selection."""

    MANUAL_SCHEMA_VALUE = "__MANUAL__"

    def __init__(self):
        """Initialize database selection step."""
        super().__init__(
            title="Select Database & Schema",
            description="Select your default database and schema.",
            step_id="database-selection",
        )
        self.default_db_select: Select
        self.schema_select: Select
        self.manual_schema_input: Input
        self.additional_db_select: SelectionList
        self.manual_db_input: Input
        self.skip_mode = False
        self.available_schemas: list[str] = []
        self.schemas_loaded = False

    def get_content(self) -> ComposeResult:
        """Get step content."""
        # If we have databases from previous step, show selection
        # Otherwise show manual input
        self.skip_mode = True
        if self.screen and hasattr(self.screen, "wizard_data"):
            available_dbs = self.screen.wizard_data.get("available_databases", [])
            if available_dbs:
                self.skip_mode = False

                yield Label("Default Database (Required):")
                self.default_db_select = Select(
                    options=[(db, db) for db in available_dbs],
                    prompt="Select a default database",
                    id="default-db-select",
                )
                yield self.default_db_select

                yield Label("Default Schema:")
                # Start with just manual entry option until schemas are loaded
                self.schema_select = Select(
                    options=[("Enter manually", self.MANUAL_SCHEMA_VALUE)],
                    prompt="Select database first...",
                    id="schema-select",
                    disabled=True,
                )
                yield self.schema_select

                yield Label("Or enter schema manually:")
                self.manual_schema_input = Input(
                    placeholder="PUBLIC",
                    value="PUBLIC",
                    id="manual-schema-input",
                )
                yield self.manual_schema_input

                yield Label("Additional Databases (Optional):")
                self.additional_db_select = SelectionList(
                    *[Selection(db, db) for db in available_dbs],
                    id="additional-db-select",
                )
                yield self.additional_db_select
                return

        # Fallback for manual entry or failed connection
        yield Label(
            "⚠️ Could not list databases from Snowflake. Entering manual mode.",
            classes="warning-label",
        )
        yield Label("")  # Spacer
        yield Label("Default Database:")
        self.manual_db_input = Input(
            placeholder="DATABASE_NAME",
            id="manual-db-input",
        )
        yield self.manual_db_input

        yield Label("Default Schema:")
        self.manual_schema_input = Input(
            placeholder="PUBLIC",
            value="PUBLIC",
            id="manual-schema-input",
        )
        yield self.manual_schema_input

        yield Static(
            "Could not fetch database list. Enter values manually.",
            classes="wizard-hint",
        )

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select changes - load schemas when database is selected."""
        if event.select.id == "default-db-select" and event.value:
            # Load schemas for the selected database
            self._load_schemas(str(event.value))
        elif event.select.id == "schema-select":
            # If user selected manual entry, focus the input
            if event.value == self.MANUAL_SCHEMA_VALUE:
                self.manual_schema_input.focus()

    @work(thread=True)
    def _load_schemas(self, database: str) -> None:
        """Load schemas for the selected database in background."""
        if not self.screen or not hasattr(self.screen, "wizard_data"):
            return

        data = self.screen.wizard_data

        def update_status(text: str) -> None:
            try:
                self.query_one("#step-status", Static).update(text)
            except NoMatches:
                pass

        self.app.call_from_thread(update_status, f"⏳ Loading schemas for {database}...")

        try:
            from lineage.utils.snowflake import list_snowflake_schemas

            schemas = list_snowflake_schemas(
                account=data.get("snowflake_account", ""),
                user=data.get("snowflake_user", ""),
                role=data.get("snowflake_role", ""),
                warehouse=data.get("snowflake_warehouse", ""),
                private_key_path=data.get("snowflake_private_key_path", ""),
                database=database,
            )

            self.available_schemas = schemas
            self.schemas_loaded = True

            # Update the schema select dropdown
            def update_schema_select() -> None:
                try:
                    options = [(s, s) for s in schemas]
                    options.append(("Enter manually", self.MANUAL_SCHEMA_VALUE))
                    self.schema_select.set_options(options)
                    self.schema_select.disabled = False
                    # Pre-select PUBLIC if available
                    if "PUBLIC" in schemas:
                        self.schema_select.value = "PUBLIC"
                except AttributeError:
                    # Widget may not be initialized in skip mode
                    pass

            self.app.call_from_thread(update_schema_select)
            self.app.call_from_thread(update_status, f"✅ Found {len(schemas)} schemas")

        except Exception as e:
            # Escape error to prevent Rich markup parsing errors
            self.app.call_from_thread(update_status, f"⚠️ Could not load schemas: {escape_markup(str(e))}")
            # Keep manual input as fallback

    async def validate(self) -> tuple[bool, str]:
        """Validate selection."""
        if self.skip_mode:
            if not self.manual_db_input.value.strip():
                return False, "Database name is required"
            if not self.manual_schema_input.value.strip():
                return False, "Schema name is required"
            return True, ""

        if not self.default_db_select.value:
            return False, "Please select a default database"

        # Check schema - either from dropdown or manual input
        schema_from_select = self.schema_select.value
        schema_from_input = self.manual_schema_input.value.strip()

        if schema_from_select == self.MANUAL_SCHEMA_VALUE or schema_from_select is None:
            if not schema_from_input:
                return False, "Please enter a schema name"

        return True, ""

    def get_data(self) -> dict[str, Any]:
        """Get database and schema selection data."""
        if self.skip_mode:
            db = self.manual_db_input.value.strip()
            schema = self.manual_schema_input.value.strip() or "PUBLIC"
            return {
                "snowflake_database": db,
                "snowflake_schema": schema,
                "allowed_databases": [db],
                "allowed_schemas": [],
            }

        default_db = self.default_db_select.value
        additional_dbs = self.additional_db_select.selected

        # Get schema - prefer dropdown selection, fall back to manual input
        schema_from_select = self.schema_select.value
        if schema_from_select and schema_from_select != self.MANUAL_SCHEMA_VALUE:
            schema = schema_from_select
        else:
            schema = self.manual_schema_input.value.strip() or "PUBLIC"

        # Combine and deduplicate databases
        all_dbs = sorted(list(set([default_db] + additional_dbs)))

        return {
            "snowflake_database": default_db,
            "snowflake_schema": schema,
            "allowed_databases": all_dbs,
            "allowed_schemas": [],
        }


class ProfilesYmlStep(WizardStep):
    """Step 6: Generate profiles.yml preview for dbt project."""

    def __init__(self):
        """Initialize profiles.yml generation step."""
        super().__init__(
            title="Generate profiles.yml",
            description="We'll create a profiles.yml file for your dbt project.",
            step_id="profiles-yml",
        )
        self.preview_content: str = ""
        self.skip_step: bool = False

    def _generate_profiles_yml(self, data: dict[str, Any]) -> str:
        """Generate profiles.yml content from wizard data."""
        import yaml

        profile_name = data.get("profile_name", "dev")
        dbt_target = data.get("dbt_target", "prod")  # Use user-specified target
        account = data.get("snowflake_account", "")
        user = data.get("snowflake_user", "")
        role = data.get("snowflake_role", "")
        warehouse = data.get("snowflake_warehouse", "")
        database = data.get("snowflake_database", "")
        schema = data.get("snowflake_schema", "PUBLIC")
        private_key_path = data.get("snowflake_private_key_path", "")

        profile_config = {
            profile_name: {
                "target": dbt_target,
                "outputs": {
                    dbt_target: {
                        "type": "snowflake",
                        "account": account,
                        "user": user,
                        "role": role,
                        "warehouse": warehouse,
                        "database": database,
                        "schema": schema,
                        "private_key_path": private_key_path,
                        "threads": 8,
                    }
                }
            }
        }

        return yaml.dump(profile_config, default_flow_style=False, sort_keys=False)

    def get_content(self) -> ComposeResult:
        """Get step content."""
        # Check if profiles.yml already exists
        if self.screen and hasattr(self.screen, "wizard_data"):
            needs_generation = self.screen.wizard_data.get("needs_profile_generation", True)
            if not needs_generation:
                self.skip_step = True
                yield Static(
                    "✅ Existing profiles.yml found - will not be overwritten",
                    classes="wizard-hint"
                )
                yield Static(
                    "Press Next to continue to validation checks.",
                    classes="wizard-hint"
                )
                return

            # Generate preview
            self.preview_content = self._generate_profiles_yml(self.screen.wizard_data)

        yield Label("Preview of profiles.yml that will be created:")
        yield Static(self.preview_content, id="profiles-preview", classes="code-preview")

        # Show where file will be written
        dbt_path = ""
        if self.screen and hasattr(self.screen, "wizard_data"):
            dbt_path = self.screen.wizard_data.get(
                "dbt_project_root",
                self.screen.wizard_data.get("dbt_path", "")
            )

        yield Static(
            f"File will be written to: {dbt_path}/profiles.yml",
            classes="wizard-hint"
        )
        yield Static(
            "This file will be created when you complete the wizard.",
            classes="wizard-hint"
        )

    async def validate(self) -> tuple[bool, str]:
        """Validate step."""
        if self.skip_step:
            return True, ""

        # Ensure we have generated content
        if not self.preview_content:
            if self.screen and hasattr(self.screen, "wizard_data"):
                self.preview_content = self._generate_profiles_yml(self.screen.wizard_data)

        return True, ""

    def get_data(self) -> dict[str, Any]:
        """Return the profiles.yml content to be written."""
        if self.skip_step:
            return {}
        return {"profiles_yml_content": self.preview_content}


class PreFlightCheckStep(WizardStep, AsyncStepMixin):
    """Step: Pre-flight checks including profiles.yml generation and dbt docs generate."""

    def __init__(self):
        """Initialize pre-flight check step."""
        super().__init__(
            title="Setup & Validation",
            description="Writing configuration files and validating your setup...",
            step_id="pre-flight",
        )
        self.init_async_state()
        self.dbt_error_output: str = ""  # Store dbt error output for display

    def get_content(self) -> ComposeResult:
        """Get step content."""
        yield Static("1. Writing profiles.yml...", id="check-profiles", classes="wizard-hint")
        yield Static("2. Validating Snowflake connection...", id="check-connection", classes="wizard-hint")
        yield Static("3. Checking database access...", id="check-access", classes="wizard-hint")
        yield Static("4. Running dbt docs generate...", id="check-dbt", classes="wizard-hint")
        yield Static("5. Verifying manifest.json...", id="check-manifest", classes="wizard-hint")
        # Error details area (initially empty)
        yield Static("", id="error-details", classes="wizard-hint")

    def on_mount(self) -> None:
        """Run checks when step is mounted."""
        if self.state == StepState.IDLE:
            self.run_checks()

    @work(thread=True)
    def run_checks(self) -> None:
        """Run all setup and validation in background thread."""
        if self.state != StepState.IDLE:
            return

        self.set_state(StepState.WORKING)
        set_button_disabled("next-btn", True, self.app)

        if not self.screen or not hasattr(self.screen, "wizard_data"):
            self.set_state(StepState.FAILED, "Missing wizard data")
            set_button_disabled("next-btn", False, self.app)
            return

        data = self.screen.wizard_data
        dbt_project_root = Path(data.get("dbt_project_root", data.get("dbt_path", "")))

        def update_ui(selector: str, text: str) -> None:
            try:
                self.query_one(selector, Static).update(text)
            except NoMatches:
                pass

        # === Step 1: Write profiles.yml if needed ===
        self.app.call_from_thread(update_ui, "#step-status", "⏳ Writing profiles.yml...")
        if data.get("needs_profile_generation") and data.get("profiles_yml_content"):
            profile_path = dbt_project_root / "profiles.yml"
            try:
                profile_path.write_text(data["profiles_yml_content"])
                try:
                    ensure_gitignore_contains(dbt_project_root, ["profiles.yml"])
                except Exception as e:
                    # Non-fatal: profiles.yml was written successfully; ignore file update is best-effort.
                    logger.warning("Failed to update .gitignore for profiles.yml: %s", e)
                self.app.call_from_thread(update_ui, "#check-profiles", "✅ profiles.yml written")
            except Exception as e:
                # Escape error to prevent Rich markup parsing errors
                escaped_error = escape_markup(str(e))
                self.app.call_from_thread(update_ui, "#check-profiles", f"❌ Failed to write profiles.yml: {escaped_error}")
                self.app.call_from_thread(update_ui, "#step-status", "❌ Failed to write profiles.yml")
                self.set_state(StepState.FAILED, escaped_error)
                set_button_disabled("next-btn", False, self.app)
                return
        else:
            self.app.call_from_thread(update_ui, "#check-profiles", "✅ profiles.yml already exists")

        # === Step 2: Validate Snowflake connection config ===
        self.app.call_from_thread(update_ui, "#step-status", "⏳ Validating Snowflake connection...")
        account = data.get("snowflake_account")
        user = data.get("snowflake_user")
        role = data.get("snowflake_role")
        warehouse = data.get("snowflake_warehouse")
        key_path = data.get("snowflake_private_key_path")
        database = data.get("snowflake_database")
        schema = data.get("snowflake_schema")

        if not all([account, user, role, warehouse, key_path, database]):
            self.app.call_from_thread(update_ui, "#check-connection", "❌ Missing configuration")
            self.app.call_from_thread(update_ui, "#step-status", "❌ Missing Snowflake configuration")
            self.set_state(StepState.FAILED, "Missing Snowflake configuration")
            set_button_disabled("next-btn", False, self.app)
            return

        self.app.call_from_thread(update_ui, "#check-connection", "✅ Connection configuration valid")

        # === Step 3: Check database access (test actual connection) ===
        self.app.call_from_thread(update_ui, "#step-status", "⏳ Checking database access...")
        success, msg, _table = validate_snowflake_read_access(
            account=account,
            user=user,
            role=role,
            warehouse=warehouse,
            private_key_path=key_path,
            database=database,
            schema=schema,
        )

        if success:
            self.app.call_from_thread(update_ui, "#check-access", f"✅ Database access confirmed ({escape_markup(msg)})")
        else:
            # Escape error to prevent Rich markup parsing errors
            escaped_msg = escape_markup(msg)
            self.app.call_from_thread(update_ui, "#check-access", f"❌ Database access failed: {escaped_msg}")
            self.app.call_from_thread(update_ui, "#step-status", "❌ Database access check failed")
            self.set_state(StepState.FAILED, f"Database access failed: {escaped_msg}")
            set_button_disabled("next-btn", False, self.app)
            return

        # === Step 4: Run dbt docs generate if manifest doesn't exist ===
        manifest_path = dbt_project_root / "target" / "manifest.json"
        if not manifest_path.exists():
            self.app.call_from_thread(update_ui, "#step-status", "⏳ Running dbt docs generate (this may take a minute)...")
            try:
                from lineage.utils.dbt import run_dbt_command

                run_dbt_command(
                    ["docs", "generate"],
                    dbt_project_root,
                    profiles_dir=dbt_project_root
                )
                self.app.call_from_thread(update_ui, "#check-dbt", "✅ dbt docs generate complete")
            except subprocess.CalledProcessError as e:
                # Capture error output for display - stderr has the actual error
                error_output = e.stderr or e.stdout or str(e)
                self.dbt_error_output = error_output
                # Strip ANSI codes and show truncated error (dbt output may have ANSI codes)
                error_preview = strip_ansi_codes(error_output.strip().replace("\n", " ")[:200])
                self.app.call_from_thread(update_ui, "#check-dbt", "❌ dbt docs generate failed")
                self.app.call_from_thread(update_ui, "#error-details", error_preview)
                self.app.call_from_thread(update_ui, "#step-status", f"❌ dbt failed: {error_preview[:100]}")
                self.set_state(StepState.FAILED, "dbt docs generate failed")
                set_button_disabled("next-btn", False, self.app)
                return
            except Exception as e:
                # Strip ANSI codes from error (dbt output may contain them)
                error_str = strip_ansi_codes(str(e))
                self.app.call_from_thread(update_ui, "#check-dbt", "❌ dbt docs generate failed")
                self.app.call_from_thread(update_ui, "#error-details", error_str[:200])
                self.app.call_from_thread(update_ui, "#step-status", f"❌ dbt failed: {error_str[:100]}")
                self.set_state(StepState.FAILED, error_str)
                set_button_disabled("next-btn", False, self.app)
                return
        else:
            self.app.call_from_thread(update_ui, "#check-dbt", "✅ manifest.json already exists")

        # === Step 5: Verify manifest.json exists (required for sync) ===
        if manifest_path.exists():
            self.app.call_from_thread(update_ui, "#check-manifest", "✅ manifest.json verified")
        else:
            self.app.call_from_thread(update_ui, "#check-manifest", "❌ manifest.json not found - sync will fail")
            self.app.call_from_thread(update_ui, "#step-status", "❌ Cannot continue without manifest.json")
            self.set_state(StepState.FAILED, "manifest.json not found after dbt docs generate")
            set_button_disabled("next-btn", False, self.app)
            return

        # All checks passed
        self.set_state(StepState.COMPLETED)
        self.app.call_from_thread(update_ui, "#step-status", "✅ All checks passed! Ready to complete setup.")
        set_button_disabled("next-btn", False, self.app)
        focus_button("next-btn", self.app)

    async def validate(self) -> tuple[bool, str]:
        """Validate using state machine."""
        return self.check_async_state()

    def get_data(self) -> dict[str, Any]:
        """Return setup status."""
        return {"setup_completed": self.state == StepState.COMPLETED}


class SummaryStep(WizardStep):
    """Final step: Summary of all configuration before completing setup."""

    def __init__(self):
        """Initialize summary step."""
        super().__init__(
            title="Setup Summary",
            description="Review your configuration before completing setup.",
            step_id="summary",
        )

    def get_content(self) -> ComposeResult:
        """Get step content with summary sections."""
        # Project Configuration
        yield Label("Project Configuration", classes="section-header")
        yield Static(id="summary-project")

        # dbt Project
        yield Label("dbt Project", classes="section-header")
        yield Static(id="summary-dbt")

        # Snowflake Connection
        yield Label("Snowflake Connection", classes="section-header")
        yield Static(id="summary-snowflake")

        # Files to Create
        yield Label("Files to Create", classes="section-header")
        yield Static(id="summary-files")

    def on_mount(self) -> None:
        """Populate summary from wizard data when mounted."""
        if not self.screen or not hasattr(self.screen, "wizard_data"):
            return

        data = self.screen.wizard_data

        # Project info
        project_name = data.get("project_name", "N/A")
        try:
            self.query_one("#summary-project", Static).update(
                f"  Name: {project_name}"
            )
        except NoMatches:
            pass

        # dbt info
        dbt_path = data.get("dbt_project_root", data.get("dbt_path", "N/A"))
        profile_name = data.get("profile_name", "N/A")
        is_git_clone = data.get("is_git_clone", False)
        source_type = "Git clone" if is_git_clone else "Local path"
        try:
            self.query_one("#summary-dbt", Static).update(
                f"  Path: {dbt_path}\n"
                f"  Profile: {profile_name}\n"
                f"  Source: {source_type}"
            )
        except NoMatches:
            pass

        # Snowflake info
        account = data.get("snowflake_account", "N/A")
        user = data.get("snowflake_user", "N/A")
        role = data.get("snowflake_role", "N/A")
        warehouse = data.get("snowflake_warehouse", "N/A")
        database = data.get("snowflake_database", "N/A")
        try:
            self.query_one("#summary-snowflake", Static).update(
                f"  Account: {account}\n"
                f"  User: {user}\n"
                f"  Role: {role}\n"
                f"  Warehouse: {warehouse}\n"
                f"  Database: {database}"
            )
        except NoMatches:
            pass

        # Files that will be created
        files = []
        needs_profile = data.get("needs_profile_generation", True)
        if needs_profile:
            files.append(f"  - {dbt_path}/profiles.yml")
        files.append(f"  - ~/.typedef/projects/{project_name}/config.yml")
        try:
            self.query_one("#summary-files", Static).update("\n".join(files))
        except NoMatches:
            pass

    async def validate(self) -> tuple[bool, str]:
        """Summary step is always valid - just for review."""
        return True, ""

    def get_data(self) -> dict[str, Any]:
        """No additional data to return."""
        return {}


def create_init_wizard() -> WizardScreen:
    """Create the init wizard screen."""
    steps = [
        ProjectNameStep(),          # Step 1: Project name
        DbtPathStep(),              # Step 2: dbt project path or git URL
        DbtSubProjectStep(),        # Step 3: Select sub-project (if monorepo)
        SnowflakeConnectionStep(),  # Step 4: Snowflake credentials
        DatabaseSelectionStep(),    # Step 5: Select databases
        ProfilesYmlStep(),          # Step 6: Preview profiles.yml (no write yet)
        PreFlightCheckStep(),       # Step 7: Setup & validation (profiles.yml + dbt docs + checks)
        SummaryStep(),              # Step 8: Final summary before completion
    ]

    return WizardScreen(
        steps=steps,
        title="typedef Setup Wizard",
    )


def create_add_project_wizard() -> WizardScreen:
    """Create the add project wizard screen.

    This is the same as the init wizard but for adding additional projects.
    Each project can have its own Snowflake database/schema configuration.
    """
    steps = [
        ProjectNameStep(),          # Step 1: Project name
        DbtPathStep(),              # Step 2: dbt project path or git URL
        DbtSubProjectStep(),        # Step 3: Select sub-project (if monorepo)
        SnowflakeConnectionStep(),  # Step 4: Snowflake credentials
        DatabaseSelectionStep(),    # Step 5: Select databases
        ProfilesYmlStep(),          # Step 6: Preview profiles.yml (no write yet)
        PreFlightCheckStep(),       # Step 7: Setup & validation (profiles.yml + dbt docs + checks)
        SummaryStep(),              # Step 8: Final summary before completion
    ]

    return WizardScreen(
        steps=steps,
        title="Add New Project",
    )


class InitWizardApp(BaseWizardApp):
    """Full-screen init wizard application."""

    def __init__(self):
        """Initialize the init wizard app."""
        wizard_screen = create_init_wizard()
        super().__init__(wizard_screen)
