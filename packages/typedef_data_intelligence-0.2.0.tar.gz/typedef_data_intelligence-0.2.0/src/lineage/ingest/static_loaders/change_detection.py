"""Change detection for incremental lineage loading.

Compares per-model fingerprints (derived from compiled SQL) against graph state to
identify added, modified, removed, and unchanged models.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable, Optional

from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import (
    compute_model_fingerprint_result,
)

# Type alias for dialect resolver function: maps model unique_id -> sqlglot dialect
DialectResolver = Callable[[str], Optional[str]]

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage
    from lineage.ingest.static_loaders.dbt.dbt_loader import DbtArtifacts

logger = logging.getLogger(__name__)


def _is_empty_graph_error(error: Exception) -> bool:
    """Check if error indicates an empty/non-existent graph."""
    error_str = str(error).lower()
    return any(msg in error_str for msg in ["does not exist", "not found", "no such"])


@dataclass
class ModelChangeSet:
    """Results of comparing current vs. cached fingerprints."""

    added: list[str]  # New model unique_ids
    modified: list[str]  # Changed model unique_ids
    removed: list[str]  # Deleted model unique_ids
    unchanged: list[str]  # Same checksum

    @property
    def has_changes(self) -> bool:
        """Check if any changes were detected."""
        return bool(self.added or self.modified or self.removed)

    @property
    def models_to_process(self) -> list[str]:
        """Models needing re-analysis (added + modified)."""
        return self.added + self.modified


class ChangeDetector:
    """Detects changes in dbt models by comparing fingerprints."""

    def detect_changes(
        self,
        artifacts: DbtArtifacts,
        storage: LineageStorage,
        dialect_resolver: Optional[DialectResolver] = None,
    ) -> ModelChangeSet:
        """Detect changes by comparing manifest-derived fingerprints against graph state.

        Args:
            artifacts: DbtArtifacts from current manifest
            storage: LineageStorage to query for existing fingerprints
            dialect_resolver: Optional function mapping model unique_id -> sqlglot dialect
                to use for fingerprinting. If omitted, falls back to artifacts.adapter_type.

        Returns:
            ModelChangeSet with added, modified, removed, and unchanged models
        """
        # 1. Load current fingerprints and model IDs from graph (single query)
        current_fingerprints, existing_model_ids = self._load_graph_state(storage)

        # 2. Build manifest fingerprints dict (full scan over artifacts)
        manifest_fingerprints: dict[str, str] = {}
        manifest_model_ids: set[str] = set()
        for model in artifacts.iter_models():
            manifest_model_ids.add(model.unique_id)

            try:
                # Determine dialect for fingerprinting
                dialect = (
                    dialect_resolver(model.unique_id)
                    if dialect_resolver
                    else artifacts.adapter_type
                )
                # Compute fingerprint using shared helper (stores hash only, no prefix)
                checksum_value = model.checksum.checksum if model.checksum else None
                fp_result = compute_model_fingerprint_result(
                    resource_type=model.resource_type,
                    compiled_sql=model.compiled_sql,
                    checksum=checksum_value,
                    dialect=dialect,
                    model_id=model.unique_id,
                )
                if fp_result:
                    manifest_fingerprints[model.unique_id] = fp_result.hash
                else:
                    # No fingerprint possible - treat conservatively
                    logger.warning(
                        f"Could not compute fingerprint for {model.unique_id}, "
                        f"treating as modified for safety"
                    )
            except Exception as e:
                # Log error but continue processing other models
                logger.error(
                    f"Error computing fingerprint for {model.unique_id}: {e}",
                    exc_info=True,
                )
                # Treat as modified to ensure it gets processed
                # (safer than treating as unchanged)
            # Models without fingerprints are treated conservatively:
            # - If not in graph: treated as added
            # - If in graph: treated as modified
            # This ensures correctness for seeds, analyses, or models that failed compilation.

        # 3. Compare and categorize
        added: list[str] = []
        modified: list[str] = []
        removed: list[str] = []
        unchanged: list[str] = []

        # Added / modified / unchanged based on fingerprint equality.
        #
        # Note: if a model doesn't have compiled_sql (or fingerprinting failed),
        # we treat it as modified (if it exists) to keep correctness.
        for model_id in manifest_model_ids:
            if model_id not in existing_model_ids:
                added.append(model_id)
                continue

            manifest_fp = manifest_fingerprints.get(model_id)
            if not manifest_fp:
                modified.append(model_id)
                continue

            current_fp = current_fingerprints.get(model_id)
            if current_fp != manifest_fp:
                modified.append(model_id)
            else:
                unchanged.append(model_id)

        # Removed models (in graph but not in manifest)
        for model_id in existing_model_ids:
            if model_id not in manifest_model_ids:
                removed.append(model_id)

        logger.info(
            f"Change detection: {len(added)} added, {len(modified)} modified, "
            f"{len(removed)} removed, {len(unchanged)} unchanged"
        )

        return ModelChangeSet(
            added=added,
            modified=modified,
            removed=removed,
            unchanged=unchanged,
        )

    def _load_graph_state(
        self, storage: LineageStorage
    ) -> tuple[dict[str, str], set[str]]:
        """Load fingerprints and model IDs from graph in a single query.

        This combines what was previously two separate queries to reduce
        database round-trips.

        Args:
            storage: LineageStorage to query

        Returns:
            Tuple of (fingerprints dict, model_ids set):
            - fingerprints: Dictionary mapping model_id -> model_fingerprint
              (only includes models that have a fingerprint)
            - model_ids: Set of all model unique_ids in the graph
              (includes models without fingerprints)
        """
        query = """
            MATCH (m:DbtModel)
            RETURN m.id AS id, m.model_fingerprint AS model_fingerprint
        """

        try:
            result = storage.execute_raw_query(query)
            fingerprints: dict[str, str] = {}
            model_ids: set[str] = set()

            for row in result.rows:
                model_id = row.get("id")
                if model_id:
                    model_ids.add(model_id)
                    fingerprint = row.get("model_fingerprint")
                    if fingerprint:
                        fingerprints[model_id] = fingerprint

            logger.debug(
                f"Loaded {len(model_ids)} models ({len(fingerprints)} with fingerprints) from graph"
            )
            return fingerprints, model_ids

        except Exception as e:
            # Connection/infrastructure errors should fail fast
            if isinstance(e, (ConnectionError, TimeoutError, OSError)):
                logger.error(f"Database connection failed while loading graph state: {e}")
                raise

            # Schema/table doesn't exist -> empty graph is expected
            if _is_empty_graph_error(e):
                logger.debug(f"Graph appears empty (no DbtModel table): {e}")
                return {}, set()
            # Unexpected errors - log with traceback but treat as empty to allow recovery
            logger.warning(f"Failed to load graph state: {e}", exc_info=True)
            return {}, set()

