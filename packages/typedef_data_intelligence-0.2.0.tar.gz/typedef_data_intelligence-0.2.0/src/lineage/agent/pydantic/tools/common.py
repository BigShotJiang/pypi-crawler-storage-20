from pydantic import BaseModel, Field


class ToolError(BaseModel):
    """Error raised when a tool fails."""
    error_message: str = Field(description="The error message returned by the tool.")