"""dbt utility functions for project management."""
import logging
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def run_dbt_command(
    command: list[str],
    project_dir: Path,
    profiles_dir: Optional[Path] = None,
) -> tuple[str, str]:
    """Run a dbt command in the specified project directory.

    Args:
        command: dbt command arguments (e.g., ["deps"], ["docs", "generate"])
        project_dir: dbt project directory
        profiles_dir: Optional profiles directory override

    Returns:
        Tuple of (stdout, stderr)

    Raises:
        subprocess.CalledProcessError: If command fails
    """
    env = None
    if profiles_dir:
        env = {"DBT_PROFILES_DIR": str(profiles_dir)}

    cmd = ["dbt"] + command

    logger.info(f"Running dbt command: {' '.join(cmd)} in {project_dir}")

    # If we have env vars, merge with system env
    run_env = None
    if env:
        import os
        run_env = os.environ.copy()
        run_env.update(env)

    result = subprocess.run(
        cmd,
        cwd=project_dir,
        check=True,
        capture_output=True,
        text=True,
        env=run_env
    )

    return result.stdout, result.stderr


