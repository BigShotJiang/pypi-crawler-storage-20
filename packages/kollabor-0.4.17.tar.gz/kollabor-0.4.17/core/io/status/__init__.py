"""Status area system with customizable widget layout.

This module provides a widget-based status area system where users can
configure which widgets to display and how to arrange them.

Components:
    - StatusWidgetRegistry: Central registry for status widgets
    - StatusWidget: Base class for widget implementations
    - StatusLayoutManager: Load/save layout configuration
    - LayoutRenderer: Render status area from layout config
    - Core widgets: cwd, profile, model, endpoint, status, stats, agent, skills, tasks
"""

from .widget_registry import (
    StatusWidgetRegistry,
    StatusWidget,
    WidgetWidth,
    WidthType,
    WidgetCategory,
)
from .core_widgets import register_core_widgets, WidgetContext
from .layout_manager import (
    StatusLayoutManager,
    StatusLayout,
    RowConfig,
    WidgetConfig,
)
from .layout_renderer import StatusLayoutRenderer
from .plugin_api import StatusWidgetAPI

__all__ = [
    # Widget Registry
    "StatusWidgetRegistry",
    "StatusWidget",
    "WidgetWidth",
    "WidthType",
    "WidgetCategory",
    # Layout Manager
    "StatusLayoutManager",
    "StatusLayout",
    "RowConfig",
    "WidgetConfig",
    # Layout Renderer
    "StatusLayoutRenderer",
    # Plugin API
    "StatusWidgetAPI",
    # Core Widgets
    "register_core_widgets",
    "WidgetContext",
]
