"""Tests for posts module."""
