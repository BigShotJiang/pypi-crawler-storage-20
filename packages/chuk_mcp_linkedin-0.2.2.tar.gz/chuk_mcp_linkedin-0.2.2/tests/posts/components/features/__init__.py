"""Tests for features components."""
