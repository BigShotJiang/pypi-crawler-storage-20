"""Tests for components module."""
