"""Tests for layout components."""
