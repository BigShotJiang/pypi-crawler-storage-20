import hipython

# Installation and testing:
# pip install -e .
# python test.py
if __name__ == "__main__":
    print(hipython.PYTHON_VERSION)
    hipython.echo()
    hipython.logo()
