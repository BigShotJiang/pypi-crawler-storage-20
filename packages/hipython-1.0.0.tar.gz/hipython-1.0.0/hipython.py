import sys

PYTHON_VERSION = f"v{sys.version_info.major}.{sys.version_info.minor}"

LOGO_PYTHON = rf"""  ____        _   _
 |  _ \ _   _| |_| |__   ___  _ __ 
 | |_) | | | | __| '_ \ / _ \| '_ \
 |  __/| |_| | |_| | | | (_) | | | |
 |_|    \__, |\__|_| |_|\___/|_| |_| {PYTHON_VERSION}
        |___/
"""


def logo():
    print(LOGO_PYTHON)


def echo():
    print("Hi Python")


# Public interface
__all__ = ['logo', 'echo', 'LOGO_PYTHON', 'PYTHON_VERSION']

# Version number, aligned with setup.py
__version__ = '1.0.0'
