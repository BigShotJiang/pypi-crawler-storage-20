# 🐍 HiPython

**HiPython** is a simple python sample project.

<br/>

## 🚀 Installation

**hipython Installation :**

```bash
# Requires Python 3.6+
pip install hipython
```

**hipython information :**

```bash
$ pip list | grep hipython
hipython          1.0.0        /Users/hollson/hipython

$ pip  show hipython
Name: hipython
Version: 1.0.0
Summary: This is a simple hi python project
Author: Hollson
Author-email: hollson@qq.com
License: MIT
```



<br/>

## 📚 Usage Examples

**Basic Usage :**

```python
import hipython

print(hipython.PYTHON_VERSION)
hipython.echo()
hipython.logo()
```

**Command Line Usage :**

After installation, you can use it directly in the terminal:

```bash
python -c "import hipython; hipython.echo()"
python -c "import hipython; hipython.logo()"
```

**Output :**

```bash
 Hi Python
  ____        _
 |  _ \ _   _| |_| |__   ___  _ __ 
 | |_) | | | | __| '_ \ / _ \| '_ \
 |  __/| |_| | |_| | | | (_) | | | |
 |_|    \__, |\__|_| |_|\___/|_| |_| (v3.12)
        |___/
```



<br/>

## 🛠️ Uninstall

```bash
pip uninstall hipython -y
```



<br/>

## 📜 License

This project is open sourced under the MIT License - see the [LICENSE](LICENSE) file for details.