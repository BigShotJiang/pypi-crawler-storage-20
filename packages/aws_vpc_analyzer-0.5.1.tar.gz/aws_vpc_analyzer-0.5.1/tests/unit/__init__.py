"""Unit tests for NetGraph."""
