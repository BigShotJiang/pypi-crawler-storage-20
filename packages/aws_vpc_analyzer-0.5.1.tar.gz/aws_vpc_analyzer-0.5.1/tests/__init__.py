"""NetGraph test suite."""
