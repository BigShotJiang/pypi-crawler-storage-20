
class PlanningException(Exception):
    pass
