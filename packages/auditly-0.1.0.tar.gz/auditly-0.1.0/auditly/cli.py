import argparse
from auditly.env_scanner import scan_environment
from auditly.file_scanner import scan_requirements
from auditly.subdep_scanner import scan_requirements_transitive
from auditly.reporter import print_report


def main():
    parser = argparse.ArgumentParser("auditly")

    parser.add_argument("-r", "--requirements")
    parser.add_argument("--transitive", action="store_true")
    parser.add_argument("--json", action="store_true")

    args = parser.parse_args()

    print("[auditly] Starting dependency security audit...")

    if args.requirements:
        if args.transitive:
            findings, total = scan_requirements_transitive(args.requirements)
        else:
            findings, total = scan_requirements(args.requirements)
    else:
        findings, total = scan_environment(transitive=args.transitive)

    print_report(findings, total, json_output=args.json)
