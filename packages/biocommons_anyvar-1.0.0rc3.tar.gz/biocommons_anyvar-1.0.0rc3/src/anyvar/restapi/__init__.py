"""Provide REST API service."""
