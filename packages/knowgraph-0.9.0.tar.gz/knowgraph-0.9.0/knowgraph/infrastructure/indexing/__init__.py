"""Indexing utilities for KnowGraph."""
