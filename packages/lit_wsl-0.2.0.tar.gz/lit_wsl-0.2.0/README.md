# lit-wsl

[![Build](https://github.com/twsl/lit-wsl/actions/workflows/build.yaml/badge.svg)](https://github.com/twsl/lit-wsl/actions/workflows/build.yaml)
[![Documentation](https://github.com/twsl/lit-wsl/actions/workflows/docs.yaml/badge.svg)](https://github.com/twsl/lit-wsl/actions/workflows/docs.yaml)
![GitHub Release](https://img.shields.io/github/v/release/twsl/lit-wsl?include_prereleases)
[![PyPI - Package Version](https://img.shields.io/pypi/v/lit-wsl?logo=pypi&style=flat&color=orange)](https://pypi.org/project/lit-wsl/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/lit-wsl?logo=pypi&style=flat&color=blue)](https://pypi.org/project/lit-wsl/)
[![Docs with MkDocs](https://img.shields.io/badge/MkDocs-docs?style=flat&logo=materialformkdocs&logoColor=white&color=%23526CFE)](https://squidfunk.github.io/mkdocs-material/)
[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)](https://python-poetry.org/)
[![linting: ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](.pre-commit-config.yaml)
[![Checked with pyright](https://microsoft.github.io/pyright/img/pyright_badge.svg)](https://microsoft.github.io/pyright/)
[![security: bandit](https://img.shields.io/badge/security-bandit-yellow.svg)](https://github.com/PyCQA/bandit)
[![Semantic Versions](https://img.shields.io/badge/%20%20%F0%9F%93%A6%F0%9F%9A%80-semantic--versions-e10079.svg)](https://github.com/twsl/lit-wsl/releases)
[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-border.json)](https://github.com/copier-org/copier)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)

My personal library of reusable Pytorch Lightning components

## Features

- [IntermediateLayerGetter](./src/lit_wsl/models/intermediate_layer_getter.py)
- [WeightRenamer](./src/lit_wsl/models/weight_renamer.py)
- [WeightMapper](./src/lit_wsl/models/weight_mapper.py)
- [ModelTester](./src/lit_wsl/testing/lightning_tester.py)

## Installation

With `pip`:

```bash
python -m pip install lit-wsl
```

With [`poetry`](https://python-poetry.org/):

```bash
poetry add lit-wsl
```

## How to use it

```python
import lit_wsl

...
```

## Docs

```bash
poetry run mkdocs build -f ./docs/mkdocs.yml -d ./_build/
```

## Update template

```bash
copier update --trust -A --vcs-ref=HEAD
```

## Credits

This project was generated with [![🚀 A generic python project template.](https://img.shields.io/badge/python--project--template-%F0%9F%9A%80-brightgreen)](https://github.com/twsl/python-project-template)
