# daredevil
Vib code (python) code without reading it.

Vibe coding is good at creating code. But I would prefer not to read all of it all the time. Daredevil is a syntax analysis tool to help you understand code without reading it. At the moment, it is a dumping gound for my work on this topic.

Liable to change. Features probably won't go away but might change. Contains AI generated code. 

Will probably start as a bunch of tools that I dump which begins to take shape

## My preferences
I hate GUIs but sometimes the are the best tools. I do not want to work out out to use tools like this each time.

# Features
Show a module import graph with line numbers and doc on mousehover.

```
daredevil modules
```

## Probably features
Call graphs through modules.
Constraings

