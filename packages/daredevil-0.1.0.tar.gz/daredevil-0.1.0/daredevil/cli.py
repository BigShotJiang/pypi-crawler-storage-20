#!/usr/bin/env python3
"""
daredevil - Create and understand code without reading it.

Usage:
    daredevil modules [path] [-o output.html]
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(
        description='Create and understand code without reading it'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # modules command
    modules_parser = subparsers.add_parser(
        'modules',
        help='Visualize module imports with docstring hover'
    )
    modules_parser.add_argument('package', nargs='?', default='.',
                                help='Path to Python package (default: current directory)')
    modules_parser.add_argument('-o', '--output', default='~/.cache/daredevil/module_graph.html',
                                help='Output HTML file')
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        sys.exit(1)
    
    if args.command == 'modules':
        from daredevil.modules import build_module_graph
        import subprocess
        import os
        output = build_module_graph(args.package, args.output)
        browser = os.environ.get('BROWSER', 'chromium')
        subprocess.Popen([browser, output], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == '__main__':
    main()