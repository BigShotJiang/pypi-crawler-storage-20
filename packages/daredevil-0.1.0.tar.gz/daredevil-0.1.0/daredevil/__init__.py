"""
daredevil - Create and understand code without reading it.
"""

from .modules import build_module_graph

__all__ = ['build_module_graph']