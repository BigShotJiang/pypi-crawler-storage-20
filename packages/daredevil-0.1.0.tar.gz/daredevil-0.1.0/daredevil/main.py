#!/usr/bin/env python3
"""
Main entry point for daredevil.

Usage:
    python -m daredevil
    daredevil
"""

from daredevil.cli import main

if __name__ == '__main__':
    main()