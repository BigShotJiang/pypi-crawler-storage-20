from typing import Callable
from .context import run_stack
import time

class ToolPassthrough:
    def __init__(self, tool_name: str, func: Callable):
        self.tool_name = tool_name
        self.__func = func
    
    def run(self, *args, **kwargs):
        start = time.time()
        out = self.__func(*args, **kwargs)
        latency = time.time() - start

        run_stack = run_stack.get()
        if run_stack:
            curr_ctx = run_stack[-1]
            curr_ctx.log_tool(
                tool_name=self.tool_name,
                latency_sec=latency,
                raw_output=out,
                tool_type="tool",
                metadata={"args": args, "kwargs": kwargs}  # keep small/safe
            )
        
        return out
