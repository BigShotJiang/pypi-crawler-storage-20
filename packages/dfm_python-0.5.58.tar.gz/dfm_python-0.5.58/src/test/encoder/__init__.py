"""Tests for encoder package."""

