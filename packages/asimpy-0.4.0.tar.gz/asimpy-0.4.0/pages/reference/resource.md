::: asimpy.resource
