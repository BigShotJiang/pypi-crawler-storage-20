# Medsos Downloader 🎥

Download video dan audio dari platform media sosial populer melalui command line interface (CLI).

## Fitur

- 🎬 **TikTok** - Download tanpa watermark
- 📸 **Instagram** - Unduh video dan foto dari reel
- 🔵 **Facebook** - Download dalam kualitas HD/SD
- ▶️ **YouTube** - Unduh sebagai MP4 atau MP3

## Instalasi

```bash
pip install medsos-downloader
```

## Penggunaan

### Mode Interaktif
```bash
medsosdl
```
Pilih platform dan masukkan URL untuk diunduh.

### Mode Langsung
```bash
medsosdl https://www.tiktok.com/@user/video/123
medsosdl https://www.instagram.com/reel/ABC123/
medsosdl https://www.facebook.com/watch?v=12345
medsosdl https://youtu.be/xyz789
```

## Persyaratan

- Python 3.8+
- Internet connection
- URL video dari akun publik

## Lisensi

MIT License - Lihat file [LICENSE](LICENSE) untuk detail

## Catatan Penting

⚠️ **Gunakan secara bertanggung jawab!**
- Hanya unduh konten yang Anda memiliki hak atas atau memiliki izin dari pembuat konten
- Patuhi Syarat Layanan setiap platform
- Jangan gunakan untuk distribusi komersial tanpa izin

## Contributing

Pull request dan issue report sangat diterima!

---

Made with ❤️ for content creators
