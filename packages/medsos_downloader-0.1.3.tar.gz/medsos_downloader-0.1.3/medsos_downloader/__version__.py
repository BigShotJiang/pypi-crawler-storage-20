"""Version information for medsos-downloader."""

__version__ = "0.1.3"
__author__ = "Itsnanzzz"
__email__ = "itsnanzzz.app@gmail.com"
