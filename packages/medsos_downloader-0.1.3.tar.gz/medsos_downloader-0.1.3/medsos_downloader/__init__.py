"""Medsos Downloader - Download videos and audio from social media platforms"""

__version__ = "0.1.0"
