# medsos_downloader/utils.py

def validate_url(url: str, platform: str) -> bool:
    url = url.lower()
    if platform == "tiktok":
        return "tiktok.com" in url
    elif platform == "instagram":
        return "instagram.com" in url
    elif platform == "facebook":
        return "facebook.com" in url or "fb.watch" in url
    elif platform.startswith("youtube"):
        return "youtube.com" in url or "youtu.be" in url
    return False

def sanitize_filename(name: str) -> str:
    """Remove invalid characters from filename"""
    import re
    clean = re.sub(r'[\\/*?:"<>|]', "", name).strip()
    return clean[:100] or "download"