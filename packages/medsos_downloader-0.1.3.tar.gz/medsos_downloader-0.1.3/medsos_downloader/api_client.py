# medsos_downloader/api_client.py

import requests

BASE_URL = "https://magma-api.biz.id/download"

def fetch_tiktok(url: str) -> dict:
    response = requests.get(f"{BASE_URL}/tiktok", params={"url": url}, timeout=15)
    response.raise_for_status()
    return response.json()

def fetch_facebook(url: str) -> dict:
    response = requests.get(f"{BASE_URL}/facebook", params={"url": url}, timeout=15)
    response.raise_for_status()
    return response.json()

def fetch_instagram(url: str) -> dict:
    response = requests.get(f"{BASE_URL}/instagram", params={"url": url}, timeout=15)
    response.raise_for_status()
    return response.json()

def fetch_youtube_mp4(url: str) -> dict:
    response = requests.get(f"{BASE_URL}/ytmp4", params={"url": url}, timeout=15)
    response.raise_for_status()
    return response.json()

def fetch_youtube_mp3(url: str) -> dict:
    response = requests.get(f"{BASE_URL}/ytmp3", params={"url": url}, timeout=15)
    response.raise_for_status()
    return response.json()