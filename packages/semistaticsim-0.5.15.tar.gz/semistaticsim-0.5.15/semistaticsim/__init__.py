"""SemiStaticSim package."""
