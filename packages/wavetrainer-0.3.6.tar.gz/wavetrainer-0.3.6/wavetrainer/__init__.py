"""The wavetrain main module."""

from .create import create

__VERSION__ = "0.3.6"
__all__ = ("create",)
