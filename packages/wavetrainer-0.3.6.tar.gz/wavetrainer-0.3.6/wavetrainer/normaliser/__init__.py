"""The wavetrain normaliser module."""
