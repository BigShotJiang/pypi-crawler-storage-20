"""Agent project template."""
