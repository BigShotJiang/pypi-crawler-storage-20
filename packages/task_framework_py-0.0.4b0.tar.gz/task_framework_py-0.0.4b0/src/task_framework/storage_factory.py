"""Storage Factory for creating storage instances based on configuration.

Provides a unified way to create storage instances, enabling easy switching
between different backends (file-based, Elasticsearch, etc.) via configuration.
"""

from typing import Any

from task_framework.interfaces.database import Database
from task_framework.interfaces.deployment_tracker_store import DeploymentTrackerStore
from task_framework.interfaces.idempotency import IdempotencyStore
from task_framework.interfaces.storage import FileStorage
from task_framework.interfaces.task_registry_store import TaskRegistryStore
from task_framework.repositories.webhook_db import WebhookRepository


class StorageFactory:
    """Factory for creating storage instances based on configuration.
    
    Attributes:
        storage_type: Type of storage backend ('file' or 'elasticsearch')
        config: Configuration dictionary for the storage backend
        
    Example:
        factory = StorageFactory(storage_type="file", base_path="./data")
        database = factory.create_database()
        task_registry = factory.create_task_registry_store()
    """
    
    # Supported storage types
    STORAGE_TYPE_FILE = "file"
    STORAGE_TYPE_ELASTICSEARCH = "elasticsearch"
    
    def __init__(
        self,
        storage_type: str = "file",
        **config: Any,
    ) -> None:
        """Initialize StorageFactory.
        
        Args:
            storage_type: Type of storage backend ('file' or 'elasticsearch')
            **config: Configuration options for the storage backend
                For 'file':
                    - base_path: str - Base directory for file storage
                For 'elasticsearch':
                    - hosts: List[str] - Elasticsearch hosts
                    - index_prefix: str - Prefix for index names
                    - username: str - Optional username
                    - password: str - Optional password
        """
        self.storage_type = storage_type
        self.config = config
    
    def create_database(self) -> Database:
        """Create a Database instance.
        
        Returns:
            Database implementation based on storage_type
            
        Raises:
            ValueError: If storage_type is not supported
        """
        if self.storage_type == self.STORAGE_TYPE_FILE:
            from task_framework.repositories.file_db import FileDatabase
            return FileDatabase(base_path=self.config.get("base_path", "data"))
        
        elif self.storage_type == self.STORAGE_TYPE_ELASTICSEARCH:
            # Future: ElasticsearchDatabase
            raise NotImplementedError(
                "Elasticsearch database not yet implemented. "
                "Use 'file' storage type for now."
            )
        
        raise ValueError(f"Unsupported storage type: {self.storage_type}")
    
    def create_task_registry_store(self) -> TaskRegistryStore:
        """Create a TaskRegistryStore instance.
        
        Returns:
            TaskRegistryStore implementation based on storage_type
            
        Raises:
            ValueError: If storage_type is not supported
        """
        if self.storage_type == self.STORAGE_TYPE_FILE:
            from task_framework.repositories.file_task_registry_store import (
                FileTaskRegistryStore,
            )
            return FileTaskRegistryStore(
                data_dir=self.config.get("base_path", "data")
            )
        
        elif self.storage_type == self.STORAGE_TYPE_ELASTICSEARCH:
            raise NotImplementedError(
                "Elasticsearch task registry store not yet implemented."
            )
        
        raise ValueError(f"Unsupported storage type: {self.storage_type}")
    
    def create_deployment_tracker_store(self) -> DeploymentTrackerStore:
        """Create a DeploymentTrackerStore instance.
        
        Returns:
            DeploymentTrackerStore implementation based on storage_type
            
        Raises:
            ValueError: If storage_type is not supported
        """
        if self.storage_type == self.STORAGE_TYPE_FILE:
            from task_framework.repositories.task_deployment_tracker import (
                TaskDeploymentTracker,
            )
            return TaskDeploymentTracker(
                base_path=self.config.get("base_path", "data")
            )
        
        elif self.storage_type == self.STORAGE_TYPE_ELASTICSEARCH:
            raise NotImplementedError(
                "Elasticsearch deployment tracker store not yet implemented."
            )
        
        raise ValueError(f"Unsupported storage type: {self.storage_type}")
    
    def create_file_storage(self) -> FileStorage:
        """Create a FileStorage instance.
        
        Returns:
            FileStorage implementation based on storage_type
            
        Raises:
            ValueError: If storage_type is not supported
        """
        if self.storage_type == self.STORAGE_TYPE_FILE:
            from task_framework.repositories.file_storage import LocalFileStorage
            return LocalFileStorage(
                base_path=self.config.get("base_path", "data")
            )
        
        elif self.storage_type == self.STORAGE_TYPE_ELASTICSEARCH:
            # For ES, we might still use local file storage for binary files
            # or integrate with S3/GCS
            raise NotImplementedError(
                "Elasticsearch file storage not yet implemented."
            )
        
        raise ValueError(f"Unsupported storage type: {self.storage_type}")
    
    def create_idempotency_store(self) -> IdempotencyStore:
        """Create an IdempotencyStore instance.
        
        Returns:
            IdempotencyStore implementation based on storage_type
            
        Raises:
            ValueError: If storage_type is not supported
        """
        if self.storage_type == self.STORAGE_TYPE_FILE:
            from task_framework.repositories.file_idempotency import (
                FileIdempotencyStore,
            )
            return FileIdempotencyStore(
                base_path=self.config.get("base_path", "data")
            )
        
        elif self.storage_type == self.STORAGE_TYPE_ELASTICSEARCH:
            raise NotImplementedError(
                "Elasticsearch idempotency store not yet implemented."
            )
        
        raise ValueError(f"Unsupported storage type: {self.storage_type}")
    
    def create_webhook_repository(self) -> WebhookRepository:
        """Create a WebhookRepository instance.
        
        Returns:
            WebhookRepository implementation based on storage_type
            
        Raises:
            ValueError: If storage_type is not supported
        """
        if self.storage_type == self.STORAGE_TYPE_FILE:
            from task_framework.repositories.webhook_db import (
                FileWebhookRepository,
            )
            return FileWebhookRepository(
                base_path=self.config.get("base_path", "data")
            )
        
        elif self.storage_type == self.STORAGE_TYPE_ELASTICSEARCH:
            raise NotImplementedError(
                "Elasticsearch webhook repository not yet implemented."
            )
        
        raise ValueError(f"Unsupported storage type: {self.storage_type}")
    
    @classmethod
    def from_env(cls) -> "StorageFactory":
        """Create a StorageFactory from environment variables.
        
        Environment variables:
            STORAGE_TYPE: 'file' (default) or 'elasticsearch'
            DATA_DIR: Base path for file storage (default: 'data')
            ELASTICSEARCH_HOSTS: Comma-separated list of ES hosts
            ELASTICSEARCH_INDEX_PREFIX: Index prefix (default: 'task-framework')
            ELASTICSEARCH_USERNAME: Optional username
            ELASTICSEARCH_PASSWORD: Optional password
            
        Returns:
            Configured StorageFactory instance
        """
        import os
        
        storage_type = os.environ.get("STORAGE_TYPE", cls.STORAGE_TYPE_FILE)
        
        if storage_type == cls.STORAGE_TYPE_FILE:
            return cls(
                storage_type=storage_type,
                base_path=os.environ.get("DATA_DIR", "data"),
            )
        
        elif storage_type == cls.STORAGE_TYPE_ELASTICSEARCH:
            hosts_str = os.environ.get("ELASTICSEARCH_HOSTS", "http://localhost:9200")
            hosts = [h.strip() for h in hosts_str.split(",")]
            
            return cls(
                storage_type=storage_type,
                hosts=hosts,
                index_prefix=os.environ.get("ELASTICSEARCH_INDEX_PREFIX", "task-framework"),
                username=os.environ.get("ELASTICSEARCH_USERNAME"),
                password=os.environ.get("ELASTICSEARCH_PASSWORD"),
            )
        
        raise ValueError(f"Unsupported STORAGE_TYPE: {storage_type}")
