"""Task Framework version information."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("task-framework")
except PackageNotFoundError:
    # Package not installed (e.g., running from source)
    __version__ = "dev"

# Export version string
VERSION = __version__


def get_version_info() -> dict:
    """Get version information dictionary.
    
    Returns:
        Dictionary with version details
    """
    return {
        "version": __version__,
        "name": "task-framework",
    }
