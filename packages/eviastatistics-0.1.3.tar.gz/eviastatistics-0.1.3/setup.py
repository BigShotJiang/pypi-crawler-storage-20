from setuptools import setup, find_packages
setup(
    name='eviastatistics',
    version='0.1.3',
    packages=['eviastatistics'],       
    install_requires=[
    ],
    author='Pedro Evia',
    author_email='evipedro9@gmail.com',
    description='A statistics library for various statistical calculations',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/pedro1411-max/eviastatistics.git',
)