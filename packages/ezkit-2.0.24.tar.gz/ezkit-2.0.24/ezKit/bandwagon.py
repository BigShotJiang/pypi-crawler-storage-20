from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

BASE_URL = "https://api.64clouds.com/v1"


@dataclass(slots=True)
class BandwagonConfig:
    veid: str
    api_key: str
    timeout: int = 10


class BandwagonClient:

    def __init__(self, config: BandwagonConfig, requests_parameters: dict | None = None) -> None:
        self.config = config
        self.requests_parameters = requests_parameters

    def _request(self, *, action: str) -> dict[str, Any]:
        url = f"{BASE_URL}/{action}"
        params = {
            "veid": self.config.veid,
            "api_key": self.config.api_key,
        }

        # HTTP 请求头
        user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

        requests_parameters: dict = {
            "headers": {"User-Agent": user_agent},
            # "proxies": {
            #     "http": "http://127.0.0.1:1080",
            #     "https": "http://127.0.0.1:1080",
            # },
        }
        if self.requests_parameters:
            requests_parameters.update(self.requests_parameters)

        resp = requests.get(url, params=params, timeout=self.config.timeout, **requests_parameters)
        resp.raise_for_status()
        data: dict = resp.json()

        if data.get("error"):
            raise RuntimeError(data.get("message"))

        return data

    # -------------------------
    # 核心接口
    # -------------------------

    def get_live_info(self) -> dict[str, Any]:
        """实时运行状态（CPU / 磁盘 / 内存 / 在线状态）"""
        return self._request(action="getLiveServiceInfo")

    def get_service_info(self) -> dict[str, Any]:
        """VPS 基本信息"""
        return self._request(action="getServiceInfo")


# --------------------------------
# 业务层封装
# --------------------------------


def format_disk(info: dict) -> str:

    # 硬盘大小 (单位GB)
    total = info["ve_disk_quota_gb"]

    # 使用量 (单位GB)
    used = info["ve_used_disk_space_b"] / (1024 * 1024 * 1024)

    # 使用率
    usage = (info["ve_used_disk_space_b"] / (int(info["ve_disk_quota_gb"]) * 1024 * 1024 * 1024)) * 100

    return f"{used:.2f}/{total} GB ({usage:.2f}%)"


def format_bandwidth(info: dict) -> str:

    # 带宽大小 (单位GB)
    total = info["plan_monthly_data"] / 1024 / 1024 / 1024

    # 使用量 (单位GB)
    used = info["data_counter"] / 1024 / 1024 / 1024

    # 使用率
    usage = (info["data_counter"] / info["plan_monthly_data"]) * 100

    return f"{used:.2f}/{total:.2f} GB ({usage:.2f}%)"
