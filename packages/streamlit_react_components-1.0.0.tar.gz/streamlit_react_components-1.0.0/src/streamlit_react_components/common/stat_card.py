"""StatCard component - A styled statistics display card."""

import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, Optional, Union

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def stat_card(
    label: str,
    value: Union[str, int, float],
    color: str = "blue",
    icon: str = "",
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    key: Optional[str] = None,
) -> None:
    """
    Display a styled statistics card with a label and value.

    Args:
        label: The description label (e.g., "Total Users")
        value: The statistic value to display
        color: Accent color - preset name ("blue", "green", "red", "yellow",
               "purple", "slate") or hex value (e.g., "#94a3b8")
        icon: Optional emoji or icon to display with the label
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        key: Unique key for the component

    Example:
        # Using preset color
        stat_card(
            label="Within Threshold",
            value="4",
            color="green",
            style={"minWidth": "150px"}
        )

        # Using hex color
        stat_card(
            label="Custom Color",
            value="42",
            color="#ff5733"
        )
    """
    _component(
        component="stat_card",
        label=label,
        value=str(value),
        color=color,
        icon=icon,
        style=style,
        className=class_name,
        key=key,
        default=None,
    )
