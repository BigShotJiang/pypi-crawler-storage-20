"""CheckboxGroup component - A group of checkboxes."""

import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def checkbox_group(
    items: List[Dict[str, Any]],
    label: str = "",
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    key: Optional[str] = None,
) -> List[str]:
    """
    Display a group of checkboxes.

    Args:
        items: List of checkbox items, each with:
               - id: Unique identifier
               - label: Display label
               - checked: Initial checked state (optional, default False)
        label: Optional group label
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        key: Unique key for the component

    Returns:
        List of checked item IDs

    Example:
        selected = checkbox_group(
            label="Parameters",
            items=[
                {"id": "vphp", "label": "VPHP Hold", "checked": True},
                {"id": "lot_co", "label": "Lot C/O", "checked": True},
                {"id": "batch", "label": "Batch Size"}
            ]
        )
        # Returns: ["vphp", "lot_co"] if those are checked
    """
    # Get default checked items
    default_checked = [item["id"] for item in items if item.get("checked", False)]

    result = _component(
        component="checkbox_group",
        label=label,
        items=items,
        style=style,
        className=class_name,
        key=key,
        default=default_checked,
    )
    return result if result is not None else default_checked
