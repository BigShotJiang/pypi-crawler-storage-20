"""
Auto-generated file. DO NOT EDIT.
"""
__version__ = "0.1.6"
__author__ = "Frank1o3"
