# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

Initial development.
