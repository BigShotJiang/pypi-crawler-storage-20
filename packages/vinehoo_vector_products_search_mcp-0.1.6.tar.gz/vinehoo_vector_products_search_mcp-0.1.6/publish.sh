#!/bin/bash

# 确保脚本在出错时退出
set -e

echo "🚀 开始发布流程..."

# 1. 检查 Conda 环境
if [ "$CONDA_DEFAULT_ENV" != "vector" ]; then
    echo "⚠️  当前不在 'vector' 环境下 (当前环境: ${CONDA_DEFAULT_ENV:-base})"
    
    # 尝试查找 conda 并在子 shell 或当前 shell 环境中激活
    # 注意：在脚本中直接用 'conda activate' 需要 shell 初始化支持
    if command -v conda &> /dev/null; then
        echo "🔄 尝试激活 'vector' 环境..."
        # 获取 conda 的初始化路径
        CONDA_PATH=$(conda info --base)
        source "$CONDA_PATH/etc/profile.d/conda.sh"
        if conda activate vector 2>/dev/null; then
            echo "✅ 已成功激活 'vector' 环境。"
        else
            echo "❌ 错误: 无法激活 'vector' 环境。请先运行 'conda activate vector' 后再执行此脚本。"
            exit 1
        fi
    else
        echo "❌ 错误: 未找到 conda 命令。项目要求在 'vector' 环境下运行。"
        exit 1
    fi
fi
if ! command -v twine &> /dev/null; then
    echo "❌ 错误: 未安装 'twine'。请运行 'pip install twine' 安装。"
    exit 1
fi

if ! python -m build --help &> /dev/null; then
    echo "❌ 错误: 未安装 'build' 模块。请运行 'pip install build' 安装。"
    exit 1
fi

# 2. 获取当前版本号
# 匹配 pyproject.toml 中的 version = "x.y.z"
CURRENT_VERSION=$(grep -m 1 "version =" pyproject.toml | cut -d '"' -f 2)

if [ -z "$CURRENT_VERSION" ]; then
    echo "❌ 错误: 无法在 pyproject.toml 中找到版本号。"
    exit 1
fi

# 3. 计算建议版本号 (递增最后一项)
IFS='.' read -r major minor patch <<< "$CURRENT_VERSION"
SUGGESTED_VERSION="$major.$minor.$((patch + 1))"

# 4. 用户交互确认版本号
echo "-------------------------------------------"
echo "当前版本: $CURRENT_VERSION"
read -p "请输入新版本号 [$SUGGESTED_VERSION]: " USER_VERSION

# 如果用户直接回车，则使用建议版本
NEW_VERSION=${USER_VERSION:-$SUGGESTED_VERSION}
echo "确认使用版本: $NEW_VERSION"
echo "-------------------------------------------"

# 5. 更新 pyproject.toml (适配 Mac 系统的 sed)
sed -i '' "s/version = \"$CURRENT_VERSION\"/version = \"$NEW_VERSION\"/" pyproject.toml
echo "✅ 已更新 pyproject.toml 中的版本号。"

# 6. 清理旧的构建产物
echo "🧹 清理旧的构建产物..."
rm -rf dist/ build/ *.egg-info

# 7. 打包构建
echo "📦 正在打包构建..."
python -m build

# 8. 上传至 PyPI
echo "📤 准备上传到 PyPI..."
echo "提示: 你需要准备好 PyPI 的 API Token。"
python -m twine upload dist/*

echo "✨ 发布成功！新版本 $NEW_VERSION 已上传至 PyPI。"
