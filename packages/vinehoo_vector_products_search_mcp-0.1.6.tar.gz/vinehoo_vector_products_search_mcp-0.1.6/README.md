# VikingDB Multi-modal Search MCP Server

这是一个使用 Python FastMCP 框架开发的 MCP Server，用于在火山引擎 VikingDB 向量数据库中进行多模态检索。

## 功能介绍

提供 `search_multi_modal` 工具，支持：
- 文本搜索
- 图片搜索 (TOS 或 HTTP 链接)
- 视频搜索 (TOS 或 HTTP 链接)
- 多模态组合搜索

## 安装依赖

```bash
pip install -r requirements.txt
```

## 配置

复制 `.env.example` 为 `.env` 并填入您的火山引擎凭证：

```bash
cp .env.example .env
```

并在 `.env` 中设置以下变量：
- `VOLC_AK`: 火山引擎 Access Key
- `VOLC_SK`: 火山引擎 Secret Key
- `VIKINGDB_HOST`: VikingDB 域名 (默认: api-vikingdb.vikingdb.cn-beijing.volces.com)
- `VIKINGDB_REGION`: 区域 (默认: cn-beijing)

## 运行

```bash
python server.py
```

## MCP 工具说明

### `search_multi_modal`

参数：
- `collection_name` (str): 集合名称
- `index_name` (str): 索引名称
- `text` (str, 可选): 检索文本
- `image` (str, 可选): 图片链接
- `video_url` (str, 可选): 视频链接
- `video_fps` (float, 可选): 视频采样频率
- `need_instruction` (bool): 是否启用 Instruction (默认为 True)
- `output_fields` (list, 可选): 返回字段列表
- `limit` (int): 返回结果数量 (默认 10)

## 发布到 PyPI

如果您希望将此项目发布到 PyPI，可以使用我们提供的自动化脚本：

1. **安装必要工具**（仅需一次）：
   ```bash
   pip install build twine
   ```

2. **运行发布脚本**：
   ```bash
   ./publish.sh
   ```

   该脚本会自动执行以下步骤：
   - 检查当前版本并**建议/手动确认**新版本。
   - 自动更新 `pyproject.toml`。
   - 清理旧的构建文件。
   - 构建新的分发包。
   - 调用 `twine` 上传至 PyPI。

   > **注意**：在上传时，您需要输入 PyPI 的 API Token。建议提前在 `~/.pypirc` 中配置好 Token 以实现完全自动化。

## 本地开发安装

可以使用开发模式安装，以便直接运行命令：

```bash
pip install -e .
vinehoo-search
```
