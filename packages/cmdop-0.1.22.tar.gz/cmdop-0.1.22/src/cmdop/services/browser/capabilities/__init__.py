"""Browser capabilities."""

from .scroll import ScrollCapability
from .input import InputCapability
from .timing import TimingCapability
from .dom import DOMCapability
from .fetch import FetchCapability

__all__ = [
    "ScrollCapability",
    "InputCapability",
    "TimingCapability",
    "DOMCapability",
    "FetchCapability",
]
