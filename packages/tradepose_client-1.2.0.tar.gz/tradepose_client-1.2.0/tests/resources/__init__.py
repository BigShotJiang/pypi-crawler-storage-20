"""Resource tests."""
