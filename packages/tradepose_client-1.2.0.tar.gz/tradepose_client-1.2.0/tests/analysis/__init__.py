"""Analysis module tests."""
