from .digital_net_b2 import DigitalNetB2
