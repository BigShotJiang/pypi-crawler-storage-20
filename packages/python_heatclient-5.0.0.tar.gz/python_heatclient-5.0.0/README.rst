=================
python-heatclient
=================

.. image:: https://governance.openstack.org/tc/badges/python-heatclient.svg

.. Change things from this point on

.. image:: https://img.shields.io/pypi/v/python-heatclient.svg
    :target: https://pypi.org/project/python-heatclient/
    :alt: Latest Version


OpenStack Orchestration API Client Library

This is a client library for Heat built on the Heat orchestration API. It
provides a Python API (the ``heatclient`` module) and a command-line tool
(``heat``).

* Free software: Apache license
* `PyPi`_ - package installation
* `Online Documentation`_
* `Launchpad project`_ - release management
* `Blueprints`_ - feature specifications
* `Bugs`_ - issue tracking
* `Source`_
* `Specs`_
* `Template`_
* `How to Contribute`_

.. _PyPi: https://pypi.org/project/python-heatclient
.. _Online Documentation: https://docs.openstack.org/python-heatclient/latest
.. _Launchpad project: https://launchpad.net/python-heatclient
.. _Blueprints: https://blueprints.launchpad.net/python-heatclient
.. _Bugs: https://storyboard.openstack.org/#!/project/openstack/python-heatclient
.. _Source: https://opendev.org/openstack/python-heatclient
.. _How to Contribute: https://docs.openstack.org/infra/manual/developers.html
.. _Specs: https://specs.openstack.org/openstack/heat-specs/
.. _Template: https://opendev.org/openstack/heat-templates/
