# LinkedIn MCP Server

[![PyPI version](https://badge.fury.io/py/linkedin-mcp-server.svg)](https://badge.fury.io/py/linkedin-mcp-server)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Empower your AI agents with professional networking capabilities.**

A Model Context Protocol (MCP) server that enables Large Language Models (LLMs) like Claude to interact with LinkedIn's professional network. Built with [FastMCP](https://github.com/jlowin/fastmcp) for high performance and reliability.

## Features

- 🔐 **Secure OAuth 2.0 Authentication** - Complete OAuth flow implementation
- 📝 **Content Management** - Create, update, and delete posts with text and images
- 💬 **Engagement Tools** - Comment on posts and manage interactions
- 👥 **Profile Access** - Retrieve your profile and member information
- 🏢 **Company Intelligence** - Search companies and access organization data
- 💼 **Job Search** - Find and explore job opportunities
- 🔍 **People Search** - Discover professionals across LinkedIn

## Installation

### Using uvx (Recommended)

The easiest way to use the LinkedIn MCP server is with `uvx`:

```bash
uvx linkedin-mcp-server
```

### Using pip

```bash
pip install linkedin-mcp-server
```

### From Source

```bash
git clone https://github.com/SARAMALI15792/LinkedIn_mcp_custom_server.git
cd LinkedIn_mcp_custom_server
pip install -e .
```

## Quick Start

### 1. Setup LinkedIn App Credentials

1. Visit [LinkedIn Developer Portal](https://www.linkedin.com/developers/apps)
2. Create a new app
3. Request access to:
   - "Sign In with LinkedIn using OpenID Connect"
   - "Share on LinkedIn"
4. Add redirect URL: `http://localhost:8000`
5. Note your `Client ID` and `Client Secret`

### 2. Configure Environment

Create a `.env` file in your working directory:

```ini
LINKEDIN_CLIENT_ID=your_client_id
LINKEDIN_CLIENT_SECRET=your_client_secret
LINKEDIN_REDIRECT_URI=http://localhost:8000
```

### 3. Configure Claude Desktop

Add to your Claude Desktop config file:

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
**Linux:** `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "linkedin": {
      "command": "uvx",
      "args": ["linkedin-mcp-server"]
    }
  }
}
```

**Alternative with pip installation:**

```json
{
  "mcpServers": {
    "linkedin": {
      "command": "linkedin-mcp-server"
    }
  }
}
```

### 4. Authenticate

1. In Claude Desktop, ask: **"Generate LinkedIn login URL"**
2. Open the provided URL in your browser
3. Authorize the application
4. Copy the `code` parameter from the redirect URL
5. In Claude: **"Exchange this code: [PASTE_CODE]"**

You're now connected!

## Usage Examples

Once authenticated, you can use natural language to interact with LinkedIn:

### Creating Content

```
"Create a LinkedIn post: 'Excited to share my new MCP server project! 🚀 #AI #LinkedIn'"

"Post this image with caption 'Team photo from the conference': C:/photos/team.jpg"
```

### Engagement

```
"Show me comments on my latest post"

"Comment on post urn:li:share:123456789: 'Great insights, thanks for sharing!'"
```

### Profile & Network

```
"What's my LinkedIn email address?"

"Search for Python developers in San Francisco"

"Get details for company urn:li:organization:1234567"
```

### Job Search

```
"Find remote Senior Python Developer positions"

"Search for Machine Learning jobs in New York"

"Get details for job urn:li:job:123456789"
```

## Available Tools

| Tool | Description |
|------|-------------|
| `linkedin_get_oauth_url` | Generate OAuth 2.0 authorization URL |
| `linkedin_exchange_code` | Exchange auth code for access token |
| `linkedin_get_my_profile` | Get authenticated user's profile |
| `linkedin_get_member_profile` | Get member profile by URN |
| `linkedin_create_post` | Create text post |
| `linkedin_create_image_post` | Create post with image |
| `linkedin_update_post` | Update existing post (recreates) |
| `linkedin_delete_post` | Delete post |
| `linkedin_get_recent_posts` | List recent posts (restricted) |
| `linkedin_create_comment` | Comment on content |
| `linkedin_get_post_comments` | Get comments on post |
| `linkedin_delete_comment` | Delete comment |
| `linkedin_get_company_profile` | Get company details |
| `linkedin_search_companies` | Search for companies |
| `linkedin_search_jobs` | Search job postings |
| `linkedin_get_job_details` | Get job details |
| `linkedin_search_people` | Search for people |

## Architecture

```
linkedin-mcp-server/
├── linkedin_mcp_server/
│   ├── __init__.py          # Package initialization
│   ├── __main__.py          # CLI entry point
│   ├── server.py            # Main MCP server with tool definitions
│   ├── config.py            # Configuration management
│   ├── utils.py             # Shared utilities
│   └── tools/               # Tool implementations
│       ├── auth.py          # OAuth 2.0 flow
│       ├── profile.py       # Profile operations
│       ├── post.py          # Post & comment operations
│       ├── company.py       # Company operations
│       ├── job.py           # Job search operations
│       └── search.py        # People search
├── pyproject.toml           # Package metadata
├── README.md                # This file
└── LICENSE                  # MIT License
```

## API Permissions & Limitations

### Granted Permissions
- ✅ `openid`, `profile`, `email` - Basic profile access
- ✅ `w_member_social` - Create posts and comments

### Restricted Permissions
Many LinkedIn API endpoints require additional permissions that are restricted:

- ⚠️ `r_member_social` - Read user's posts (often unavailable)
- ⚠️ People/Company search - May require Marketing API access
- ⚠️ Job search - May require Talent Solutions access

These limitations are imposed by LinkedIn, not this MCP server.

## Development

### Setup Development Environment

```bash
git clone https://github.com/SARAMALI15792/LinkedIn_mcp_custom_server.git
cd LinkedIn_mcp_custom_server
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest tests/
```

### Code Quality

```bash
# Format code
black linkedin_mcp_server/

# Lint
ruff check linkedin_mcp_server/

# Type check
mypy linkedin_mcp_server/
```

## Troubleshooting

### Authentication Issues

**Problem:** "Unauthorized (401)" errors
**Solution:** Your access token may have expired. Re-authenticate using the OAuth flow.

**Problem:** "Forbidden (403)" errors
**Solution:** Your app lacks required permissions. Check your LinkedIn app settings.

### Connection Issues

**Problem:** Server not starting
**Solution:**
1. Check `.env` file exists with correct credentials
2. Verify `LINKEDIN_CLIENT_ID` and `LINKEDIN_CLIENT_SECRET` are set
3. Check Claude Desktop config is correct

### Permission Errors

**Problem:** "r_member_social permission required"
**Solution:** This permission is restricted by LinkedIn. Most third-party apps cannot access these endpoints.

## Security Best Practices

- ✅ Never commit `.env` files with credentials
- ✅ Use environment variables for sensitive data
- ✅ Regularly rotate access tokens
- ✅ Only request minimum required permissions
- ✅ Use HTTPS for redirect URIs in production

## Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

- 🐛 **Report bugs:** [GitHub Issues](https://github.com/SARAMALI15792/LinkedIn_mcp_custom_server/issues)
- 📖 **Documentation:** [GitHub README](https://github.com/SARAMALI15792/LinkedIn_mcp_custom_server#readme)
- 💬 **Questions:** Open a [GitHub Discussion](https://github.com/SARAMALI15792/LinkedIn_mcp_custom_server/discussions)

## Credits

Built with:
- [FastMCP](https://github.com/jlowin/fastmcp) - Fast MCP server framework
- [Model Context Protocol](https://modelcontextprotocol.io/) - Protocol for LLM integrations
- [LinkedIn API](https://learn.microsoft.com/en-us/linkedin/) - LinkedIn's developer platform

## Author

**SARAM ALI**
Email: saramali15792@gmail.com
GitHub: [@SARAMALI15792](https://github.com/SARAMALI15792)

---

**Made with ❤️ for the AI and LinkedIn communities**
