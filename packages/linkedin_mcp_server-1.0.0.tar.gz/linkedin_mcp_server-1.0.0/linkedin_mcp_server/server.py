from fastmcp import FastMCP
from .config import settings
from .tools import auth, profile, post, company, search, job

# Initialize MCP Server
mcp = FastMCP("linkedin_custom_mcp")

# --- Authentication Tools ---

@mcp.tool(
    name="linkedin_get_oauth_url",
    annotations={
        "title": "Get LinkedIn Auth URL",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_oauth_url() -> str:
    '''Generate the LinkedIn OAuth 2.0 authorization URL for browser login.

    This tool generates the authorization URL that users must visit in their browser
    to grant permissions to this MCP server. After authorization, LinkedIn redirects
    to the configured redirect URI with an authorization code. This tool does NOT
    perform the authentication itself, only generates the URL.

    Returns:
        str: Markdown-formatted message containing:
            - Authorization URL with proper OAuth 2.0 parameters
            - Step-by-step instructions for completing authentication
            - Instructions for using linkedin_exchange_code tool
        Or error message if client credentials are not configured.

    Examples:
        - Use when: Starting a new authentication flow
        - Use when: Access token has expired and needs refresh
        - Don't use when: You already have a valid access token
        - Don't use when: You need to exchange an auth code (use linkedin_exchange_code)

    Error Handling:
        - Returns "Error: LINKEDIN_CLIENT_ID not configured in .env" if credentials missing
        - No network errors possible (URL generation only)

    OAuth Scopes Requested:
        - openid: Standard OIDC authentication
        - profile: Access to basic profile information
        - email: Access to email address
        - w_member_social: Create posts and shares
    '''
    return await auth.get_oauth_url()

@mcp.tool(
    name="linkedin_exchange_code",
    annotations={
        "title": "Exchange Auth Code",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True
    }
)
async def linkedin_exchange_code(code: str) -> str:
    '''Exchange the browser-provided authorization code for a persistent access token.

    After a user authorizes via the OAuth URL, LinkedIn redirects with an authorization
    code in the URL. This tool exchanges that code for an access token and saves it
    to the .env file for future use. The access token is required for all LinkedIn
    API operations. This tool modifies the .env file.

    Args:
        code (str): The authorization code from LinkedIn OAuth redirect URL
            (e.g., "AQTvqXXXXXXXXXXX" - found in the 'code' parameter after redirect)

    Returns:
        str: Success message with token expiration time in format:
            "✅ Success! Access Token saved. Expires in {seconds} seconds."
        Or error message:
            "Error: Missing client credentials (ID or Secret)."
            "Error exchanging code: {details}"
            "Error: {exception message}"

    Examples:
        - Use when: You have an authorization code from OAuth redirect
        - Use when: Setting up authentication for the first time
        - Don't use when: You already have a valid access token
        - Don't use when: You need to generate the OAuth URL (use linkedin_get_oauth_url)

    Error Handling:
        - Returns "Error: Missing client credentials" if LINKEDIN_CLIENT_ID or LINKEDIN_CLIENT_SECRET not set
        - Returns detailed error message if token exchange fails (invalid code, network error, etc.)
        - Automatically updates .env file with new token on success

    Side Effects:
        - Writes LINKEDIN_ACCESS_TOKEN to .env file
        - Creates .env file if it doesn't exist
    '''
    return await auth.exchange_code(code)

# --- Profile Tools ---

@mcp.tool(
    name="linkedin_get_my_profile",
    annotations={
        "title": "Get My Profile",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_my_profile() -> str:
    '''Fetch the authenticated user's profile information (Name, Email, Picture).

    This tool retrieves the profile information for the currently authenticated user
    using the OpenID Connect userinfo endpoint. It provides reliable access to basic
    profile data including name, email, and profile picture. This tool does NOT
    retrieve connection information, work history, or detailed profile sections.

    Returns:
        str: JSON-formatted string containing profile data with the following schema:

        Success response:
        {
            "id": str,              # LinkedIn member ID (e.g., "Ab12CDeFgH")
            "name": str,            # Full name (e.g., "John Doe")
            "given_name": str,      # First name (e.g., "John")
            "family_name": str,     # Last name (e.g., "Doe")
            "email": str,           # Email address (e.g., "john.doe@example.com")
            "email_verified": bool, # Whether email is verified
            "picture": str,         # Profile picture URL
            "locale": str           # Locale preference (e.g., "en_US")
        }

        Error response:
        "Error: Unauthorized (401). Your access token might be invalid or expired."
        "Error: {error message}"

    Examples:
        - Use when: "What's my LinkedIn email address?"
        - Use when: "Show me my profile information"
        - Use when: Need to get the authenticated user's ID for other operations
        - Don't use when: Looking for another user's profile (use linkedin_get_member_profile)
        - Don't use when: Need detailed work history or connections

    Error Handling:
        - Returns "Error: Unauthorized (401)" if access token is invalid or expired
        - Returns "Error: Rate limit exceeded" for 429 status
        - Returns formatted error message for other API failures

    Required Permissions:
        - openid, profile, email scopes (standard with OAuth flow)
    '''
    return await profile.get_my_profile()

@mcp.tool(
    name="linkedin_get_member_profile",
    annotations={
        "title": "Get Member Profile",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_member_profile(member_urn: str) -> str:
    '''Fetch a specific member's profile by their URN (e.g., 'urn:li:person:123').

    This tool retrieves public profile information for a LinkedIn member specified
    by their URN (Uniform Resource Name). The available data depends on the viewer's
    relationship with the member and the member's privacy settings. This tool does
    NOT modify profiles or send connection requests.

    Args:
        member_urn (str): The LinkedIn member URN in format 'urn:li:person:{id}'
            (e.g., "urn:li:person:Ab12CDeFgH")

    Returns:
        str: JSON-formatted string containing available profile data

        Success response includes fields like:
        {
            "id": str,           # Member URN
            "firstName": str,    # Member's first name
            "lastName": str,     # Member's last name
            "headline": str,     # Professional headline
            ...                  # Additional fields based on permissions
        }

        Error response:
        "Error: Resource not found" if member doesn't exist or is inaccessible
        "Error: Forbidden (403)" if lacking permissions
        "Error: {error message}"

    Examples:
        - Use when: "Get profile for member urn:li:person:XYZ"
        - Use when: Need details about a specific LinkedIn member
        - Don't use when: You want your own profile (use linkedin_get_my_profile)
        - Don't use when: Searching for members by name (use linkedin_search_people)

    Error Handling:
        - Returns "Error: Resource not found" for invalid or inaccessible URNs (404)
        - Returns "Error: Forbidden (403)" if you lack permissions to view the profile
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns formatted error for other API failures

    Required Permissions:
        - r_basicprofile or equivalent profile viewing permissions
        - Access depends on connection relationship and privacy settings
    '''
    return await search.get_member_profile(member_urn)

# --- Post Tools ---

@mcp.tool(
    name="linkedin_create_post",
    annotations={
        "title": "Create Feed Post",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True
    }
)
async def linkedin_create_post(text: str, visibility: str = "PUBLIC") -> str:
    '''Create a new text-based update on the user LinkedIn feed.

    This tool publishes a text-only post to the authenticated user's LinkedIn feed.
    The post will be visible to the specified audience (public or connections only).
    This tool does NOT support images, videos, articles, or polls - use
    linkedin_create_image_post for posts with images.

    Args:
        text (str): The content of the post, supports plain text and LinkedIn-formatted text
            (e.g., "Excited to announce my new project! #innovation #tech")
            Maximum length: 3000 characters
        visibility (str): Post visibility setting, must be 'PUBLIC' or 'CONNECTIONS'
            (default: 'PUBLIC')
            - PUBLIC: Visible to anyone on LinkedIn
            - CONNECTIONS: Only visible to your connections

    Returns:
        str: Success message with post ID in format:
            "✅ Post created successfully.\nID: urn:li:share:123456789"
        Or error message:
            "Error: {error message}"

    Examples:
        - Use when: "Post 'Just published a new article on AI' to LinkedIn"
        - Use when: "Share an update with my connections about the project launch"
        - Use when: Creating text-only status updates or announcements
        - Don't use when: You want to include an image (use linkedin_create_image_post)
        - Don't use when: You want to edit an existing post (use linkedin_update_post)
        - Don't use when: You want to share a URL with rich preview (may need image post)

    Error Handling:
        - Returns "Error: Unauthorized (401)" if access token is invalid or expired
        - Returns "Error: Forbidden (403)" if lacking w_member_social permission
        - Returns "Error: Rate limit exceeded" for 429 status
        - Returns formatted error for validation failures or other API errors

    Required Permissions:
        - w_member_social: Required to create posts and shares
    '''
    params = post.PostParams(text=text, visibility=visibility)
    return await post.create_post(params)

@mcp.tool(
    name="linkedin_create_image_post",
    annotations={
        "title": "Create Image Post",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True
    }
)
async def linkedin_create_image_post(text: str, image_source: str, visibility: str = "PUBLIC") -> str:
    '''Create a post with an image.

    This tool publishes a post with an image to the authenticated user's LinkedIn feed.
    The image can be provided as a local file path or a publicly accessible URL. The
    tool handles the complete image upload process (register, upload binary, create post).
    This tool does NOT support multiple images or video uploads.

    Args:
        text (str): Post caption and commentary
            (e.g., "Check out our new product launch! #innovation")
            Maximum length: 3000 characters
        image_source (str): Local file path or public URL of the image
            Examples:
            - Local: "C:/photos/launch.jpg", "/home/user/images/event.png"
            - URL: "https://example.com/images/photo.jpg"
            Supported formats: JPEG, PNG, GIF
            Recommended size: Max 10MB
        visibility (str): Post visibility setting, must be 'PUBLIC' or 'CONNECTIONS'
            (default: 'PUBLIC')

    Returns:
        str: Success message with post ID in format:
            "✅ Image Post created successfully.\nID: urn:li:share:123456789"
        Or error message:
            "Error: {error message}"
            "FileNotFoundError: Image file not found: {path}"

    Examples:
        - Use when: "Post this image with caption 'New office opening!'"
        - Use when: Sharing visual content like infographics, photos, or screenshots
        - Use when: Creating announcements that need visual elements
        - Don't use when: You only have text (use linkedin_create_post)
        - Don't use when: You want to share multiple images (not supported by API)
        - Don't use when: You want to upload a video (different API endpoint needed)

    Error Handling:
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns "Error: Forbidden (403)" if lacking permissions
        - Returns "FileNotFoundError" if local image file doesn't exist
        - Returns formatted error if image download fails (for URL sources)
        - Returns error if image upload fails or post creation fails
        - Performs 3-step process: register upload, upload binary, create post

    Required Permissions:
        - w_member_social: Required to create posts with media
        - w_organization_social: May be required for organization posts

    Side Effects:
        - Uploads image to LinkedIn's media servers
        - Creates a permanent post on user's feed
    '''
    params = post.ImagePostParams(text=text, image_source=image_source, visibility=visibility)
    return await post.create_image_post(params)

@mcp.tool(
    name="linkedin_update_post",
    annotations={
        "title": "Update Post",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True
    }
)
async def linkedin_update_post(post_urn: str, text: str, visibility: str = "PUBLIC") -> str:
    '''Update a post's text.

    ⚠️ IMPORTANT: LinkedIn API does not support direct editing of published posts.
    This tool implements "update" by DELETING the old post and creating a new one
    with the updated text. The new post will have a different ID and will lose all
    engagement metrics (likes, comments, shares) from the original post. This is
    a DESTRUCTIVE operation.

    Args:
        post_urn (str): The URN of the post to update
            (e.g., "urn:li:share:123456789", "urn:li:ugcPost:123456789")
        text (str): The new text content for the post
            (e.g., "Updated: Exciting news about our product launch!")
            Maximum length: 3000 characters
        visibility (str): Visibility for the new post, must be 'PUBLIC' or 'CONNECTIONS'
            (default: 'PUBLIC')

    Returns:
        str: Success message with old and new post IDs in format:
            "✅ Post updated (Re-created).\nOld ID: {old_urn}\n✅ Post created successfully.\nID: {new_id}"
        Or error messages:
            "Update Failed during deletion step: {error}"
            "⚠️ Old post deleted, but creation failed: {error}"
            "Error: {error message}"

    Examples:
        - Use when: "Fix the typo in my last post"
        - Use when: "Update the post with ID urn:li:share:123 to say 'Event postponed'"
        - Don't use when: You want to add a comment (use linkedin_create_comment)
        - Don't use when: The post has significant engagement you want to preserve
        - Don't use when: You just want to delete (use linkedin_delete_post)

    Error Handling:
        - Returns "Update Failed during deletion step" if original post can't be deleted
        - Returns "⚠️ Old post deleted, but creation failed" if new post creation fails after deletion
        - Returns "Error: Post {urn} not found" if post doesn't exist (404)
        - Returns "Error: Forbidden (403)" if you don't own the post
        - Returns formatted error for other API failures

    Required Permissions:
        - w_member_social: Required to delete old post and create new one

    Side Effects:
        - PERMANENTLY DELETES the original post and all its engagement
        - Creates a new post with different ID
        - Engagement metrics (likes, comments, shares) are NOT preserved
        - Post timestamp will reflect the new creation time
    '''
    params = post.UpdatePostParams(post_urn=post_urn, text=text, visibility=visibility)
    return await post.update_post(params)

@mcp.tool(
    name="linkedin_delete_post",
    annotations={
        "title": "Delete Post",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_delete_post(post_urn: str) -> str:
    '''Delete a LinkedIn post by its URN (e.g., 'urn:li:share:123').

    This tool permanently deletes a post from the authenticated user's LinkedIn feed.
    The deletion is immediate and irreversible. All engagement (likes, comments, shares)
    associated with the post will also be removed. This is a DESTRUCTIVE operation.

    Args:
        post_urn (str): The URN of the post to delete
            (e.g., "urn:li:share:123456789", "urn:li:ugcPost:123456789")
            Must be a post owned by the authenticated user

    Returns:
        str: Success message in format:
            "✅ Post {post_urn} deleted successfully."
        Or error message:
            "Error: Post {post_urn} not found."
            "Error: Forbidden (403). You don't have permission to delete this post."
            "Error: {error message}"

    Examples:
        - Use when: "Delete my most recent post"
        - Use when: "Remove the post with ID urn:li:share:123456789"
        - Use when: Need to remove inappropriate or outdated content
        - Don't use when: You want to edit the post (use linkedin_update_post)
        - Don't use when: You want to hide a post temporarily (no hide feature in API)
        - Don't use when: Trying to delete someone else's post (only works for your own posts)

    Error Handling:
        - Returns "Error: Post {urn} not found" if post doesn't exist or already deleted (404)
        - Returns "Error: Forbidden (403)" if post belongs to another user
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns formatted error for other API failures
        - Repeated calls to delete same post return 404 (idempotent behavior)

    Required Permissions:
        - w_member_social: Required to delete posts

    Side Effects:
        - PERMANENTLY removes the post from LinkedIn
        - All engagement (likes, comments, shares) is lost
        - Cannot be undone
    '''
    return await post.delete_post(post_urn)

@mcp.tool(
    name="linkedin_get_recent_posts",
    annotations={
        "title": "Get Recent Posts",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_recent_posts() -> str:
    '''List the user's recent posts (Requires 'r_member_social' permission).

    This tool retrieves a list of the authenticated user's recent posts and shares.
    ⚠️ NOTE: This endpoint often requires the 'r_member_social' permission which is
    restricted by LinkedIn and not available to most applications. Many developers
    will receive a 403 Forbidden error when calling this tool.

    Returns:
        str: JSON-formatted array of posts with the following schema:

        Success response:
        [
            {
                "id": str,           # Post URN (e.g., "urn:li:share:123")
                "text": str,         # Post text content
                "created": int,      # Unix timestamp of creation
                "visibility": str    # Visibility setting (PUBLIC/CONNECTIONS)
            },
            ...
        ]

        Error response:
        "Error: Forbidden (403). You lack permissions for this action."
        "Error: Unauthorized (401). Your access token might be invalid."
        "Error: {error message}"

    Examples:
        - Use when: "Show me my last 5 LinkedIn posts"
        - Use when: Need to review your posting history
        - Use when: Looking for a specific post ID from your history
        - Don't use when: Looking for another user's posts (not supported)
        - Don't use when: You need detailed engagement metrics (use LinkedIn UI)

    Error Handling:
        - Returns "Error: Forbidden (403)" if r_member_social permission not granted (common)
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns empty array [] if user has no posts
        - Returns formatted error for other API failures

    Required Permissions:
        - r_member_social: Required to read user's social activity
        - ⚠️ This permission is often RESTRICTED and not available to most apps

    Limitations:
        - May not return all historical posts (LinkedIn may limit the response)
        - Does not include detailed engagement metrics
        - Does not include posts on organization pages
    '''
    return await post.get_recent_posts()

@mcp.tool(
    name="linkedin_create_comment",
    annotations={
        "title": "Create Comment",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True
    }
)
async def linkedin_create_comment(object_urn: str, text: str) -> str:
    '''Create a comment on a LinkedIn share, article, or video.

    This tool posts a new comment on LinkedIn content including shares, UGC posts,
    articles, and videos. The comment will be visible to viewers of the content based on
    their permissions. This tool does NOT edit existing comments or support threaded
    replies (replies to comments).

    Args:
        object_urn (str): The URN of the content to comment on
            (e.g., 'urn:li:share:123456789', 'urn:li:ugcPost:123456789', 'urn:li:article:123')
            Must be a valid LinkedIn content URN
        text (str): The text content of the comment
            (e.g., "Great insights! Thanks for sharing.")
            Maximum length: 1250 characters for comments

    Returns:
        str: Success message with comment ID in format:
            "✅ Comment created successfully.\nID: urn:li:comment:(urn:li:share:123,456)"
        Or error message:
            "Error: Resource not found" if object doesn't exist
            "Error: Forbidden (403)" if you lack permissions
            "Error: {error message}"

    Examples:
        - Use when: "Reply to the post saying 'Great insights!'"
        - Use when: "Add a comment asking for clarification on post urn:li:share:123"
        - Use when: Engaging with content in your feed
        - Don't use when: You want to edit an existing comment (not supported)
        - Don't use when: You want to delete a comment (use linkedin_delete_comment)
        - Don't use when: You want to create a post (use linkedin_create_post)
        - Don't use when: You want to reply to a comment (threaded replies not fully supported)

    Error Handling:
        - Returns "Error: Resource not found" if object URN doesn't exist or is inaccessible (404)
        - Returns "Error: Forbidden (403)" if you lack permissions to comment
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns "Error: Rate limit exceeded" for 429 status
        - Returns formatted error for validation failures or other API errors

    Required Permissions:
        - w_member_social: Required to create comments

    Limitations:
        - Cannot edit comments after creation
        - Threaded replies (replies to comments) have limited support
        - Cannot tag other users with @ mentions in all cases
    '''
    params = post.CommentParams(object_urn=object_urn, text=text)
    return await post.create_comment(params)

@mcp.tool(
    name="linkedin_get_post_comments",
    annotations={
        "title": "Get Comments",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_post_comments(object_urn: str) -> str:
    '''Get comments for a specific post/share.

    This tool retrieves all comments on a LinkedIn post, share, article, or other
    content object. It returns basic comment information including comment text,
    author, and timestamps. This tool does NOT retrieve reactions/likes, only comments.

    Args:
        object_urn (str): The URN of the content to get comments for
            (e.g., 'urn:li:share:123456789', 'urn:li:ugcPost:123456789')

    Returns:
        str: JSON-formatted array of comments with the following schema:

        Success response:
        [
            {
                "id": str,        # Comment URN (e.g., "urn:li:comment:(...)")
                "actor": str,     # Author URN (e.g., "urn:li:person:123")
                "text": str,      # Comment text content
                "created": int    # Unix timestamp of creation (milliseconds)
            },
            ...
        ]

        Returns empty array [] if no comments exist.

        Error response:
        "Error: Resource not found" if object doesn't exist
        "Error: Forbidden (403)" if you lack permissions
        "Error: {error message}"

    Examples:
        - Use when: "Show me all comments on post urn:li:share:123"
        - Use when: "How many people commented on my latest post?"
        - Use when: Need to analyze engagement on a specific post
        - Don't use when: You want reaction counts (likes) - not included in response
        - Don't use when: You need detailed author profiles - only URNs are provided
        - Don't use when: You want to create a comment (use linkedin_create_comment)

    Error Handling:
        - Returns "Error: Resource not found" if object URN doesn't exist (404)
        - Returns "Error: Forbidden (403)" if you lack permissions to view comments
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns empty array [] if post has no comments (not an error)
        - Returns formatted error for other API failures

    Required Permissions:
        - r_member_social or equivalent permissions to read social activity
        - Permissions vary based on your relationship to the content

    Limitations:
        - Does not include reaction/like information
        - Does not include detailed author profiles (only URNs)
        - May not return all comments for posts with very high engagement
    '''
    return await post.get_post_comments(object_urn)

@mcp.tool(
    name="linkedin_delete_comment",
    annotations={
        "title": "Delete Comment",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_delete_comment(comment_urn: str, object_urn: str) -> str:
    '''Delete a specific comment.

    This tool permanently deletes a comment that you previously created on LinkedIn
    content. The deletion is immediate and irreversible. You can only delete your own
    comments, not comments by other users. This is a DESTRUCTIVE operation.

    Args:
        comment_urn (str): The URN of the comment to delete
            (e.g., "urn:li:comment:(urn:li:share:123,456)" or just the comment ID portion)
            If the full URN is provided, the tool extracts the comment ID
        object_urn (str): The URN of the parent post/object the comment is on
            (e.g., "urn:li:share:123456789")
            Required by LinkedIn API to identify the context

    Returns:
        str: Success message:
            "✅ Comment deleted successfully."
        Or error message:
            "Error: Comment or Object not found."
            "Error: Forbidden (403). You can only delete your own comments."
            "Error: {error message}"

    Examples:
        - Use when: "Delete my comment on post urn:li:share:123"
        - Use when: "Remove the comment with ID 456 from post urn:li:share:123"
        - Use when: Need to remove an inappropriate or incorrect comment
        - Don't use when: Trying to delete someone else's comment (only your own)
        - Don't use when: You want to edit a comment (not supported - delete and recreate)
        - Don't use when: You want to delete the post itself (use linkedin_delete_post)

    Error Handling:
        - Returns "Error: Comment or Object not found" if comment or post doesn't exist (404)
        - Returns "Error: Forbidden (403)" if comment belongs to another user
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns formatted error for other API failures
        - Repeated calls to delete same comment return 404 (idempotent behavior)

    Required Permissions:
        - w_member_social: Required to delete comments

    Side Effects:
        - PERMANENTLY removes the comment from LinkedIn
        - Cannot be undone
        - Other users will no longer see the comment

    Technical Notes:
        - If comment_urn contains parentheses (full URN format), the tool extracts the comment ID
        - If just the ID is provided, it's used directly
    '''
    return await post.delete_comment(comment_urn, object_urn)

# --- Company Tools ---

@mcp.tool(
    name="linkedin_get_company_profile",
    annotations={
        "title": "Get Company Profile",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_company_profile(company_urn: str) -> str:
    '''Fetch a company's profile information by its URN (e.g., 'urn:li:organization:123').

    This tool retrieves public information about a LinkedIn company/organization page.
    The available data includes company name, description, industry, size, and other
    profile details. This tool does NOT retrieve employee lists, job postings, or
    detailed analytics.

    Args:
        company_urn (str): The LinkedIn organization URN in format 'urn:li:organization:{id}'
            (e.g., "urn:li:organization:1234567")

    Returns:
        str: JSON-formatted company profile data with fields like:

        Success response includes:
        {
            "id": str,              # Organization URN
            "name": str,            # Company name
            "description": str,     # Company description
            "industry": str,        # Industry category
            "companyType": str,     # Company type (e.g., "PUBLIC_COMPANY")
            "companySize": str,     # Size range (e.g., "51-200")
            "website": str,         # Company website URL
            "specialties": [str],   # List of specialties
            ...                     # Additional fields based on permissions
        }

        Error response:
        "Error: Resource not found" if company doesn't exist
        "Error: {error message}"

    Examples:
        - Use when: "Get details for company urn:li:organization:1234567"
        - Use when: "What's the description for Microsoft's LinkedIn page?"
        - Use when: Need company information for research or analysis
        - Don't use when: Searching by company name (use linkedin_search_companies)
        - Don't use when: You need employee information (not included)
        - Don't use when: You need job postings (use linkedin_search_jobs)

    Error Handling:
        - Returns "Error: Resource not found" for invalid or non-existent URNs (404)
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns formatted error for other API failures

    Required Permissions:
        - Basic API access (no special organization permissions required for public data)

    Limitations:
        - Only returns publicly available information
        - Does not include employee lists or detailed analytics
        - Does not include job postings
    '''
    return await company.get_company_profile(company_urn)

@mcp.tool(
    name="linkedin_search_companies",
    annotations={
        "title": "Search Companies",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_search_companies(keywords: str) -> str:
    '''Search for companies on LinkedIn by keywords.

    This tool searches LinkedIn's company database using keywords. It returns matching
    organization profiles based on company names, descriptions, and other indexed fields.
    ⚠️ NOTE: This endpoint often requires specialized LinkedIn Marketing or Talent
    Solutions permissions and may not be available to standard applications.

    Args:
        keywords (str): Search keywords to match against company information
            (e.g., "technology startup San Francisco", "automotive manufacturer")

    Returns:
        str: JSON-formatted search results with company information

        Success response format varies but typically includes:
        {
            "elements": [
                {
                    "id": str,      # Organization URN
                    "name": str,    # Company name
                    ...             # Additional company fields
                }
            ],
            "paging": {...}         # Pagination information
        }

        Returns empty results if no matches found.

        Error response:
        "Error: Forbidden (403). You lack permissions for this action."
        "Error: {error message}"

    Examples:
        - Use when: "Find technology companies in San Francisco"
        - Use when: "Search for companies with 'AI' in their description"
        - Use when: Need to discover companies by topic or industry
        - Don't use when: You have a specific company URN (use linkedin_get_company_profile)
        - Don't use when: Searching for jobs (use linkedin_search_jobs)
        - Don't use when: Searching for people (use linkedin_search_people)

    Error Handling:
        - Returns "Error: Forbidden (403)" if lacking required permissions (common)
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns empty results if no companies match keywords
        - Returns formatted error for other API failures

    Required Permissions:
        - Often requires LinkedIn Marketing API or Talent Solutions permissions
        - ⚠️ Standard API access may receive 403 Forbidden errors

    Limitations:
        - May not be available to all applications
        - Results may be limited based on your API tier
        - Does not support advanced filtering (industry, size, location)
    '''
    return await company.search_companies(keywords)

# --- Job Tools ---

@mcp.tool(
    name="linkedin_search_jobs",
    annotations={
        "title": "Search Jobs",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_search_jobs(keywords: str, location: str = None) -> str:
    '''Search for jobs on LinkedIn by keywords and optional location.

    This tool searches LinkedIn's job listings using keywords and optional location
    filters. It returns matching job postings with basic information. ⚠️ NOTE: Job
    search functionality may require LinkedIn Talent Solutions or specialized API
    permissions and may not be fully available to standard applications.

    Args:
        keywords (str): Job search keywords to match against titles, descriptions, companies
            (e.g., "Python Developer", "Senior Data Scientist", "Machine Learning Engineer")
        location (Optional[str]): Optional location filter for job search
            (e.g., "San Francisco, CA", "New York City", "Remote")
            If None, searches across all locations

    Returns:
        str: JSON-formatted search results with job listings

        Success response format varies but typically includes:
        {
            "elements": [
                {
                    "id": str,          # Job posting URN
                    "title": str,       # Job title
                    "company": str,     # Company name or URN
                    "location": str,    # Job location
                    ...                 # Additional job fields
                }
            ],
            "paging": {...}             # Pagination information
        }

        Returns empty results if no matches found.

        Error response:
        "Error: Forbidden (403). You lack permissions for this action."
        "Error: {error message}"

    Examples:
        - Use when: "Find Python Developer jobs in San Francisco"
        - Use when: "Search for remote data science positions"
        - Use when: "What Senior Engineer jobs are available?"
        - Don't use when: You have a specific job URN (use linkedin_get_job_details)
        - Don't use when: Searching for companies (use linkedin_search_companies)
        - Don't use when: Searching for people (use linkedin_search_people)

    Error Handling:
        - Returns "Error: Forbidden (403)" if lacking required permissions (possible)
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns empty results if no jobs match search criteria
        - Returns formatted error for other API failures

    Required Permissions:
        - May require LinkedIn Talent Solutions or specialized permissions
        - Standard API access may have limited functionality

    Limitations:
        - May not return all available jobs (depends on API tier and permissions)
        - Advanced filters (salary, experience level, job type) may not be available
        - Results may be limited compared to LinkedIn web search
    '''
    return await job.search_jobs(keywords, location)

@mcp.tool(
    name="linkedin_get_job_details",
    annotations={
        "title": "Get Job Details",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_get_job_details(job_urn: str) -> str:
    '''Fetch details for a specific job posting by its URN.

    This tool retrieves detailed information about a specific LinkedIn job posting
    including title, description, requirements, company information, and application
    details. This tool does NOT apply to jobs or submit applications.

    Args:
        job_urn (str): The job posting URN in format 'urn:li:job:{id}'
            (e.g., "urn:li:job:123456789")

    Returns:
        str: JSON-formatted job details with fields like:

        Success response includes:
        {
            "id": str,              # Job URN
            "title": str,           # Job title
            "description": str,     # Full job description
            "company": str,         # Company URN or name
            "location": str,        # Job location
            "employmentType": str,  # Full-time, Part-time, Contract, etc.
            "seniorityLevel": str,  # Entry-level, Mid-Senior, Executive, etc.
            "industries": [str],    # Relevant industries
            ...                     # Additional fields
        }

        Error response:
        "Error: Resource not found" if job doesn't exist or was removed
        "Error: {error message}"

    Examples:
        - Use when: "Get full details for job urn:li:job:123456789"
        - Use when: "What's the description for this job posting?"
        - Use when: Need complete job information including requirements
        - Don't use when: Searching for jobs by keywords (use linkedin_search_jobs)
        - Don't use when: You want to apply to the job (not supported via API)

    Error Handling:
        - Returns "Error: Resource not found" if job doesn't exist or was removed (404)
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns formatted error for other API failures

    Required Permissions:
        - Basic API access for public job postings
        - May require additional permissions for restricted postings

    Limitations:
        - Cannot apply to jobs via API (must use LinkedIn website/app)
        - Some job details may be restricted based on permissions
        - Expired job postings may no longer be accessible
    '''
    return await job.get_job_details(job_urn)

# --- Search Tools ---

@mcp.tool(
    name="linkedin_search_people",
    annotations={
        "title": "Search People",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True
    }
)
async def linkedin_search_people(keywords: str) -> str:
    '''Search for people on LinkedIn by keywords.

    This tool searches LinkedIn's member database using keywords to find people based
    on names, job titles, skills, companies, and other profile information. ⚠️ NOTE:
    People search functionality requires specific LinkedIn API permissions (e.g.,
    r_basicprofile) which are often restricted and may not be available to standard
    applications.

    Args:
        keywords (str): Search keywords to match against member profiles
            (e.g., "John Smith", "Software Engineer at Google", "Data Scientist")

    Returns:
        str: JSON-formatted search results with member information

        Success response format varies but typically includes:
        {
            "elements": [
                {
                    "id": str,          # Member URN
                    "firstName": str,   # First name
                    "lastName": str,    # Last name
                    "headline": str,    # Professional headline
                    ...                 # Additional profile fields
                }
            ],
            "paging": {...}             # Pagination information
        }

        Returns empty results if no matches found.

        Error response:
        "Error: Forbidden (403). You lack permissions for this action."
        "Error: {error message}"

    Examples:
        - Use when: "Find people named 'John Smith'"
        - Use when: "Search for software engineers in my network"
        - Use when: "Find data scientists at Microsoft"
        - Don't use when: You have a specific member URN (use linkedin_get_member_profile)
        - Don't use when: Searching for companies (use linkedin_search_companies)
        - Don't use when: Searching for jobs (use linkedin_search_jobs)

    Error Handling:
        - Returns "Error: Forbidden (403)" if lacking required permissions (very common)
        - Returns "Error: Unauthorized (401)" if access token is invalid
        - Returns empty results if no people match keywords
        - Returns formatted error for other API failures

    Required Permissions:
        - r_basicprofile or equivalent people search permissions
        - ⚠️ These permissions are often RESTRICTED and not available to most apps

    Limitations:
        - May not be available to most applications due to permission restrictions
        - Search is limited to accessible profiles based on privacy settings
        - Advanced filters may not be available
        - Results depend on connection relationships and privacy settings
    '''
    return await search.search_people(keywords)

# --- Main Entry Point ---

def main():
    """Main entry point for the LinkedIn MCP Server CLI."""
    import sys
    try:
        # Use stdio transport for MCP clients (like Claude Code CLI)
        # This allows the server to communicate via stdin/stdout
        mcp.run(transport="stdio")
        return 0
    except KeyboardInterrupt:
        print("\nServer stopped by user", file=sys.stderr)
        return 0
    except Exception as e:
        print(f"Error starting server: {e}", file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
