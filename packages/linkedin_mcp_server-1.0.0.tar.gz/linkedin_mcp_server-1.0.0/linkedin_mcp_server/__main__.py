"""CLI entry point for LinkedIn MCP Server."""

import sys
from .server import main

if __name__ == "__main__":
    sys.exit(main())
