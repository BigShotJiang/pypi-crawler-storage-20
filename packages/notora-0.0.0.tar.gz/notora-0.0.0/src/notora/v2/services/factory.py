from typing import TypeVar

from notora.v2.models.base import GenericBaseModel
from notora.v2.repositories.base import Repository, SoftDeleteRepository
from notora.v2.repositories.config import RepoConfig
from notora.v2.repositories.factory import build_repository
from notora.v2.schemas.base import BaseResponseSchema
from notora.v2.services.base import RepositoryService, SoftDeleteRepositoryService
from notora.v2.services.config import ServiceConfig

ModelType = TypeVar('ModelType', bound=GenericBaseModel)
ResponseSchema = TypeVar('ResponseSchema', bound=BaseResponseSchema)
PKType = TypeVar('PKType')


def build_service(  # noqa: C901
    model: type[ModelType],
    *,
    repo: Repository[PKType, ModelType] | SoftDeleteRepository[PKType, ModelType] | None = None,
    repo_config: RepoConfig[ModelType] | None = None,
    service_config: ServiceConfig[ResponseSchema] | None = None,
    soft_delete: bool = False,
    repo_cls: type[Repository[PKType, ModelType]]
    | type[SoftDeleteRepository[PKType, ModelType]]
    | None = None,
    service_cls: type[RepositoryService[PKType, ModelType, ResponseSchema]]
    | type[SoftDeleteRepositoryService[PKType, ModelType, ResponseSchema]]
    | None = None,
) -> (
    RepositoryService[PKType, ModelType, ResponseSchema]
    | SoftDeleteRepositoryService[PKType, ModelType, ResponseSchema]
):
    """Create a repository + service pair with optional config overrides."""
    if repo is None:
        repo = build_repository(
            model,
            config=repo_config,
            soft_delete=soft_delete,
            repo_cls=repo_cls,
        )
    if service_cls is None:
        if soft_delete or isinstance(repo, SoftDeleteRepository):
            if not isinstance(repo, SoftDeleteRepository):
                msg = 'Soft-delete service requires a soft-delete repository.'
                raise TypeError(msg)
            return SoftDeleteRepositoryService(repo, config=service_config)
        return RepositoryService(repo, config=service_config)

    if issubclass(service_cls, SoftDeleteRepositoryService):
        if not isinstance(repo, SoftDeleteRepository):
            msg = 'Soft-delete service requires a soft-delete repository.'
            raise TypeError(msg)
        return service_cls(repo, config=service_config)
    return service_cls(repo, config=service_config)


def build_service_for_repo(
    repo: Repository[PKType, ModelType] | SoftDeleteRepository[PKType, ModelType],
    *,
    service_config: ServiceConfig[ResponseSchema] | None = None,
    service_cls: type[RepositoryService[PKType, ModelType, ResponseSchema]]
    | type[SoftDeleteRepositoryService[PKType, ModelType, ResponseSchema]]
    | None = None,
) -> (
    RepositoryService[PKType, ModelType, ResponseSchema]
    | SoftDeleteRepositoryService[PKType, ModelType, ResponseSchema]
):
    """Create a service for an existing repository."""
    if service_cls is None:
        if isinstance(repo, SoftDeleteRepository):
            return SoftDeleteRepositoryService(repo, config=service_config)
        return RepositoryService(repo, config=service_config)

    if issubclass(service_cls, SoftDeleteRepositoryService):
        if not isinstance(repo, SoftDeleteRepository):
            msg = 'Soft-delete service requires a soft-delete repository.'
            raise TypeError(msg)
        return service_cls(repo, config=service_config)
    return service_cls(repo, config=service_config)
