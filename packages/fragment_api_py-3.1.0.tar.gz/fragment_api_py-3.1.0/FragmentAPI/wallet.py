"""
Wallet management and transaction execution for Fragment API
"""

import logging
import base64
from typing import Optional
from .exceptions import WalletError, InsufficientBalanceError, TransactionError
from .models import WalletBalance, TransferResult
from .utils import nano_to_ton, ton_to_nano

logger = logging.getLogger(__name__)


class WalletManager:
    """
    Manages TON wallet operations including balance checking and transaction signing
    """

    TRANSFER_FEE_NANO = "1000000"
    TRANSFER_FEE_TON = 0.05

    def __init__(self, wallet_mnemonic: str, wallet_api_key: str):
        if not wallet_mnemonic or not wallet_api_key:
            raise WalletError("Wallet mnemonic and API key are required")
        
        self.wallet_mnemonic = wallet_mnemonic.split() if isinstance(wallet_mnemonic, str) else wallet_mnemonic
        self.wallet_api_key = wallet_api_key

    async def get_balance(self) -> WalletBalance:
        try:
            from tonutils.client import TonapiClient
            from tonutils.wallet import WalletV4R2
            import httpx
            
            client = TonapiClient(api_key=self.wallet_api_key, is_testnet=False)
            
            wallet_tuple = WalletV4R2.from_mnemonic(client, self.wallet_mnemonic)
            
            if isinstance(wallet_tuple, tuple):
                wallet = wallet_tuple[0]
            else:
                wallet = wallet_tuple
            
            address = wallet.address.to_str(is_user_friendly=True)
            
            async with httpx.AsyncClient() as http_client:
                response = await http_client.get(
                    f"https://tonapi.io/v2/accounts/{address}",
                    headers={"Authorization": f"Bearer {self.wallet_api_key}"}
                )
                
                if response.status_code == 200:
                    data = response.json()
                    balance_nano = data.get("balance", "0")
                else:
                    balance_nano = "0"
            
            balance_ton = nano_to_ton(str(balance_nano))
            
            return WalletBalance(
                balance_nano=str(balance_nano),
                balance_ton=balance_ton,
                address=address,
                is_ready=True
            )
        except Exception as e:
            logger.error(f"Balance retrieval error: {e}")
            raise WalletError(f"Failed to get wallet balance: {e}")

    def get_balance_sync(self) -> WalletBalance:
        import asyncio
        
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            balance = loop.run_until_complete(self.get_balance())
            loop.close()
            return balance
        except Exception as e:
            raise WalletError(f"Failed to get wallet balance: {e}")

    async def send_transaction(self, dest_address: str, amount_nano: str, raw_boc: str) -> str:
        try:
            from tonutils.client import TonapiClient
            from tonutils.wallet import WalletV4R2
            from pytoniq_core import Cell
            
            client = TonapiClient(api_key=self.wallet_api_key, is_testnet=False)
            
            wallet_tuple = WalletV4R2.from_mnemonic(client, self.wallet_mnemonic)
            
            if isinstance(wallet_tuple, tuple):
                wallet = wallet_tuple[0]
            else:
                wallet = wallet_tuple
            
            current_balance = await self.get_balance()
            total_required = int(amount_nano) + int(self.TRANSFER_FEE_NANO)
            
            if int(current_balance.balance_nano) < total_required:
                required_ton = nano_to_ton(str(total_required))
                raise InsufficientBalanceError(
                    f"Insufficient balance. Required: {required_ton:.6f} TON, "
                    f"Available: {current_balance.balance_ton:.6f} TON"
                )
            
            amount_ton = nano_to_ton(amount_nano)
            
            missing_padding = len(raw_boc) % 4
            if missing_padding != 0:
                raw_boc = raw_boc + '=' * (4 - missing_padding)
            
            boc_bytes = base64.b64decode(raw_boc)
            cell = Cell.one_from_boc(boc_bytes)
            
            tx_hash = await wallet.transfer(
                destination=dest_address,
                amount=amount_ton,
                body=cell
            )
            
            logger.info(f"Transaction sent: {tx_hash}")
            return tx_hash
        
        except InsufficientBalanceError:
            raise
        except Exception as e:
            logger.error(f"Transaction error: {e}")
            raise TransactionError(f"Transaction failed: {e}")

    def send_transaction_sync(self, dest_address: str, amount_nano: str, raw_boc: str) -> str:
        import asyncio
        
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            tx_hash = loop.run_until_complete(
                self.send_transaction(dest_address, amount_nano, raw_boc)
            )
            loop.close()
            return tx_hash
        except (TransactionError, InsufficientBalanceError):
            raise
        except Exception as e:
            raise TransactionError(f"Failed to send transaction: {e}")

    async def transfer_ton(self, to_address: str, amount_ton: float, memo: Optional[str] = None) -> TransferResult:
        try:
            from tonutils.client import TonapiClient
            from tonutils.wallet import WalletV4R2
            from pytoniq_core import begin_cell
            
            if not to_address or not isinstance(to_address, str):
                raise WalletError("Invalid destination address")
            
            if amount_ton <= 0:
                raise WalletError("Amount must be greater than 0")
            
            client = TonapiClient(api_key=self.wallet_api_key, is_testnet=False)
            
            wallet_tuple = WalletV4R2.from_mnemonic(client, self.wallet_mnemonic)
            wallet = wallet_tuple[0] if isinstance(wallet_tuple, tuple) else wallet_tuple
            
            sender_address = wallet.address.to_str(is_user_friendly=True)
            
            current_balance = await self.get_balance()
            required = amount_ton + self.TRANSFER_FEE_TON
            
            if current_balance.balance_ton < required:
                raise InsufficientBalanceError(
                    f"Insufficient balance. Required: ~{required:.4f} TON (including fee), "
                    f"Available: {current_balance.balance_ton:.4f} TON"
                )
            
            body = None
            if memo:
                body = (
                    begin_cell()
                    .store_uint(0, 32)
                    .store_snake_string(memo)
                    .end_cell()
                )
            
            tx_hash = await wallet.transfer(
                destination=to_address,
                amount=amount_ton,
                body=body
            )
            
            logger.info(f"TON transfer sent: {tx_hash}")
            
            return TransferResult(
                success=True,
                transaction_hash=tx_hash,
                from_address=sender_address,
                to_address=to_address,
                amount_ton=amount_ton,
                balance_before=current_balance.balance_ton,
                memo=memo
            )
        
        except InsufficientBalanceError:
            raise
        except WalletError:
            raise
        except Exception as e:
            logger.error(f"TON transfer error: {e}")
            raise TransactionError(f"TON transfer failed: {e}")

    def transfer_ton_sync(self, to_address: str, amount_ton: float, memo: Optional[str] = None) -> TransferResult:
        import asyncio
        
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(
                self.transfer_ton(to_address, amount_ton, memo)
            )
            loop.close()
            return result
        except (TransactionError, InsufficientBalanceError, WalletError):
            raise
        except Exception as e:
            raise TransactionError(f"Failed to transfer TON: {e}")