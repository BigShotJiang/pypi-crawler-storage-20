# CLI package for speculate
