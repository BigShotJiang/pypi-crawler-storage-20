import os

# Base template for blog pages
base_template = '''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="{description}">
  <title>{title} - CloudFlow Blog</title>
  <link rel="stylesheet" href="../../css/main.css">
</head>
<body>
  <header>
    <div class="header-container">
      <a href="../../index.html" class="logo">
        <svg class="logo-icon" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="32" height="32" rx="8" fill="currentColor"/>
          <path d="M16 8L24 16L16 24L8 16L16 8Z" fill="white"/>
        </svg>
        CloudFlow
      </a>
      <nav class="nav-menu">
        <a href="../../index.html" class="nav-link">Home</a>
        <a href="../about.html" class="nav-link">About</a>
        <a href="../features.html" class="nav-link">Features</a>
        <a href="../pricing.html" class="nav-link">Pricing</a>
        <a href="../product/overview.html" class="nav-link">Product</a>
        <a href="../industries/healthcare.html" class="nav-link">Industries</a>
        <a href="../resources.html" class="nav-link">Resources</a>
        <a href="../contact.html" class="nav-cta">Get Started</a>
      </nav>
      <div class="mobile-toggle"><span></span><span></span><span></span></div>
    </div>
    <div class="mobile-overlay"></div>
    <div class="mobile-menu">
      <a href="../../index.html" class="nav-link">Home</a>
      <a href="../about.html" class="nav-link">About</a>
      <a href="../features.html" class="nav-link">Features</a>
      <a href="../pricing.html" class="nav-link">Pricing</a>
      <a href="../product/overview.html" class="nav-link">Product</a>
      <a href="../industries/healthcare.html" class="nav-link">Industries</a>
      <a href="../resources.html" class="nav-link">Resources</a>
      <a href="../contact.html" class="nav-cta">Get Started</a>
    </div>
  </header>

  <main>
    <section class="section" style="background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%); color: white; padding: var(--space-20) 0;">
      <div class="container text-center">
        <h1 style="color: white; margin-bottom: var(--space-4);">{hero_title}</h1>
        <p style="font-size: var(--text-xl); max-width: 700px; margin: 0 auto; opacity: 0.9;">{hero_subtitle}</p>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="grid grid-cols-3 gap-8">
          <div class="card">
            <span class="badge badge-primary" style="margin-bottom: var(--space-2);">Automation</span>
            <h3 class="card-title">Getting Started with Workflow Automation</h3>
            <p class="card-content">Learn the basics of workflow automation and how CloudFlow can help your team.</p>
            <a href="#" class="btn btn-outline" style="margin-top: var(--space-4);">Read More</a>
          </div>
          <div class="card">
            <span class="badge badge-secondary" style="margin-bottom: var(--space-2);">Productivity</span>
            <h3 class="card-title">10 Ways to Boost Team Productivity</h3>
            <p class="card-content">Discover practical tips to increase your team's efficiency with automation.</p>
            <a href="#" class="btn btn-outline" style="margin-top: var(--space-4);">Read More</a>
          </div>
          <div class="card">
            <span class="badge badge-primary" style="margin-bottom: var(--space-2);">Integrations</span>
            <h3 class="card-title">Top 5 CloudFlow Integrations</h3>
            <p class="card-content">Explore the most popular integrations and how to use them effectively.</p>
            <a href="#" class="btn btn-outline" style="margin-top: var(--space-4);">Read More</a>
          </div>
        </div>
      </div>
    </section>
  </main>

  <footer>
    <div class="container">
      <div class="footer-grid">
        <div class="footer-column">
          <h4>Product</h4>
          <ul class="footer-links">
            <li><a href="../product/overview.html">Overview</a></li>
            <li><a href="../product/automation.html">Automation</a></li>
          </ul>
        </div>
        <div class="footer-column">
          <h4>Company</h4>
          <ul class="footer-links">
            <li><a href="../about.html">About Us</a></li>
            <li><a href="../contact.html">Contact</a></li>
          </ul>
        </div>
        <div class="footer-column">
          <h4>Stay Updated</h4>
          <form id="newsletter-form" style="display: flex; gap: 0.5rem;">
            <input type="email" placeholder="Enter your email" class="form-input" style="flex: 1;" required>
            <button type="submit" class="btn btn-primary">Subscribe</button>
          </form>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2024 CloudFlow. All rights reserved.</p>
      </div>
    </div>
  </footer>

  <script type="module" src="../../js/main.js"></script>
</body>
</html>'''

# Blog pages to generate
blog_pages = {
    'index.html': {
        'title': 'Blog',
        'description': 'Latest news and updates from CloudFlow',
        'hero_title': 'CloudFlow Blog',
        'hero_subtitle': 'Insights, tips, and updates on workflow automation'
    },
    'category-automation.html': {
        'title': 'Automation Articles',
        'description': 'Articles about workflow automation',
        'hero_title': 'Automation',
        'hero_subtitle': 'Everything about workflow automation'
    },
    'category-productivity.html': {
        'title': 'Productivity Tips',
        'description': 'Productivity tips and tricks',
        'hero_title': 'Productivity',
        'hero_subtitle': 'Boost your productivity with automation'
    },
    'category-integrations.html': {
        'title': 'Integration Guides',
        'description': 'Guides for CloudFlow integrations',
        'hero_title': 'Integrations',
        'hero_subtitle': 'Learn about CloudFlow integrations'
    },
    'post-1.html': {
        'title': 'Getting Started with Workflow Automation',
        'description': 'Learn the basics of workflow automation',
        'hero_title': 'Getting Started with Workflow Automation',
        'hero_subtitle': 'A beginner\'s guide to automating your workflows'
    }
}

# Generate blog pages
for filename, data in blog_pages.items():
    filepath = f'pages/blog/{filename}'
    content = base_template.format(**data)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f'Created blog/{filename}')

print('\nAll blog pages created successfully!')
