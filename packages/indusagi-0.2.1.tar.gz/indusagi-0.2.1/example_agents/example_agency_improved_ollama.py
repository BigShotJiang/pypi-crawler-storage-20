"""
Improved Agency Setup - Dynamic AI-Controlled Routing with Ollama Provider

Based on Agency-Code architecture using Ollama Provider (GLM-4.7 via Ollama Cloud):
- Coder agent is the entry point (receives all user requests)
- Coder intelligently decides when to handoff to Planner
- Planner creates detailed plans and hands back to Coder
- No separate router needed - intelligence is in the instructions
- Uses GLM-4.7 via Ollama Cloud API

Usage:
    python example_agency_improved_ollama.py
"""

import os
from typing import Optional, List, Dict, Any
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

from indusagi import Agent, AgentConfig, Agency
from indusagi.tools import Bash, Read, Edit, Write, Glob, Grep, TodoWrite
from indusagi.tools import handoff_to_agent, set_current_agency, registry
from indusagi.hooks import SystemReminderHook, CompositeHook

# Rich imports for beautiful terminal output
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

# Initialize Rich console
console = Console()

# ============================================================================
# Agent Factory Functions (Improved Instructions)
# ============================================================================

def create_planner_agent(model: str = "glm-4.7", reasoning_effort: str = "medium") -> Agent:
    """
    Strategic Planner Agent - Creates detailed implementation plans.
    Uses Ollama provider (GLM-4.7 via Ollama Cloud).

    Loads prompt from markdown file for better maintainability.
    """
    config = AgentConfig(
        model=model,
        provider="ollama",
        temperature=0.7,
        max_tokens=16000,  # Increased for comprehensive plan generation
    )

    # Get the directory containing this script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    prompt_dir = os.path.join(current_dir, "example_agency_improved_ollama_prompts")
    prompt_file = os.path.join(prompt_dir, "planner_instructions.md")

    agent = Agent(
        name="Planner",
        role="Strategic planning and task breakdown specialist",
        config=config,
        prompt_file=prompt_file  # ✅ Load from .md file
    )

    return agent


def create_coder_agent(model: str = "glm-4.7", reasoning_effort: str = "medium") -> Agent:
    """
    Coder Agent - Entry point with intelligent handoff to Planner.
    Uses Ollama provider (GLM-4.7 via Ollama Cloud).

    Loads prompt from markdown file for better maintainability.
    """
    config = AgentConfig(
        model=model,
        provider="ollama",
        temperature=0.5,
        max_tokens=8000,  # Increased for complex implementations
    )

    # Get the directory containing this script
    current_dir = os.path.dirname(os.path.abspath(__file__))
    prompt_dir = os.path.join(current_dir, "example_agency_improved_ollama_prompts")
    prompt_file = os.path.join(prompt_dir, "coder_instructions.md")

    agent = Agent(
        name="Coder",
        role="Code implementation and execution",
        config=config,
        prompt_file=prompt_file  # ✅ Load from .md file
    )

    return agent


# ============================================================================
# Agency Setup
# ============================================================================

def create_development_agency(
    model: str = "glm-4.7",
    reasoning_effort: str = "medium",
    max_handoffs: int = 100,
    max_turns: Optional[int] = None
) -> Agency:
    """
    Create development agency with intelligent routing using Ollama provider.

    Architecture:
    - Entry: Coder (receives all requests)
    - Coder decides when to handoff to Planner
    - Planner creates plans and hands back to Coder
    - Bidirectional communication flows
    - All agents use GLM-4.7 via Ollama Cloud API

    Args:
        model: LLM model to use (default: "glm-4.7")
        reasoning_effort: Reasoning effort level (default: "medium")
        max_handoffs: Maximum number of handoffs allowed (default: 100)
        max_turns: Max tool-calling iterations per agent. None uses 1000 (default: None)
    """
    # Register tools in global registry
    for tool_class in [Bash, Read, Edit, Write, Glob, Grep, TodoWrite]:
        registry.register(tool_class)

    # Create agents with Ollama provider
    coder = create_coder_agent(model=model, reasoning_effort=reasoning_effort)
    coder.context = registry.context

    planner = create_planner_agent(model=model, reasoning_effort=reasoning_effort)
    planner.context = registry.context

    # Get tool schemas and add handoff schema
    tools = registry.schemas.copy()
    handoff_schema = {
        "type": "function",
        "function": {
            "name": "handoff_to_agent",
            "description": "Hand off the current task to another agent in the agency",
            "parameters": {
                "type": "object",
                "properties": {
                    "agent_name": {
                        "type": "string",
                        "description": "Name of the agent to hand off to (e.g., 'Planner', 'Coder')"
                    },
                    "message": {
                        "type": "string",
                        "description": "Message or task description for the target agent"
                    },
                    "context": {
                        "type": "string",
                        "description": "Optional context or additional information"
                    }
                },
                "required": ["agent_name", "message"]
            }
        }
    }
    tools.append(handoff_schema)

    # Create agency with Coder as entry point (receives all user requests)
    agency = Agency(
        entry_agent=coder,  # ✅ Coder is entry - it decides when to use Planner
        agents=[coder, planner],
        communication_flows=[
            (coder, planner),    # Coder can handoff to Planner
            (planner, coder),    # Planner hands back to Coder
        ],
        shared_instructions=None,
        name="DevAgency_Ollama",
        max_handoffs=max_handoffs,
        max_turns=max_turns,  # ✅ Uses provided max_turns or 1000 if None
        tools=tools,
        tool_executor=registry
    )

    # Set current agency for handoff tools
    set_current_agency(agency)

    return agency


# ============================================================================
# Display Functions (Mini Agent Style)
# ============================================================================

def print_agency_banner():
    """Display agency banner in Mini Agent style."""
    banner_text = "[bold bright_cyan]Indus Agents - Multi-Agent System[/bold bright_cyan]\n\n"
    banner_text += "[yellow]Dynamic AI-Controlled Routing: Coder <-> Planner[/yellow]\n"
    banner_text += "[dim]Provider: Ollama (GLM-4.7 via Ollama Cloud)[/dim]"

    console.print()
    console.print(Panel(
        banner_text,
        box=box.DOUBLE_EDGE,
        border_style="bright_cyan",
        padding=(1, 2),
        width=70,
    ))
    console.print()


def print_workflow_explanation():
    """Display workflow explanation."""
    workflow = """[bold cyan]How it works:[/bold cyan]

  [green]1.[/green] You talk to [bright_blue]Coder[/bright_blue] (entry agent)
  [green]2.[/green] Coder decides: simple task = handle directly
  [green]3.[/green]              : complex task = handoff to [bright_blue]Planner[/bright_blue]
  [green]4.[/green] Planner creates plan.md -> hands back to [bright_blue]Coder[/bright_blue]
  [green]5.[/green] Coder reads plan.md and implements
"""

    console.print(Panel(
        workflow,
        box=box.ROUNDED,
        border_style="cyan",
        padding=(1, 2),
        width=70,
    ))
    console.print()


def print_agency_config(agency):
    """Display agency configuration in table."""
    config_table = Table.grid(padding=(0, 2))
    config_table.add_column(style="cyan", justify="left", width=20)
    config_table.add_column(style="white", justify="left")

    config_table.add_row("Agency:", agency.name)
    config_table.add_row("Entry Agent:", f"[bright_blue]{agency.entry_agent.name}[/bright_blue] (smart router)")
    config_table.add_row("Total Agents:", str(len(agency.agents)))
    config_table.add_row("Provider:", agency.entry_agent.provider.get_provider_name())
    config_table.add_row("Model:", agency.entry_agent.config.model)

    console.print(Panel(
        config_table,
        title="[bright_cyan]Agency Configuration[/bright_cyan]",
        box=box.ROUNDED,
        border_style="bright_cyan",
        padding=(1, 2),
    ))
    console.print()


def print_example_prompts():
    """Display example prompts."""
    examples = """[bold yellow]Simple tasks (Coder handles directly):[/bold yellow]
  [green]-[/green] "Create a hello world HTML page"
  [green]-[/green] "Create a simple calculator with HTML/CSS/JS"

[bold yellow]Complex tasks (Coder -> Planner -> Coder):[/bold yellow]
  [green]-[/green] "Create plan.md for a todo app, then implement it"
  [green]-[/green] "Plan and build a weather dashboard with API integration"
  [green]-[/green] "I need a multi-page website. First create plan.md"
"""

    console.print(Panel(
        examples,
        title="[bright_cyan]Example Prompts[/bright_cyan]",
        box=box.ROUNDED,
        border_style="yellow",
        padding=(1, 2),
    ))
    console.print()


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    """
    Main entry point - improved agency with dynamic routing using Ollama.
    """
    # Check for API key
    if not os.getenv("OLLAMA_API_KEY"):
        console.print(Panel(
            "[red]Error: OLLAMA_API_KEY not set in environment[/red]\n\n"
            "Please set it in .env file or with:\n"
            "export OLLAMA_API_KEY='your-key-here'",
            title="[red]Configuration Error[/red]",
            border_style="red",
            box=box.ROUNDED,
        ))
        return

    # Display banner and workflow
    print_agency_banner()
    print_workflow_explanation()

    # Create agency with GLM-4.7 (via Ollama Cloud API)
    console.print("[cyan]Creating development agency...[/cyan]")
    agency = create_development_agency(
        model="glm-4.7",  # ✅ GLM-4.7 via Ollama Cloud API
        reasoning_effort="medium",
        max_handoffs=100
        # max_turns=None uses 1000 as default (increased from 100)
    )

    # Display configuration
    print_agency_config(agency)

    # Show flows
    console.print(Panel(
        "[bold]Communication Flows:[/bold]",
        box=box.ROUNDED,
        border_style="dim",
    ))
    agency.visualize()
    console.print()

    # Show examples
    print_example_prompts()

    # Run terminal demo
    console.print(Panel(
        "[cyan]Starting interactive demo...[/cyan]\n\n"
        "[dim]Commands: /quit, /agents, /handoffs, /logs, /stats[/dim]",
        box=box.ROUNDED,
        border_style="green",
    ))
    console.print()

    try:
        agency.terminal_demo(show_reasoning=False)
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Interrupted by user. Exiting...[/yellow]")
    except Exception as e:
        console.print(Panel(
            f"[red]{str(e)}[/red]",
            title="[red]Error[/red]",
            border_style="red",
            box=box.ROUNDED,
        ))
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
