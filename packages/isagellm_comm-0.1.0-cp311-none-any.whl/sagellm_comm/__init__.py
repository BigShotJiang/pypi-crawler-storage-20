"""sagellm-comm: Communication Layer for sageLLM distributed inference."""

from __future__ import annotations

__version__ = "0.1.0"

# Public API will be defined here after Task1.1-1.5 implementation
# Expected exports:
# - CommGroup
# - Topology
# - CollectiveOp
# - KVTransfer

__all__ = [
    "__version__",
]
