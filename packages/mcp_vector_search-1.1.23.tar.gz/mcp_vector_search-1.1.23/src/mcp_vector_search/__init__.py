"""MCP Vector Search - CLI-first semantic code search with MCP integration."""

__version__ = "1.1.23"
__build__ = "123"
__author__ = "Robert Matsuoka"
__email__ = "bob@matsuoka.com"

from .core.exceptions import MCPVectorSearchError

__all__ = ["MCPVectorSearchError", "__version__", "__build__"]
