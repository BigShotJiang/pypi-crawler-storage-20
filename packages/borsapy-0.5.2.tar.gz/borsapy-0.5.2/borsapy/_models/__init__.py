"""Data models for borsapy."""
