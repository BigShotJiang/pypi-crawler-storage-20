"""Journeys command - list and manage journeys."""

import asyncio
from datetime import datetime

import httpx
import typer
from rich.console import Console
from rich.table import Table

from terryann_cli.config import load_config

console = Console()


def _parse_datetime(dt_str: str) -> datetime:
    """Parse ISO datetime string."""
    return datetime.fromisoformat(dt_str.replace("Z", "+00:00"))


def _format_relative_time(dt: datetime) -> str:
    """Format datetime as relative time (e.g., '2 hours ago')."""
    now = datetime.now(dt.tzinfo)
    delta = now - dt

    if delta.days > 0:
        return f"{delta.days}d ago"
    elif delta.seconds >= 3600:
        hours = delta.seconds // 3600
        return f"{hours}h ago"
    elif delta.seconds >= 60:
        minutes = delta.seconds // 60
        return f"{minutes}m ago"
    else:
        return "just now"


async def _fetch_journeys(gateway_url: str, limit: int = 20) -> dict:
    """Fetch journeys from gateway."""
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(
            f"{gateway_url}/gateway/journeys",
            params={"limit": limit},
        )
        response.raise_for_status()
        return response.json()


def list_journeys(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of journeys to show"),
):
    """List recent journeys."""
    config = load_config()

    try:
        data = asyncio.run(_fetch_journeys(config.gateway_url, limit))
    except httpx.ConnectError:
        console.print("[red]Error: Cannot connect to gateway.[/red]")
        raise typer.Exit(code=1)
    except httpx.HTTPStatusError as e:
        console.print(f"[red]Error: Gateway returned {e.response.status_code}[/red]")
        raise typer.Exit(code=1)

    journeys = data.get("journeys", [])

    if not journeys:
        console.print("[dim]No journeys found.[/dim]")
        return

    # Create table
    table = Table(title="Recent Journeys", show_header=True, header_style="bold magenta")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Status", style="green")
    table.add_column("Target", style="white")
    table.add_column("Touchpoints", justify="right")
    table.add_column("Created", style="dim")

    for j in journeys:
        journey_id = j["id"][:8]  # Short ID
        status = j.get("status", "draft")

        # Extract target from cohort_config or journey_data
        cohort = j.get("cohort_config", {})
        journey_data = j.get("journey_data", {}) or {}

        target = cohort.get("location", cohort.get("name", "—"))
        if not target or target == "—":
            # Try to get from journey_data
            target = journey_data.get("name", "—")

        # Get touchpoint count
        touchpoints = journey_data.get("touchpoints", [])
        tp_count = str(len(touchpoints)) if touchpoints else "—"

        # Format created time
        created_at = _parse_datetime(j["created_at"])
        created = _format_relative_time(created_at)

        # Color status
        status_display = {
            "draft": "[yellow]draft[/yellow]",
            "simulated": "[blue]simulated[/blue]",
            "approved": "[green]approved[/green]",
            "executing": "[cyan]executing[/cyan]",
        }.get(status, status)

        table.add_row(journey_id, status_display, target, tp_count, created)

    console.print(table)
    console.print(f"\n[dim]Total: {data.get('count', len(journeys))} journeys[/dim]")
