"""Core functionality for wtf."""
