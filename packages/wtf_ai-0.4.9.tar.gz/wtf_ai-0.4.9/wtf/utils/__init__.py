"""Utility functions for wtf."""
