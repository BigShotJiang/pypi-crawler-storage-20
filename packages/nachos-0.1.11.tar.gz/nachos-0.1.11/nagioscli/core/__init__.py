"""Core module for nagioscli."""
