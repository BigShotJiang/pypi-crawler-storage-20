"""Services module for nagioscli."""
