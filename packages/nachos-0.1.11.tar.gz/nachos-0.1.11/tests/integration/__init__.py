"""Integration tests for nagioscli."""
