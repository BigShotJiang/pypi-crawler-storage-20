"""Unit tests for nagioscli."""
