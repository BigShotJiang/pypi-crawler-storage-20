"""Tests for nagioscli."""
