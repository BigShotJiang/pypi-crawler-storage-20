"""Test fixtures for nagioscli."""
