"""Tests for ha-sync."""
