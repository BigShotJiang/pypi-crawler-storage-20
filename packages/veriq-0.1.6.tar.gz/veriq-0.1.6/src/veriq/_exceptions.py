class VeriqCLIEError(Exception):
    pass
