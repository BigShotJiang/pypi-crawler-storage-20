from pathlib import Path

from setuptools import find_packages, setup

PACKAGE_ROOT = Path(__file__).parent

# Reuse the single source of truth for the package version.
ABOUT_PATH = PACKAGE_ROOT / "src" / "envis" / "__about__.py"
ABOUT: dict = {}
exec(ABOUT_PATH.read_text(encoding="utf-8"), ABOUT)

README_PATH = PACKAGE_ROOT / "README.md"
LONG_DESCRIPTION = README_PATH.read_text(encoding="utf-8")

setup(
    name="envis",
    version=ABOUT["__version__"],
    description="Secure, simple, and powerful secret management.",
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    author="Umair Arham",
    author_email="contact@uarham.me",
    url="https://github.com/umairx25/envis",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",
        "termcolor>=2.3.0",
    ],
    include_package_data=True
)
