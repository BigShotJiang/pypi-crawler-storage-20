# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateVpnGatewayCertificateRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'certificate': 'CreateVpnGatewayCertificateRequestBodyContent'
    }

    attribute_map = {
        'certificate': 'certificate'
    }

    def __init__(self, certificate=None):
        r"""CreateVpnGatewayCertificateRequestBody

        The model defined in huaweicloud sdk

        :param certificate: 
        :type certificate: :class:`huaweicloudsdkvpn.v5.CreateVpnGatewayCertificateRequestBodyContent`
        """
        
        

        self._certificate = None
        self.discriminator = None

        self.certificate = certificate

    @property
    def certificate(self):
        r"""Gets the certificate of this CreateVpnGatewayCertificateRequestBody.

        :return: The certificate of this CreateVpnGatewayCertificateRequestBody.
        :rtype: :class:`huaweicloudsdkvpn.v5.CreateVpnGatewayCertificateRequestBodyContent`
        """
        return self._certificate

    @certificate.setter
    def certificate(self, certificate):
        r"""Sets the certificate of this CreateVpnGatewayCertificateRequestBody.

        :param certificate: The certificate of this CreateVpnGatewayCertificateRequestBody.
        :type certificate: :class:`huaweicloudsdkvpn.v5.CreateVpnGatewayCertificateRequestBodyContent`
        """
        self._certificate = certificate

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateVpnGatewayCertificateRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
