# HW Logging

A small package for managing log setup across HW Animation Tech projects.

## Installation

With uv:

```bash
uv add hw-logging
```

Or with pip:

```bash
pip install hw-logging
```

## Usage

### Basic Setup

```python
from pathlib import Path
import hw_logging

log_file = Path.home() / ".my-app" / "app.log"
hw_logging.setup_logging(log_file=log_file, log_level="INFO")

# Now use standard logging
import logging
logger = logging.getLogger(__name__)
logger.info("Application started")
```
