# Copyright (C) 2025 Henrik Wilhelmsen.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at <https://mozilla.org/MPL/2.0/>.

import logging
import logging.config
from enum import StrEnum
from pathlib import Path


class LogLevels(StrEnum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


def setup_logging(log_file: Path, log_level: LogLevels) -> None:
    """Set up logging to stdout and file."""
    log_file.parent.mkdir(parents=True, exist_ok=True)
    log_file.touch(exist_ok=True)

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "simple": {
                "format": "%(levelname)s: %(message)s",
            },
            "detailed": {
                "format": "%(asctime)s [%(levelname)s] | %(pathname)s | L%(lineno)d: %(message)s",  # noqa: E501
            },
        },
        "handlers": {
            "stdout": {
                "class": "logging.StreamHandler",
                "level": log_level,
                "formatter": "simple",
                "stream": "ext://sys.stdout",
            },
            "file": {
                "class": "logging.handlers.RotatingFileHandler",
                "level": log_level,
                "formatter": "detailed",
                "filename": log_file.as_posix(),
                "maxBytes": 10000000,
                "backupCount": 3,
                "encoding": "utf-8",
            },
        },
        "loggers": {"root": {"level": log_level, "handlers": ["stdout", "file"]}},
    }

    logging.config.dictConfig(logging_config)
