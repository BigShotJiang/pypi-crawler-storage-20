from setuptools import setup, find_packages

setup(
    name="codepacker",
    version="9.9.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "codepacker=moonspic_codepacker.logic:start",
        ],
    },
)
