import os, hashlib, json, uuid, zipfile, shutil, io, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import random

class MoonspicCore:
    def __init__(self):
        self.code_exts = {'.py', '.txt', '.js', '.html', '.css', '.json', '.sh', '.md', '.yaml', '.xml', '.c', '.cpp', '.h'}
        self.delimiter = "#MOONSPIC_CODEPACKER#"

    def get_sha512(self, data):
        return hashlib.sha512(data if isinstance(data, bytes) else data.encode()).hexdigest()

    def pack(self, src_path, out_dir):
        src, out = Path(src_path).resolve(), Path(out_dir).resolve()
        stage = out / f"STAGE_{uuid.uuid4().hex[:6]}"
        stage.mkdir(parents=True, exist_ok=True)
        meta = {"project_name": src.name, "files": {}, "delimiter": self.delimiter}
        code_blocks = []
        assets_buffer = io.BytesIO()
        with zipfile.ZipFile(assets_buffer, 'w') as az:
            for r, _, files in os.walk(src):
                for f in files:
                    fp = Path(r) / f
                    rel = str(fp.relative_to(src))
                    f_id = str(uuid.uuid4())[:8]
                    raw_data = fp.read_bytes()
                    if fp.suffix.lower() in self.code_exts:
                        content = raw_data.decode('utf-8', errors='ignore')
                        code_blocks.append(f"{self.delimiter} {f_id};{rel}\n{content}")
                    else:
                        az.write(fp, rel)
        (stage / "CODE.txt").write_text("\n".join(code_blocks))
        (stage / "META.json").write_text(json.dumps(meta, indent=4))
        (stage / "Assets.zip").write_bytes(assets_buffer.getvalue())
        final_zip = out / f"{src.name}_BUNDLE.zip"
        with zipfile.ZipFile(final_zip, 'w') as fz:
            for f in ["CODE.txt", "META.json", "Assets.zip"]: fz.write(stage / f, f)
        shutil.rmtree(stage)
        return str(final_zip)

    def unpack(self, zip_path, target_dir):
        base_target = Path(target_dir).resolve()
        temp = base_target / "TEMP_UNPACK"
        if temp.exists(): shutil.rmtree(temp)
        temp.mkdir(parents=True, exist_ok=True)
        shutil.unpack_archive(zip_path, temp)
        meta = json.loads((temp / "META.json").read_text())
        proj_folder = meta.get("project_name", "restored_project")
        actual_dest = base_target / proj_folder
        if actual_dest.exists(): shutil.rmtree(actual_dest)
        actual_dest.mkdir(parents=True, exist_ok=True)
        if (temp / "Assets.zip").exists():
            with zipfile.ZipFile(temp / "Assets.zip", 'r') as az: az.extractall(actual_dest)
        if (temp / "CODE.txt").exists():
            parts = (temp / "CODE.txt").read_text().split(meta.get("delimiter", self.delimiter))
            for part in parts:
                if not part.strip() or ";" not in part: continue
                header, body = part.split("\n", 1)
                rel = header.strip().split(";")[1]
                out_f = actual_dest / rel.strip()
                out_f.parent.mkdir(parents=True, exist_ok=True)
                out_f.write_text(body.strip())
        shutil.rmtree(temp)
        return str(actual_dest)

    def calculate_content_hash(self, directory):
        hasher = hashlib.sha512()
        base = Path(directory).resolve()
        for fp in sorted([f for f in base.rglob('*') if f.is_file()]):
            hasher.update(str(fp.relative_to(base)).encode())
            hasher.update(fp.read_bytes())
        return hasher.hexdigest()

class GUI:
    def start(self):
        root = tk.Tk(); root.title("Moonspic v9.6.0"); root.geometry("800x650")
        core = MoonspicCore()
        nb = ttk.Notebook(root); nb.pack(expand=1, fill='both', padx=10, pady=10)
        t1, t2, t3, t4 = ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb)
        nb.add(t1, text=" Pack "); nb.add(t2, text=" Unpack "); nb.add(t3, text=" IntegrityMatch "); nb.add(t4, text=" Config ")
        # ... (Rest of GUI remains identical to your source)
        tk.Label(t4, text="MoonspicAI v9.7.0").pack(pady=20)
        root.mainloop()
        
def start():
    gui = GUI()
    gui.start()

