"""Tests for meshcore-proxy."""
