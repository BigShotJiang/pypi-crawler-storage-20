"""CLI unit tests."""
