from unittest.mock import MagicMock

from meili_sdk.clients.sdk_client import SDKClient
from meili_sdk.resources.forms import SDKFormResource
from tests.helpers import build_mocked_response

example_form = {
    "uuid": "e6a9741bd88d4e69bd5930010e9f4322",
    "name": "Vehicle form",
    "team": "7cf6aabb5116431fbab78efea4b783f0",
    "target_object": "vehicle",
    "variables": [
        {
            "uuid": "23cfba2de0264f03a024f759e57585a9",
            "name": "Is the vehicle autonomous?",
            "help_text": "Check if vehicle can work autonomously",
            "required": True,
            "sort_priority": 100,
            "variable": {
                "uuid": "e2e5878f2ed4466792e514a8f396e271",
                "organization": "287c54aeaa534b71bc2cfd7762018ba4",
                "name": "Autonomous",
                "variable_name": "autonomous",
                "variable_type": "boolean",
            },
        }
    ],
}

example_form_list = [example_form]

example_form_instance = {
    "entries": [
        {
            "value": 1,
            "variable_name": "count",
            "variable_type": "integer",
        }
    ]
}


class TestFormResource:
    def test_sdkform_retrieval(self, mocker):
        mocked: MagicMock = mocker.patch(
            "requests.get", return_value=build_mocked_response(example_form_list)
        )

        resource = SDKFormResource(SDKClient(""))
        status, form, raw_data, next_page = resource.get_forms(
            example_form["target_object"], example_form["uuid"]
        )

        assert mocked.called
        assert mocked.call_count == 1
        assert next_page is None
        assert raw_data is not None
        assert status == 200
        assert form[0].uuid == example_form["uuid"]
        assert form[0].name == example_form["name"]
        assert form[0].team == example_form["team"]
        assert form[0].target_object[0] == example_form["target_object"][0]

    def test_sdk_form_instance_retrieval(self, mocker):
        mocked: MagicMock = mocker.patch(
            "requests.get", return_value=build_mocked_response(example_form_instance)
        )
        resource = SDKFormResource(SDKClient(""))
        status, form, raw_data, next_page = resource.get_form_instance(
            example_form["target_object"], example_form["uuid"]
        )

        assert mocked.call_count == 1
        assert next_page is None
        assert raw_data is not None
        assert status == 200
        assert len(form.entries) == 1
