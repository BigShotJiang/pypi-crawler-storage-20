from meili_sdk.exceptions import MissingAttributesException, ValidationError
from meili_sdk.websockets import constants
from meili_sdk.websockets.models.message import Message


class TestMessage:
    def test_message_invalid_event(self):
        try:
            Message(event="invalid")
        except ValueError:
            assert True
        else:
            assert False, "Error not risen"

    def test_register_message_init(self):
        try:
            Message(event=constants.EVENT_CONNECT)
        except MissingAttributesException:
            assert True
        else:
            assert False, "Error not risen"

    def test_register_validation(self):
        message = Message(event=constants.EVENT_CONNECT, vehicles="1234")

        self.__do_failing_check(message)

        message = Message(event=constants.EVENT_CONNECT, vehicles=["1234"])
        message.validate()

    def test_location_validation(self):
        message = Message(
            event=constants.EVENT_LOCATION, vehicle="1234", value={"x": 123, "y": 312}
        )
        message.validate()

        message.value = {"xm": 12, "y": 3}
        self.__do_failing_check(message)

    def test_speed_validation(self):
        message = Message(
            event=constants.EVENT_SPEED, vehicle="1234", value={"speed": 0.5}
        )
        message.validate()

        message.value = {"speed_": 0.5}
        self.__do_failing_check(message)

    def test_goal_status_validation(self):
        message = Message(
            event=constants.EVENT_GOAL_STATUS,
            vehicle="1234",
            value={"status_id": 3, "goal_id": 23},
        )
        message.validate()
        message.value = {"goal_id": 1}
        self.__do_failing_check(message)

    def test_notification_validation(self):
        message = Message(
            event=constants.EVENT_NOTIFICATION,
            vehicle="1234",
            value={"message": "test", "level": "info"},
        )
        message.validate()

        # Test with error level
        message_2 = Message(
            event=constants.EVENT_NOTIFICATION,
            vehicle="1234",
            value={"message": "test", "level": "error"},
        )
        message_2.value = {"message": "test", "level": "error"}
        message_2.validate()

        # Test with wrong message length (more than 255 characters)
        message.value = {"message": "test" * 100, "level": "info"}

        self.__do_failing_check(message)

        message.value = {"message": "test"}
        self.__do_failing_check(message)

        message.value = {"level": "info"}
        self.__do_failing_check(message)

        message.value = {"level": "info", "message": 1234}
        self.__do_failing_check(message)

        message.value = {"level": "info", "message": "a" * 256}
        self.__do_failing_check(message)

    def test_topic_list_validation(self):
        tests = (
            ([{"topic": "123", "messageType": 123}], True),
            ({"topic": "123", "messageType": 123}, False),
            (["topic"], False),
            ([{"topic": "123", "messageTypie": 123}], False),
        )
        message = Message(event=constants.EVENT_TOPICS_LIST, vehicle="1234", value={})
        for data, is_correct in tests:
            message.value = data
            if is_correct:
                message.validate()
            else:
                self.__do_failing_check(message)

    def test_path_validation(self):
        path = [
            [-3.9999999552965164, -7.749999959021807],
            [-4.000014641881208, -7.709340435405679],
            [-4.0000216990712545, -7.68434043503315],
            [-4.0000310450796945, -7.659340434660621],
            [-4.000042489171662, -7.634340434288092],
            [-4.0000571757563534, -7.609340433915563],
            [-4.000074532629171, -7.5843404335430336],
            [-4.00009570419931, -7.5593404331705045],
            [-4.000120499731906, -7.5343404327979755],
            [-4.000149491431557, -7.5093404324254465],
            [-4.000182679298263, -7.484340432052917],
            [-4.000220826271487, -7.4593406224152545],
            [-4.000263550881499, -7.4343406220427255],
            [-4.000311806802628, -7.4093406216701965],
            [-4.000365212565143, -7.384340621297667],
            [-4.000424531108507, -7.3593408116600045],
            [-4.000489571697855, -7.3343408112874755],
            [-4.0005610972726515, -7.309341001649813],
            [-4.0006383448934315, -7.284341001277284],
            [-4.000722458969392, -7.259341382374487],
            [-4.000812867295934, -7.234341382001958],
            [-4.00091052354739, -7.209341381629429],
            [-4.001014664784293, -7.184341762726632],
            [-4.001126244680975, -7.159342143823835],
            [-4.001244500297972, -7.134342143451306],
            [-4.001370576044479, -7.109342524548509],
            [-4.001503518246167, -7.084342905645713],
            [-4.0016444713122326, -7.059343286742916],
            [-4.001792481568344, -7.034343667840119],
            [-3.9996312648003, -7.009437509021723],
            [-3.9974782496314987, -6.98453020579413],
            [-3.995311883022069, -6.959624428445466],
            [-3.9931489496402293, -6.934717888157337],
            [-3.990970948203966, -6.90981325521787],
            [-3.988793328237435, -6.88490824080867],
            [-3.9866000680118816, -6.860004370808667],
            [-3.984404709702801, -6.835101263748129],
            [-3.982193520399832, -6.810198919627055],
            [-3.979978516399541, -6.785297338445446],
            [-3.9777480628750936, -6.7603972831427654],
            [-3.9755130317138594, -6.735497227840085],
            [-3.9732629324982014, -6.710598698416334],
            [-3.9710080649108903, -6.685700550462315],
            [-3.96873889220862, -6.6608039283872245],
            [-3.9664649511346965, -6.635907306312134],
            [-3.9641778493550106, -6.611012210115973],
            [-3.96188655140827, -6.586117495389544],
            [-3.9595830464300974, -6.561223925072312],
            [-3.9572759174894685, -6.53633035475508],
            [-3.9549581073963367, -6.511438310316777],
            [-3.9526378177499453, -6.486546265878474],
            [-3.9503078006253816, -6.461654984379635],
            [-3.947976448356755, -6.436763702880796],
            [-3.945636894488885, -6.411873565791154],
            [-3.943296959151283, -6.386983428701512],
            [-3.9409505388282327, -6.362093673081603],
            [-3.938604881444647, -6.337203917461693],
            [-3.9362540742196757, -6.3123145433115155],
            [-3.9339046021387674, -6.287425169161338],
            [-3.931551887565135, -6.262536176480893],
            [-3.9279332656850414, -6.237799390223614],
            [-3.92516818233085, -6.212953122153181],
            [-3.923311569144005, -6.188022167802188],
            [-3.9219928282796275, -6.163056881175294],
            [-3.920030738711816, -6.1381339376886785],
            [-3.919201423513911, -6.11314767022651],
            [-3.9197425383291034, -6.088153391899965],
            [-3.9216880339635622, -6.063229304004153],
            [-3.9260724563311413, -6.038616876879587],
            [-3.9315639038617007, -6.014227228078653],
            [-3.9377315064926677, -5.990000085383656],
            [-3.9447640917415043, -5.966009453922652],
            [-3.951799919483065, -5.942019966870845],
            [-3.959386398783124, -5.918199089440691],
            [-3.9668849493099003, -5.8943499832503505],
            [-3.9748422171897033, -5.870650413195051],
            [-3.9828942802979697, -5.846982505127528],
            [-3.99135451601974, -5.823457648209597],
            [-3.9999999552965164, -5.799999929964542],
            [-4.0499999560415745, -5.749999929219484],
            [-4.0, -5.7],
        ]
        message = Message(
            event=constants.EVENT_PATH_DATA, vehicle="1234", value={"path": path}
        )
        message.validate()

        invalid_paths = [
            [[1, 3], [2]],
            ["2134"],
            [
                [23, 4],
                "123",
            ],
            "aaaa",
        ]

        for invalid_path in invalid_paths:
            message.value = {"path": invalid_path}
            self.__do_failing_check(message, invalid_path)

        message.value = {}
        self.__do_failing_check(message)

    def test_path_message_to_json(self):
        message = Message(
            event=constants.EVENT_PATH_DATA,
            vehicle="1234",
            value={"path": [[1, 3], [3, 4]]},
        )
        assert {
            "event": "path_data",
            "value": {"path": [[1, 3], [3, 4]]},
            "vehicle": "1234",
        } == dict(message)

    def test_docking_routine_message_to_json(self):
        message = Message(
            event=constants.EVENT_DOCKING_ROUTINE,
            vehicle="1234",
            value={"path": [[1, 2], [3, 4]]},
        )

        assert {
            "event": "docking_routine",
            "value": {"path": [[1, 2], [3, 4]]},
            "vehicle": "1234",
        } == dict(message)

    def test_dock_routine_message_validation(self):
        path = [[1, 2], [3, 4], [5, 6]]

        message = Message(
            event=constants.EVENT_DOCKING_ROUTINE, vehicle="1234", value={"path": path}
        )

        message.validate()

        invalid_paths = [
            [[1, 3], [2]],
            ["2134"],
            [
                [23, 4],
                "123",
            ],
            "aaaa",
        ]

        for invalid_path in invalid_paths:
            message.value = {"path": invalid_path}
            self.__do_failing_check(message, invalid_path)

        message.value = {}
        self.__do_failing_check(message)

    @staticmethod
    def __do_failing_check(message, d=None):
        try:
            message.validate()
        except ValidationError:
            assert True
        else:
            assert False, "Validation error not risen" + (
                f". With data={d}" if d else ""
            )
