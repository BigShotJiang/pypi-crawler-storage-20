from meili_sdk.mqtt.site import get_host


class TestMqttSite:
    def test_site_retrieval(self):
        host = get_host()
        assert host == "mqtt://mqtt.meilirobots.com"
