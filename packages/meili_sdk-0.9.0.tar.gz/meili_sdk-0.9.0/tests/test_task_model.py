from meili_sdk.models.task import Task


class TestTaskModel:
    def test_nested_initialization(self):
        data = {
            "subtasks": [
                {"location": "1234", "index": 1},
                {"location": "4321", "index": 2},
            ]
        }

        task = Task(**data)

        assert bool(task.subtasks)
        assert len(task.subtasks) == 2
