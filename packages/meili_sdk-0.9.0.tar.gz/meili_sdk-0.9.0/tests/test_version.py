from meili_sdk.version import VERSION


def test_version_returns_string():
    assert isinstance(VERSION, str), "Version returns a non-string value"
