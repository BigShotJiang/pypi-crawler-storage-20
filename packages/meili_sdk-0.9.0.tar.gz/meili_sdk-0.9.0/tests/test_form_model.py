from meili_sdk.exceptions import MissingAttributesException
from meili_sdk.models.form import Form, FormInstance

data = {
    "uuid": "e6a9741bd88d4e69bd5930010e9f4322",
    "name": "Vehicle form",
    "team": "7cf6aabb5116431fbab78efea4b783f0",
    "target_object": "vehicle",
    "variables": [],
}


class TestFormModel:
    def test_form_variable_exception(self):
        try:
            Form(**data)
        except MissingAttributesException as exc:
            assert exc is not None
        else:
            assert False, "Exception was not raised"

    def test_form_instance_variable_exception(self):
        try:
            FormInstance(**data)
        except MissingAttributesException as exc:
            assert exc is not None
        else:
            assert False, "Exception was not raised"

    def test_form_instance(self):
        data = {
            "entries": [
                {
                    "value": 1,
                    "variable_name": "var",
                    "variable_type": "integer",
                }
            ]
        }

        instance = FormInstance(**data)

        assert len(instance.entries) == 1
