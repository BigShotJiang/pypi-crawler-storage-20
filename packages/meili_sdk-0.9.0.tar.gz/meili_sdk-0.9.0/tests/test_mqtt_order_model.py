from meili_sdk.exceptions import MissingAttributesException
from meili_sdk.mqtt.models.order import (
    VDA5050ControlPoint,
    VDA5050Edge,
    VDA5050Node,
    VDA5050NodePosition,
    VDA5050OrderMessage,
)


class TestVDA5050OrderMessage:
    def test_initialization(self):
        data = {
            "headerId": 12,
            "version": "0.1.2",
            "manufacturer": "meili",
            "serialNumber": "1234",
            "orderId": "1234",
            "nodes": [
                {
                    "nodeId": 1,
                    "sequenceId": 1,
                    "description": "First node",
                    "released": True,
                    "nodePosition": {
                        "x": 1.2,
                        "y": 2.1,
                        "theta": 300,
                    },
                },
                VDA5050Node(
                    nodeId=2,
                    sequenceId=2,
                    description="Second node",
                    nodePosition=VDA5050NodePosition(x=1, y=2, theta=100),
                ),
            ],
            "edges": [
                {
                    "edgeId": 123,
                    "sequenceId": 1,
                    "endNodeId": 123,
                    "trajectory": {
                        "controlPoints": [
                            {
                                "x": 1,
                                "y": 2,
                            }
                        ]
                    },
                },
                VDA5050Edge(
                    edgeId=123,
                    sequenceId=1,
                    released=True,
                    endNodeId=123,
                    trajectory={
                        "controlPoints": [
                            VDA5050ControlPoint(
                                x=1,
                                y=2,
                            )
                        ]
                    },
                ),
            ],
        }

        order = VDA5050OrderMessage(**data)

        assert order.orderId == "1234"
        assert len(order.nodes) == 2
        assert len(order.edges) == 2
