import typing as t

from meili_sdk.exceptions import (
    MeiliException,
    MissingAttributesException,
    ValidationError,
)
from meili_sdk.models.base import BaseModel


class _TestModel(BaseModel):
    a: int
    b: t.Optional[int] = 2

    def validate_a(self):
        raise ValidationError("v1")

    def validate_b(self):
        raise ValidationError("v2")


class TestBaseModel:
    def test_missing_arguments(self):
        try:
            _TestModel()
        except MissingAttributesException as exc:
            assert exc is not None
        else:
            assert False, "Exception was not raised"

    def test_validation_called(self):
        tm = _TestModel(a=10)
        try:
            tm.validate()
        except MeiliException:
            assert True
        else:
            assert False, "Model validation not called"

    def test_ignore_not_set_attribute(self):
        m = _TestModel(a=12, c=12)
        assert m.a == 12, "Annotated parameter not set"
        assert getattr(m, "c", None) is None, "Non annotated parameter was set"

    def test_validation_errors_added(self):
        tm = _TestModel(a=10)

        try:
            tm.validate()
        except ValidationError as e:
            assert str(e) == "Validation error for a: v1\nValidation error for b: v2"
        else:
            assert False, "Validation was never called"
