class FleetEvents:
    """
    Events that can be sent via sdk from the fleet
    """

    CONNECT = "connect"
    CONNECTION_BROKEN = "connection_broken"
    DISCONNECT = "disconnect"
    LOCATION = "location"
    BATTERY = "batteryStatus"
    GOAL_STATUS = "goalStatus"
    TOPICS_LIST = "topics"
    TOPIC_DATA = "topic_data"
    PATH_DATA = "path_data"
    SPEED_DATA = "speed"
    STATE = "state"
    MAP_UPDATE = "map_update"
    NEW_MISSION = "new_mission"
    VEHICLE_LOADSET_DATA = "loads"  # Vehicle loadset data
    MAP_ID_UPDATE = "map_id_update"
    DOCKING_ROUTINE = "docking_routine"
    NOTIFICATION = "notification"

    ALL = (
        CONNECT,
        DISCONNECT,
        LOCATION,
        BATTERY,
        GOAL_STATUS,
        TOPICS_LIST,
        TOPIC_DATA,
        PATH_DATA,
        SPEED_DATA,
        STATE,
        MAP_UPDATE,
        NEW_MISSION,
        VEHICLE_LOADSET_DATA,
        MAP_ID_UPDATE,
        DOCKING_ROUTINE,
        NOTIFICATION,
    )


# TODO deprecate these constants in future releases and use FleetEvents directly
EVENT_DOCKING_ROUTINE = FleetEvents.DOCKING_ROUTINE
EVENT_CONNECT = FleetEvents.CONNECT
EVENT_LOCATION = FleetEvents.LOCATION
EVENT_SPEED = FleetEvents.SPEED_DATA
EVENT_BATTERY = FleetEvents.BATTERY
EVENT_GOAL_STATUS = FleetEvents.GOAL_STATUS
EVENT_NOTIFICATION = FleetEvents.NOTIFICATION
EVENT_TOPICS_LIST = FleetEvents.TOPICS_LIST
EVENT_TOPIC_DATA = FleetEvents.TOPIC_DATA
EVENT_PATH_DATA = FleetEvents.PATH_DATA
EVENT_STATE = FleetEvents.STATE
EVENT_MAP_UPDATE = FleetEvents.MAP_UPDATE
EVENT_NEW_MISSION = FleetEvents.NEW_MISSION
EVENT_VEHICLE_LOADSET_DATA = FleetEvents.VEHICLE_LOADSET_DATA


# Incoming actions
ACTION_DOCKING_ROUTINE_REQUEST = "docking_routine_request"
ACTION_DOCKING_ROUTINE_FINALIZE = "docking_routine_finalize_request"
ACTION_TASK_V2 = "taskv2"
ACTION_TASK_CANCELLATION = "cancelOrder"
ACTION_MOVE = "move"
ACTION_MOVE_TO_CHARGING_POINT = "move_charge"
ACTION_SLOW_DOWN = "slow_down"
ACTION_TOPIC_LIST = "request_topics"
ACTION_TOPIC_INITIALIZATION = "topic_init"
ACTION_ERROR = "errors"
ACTION_PATH_REROUTING = "path_rerouting"
ACTION_COLLISION_CLEARANCE = "clear_collision"
ACTION_UPDATE_MAP = "update_maps"
ACTION_UPDATE_VEHICLE_SETTINGS = "vehicle_settings"
ACTION_PAUSE_TASK = "startPause"
ACTION_RESUME_TASK = "stopPause"
ACTION_SET_INITIAL_POSITION = "set_initial_pose"
ACTION_UPDATE_MAP_ID = "update_map_id"

ALL_ACTIONS = (
    ACTION_DOCKING_ROUTINE_REQUEST,
    ACTION_DOCKING_ROUTINE_FINALIZE,
    ACTION_TASK_V2,
    ACTION_MOVE,
    ACTION_MOVE_TO_CHARGING_POINT,
    ACTION_SLOW_DOWN,
    ACTION_PATH_REROUTING,
    ACTION_TOPIC_LIST,
    ACTION_TOPIC_INITIALIZATION,
    ACTION_ERROR,
    ACTION_UPDATE_MAP,
    ACTION_UPDATE_VEHICLE_SETTINGS,
    ACTION_PAUSE_TASK,
    ACTION_RESUME_TASK,
    ACTION_SET_INITIAL_POSITION,
    ACTION_UPDATE_MAP_ID,
)

IGNORED_TYPES = (
    "initialized",
    "not_initialized",
)


class MapUpdateMessageStatuses:
    UPDATE = "update"
    CONFIRM = "confirm"


class FleetConsumerCodes:
    VERSION_INCOMPATIBLE = 4000
    INVALID_EVENT = 4001
    INVALID_TEAM = 4002
    INVALID_SITE = 4003

    ALL = (
        VERSION_INCOMPATIBLE,
        INVALID_EVENT,
        INVALID_TEAM,
        INVALID_SITE,
    )
    TEXT = {
        VERSION_INCOMPATIBLE: "Websocket version is incompatible with the server. "
        "Please update the meili-sdk library to the latest version.",
        INVALID_EVENT: "Invalid event type received from the server.",
        INVALID_TEAM: "Invalid team ID received from the server.",
        INVALID_SITE: "Invalid site ID received from the server.",
    }
