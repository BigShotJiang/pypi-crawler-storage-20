import logging
import re
import ssl
import time

import websocket

from meili_sdk.clients.base_meili_client import MeiliBaseClient
from meili_sdk.exceptions import (
    MeiliCriticalException,
    MeiliException,
    WebsocketException,
)
from meili_sdk.resources.base import BaseResource
from meili_sdk.version import VERSION
from meili_sdk.websockets import constants
from meili_sdk.websockets.models.message import Message

logger = logging.getLogger("meili_sdk")

__all__ = ("MeiliWebsocketClient",)


class MeiliWebsocketClient(MeiliBaseClient):
    """
    Client for all communication related with FMS through websockets
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._url = BaseResource.build_url(
            self._host, f"ws/{'fleets/' if self._fleet else 'vehicle/'}"
        )

    def get_headers(self) -> dict:
        return {
            "User-Agent": "Mozilla/5.0 (platform; rv:gecko-version) Gecko/gecko-trail Firefox/firefox-version",
            "x-meili-app-name": "sdk",
            "x-meili-app-version": VERSION,
            "x-meili-fleet-token": self.token,
        }

    def run(self, loop=False):
        self.reconnect()

        if loop:
            while True:
                if self.skip_tls:
                    self._connection.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})
                else:
                    self._connection.run_forever()
                time.sleep(2)

        else:
            self._connection.run_forever()

    def reconnect(self):
        if self._connection and isinstance(self._connection, websocket.WebSocketApp):
            self._connection.close()
        self._connection = websocket.WebSocketApp(
            self._url,
            on_close=self.__on_close,
            on_open=self.__on_open,
            on_message=self.on_message,
            on_error=self.on_error,
            header=self.get_headers(),
        )

    def __on_open(self, _):
        self._connection_is_open = True
        self.on_open()

    def __on_close(self, _, code, __):
        self._connection_is_open = False
        self.on_close()
        if code in constants.FleetConsumerCodes.ALL:
            self.on_error(
                self.__connection,
                MeiliCriticalException(
                    f"Connection closed with custom code {code}. ",
                    constants.FleetConsumerCodes.TEXT[code],
                ),
            )

    def on_error(self, connection, error):
        logger.warning(f"An error has occurred inside the websocket client: {error}")
        if self._error_handler:
            self._error_handler(connection, error)

    def send_raw(self, message, timeout=1):
        try:
            self._connection.send(message)
        except websocket.WebSocketException as e:
            logger.warning(f"Failed to send message due to {e}. Reconnecting...")
            self.reconnect()
            time.sleep(timeout)
            self.send_raw(message, timeout + 1)

    def process_message_error(self, message: dict):
        # Handle vehicle removal from fleet
        if (
            message["errors"]
            and "vehicle" in message["errors"]
            and message["errors"]["vehicle"][0]
        ):
            pattern = r"^Vehicle with UUID ([0-9a-fA-F]{32}) does not exist, or was removed from the fleet setup$"
            match = re.search(pattern, message["errors"]["vehicle"][0])
            logger.warning(f"{message['errors']['vehicle'][0]}")
            if match:
                logger.warning("Vehicle removal from fleet detected.")
                vehicle_to_remove_uuid = match.group(
                    1
                )  # Get the UUID from the error message
                self.process_remove_vehicle_from_fleet(vehicle_to_remove_uuid)
                return

        logger.warning(
            f"Validation failed for message with the following errors: {message}"
        )
        handler = getattr(self, "_MeiliBaseClient__message_error_handler", None)
        if handler:
            handler(message["errors"])


       

    def process_remove_vehicle_from_fleet(self, vehicle_uuid: str):
        if self.__remove_vehicle_from_fleet_handler and callable(
            self.__remove_vehicle_from_fleet_handler
        ):
            self.__remove_vehicle_from_fleet_handler(vehicle_uuid)

    def close_ws(self):
        logger.info("[MEILI_SDK] Force the Closing of WS")
        self._connection.close()
