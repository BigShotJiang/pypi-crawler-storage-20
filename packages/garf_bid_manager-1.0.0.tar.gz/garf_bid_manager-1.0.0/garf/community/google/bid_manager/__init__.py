# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import logging

from garf.community.google.bid_manager.api_clients import BidManagerApiClient
from garf.community.google.bid_manager.report_fetcher import (
  BidManagerApiReportFetcher,
)

__all__ = [
  'BidManagerApiClient',
  'BidManagerApiReportFetcher',
]

__version__ = '1.0.0'

logging.getLogger('googleapiclient.discovery_cache').setLevel(logging.ERROR)
logging.getLogger('google_auth_oauthlib.flow').setLevel(logging.ERROR)
