from .TernaryMAC import TernaryMAC
