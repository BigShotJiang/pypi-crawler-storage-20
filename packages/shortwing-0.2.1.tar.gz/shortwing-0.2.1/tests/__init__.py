"""Shortwing test suite."""
