"""Version information for llama-cpp-py-sync."""

__version__ = "0.7769"
__llama_cpp_commit__ = "bbcdac018"
__llama_cpp_tag__ = "b7769"
