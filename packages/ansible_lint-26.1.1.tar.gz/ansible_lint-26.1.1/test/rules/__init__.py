"""Tests for specific rules."""
