"""Tests the yaml module"""
