print("a")


print("b")
