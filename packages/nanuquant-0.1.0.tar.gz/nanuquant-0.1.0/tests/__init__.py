"""Tests for nanuquant."""
