class InvalidAttributeNameError(Exception):
    pass
