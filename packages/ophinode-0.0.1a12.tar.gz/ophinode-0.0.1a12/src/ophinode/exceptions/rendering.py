class NonRenderableNodeError(Exception):
    pass
