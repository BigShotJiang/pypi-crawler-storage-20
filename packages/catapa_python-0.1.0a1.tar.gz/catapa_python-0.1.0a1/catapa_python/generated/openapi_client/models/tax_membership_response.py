# coding: utf-8

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  ## Python ```bash pip install requests ```  ```python import requests from requests.auth import HTTPBasicAuth  base_url = \"https://api.catapa.com\" tenant = \"zfrl\" client_id = \"test-client-id\" client_secret = \"test-client-secret\"  # Get access token token_data = requests.post(     f\"{base_url}/oauth/token\",     headers={\"Tenant\": tenant},     data={\"grant_type\": \"client_credentials\"},     auth=HTTPBasicAuth(client_id, client_secret) ) access_token = token_data.json()[\"access_token\"]  # Get company company = requests.get(     f\"{base_url}/core/v1/companies\",     headers={\"Tenant\": tenant, \"Authorization\": f\"Bearer {access_token}\"} ) print(company.json()) ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr, field_validator
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing_extensions import Annotated
from openapi_client.models.tax_dependent_response import TaxDependentResponse
from openapi_client.models.tax_membership_period_response import TaxMembershipPeriodResponse
from typing import Optional, Set
from typing_extensions import Self

class TaxMembershipResponse(BaseModel):
    """
    TaxMembershipResponse
    """ # noqa: E501
    id: StrictStr = Field(description="Unique identifier for the tax membership")
    foreign_tax_object: StrictBool = Field(description="Whether this is a foreign tax object", alias="foreignTaxObject")
    kpp_id: StrictStr = Field(description="Tax office (KPP) identifier", alias="kppId")
    link_to_payroll: StrictBool = Field(description="Whether this tax membership is linked to payroll", alias="linkToPayroll")
    membership_end_period: TaxMembershipPeriodResponse = Field(alias="membershipEndPeriod")
    membership_start_period: TaxMembershipPeriodResponse = Field(alias="membershipStartPeriod")
    effective_end_period: Optional[TaxMembershipPeriodResponse] = Field(default=None, alias="effectiveEndPeriod")
    effective_start_period: Optional[TaxMembershipPeriodResponse] = Field(default=None, alias="effectiveStartPeriod")
    method: StrictStr = Field(description="PPh21 calculation method")
    more_than_one_employer: StrictBool = Field(description="Whether employee has more than one employer", alias="moreThanOneEmployer")
    npwp_address: StrictStr = Field(description="Address registered with NPWP", alias="npwpAddress")
    npwp_number: Annotated[str, Field(strict=True)] = Field(description="NPWP (Tax ID) number - can be empty or contain only digits", alias="npwpNumber")
    tin: Optional[StrictStr] = Field(default=None, description="Tax Identification Number")
    previous_net_income: Union[Annotated[float, Field(strict=True, ge=0)], Annotated[int, Field(strict=True, ge=0)]] = Field(description="Previous net income amount", alias="previousNetIncome")
    previous_paid_pph: Union[Annotated[float, Field(strict=True, ge=0)], Annotated[int, Field(strict=True, ge=0)]] = Field(description="Previous paid PPh amount", alias="previousPaidPph")
    ptkp_category_id: StrictStr = Field(description="PTKP (Personal Tax Free Income) category identifier", alias="ptkpCategoryId")
    tax_object: StrictStr = Field(description="Type of tax object for the employee", alias="taxObject")
    use_recommended_period: Optional[StrictBool] = Field(default=None, alias="useRecommendedPeriod")
    tax_dependents: Optional[List[TaxDependentResponse]] = Field(default=None, description="List of tax dependents for PTKP calculation", alias="taxDependents")
    __properties: ClassVar[List[str]] = ["id", "foreignTaxObject", "kppId", "linkToPayroll", "membershipEndPeriod", "membershipStartPeriod", "effectiveEndPeriod", "effectiveStartPeriod", "method", "moreThanOneEmployer", "npwpAddress", "npwpNumber", "tin", "previousNetIncome", "previousPaidPph", "ptkpCategoryId", "taxObject", "useRecommendedPeriod", "taxDependents"]

    @field_validator('method')
    def method_validate_enum(cls, value):
        """Validates the enum"""
        if value not in set(['GROSS', 'NETTO', 'GROSS_UP', 'MIX', 'MIX_GROSS_NETTO', 'MIX_NETTO_GROSS', 'MIX_GROSS_UP_GROSS']):
            raise ValueError("must be one of enum values ('GROSS', 'NETTO', 'GROSS_UP', 'MIX', 'MIX_GROSS_NETTO', 'MIX_NETTO_GROSS', 'MIX_GROSS_UP_GROSS')")
        return value

    @field_validator('npwp_number')
    def npwp_number_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if not re.match(r"^$|^\d+$", value):
            raise ValueError(r"must validate the regular expression /^$|^\d+$/")
        return value

    @field_validator('tax_object')
    def tax_object_validate_enum(cls, value):
        """Validates the enum"""
        if value not in set(['PERMANENT', 'TEMPORARY', 'MULTI_LEVEL_DISTRIBUTOR', 'INSURANCE_AGENT', 'MERCHANT_GOODS', 'EXPERT_CONTINUOUS', 'EXPERT_NON_CONTINUOUS', 'CONTINUOUS', 'NON_CONTINUOUS', 'COMMISSIONER', 'FORMER_EMPLOYEE', 'EVENT_PARTICIPANT', 'EXPATRIATE', 'EXPERT', 'MEETING_PARTICIPANT', 'COMMITTEE_PARTICIPANT', 'EDUCATION_PARTICIPANT', 'OTHER_PARTICIPANT', 'ADVISOR_LECTURER', 'AUTHOR_RESEARCHER', 'SERVICE_PROVIDER', 'ADVERTISING_AGENT', 'PROJECT_MANAGER', 'INTERMEDIARY', 'ARTIST', 'ATHLETE', 'TEMPORARY_MONTHLY', 'COMPETITION_PARTICIPANT']):
            raise ValueError("must be one of enum values ('PERMANENT', 'TEMPORARY', 'MULTI_LEVEL_DISTRIBUTOR', 'INSURANCE_AGENT', 'MERCHANT_GOODS', 'EXPERT_CONTINUOUS', 'EXPERT_NON_CONTINUOUS', 'CONTINUOUS', 'NON_CONTINUOUS', 'COMMISSIONER', 'FORMER_EMPLOYEE', 'EVENT_PARTICIPANT', 'EXPATRIATE', 'EXPERT', 'MEETING_PARTICIPANT', 'COMMITTEE_PARTICIPANT', 'EDUCATION_PARTICIPANT', 'OTHER_PARTICIPANT', 'ADVISOR_LECTURER', 'AUTHOR_RESEARCHER', 'SERVICE_PROVIDER', 'ADVERTISING_AGENT', 'PROJECT_MANAGER', 'INTERMEDIARY', 'ARTIST', 'ATHLETE', 'TEMPORARY_MONTHLY', 'COMPETITION_PARTICIPANT')")
        return value

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of TaxMembershipResponse from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of membership_end_period
        if self.membership_end_period:
            _dict['membershipEndPeriod'] = self.membership_end_period.to_dict()
        # override the default output from pydantic by calling `to_dict()` of membership_start_period
        if self.membership_start_period:
            _dict['membershipStartPeriod'] = self.membership_start_period.to_dict()
        # override the default output from pydantic by calling `to_dict()` of effective_end_period
        if self.effective_end_period:
            _dict['effectiveEndPeriod'] = self.effective_end_period.to_dict()
        # override the default output from pydantic by calling `to_dict()` of effective_start_period
        if self.effective_start_period:
            _dict['effectiveStartPeriod'] = self.effective_start_period.to_dict()
        # override the default output from pydantic by calling `to_dict()` of each item in tax_dependents (list)
        _items = []
        if self.tax_dependents:
            for _item_tax_dependents in self.tax_dependents:
                if _item_tax_dependents:
                    _items.append(_item_tax_dependents.to_dict())
            _dict['taxDependents'] = _items
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of TaxMembershipResponse from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "id": obj.get("id"),
            "foreignTaxObject": obj.get("foreignTaxObject"),
            "kppId": obj.get("kppId"),
            "linkToPayroll": obj.get("linkToPayroll"),
            "membershipEndPeriod": TaxMembershipPeriodResponse.from_dict(obj["membershipEndPeriod"]) if obj.get("membershipEndPeriod") is not None else None,
            "membershipStartPeriod": TaxMembershipPeriodResponse.from_dict(obj["membershipStartPeriod"]) if obj.get("membershipStartPeriod") is not None else None,
            "effectiveEndPeriod": TaxMembershipPeriodResponse.from_dict(obj["effectiveEndPeriod"]) if obj.get("effectiveEndPeriod") is not None else None,
            "effectiveStartPeriod": TaxMembershipPeriodResponse.from_dict(obj["effectiveStartPeriod"]) if obj.get("effectiveStartPeriod") is not None else None,
            "method": obj.get("method"),
            "moreThanOneEmployer": obj.get("moreThanOneEmployer"),
            "npwpAddress": obj.get("npwpAddress"),
            "npwpNumber": obj.get("npwpNumber"),
            "tin": obj.get("tin"),
            "previousNetIncome": obj.get("previousNetIncome"),
            "previousPaidPph": obj.get("previousPaidPph"),
            "ptkpCategoryId": obj.get("ptkpCategoryId"),
            "taxObject": obj.get("taxObject"),
            "useRecommendedPeriod": obj.get("useRecommendedPeriod"),
            "taxDependents": [TaxDependentResponse.from_dict(_item) for _item in obj["taxDependents"]] if obj.get("taxDependents") is not None else None
        })
        return _obj


