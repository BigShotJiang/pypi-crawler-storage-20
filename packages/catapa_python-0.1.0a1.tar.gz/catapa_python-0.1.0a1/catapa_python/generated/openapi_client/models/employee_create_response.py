# coding: utf-8

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  ## Python ```bash pip install requests ```  ```python import requests from requests.auth import HTTPBasicAuth  base_url = \"https://api.catapa.com\" tenant = \"zfrl\" client_id = \"test-client-id\" client_secret = \"test-client-secret\"  # Get access token token_data = requests.post(     f\"{base_url}/oauth/token\",     headers={\"Tenant\": tenant},     data={\"grant_type\": \"client_credentials\"},     auth=HTTPBasicAuth(client_id, client_secret) ) access_token = token_data.json()[\"access_token\"]  # Get company company = requests.get(     f\"{base_url}/core/v1/companies\",     headers={\"Tenant\": tenant, \"Authorization\": f\"Bearer {access_token}\"} ) print(company.json()) ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from datetime import date
from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr
from typing import Any, ClassVar, Dict, List, Optional
from openapi_client.models.employment_type_response import EmploymentTypeResponse
from openapi_client.models.job_level_response import JobLevelResponse
from openapi_client.models.job_title_response import JobTitleResponse
from openapi_client.models.location_response import LocationResponse
from openapi_client.models.organization_response import OrganizationResponse
from openapi_client.models.place_of_birth_response import PlaceOfBirthResponse
from openapi_client.models.point_of_hire_response import PointOfHireResponse
from openapi_client.models.religion_response import ReligionResponse
from typing import Optional, Set
from typing_extensions import Self

class EmployeeCreateResponse(BaseModel):
    """
    EmployeeCreateResponse
    """ # noqa: E501
    id: Optional[StrictStr] = None
    marital_status: Optional[StrictStr] = Field(default=None, alias="maritalStatus")
    religion: Optional[ReligionResponse] = None
    foreign_labour: Optional[StrictBool] = Field(default=None, alias="foreignLabour")
    citizenship: Optional[Dict[str, Any]] = None
    identification_number: Optional[StrictStr] = Field(default=None, alias="identificationNumber")
    name: Optional[StrictStr] = None
    date_of_birth: Optional[StrictStr] = Field(default=None, alias="dateOfBirth")
    place_of_birth: Optional[PlaceOfBirthResponse] = Field(default=None, alias="placeOfBirth")
    join_date: Optional[StrictStr] = Field(default=None, alias="joinDate")
    start_date: Optional[StrictStr] = Field(default=None, alias="startDate")
    gender: Optional[StrictStr] = None
    point_of_hire: Optional[PointOfHireResponse] = Field(default=None, alias="pointOfHire")
    employment_status_number: Optional[StrictStr] = Field(default=None, alias="employmentStatusNumber")
    organization: Optional[OrganizationResponse] = None
    job_title: Optional[JobTitleResponse] = Field(default=None, alias="jobTitle")
    job_level: Optional[JobLevelResponse] = Field(default=None, alias="jobLevel")
    location: Optional[LocationResponse] = None
    employment_type: Optional[EmploymentTypeResponse] = Field(default=None, alias="employmentType")
    contract_start: Optional[StrictStr] = Field(default=None, alias="contractStart")
    contract_end: Optional[StrictStr] = Field(default=None, alias="contractEnd")
    identity_card_number: Optional[StrictStr] = Field(default=None, alias="identityCardNumber")
    identity_card_expired_date: Optional[date] = Field(default=None, alias="identityCardExpiredDate")
    email: Optional[StrictStr] = None
    __properties: ClassVar[List[str]] = ["id", "maritalStatus", "religion", "foreignLabour", "citizenship", "identificationNumber", "name", "dateOfBirth", "placeOfBirth", "joinDate", "startDate", "gender", "pointOfHire", "employmentStatusNumber", "organization", "jobTitle", "jobLevel", "location", "employmentType", "contractStart", "contractEnd", "identityCardNumber", "identityCardExpiredDate", "email"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of EmployeeCreateResponse from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of religion
        if self.religion:
            _dict['religion'] = self.religion.to_dict()
        # override the default output from pydantic by calling `to_dict()` of place_of_birth
        if self.place_of_birth:
            _dict['placeOfBirth'] = self.place_of_birth.to_dict()
        # override the default output from pydantic by calling `to_dict()` of point_of_hire
        if self.point_of_hire:
            _dict['pointOfHire'] = self.point_of_hire.to_dict()
        # override the default output from pydantic by calling `to_dict()` of organization
        if self.organization:
            _dict['organization'] = self.organization.to_dict()
        # override the default output from pydantic by calling `to_dict()` of job_title
        if self.job_title:
            _dict['jobTitle'] = self.job_title.to_dict()
        # override the default output from pydantic by calling `to_dict()` of job_level
        if self.job_level:
            _dict['jobLevel'] = self.job_level.to_dict()
        # override the default output from pydantic by calling `to_dict()` of location
        if self.location:
            _dict['location'] = self.location.to_dict()
        # override the default output from pydantic by calling `to_dict()` of employment_type
        if self.employment_type:
            _dict['employmentType'] = self.employment_type.to_dict()
        # set to None if citizenship (nullable) is None
        # and model_fields_set contains the field
        if self.citizenship is None and "citizenship" in self.model_fields_set:
            _dict['citizenship'] = None

        # set to None if identification_number (nullable) is None
        # and model_fields_set contains the field
        if self.identification_number is None and "identification_number" in self.model_fields_set:
            _dict['identificationNumber'] = None

        # set to None if employment_status_number (nullable) is None
        # and model_fields_set contains the field
        if self.employment_status_number is None and "employment_status_number" in self.model_fields_set:
            _dict['employmentStatusNumber'] = None

        # set to None if employment_type (nullable) is None
        # and model_fields_set contains the field
        if self.employment_type is None and "employment_type" in self.model_fields_set:
            _dict['employmentType'] = None

        # set to None if contract_start (nullable) is None
        # and model_fields_set contains the field
        if self.contract_start is None and "contract_start" in self.model_fields_set:
            _dict['contractStart'] = None

        # set to None if contract_end (nullable) is None
        # and model_fields_set contains the field
        if self.contract_end is None and "contract_end" in self.model_fields_set:
            _dict['contractEnd'] = None

        # set to None if identity_card_expired_date (nullable) is None
        # and model_fields_set contains the field
        if self.identity_card_expired_date is None and "identity_card_expired_date" in self.model_fields_set:
            _dict['identityCardExpiredDate'] = None

        # set to None if email (nullable) is None
        # and model_fields_set contains the field
        if self.email is None and "email" in self.model_fields_set:
            _dict['email'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of EmployeeCreateResponse from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "id": obj.get("id"),
            "maritalStatus": obj.get("maritalStatus"),
            "religion": ReligionResponse.from_dict(obj["religion"]) if obj.get("religion") is not None else None,
            "foreignLabour": obj.get("foreignLabour"),
            "citizenship": obj.get("citizenship"),
            "identificationNumber": obj.get("identificationNumber"),
            "name": obj.get("name"),
            "dateOfBirth": obj.get("dateOfBirth"),
            "placeOfBirth": PlaceOfBirthResponse.from_dict(obj["placeOfBirth"]) if obj.get("placeOfBirth") is not None else None,
            "joinDate": obj.get("joinDate"),
            "startDate": obj.get("startDate"),
            "gender": obj.get("gender"),
            "pointOfHire": PointOfHireResponse.from_dict(obj["pointOfHire"]) if obj.get("pointOfHire") is not None else None,
            "employmentStatusNumber": obj.get("employmentStatusNumber"),
            "organization": OrganizationResponse.from_dict(obj["organization"]) if obj.get("organization") is not None else None,
            "jobTitle": JobTitleResponse.from_dict(obj["jobTitle"]) if obj.get("jobTitle") is not None else None,
            "jobLevel": JobLevelResponse.from_dict(obj["jobLevel"]) if obj.get("jobLevel") is not None else None,
            "location": LocationResponse.from_dict(obj["location"]) if obj.get("location") is not None else None,
            "employmentType": EmploymentTypeResponse.from_dict(obj["employmentType"]) if obj.get("employmentType") is not None else None,
            "contractStart": obj.get("contractStart"),
            "contractEnd": obj.get("contractEnd"),
            "identityCardNumber": obj.get("identityCardNumber"),
            "identityCardExpiredDate": obj.get("identityCardExpiredDate"),
            "email": obj.get("email")
        })
        return _obj


