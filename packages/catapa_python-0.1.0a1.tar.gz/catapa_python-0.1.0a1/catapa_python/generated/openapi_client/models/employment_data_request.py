# coding: utf-8

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  ## Python ```bash pip install requests ```  ```python import requests from requests.auth import HTTPBasicAuth  base_url = \"https://api.catapa.com\" tenant = \"zfrl\" client_id = \"test-client-id\" client_secret = \"test-client-secret\"  # Get access token token_data = requests.post(     f\"{base_url}/oauth/token\",     headers={\"Tenant\": tenant},     data={\"grant_type\": \"client_credentials\"},     auth=HTTPBasicAuth(client_id, client_secret) ) access_token = token_data.json()[\"access_token\"]  # Get company company = requests.get(     f\"{base_url}/core/v1/companies\",     headers={\"Tenant\": tenant, \"Authorization\": f\"Bearer {access_token}\"} ) print(company.json()) ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from datetime import date
from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictStr
from typing import Any, ClassVar, Dict, List, Optional
from typing_extensions import Annotated
from typing import Optional, Set
from typing_extensions import Self

class EmploymentDataRequest(BaseModel):
    """
    EmploymentDataRequest
    """ # noqa: E501
    contract_start: Optional[date] = Field(default=None, description="YYYY-MM-DD", alias="contractStart")
    contract_end: Optional[date] = Field(default=None, description="YYYY-MM-DD", alias="contractEnd")
    effective_date: date = Field(description="YYYY-MM-DD", alias="effectiveDate")
    employment_status_number: Annotated[str, Field(strict=True, max_length=255)] = Field(alias="employmentStatusNumber")
    employment_status_type_id: StrictStr = Field(alias="employmentStatusTypeId")
    employment_type_id: StrictStr = Field(alias="employmentTypeId")
    job_level_id: StrictStr = Field(alias="jobLevelId")
    job_title_id: StrictStr = Field(alias="jobTitleId")
    location_id: StrictStr = Field(alias="locationId")
    organization_id: StrictStr = Field(alias="organizationId")
    cost_center_id: Optional[StrictStr] = Field(default=None, alias="costCenterId")
    permanent_date: Optional[date] = Field(default=None, description="YYYY-MM-DD", alias="permanentDate")
    sign_date: date = Field(description="YYYY-MM-DD", alias="signDate")
    generate_employment_status_number: Optional[StrictBool] = Field(default=False, alias="generateEmploymentStatusNumber")
    sub_location_id: Optional[StrictStr] = Field(default=None, alias="subLocationId")
    operational_group_id: Optional[StrictStr] = Field(default=None, alias="operationalGroupId")
    __properties: ClassVar[List[str]] = ["contractStart", "contractEnd", "effectiveDate", "employmentStatusNumber", "employmentStatusTypeId", "employmentTypeId", "jobLevelId", "jobTitleId", "locationId", "organizationId", "costCenterId", "permanentDate", "signDate", "generateEmploymentStatusNumber", "subLocationId", "operationalGroupId"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of EmploymentDataRequest from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # set to None if contract_start (nullable) is None
        # and model_fields_set contains the field
        if self.contract_start is None and "contract_start" in self.model_fields_set:
            _dict['contractStart'] = None

        # set to None if contract_end (nullable) is None
        # and model_fields_set contains the field
        if self.contract_end is None and "contract_end" in self.model_fields_set:
            _dict['contractEnd'] = None

        # set to None if cost_center_id (nullable) is None
        # and model_fields_set contains the field
        if self.cost_center_id is None and "cost_center_id" in self.model_fields_set:
            _dict['costCenterId'] = None

        # set to None if permanent_date (nullable) is None
        # and model_fields_set contains the field
        if self.permanent_date is None and "permanent_date" in self.model_fields_set:
            _dict['permanentDate'] = None

        # set to None if sub_location_id (nullable) is None
        # and model_fields_set contains the field
        if self.sub_location_id is None and "sub_location_id" in self.model_fields_set:
            _dict['subLocationId'] = None

        # set to None if operational_group_id (nullable) is None
        # and model_fields_set contains the field
        if self.operational_group_id is None and "operational_group_id" in self.model_fields_set:
            _dict['operationalGroupId'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of EmploymentDataRequest from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "contractStart": obj.get("contractStart"),
            "contractEnd": obj.get("contractEnd"),
            "effectiveDate": obj.get("effectiveDate"),
            "employmentStatusNumber": obj.get("employmentStatusNumber"),
            "employmentStatusTypeId": obj.get("employmentStatusTypeId"),
            "employmentTypeId": obj.get("employmentTypeId"),
            "jobLevelId": obj.get("jobLevelId"),
            "jobTitleId": obj.get("jobTitleId"),
            "locationId": obj.get("locationId"),
            "organizationId": obj.get("organizationId"),
            "costCenterId": obj.get("costCenterId"),
            "permanentDate": obj.get("permanentDate"),
            "signDate": obj.get("signDate"),
            "generateEmploymentStatusNumber": obj.get("generateEmploymentStatusNumber") if obj.get("generateEmploymentStatusNumber") is not None else False,
            "subLocationId": obj.get("subLocationId"),
            "operationalGroupId": obj.get("operationalGroupId")
        })
        return _obj


