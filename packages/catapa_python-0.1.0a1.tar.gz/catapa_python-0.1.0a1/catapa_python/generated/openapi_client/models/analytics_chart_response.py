# coding: utf-8

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  ## Python ```bash pip install requests ```  ```python import requests from requests.auth import HTTPBasicAuth  base_url = \"https://api.catapa.com\" tenant = \"zfrl\" client_id = \"test-client-id\" client_secret = \"test-client-secret\"  # Get access token token_data = requests.post(     f\"{base_url}/oauth/token\",     headers={\"Tenant\": tenant},     data={\"grant_type\": \"client_credentials\"},     auth=HTTPBasicAuth(client_id, client_secret) ) access_token = token_data.json()[\"access_token\"]  # Get company company = requests.get(     f\"{base_url}/core/v1/companies\",     headers={\"Tenant\": tenant, \"Authorization\": f\"Bearer {access_token}\"} ) print(company.json()) ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictFloat, StrictInt, StrictStr
from typing import Any, ClassVar, Dict, List, Optional, Union
from openapi_client.models.analytics_color_scheme_response import AnalyticsColorSchemeResponse
from openapi_client.models.chart_filter_response import ChartFilterResponse
from openapi_client.models.chart_table_relation_response import ChartTableRelationResponse
from typing import Optional, Set
from typing_extensions import Self

class AnalyticsChartResponse(BaseModel):
    """
    AnalyticsChartResponse
    """ # noqa: E501
    id: Optional[StrictStr] = None
    title: Optional[StrictStr] = None
    size: Optional[Union[StrictFloat, StrictInt]] = None
    options: Optional[StrictStr] = None
    chart_type: Optional[StrictStr] = Field(default=None, alias="chartType")
    aggregation_type: Optional[StrictStr] = Field(default=None, alias="aggregationType")
    table_id: Optional[StrictStr] = Field(default=None, alias="tableId")
    yaxis_title: Optional[StrictStr] = Field(default=None, alias="yaxisTitle")
    ycolumn_id: Optional[StrictStr] = Field(default=None, alias="ycolumnId")
    ychart_table_relations: Optional[List[ChartTableRelationResponse]] = Field(default=None, alias="ychartTableRelations")
    xaxis_title: Optional[StrictStr] = Field(default=None, alias="xaxisTitle")
    xcolumn_id: Optional[StrictStr] = Field(default=None, alias="xcolumnId")
    xchart_table_relations: Optional[List[ChartTableRelationResponse]] = Field(default=None, alias="xchartTableRelations")
    series_axis_title: Optional[StrictStr] = Field(default=None, alias="seriesAxisTitle")
    series_column_id: Optional[StrictStr] = Field(default=None, alias="seriesColumnId")
    series_chart_table_relations: Optional[List[ChartTableRelationResponse]] = Field(default=None, alias="seriesChartTableRelations")
    color_scheme: Optional[AnalyticsColorSchemeResponse] = Field(default=None, alias="colorScheme")
    data_trustee_enabled: Optional[StrictBool] = Field(default=None, alias="dataTrusteeEnabled")
    chart_filters: Optional[List[ChartFilterResponse]] = Field(default=None, alias="chartFilters")
    max_items: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="maxItems")
    sort_type: Optional[StrictStr] = Field(default=None, alias="sortType")
    __properties: ClassVar[List[str]] = ["id", "title", "size", "options", "chartType", "aggregationType", "tableId", "yaxisTitle", "ycolumnId", "ychartTableRelations", "xaxisTitle", "xcolumnId", "xchartTableRelations", "seriesAxisTitle", "seriesColumnId", "seriesChartTableRelations", "colorScheme", "dataTrusteeEnabled", "chartFilters", "maxItems", "sortType"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of AnalyticsChartResponse from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of each item in ychart_table_relations (list)
        _items = []
        if self.ychart_table_relations:
            for _item_ychart_table_relations in self.ychart_table_relations:
                if _item_ychart_table_relations:
                    _items.append(_item_ychart_table_relations.to_dict())
            _dict['ychartTableRelations'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in xchart_table_relations (list)
        _items = []
        if self.xchart_table_relations:
            for _item_xchart_table_relations in self.xchart_table_relations:
                if _item_xchart_table_relations:
                    _items.append(_item_xchart_table_relations.to_dict())
            _dict['xchartTableRelations'] = _items
        # override the default output from pydantic by calling `to_dict()` of each item in series_chart_table_relations (list)
        _items = []
        if self.series_chart_table_relations:
            for _item_series_chart_table_relations in self.series_chart_table_relations:
                if _item_series_chart_table_relations:
                    _items.append(_item_series_chart_table_relations.to_dict())
            _dict['seriesChartTableRelations'] = _items
        # override the default output from pydantic by calling `to_dict()` of color_scheme
        if self.color_scheme:
            _dict['colorScheme'] = self.color_scheme.to_dict()
        # override the default output from pydantic by calling `to_dict()` of each item in chart_filters (list)
        _items = []
        if self.chart_filters:
            for _item_chart_filters in self.chart_filters:
                if _item_chart_filters:
                    _items.append(_item_chart_filters.to_dict())
            _dict['chartFilters'] = _items
        # set to None if options (nullable) is None
        # and model_fields_set contains the field
        if self.options is None and "options" in self.model_fields_set:
            _dict['options'] = None

        # set to None if series_axis_title (nullable) is None
        # and model_fields_set contains the field
        if self.series_axis_title is None and "series_axis_title" in self.model_fields_set:
            _dict['seriesAxisTitle'] = None

        # set to None if series_column_id (nullable) is None
        # and model_fields_set contains the field
        if self.series_column_id is None and "series_column_id" in self.model_fields_set:
            _dict['seriesColumnId'] = None

        # set to None if series_chart_table_relations (nullable) is None
        # and model_fields_set contains the field
        if self.series_chart_table_relations is None and "series_chart_table_relations" in self.model_fields_set:
            _dict['seriesChartTableRelations'] = None

        # set to None if chart_filters (nullable) is None
        # and model_fields_set contains the field
        if self.chart_filters is None and "chart_filters" in self.model_fields_set:
            _dict['chartFilters'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of AnalyticsChartResponse from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "id": obj.get("id"),
            "title": obj.get("title"),
            "size": obj.get("size"),
            "options": obj.get("options"),
            "chartType": obj.get("chartType"),
            "aggregationType": obj.get("aggregationType"),
            "tableId": obj.get("tableId"),
            "yaxisTitle": obj.get("yaxisTitle"),
            "ycolumnId": obj.get("ycolumnId"),
            "ychartTableRelations": [ChartTableRelationResponse.from_dict(_item) for _item in obj["ychartTableRelations"]] if obj.get("ychartTableRelations") is not None else None,
            "xaxisTitle": obj.get("xaxisTitle"),
            "xcolumnId": obj.get("xcolumnId"),
            "xchartTableRelations": [ChartTableRelationResponse.from_dict(_item) for _item in obj["xchartTableRelations"]] if obj.get("xchartTableRelations") is not None else None,
            "seriesAxisTitle": obj.get("seriesAxisTitle"),
            "seriesColumnId": obj.get("seriesColumnId"),
            "seriesChartTableRelations": [ChartTableRelationResponse.from_dict(_item) for _item in obj["seriesChartTableRelations"]] if obj.get("seriesChartTableRelations") is not None else None,
            "colorScheme": AnalyticsColorSchemeResponse.from_dict(obj["colorScheme"]) if obj.get("colorScheme") is not None else None,
            "dataTrusteeEnabled": obj.get("dataTrusteeEnabled"),
            "chartFilters": [ChartFilterResponse.from_dict(_item) for _item in obj["chartFilters"]] if obj.get("chartFilters") is not None else None,
            "maxItems": obj.get("maxItems"),
            "sortType": obj.get("sortType")
        })
        return _obj


