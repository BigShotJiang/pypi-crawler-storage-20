# coding: utf-8

"""
    CATAPA API

    # Introduction CATAPA API uses RESTful API style. It uses JSON data format for data exchange and utilizes HTTP verbs as appropriate.  For authorization & authentication, CATAPA API uses OAuth 2.0 protocol.  # Quickstart ## Node.js SDK (Beta) ### TypeScript First, run this command to install the SDK. ```bash npm i @catapa/node typescript ```  Write this code to the `index.ts`. ```typescript import { Catapa } from '@catapa/node';  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash tsc index.ts && node index.js ```  Not all endpoints have fluent methods. For that case, you can use following generic methods: ```typescript await catapa.get('/<path>');  await catapa.post('/<path>', object);  await catapa.put('/<path>', object);  await catapa.patch('/<path>', object);  await catapa.delete('/<path>'); ```  ### JavaScript First, run this command to install the SDK. ```bash npm i @catapa/node ```  Write this code to `index.js`. ```javascript const { Catapa } = require('@catapa/node');  // Setup const catapa = new Catapa({tenant: 'zfrl', clientId: 'test-client-id', clientSecret: 'test-client-secret'});  // Get company info catapa.company.get()   .then(company => console.log(company));  // List employees catapa.employees.list({page: 0, size: 10})   .then(employees => console.log(employees)); ```  Then, run: ```bash node index.js ```  ## Python ```bash pip install requests ```  ```python import requests from requests.auth import HTTPBasicAuth  base_url = \"https://api.catapa.com\" tenant = \"zfrl\" client_id = \"test-client-id\" client_secret = \"test-client-secret\"  # Get access token token_data = requests.post(     f\"{base_url}/oauth/token\",     headers={\"Tenant\": tenant},     data={\"grant_type\": \"client_credentials\"},     auth=HTTPBasicAuth(client_id, client_secret) ) access_token = token_data.json()[\"access_token\"]  # Get company company = requests.get(     f\"{base_url}/core/v1/companies\",     headers={\"Tenant\": tenant, \"Authorization\": f\"Bearer {access_token}\"} ) print(company.json()) ```  # Base URL Production: https://api.catapa.com  # Authentication Clients need to acquire an access token before they send HTTP requests to resource endpoints.  <SecurityDefinitions />  ## Validate Access Token    Use this endpoint to verify if an access token is valid and was issued by the API gateway. The endpoint supports both user tokens and client credentials tokens.    | **HTTP Method**  | `GET`                                                |                                         |   |------------------|------------------------------------------------------|-----------------------------------------|   | **URL**          | `<base-url>/v1/oauth-clients/validate-access-token`  |                                         |   | **Headers**      | `Authorization`                                      | `Bearer <access-token>`                 |   |                  | `Tenant`                                             | Your tenant identifier (e.g., \"catapa\") |  ### Example request using `curl`    ```bash   curl --location '<base-url>/v1/oauth-clients/validate-access-token' \\     --header 'Tenant: catapa' \\     --header 'Authorization: Bearer <access-token>'   ```  ### Response codes  - **200 OK**: Token is valid - **401 Unauthorized**: Token is invalid or expired  ### Notes  - This endpoint validates both user authentication tokens and client credentials tokens - For server-to-server communication, use client credentials flow with the token in the Authorization header - No response body is returned; the status code indicates the validation result - The `Tenant` header is required to specify which tenant context to validate the token against  # HTTP Headers Each request should contain the following headers.  |Headers        |Description  | |---------------|-------------| |Tenant         |Tenant name. e.g. Catapa| |Authorization  |For authentication. Value format: Bearer <access-token>|  Example HTTP Request using cURL: ```bash curl <base-url>/core/v1/employees?page=0&size=10 \\ -H \"Tenant: <tenant name>\" \\ -H \"Authorization: Bearer <access-token>\" ```  # Rate Limit To ensure optimal API performance and fair usage for all users, we implement rate limiting. The general limit is **400 requests per minute, per Client ID**. If you exceed the rate limit, you will receive an HTTP 429 (Too Many Requests) error response.  # Pagination The API provides `page` & `size` query params. `page` is a page number starting from 0. `size` is number of elements per page. Maximum value of `size` is 50.  Every paginated endpoints will have following response format: ``` {   \"content\": [     { ... },     { ... }   ],   \"number\": 0, // page number   \"size\": 10, // page size   \"numberOfElements\": 10, // number of element in this current page   \"totalElements\": 100,   \"totalPages\": 10 } ```  # Search Query You can perform search operations in some endpoints by setting the query parameter. Query value parameter constructed with following format:  ```bash ?query=<key><operator><value>,<key><operator><value> ```  Explanations: | Format | Descriptions | |-|-| | `<key>` | Key name to search certain fields | | `<operator>`   | Operation to apply on certain fields.<br>Supported operators: `:` `<` `>` | | `<value>` | Value to apply on search. **Value should be encoded using URL encoder**. For examples:<br><br>Plain: `John Doe`<br>Encoded: `John%20Doe` | | `,` | AND operator |   For example, the `/core/v1/employees` endpoint has following search query. |Key                    |Supported Operators  |Notes  | |-----------------------|---------------------|-------| |identificationNumberIn | `:`                 |Equal operator with multiple values. Each value should separated with delimiters `;`| |name                   | `:`                 |Like operator| |startDate              | `:`<br/>`>`<br/>`<` |Equal<br>Greater than or equal to<br>Less than or equal to|  Clients can construct search query with these following variations:  1. Search an employee with ID number 1111 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111 ``` 1. Search multiple employees with ID number 1111 and 2222 ```bash curl <base-url>/core/v1/employees?query=identificationNumberIn:1111;2222 ``` 1. Search employees with name `John Doe` ```bash curl <base-url>/core/v1/employees?query=name:John%20Doe ``` 1. Search all employees with start date between 2020-01-01 and 2020-12-31: ```bash curl <base-url>/core/v1/employees?query=startDate>2020-01-01,startDate<2020-12-31 ``` 

    The version of the OpenAPI document: 1.0.0
    Contact: support@catapa.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictBool, StrictFloat, StrictInt, StrictStr
from typing import Any, ClassVar, Dict, List, Optional, Union
from openapi_client.models.employee_simple_response import EmployeeSimpleResponse
from typing import Optional, Set
from typing_extensions import Self

class LeaveBalanceItemResponse(BaseModel):
    """
    LeaveBalanceItemResponse
    """ # noqa: E501
    id: Optional[StrictStr] = None
    year: Optional[Union[StrictFloat, StrictInt]] = None
    accrual_frequency_type: Optional[StrictStr] = Field(default=None, alias="accrualFrequencyType")
    monthly_accrual_include_bonus: Optional[StrictBool] = Field(default=None, alias="monthlyAccrualIncludeBonus")
    given_date: Optional[StrictStr] = Field(default=None, alias="givenDate")
    start_date: Optional[StrictStr] = Field(default=None, alias="startDate")
    end_date: Optional[StrictStr] = Field(default=None, alias="endDate")
    expected_balance: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="expectedBalance")
    balance: Optional[Union[StrictFloat, StrictInt]] = None
    bonus: Optional[Union[StrictFloat, StrictInt]] = None
    debt: Optional[Union[StrictFloat, StrictInt]] = None
    extended: Optional[StrictBool] = None
    maximum_extended_duration: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="maximumExtendedDuration")
    maximum_extended_balance: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="maximumExtendedBalance")
    extended_balance_include_bonus: Optional[StrictBool] = Field(default=None, alias="extendedBalanceIncludeBonus")
    total_balance: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="totalBalance")
    used_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="usedLeave")
    active: Optional[StrictBool] = None
    employee: Optional[EmployeeSimpleResponse] = None
    approved_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="approvedLeave")
    pending_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="pendingLeave")
    collective_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="collectiveLeave")
    remaining: Optional[Union[StrictFloat, StrictInt]] = None
    extended_date: Optional[StrictStr] = Field(default=None, alias="extendedDate")
    extended_balance: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedBalance")
    extended_used_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedUsedLeave")
    extended_collective_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedCollectiveLeave")
    extended_available: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedAvailable")
    extended_remaining: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedRemaining")
    extended_approved_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedApprovedLeave")
    extended_pending_leave: Optional[Union[StrictFloat, StrictInt]] = Field(default=None, alias="extendedPendingLeave")
    __properties: ClassVar[List[str]] = ["id", "year", "accrualFrequencyType", "monthlyAccrualIncludeBonus", "givenDate", "startDate", "endDate", "expectedBalance", "balance", "bonus", "debt", "extended", "maximumExtendedDuration", "maximumExtendedBalance", "extendedBalanceIncludeBonus", "totalBalance", "usedLeave", "active", "employee", "approvedLeave", "pendingLeave", "collectiveLeave", "remaining", "extendedDate", "extendedBalance", "extendedUsedLeave", "extendedCollectiveLeave", "extendedAvailable", "extendedRemaining", "extendedApprovedLeave", "extendedPendingLeave"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of LeaveBalanceItemResponse from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of employee
        if self.employee:
            _dict['employee'] = self.employee.to_dict()
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of LeaveBalanceItemResponse from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "id": obj.get("id"),
            "year": obj.get("year"),
            "accrualFrequencyType": obj.get("accrualFrequencyType"),
            "monthlyAccrualIncludeBonus": obj.get("monthlyAccrualIncludeBonus"),
            "givenDate": obj.get("givenDate"),
            "startDate": obj.get("startDate"),
            "endDate": obj.get("endDate"),
            "expectedBalance": obj.get("expectedBalance"),
            "balance": obj.get("balance"),
            "bonus": obj.get("bonus"),
            "debt": obj.get("debt"),
            "extended": obj.get("extended"),
            "maximumExtendedDuration": obj.get("maximumExtendedDuration"),
            "maximumExtendedBalance": obj.get("maximumExtendedBalance"),
            "extendedBalanceIncludeBonus": obj.get("extendedBalanceIncludeBonus"),
            "totalBalance": obj.get("totalBalance"),
            "usedLeave": obj.get("usedLeave"),
            "active": obj.get("active"),
            "employee": EmployeeSimpleResponse.from_dict(obj["employee"]) if obj.get("employee") is not None else None,
            "approvedLeave": obj.get("approvedLeave"),
            "pendingLeave": obj.get("pendingLeave"),
            "collectiveLeave": obj.get("collectiveLeave"),
            "remaining": obj.get("remaining"),
            "extendedDate": obj.get("extendedDate"),
            "extendedBalance": obj.get("extendedBalance"),
            "extendedUsedLeave": obj.get("extendedUsedLeave"),
            "extendedCollectiveLeave": obj.get("extendedCollectiveLeave"),
            "extendedAvailable": obj.get("extendedAvailable"),
            "extendedRemaining": obj.get("extendedRemaining"),
            "extendedApprovedLeave": obj.get("extendedApprovedLeave"),
            "extendedPendingLeave": obj.get("extendedPendingLeave")
        })
        return _obj


