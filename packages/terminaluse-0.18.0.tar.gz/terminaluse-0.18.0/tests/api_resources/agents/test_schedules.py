# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from sb0 import Sb0, AsyncSb0
from sb0.types import DeleteResponse
from sb0._utils import parse_datetime
from tests.utils import assert_matches_type
from sb0.types.agents import (
    ScheduleResponse,
    ScheduleListResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSchedules:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: Sb0) -> None:
        schedule = client.agents.schedules.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Sb0) -> None:
        schedule = client.agents.schedules.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
            cron_expression="cron_expression",
            end_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            execution_timeout_seconds=1,
            interval_seconds=1,
            paused=True,
            start_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            workflow_params={"foo": "bar"},
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_create(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.create(
                agent_id="",
                name="name",
                task_queue="task_queue",
                workflow_name="workflow_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Sb0) -> None:
        schedule = client.agents.schedules.retrieve(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.retrieve(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.retrieve(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.retrieve(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            client.agents.schedules.with_raw_response.retrieve(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: Sb0) -> None:
        schedule = client.agents.schedules.list(
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Sb0) -> None:
        schedule = client.agents.schedules.list(
            agent_id="agent_id",
            page_size=1,
        )
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.list(
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.list(
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleListResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_list(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.list(
                agent_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: Sb0) -> None:
        schedule = client.agents.schedules.delete(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(DeleteResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.delete(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(DeleteResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.delete(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(DeleteResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.delete(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            client.agents.schedules.with_raw_response.delete(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_pause(self, client: Sb0) -> None:
        schedule = client.agents.schedules.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_pause_with_all_params(self, client: Sb0) -> None:
        schedule = client.agents.schedules.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
            note="note",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_pause(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_pause(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_pause(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.pause(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            client.agents.schedules.with_raw_response.pause(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_trigger(self, client: Sb0) -> None:
        schedule = client.agents.schedules.trigger(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_trigger(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.trigger(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_trigger(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.trigger(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_trigger(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.trigger(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            client.agents.schedules.with_raw_response.trigger(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_unpause(self, client: Sb0) -> None:
        schedule = client.agents.schedules.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_unpause_with_all_params(self, client: Sb0) -> None:
        schedule = client.agents.schedules.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
            note="note",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_unpause(self, client: Sb0) -> None:
        response = client.agents.schedules.with_raw_response.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_unpause(self, client: Sb0) -> None:
        with client.agents.schedules.with_streaming_response.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_unpause(self, client: Sb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            client.agents.schedules.with_raw_response.unpause(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            client.agents.schedules.with_raw_response.unpause(
                schedule_name="",
                agent_id="agent_id",
            )


class TestAsyncSchedules:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
            cron_expression="cron_expression",
            end_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            execution_timeout_seconds=1,
            interval_seconds=1,
            paused=True,
            start_at=parse_datetime("2019-12-27T18:11:19.117Z"),
            workflow_params={"foo": "bar"},
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.create(
            agent_id="agent_id",
            name="name",
            task_queue="task_queue",
            workflow_name="workflow_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_create(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.create(
                agent_id="",
                name="name",
                task_queue="task_queue",
                workflow_name="workflow_name",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.retrieve(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.retrieve(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.retrieve(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.retrieve(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            await async_client.agents.schedules.with_raw_response.retrieve(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.list(
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.list(
            agent_id="agent_id",
            page_size=1,
        )
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.list(
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleListResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.list(
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleListResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_list(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.list(
                agent_id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.delete(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(DeleteResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.delete(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(DeleteResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.delete(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(DeleteResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.delete(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            await async_client.agents.schedules.with_raw_response.delete(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_pause(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_pause_with_all_params(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
            note="note",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_pause(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_pause(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.pause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_pause(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.pause(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            await async_client.agents.schedules.with_raw_response.pause(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_trigger(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.trigger(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_trigger(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.trigger(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_trigger(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.trigger(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_trigger(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.trigger(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            await async_client.agents.schedules.with_raw_response.trigger(
                schedule_name="",
                agent_id="agent_id",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_unpause(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_unpause_with_all_params(self, async_client: AsyncSb0) -> None:
        schedule = await async_client.agents.schedules.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
            note="note",
        )
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_unpause(self, async_client: AsyncSb0) -> None:
        response = await async_client.agents.schedules.with_raw_response.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        schedule = await response.parse()
        assert_matches_type(ScheduleResponse, schedule, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_unpause(self, async_client: AsyncSb0) -> None:
        async with async_client.agents.schedules.with_streaming_response.unpause(
            schedule_name="schedule_name",
            agent_id="agent_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            schedule = await response.parse()
            assert_matches_type(ScheduleResponse, schedule, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_unpause(self, async_client: AsyncSb0) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `agent_id` but received ''"):
            await async_client.agents.schedules.with_raw_response.unpause(
                schedule_name="schedule_name",
                agent_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `schedule_name` but received ''"):
            await async_client.agents.schedules.with_raw_response.unpause(
                schedule_name="",
                agent_id="agent_id",
            )
