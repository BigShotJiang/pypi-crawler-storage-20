# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["EnvironmentUpdateParams"]


class EnvironmentUpdateParams(TypedDict, total=False):
    namespace_slug: Required[str]

    agent_name: Required[str]

    are_tasks_sticky: Optional[bool]
    """If true, running tasks stay on their original version"""

    branch_rules: Optional[SequenceNotStr[str]]
    """Branch patterns for matching"""

    replicas: Optional[int]
    """Desired replica count"""

    resources: Optional[Dict[str, object]]
    """Resource requests and limits"""
