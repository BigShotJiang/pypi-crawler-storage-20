# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, TypedDict

from ..._types import SequenceNotStr

__all__ = ["EnvironmentCreateParams"]


class EnvironmentCreateParams(TypedDict, total=False):
    namespace_slug: Required[str]

    branch_rules: Required[SequenceNotStr[str]]
    """Branch patterns for matching (e.g., ['feature/*'], ['develop'])"""

    name: Required[str]
    """Environment name (lowercase alphanumeric and hyphens only)"""

    are_tasks_sticky: bool
    """If true, running tasks stay on their original version until completion"""

    replicas: int
    """Desired replica count (1-10)"""

    resources: Optional[Dict[str, object]]
    """Resource requests and limits (e.g., {'requests': {'cpu': '100m'}})"""
