import os
from typing import Any, Dict

import requests


class CFLabs:
    def __init__(
        self,
        prompt_id: str,
        prompt_version: str,
        api_key: str,
        base_url: str = "http://localhost:8000",
    ):
        """
        Initialize the CFLabs client.
        """
        self.api_key = api_key or os.environ.get("CFLABS_API_KEY")
        self.base_url = base_url.rstrip("/")
        self.prompt_id = prompt_id
        self.prompt_version = prompt_version

    def run(self, var_parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Trigger an inference of the Prompt using the Octavian API.
        """
        url = f"{self.base_url}/run"
        headers = {"Content-Type": "application/json"}
        headers["Authorization"] = f"Bearer {self.api_key}"

        payload = {
            "prompt_id": self.prompt_id,
            "prompt_version": self.prompt_version,
            "inputs": var_parameters,
        }

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()

        return response.json()
