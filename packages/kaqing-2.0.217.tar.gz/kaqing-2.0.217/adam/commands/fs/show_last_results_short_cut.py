from adam.commands.fs.utils_last_results import show_last_results
from adam.commands.command import Command
from adam.repl_state import ReplState

class ShowLastResultsShortCut(Command):
    COMMAND = ':?'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ShowLastResultsShortCut, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ShowLastResultsShortCut.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        show_last_results()

        return state

    def completion(self, state: ReplState):
        return super().completion(state)