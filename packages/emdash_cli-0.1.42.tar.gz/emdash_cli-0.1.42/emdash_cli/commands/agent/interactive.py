"""Interactive REPL mode for the agent CLI."""

import subprocess
import threading
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from .constants import AgentMode, SLASH_COMMANDS
from .file_utils import expand_file_references, fuzzy_find_files
from .menus import (
    get_clarification_response,
    show_plan_approval_menu,
    show_plan_mode_approval_menu,
)
from .handlers import (
    handle_agents,
    handle_session,
    handle_todos,
    handle_todo_add,
    handle_hooks,
    handle_rules,
    handle_skills,
    handle_mcp,
    handle_auth,
    handle_status,
    handle_pr,
    handle_projectmd,
    handle_research,
    handle_context,
)

console = Console()


def render_with_interrupt(renderer, stream) -> dict:
    """Render stream with ESC key interrupt support.

    Args:
        renderer: SSE renderer instance
        stream: SSE stream iterator

    Returns:
        Result dict from renderer, with 'interrupted' flag
    """
    from ...keyboard import KeyListener

    interrupt_event = threading.Event()

    def on_escape():
        interrupt_event.set()

    listener = KeyListener(on_escape)

    try:
        listener.start()
        result = renderer.render_stream(stream, interrupt_event=interrupt_event)
        return result
    finally:
        listener.stop()


def run_single_task(
    client,
    renderer,
    task: str,
    model: str | None,
    max_iterations: int,
    options: dict,
):
    """Run a single agent task."""
    import click

    try:
        stream = client.agent_chat_stream(
            message=task,
            model=model,
            max_iterations=max_iterations,
            options=options,
        )
        result = render_with_interrupt(renderer, stream)
        if result.get("interrupted"):
            console.print("[dim]Task interrupted. You can continue or start a new task.[/dim]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise click.Abort()


def run_slash_command_task(
    client,
    renderer,
    model: str | None,
    max_iterations: int,
    task: str,
    options: dict,
):
    """Run a task from a slash command."""
    try:
        stream = client.agent_chat_stream(
            message=task,
            model=model,
            max_iterations=max_iterations,
            options=options,
        )
        result = render_with_interrupt(renderer, stream)
        if result.get("interrupted"):
            console.print("[dim]Task interrupted.[/dim]")
        console.print()
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


def run_interactive(
    client,
    renderer,
    model: str | None,
    max_iterations: int,
    options: dict,
):
    """Run interactive REPL mode with slash commands."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.styles import Style
    from prompt_toolkit.key_binding import KeyBindings

    # Current mode
    current_mode = AgentMode(options.get("mode", "code"))
    session_id = None
    current_spec = None
    # Attached images for next message
    attached_images: list[dict] = []
    # Loaded messages from saved session (for restoration)
    loaded_messages: list[dict] = []
    # Pending todos to add when session starts
    pending_todos: list[str] = []

    # Style for prompt
    PROMPT_STYLE = Style.from_dict({
        "prompt.mode.plan": "#ffcc00 bold",
        "prompt.mode.code": "#00cc66 bold",
        "prompt.prefix": "#888888",
        "prompt.image": "#00ccff",
        "completion-menu": "bg:#1a1a2e #ffffff",
        "completion-menu.completion": "bg:#1a1a2e #ffffff",
        "completion-menu.completion.current": "bg:#4a4a6e #ffffff bold",
        "completion-menu.meta.completion": "bg:#1a1a2e #888888",
        "completion-menu.meta.completion.current": "bg:#4a4a6e #aaaaaa",
        "command": "#00ccff bold",
    })

    class SlashCommandCompleter(Completer):
        """Completer for slash commands and @file references."""

        def get_completions(self, document, complete_event):
            text = document.text_before_cursor

            # Handle @file completions
            # Find the last @ in the text
            at_idx = text.rfind('@')
            if at_idx != -1:
                # Get the query after @
                query = text[at_idx + 1:]
                # Only complete if query has at least 1 char and no space after @
                if query and ' ' not in query:
                    matches = fuzzy_find_files(query, limit=10)
                    cwd = Path.cwd()
                    for match in matches:
                        try:
                            rel_path = match.relative_to(cwd)
                        except ValueError:
                            rel_path = match
                        # Replace from @ onwards
                        yield Completion(
                            f"@{rel_path}",
                            start_position=-(len(query) + 1),  # +1 for @
                            display=str(rel_path),
                            display_meta="file",
                        )
                    return

            # Handle slash commands
            if not text.startswith("/"):
                return
            for cmd, description in SLASH_COMMANDS.items():
                # Extract base command (e.g., "/pr" from "/pr [url]")
                base_cmd = cmd.split()[0]
                if base_cmd.startswith(text):
                    yield Completion(
                        base_cmd,
                        start_position=-len(text),
                        display=cmd,
                        display_meta=description,
                    )

    # Setup history file
    history_file = Path.home() / ".emdash" / "cli_history"
    history_file.parent.mkdir(parents=True, exist_ok=True)
    history = FileHistory(str(history_file))

    # Key bindings: Enter submits, Alt+Enter inserts newline
    kb = KeyBindings()

    @kb.add("enter")
    def submit_on_enter(event):
        """Submit on Enter."""
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")  # Alt+Enter (Escape then Enter)
    @kb.add("c-j")  # Ctrl+J as alternative for newline
    def insert_newline_alt(event):
        """Insert a newline character with Alt+Enter or Ctrl+J."""
        event.current_buffer.insert_text("\n")

    @kb.add("c-v")  # Ctrl+V to paste (check for images)
    def paste_with_image_check(event):
        """Paste text or attach image from clipboard."""
        nonlocal attached_images
        from ...clipboard import get_clipboard_image, get_image_from_path

        # Try to get image from clipboard
        image_data = get_clipboard_image()
        if image_data:
            base64_data, img_format = image_data
            attached_images.append({"data": base64_data, "format": img_format})
            # Refresh prompt to show updated image list
            event.app.invalidate()
            return

        # Check if clipboard contains an image file path
        clipboard_data = event.app.clipboard.get_data()
        if clipboard_data and clipboard_data.text:
            text = clipboard_data.text.strip()
            # Remove escape characters from dragged paths (e.g., "path\ with\ spaces")
            clean_path = text.replace("\\ ", " ")
            # Check if it looks like an image file path
            if clean_path.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp')):
                image_data = get_image_from_path(clean_path)
                if image_data:
                    base64_data, img_format = image_data
                    attached_images.append({"data": base64_data, "format": img_format})
                    event.app.invalidate()
                    return

        # No image, do normal paste
        event.current_buffer.paste_clipboard_data(clipboard_data)

    def check_for_image_path(buff):
        """Check if buffer contains an image path and attach it."""
        nonlocal attached_images
        text = buff.text.strip()
        if not text:
            return
        # Clean escaped spaces from dragged paths
        clean_text = text.replace("\\ ", " ")
        if clean_text.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp')):
            from ...clipboard import get_image_from_path
            from prompt_toolkit.application import get_app
            image_data = get_image_from_path(clean_text)
            if image_data:
                base64_data, img_format = image_data
                attached_images.append({"data": base64_data, "format": img_format})
                # Clear the buffer
                buff.text = ""
                buff.cursor_position = 0
                # Refresh prompt to show image indicator
                try:
                    get_app().invalidate()
                except Exception:
                    pass

    session = PromptSession(
        history=history,
        completer=SlashCommandCompleter(),
        style=PROMPT_STYLE,
        complete_while_typing=True,
        multiline=True,
        prompt_continuation="... ",
        key_bindings=kb,
    )

    # Watch for image paths being pasted/dropped
    session.default_buffer.on_text_changed += check_for_image_path

    def get_prompt():
        """Get formatted prompt."""
        nonlocal attached_images
        parts = []
        # Show attached images above prompt
        if attached_images:
            image_tags = " ".join(f"[Image #{i+1}]" for i in range(len(attached_images)))
            parts.append(("class:prompt.image", f" {image_tags}\n"))
        parts.append(("class:prompt.prefix", "> "))
        return parts

    def show_help():
        """Show available commands."""
        console.print()
        console.print("[bold cyan]Available Commands[/bold cyan]")
        console.print()
        for cmd, desc in SLASH_COMMANDS.items():
            console.print(f"  [cyan]{cmd:12}[/cyan] {desc}")
        console.print()
        console.print("[dim]Type your task or question to interact with the agent.[/dim]")
        console.print()

    def handle_slash_command(cmd: str) -> bool:
        """Handle a slash command. Returns True if should continue, False to exit."""
        nonlocal current_mode, session_id, current_spec, pending_todos

        cmd_parts = cmd.strip().split(maxsplit=1)
        command = cmd_parts[0].lower()
        args = cmd_parts[1] if len(cmd_parts) > 1 else ""

        if command == "/quit" or command == "/exit" or command == "/q":
            return False

        elif command == "/help":
            show_help()

        elif command == "/plan":
            current_mode = AgentMode.PLAN
            # Reset session so next chat creates a new session with plan mode
            if session_id:
                session_id = None
                console.print("[bold green]✓ Plan mode activated[/bold green] [dim](session reset)[/dim]")
            else:
                console.print("[bold green]✓ Plan mode activated[/bold green]")

        elif command == "/code":
            current_mode = AgentMode.CODE
            # Reset session so next chat creates a new session with code mode
            if session_id:
                session_id = None
                console.print("[green]Switched to code mode (session reset)[/green]")
            else:
                console.print("[green]Switched to code mode[/green]")

        elif command == "/mode":
            console.print(f"Current mode: [bold]{current_mode.value}[/bold]")

        elif command == "/reset":
            session_id = None
            current_spec = None
            console.print("[dim]Session reset[/dim]")

        elif command == "/spec":
            if current_spec:
                console.print(Panel(Markdown(current_spec), title="Current Spec"))
            else:
                console.print("[dim]No spec available. Use plan mode to create one.[/dim]")

        elif command == "/pr":
            handle_pr(args, run_slash_command_task, client, renderer, model, max_iterations)

        elif command == "/projectmd":
            handle_projectmd(run_slash_command_task, client, renderer, model, max_iterations)

        elif command == "/research":
            handle_research(args, run_slash_command_task, client, renderer, model)

        elif command == "/status":
            handle_status(client)

        elif command == "/agents":
            handle_agents(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/todos":
            handle_todos(args, client, session_id, pending_todos)

        elif command == "/todo-add":
            handle_todo_add(args, client, session_id, pending_todos)

        elif command == "/session":
            # Use list wrappers to allow mutation
            session_id_ref = [session_id]
            current_spec_ref = [current_spec]
            current_mode_ref = [current_mode]
            loaded_messages_ref = [loaded_messages]

            handle_session(
                args, client, model,
                session_id_ref, current_spec_ref, current_mode_ref, loaded_messages_ref
            )

            # Update local variables from refs
            session_id = session_id_ref[0]
            current_spec = current_spec_ref[0]
            current_mode = current_mode_ref[0]
            loaded_messages[:] = loaded_messages_ref[0]

        elif command == "/hooks":
            handle_hooks(args)

        elif command == "/rules":
            handle_rules(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/skills":
            handle_skills(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/context":
            handle_context(renderer)

        elif command == "/mcp":
            handle_mcp(args)

        elif command == "/auth":
            handle_auth(args)

        else:
            console.print(f"[yellow]Unknown command: {command}[/yellow]")
            console.print("[dim]Type /help for available commands[/dim]")

        return True

    # Show welcome message
    from ... import __version__

    # Get current working directory
    cwd = Path.cwd()

    # Get git repo name (if in a git repo)
    git_repo = None
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, cwd=cwd
        )
        if result.returncode == 0:
            git_repo = Path(result.stdout.strip()).name
    except Exception:
        pass

    # Welcome banner
    console.print()
    console.print(f"[bold cyan] Emdash Code[/bold cyan] [dim]v{__version__}[/dim]")
    # Get display model name
    if model:
        display_model = model
    else:
        from emdash_core.agent.providers.factory import DEFAULT_MODEL
        display_model = DEFAULT_MODEL
    if git_repo:
        console.print(f"[dim]Repo:[/dim] [bold green]{git_repo}[/bold green] [dim]| Mode:[/dim] [bold]{current_mode.value}[/bold] [dim]| Model:[/dim] {display_model}")
    else:
        console.print(f"[dim]Mode:[/dim] [bold]{current_mode.value}[/bold] [dim]| Model:[/dim] {display_model}")
    console.print()

    while True:
        try:
            # Get user input
            user_input = session.prompt(get_prompt()).strip()

            if not user_input:
                continue

            # Check if input is an image file path (dragged file)
            clean_input = user_input.replace("\\ ", " ")
            if clean_input.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp')):
                from ...clipboard import get_image_from_path
                image_data = get_image_from_path(clean_input)
                if image_data:
                    base64_data, img_format = image_data
                    attached_images.append({"data": base64_data, "format": img_format})
                    continue  # Prompt again for actual message

            # Handle slash commands
            if user_input.startswith("/"):
                if not handle_slash_command(user_input):
                    break
                continue

            # Handle quit shortcuts
            if user_input.lower() in ("quit", "exit", "q"):
                break

            # Expand @file references in the message
            expanded_input, included_files = expand_file_references(user_input)
            if included_files:
                console.print(f"[dim]Including {len(included_files)} file(s): {', '.join(Path(f).name for f in included_files)}[/dim]")

            # Build options with current mode
            request_options = {
                **options,
                "mode": current_mode.value,
            }

            # Run agent with current mode
            try:
                # Prepare images for API call
                images_to_send = attached_images if attached_images else None

                if session_id:
                    stream = client.agent_continue_stream(
                        session_id, expanded_input, images=images_to_send
                    )
                else:
                    # Pass loaded_messages from saved session if available
                    stream = client.agent_chat_stream(
                        message=expanded_input,
                        model=model,
                        max_iterations=max_iterations,
                        options=request_options,
                        images=images_to_send,
                        history=loaded_messages if loaded_messages else None,
                    )
                    # Clear loaded_messages after first use
                    loaded_messages.clear()

                # Clear attached images after sending
                attached_images = []

                # Render the stream and capture any spec output
                result = render_with_interrupt(renderer, stream)

                # Check if we got a session ID back
                if result and result.get("session_id"):
                    session_id = result["session_id"]

                    # Add any pending todos now that we have a session
                    if pending_todos:
                        for todo_title in pending_todos:
                            try:
                                client.add_todo(session_id, todo_title)
                            except Exception:
                                pass  # Silently ignore errors adding todos
                        pending_todos.clear()

                # Check for spec output
                if result and result.get("spec"):
                    current_spec = result["spec"]

                # Handle clarifications (may be chained - loop until no more)
                while True:
                    clarification = result.get("clarification")
                    if not (clarification and session_id):
                        break

                    response = get_clarification_response(clarification)
                    if not response:
                        break

                    # Show the user's selection in the chat
                    console.print()
                    console.print(f"[dim]Selected:[/dim] [bold]{response}[/bold]")
                    console.print()

                    # Use dedicated clarification answer endpoint
                    try:
                        stream = client.clarification_answer_stream(session_id, response)
                        result = render_with_interrupt(renderer, stream)

                        # Update mode if user chose code
                        if "code" in response.lower():
                            current_mode = AgentMode.CODE
                    except Exception as e:
                        console.print(f"[red]Error continuing session: {e}[/red]")
                        break

                # Handle plan mode entry request (show approval menu)
                plan_mode_requested = result.get("plan_mode_requested")
                if plan_mode_requested is not None and session_id:
                    choice, feedback = show_plan_mode_approval_menu()

                    if choice == "approve":
                        current_mode = AgentMode.PLAN
                        console.print()
                        console.print("[bold green]✓ Plan mode activated[/bold green]")
                        console.print()
                        # Use the planmode approve endpoint
                        stream = client.planmode_approve_stream(session_id)
                        result = render_with_interrupt(renderer, stream)
                        # After approval, check if there's now a plan submitted
                        if result.get("plan_submitted"):
                            pass  # plan_submitted will be handled below
                    elif choice == "feedback":
                        # Use the planmode reject endpoint - stay in code mode
                        stream = client.planmode_reject_stream(session_id, feedback)
                        render_with_interrupt(renderer, stream)

                # Handle plan mode completion (show approval menu)
                # Only show menu when agent explicitly submits a plan via exit_plan tool
                plan_submitted = result.get("plan_submitted")
                should_show_plan_menu = (
                    current_mode == AgentMode.PLAN and
                    session_id and
                    plan_submitted is not None  # Agent called exit_plan tool
                )
                if should_show_plan_menu:
                    choice, feedback = show_plan_approval_menu()

                    if choice == "approve":
                        current_mode = AgentMode.CODE
                        # Use the plan approve endpoint which properly resets mode on server
                        stream = client.plan_approve_stream(session_id)
                        render_with_interrupt(renderer, stream)
                    elif choice == "feedback":
                        if feedback:
                            # Use the plan reject endpoint which keeps mode as PLAN on server
                            stream = client.plan_reject_stream(session_id, feedback)
                            render_with_interrupt(renderer, stream)
                        else:
                            console.print("[dim]No feedback provided[/dim]")
                            session_id = None
                            current_spec = None

                console.print()

            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")

        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted[/dim]")
            break
        except EOFError:
            break
