import typer

app = typer.Typer(
    name="agentroute",
    help="AgentRoute CLI - Build, deploy, and monetize AI agents.",
)


@app.callback(invoke_without_command=True)
def main(
    version: bool = typer.Option(False, "--version", "-v", help="Show version"),
) -> None:
    if version:
        typer.echo("agentroute-cli 0.1.0")
        raise typer.Exit()


if __name__ == "__main__":
    app()
