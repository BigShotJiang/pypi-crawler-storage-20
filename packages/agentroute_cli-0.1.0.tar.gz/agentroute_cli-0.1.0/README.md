# AgentRoute CLI

Command-line interface for AgentRoute.

## Installation

```bash
pip install agentroute-cli
```

## Usage

```bash
agentroute --help
```

## License

MIT
