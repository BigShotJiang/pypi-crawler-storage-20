"""Gostrap models."""
