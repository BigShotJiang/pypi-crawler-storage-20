"""Configurable GO sample generator."""
