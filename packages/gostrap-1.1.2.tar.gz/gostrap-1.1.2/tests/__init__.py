"""GoStrap's test cases."""
