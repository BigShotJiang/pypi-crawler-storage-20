"""Synchronous browser session and service."""

from cmdop.services.browser.sync.session import BrowserSession
from cmdop.services.browser.sync.service import BrowserService

__all__ = ["BrowserSession", "BrowserService"]
