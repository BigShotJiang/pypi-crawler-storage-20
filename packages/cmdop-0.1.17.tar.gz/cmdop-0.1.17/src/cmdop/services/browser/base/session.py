"""Base session class with shared logic."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from cmdop.services.browser.models import BrowserCookie, BrowserState
from cmdop.services.browser.js import (
    build_async_js,
    build_fetch_js,
    build_fetch_all_js,
    parse_json_result,
)

if TYPE_CHECKING:
    from cmdop.services.browser.base.service import BaseServiceMixin


class BaseSession(ABC):
    """
    Abstract base for browser sessions.

    Subclasses must implement:
    - _execute_script(script) -> str
    - All service delegation methods (navigate, click, etc.)
    - Context manager methods (__enter__/__exit__ or __aenter__/__aexit__)
    """

    def __init__(self, service: BaseServiceMixin, session_id: str) -> None:
        self._service = service
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        return self._session_id

    # === Abstract methods (sync/async differ) ===

    @abstractmethod
    def _call_service(self, method: str, *args: Any, **kwargs: Any) -> Any:
        """Call service method. Sync returns value, async returns coroutine."""
        ...

    # === Shared helpers (pure logic, no I/O) ===

    def _build_execute_js(self, code: str) -> str:
        """Build wrapped async JS code."""
        return build_async_js(code)

    def _parse_execute_js(self, result: str, raw: bool) -> dict | list | str | None:
        """Parse execute_js result."""
        if raw:
            return result
        return parse_json_result(result)

    def _build_fetch_json(self, url: str) -> str:
        """Build fetch JS for single URL."""
        return build_fetch_js(url)

    def _build_fetch_all(
        self,
        urls: dict[str, str],
        headers: dict[str, str] | None,
        credentials: bool,
    ) -> str:
        """Build fetch_all JS code."""
        return build_fetch_all_js(urls, headers, credentials)

    def _parse_fetch_all(self, result: Any) -> dict[str, Any]:
        """Ensure fetch_all returns dict."""
        return result if isinstance(result, dict) else {}
