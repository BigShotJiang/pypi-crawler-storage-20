"""Base classes for browser sessions and services."""

from cmdop.services.browser.base.session import BaseSession
from cmdop.services.browser.base.service import BaseServiceMixin

__all__ = ["BaseSession", "BaseServiceMixin"]
