"""Scroll JavaScript builders for browser automation."""

from __future__ import annotations

import json


def build_scroll_js(
    direction: str = "down",
    amount: int = 500,
    selector: str | None = None,
) -> str:
    """
    Build JS for scrolling.

    Args:
        direction: "up", "down", "left", "right"
        amount: Pixels to scroll (ignored if selector provided)
        selector: CSS selector to scroll into view
    """
    if selector:
        return f"""
        (function() {{
            const el = document.querySelector("{selector}");
            if (el) {{
                el.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                return JSON.stringify({{ success: true }});
            }}
            return JSON.stringify({{ success: false, error: 'Element not found' }});
        }})()
        """

    scroll_map = {
        "down": f"window.scrollBy(0, {amount})",
        "up": f"window.scrollBy(0, -{amount})",
        "right": f"window.scrollBy({amount}, 0)",
        "left": f"window.scrollBy(-{amount}, 0)",
    }
    scroll_code = scroll_map.get(direction, scroll_map["down"])

    return f"""
    (function() {{
        const before = window.scrollY;
        {scroll_code};
        return JSON.stringify({{
            success: true,
            scrollY: window.scrollY,
            scrolledBy: window.scrollY - before,
            atBottom: (window.innerHeight + window.scrollY) >= document.body.scrollHeight
        }});
    }})()
    """


def build_scroll_to_bottom_js() -> str:
    """Build JS to scroll to page bottom."""
    return """
    (function() {
        const before = window.scrollY;
        window.scrollTo(0, document.body.scrollHeight);
        return JSON.stringify({
            success: true,
            scrollY: window.scrollY,
            scrolledBy: window.scrollY - before,
            atBottom: true
        });
    })()
    """


def build_infinite_scroll_js(
    seen_keys: list[str],
    key_selector: str = "a[href]",
    key_attr: str = "href",
    container_selector: str = "body",
) -> str:
    """
    Build JS for infinite scroll with deduplication.

    Args:
        seen_keys: List of already seen keys (e.g., URLs)
        key_selector: CSS selector for key elements
        key_attr: Attribute to use as key (default: href)
        container_selector: Container to find elements in

    Returns:
        JS that returns {new_keys: [...], at_bottom: bool}
    """
    seen_json = json.dumps(seen_keys)
    return f"""
    (function() {{
        const seen = new Set({seen_json});
        const container = document.querySelector("{container_selector}");
        if (!container) return JSON.stringify({{ new_keys: [], at_bottom: true, error: 'Container not found' }});

        const elements = container.querySelectorAll("{key_selector}");
        const newKeys = [];

        elements.forEach(el => {{
            const key = el.getAttribute("{key_attr}") || el.textContent.trim();
            if (key && !seen.has(key)) {{
                seen.add(key);
                newKeys.push(key);
            }}
        }});

        const atBottom = (window.innerHeight + window.scrollY) >= document.body.scrollHeight - 100;

        return JSON.stringify({{
            new_keys: newKeys,
            at_bottom: atBottom,
            total_seen: seen.size
        }});
    }})()
    """


def build_get_scroll_info_js() -> str:
    """Build JS to get current scroll position and page dimensions."""
    return """
    (function() {
        return JSON.stringify({
            scrollX: window.scrollX,
            scrollY: window.scrollY,
            pageHeight: document.body.scrollHeight,
            pageWidth: document.body.scrollWidth,
            viewportHeight: window.innerHeight,
            viewportWidth: window.innerWidth,
            atBottom: (window.innerHeight + window.scrollY) >= document.body.scrollHeight - 10,
            atTop: window.scrollY <= 10
        });
    })()
    """
