from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BrowserCreateSessionRequest(_message.Message):
    __slots__ = ("session_id", "provider", "profile_id", "start_url", "headless", "width", "height")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    PROFILE_ID_FIELD_NUMBER: _ClassVar[int]
    START_URL_FIELD_NUMBER: _ClassVar[int]
    HEADLESS_FIELD_NUMBER: _ClassVar[int]
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    provider: str
    profile_id: str
    start_url: str
    headless: bool
    width: int
    height: int
    def __init__(self, session_id: _Optional[str] = ..., provider: _Optional[str] = ..., profile_id: _Optional[str] = ..., start_url: _Optional[str] = ..., headless: bool = ..., width: _Optional[int] = ..., height: _Optional[int] = ...) -> None: ...

class BrowserCreateSessionResponse(_message.Message):
    __slots__ = ("success", "browser_session_id", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    browser_session_id: str
    error: str
    def __init__(self, success: bool = ..., browser_session_id: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserCloseSessionRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ...) -> None: ...

class BrowserCloseSessionResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class BrowserNavigateRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "url", "timeout_ms")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    url: str
    timeout_ms: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., url: _Optional[str] = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class BrowserNavigateResponse(_message.Message):
    __slots__ = ("success", "final_url", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    FINAL_URL_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    final_url: str
    error: str
    def __init__(self, success: bool = ..., final_url: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserClickRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "selector", "timeout_ms")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    selector: str
    timeout_ms: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., selector: _Optional[str] = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class BrowserClickResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class BrowserTypeRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "selector", "text", "human_like", "clear_first")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    HUMAN_LIKE_FIELD_NUMBER: _ClassVar[int]
    CLEAR_FIRST_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    selector: str
    text: str
    human_like: bool
    clear_first: bool
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., selector: _Optional[str] = ..., text: _Optional[str] = ..., human_like: bool = ..., clear_first: bool = ...) -> None: ...

class BrowserTypeResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class BrowserWaitRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "selector", "timeout_ms")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    TIMEOUT_MS_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    selector: str
    timeout_ms: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., selector: _Optional[str] = ..., timeout_ms: _Optional[int] = ...) -> None: ...

class BrowserWaitResponse(_message.Message):
    __slots__ = ("success", "found", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    FOUND_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    found: bool
    error: str
    def __init__(self, success: bool = ..., found: bool = ..., error: _Optional[str] = ...) -> None: ...

class BrowserExtractRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "selector", "attribute", "limit")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    selector: str
    attribute: str
    limit: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., selector: _Optional[str] = ..., attribute: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class BrowserExtractResponse(_message.Message):
    __slots__ = ("success", "values", "count", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    VALUES_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    values: _containers.RepeatedScalarFieldContainer[str]
    count: int
    error: str
    def __init__(self, success: bool = ..., values: _Optional[_Iterable[str]] = ..., count: _Optional[int] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserExtractRegexRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "pattern", "from_html", "limit")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    PATTERN_FIELD_NUMBER: _ClassVar[int]
    FROM_HTML_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    pattern: str
    from_html: bool
    limit: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., pattern: _Optional[str] = ..., from_html: bool = ..., limit: _Optional[int] = ...) -> None: ...

class BrowserExtractRegexResponse(_message.Message):
    __slots__ = ("success", "matches", "count", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MATCHES_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    matches: _containers.RepeatedScalarFieldContainer[str]
    count: int
    error: str
    def __init__(self, success: bool = ..., matches: _Optional[_Iterable[str]] = ..., count: _Optional[int] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserGetHTMLRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "selector")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    selector: str
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., selector: _Optional[str] = ...) -> None: ...

class BrowserGetHTMLResponse(_message.Message):
    __slots__ = ("success", "html", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    HTML_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    html: str
    error: str
    def __init__(self, success: bool = ..., html: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserGetTextRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "selector")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    selector: str
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., selector: _Optional[str] = ...) -> None: ...

class BrowserGetTextResponse(_message.Message):
    __slots__ = ("success", "text", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    text: str
    error: str
    def __init__(self, success: bool = ..., text: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserExecuteScriptRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "script")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SCRIPT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    script: str
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., script: _Optional[str] = ...) -> None: ...

class BrowserExecuteScriptResponse(_message.Message):
    __slots__ = ("success", "result", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    result: str
    error: str
    def __init__(self, success: bool = ..., result: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserScreenshotRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "full_page", "format", "quality")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    FULL_PAGE_FIELD_NUMBER: _ClassVar[int]
    FORMAT_FIELD_NUMBER: _ClassVar[int]
    QUALITY_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    full_page: bool
    format: str
    quality: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., full_page: bool = ..., format: _Optional[str] = ..., quality: _Optional[int] = ...) -> None: ...

class BrowserScreenshotResponse(_message.Message):
    __slots__ = ("success", "data", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    data: bytes
    error: str
    def __init__(self, success: bool = ..., data: _Optional[bytes] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserGetStateRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ...) -> None: ...

class BrowserGetStateResponse(_message.Message):
    __slots__ = ("success", "url", "title", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    url: str
    title: str
    error: str
    def __init__(self, success: bool = ..., url: _Optional[str] = ..., title: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserCookie(_message.Message):
    __slots__ = ("name", "value", "domain", "path", "secure", "http_only", "same_site", "expires")
    NAME_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    SECURE_FIELD_NUMBER: _ClassVar[int]
    HTTP_ONLY_FIELD_NUMBER: _ClassVar[int]
    SAME_SITE_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_FIELD_NUMBER: _ClassVar[int]
    name: str
    value: str
    domain: str
    path: str
    secure: bool
    http_only: bool
    same_site: str
    expires: int
    def __init__(self, name: _Optional[str] = ..., value: _Optional[str] = ..., domain: _Optional[str] = ..., path: _Optional[str] = ..., secure: bool = ..., http_only: bool = ..., same_site: _Optional[str] = ..., expires: _Optional[int] = ...) -> None: ...

class BrowserSetCookiesRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "cookies")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    COOKIES_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    cookies: _containers.RepeatedCompositeFieldContainer[BrowserCookie]
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., cookies: _Optional[_Iterable[_Union[BrowserCookie, _Mapping]]] = ...) -> None: ...

class BrowserSetCookiesResponse(_message.Message):
    __slots__ = ("success", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    error: str
    def __init__(self, success: bool = ..., error: _Optional[str] = ...) -> None: ...

class BrowserGetCookiesRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "domain")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    domain: str
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., domain: _Optional[str] = ...) -> None: ...

class BrowserGetCookiesResponse(_message.Message):
    __slots__ = ("success", "cookies", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    COOKIES_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    cookies: _containers.RepeatedCompositeFieldContainer[BrowserCookie]
    error: str
    def __init__(self, success: bool = ..., cookies: _Optional[_Iterable[_Union[BrowserCookie, _Mapping]]] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserValidateSelectorsRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "item", "fields")
    class FieldsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    FIELDS_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    item: str
    fields: _containers.ScalarMap[str, str]
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., item: _Optional[str] = ..., fields: _Optional[_Mapping[str, str]] = ...) -> None: ...

class BrowserValidateSelectorsResponse(_message.Message):
    __slots__ = ("success", "valid", "counts", "samples", "errors", "error")
    class CountsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: int
        def __init__(self, key: _Optional[str] = ..., value: _Optional[int] = ...) -> None: ...
    class SamplesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    VALID_FIELD_NUMBER: _ClassVar[int]
    COUNTS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    ERRORS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    valid: bool
    counts: _containers.ScalarMap[str, int]
    samples: _containers.ScalarMap[str, str]
    errors: _containers.RepeatedScalarFieldContainer[str]
    error: str
    def __init__(self, success: bool = ..., valid: bool = ..., counts: _Optional[_Mapping[str, int]] = ..., samples: _Optional[_Mapping[str, str]] = ..., errors: _Optional[_Iterable[str]] = ..., error: _Optional[str] = ...) -> None: ...

class BrowserExtractDataRequest(_message.Message):
    __slots__ = ("session_id", "browser_session_id", "item", "fields_json", "limit")
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    BROWSER_SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    ITEM_FIELD_NUMBER: _ClassVar[int]
    FIELDS_JSON_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    session_id: str
    browser_session_id: str
    item: str
    fields_json: str
    limit: int
    def __init__(self, session_id: _Optional[str] = ..., browser_session_id: _Optional[str] = ..., item: _Optional[str] = ..., fields_json: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class BrowserExtractDataResponse(_message.Message):
    __slots__ = ("success", "items_json", "count", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ITEMS_JSON_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    items_json: str
    count: int
    error: str
    def __init__(self, success: bool = ..., items_json: _Optional[str] = ..., count: _Optional[int] = ..., error: _Optional[str] = ...) -> None: ...
