"""Middleware implementations for FastMCP."""
