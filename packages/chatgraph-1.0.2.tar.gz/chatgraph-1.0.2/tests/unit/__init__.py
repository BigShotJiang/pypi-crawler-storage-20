"""Testes unitários do ChatGraph."""
