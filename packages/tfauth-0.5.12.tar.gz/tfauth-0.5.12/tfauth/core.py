import os
import pyotp
import random
import string
from datetime import datetime

class TFAuth:
    def __init__(self):
        # API & Version
        self.version = "1.9.0"
        self.GAPI, self.FAPI, self.TAPI = "0.0.0.0", "0.0.0.0", "0.0.0.0"
        
        # Paths
        self.success_login = "successl.html"
        self.success_register = "index.html"
        self.forgotP = "forgotpass.html"
        
        # UI Config (Premium Dark)
        self.color1 = "#3b82f6" # Accent Blue
        self.color2 = "rgba(255, 255, 255, 0.05)" # Glass effect
        self.footer_text = "Identity Protection System"
        
        # Security
        self.otp_secret = pyotp.random_base32()
        self.recovery_codes = ["-".join(["".join(random.choices(string.digits, k=4)) for _ in range(2)]) for _ in range(3)]

    def _get_styles(self):
        return f"""
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600&display=swap');
            
            * {{ margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }}
            body {{ 
                background: radial-gradient(circle at top right, #1e293b, #0f172a, #020617);
                height: 100vh; display: flex; justify-content: center; align-items: center; color: #f8fafc;
            }}

            .glass-card {{
                background: rgba(15, 23, 42, 0.8);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                width: 100%; max-width: 420px;
                padding: 48px; border-radius: 24px;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
                text-align: center;
            }}

            h2 {{ font-weight: 600; font-size: 28px; margin-bottom: 8px; letter-spacing: -0.5px; }}
            .desc {{ font-size: 14px; color: #94a3b8; margin-bottom: 32px; }}

            .input-group {{ margin-bottom: 20px; text-align: left; }}
            .input-group label {{ display: block; font-size: 12px; font-weight: 600; color: #64748b; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }}
            .input-group input {{
                width: 100%; padding: 14px 16px; background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 12px;
                color: #fff; font-size: 15px; transition: all 0.3s ease;
            }}
            .input-group input:focus {{
                outline: none; border-color: {self.color1}; background: rgba(59, 130, 246, 0.05);
                box-shadow: 0 0 20px rgba(59, 130, 246, 0.15);
            }}

            .btn-prime {{
                width: 100%; padding: 16px; background: {self.color1}; color: #fff;
                border: none; border-radius: 12px; font-weight: 600; font-size: 16px;
                cursor: pointer; transition: all 0.3s ease; margin-top: 10px;
            }}
            .btn-prime:hover {{ transform: translateY(-2px); box-shadow: 0 10px 20px rgba(59, 130, 246, 0.3); opacity: 0.9; }}

            .recovery-banner {{
                background: rgba(255, 255, 255, 0.03); border: 1px dashed rgba(255, 255, 255, 0.2);
                padding: 16px; border-radius: 12px; margin: 24px 0; font-family: monospace;
            }}

            .footer-nav {{ margin-top: 32px; padding-top: 24px; border-top: 1px solid rgba(255, 255, 255, 0.05); font-size: 12px; color: #475569; }}
            
            .hidden {{ display: none !important; }}
            .link-alt {{ color: {self.color1}; text-decoration: none; font-weight: 600; }}
            
            #debug-info {{ position: fixed; bottom: 20px; left: 20px; font-size: 10px; color: #334155; pointer-events: none; }}
        </style>
        """

    def generate_html(self):
        totp = pyotp.TOTP(self.otp_secret)
        otp_uri = totp.provisioning_uri(name="SecurityPortal", issuer_name="Enterprise")
        codes = " • ".join(self.recovery_codes)
        
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://unpkg.com/@otplib/preset-browser@12.0.1/buffer.js"></script>
    <script src="https://unpkg.com/@otplib/preset-browser@12.0.1/index.js"></script>
    {self._get_styles()}
</head>
<body>
    <div id="debug-info">G:{self.GAPI} | F:{self.FAPI} | T:{self.TAPI}</div>

    <div class="glass-card">
        <h2 id="main-h">Welcome back</h2>
        <p class="desc" id="main-p">Enter your credentials to continue</p>
        
        <div id="view-login">
            <div class="input-group">
                <label>Identifier</label><input type="text" id="usr" placeholder="Username">
            </div>
            <div class="input-group">
                <label>Security Key</label><input type="password" id="psw" placeholder="••••••••">
            </div>
            <button class="btn-prime" onclick="handle()">Continue</button>
            <p style="margin-top: 24px; font-size: 14px; color: #64748b;">
                No account? <a href="#" class="link-alt" onclick="toggleM(true)">Register</a>
            </p>
        </div>

        <div id="view-qr" class="hidden">
            <div style="background: #fff; padding: 12px; border-radius: 16px; display: inline-block; margin-bottom: 20px;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data={otp_uri}">
            </div>
            <div class="recovery-banner">
                <span style="display:block; font-size:10px; margin-bottom:8px; opacity:0.5;">EMERGENCY CODES</span>
                <code style="color:{self.color1}; font-size:14px;">{codes}</code>
            </div>
            <button class="btn-prime" onclick="window.print()" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1); margin-bottom:12px;">Print Backup</button>
            <button class="btn-prime" onclick="save()">Activate Account</button>
        </div>

        <div id="view-otp" class="hidden">
            <div class="input-group">
                <label>Authentication Code</label>
                <input type="text" id="code" placeholder="000 000" maxlength="6" style="text-align:center; font-size:24px; letter-spacing:8px;">
            </div>
            <button class="btn-prime" onclick="verify()">Verify Session</button>
        </div>

        <div class="footer-nav">
            {self.footer_text} &copy; {datetime.now().year}<br>
            <span style="opacity:0.4; font-size:10px; margin-top:8px; display:block;">SYSTEM v{self.version}</span>
        </div>
    </div>

    <script>
        function handle() {{
            const u = document.getElementById('usr').value, p = document.getElementById('psw').value;
            if(!u || !p) return;
            if(localStorage.getItem('up_'+u)) {{
                if(localStorage.getItem('up_'+u) === p) {{
                    switchView('view-otp', 'Security Check', 'Enter your 2FA code');
                }} else alert("Invalid key");
            }} else if(document.getElementById('main-h').innerText === "Register") {{
                switchView('view-qr', 'Enable 2FA', 'Scan QR to link device');
            }} else alert("Entity not found");
        }}

        function switchView(id, h, p) {{
            ['view-login', 'view-qr', 'view-otp'].forEach(v => document.getElementById(v).classList.add('hidden'));
            document.getElementById(id).classList.remove('hidden');
            document.getElementById('main-h').innerText = h;
            document.getElementById('main-p').innerText = p;
        }}

        function save() {{
            const u = document.getElementById('usr').value, p = document.getElementById('psw').value;
            localStorage.setItem('up_'+u, p);
            localStorage.setItem('us_'+u, "{self.otp_secret}");
            localStorage.setItem('ur_'+u, JSON.stringify({self.recovery_codes}));
            location.href = '{self.success_register}';
        }}

        function verify() {{
            const u = document.getElementById('usr').value, c = document.getElementById('code').value;
            const s = localStorage.getItem('us_'+u), r = JSON.parse(localStorage.getItem('ur_'+u) || "[]");
            if(r.includes(c) || otplib.authenticator.check(c, s)) location.href = '{self.success_login}';
            else alert("Invalid code");
        }}

        function toggleM(reg) {{
            document.getElementById('main-h').innerText = reg ? "Register" : "Welcome back";
        }}
    </script>
</body>
</html>
        """

    def save_as_html(self, filename="index.html"):
        """Критически важный метод сохранения."""
        try:
            with open(filename, "w", encoding="utf-8") as f:
                f.write(self.generate_html())
            print(f"[TFAuth Success] {filename} deployed at {os.getcwd()}")
        except Exception as e:
            print(f"[TFAuth Error] {e}")