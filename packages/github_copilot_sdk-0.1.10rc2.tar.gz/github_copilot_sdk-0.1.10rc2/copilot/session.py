"""
Copilot Session - represents a single conversation session with the CLI
"""

import inspect
import threading
from typing import Any, Callable, Dict, List, Optional, Set

from .generated.session_events import session_event_from_dict
from .types import (
    MessageOptions,
    PermissionHandler,
    SessionEvent,
    Tool,
    ToolHandler,
)


class CopilotSession:
    """Represents a single conversation session with the Copilot CLI"""

    def __init__(self, session_id: str, client: Any):
        self.session_id = session_id
        self._client = client
        self._event_handlers: Set[Callable[[SessionEvent], None]] = set()
        self._event_handlers_lock = threading.Lock()
        self._tool_handlers: Dict[str, ToolHandler] = {}
        self._tool_handlers_lock = threading.Lock()
        self._permission_handler: Optional[PermissionHandler] = None
        self._permission_handler_lock = threading.Lock()

    async def send(self, options: MessageOptions) -> str:
        """
        Send a message to this session

        Args:
            options: Message options including prompt and optional attachments

        Returns:
            Message ID
        """
        response = await self._client.request(
            "session.send",
            {
                "sessionId": self.session_id,
                "prompt": options["prompt"],
                "attachments": options.get("attachments"),
                "mode": options.get("mode"),
            },
        )
        return response["messageId"]

    def on(self, handler: Callable[[SessionEvent], None]) -> Callable[[], None]:
        """
        Subscribe to events from this session

        Args:
            handler: Event handler function

        Returns:
            Unsubscribe function
        """
        with self._event_handlers_lock:
            self._event_handlers.add(handler)

        def unsubscribe():
            with self._event_handlers_lock:
                self._event_handlers.discard(handler)

        return unsubscribe

    def _dispatch_event(self, event: SessionEvent) -> None:
        """Internal: dispatch an event to all handlers"""
        with self._event_handlers_lock:
            handlers = list(self._event_handlers)

        for handler in handlers:
            try:
                handler(event)
            except Exception as e:
                print(f"Error in session event handler: {e}")

    def _register_tools(self, tools: Optional[List[Tool]]) -> None:
        with self._tool_handlers_lock:
            self._tool_handlers.clear()
            if not tools:
                return
            for tool in tools:
                if not tool.name or not tool.handler:
                    continue
                self._tool_handlers[tool.name] = tool.handler

    def _get_tool_handler(self, name: str) -> Optional[ToolHandler]:
        with self._tool_handlers_lock:
            return self._tool_handlers.get(name)

    def _register_permission_handler(self, handler: Optional[PermissionHandler]) -> None:
        with self._permission_handler_lock:
            self._permission_handler = handler

    async def _handle_permission_request(self, request: dict) -> dict:
        """Internal: handle permission request from server"""
        with self._permission_handler_lock:
            handler = self._permission_handler

        if not handler:
            # No handler registered, deny permission
            return {"kind": "denied-no-approval-rule-and-could-not-request-from-user"}

        try:
            result = handler(request, {"session_id": self.session_id})
            if inspect.isawaitable(result):
                result = await result
            return result
        except Exception:  # pylint: disable=broad-except
            # Handler failed, deny permission
            return {"kind": "denied-no-approval-rule-and-could-not-request-from-user"}

    async def get_messages(self) -> List[SessionEvent]:
        """
        Get all events/messages from this session

        Returns:
            List of session events
        """
        response = await self._client.request("session.getMessages", {"sessionId": self.session_id})
        # Convert dict events to SessionEvent objects
        events_dicts = response["events"]
        return [session_event_from_dict(event_dict) for event_dict in events_dicts]

    async def destroy(self) -> None:
        """Destroy this session and free resources"""
        await self._client.request("session.destroy", {"sessionId": self.session_id})
        with self._event_handlers_lock:
            self._event_handlers.clear()
        with self._tool_handlers_lock:
            self._tool_handlers.clear()
        with self._permission_handler_lock:
            self._permission_handler = None

    async def abort(self) -> None:
        """Abort the currently processing message in this session"""
        await self._client.request("session.abort", {"sessionId": self.session_id})
