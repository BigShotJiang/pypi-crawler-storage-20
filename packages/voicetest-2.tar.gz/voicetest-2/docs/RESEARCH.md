# voicetest Research Notes

Background research informing design decisions. See M1_SPEC.md for architecture and implementation.

---

## OSS Voice Agent Testing Landscape

### voice-lab (saharmor/voice-lab)
Apache 2.0 licensed testing framework. 159 stars.

**What it does:**
- Text-only testing of LLM + prompt combinations
- Custom metrics via JSON + LLM-as-judge
- Model comparison (e.g., GPT-4 vs GPT-4-mini)
- Persona-based simulation

**What it lacks:**
- No workflow/conversation flow support
- No Retell/Vapi/LiveKit format compatibility
- No node traversal validation
- No multi-turn conversation orchestration

**Conclusion:** Good for prompt iteration, not for workflow testing.

### LiveKit Agents Test Framework
Built into livekit-agents SDK.

**What it does:**
```python
async with AgentSession(llm=llm) as sess:
    await sess.start(MyAgent())
    result = await sess.run(user_input="Hello")
    result.expect.next_event().is_message(role="assistant")
    await result.expect.next_event().judge(llm, intent="should ask what user wants")
```

**Characteristics:**
- Turn-by-turn (not autonomous simulation)
- Per-turn assertions and LLM judging
- Requires LiveKit Agent implementation
- No support for external configs (Retell/Vapi)

**Conclusion:** Good for LiveKit-native agents, not for cross-platform testing.

---

## Commercial Voice Agent Testing Tools

| Tool | Approach | Platforms | Pricing |
|------|----------|-----------|---------|
| **Hamming AI** | Auto-generates tests, two-step LLM evaluation | Vapi, Retell, 11Labs | $400+/mo |
| **Coval** | Langfuse integration, simulation | Custom | Enterprise |
| **Maxim AI** | Full platform (simulation + eval + observability) | Custom | Enterprise |
| **Cekura** | Auto-generates scenarios from agent description | Custom | Unknown |
| **Roark** | Voice-specific latency + ASR quality testing | Custom | Enterprise |

**Key insight from Hamming:** 95-96% agreement with human evaluators using two-step pipeline:
1. Extract facts from transcript
2. Judge against criteria using extracted facts

---

## Platform Testing Approaches

### Retell Simulation Testing
Built-in dashboard feature.

**Test case format:**
```markdown
## Identity
Your name is Mike.
Your date of birth is June 10, 1999.
Your order number is 7891273.

## Goal
Your primary objective is to return the package you received and get a refund.

## Personality  
You are a patient customer. However, if the conversation becomes too long 
or complicated, you will show signs of impatience.
```

**Metrics:** Numbered criteria evaluated by LLM after conversation completes.

**Limitations:** 
- Dashboard-only (no API)
- No CI/CD integration
- No cross-platform testing

### Vapi Evals
API-based testing framework.

**Judge types:**
- `exact` — String match
- `regex` — Pattern match
- `ai` — LLM judge with custom prompt

**Features:**
- Mock conversations via API
- Tool call validation
- `continuePlan` for flow control (exit on failure, override responses)
- Squad handoff testing

**Test structure:**
```json
{
  "messages": [
    {"role": "user", "content": "Hello"},
    {"role": "assistant", "judgePlan": {"type": "regex", "content": ".*help.*"}}
  ]
}
```

**Limitation:** Turn-by-turn scripting, not autonomous simulation.

---

## DSPy vs BAML Analysis

### BAML Strengths
- Schema-aligned parsing (SAP) — recovers from minor formatting errors
- ~300 fewer prompt tokens than JSON schema
- 2-4x faster than OpenAI function calling
- Type-safe structured outputs

### DSPy Strengths
- Prompt optimization (GEPA, MIPROv2)
- LiteLLM integration for provider flexibility
- Composable signatures
- Assertions and metrics built-in

### DSPy + BAML Together
```python
from dspy.adapters.baml_adapter import BAMLAdapter

llm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=llm, adapter=BAMLAdapter())
```

BAML adapter uses BAML's prompting format inside DSPy, getting benefits of both.

**Decision:** Use DSPy with BAMLAdapter for judges. Enables prompt optimization while getting efficient structured outputs.

---

## LiveKit Plugin Architecture (Background)

### Core Plugin Model
Abstract base classes for STT, TTS, LLM, VAD:

```python
class CustomTTS(tts.TTS):
    async def synthesize(self, text: str) -> AsyncGenerator[SynthesizedAudio, None]:
        ...
```

### Available Plugins (48+)
- **LLM:** OpenAI, Anthropic, Google, Mistral, Groq, Cerebras, Azure
- **STT:** Deepgram, AssemblyAI, Google, OpenAI Whisper, Azure
- **TTS:** Cartesia, ElevenLabs, Rime, OpenAI, Google, Azure
- **VAD:** Silero (default)

### AgentSession
Orchestrates STT → LLM → TTS pipeline with turn detection. 

Key for voicetest: AgentSession works in **text-only mode** — no audio pipeline required for testing. Pass `user_input` string directly.

---

## Platform Transition Model Equivalence

All three platforms use LLM-based transition evaluation:

| Platform | Transition Mechanism |
|----------|---------------------|
| **Retell** | LLM evaluates edge condition prompts |
| **Vapi** | LLM decides tool calls / squad transfers |
| **LiveKit** | LLM calls tools that return `(Agent, str)` handoff tuples |

**Implication:** Can model all as "LLM decides when to call transition tool" → unified execution via LiveKit AgentSession with generated tools per transition.

---

## Fidelity Considerations

Execution engine **approximates** source platform behavior. Expected differences:

1. **LLM routing** — Each platform has proprietary logic for when/how transitions are evaluated
2. **Timing** — When transition conditions are checked relative to response generation
3. **Prompt wrapping** — Undocumented system prompts added by platforms
4. **Tool call formatting** — Subtle differences in how tools are presented to LLM

**Mitigation strategy:**
- Test against known transcripts from production
- Allow tuning tool descriptions in test config
- Document behavioral differences per importer
- Accept "close enough for useful testing" not "bit-for-bit identical"

---

## Key Research Conclusions

1. **No good OSS option exists** for testing voice agent workflows across platforms

2. **Retell's Identity/Goal/Personality format** is a good simulation prompt structure — widely understood, easy to author

3. **DSPy with BAMLAdapter** is optimal for judges — combines optimization with efficient structured outputs

4. **LiveKit AgentSession** can serve as execution engine even for non-LiveKit agents — text-only mode, no infrastructure dependency

5. **Autonomous simulation** (not turn-by-turn scripting) is the key differentiator — matches how Retell does it, more realistic testing

6. **Platform transition models are functionally equivalent** — all reducible to "LLM calls tools to trigger transitions"
