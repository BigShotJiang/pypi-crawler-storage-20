"""Interactive REPL mode for the agent CLI."""

import subprocess
import sys
import time
import threading
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from .constants import AgentMode, SLASH_COMMANDS
from .onboarding import is_first_run, run_onboarding
from .help import show_command_help
from .session_restore import get_recent_session, show_session_restore_prompt
from ...design import (
    header, footer, Colors, STATUS_ACTIVE, DOT_BULLET,
    ARROW_PROMPT, SEPARATOR_WIDTH,
)


def show_welcome_banner(
    version: str,
    git_repo: str | None,
    git_branch: str | None,
    mode: str,
    model: str,
    console: Console,
) -> None:
    """Display clean welcome banner with zen styling."""
    console.print()

    # Simple header
    console.print(f"[{Colors.MUTED}]{header('emdash', SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print(f"  [{Colors.DIM}]v{version}[/{Colors.DIM}]")
    console.print()

    # Info section
    if git_repo:
        branch_display = f" [{Colors.WARNING}]{git_branch}[/{Colors.WARNING}]" if git_branch else ""
        console.print(f"  [{Colors.DIM}]repo[/{Colors.DIM}]     [{Colors.SUCCESS}]{git_repo}[/{Colors.SUCCESS}]{branch_display}")

    mode_color = Colors.WARNING if mode == "plan" else Colors.SUCCESS
    console.print(f"  [{Colors.DIM}]mode[/{Colors.DIM}]     [{mode_color}]{mode}[/{mode_color}]")
    console.print(f"  [{Colors.DIM}]model[/{Colors.DIM}]    [{Colors.MUTED}]{model}[/{Colors.MUTED}]")
    console.print()

    console.print(f"[{Colors.MUTED}]{footer(SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
    console.print()

    # Quick tips
    console.print(f"  [{Colors.DIM}]› /help commands   › @file include files   › Ctrl+C cancel[/{Colors.DIM}]")
    console.print()
from .file_utils import expand_file_references, fuzzy_find_files
from .menus import (
    get_clarification_response,
    show_plan_approval_menu,
    show_plan_mode_approval_menu,
)
from .handlers import (
    handle_agents,
    handle_session,
    handle_todos,
    handle_todo_add,
    handle_hooks,
    handle_rules,
    handle_skills,
    handle_index,
    handle_mcp,
    handle_registry,
    handle_auth,
    handle_doctor,
    handle_verify,
    handle_verify_loop,
    handle_setup,
    handle_status,
    handle_pr,
    handle_projectmd,
    handle_research,
    handle_context,
    handle_compact,
    handle_diff,
    handle_telegram,
)

console = Console()


def render_with_interrupt(renderer, stream) -> dict:
    """Render stream with ESC key interrupt support.

    Args:
        renderer: SSE renderer instance
        stream: SSE stream iterator

    Returns:
        Result dict from renderer, with 'interrupted' flag
    """
    from ...keyboard import KeyListener

    interrupt_event = threading.Event()

    def on_escape():
        interrupt_event.set()

    listener = KeyListener(on_escape)

    try:
        listener.start()
        result = renderer.render_stream(stream, interrupt_event=interrupt_event)
        return result
    finally:
        listener.stop()


def run_single_task(
    client,
    renderer,
    task: str,
    model: str | None,
    max_iterations: int,
    options: dict,
):
    """Run a single agent task."""
    import click

    try:
        stream = client.agent_chat_stream(
            message=task,
            model=model,
            max_iterations=max_iterations,
            options=options,
        )
        result = render_with_interrupt(renderer, stream)
        if result.get("interrupted"):
            console.print("[dim]Task interrupted. You can continue or start a new task.[/dim]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        raise click.Abort()


def run_slash_command_task(
    client,
    renderer,
    model: str | None,
    max_iterations: int,
    task: str,
    options: dict,
):
    """Run a task from a slash command."""
    try:
        stream = client.agent_chat_stream(
            message=task,
            model=model,
            max_iterations=max_iterations,
            options=options,
        )
        result = render_with_interrupt(renderer, stream)
        if result.get("interrupted"):
            console.print("[dim]Task interrupted.[/dim]")
        console.print()
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


def run_interactive(
    client,
    renderer,
    model: str | None,
    max_iterations: int,
    options: dict,
):
    """Run interactive REPL mode with slash commands."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import FileHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.styles import Style
    from prompt_toolkit.key_binding import KeyBindings

    # Current mode
    current_mode = AgentMode(options.get("mode", "code"))
    session_id = None
    current_spec = None
    # Attached images for next message
    attached_images: list[dict] = []
    # Loaded messages from saved session (for restoration)
    loaded_messages: list[dict] = []
    # Pending todos to add when session starts
    pending_todos: list[str] = []

    # Style for prompt (emdash signature style)
    # Toolbar info (will be set later, but need closure access)
    toolbar_branch: str | None = None
    toolbar_model: str = "unknown"

    PROMPT_STYLE = Style.from_dict({
        "prompt.mode.plan": f"{Colors.WARNING} bold",
        "prompt.mode.code": f"{Colors.PRIMARY} bold",
        "prompt.prefix": Colors.MUTED,
        "prompt.cursor": f"{Colors.PRIMARY}",
        "prompt.image": Colors.ACCENT,
        "completion-menu": "bg:#1a1a2e #e8ecf0",
        "completion-menu.completion": "bg:#1a1a2e #e8ecf0",
        "completion-menu.completion.current": f"bg:#2a2a3e {Colors.SUCCESS} bold",
        "completion-menu.meta.completion": f"bg:#1a1a2e {Colors.MUTED}",
        "completion-menu.meta.completion.current": f"bg:#2a2a3e {Colors.SUBTLE}",
        "command": f"{Colors.PRIMARY} bold",
        # Zen bottom toolbar styles
        "bottom-toolbar": f"bg:#1a1a1a {Colors.DIM}",
        "bottom-toolbar.brand": f"bg:#1a1a1a {Colors.PRIMARY}",
        "bottom-toolbar.branch": f"bg:#1a1a1a {Colors.WARNING}",
        "bottom-toolbar.model": f"bg:#1a1a1a {Colors.ACCENT}",
        "bottom-toolbar.mode-code": f"bg:#1a1a1a {Colors.SUCCESS}",
        "bottom-toolbar.mode-plan": f"bg:#1a1a1a {Colors.WARNING}",
        "bottom-toolbar.session": f"bg:#1a1a1a {Colors.SUCCESS}",
        "bottom-toolbar.no-session": f"bg:#1a1a1a {Colors.MUTED}",
    })

    class SlashCommandCompleter(Completer):
        """Completer for slash commands and @file references."""

        def get_completions(self, document, complete_event):
            text = document.text_before_cursor

            # Handle @file completions
            # Find the last @ in the text
            at_idx = text.rfind('@')
            if at_idx != -1:
                # Get the query after @
                query = text[at_idx + 1:]
                # Only complete if query has at least 1 char and no space after @
                if query and ' ' not in query:
                    matches = fuzzy_find_files(query, limit=10)
                    cwd = Path.cwd()
                    for match in matches:
                        try:
                            rel_path = match.relative_to(cwd)
                        except ValueError:
                            rel_path = match
                        # Replace from @ onwards
                        yield Completion(
                            f"@{rel_path}",
                            start_position=-(len(query) + 1),  # +1 for @
                            display=str(rel_path),
                            display_meta="file",
                        )
                    return

            # Handle slash commands
            if not text.startswith("/"):
                return
            for cmd, description in SLASH_COMMANDS.items():
                # Extract base command (e.g., "/pr" from "/pr [url]")
                base_cmd = cmd.split()[0]
                if base_cmd.startswith(text):
                    yield Completion(
                        base_cmd,
                        start_position=-len(text),
                        display=cmd,
                        display_meta=description,
                    )

    # Setup history file
    history_file = Path.home() / ".emdash" / "cli_history"
    history_file.parent.mkdir(parents=True, exist_ok=True)
    history = FileHistory(str(history_file))

    # Key bindings: Enter submits, Alt+Enter inserts newline
    kb = KeyBindings()

    @kb.add("enter", eager=True)
    def submit_on_enter(event):
        """Submit on Enter."""
        event.current_buffer.validate_and_handle()

    @kb.add("escape", "enter")  # Alt+Enter (Escape then Enter)
    @kb.add("c-j")  # Ctrl+J as alternative for newline
    def insert_newline_alt(event):
        """Insert a newline character with Alt+Enter or Ctrl+J."""
        event.current_buffer.insert_text("\n")

    @kb.add("c-v")  # Ctrl+V to paste (check for images)
    def paste_with_image_check(event):
        """Paste text or attach image from clipboard."""
        nonlocal attached_images
        from ...clipboard import get_clipboard_image, get_image_from_path

        # Try to get image from clipboard
        image_data = get_clipboard_image()
        if image_data:
            base64_data, img_format = image_data
            attached_images.append({"data": base64_data, "format": img_format})
            # Show feedback that image was attached
            console.print(f"  [{Colors.SUCCESS}]✓ Image {len(attached_images)} attached[/{Colors.SUCCESS}]")
            # Refresh prompt to show updated image list
            event.app.invalidate()
            return

        # Check if clipboard contains an image file path
        clipboard_data = event.app.clipboard.get_data()
        if clipboard_data and clipboard_data.text:
            text = clipboard_data.text.strip()
            # Remove escape characters from dragged paths (e.g., "path\ with\ spaces")
            clean_path = text.replace("\\ ", " ")
            # Check if it looks like an image file path
            if clean_path.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp')):
                image_data = get_image_from_path(clean_path)
                if image_data:
                    base64_data, img_format = image_data
                    attached_images.append({"data": base64_data, "format": img_format})
                    event.app.invalidate()
                    return

        # No image, do normal paste
        event.current_buffer.paste_clipboard_data(clipboard_data)

    def check_for_image_path(buff):
        """Check if buffer contains an image path and attach it."""
        nonlocal attached_images
        text = buff.text.strip()
        if not text:
            return
        # Clean escaped spaces from dragged paths
        clean_text = text.replace("\\ ", " ")
        if clean_text.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp')):
            from ...clipboard import get_image_from_path
            from prompt_toolkit.application import get_app
            image_data = get_image_from_path(clean_text)
            if image_data:
                base64_data, img_format = image_data
                attached_images.append({"data": base64_data, "format": img_format})
                # Clear the buffer
                buff.text = ""
                buff.cursor_position = 0
                # Refresh prompt to show image indicator
                try:
                    get_app().invalidate()
                except Exception:
                    pass

    def get_bottom_toolbar():
        """Bottom status bar with zen aesthetic - em-dashes and warm colors."""
        nonlocal current_mode, session_id, toolbar_branch, toolbar_model

        # Zen symbols
        em = "─"
        dot = "∷"

        # Build toolbar with zen aesthetic
        parts = [
            ("class:bottom-toolbar", f" {em}{em} "),
            ("class:bottom-toolbar.brand", "◈ emdash"),
        ]

        # Branch with stippled bullet
        if toolbar_branch:
            parts.append(("class:bottom-toolbar", f" {dot} "))
            parts.append(("class:bottom-toolbar.branch", toolbar_branch))

        # Model with stippled bullet
        if toolbar_model and toolbar_model != "unknown":
            parts.append(("class:bottom-toolbar", f" {dot} "))
            parts.append(("class:bottom-toolbar.model", toolbar_model))

        # Mode indicator
        parts.append(("class:bottom-toolbar", f" {em}{em} "))
        if current_mode == AgentMode.PLAN:
            parts.append(("class:bottom-toolbar.mode-plan", "▹ plan"))
        else:
            parts.append(("class:bottom-toolbar.mode-code", "▸ code"))

        # Session indicator
        if session_id:
            parts.append(("class:bottom-toolbar.session", " ●"))
        else:
            parts.append(("class:bottom-toolbar.no-session", " ○"))

        parts.append(("class:bottom-toolbar", " "))

        return parts

    session = PromptSession(
        history=history,
        completer=SlashCommandCompleter(),
        style=PROMPT_STYLE,
        complete_while_typing=True,
        multiline=True,
        prompt_continuation="     ",
        key_bindings=kb,
        bottom_toolbar=get_bottom_toolbar,
    )

    # Watch for image paths being pasted/dropped
    session.default_buffer.on_text_changed += check_for_image_path

    def get_prompt():
        """Get formatted prompt with distinctive emdash styling."""
        nonlocal attached_images, current_mode
        parts = []
        # Show attached images above prompt
        if attached_images:
            image_tags = " ".join(f"[Image {i+1}]" for i in range(len(attached_images)))
            parts.append(("class:prompt.image", f"  {image_tags}\n"))
        # Distinctive em-dash prompt with mode indicator
        mode_class = "class:prompt.mode.plan" if current_mode == AgentMode.PLAN else "class:prompt.mode.code"
        # Use em-dash as the signature prompt element
        parts.append(("class:prompt.prefix", "  "))
        parts.append((mode_class, f"─── "))
        parts.append(("class:prompt.cursor", "█ "))
        return parts

    def show_help():
        """Show available commands with zen styling."""
        console.print()
        console.print(f"[{Colors.MUTED}]{header('Commands', SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
        console.print()
        for cmd, desc in SLASH_COMMANDS.items():
            console.print(f"  [{Colors.PRIMARY}]{cmd:18}[/{Colors.PRIMARY}] [{Colors.DIM}]{desc}[/{Colors.DIM}]")
        console.print()
        console.print(f"[{Colors.MUTED}]{footer(SEPARATOR_WIDTH)}[/{Colors.MUTED}]")
        console.print()
        console.print(f"  [{Colors.DIM}]Type your task or question to interact with the agent.[/{Colors.DIM}]")
        console.print()

    def handle_slash_command(cmd: str) -> bool:
        """Handle a slash command. Returns True if should continue, False to exit."""
        nonlocal current_mode, session_id, current_spec, pending_todos

        cmd_parts = cmd.strip().split(maxsplit=1)
        command = cmd_parts[0].lower()
        args = cmd_parts[1] if len(cmd_parts) > 1 else ""

        if command == "/quit" or command == "/exit" or command == "/q":
            return False

        elif command == "/help":
            if args:
                # Show contextual help for specific command
                show_command_help(args)
            else:
                show_help()

        elif command == "/plan":
            current_mode = AgentMode.PLAN
            # Reset session so next chat creates a new session with plan mode
            if session_id:
                session_id = None
                console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.WARNING}]plan mode[/{Colors.WARNING}] [{Colors.DIM}](session reset)[/{Colors.DIM}]")
            else:
                console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.WARNING}]plan mode[/{Colors.WARNING}]")

        elif command == "/code":
            current_mode = AgentMode.CODE
            # Reset session so next chat creates a new session with code mode
            if session_id:
                session_id = None
                console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.SUCCESS}]code mode[/{Colors.SUCCESS}] [{Colors.DIM}](session reset)[/{Colors.DIM}]")
            else:
                console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.SUCCESS}]code mode[/{Colors.SUCCESS}]")

        elif command == "/mode":
            mode_color = Colors.WARNING if current_mode == AgentMode.PLAN else Colors.SUCCESS
            console.print(f"  [{Colors.MUTED}]current mode:[/{Colors.MUTED}] [{mode_color}]{current_mode.value}[/{mode_color}]")

        elif command == "/reset":
            session_id = None
            current_spec = None
            console.print(f"  [{Colors.DIM}]session reset[/{Colors.DIM}]")

        elif command == "/spec":
            if current_spec:
                console.print(Panel(Markdown(current_spec), title="Current Spec"))
            else:
                console.print("[dim]No spec available. Use plan mode to create one.[/dim]")

        elif command == "/pr":
            handle_pr(args, run_slash_command_task, client, renderer, model, max_iterations)

        elif command == "/projectmd":
            handle_projectmd(run_slash_command_task, client, renderer, model, max_iterations)

        elif command == "/research":
            handle_research(args, run_slash_command_task, client, renderer, model)

        elif command == "/status":
            handle_status(client)

        elif command == "/diff":
            handle_diff(args)

        elif command == "/agents":
            handle_agents(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/todos":
            handle_todos(args, client, session_id, pending_todos)

        elif command == "/todo-add":
            handle_todo_add(args, client, session_id, pending_todos)

        elif command == "/session":
            # Use list wrappers to allow mutation
            session_id_ref = [session_id]
            current_spec_ref = [current_spec]
            current_mode_ref = [current_mode]
            loaded_messages_ref = [loaded_messages]

            handle_session(
                args, client, model,
                session_id_ref, current_spec_ref, current_mode_ref, loaded_messages_ref
            )

            # Update local variables from refs
            session_id = session_id_ref[0]
            current_spec = current_spec_ref[0]
            current_mode = current_mode_ref[0]
            loaded_messages[:] = loaded_messages_ref[0]

        elif command == "/hooks":
            handle_hooks(args)

        elif command == "/rules":
            handle_rules(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/skills":
            handle_skills(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/index":
            handle_index(args, client)

        elif command == "/context":
            handle_context(renderer)

        elif command == "/paste" or command == "/image":
            # Attach image from clipboard
            from ...clipboard import get_clipboard_image
            image_data = get_clipboard_image()
            if image_data:
                base64_data, img_format = image_data
                attached_images.append({"data": base64_data, "format": img_format})
                console.print(f"  [{Colors.SUCCESS}]✓ Image {len(attached_images)} attached[/{Colors.SUCCESS}]")
            else:
                console.print(f"  [{Colors.WARNING}]No image in clipboard[/{Colors.WARNING}]")
                console.print(f"  [{Colors.DIM}]Copy an image first (Cmd+Shift+4 for screenshot)[/{Colors.DIM}]")

        elif command == "/compact":
            handle_compact(client, session_id)

        elif command == "/mcp":
            handle_mcp(args)

        elif command == "/registry":
            handle_registry(args)

        elif command == "/auth":
            handle_auth(args)

        elif command == "/doctor":
            handle_doctor(args)

        elif command == "/verify":
            handle_verify(args, client, renderer, model, max_iterations, render_with_interrupt)

        elif command == "/verify-loop":
            if not args:
                console.print("[yellow]Usage: /verify-loop <task description>[/yellow]")
                console.print("[dim]Example: /verify-loop fix the failing tests[/dim]")
                return True

            # Create a task runner function that uses current client/renderer
            def run_task(task_message: str):
                nonlocal session_id  # session_id is declared nonlocal in handle_slash_command
                if session_id:
                    stream = client.agent_continue_stream(session_id, task_message)
                else:
                    stream = client.agent_chat_stream(
                        message=task_message,
                        model=model,
                        max_iterations=max_iterations,
                        options={**options, "mode": current_mode.value},
                    )
                result = render_with_interrupt(renderer, stream)
                if result and result.get("session_id"):
                    session_id = result["session_id"]

            handle_verify_loop(args, run_task)
            return True

        elif command == "/setup":
            handle_setup(args, client, renderer, model)
            return True

        elif command == "/telegram":
            handle_telegram(args)
            return True

        else:
            console.print(f"[yellow]Unknown command: {command}[/yellow]")
            console.print("[dim]Type /help for available commands[/dim]")

        return True

    # Check for first run and show onboarding
    if is_first_run():
        run_onboarding()

    # Check for recent session to restore
    recent_session = get_recent_session(client)
    if recent_session:
        choice, session_data = show_session_restore_prompt(recent_session)
        if choice == "restore" and session_data:
            session_id = session_data.get("name")
            if session_data.get("mode"):
                current_mode = AgentMode(session_data["mode"])
            console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] Session restored: {session_id}")
            console.print()

    # Show welcome message
    from ... import __version__

    # Get current working directory
    cwd = Path.cwd()

    # Get git repo name (if in a git repo)
    git_repo = None
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, cwd=cwd
        )
        if result.returncode == 0:
            git_repo = Path(result.stdout.strip()).name
    except Exception:
        pass

    # Get current git branch
    git_branch = None
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            git_branch = result.stdout.strip()
    except Exception:
        pass

    # Get display model name
    if model:
        display_model = model
    else:
        from emdash_core.agent.providers.factory import DEFAULT_MODEL
        display_model = DEFAULT_MODEL

    # Shorten model name for display
    if "/" in display_model:
        display_model = display_model.split("/")[-1]

    # Update toolbar variables for the bottom bar
    toolbar_branch = git_branch
    toolbar_model = display_model

    # Welcome banner
    show_welcome_banner(
        version=__version__,
        git_repo=git_repo,
        git_branch=git_branch,
        mode=current_mode.value,
        model=display_model,
        console=console,
    )

    while True:
        try:
            # Get user input
            user_input = session.prompt(get_prompt()).strip()

            if not user_input:
                continue

            # Check if input is an image file path (dragged file)
            clean_input = user_input.replace("\\ ", " ")
            if clean_input.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp')):
                from ...clipboard import get_image_from_path
                image_data = get_image_from_path(clean_input)
                if image_data:
                    base64_data, img_format = image_data
                    attached_images.append({"data": base64_data, "format": img_format})
                    continue  # Prompt again for actual message

            # Handle slash commands
            if user_input.startswith("/"):
                if not handle_slash_command(user_input):
                    break
                continue

            # Handle quit shortcuts
            if user_input.lower() in ("quit", "exit", "q"):
                break

            # Expand @file references in the message
            expanded_input, included_files = expand_file_references(user_input)
            if included_files:
                console.print(f"[dim]Including {len(included_files)} file(s): {', '.join(Path(f).name for f in included_files)}[/dim]")

            # Build options with current mode
            request_options = {
                **options,
                "mode": current_mode.value,
            }

            # Run agent with current mode
            try:
                # Prepare images for API call
                images_to_send = attached_images if attached_images else None

                if session_id:
                    stream = client.agent_continue_stream(
                        session_id, expanded_input, images=images_to_send
                    )
                else:
                    # Pass loaded_messages from saved session if available
                    stream = client.agent_chat_stream(
                        message=expanded_input,
                        model=model,
                        max_iterations=max_iterations,
                        options=request_options,
                        images=images_to_send,
                        history=loaded_messages if loaded_messages else None,
                    )
                    # Clear loaded_messages after first use
                    loaded_messages.clear()

                # Clear attached images after sending
                attached_images = []

                # Render the stream and capture any spec output
                result = render_with_interrupt(renderer, stream)

                # Check if we got a session ID back
                if result and result.get("session_id"):
                    session_id = result["session_id"]

                    # Add any pending todos now that we have a session
                    if pending_todos:
                        for todo_title in pending_todos:
                            try:
                                client.add_todo(session_id, todo_title)
                            except Exception:
                                pass  # Silently ignore errors adding todos
                        pending_todos.clear()

                # Check for spec output
                if result and result.get("spec"):
                    current_spec = result["spec"]

                # Handle clarifications (may be chained - loop until no more)
                while True:
                    clarification = result.get("clarification")
                    if not (clarification and session_id):
                        break

                    response = get_clarification_response(clarification)
                    if not response:
                        break

                    # Show the user's selection in the chat
                    console.print()
                    console.print(f"[dim]Selected:[/dim] [bold]{response}[/bold]")
                    console.print()

                    # Use dedicated clarification answer endpoint
                    try:
                        stream = client.clarification_answer_stream(session_id, response)
                        result = render_with_interrupt(renderer, stream)

                        # Update mode if user chose code
                        if "code" in response.lower():
                            current_mode = AgentMode.CODE
                    except Exception as e:
                        console.print(f"[red]Error continuing session: {e}[/red]")
                        break

                # Handle plan mode entry request (show approval menu)
                plan_mode_requested = result.get("plan_mode_requested")
                if plan_mode_requested is not None and session_id:
                    choice, feedback = show_plan_mode_approval_menu()

                    if choice == "approve":
                        current_mode = AgentMode.PLAN
                        console.print()
                        console.print(f"  [{Colors.SUCCESS}]{STATUS_ACTIVE}[/{Colors.SUCCESS}] [{Colors.WARNING}]plan mode activated[/{Colors.WARNING}]")
                        console.print()
                        # Use the planmode approve endpoint
                        stream = client.planmode_approve_stream(session_id)
                        result = render_with_interrupt(renderer, stream)
                        # After approval, check if there's now a plan submitted
                        if result.get("plan_submitted"):
                            pass  # plan_submitted will be handled below
                    elif choice == "feedback":
                        # Use the planmode reject endpoint - stay in code mode
                        stream = client.planmode_reject_stream(session_id, feedback)
                        render_with_interrupt(renderer, stream)

                # Handle plan mode completion (show approval menu)
                # Only show menu when agent explicitly submits a plan via exit_plan tool
                plan_submitted = result.get("plan_submitted")
                should_show_plan_menu = (
                    current_mode == AgentMode.PLAN and
                    session_id and
                    plan_submitted is not None  # Agent called exit_plan tool
                )
                if should_show_plan_menu:
                    choice, feedback = show_plan_approval_menu()

                    if choice == "approve":
                        current_mode = AgentMode.CODE
                        # Use the plan approve endpoint which properly resets mode on server
                        stream = client.plan_approve_stream(session_id)
                        render_with_interrupt(renderer, stream)
                    elif choice == "feedback":
                        if feedback:
                            # Use the plan reject endpoint which keeps mode as PLAN on server
                            stream = client.plan_reject_stream(session_id, feedback)
                            render_with_interrupt(renderer, stream)
                        else:
                            console.print("[dim]No feedback provided[/dim]")
                            session_id = None
                            current_spec = None

                console.print()

            except Exception as e:
                console.print(f"[red]Error: {e}[/red]")

        except KeyboardInterrupt:
            console.print("\n[dim]Interrupted[/dim]")
            break
        except EOFError:
            break
