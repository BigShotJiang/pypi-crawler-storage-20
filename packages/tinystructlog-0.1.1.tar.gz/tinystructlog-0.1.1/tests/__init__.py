"""Test suite for contexlog."""
