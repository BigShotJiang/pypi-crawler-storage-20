"""Embedding module for MicroRAG."""

from microrag.embedding.model import EmbeddingModel

__all__ = ["EmbeddingModel"]
