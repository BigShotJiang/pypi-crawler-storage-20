# AutoEngineer-CLI 🤖

> **Autonomous Software Engineering Multi-Agent System**

A production-grade CLI tool that uses 5 specialized AI agents to autonomously analyze, implement, test, and review code from natural language descriptions.

[![PyPI version](https://badge.fury.io/py/autoengineer-cli.svg)](https://pypi.org/project/autoengineer-cli/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

- **5 Specialized AI Agents**: Manager, Architect, Coder, QA, and Reviewer
- **Autonomous Code Generation**: Creates complete, working implementations from task descriptions
- **Sandboxed Execution**: Tests code safely in Podman containers
- **Comprehensive Code Review**: Security analysis, best practices, and performance recommendations
- **Free-Tier LLM Support**: Works with OpenRouter's free models (262k+ context)

## 🚀 Installation

### Recommended: Using pipx (Isolated Installation)

```bash
pipx install autoengineer-cli
```

### Alternative: Using pip

```bash
pip install autoengineer-cli
```

### Alternative: Using uv

```bash
uv tool install autoengineer-cli
```

## ⚙️ Setup

1. **Get an OpenRouter API Key** (Free):
   - Visit [OpenRouter.ai](https://openrouter.ai/)
   - Create an account and get your API key

2. **Set the Environment Variable**:
   ```bash
   # Linux/macOS
   export OPENROUTER_API_KEY="your-api-key-here"
   
   # Windows PowerShell
   $env:OPENROUTER_API_KEY="your-api-key-here"
   
   # Or create a .env file in your project
   echo "OPENROUTER_API_KEY=your-api-key-here" > .env
   ```

3. **Install Podman** (Optional, for sandboxed testing):
   - [Podman Installation Guide](https://podman.io/getting-started/installation)

## 📖 Usage

### Basic Usage

```bash
# Create a new project directory
mkdir my-project && cd my-project

# Run AutoEngineer with a task
autoengineer --repo . --task "Create a REST API with user authentication"
```

### CLI Options

```bash
autoengineer --help

Options:
  -r, --repo PATH       Path to the repository to work on (required)
  -t, --task TEXT       Description of the task to complete (required)
  -o, --output PATH     Save the final report to a file
  -v, --verbose         Enable verbose output
  --max-retries INT     Maximum retry attempts (default: 3)
```

### Examples

```bash
# Create a simple script
autoengineer -r ./my-project -t "Create a Python script that calculates Fibonacci numbers"

# Build an authentication system
autoengineer -r ./my-project -t "Add JWT-based authentication with login, register, and token refresh"

# Add a feature to existing code
autoengineer -r ./existing-project -t "Add logging to all API endpoints"

# Save the report to a file
autoengineer -r ./my-project -t "Create a CLI calculator" -o report.md
```

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│ User: "Add authentication API"                                  │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ Manager Agent → Parses requirements, creates task breakdown     │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ Architect Agent → Analyzes codebase, creates execution plan     │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ Coder Agent → Writes actual code files using file tools         │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ QA Agent → Tests code in Podman sandbox, reports issues         │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│ Reviewer Agent → Generates comprehensive code review report     │
└─────────────────────────────────────────────────────────────────┘
```

## 🔧 Tech Stack

| Component | Technology |
|-----------|------------|
| AI Orchestration | CrewAI |
| LLM Gateway | LiteLLM + OpenRouter |
| Containerization | Podman |
| CLI Framework | Click |
| Language | Python 3.10+ |

## 📁 Generated Output

AutoEngineer creates:
- **Source code files** in your repository
- **Configuration files** (requirements.txt, etc.)
- **Documentation** (README, API docs)
- **Final Report** with code review and recommendations

## 🔒 Security

- **Path Traversal Prevention**: File tools validate paths to prevent escaping repository
- **Network Isolation**: Podman containers run with `--network=none`
- **Memory Limits**: Containers limited to 512MB by default
- **Execution Timeouts**: 60-second limit on sandboxed code execution

## 🤝 Contributing

Contributions are welcome! Please read our [Contributing Guide](CONTRIBUTING.md) first.

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

## 🙏 Acknowledgments

- [CrewAI](https://crewai.com/) - Multi-agent orchestration framework
- [OpenRouter](https://openrouter.ai/) - LLM API gateway
- [LiteLLM](https://litellm.ai/) - Universal LLM interface
- [Podman](https://podman.io/) - Rootless containerization
