"""
Claude Board - Physical Console for Claude Code

A permission approval console that supports:
- Web UI for mobile/desktop approval
- Future: Bluetooth physical console with mechanical keys and e-ink display
"""

__version__ = "0.1.0"
__app_name__ = "claude-board"
