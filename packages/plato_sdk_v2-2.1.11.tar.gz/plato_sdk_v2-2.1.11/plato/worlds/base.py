"""Base world class for Plato worlds."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, ClassVar, Generic, TypeVar, get_args, get_origin

from pydantic import BaseModel, Field

from plato.worlds.config import RunConfig

if TYPE_CHECKING:
    from plato.v2.async_.session import Session

logger = logging.getLogger(__name__)

# Global registry of worlds
_WORLD_REGISTRY: dict[str, type[BaseWorld]] = {}

# Type variable for config
ConfigT = TypeVar("ConfigT", bound=RunConfig)


def register_world(name: str | None = None):
    """Decorator to register a world class.

    Usage:
        @register_world("code")
        class CodeWorld(BaseWorld[CodeWorldConfig]):
            ...
    """

    def decorator(cls: type[BaseWorld]) -> type[BaseWorld]:
        world_name = name or getattr(cls, "name", cls.__name__.lower().replace("world", ""))
        _WORLD_REGISTRY[world_name] = cls
        logger.debug(f"Registered world: {world_name} -> {cls.__name__}")
        return cls

    return decorator


def get_registered_worlds() -> dict[str, type[BaseWorld]]:
    """Get all registered worlds."""
    return _WORLD_REGISTRY.copy()


def get_world(name: str) -> type[BaseWorld] | None:
    """Get a world by name."""
    return _WORLD_REGISTRY.get(name)


class Observation(BaseModel):
    """Observation returned from reset/step."""

    data: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow"}


class StepResult(BaseModel):
    """Result of a step."""

    observation: Observation
    done: bool = False
    info: dict[str, Any] = Field(default_factory=dict)


class BaseWorld(ABC, Generic[ConfigT]):
    """Base class for Plato worlds.

    Subclass with a config type parameter for fully typed config access:

        class CodeWorldConfig(RunConfig):
            repository_url: str
            prompt: str
            coder: Annotated[AgentConfig, Agent(description="Coding agent")]
            git_token: Annotated[str | None, Secret(description="GitHub token")] = None

        @register_world("code")
        class CodeWorld(BaseWorld[CodeWorldConfig]):
            name = "code"
            description = "Run coding agents"

            async def reset(self) -> Observation:
                url = self.config.repository_url  # typed as str
                agent = self.config.coder          # typed as AgentConfig
                token = self.config.git_token      # typed as str | None
    """

    # Class attributes
    name: ClassVar[str] = "base"
    description: ClassVar[str] = ""

    # Instance attributes
    config: ConfigT  # Typed via generic parameter
    plato_session: Session | None = None  # Connected Plato session (if running on managed VM)

    def __init__(self) -> None:
        self.logger = logging.getLogger(f"plato.worlds.{self.name}")
        self._step_count: int = 0
        self.plato_session = None

    @classmethod
    def get_config_class(cls) -> type[RunConfig]:
        """Get the config class from the generic parameter."""
        # Walk up the class hierarchy to find Generic base
        for base in getattr(cls, "__orig_bases__", []):
            origin = get_origin(base)
            if origin is BaseWorld:
                args = get_args(base)
                if args and isinstance(args[0], type) and issubclass(args[0], RunConfig):
                    return args[0]
        return RunConfig

    @classmethod
    def get_version(cls) -> str:
        """Get version from package metadata."""
        import importlib.metadata

        for pkg_name in [cls.__module__.split(".")[0], f"plato-world-{cls.name}"]:
            try:
                return importlib.metadata.version(pkg_name)
            except importlib.metadata.PackageNotFoundError:
                continue
        return "0.0.0"

    @classmethod
    def get_schema(cls) -> dict:
        """Get full schema including world config, agents, and secrets."""
        config_class = cls.get_config_class()
        schema = config_class.get_json_schema()

        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": schema.get("properties", {}),
            "required": schema.get("required", []),
            "agents": schema.get("agents", []),
            "secrets": schema.get("secrets", []),
        }

    @abstractmethod
    async def reset(self) -> Observation:
        """Setup the world and return initial observation.

        Access configuration via self.config (fully typed).
        """
        pass

    @abstractmethod
    async def step(self) -> StepResult:
        """Execute one step of the world.

        Called repeatedly until done=True is returned.
        """
        pass

    async def close(self) -> None:
        """Cleanup resources. Called after run completes."""
        pass

    async def _connect_plato_session(self) -> None:
        """Connect to Plato session from config.

        This is called automatically during run() to restore the session
        and start sending heartbeats while the world runs.
        """
        try:
            from plato.v2.async_.session import Session

            self.logger.info("Restoring Plato session from serialized data")
            self.plato_session = await Session.load(self.config.plato_session, start_heartbeat=True)
            self.logger.info(f"Plato session {self.plato_session.session_id} restored, heartbeat started")
        except Exception as e:
            self.logger.warning(f"Failed to restore Plato session: {e}")

    async def _disconnect_plato_session(self) -> None:
        """Stop heartbeat for the Plato session (does not close the session)."""
        if self.plato_session:
            try:
                await self.plato_session.stop_heartbeat()
                self.logger.info("Plato session heartbeat stopped")
            except Exception as e:
                self.logger.warning(f"Error stopping Plato heartbeat: {e}")

    async def run(self, config: ConfigT) -> None:
        """Run the world: reset -> step until done -> close.

        This is the main entry point. If plato_session_id is provided in config,
        automatically connects to the Plato session to send heartbeats.
        """
        self.config = config
        self._step_count = 0

        self.logger.info(f"Starting world '{self.name}'")

        # Connect to Plato session if configured (for heartbeats)
        await self._connect_plato_session()

        try:
            obs = await self.reset()
            self.logger.info(f"World reset complete: {obs}")

            while True:
                self._step_count += 1
                result = await self.step()
                self.logger.info(f"Step {self._step_count}: done={result.done}")

                if result.done:
                    break

        finally:
            await self.close()
            await self._disconnect_plato_session()
            self.logger.info(f"World '{self.name}' completed after {self._step_count} steps")
