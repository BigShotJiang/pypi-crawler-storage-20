"""Tests for bashlet SDK."""
