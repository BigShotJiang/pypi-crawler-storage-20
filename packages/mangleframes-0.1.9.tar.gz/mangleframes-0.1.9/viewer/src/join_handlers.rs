//! HTTP handlers for join analysis endpoints.

use std::sync::Arc;
use std::time::Instant;

use arrow::record_batch::RecordBatch;
use axum::body::Body;
use axum::extract::{Path, Query, State};
use axum::http::{header, Response, StatusCode};
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::json;

use crate::arrow_reader;
use crate::export;
use crate::join_analysis::JoinAnalyzer;
use crate::web_server::{AppState, CachedFrame};

#[derive(Deserialize)]
pub struct JoinRequest {
    left_frame: String,
    right_frame: String,
    left_keys: Vec<String>,
    right_keys: Vec<String>,
}

pub async fn analyze_join(
    State(state): State<Arc<AppState>>,
    Json(req): Json<JoinRequest>,
) -> impl IntoResponse {
    if req.left_keys.len() != req.right_keys.len() {
        return error_response(StatusCode::BAD_REQUEST, "Key count mismatch");
    }
    if req.left_keys.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "At least one join key required");
    }

    let (left_batches, right_batches) = match get_frame_batches(&state, &req.left_frame, &req.right_frame).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let analyzer = JoinAnalyzer::new();
    match analyzer.analyze(left_batches, right_batches, &req.left_keys, &req.right_keys, 100).await {
        Ok(result) => Json(result).into_response(),
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

#[derive(Deserialize)]
pub struct UnmatchedQuery {
    left_frame: String,
    right_frame: String,
    left_keys: String,
    right_keys: String,
    offset: Option<usize>,
    limit: Option<usize>,
}

pub async fn get_unmatched(
    State(state): State<Arc<AppState>>,
    Path(side): Path<String>,
    Query(query): Query<UnmatchedQuery>,
) -> impl IntoResponse {
    if side != "left" && side != "right" {
        return error_response(StatusCode::BAD_REQUEST, "Side must be 'left' or 'right'");
    }

    let left_keys: Vec<String> = query.left_keys.split(',').map(|s| s.trim().to_string()).collect();
    let right_keys: Vec<String> = query.right_keys.split(',').map(|s| s.trim().to_string()).collect();

    if left_keys.len() != right_keys.len() {
        return error_response(StatusCode::BAD_REQUEST, "Key count mismatch");
    }

    let (left_batches, right_batches) = match get_frame_batches(&state, &query.left_frame, &query.right_frame).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let offset = query.offset.unwrap_or(0);
    let limit = query.limit.unwrap_or(100).min(1000);

    let analyzer = JoinAnalyzer::new();
    match analyzer.get_unmatched_page(left_batches, right_batches, &left_keys, &right_keys, &side, offset, limit).await {
        Ok(result) => Json(json!({
            "rows": result.rows,
            "total": result.total,
            "offset": offset
        })).into_response(),
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

#[derive(Deserialize)]
pub struct ExportRequest {
    left_frame: String,
    right_frame: String,
    left_keys: Vec<String>,
    right_keys: Vec<String>,
    side: String,
    format: String,
}

pub async fn export_unmatched(
    State(state): State<Arc<AppState>>,
    Json(req): Json<ExportRequest>,
) -> impl IntoResponse {
    if req.side != "left" && req.side != "right" {
        return error_response(StatusCode::BAD_REQUEST, "Side must be 'left' or 'right'");
    }

    let (left_batches, right_batches) = match get_frame_batches(&state, &req.left_frame, &req.right_frame).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let analyzer = JoinAnalyzer::new();
    let result = match analyzer.get_unmatched_page(
        left_batches, right_batches,
        &req.left_keys, &req.right_keys,
        &req.side, 0, 100000
    ).await {
        Ok(r) => r,
        Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    };

    // Convert JSON rows back to RecordBatch for export
    let batches = match json_to_batches(&result.rows) {
        Ok(b) => b,
        Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e),
    };

    let (content_type, data, ext) = match req.format.as_str() {
        "csv" => match export::to_csv(&batches) {
            Ok(d) => ("text/csv", d, "csv"),
            Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        "json" => match export::to_json(&batches) {
            Ok(d) => ("application/json", d, "json"),
            Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        "parquet" => match export::to_parquet(&batches) {
            Ok(d) => ("application/octet-stream", d, "parquet"),
            Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
        },
        _ => return error_response(StatusCode::BAD_REQUEST, "Invalid format"),
    };

    let filename = format!("{}_unmatched.{}", req.side, ext);
    Response::builder()
        .header(header::CONTENT_TYPE, content_type)
        .header(header::CONTENT_DISPOSITION, format!("attachment; filename=\"{}\"", filename))
        .body(Body::from(data))
        .unwrap()
        .into_response()
}

async fn get_frame_batches(
    state: &AppState,
    left_frame: &str,
    right_frame: &str,
) -> Result<(Vec<RecordBatch>, Vec<RecordBatch>), axum::response::Response> {
    let left_batches = get_or_fetch_frame(state, left_frame).await?;
    let right_batches = get_or_fetch_frame(state, right_frame).await?;
    Ok((left_batches, right_batches))
}

async fn get_or_fetch_frame(
    state: &AppState,
    frame_name: &str,
) -> Result<Vec<RecordBatch>, axum::response::Response> {
    // Check cache first
    {
        let cache = state.cache.read().await;
        if let Some(cached) = cache.get(frame_name) {
            return Ok(cached.batches.clone());
        }
    }

    // Fetch from Python server
    let response = state.client.get_frame(frame_name, 100000).map_err(|e| {
        error_response(StatusCode::NOT_FOUND, &format!("Failed to fetch {}: {}", frame_name, e))
    })?;

    let batches = arrow_reader::parse_arrow_stream(&response.data)
        .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))?;

    // Cache for future use
    state.evict_frame_if_needed().await;
    let mut cache = state.cache.write().await;
    cache.insert(
        frame_name.to_string(),
        CachedFrame { batches: batches.clone(), stats: None, last_access: Instant::now() },
    );

    Ok(batches)
}

fn error_response(status: StatusCode, msg: &str) -> axum::response::Response {
    (status, Json(json!({"error": msg}))).into_response()
}

fn json_to_batches(rows: &[serde_json::Value]) -> Result<Vec<arrow::record_batch::RecordBatch>, String> {
    if rows.is_empty() {
        return Ok(vec![]);
    }

    let json_bytes = serde_json::to_vec(rows).map_err(|e| e.to_string())?;
    let cursor = std::io::Cursor::new(json_bytes);
    let reader = arrow::json::ReaderBuilder::new(arrow::datatypes::SchemaRef::new(
        infer_schema_from_json(rows)?
    )).build(cursor).map_err(|e| e.to_string())?;

    reader.into_iter().collect::<Result<Vec<_>, _>>().map_err(|e| e.to_string())
}

fn infer_schema_from_json(rows: &[serde_json::Value]) -> Result<arrow::datatypes::Schema, String> {
    use arrow::datatypes::{DataType, Field};

    let first = rows.first().ok_or("No rows")?;
    let obj = first.as_object().ok_or("Row is not an object")?;

    let fields: Vec<Field> = obj.iter().map(|(k, v)| {
        let dtype = match v {
            serde_json::Value::Bool(_) => DataType::Boolean,
            serde_json::Value::Number(n) if n.is_i64() => DataType::Int64,
            serde_json::Value::Number(_) => DataType::Float64,
            _ => DataType::Utf8,
        };
        Field::new(k, dtype, true)
    }).collect();

    Ok(arrow::datatypes::Schema::new(fields))
}
