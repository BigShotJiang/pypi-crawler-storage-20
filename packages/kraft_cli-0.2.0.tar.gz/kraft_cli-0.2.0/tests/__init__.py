"""Tests for kraft CLI."""
