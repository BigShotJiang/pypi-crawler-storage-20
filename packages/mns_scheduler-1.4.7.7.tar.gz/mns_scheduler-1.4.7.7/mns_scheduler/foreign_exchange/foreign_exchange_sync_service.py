import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)
import mns_common.api.foreign_exchange.foreign_exchange_api as foreign_exchange_api
import mns_common.constant.extra_income_db_name as extra_income_db_name
from mns_common.db.MongodbUtil import MongodbUtil
from datetime import datetime

mongodb_util = MongodbUtil('27017')


# 外汇信息同步
def foreign_exchange_sync():
    forex_spot_em_df = foreign_exchange_api.get_foreign_exchange()
    now_date = datetime.now()
    str_now_time = now_date.strftime('%Y-%m-%d %H:%M:%S')
    forex_spot_em_df['str_now_time'] = str_now_time
    forex_spot_em_df['_id'] = forex_spot_em_df['symbol']

    mongodb_util.save_mongo(forex_spot_em_df, extra_income_db_name.FOREIGN_EXCHANGE_TABLE)


if __name__ == '__main__':
    foreign_exchange_sync()
