from symjoy import symbols, arrows, math, currency, misc, search
from rich import print

print(symbols.get("heart"))
print(symbols.random())

print(arrows.get("right"))
print(arrows.random())

print(math.get("pi"))
print(math.random())

print(currency.get("rupee"))
print(currency.random())

print(misc.get("sun"))
print(misc.random())

print(search("heart"))
print(search("HeArT"))
print(search("star"))
print(search("does_not_exist"))

from symjoy import emojis
print(emojis["smile"])

# from symjoy import emoji
# print(emoji.get("smile"))
