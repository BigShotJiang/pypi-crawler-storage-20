"""
Docstring for holamundomiprimerpaquete.player
modulo que incluye la clase de reproductor de musica
"""


class Player:
    """
    Docstring for Player
    esta clase crea un reproductor de musica
    """

    def play(self, song):
        """
        Reproduce la cancion que recibio como parametro
        Docstring for play
        :param self: Description
        :param song(str): str con el path de la cancion
        returns:
        int: devuelve 1 si se reproduce con exito, en caso contrario 0
        """
        print("reproduciendo cancion")

    def stop(self):
        """
        Docstring for stop
        :param self: Description
        este metodo es para hacer el stop de la musica
        """
        print("stopping")
