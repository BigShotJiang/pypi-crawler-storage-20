### Added
- `weld plan` now accepts multiple specification files
  - Combines all specs into a single implementation plan
  - Usage: `weld plan spec1.md spec2.md spec3.md`
