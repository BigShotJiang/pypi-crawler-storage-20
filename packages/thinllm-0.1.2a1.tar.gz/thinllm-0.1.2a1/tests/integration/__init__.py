"""Integration tests for thinllm."""
