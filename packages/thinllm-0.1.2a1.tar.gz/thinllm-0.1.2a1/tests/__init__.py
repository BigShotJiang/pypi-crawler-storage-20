"""Test suite for thinllm."""
