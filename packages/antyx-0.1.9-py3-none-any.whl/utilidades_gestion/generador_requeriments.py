import subprocess
import os

def generate_requirements(project_path):
    """
    Genera requirements.txt basado en imports reales del proyecto usando pipreqs.
    """
    print("🔍 Generando requirements.txt basado en imports...")

    # Instalar pipreqs si no está instalado
    try:
        import pipreqs
    except ImportError:
        print("📦 Instalando pipreqs...")
        subprocess.run(["pip", "install", "pipreqs"], check=True)

    # Ejecutar pipreqs
    subprocess.run([
        "pipreqs",
        project_path,
        "--force"
    ], check=True)

    print("✅ requirements.txt generado correctamente.")


# Ejemplo de uso
if __name__ == "__main__":
    project_path = "C:/Dany/DataScience/antyx"
    generate_requirements(project_path)