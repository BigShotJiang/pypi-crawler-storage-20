"""Spark Kubernetes Extra Links"""
from __future__ import annotations

from airflow.models import BaseOperator, XCom
from airflow.models.baseoperatorlink import BaseOperatorLink
from airflow.models.taskinstancekey import TaskInstanceKey

XCOM_SPARK_UI_LINK = "spark_ui_link"
XCOM_SPARK_HISTORY_LINK = "spark_history_link"
XCOM_GRAFANA_LINK = "grafana_link"


class SparkLink(BaseOperatorLink):
    """
    Base class for Spark Operator Links.

    Retrieves a URL from Airflow XCom based on the `key` provided.
    Designed to be subclassed with a concrete `name` and `key`.

    Attributes:
        name (str): Display name for the link in Airflow UI.
        key (str): XCom key to fetch the URL from.
    """

    name: str
    key: str

    def get_link(self, operator: BaseOperator, *, ti_key: TaskInstanceKey) -> str:
        """
        Retrieve the link from XCom for the given task instance.

        Args:
            operator (BaseOperator): The operator instance (unused here).
            ti_key (TaskInstanceKey): TaskInstanceKey identifying the task.

        Returns:
            str: The URL stored in XCom, or empty string if not present.
        """
        link = XCom.get_value(ti_key=ti_key, key=self.key)
        return link if link else ""


class SparkUiLink(SparkLink):
    """
    Spark UI link for ADNSparkKubernetesOperator.

    Fetches the Spark UI URL from XCom using XCOM_SPARK_UI_LINK.
    """

    name = "Spark UI"
    key = XCOM_SPARK_UI_LINK


class SparkUiHistoryLink(SparkLink):
    """
    Spark History Server link for ADNSparkKubernetesOperator.

    Fetches the Spark History URL from XCom using XCOM_SPARK_HISTORY_LINK.
    """

    name = "Spark History"
    key = XCOM_SPARK_HISTORY_LINK


class GrafanaLink(SparkLink):
    """
    Grafana metrics link for ADNSparkKubernetesOperator.

    Fetches the Grafana dashboard URL from XCom using XCOM_GRAFANA_LINK.
    """

    name = "Grafana"
    key = XCOM_GRAFANA_LINK
