from . import __version__

def get_provider_info():
    """
    Return provider metadata used by Airflow to register this provider.
    """
    return {

        "package-name": "adn-airflow-providers",
        "name": "Adn Airflow Providers",
        "description": "ADN Airflow providers to use ",
        "version": __version__,
        "extra-links": [
            "adn_airflow_providers.operator_extra_links.spark_links.SparkUiLink",
            "adn_airflow_providers.operator_extra_links.spark_links.SparkUiHistoryLink",
            "adn_airflow_providers.operator_extra_links.spark_links.GrafanaLink",
        ],
    }