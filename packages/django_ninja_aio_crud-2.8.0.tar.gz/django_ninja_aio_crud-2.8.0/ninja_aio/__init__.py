"""Django Ninja AIO CRUD - Rest Framework"""

__version__ = "2.8.0"

from .api import NinjaAIO

__all__ = ["NinjaAIO"]
