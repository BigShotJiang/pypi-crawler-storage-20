"""Pandas-specific implementation details."""
