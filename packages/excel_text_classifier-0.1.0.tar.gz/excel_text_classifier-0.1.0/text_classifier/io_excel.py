from __future__ import annotations

from typing import Optional

import pandas as pd


def read_excel(path: str, sheet_name: Optional[str] = None) -> pd.DataFrame:
    """读取 Excel 文件并返回 DataFrame。

    :param path: Excel 文件路径
    :param sheet_name: 工作表名称；为 None 时读取默认工作表
    :return: DataFrame
    """
    return pd.read_excel(path, sheet_name=sheet_name)


def write_excel_with_column(df: pd.DataFrame, path: str) -> None:
    """将 DataFrame 写回 Excel 文件。

    :param df: 数据表
    :param path: 输出文件路径
    """
    df.to_excel(path, index=False)
