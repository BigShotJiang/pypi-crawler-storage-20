"""
Custom and advanced XPS line shape implementations.

Contains specialized peak models for specific XPS applications:
Gaussian-Lorentzian mixing, asymmetric shapes, etc.
"""

from .base import LineShape
from lmfit import Model, Parameters
import numpy as np


class GaussianLorentzianMixLineShape(LineShape):
    """
    Variable Gaussian-Lorentzian mix line shape with GL(n) notation support.
    
    Allows smooth interpolation between pure Gaussian and pure Lorentzian
    through a mixing parameter. More flexible than fixed Voigt.
    
    Supports Casa-style GL(n) notation where n is the Lorentzian percentage.
    
    Parameters
    ----------
    name : str
        Peak name
    prefix : str
        lmfit parameter prefix
    lorentzian_percent : float or None
        Lorentzian percentage (0-100). If set, m is fixed to this value / 100.
        If None (default), m is optimized during fitting starting from 50%.
        
    Examples
    --------
    >>> # GL(30) - 30% Lorentzian, 70% Gaussian (fixed)
    >>> shape = GaussianLorentzianMixLineShape("Al 2p3/2", prefix="p0_", lorentzian_percent=30)
    
    >>> # GL(50) - 50/50 mix (fixed)
    >>> shape = GaussianLorentzianMixLineShape("N 1s", prefix="p0_", lorentzian_percent=50)
    
    >>> # Optimize the mix ratio automatically
    >>> shape = GaussianLorentzianMixLineShape("Fe 2p", prefix="p0_")
    """
    
    def __init__(self, name: str, prefix: str = "", lorentzian_percent: float = None):
        """
        Initialize GL mix line shape.
        
        Parameters
        ----------
        name : str
            Peak name
        prefix : str
            lmfit prefix
        lorentzian_percent : float, optional
            Lorentzian percentage (0-100). If provided, fixes m to this value.
        """
        super().__init__(name, prefix)
        self.lorentzian_percent = lorentzian_percent
        
        if lorentzian_percent is not None:
            if not (0 <= lorentzian_percent <= 100):
                raise ValueError("lorentzian_percent must be between 0 and 100")
    
    @staticmethod
    def gl_mix_func(x: np.ndarray, amplitude: float, center: float, 
                    sigma: float, m: float) -> np.ndarray:
        """
        Compute Gaussian-Lorentzian mix at given x values.
        
        Parameters
        ----------
        x : np.ndarray
            Energy values
        amplitude : float
            Peak height
        center : float
            Peak center
        sigma : float
            Width
        m : float
            Mixing parameter (0=pure Gaussian, 1=pure Lorentzian)
            
        Returns
        -------
        np.ndarray
            Peak values
        """
        from scipy.special import wofz
        
        z = ((x - center) + 1j * sigma) / (sigma * np.sqrt(2))
        voigt = np.real(wofz(z)) / (sigma * np.sqrt(2 * np.pi))
        
        gaussian = np.exp(-((x - center)**2) / (2 * sigma**2)) / (sigma * np.sqrt(2 * np.pi))
        lorentzian = sigma / ((x - center)**2 + sigma**2) / np.pi
        
        result = (1 - m) * gaussian + m * lorentzian
        return amplitude * result / np.max(result)
    
    def get_model(self) -> Model:
        """Return a custom Model using gl_mix_func."""
        return Model(self.gl_mix_func, prefix=self.prefix)
    
    def make_params(self, x: np.ndarray, y: np.ndarray) -> Parameters:
        """
        Initialize GL mix parameters.
        
        If lorentzian_percent was specified in __init__, m is fixed to that value.
        Otherwise, starts with m=0.5 (neutral) and lets optimization find the best blend.
        """
        center = np.sum(x * y) / np.sum(y) if np.sum(y) > 0 else np.mean(x)
        amplitude = np.max(y)
        sigma = np.std(x[y > amplitude/2]) if np.max(y) > 0 else 0.5
        
        params = Parameters()
        params.add(f'{self.prefix}amplitude', value=amplitude, min=0)
        params.add(f'{self.prefix}center', value=center, min=np.min(x), max=np.max(x))
        params.add(f'{self.prefix}sigma', value=max(0.1, sigma), min=0.05, max=2.0)
        
        # Set m based on whether lorentzian_percent was specified
        if self.lorentzian_percent is not None:
            m_value = self.lorentzian_percent / 100.0
            params.add(f'{self.prefix}m', value=m_value, vary=False)  # Fixed
        else:
            params.add(f'{self.prefix}m', value=0.5, min=0.0, max=1.0)  # Optimizable
        
        return params


class AsymmetricLineShape(LineShape):
    """
    Asymmetric line shape with independent left/right broadening.
    
    Models cases where asymmetry is physically meaningful (shake-up satellites,
    charge-transfer effects, etc.).
    
    Parameters
    ----------
    amplitude : float
        Peak intensity
    center : float
        Peak position
    sigma : float
        Base width parameter
    alpha : float
        Left-side broadening factor
    beta : float
        Right-side broadening factor
    """
    
    @staticmethod
    def asymmetric_func(x: np.ndarray, amplitude: float, center: float,
                       sigma: float, alpha: float, beta: float) -> np.ndarray:
        """
        Compute asymmetric peak at given x values.
        
        Parameters
        ----------
        x : np.ndarray
            Energy values
        amplitude : float
            Peak height
        center : float
            Peak center
        sigma : float
            Width
        alpha : float
            Left broadening
        beta : float
            Right broadening
            
        Returns
        -------
        np.ndarray
            Peak values
        """
        left = x < center
        right = x >= center
        
        result = np.zeros_like(x, dtype=float)
        
        if np.any(left):
            result[left] = amplitude * np.exp(-((x[left] - center)**2) / (2 * (sigma * alpha)**2))
        if np.any(right):
            result[right] = amplitude * np.exp(-((x[right] - center)**2) / (2 * (sigma * beta)**2))
        
        return result
    
    def get_model(self) -> Model:
        """Return a custom Model using asymmetric_func."""
        return Model(self.asymmetric_func, prefix=self.prefix)
    
    def make_params(self, x: np.ndarray, y: np.ndarray) -> Parameters:
        """
        Initialize asymmetric parameters.
        
        Start with alpha=beta=1.0 (symmetric) and optimize.
        """
        center = np.sum(x * y) / np.sum(y) if np.sum(y) > 0 else np.mean(x)
        amplitude = np.max(y)
        sigma = np.std(x[y > amplitude/2]) if np.max(y) > 0 else 0.5
        
        params = Parameters()
        params.add(f'{self.prefix}amplitude', value=amplitude, min=0)
        params.add(f'{self.prefix}center', value=center, min=np.min(x), max=np.max(x))
        params.add(f'{self.prefix}sigma', value=max(0.1, sigma), min=0.05, max=2.0)
        params.add(f'{self.prefix}alpha', value=1.0, min=0.5, max=2.0)
        params.add(f'{self.prefix}beta', value=1.0, min=0.5, max=2.0)
        
        return params