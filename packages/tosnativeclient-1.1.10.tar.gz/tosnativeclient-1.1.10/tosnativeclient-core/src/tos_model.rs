use ve_tos_rust_sdk::object::HeadObjectOutput;

#[derive(Clone, Debug)]
pub struct TosObject {
    pub(crate) bucket: String,
    pub(crate) key: String,
    pub(crate) etag: String,
    pub(crate) size: isize,
    pub(crate) crc64: u64,
}

impl TosObject {
    pub fn new(
        bucket: impl Into<String>,
        key: impl Into<String>,
        size: isize,
        etag: impl Into<String>,
        crc64: u64,
    ) -> Self {
        Self {
            bucket: bucket.into(),
            key: key.into(),
            etag: etag.into(),
            size,
            crc64,
        }
    }
    pub(crate) fn inner_new(
        bucket: impl Into<String>,
        key: impl Into<String>,
        output: HeadObjectOutput,
    ) -> Self {
        Self {
            bucket: bucket.into(),
            key: key.into(),
            etag: output.etag().to_string(),
            size: output.content_length() as isize,
            crc64: output.hash_crc64ecma(),
        }
    }

    pub fn bucket(&self) -> &str {
        &self.bucket
    }

    pub fn key(&self) -> &str {
        &self.key
    }

    pub fn size(&self) -> isize {
        self.size
    }

    pub fn etag(&self) -> &str {
        &self.etag
    }

    pub fn crc64(&self) -> u64 {
        self.crc64
    }
}
