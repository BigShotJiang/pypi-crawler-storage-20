use crate::read_stream::ReadStream;
use crate::tos_client::TosClient;
use crate::tos_model::TosObject;
use bytes::BytesMut;
use once_cell::sync::OnceCell;
use pprof::flamegraph::Options;
use pprof::ProfilerGuard;
use slab::Slab;
use std::collections::{LinkedList, VecDeque};
use std::fs::File;
use std::path::Path;
use std::sync::Arc;
use std::thread::sleep;
use std::time::Duration;
use std::{fs, io, thread};
use tokio::runtime::{Builder, Runtime};
use tokio::sync::{AcquireError, OwnedSemaphorePermit, RwLock, Semaphore, TryAcquireError};
use tracing::warn;
use tracing_appender::non_blocking::WorkerGuard;

const DEFAULT_BUFFER_SIZE: isize = 8 * 1024 * 1024;
const DEFAULT_BUFFER_COUNT: isize = 100;

pub fn async_write_profile(seconds: i64, file_path: &str, mut image_width: usize) {
    if seconds <= 0 {
        return;
    }

    let fp;
    if file_path.is_empty() {
        fp = String::from("cpu_profile.html");
    } else if !file_path.ends_with(".html") {
        fp = String::from(file_path) + ".html";
    } else {
        fp = file_path.to_string();
    }

    if let Some(p) = Path::new(fp.as_str()).parent() {
        if let Err(ex) = fs::create_dir_all(p) {
            if ex.kind() != io::ErrorKind::AlreadyExists {
                warn!("flamegraph error, {:?}", ex);
                return;
            }
        }
    }
    if image_width <= 0 {
        image_width = 1200;
    }
    match ProfilerGuard::new(100) {
        Err(ex) => {
            warn!("flamegraph new error, {:?}", ex);
        }
        Ok(guard) => {
            thread::spawn(move || {
                sleep(Duration::from_secs(seconds as u64));
                match File::create(fp) {
                    Ok(fd) => {
                        if let Ok(report) = guard.report().build() {
                            let mut options = Options::default();
                            options.image_width = Some(image_width);
                            if let Err(ex) = report.flamegraph_with_options(fd, &mut options) {
                                warn!("flamegraph error, {:?}", ex);
                            }
                        }
                    }
                    Err(ex) => {
                        warn!("flamegraph error, {:?}", ex);
                    }
                }
            });
        }
    }
}

static LOG_GUARD: OnceCell<WorkerGuard> = OnceCell::new();

pub fn init_tracing_log(directives: String, directory: String, file_name_prefix: String) {
    if directory == "" {
        return;
    }
    LOG_GUARD.get_or_init(|| {
        let guard: WorkerGuard = ve_tos_rust_sdk::common::init_tracing_log(
            directives.clone(),
            directory.clone(),
            file_name_prefix.clone(),
        );
        guard
    });
}

static GLOBAL_RUNTIME: OnceCell<Arc<Runtime>> = OnceCell::new();
pub fn init_global_runtime() -> Arc<Runtime> {
    GLOBAL_RUNTIME
        .get_or_init(|| {
            let mut builder = Builder::new_multi_thread();
            if let Ok(max_worker_threads) = thread::available_parallelism() {
                builder.worker_threads(max_worker_threads.get());
            } else {
                builder.worker_threads(16);
            }
            Arc::new(builder.enable_all().build().unwrap())
        })
        .clone()
}

pub(crate) struct TokenAcquirer {
    semaphore: Arc<Semaphore>,
}

impl TokenAcquirer {
    pub(crate) fn new(max_tokens: isize) -> Self {
        Self {
            semaphore: Arc::new(Semaphore::new(max_tokens as usize)),
        }
    }

    pub(crate) async fn acquire(&self) -> Result<OwnedSemaphorePermit, AcquireError> {
        self.semaphore.clone().acquire_owned().await
    }

    pub(crate) fn try_acquire(&self) -> Result<OwnedSemaphorePermit, TryAcquireError> {
        self.semaphore.clone().try_acquire_owned()
    }

    pub(crate) fn close(&self) {
        self.semaphore.close();
    }

    pub(crate) fn available_permits(&self) -> usize {
        self.semaphore.available_permits()
    }
}

pub(crate) async fn split_objects(
    bucket: Option<&str>,
    objects: &mut VecDeque<TosObject>,
    tos_client: Arc<TosClient>,
    ta: Arc<TokenAcquirer>,
    permit: OwnedSemaphorePermit,
) -> (VecDeque<TosObject>, Vec<ReadStream>) {
    let mut permits = LinkedList::new();
    permits.push_back(permit);
    loop {
        if permits.len() >= objects.len() {
            break;
        }

        match ta.try_acquire() {
            Ok(permit) => {
                permits.push_back(permit);
            }
            Err(_) => {
                break;
            }
        }
    }

    let mut splited_objects = VecDeque::with_capacity(permits.len());
    let mut read_stream_list = Vec::with_capacity(permits.len());
    loop {
        if permits.is_empty() || objects.is_empty() {
            break;
        }
        let object = objects.pop_front().unwrap();
        let permit = permits.pop_front().unwrap();
        let bkt = match bucket {
            None => object.bucket(),
            Some(bkt) => bkt,
        };
        let read_stream;
        if object.size() >= 0 {
            read_stream = tos_client
                .async_get_object(
                    bkt.to_string(),
                    object.key().to_string(),
                    Some(object.etag().to_string()),
                    Some(object.size()),
                    Some(object.crc64()),
                    false,
                )
                .await;
        } else {
            read_stream = tos_client
                .async_get_object(
                    bkt.to_string(),
                    object.key().to_string(),
                    None,
                    None,
                    None,
                    false,
                )
                .await;
        }
        read_stream
            .trigger_first_fetch_task(Some((None, Some(permit))))
            .await;
        read_stream_list.push(read_stream);
        splited_objects.push_back(object);
    }

    (splited_objects, read_stream_list)
}

pub(crate) struct BufferPool {
    inner: Arc<RwLock<Slab<BytesMut>>>,
    buffer_count: isize,
    buffer_size: isize,
}

impl Clone for BufferPool {
    fn clone(&self) -> Self {
        Self {
            inner: self.inner.clone(),
            buffer_count: self.buffer_count,
            buffer_size: self.buffer_size,
        }
    }
}

impl BufferPool {
    pub(crate) fn new(mut buffer_size: isize, total_buffer_size: isize) -> Self {
        if buffer_size <= 0 {
            buffer_size = DEFAULT_BUFFER_SIZE
        }

        let mut buffer_count = total_buffer_size / buffer_size;

        if buffer_count <= 0 {
            buffer_count = DEFAULT_BUFFER_COUNT;
        }

        let mut slab = Slab::with_capacity(buffer_count as usize);
        for _ in 0..buffer_count {
            let mut buffer = BytesMut::with_capacity(buffer_size as usize);
            buffer.resize(buffer_size as usize, 0);
            slab.insert(buffer);
        }
        Self {
            inner: Arc::new(RwLock::new(slab)),
            buffer_count,
            buffer_size,
        }
    }
    pub(crate) fn buffer_size(&self) -> isize {
        self.buffer_size
    }
    pub(crate) fn buffer_count(&self) -> isize {
        self.buffer_count
    }

    pub(crate) async fn len(&self) -> usize {
        self.inner.read().await.len()
    }

    pub(crate) async fn must_allocate(&self) -> BytesMut {
        {
            let inner = self.inner.read().await;
            if inner.len() == 0 {
                return BytesMut::with_capacity(self.buffer_size as usize);
            }
        }

        let mut inner = self.inner.write().await;
        if inner.len() == 0 {
            return BytesMut::with_capacity(self.buffer_size as usize);
        }
        let key = inner.iter().next().map(|(key, _)| key).unwrap();
        let mut buf = inner.remove(key);
        buf.clear();
        buf
    }

    pub(crate) async fn deallocate(&self, mut buffer: BytesMut) {
        if buffer.capacity() != self.buffer_size as usize {
            return;
        }

        {
            let inner = self.inner.read().await;
            if inner.vacant_key() >= self.buffer_count as usize {
                return;
            }
        }

        let mut inner = self.inner.write().await;
        if inner.vacant_key() >= self.buffer_count as usize {
            return;
        };
        buffer.clear();
        inner.insert(buffer);
    }
}

const GF2_DIM: usize = 64;
const ECMA: u64 = 0xC96C5795D7870F42;
fn gf2matrix_times(mat: &[u64; GF2_DIM], mut vec: u64) -> u64 {
    let mut sum = 0u64;
    let mut i = 0;
    while vec != 0 {
        if vec & 1 != 0 {
            sum ^= mat[i];
        }
        vec >>= 1;
        i += 1;
    }
    sum
}

fn gf2matrix_square(square: &mut [u64; GF2_DIM], mat: &[u64; 64]) {
    let mut n = 0;
    while n < GF2_DIM {
        square[n] = gf2matrix_times(mat, mat[n]);
        n += 1;
    }
}

pub(crate) fn combine_crc64(mut crc1: u64, crc2: u64, mut len2: usize) -> u64 {
    // Degenerate case
    if len2 == 0 {
        return crc1;
    }

    let mut even = [0u64; GF2_DIM];
    let mut odd = [0u64; GF2_DIM];

    // Put operator for one zero bit in odd
    odd[0] = ECMA;
    let mut row = 1u64;
    for n in 1..GF2_DIM {
        odd[n] = row;
        row <<= 1;
    }

    // Put operator for two zero bits in even
    gf2matrix_square(&mut even, &odd);

    // Put operator for four zero bits in odd
    gf2matrix_square(&mut odd, &even);

    // Apply len2 zeros to crc1, first square will put the operator for one zero byte, eight zero bits, in even
    loop {
        // Apply zeros operator for this bit of len2
        gf2matrix_square(&mut even, &odd);

        if len2 & 1 != 0 {
            crc1 = gf2matrix_times(&even, crc1)
        }

        len2 >>= 1;

        // If no more bits set, then done
        if len2 == 0 {
            break;
        }

        // Another iteration of the loop with odd and even swapped
        gf2matrix_square(&mut odd, &even);
        if len2 & 1 != 0 {
            crc1 = gf2matrix_times(&odd, crc1);
        }
        len2 >>= 1;

        // If no more bits set, then done
        if len2 == 0 {
            break;
        }
    }

    // Return combined CRC
    crc1 ^= crc2;
    crc1
}

#[cfg(test)]
mod tests {
    use crate::common::{BufferPool, DEFAULT_BUFFER_SIZE};
    use bytes::{Bytes, BytesMut};
    use std::fmt::Write;

    #[test]
    fn test_buffer_pool() {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async {
            let pool = BufferPool::new(0, DEFAULT_BUFFER_SIZE * 3);
            assert_eq!(pool.len().await, 3);
            let buf = pool.must_allocate().await;
            assert_eq!(pool.len().await, 2);
            let pool2 = pool.clone();
            let handler = rt.spawn(async move {
                let mut buf = pool2.must_allocate().await;
                assert_eq!(pool2.len().await, 1);
                assert_eq!(buf.len(), 0);
                buf.write_str("hello world").unwrap();
                assert_eq!(buf.len(), "hello world".len());
                buf
            });
            let buf2 = handler.await.unwrap();
            assert_eq!(pool.len().await, 1);
            let pool2 = pool.clone();
            let handler = rt.spawn(async move {
                pool2.deallocate(buf).await;
                assert_eq!(pool2.len().await, 2);
                pool2.deallocate(buf2).await;

                pool2
                    .deallocate(BytesMut::with_capacity(DEFAULT_BUFFER_SIZE as usize))
                    .await;
            });
            let _ = handler.await;
            assert_eq!(pool.len().await, 3);
        });
    }
}
