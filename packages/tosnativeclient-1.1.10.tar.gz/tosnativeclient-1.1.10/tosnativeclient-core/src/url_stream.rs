use crate::common::{split_objects, TokenAcquirer};
use crate::read_stream::ReadStream;
use crate::tos_client::{InnerTosClient, TosClient};
use crate::tos_model::TosObject;
use arc_swap::ArcSwap;
use async_channel::Receiver;
use std::collections::VecDeque;
use std::error::Error;
use std::sync::atomic::{AtomicI8, Ordering};
use std::sync::Arc;
use tokio::runtime::Runtime;
use tokio::sync::RwLock;
use tokio::task::JoinHandle;
use tracing::log::warn;
use ve_tos_rust_sdk::error::TosError;

const DEFAULT_BUFFER_COUNT: usize = 3;
pub struct UrlStream {
    runtime: Arc<Runtime>,
    paginator: RwLock<Paginator>,
    closed: AtomicI8,
}

impl UrlStream {
    pub(crate) fn new(
        runtime: Arc<Runtime>,
        tos_client: Arc<TosClient>,
        urls: impl Iterator<Item = Result<String, Box<dyn Error + Send>>> + Send + 'static,
        max_keys: isize,
        list_background_buffer_count: isize,
        prefetch_concurrency: isize,
        distributed_info: Option<(isize, isize, isize, isize)>,
    ) -> Self {
        Self {
            runtime: runtime.clone(),
            paginator: RwLock::new(Paginator::new(
                runtime,
                tos_client,
                urls,
                max_keys,
                list_background_buffer_count,
                prefetch_concurrency,
                distributed_info,
            )),
            closed: AtomicI8::new(0),
        }
    }

    pub fn next(&self) -> Result<Option<(VecDeque<TosObject>, Option<Vec<ReadStream>>)>, TosError> {
        self.runtime.block_on(async {
            if self.closed.load(Ordering::Acquire) == 1 {
                return Err(TosError::TosClientError {
                    message: "UrlStream is closed".to_string(),
                    cause: None,
                    request_url: "".to_string(),
                });
            }

            let pg = self.paginator.read().await;
            self.next_page(&pg).await
        })
    }

    pub fn close(&self) {
        if let Ok(_) = self
            .closed
            .compare_exchange(0, 1, Ordering::AcqRel, Ordering::Relaxed)
        {
            self.runtime.block_on(async {
                let mut pg = self.paginator.write().await;
                pg.receiver.close();
                pg.close().await;
            })
        }
    }

    pub(crate) async fn next_page(
        &self,
        pg: &Paginator,
    ) -> Result<Option<(VecDeque<TosObject>, Option<Vec<ReadStream>>)>, TosError> {
        match pg.has_next() {
            Err(ex) => {
                return Err(ex);
            }
            Ok(has_next) => {
                if !has_next {
                    return Ok(None);
                }
            }
        }
        pg.next_page().await
    }
}

struct Paginator {
    is_end: ArcSwap<bool>,
    last_err: ArcSwap<Option<TosError>>,
    receiver: Receiver<(
        bool,
        Result<(VecDeque<TosObject>, Option<Vec<ReadStream>>), TosError>,
    )>,
    wait_list_background: Option<JoinHandle<()>>,
}

impl Paginator {
    fn new(
        runtime: Arc<Runtime>,
        tos_client: Arc<TosClient>,
        mut urls: impl Iterator<Item = Result<String, Box<dyn Error + Send>>> + Send + 'static,
        mut max_keys: isize,
        list_background_buffer_count: isize,
        prefetch_concurrency: isize,
        distributed_info: Option<(isize, isize, isize, isize)>,
    ) -> Self {
        let mut buffer_count = list_background_buffer_count as usize;
        if buffer_count <= 0 {
            buffer_count = DEFAULT_BUFFER_COUNT;
        }
        if max_keys <= 0 {
            max_keys = 1000;
        }
        let (sender, receiver) = async_channel::bounded(buffer_count);
        let ta;
        if prefetch_concurrency > 0 {
            ta = Some(Arc::new(TokenAcquirer::new(prefetch_concurrency)));
        } else {
            ta = None;
        }
        let wait_list_background = runtime.spawn(async move {
            // global_idx, worker_idx
            let mut idxs = (0, 0);
            let mut need_break = false;
            loop {
                let mut objects = VecDeque::with_capacity(max_keys as usize);
                while objects.len() < max_keys as usize {
                    match urls.next() {
                        None => {
                            need_break = true;
                            break;
                        }
                        Some(url) => match url {
                            Err(e) => {
                                need_break = true;
                                let _ = sender
                                    .send((
                                        need_break,
                                        Err(TosError::TosClientError {
                                            message: e.to_string(),
                                            cause: None,
                                            request_url: "".to_string(),
                                        }),
                                    ))
                                    .await;
                                return;
                            }
                            Ok(url) => {
                                if let Some((world_size, rank, worker_size, worker_id)) =
                                    distributed_info
                                {
                                    if idxs.0 % world_size == rank {
                                        if idxs.1 % worker_size == worker_id {
                                            match parse_tos_url(
                                                url,
                                                ta.is_none(),
                                                tos_client.clone(),
                                            )
                                            .await
                                            {
                                                Ok(object) => objects.push_back(object),
                                                Err(e) => {
                                                    need_break = true;
                                                    let _ = sender.send((need_break, Err(e))).await;
                                                    return;
                                                }
                                            }
                                        }
                                        idxs.1 += 1;
                                    }
                                    idxs.0 += 1;
                                } else {
                                    idxs.0 += 1;
                                    idxs.1 += 1;
                                    match parse_tos_url(url, ta.is_none(), tos_client.clone()).await
                                    {
                                        Ok(object) => objects.push_back(object),
                                        Err(e) => {
                                            need_break = true;
                                            let _ = sender.send((need_break, Err(e))).await;
                                            return;
                                        }
                                    }
                                }
                            }
                        },
                    }
                }

                if objects.is_empty() || ta.is_none() {
                    if let Err(_) = sender.send((need_break, Ok((objects, None)))).await {
                        warn!("send on closed channel!");
                        need_break = true;
                    }
                } else {
                    let ta = ta.as_ref().unwrap();
                    let mut is_end = false;
                    while objects.len() > 0 {
                        let permit = ta.acquire().await.unwrap();
                        let (splited_objects, read_stream_list) = split_objects(
                            None,
                            &mut objects,
                            tos_client.clone(),
                            ta.clone(),
                            permit,
                        )
                        .await;
                        if objects.is_empty() {
                            is_end = need_break;
                        }
                        if let Err(_) = sender
                            .send((is_end, Ok((splited_objects, Some(read_stream_list)))))
                            .await
                        {
                            warn!("send on closed channel!");
                            is_end = true;
                            need_break = true;
                        }
                    }
                }

                if need_break {
                    break;
                }
            }
        });
        Paginator {
            is_end: ArcSwap::new(Arc::new(false)),
            last_err: ArcSwap::new(Arc::new(None)),
            receiver,
            wait_list_background: Some(wait_list_background),
        }
    }

    fn has_next(&self) -> Result<bool, TosError> {
        if let Some(err) = self.last_err.load().as_ref() {
            return Err(err.clone());
        }
        Ok(!*self.is_end.load().as_ref())
    }

    async fn close(&mut self) {
        if let Some(wait_list_background) = self.wait_list_background.take() {
            let _ = wait_list_background.await;
        }
    }

    async fn next_page(
        &self,
    ) -> Result<Option<(VecDeque<TosObject>, Option<Vec<ReadStream>>)>, TosError> {
        if let Some(e) = self.last_err.load().as_ref() {
            return Err(e.clone());
        }
        if *self.is_end.load().as_ref() {
            return Ok(None);
        }

        match self.receiver.recv().await {
            Err(_) => {
                self.is_end.store(Arc::new(true));
                Err(TosError::TosClientError {
                    message: "no next page error".to_string(),
                    cause: None,
                    request_url: "".to_string(),
                })
            }
            Ok((is_end, result)) => match result {
                Err(e) => {
                    self.last_err.store(Arc::new(Some(e.clone())));
                    Err(e)
                }
                Ok(output) => {
                    if is_end {
                        self.is_end.store(Arc::new(true));
                    }
                    Ok(Some((output.0, output.1)))
                }
            },
        }
    }
}

async fn parse_tos_url(
    url: String,
    fetch_etag_size: bool,
    tos_client: Arc<TosClient>,
) -> Result<TosObject, TosError> {
    let mut url = url.trim();
    if url.is_empty() {
        return Err(TosError::TosClientError {
            message: "url is empty".to_string(),
            cause: None,
            request_url: "".to_string(),
        });
    }

    if url.starts_with("tos://") {
        url = &url["tos://".len()..url.len()];
    }

    if url.is_empty() {
        return Err(TosError::TosClientError {
            message: "bucket is empty".to_string(),
            cause: None,
            request_url: "".to_string(),
        });
    }
    let url = url.splitn(2, '/').collect::<Vec<&str>>();
    let bucket;
    let key;
    if url.len() == 1 {
        bucket = url[0];
        key = "";
    } else {
        bucket = url[0];
        key = url[1];
    }
    if bucket.is_empty() {
        return Err(TosError::TosClientError {
            message: "bucket is empty".to_string(),
            cause: None,
            request_url: "".to_string(),
        });
    }

    if fetch_etag_size {
        let output = tos_client
            .async_head_object(bucket.to_string(), key.to_string())
            .await?;
        return Ok(output);
    }

    Ok(TosObject::new(bucket, key, -1, "", 0))
}
