use futures_util::StreamExt;
use md5::Digest;
use md5::Md5;
use rand::Rng;
use scopeguard::defer;
use std::env;
use std::error::Error;
use std::path::Path;
use std::sync::Arc;
use tosnativeclient_core::common::init_tracing_log;
use tosnativeclient_core::tos_client::TosClient;
use ve_tos_rust_sdk::asynchronous::bucket::BucketAPI;
use ve_tos_rust_sdk::asynchronous::multipart::MultipartAPI;
use ve_tos_rust_sdk::asynchronous::object::ObjectAPI;
use ve_tos_rust_sdk::bucket::DeleteBucketInput;
use ve_tos_rust_sdk::multipart::{AbortMultipartUploadInput, ListMultipartUploadsInput};
use ve_tos_rust_sdk::object::{DeleteObjectInput, GetObjectInput, ListObjectsType2Input};

#[test]
fn test_main() {
    let ak = env::var("TOS_ACCESS_KEY").unwrap_or("".to_string());
    let sk = env::var("TOS_SECRET_KEY").unwrap_or("".to_string());
    let ep = env::var("TOS_ENDPOINT").unwrap_or("".to_string());
    let mut client = TosClient::new(
        "test-region".to_string(),
        ep.clone(),
        ak.clone(),
        sk.clone(),
        5 * 1024 * 1024,
        3,
        1,
        32,
        true,
        1,
        32,
        0,
        true,
        None,
        Some(("soft_name".to_string(), "soft_version".to_string())),
    )
    .unwrap();

    let mut client_no_crc = TosClient::new(
        "test-region".to_string(),
        ep,
        ak,
        sk,
        5 * 1024 * 1024,
        3,
        1,
        32,
        false,
        1,
        32,
        0,
        true,
        None,
        Some(("soft_name".to_string(), "soft_version".to_string())),
    )
    .unwrap();

    let log_path = "logs";
    let bucket = create_bucket(client.clone());
    init_tracing_log("info".to_string(), log_path.to_string(), "test".to_string());
    defer! {
       clean_bucket(client.clone(), &bucket, true);
        client.close();
        client_no_crc.close();
        clean_logs(log_path);
    }

    test_single_small_object(client.clone(), &bucket);
    test_single_small_object(client_no_crc.clone(), &bucket);
    test_single_large_object(client.clone(), &bucket);
    test_single_large_object(client_no_crc.clone(), &bucket);
    test_multi_objects(client.clone(), &bucket);
}

fn clean_logs(log_path: &str) {
    let path = Path::new(log_path);
    if path.exists() && path.is_dir() {
        std::fs::remove_dir_all(path).unwrap();
    }
}

fn test_multi_objects(client: Arc<TosClient>, bucket: &str) {
    clean_bucket(client.clone(), &bucket, false);
    let mut keys_all = Vec::new();
    let mut common_prefixes_all = Vec::new();
    let mut first_prefix_keys = Vec::new();
    let mut first_prefix_common_prefixes = Vec::new();
    let prefix_count = 5;
    let key_count = 10;
    for i in 0..prefix_count {
        let prefix = gen_random_string(8);
        common_prefixes_all.push(prefix.clone() + "/");
        for j in 0..prefix_count {
            let sub_prefix = format!("{}/{}", prefix, gen_random_string(8));
            if i == 0 {
                first_prefix_common_prefixes.push(sub_prefix.clone() + "/");
            }
            common_prefixes_all.push(sub_prefix.clone() + "/");
            for k in 0..key_count {
                let key = format!("{}/{}", sub_prefix, gen_random_string(8));
                if i == 0 {
                    first_prefix_keys.push(key.clone());
                }
                let ws = client
                    .put_object(bucket.to_string(), key.clone(), None)
                    .unwrap();
                let size = ws.write(key.as_bytes()).unwrap();
                assert_eq!(size, key.len() as isize);
                ws.close().unwrap();
                keys_all.push(key);
            }
        }
    }

    let first_prefix = common_prefixes_all.get(0).unwrap().clone();
    keys_all.sort();
    common_prefixes_all.sort();
    first_prefix_keys.sort();
    first_prefix_common_prefixes.sort();

    for key in keys_all.iter() {
        let om = client
            .head_object(bucket.to_string(), key.to_string())
            .unwrap();
        assert_eq!(om.size(), key.len() as isize);
    }

    for (delimiter, prefetch_concurrency) in vec![("", 0), ("/", 0)] {
        let ls = client.list_objects(
            bucket.to_string(),
            first_prefix.clone(),
            3,
            delimiter.to_string(),
            "".to_string(),
            "".to_string(),
            3,
            prefetch_concurrency,
            None,
        );
        let mut keys = Vec::new();
        let mut prefixes = Vec::new();
        loop {
            let result = ls.next().unwrap();
            if result.is_none() {
                break;
            }
            let result = result.unwrap();
            for obj in result.0 {
                keys.push(obj.key().to_string());
            }

            if let Some(mut common_prefixes) = result.1 {
                prefixes.append(&mut common_prefixes);
            }
        }

        keys.sort();
        prefixes.sort();
        if delimiter == "/" {
            assert_eq!(first_prefix_common_prefixes, prefixes);
        }
        assert_eq!(first_prefix_keys, keys);
        ls.close();
    }

    for (delimiter, prefetch_concurrency) in vec![("", 0), ("/", 0), ("", 3), ("/", 3)] {
        let ls = client.list_objects(
            bucket.to_string(),
            "".to_string(),
            3,
            delimiter.to_string(),
            "".to_string(),
            "".to_string(),
            3,
            prefetch_concurrency,
            None,
        );
        let mut keys = Vec::new();
        let mut prefixes = Vec::new();
        loop {
            let result = ls.next().unwrap();
            if result.is_none() {
                break;
            }
            let result = result.unwrap();
            for obj in result.0.iter() {
                keys.push(obj.key().to_string());
            }

            if let Some(mut common_prefixes) = result.1 {
                prefixes.append(&mut common_prefixes);
            }

            if prefetch_concurrency == 0 {
                assert!(result.2.is_none());
            } else {
                let read_streams = result.2.unwrap();
                for (idx, rs) in read_streams.iter().enumerate() {
                    let key = result.0.get(idx).unwrap();
                    assert_eq!(rs.key(), key.key());
                    assert_eq!(rs.fetch_etag_size_err(), None);
                    let mut readed = Vec::with_capacity(rs.size() as usize);
                    let mut offset = 0;
                    loop {
                        let data = rs.read(offset, 1 * 1024 * 1024, true).unwrap();
                        if data.is_none() {
                            break;
                        }
                        let data = data.unwrap();
                        assert!(data.len() <= 1 * 1024 * 1024);
                        readed.extend_from_slice(&data);
                        offset += data.len() as isize;
                    }
                    // println!("{}", String::from_utf8(readed.clone()).unwrap());
                    rs.close();
                    assert_eq!(readed, key.key().as_bytes());
                }
            }
        }

        keys.sort();
        prefixes.sort();
        if delimiter == "/" {
            assert_eq!(common_prefixes_all, prefixes);
        }
        assert_eq!(keys_all, keys);
        ls.close();
    }

    let ls = client.list_objects(
        bucket.to_string(),
        "".to_string(),
        3,
        "".to_string(),
        "".to_string(),
        "".to_string(),
        3,
        0,
        Some((2, 1, 5, 1)),
    );

    let mut count = 0;
    loop {
        let result = ls.next().unwrap();
        if result.is_none() {
            break;
        }
        count += result.unwrap().0.len();
    }
    assert_eq!(count, keys_all.len() / 10);
    ls.close();

    let mut urls = Vec::with_capacity(keys_all.len());
    for key in keys_all.iter() {
        urls.push(format!("tos://{}/{}", bucket, key));
    }

    let urls = UrlIterator { urls, idx: 0 };

    for prefetch_concurrency in vec![0, 3] {
        let mut keys = Vec::new();
        let us = client.list_objects_from_urls(urls.clone(), 10, 3, prefetch_concurrency, None);
        let mut count = 0;
        loop {
            let result = us.next().unwrap();
            if result.is_none() {
                break;
            }
            let result = result.unwrap();
            for obj in result.0.iter() {
                keys.push(obj.key().to_string());
            }
            count += result.0.len();
            if prefetch_concurrency > 0 && result.0.len() > 0 {
                for rs in result.1.unwrap() {
                    assert_eq!(rs.fetch_etag_size_err(), None);
                    let mut readed = Vec::with_capacity(rs.size() as usize);
                    let mut offset = 0;
                    loop {
                        let data = rs.read(offset, 1 * 1024 * 1024, true).unwrap();
                        if data.is_none() {
                            break;
                        }
                        let data = data.unwrap();
                        assert!(data.len() <= 1 * 1024 * 1024);
                        readed.extend_from_slice(&data);
                        offset += data.len() as isize;
                    }
                    rs.close();
                    assert_eq!(readed, rs.key().as_bytes());
                }
            } else {
                assert!(result.1.is_none())
            }
        }
        keys.sort();
        assert_eq!(keys, keys_all);
        assert_eq!(count, keys_all.len());
        us.close();
    }

    let us = client.list_objects_from_urls(urls.clone(), 3, 3, 0, Some((2, 1, 5, 1)));
    let mut count = 0;
    loop {
        let result = us.next().unwrap();
        if result.is_none() {
            break;
        }
        count += result.unwrap().0.len();
    }
    assert_eq!(count, keys_all.len() / 10);
    us.close();
}

fn test_single_large_object(client: Arc<TosClient>, bucket: &str) {
    let key = gen_random_string(8);
    let content = gen_random_string(1024 * 1024 * 5);
    let ws = client
        .put_object(bucket.to_string(), key.clone(), None)
        .unwrap();

    let mut hasher = Md5::new();
    // 100MB = 5MB*20
    let count = 20;
    for i in 0..count {
        let size = ws.write(content.as_bytes()).unwrap();
        assert_eq!(size, content.len() as isize);
        hasher.update(content.as_bytes());
    }
    ws.close().unwrap();
    let expected = hex::encode(hasher.finalize());
    println!("{}", "write data done");

    let om = client.head_object(bucket.to_string(), key.clone()).unwrap();
    assert_eq!(om.size(), count * content.len() as isize);

    for (etag, size, crc64) in vec![
        (
            Some(om.etag().to_string()),
            Some(om.size()),
            Some(om.crc64()),
        ),
        (None, None, None),
    ] {
        let preload;
        if etag.is_none() {
            preload = true;
        } else {
            preload = false;
        }
        let rs = client.get_object(
            bucket.to_string(),
            key.clone(),
            etag.clone(),
            size,
            crc64,
            preload,
        );
        for i in 0..2 {
            let mut hasher = Md5::new();
            let mut offset = 0;
            loop {
                let data = rs.read(offset, 1 * 1024 * 1024, true).unwrap();
                if data.is_none() {
                    break;
                }
                let data = data.unwrap();
                assert!(data.len() <= 1 * 1024 * 1024);
                hasher.update(&data);
                offset += data.len() as isize;
            }
            assert_eq!(offset, om.size());
            let actual = hex::encode(hasher.finalize());
            assert_eq!(expected, actual);
        }
        rs.close();
    }
}

fn test_single_small_object(client: Arc<TosClient>, bucket: &str) {
    let key = gen_random_string(8);
    let ws = client
        .put_object(bucket.to_string(), key.clone(), None)
        .unwrap();
    ws.close().unwrap();
    let om = client.head_object(bucket.to_string(), key.clone()).unwrap();
    assert_eq!(om.size(), 0 as isize);
    let rs = client.get_object(
        bucket.to_string(),
        key.clone(),
        Some(om.etag().to_string()),
        Some(om.size()),
        Some(om.crc64()),
        false,
    );
    let data = rs.read(0, 3, true).unwrap();
    assert!(data.is_none());

    let key = gen_random_string(8);
    let ws = client
        .put_object(bucket.to_string(), key.clone(), None)
        .unwrap();
    for i in 0..3 {
        let size = ws.write("helloworld".as_bytes()).unwrap();
        assert_eq!(size, "helloworld".len() as isize);
    }
    ws.close().unwrap();

    let om = client.head_object(bucket.to_string(), key.clone()).unwrap();
    assert_eq!(om.size(), ("helloworld".len() * 3) as isize);

    let rs = client.get_object(
        bucket.to_string(),
        key.clone(),
        Some(om.etag().to_string()),
        Some(om.size()),
        Some(om.crc64()),
        false,
    );
    let data = rs.read(om.size(), 3, true).unwrap();
    assert!(data.is_none());

    for (etag, size, crc64) in vec![
        (
            Some(om.etag().to_string()),
            Some(om.size()),
            Some(om.crc64()),
        ),
        (None, None, None),
    ] {
        let preload;
        if etag.is_none() {
            preload = true;
        } else {
            preload = false;
        }
        let rs = client.get_object(bucket.to_string(), key.clone(), etag, size, crc64, preload);
        for i in 0..3 {
            let mut content = Vec::with_capacity(om.size() as usize);
            let mut offset = 0;
            loop {
                let data = rs.read(offset, 3, true).unwrap();
                if data.is_none() {
                    break;
                }
                let data = data.unwrap();
                assert!(data.len() <= 3);
                content.extend_from_slice(&data);
                offset += data.len() as isize;
            }
            assert_eq!(offset, om.size());
            assert_eq!(content, "helloworld".repeat(3).as_bytes());
        }
        rs.close();
    }
}

fn create_bucket(client: Arc<TosClient>) -> String {
    let mut fixed_bucket;
    loop {
        fixed_bucket = gen_random_string(10);
        match client.create_bucket(fixed_bucket.clone()) {
            Ok(_) => {
                return fixed_bucket;
            }
            Err(e) => {
                if !e.is_server_error() {
                    panic!("{}", e.to_string());
                }

                let ex = e.as_server_error().unwrap();
                if ex.status_code() != 409 {
                    panic!("unexpected status code, {}", ex.code());
                }
            }
        }
    }
}

fn gen_random_string(len: usize) -> String {
    let mut result = String::with_capacity(len);
    let characters = "0123456789abcdefghijklmnopqrstuvwxyz".as_bytes();
    let mut ra = rand::thread_rng();
    for _ in 0..len {
        let a = ra.gen_range(0..characters.len());
        result.push(characters[a] as char);
    }

    result
}

fn clean_bucket(client: Arc<TosClient>, bucket: &str, delete_bucket: bool) {
    let runtime = client.get_async_runtime();
    let client = client.wclient();
    runtime.block_on(async {
        let mut can_delete_bucket = true;
        let mut input = ListObjectsType2Input::new(bucket);
        input.set_max_keys(1000);
        'outer: loop {
            match client.list_objects_type2(&input).await {
                Ok(o) => {
                    for content in o.contents() {
                        if let Err(_) = client
                            .delete_object(&DeleteObjectInput::new(bucket, content.key()))
                            .await
                        {
                            can_delete_bucket = false;
                            break 'outer;
                        }
                    }

                    if !o.is_truncated() {
                        break;
                    }

                    input.set_continuation_token(o.next_continuation_token());
                }
                Err(_) => {
                    can_delete_bucket = false;
                    break;
                }
            }
        }

        let mut input = ListMultipartUploadsInput::new(bucket);
        input.set_max_uploads(1000);
        'outer: loop {
            match client.list_multipart_uploads(&input).await {
                Ok(o) => {
                    for upload in o.uploads() {
                        if let Err(_) = client
                            .abort_multipart_upload(&AbortMultipartUploadInput::new(
                                bucket,
                                upload.key(),
                                upload.upload_id(),
                            ))
                            .await
                        {
                            can_delete_bucket = false;
                            break 'outer;
                        }
                    }

                    if !o.is_truncated() {
                        break;
                    }

                    input.set_upload_id_marker(o.next_upload_id_marker());
                    input.set_key_marker(o.next_key_marker());
                }
                Err(_) => {
                    can_delete_bucket = false;
                    break;
                }
            }
        }

        if can_delete_bucket && delete_bucket {
            let _ = client.delete_bucket(&DeleteBucketInput::new(bucket)).await;
        }
    });
}

#[derive(Clone)]
struct UrlIterator {
    urls: Vec<String>,
    idx: usize,
}

impl Iterator for UrlIterator {
    type Item = Result<String, Box<dyn Error + Send>>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.idx >= self.urls.len() {
            return None;
        }
        let url = &self.urls[self.idx];
        self.idx += 1;
        Some(Ok(url.to_string()))
    }
}
