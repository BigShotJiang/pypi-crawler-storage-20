use crate::read_stream::ReadStream;
use crate::tos_model::ListObjectsResult;
use pyo3::{pyfunction, PyResult, Python};
use std::collections::VecDeque;
use std::sync::Arc;

#[pyfunction]
#[pyo3(signature = (seconds, file_path, image_width=1200))]
pub fn async_write_profile(
    py: Python<'_>,
    seconds: i64,
    file_path: String,
    image_width: usize,
) -> PyResult<()> {
    tosnativeclient_core::common::async_write_profile(seconds, file_path.as_str(), image_width);
    Ok(())
}

#[pyfunction]
#[pyo3(signature = (directives, directory, file_name_prefix))]
pub fn init_tracing_log(
    py: Python<'_>,
    directives: String,
    directory: String,
    file_name_prefix: String,
) -> PyResult<()> {
    tosnativeclient_core::common::init_tracing_log(directives, directory, file_name_prefix);
    Ok(())
}

pub(crate) fn trans_list_objects_result(
    output: (
        VecDeque<tosnativeclient_core::tos_model::TosObject>,
        Option<Vec<String>>,
        Option<Vec<tosnativeclient_core::read_stream::ReadStream>>,
    ),
) -> (ListObjectsResult, Option<Vec<ReadStream>>) {
    match output.2 {
        None => (ListObjectsResult::new(output.0, output.1), None),
        Some(streams) => {
            let mut read_streams = Vec::with_capacity(streams.len());
            for stream in streams {
                let bucket = stream.bucket().to_string();
                let key = stream.key().to_string();
                read_streams.push(ReadStream {
                    read_stream: Arc::new(stream),
                    bucket,
                    key,
                });
            }
            (
                ListObjectsResult::new(output.0, output.1),
                Some(read_streams),
            )
        }
    }
}
