"""Core module initialization."""
