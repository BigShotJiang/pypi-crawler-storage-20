"""Database module initialization."""
