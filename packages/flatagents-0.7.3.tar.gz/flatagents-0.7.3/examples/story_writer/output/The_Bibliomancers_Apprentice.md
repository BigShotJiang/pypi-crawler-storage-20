# The Bibliomancer's Apprentice

*Genre: science fiction*

*Premise: A librarian discovers books can transport readers into their stories*

---

## Chapter 1

The pull began not as a thought, but as a physical itch behind his sternum. Elias paused, a first-edition alchemical text halfway to its designated shelf, and cataloged the sensation: a low-frequency hum, a localized pressure, a sudden, inexplicable yearning directed toward the Restricted Stacks. He prided himself on this mental discipline, this ability to categorize and file away every stray impulse. It was the librarian's art. Order from chaos. But this feeling refused its Dewey Decimal number.

He abandoned his duties. His precise, measured steps devolved into a hurried, uneven gait down the narrow, dust-moted aisle. The air grew thick, humming with the same frequency that now vibrated in his bones. The source was a volume bound in what looked like flayed, obsidian-scale leather, tucked away behind a row of forgotten occult histories. It was vibrating, a low, resonant thrum that seemed to pull the light from the air around it.

His fingers, usually so careful, trembled as they grazed the cover. The moment his skin made contact, the world dissolved. He was no longer in the library. He tore himself free, stumbling back into the library's hush, the scent of old paper and leather a sudden, desperate anchor. But the other place lingered. The sharp, citrus-and-ozone tang of crystalline blossoms clung to the back of his throat. His hands, he saw with a jolt of pure, clinical horror, were smudged with a fine, iridescent dust that shimmered with an impossible violet light.

He shoved the book back onto its shelf, his breath coming in ragged, un-catalogued gasps. He had to get back to his desk, to the familiar, the rational. He smoothed his tweed jacket, his fingers catching on a tiny, sharp imperfection. He pulled his hand away. There, caught on the woolen fabric, was a single sliver of a petal. It was made of what looked like spun glass, and it pulsed with a soft, internal luminescence. A data point. An impossible, terrifying data point from a world that should not exist. And it was here. In his library. On his jacket.

## Chapter 2

The memory of the book clung to Elias like the scent of ozone after a lightning strike. Three days had passed since his unauthorized excursion into the Restricted Stacks, three days spent in a haze of shelving and cataloging while his mind replayed the impossible journey. The world inside the book—a crystalline forest under a binary sunset—had felt more real than the scent of aging paper and binding glue that now filled his nostrils. He was haunted, not by fear, but by a profound and unsettling curiosity.

That night, alone in the stark silence of his apartment, Elias placed the book on his kitchen table. Its cover was plain, unmarked black leather, deceptively mundane. He ran a finger over its spine, the familiar itch returning, a phantom pull that resonated in the hollow of his bones. He took a steadying breath. This time, he would be in control.

He focused on the feeling, not as a passenger but as a pilot. He imagined it as a dial, a frequency he could tune. A low hum built behind his eyes, a pressure that was both painful and ecstatic. He nudged his consciousness forward, just a sliver. The world didn't dissolve. Instead, a single, impossible detail bled into his reality: a petal from one of the crystalline flowers shimmered into existence on the table before him, pulsing with a soft, internal light. It was beautiful, terrifying, and utterly silent. With a gasp, Elias pulled back, the pressure receding, and the petal vanished.

He spent the next hour experimenting, learning to modulate the connection. A brief glimpse of the twin suns painted rainbows on his ceiling, the sound of a wind that had no air to carry it whispered in his ears, the scent of alien soil filled his lungs. He was learning the language of the book, and it was learning him. He was so engrossed, so drunk on the power, that he failed to notice the sudden chill in the room, or the flicker of movement in the window's reflection. Down on the rain-slicked street, a man in a tan trench coat stood watching.

The next morning, a note was tucked into his locker at the Athenaeum. The paper was thick, expensive, and the ink was a deep, unsettling crimson. The handwriting was a sharp, decisive scrawl.

*They feel you using the key. The Archivist is not what he seems. He is the Warden. These are not escapes, apprentice. They are cages. Be careful whose cage you rattle.*

Elias’s blood ran cold. *Warden? Cages?* He read the note again, his heart hammering against his ribs. The Archivist—Mr. Abernathy, the man who had given him his job, the man with the kind eyes and gentle smile—was the leader of a society that hunted these books? It was absurd. But the crystalline petal, the impossible journey, the raw, undeniable power of the text… it was all absurd.

He crumpled the note in his fist, his mind a whirlwind of paranoia and revelation. He looked up and saw Mr. Abernathy walking down the main aisle, his face a mask of serene benevolence. He was returning a book to its shelf, his movements precise and practiced. As he passed Elias’s cart, he paused.

“Elias,” Abernathy said, his voice as dry and rustling as turning a brittle page. “You look a bit peaked. Late night with a particularly dense volume?”

“Just… cross-referencing, Mr. Abernathy. A difficult provenance,” Elias managed, his throat dry. He could feel the weight of the crumpled note in his pocket, a secret made of paper and ink that felt heavier than lead.

“Good. A thirst for knowledge is the lifeblood of this place,” Abernathy said, placing a hand on Elias’s shoulder. The touch was paternal, but Elias flinched. “But we must be careful not to let the stories consume the storyteller, eh, Elias?” His eyes, for just a moment, held a glint of something cold and sharp, like a shard of broken glass. He held Elias’s gaze, a beat too long, and Elias felt an overwhelming urge to run, but his feet were rooted to the floor. Then, the glint was gone, replaced by the familiar warmth. He smiled and continued on his way, leaving Elias trembling in his wake. The silence stretched, thick and suffocating, before the scent of old paper suddenly smelled of a prison.

