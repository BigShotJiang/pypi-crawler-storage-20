"""sageLLM Core 运行时。

本包提供 sageLLM 的核心运行时组件：
- 配置 schema 与校验
- Engine 抽象接口与实现
- Backend 与 Engine 工厂函数
- 插件系统
- Demo Runner
"""

from __future__ import annotations

from sagellm_core.config import (
    BackendConfig,
    DemoConfig,
    EngineConfig,
    MockConfig,
    OutputConfig,
    WorkloadConfig,
    WorkloadSegment,
    load_config,
)
from sagellm_core.demo import main as demo_main
from sagellm_core.engine import BaseEngine
from sagellm_core.factory import create_backend, create_engine
from sagellm_core.health import HealthStatus
from sagellm_core.plugins import PluginResolutionError, list_entry_points, resolve_kind
from sagellm_core.runner import DemoRunner, RunnerContext

__version__ = "0.1.0.3"

__all__ = [
    # Version
    "__version__",
    # Configuration
    "BackendConfig",
    "DemoConfig",
    "EngineConfig",
    "MockConfig",
    "OutputConfig",
    "WorkloadConfig",
    "WorkloadSegment",
    "load_config",
    # Engine abstraction
    "BaseEngine",
    "HealthStatus",
    # Factory functions
    "create_backend",
    "create_engine",
    # Plugin system
    "PluginResolutionError",
    "list_entry_points",
    "resolve_kind",
    # Demo runner
    "demo_main",
    "DemoRunner",
    "RunnerContext",
]
