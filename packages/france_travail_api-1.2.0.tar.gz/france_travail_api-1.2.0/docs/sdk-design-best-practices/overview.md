# A Guide to Creating SDKs for RESTful APIs

You’ve decided to start building SDKs or are looking to improve existing ones. We want to recognize there are many types of SDKs. As a starting point, we’ve chosen to focus our best practices on building SDKs for RESTful APIs. There are thousands of RESTful API that developers consume using variety of languages like C#, Go, Java, PHP, Python, Ruby, TypeScript and many more.

Our goals is to foster a community of SDK builders, and will start by contributing our knowledge around building SDKs for APIs.

Hardware platforms like Apple iOS and other technologies like GraphQL, gRPC and platforms like Salesforce offer SDKs too. But they differ from RESTful APIs and likely need their own guides. If you have experience building other types of SDKs and would like to contribute, head over to GitHub discussions to connect with our team about contributing content or a guest blog post.

The design section will help you think big picture and establish guidelines for developing code libraries that are the foundation for your SDK. The build section gets into the details of structuring your code to be robust and resilient for developers. Lastly, the support section covers tips for educating and engaging developers around your SDKs.
