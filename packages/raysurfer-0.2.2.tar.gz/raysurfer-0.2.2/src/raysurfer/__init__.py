"""
RaySurfer Python SDK

Store and retrieve code blocks for AI agents with semantic search
and verdict-aware scoring.

Includes Claude Agent SDK integration via RaysurferClient.
"""

from raysurfer.client import AsyncRaySurfer, RaySurfer
from raysurfer.exceptions import APIError, AuthenticationError, RaySurferError
from raysurfer.sdk_client import RaysurferAgentOptions, RaysurferClient
from raysurfer.sdk_types import CodeFile, GetCodeFilesResponse
from raysurfer.types import (
    AgentReview,
    AgentVerdict,
    BestMatch,
    CodeBlock,
    ExecutionIO,
    ExecutionRecord,
    ExecutionState,
    FewShotExample,
    FileWritten,
    SubmitExecutionResultResponse,
    TaskPattern,
)

__version__ = "0.2.0"

__all__ = [
    # Clients
    "RaySurfer",
    "AsyncRaySurfer",
    # Claude Agent SDK integration
    "RaysurferClient",
    "RaysurferAgentOptions",
    # Types
    "AgentReview",
    "AgentVerdict",
    "BestMatch",
    "CodeBlock",
    "CodeFile",
    "ExecutionIO",
    "ExecutionRecord",
    "ExecutionState",
    "FewShotExample",
    "FileWritten",
    "GetCodeFilesResponse",
    "SubmitExecutionResultResponse",
    "TaskPattern",
    # Exceptions
    "RaySurferError",
    "APIError",
    "AuthenticationError",
]
