"""
Module to include the functionality related
to easings.

Thanks for the inspiration:
- https://github.com/semitable/easing-functions/blob/master/easing_functions
"""
from yta_math_easings.linear import LinearEasing
from yta_math_easings.slow_into import SlowIntoEasing


__all__ = [
    'LinearEasing',
    'SlowIntoEasing'
]