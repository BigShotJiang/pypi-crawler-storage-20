


def get_class(
    name: str
    # TODO: Add the imports if the method is needed
) -> any:
# ) -> Union[EasingFunction, None]:
    """
    Get the easing function class that corresponds to the
    `name` provided, if existing.
    """
    from yta_math_easings.linear import LinearEasing

    # TODO: Add all the classes here
    classes = [
        LinearEasing
    ]

    for cls in classes:
        if cls.__name__.lower() == f'{name.lower()}easing':
            return cls
        
    return None