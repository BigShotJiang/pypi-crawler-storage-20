from yta_math_easings.abstract import EasingFunction


class LinearEasing(EasingFunction):
    """
    A linear easing function.

    The formula:
    - `n`
    """

    def _func(
        self,
        n: float
    ) -> float:
        return n
    
