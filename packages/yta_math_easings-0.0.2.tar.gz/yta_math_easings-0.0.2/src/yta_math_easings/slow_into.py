from yta_math_easings.abstract import EasingFunction

import numpy as np


class SlowIntoEasing(EasingFunction):
    """
    A slow into easing function.

    The formula:
    - `np.sqrt(1 - (1 - n) * (1 - n))`
    """

    def _func(
        self,
        n: float
    ) -> float:
        return np.sqrt(1 - (1 - n) * (1 - n))