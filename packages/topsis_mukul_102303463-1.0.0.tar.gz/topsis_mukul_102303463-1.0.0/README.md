# Topsis-Mukul-10155792

## Description
This package implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.

## Installation
```bash
pip install Topsis-Mukul-10155792

topsis <InputDataFile> <Weights> <Impacts> <OutputFile>

topsis data.csv "1,1,1,2,1" "+,+,-,+,+" result.csv
