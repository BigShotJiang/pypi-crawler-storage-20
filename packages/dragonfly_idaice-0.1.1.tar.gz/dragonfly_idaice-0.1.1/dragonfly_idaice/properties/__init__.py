"""dragonfly-idaice properties."""
