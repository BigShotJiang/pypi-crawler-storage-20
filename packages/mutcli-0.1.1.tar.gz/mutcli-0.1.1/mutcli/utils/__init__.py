"""Utility functions for mut."""
