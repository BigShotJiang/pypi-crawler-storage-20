"""RunSentry Agent - Monitor and track scheduled job executions."""

__version__ = "1.0.0"

