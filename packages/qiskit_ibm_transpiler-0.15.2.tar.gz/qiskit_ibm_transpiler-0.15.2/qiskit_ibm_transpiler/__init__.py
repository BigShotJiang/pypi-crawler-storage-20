# -*- coding: utf-8 -*-

# (C) Copyright 2024 IBM. All Rights Reserved.
#
# This code is licensed under the Apache License, Version 2.0. You may
# obtain a copy of this license in the LICENSE.txt file in the root directory
# of this source tree or at http://www.apache.org/licenses/LICENSE-2.0.
#
# Any modifications or derivative works of this code must retain this
# copyright notice, and modified files need to carry a notice indicating
# that they have been altered from the originals.

import logging

from .ai import AIRouting
from .ai_passmanager import generate_ai_pass_manager
from .transpiler_service import TranspilerService
from .utils import create_random_linear_function, get_metrics
from .version import __version__

logging.basicConfig()
logging.getLogger(__name__).addHandler(logging.NullHandler())
