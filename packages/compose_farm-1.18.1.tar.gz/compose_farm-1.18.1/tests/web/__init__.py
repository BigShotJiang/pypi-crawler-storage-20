"""Web UI tests."""
