# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict, List

from alibabacloud_fc20230330 import models as main_models
from darabonba.model import DaraModel

class UpdateFunctionInput(DaraModel):
    def __init__(
        self,
        code: main_models.InputCodeLocation = None,
        cpu: float = None,
        custom_container_config: main_models.CustomContainerConfig = None,
        custom_dns: main_models.CustomDNS = None,
        custom_runtime_config: main_models.CustomRuntimeConfig = None,
        description: str = None,
        disable_inject_credentials: str = None,
        disable_ondemand: bool = None,
        disk_size: int = None,
        enable_long_living: bool = None,
        environment_variables: Dict[str, str] = None,
        gpu_config: main_models.GPUConfig = None,
        handler: str = None,
        idle_timeout: int = None,
        instance_concurrency: int = None,
        instance_isolation_mode: str = None,
        instance_lifecycle_config: main_models.InstanceLifecycleConfig = None,
        internet_access: bool = None,
        layers: List[str] = None,
        log_config: main_models.LogConfig = None,
        memory_size: int = None,
        nas_config: main_models.NASConfig = None,
        oss_mount_config: main_models.OSSMountConfig = None,
        polar_fs_config: main_models.PolarFsConfig = None,
        role: str = None,
        runtime: str = None,
        session_affinity: str = None,
        session_affinity_config: str = None,
        timeout: int = None,
        tracing_config: main_models.TracingConfig = None,
        vpc_config: main_models.VPCConfig = None,
    ):
        self.code = code
        self.cpu = cpu
        self.custom_container_config = custom_container_config
        self.custom_dns = custom_dns
        self.custom_runtime_config = custom_runtime_config
        self.description = description
        self.disable_inject_credentials = disable_inject_credentials
        self.disable_ondemand = disable_ondemand
        self.disk_size = disk_size
        self.enable_long_living = enable_long_living
        self.environment_variables = environment_variables
        self.gpu_config = gpu_config
        self.handler = handler
        self.idle_timeout = idle_timeout
        self.instance_concurrency = instance_concurrency
        self.instance_isolation_mode = instance_isolation_mode
        self.instance_lifecycle_config = instance_lifecycle_config
        self.internet_access = internet_access
        self.layers = layers
        self.log_config = log_config
        self.memory_size = memory_size
        self.nas_config = nas_config
        self.oss_mount_config = oss_mount_config
        self.polar_fs_config = polar_fs_config
        self.role = role
        self.runtime = runtime
        self.session_affinity = session_affinity
        self.session_affinity_config = session_affinity_config
        self.timeout = timeout
        self.tracing_config = tracing_config
        self.vpc_config = vpc_config

    def validate(self):
        if self.code:
            self.code.validate()
        if self.custom_container_config:
            self.custom_container_config.validate()
        if self.custom_dns:
            self.custom_dns.validate()
        if self.custom_runtime_config:
            self.custom_runtime_config.validate()
        if self.gpu_config:
            self.gpu_config.validate()
        if self.instance_lifecycle_config:
            self.instance_lifecycle_config.validate()
        if self.log_config:
            self.log_config.validate()
        if self.nas_config:
            self.nas_config.validate()
        if self.oss_mount_config:
            self.oss_mount_config.validate()
        if self.polar_fs_config:
            self.polar_fs_config.validate()
        if self.tracing_config:
            self.tracing_config.validate()
        if self.vpc_config:
            self.vpc_config.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code is not None:
            result['code'] = self.code.to_map()

        if self.cpu is not None:
            result['cpu'] = self.cpu

        if self.custom_container_config is not None:
            result['customContainerConfig'] = self.custom_container_config.to_map()

        if self.custom_dns is not None:
            result['customDNS'] = self.custom_dns.to_map()

        if self.custom_runtime_config is not None:
            result['customRuntimeConfig'] = self.custom_runtime_config.to_map()

        if self.description is not None:
            result['description'] = self.description

        if self.disable_inject_credentials is not None:
            result['disableInjectCredentials'] = self.disable_inject_credentials

        if self.disable_ondemand is not None:
            result['disableOndemand'] = self.disable_ondemand

        if self.disk_size is not None:
            result['diskSize'] = self.disk_size

        if self.enable_long_living is not None:
            result['enableLongLiving'] = self.enable_long_living

        if self.environment_variables is not None:
            result['environmentVariables'] = self.environment_variables

        if self.gpu_config is not None:
            result['gpuConfig'] = self.gpu_config.to_map()

        if self.handler is not None:
            result['handler'] = self.handler

        if self.idle_timeout is not None:
            result['idleTimeout'] = self.idle_timeout

        if self.instance_concurrency is not None:
            result['instanceConcurrency'] = self.instance_concurrency

        if self.instance_isolation_mode is not None:
            result['instanceIsolationMode'] = self.instance_isolation_mode

        if self.instance_lifecycle_config is not None:
            result['instanceLifecycleConfig'] = self.instance_lifecycle_config.to_map()

        if self.internet_access is not None:
            result['internetAccess'] = self.internet_access

        if self.layers is not None:
            result['layers'] = self.layers

        if self.log_config is not None:
            result['logConfig'] = self.log_config.to_map()

        if self.memory_size is not None:
            result['memorySize'] = self.memory_size

        if self.nas_config is not None:
            result['nasConfig'] = self.nas_config.to_map()

        if self.oss_mount_config is not None:
            result['ossMountConfig'] = self.oss_mount_config.to_map()

        if self.polar_fs_config is not None:
            result['polarFsConfig'] = self.polar_fs_config.to_map()

        if self.role is not None:
            result['role'] = self.role

        if self.runtime is not None:
            result['runtime'] = self.runtime

        if self.session_affinity is not None:
            result['sessionAffinity'] = self.session_affinity

        if self.session_affinity_config is not None:
            result['sessionAffinityConfig'] = self.session_affinity_config

        if self.timeout is not None:
            result['timeout'] = self.timeout

        if self.tracing_config is not None:
            result['tracingConfig'] = self.tracing_config.to_map()

        if self.vpc_config is not None:
            result['vpcConfig'] = self.vpc_config.to_map()

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('code') is not None:
            temp_model = main_models.InputCodeLocation()
            self.code = temp_model.from_map(m.get('code'))

        if m.get('cpu') is not None:
            self.cpu = m.get('cpu')

        if m.get('customContainerConfig') is not None:
            temp_model = main_models.CustomContainerConfig()
            self.custom_container_config = temp_model.from_map(m.get('customContainerConfig'))

        if m.get('customDNS') is not None:
            temp_model = main_models.CustomDNS()
            self.custom_dns = temp_model.from_map(m.get('customDNS'))

        if m.get('customRuntimeConfig') is not None:
            temp_model = main_models.CustomRuntimeConfig()
            self.custom_runtime_config = temp_model.from_map(m.get('customRuntimeConfig'))

        if m.get('description') is not None:
            self.description = m.get('description')

        if m.get('disableInjectCredentials') is not None:
            self.disable_inject_credentials = m.get('disableInjectCredentials')

        if m.get('disableOndemand') is not None:
            self.disable_ondemand = m.get('disableOndemand')

        if m.get('diskSize') is not None:
            self.disk_size = m.get('diskSize')

        if m.get('enableLongLiving') is not None:
            self.enable_long_living = m.get('enableLongLiving')

        if m.get('environmentVariables') is not None:
            self.environment_variables = m.get('environmentVariables')

        if m.get('gpuConfig') is not None:
            temp_model = main_models.GPUConfig()
            self.gpu_config = temp_model.from_map(m.get('gpuConfig'))

        if m.get('handler') is not None:
            self.handler = m.get('handler')

        if m.get('idleTimeout') is not None:
            self.idle_timeout = m.get('idleTimeout')

        if m.get('instanceConcurrency') is not None:
            self.instance_concurrency = m.get('instanceConcurrency')

        if m.get('instanceIsolationMode') is not None:
            self.instance_isolation_mode = m.get('instanceIsolationMode')

        if m.get('instanceLifecycleConfig') is not None:
            temp_model = main_models.InstanceLifecycleConfig()
            self.instance_lifecycle_config = temp_model.from_map(m.get('instanceLifecycleConfig'))

        if m.get('internetAccess') is not None:
            self.internet_access = m.get('internetAccess')

        if m.get('layers') is not None:
            self.layers = m.get('layers')

        if m.get('logConfig') is not None:
            temp_model = main_models.LogConfig()
            self.log_config = temp_model.from_map(m.get('logConfig'))

        if m.get('memorySize') is not None:
            self.memory_size = m.get('memorySize')

        if m.get('nasConfig') is not None:
            temp_model = main_models.NASConfig()
            self.nas_config = temp_model.from_map(m.get('nasConfig'))

        if m.get('ossMountConfig') is not None:
            temp_model = main_models.OSSMountConfig()
            self.oss_mount_config = temp_model.from_map(m.get('ossMountConfig'))

        if m.get('polarFsConfig') is not None:
            temp_model = main_models.PolarFsConfig()
            self.polar_fs_config = temp_model.from_map(m.get('polarFsConfig'))

        if m.get('role') is not None:
            self.role = m.get('role')

        if m.get('runtime') is not None:
            self.runtime = m.get('runtime')

        if m.get('sessionAffinity') is not None:
            self.session_affinity = m.get('sessionAffinity')

        if m.get('sessionAffinityConfig') is not None:
            self.session_affinity_config = m.get('sessionAffinityConfig')

        if m.get('timeout') is not None:
            self.timeout = m.get('timeout')

        if m.get('tracingConfig') is not None:
            temp_model = main_models.TracingConfig()
            self.tracing_config = temp_model.from_map(m.get('tracingConfig'))

        if m.get('vpcConfig') is not None:
            temp_model = main_models.VPCConfig()
            self.vpc_config = temp_model.from_map(m.get('vpcConfig'))

        return self

