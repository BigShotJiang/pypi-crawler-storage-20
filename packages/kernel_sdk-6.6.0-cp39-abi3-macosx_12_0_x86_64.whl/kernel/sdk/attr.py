from typing import Dict, Any


class AttrDict(Dict[str, Any]):
    """A dictionary with its keys as accessible attributes."""

    def __setattr__(self, name: str, value: Any):
        self[name] = value

    def __getattr__(self, name: str):
        if name in self:
            return self[name]
        object.__getattribute__(self, name)


class ImmutableAttrDict(AttrDict):
    """A dictionary with its keys as accessible attributes.
    After setting a key in this dict it is no longer mutable.
    """

    def __setitem__(self, key: str, value: Any):
        if key in self:
            raise KeyError(f"{key} was already set")
        super().__setitem__(key, value)
