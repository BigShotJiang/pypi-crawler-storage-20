import enum
import inspect
import types

from threading import Lock

from .attr import ImmutableAttrDict


env = ImmutableAttrDict()
env.cfg = ImmutableAttrDict()  # Default name for configuration files
env.tlm = ImmutableAttrDict()  # Default name for telemetry sockets
env.cmd = ImmutableAttrDict()  # Default name for command clients
