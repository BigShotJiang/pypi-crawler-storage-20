"""
defines consts for task urns

Emitted as part of experiment block
"""
from enum import Enum


class TaskRegistry(Enum):
    ABLINK01 = "urn:kernel.com/task/flow_neuro_ABLINK/01"
    ADD01 = "urn:kernel.com/task/flow_neuro_ADD/01"
    BHOLD01 = "urn:kernel.com/task/flow_neuro_BHOLD/01"
    DRIVE01 = "urn:kernel.com/task/flow_neuro_DRIVE/01"
    FLASH01 = "urn:kernel.com/task/flow_neuro_FLASH/01"
    FOCUS01 = "urn:kernel.com/task/flow_neuro_FOCUS/01"
    FT02 = "urn:kernel.com/task/flow_neuro_FT/02"
    GNG01 = "urn:kernel.com/task/flow_neuro_GNG/01"
    KDT01 = "urn:kernel.com/task/flow_neuro_KDT/01"
    MEDIT01 = "urn:kernel.com/task/flow_neuro_MEDIT/01"
    NBACK02 = "urn:kernel.com/task/flow_neuro_NBACK/02"
    NBACKA02 = "urn:kernel.com/task/flow_neuro_NBACKA/02"
    NFB01 = "urn:kernel.com/task/flow_neuro_NFB/01"
    SAND01 = "urn:kernel.com/task/flow_neuro_SAND/01"
    SART01 = "urn:kernel.com/task/flow_neuro_SART/01"
    STORY01 = "urn:kernel.com/task/flow_neuro_STORY/01"
    STROOP01 = "urn:kernel.com/task/flow_neuro_STROOP/01"
    WDOS01 = "urn:kernel.com/task/flow_neuro_WDOS/01"
    WCST03 = "urn:kernel.com/task/flow_neuro_WCST/03"
