import enum
import functools  # Add this import for the decorator
import json
import logging
import math
import platform
import struct
import sys
import threading
import time
import traceback
from collections import defaultdict, namedtuple
from concurrent.futures import CancelledError, Future, ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeout
from concurrent.futures import as_completed
from pathlib import Path
from queue import Empty, Queue
from threading import Event as ThreadEvent
from threading import Thread
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, TypeVar, Union, cast
from urllib.parse import urlparse
from uuid import UUID, uuid4

import numpy as np
import psutil
import requests

from ._sdk import (
    Connection,
    DanubeSerialNumbers,
    MetadataSubscription,
    Request,
    Response,
    Subscription,
    connect_websocket,
    deserialize_available_modules_from_metadata,
    request_message,
    text_message,
)
from .auth import encode_from_user
from .prelude import *

VirtualStore = namedtuple("VirtualStore", ["urn", "rate_us"])
DEFAULT_PACKET_RATE = 10000  # in us
DEFAULT_ALIGNMENT_DISTANCE = 30  # in us
NUM_WORKERS = psutil.cpu_count(logical=True)
log = logging.getLogger(__name__)


class StartTimeoutError(Exception):
    def __init__(self, message: str):
        self.message = message
        super().__init__(self.message)


class ThreadPoolExecutorTrace(ThreadPoolExecutor):
    """
    Subclass fo ThreadPoolExecutor that allows for tracebacks
    """

    def submit(self, fn, *args, **kwargs):
        """Submits using the wrapped function to catch traceback information"""
        return super().submit(self._function_wrapper, fn, *args, **kwargs)

    def _function_wrapper(self, fn, *args, **kwargs):
        """Function wrapper that will raise with traceback"""
        try:
            return fn(*args, **kwargs)
        except Exception:
            raise sys.exc_info()[0](traceback.format_exc())


class SocketState(enum.Enum):
    DISCONNECTED = 0
    CONNECTING = 1
    CONNECTED = 2
    STOPPING = 3
    SHUTDOWN = 4


class Event:
    def __init__(
        self,
        device,
        field_urns,
        rate=DEFAULT_PACKET_RATE,
        pre_subscribe=False,
    ):
        self.device = device
        self.fields = field_urns
        self.rate = rate
        self.pre_subscribe = pre_subscribe

    def __str__(self):
        return f"Event: device - {self.device}, rate - {self.rate}, pre_subscribe - {self.pre_subscribe}"


class EventFuture:
    def __init__(
        self,
        urn: str,
        callback: Callable,
        call_cancel: Callable,
        once=False,
        block_on_unsubscribe=False,
    ):
        self.urn = urn
        self.callback = callback
        self._cancel = ThreadEvent()
        self._call_cancel = call_cancel
        self._once = once
        self._block_on_unsubscribe = block_on_unsubscribe

    def __eq__(self, other):
        return other.urn == self.urn and other.callback == self.callback

    def __hash__(self):
        return hash((self.urn, self.callback))

    def __repr__(self):
        return f"EventFuture({self.urn}, {self.callback})"

    def __call__(self, data):
        if self._cancel.is_set():
            return
        self.callback(data)
        if self._once:
            self.cancel()

    @property
    def is_set(self) -> bool:
        return self._cancel.is_set()

    def wait_until_cancelled(self, timeout: Optional[float] = None):
        self._cancel.wait(timeout)

    def cancel_immediate(self):
        self._cancel.set()

    def cancel(self):
        if self._cancel.is_set():
            return
        self.cancel_immediate()
        self._call_cancel(self)


class Disconnected(Exception):
    """Raised when the client attempts to interact with a disconnected server."""

    def __init__(
        self, message="Socket is not connected. Please check socket connection"
    ):
        super().__init__(message)


class FlowDisconnected(Exception):
    """Raised when the client attempts to interact with a disconnected Flow device."""

    def __init__(
        self,
        message="Flow device is not connected. Please check the physical connection.",
    ):
        super().__init__(message)


class _SdkClient:
    TIMESTAMP_URN = "urn:kernel.com/field/timestamp"
    CONNECT_EVENT = "urn:kernel.com/connected"
    DISCONNECT_EVENT = "urn:kernel.com/disconnected"
    STOP_EVENT = "urn:kernel.com/stop"
    DEVICE_UPDATED_EVENT = "urn:kernel.com/event/device_update"
    DEVICE_ERROR_UPDATING_EVENT = "urn:kernel.com/event/device_error"
    DEVICE_PROGRESS_EVENT = "urn:kernel.com/event/device_progress"
    UPLOAD_PROGRESS_EVENT = "urn:kernel.com/event/upload_progress"
    RECEIVE_RATE_EVENT = "urn:kernel.com/event/receive_rate"
    FINISHED_EVENT = "urn:kernel.com/event/finished"
    SERVER_CHAT_EVENT = "urn:kernel.com/event/chat"
    NEUROME_TARGET = "NeuromeProduction"
    NEUROME_HOSTNAME = "api.kernel.com"

    @staticmethod
    def as_urn(might_be_urn: str, urn_converter: Callable):
        """Convert to a URN with urn_converter if the string is not a URN."""
        if might_be_urn.startswith("urn:"):
            return might_be_urn
        return urn_converter(might_be_urn)

    def __init__(self, ws_addr: str, token=None, secret=None, autostart=False):

        parse_ws_addr = urlparse(ws_addr)
        if secret is not None:
            assert token is None, "Both token and secret cannot be set"
            token = encode_from_user(secret)

        auth = f"?authorization={token}" if token else ""
        if parse_ws_addr.netloc:
            self.ws_addr = f"ws://{parse_ws_addr.netloc}/{auth}"
        else:
            self.ws_addr = f"ws://{ws_addr}/{auth}"

        self._state: SocketState = SocketState.DISCONNECTED

        self._control_queue = Queue()
        self._response_queue = Queue()
        self._request_queue = Queue()
        self._module_queue = Queue()
        self._data_queue = Queue()
        self._metadata_queue = Queue()

        self.metadata_cache = {}

        self._future_queue = Queue()

        self._control_thread = Thread(target=self._read_control_responses, daemon=True)
        self._response_thread = Thread(target=self._read_responses, daemon=True)
        self._module_thread = Thread(target=self._read_modules, daemon=True)
        self._data_thread = Thread(target=self._read_data, daemon=True)
        self._metadata_thread = Thread(target=self._read_metadata, daemon=True)
        self._connect_thread = Thread(target=self._reconnector, daemon=True)
        self._future_check = Thread(target=self._check_futures, daemon=True)
        self._pool = ThreadPoolExecutorTrace(max_workers=math.ceil(NUM_WORKERS / 2))

        self._devices = set()
        self._responses = {}
        self._events = defaultdict(set)
        self._static_events = set()

        self._stop_event = ThreadEvent()

        self._subs = set()
        self._virtuals = defaultdict(set)

        self._fields_by_urn = {}
        self._field_urns = set()

        self._req_id = 0

        self._control_thread.start()
        self._response_thread.start()
        self._module_thread.start()
        self._data_thread.start()
        self._metadata_thread.start()
        self._future_check.start()

        if autostart:
            self.start()

    def __del__(self):
        self.stop()

    @property
    def state(self) -> SocketState:
        """Current state of the socket."""
        return self._state

    @property
    def fields_by_urn(self) -> Dict:
        """Return dictionary of all seen URNs by this client."""
        return self._fields_by_urn.copy()

    @property
    def fields(self) -> Set[str]:
        """Return set of all urns seen by this client."""
        return self._field_urns.copy()

    def when_connected(self, callback: Callable):
        """Call this function when a connection is made.

        Arguments:
            callback: Function to call when connected.
        """
        self._do_register_future(self.CONNECT_EVENT, callback, static=True)

    def when_disconnected(self, callback: Callable):
        """Call this function when a disconnection happens.

        Arguments:
            callback: Function to call when disconnected.
        """
        self._do_register_future(self.DISCONNECT_EVENT, callback, static=True)

    def when_device_updated(self, callback: Callable):
        """Call this function when the control socket reports a device is updated

        Arguments:
            callback: Function to call when device updated.
        """
        self._do_register_future(self.DEVICE_UPDATED_EVENT, callback, static=True)

    def when_device_errors(self, callback: Callable):
        """Call this function when the control socket reports a device errors

        Arguments:
            callback: Function to call when device errors.
        """
        self._do_register_future(
            self.DEVICE_ERROR_UPDATING_EVENT, callback, static=True
        )

    def when_device_progresses(self, callback: Callable):
        """Call this function when the control socket reports a device progresses.

        Arguments:
            callback: Function to call when device progresses.
        """
        self._do_register_future(self.DEVICE_PROGRESS_EVENT, callback, static=True)

    def when_upload_progresses(self, callback: Callable):
        """Call this function when the control socket reports an upload progresses.

        Arguments:
            callback: Function to call when upload progresses.
        """
        self._do_register_future(self.UPLOAD_PROGRESS_EVENT, callback, static=True)

    def when_rate_received(self, callback: Callable):
        """Call this function when the control socket reports rate event.

        Arguments:
            callback: Function to call when rate event received.
        """
        self._do_register_future(self.RECEIVE_RATE_EVENT, callback, static=True)

    def when_upload_finished(self, callback: Callable):
        """Call this function when the control socket reports upload finished.

        Arguments:
            callback: Function to call when rate event received.
        """
        self._do_register_future(self.FINISHED_EVENT, callback, static=True)

    def when_stopped(self, callback: Callable):
        """Call this function when the socket is stopping and will cease all processing.

        Arguments:
            callback: Function to call when stopped.
        """
        self._do_register_future(self.STOP_EVENT, callback, static=True)

    def _generic_event_handler(self, event_key):
        event_list = list(self._events.get(event_key, []))
        for event in event_list:
            self._future_queue.put(self._pool.submit(event, event_key))

    def _reconnector(self):
        while True:
            if self._state == SocketState.DISCONNECTED:
                self._state = SocketState.CONNECTING
                self._response_queue.queue.clear()
                self._control_queue.queue.clear()
                self._request_queue.queue.clear()
                self._module_queue.queue.clear()
                self._data_queue.queue.clear()
                self._metadata_queue.queue.clear()
                self._subs.clear()
                for ev in list(self._events.keys()):
                    if ev not in self._static_events:
                        del self._events[ev]

                conn = Connection(
                    self.ws_addr,
                    self._request_queue,
                    self._response_queue,
                    self._control_queue,
                    self._module_queue,
                    self._data_queue,
                    self._metadata_queue,
                )
                connect_websocket(conn)
            time.sleep(1)

    def _on_disconnect(self):
        prev_state = self._state
        self._state = SocketState.DISCONNECTED
        self._request_queue.put(None)
        if prev_state == SocketState.CONNECTED:
            self._generic_event_handler(self.DISCONNECT_EVENT)

    def _on_connect(self):
        self._state = SocketState.CONNECTED
        self._generic_event_handler(self.CONNECT_EVENT)

    def _on_stopping(self):
        self._state = SocketState.STOPPING
        self._generic_event_handler(self.STOP_EVENT)
        # Cancel all events except the stop event
        event_list = list(self._events.items())
        for event_name, egroup in event_list:
            if event_name == self.STOP_EVENT:
                continue
            for event in list(egroup):
                event.cancel()
        log.info("Stopped SdkClient.")

    def start(self, block: bool = True, timeout: float = 10):
        self._connect_thread.start()
        start_time = time.time()
        if block:
            while self._state != SocketState.CONNECTED:
                if time.time() - start_time > timeout:
                    raise StartTimeoutError(
                        "Failed to start the telemetry socket within the allowed timeout."
                    )
                time.sleep(0.1)

    def stop(self):
        self._state = SocketState.STOPPING
        self._send_stop()
        self._on_stopping()
        self._response_thread.join()
        self._module_thread.join()
        self._data_thread.join()
        self._state = SocketState.SHUTDOWN

    def _send_stop(self):
        self._stop_event.set()
        self._request_queue.put(None)

    def _read_control_responses(self):
        while not self._stop_event.is_set():
            resp = self._control_queue.get()
            name = resp.name

            if name == "UpdateState":
                handler = self.DEVICE_UPDATED_EVENT
            elif name == "UpdateStateError":
                handler = self.DEVICE_ERROR_UPDATING_EVENT
            elif name == "ProgressUpdate":
                handler = self.DEVICE_PROGRESS_EVENT
            elif name == "ReceiveRate":
                handler = self.RECEIVE_RATE_EVENT
            elif name == "SessionFinished":
                handler = self.FINISHED_EVENT
            else:
                print("Message received from control but not understood:", name)
                continue

            events = self._events.get(handler)
            if events:
                for fun in events:
                    self._pool.submit(fun, args=(resp,))

    def _read_responses(self):
        while not self._stop_event.is_set():
            try:
                resp = self._response_queue.get(timeout=1)
            except Empty:
                continue
            if resp is None:
                if self._stop_event.is_set():
                    break
                self._on_disconnect()
                continue

            if isinstance(resp, str):
                event_list = self._events.get(self.SERVER_CHAT_EVENT, [])
                for event in event_list:
                    self._future_queue.put(self._pool.submit(event, resp))
            else:
                request_id = bytes(resp.request_id)
                if not request_id:
                    self._on_connect()
                    continue

                try:
                    self._responses[request_id].set_result(resp)
                    del self._responses[request_id]
                except KeyError:
                    print(
                        f"Received unknown response id {request_id} (waiting for: {self._responses.keys()})"
                    )

    def _read_modules(self):
        while not self._stop_event.is_set():
            try:
                module = self._module_queue.get(timeout=1)
            except Empty:
                continue
            if module is None:
                if self._stop_event.is_set():
                    break
                self._on_disconnect()
                continue
            self._fields_by_urn[module.urn] = set(field.urn for field in module.fields)
            self._field_urns.update(field.urn for field in module.fields)

            event_list = []
            event_list.extend(self._events.get(module.device_urn, []))

            for update in event_list:
                self._future_queue.put(self._pool.submit(update, module))

    def _read_data(self):
        while not self._stop_event.is_set():
            try:
                packet = self._data_queue.get(timeout=1)
            except Empty:
                continue
            if packet is None:
                if self._stop_event.is_set():
                    break
                self._on_disconnect()
                continue

            urn, data = packet

            event_list = []
            event_list.extend(self._events.get(urn, []))

            for update in event_list:
                self._future_queue.put(self._pool.submit(update, data))

    def _read_metadata(self):
        while not self._stop_event.is_set():
            try:
                metadata = self._metadata_queue.get(timeout=1)
            except Empty:
                continue
            if metadata is None:
                if self._stop_event.is_set():
                    break
                self._on_disconnect()
                continue
            self.metadata_cache[metadata.urn] = metadata

            event_list = []
            event_list.extend(self._events.get(metadata.urn, []))

            for update in event_list:
                self._future_queue.put(self._pool.submit(update, metadata))

    def _check_futures(self):
        while not self._stop_event.is_set():
            futures = []
            while True:
                try:
                    futures.append(self._future_queue.get_nowait())
                except Empty:
                    break
            for future in as_completed(futures):
                try:
                    exc = future.exception()
                    if exc is not None:
                        log.error("Future raised an exception: %s", exc)
                except CancelledError:
                    pass
            time.sleep(0.1)

    def _new_request(self, request_id: bytes):
        if self.state != SocketState.CONNECTED:
            raise Disconnected()

        assert request_id not in self._responses
        future = Future()
        self._responses[request_id] = future
        return future

    def new_event(
        self,
        event: Event,
        callback: Callable,
        force_event: bool = False,
        once: bool = False,
    ) -> EventFuture:
        """Set a new event to virtually subscribe for callbacks.

        Arguments:
            event: Event to create callback subscription for.
            callback: Callable taking a dictionary of field urns to numpy arrays.
            force_event: a bool determining if we will force the virtual subscribe.
            once: a bool determining if we cancel the event after 1 trigger
        """
        event_fields_set = set(event.fields)
        for urn, field_group in self._fields_by_urn.items():
            if event_fields_set.issubset(field_group) and not force_event:
                virtuals = self._virtuals.get(urn, [])
                for virtual in virtuals:
                    if virtual.rate_us == event.rate:
                        break
                else:
                    continue
                break
        else:
            urn = self.virtual_subscribe(event)

        return self._register_future(urn, callback, once)

    def _register_future(
        self, urn, callback, once: bool = False, block_on_unsubscribe: bool = False
    ) -> EventFuture:
        if self.state != SocketState.CONNECTED:
            raise Disconnected()
        return self._do_register_future(
            urn, callback, once, block_on_unsubscribe=block_on_unsubscribe
        )

    def _do_register_future(
        self,
        urn,
        callback,
        once: bool = False,
        static: bool = False,
        block_on_unsubscribe: bool = False,
    ) -> EventFuture:
        future = EventFuture(
            urn,
            callback,
            self._cancel_future,
            once=once,
            block_on_unsubscribe=block_on_unsubscribe,
        )
        self._events[future.urn].add(future)
        if static:
            self._static_events.add(future.urn)

        return future

    def _cancel_future(self, future):
        event_set = list(self._events.get(future.urn, set()))
        try:
            event_set.remove(future)
        except KeyError:
            pass

        if len(event_set) == 0:
            if self.state == SocketState.CONNECTED:
                self.unsubscribe(future.urn, block=future._block_on_unsubscribe)
            try:
                del self._events[future.urn]
            except KeyError:
                pass

    def _next_id(self):
        self._req_id += 1
        return bytes(struct.pack("!I", self._req_id))

    def subscribe(
        self,
        module: str,
        callback: Callable,
        rate: int = DEFAULT_PACKET_RATE,
        once=False,
        pre_subscribe: bool = False,
        force_subscribe: bool = False,
        block_on_unsubscribe: bool = False,
    ) -> EventFuture:
        """Subscribe to all the data from a given module

        Arguments:
            module: URN or name of the module to be subscribed to.
            callback: Function taking one argument (the data dictionary of the subscriptions) to be
                      called on each new receipt of data.
            rate: Rate to subscribe for updates at. Optional (default: DEFAULT_PACKET_RATE).
            once: Send only one update and then unsubscribe. Optional (default: False).
            pre_subscribe: Subscribe prior to a module being seen, will not fail if the module does
                           not exist yet. Optional (default: False).
            force_subscribe: flag determining if we will force the subscribe to occur.
        """
        urn = self.as_urn(module, lambda module: f"urn:kernel.com/module/{module}")
        event = self._register_future(
            urn, callback, once=once, block_on_unsubscribe=block_on_unsubscribe
        )

        if urn in self._subs and not force_subscribe:
            return event

        sub = Subscription(urn, rate, [], pre_subscribe)
        req = Request(self._next_id(), "Subscribe", None, sub, None)
        resp: Response = self._send_request(req)
        self._subs.add(resp.urn)
        return event

    def virtual_subscribe(self, event: Event) -> str:
        """Subscribe to a virtual module created from the urns in Event.

        Arguments:
            event: Event descriptor to subscribe with.
        """
        sub = Subscription(
            f"urn:kernel.com/module/{event.device}/virtual",
            event.rate,
            event.fields,
            event.pre_subscribe,
        )
        req = Request(self._next_id(), "VirtualSubscribe", None, sub, None)
        result: Response = self._send_request(req, block=True)
        self._virtuals[result.urn].add(VirtualStore(result.urn, event.rate))
        return result.urn

    def metadata_subscribe(
        self, modules: List[str], callback: Callable, once=False
    ) -> List[EventFuture]:
        """List of all metadata modules the client wishes to subscribe to attached to this callback.

        Arguments:
            modules: ModuleUrns to subscribe to
            callback: Callback to attach subscription to
            once: Call callback once and then remove event
        """
        futures = []
        for urn in modules:
            event = self._register_future(urn, callback, once=once)

            if urn in self._subs:
                futures.append(event)
                continue

            sub = MetadataSubscription(urn)
            self._subs.add(urn)
            req = Request(self._next_id(), "MetadataSubscribe", None, None, sub)
            self._send_request(req)
            futures.append(event)
        return futures

    def list_subscriptions(self) -> Dict[str, List[Subscription]]:
        """List subscriptions for this client known to the server."""
        req = Request(self._next_id(), "ListSubscriptions", None, None, None)
        result: Response = self._send_request(req, block=True)
        return result.subs

    def list_devices(self) -> List[str]:
        """List subscriptions for this client known to the server."""
        req = Request(self._next_id(), "ListDevices", None, None)
        result: Response = self._send_request(req, block=True)
        return [key for key in result.subs]

    def list_metadata(self) -> List[str]:
        """List metadata available on this server."""
        req = Request(self._next_id(), "ListMetadata", None, None, None)
        result: Response = self._send_request(req, block=True)
        sub = []
        for v in result.subs.values():
            sub.extend(v)
        if sub:
            return sub[0].field_urns
        else:
            return []

    def unsubscribe(self, module: str, block: bool = True):
        """Unsubscribe from a module. Removes all events from the virtual modules.

        Arguments:
            module: Module URN or name to unsubscribe from (can be a virtual module).
        """
        urn = self.as_urn(module, lambda module: f"urn:kernel.com/module/{module}")
        if urn in self._subs:

            def cleanup():
                self._subs.remove(urn)

        elif urn in self._virtuals:

            def cleanup():
                for future in self._events[urn]:
                    future.cancel_immediate()
                try:
                    del self._virtuals[urn]
                except KeyError:
                    pass

        else:
            return
        req = Request(self._next_id(), "Unsubscribe", urn, None, None)
        self._send_request(req, block=block)
        cleanup()

    def _send_request(
        self, req: Request, block: bool = True, timeout: float = 300.0
    ) -> Union[Future, Response]:
        if self.state != SocketState.CONNECTED:
            raise Disconnected()
        future = self._new_request(bytes(req.request_id))
        self._request_queue.put(request_message(req))
        return self._wait_for_response(future, block, timeout)

    @staticmethod
    def _wait_for_response(
        future, block: bool, timeout: float, uuid: Optional[UUID] = None
    ) -> Union[Future, Response]:
        if not future.done() and not future.set_running_or_notify_cancel():
            # future was cancelled
            raise CommandFailure("Future cancelled before response received")
        if block:
            try:
                result = future.result(timeout)
            except FutureTimeout:
                if uuid:
                    print(f"Timed out waiting for {uuid}")
                raise TimeoutError
            if not result.success:
                raise CommandFailure(result.failure_reason)
            return result
        return future

    def _send_command(
        self,
        command: Dict,
        block: bool = True,
        timeout: float = 300.0,
    ):
        """Command a connected device

        Send a command to flow, optionally blocking to receive the device response

        Parameters:
            command: dict - the command to send. see below for list of commands
            block: bool (default: True) - if this command should block this thread waiting for the device response
            timeout: float (default: 300.0) - time in seconds to block (if block is True) on device response before timing out (raises TimeoutError)
        Raises:
            TimeoutError - if block is True and a device response has not been received within `timeout` seconds
            CommandFailure - if the receiving Future was cancelled before the response was received, or if the command failed on the device

        Commands:
            {"Initialize":{}}

            {"GetSerialNumbers":{}}

            {"Tune":{}}

            {"StartDataGathering":{}}

            {"StopDataGathering":{}}

        example:
            >>> from kernel.sdk import SdkClient
            >>> secret = "" # paste your JWT secret from the portal UI
            >>> client = SdkClient("ws://localhost:13254",secret=secret)
            >>> client.start()
            >>> serial_numbers = client.send_command({"GetSerialNumbers":{}})
            >>> print(serial_numbers)
            >>> client.send_command({"Initialize": {"target": client.NEUROME_TARGET}})
            >>> client.send_command({"Tune": {}})
            >>> client.send_command({"StartDataGathering":{}})
            >>> # lasers are on now
            >>> client.send_command({"StopDataGathering":{}})
            >>> # lasers are off now
        """
        uuid = uuid4()
        future = self._new_request(uuid.bytes)

        cmd = {"id": str(uuid), "command": {"Danube": command}}

        self._request_queue.put(text_message(json.dumps(cmd)))
        return self._wait_for_response(future, block, timeout, uuid)

    def _connect_out(self, ws_url: str, ws_token: str):
        uuid = uuid4()
        future = self._new_request(uuid.bytes)
        self._request_queue.put(
            text_message(
                json.dumps(
                    {
                        "id": str(uuid),
                        "control": {
                            "ConnectOutNeurome": {
                                "url": ws_url,
                                "token": ws_token,
                                "target": self.NEUROME_TARGET,
                                "handshake_domain": self.NEUROME_HOSTNAME,
                            }
                        },
                    }
                )
            )
        )
        return self._wait_for_response(future, True, 20, uuid)


class MomentNumber(enum.IntEnum):
    Zeroth = 0
    First = 1
    Second = 2


class Wavelength(enum.Enum):
    Red = "Red"
    IR = "IR"


class UsbState(enum.Enum):
    Connected = "CONNECTED"
    Disconnected = "DISCONNECTED"


class FlowSystemState(enum.Enum):
    Booting = "BOOTING"
    Ready = "READY"
    Sleeping = "SLEEPING"
    DataGathering = "DATA_GATHERING"
    Faulted = "FAULTED"


class FlowNotBooted(Exception):
    """Raised when the Flow device is not booted yet."""

    def __init__(
        self,
        message="Flow device is still booting. Please wait after powering on Flow.",
    ):
        super().__init__(message)


class FlowFaulted(Exception):
    """Raised when the Flow device is in a faulted state."""

    def __init__(
        self,
        message="Flow device is in a faulted state. Please power cycle Flow and try again.",
    ):
        super().__init__(message)


# Add these types for the decorator
T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])


def requires_flow_connected(method: F) -> F:
    """Decorator to check if Flow is connected before executing a method"""

    @functools.wraps(method)
    def wrapper(self: "SdkClient", *args: Any, **kwargs: Any) -> Any:
        with self._usb_state_lock:
            if self._usb_state != UsbState.Connected:
                raise FlowDisconnected()
        return method(self, *args, **kwargs)

    return cast(F, wrapper)


def requires_flow_booted(method: F) -> F:
    """Decorator to check if Flow is booted before executing a method"""

    @functools.wraps(method)
    def wrapper(self: "SdkClient", *args: Any, **kwargs: Any) -> Any:
        with self._flow_system_state_lock:
            if self._flow_system_state == FlowSystemState.Faulted:
                raise FlowFaulted()
            if self._flow_system_state == FlowSystemState.Booting:
                raise FlowNotBooted()
        return method(self, *args, **kwargs)

    return cast(F, wrapper)


def check_faulted_on_command_failure(method: F) -> F:
    """Decorator to check if Flow is in a faulted state after a CommandFailure"""

    @functools.wraps(method)
    def wrapper(self: "SdkClient", *args: Any, **kwargs: Any):
        try:
            return method(self, *args, **kwargs)
        except CommandFailure as e:
            # Wait a moment for state to update
            time.sleep(1)
            # Check if flow is in a faulted state
            with self._flow_system_state_lock:
                if self._flow_system_state == FlowSystemState.Faulted:
                    raise FlowFaulted() from e
            # Re-raise the original exception if not faulted
            raise

    return cast(F, wrapper)


class SdkClient:

    KORTEX_CONFIG_PATH = (
        Path("C:\\Program Files\\Kortex\\kortex.json")
        if platform.system() == "Windows"
        else "/etc/kernel.com/kortex.json"
    )

    MOMENTS_MODULE_URN_TEMPLATE = (
        "urn:kernel.com/module/flow/moments_{moment_id}_{wavelength}"
    )
    MOMENTS_FIELD_URN_TEMPLATE = (
        "urn:kernel.com/field/flow/moments_{moment_id}_{wavelength}/moment"
    )
    RETAINED_CHANNELS_MODULE_URN = "urn:kernel.com/module/flow/retained_channels"
    RETAINED_CHANNELS_FIELD_URN = (
        "urn:kernel.com/field/flow/retained_channels/retained_channels_percentage"
    )
    EEG_MODULE_URN = "urn:kernel.com/module/flow/eeg"
    EEG_VOLTAGE_FIELD_URN = "urn:kernel.com/field/flow/eeg/voltage"
    EEG_IMPEDANCE_FIELD_URN = "urn:kernel.com/field/flow/eeg/impedance"

    TASK_MODULE_URN = "urn:kernel.com/module/task/generic"
    TASK_EVENT_FIELD_URN = "urn:kernel.com/field/task/generic/event"
    TASK_VALUE_FIELD_URN = "urn:kernel.com/field/task/generic/value"

    DANUBE_SOURCE_METADATA = "urn:kernel.com/module/metadata/danube_source_metadata"
    USB_STATE_METADATA = "urn:kernel.com/module/metadata/usb_status_danube"
    FLOW_SYSTEM_STATE_METADATA = "urn:kernel.com/module/metadata/danube_system_state"
    MAX_MODULES = 48
    _BOOT_TIMEOUT = 100  # in seconds
    _BOOT_CHECK_INTERVAL = 5  # in seconds

    def __init__(self, autostart: bool = True):
        with open(SdkClient.KORTEX_CONFIG_PATH, "r") as f:
            config = json.load(f)
            secret = config["api"].get("jwt_secret")
            ws_url = f'ws://{config["api"].get("websocket_addr")}'
        self._sdk = _SdkClient(ws_url, secret=secret)

        # Add separate locks for each type of metadata
        self._usb_state_lock = threading.RLock()
        self._flow_system_state_lock = threading.RLock()
        self._usb_state = None
        self._flow_system_state = None

        if autostart:
            self.start(timeout=1)

    def _on_usb_state_metadata(self, metadata: Response):
        with self._usb_state_lock:
            self._usb_state = UsbState(json.loads(bytes(metadata.msg))["state"])

    def _on_flow_system_state_metadata(self, metadata: Response):
        with self._flow_system_state_lock:
            # metadata.msg may be None or a list of bytes
            new_state = json.loads(bytes(metadata.msg))
            self._flow_system_state = (
                None if new_state is None else FlowSystemState(new_state)
            )

    # Convert getters to properties for cleaner access
    @property
    def usb_state(self) -> Optional[UsbState]:
        with self._usb_state_lock:
            return self._usb_state

    @property
    def flow_system_state(self) -> Optional[FlowSystemState]:
        with self._flow_system_state_lock:
            return self._flow_system_state

    def start(self, block: bool = True, timeout: float = 10):
        """
        Start the telemetry socket thread, optionally blocking until the socket is connected. Subscribes to metadata for state checks on commands

        This method is called automatically when the SdkClient is created with autostart=True.
        """
        self._sdk.start(block, timeout)

        # register for metadata and bind updates to an instance variable
        self._usb_state_future = self._sdk.metadata_subscribe(
            [SdkClient.USB_STATE_METADATA], self._on_usb_state_metadata
        )
        self._flow_state_future = self._sdk.metadata_subscribe(
            [SdkClient.FLOW_SYSTEM_STATE_METADATA], self._on_flow_system_state_metadata
        )
        time.sleep(0.1)  # Give time for the metadata to be received

        # if usb connected, wait for boot
        if self.usb_state == UsbState.Connected:
            self._wait_for_boot()

    def stop(self):
        """
        Stop the telemetry socket thread.

        The SdkClient is not usable after this method is called. To use the SdkClient again, create a new instance.
        """
        self._sdk.stop()

    def __del__(self):
        """
        Stop the telemetry socket thread when the SdkClient is deleted.
        """
        self.stop()
        for f in self._usb_state_future:
            f.cancel()
        for f in self._flow_state_future:
            f.cancel()

    def on_moments(
        self,
        moment_id: MomentNumber,
        wavelength: Wavelength,
        callback: Callable[[np.ndarray, np.ndarray], Any],
        once: bool = False,
    ) -> EventFuture:
        """
        Register a callback handler for moments data.

        The callback will received a tuple of (timestamp, data) where timestamps ia a 1-D numpy array of timestamps of shape (t) and data is a 5-D numpy array of the moments data with dimensions (time, source_module, source_id, detector_module, detector_id) of shape (t, 48, 3, 48, 6).
        Typically you can expect the first invocation to have a shape of (t, 48, 3, 48, 6) where t is the number of moments data available at the time of subscription.
        Subsequent invocations will typically have a shape of (1, 48, 3, 48, 6).

        the moments array data is of type np.float32, where -np.inf indicates no data available for that channel.

        The callback will be called whenever a new laser pattern is finished, approximately every 200ms. if the previous callback invocation is still running, the next invocation will be skipped.
        To prevent data loss, we recommend offloading heavy compute tasks to a separate thread or process, and writing the callback to emit the data to a queue.

        Arguments:
            moment_id: Moment ID to subscribe to
            wavelength: Wavelength to subscribe to
            callback: Function to call when new moments data is available
            once: Subscribe only once and then unsubscribe

        Returns:
            EventFuture: An object that can be used to cancel the subscription
        """

        urn = self.MOMENTS_MODULE_URN_TEMPLATE.format(
            moment_id=moment_id.value, wavelength=wavelength.value
        )
        if self._sdk.fields_by_urn.get(urn) is None:
            raise ValueError(
                f"Moments {moment_id.name} {wavelength.value} not available. Connect a flow device to enable this feature. {urn} not in {self._sdk.fields_by_urn.keys()}"
            )
        field_urn = self.MOMENTS_FIELD_URN_TEMPLATE.format(
            moment_id=moment_id.value, wavelength=wavelength.value
        )
        _running = False

        def wrapped_callback(data):
            nonlocal _running
            if _running:
                return
            _running = True
            callback_exception = None
            try:
                d = data[field_urn][:, :, :, :, :6]
                resp = callback(
                    data[_SdkClient.TIMESTAMP_URN], d
                )  # unpack the data dictionary and call the callback
            except Exception as e:
                callback_exception = e
            _running = False
            if callback_exception:
                raise callback_exception
            return resp

        return self._sdk.subscribe(
            urn, wrapped_callback, rate=0, once=once, block_on_unsubscribe=True
        )

    def on_moments_by_module(
        self,
        moment_id: MomentNumber,
        wavelength: Wavelength,
        module: int,
        callback: Callable[[np.ndarray, np.ndarray], Any],
        once: bool = False,
    ) -> EventFuture:
        """
        Register a callback handler for moments data for detectors on a single module, averaged across within-module sources.

        The callback will received a tuple of (timestamp, data) where timestamps ia a 1-D numpy array of timestamps of shape (t) and data is a 2-D numpy array of the moments data with dimensions (time, detector_id) of shape (t, 6).
        Typically you can expect the first invocation to have a shape of (t, 6) where t is the number of moments data available at the time of subscription.
        Subsequent invocations will typically have a shape of (1, 6).

        the moments array data is of type np.float32, where 0.0 indicates no data available for that detector.
        If all detectors have 0.0, the module is not connected or is experiencing issues.
        Confirm the module is connected, and if you are still experiencing issues, contact support.
        """
        if module < 0:
            raise ValueError("module must be a non-negative integer")
        if module >= self.MAX_MODULES:
            raise ValueError(f"module must be less than {self.MAX_MODULES}")

        def wrapped_callable(ts, data):
            by_module = data[:, module, :, module, :]
            by_module[~np.isfinite(by_module)] = 0  # replace -inf with 0 for mean
            avg_data = np.mean(by_module, axis=(1))
            return callback(ts, avg_data)

        return self.on_moments(moment_id, wavelength, wrapped_callable, once)

    def on_retained_channels(
        self, callback: Callable[[np.ndarray, np.ndarray], Any]
    ) -> EventFuture:
        """
        Register a callback handler for retained channels data.

        The callback will received a tuple of (timestamp, data) where timestamps ia a 1-D numpy array of timestamps of shape (t) and data is a 2-D numpy array of the retained channels data with dimensions (time, module_id) of shape (t, MAX_MODULES).
        Typically you can expect the first invocation to have a shape of (t, MAX_MODULES) where t is the number of retained channels data available at the time of subscription.
        Subsequent invocations will typically have a shape of (1, MAX_MODULES).

        the retained channels array data is of type np.float32, where -np.inf indicates no data available for that channel.
        """

        def wrapped_callback(data: dict):
            retained_channels = data.get(self.RETAINED_CHANNELS_FIELD_URN)
            if retained_channels is not None:
                timestamps = data[_SdkClient.TIMESTAMP_URN]
                callback(timestamps, retained_channels)

        return self._sdk.subscribe(
            self.RETAINED_CHANNELS_MODULE_URN,
            wrapped_callback,
            rate=0,
            once=False,
            block_on_unsubscribe=True,
        )

    def on_task(self, callback: Callable[[np.ndarray, dict], Any]) -> EventFuture:
        """
        Register a callback handler for task updates.

        The callback will receive a dictionay with keys "events" and "values", where "events" is a list of event strings and "values" is a list of corresponding values (which may be strings or JSON objects).

        Arguments:
            callback: Function to call when new task data is available

        Returns:
            EventFuture: An object that can be used to cancel the subscription
        """

        def wrapped_callback(data: dict):
            # Call the provided callback with the task data
            events, values = data.get(self.TASK_EVENT_FIELD_URN), data.get(
                self.TASK_VALUE_FIELD_URN
            )
            if events is not None and values is not None:
                timestamps = data[_SdkClient.TIMESTAMP_URN]

                callback(
                    timestamps,
                    {
                        "events": [
                            e.decode("utf-8") if isinstance(e, bytes) else e
                            for e in events
                        ],
                        "values": [
                            v.decode("utf-8") if isinstance(v, bytes) else v
                            for v in values
                        ],
                    },
                )

        return self._sdk.subscribe(
            self.TASK_MODULE_URN,
            wrapped_callback,
            rate=0,
            once=False,
            block_on_unsubscribe=True,
        )

    def on_eeg(self, callback: Callable[[np.ndarray, np.ndarray], Any]) -> EventFuture:
        """
        Register a callback handler for EEG data.

        The callback will receive a tuple of (timestamp, data) where timestamps is a 1-D numpy array of timestamps of shape (t) and data is a 3-D numpy array of the EEG data with dimensions (time, channel_id, data_type) of shape (t, 8, 2).

        the EEG array data is of type np.float32, where -np.inf indicates no data available for that channel. The data_type dimension is 0 for voltage (Volts) and 1 for impedance (Ohms).
        """

        def wrapped_callback(data: dict):
            eeg_voltage, eeg_impedance = data.get(self.EEG_VOLTAGE_FIELD_URN), data.get(
                self.EEG_IMPEDANCE_FIELD_URN
            )
            if eeg_voltage is not None and eeg_impedance is not None:
                timestamps = data[_SdkClient.TIMESTAMP_URN]
                eeg_data = np.stack((eeg_voltage, eeg_impedance), axis=-1)
                callback(timestamps, eeg_data)

        return self._sdk.subscribe(
            self.EEG_MODULE_URN,
            wrapped_callback,
            rate=0,
            once=False,
            block_on_unsubscribe=True,
        )

    @check_faulted_on_command_failure
    @requires_flow_connected
    @requires_flow_booted
    def get_available_modules(self) -> List[int]:
        """
        Get the available modules on the connected Flow device.

        Use this method to determine which modules are available for subscription when calling on_moments_by_module.

        Returns:
            List[int]: A list of integers representing the available modules.

        Raises:
            ValueError: If the available modules cannot be deserialized from the metadata. This may indicate a version mismatch between the SDK and kortex.
            TimeoutError: If the available modules cannot be received within 1 second. This may indicate the flow device is not connected.
            FlowDisconnected: If the Flow device is not connected.
            FlowNotBooted: If the Flow device is not fully booted.
            FlowFaulted: If the Flow device is in a faulted state.
        """
        ready = threading.Event()
        modules = None
        decode_err = None

        def on_source_metadata(data):
            nonlocal modules, decode_err
            try:
                modules = deserialize_available_modules_from_metadata(data.msg)
            except Exception as e:
                decode_err = e
            ready.set()

        self._sdk.metadata_subscribe(
            [self.DANUBE_SOURCE_METADATA],
            on_source_metadata,
            once=True,
        )
        # wait up to 1 second for metadata to be received, typically this is very fast
        # unless flow is not connected
        is_ready = ready.wait(1)
        if not is_ready:
            raise TimeoutError("Failed to receive available modules from metadata")
        if decode_err is not None:
            raise cast(Exception, decode_err)
        if modules is None:
            raise ValueError("Failed to deserialize available modules from metadata")
        return modules

    def _wait_for_boot(self):
        print("Flow is booting", end="", flush=True)
        start_time = time.time()
        dots = 0
        max_dots = 3

        while (
            self._flow_system_state == FlowSystemState.Booting
            and time.time() - start_time < self._BOOT_TIMEOUT
        ):
            # Update the dots animation
            if dots < max_dots:
                print(".", end="", flush=True)
                dots += 1
            else:
                print("\rFlow is booting", end="", flush=True)
                dots = 0

            # Sleep for a moment before checking again
            time.sleep(self._BOOT_CHECK_INTERVAL)

        # Clear the line and print final status
        print("\r", end="", flush=True)
        flow_state = self._flow_system_state
        if flow_state == FlowSystemState.Booting:
            raise TimeoutError(
                f"Flow is still booting after {self._BOOT_TIMEOUT} seconds. Please power cycle Flow and try again."
            )
        elif flow_state in (
            FlowSystemState.Ready,
            FlowSystemState.DataGathering,
            FlowSystemState.Sleeping,
        ):
            print(f"Flow finished booting. Current state: {flow_state}")
        else:
            raise RuntimeError(
                f"Flow is in an invalid state for initialization: {flow_state}"
            )

    def _go_to_sleep(self):
        """
        Put the flow device to sleep. This should be done when the device is not in use.
        """
        self._sdk._send_command({"GoToSleep": {}}, timeout=30)

    @check_faulted_on_command_failure
    @requires_flow_connected
    def initialize_flow(self, study_id: str, api_key: str):
        """
        Initialize the flow device. This should be done once after powering on the device.
        """
        flow_state = self._flow_system_state
        # flow needs to be in sleeping state to initialize
        if flow_state == FlowSystemState.Faulted:
            raise ValueError(
                f"Flow is in a faulted state. Power cycle the device and try again."
            )
        elif flow_state == FlowSystemState.Booting:
            self._wait_for_boot()  # boots into sleeping state
        elif flow_state != FlowSystemState.Sleeping:
            self._go_to_sleep()

        # get serial number
        serial_numbers_resp = cast(
            Response, self._sdk._send_command({"GetSerialNumbers": {}}, timeout=30)
        )
        if not serial_numbers_resp.success:
            raise CommandFailure(serial_numbers_resp.failure_reason)
        serial_numbers = cast(DanubeSerialNumbers, serial_numbers_resp.response_data)

        headset_serial_number = serial_numbers.hub_serial_number

        connect_out_resp = requests.get(
            f"https://{self._sdk.NEUROME_HOSTNAME}/api/v1/connect_out/{study_id}/{headset_serial_number}",
            headers={"Authorization": api_key},
        )
        connect_out_resp.raise_for_status()
        connect_out_info = connect_out_resp.json()

        # connect kortex to neurome
        self._sdk._connect_out(connect_out_info["ws_url"], connect_out_info["ws_token"])

        # initialize flow
        self._sdk._send_command(
            {"Initialize": {"target": self._sdk.NEUROME_TARGET}},
            timeout=120,  # initialize can take some time with a full headset
        )

    @check_faulted_on_command_failure
    @requires_flow_connected
    def tune(self):
        """
        Tune the flow device. This should be done after initializing the device.
        """
        flow_state = self._flow_system_state
        if flow_state not in (FlowSystemState.Ready, FlowSystemState.Sleeping):
            raise ValueError(f"Flow is in an invalid state for tuning: {flow_state}")
        self._sdk._send_command(
            {"Tune": {"target": self._sdk.NEUROME_TARGET}}, timeout=30
        )

    @check_faulted_on_command_failure
    @requires_flow_connected
    def turn_lasers_off(self):
        """
        Turn off the lasers on the flow device.
        """
        self._sdk._send_command({"StopDataGathering": {}}, timeout=30)

    @check_faulted_on_command_failure
    @requires_flow_connected
    def turn_lasers_on(self):
        """
        Turn on the lasers on the flow device.
        """
        self._sdk._send_command({"StartDataGathering": {}}, timeout=30)

    def current_flow_usb_state(self) -> str:
        """
        Get the current state of the flow device.
        """
        # Check if we already have the state first
        with self._usb_state_lock:
            if self._usb_state is not None:
                return self._usb_state.value

        # If not, fetch it
        ready = threading.Event()
        usb_state = None

        def on_metadata(data):
            nonlocal usb_state
            usb_state = data.msg
            ready.set()

        self._sdk.metadata_subscribe(
            [self.USB_STATE_METADATA],
            on_metadata,
            once=True,
        )
        # wait up to 1 second for metadata to be received, typically this is very fast
        # unless flow is not connected
        is_ready = ready.wait(1)
        if not is_ready:
            raise TimeoutError("Failed to receive usb state from metadata")
        if usb_state is None:
            raise ValueError("Failed to update usb state from metadata")
        return json.loads(bytes(usb_state))["state"]

    def get_flow_system_state(self) -> str:
        """
        Get the current system state of the flow device.
        """
        # Check if we already have the state first
        with self._flow_system_state_lock:
            if self._flow_system_state is not None:
                return self._flow_system_state.value

        # If not, fetch it
        ready = threading.Event()
        system_state = None

        def on_metadata(data):
            nonlocal system_state
            system_state = data.msg
            ready.set()

        self._sdk.metadata_subscribe(
            [self.FLOW_SYSTEM_STATE_METADATA],
            on_metadata,
            once=True,
        )
        # wait up to 1 second for metadata to be received, typically this is very fast
        # unless flow is not connected
        is_ready = ready.wait(1)
        if not is_ready:
            raise TimeoutError("Failed to receive system state from metadata")
        if system_state is None:
            raise ValueError("Failed to update system state from metadata")
        return json.loads(bytes(system_state))


def check_coupling(
    client: SdkClient, high_priority_modules: Optional[List[int]] = None
) -> bool:
    """
    Interactive function to check coupling with the Flow device.
    This function will prompt the user to adjust the headset placement until the coupling is good.

    Returns:
        bool: True if the coupling is good, False if the user chooses to continue.
    Raises:
        ValueError: If the high_priority_modules list contains invalid module numbers.
        RuntimeError: If the user chooses to abort the coupling check.
    """
    if high_priority_modules is None:
        high_priority_modules = []

    if any(
        module < 0 or module >= client.MAX_MODULES for module in high_priority_modules
    ):
        raise ValueError(
            f"Invalid module numbers: {high_priority_modules}. Must be between 0 and {client.MAX_MODULES - 1}."
        )
    modules = client.get_available_modules()
    aggregate_high_priority = 0.0
    aggregate_all = 0.0
    cycle_count = 0

    def retained_channels_callback(
        ts: np.ndarray, retained_channels_percentage: np.ndarray
    ):
        nonlocal aggregate_high_priority, aggregate_all, cycle_count
        count_high_priority = 0
        count_modules = 0
        value_high_priority = 0.0
        value_modules = 0.0
        for cycle in range(ts.shape[0]):
            cycle_count += 1
            print(f"retained channels %: {retained_channels_percentage[cycle,modules]}")
            for module in modules:
                value = retained_channels_percentage[cycle, module]
                if value == -1.0:
                    value = np.nan
                else:
                    value = float(value)
                    count_modules += 1
                    value_modules += value
                    if module in high_priority_modules:
                        count_high_priority += 1
                        value_high_priority += value

        if count_modules > 0:
            aggregate_all = value_modules / count_modules
            if count_high_priority > 0:
                aggregate_high_priority = value_high_priority / count_high_priority
            else:
                aggregate_high_priority = 0.0

    while True:
        print("checking coupling...")
        cycle_count = 0
        aggregate_all = 0.0
        aggregate_high_priority = 0.0
        retained_channels_future = client.on_retained_channels(
            retained_channels_callback
        )

        # check initial retained channels
        start_time = time.time()
        while cycle_count < 2 and time.time() - start_time < 2:
            time.sleep(0.1)

        # if there are too many bad cycles, ask to reposition the headset
        retained_channels_future.cancel()

        if aggregate_all < 0.15:
            print("Lowest signal")
        elif aggregate_all < 0.4:
            print("Low signal")
        elif aggregate_all < 0.8:
            print("High signal")
        else:
            print("Highest signal")

        if aggregate_all < 0.4 or aggregate_high_priority < 0.4:
            print(
                f"Poor coupling: {aggregate_all:.2f} (all modules), {aggregate_high_priority:.2f} (high priority modules)"
            )
            print("Please adjust the headset placement and try again.")
            # ask user to adjust headset placement or abort
            user_input = input(
                "Press Enter to continue checking, 'c' to continue with poor coupling, or 'q' to quit: "
            )
            if user_input.lower() == "q":
                raise RuntimeError("Coupling check aborted by user.")
            elif user_input.lower() == "c":
                print("Continuing with poor coupling...")
                return False
        else:
            print(
                f"Good coupling: {aggregate_all:.2f} (all modules), {aggregate_high_priority:.2f} (high priority modules)"
            )
            return True


def run_workflow(
    study_id: str,
    api_key: str,
    skip_initialize: bool = False,
    skip_coupling_check: bool = False,
    high_priority_modules: Optional[List[int]] = None,
):
    """
    Run an example workflow to record a dataset with the Flow device.

    This workflow will guide a user through the process of initializing the Flow device, tuning it, and starting data gathering.
    It will also check the coupling of the headset and prompt the user to adjust the placement if necessary.
    Parameters:
        study_id (str): The study ID for the Flow device.
        api_key (str): The API key for the Flow device.
        skip_initialize (bool): If True, skip the initialization step. Default is False.
        skip_coupling_check (bool): If True, skip the coupling check step. Default is False.
        high_priority_modules (Optional[List[int]]): A list of module IDs to check for high priority coupling. Default is None.
    Raises:
        ValueError: If the Flow device is not connected or if the USB state is not valid.
        RuntimeError: If the user chooses to abort the workflow.
        TimeoutError: If the Flow device does not respond within the specified timeout.

    Note:
        This workflow is provided as an example and may need to be modified for your specific use case.
    """

    client = SdkClient()

    try:
        usb_state = client.current_flow_usb_state()

        if UsbState(usb_state) != UsbState.Connected:
            raise ValueError(f"Flow is not connected. Current USB state: {usb_state}")

        available_modules = client.get_available_modules()

        print(f"Available modules: {available_modules}")

        if not skip_initialize:
            input("Press Enter after Flow is placed on stand...")

            print("Initializing flow...")
            client.initialize_flow(
                study_id, api_key
            )  # will raise an exception if any errors occur
            print("Flow initialized.")

        input("Press Enter after moving Flow to participant...")
        print("Tuning flow...")
        client.tune()  # will raise an exception if any errors occur
        print("Flow tuned.")

        input("Press Enter to start data gathering...")
        client.turn_lasers_on()  # will raise an exception if any errors occur
        print("Data gathering started.")

        # check retained channels before recording

        if not skip_coupling_check:
            check_coupling(client, high_priority_modules)

        # register callback for moments data
        def callback(ts: np.ndarray, data: np.ndarray):
            print(
                f"Received moments data: {ts}, {data}"
            )  # replace with your own processing code
            return None

        on_moments_future = client.on_moments_by_module(
            MomentNumber.First,
            Wavelength.Red,
            module=0,  # pick one from available_modules
            callback=callback,
            once=False,
        )

        # you can call client.on_moments_by_module multiple times to register multiple callbacks for different modules

        # on_moments will run in a separate thread

        input("Press Enter to stop data gathering...")

        client.turn_lasers_off()  # will raise an exception if any errors occur
        print("Data gathering stopped.")
        on_moments_future.cancel()  # stop the callback
    finally:
        try:
            client.turn_lasers_off()  # turn off the lasers if they are still on
        except Exception as e:
            print(f"Failed to turn off lasers: {e}")
            print(f"For saftey, please power cycle the Flow device before retrying.")
        client.stop()  # stop the sdk client
        print("SdkClient stopped.")
