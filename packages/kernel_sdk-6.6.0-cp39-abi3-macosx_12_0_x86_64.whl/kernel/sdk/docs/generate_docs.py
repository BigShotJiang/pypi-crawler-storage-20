import sys
from unittest.mock import MagicMock


# Set up mock for kernel.sdk._sdk
class Mock(MagicMock):
    @classmethod
    def __getattr__(cls, name):
        return MagicMock()

sys.modules['kernel.sdk._sdk'] = Mock()

# Now we can safely import pydoc and other necessary modules
import pydoc
from html import escape


# Create a custom HTML documentation generator
class CustomHTMLDoc(pydoc.HTMLDoc):
    def heading(self, title, fgcol, bgcol, extras=''):
        """Override heading to customize the page header"""
        return f'<h1>{escape(title)}</h1>\n'

def generate_docs():
    # Import the modules we need to document
    import kernel.sdk.socket

    # Create our HTML document
    html_doc = CustomHTMLDoc()

    # Open a single HTML file for output
    with open('kernel.sdk.socket.combined.html', 'w') as f:
        # Write HTML header
        f.write("""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>kernel.sdk.socket Documentation</title>
<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h1, h2 { color: #333; }
pre { background-color: #f5f5f5; padding: 10px; border-radius: 5px; }
.section { margin-bottom: 30px; }
</style>
</head>
<body>
<h1>kernel.sdk.SdkClient Documentation</h1>
""")
        
        # Document SdkClient class
        f.write('<div class="section"><h2>SdkClient Class</h2>')
        sdkclient_doc = html_doc.document(kernel.sdk.socket.SdkClient)
        # Handle the HTML content safely without assuming specific tags
        if '<body>' in sdkclient_doc and '</body>' in sdkclient_doc:
            # Extract content between body tags if they exist
            content = sdkclient_doc.split('<body>', 1)[1].split('</body>', 1)[0]
        else:
            # Use the entire content if body tags don't exist
            content = sdkclient_doc
        f.write(content)
        f.write('</div>')
        
        # Document run_workflow function
        f.write('<div class="section"><h2>run_workflow Function</h2>')
        run_workflow_doc = html_doc.docroutine(kernel.sdk.socket.run_workflow)
        f.write(run_workflow_doc)
        f.write('</div>')
        
        # Write HTML footer
        f.write('</body></html>')

    print("Documentation generated successfully")

if __name__ == "__main__":
    generate_docs()
