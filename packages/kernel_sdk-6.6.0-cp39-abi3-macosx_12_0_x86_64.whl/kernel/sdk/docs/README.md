# kernel.sdk

## Installation
`pip install -r requirements.txt`

## Usage

### Task Client
See `TASK.md`

### Sdk Client
See `SDK.md`