#!/bin/bash

# Change to the project directory
pushd ../../../

# Run the Python documentation generator script
python kernel/sdk/docs/generate_docs.py

# Move the generated file to the docs directory
mv kernel.sdk.socket.combined.html kernel/sdk/docs/kernel.sdk.socket.SdkClient.html
echo "Documentation generated at kernel/sdk/docs/kernel.sdk.socket.SdkClient.html"
popd