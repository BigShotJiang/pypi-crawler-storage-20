import logging
import os
import platform
import socket
import struct
import tempfile
from abc import ABC, abstractmethod
from collections import Counter
from enum import Enum
from pathlib import Path
from typing import List, Optional

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)

# Update STORAGE_DIR to use platform-appropriate temp directory
STORAGE_DIR = Path(tempfile.gettempdir()) if platform.system() == "Windows" else Path("/tmp/")


class ClientProtocol(Enum):
    """
    Enum for Socket protocol
    """

    UDP = 1
    TCP = 2


class Socket:
    """
    Wrapper around a `socket` to hide protocol details
    """

    def __init__(
        self,
        protocol: ClientProtocol,
        ip: str,
        port: int,
        mcast_ttl: Optional[int] = 0,
        timeout: Optional[float] = None,
    ):

        self.protocol = protocol
        self.ip = ip
        self.port = port
        self.mcast_ttl: int = 0 if mcast_ttl is None else mcast_ttl
        if protocol is ClientProtocol.UDP:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._socket.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, self.mcast_ttl)
        elif protocol is ClientProtocol.TCP:
            self._socket = socket.create_connection((ip, port), timeout)
        else:
            raise ValueError(f"Invalid protocol {protocol}")

    def sendto(self, msg: bytes):
        if self.protocol is ClientProtocol.UDP:
            self._socket.sendto(msg, (self.ip, self.port))
        else:
            # have to send the len(msg) as a network-endian uint32 header when sending to kortex's tcp listener
            msg = struct.pack("!I", len(msg)) + msg
            self._socket.sendall(msg)

DEFAULT_POST_SESSION_PATH = (
    Path(os.path.expanduser("~")) / "AppData" / "Local" / "post_session" 
    if platform.system() == "Windows" 
    else Path("/usr/local/post_session")
)

class CoreClient(ABC):
    def __init__(
        self,
        multicast_ip: str,  # name is multicast_ip for backwards compatibility purposes, TCP protocol will use this as the server ip
        multicast_port: int,  # name is multicast_port for backwards compatibility purposes, TCP protocol will use this as the server port
        post_session_object_path: Optional[Path] = None,
        debug: bool = False,
        multicast_ttl_override: Optional[int] = None,
        protocol: ClientProtocol = ClientProtocol.UDP,
    ) -> None:
        
        if post_session_object_path is None:
            post_session_object_path = DEFAULT_POST_SESSION_PATH

        self._post_session_object_path = post_session_object_path

        self._setup()  # exposed for unit tests

        self._debug = debug
        self._debug_events: List[bytes] = []

        if debug:
            LOGGER.warning("WARNING: CLIENT IS IN DEBUG MODE AND WILL NOT SEND PACKETS!!!")
        else:
            self._socket = Socket(
                protocol,
                multicast_ip,
                multicast_port,
                multicast_ttl_override,
                timeout=None,
            )

    def _setup(self):
        self._id = 0
        self._event_counter = Counter()
        self._groupings = []

    @property
    def debug_events(self) -> List[bytes]:
        return self._debug_events

    @abstractmethod
    def send_event(self, *args, **kwargs):
        raise NotImplementedError

    def _send_event(self, event: bytes):
        if not self._debug:
            LOGGER.debug(
                f"sent {len(event)} bytes to {self._socket.protocol}//{self._socket.ip}:{self._socket.port}"
            )
            self._socket.sendto(event)
        else:
            self._debug_events.append(event)

    def _post_session_file(self, file: str):
        if self._post_session_object_path and self._post_session_object_path.exists():
            return self._post_session_object_path / file

        LOGGER.warning(
            f"Incorrect post session object path, using /tmp! {self._post_session_object_path}"
        )
        return STORAGE_DIR / file
