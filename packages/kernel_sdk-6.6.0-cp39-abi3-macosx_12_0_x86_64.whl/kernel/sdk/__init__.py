import logging
import os
import sys

from ._global import env
from ._sdk import deserialize_usb_meta  # reexport
from .prelude import *
from .socket import Disconnected, MomentNumber, SdkClient, Wavelength, run_workflow

__all__ = [
    "env",
    "SdkClient",
    "MomentNumber",
    "Wavelength",
    "Disconnected",
    "SDKError",
    "TimeoutError",
]

TEST = "pytest" in sys.modules or os.getenv("TEST", False)
SENTRY_DSN_SDK = os.getenv(
    "SENTRY_DSN_SDK", "https://27a1b04684af424d9b2e35da5d2a9f5d@sentry.kernel.co/5"
)

if not TEST and SENTRY_DSN_SDK:
    import sentry_sdk

    sentry_sdk.init(SENTRY_DSN_SDK)

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
    datefmt="%Y-%m-%d %H:%M:%S",
)
LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)
