import datetime
import getpass
import os
import platform
from typing import Optional

import jwt


def expire_tomorrow() -> int:
    return int((datetime.datetime.now() + datetime.timedelta(days=1)).timestamp())


def encode_from_user(secret: str):
    # Try to get username using getpass first (works cross-platform)
    try:
        user = getpass.getuser()
    except Exception:
        # Fall back to environment variables if getpass fails
        user_env_var = "USERNAME" if platform.system() == "Windows" else "USER"
        user = os.getenv(user_env_var)
        if user is None:
            raise ValueError(
                f"Could not determine username: {user_env_var} environment variable not set"
            )

    return encode(user, secret, False, expire_tomorrow(), None)


def encode(
    user: str, secret: str, admin: bool, time: int, plugin: Optional[str]
) -> str:
    payload = {"sub": user, "exp": time, "is_admin": False, "plugin": plugin}
    return jwt.encode(payload, secret, algorithm="HS256")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("secret")
    parser.add_argument("time", type=int)
    args = parser.parse_args()
    user = os.getenv("USER")
    if user is None:
        raise ValueError(user)
    print(encode(user, args.secret, False, args.time, None))
