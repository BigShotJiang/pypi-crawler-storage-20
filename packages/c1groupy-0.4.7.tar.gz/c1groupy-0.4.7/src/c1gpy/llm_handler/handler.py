"""
Main LLM Handler class for unified LLM interactions.

This module provides the LLMHandler class which offers a unified interface
for calling various LLM providers (OpenAI, Anthropic, Google) with Langfuse
integration for prompt management and tracing.
"""

import json
import os
from collections.abc import AsyncIterator, Iterator
from typing import Any, TypeVar

from langfuse import Langfuse
from langfuse.api.resources.commons.errors import NotFoundError as LangfuseNotFoundError
from langfuse.langchain import CallbackHandler
from pydantic import BaseModel

from c1gpy.llm_handler.provider_registry import (
    ModelProvider,
    create_llm,
    detect_provider,
)
from c1gpy.llm_handler.exceptions import (
    LLMHandlerError,
    PromptCompilationError,
    PromptNotFoundError,
    ResponseParsingError,
)

# Type hint for Pydantic models
# This allows the LLMHandler to return either a Pydantic model or a JSON dictionary
# depending on the response_model and json_mode parameters
T = TypeVar("T", bound=BaseModel)


class LLMHandler:
    """Unified handler for LLM interactions with Langfuse integration.

    Provides a clean interface for calling LLMs from various providers
    (OpenAI, Anthropic, Google) with support for:
    - Structured output via Pydantic models
    - JSON mode for dict responses
    - Synchronous and asynchronous calls
    - Streaming responses
    - Automatic prompt management via Langfuse
    - Request tracing via Langfuse callbacks

    Args:
        langfuse: Initialized Langfuse client.
        langfuse_prompt_name: Name of the prompt in Langfuse.
        model_name: Name of the model to use (e.g., 'gpt-4o', 'claude-3-sonnet').
            If None, uses value from Langfuse prompt config.
        api_key: API key for the model provider.
        langfuse_prompt_label: Label for the Langfuse prompt version.
            Defaults to 'production'.
        provider: Explicit provider override. If None, auto-detected from model name.
        response_model: Optional Pydantic model for validated structured output.
            Mutually exclusive with json_mode.
        json_mode: If True, parse response as unvalidated JSON dict.
            Mutually exclusive with response_model.
        temperature: Sampling temperature for the model. If None, uses value from
            Langfuse prompt config, defaulting to 1.0.
        max_tokens: Maximum tokens in the response. If None, uses value from
            Langfuse prompt config, defaulting to model default.
        cache_ttl_seconds: Cache TTL for Langfuse prompts. Defaults to 300.

    Raises:
        ValueError: If both response_model and json_mode=True are specified.
        PromptNotFoundError: If the Langfuse prompt cannot be found.

    Example:
        >>> from langfuse import Langfuse
        >>> from pydantic import BaseModel
        >>> from c1gpy.llm_handler import LLMHandler
        >>>
        >>> langfuse = Langfuse()
        >>>
        >>> class ProductTitles(BaseModel):
        ...     titles: list[str]
        ...
        >>> handler = LLMHandler(
        ...     langfuse=langfuse,
        ...     langfuse_prompt_name="product-title-generator",
        ...     model_name="gpt-4o",
        ...     api_key="sk-...",
        ...     response_model=ProductTitles,
        ... )
        >>> result = handler.call_model(keywords=["laptop", "gaming"])
        >>> print(result.titles)
    """

    def __init__(
        self,
        langfuse: Langfuse,
        langfuse_prompt_name: str,
        *,
        model_name: str | None = None,
        api_key: str | None = None,
        langfuse_prompt_label: str = "production",
        provider: ModelProvider | None = None,
        response_model: type[T] | None = None,
        json_mode: bool = False,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        cache_ttl_seconds: int = 0,
    ) -> None:
        # Validate mutually exclusive parameters
        if response_model is not None and json_mode:
            raise ValueError(
                "Cannot use both 'response_model' and 'json_mode=True'. "
                "Use 'response_model' for validated Pydantic output, "
                "or 'json_mode=True' for unvalidated JSON dict."
            )

        self._langfuse = langfuse
        self._langfuse_prompt_name = langfuse_prompt_name
        self._langfuse_prompt_label = langfuse_prompt_label
        self._api_key = api_key
        self._response_model = response_model
        self._json_mode = json_mode
        self._timeout = timeout
        self._cache_ttl_seconds = cache_ttl_seconds

        # 2. Fetch the prompt from Langfuse
        try:
            self._prompt = self._langfuse.get_prompt(
                name=langfuse_prompt_name,
                label=langfuse_prompt_label,
                cache_ttl_seconds=cache_ttl_seconds,
            )
        except LangfuseNotFoundError as e:
            raise PromptNotFoundError(
                prompt_name=langfuse_prompt_name,
                label=langfuse_prompt_label,
                original_error=e,
            ) from e

        # Get prompt config
        prompt_config = getattr(self._prompt, "config", {})
        if not isinstance(prompt_config, dict):
            prompt_config = {}

        # 3. Determine model name
        if model_name is not None:
            self._model_name = model_name
        else:
            # Try to get model from prompt config
            prompt_model = prompt_config.get("model")
            if isinstance(prompt_model, str):
                self._model_name = prompt_model
            else:
                raise ValueError(
                    f"Model name not provided and not found in Langfuse prompt '{langfuse_prompt_name}' config."
                )

        # Determine temperature
        if temperature is not None:
            self._temperature = temperature
        else:
            self._temperature = prompt_config.get("temperature")
            # Default to 1.0 if not found in config either
            if self._temperature is None:
                self._temperature = 1.0
            else:
                # Ensure it's a float
                self._temperature = float(self._temperature)

        # Determine max_tokens
        if max_tokens is not None:
            self._max_tokens = max_tokens
        else:
            config_max_tokens = prompt_config.get("max_tokens")
            self._max_tokens = (
                int(config_max_tokens) if config_max_tokens is not None else None
            )

        # 4. Detect or use explicit provider
        self._provider = (
            provider if provider is not None else detect_provider(self._model_name)
        )

        # Build model kwargs
        model_kwargs: dict[str, Any] = {"temperature": self._temperature}
        if self._max_tokens is not None:
            model_kwargs["max_tokens"] = self._max_tokens
        if self._timeout is not None:
            model_kwargs["timeout"] = self._timeout

        if json_mode and self._provider == ModelProvider.OPENAI:
            existing_model_kwargs = model_kwargs.get("model_kwargs")
            if existing_model_kwargs is None:
                model_kwargs["model_kwargs"] = {
                    "response_format": {"type": "json_object"}
                }
            elif isinstance(existing_model_kwargs, dict):
                existing_model_kwargs.setdefault(
                    "response_format", {"type": "json_object"}
                )

        # Create the LLM instance
        self._llm = create_llm(
            provider=self._provider,
            model_name=self._model_name,
            api_key=api_key,
            **model_kwargs,
        )

        # Configure structured output if needed
        if response_model is not None:
            if self._provider == ModelProvider.GOOGLE:
                # Google Gemini supports json_schema method for structured output
                self._llm = self._llm.with_structured_output(
                    response_model,
                    method="json_schema",
                )
            elif self._provider == ModelProvider.ANTHROPIC:
                # Anthropic supports json_schema method for structured output
                self._llm = self._llm.with_structured_output(
                    response_model,
                    method="json_schema",
                )
            else:
                self._llm = self._llm.with_structured_output(response_model)
        elif json_mode:
            # For JSON mode without Pydantic, we'll parse manually
            pass

        # Create callback handler for tracing
        self._callback_handler = CallbackHandler()
        lf_public_key = getattr(self._langfuse, "public_key", None)
        lf_secret_key = getattr(self._langfuse, "secret_key", None)
        lf_host = getattr(self._langfuse, "host", None)

        try:
            # Fallback to internal client wrapper (Langfuse v3 structure)
            if not (lf_public_key and lf_secret_key):
                api_client = getattr(self._langfuse, "api", None)
                client_wrapper = getattr(api_client, "_client_wrapper", None)
                if client_wrapper:
                    lf_public_key = getattr(client_wrapper, "_username", lf_public_key)
                    lf_secret_key = getattr(client_wrapper, "_password", lf_secret_key)
                    lf_host = getattr(client_wrapper, "_base_url", lf_host)
        except Exception:
            # If extraction fails, we rely on environment variables which CallbackHandler uses by default
            pass

        # Set environment variables for CallbackHandler if we found keys.
        # CallbackHandler reads from env vars for secret_key and host.
        if lf_public_key:
            os.environ["LANGFUSE_PUBLIC_KEY"] = lf_public_key
        if lf_secret_key:
            os.environ["LANGFUSE_SECRET_KEY"] = lf_secret_key
        if lf_host:
            os.environ["LANGFUSE_HOST"] = lf_host

        self._callback_handler = CallbackHandler(
            public_key=lf_public_key,
        )

    @property
    def model_name(self) -> str:
        """The name of the model being used."""
        return self._model_name

    @property
    def provider(self) -> ModelProvider:
        """The model provider."""
        return self._provider

    @property
    def prompt_name(self) -> str:
        """The Langfuse prompt name."""
        return self._langfuse_prompt_name

    @property
    def prompt_label(self) -> str:
        """The Langfuse prompt label."""
        return self._langfuse_prompt_label

    def _compile_prompt(self, **kwargs: Any) -> list[dict[str, str]]:
        """Compile the Langfuse prompt with the given variables.

        Args:
            **kwargs: Template variables for the prompt.

        Returns:
            Compiled messages list.

        Raises:
            PromptCompilationError: If compilation fails.
        """
        try:
            return self._prompt.compile(**kwargs)
        except Exception as e:
            raise PromptCompilationError(
                f"Failed to compile prompt '{self._langfuse_prompt_name}': {e}",
                prompt_name=self._langfuse_prompt_name,
            ) from e

    def _parse_json_response(self, content: str) -> dict[str, Any]:
        """Parse a string response as JSON.

        Args:
            content: The raw response content.

        Returns:
            Parsed JSON as a dictionary.

        Raises:
            ResponseParsingError: If parsing fails.
        """
        if content is None:
            raise ResponseParsingError(
                "Failed to parse response as JSON: response content is None",
                raw_response=None,
            )

        cleaned = content.strip()
        if cleaned == "":
            raise ResponseParsingError(
                "Failed to parse response as JSON: response content is empty",
                raw_response=content,
            )

        def _try_load_json(text: str) -> dict[str, Any] | None:
            try:
                loaded = json.loads(text)
            except json.JSONDecodeError:
                return None
            if not isinstance(loaded, dict):
                raise ResponseParsingError(
                    f"Expected JSON object, got {type(loaded).__name__}",
                    raw_response=content,
                )
            return loaded

        try:
            result = _try_load_json(cleaned)
            if result is not None:
                return result

            if cleaned.startswith("```"):
                fenced = cleaned
                if fenced.startswith("```json"):
                    fenced = fenced[7:]
                else:
                    fenced = fenced[3:]
                if fenced.endswith("```"):
                    fenced = fenced[:-3]
                fenced = fenced.strip()
                result = _try_load_json(fenced)
                if result is not None:
                    return result

            start = cleaned.find("{")
            end = cleaned.rfind("}")
            if start != -1 and end != -1 and end > start:
                candidate = cleaned[start : end + 1]
                result = _try_load_json(candidate)
                if result is not None:
                    return result

            raise json.JSONDecodeError("Expecting value", cleaned, 0)
        except json.JSONDecodeError as e:
            raise ResponseParsingError(
                f"Failed to parse response as JSON: {e}",
                raw_response=content,
            ) from e

    def _extract_content(self, response: Any) -> str:
        if response is None:
            return ""

        if hasattr(response, "content"):
            content = response.content
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts: list[str] = []
                for item in content:
                    if isinstance(item, str):
                        parts.append(item)
                    elif isinstance(item, dict):
                        if isinstance(item.get("text"), str):
                            parts.append(item["text"])
                        elif isinstance(item.get("content"), str):
                            parts.append(item["content"])
                joined = "".join(parts)
                if joined != "":
                    return joined
                return str(content)

        return str(response)

    def _extract_json_from_tool_calls(self, response: Any) -> str | None:
        additional_kwargs = getattr(response, "additional_kwargs", None)
        if not isinstance(additional_kwargs, dict):
            return None

        tool_calls = additional_kwargs.get("tool_calls")
        if isinstance(tool_calls, list) and tool_calls:
            first = tool_calls[0]
            if isinstance(first, dict):
                fn = first.get("function")
                if isinstance(fn, dict) and isinstance(fn.get("arguments"), str):
                    return fn["arguments"]

        function_call = additional_kwargs.get("function_call")
        if isinstance(function_call, dict) and isinstance(
            function_call.get("arguments"), str
        ):
            return function_call["arguments"]

        return None

    def call_model(self, **kwargs: Any) -> dict[str, Any] | T:
        """Call the LLM synchronously with the given prompt variables.

        Compiles the Langfuse prompt with the provided variables and
        invokes the model. Returns either a Pydantic model instance,
        a JSON dict, or raises an error.

        Args:
            **kwargs: Template variables for the prompt (e.g., keywords, n_titles).

        Returns:
            If response_model is set: validated Pydantic model instance.
            If json_mode is True: parsed JSON dictionary.
            Otherwise: raw response content as string in a dict.

        Raises:
            PromptCompilationError: If prompt compilation fails.
            ResponseParsingError: If response parsing fails.
            LLMHandlerError: For other LLM-related errors.

        Example:
            >>> result = handler.call_model(keywords=["laptop"], n_titles=5)
        """
        messages = self._compile_prompt(**kwargs)

        try:
            response = self._llm.invoke(
                messages,
                config={
                    "callbacks": [self._callback_handler],
                    "run_name": self._langfuse_prompt_name,
                },
            )

            # If using structured output with Pydantic, response is already parsed
            if self._response_model is not None:
                return response

            # Extract content from response
            content = self._extract_content(response)
            if self._json_mode and content.strip() == "":
                tool_json = self._extract_json_from_tool_calls(response)
                if tool_json is not None:
                    content = tool_json

            # If json_mode, parse as JSON
            if self._json_mode:
                return self._parse_json_response(content)

            # Return raw content wrapped in dict
            return {"content": content}

        except (PromptCompilationError, ResponseParsingError):
            raise
        except Exception as e:
            raise LLMHandlerError(f"Model invocation failed: {e}") from e

    def invoke(self, **kwargs: Any) -> dict[str, Any] | T:
        """Alias for `call_model`."""

        return self.call_model(**kwargs)

    async def acall_model(self, **kwargs: Any) -> dict[str, Any] | T:
        """Call the LLM asynchronously with the given prompt variables.

        Async version of call_model. Compiles the Langfuse prompt with
        the provided variables and invokes the model asynchronously.

        Args:
            **kwargs: Template variables for the prompt.

        Returns:
            Same as call_model.

        Raises:
            Same as call_model.

        Example:
            >>> result = await handler.acall_model(keywords=["laptop"], n_titles=5)
        """
        messages = self._compile_prompt(**kwargs)

        try:
            response = await self._llm.ainvoke(
                messages,
                config={
                    "callbacks": [self._callback_handler],
                    "run_name": self._langfuse_prompt_name,
                },
            )

            # If using structured output with Pydantic, response is already parsed
            if self._response_model is not None:
                if response is None:
                    raise ResponseParsingError(
                        "LLM returned None. This may indicate an invalid model name, "
                        "API error, or the model failed to generate structured output.",
                        raw_response=None,
                    )
                return response

            # Extract content from response
            content = self._extract_content(response)
            if self._json_mode and content.strip() == "":
                tool_json = self._extract_json_from_tool_calls(response)
                if tool_json is not None:
                    content = tool_json

            # If json_mode, parse as JSON
            if self._json_mode:
                return self._parse_json_response(content)

            # Return raw content wrapped in dict
            return {"content": content}

        except (PromptCompilationError, ResponseParsingError):
            raise
        except Exception as e:
            raise LLMHandlerError(f"Async model invocation failed: {e}") from e

    async def ainvoke(self, **kwargs: Any) -> dict[str, Any] | T:
        """Alias for `acall_model`."""

        return await self.acall_model(**kwargs)

    def batch_invoke(
        self, batch_kwargs: list[dict[str, Any]]
    ) -> list[dict[str, Any] | T]:
        """Invoke the model for many prompt-variable dicts (sync)."""

        if not batch_kwargs:
            return []

        messages_batch = [self._compile_prompt(**kwargs) for kwargs in batch_kwargs]
        configs = [
            {
                "callbacks": [self._callback_handler],
                "run_name": self._langfuse_prompt_name,
            }
            for _ in range(len(messages_batch))
        ]

        try:
            responses = self._llm.batch(messages_batch, config=configs)

            if self._response_model is not None:
                if any(r is None for r in responses):
                    raise ResponseParsingError(
                        "LLM returned None for one or more batch items. This may indicate an invalid model name, "
                        "API error, or the model failed to generate structured output.",
                        raw_response=None,
                    )
                return responses

            results: list[dict[str, Any] | T] = []
            for response in responses:
                content = self._extract_content(response)
                if self._json_mode and content.strip() == "":
                    tool_json = self._extract_json_from_tool_calls(response)
                    if tool_json is not None:
                        content = tool_json
                if self._json_mode:
                    results.append(self._parse_json_response(content))
                else:
                    results.append({"content": content})
            return results

        except (PromptCompilationError, ResponseParsingError):
            raise
        except Exception as e:
            raise LLMHandlerError(f"Batch model invocation failed: {e}") from e

    async def abatch_invoke(
        self, batch_kwargs: list[dict[str, Any]]
    ) -> list[dict[str, Any] | T]:
        """Invoke the model for many prompt-variable dicts (async)."""

        if not batch_kwargs:
            return []

        messages_batch = [self._compile_prompt(**kwargs) for kwargs in batch_kwargs]
        configs = [
            {
                "callbacks": [self._callback_handler],
                "run_name": self._langfuse_prompt_name,
            }
            for _ in range(len(messages_batch))
        ]

        try:
            responses = await self._llm.abatch(messages_batch, config=configs)

            if self._response_model is not None:
                if any(r is None for r in responses):
                    raise ResponseParsingError(
                        "LLM returned None for one or more batch items. This may indicate an invalid model name, "
                        "API error, or the model failed to generate structured output.",
                        raw_response=None,
                    )
                return responses

            results: list[dict[str, Any] | T] = []
            for response in responses:
                content = self._extract_content(response)
                if self._json_mode and content.strip() == "":
                    tool_json = self._extract_json_from_tool_calls(response)
                    if tool_json is not None:
                        content = tool_json
                if self._json_mode:
                    results.append(self._parse_json_response(content))
                else:
                    results.append({"content": content})
            return results

        except (PromptCompilationError, ResponseParsingError):
            raise
        except Exception as e:
            raise LLMHandlerError(f"Async batch model invocation failed: {e}") from e

    def call_model_stream(self, **kwargs: Any) -> Iterator[str]:
        """Stream the LLM response synchronously.

        Compiles the prompt and streams the response token by token.
        Note: Streaming does not support structured output (Pydantic models).

        Args:
            **kwargs: Template variables for the prompt.

        Yields:
            Response content chunks as strings.

        Raises:
            PromptCompilationError: If prompt compilation fails.
            LLMHandlerError: For other LLM-related errors.

        Example:
            >>> for chunk in handler.call_model_stream(keywords=["laptop"]):
            ...     print(chunk, end="", flush=True)
        """
        messages = self._compile_prompt(**kwargs)

        try:
            for chunk in self._llm.stream(
                messages,
                config={
                    "callbacks": [self._callback_handler],
                    "run_name": self._langfuse_prompt_name,
                },
            ):
                content = self._extract_content(chunk)
                if content:
                    yield content

        except PromptCompilationError:
            raise
        except Exception as e:
            raise LLMHandlerError(f"Streaming invocation failed: {e}") from e

    async def acall_model_stream(self, **kwargs: Any) -> AsyncIterator[str]:
        """Stream the LLM response asynchronously.

        Async version of call_model_stream. Compiles the prompt and
        streams the response token by token.

        Args:
            **kwargs: Template variables for the prompt.

        Yields:
            Response content chunks as strings.

        Raises:
            Same as call_model_stream.

        Example:
            >>> async for chunk in handler.acall_model_stream(keywords=["laptop"]):
            ...     print(chunk, end="", flush=True)
        """
        messages = self._compile_prompt(**kwargs)

        try:
            async for chunk in self._llm.astream(
                messages,
                config={
                    "callbacks": [self._callback_handler],
                    "run_name": self._langfuse_prompt_name,
                },
            ):
                content = self._extract_content(chunk)
                if content:
                    yield content

        except PromptCompilationError:
            raise
        except Exception as e:
            raise LLMHandlerError(f"Async streaming invocation failed: {e}") from e

    def __str__(self) -> str:
        """Return a human-readable string representation.

        Example:
            >>> print(handler)
            LLMHandler(model='gpt-4o', provider=OPENAI, prompt='my-prompt', label='production')
        """
        return (
            f"LLMHandler("
            f"model='{self._model_name}', "
            f"provider={self._provider.name}, "
            f"prompt='{self._langfuse_prompt_name}', "
            f"label='{self._langfuse_prompt_label}'"
            f")"
        )

    def __repr__(self) -> str:
        """Return a detailed string representation for debugging.

        Example:
            >>> repr(handler)
            LLMHandler(model='gpt-4o', provider=OPENAI, prompt='my-prompt', ...)
        """
        return (
            f"LLMHandler("
            f"model_name='{self._model_name}', "
            f"provider={self._provider!r}, "
            f"langfuse_prompt_name='{self._langfuse_prompt_name}', "
            f"langfuse_prompt_label='{self._langfuse_prompt_label}', "
            f"response_model={self._response_model}, "
            f"json_mode={self._json_mode}, "
            f"temperature={self._temperature}, "
            f"max_tokens={self._max_tokens}, "
            f"timeout={self._timeout}"
            f")"
        )
