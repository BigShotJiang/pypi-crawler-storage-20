"""
Custom exceptions for the LLM Handler module.

This module defines exceptions for error handling across the LLM handler,
including provider-related errors, prompt compilation errors, and general
handler errors.
"""


class LLMHandlerError(Exception):
    """Base exception for all LLM Handler errors.

    Args:
        message: Human-readable error description.

    Example:
        >>> raise LLMHandlerError("Failed to process LLM response")
    """

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(self.message)


class ProviderError(LLMHandlerError):
    """Raised when there is an error related to the model provider.

    This includes errors such as:
    - Unknown or unsupported model provider
    - Failed provider initialization
    - Invalid API key for provider

    Args:
        message: Human-readable error description.
        provider: Optional provider name that caused the error.

    Example:
        >>> raise ProviderError("Unknown model: xyz-model", provider="unknown")
    """

    def __init__(self, message: str, provider: str | None = None) -> None:
        self.provider = provider
        super().__init__(message)


class PromptCompilationError(LLMHandlerError):
    """Raised when prompt compilation fails.

    This occurs when:
    - Required template variables are missing
    - Template syntax is invalid
    - Langfuse prompt retrieval fails

    Args:
        message: Human-readable error description.
        prompt_name: Optional name of the prompt that failed.
        missing_vars: Optional list of missing template variables.

    Example:
        >>> raise PromptCompilationError(
        ...     "Missing required variable",
        ...     prompt_name="product-generator",
        ...     missing_vars=["keywords"]
        ... )
    """

    def __init__(
        self,
        message: str,
        prompt_name: str | None = None,
        missing_vars: list[str] | None = None,
    ) -> None:
        self.prompt_name = prompt_name
        self.missing_vars = missing_vars or []
        super().__init__(message)


class ResponseParsingError(LLMHandlerError):
    """Raised when the LLM response cannot be parsed.

    This occurs when:
    - Response is not valid JSON when json_mode is enabled
    - Response does not match the expected Pydantic model schema
    - Response content is empty or malformed

    Args:
        message: Human-readable error description.
        raw_response: Optional raw response content that failed to parse.

    Example:
        >>> raise ResponseParsingError(
        ...     "Invalid JSON in response",
        ...     raw_response="not valid json"
        ... )
    """

    def __init__(self, message: str, raw_response: str | None = None) -> None:
        self.raw_response = raw_response
        super().__init__(message)


class PromptNotFoundError(LLMHandlerError):
    """Raised when a Langfuse prompt cannot be found.

    This error typically occurs due to one of the following reasons:
    - The prompt name does not exist in the Langfuse project
    - The specified label (e.g., 'production') does not exist for the prompt
    - The API keys (secret_key, public_key) belong to a different Langfuse project

    Args:
        prompt_name: Name of the prompt that was not found.
        label: Label that was searched for.
        original_error: Optional original exception from Langfuse.

    Example:
        >>> raise PromptNotFoundError(
        ...     prompt_name="my-prompt",
        ...     label="production",
        ... )
    """

    def __init__(
        self,
        prompt_name: str,
        label: str,
        original_error: Exception | None = None,
    ) -> None:
        self.prompt_name = prompt_name
        self.label = label
        self.original_error = original_error

        message = (
            f"Langfuse prompt not found: '{prompt_name}' with label '{label}'.\n\n"
            f"Please verify:\n"
            f"  1. The prompt name '{prompt_name}' exists in your Langfuse project\n"
            f"  2. The prompt has a version with label '{label}'\n"
            f"  3. Your API keys (secret_key, public_key) are from the SAME Langfuse "
            f"project where the prompt was created\n\n"
            f"Hint: Prompts are project-scoped in Langfuse. If you created the prompt "
            f"in a different project, you need to use that project's API keys."
        )
        super().__init__(message)
