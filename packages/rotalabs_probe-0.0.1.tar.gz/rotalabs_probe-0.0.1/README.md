# rotalabs-probe

Sandbagging detection via metacognitive probes from [Rotalabs](https://rotalabs.ai).

Detects when AI systems deliberately underperform or hide capabilities.

**This is a placeholder package. Full implementation coming soon.**

## Features (Planned)

- 90-96% detection accuracy
- Metacognitive probe architecture

## Links

- Website: https://rotalabs.ai
- GitHub: https://github.com/rotalabs/rotalabs-probe
- Contact: research@rotalabs.ai
