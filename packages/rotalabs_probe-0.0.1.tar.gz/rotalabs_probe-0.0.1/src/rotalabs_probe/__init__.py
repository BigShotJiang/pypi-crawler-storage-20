"""
rotalabs-probe - Sandbagging detection via metacognitive probes

https://rotalabs.ai
"""

__version__ = "0.0.1"
