"""Tests for dceapi package."""
