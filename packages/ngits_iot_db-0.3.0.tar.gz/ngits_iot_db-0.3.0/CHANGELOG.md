# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-01-15

### Added
- Data Warehouse (DWH) architecture implementation with Hybrid Star Schema
- New dimension models in `iot_db/models/dimensions/`:
  - `DimDataSource` - Dictionary of IoT data sources (sensorhub, chirpstack, supla)
  - `DimChannelFunction` - Device/channel function types with source mapping
  - `DimDevice` - Universal device registry with denormalization for performance and multi-channel support
  - `DimDate` - Date dimension for time-based analytics
- Multi-channel device support in `DimDevice` model:
  - `device_id` (Text) - Physical device ID shared across channels
  - `device_channel_id` (Text) - Device's channel ID
  - `device_name` (Text) - Physical device name (denormalized for performance)
  - `device_model` (Text) - Physical device model (denormalized for performance)
  - `parent_device_id` (Integer, FK) - Optional parent device for hierarchical organization
  - New indexes: `idx_device_device_id`, `idx_device_device_channel`
- Extended `RawMeasurement` model for DWH staging (replaces separate FactRawData table):
  - Added `processed_ts` - Timestamp when record was processed
  - Added `processing_error` - Error message if processing failed
  - Made `type` field nullable for backward compatibility with new DWH records
  - Added helper methods: `mark_as_processed()`, `mark_as_failed(error)`
  - Serves as unified staging area for both legacy models and DWH fact tables
- New fact models in `iot_db/models/facts/`:
  - `FactMeasurement` - Counter-based measurements for meters (electricity, water, heat, gas)
  - `FactState` - Device state snapshots for sensors and actuators
  - `FactUsage` - Pre-calculated consumption aggregates (hourly, daily, monthly, yearly)
- Migration tracking fields in `RawMeasurement` model:
  - `migrated_to_dwh` (Boolean, indexed) - Flag indicating if record was migrated to DWH
  - `migrated_ts` (DateTime) - Timestamp of migration to DWH
  - `mark_as_migrated()` method - Helper method for marking records as migrated
- Seed scripts for DWH (included in package):
  - `iot_db.scripts.seed_dimension_data` - Populates dimension tables
  - `iot_db.scripts.populate_dim_date` - Generates date dimension with Polish holidays support
  - Scripts can be run as modules: `python -m iot_db.scripts.seed_dimension_data`
  - Scripts can be imported as functions: `from iot_db.scripts import seed_dimension_data`

### Deprecated
- `DimDevice.external_id` is now deprecated in favor of `device_id`
  - Field kept for backward compatibility but should not be used in new code
  - Use `device_id` for device identification and `device_name` for display

## [0.2.6] - 2026-01-06

### Fixed
- Fixed missing `Sources` enum export in package `__init__.py`

## [0.2.5] - 2026-01-06

### Added
- Added `source` field to `RawMeasurement` model for tracking data source origin
- New `Sources` enum in base models with values: sensorhub (1), chirpstack (2), supla (3)
- `source_enum` property for convenient access to Sources enum on RawMeasurement
- Database migration `e0d5bb6c3974_add_source_field_to_rawmeasurement.py` adds source column with default value sensorhub

## [0.2.4] - 2025-08-13

### Added
- Added `Alert` model for storing active and resolved alert instances
- Alert model features:
  - `active_marker` for tracking alert status (NULL for resolved, True for active)
  - `detected_ts` for when alert was first detected
  - `resolved_ts` for when alert was resolved
  - `details` JSON field for flexible alert data storage
  - Unique constraint ensuring one active alert per device/type/level combination
  - Foreign key relationship to `AlertDefinition`
- Removed `device_name` from `AlertBase`, moved to `AlertDefinition` model

### Changed
- Alembic migration files formatted with isort and black for consistent code style

## [0.2.3] - 2025-08-13

### Added
- Added `receivers` field to `AlertDefinition` model for storing alert notification recipients as JSON
- Database migration `314a5d69646a_add_receivers_to_alert_definition.py` adds the receivers column

## [0.2.2] - 2025-08-05

### Changed
- Removed unique constraint on `alert_definition` table for `tenant` and `meter_id` columns
- Database migration `90c1158cc2ba_delete_alert_uniqueness.py` removes the uniqueness constraint

## [0.2.1] - 2025-08-04

### Fixed
- Fixed missing imports: Added `AlertLevels` and `AlertTypes` to package exports

## [0.2.0] - 2025-08-04

### Added
- Alert system models for IoT monitoring
- `AlertDefinition` model for defining alert rules with JSON properties
- `AlertBase` abstract base class with type, level, and device name fields
- New enum types for alert categorization:
  - `AlertTypes`: threshold_high, threshold_low, sudden_change, offline, data_gap, data_delayed, invalid_reading, stuck_value, noise
  - `AlertLevels`: emergency, critical, warning, info
- Database migration `0d7bea8f4d60_create_alerts_models.py` for alert_definition table

## [0.1.2] - 2025-07-31

### Changed
- **BREAKING**: Restructured package layout from `models.*` to `iot_db.models.*`
- Updated import paths: use `from iot_db.models import WaterMeasurement` instead of `from models import WaterMeasurement`
- Updated Alembic configuration to work with new package structure

### Migration Guide
- Change imports from `from models import *` to `from iot_db.models import *`
- All model classes remain the same, only import paths have changed

## [0.1.1] - 2025-07-31

### Fixed
- Fixed package metadata configuration for PyPI compatibility
- Resolved license file inclusion issues

### Changed
- Updated package name to `ngits-iot-db`
- Improved build configuration

## [0.1.0] - 2025-07-30

### Added
- Initial release of IoT Database Models
- SQLAlchemy models for IoT sensor data:
  - ElectricityMeasurement and usage models
  - WaterMeasurement and usage models  
  - HeatMeasurement and usage models
  - TemperatureMeasurement model
  - RawMeasurement model for unprocessed data
- Alembic migrations support with existing migration history
- Multi-tenant support via tenant UUID field
- Type-safe enums for sensor types (electricity, water, heat, temperature)
- Helper functions for model mapping
- Full type annotations with py.typed marker

### Features
- PostgreSQL backend support
- Automatic timestamping (created_ts, updated_ts)  
- Unique constraints to prevent duplicate measurements
- Daily and monthly usage aggregation models
- Raw sensor data storage with JSON fields
- External system integration support via external_id and meter_id

### Migration History Included
- 78371c256762_init_schema.py - Initial database schema
- fc391d505594_add_temperature.py - Temperature sensor support