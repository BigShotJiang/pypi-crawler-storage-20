"""
Main SecureX SDK client.
This is what developers import and use.
"""
import discord
from typing import Callable, Dict, List, Optional, Any
from pathlib import Path
import asyncio

from .models import ThreatEvent, BackupInfo, RestoreResult
from .backup.manager import BackupManager
from .utils.whitelist import WhitelistManager
from .utils.punishment import PunishmentExecutor
from .handlers.channel import ChannelHandler
from .handlers.role import RoleHandler
from .handlers.member import MemberHandler
from .handlers.webhook import WebhookHandler
from .handlers.role_monitor import RolePositionMonitor


class SecureX:
    """
    Main SDK client for anti-nuke protection.
    
    Example:
        ```python
        bot = commands.Bot(...)
        sx = SecureX(bot)
        
        @sx.on_threat_detected
        async def alert(threat: ThreatEvent):
            # Your custom UI here
            await channel.send(f"Threat: {threat.type}")
        
        bot.run("TOKEN")
        ```
    """
    
    def __init__(self, bot: discord.Client, backup_dir: Optional[Path] = None):
        """
        Initialize SecureX SDK.
        
        Args:
            bot: Discord bot instance
            backup_dir: Directory for backups (default: ./data/backups)
        """
        self.bot = bot
        self.backup_dir = backup_dir or Path("./data/backups")
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Callback registry
        self._callbacks: Dict[str, List[Callable]] = {
            'threat_detected': [],
            'backup_completed': [],
            'restore_completed': [],
            'whitelist_changed': [],
        }
        
        # Punishment configuration - defaults to no punishment
        self.punishments = {
            "channel_delete": "none",
            "channel_create": "none",
            "channel_update": "none",
            "role_delete": "none",
            "role_create": "none",
            "role_update": "none",
            "member_ban": "none",
            "member_kick": "none",
            "webhook_create": "none",
            "webhook_spam": "none"
        }
        self.timeout_duration = 600  # seconds (10 minutes)
        self.notify_punished_user = True
        
        # Initialize managers
        self.backup_manager = BackupManager(self)
        self.whitelist = WhitelistManager(self)
        self.punisher = PunishmentExecutor(self)
        
        # Initialize handlers
        self.channel_handler = ChannelHandler(self)
        self.role_handler = RoleHandler(self)
        self.member_handler = MemberHandler(self)
        self.webhook_handler = WebhookHandler(self)
        
        # Initialize role position monitor
        self.role_monitor = RolePositionMonitor(self)
        
        # Auto-register Discord events
        self._register_discord_events()
    
    def _register_discord_events(self):
        """Register all Discord event listeners"""
        # This replaces the old events/ directory approach
        # Now events are handled internally by the SDK
        
        @self.bot.event
        async def on_guild_channel_create(channel):
            await self.channel_handler.on_channel_create(channel)
        
        @self.bot.event  
        async def on_guild_channel_delete(channel):
            await self.channel_handler.on_channel_delete(channel)
        
        @self.bot.event
        async def on_guild_channel_update(before, after):
            await self.channel_handler.on_channel_update(before, after)
        
        @self.bot.event
        async def on_guild_role_create(role):
            await self.role_handler.on_role_create(role)
        
        @self.bot.event
        async def on_guild_role_delete(role):
            await self.role_handler.on_role_delete(role)
        
        @self.bot.event
        async def on_guild_role_update(before, after):
            await self.role_handler.on_role_update(before, after)
        
        @self.bot.event
        async def on_webhooks_update(channel):
            await self.webhook_handler.on_webhooks_update(channel)
        
        @self.bot.event
        async def on_member_join(member):
            await self.member_handler.on_member_join(member)
        
        @self.bot.event
        async def on_member_ban(guild, user):
            await self.member_handler.on_member_ban(guild, user)
        
        @self.bot.event
        async def on_member_remove(member):
            await self.member_handler.on_member_remove(member)
    
    # Callback decorators
    def on_threat_detected(self, callback: Callable):
        """
        Register callback for threat detection.
        
        Args:
            callback: Async function that receives ThreatEvent
        
        Example:
            ```python
            @sx.on_threat_detected
            async def handle(threat: ThreatEvent):
                print(f"Detected: {threat.type}")
            ```
        """
        self._callbacks['threat_detected'].append(callback)
        return callback
    
    def on_backup_completed(self, callback: Callable):
        """Register callback for backup completion"""
        self._callbacks['backup_completed'].append(callback)
        return callback
    
    def on_restore_completed(self, callback: Callable):
        """Register callback for restore completion"""
        self._callbacks['restore_completed'].append(callback)
        return callback
    
    def on_whitelist_changed(self, callback: Callable):
        """Register callback for whitelist changes"""
        self._callbacks['whitelist_changed'].append(callback)
        return callback
    
    async def _trigger_callbacks(self, event_name: str, data: Any):
        """Trigger all registered callbacks for an event"""
        if event_name in self._callbacks:
            for callback in self._callbacks[event_name]:
                try:
                    await callback(data)
                except Exception as e:
                    # Log but don't crash if user's callback fails
                    print(f"Error in callback {callback.__name__}: {e}")
    
    # Public API methods
    async def enable(
        self, 
        guild_id: int = None, 
        whitelist: Optional[List[int]] = None, 
        auto_backup: bool = True, 
        role_position_monitoring: bool = True,
        punishments: Dict[str, str] = None,
        timeout_duration: int = 600,
        notify_user: bool = True
    ):
        """
        Enable anti-nuke protection with punishment configuration.
        
        Args:
            guild_id: Specific guild to enable for (if None, must add via whitelist per-guild)
            whitelist: List of user IDs to whitelist for this guild
            auto_backup: Enable automatic backups
            role_position_monitoring: Enable continuous 5-second role position checks
            punishments: Dict mapping violation types to punishment actions
                Example: {"channel_delete": "ban", "role_create": "kick"}
                Available actions: "none", "warn", "timeout", "kick", "ban"
            timeout_duration: Duration in seconds for timeout punishment (default: 600)
            notify_user: Whether to DM violators about punishment (default: True)
        """
        if whitelist and guild_id:
            for user_id in whitelist:
                await self.whitelist.add(guild_id, user_id)
        
        if auto_backup:
            # Start backup task (will be implemented in BackupManager)
            self.backup_manager.start_auto_backup()
        
        if role_position_monitoring:
            # Start role position monitoring
            self.role_monitor.start()
        
        # Update punishment config
        if punishments:
            self.punishments.update(punishments)
        
        self.timeout_duration = timeout_duration
        self.notify_punished_user = notify_user
        
        # Log enabled features
        if punishments:
            enabled_punishments = {k: v for k, v in self.punishments.items() if v != "none"}
            if enabled_punishments:
                print(f"⚠️  Punishments configured for {len(enabled_punishments)} violation types")
    
    async def create_backup(self, guild_id: int) -> BackupInfo:
        """
        Manually create a backup for a guild.
        
        Args:
            guild_id: Guild to backup
        
        Returns:
            BackupInfo with backup details
        """
        return await self.backup_manager.create_backup(guild_id)
    
    async def get_recent_threats(self, guild_id: int, limit: int = 10) -> List[ThreatEvent]:
        """
        Get recent threats for a guild.
        
        Args:
            guild_id: Guild ID
            limit: Maximum number of threats to return
        
        Returns:
            List of ThreatEvent objects
        """
        # This would read from threat history file
        # For now, return empty list (implement in handler)
        return []
