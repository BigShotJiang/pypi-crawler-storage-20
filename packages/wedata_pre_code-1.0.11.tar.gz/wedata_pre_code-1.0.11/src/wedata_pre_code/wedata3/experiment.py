import http
import os
import hashlib
import hmac
import json
import time
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from http.client import HTTPSConnection, HTTPException
from mlflow.protos.databricks_pb2 import  ABORTED, BAD_REQUEST
from mlflow import MlflowException


__doc__ = """
实验相关云API接口
"""


def _set_request_header(headers: Optional[Dict[str, str]]) -> Dict[str, str]:
    if headers is None:
        headers = {}

    if "IS_WEDATA_TEST" in os.environ.keys():
        headers["X-Qcloud-User-Id"] = os.environ["TEST_USER_ID"]

    return headers


def _get_endpoint() -> str:
    endpoint = os.getenv("TENCENTCLOUD_ENDPOINT")
    if endpoint is None:
        endpoint = "wedata.internal.tencentcloudapi.com"

    return endpoint


class _DataScienceApi(object):
    _version = "2025-10-10"
    _service = "wedata"

    def __init__(self, region: str, secret_id: str, secret_key: str, token: Optional[str] = None) -> None:
        self._host = _get_endpoint()
        self._region = region
        self._secret_id = secret_id
        self._secret_key = secret_key
        self._token = token

    def _sign(self, action: str, body: str, timestamp: int) -> str:
        """http请求签名"""
        algorithm = "TC3-HMAC-SHA256"
        date = datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%d")

        # ************* 步骤 1：拼接规范请求串 *************
        http_request_method = "POST"
        canonical_uri = "/"
        canonical_querystring = ""
        ct = "application/json; charset=utf-8"
        canonical_headers = "content-type:%s\nhost:%s\nx-tc-action:%s\n" % (ct, self._host, action.lower())
        signed_headers = "content-type;host;x-tc-action"
        hashed_request_payload = hashlib.sha256(body.encode("utf-8")).hexdigest()
        canonical_request = (http_request_method + "\n" +
                             canonical_uri + "\n" +
                             canonical_querystring + "\n" +
                             canonical_headers + "\n" +
                             signed_headers + "\n" +
                             hashed_request_payload)

        # ************* 步骤 2：拼接待签名字符串 *************
        credential_scope = date + "/" + self._service + "/" + "tc3_request"
        hashed_canonical_request = hashlib.sha256(canonical_request.encode("utf-8")).hexdigest()
        string_to_sign = (algorithm + "\n" +
                          str(timestamp) + "\n" +
                          credential_scope + "\n" +
                          hashed_canonical_request)

        # ************* 步骤 3：计算签名 *************
        secret_date = hmac.new(("TC3" + self._secret_key).encode("utf-8"), date.encode("utf-8"), hashlib.sha256).digest()
        secret_service = hmac.new(secret_date, self._service.encode("utf-8"), hashlib.sha256).digest()
        secret_signing = hmac.new(secret_service, "tc3_request".encode("utf-8"), hashlib.sha256).digest()
        signature = hmac.new(secret_signing, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

        # ************* 步骤 4：拼接 Authorization *************
        authorization = (algorithm + " " +
                         "Credential=" + self._secret_id + "/" + credential_scope + ", " +
                         "SignedHeaders=" + signed_headers + ", " +
                         "Signature=" + signature)

        return authorization

    def _request(self, action: str, payload: Dict[str, Any], headers: Dict[str, str]):
        body = json.dumps(payload)
        timestamp = int(time.time())
        authorization = self._sign(action, body, timestamp)

        headers.update({
            "Authorization": authorization,
            "Content-Type": "application/json; charset=utf-8",
            "Host": self._host,
            "X-TC-Action": action,
            "X-TC-Timestamp": str(timestamp),
            "X-TC-Version": self._version,
        })
        if self._region:
            headers["X-TC-Region"] = self._region
        if self._token:
            headers["X-TC-Token"] = self._token

        req = HTTPSConnection(self._host, timeout=30)
        try:
            req.request("POST", "/", headers=headers, body=body.encode("utf-8"))
            resp = req.getresponse()
        finally:
            req.close()
        content = resp.read().decode("utf-8")

        # check http status
        if resp.status != http.HTTPStatus.OK:
            raise HTTPException(f"ServerNetworkError, message: {content}")
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            raise HTTPException(f"ServerNetworkError, message: {content}")

        # check error
        if "Error" in data["Response"]:
            code = data["Response"]["Error"]["Code"]
            message = data["Response"]["Error"]["Message"]
            req_id = data["Response"]["RequestId"]
            raise HTTPException(f"code:{code} message:{message} requestId:{req_id}")

        return data

    def create_experiment(self, body: Dict[str, Any], headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        headers = _set_request_header(headers)
        resp = self._request("CreateExperiment", body, headers)

        return resp

    def rename_experiment(self, body: Dict[str, Any], headers: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        headers = _set_request_header(headers)
        resp = self._request("UpdateExperimentName", body, headers)

        return resp


def _get_client() -> _DataScienceApi:
    region = os.environ["KERNEL_WEDATA_REGION"]
    secret_id = os.environ["KERNEL_WEDATA_CLOUD_SDK_SECRET_ID"]
    secret_key = os.environ["KERNEL_WEDATA_CLOUD_SDK_SECRET_KEY"]
    token = os.environ["KERNEL_WEDATA_CLOUD_SDK_SECRET_TOKEN"]
    _client = _DataScienceApi(region, secret_id, secret_key, token)
    return _client


def _create_experiment(
        self, name: str,
        artifact_location: Optional[str] = None,
        tags: Optional[dict[str, Any]] = None,
) -> str:
    req_body = {
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
        "Name": name,
        "Type": "MACHINE_LEARNING",
        "Tags": [{"Key": key, "Value": value} for key, value in (tags or {}).items()]
    }
    _client = _get_client()
    resp = _client.create_experiment(req_body)
    return resp["Response"]["Data"]["ExperimentId"]

def _rename_experiment(self, experiment_id: str, new_name: str) -> None:
    req_body = {
        "NewName": new_name,
        "ExperimentId": experiment_id,
        "WorkspaceId": os.environ["WEDATA_WORKSPACE_ID"],
    }
    _client = _get_client()
    resp = _client.rename_experiment(req_body)
    if not resp["Response"]["Data"]["Status"]:
        raise MlflowException("Failed to rename the experiment", BAD_REQUEST)

def _restore_experiment(self, experiment_id: str) -> None:
    raise MlflowException("Please go to the WeData console to restore the experiment; "
                            "this operation is prohibited in scripts.", ABORTED)

def _delete_experiment(self, experiment_id: str) -> None:
    raise MlflowException("Please go to the WeData console to delete the experiment; "
                            "this operation is prohibited in scripts.", ABORTED)
