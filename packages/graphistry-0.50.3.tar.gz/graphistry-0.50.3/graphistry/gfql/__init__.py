"""GFQL helpers."""
