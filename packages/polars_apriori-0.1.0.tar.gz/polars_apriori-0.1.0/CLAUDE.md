# CLAUDE.md

## Project Overview

Polars-based implementation of the Apriori algorithm for association rule mining.

**Goal:** 10-15x memory reduction compared to `efficient-apriori` by using Polars' native List types.

## Session Start

Read `CONTEXT.md` for the full background and motivation.

## Key Files

| File | Contents |
|------|----------|
| `CONTEXT.md` | Origin, analysis, conceptual implementation |
| `src/polars_apriori/` | Main implementation |
| `benchmarks/` | Comparison with efficient-apriori |
| `tests/` | pytest test suite |

## Development Commands

```bash
# Setup
uv venv && source .venv/bin/activate
uv pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Run benchmarks
python benchmarks/compare.py

# Memory profiling
python -m tracemalloc benchmarks/memory_test.py
```
