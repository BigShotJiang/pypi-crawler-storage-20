# benchmarks/compare.py
import tracemalloc
import time
import random
import polars as pl
from efficient_apriori import apriori as ea_apriori

# Import from installed package or local
import sys
sys.path.insert(0, "/home/et/personal-projects/polars-apriori/src")
from polars_apriori import apriori as pa_apriori


def generate_transactions(n_transactions: int, n_items: int, avg_items_per_tx: int) -> list[tuple]:
    """Generate random transactions for benchmarking."""
    transactions = []
    for _ in range(n_transactions):
        n_items_in_tx = random.randint(1, avg_items_per_tx * 2)
        tx = tuple(random.sample(range(1, n_items + 1), min(n_items_in_tx, n_items)))
        transactions.append(tx)
    return transactions


def benchmark(n_transactions: int, n_items: int, min_support: float):
    """Run benchmark comparing efficient-apriori and polars-apriori."""
    print(f"\n{'='*60}")
    print(f"Benchmark: {n_transactions} transactions, {n_items} items, min_support={min_support}")
    print(f"{'='*60}")

    # Generate test data
    transactions_list = generate_transactions(n_transactions, n_items, avg_items_per_tx=5)

    # Convert to Polars format
    transactions_df = pl.DataFrame({
        "items": [list(tx) for tx in transactions_list]
    })

    # efficient-apriori benchmark
    tracemalloc.start()
    t0 = time.perf_counter()
    ea_itemsets, ea_rules = ea_apriori(transactions_list, min_support)
    ea_time = time.perf_counter() - t0
    ea_memory = tracemalloc.get_traced_memory()[1]  # Peak memory
    tracemalloc.stop()

    ea_count = sum(len(v) for v in ea_itemsets.values())

    # polars-apriori benchmark
    tracemalloc.start()
    t0 = time.perf_counter()
    pa_result = pa_apriori(transactions_df, min_support)
    pa_time = time.perf_counter() - t0
    pa_memory = tracemalloc.get_traced_memory()[1]  # Peak memory
    tracemalloc.stop()

    pa_count = pa_result.height

    # Results
    print(f"\nefficient-apriori:")
    print(f"  Time: {ea_time:.3f}s")
    print(f"  Peak memory: {ea_memory/1e6:.2f} MB")
    print(f"  Itemsets found: {ea_count}")

    print(f"\npolars-apriori:")
    print(f"  Time: {pa_time:.3f}s")
    print(f"  Peak memory: {pa_memory/1e6:.2f} MB")
    print(f"  Itemsets found: {pa_count}")

    print(f"\nComparison:")
    if pa_memory > 0:
        print(f"  Memory ratio: {ea_memory/pa_memory:.1f}x (efficient-apriori / polars-apriori)")
    print(f"  Speed ratio: {ea_time/pa_time:.2f}x")
    print(f"  Itemsets match: {ea_count == pa_count}")

    return {
        "ea_time": ea_time, "ea_memory": ea_memory, "ea_count": ea_count,
        "pa_time": pa_time, "pa_memory": pa_memory, "pa_count": pa_count
    }


if __name__ == "__main__":
    random.seed(42)  # Reproducibility

    print("Polars-Apriori vs Efficient-Apriori Benchmark")
    print("=" * 60)

    print("\n" + "=" * 60)
    print("SCENARIO A: Dense data (many frequent itemsets expected)")
    print("=" * 60)

    # Dense data: fewer items = higher support per item = more frequent itemsets
    benchmark(n_transactions=1000, n_items=30, min_support=0.05)
    benchmark(n_transactions=10_000, n_items=30, min_support=0.05)
    benchmark(n_transactions=100_000, n_items=30, min_support=0.05)

    print("\n" + "=" * 60)
    print("SCENARIO B: Sparse data (few/no frequent itemsets expected)")
    print("=" * 60)

    # Sparse data: many items = lower support per item = fewer frequent itemsets
    benchmark(n_transactions=10_000, n_items=100, min_support=0.1)
    benchmark(n_transactions=100_000, n_items=500, min_support=0.05)
    benchmark(n_transactions=1_000_000, n_items=1000, min_support=0.01)

    print("\n" + "=" * 60)
    print("SCENARIO C: Extreme scale test")
    print("=" * 60)

    # Large scale with dense data
    benchmark(n_transactions=1_000_000, n_items=50, min_support=0.05)
