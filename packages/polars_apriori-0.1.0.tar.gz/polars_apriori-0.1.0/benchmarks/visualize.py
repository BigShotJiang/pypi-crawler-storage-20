# benchmarks/visualize.py
"""Visualization of benchmark results comparing polars-apriori vs efficient-apriori."""

import tracemalloc
import time
import random
import polars as pl
import matplotlib.pyplot as plt
import numpy as np
from efficient_apriori import apriori as ea_apriori

import sys
sys.path.insert(0, "/home/et/personal-projects/polars-apriori/src")
from polars_apriori import apriori as pa_apriori


def generate_transactions(n_transactions: int, n_items: int, avg_items_per_tx: int = 5) -> list[tuple]:
    """Generate random transactions for benchmarking."""
    transactions = []
    for _ in range(n_transactions):
        n_items_in_tx = random.randint(1, avg_items_per_tx * 2)
        tx = tuple(random.sample(range(1, n_items + 1), min(n_items_in_tx, n_items)))
        transactions.append(tx)
    return transactions


def run_benchmark(n_transactions: int, n_items: int, min_support: float) -> dict:
    """Run a single benchmark and return results."""
    transactions_list = generate_transactions(n_transactions, n_items)
    transactions_df = pl.DataFrame({"items": [list(tx) for tx in transactions_list]})

    # efficient-apriori
    tracemalloc.start()
    tracemalloc.reset_peak()
    t0 = time.perf_counter()
    ea_itemsets, _ = ea_apriori(transactions_list, min_support)
    ea_time = time.perf_counter() - t0
    ea_memory = tracemalloc.get_traced_memory()[1] / 1e6  # MB
    tracemalloc.stop()
    ea_count = sum(len(v) for v in ea_itemsets.values())

    # polars-apriori
    tracemalloc.start()
    tracemalloc.reset_peak()
    t0 = time.perf_counter()
    pa_result = pa_apriori(transactions_df, min_support)
    pa_time = time.perf_counter() - t0
    pa_memory = tracemalloc.get_traced_memory()[1] / 1e6  # MB
    tracemalloc.stop()

    return {
        "n_transactions": n_transactions,
        "n_items": n_items,
        "min_support": min_support,
        "ea_time": ea_time,
        "ea_memory": ea_memory,
        "ea_count": ea_count,
        "pa_time": pa_time,
        "pa_memory": pa_memory,
        "pa_count": pa_result.height,
        "memory_ratio": ea_memory / pa_memory if pa_memory > 0 else float('inf'),
        "speed_ratio": ea_time / pa_time if pa_time > 0 else float('inf'),
    }


def create_visualizations():
    """Create benchmark visualizations and save to files."""
    random.seed(42)

    print("Running benchmarks for visualization...")
    print("=" * 60)

    # Run benchmarks at different scales
    results = []

    # Scenario A: Varying transaction count (sparse data - few items found)
    print("\nScenario A: Scaling transactions (sparse data)")
    for n_tx in [10_000, 50_000, 100_000, 500_000, 1_000_000]:
        print(f"  Running {n_tx:,} transactions...")
        result = run_benchmark(n_tx, n_items=100, min_support=0.1)
        result["scenario"] = "sparse"
        results.append(result)

    # Scenario B: Dense data (many itemsets found)
    print("\nScenario B: Scaling transactions (dense data)")
    for n_tx in [10_000, 50_000, 100_000]:
        print(f"  Running {n_tx:,} transactions...")
        result = run_benchmark(n_tx, n_items=30, min_support=0.05)
        result["scenario"] = "dense"
        results.append(result)

    # Create figure with subplots
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle("polars-apriori vs efficient-apriori Benchmark", fontsize=16, fontweight='bold')

    # Color scheme
    ea_color = '#e74c3c'  # Red
    pa_color = '#3498db'  # Blue

    # Plot 1: Memory comparison (sparse)
    ax1 = axes[0, 0]
    sparse_results = [r for r in results if r["scenario"] == "sparse"]
    x_labels = [f"{r['n_transactions']//1000}K" for r in sparse_results]
    x = np.arange(len(x_labels))
    width = 0.35

    bars1 = ax1.bar(x - width/2, [r["ea_memory"] for r in sparse_results], width,
                    label='efficient-apriori', color=ea_color, alpha=0.8)
    bars2 = ax1.bar(x + width/2, [r["pa_memory"] for r in sparse_results], width,
                    label='polars-apriori', color=pa_color, alpha=0.8)

    ax1.set_ylabel('Peak Memory (MB)', fontsize=11)
    ax1.set_xlabel('Transactions', fontsize=11)
    ax1.set_title('Memory Usage (Sparse Data)', fontsize=12)
    ax1.set_xticks(x)
    ax1.set_xticklabels(x_labels)
    ax1.legend()
    ax1.set_yscale('log')

    # Add ratio annotations
    for i, r in enumerate(sparse_results):
        ratio = r["memory_ratio"]
        if ratio > 1:
            ax1.annotate(f'{ratio:.0f}x', xy=(i, max(r["ea_memory"], r["pa_memory"])),
                        xytext=(0, 5), textcoords='offset points', ha='center', fontsize=9,
                        fontweight='bold', color='#27ae60')

    # Plot 2: Speed comparison (sparse)
    ax2 = axes[0, 1]
    bars1 = ax2.bar(x - width/2, [r["ea_time"] for r in sparse_results], width,
                    label='efficient-apriori', color=ea_color, alpha=0.8)
    bars2 = ax2.bar(x + width/2, [r["pa_time"] for r in sparse_results], width,
                    label='polars-apriori', color=pa_color, alpha=0.8)

    ax2.set_ylabel('Time (seconds)', fontsize=11)
    ax2.set_xlabel('Transactions', fontsize=11)
    ax2.set_title('Execution Time (Sparse Data)', fontsize=12)
    ax2.set_xticks(x)
    ax2.set_xticklabels(x_labels)
    ax2.legend()

    # Plot 3: Memory comparison (dense)
    ax3 = axes[1, 0]
    dense_results = [r for r in results if r["scenario"] == "dense"]
    x_labels_dense = [f"{r['n_transactions']//1000}K" for r in dense_results]
    x_dense = np.arange(len(x_labels_dense))

    bars1 = ax3.bar(x_dense - width/2, [r["ea_memory"] for r in dense_results], width,
                    label='efficient-apriori', color=ea_color, alpha=0.8)
    bars2 = ax3.bar(x_dense + width/2, [r["pa_memory"] for r in dense_results], width,
                    label='polars-apriori', color=pa_color, alpha=0.8)

    ax3.set_ylabel('Peak Memory (MB)', fontsize=11)
    ax3.set_xlabel('Transactions', fontsize=11)
    ax3.set_title('Memory Usage (Dense Data - With Frequent Itemsets)', fontsize=12)
    ax3.set_xticks(x_dense)
    ax3.set_xticklabels(x_labels_dense)
    ax3.legend()

    # Add ratio annotations
    for i, r in enumerate(dense_results):
        ratio = r["memory_ratio"]
        if ratio > 1:
            ax3.annotate(f'{ratio:.0f}x', xy=(i, max(r["ea_memory"], r["pa_memory"])),
                        xytext=(0, 5), textcoords='offset points', ha='center', fontsize=9,
                        fontweight='bold', color='#27ae60')

    # Plot 4: Speed comparison (dense)
    ax4 = axes[1, 1]
    bars1 = ax4.bar(x_dense - width/2, [r["ea_time"] for r in dense_results], width,
                    label='efficient-apriori', color=ea_color, alpha=0.8)
    bars2 = ax4.bar(x_dense + width/2, [r["pa_time"] for r in dense_results], width,
                    label='polars-apriori', color=pa_color, alpha=0.8)

    ax4.set_ylabel('Time (seconds)', fontsize=11)
    ax4.set_xlabel('Transactions', fontsize=11)
    ax4.set_title('Execution Time (Dense Data - With Frequent Itemsets)', fontsize=12)
    ax4.set_xticks(x_dense)
    ax4.set_xticklabels(x_labels_dense)
    ax4.legend()

    # Add itemset count annotations
    for i, r in enumerate(dense_results):
        ax4.annotate(f'{r["ea_count"]} itemsets', xy=(i, max(r["ea_time"], r["pa_time"])),
                    xytext=(0, 5), textcoords='offset points', ha='center', fontsize=8)

    plt.tight_layout()
    plt.savefig('benchmarks/benchmark_results.png', dpi=150, bbox_inches='tight')
    print(f"\n✅ Saved: benchmarks/benchmark_results.png")

    # Create a summary text file
    with open('benchmarks/benchmark_summary.txt', 'w') as f:
        f.write("Polars-Apriori Benchmark Summary\n")
        f.write("=" * 60 + "\n\n")

        f.write("SPARSE DATA (few/no frequent itemsets)\n")
        f.write("-" * 40 + "\n")
        for r in sparse_results:
            f.write(f"{r['n_transactions']:>10,} tx: Memory {r['memory_ratio']:>8.0f}x, Speed {r['speed_ratio']:>6.1f}x\n")

        f.write("\nDENSE DATA (many frequent itemsets)\n")
        f.write("-" * 40 + "\n")
        for r in dense_results:
            f.write(f"{r['n_transactions']:>10,} tx: Memory {r['memory_ratio']:>8.0f}x, Speed {r['speed_ratio']:>6.1f}x, {r['ea_count']} itemsets\n")

        f.write("\n" + "=" * 60 + "\n")
        f.write("Key Insight: polars-apriori uses 100-50,000x less memory,\n")
        f.write("but may be ~2x slower when many itemsets are found.\n")

    print(f"✅ Saved: benchmarks/benchmark_summary.txt")

    # Also show the plot
    plt.show()

    return results


if __name__ == "__main__":
    create_visualizations()
