def main():
    print("Hello from polars-apriori!")

if __name__ == "__main__":
    main()
