"""Tests for the apriori() function."""

import polars as pl
import pytest

from polars_apriori import apriori


class TestAprioriBasic:
    """Basic functionality tests for apriori()."""

    def test_apriori_basic(self, sample_transactions):
        """Test basic apriori with standard parameters."""
        result = apriori(sample_transactions, min_support=0.5)

        # Should find items 1, 2, 3 and pairs [1,3], [2,3]
        assert result.height == 5

        # Check schema
        assert "itemset" in result.columns
        assert "support" in result.columns
        assert result.schema["itemset"] == pl.List(pl.Int64)
        assert result.schema["support"] == pl.Float64

        # Verify specific supports
        itemsets = {tuple(row["itemset"]): row["support"] for row in result.iter_rows(named=True)}
        assert (3,) in itemsets
        assert itemsets[(3,)] == 1.0  # Item 3 in all transactions
        assert (2, 3) in itemsets
        assert itemsets[(2, 3)] == 0.75

    def test_apriori_high_support_empty_result(self, sample_transactions):
        """Test that high min_support returns empty DataFrame."""
        result = apriori(sample_transactions, min_support=1.1)

        assert result.height == 0
        assert "itemset" in result.columns
        assert "support" in result.columns

    def test_apriori_low_support_all_frequent(self, sample_transactions):
        """Test that min_support=0 returns all possible itemsets."""
        result = apriori(sample_transactions, min_support=0.0)

        # Should include items 4 and 5 (support=0.25)
        itemsets = [tuple(row["itemset"]) for row in result.iter_rows(named=True)]
        assert (4,) in itemsets
        assert (5,) in itemsets

    def test_apriori_support_at_boundary(self, sample_transactions):
        """Test min_support exactly at item support boundary."""
        # Item 1 has support=0.5
        result = apriori(sample_transactions, min_support=0.5)
        itemsets = [tuple(row["itemset"]) for row in result.iter_rows(named=True)]
        assert (1,) in itemsets

        # With support just above 0.5, item 1 should be excluded
        result = apriori(sample_transactions, min_support=0.51)
        itemsets = [tuple(row["itemset"]) for row in result.iter_rows(named=True)]
        assert (1,) not in itemsets


class TestAprioriParameters:
    """Tests for apriori() parameters."""

    def test_apriori_max_length(self, sample_transactions):
        """Test max_length parameter limits itemset size."""
        result = apriori(sample_transactions, min_support=0.5, max_length=1)

        lengths = [len(row["itemset"]) for row in result.iter_rows(named=True)]
        assert all(length == 1 for length in lengths)
        assert result.height == 3  # Items 1, 2, 3

    def test_apriori_max_length_two(self, sample_transactions):
        """Test max_length=2 allows pairs but not triplets."""
        result = apriori(sample_transactions, min_support=0.25, max_length=2)

        lengths = [len(row["itemset"]) for row in result.iter_rows(named=True)]
        assert max(lengths) <= 2

    def test_apriori_custom_column(self, custom_column_transactions):
        """Test item_col parameter with custom column name."""
        result = apriori(
            custom_column_transactions,
            min_support=0.5,
            item_col="products"
        )

        assert result.height > 0
        itemsets = [tuple(row["itemset"]) for row in result.iter_rows(named=True)]
        assert (20,) in itemsets  # Item 20 appears in all 3 transactions


class TestAprioriEdgeCases:
    """Edge case tests for apriori()."""

    def test_apriori_single_transaction(self, single_transaction):
        """Test with only one transaction."""
        result = apriori(single_transaction, min_support=0.5)

        # All items have support=1.0 in single transaction
        assert result.height > 0
        supports = result["support"].to_list()
        assert all(s == 1.0 for s in supports)

    def test_apriori_empty_dataframe(self, empty_transactions):
        """Test with empty DataFrame."""
        result = apriori(empty_transactions, min_support=0.5)

        assert result.height == 0
        assert "itemset" in result.columns
        assert "support" in result.columns

    def test_apriori_output_schema(self, sample_transactions):
        """Verify output DataFrame has correct schema."""
        result = apriori(sample_transactions, min_support=0.5)

        expected_schema = {
            "itemset": pl.List(pl.Int64),
            "support": pl.Float64
        }
        assert result.schema == expected_schema

    def test_apriori_itemsets_sorted(self, sample_transactions):
        """Verify itemsets are internally sorted."""
        result = apriori(sample_transactions, min_support=0.5)

        for row in result.iter_rows(named=True):
            itemset = row["itemset"]
            assert itemset == sorted(itemset), f"Itemset {itemset} is not sorted"
