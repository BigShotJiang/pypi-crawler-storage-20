"""Apriori algorithm implementation using Polars.

This module contains the main apriori function for finding frequent itemsets.

Transaction Format (input):
    transactions = pl.DataFrame({
        "transaction_id": [1, 2, 3],
        "items": [[1, 2, 3], [2, 3, 4], [1, 3, 5]]  # List[i32]
    })

Frequent Itemsets Format (output):
    frequent_itemsets = pl.DataFrame({
        "itemset": [[1], [2], [3], [1, 2], [2, 3]],  # List[i32]
        "support": [0.67, 1.0, 1.0, 0.33, 0.67]
    })
"""

import polars as pl
from .itemsets import _frequent_1_itemsets, _generate_candidates, _count_support


def apriori(
    transactions: pl.DataFrame,
    min_support: float = 0.5,
    max_length: int | None = None,
    item_col: str = "items"
) -> pl.DataFrame:
    """
    Find frequent itemsets using the Apriori algorithm.

    Args:
        transactions: DataFrame with item_col containing List[Int64]
        min_support: Minimum support threshold (0.0-1.0)
        max_length: Maximum itemset length (None = unlimited)
        item_col: Name of the items column

    Returns:
        DataFrame with columns: itemset (List[Int64]), support (Float64)
    """
    all_frequent = []

    # Phase 1: Frequent 1-itemsets
    frequent_k = _frequent_1_itemsets(transactions, min_support, item_col)
    all_frequent.append(frequent_k)

    k = 1
    while frequent_k.height > 0:
        if max_length and k >= max_length:
            break

        # Generate k+1 candidates
        candidates = _generate_candidates(frequent_k, k)

        if candidates.height == 0:
            break

        # Count support
        frequent_k = _count_support(candidates, transactions, min_support, item_col)

        if frequent_k.height > 0:
            all_frequent.append(frequent_k)

        k += 1

    # Handle edge case: if no frequent itemsets found, return empty DataFrame with correct schema
    if not all_frequent or all(df.height == 0 for df in all_frequent):
        return pl.DataFrame({
            "itemset": pl.Series([], dtype=pl.List(pl.Int64)),
            "support": pl.Series([], dtype=pl.Float64)
        })

    return pl.concat(all_frequent)
