"""Polars-based implementation of the Apriori algorithm for association rule mining.

This package provides memory-efficient association rule mining using Polars'
native List types, achieving ~15x memory reduction compared to traditional
Python implementations using frozensets.

Example:
    >>> import polars as pl
    >>> from polars_apriori import apriori, generate_rules
    >>>
    >>> # Create transactions DataFrame
    >>> transactions = pl.DataFrame({
    ...     "transaction_id": [1, 2, 3],
    ...     "items": [[1, 2, 3], [2, 3, 4], [1, 3, 5]]  # List[i32]
    ... })
    >>>
    >>> # Find frequent itemsets
    >>> itemsets = apriori(transactions, min_support=0.5)
    >>>
    >>> # Generate association rules
    >>> rules = generate_rules(itemsets, min_confidence=0.7)
"""

from polars_apriori.apriori import apriori
from polars_apriori.rules import generate_rules

__all__ = ["apriori", "generate_rules"]
__version__ = "0.1.0"
