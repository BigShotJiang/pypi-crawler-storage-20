"""Itemset operations and utilities.

This module contains helper functions for itemset manipulation,
candidate generation, and support counting.
"""

import polars as pl


def _frequent_1_itemsets(
    transactions: pl.DataFrame,
    min_support: float,
    item_col: str = "items"
) -> pl.DataFrame:
    """Find all frequent 1-itemsets in the transaction database.

    Args:
        transactions: DataFrame with a column containing transaction items as lists.
        min_support: Minimum support threshold (between 0 and 1).
        item_col: Name of the column containing item lists.

    Returns:
        DataFrame with columns:
            - itemset: List[Int64] containing a single item
            - support: Float64 support value
    """
    n_transactions = transactions.height

    return (
        transactions
        .select(pl.col(item_col).explode())
        .group_by(item_col)
        .agg(pl.len().alias("count"))
        .with_columns(
            (pl.col("count") / n_transactions).alias("support")
        )
        .filter(pl.col("support") >= min_support)
        .with_columns(
            pl.col(item_col).map_elements(lambda x: [x], return_dtype=pl.List(pl.Int64)).alias("itemset")
        )
        .select(["itemset", "support"])
    )


def _generate_candidates(
    frequent_k: pl.DataFrame,
    k: int
) -> pl.DataFrame:
    """Generate k+1 itemset candidates from frequent k-itemsets.

    Uses prefix-based self-join to generate candidates. Two k-itemsets
    can be joined if they share the same k-1 prefix.

    Args:
        frequent_k: DataFrame with frequent k-itemsets (column "itemset").
        k: Size of current itemsets.

    Returns:
        DataFrame with column "itemset" containing candidate (k+1)-itemsets.
    """
    # Sort itemsets for consistent prefix comparison
    sorted_itemsets = frequent_k.with_columns(
        pl.col("itemset").list.sort()
    )

    # Add prefix column (first k-1 items) and last item
    with_prefix = sorted_itemsets.with_columns(
        pl.col("itemset").list.head(k - 1).alias("prefix"),
        pl.col("itemset").list.tail(1).list.first().alias("last_item")
    )

    # Self-join on prefix
    candidates = (
        with_prefix.join(
            with_prefix,
            on="prefix",
            suffix="_right"
        )
        .filter(pl.col("last_item") < pl.col("last_item_right"))
        .with_columns(
            pl.col("itemset").list.concat(
                pl.col("last_item_right").map_elements(lambda x: [x], return_dtype=pl.List(pl.Int64))
            ).alias("candidate")
        )
        .select(["candidate"])
        .rename({"candidate": "itemset"})
    )

    return candidates


def _count_support(
    candidates: pl.DataFrame,
    transactions: pl.DataFrame,
    min_support: float,
    item_col: str = "items"
) -> pl.DataFrame:
    """Count support for candidate itemsets and filter by minimum support.

    For each candidate itemset, counts how many transactions contain all items
    in the itemset (i.e., the itemset is a subset of the transaction).

    Uses lazy evaluation with streaming engine for memory-efficient processing
    of large datasets.

    Args:
        candidates: DataFrame with column "itemset" containing candidate itemsets.
        transactions: DataFrame with a column containing transaction items as lists.
        min_support: Minimum support threshold (between 0 and 1).
        item_col: Name of the column containing item lists.

    Returns:
        DataFrame with columns:
            - itemset: List[Int64] containing the itemset
            - support: Float64 support value
        Only itemsets meeting min_support are returned.
    """
    n_transactions = transactions.height

    # Use lazy evaluation with streaming for memory-efficient cross join
    # The streaming engine processes data in batches, avoiding OOM on large datasets
    return (
        candidates.lazy()
        .join(transactions.lazy(), how="cross")
        .with_columns(
            # Check: is candidate a subset of transaction?
            (pl.col("itemset").list.set_difference(pl.col(item_col)).list.len() == 0)
            .alias("is_subset")
        )
        .filter(pl.col("is_subset"))
        .group_by("itemset")
        .agg(pl.len().alias("count"))
        .with_columns(
            (pl.col("count") / n_transactions).alias("support")
        )
        .filter(pl.col("support") >= min_support)
        .select(["itemset", "support"])
        .collect(engine="streaming")
    )


if __name__ == "__main__":
    # Test the _frequent_1_itemsets function
    transactions = pl.DataFrame({
        "items": [[1, 2, 3], [2, 3, 4], [1, 3, 5], [2, 3]]
    })
    # Item 3 appears in all 4 transactions (support=1.0)
    # Item 2 appears in 3 transactions (support=0.75)
    # Item 1 appears in 2 transactions (support=0.5)
    # Items 4,5 appear in 1 transaction each (support=0.25)
    # With min_support=0.5, should return items 1, 2, 3

    result = _frequent_1_itemsets(transactions, min_support=0.5)
    print("Frequent 1-itemsets with min_support=0.5:")
    print(result)

    # Test candidate generation
    # From frequent 2-itemsets: [1,2], [1,3], [2,3]
    # Should generate 3-itemset candidates: [1,2,3]
    frequent_2 = pl.DataFrame({
        "itemset": [[1, 2], [1, 3], [2, 3]],
        "support": [0.5, 0.5, 0.5]
    })
    candidates = _generate_candidates(frequent_2, k=2)
    print("\nCandidates from 2-itemsets:")
    print(candidates)
    # Expected: one candidate [1, 2, 3]

    # Test support counting
    print("\n--- Test _count_support ---")
    candidates_test = pl.DataFrame({
        "itemset": [[1, 2], [2, 3], [3, 4]]
    })
    # [1,2] appears in: [1,2,3] -> 1 time, support=0.25
    # [2,3] appears in: [1,2,3], [2,3,4], [2,3] -> 3 times, support=0.75
    # [3,4] appears in: [2,3,4] -> 1 time, support=0.25

    result = _count_support(candidates_test, transactions, min_support=0.5)
    print("Support counting with min_support=0.5:")
    print(result)
    # Expected: only [2,3] with support=0.75
