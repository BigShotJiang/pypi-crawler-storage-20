"""Association rule generation from frequent itemsets.

This module contains functions for generating association rules
from frequent itemsets with confidence and lift metrics.
"""

from dataclasses import dataclass
import polars as pl


@dataclass
class Rule:
    lhs: list[int]  # Left-hand side (antecedent)
    rhs: list[int]  # Right-hand side (consequent)
    support: float
    confidence: float
    lift: float


def _powerset_nonempty(iterable):
    """Generate all non-empty subsets of an iterable."""
    from itertools import chain, combinations
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(1, len(s)))


def generate_rules(
    frequent_itemsets: pl.DataFrame,
    min_confidence: float = 0.5
) -> list[Rule]:
    """Generate association rules from frequent itemsets.

    Args:
        frequent_itemsets: DataFrame with columns "itemset" (List[Int64]) and "support" (Float64)
        min_confidence: Minimum confidence threshold (0.0-1.0)

    Returns:
        List of Rule objects meeting the confidence threshold
    """
    rules = []

    # Build support lookup
    support_map = {
        tuple(row["itemset"]): row["support"]
        for row in frequent_itemsets.iter_rows(named=True)
    }

    for row in frequent_itemsets.iter_rows(named=True):
        itemset = row["itemset"]
        if len(itemset) < 2:
            continue

        # Generate all non-empty subsets as LHS
        for lhs in _powerset_nonempty(itemset):
            rhs = [x for x in itemset if x not in lhs]
            if not rhs:
                continue

            lhs_support = support_map.get(tuple(sorted(lhs)), 0)
            if lhs_support == 0:
                continue

            confidence = row["support"] / lhs_support
            if confidence < min_confidence:
                continue

            rhs_support = support_map.get(tuple(sorted(rhs)), 0)
            lift = confidence / rhs_support if rhs_support > 0 else 0

            rules.append(Rule(
                lhs=list(lhs),
                rhs=list(rhs),
                support=row["support"],
                confidence=confidence,
                lift=lift
            ))

    return rules
