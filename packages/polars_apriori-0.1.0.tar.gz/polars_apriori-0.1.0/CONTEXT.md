# Polars Apriori - Project Context

## Origin

This project originated from a discussion on GitHub: [Efficient-Apriori Issue #69](https://github.com/tommyod/Efficient-Apriori/issues/69)

**Core question:** Can the Apriori algorithm be made more memory-efficient using Polars?

## The Problem

The `efficient-apriori` implementation:
- Uses Python `frozenset` for itemset storage (~300 bytes per itemset)
- Has enormous memory overhead for large datasets
- Limited to ~200-300k transactions on 32GB RAM

## The Solution

Using Polars' native `List[Int64]` type + streaming execution:

### Benchmark Results

We tested two scenarios to understand the full performance picture:

**Scenario A: Sparse data (no frequent itemsets found)**
| Transactions | Items | efficient-apriori | polars-apriori | Memory Reduction | Speed |
|--------------|-------|-------------------|----------------|------------------|-------|
| 1M | 1000 | 552 MB / 4.7s | 0.01 MB / 0.05s | **50,813x** | **102x faster** |

**Scenario B: Dense data (frequent itemsets found)**
| Transactions | Items | Itemsets | efficient-apriori | polars-apriori | Memory Reduction | Speed |
|--------------|-------|----------|-------------------|----------------|------------------|-------|
| 100k | 30 | 30 | 19 MB / 0.6s | 0.17 MB / 1.3s | **109x** | 0.5x |
| 1M | 50 | 50 | 238 MB / 16s | 0.17 MB / 34s | **1,369x** | 0.5x |

### Key Insights

1. **Memory wins are ALWAYS massive** (100x - 50,000x depending on scenario)
2. **Speed trade-off**: When frequent itemsets exist, polars-apriori is ~2x slower
3. **Scalability**: polars-apriori can handle datasets that would OOM efficient-apriori

The extreme 50,813x ratio occurs because:
- With 1000 items spread over 1M transactions, no item reaches the 1% support threshold
- efficient-apriori still converts all transactions to frozensets (552 MB overhead)
- polars-apriori does a streaming `group_by()`, sees 0 frequent items, and stops immediately

## Why Polars Works for Apriori

The repo owner was skeptical: "Apriori cannot be expressed as dataframe ops"

**But Apriori's core operations ARE dataframe-friendly:**

| Operation | Polars Implementation |
|----------|----------------------|
| Support counting | `explode() + group_by() + count()` |
| Candidate generation | Prefix-based self-join |
| Subset matching | `list.set_difference().len() == 0` |
| Pruning | `filter(support >= min_support)` |
| Memory efficiency | `lazy() + collect(engine="streaming")` |

## Key Innovation: Streaming Cross-Join

The breakthrough was using Polars' streaming engine for subset matching:

```python
# Instead of materializing candidates × transactions in memory,
# the streaming engine processes in batches
(
    candidates.lazy()
    .join(transactions.lazy(), how="cross")
    .filter(is_subset_condition)
    .collect(engine="streaming")  # <-- This is the magic
)
```

This avoids the O(candidates × transactions) memory explosion.

## Links

- [Efficient-Apriori repo](https://github.com/tommyod/Efficient-Apriori)
- [Original Issue #69](https://github.com/tommyod/Efficient-Apriori/issues/69)
- [Polars List type docs](https://docs.pola.rs/api/python/stable/reference/series/list.html)
