# Polars-Apriori

Memory-efficient implementation of the Apriori algorithm using [Polars](https://pola.rs/).

**100x - 50,000x less memory** than [efficient-apriori](https://github.com/tommyod/Efficient-Apriori) on large datasets.

## Installation

```bash
pip install polars-apriori
```

Or with development dependencies:

```bash
pip install polars-apriori[dev]
```

## Quick Start

```python
import polars as pl
from polars_apriori import apriori, generate_rules

# Create transaction data
transactions = pl.DataFrame({
    "items": [
        [1, 2, 3],      # Transaction 1: items 1, 2, 3
        [2, 3, 4],      # Transaction 2: items 2, 3, 4
        [1, 3, 5],      # Transaction 3: items 1, 3, 5
        [2, 3],         # Transaction 4: items 2, 3
    ]
})

# Find frequent itemsets (minimum 50% support)
itemsets = apriori(transactions, min_support=0.5)
print(itemsets)
# shape: (5, 2)
# ┌───────────┬─────────┐
# │ itemset   ┆ support │
# │ list[i64] ┆ f64     │
# ╞═══════════╪═════════╡
# │ [3]       ┆ 1.0     │
# │ [2]       ┆ 0.75    │
# │ [1]       ┆ 0.5     │
# │ [2, 3]    ┆ 0.75    │
# │ [1, 3]    ┆ 0.5     │
# └───────────┴─────────┘

# Generate association rules (minimum 70% confidence)
rules = generate_rules(itemsets, min_confidence=0.7)
for rule in rules:
    print(f"{rule.lhs} → {rule.rhs}: confidence={rule.confidence:.2f}, lift={rule.lift:.2f}")
# [2] → [3]: confidence=1.00, lift=1.00
# [1] → [3]: confidence=1.00, lift=1.00
```

## API Reference

### `apriori()`

Find frequent itemsets using the Apriori algorithm.

```python
def apriori(
    transactions: pl.DataFrame,
    min_support: float = 0.5,
    max_length: int | None = None,
    item_col: str = "items"
) -> pl.DataFrame
```

**Parameters:**
- `transactions`: DataFrame with a column containing item lists (`List[Int64]`)
- `min_support`: Minimum support threshold (0.0-1.0), default 0.5
- `max_length`: Maximum itemset length (None = unlimited)
- `item_col`: Name of the items column, default "items"

**Returns:** DataFrame with columns:
- `itemset`: `List[Int64]` - the frequent itemset
- `support`: `Float64` - fraction of transactions containing the itemset

### `generate_rules()`

Generate association rules from frequent itemsets.

```python
def generate_rules(
    frequent_itemsets: pl.DataFrame,
    min_confidence: float = 0.5
) -> list[Rule]
```

**Parameters:**
- `frequent_itemsets`: Output from `apriori()`
- `min_confidence`: Minimum confidence threshold (0.0-1.0), default 0.5

**Returns:** List of `Rule` objects

### `Rule` dataclass

```python
@dataclass
class Rule:
    lhs: list[int]      # Left-hand side (antecedent)
    rhs: list[int]      # Right-hand side (consequent)
    support: float      # Support of lhs ∪ rhs
    confidence: float   # P(rhs | lhs) = support / support(lhs)
    lift: float         # confidence / support(rhs)
```

## Performance

Benchmarked against `efficient-apriori` on random transaction data:

### Memory Reduction: 100x - 50,000x

| Scenario | Transactions | efficient-apriori | polars-apriori | Memory | Speed |
|----------|--------------|-------------------|----------------|--------|-------|
| Sparse (0 itemsets) | 1M | 552 MB / 4.7s | 0.01 MB / 0.05s | **50,813x** | 102x faster |
| Dense (50 itemsets) | 1M | 238 MB / 16s | 0.17 MB / 34s | **1,369x** | 0.5x |

![Benchmark Results](benchmarks/benchmark_results.png)

### Trade-offs

| Metric | Winner | Details |
|--------|--------|---------|
| **Memory** | polars-apriori ✅ | Always 100-50,000x less memory |
| **Speed (sparse data)** | polars-apriori ✅ | Up to 100x faster when few/no itemsets |
| **Speed (dense data)** | efficient-apriori | ~2x faster when many itemsets found |
| **Scalability** | polars-apriori ✅ | Handles datasets that OOM efficient-apriori |

### Why so memory efficient?

1. **Polars List columns**: Uses Arrow-backed `List[Int64]` (~20 bytes per itemset) instead of Python `frozenset` (~300 bytes)
2. **Streaming engine**: Lazy evaluation with streaming processes data in batches, avoiding memory explosion on cross-joins
3. **No Python object overhead**: All operations stay in Polars' native format
4. **Early termination**: Stops immediately when no frequent items are found

## Working with String Items

If your items are strings, encode them as integers first:

```python
import polars as pl
from polars_apriori import apriori

# Original string transactions
raw_transactions = [
    ["bread", "milk", "eggs"],
    ["bread", "butter"],
    ["milk", "eggs"],
]

# Build item encoding
all_items = sorted(set(item for tx in raw_transactions for item in tx))
item_to_id = {item: i for i, item in enumerate(all_items)}
id_to_item = {i: item for item, i in item_to_id.items()}

# Encode transactions
encoded = [[item_to_id[item] for item in tx] for tx in raw_transactions]
transactions = pl.DataFrame({"items": encoded})

# Run apriori
itemsets = apriori(transactions, min_support=0.5)

# Decode results
for row in itemsets.iter_rows(named=True):
    items = [id_to_item[i] for i in row["itemset"]]
    print(f"{items}: {row['support']:.2f}")
```

## Development

```bash
# Clone and setup
git clone https://github.com/youruser/polars-apriori
cd polars-apriori
uv venv && source .venv/bin/activate
uv pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Run benchmarks
python benchmarks/compare.py
```

## License

MIT
