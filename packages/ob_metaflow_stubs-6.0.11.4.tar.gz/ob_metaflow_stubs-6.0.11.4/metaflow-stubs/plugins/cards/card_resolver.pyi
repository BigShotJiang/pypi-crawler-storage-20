######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-18T13:29:13.994085                                                            #
######################################################################################################

from __future__ import annotations


from .card_datastore import CardDatastore as CardDatastore

def resumed_info(task):
    ...

def resolve_paths_from_task(flow_datastore, pathspec = None, type = None, hash = None, card_id = None):
    ...

