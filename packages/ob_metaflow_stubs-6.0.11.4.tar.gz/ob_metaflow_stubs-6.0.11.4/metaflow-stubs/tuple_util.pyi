######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-18T13:29:13.926172                                                            #
######################################################################################################

from __future__ import annotations



def namedtuple_with_defaults(typename, field_descr, defaults = ()):
    ...

foreach_frame_field_list: list

