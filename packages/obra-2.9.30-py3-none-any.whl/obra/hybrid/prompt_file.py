"""Prompt file lifecycle management for hybrid orchestration."""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4


class PromptFileManager:
    """Manage prompt file creation and cleanup for LLM invocations."""

    def __init__(self, working_dir: Path, retain: bool = False) -> None:
        self._working_dir = working_dir
        self._retain = retain

    def write_prompt(self, prompt: str) -> tuple[Path, str]:
        """Write prompt to a file and return (path, instruction)."""
        filename = f".obra-prompt-{uuid4().hex[:8]}.txt"
        filepath = self._working_dir / filename
        filepath.write_text(prompt, encoding="utf-8")
        instruction = f"Read and execute all instructions in {filename}"
        return filepath, instruction

    def cleanup(self, filepath: Path) -> None:
        """Delete prompt file unless retention is enabled."""
        if self._retain:
            return
        filepath.unlink(missing_ok=True)

    @classmethod
    def cleanup_orphaned(cls, working_dir: Path) -> int:
        """Remove orphaned prompt files in the working directory."""
        count = 0
        for prompt_file in working_dir.glob(".obra-prompt-*.txt"):
            prompt_file.unlink(missing_ok=True)
            count += 1
        return count


__all__ = ["PromptFileManager"]
