"""Tests for pycastic."""
