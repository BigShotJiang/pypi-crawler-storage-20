from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SerialiserLike(Protocol):
    """
    描述:
    - 通用序列化接口协议。
    - 定义序列化方法的签名，适用于各种数据格式。
    - 将数据对象（如 DataFrame）转换为字节流。

    方法:
    - serialise(data, format, **kwargs): 通用序列化方法，返回 bytes。

    例子:
    ```python
        from xfintech.serde.common.serialiserlike import SerialiserLike
        import pandas as pd

        class MySerialiser:
            @staticmethod
            def serialise(data, format, **kwargs):
                # 实现序列化逻辑
                return b"serialized data"

        # 检查是否符合协议
        assert isinstance(MySerialiser(), SerialiserLike)
    ```
    """

    @staticmethod
    def serialise(
        data: Any,
        format: Any,
        **kwargs: Any,
    ) -> bytes: ...
