from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class DeserialiserLike(Protocol):
    """
    描述:
    - 通用反序列化接口协议。
    - 定义反序列化方法的签名，适用于各种数据格式。
    - 将字节流转换为数据对象（如 DataFrame）。

    方法:
    - deserialise(data, format, **kwargs): 通用反序列化方法，返回数据对象。

    例子:
    ```python
        from xfintech.serde.common.deserialiserlike import DeserialiserLike
        import pandas as pd

        class MyDeserialiser:
            @staticmethod
            def deserialise(data, format, **kwargs):
                # 实现反序列化逻辑
                return pd.DataFrame()

        # 检查是否符合协议
        assert isinstance(MyDeserialiser(), DeserialiserLike)
    ```
    """

    @staticmethod
    def deserialise(
        data: Any,
        format: Any,
        **kwargs: Any,
    ) -> Any: ...
