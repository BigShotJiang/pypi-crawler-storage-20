from __future__ import annotations


class DeserialiserInputTypeError(TypeError):
    """
    描述:
    - 反序列化输入类型错误异常。
    - 当输入数据类型不符合预期时抛出（例如期望 bytes 但收到 str）。
    - 继承自 TypeError。

    例子:
    ```python
        from xfintech.serde.common.error import DeserialiserInputTypeError

        def deserialise(data):
            if not isinstance(data, bytes):
                raise DeserialiserInputTypeError(
                    f"Expected bytes, got {type(data)}"
                )
    ```
    """

    pass


class DeserialiserNotSupportedError(TypeError):
    """
    描述:
    - 反序列化格式不支持异常。
    - 当请求的数据格式不被支持时抛出。
    - 继承自 TypeError。

    例子:
    ```python
        from xfintech.serde.common.error import DeserialiserNotSupportedError

        supported_formats = ["parquet", "csv", "json"]
        if format not in supported_formats:
            raise DeserialiserNotSupportedError(
                f"Format {format} not supported"
            )
    ```
    """

    pass


class DeserialiserImportError(ImportError):
    """
    描述:
    - 反序列化依赖导入错误异常。
    - 当必需的库未安装时抛出（例如 pyarrow）。
    - 继承自 ImportError。

    例子:
    ```python
        from xfintech.serde.common.error import DeserialiserImportError

        try:
            import pyarrow
        except ImportError as e:
            raise DeserialiserImportError(
                "pyarrow is required. Install with: pip install pyarrow"
            ) from e
    ```
    """

    pass


class DeserialiserFailedError(Exception):
    """
    描述:
    - 反序列化失败异常。
    - 当反序列化过程中发生错误时抛出。
    - 继承自 Exception。

    例子:
    ```python
        from xfintech.serde.common.error import DeserialiserFailedError

        try:
            result = parse_data(corrupted_bytes)
        except Exception as e:
            raise DeserialiserFailedError(
                f"Failed to deserialise data: {e}"
            ) from e
    ```
    """

    pass


class SerialiserInputTypeError(TypeError):
    """
    描述:
    - 序列化输入类型错误异常。
    - 当输入数据类型不符合预期时抛出（例如期望 DataFrame 但收到 list）。
    - 继承自 TypeError。

    例子:
    ```python
        from xfintech.serde.common.error import SerialiserInputTypeError
        import pandas as pd

        def serialise(data):
            if not isinstance(data, pd.DataFrame):
                raise SerialiserInputTypeError(
                    f"Expected DataFrame, got {type(data)}"
                )
    ```
    """

    pass


class SerialiserNotSupportedError(TypeError):
    """
    描述:
    - 序列化格式不支持异常。
    - 当请求的数据格式不被支持时抛出。
    - 继承自 TypeError。

    例子:
    ```python
        from xfintech.serde.common.error import SerialiserNotSupportedError

        supported_formats = ["parquet", "csv", "json"]
        if format not in supported_formats:
            raise SerialiserNotSupportedError(
                f"Format {format} not supported"
            )
    ```
    """

    pass


class SerialiserImportError(ImportError):
    """
    描述:
    - 序列化依赖导入错误异常。
    - 当必需的库未安装时抛出（例如 pyarrow）。
    - 继承自 ImportError。

    例子:
    ```python
        from xfintech.serde.common.error import SerialiserImportError

        try:
            import pyarrow
        except ImportError as e:
            raise SerialiserImportError(
                "pyarrow is required. Install with: pip install pyarrow"
            ) from e
    ```
    """

    pass


class SerialiserFailedError(Exception):
    """
    描述:
    - 序列化失败异常。
    - 当序列化过程中发生错误时抛出。
    - 继承自 Exception。

    例子:
    ```python
        from xfintech.serde.common.error import SerialiserFailedError

        try:
            bytes_data = convert_to_bytes(data)
        except Exception as e:
            raise SerialiserFailedError(
                f"Failed to serialise data: {e}"
            ) from e
    ```
    """

    pass
