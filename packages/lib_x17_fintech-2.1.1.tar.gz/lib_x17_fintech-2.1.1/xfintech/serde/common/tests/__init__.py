# Tests for xfintech.serde.format module
