from xfintech.connect.artifact.artifact import Artifact

__all__ = [
    "Artifact",
]
