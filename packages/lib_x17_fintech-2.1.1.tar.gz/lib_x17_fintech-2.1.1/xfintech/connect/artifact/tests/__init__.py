"""
Tests for Artifact module
"""
