"""Tests for xfintech.connect.common module."""
