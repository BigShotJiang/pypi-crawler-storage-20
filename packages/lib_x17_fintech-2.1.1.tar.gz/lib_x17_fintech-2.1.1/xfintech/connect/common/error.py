from __future__ import annotations


class ConnectRefKeyError(KeyError):
    """
    描述:
    - 连接引用键错误异常。
    - 当连接引用数据中缺少必需的键时抛出。
    - 继承自 KeyError。

    例子:
    ```python
        from xfintech.connect.common.error import ConnectRefKeyError

        data = {"kind": "s3"}  # 缺少 'location'
        if "location" not in data:
            raise ConnectRefKeyError("'location' is required in data")
    ```
    """

    pass


class ConnectKeyError(KeyError):
    """
    描述:
    - 连接键错误异常。
    - 当连接操作中使用了无效或缺失的键时抛出。
    - 继承自 KeyError。

    例子:
    ```python
        from xfintech.connect.common.error import ConnectKeyError

        if location is None:
            raise ConnectKeyError("location cannot be None")
    ```
    """

    pass


class ConnectFailedError(Exception):
    """
    描述:
    - 连接操作失败异常。
    - 当连接操作（读取或写入）执行失败时抛出。
    - 继承自 Exception。

    例子:
    ```python
        from xfintech.connect.common.error import ConnectFailedError

        try:
            with open(path, 'rb') as f:
                data = f.read()
        except Exception as e:
            raise ConnectFailedError(str(e)) from e
    ```
    """

    pass
