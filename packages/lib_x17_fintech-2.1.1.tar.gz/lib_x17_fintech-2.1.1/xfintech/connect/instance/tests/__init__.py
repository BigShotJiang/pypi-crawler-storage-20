"""Tests for xfintech.connect.instance module."""
