class NoConnectionError(Exception):
    pass
