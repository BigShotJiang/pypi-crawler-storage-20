"""Float/Double 回退启发式测试.

测试 DataReader.read_float() 和 read_double() 中的启发式逻辑,
用于在未指定字节序时尝试检测小端序编码数据.
"""

import math
import struct

import pytest

from jce.decoder import DataReader
from jce.exceptions import JcePartialDataError
from jce.options import OPT_LITTLE_ENDIAN


def test_float_normal_big_endian():
    """测试大端序编码的正常 float."""
    # 3.14 (大端序)
    data = struct.pack(">f", math.pi)
    reader = DataReader(data, option=0)
    result = reader.read_float()
    assert abs(result - math.pi) < 0.001


def test_float_normal_little_endian_explicit():
    """测试显式指定的小端序编码 float."""
    # 3.14 (小端序)
    data = struct.pack("<f", math.pi)
    reader = DataReader(data, option=OPT_LITTLE_ENDIAN)
    result = reader.read_float()
    assert abs(result - math.pi) < 0.001


def test_float_nan_big_endian_fallback_to_little():
    """当 BE 产生 NaN 但 LE 产生有限值时, 优先选择 LE."""
    # 创建 BE 产生 NaN 但 LE 产生正常数字的数据
    # NaN 模式: 指数全 1, 尾数非零
    # 我们希望 BE 产生 NaN, LE 产生有限值

    # 使用一个已知案例: 0xFF800001 是 BE float 的 -NaN
    # 在 LE 中, 相同的字节可能有不同的值
    # 让我们找一个更好的例子:
    # 创建在一个字节序中为 NaN 但在另一个中有效的字节

    # 简单方法: 将正常 float 打包为 LE, 然后解释为 BE
    normal_val = 123.456
    le_bytes = struct.pack("<f", normal_val)
    be_interpretation = struct.unpack(">f", le_bytes)[0]
    le_interpretation = struct.unpack("<f", le_bytes)[0]

    # 如果 BE 不是有限值但 LE 是, 启发式算法应选择 LE
    if not math.isfinite(be_interpretation) and math.isfinite(le_interpretation):
        reader = DataReader(le_bytes, option=0)  # 无 LE 选项
        result = reader.read_float()
        # 应优先选择有限值 (LE) 解释
        assert math.isfinite(result)


def test_float_large_be_small_le_fallback():
    """当 BE 产生极大值但 LE 产生小值时, 优先选择 LE."""
    # 创建 BE 产生巨大值, LE 产生合理值的数据
    # 测试数量级启发式

    # 将小值打包为 LE
    small_val = 42.5
    le_bytes = struct.pack("<f", small_val)
    be_interpretation = struct.unpack(">f", le_bytes)[0]
    le_interpretation = struct.unpack("<f", le_bytes)[0]

    # 如果 BE 极大 (>1e9) 且 LE 较小 (<=1e6)
    if (
        math.isfinite(be_interpretation)
        and math.isfinite(le_interpretation)
        and abs(be_interpretation) > 1e9
        and abs(le_interpretation) <= 1e6
    ):
        reader = DataReader(le_bytes, option=0)
        result = reader.read_float()
        # 应优先选择较小数量级 (LE)
        assert abs(result - small_val) < 0.01


def test_float_both_normal_prefer_be():
    """当两种解释都正常时, 优先选择 BE (主要)."""
    # 在两种字节序下都合理的值
    # 打包为 BE
    val = 1.0
    be_bytes = struct.pack(">f", val)
    reader = DataReader(be_bytes, option=0)
    result = reader.read_float()
    assert abs(result - 1.0) < 0.001


def test_double_normal_big_endian():
    """测试大端序编码的正常 double."""
    data = struct.pack(">d", math.pi)
    reader = DataReader(data, option=0)
    result = reader.read_double()
    assert abs(result - math.pi) < 1e-10


def test_double_normal_little_endian_explicit():
    """测试显式指定的小端序编码 double."""
    data = struct.pack("<d", math.pi)
    reader = DataReader(data, option=OPT_LITTLE_ENDIAN)
    result = reader.read_double()
    assert abs(result - math.pi) < 1e-10


def test_double_nan_big_endian_fallback_to_little():
    """当 BE 产生 NaN 但 LE 产生有限值时, 优先选择 LE."""
    normal_val = 12345.6789
    le_bytes = struct.pack("<d", normal_val)
    be_interpretation = struct.unpack(">d", le_bytes)[0]
    le_interpretation = struct.unpack("<d", le_bytes)[0]

    if not math.isfinite(be_interpretation) and math.isfinite(le_interpretation):
        reader = DataReader(le_bytes, option=0)
        result = reader.read_double()
        assert math.isfinite(result)


def test_double_large_be_small_le_fallback():
    """当 BE 产生极大值但 LE 产生小值时, 优先选择 LE."""
    small_val = 100.5
    le_bytes = struct.pack("<d", small_val)
    be_interpretation = struct.unpack(">d", le_bytes)[0]
    le_interpretation = struct.unpack("<d", le_bytes)[0]

    # 启发式: |BE| > 1e18 且 |LE| <= 1e12
    if (
        math.isfinite(be_interpretation)
        and math.isfinite(le_interpretation)
        and abs(be_interpretation) > 1e18
        and abs(le_interpretation) <= 1e12
    ):
        reader = DataReader(le_bytes, option=0)
        result = reader.read_double()
        assert abs(result - small_val) < 0.01


def test_double_subnormal_be_normal_le_fallback():
    """当 BE 产生次正规数 (<1e-30) 但 LE 产生合理值时."""
    small_val = 50.0
    le_bytes = struct.pack("<d", small_val)
    be_interpretation = struct.unpack(">d", le_bytes)[0]
    le_interpretation = struct.unpack("<d", le_bytes)[0]

    # 启发式: |BE| < 1e-30 且 |LE| <= 1e6
    if (
        math.isfinite(be_interpretation)
        and math.isfinite(le_interpretation)
        and abs(be_interpretation) < 1e-30
        and abs(le_interpretation) <= 1e6
    ):
        reader = DataReader(le_bytes, option=0)
        result = reader.read_double()
        assert abs(result - small_val) < 0.01


def test_double_both_normal_prefer_be():
    """当两种解释都正常时, 优先选择 BE."""
    val = 1.0
    be_bytes = struct.pack(">d", val)
    reader = DataReader(be_bytes, option=0)
    result = reader.read_double()
    assert abs(result - 1.0) < 1e-10


def test_float_eof():
    """在数据不足时读取 float."""
    data = b"\x00\x00\x00"  # 仅 3 字节, 需要 4 字节
    reader = DataReader(data, option=0)
    with pytest.raises(JcePartialDataError):
        reader.read_float()


def test_double_eof():
    """在数据不足时读取 double."""
    data = b"\x00\x00\x00\x00\x00\x00\x00"  # 仅 7 字节, 需要 8 字节
    reader = DataReader(data, option=0)
    with pytest.raises(JcePartialDataError):
        reader.read_double()
