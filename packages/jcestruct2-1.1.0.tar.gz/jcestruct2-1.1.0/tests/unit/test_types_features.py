"""types.py 覆盖率测试.

使用函数式测试风格, 每个测试函数独立且自描述.
"""

import pytest

from jce import (
    JceField,
    JceStruct,
    dumps,
    field_deserializer,
    field_serializer,
    loads,
)
from jce.context import DeserializationInfo, SerializationInfo
from jce.types import (
    LIST,
    MAP,
    guess_jce_type,
    prepare_fields,
)

# =============================================================================
# field_serializer / field_deserializer 装饰器测试
# =============================================================================


def test_field_serializer_transforms_value_on_encode():
    """@field_serializer 应该在编码时转换字段值."""

    class _TestStruct(JceStruct):
        value: str = JceField(jce_id=0, default="")

        @field_serializer("value")
        def serialize_value(
            self,
            value: str,
            info: SerializationInfo,  # noqa: ARG002
        ) -> str:
            return value.upper()

    obj = _TestStruct(value="hello")
    encoded = dumps(obj)
    result = loads(encoded, dict)

    assert result[0] == "HELLO"


def test_field_deserializer_transforms_value_on_decode():
    """@field_deserializer 应该在解码时转换字段值."""

    class _TestStruct(JceStruct):
        value: str = JceField(jce_id=0, default="")

        @classmethod
        @field_deserializer("value")
        def deserialize_value(
            cls,
            value: str | bytes,
            info: DeserializationInfo,  # noqa: ARG003
        ) -> str:
            if isinstance(value, bytes):
                value = value.decode("utf-8")
            return value.lower()

    data = {0: "HELLO"}
    encoded = dumps(data)
    result = loads(encoded, _TestStruct)

    assert result.value == "hello"


def test_field_serializer_receives_context():
    """@field_serializer 应该能访问序列化上下文."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

        @field_serializer("value")
        def serialize_value(self, value: int, info: SerializationInfo) -> int:
            offset = info.context.get("offset", 0)
            return value + offset

    obj = _TestStruct(value=10)
    encoded = dumps(obj, context={"offset": 5})
    result = loads(encoded, dict)

    assert result[0] == 15


def test_field_deserializer_receives_context():
    """@field_deserializer 应该能访问反序列化上下文."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

        @classmethod
        @field_deserializer("value")
        def deserialize_value(cls, value: int, info: DeserializationInfo) -> int:
            offset = info.context.get("offset", 0)
            return value - offset

    data = {0: 15}
    encoded = dumps(data)
    result = loads(encoded, _TestStruct, context={"offset": 5})

    assert result.value == 10


# =============================================================================
# Union 类型错误测试
# =============================================================================


def test_multi_type_union_raises_type_error():
    """多类型 Union (如 int | str) 应该在定义时抛出 TypeError."""
    with pytest.raises(TypeError, match="Union type"):

        class _BadStruct(JceStruct):
            value: int | str = JceField(jce_id=0)


def test_optional_type_is_allowed():
    """Optional[T] (即 T | None) 应该被允许."""

    class _GoodStruct(JceStruct):
        value: int | None = JceField(jce_id=0, default=None)

    obj = _GoodStruct(value=42)
    encoded = dumps(obj)
    result = loads(encoded, _GoodStruct)

    assert result.value == 42


# =============================================================================
# MAP 类型验证测试
# =============================================================================


def test_map_validate_rejects_invalid_key_type():
    """MAP.validate 应该拒绝无效的键类型."""
    with pytest.raises(TypeError, match="Invalid MAP key"):
        MAP.validate({object(): "value"})


def test_map_validate_rejects_invalid_value_type():
    """MAP.validate 应该拒绝无效的值类型."""
    with pytest.raises(TypeError, match="Invalid MAP value"):
        MAP.validate({"key": object()})


def test_map_validate_rejects_non_mapping():
    """MAP.validate 应该拒绝非映射类型."""
    with pytest.raises(TypeError, match="Invalid MAP type"):
        MAP.validate("not a dict")


# =============================================================================
# LIST 类型验证测试
# =============================================================================


def test_list_validate_rejects_invalid_item_type():
    """LIST.validate 应该拒绝无效的元素类型."""
    with pytest.raises(TypeError, match="Invalid LIST item type"):
        LIST.validate([object()])


def test_list_validate_rejects_non_iterable():
    """LIST.validate 应该拒绝非可迭代类型."""
    with pytest.raises(TypeError, match="Invalid LIST type"):
        LIST.validate(12345)


# =============================================================================
# JceStruct.from_bytes 方法测试
# =============================================================================


def test_jce_struct_from_bytes_returns_dict_and_offset():
    """JceStruct.from_bytes 应该返回 (dict, offset) 元组."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

    data = {0: 42}
    encoded = dumps(data)

    result, offset = _TestStruct.from_bytes(encoded)

    assert isinstance(result, dict)
    assert result[0] == 42
    assert offset == len(encoded)


# =============================================================================
# JceStruct._jce_pre_validate 方法测试
# =============================================================================


def test_jce_pre_validate_decodes_bytes():
    """_jce_pre_validate 应该能从字节反序列化."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

    encoded = dumps({0: 42})
    result = _TestStruct.model_validate(encoded)

    assert result.value == 42


def test_jce_pre_validate_raises_on_invalid_bytes():
    """_jce_pre_validate 应该在字节解码失败时抛出 TypeError."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0)  # 必需字段, 无默认值

    with pytest.raises(TypeError, match="Failed to decode"):
        _TestStruct.model_validate(b"")


def test_jce_pre_validate_rejects_non_dict_non_bytes():
    """_jce_pre_validate 应该拒绝非 dict 非 bytes 类型."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

    with pytest.raises(TypeError, match="Invalid value type"):
        _TestStruct.model_validate("not a dict")


def test_jce_pre_validate_handles_map_field_bytes():
    """_jce_pre_validate 应该能处理 MAP 字段中的嵌套字节."""

    class _TestStruct(JceStruct):
        data: dict = JceField(jce_id=0, jce_type=MAP, default_factory=dict)

    inner = {0: 42}
    inner_encoded = dumps(inner)

    result = _TestStruct.model_validate({0: inner_encoded})

    assert isinstance(result.data, dict)


# =============================================================================
# guess_jce_type 函数测试
# =============================================================================


def test_guess_jce_type_raises_for_unknown_type():
    """guess_jce_type 应该对未知类型抛出 TypeError."""
    with pytest.raises(TypeError):
        guess_jce_type(object())


def test_guess_jce_type_returns_struct_class_for_jce_struct():
    """guess_jce_type 应该为 JceStruct 实例返回其类."""

    class _TestStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

    obj = _TestStruct(value=42)
    result = guess_jce_type(obj)

    assert result is _TestStruct


# =============================================================================
# prepare_fields 函数测试
# =============================================================================


def test_prepare_fields_skips_invalid_jce_type():
    """prepare_fields 应该跳过带有无效 jce_type 的字段."""
    from pydantic.fields import FieldInfo

    field = FieldInfo(default=0, json_schema_extra={"jce_id": 0, "jce_type": "invalid"})

    result = prepare_fields({"bad_field": field})

    assert "bad_field" not in result
