"""options.py 覆盖率测试.

使用函数式测试风格, 每个测试函数独立且自描述.
"""

import pytest

from jce.options import (
    OPT_LITTLE_ENDIAN,
    OPT_OMIT_DEFAULT,
    OPT_SERIALIZE_NONE,
    OPT_STRICT_MAP,
    OPT_ZERO_COPY,
    validate_option,
)

# =============================================================================
# validate_option 函数测试
# =============================================================================


def test_validate_option_accepts_single_valid_option():
    """validate_option 应该接受单个有效选项."""
    validate_option(OPT_LITTLE_ENDIAN)
    validate_option(OPT_STRICT_MAP)
    validate_option(OPT_SERIALIZE_NONE)
    validate_option(OPT_ZERO_COPY)
    validate_option(OPT_OMIT_DEFAULT)


def test_validate_option_accepts_combined_options():
    """validate_option 应该接受组合的有效选项."""
    validate_option(OPT_LITTLE_ENDIAN | OPT_STRICT_MAP)
    validate_option(OPT_ZERO_COPY | OPT_OMIT_DEFAULT)
    validate_option(
        OPT_LITTLE_ENDIAN
        | OPT_STRICT_MAP
        | OPT_SERIALIZE_NONE
        | OPT_ZERO_COPY
        | OPT_OMIT_DEFAULT
    )


def test_validate_option_accepts_zero():
    """validate_option 应该接受零值 (默认选项)."""
    validate_option(0)


def test_validate_option_rejects_non_int():
    """validate_option 应该拒绝非整数类型."""
    with pytest.raises(TypeError, match="Option must be int"):
        validate_option("invalid")  # type: ignore

    with pytest.raises(TypeError, match="Option must be int"):
        validate_option(1.5)  # type: ignore

    with pytest.raises(TypeError, match="Option must be int"):
        validate_option(None)  # type: ignore


def test_validate_option_rejects_unknown_bits():
    """validate_option 应该拒绝未知的选项位."""
    with pytest.raises(ValueError, match="Unknown option bits"):
        validate_option(0x1000)

    with pytest.raises(ValueError, match="Unknown option bits"):
        validate_option(0x0100)

    # 组合有效和无效位
    with pytest.raises(ValueError, match="Unknown option bits"):
        validate_option(OPT_LITTLE_ENDIAN | 0x1000)
