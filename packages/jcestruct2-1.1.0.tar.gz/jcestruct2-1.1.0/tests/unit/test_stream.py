"""stream.py 覆盖率测试.

使用函数式测试风格, 每个测试函数独立且自描述.
"""

import pytest

from jce import JceField, JceStruct
from jce.stream import (
    JcePacker,
    JceUnpacker,
    LengthPrefixedPacker,
    LengthPrefixedUnpacker,
)


class _SimpleStruct(JceStruct):
    """测试用简单结构体."""

    value: int = JceField(jce_id=0, default=0)


@pytest.fixture
def simple_struct() -> _SimpleStruct:
    """创建一个简单的测试结构体."""
    return _SimpleStruct(value=42)


def test_jce_packer_pack_bytes():
    """JcePacker.pack_bytes 应该直接追加原始字节."""
    packer = JcePacker()
    packer.pack_bytes(b"raw bytes")

    assert b"raw bytes" in packer.get_buffer()


def test_jce_packer_with_context(simple_struct):
    """JcePacker 应该支持 context 参数."""
    packer = JcePacker(context={"key": "value"})
    packer.pack(simple_struct)

    assert len(packer.get_buffer()) > 0


def test_jce_unpacker_iter_raises_not_implemented():
    """JceUnpacker.__iter__ 应该抛出 NotImplementedError."""
    unpacker = JceUnpacker(target=_SimpleStruct)
    unpacker.feed(b"some data")

    with pytest.raises(NotImplementedError, match="LengthPrefixedUnpacker"):
        list(unpacker)


def test_length_prefixed_packer_rejects_invalid_length_type():
    """LengthPrefixedPacker 应该拒绝无效的 length_type."""
    with pytest.raises(ValueError, match="length_type must be 1, 2, or 4"):
        LengthPrefixedPacker(length_type=3)

    with pytest.raises(ValueError, match="length_type must be 1, 2, or 4"):
        LengthPrefixedPacker(length_type=8)


def test_length_prefixed_packer_1byte_length(simple_struct):
    """LengthPrefixedPacker 应该支持 1 字节长度前缀."""
    packer = LengthPrefixedPacker(length_type=1)
    packer.pack(simple_struct)

    data = packer.get_buffer()
    assert len(data) > 0


def test_length_prefixed_packer_2byte_length(simple_struct):
    """LengthPrefixedPacker 应该支持 2 字节长度前缀."""
    packer = LengthPrefixedPacker(length_type=2)
    packer.pack(simple_struct)

    data = packer.get_buffer()
    assert len(data) > 0


def test_length_prefixed_packer_1byte_length_overflow():
    """LengthPrefixedPacker 1 字节模式应该拒绝超大数据."""
    packer = LengthPrefixedPacker(length_type=1)
    large_data = {i: i for i in range(100)}

    with pytest.raises(ValueError, match="Packet too large for 1-byte length"):
        packer.pack(large_data)


def test_length_prefixed_packer_2byte_length_overflow():
    """LengthPrefixedPacker 2 字节模式应该拒绝超大长度."""
    packer = LengthPrefixedPacker(length_type=2)

    with pytest.raises(ValueError, match="Packet too large for 2-byte length"):
        packer._pack_length(70000)


def test_length_prefixed_packer_4byte_length_overflow():
    """LengthPrefixedPacker 4 字节模式应该拒绝超大长度."""
    packer = LengthPrefixedPacker(length_type=4)

    with pytest.raises(ValueError, match="Packet too large for 4-byte length"):
        packer._pack_length(5000000000)


def test_length_prefixed_packer_little_endian(simple_struct):
    """LengthPrefixedPacker 应该支持小端序长度."""
    packer = LengthPrefixedPacker(length_type=4, little_endian_length=True)
    packer.pack(simple_struct)

    data = packer.get_buffer()
    assert len(data) > 0


def test_length_prefixed_packer_non_inclusive_length(simple_struct):
    """LengthPrefixedPacker 应该支持不包含头部的长度模式."""
    packer = LengthPrefixedPacker(length_type=4, inclusive_length=False)
    packer.pack(simple_struct)

    data = packer.get_buffer()
    assert len(data) > 0


def test_length_prefixed_unpacker_rejects_invalid_length_type():
    """LengthPrefixedUnpacker 应该拒绝无效的 length_type."""
    with pytest.raises(ValueError, match="length_type must be 1, 2, or 4"):
        LengthPrefixedUnpacker(target=_SimpleStruct, length_type=3)


def test_length_prefixed_unpacker_1byte_length(simple_struct):
    """LengthPrefixedUnpacker 应该支持 1 字节长度前缀解包."""
    packer = LengthPrefixedPacker(length_type=1)
    packer.pack(simple_struct)
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(target=_SimpleStruct, length_type=1)
    unpacker.feed(data)

    results = list(unpacker)
    assert len(results) == 1
    assert results[0].value == 42


def test_length_prefixed_unpacker_2byte_length(simple_struct):
    """LengthPrefixedUnpacker 应该支持 2 字节长度前缀解包."""
    packer = LengthPrefixedPacker(length_type=2)
    packer.pack(simple_struct)
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(target=_SimpleStruct, length_type=2)
    unpacker.feed(data)

    results = list(unpacker)
    assert len(results) == 1
    assert results[0].value == 42


def test_length_prefixed_unpacker_little_endian(simple_struct):
    """LengthPrefixedUnpacker 应该支持小端序长度解包."""
    packer = LengthPrefixedPacker(length_type=4, little_endian_length=True)
    packer.pack(simple_struct)
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(
        target=_SimpleStruct, length_type=4, little_endian_length=True
    )
    unpacker.feed(data)

    results = list(unpacker)
    assert len(results) == 1
    assert results[0].value == 42


def test_length_prefixed_unpacker_non_inclusive_length(simple_struct):
    """LengthPrefixedUnpacker 应该支持不包含头部的长度模式解包."""
    packer = LengthPrefixedPacker(length_type=4, inclusive_length=False)
    packer.pack(simple_struct)
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(
        target=_SimpleStruct, length_type=4, inclusive_length=False
    )
    unpacker.feed(data)

    results = list(unpacker)
    assert len(results) == 1
    assert results[0].value == 42


def test_length_prefixed_unpacker_dict_target():
    """LengthPrefixedUnpacker 应该支持 dict 作为目标类型."""
    packer = LengthPrefixedPacker()
    packer.pack({0: 42})
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(target=dict)
    unpacker.feed(data)

    results = list(unpacker)
    assert len(results) == 1
    assert results[0][0] == 42


def test_length_prefixed_unpacker_handles_partial_data(simple_struct):
    """LengthPrefixedUnpacker 应该正确处理部分数据."""
    packer = LengthPrefixedPacker()
    packer.pack(simple_struct)
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(target=_SimpleStruct)

    # 只输入一半的数据
    unpacker.feed(data[: len(data) // 2])
    results = list(unpacker)
    assert len(results) == 0

    # 输入剩余数据
    unpacker.feed(data[len(data) // 2 :])
    results = list(unpacker)
    assert len(results) == 1


def test_length_prefixed_unpacker_handles_multiple_packets():
    """LengthPrefixedUnpacker 应该正确解析多个连续的包."""
    packer = LengthPrefixedPacker()
    packer.pack(_SimpleStruct(value=1))
    packer.pack(_SimpleStruct(value=2))
    packer.pack(_SimpleStruct(value=3))
    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(target=_SimpleStruct)
    unpacker.feed(data)

    results = list(unpacker)
    assert len(results) == 3
    assert [r.value for r in results] == [1, 2, 3]
