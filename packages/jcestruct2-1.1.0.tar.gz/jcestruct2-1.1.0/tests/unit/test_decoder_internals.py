from jce.decoder import DataReader, GenericDecoder


def test_freeze_key_coverage():
    """测试 _freeze_key 方法的覆盖率."""
    reader = DataReader(b"")
    decoder = GenericDecoder(reader)

    # 测试基本类型 (应按原样返回)
    assert decoder._freeze_key(1) == 1
    assert decoder._freeze_key("a") == "a"
    assert decoder._freeze_key(b"b") == b"b"
    assert decoder._freeze_key(None) is None

    # 测试列表 (应转换为元组)
    lst = [1, 2, 3]
    frozen_lst = decoder._freeze_key(lst)
    assert frozen_lst == (1, 2, 3)
    assert isinstance(frozen_lst, tuple)

    # 测试字典 (应转换为排序后的键值对元组)
    dct = {"b": 2, "a": 1}
    frozen_dct = decoder._freeze_key(dct)
    assert frozen_dct == (("a", 1), ("b", 2))

    # 测试嵌套
    nested = {"k": [1, 2]}
    frozen_nested = decoder._freeze_key(nested)
    assert frozen_nested == (("k", (1, 2)),)

    # 测试缓存 (覆盖缓存命中逻辑)
    # 使用相同对象再次调用 (ID 检查)
    frozen_lst_2 = decoder._freeze_key(lst)
    assert frozen_lst_2 is frozen_lst  # 验证缓存命中
