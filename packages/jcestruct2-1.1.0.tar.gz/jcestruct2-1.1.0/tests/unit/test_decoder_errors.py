"""decoder.py 错误处理路径测试.

测试 EOF 处理, 递归限制和其他错误条件.
"""

import struct

import pytest

from jce import JceField, JceStruct, types
from jce.decoder import DataReader, GenericDecoder, SchemaDecoder
from jce.exceptions import JceDecodeError, JcePartialDataError


def test_read_u8_eof():
    """测试 read_u8 在 EOF 时抛出异常."""
    reader = DataReader(b"", option=0)
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.read_u8()


def test_peek_u8_eof():
    """测试 peek_u8 在 EOF 时抛出异常."""
    reader = DataReader(b"", option=0)
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.peek_u8()


def test_read_bytes_eof():
    """测试 read_bytes 在 EOF 时抛出异常."""
    reader = DataReader(b"\x00\x01", option=0)
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.read_bytes(10, zero_copy=False)


def test_skip_eof():
    """测试 skip 在 EOF 时抛出异常."""
    reader = DataReader(b"\x00\x01", option=0)
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.skip(10)


def test_read_int1_eof():
    """测试 read_int1 在 EOF 时抛出异常."""
    reader = DataReader(b"", option=0)
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.read_int1()


def test_read_int2_eof():
    """测试 read_int2 在字节不足时抛出异常."""
    reader = DataReader(b"\x00", option=0)  # 仅 1 字节, 需要 2 字节
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.read_int2()


def test_read_int4_eof():
    """测试 read_int4 在字节不足时抛出异常."""
    reader = DataReader(b"\x00\x01\x02", option=0)  # 仅 3 字节, 需要 4 字节
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.read_int4()


def test_read_int8_eof():
    """测试 read_int8 在字节不足时抛出异常."""
    reader = DataReader(b"\x00\x01\x02\x03\x04\x05\x06", option=0)  # 7 字节
    with pytest.raises(JcePartialDataError, match="Not enough data"):
        reader.read_int8()


def test_eof_property():
    """测试 EOF 属性在耗尽时返回 True."""
    reader = DataReader(b"\x42", option=0)
    assert not reader.eof
    reader.read_u8()
    assert reader.eof


def test_read_bytes_negative_length():
    """测试 read_bytes 在负长度时抛出异常."""
    reader = DataReader(b"\x00\x01\x02\x03", option=0)
    with pytest.raises(JceDecodeError, match="Cannot read negative"):
        reader.read_bytes(-1, zero_copy=False)


def test_skip_negative_length():
    """测试 skip 在负长度时抛出异常."""
    reader = DataReader(b"\x00\x01\x02\x03", option=0)
    with pytest.raises(JceDecodeError, match="Cannot skip negative"):
        reader.skip(-5)


def test_recursion_limit_list():
    """测试列表嵌套的递归限制检查."""
    # 创建一个非常深的嵌套LIST结构.
    # LIST header: tag 0, type 9 (LIST) = 0x09
    # 长度1: tag 0, type 12 (ZERO_TAG) 后面是另一个LIST

    # 手动构建超过100层嵌套的数据太复杂, 直接测试内部限制.
    reader = DataReader(b"\x09\x0c", option=0)  # LIST header + length 0
    decoder = GenericDecoder(reader, option=0)

    # 强制设置递归限制为0来触发错误.
    decoder._recursion_limit = 0

    with pytest.raises(RecursionError, match="recursion limit"):
        decoder._read_list()


def test_recursion_limit_map():
    """测试 Map 嵌套的递归限制检查."""
    reader = DataReader(b"\x08\x0c", option=0)  # MAP header + length 0
    decoder = GenericDecoder(reader, option=0)
    decoder._recursion_limit = 0

    with pytest.raises(RecursionError, match="recursion limit"):
        decoder._read_map()


def test_recursion_limit_struct():
    """测试 Struct 嵌套的递归限制检查."""
    reader = DataReader(b"\x0b", option=0)  # 仅 STRUCT_END
    decoder = GenericDecoder(reader, option=0)
    decoder._recursion_limit = 0

    with pytest.raises(RecursionError, match="recursion limit"):
        decoder._read_struct()


def test_unknown_type_id():
    """测试未知类型 ID 抛出错误."""
    # Type 14 和 15 无效 (14 保留, 15 标签扩展).
    # 创建一个带有无效类型的头部.
    # Tag 0, Type 14 = 0x0E
    reader = DataReader(b"\x0e", option=0)
    decoder = GenericDecoder(reader, option=0)

    # 读取头部
    _, type_id = decoder._read_head()
    assert type_id == 14

    with pytest.raises(JceDecodeError, match="Unknown JCE Type ID"):
        decoder._read_value(type_id)


def test_schema_recursion_limit_list():
    """SchemaDecoder 检查列表递归限制."""

    class TestStruct(JceStruct):
        items: list = JceField(jce_id=0, jce_type=types.LIST, default_factory=list)

    reader = DataReader(b"\x09\x0c", option=0)
    decoder = SchemaDecoder(reader, TestStruct, option=0)
    decoder._recursion_limit = 0

    with pytest.raises(RecursionError, match="recursion limit"):
        decoder._read_list()


def test_schema_recursion_limit_map():
    """SchemaDecoder 检查 Map 递归限制."""

    class TestStruct(JceStruct):
        data: dict = JceField(jce_id=0, jce_type=types.MAP, default_factory=dict)

    reader = DataReader(b"\x08\x0c", option=0)
    decoder = SchemaDecoder(reader, TestStruct, option=0)
    decoder._recursion_limit = 0

    with pytest.raises(RecursionError, match="recursion limit"):
        decoder._read_map()


def test_schema_recursion_limit_struct():
    """SchemaDecoder 检查 Struct 嵌套递归限制."""

    class Inner(JceStruct):
        val: int = JceField(jce_id=0, default=0)

    class Outer(JceStruct):
        inner: Inner = JceField(jce_id=0)

    reader = DataReader(b"\x0b", option=0)
    decoder = SchemaDecoder(reader, Outer, option=0)
    decoder._recursion_limit = 0

    with pytest.raises(RecursionError, match="recursion limit"):
        decoder._read_struct()


def test_map_invalid_key_tag():
    """测试 Map 非零 key tag 抛出错误."""
    # MAP header: tag 0, type 8 = 0x08
    # 长度: tag 0, type 0 (BYTE), value 1 = 0x00 0x01
    # 键: tag 1 (invalid!), type 0, value 42 = 0x10 0x2a
    # 值: tag 1, type 0, value 99 = 0x10 0x63
    data = bytes(
        [
            0x08,  # MAP header (tag 0, type 8)
            0x00,
            0x01,  # 长度1 (tag 0, BYTE, value 1)
            0x10,
            0x2A,  # Key with tag 1 (invalid, should be 0)
            0x10,
            0x63,  # Value with tag 1
        ]
    )
    reader = DataReader(data, option=0)
    decoder = GenericDecoder(reader, option=0)

    # 读取MAP头部
    _, _ = decoder._read_head()
    with pytest.raises(JceDecodeError, match="Expected Map Key Tag 0"):
        decoder._read_map()


def test_map_invalid_value_tag():
    """测试 Map 非 1 value tag 抛出错误."""
    # MAP header, 长度1, Key (tag 0), Value with tag 0 (invalid)
    data = bytes(
        [
            0x08,  # MAP header
            0x00,
            0x01,  # 长度1
            0x00,
            0x2A,  # Key with tag 0, value 42
            0x00,
            0x63,  # Value with tag 0 (invalid, should be 1)
        ]
    )
    reader = DataReader(data, option=0)
    decoder = GenericDecoder(reader, option=0)

    _, _ = decoder._read_head()
    with pytest.raises(JceDecodeError, match="Expected Map Value Tag 1"):
        decoder._read_map()


def test_simple_list_invalid_type_tag():
    """测试 SimpleList 非零 type tag 抛出错误."""
    # SimpleList header: tag 0, type 13 = 0x0d
    # Type tag should be 0, but we provide tag 1
    data = bytes(
        [
            0x0D,  # SimpleList header
            0x10,  # Type header with tag 1 (invalid, should be 0)
            0x00,
            0x03,  # 长度3
            0x01,
            0x02,
            0x03,  # data
        ]
    )
    reader = DataReader(data, option=0)
    decoder = GenericDecoder(reader, option=0)

    _, _ = decoder._read_head()
    with pytest.raises(JceDecodeError, match="SimpleList expected Type Tag 0"):
        decoder._read_simple_list()


def test_simple_list_invalid_element_type():
    """测试 SimpleList 非 BYTE 元素类型抛出错误."""
    # SimpleList should only contain BYTEs (type 0).
    # Provide type 1 (INT2).
    data = bytes(
        [
            0x0D,  # SimpleList header
            0x01,  # Type header: tag 0, type 1 (INT2) - invalid
            0x00,
            0x03,  # 长度
        ]
    )
    reader = DataReader(data, option=0)
    decoder = GenericDecoder(reader, option=0)

    _, _ = decoder._read_head()
    with pytest.raises(JceDecodeError, match="SimpleList expected BYTE type"):
        decoder._read_simple_list()


def test_string4_negative_length():
    """测试 STRING4 负长度抛出错误."""
    # STRING4 header: tag 0, type 7 = 0x07
    # 长度: -1 as signed int32 = 0xffffffff

    length_bytes = struct.pack(">i", -1)
    data = bytes([0x07]) + length_bytes
    reader = DataReader(data, option=0)
    decoder = GenericDecoder(reader, option=0)

    _, type_id = decoder._read_head()
    with pytest.raises(JceDecodeError, match="cannot be negative"):
        decoder._read_value(type_id)


def test_freeze_dict_key():
    """测试 Dict 键转换为元组."""
    reader = DataReader(b"", option=0)
    decoder = GenericDecoder(reader, option=0)

    result = decoder._freeze_key({"a": 1, "b": 2})
    # 应该是一个排序后的元组
    assert isinstance(result, tuple)
    assert ("a", 1) in result
    assert ("b", 2) in result


def test_freeze_list_key():
    """测试 List 键转换为元组."""
    reader = DataReader(b"", option=0)
    decoder = GenericDecoder(reader, option=0)

    result = decoder._freeze_key([1, 2, 3])
    assert result == (1, 2, 3)


def test_freeze_nested():
    """测试嵌套结构递归冻结."""
    reader = DataReader(b"", option=0)
    decoder = GenericDecoder(reader, option=0)

    result = decoder._freeze_key({"a": [1, 2], "b": {"c": 3}})
    assert isinstance(result, tuple)


def test_freeze_immutable_passthrough():
    """测试不可变类型保持不变."""
    reader = DataReader(b"", option=0)
    decoder = GenericDecoder(reader, option=0)

    assert decoder._freeze_key("hello") == "hello"
    assert decoder._freeze_key(42) == 42
    assert decoder._freeze_key(3.14) == 3.14
    assert decoder._freeze_key(True) is True
    assert decoder._freeze_key(None) is None
    assert decoder._freeze_key(b"\x00") == b"\x00"


def test_freeze_caching():
    """测试冻结对象缓存性能."""
    reader = DataReader(b"", option=0)
    decoder = GenericDecoder(reader, option=0)

    obj = {"key": "value"}
    decoder._freeze_key(obj)
    decoder._freeze_key(obj)
    # 缓存应该命中.
    assert id(obj) in decoder._freeze_cache
