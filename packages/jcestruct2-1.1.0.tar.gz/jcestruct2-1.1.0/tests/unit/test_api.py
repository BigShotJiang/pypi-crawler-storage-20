"""api.py 覆盖率测试.

使用函数式测试风格, 每个测试函数独立且自描述.
"""

import io
import warnings
from typing import Any

import pytest

from jce import (
    JceField,
    JceStruct,
    dump,
    dumps,
    field_deserializer,
    field_serializer,
    load,
    loads,
)
from jce.context import DeserializationInfo, SerializationInfo


class _SimpleStruct(JceStruct):
    """测试用简单结构体."""

    value: int = JceField(jce_id=0, default=0)
    name: str = JceField(jce_id=1, default="")


@pytest.fixture
def simple_struct() -> _SimpleStruct:
    """创建一个简单的测试结构体."""
    return _SimpleStruct(value=42, name="test")


def test_dump_writes_to_file(tmp_path, simple_struct):
    """Dump 应该将对象序列化并写入文件."""
    filepath = tmp_path / "test.jce"

    with open(filepath, "wb") as f:
        dump(simple_struct, f)

    assert filepath.exists()
    assert filepath.stat().st_size > 0


def test_load_reads_from_file(tmp_path, simple_struct):
    """Load 应该从文件读取并反序列化对象."""
    filepath = tmp_path / "test.jce"

    with open(filepath, "wb") as f:
        dump(simple_struct, f)

    with open(filepath, "rb") as f:
        restored = load(f, _SimpleStruct)

    assert isinstance(restored, _SimpleStruct)
    assert restored.value == 42
    assert restored.name == "test"


def test_dump_load_with_bytesio(simple_struct):
    """dump/load 应该支持 BytesIO 对象."""
    buffer = io.BytesIO()
    dump(simple_struct, buffer)

    buffer.seek(0)
    restored = load(buffer, _SimpleStruct)

    assert isinstance(restored, _SimpleStruct)
    assert restored.value == simple_struct.value
    assert restored.name == simple_struct.name


def test_load_with_dict_target():
    """Load 应该支持 dict 作为目标类型."""
    data = {0: 100, 1: "hello"}
    encoded = dumps(data)

    buffer = io.BytesIO(encoded)
    result = load(buffer, dict)

    assert result[0] == 100
    assert result[1] == "hello"


def test_bytes_mode_raw_keeps_original_bytes():
    """bytes_mode='raw' 应该保持原始字节不转换."""
    data = {0: b"hello"}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="raw")

    assert result[0] == b"hello"


def test_bytes_mode_string_converts_to_utf8():
    """bytes_mode='string' 应该将字节转换为 UTF-8 字符串."""
    data = {0: "hello"}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="string")

    assert result[0] == "hello"


def test_bytes_mode_string_keeps_invalid_utf8():
    """bytes_mode='string' 遇到无效 UTF-8 时应该保持原始字节."""
    invalid_bytes = b"\xff\xfe"
    data = {0: invalid_bytes}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="string")

    assert result[0] == invalid_bytes


def test_bytes_mode_auto_parses_nested_jce():
    """bytes_mode='auto' 应该递归解析嵌套的 JCE 数据."""
    inner = {0: 42}
    inner_encoded = dumps(inner)
    outer = {0: inner_encoded}
    encoded = dumps(outer)

    result = loads(encoded, dict, bytes_mode="auto")

    assert isinstance(result[0], dict)
    assert result[0][0] == 42


def test_bytes_mode_auto_converts_ascii_string():
    """bytes_mode='auto' 应该将 ASCII 可打印字节转换为字符串."""
    data = {0: "hello world"}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="auto")

    assert result[0] == "hello world"


def test_bytes_mode_auto_keeps_binary_data():
    """bytes_mode='auto' 应该保持非可打印二进制数据为原始字节."""
    binary_data = bytes([0x00, 0x01, 0x02, 0x03])
    data = {0: binary_data}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="auto")

    assert result[0] == binary_data


def test_bytes_mode_handles_empty_bytes():
    """bytes_mode 应该正确处理空字节."""
    data = {0: b""}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="string")

    assert result[0] == ""


def test_bytes_mode_auto_converts_map_keys():
    """bytes_mode='auto' 应该转换 MAP 中的字节键."""
    inner_map = {b"key": "value"}
    data = {0: inner_map}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="auto")

    assert isinstance(result[0], dict)
    assert "key" in result[0]


def test_bytes_mode_auto_keeps_invalid_utf8_map_keys():
    """bytes_mode='auto' 应该保持无效 UTF-8 的 MAP 键为原始字节."""
    invalid_key = b"\xff\xfe"
    inner_map = {invalid_key: "value"}
    data = {0: inner_map}
    encoded = dumps(data)

    result = loads(encoded, dict, bytes_mode="auto")

    assert isinstance(result[0], dict)
    assert invalid_key in result[0]


def test_smart_decode_true_emits_deprecation_warning():
    """smart_decode=True 应该产生 DeprecationWarning."""
    data = {0: "test"}
    encoded = dumps(data)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        loads(encoded, dict, smart_decode=True)

        assert len(w) == 1
        assert issubclass(w[0].category, DeprecationWarning)
        assert "smart_decode" in str(w[0].message)


def test_smart_decode_false_emits_deprecation_warning():
    """smart_decode=False 应该产生 DeprecationWarning."""
    data = {0: "test"}
    encoded = dumps(data)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        loads(encoded, dict, smart_decode=False)

        assert len(w) == 1
        assert issubclass(w[0].category, DeprecationWarning)


def test_smart_decode_true_behaves_like_bytes_mode_auto():
    """smart_decode=True 应该等效于 bytes_mode='auto'."""
    inner = {0: 42}
    inner_encoded = dumps(inner)
    outer = {0: inner_encoded}
    encoded = dumps(outer)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = loads(encoded, dict, smart_decode=True)

    assert isinstance(result[0], dict)


def test_smart_decode_false_behaves_like_bytes_mode_raw():
    """smart_decode=False 应该等效于 bytes_mode='raw'."""
    data = {0: b"hello"}
    encoded = dumps(data)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = loads(encoded, dict, smart_decode=False)

    assert result[0] == b"hello"


def test_dumps_passes_context_to_field_serializer():
    """Dumps 应该将 context 传递给字段序列化器."""

    class _ContextStruct(JceStruct):
        data: str = JceField(jce_id=0, default="")

        @field_serializer("data")
        def serialize_data(self, value: str, info: SerializationInfo) -> str:
            prefix = info.context.get("prefix", "")
            return f"{prefix}{value}"

    obj = _ContextStruct(data="hello")
    encoded = dumps(obj, context={"prefix": "PREFIX_"})

    result = loads(encoded, dict)
    assert result[0] == "PREFIX_hello"


def test_loads_passes_context_to_field_deserializer():
    """Loads 应该将 context 传递给字段反序列化器."""

    class _ContextStruct(JceStruct):
        data: str = JceField(jce_id=0, default="")

        @classmethod
        @field_deserializer("data")
        def deserialize_data(cls, value: Any, info: DeserializationInfo) -> str:
            if isinstance(value, bytes):
                value = value.decode("utf-8")
            suffix = info.context.get("suffix", "")
            return f"{value}{suffix}"

    data = {0: "hello"}
    encoded = dumps(data)

    result = loads(encoded, _ContextStruct, context={"suffix": "_SUFFIX"})
    assert result.data == "hello_SUFFIX"


def test_dump_passes_context_to_field_serializer():
    """Dump 应该将 context 传递给字段序列化器."""

    class _ContextStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

        @field_serializer("value")
        def serialize_value(self, value: int, info: SerializationInfo) -> int:
            multiplier = info.context.get("multiplier", 1)
            return value * multiplier

    obj = _ContextStruct(value=10)
    buffer = io.BytesIO()
    dump(obj, buffer, context={"multiplier": 2})

    buffer.seek(0)
    result = loads(buffer.read(), dict)
    assert result[0] == 20


def test_load_passes_context_to_field_deserializer():
    """Load 应该将 context 传递给字段反序列化器."""

    class _ContextStruct(JceStruct):
        value: int = JceField(jce_id=0, default=0)

        @classmethod
        @field_deserializer("value")
        def deserialize_value(cls, value: int, info: DeserializationInfo) -> int:
            divisor = info.context.get("divisor", 1)
            return value // divisor

    data = {0: 100}
    encoded = dumps(data)

    buffer = io.BytesIO(encoded)
    result = load(buffer, _ContextStruct, context={"divisor": 10})
    assert isinstance(result, _ContextStruct)
    assert result.value == 10
