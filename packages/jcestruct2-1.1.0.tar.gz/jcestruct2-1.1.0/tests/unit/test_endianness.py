"""Little-Endian编码/解码测试.

测试OPT_LITTLE_ENDIAN选项的正确性.
"""

import math

from jce import JceField, JceStruct, dumps
from jce.options import OPT_LITTLE_ENDIAN
from jce.types import DOUBLE, FLOAT, INT, INT64


class LeStruct(JceStruct):
    """小端测试结构体."""

    i: int = JceField(jce_id=0, jce_type=INT)
    long_val: int = JceField(jce_id=1, jce_type=INT64, default=0)
    f: float = JceField(jce_id=2, jce_type=FLOAT, default=0.0)
    d: float = JceField(jce_id=3, jce_type=DOUBLE, default=0.0)


def test_little_endian_encoding() -> None:
    """测试小端编码和解码的正确性."""
    s = LeStruct(i=1000, long_val=10000000000, f=math.pi, d=12345.6789)
    encoded = dumps(s, option=OPT_LITTLE_ENDIAN)

    # Verify INT2 (1000) is little endian: 0x3E8 -> E8 03
    # Tag 0, Type 1 (INT2) -> 0x01
    # Val -> E8 03
    assert encoded[0] == 0x01
    assert encoded[1:3] == b"\xe8\x03"

    # Decode back
    decoded = LeStruct.decode(encoded, option=OPT_LITTLE_ENDIAN)
    assert decoded.i == 1000
    assert decoded.long_val == 10000000000
    assert abs(decoded.f - math.pi) < 0.0001
    assert abs(decoded.d - 12345.6789) < 0.0001


def test_mixed_endian_error() -> None:
    """测试用大端解码小端数据会产生错误的值."""
    # Attempt to decode LE data as BE should produce wrong values or error
    s = LeStruct(i=1000)
    encoded = dumps(s, option=OPT_LITTLE_ENDIAN)  # 01 E8 03

    # Decoding as BE (default)
    # 01 -> Tag 0 INT2
    # E8 03 -> BE value is -6141 (signed short) or 59395 (unsigned)
    # struct.unpack(">h", b"\xE8\x03") -> -6141
    decoded = LeStruct.decode(encoded, option=0)
    assert decoded.i != 1000
    assert decoded.i == -6141
