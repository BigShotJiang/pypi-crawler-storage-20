"""jce/types.py 中 from_bytes 方法的测试.

测试 INT8/16/32/64, STRING1/4, FLOAT/DOUBLE 的 from_bytes 方法.
"""

import struct

import pytest

from jce.types import (
    BOOL,
    BYTE,
    DOUBLE,
    FLOAT,
    INT,
    INT8,
    INT16,
    INT32,
    INT64,
    STRING,
    STRING1,
    STRING4,
    ZERO_TAG,
)


def test_int8_from_bytes_positive():
    """测试 INT8.from_bytes 正数值."""
    data = struct.pack(">b", 100)
    value, consumed = INT8.from_bytes(data)
    assert value == 100
    assert consumed == 1


def test_int8_from_bytes_negative():
    """测试 INT8.from_bytes 负数值."""
    data = struct.pack(">b", -50)
    value, consumed = INT8.from_bytes(data)
    assert value == -50
    assert consumed == 1


def test_int8_from_bytes_boundary():
    """测试 INT8.from_bytes 边界值."""
    # 最大值
    data = struct.pack(">b", 127)
    value, consumed = INT8.from_bytes(data)
    assert value == 127
    assert consumed == 1

    # 最小值
    data = struct.pack(">b", -128)
    value, consumed = INT8.from_bytes(data)
    assert value == -128
    assert consumed == 1


def test_int16_from_bytes_positive():
    """测试 INT16.from_bytes 正数值."""
    data = struct.pack(">h", 1000)
    value, consumed = INT16.from_bytes(data)
    assert value == 1000
    assert consumed == 2


def test_int16_from_bytes_negative():
    """测试 INT16.from_bytes 负数值."""
    data = struct.pack(">h", -5000)
    value, consumed = INT16.from_bytes(data)
    assert value == -5000
    assert consumed == 2


def test_int16_from_bytes_boundary():
    """测试 INT16.from_bytes 边界值."""
    data = struct.pack(">h", 32767)
    value, _ = INT16.from_bytes(data)
    assert value == 32767

    data = struct.pack(">h", -32768)
    value, _ = INT16.from_bytes(data)
    assert value == -32768


def test_int32_from_bytes_positive():
    """测试 INT32.from_bytes 正数值."""
    data = struct.pack(">i", 100000)
    value, consumed = INT32.from_bytes(data)
    assert value == 100000
    assert consumed == 4


def test_int32_from_bytes_negative():
    """测试 INT32.from_bytes 负数值."""
    data = struct.pack(">i", -100000)
    value, consumed = INT32.from_bytes(data)
    assert value == -100000
    assert consumed == 4


def test_int32_from_bytes_boundary():
    """测试 INT32.from_bytes 边界值."""
    data = struct.pack(">i", 2147483647)
    value, _ = INT32.from_bytes(data)
    assert value == 2147483647

    data = struct.pack(">i", -2147483648)
    value, _ = INT32.from_bytes(data)
    assert value == -2147483648


def test_int64_from_bytes_positive():
    """测试 INT64.from_bytes 正数值."""
    data = struct.pack(">q", 10000000000)
    value, consumed = INT64.from_bytes(data)
    assert value == 10000000000
    assert consumed == 8


def test_int64_from_bytes_negative():
    """测试 INT64.from_bytes 负数值."""
    data = struct.pack(">q", -10000000000)
    value, consumed = INT64.from_bytes(data)
    assert value == -10000000000
    assert consumed == 8


def test_int_validate_from_1byte():
    """测试 INT.validate 自动检测 1 字节编码."""
    data = struct.pack(">b", 42)
    result = INT.validate(data)
    assert result == 42
    assert isinstance(result, INT)


def test_int_validate_from_2bytes():
    """测试 INT.validate 自动检测 2 字节编码."""
    data = struct.pack(">h", 1000)
    result = INT.validate(data)
    assert result == 1000
    assert isinstance(result, INT)


def test_int_validate_from_4bytes():
    """测试 INT.validate 自动检测 4 字节编码."""
    data = struct.pack(">i", 100000)
    result = INT.validate(data)
    assert result == 100000
    assert isinstance(result, INT)


def test_int_validate_from_8bytes():
    """测试 INT.validate 自动检测 8 字节编码."""
    data = struct.pack(">q", 10000000000)
    result = INT.validate(data)
    assert result == 10000000000
    assert isinstance(result, INT)


def test_int_validate_invalid_length():
    """测试 INT.validate 拒绝无效的字节长度."""
    with pytest.raises(ValueError, match="Invalid value length"):
        INT.validate(b"\x00\x00\x00")  # 3 字节无效


def test_int_validate_from_int():
    """测试 INT.validate 直接接受 int."""
    result = INT.validate(12345)
    assert result == 12345
    assert isinstance(result, INT)


def test_int_validate_invalid_type():
    """测试 INT.validate 拒绝无效类型."""
    with pytest.raises(TypeError, match="Invalid value type"):
        INT.validate("not an int")


def test_string1_from_bytes_ascii():
    """测试 STRING1.from_bytes 处理 ASCII 文本."""
    text = "hello"
    encoded = text.encode()
    data = struct.pack(">B", len(encoded)) + encoded
    value, consumed = STRING1.from_bytes(data)
    assert value == "hello"
    assert consumed == 1 + len(encoded)


def test_string1_from_bytes_unicode():
    """测试 STRING1.from_bytes 处理 Unicode 文本."""
    text = "你好"
    encoded = text.encode()
    data = struct.pack(">B", len(encoded)) + encoded
    value, consumed = STRING1.from_bytes(data)
    assert value == "你好"
    assert consumed == 1 + len(encoded)


def test_string1_from_bytes_empty():
    """测试 STRING1.from_bytes 处理空字符串."""
    data = struct.pack(">B", 0)
    value, consumed = STRING1.from_bytes(data)
    assert value == ""
    assert consumed == 1


def test_string4_from_bytes_ascii():
    """测试 STRING4.from_bytes 处理 ASCII 文本."""
    text = "hello world"
    encoded = text.encode()
    data = struct.pack(">I", len(encoded)) + encoded
    value, consumed = STRING4.from_bytes(data)
    assert value == "hello world"
    assert consumed == 4 + len(encoded)


def test_string4_from_bytes_unicode():
    """测试 STRING4.from_bytes 处理 Unicode 文本."""
    text = "世界你好"
    encoded = text.encode()
    data = struct.pack(">I", len(encoded)) + encoded
    value, consumed = STRING4.from_bytes(data)
    assert value == "世界你好"
    assert consumed == 4 + len(encoded)


def test_string4_from_bytes_empty():
    """测试 STRING4.from_bytes 处理空字符串."""
    data = struct.pack(">I", 0)
    value, consumed = STRING4.from_bytes(data)
    assert value == ""
    assert consumed == 4


def test_string_validate_from_bytes():
    """测试 STRING.validate 自动解码 bytes."""
    data = b"hello"
    result = STRING.validate(data)
    assert result == "hello"
    assert isinstance(result, STRING)


def test_string_validate_from_str():
    """测试 STRING.validate 直接接受 str."""
    result = STRING.validate("hello")
    assert result == "hello"
    assert isinstance(result, STRING)


def test_string_validate_invalid_type():
    """测试 STRING.validate 拒绝无效类型."""
    with pytest.raises(TypeError, match="Invalid value type"):
        STRING.validate(12345)


def test_float_from_bytes():
    """测试 FLOAT.from_bytes 正常值."""
    data = struct.pack(">f", 3.14)
    value, consumed = FLOAT.from_bytes(data)
    assert abs(value - 3.14) < 0.001
    assert consumed == 4


def test_float_validate_from_bytes():
    """测试 FLOAT.validate 从 bytes."""
    data = struct.pack(">f", 2.5)
    result = FLOAT.validate(data)
    assert abs(result - 2.5) < 0.001
    assert isinstance(result, FLOAT)


def test_float_validate_from_float():
    """测试 FLOAT.validate 从 float."""
    result = FLOAT.validate(1.5)
    assert result == 1.5
    assert isinstance(result, FLOAT)


def test_float_validate_from_int():
    """测试 FLOAT.validate 从 int (自动转换)."""
    result = FLOAT.validate(5)
    assert result == 5.0
    assert isinstance(result, FLOAT)


def test_float_validate_invalid_type():
    """测试 FLOAT.validate 拒绝无效类型."""
    with pytest.raises(TypeError, match="Invalid value type"):
        FLOAT.validate("not a float")


def test_double_from_bytes():
    """测试 DOUBLE.from_bytes 正常值."""
    data = struct.pack(">d", 3.141592653589793)
    value, consumed = DOUBLE.from_bytes(data)
    assert abs(value - 3.141592653589793) < 1e-15
    assert consumed == 8


def test_double_validate_from_bytes():
    """测试 DOUBLE.validate 从 bytes."""
    data = struct.pack(">d", 2.718281828459045)
    result = DOUBLE.validate(data)
    assert abs(result - 2.718281828459045) < 1e-15
    assert isinstance(result, DOUBLE)


def test_double_validate_from_float():
    """测试 DOUBLE.validate 从 float."""
    result = DOUBLE.validate(1.5)
    assert result == 1.5
    assert isinstance(result, DOUBLE)


def test_double_validate_from_int():
    """测试 DOUBLE.validate 从 int (自动转换)."""
    result = DOUBLE.validate(10)
    assert result == 10.0
    assert isinstance(result, DOUBLE)


def test_double_validate_invalid_type():
    """测试 DOUBLE.validate 拒绝无效类型."""
    with pytest.raises(TypeError, match="Invalid value type"):
        DOUBLE.validate("not a double")


def test_bool_from_bytes_true():
    """测试 BOOL.from_bytes (True)."""
    data = struct.pack(">?", True)
    value, consumed = BOOL.from_bytes(data)
    assert value is True
    assert consumed == 1


def test_bool_from_bytes_false():
    """测试 BOOL.from_bytes (False)."""
    data = struct.pack(">?", False)
    value, consumed = BOOL.from_bytes(data)
    assert value is False
    assert consumed == 1


def test_bool_validate_from_bytes():
    """测试 BOOL.validate 从 bytes."""
    data = b"\x01"
    result = BOOL.validate(data)
    assert result
    assert isinstance(result, BOOL)


def test_bool_validate_from_int():
    """测试 BOOL.validate 从 int."""
    result = BOOL.validate(1)
    assert result
    assert isinstance(result, BOOL)


def test_bool_validate_invalid_bytes_length():
    """测试 BOOL.validate 拒绝错误的字节长度."""
    with pytest.raises(ValueError, match="Invalid byte length"):
        BOOL.validate(b"\x00\x01")


def test_bool_validate_invalid_type():
    """测试 BOOL.validate 拒绝无效类型."""
    with pytest.raises(TypeError, match="Invalid value type"):
        BOOL.validate("not a bool")


def test_byte_from_bytes():
    """测试 BYTE.from_bytes 返回单个字节."""
    data = b"\x42"
    value, consumed = BYTE.from_bytes(data)
    assert value == b"\x42"
    assert consumed == 1


def test_zero_tag_from_bytes():
    """测试 ZERO_TAG.from_bytes 返回零字节."""
    data = b""  # ZERO_TAG has no data
    value, consumed = ZERO_TAG.from_bytes(data)
    assert value == b"\x00"
    assert consumed == 0
