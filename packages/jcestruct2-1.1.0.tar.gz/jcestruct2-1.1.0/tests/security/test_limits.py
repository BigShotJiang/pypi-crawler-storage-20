"""测试 JCE 解码器的安全限制, 防止 DoS 攻击."""

import struct

import pytest

from jce import JceDecodeError
from jce.decoder import (
    MAX_CONTAINER_SIZE,
    MAX_STRING_LENGTH,
    DataReader,
    GenericDecoder,
)


def test_negative_list_length():
    """测试负数列表长度抛出错误."""
    # LIST header: tag 0, type LIST (9)
    # Length header: tag 0, type INT1 (0) -> value -1 (0xFF)
    # 注意: read_int1 读取 signed byte.
    data = bytearray()
    data.append(0x09)  # Tag 0, LIST
    data.append(0x00)  # Tag 0, INT1 (Length)
    data.extend(struct.pack(">b", -1))

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="Container length cannot be negative"):
        decoder.decode()


def test_huge_list_length():
    """测试超大列表长度抛出错误 (DoS防护)."""
    limit = MAX_CONTAINER_SIZE + 1

    data = bytearray()
    data.append(0x09)  # Tag 0, LIST
    data.append(0x02)  # Tag 0, INT4 (Length)
    data.extend(struct.pack(">i", limit))

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="exceeds max limit"):
        decoder.decode()


def test_negative_string4_length():
    """测试负数 STRING4 长度."""
    data = bytearray()
    data.append(0x07)  # Tag 0, STRING4
    data.extend(struct.pack(">i", -100))  # Length -100

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="String4 length cannot be negative"):
        decoder.decode()


def test_huge_string4_length():
    """测试超大 STRING4 长度."""
    limit = MAX_STRING_LENGTH + 1

    data = bytearray()
    data.append(0x07)  # Tag 0, STRING4
    data.extend(struct.pack(">i", limit))

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="exceeds max limit"):
        decoder.decode()


def test_datareader_read_negative():
    """测试 DataReader 底层拒绝负数读取."""
    reader = DataReader(b"123")
    with pytest.raises(JceDecodeError, match="Cannot read negative bytes"):
        reader.read_bytes(-1)


def test_datareader_skip_negative():
    """测试 DataReader 底层拒绝负数跳过."""
    reader = DataReader(b"123")
    with pytest.raises(JceDecodeError, match="Cannot skip negative bytes"):
        reader.skip(-1)
