"""解码容错性测试.

测试解码器对无效输入的处理, 确保抛出正确的错误类型.
"""

import struct

import pytest

from jce import JceDecodeError
from jce.decoder import DataReader, GenericDecoder


def test_invalid_length_type_in_list():
    """测试为列表长度提供非整数类型(例如 float)时抛出 JceDecodeError.

    验证不会抛出 TypeError 或其他意外错误.
    """
    # 构造 JCE 流:
    # Tag 0, 类型 LIST (9)
    # 长度部分: Tag 0, 类型 FLOAT (4) -> 值 1.0 (无效长度)

    # List 头部: Tag 0 (0x00) | 类型 LIST (9) -> 0x09
    # Length 头部: Tag 0 (0x00) | 类型 FLOAT (4) -> 0x04
    # 浮点值 1.0: 3f 80 00 00 (大端序)

    data = bytearray()
    data.append(0x09)  # List
    data.append(0x04)  # Length is Float

    data.extend(struct.pack(">f", 1.0))  # 1.0

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="Expected integer for length"):
        decoder.decode()


def test_invalid_length_type_in_map():
    """测试为 Map 长度提供非整数类型时抛出 JceDecodeError."""
    # Tag 0, 类型 MAP (8)
    # 长度部分: Tag 0, 类型 FLOAT (4) -> 值 1.0

    data = bytearray()
    data.append(0x08)  # Map
    data.append(0x04)  # Length is Float

    data.extend(struct.pack(">f", 1.0))

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="Expected integer for length"):
        decoder.decode()


def test_invalid_length_type_in_simple_list():
    """测试为 SimpleList 长度提供非整数类型时抛出 JceDecodeError."""
    # Tag 0, 类型 SimpleList (13)
    # 头部类型标签: Tag 0, 类型 BYTE (0) -> 0x00
    # 长度部分: Tag 0, 类型 FLOAT (4) -> 值 1.0

    data = bytearray()
    data.append(0x0D)  # SimpleList
    data.append(0x00)  # Type Byte (SimpleList 头部必须)
    data.append(0x04)  # Length is Float

    data.extend(struct.pack(">f", 1.0))

    reader = DataReader(data)
    decoder = GenericDecoder(reader)

    with pytest.raises(JceDecodeError, match="Expected integer for length"):
        decoder.decode()
