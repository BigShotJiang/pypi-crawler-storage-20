"""测试 JCE 编码是否符合协议规范."""

from jce import JceField, JceStruct
from jce.decoder import DataReader, GenericDecoder
from jce.encoder import JceEncoder


def encode_val(val, tag):
    """编码单个值并返回字节序列."""
    encoder = JceEncoder()
    encoder.encode_value(val, tag)
    return encoder._writer.get_bytes()


def test_bytes_simple_list_compliance():
    """Verify BYTES encoding matches SimpleList spec."""
    # Spec: [Tag][Type=13] [Tag=0][Type=0] [Length(JCE Int)] [Data]
    val = b"hello"
    # Tag 1
    encoded = encode_val(val, 1)

    # Analyze bytes
    # Tag 1, Type 13 -> 0x1D
    # Head 0, Type 0 -> 0x00
    # Length 5 (INT1, Tag 0) -> 0x00 0x05 (Head 0 Type 0, Value 5)
    # Data -> 68 65 6c 6c 6f

    expected = bytes.fromhex("1D 00 00 05 68 65 6c 6c 6f")
    assert encoded == expected

    # Decode back using GenericDecoder to verify structure
    reader = DataReader(encoded)
    decoder = GenericDecoder(reader)
    decoded = decoder.decode()
    assert decoded[1] == val


def test_string1_compliance():
    """Verify STRING1 (len < 256) compliance."""
    # Spec: [Tag][Type=6] [Len(1 byte)] [Data]
    val = "A" * 10
    encoded = encode_val(val, 2)

    # Tag 2, Type 6 -> 0x26
    # Len 10 -> 0x0A
    # Data -> ...
    expected = bytes([0x26, 0x0A]) + val.encode()
    assert encoded == expected

    reader = DataReader(encoded)
    decoder = GenericDecoder(reader)
    decoded = decoder.decode()
    # GenericDecoder returns bytes for strings, as it doesn't know it's a string
    assert decoded[2] == val.encode()


def test_string4_compliance():
    """Verify STRING4 (len >= 256) compliance."""
    # Spec: [Tag][Type=7] [Len(4 bytes BE)] [Data]
    val = "A" * 256
    encoded = encode_val(val, 2)

    # Tag 2, Type 7 -> 0x27
    # Len 256 -> 00 00 01 00
    expected = bytes([0x27, 0x00, 0x00, 0x01, 0x00]) + val.encode()
    assert encoded == expected

    reader = DataReader(encoded)
    decoder = GenericDecoder(reader)
    decoded = decoder.decode()
    # GenericDecoder returns bytes for strings
    assert decoded[2] == val.encode()


def test_int_zero_tag_compliance():
    """Verify 0 is encoded as ZERO_TAG."""
    # Spec: [Tag][Type=12]
    encoded = encode_val(0, 3)

    # Tag 3, Type 12 (0xC) -> 0x3C
    expected = bytes([0x3C])
    assert encoded == expected

    reader = DataReader(encoded)
    decoder = GenericDecoder(reader)
    decoded = decoder.decode()
    assert decoded[3] == 0


def test_int_ranges():
    """Verify INT encoding ranges."""
    # INT1: -128 ~ 127 (Type 0)
    # Tag 3, Type 0 -> 0x30
    # Value 1 -> 0x01
    assert encode_val(1, 3) == bytes([0x30, 0x01])
    assert encode_val(-1, 3) == bytes([0x30, 0xFF])

    # INT2: -32768 ~ 32767 (Type 1)
    # Tag 3, Type 1 -> 0x31
    # Value 128 -> 00 80
    assert encode_val(128, 3) == bytes([0x31, 0x00, 0x80])

    # INT4: (Type 2)
    # Value 32768 -> 00 00 80 00
    assert encode_val(32768, 3) == bytes([0x32, 0x00, 0x00, 0x80, 0x00])

    # INT8: (Type 3)
    # Value 2147483648 -> 00 00 00 00 80 00 00 00
    assert encode_val(2147483648, 3) == bytes(
        [
            0x33,
            0x00,
            0x00,
            0x00,
            0x00,
            0x80,
            0x00,
            0x00,
            0x00,
        ]
    )


def test_struct_persistence():
    """Verify STRUCT_BEGIN and STRUCT_END."""

    class Inner(JceStruct):
        a: int = JceField(jce_id=0)

    class Outer(JceStruct):
        inner: Inner = JceField(jce_id=1)

    o = Outer(inner=Inner(a=99))
    encoded = o.encode()

    # Tag 1, Type 10 (Struct Begin) -> 0x1A
    # Inner Content: Tag 0, Type 0, Val 99 -> 0x00 0x63
    # End Marker: Tag 0, Type 11 (Struct End) -> 0x0B

    expected = bytes([0x1A, 0x00, 0x63, 0x0B])
    assert encoded == expected

    decoded = Outer.decode(encoded)
    assert decoded.inner.a == 99
