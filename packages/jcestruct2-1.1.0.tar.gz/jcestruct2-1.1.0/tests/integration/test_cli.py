"""测试 JCE 解码的命令行接口."""

import json
import tempfile
from pathlib import Path

import pytest

from jce import dumps

try:
    import click
    from click.testing import CliRunner

    from jce.__main__ import cli
except ImportError:
    click = None
    CliRunner = None  # type: ignore
    cli = None  # type: ignore


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_decode_hex_arg():
    """测试通过命令行参数解码十六进制数据."""
    assert CliRunner is not None
    assert cli is not None

    # 编码一些测试数据.
    test_data = {0: 42, 1: "hello"}
    encoded = dumps(test_data)
    hex_str = encoded.hex()

    runner = CliRunner()
    result = runner.invoke(cli, [hex_str])

    assert result.exit_code == 0
    assert "42" in result.output
    assert "hello" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_decode_hex_file():
    """测试从文件解码十六进制数据."""
    assert CliRunner is not None
    assert cli is not None

    test_data = {0: 100, 1: "world"}
    encoded = dumps(test_data)
    hex_str = encoded.hex()

    with tempfile.NamedTemporaryFile(mode="w", suffix=".hex", delete=False) as f:
        f.write(hex_str)
        temp_path = f.name

    try:
        runner = CliRunner()
        result = runner.invoke(cli, ["-f", temp_path])

        assert result.exit_code == 0
        assert "100" in result.output
        assert "world" in result.output
    finally:
        Path(temp_path).unlink()


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_json_format_output():
    """测试 JSON 格式输出."""
    assert CliRunner is not None
    assert cli is not None

    test_data = {0: 123}
    encoded = dumps(test_data)
    hex_str = encoded.hex()

    runner = CliRunner()
    result = runner.invoke(cli, [hex_str, "--format", "json"])

    assert result.exit_code == 0
    parsed = json.loads(result.output)
    assert parsed["0"] == 123


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_output_to_file():
    """测试保存输出到文件."""
    assert CliRunner is not None
    assert cli is not None

    test_data = {0: 999}
    encoded = dumps(test_data)
    hex_str = encoded.hex()

    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        output_path = f.name

    try:
        runner = CliRunner()
        # output_path exists (created by tempfile), verify overwrite works
        result = runner.invoke(cli, [hex_str, "-o", output_path])

        assert result.exit_code == 0
        # 验证文件内容.
        content = Path(output_path).read_text(encoding="utf-8")
        assert "999" in content
        assert f"结果已保存到: {output_path}" in result.output
    finally:
        Path(output_path).unlink()


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_output_file_json_format():
    """测试保存 JSON 格式到文件."""
    assert CliRunner is not None
    assert cli is not None

    test_data = {0: 777}
    encoded = dumps(test_data)
    hex_str = encoded.hex()

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        output_path = f.name

    try:
        runner = CliRunner()
        result = runner.invoke(cli, [hex_str, "--format", "json", "-o", output_path])

        assert result.exit_code == 0
        content = Path(output_path).read_text(encoding="utf-8")
        parsed = json.loads(content)
        assert parsed["0"] == 777
    finally:
        Path(output_path).unlink()


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_verbose_output():
    """测试详细模式显示调试信息."""
    assert CliRunner is not None
    assert cli is not None

    test_data = {0: 1}
    encoded = dumps(test_data)
    hex_str = encoded.hex()

    runner = CliRunner()
    result = runner.invoke(cli, [hex_str, "-v"])

    assert result.exit_code == 0
    assert "[DEBUG]" in result.output
    assert "原始十六进制数据" in result.output or "字节" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_file_not_found():
    """测试文件不存在时的错误处理."""
    assert CliRunner is not None
    assert cli is not None

    runner = CliRunner()
    result = runner.invoke(cli, ["-f", "/nonexistent/file.hex"])
    assert result.exit_code != 0
    assert "不存在" in result.output or "Error" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_invalid_hex_format():
    """测试无效的十六进制字符串错误."""
    assert CliRunner is not None
    assert cli is not None

    runner = CliRunner()
    result = runner.invoke(cli, ["ZZZZ"])  # Invalid hex
    assert result.exit_code != 0
    assert "无效的十六进制格式" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_invalid_hex_odd_length():
    """测试奇数长度的十六进制字符串错误."""
    assert CliRunner is not None
    assert cli is not None

    runner = CliRunner()
    result = runner.invoke(cli, ["ABC"])  # Odd length
    assert result.exit_code != 0
    assert "无效的十六进制格式" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_invalid_jce_data():
    """测试无效的 JCE 数据错误."""
    assert CliRunner is not None
    assert cli is not None

    # 无效的JCE数据(随机字节).
    runner = CliRunner()
    result = runner.invoke(cli, ["FFFFFFFFFF"])
    assert result.exit_code != 0
    assert "解码失败" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_verbose_shows_traceback_on_error():
    """测试详细模式下显示回溯信息."""
    assert CliRunner is not None
    assert cli is not None

    runner = CliRunner()
    result = runner.invoke(cli, ["ZZZZ", "-v"])
    assert result.exit_code != 0
    assert "Traceback" in result.output or "Error" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_missing_args():
    """测试缺少参数时的错误."""
    assert CliRunner is not None
    assert cli is not None

    runner = CliRunner()
    result = runner.invoke(cli, [])
    assert result.exit_code != 0
    assert "必须指定 ENCODED 数据或 --file 参数" in result.output


@pytest.mark.skipif(click is None, reason="click is not installed")
def test_conflicting_args():
    """测试同时指定编码数据和文件时的错误."""
    assert CliRunner is not None
    assert cli is not None

    runner = CliRunner()
    # Creating a dummy file to pass existing check
    with tempfile.NamedTemporaryFile() as f:
        result = runner.invoke(cli, ["ABC", "-f", f.name])
        assert result.exit_code != 0
        assert "不能同时指定" in result.output

    def test_auto_convert_bytes_dict():
        """测试 _convert_bytes_recursive 处理字典."""
        from jce.api import _convert_bytes_recursive

        data = {b"key": b"value", b"num": 123}
        result = _convert_bytes_recursive(data, mode="auto")
        assert result["key"] == "value"
        assert result["num"] == 123
        # 原始bytes键应该保留还是被删除?
        # _convert_bytes_recursive 会创建一个新字典.
        # 如果键被解码为str, 那么旧的bytes键就不存在了.
        # 但是如果原始data中有bytes键, result中是str键.
        assert b"key" not in result

    def test_auto_convert_bytes_list():
        """测试 _convert_bytes_recursive 处理列表."""
        from jce.api import _convert_bytes_recursive

        data = [b"item1", b"item2", 123]
        result = _convert_bytes_recursive(data, mode="auto")
        assert result == ["item1", "item2", 123]

    def test_auto_convert_bytes_nested():
        """测试 _convert_bytes_recursive 处理嵌套结构."""
        from jce.api import _convert_bytes_recursive

        data = {b"list": [b"nested", {b"inner": b"val"}]}
        result = _convert_bytes_recursive(data, mode="auto")
        assert result["list"][0] == "nested"
        assert result["list"][1]["inner"] == "val"

    def test_auto_convert_bytes_non_smart():
        """测试 _convert_bytes_recursive 原始模式."""
        from jce.api import _convert_bytes_recursive

        data = {b"key": b"value"}
        result = _convert_bytes_recursive(data, mode="raw")
        assert result[b"key"] == b"value"

    def test_auto_convert_bytes_empty():
        """测试 _convert_bytes_recursive 处理空 bytes."""
        from jce.api import _convert_bytes_recursive

        assert _convert_bytes_recursive(b"", mode="auto") == ""

    def test_auto_convert_bytes_non_utf8():
        """测试 _convert_bytes_recursive 处理非 UTF-8 bytes."""
        from jce.api import _convert_bytes_recursive

        # 0xFF 是无效的 UTF-8 start byte
        data = b"\xff\xff"
        assert _convert_bytes_recursive(data, mode="auto") == data


def test_is_valid_printable_string_ascii():
    """测试 _is_valid_printable_string 的 ASCII 模式."""
    from jce.api import _is_valid_printable_string

    assert _is_valid_printable_string("hello", ascii_only=True)
    assert _is_valid_printable_string("Hello World!", ascii_only=True)
    assert not _is_valid_printable_string("你好", ascii_only=True)
    assert not _is_valid_printable_string("\x00\x01", ascii_only=True)


def test_is_valid_printable_string_unicode():
    """测试 _is_valid_printable_string 的 Unicode 模式."""
    from jce.api import _is_valid_printable_string

    assert _is_valid_printable_string("hello", ascii_only=False)
    assert _is_valid_printable_string("你好", ascii_only=False)
    assert _is_valid_printable_string("Hello\nWorld", ascii_only=False)
    assert _is_valid_printable_string("Tab\there", ascii_only=False)


def test_is_valid_printable_string_empty():
    """测试 _is_valid_printable_string 处理空字符串."""
    from jce.api import _is_valid_printable_string

    assert _is_valid_printable_string("", ascii_only=True)
    assert _is_valid_printable_string("", ascii_only=False)
