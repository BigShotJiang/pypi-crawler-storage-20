"""JCE通用编解码测试."""

from jce import JceField, JceStruct, dumps, loads, types


class SimpleStruct(JceStruct):
    """简单测试结构体."""

    a: int = JceField(jce_id=0, jce_type=types.INT)
    b: str = JceField(jce_id=1, jce_type=types.STRING)


def test_dumps_loads_struct() -> None:
    """测试结构体序列化和反序列化."""
    s = SimpleStruct(a=123, b="hello")
    data = dumps(s)

    # 作为结构体加载
    s2 = loads(data, SimpleStruct)
    assert s.a == s2.a
    assert s.b == s2.b

    # 作为字典加载
    d = loads(data, dict)
    assert d[0] == 123
    assert d[1] == "hello"  # 通用解码器解码字符串


def test_dumps_dict() -> None:
    """测试字典序列化."""
    # 将字典作为结构体转储
    d = {0: 123, 1: "hello"}
    data = dumps(d)

    # 加载回
    d2 = loads(data, dict)
    assert d2[0] == 123
    assert d2[1] == "hello"


def test_nested_generic() -> None:
    """测试嵌套通用类型."""
    # 包含列表的结构体
    # 我们目前无法轻松定义嵌套结构体而没有用于转储的JceStruct类
    # 除非我们在字典中手动构造带有标签的数据.

    # {0: [1, 2, 3]} -> 标签 0 是整数列表
    d = {0: [1, 2, 3]}
    data = dumps(d)

    d2 = loads(data, dict)
    assert d2[0] == [1, 2, 3]


def test_generic_struct() -> None:
    """测试泛型结构体支持."""
    from typing import Generic, TypeVar

    T = TypeVar("T")

    class Box(JceStruct, Generic[T]):
        content: T = JceField(jce_id=0)

    # 测试 Box[int]
    box_int = Box[int](content=42)
    data = dumps(box_int)
    decoded_int = loads(data, Box[int])
    assert decoded_int.content == 42

    # 测试 Box[str]
    box_str = Box[str](content="generic")
    data = dumps(box_str)
    decoded_str = loads(data, Box[str])
    assert decoded_str.content == "generic"

    # 测试 Box[list[int]]
    box_list = Box[list[int]](content=[1, 2])
    data = dumps(box_list)
    decoded_list = loads(data, Box[list[int]])
    assert decoded_list.content == [1, 2]

    # 测试 Box[JceStruct] (嵌套结构体)
    class Inner(JceStruct):
        val: int = JceField(jce_id=1)

    box_struct = Box[Inner](content=Inner(val=99))
    data = dumps(box_struct)
    decoded_struct = loads(data, Box[Inner])
    assert decoded_struct.content.val == 99
