"""泛型dict/list类型推断测试.

测试JceStruct对dict和list泛型参数的支持.
"""

from typing import Generic, TypeVar

import pytest

from jce import JceField, JceStruct

DataT = TypeVar("DataT")


class Wrapper(JceStruct, Generic[DataT]):
    """泛型包装器结构体."""

    data: DataT | None = JceField(jce_id=0)


def test_generic_dict_instantiation() -> None:
    """Test that JceStruct with dict as generic argument works correctly."""
    # When Wrapper[dict] is created, data field should be recognized as MAP

    # Check if data field is present in __jce_fields__
    wrapper_cls = Wrapper[dict]
    if (
        not hasattr(wrapper_cls, "__jce_fields__")
        or "data" not in wrapper_cls.__jce_fields__
    ):
        # This confirms the issue: field was skipped because type inference failed
        pytest.fail(
            "Field 'data' was skipped in Wrapper[dict] because JCE type inference failed for 'dict'"
        )

    # Presence of field is enough to prove fix.
    assert "data" in wrapper_cls.__jce_fields__

    # Test round trip
    input_data = {"key": "value"}
    w = wrapper_cls(data=input_data)
    encoded = w.encode()
    decoded = wrapper_cls.decode(encoded)

    # Note: JCE strings are decoded as bytes when type information is missing (generic dict/list)
    # So we expect bytes here.
    expected_data = {b"key": b"value"}
    assert decoded.data == expected_data
    assert isinstance(decoded.data, dict)


def test_generic_list_instantiation() -> None:
    """Test that JceStruct with list as generic argument works correctly."""
    wrapper_cls = Wrapper[list]
    if (
        not hasattr(wrapper_cls, "__jce_fields__")
        or "data" not in wrapper_cls.__jce_fields__
    ):
        pytest.fail(
            "Field 'data' was skipped in Wrapper[list] because JCE type inference failed for 'list'"
        )

    input_data = ["item1", "item2"]
    w = wrapper_cls(data=input_data)
    encoded = w.encode()
    decoded = wrapper_cls.decode(encoded)

    # Note: JCE strings are decoded as bytes when type information is missing
    expected_data = [b"item1", b"item2"]
    assert decoded.data == expected_data
    assert isinstance(decoded.data, list)
