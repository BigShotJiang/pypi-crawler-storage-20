"""Tests for JCE streaming functionality."""

import pytest

from jce import (
    JceField,
    JcePacker,
    JceStruct,
    LengthPrefixedPacker,
    LengthPrefixedUnpacker,
    types,
)


class Simple(JceStruct):
    """用于测试的简单 JCE 结构体."""

    a: int = JceField(jce_id=0, jce_type=types.INT)
    b: str = JceField(jce_id=1, jce_type=types.STRING)


def test_jce_packer_basic():
    """JcePacker 应该能正确打包多个对象到连续缓冲区."""
    packer = JcePacker()
    obj1 = Simple(a=1, b="one")
    obj2 = Simple(a=2, b="two")

    packer.pack(obj1)
    packer.pack(obj2)

    buffer = packer.get_buffer()
    assert len(buffer) > 0
    # 手动检查: obj1 编码 + obj2 编码
    expected1 = obj1.encode()
    expected2 = obj2.encode()
    assert buffer == expected1 + expected2


def test_length_prefixed_packer_4bytes():
    """LengthPrefixedPacker 应该在数据前添加 4 字节长度头."""
    packer = LengthPrefixedPacker(length_type=4)
    obj = Simple(a=1, b="test")
    packer.pack(obj)

    data = packer.get_buffer()
    # 头 4 字节 + 包体
    assert len(data) == 4 + len(obj.encode())

    # 检查长度 (默认大端序)
    length = int.from_bytes(data[:4], "big")
    assert length == len(data)  # 包含头部长度


def test_length_prefixed_unpacker_4bytes():
    """LengthPrefixedUnpacker 应该能从分块数据中解析出完整对象."""
    packer = LengthPrefixedPacker(length_type=4)
    objs = [Simple(a=i, b=str(i)) for i in range(3)]
    for obj in objs:
        packer.pack(obj)

    data = packer.get_buffer()

    unpacker = LengthPrefixedUnpacker(target=Simple, length_type=4)

    # 分块输入数据以模拟流
    chunk_size = 5
    results = []

    for i in range(0, len(data), chunk_size):
        chunk = data[i : i + chunk_size]
        unpacker.feed(chunk)
        results.extend(unpacker)

    assert len(results) == 3
    for i, res in enumerate(results):
        assert res.a == objs[i].a
        assert res.b == objs[i].b


def test_length_prefixed_unpacker_dict():
    """LengthPrefixedUnpacker 应该能解析 dict 类型的目标."""
    packer = LengthPrefixedPacker(length_type=4)
    data_dict = {0: 123, 1: "test"}
    packer.pack(data_dict)

    unpacker = LengthPrefixedUnpacker(target=dict, length_type=4)
    unpacker.feed(packer.get_buffer())

    results = list(unpacker)
    assert len(results) == 1
    assert results[0][0] == 123
    assert results[0][1] == "test"


def test_packer_clear():
    """JcePacker.clear() 应该清空内部缓冲区."""
    packer = JcePacker()
    packer.pack(Simple(a=1, b="1"))
    assert len(packer.get_buffer()) > 0
    packer.clear()
    assert len(packer.get_buffer()) == 0


def test_unpacker_buffer_limit():
    """LengthPrefixedUnpacker 应该在超出缓冲区限制时抛出 BufferError."""
    unpacker = LengthPrefixedUnpacker(Simple, max_buffer_size=10)
    with pytest.raises(BufferError):
        unpacker.feed(b"a" * 20)
