"""测试 OPT_OMIT_DEFAULT 选项的编解码行为."""

from jce import JceField, JceStruct, dumps, loads
from jce.options import OPT_OMIT_DEFAULT


class Config(JceStruct):
    """测试用配置结构体, 包含带默认值的字段."""

    a: int = JceField(jce_id=0, default=100)
    b: str = JceField(jce_id=1, default="default")
    c: int = JceField(jce_id=2, default=0)  # 0 often default but we set explicit


def test_omit_default():
    """测试 OPT_OMIT_DEFAULT 选项: 默认值字段应被省略."""
    # 1. 不带选项 (默认行为: 总是编码)
    c = Config()
    encoded = dumps(c)
    # 应包含所有字段
    decoded = Config.decode(encoded, option=0)
    assert decoded.a == 100
    assert decoded.b == "default"
    assert decoded.c == 0

    assert len(encoded) > 0

    # 2. 使用 OPT_OMIT_DEFAULT
    encoded_omit = dumps(c, option=OPT_OMIT_DEFAULT)
    # 因为所有字段都匹配默认值, 输出应为空!
    assert len(encoded_omit) == 0

    # 解码空字节应返回默认值
    decoded_omit = loads(encoded_omit, Config)
    assert decoded_omit.a == 100
    assert decoded_omit.b == "default"
    assert decoded_omit.c == 0


def test_omit_partial():
    """测试部分字段修改时的 OPT_OMIT_DEFAULT 行为."""
    # 修改一个字段
    c = Config(a=200)
    encoded = dumps(c, option=OPT_OMIT_DEFAULT)

    # 应只包含字段 'a' (Tag 0)
    assert len(encoded) == 3
    assert encoded == bytes([0x01, 0x00, 0xC8])

    decoded = Config.decode(encoded)
    assert decoded.a == 200
    assert decoded.b == "default"
    assert decoded.c == 0
