"""JCE协议序列化库.

提供了JceStruct定义、序列化(dumps)和反序列化(loads)功能.
"""

from . import types
from .api import dump, dumps, load, loads
from .context import DeserializationInfo, SerializationInfo
from .exceptions import (
    JceDecodeError,
    JceEncodeError,
    JceError,
    JcePartialDataError,
    JceTypeError,
    JceValueError,
)
from .options import (
    OPT_LITTLE_ENDIAN,
    OPT_NETWORK_BYTE_ORDER,
    OPT_OMIT_DEFAULT,
    OPT_SERIALIZE_NONE,
    OPT_STRICT_MAP,
    OPT_ZERO_COPY,
)
from .stream import (
    JcePacker,
    JceUnpacker,
    LengthPrefixedPacker,
    LengthPrefixedUnpacker,
)
from .types import JceField, JceStruct, field_deserializer, field_serializer

__version__ = "1.1.0"

__all__ = [
    "OPT_LITTLE_ENDIAN",
    "OPT_NETWORK_BYTE_ORDER",
    "OPT_OMIT_DEFAULT",
    "OPT_SERIALIZE_NONE",
    "OPT_STRICT_MAP",
    "OPT_ZERO_COPY",
    "DeserializationInfo",
    "JceDecodeError",
    "JceEncodeError",
    "JceError",
    "JceField",
    "JcePacker",
    "JcePartialDataError",
    "JceStruct",
    "JceTypeError",
    "JceUnpacker",
    "JceValueError",
    "LengthPrefixedPacker",
    "LengthPrefixedUnpacker",
    "SerializationInfo",
    "__version__",
    "dump",
    "dumps",
    "field_deserializer",
    "field_serializer",
    "load",
    "loads",
    "types",
]
