"""JCE序列化和反序列化的配置选项.

该模块定义了用于控制 `dumps` 和 `loads` 函数行为的位掩码常量.
"""

# 默认行为:网络字节序(大端模式)
OPT_NETWORK_BYTE_ORDER = 0x0000

# 强制小端字节序(非标准JCE)
OPT_LITTLE_ENDIAN = 0x0001

# 强制严格的JCE映射要求:键标签=0,值标签=1
OPT_STRICT_MAP = 0x0002

# 允许序列化None值(默认情况下通常跳过)
OPT_SERIALIZE_NONE = 0x0004

# 零复制模式:在可能的地方返回memoryview切片而不是字节
OPT_ZERO_COPY = 0x0010

# 在序列化过程中省略默认值以节省带宽
OPT_OMIT_DEFAULT = 0x0020

# 所有已知选项的掩码
_ALL_OPTIONS_MASK = (
    OPT_LITTLE_ENDIAN
    | OPT_STRICT_MAP
    | OPT_SERIALIZE_NONE
    | OPT_ZERO_COPY
    | OPT_OMIT_DEFAULT
)


def validate_option(option: int) -> None:
    """验证选项标志.

    Args:
        option: 选项整数.

    Raises:
        ValueError: 如果选项包含未知位.
    """
    if not isinstance(option, int):
        raise TypeError(f"Option must be int, got {type(option).__name__}")

    unknown = option & ~_ALL_OPTIONS_MASK
    if unknown:
        # 在严格模式下这可能是个错误,但为了前向兼容性,我们只警告或允许?
        # 任务要求"添加 option 验证",这里我们抛出 ValueError,或者打印警告.
        # 考虑到这是库,最好保持严格.
        # 但如果未来添加了新选项,旧代码可能会出错.
        # 让我们打印警告而不是抛出异常,或者提供一个 STRICT_CHECK 模式.
        # "P1 添加 option 验证" - Usually implies checking for validity.
        # Let's assume throwing generic error for now, or just pass if we want forward compat.
        # Given "Defensive programming" benefit, raising error helps catch typos.
        raise ValueError(f"Unknown option bits set: {hex(unknown)}")
