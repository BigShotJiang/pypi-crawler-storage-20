"""JCE API模块.

为JCE序列化提供`loads`和`dumps`函数.
"""

import warnings
from typing import IO, TYPE_CHECKING, Any, Literal, TypeVar, cast, overload

from .decoder import DataReader, GenericDecoder, SchemaDecoder
from .encoder import JceEncoder
from .exceptions import JceDecodeError, JcePartialDataError
from .options import OPT_NETWORK_BYTE_ORDER, validate_option

if TYPE_CHECKING:
    from .types import JceStruct

T = TypeVar("T", bound="JceStruct")
BytesMode = Literal["raw", "string", "auto"]


def _is_valid_printable_string(s: str, ascii_only: bool = False) -> bool:
    if not s:
        return True

    if ascii_only:
        # 仅ASCII可打印字符(32-127)
        return all(32 <= ord(c) < 127 for c in s)
    # 可打印字符或控制字符\n\t\r
    return all(c.isprintable() or c in "\n\t\r" for c in s)


def _convert_bytes_recursive(data: Any, mode: BytesMode = "auto") -> Any:
    if mode == "raw":
        return data

    if isinstance(data, dict):
        result = {}
        for key, value in data.items():
            if isinstance(key, bytes):
                # 键始终尝试转换为字符串
                try:
                    decoded_key = key.decode("utf-8")
                    if _is_valid_printable_string(decoded_key, ascii_only=False):
                        key = decoded_key
                except UnicodeDecodeError:
                    pass
            result[key] = _convert_bytes_recursive(value, mode)
        return result

    if isinstance(data, list):
        return [_convert_bytes_recursive(item, mode) for item in data]

    if isinstance(data, bytes):
        if len(data) == 0:
            return ""

        # STRING 模式: 仅尝试UTF-8
        if mode == "string":
            try:
                return data.decode("utf-8")
            except UnicodeDecodeError:
                return data

        # AUTO 模式: JCE -> UTF-8 -> RAW
        # 优先尝试作为JCE数据解析(用于SimpleList等嵌入的JCE结构)
        try:
            reader = DataReader(data, option=0)
            decoder = GenericDecoder(reader, option=0)
            parsed = decoder.decode(suppress_log=True)
            return _convert_bytes_recursive(parsed, mode="auto")
        except (JceDecodeError, JcePartialDataError):
            pass

        # 如果JCE解析失败,尝试作为纯文本字符串(仅ASCII可打印)
        try:
            decoded = data.decode("utf-8")
            if _is_valid_printable_string(decoded, ascii_only=True):
                return decoded
        except UnicodeDecodeError:
            pass

        return data

    return data


def dumps(
    obj: Any,
    option: int = OPT_NETWORK_BYTE_ORDER,
    default: Any | None = None,
    context: dict[str, Any] | None = None,
) -> bytes:
    """序列化对象为JCE字节.

    Args:
        obj: 要序列化的对象(JceStruct或dict).
        option: 格式化选项(例如OPT_LITTLE_ENDIAN).
        default: 未知类型的默认函数.
        context: 序列化上下文(传递给字段序列化器).

    Returns:
        JCE编码的字节.
    """
    validate_option(option)
    encoder = JceEncoder(option, default, context)
    return encoder.encode(obj)


def dump(
    obj: Any,
    fp: IO[bytes],
    option: int = OPT_NETWORK_BYTE_ORDER,
    default: Any | None = None,
    context: dict[str, Any] | None = None,
) -> None:
    """序列化对象为JCE字节并写入文件.

    Args:
        obj: 要序列化的对象.
        fp: 必须支持 write() 方法的文件类对象.
        option: 格式化选项.
        default: 未知类型的默认函数.
        context: 序列化上下文.
    """
    fp.write(dumps(obj, option=option, default=default, context=context))


@overload
def loads(
    data: bytes | bytearray | memoryview,
    target: type[T],
    option: int = OPT_NETWORK_BYTE_ORDER,
    *,
    bytes_mode: BytesMode = "auto",
    smart_decode: bool | None = None,
    context: dict[str, Any] | None = None,
) -> T: ...


@overload
def loads(
    data: bytes | bytearray | memoryview,
    target: type[dict[Any, Any]] = dict,
    option: int = OPT_NETWORK_BYTE_ORDER,
    *,
    bytes_mode: BytesMode = "auto",
    smart_decode: bool | None = None,
    context: dict[str, Any] | None = None,
) -> dict[int, Any]: ...


def loads(
    data: bytes | bytearray | memoryview,
    target: type[T] | type[dict[Any, Any]] = dict,
    option: int = OPT_NETWORK_BYTE_ORDER,
    *,
    bytes_mode: BytesMode = "auto",
    smart_decode: bool | None = None,
    context: dict[str, Any] | None = None,
) -> T | dict[int, Any]:
    """反序列化JCE字节为对象.

    Args:
        data: 二进制数据.
        target: 目标类(JceStruct子类或dict).
        option: 格式化选项(例如OPT_LITTLE_ENDIAN).
        bytes_mode: 字节转换模式.
        smart_decode: (已弃用).
        context: 反序列化上下文(传递给字段反序列化器).

    Returns:
        目标类的实例或dict.
    """
    validate_option(option)

    # 处理向后兼容
    if smart_decode is not None:
        warnings.warn(
            "The 'smart_decode' argument is deprecated, use 'bytes_mode' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        if smart_decode:
            bytes_mode = "auto"
        else:
            bytes_mode = "raw"

    reader = DataReader(data, option)

    # 使用'is'检查dict,这是常见的模式,或使用'issubclass'安全检查
    if target is dict:
        decoder = GenericDecoder(reader, option)
        result = decoder.decode()
        return _convert_bytes_recursive(result, mode=bytes_mode)

    # 假设target是JceStruct子类
    decoder = SchemaDecoder(reader, target, option, context)
    return cast(T, decoder.decode())


def load(
    fp: IO[bytes],
    target: type[T] | type[dict[Any, Any]] = dict,
    option: int = OPT_NETWORK_BYTE_ORDER,
    *,
    bytes_mode: BytesMode = "auto",
    smart_decode: bool | None = None,
    context: dict[str, Any] | None = None,
) -> T | dict[int, Any]:
    """从文件读取并反序列化JCE字节.

    Args:
        fp: 必须支持 read() 方法的文件类对象.
        target: 目标类(JceStruct子类或dict).
        option: 格式化选项.
        bytes_mode: 字节转换模式.
        smart_decode: (已弃用).
        context: 反序列化上下文.

    Returns:
        目标类的实例或dict.
    """
    data = fp.read()
    return loads(
        data,
        target=target,
        option=option,
        bytes_mode=bytes_mode,
        smart_decode=smart_decode,
        context=context,
    )
