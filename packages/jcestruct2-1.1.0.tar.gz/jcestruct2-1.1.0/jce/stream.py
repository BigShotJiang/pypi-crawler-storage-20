"""JCE流式处理模块.

该模块提供用于网络协议和流处理的 Packer 和 Unpacker 类.
设计灵感来自 msgpack-python, 支持增量编码和解码.
"""

import struct
from collections.abc import Generator
from typing import Any

from .api import BytesMode
from .decoder import DataReader, GenericDecoder, SchemaDecoder
from .encoder import JceEncoder
from .options import OPT_NETWORK_BYTE_ORDER
from .types import JceStruct


class JcePacker:
    """JCE流式打包器.

    允许增量序列化多个对象到同一个缓冲区.
    """

    def __init__(
        self,
        option: int = OPT_NETWORK_BYTE_ORDER,
        default: Any = None,
        context: dict[str, Any] | None = None,
    ):
        self._option = option
        self._default = default
        self._context = context
        self._buffer = bytearray()

    def pack(self, obj: Any) -> None:
        """序列化对象并追加到缓冲区."""
        # 每次创建一个新的 temporary encoder, 保证无状态干扰
        encoder = JceEncoder(self._option, self._default, self._context)
        data = encoder.encode(obj)
        self._buffer.extend(data)

    def pack_bytes(self, data: bytes) -> None:
        """直接追加原始字节."""
        self._buffer.extend(data)

    def get_buffer(self) -> bytes:
        """获取当前缓冲区内容."""
        return bytes(self._buffer)

    def clear(self) -> None:
        """清空缓冲区."""
        self._buffer.clear()


class JceUnpacker:
    """JCE流式解包器.

    支持通过 feed() 方法输入数据, 并通过迭代器产生对象.
    需要知道目标类型(target).
    """

    def __init__(
        self,
        target: type[JceStruct] | type[dict],
        option: int = OPT_NETWORK_BYTE_ORDER,
        max_buffer_size: int = 10 * 1024 * 1024,  # 10MB
        context: dict[str, Any] | None = None,
        bytes_mode: BytesMode = "auto",
    ):
        self._target = target
        self._option = option
        self._buffer = bytearray()
        self._max_buffer_size = max_buffer_size
        self._context = context
        self._bytes_mode = bytes_mode

    def feed(self, data: bytes | bytearray | memoryview) -> None:
        """输入数据到内部缓冲区."""
        if len(self._buffer) + len(data) > self._max_buffer_size:
            raise BufferError("JceUnpacker buffer exceeded max size")
        self._buffer.extend(data)

    def __iter__(self) -> Generator[Any, None, None]:
        """迭代解析出的对象.

        纯 JCE 流不支持连续对象解析, 因为没有外部定界符.
        请使用 LengthPrefixedUnpacker 处理带长度前缀的流式数据.
        """
        raise NotImplementedError("Use LengthPrefixedUnpacker for stream decoding")


class LengthPrefixedPacker(JcePacker):
    """带长度前缀的打包器.

    格式: [Length][Data]
    Length 可以是 1, 2, 或 4 字节.
    Tars 协议通常使用 4 字节长度(包含头部), 大端序.
    """

    def __init__(
        self,
        option: int = OPT_NETWORK_BYTE_ORDER,
        default: Any = None,
        context: dict[str, Any] | None = None,
        length_type: int = 4,  # 1, 2, or 4 bytes
        inclusive_length: bool = True,  # 长度包含头部本身
        little_endian_length: bool = False,  # 长度字段字节序
    ):
        super().__init__(option, default, context)
        if length_type not in (1, 2, 4):
            raise ValueError("length_type must be 1, 2, or 4")
        self._length_type = length_type
        self._inclusive_length = inclusive_length
        self._little_endian_length = little_endian_length

    def pack(self, obj: Any) -> None:
        """序列化对象, 添加长度前缀, 并追加到缓冲区."""
        # 1. 编码包体
        encoder = JceEncoder(self._option, self._default, self._context)
        body = encoder.encode(obj)

        # 2. 计算长度
        length = len(body)
        if self._inclusive_length:
            length += self._length_type

        # 3. 编码长度头
        header = self._pack_length(length)

        # 4. 追加
        self._buffer.extend(header)
        self._buffer.extend(body)

    def _pack_length(self, length: int) -> bytes:
        endian = "<" if self._little_endian_length else ">"
        if self._length_type == 1:
            if length > 255:
                raise ValueError(f"Packet too large for 1-byte length: {length}")
            return struct.pack(f"{endian}B", length)
        elif self._length_type == 2:
            if length > 65535:
                raise ValueError(f"Packet too large for 2-byte length: {length}")
            return struct.pack(f"{endian}H", length)
        else:  # 4
            if length > 4294967295:
                raise ValueError(f"Packet too large for 4-byte length: {length}")
            return struct.pack(f"{endian}I", length)


class LengthPrefixedUnpacker(JceUnpacker):
    """带长度前缀的解包器."""

    def __init__(
        self,
        target: type[JceStruct] | type[dict],
        option: int = OPT_NETWORK_BYTE_ORDER,
        max_buffer_size: int = 10 * 1024 * 1024,
        context: dict[str, Any] | None = None,
        length_type: int = 4,
        inclusive_length: bool = True,
        little_endian_length: bool = False,
        bytes_mode: BytesMode = "auto",
    ):
        super().__init__(target, option, max_buffer_size, context, bytes_mode)
        if length_type not in (1, 2, 4):
            raise ValueError("length_type must be 1, 2, or 4")
        self._length_type = length_type
        self._inclusive_length = inclusive_length
        self._little_endian_length = little_endian_length

    def __iter__(self) -> Generator[Any, None, None]:
        """从缓冲区解析所有完整的包."""
        while True:
            # 1. 检查是否有足够数据读取长度头
            if len(self._buffer) < self._length_type:
                break

            # 2. 读取长度
            length_bytes = self._buffer[: self._length_type]
            length = self._unpack_length(length_bytes)

            # 3. 确定包大小
            # 如果包含头部, 包大小 = 长度
            # 如果不包含头部, 包大小 = 长度 + 头大小
            packet_size = (
                length if self._inclusive_length else length + self._length_type
            )

            # 4. 检查是否有完整包
            if len(self._buffer) < packet_size:
                break

            # 5. 提取包体
            # 包体在头部之后
            body_start = self._length_type
            body_end = packet_size
            body_data = self._buffer[body_start:body_end]

            # 6. 解码
            from .api import _convert_bytes_recursive

            reader = DataReader(body_data, self._option)

            if self._target is dict:
                decoder = GenericDecoder(reader, self._option)
                result = decoder.decode()
                yield _convert_bytes_recursive(result, mode=self._bytes_mode)  # type: ignore
            else:
                decoder = SchemaDecoder(
                    reader, self._target, self._option, self._context
                )
                yield decoder.decode()

            # 7. 消耗缓冲区
            del self._buffer[:packet_size]

    def _unpack_length(self, data: bytes | bytearray) -> int:
        endian = "<" if self._little_endian_length else ">"
        if self._length_type == 1:
            return struct.unpack(f"{endian}B", data)[0]
        elif self._length_type == 2:
            return struct.unpack(f"{endian}H", data)[0]
        else:
            return struct.unpack(f"{endian}I", data)[0]
