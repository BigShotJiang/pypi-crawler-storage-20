class SearchStoreFeature:
    pass
