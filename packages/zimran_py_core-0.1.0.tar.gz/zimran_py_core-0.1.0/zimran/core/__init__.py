"""Zimran Core - Core Python utilities and shared components for Zimran projects."""

__version__ = "0.1.0"
