# AWS Rekognition Tool 🔍

Easy-to-use Python package for AWS Rekognition - Detect labels, faces, and text in images!

## Installation

```bash
pip install aws-rekognition-tool