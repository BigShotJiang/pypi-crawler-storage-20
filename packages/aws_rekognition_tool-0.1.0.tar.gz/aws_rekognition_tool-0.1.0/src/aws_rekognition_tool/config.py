"""
Configuration - Default settings ellam inga irukkum
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class AWSConfig:
    """
    AWS Configuration class
    
    Attributes:
        aws_access_key_id: Unga AWS access key
        aws_secret_access_key: Unga AWS secret key
        region_name: AWS region (default: us-east-1)
        bucket_name: S3 bucket name
        s3_folder: S3 la image save aagura folder
    """
    aws_access_key_id: str
    aws_secret_access_key: str
    region_name: str = "us-east-1"
    bucket_name: str = ""
    s3_folder: str = "rekognition_images/"
    
    def validate(self) -> bool:
        """Credentials ellam proper ah irukka check pannum"""
        if not self.aws_access_key_id or not self.aws_secret_access_key:
            return False
        if not self.bucket_name:
            return False
        return True


@dataclass
class RekognitionSettings:
    """
    Rekognition API settings
    
    Attributes:
        max_labels: Maximum labels detect pannum
        min_confidence: Minimum confidence percentage
        detect_faces: Face detection enable/disable
        detect_text: Text detection enable/disable
    """
    max_labels: int = 10
    min_confidence: float = 75.0
    detect_faces: bool = False
    detect_text: bool = False
    detect_moderation: bool = False


# Default settings
DEFAULT_REGION = "us-east-1"
DEFAULT_MAX_LABELS = 10
DEFAULT_MIN_CONFIDENCE = 75.0
SUPPORTED_IMAGE_FORMATS = ['.jpg', '.jpeg', '.png']
MAX_IMAGE_SIZE_MB = 15  # Rekognition limit