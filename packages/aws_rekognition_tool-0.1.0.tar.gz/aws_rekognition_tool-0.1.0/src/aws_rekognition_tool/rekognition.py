"""
Main Rekognition Module - Core functionality ellam inga
"""

import os
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

from .config import AWSConfig, RekognitionSettings, SUPPORTED_IMAGE_FORMATS
from .s3_handler import S3Handler
from .exceptions import (
    RekognitionError,
    InvalidImageError,
    ImageTooLargeError,
    AWSCredentialsError,
    ImageNotFoundError
)


@dataclass
class Label:
    """Detected label ah represent pannum"""
    name: str
    confidence: float
    parents: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict:
        return {
            'name': self.name,
            'confidence': self.confidence,
            'parents': self.parents
        }


@dataclass
class DetectionResult:
    """Rekognition result ah represent pannum"""
    labels: List[Label] = field(default_factory=list)
    image_path: str = ""
    s3_key: str = ""
    success: bool = False
    error_message: str = ""
    
    def to_dict(self) -> Dict:
        return {
            'success': self.success,
            'image_path': self.image_path,
            's3_key': self.s3_key,
            'labels': [label.to_dict() for label in self.labels],
            'error_message': self.error_message
        }
    
    def print_labels(self) -> None:
        """Labels ah console la print pannum"""
        if not self.labels:
            print("No labels detected!")
            return
        
        print(f"\n{'='*50}")
        print(f"Detected Labels for: {self.image_path}")
        print(f"{'='*50}")
        
        for label in self.labels:
            print(f"\n  🏷️  Label: {label.name}")
            print(f"      Confidence: {label.confidence:.2f}%")
            if label.parents:
                print(f"      Parents: {', '.join(label.parents)}")
        
        print(f"\n{'='*50}")


class AWSRekognition:
    """
    Main AWS Rekognition class - Image analysis ku use pannunga
    
    Example Usage:
        from aws_rekognition_tool import AWSRekognition
        
        rekognition = AWSRekognition(
            aws_access_key_id="YOUR_KEY",
            aws_secret_access_key="YOUR_SECRET",
            bucket_name="your-bucket",
            region_name="us-east-1"
        )
        
        result = rekognition.detect_labels("/path/to/image.jpg")
        result.print_labels()
    """
    
    def __init__(
        self,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        region_name: str = "us-east-1",
        s3_folder: str = "rekognition_images/",
        max_labels: int = 10,
        min_confidence: float = 75.0,
        auto_cleanup: bool = True
    ):
        """
        AWSRekognition initialize pannum
        
        Args:
            aws_access_key_id: AWS Access Key
            aws_secret_access_key: AWS Secret Key
            bucket_name: S3 Bucket name
            region_name: AWS Region (default: us-east-1)
            s3_folder: S3 folder path (default: rekognition_images/)
            max_labels: Maximum labels to detect (default: 10)
            min_confidence: Minimum confidence % (default: 75.0)
            auto_cleanup: S3 la image delete panrathu (default: True)
        """
        # Config setup
        self.config = AWSConfig(
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            region_name=region_name,
            bucket_name=bucket_name,
            s3_folder=s3_folder
        )
        
        self.settings = RekognitionSettings(
            max_labels=max_labels,
            min_confidence=min_confidence
        )
        
        self.auto_cleanup = auto_cleanup
        
        # Initialize clients
        self._s3_handler = None
        self._rekognition_client = None
        self._initialize_clients()
    
    def _initialize_clients(self) -> None:
        """AWS clients initialize pannum"""
        try:
            # S3 Handler
            self._s3_handler = S3Handler(self.config)
            
            # Rekognition client
            self._rekognition_client = boto3.client(
                'rekognition',
                region_name=self.config.region_name,
                aws_access_key_id=self.config.aws_access_key_id,
                aws_secret_access_key=self.config.aws_secret_access_key
            )
            
        except NoCredentialsError:
            raise AWSCredentialsError("AWS credentials illa!")
        except Exception as e:
            raise AWSCredentialsError(f"Client initialization fail: {e}")
    
    def _validate_image(self, image_path: str) -> None:
        """Image file validate pannum"""
        if not os.path.exists(image_path):
            raise ImageNotFoundError(f"Image file illa: {image_path}")
        
        # File extension check
        ext = os.path.splitext(image_path)[1].lower()
        if ext not in SUPPORTED_IMAGE_FORMATS:
            raise InvalidImageError(
                f"Invalid format: {ext}. Supported: {SUPPORTED_IMAGE_FORMATS}"
            )
        
        # File size check (15MB limit)
        file_size_mb = os.path.getsize(image_path) / (1024 * 1024)
        if file_size_mb > 15:
            raise ImageTooLargeError(
                f"Image too large: {file_size_mb:.2f}MB. Max: 15MB"
            )
    
    def detect_labels(
        self,
        image_path: str,
        max_labels: Optional[int] = None,
        min_confidence: Optional[float] = None
    ) -> DetectionResult:
        """
        Image la labels detect pannum - MAIN FUNCTION
        
        Args:
            image_path: Local image file path
            max_labels: Override default max labels
            min_confidence: Override default min confidence
        
        Returns:
            DetectionResult object with labels
        
        Example:
            result = rekognition.detect_labels("/home/user/image.jpg")
            for label in result.labels:
                print(f"{label.name}: {label.confidence}%")
        """
        result = DetectionResult(image_path=image_path)
        s3_key = ""
        
        try:
            # Step 1: Validate image
            self._validate_image(image_path)
            
            # Step 2: Upload to S3
            s3_key = self._s3_handler.upload_image(image_path)
            result.s3_key = s3_key
            
            # Step 3: Call Rekognition API
            response = self._rekognition_client.detect_labels(
                Image={
                    'S3Object': {
                        'Bucket': self.config.bucket_name,
                        'Name': s3_key
                    }
                },
                MaxLabels=max_labels or self.settings.max_labels,
                MinConfidence=min_confidence or self.settings.min_confidence
            )
            
            # Step 4: Parse response
            for label_data in response.get('Labels', []):
                parents = [p['Name'] for p in label_data.get('Parents', [])]
                
                label = Label(
                    name=label_data['Name'],
                    confidence=label_data['Confidence'],
                    parents=parents
                )
                result.labels.append(label)
            
            result.success = True
            
        except self._rekognition_client.exceptions.InvalidImageFormatException:
            result.error_message = "Invalid image format!"
            raise InvalidImageError("Rekognition: Invalid image format")
            
        except self._rekognition_client.exceptions.ImageTooLargeException:
            result.error_message = "Image too large!"
            raise ImageTooLargeError("Rekognition: Image exceeds size limit")
            
        except self._rekognition_client.exceptions.AccessDeniedException:
            result.error_message = "Access denied! Check IAM permissions."
            raise RekognitionError("Access denied - check IAM permissions")
            
        except ClientError as e:
            result.error_message = str(e)
            raise RekognitionError(f"AWS Error: {e}")
            
        except Exception as e:
            result.error_message = str(e)
            raise
            
        finally:
            # Step 5: Cleanup - Delete from S3
            if self.auto_cleanup and s3_key:
                try:
                    self._s3_handler.delete_image(s3_key)
                except Exception:
                    pass  # Cleanup error ignore pannrom
        
        return result
    
    def detect_faces(self, image_path: str) -> Dict[str, Any]:
        """
        Image la faces detect pannum
        
        Args:
            image_path: Local image path
        
        Returns:
            Dictionary with face details
        """
        s3_key = ""
        
        try:
            self._validate_image(image_path)
            s3_key = self._s3_handler.upload_image(image_path)
            
            response = self._rekognition_client.detect_faces(
                Image={
                    'S3Object': {
                        'Bucket': self.config.bucket_name,
                        'Name': s3_key
                    }
                },
                Attributes=['ALL']
            )
            
            return {
                'success': True,
                'face_count': len(response.get('FaceDetails', [])),
                'faces': response.get('FaceDetails', [])
            }
            
        finally:
            if self.auto_cleanup and s3_key:
                try:
                    self._s3_handler.delete_image(s3_key)
                except Exception:
                    pass
    
    def detect_text(self, image_path: str) -> Dict[str, Any]:
        """
        Image la text detect pannum
        
        Args:
            image_path: Local image path
        
        Returns:
            Dictionary with detected text
        """
        s3_key = ""
        
        try:
            self._validate_image(image_path)
            s3_key = self._s3_handler.upload_image(image_path)
            
            response = self._rekognition_client.detect_text(
                Image={
                    'S3Object': {
                        'Bucket': self.config.bucket_name,
                        'Name': s3_key
                    }
                }
            )
            
            texts = []
            for text in response.get('TextDetections', []):
                if text['Type'] == 'LINE':
                    texts.append({
                        'text': text['DetectedText'],
                        'confidence': text['Confidence']
                    })
            
            return {
                'success': True,
                'text_count': len(texts),
                'texts': texts
            }
            
        finally:
            if self.auto_cleanup and s3_key:
                try:
                    self._s3_handler.delete_image(s3_key)
                except Exception:
                    pass
    
    def analyze_image(self, image_path: str) -> Dict[str, Any]:
        """
        Complete image analysis - labels, faces, text ellam
        
        Args:
            image_path: Local image path
        
        Returns:
            Dictionary with all analysis results
        """
        results = {
            'image_path': image_path,
            'labels': None,
            'faces': None,
            'text': None
        }
        
        # Detect labels
        try:
            label_result = self.detect_labels(image_path)
            results['labels'] = label_result.to_dict()
        except Exception as e:
            results['labels'] = {'error': str(e)}
        
        # Detect faces
        try:
            results['faces'] = self.detect_faces(image_path)
        except Exception as e:
            results['faces'] = {'error': str(e)}
        
        # Detect text
        try:
            results['text'] = self.detect_text(image_path)
        except Exception as e:
            results['text'] = {'error': str(e)}
        
        return results