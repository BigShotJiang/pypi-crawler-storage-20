"""
AWS Rekognition Tool - Easy to use Python package for AWS Rekognition

Example:
    from aws_rekognition_tool import AWSRekognition
    
    rekognition = AWSRekognition(
        aws_access_key_id="YOUR_KEY",
        aws_secret_access_key="YOUR_SECRET",
        bucket_name="your-bucket"
    )
    
    result = rekognition.detect_labels("/path/to/image.jpg")
    result.print_labels()
"""

from .rekognition import AWSRekognition, DetectionResult, Label
from .s3_handler import S3Handler
from .config import AWSConfig, RekognitionSettings
from .exceptions import (
    RekognitionToolError,
    AWSCredentialsError,
    ImageNotFoundError,
    S3UploadError,
    S3DeleteError,
    RekognitionError,
    InvalidImageError,
    ImageTooLargeError
)

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    # Main classes
    "AWSRekognition",
    "DetectionResult",
    "Label",
    "S3Handler",
    
    # Config
    "AWSConfig",
    "RekognitionSettings",
    
    # Exceptions
    "RekognitionToolError",
    "AWSCredentialsError",
    "ImageNotFoundError",
    "S3UploadError",
    "S3DeleteError",
    "RekognitionError",
    "InvalidImageError",
    "ImageTooLargeError",
]


def quick_detect(
    image_path: str,
    aws_access_key_id: str,
    aws_secret_access_key: str,
    bucket_name: str,
    region_name: str = "us-east-1"
) -> DetectionResult:
    """
    Quick one-liner function for label detection
    
    Args:
        image_path: Path to local image
        aws_access_key_id: AWS Access Key
        aws_secret_access_key: AWS Secret Key
        bucket_name: S3 Bucket name
        region_name: AWS Region
    
    Returns:
        DetectionResult object
    
    Example:
        from aws_rekognition_tool import quick_detect
        
        result = quick_detect(
            "/path/to/image.jpg",
            "ACCESS_KEY",
            "SECRET_KEY",
            "my-bucket"
        )
        result.print_labels()
    """
    client = AWSRekognition(
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key,
        bucket_name=bucket_name,
        region_name=region_name
    )
    return client.detect_labels(image_path)