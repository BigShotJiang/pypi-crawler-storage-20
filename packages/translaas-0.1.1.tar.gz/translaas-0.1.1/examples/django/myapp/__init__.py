"""Django example application."""
