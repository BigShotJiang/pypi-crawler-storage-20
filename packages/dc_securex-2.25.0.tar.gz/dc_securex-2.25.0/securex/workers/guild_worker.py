"""
Guild Restoration Worker - Restores ALL guild settings (name, icon, banner, vanity, etc.)
Supports per-guild user tokens with file storage and memory caching
"""
import asyncio
import discord
import aiohttp
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional


class GuildWorker:
    """Background worker for guild settings restoration"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self._worker_task = None
        
        # Per-guild user tokens
        self._user_tokens: Dict[int, str] = {}  # guild_id -> user_token (cache)
        self._tokens_file = sdk.backup_dir / "user_tokens.json"
        
        # Load tokens from file
        asyncio.create_task(self._load_tokens())
    
    async def _load_tokens(self):
        """Load user tokens from file into cache"""
        try:
            if self._tokens_file.exists():
                with open(self._tokens_file, 'r') as f:
                    data = json.load(f)
                    # Convert string keys back to int
                    self._user_tokens = {int(k): v for k, v in data.items()}
                    print(f"✅ Loaded user tokens for {len(self._user_tokens)} guild(s)")
        except Exception as e:
            print(f"Error loading user tokens: {e}")
    
    async def _save_tokens(self):
        """Save user tokens to file"""
        try:
            # Convert int keys to string for JSON
            data = {str(k): v for k, v in self._user_tokens.items()}
            with open(self._tokens_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving user tokens: {e}")
    
    async def set_user_token(self, guild_id: int, token: str):
        """Set user token for a specific guild"""
        self._user_tokens[guild_id] = token
        await self._save_tokens()
        print(f"✅ User token set for guild {guild_id}")
    
    def get_user_token(self, guild_id: int) -> Optional[str]:
        """Get user token for a guild (from cache)"""
        return self._user_tokens.get(guild_id)
    
    async def remove_user_token(self, guild_id: int):
        """Remove user token for a guild"""
        if guild_id in self._user_tokens:
            del self._user_tokens[guild_id]
            await self._save_tokens()
            print(f"❌ User token removed for guild {guild_id}")
    
    async def start(self):
        """Start the guild restoration worker"""
        if self._worker_task is None or self._worker_task.done():
            self._worker_task = asyncio.create_task(self._restoration_loop())
            print("⚡ Guild Restoration Worker started")
    
    async def stop(self):
        """Stop the worker"""
        if self._worker_task:
            self._worker_task.cancel()
            self._worker_task = None
    
    async def _restoration_loop(self):
        """Main worker loop - processes guild_update entries from queue"""
        while True:
            try:
                entry = await self.sdk.guild_queue.get()
                
                # Only process guild_update actions
                if entry.action != discord.AuditLogAction.guild_update:
                    continue
                
                # Extract changes from entry
                guild = entry.guild
                executor = entry.user
                
                # Skip if bot did it
                if executor.id == self.bot.user.id:
                    continue
                
                # Extract relevant changes
                changes = {}
                if hasattr(entry, "changes"):
                    for change in entry.changes:
                        if change.key in ["vanity_url_code", "name", "icon", "banner", "description"]:
                            changes[change.key] = (change.before, change.after)
                
                # Restore if there are changes
                if changes:
                    await self._restore_guild_settings({"guild": guild, "changes": changes, "timestamp": datetime.now()})
                    
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error in guild restoration worker: {e}")
    
    async def _restore_vanity_via_api(self, guild_id: int, vanity_code: str) -> bool:
        """Restore vanity URL using user token and Discord API"""
        user_token = self.get_user_token(guild_id)
        
        if not user_token:
            print(f"⚠️ No user token set for guild {guild_id}! Cannot restore vanity URL.")
            print(f"   Use: await sx.guild_worker.set_user_token({guild_id}, 'USER_TOKEN')")
            return False
        
        try:
            url = f"https://discord.com/api/v9/guilds/{guild_id}/vanity-url"
            headers = {
                "authorization": user_token,
                "content-type": "application/json"
            }
            payload = {"code": vanity_code}
            
            async with aiohttp.ClientSession() as session:
                async with session.patch(url, headers=headers, json=payload) as response:
                    if response.status == 200:
                        return True
                    else:
                        error_text = await response.text()
                        print(f"⚠️ Failed to restore vanity: {response.status} - {error_text}")
                        return False
        except Exception as e:
            print(f"Error restoring vanity via API: {e}")
            return False
    
    async def _restore_guild_settings(self, task: dict):
        """Restore guild settings"""
        try:
            guild = task["guild"]
            changes = task["changes"]
            
            start_time = datetime.now()
            
            backup_data = await self.sdk.backup_manager.get_guild_settings(guild.id)
            if not backup_data:
                print(f"⚠️ No backup found for guild {guild.name}")
                return
            
            restore_params = {}
            restored_items = []
            
            if "vanity_url_code" in changes and backup_data.get("vanity_url_code"):
                old_vanity = backup_data["vanity_url_code"]
                vanity_success = await self._restore_vanity_via_api(guild.id, old_vanity)
                if vanity_success:
                    restored_items.append(f"vanity (discord.gg/{old_vanity})")
            
            if "name" in changes and backup_data.get("name"):
                restore_params["name"] = backup_data["name"]
                restored_items.append(f"name ({backup_data['name']})")
            
            if "icon" in changes and "icon" in backup_data:
                if backup_data["icon"]:
                    restore_params["icon"] = None
                restored_items.append("icon")
            
            if "banner" in changes and "banner" in backup_data:
                if backup_data["banner"]:
                    restore_params["banner"] = None
                restored_items.append("banner")
            
            if "description" in changes and backup_data.get("description"):
                restore_params["description"] = backup_data["description"]
                restored_items.append("description")
            
            if restore_params:
                await guild.edit(**restore_params, reason="SecureX: Restoring unauthorized guild changes")
            
            if restored_items:
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                items_str = ", ".join(restored_items)
                print(f"⚡ Restored guild settings in {elapsed:.0f}ms: {items_str}")
            
        except discord.errors.HTTPException as e:
            if e.code == 50035:
                print(f"⚠️ Some settings could not be restored: {e}")
            else:
                print(f"Error restoring guild settings: {e}")
        except Exception as e:
            print(f"Error in guild restoration: {e}")
