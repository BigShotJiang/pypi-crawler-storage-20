"""Core functionality for englog."""
