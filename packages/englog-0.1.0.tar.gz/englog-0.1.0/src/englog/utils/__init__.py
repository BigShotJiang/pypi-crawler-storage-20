"""Utility functions for englog."""
