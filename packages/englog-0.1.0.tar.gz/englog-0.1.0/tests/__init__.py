"""Tests for englog."""
