import pytest
from unittest.mock import AsyncMock, MagicMock
from llmteam.canvas.handlers.team_handler import TeamHandler
from llmteam.runtime import StepContext

class TestTeamHandler:
    
    @pytest.mark.asyncio
    async def test_team_execution(self):
        """Test successful team execution via handler."""
        # Mock Team
        mock_team = AsyncMock()
        mock_team.orchestrate.return_value = {"result": "success", "score": 0.95}
        
        # Mock Runtime to resolve team
        mock_runtime = MagicMock()
        mock_runtime.get_team.return_value = mock_team
        
        # Context
        ctx = MagicMock(spec=StepContext)
        ctx.runtime = mock_runtime
        ctx.step_id = "step_1"
        
        # Config & Input
        config = {
            "team_ref": "analyst_team",
            "input_mapping": {"query": "input.q"},
            "output_mapping": {"final_result": "result"}
        }
        input_data = {"input": {"q": "test query"}, "other": 123}
        
        # Handler
        handler = TeamHandler()
        result = await handler(ctx, config, input_data)
        
        # Verification
        mock_runtime.get_team.assert_called_with("analyst_team")
        mock_team.orchestrate.assert_called_once()
        args, _ = mock_team.orchestrate.call_args
        # Handler preserves structure, so 'input' key remains even if 'input.q' was mapped
        expected_input = {
            "query": "test query", 
            "other": 123,
            "input": {"q": "test query"}
        }
        assert args[1] == expected_input
        
        assert result["output"]["final_result"] == "success"
        # "score" is unmapped, so it should be included
        assert result["output"]["score"] == 0.95

    @pytest.mark.asyncio
    async def test_team_not_found(self):
        """Test error when team is not found."""
        mock_runtime = MagicMock()
        mock_runtime.get_team.return_value = None
        
        ctx = MagicMock(spec=StepContext)
        ctx.runtime = mock_runtime
        
        config = {"team_ref": "missing_team"}
        handler = TeamHandler()
        
        with pytest.raises(Exception) as exc:
            await handler(ctx, config, {})
        assert "not found" in str(exc.value)
