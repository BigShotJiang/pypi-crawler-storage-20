from __future__ import annotations

import json
import shutil
import time
from dataclasses import asdict

from .context import BundleContext
from .packaging import archive_output_path, make_archive, resolve_archive_format
from .manifest import write_manifest
from .steps.base import StepResult


def run_profile(ctx: BundleContext, profile) -> int:
    t0 = time.time()
    ctx.write_runlog(f"=== pybundle run {profile.name} ===")
    ctx.write_runlog(f"ROOT: {ctx.root}")
    ctx.write_runlog(f"WORK: {ctx.workdir}")

    ctx.results.clear()
    results: list[StepResult] = ctx.results
    any_fail = False

    for step in profile.steps:
        ctx.write_runlog(f"-- START: {step.name}")
        r = step.run(ctx)
        results.append(r)
        ctx.results = results
        ctx.write_runlog(
            f"-- DONE:  {step.name} [{r.status}] ({r.seconds}s) {r.note}".rstrip()
        )
        if r.status == "FAIL":
            any_fail = True
            if ctx.strict:
                break

    ctx.summary_json.write_text(
        json.dumps(
            {
                "profile": profile.name,
                "root": str(ctx.root),
                "workdir": str(ctx.workdir),
                "results": [asdict(r) for r in results],
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    ctx.results = results

    # Write the manifest BEFORE archiving so it's included inside the bundle.
    archive_fmt_used = resolve_archive_format(ctx)
    archive_path = archive_output_path(ctx, archive_fmt_used)

    write_manifest(
        ctx=ctx,
        profile_name=profile.name,
        archive_path=archive_path,
        archive_format_used=archive_fmt_used,
    )

    archive_path, archive_fmt_used = make_archive(ctx)
    ctx.archive_path = archive_path
    ctx.duration_ms = int((time.time() - t0) * 1000)

    ctx.write_runlog(f"ARCHIVE: {archive_path}")

    ctx.emit(f"✅ Archive created: {archive_path}")
    if ctx.keep_workdir:
        ctx.emit(f"📁 Workdir kept:     {ctx.workdir}")

    if not ctx.keep_workdir:
        shutil.rmtree(ctx.workdir, ignore_errors=True)

    if any_fail and ctx.strict:
        return 10
    return 0
