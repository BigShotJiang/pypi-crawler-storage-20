"""AWS CostLens - AWS Cost Intelligence Tool."""

__version__ = "1.1.0"
