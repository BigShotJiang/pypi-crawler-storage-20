"""
SecureX SDK - Main Client
Backend-only anti-nuke protection system
"""
import discord
import asyncio
from pathlib import Path
from typing import Dict, List, Callable, Optional
from .backup.manager import BackupManager
from .handlers.channel import ChannelHandler
from .handlers.role import RoleHandler
from .handlers.member import MemberHandler
from .handlers.webhook import WebhookHandler
from .handlers.role_monitor import RolePositionMonitor
from .utils.whitelist import WhitelistManager
from .utils.punishment import PunishmentExecutor
from .models import ThreatEvent, BackupInfo


class SecureX:
    """
    Main SecureX SDK class for anti-nuke protection.
    Backend-only - no UI, no commands, just pure protection logic.
    """
    
    def __init__(
        self,
        bot: discord.Client,
        backup_dir: str = "./data/backups",
        punishments: Optional[Dict[str, str]] = None,
        timeout_duration: int = 600,
        notify_user: bool = True
    ):
        """
        Initialize SecureX SDK.
        
        Args:
            bot: Your discord.Client or commands.Bot instance
            backup_dir: Directory to store backups (default: ./data/backups)
            punishments: Dict mapping violation types to punishment actions
            timeout_duration: Duration in seconds for timeout punishment (default: 600)
            notify_user: Whether to DM violators about punishment (default: True)
        """
        self.bot = bot
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Core managers
        self.backup_manager = BackupManager(self)
        self.whitelist = WhitelistManager(self)
        
        # Callback registry
        self._callbacks: Dict[str, List[Callable]] = {
            'threat_detected': [],
            'backup_completed': [],
            'restore_completed': [],
            'whitelist_changed': [],
        }
        
        # Punishment configuration - defaults to no punishment
        self.punishments = {
            "channel_delete": "none",
            "channel_create": "none",
            "channel_update": "none",
            "role_delete": "none",
            "role_create": "none",
            "role_update": "none",
            "member_ban": "none",
            "member_kick": "none",
            "webhook_create": "none",
            "webhook_spam": "none"
        }
        
        # Punishment system
        self.punisher = PunishmentExecutor(bot)
        self.timeout_duration = timeout_duration
        self.notify_punished_user = notify_user
        
        # Spam handling locks (prevent duplicate processing)
        self._spam_locks = {}  # {guild_id: asyncio.Lock}
        
        # Handlers
        self.channel_handler = ChannelHandler(self)
        self.role_handler = RoleHandler(self)
        self.member_handler = MemberHandler(self)
        self.webhook_handler = WebhookHandler(self)
        self.role_monitor = RolePositionMonitor(self)
        
        # Register event listeners
        self._register_events()
    
    def _register_events(self):
        """Register Discord event listeners"""
        @self.bot.event
        async def on_channel_create(channel):
            await self.channel_handler.on_channel_create(channel)
        
        @self.bot.event
        async def on_channel_delete(channel):
            await self.channel_handler.on_channel_delete(channel)
        
        @self.bot.event
        async def on_channel_update(before, after):
            await self.channel_handler.on_channel_update(before, after)
        
        @self.bot.event
        async def on_guild_role_create(role):
            await self.role_handler.on_role_create(role)
        
        @self.bot.event
        async def on_guild_role_delete(role):
            await self.role_handler.on_role_delete(role)
        
        @self.bot.event
        async def on_guild_role_update(before, after):
            await self.role_handler.on_role_update(before, after)
        
        @self.bot.event
        async def on_member_ban(guild, user):
            await self.member_handler.on_member_ban(guild, user)
        
        @self.bot.event
        async def on_member_remove(member):
            await self.member_handler.on_member_kick(member)
        
        @self.bot.event
        async def on_webhooks_update(channel):
            await self.webhook_handler.on_webhook_event(channel)
    
    def on(self, event_name: str):
        """
        Decorator to register callbacks for SDK events.
        
        Usage:
            @sx.on('threat_detected')
            async def handle_threat(event: ThreatEvent):
                print(f"Threat: {event.type}")
        """
        def decorator(func: Callable):
            if event_name in self._callbacks:
                self._callbacks[event_name].append(func)
            return func
        return decorator
    
    async def _trigger_callbacks(self, event_name: str, *args, **kwargs):
        """Trigger all registered callbacks for an event"""
        if event_name in self._callbacks:
            for callback in self._callbacks[event_name]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(*args, **kwargs)
                    else:
                        callback(*args, **kwargs)
                except Exception as e:
                    print(f"Error in callback for {event_name}: {e}")
    
    async def enable(
        self,
        guild_id: Optional[int] = None,
        whitelist: Optional[List[int]] = None,
        auto_backup: bool = True,
        role_position_monitoring: bool = True,
        punishments: Optional[Dict[str, str]] = None,
        timeout_duration: int = 600,
        notify_user: bool = True
    ):
        """
        Enable SecureX protection.
        
        Args:
            guild_id: Guild ID to enable protection for (required if using whitelist)
            whitelist: List of user IDs to whitelist (default: [])
            auto_backup: Enable automatic backups every 30 minutes (default: True)
            role_position_monitoring: Enable role position monitoring (default: True)
            punishments: Dict mapping violation types to punishment actions
                Example: {"channel_delete": "ban", "role_create": "kick"}
                Available actions: "none", "warn", "timeout", "kick", "ban"
            timeout_duration: Duration in seconds for timeout punishment (default: 600)
            notify_user: Whether to DM violators about punishment (default: True)
        """
        # Preload all caches into memory
        await self.whitelist.preload_all()
        await self.backup_manager.preload_all()
        await self.role_monitor.preload_all()
        
        if whitelist and guild_id:
            for user_id in whitelist:
                await self.whitelist.add(guild_id, user_id)
        
        if auto_backup:
            # Start backup task
            self.backup_manager.start_auto_backup()
            # Start cache auto-refresh (every 10 minutes)
            self.backup_manager.start_auto_refresh()
        
        if role_position_monitoring:
            # Start role position monitoring
            self.role_monitor.start()
        
        # Update punishment config
        if punishments:
            self.punishments.update(punishments)
        
        self.timeout_duration = timeout_duration
        self.notify_punished_user = notify_user
        
        # Log enabled features
        if punishments:
            enabled_punishments = {k: v for k, v in self.punishments.items() if v != "none"}
            if enabled_punishments:
                print(f"⚠️  Punishments configured for {len(enabled_punishments)} violation types")
        
        print("✅ SecureX SDK initialized with all features")
        
        # Create initial backup
        if guild_id:
            backup = await self.backup_manager.create_backup(guild_id)
            if backup.success:
                print(f"✅ Backup completed for guild {guild_id}: "
                      f"{backup.channel_count} channels, {backup.role_count} roles")
