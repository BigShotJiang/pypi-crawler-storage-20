"""Monocular Surface Normal Estimation Script."""

import argparse
from pathlib import Path

from monocular_path_prediction.config.definitions import DEFAULT_LOG_LEVEL, LogLevel
from monocular_path_prediction.pipeline import Pipeline, PipelineConfig


def main(
    image_path: Path | None,
    hide_display: bool,
    use_loop: bool,
    camera_index: int | None,
    log_level: str,
) -> None:
    """Run the main function for the Monocular Surface Normal Estimation script."""
    if image_path is not None:
        camera_index = 0

    config = PipelineConfig(
        camera_index=camera_index,
        hide_display=hide_display,
        log_level=log_level,
    )
    pipeline = Pipeline(config=config)
    if use_loop:
        pipeline.run_loop(image_path=image_path)
    else:
        pipeline.run(image_path=image_path)
    pipeline.close()


if __name__ == "__main__":  # pragma: no cover
    parser = argparse.ArgumentParser(description="Monocular Surface Normal Estimation")
    parser.add_argument(
        "--image_filepath",
        type=str,
        default=None,
        help="Optional filepath to an input image",
    )
    parser.add_argument(
        "--hide_display",
        help="Hide the visualization display",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--loop",
        help="Run in a loop",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--log-level",
        help="Select the log level",
        required=False,
        choices=list(LogLevel()),
        default=DEFAULT_LOG_LEVEL,
    )
    parser.add_argument(
        "--camera_index",
        type=int,
        help="Camera index",
        required=False,
        default=None,
    )

    args = parser.parse_args()

    main(
        image_path=args.image_filepath,
        hide_display=args.hide_display,
        use_loop=args.loop,
        log_level=args.log_level,
        camera_index=args.camera_index,
    )
