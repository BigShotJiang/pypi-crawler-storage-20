from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": "-", "description": "bird a pullus (one ‘hyphen’)."},
    {"code": "U", "description": "Unknown or unrecorded."},
    {"code": "N", "description": "Nesting or Breeding."},
    {"code": "R", "description": "Roosting assemblage."},
    {"code": "K", "description": "In Colony (not necessarily breeding but not pullus)."},
    {"code": "M", "description": "Moulting assemblage (whether bird moulting or not)."},
    {"code": "T", "description": "MoulTing."},
    {"code": "L", "description": "Apparently a Local bird, but not breeding."},
    {"code": "W", "description": "Apparently a bird Wintering in the locality."},
    {
        "code": "P",
        "description": "On Passage – certainly not a local breeding nor wintering bird (includes birds attracted to "
        "lighthouses).",
    },
    {"code": "S", "description": "At Sea – birds on boats, lightships or oil rigs."},
]
