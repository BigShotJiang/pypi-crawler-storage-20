"""
# :material-image: Assets API

"""
