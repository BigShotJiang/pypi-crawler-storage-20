
import torch
import torch.nn as nn
from composennent.trainer.distillation import DistillationTrainer

# Mock classes to simulate the mismatch
class MockTeacher:
    def get_logits(self, input_ids, attention_mask=None):
        batch_size, seq_len = input_ids.shape
        # Teacher has vocab size 100
        return torch.randn(batch_size, seq_len, 100)
        
    def to(self, device): return self
    def eval(self): return self

class MockStudent(nn.Module):
    def __init__(self):
        super().__init__()
        # Student has vocab size 50
        self.head = nn.Linear(32, 50)
        
    def forward(self, input_ids, attention_mask=None):
        batch_size, seq_len = input_ids.shape
        return self.head(torch.randn(batch_size, seq_len, 32))

def test_mismatch():
    teacher = MockTeacher()
    student = MockStudent()
    trainer = DistillationTrainer(student, teacher, tokenizer=None, device="cpu", use_amp=False)
    
    # Create dummy batch
    input_ids = torch.randint(0, 50, (2, 10))
    batch = {"input_ids": input_ids}
    
    try:
        trainer.train_step(batch)
        print("Test FAILED: No exception raised")
    except ValueError as e:
        print(f"Test PASSED. Caught expected error:\n{e}")
    except Exception as e:
        print(f"Test FAILED: Caught unexpected error: {type(e).__name__}: {e}")

if __name__ == "__main__":
    test_mismatch()
