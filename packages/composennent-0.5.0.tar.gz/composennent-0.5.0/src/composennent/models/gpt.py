"""GPT (Generative Pre-trained Transformer) implementation."""

import torch
import torch.nn as nn
from typing import Optional, List, Tuple
from composennent.modules.decoders import Decoder
from composennent.modules.attention import causal_mask
from .nlp_base import BaseLanguageModel


class GPT(BaseLanguageModel):
    """GPT: Decoder-only Transformer for autoregressive language modeling.

    Implements a GPT-style architecture with stacked decoder layers,
    token embeddings, learned positional embeddings, and weight tying
    between the input embeddings and output projection.

    Args:
        vocab_size: Size of the vocabulary.
        latent_dim: Dimension of the model (embedding size).
        num_heads: Number of attention heads per layer.
        num_layers: Number of decoder layers.
        max_seq_len: Maximum sequence length. Defaults to 512.
        drop_out: Dropout probability. Defaults to 0.1.
        mlp_ratio: MLP expansion ratio for decoder layers. Defaults to 4.

    Example:
        >>> # Create new model
        >>> model = GPT(
        ...     vocab_size=50257,
        ...     latent_dim=768,
        ...     num_heads=12,
        ...     num_layers=12,
        ... )
        >>> logits = model(input_ids)  # (batch, seq_len, vocab_size)
        >>>
        >>> # Save model
        >>> model.save("gpt_model.pt")
        >>>
        >>> # Load pretrained model
        >>> loaded_model = GPT.load("gpt_model.pt")

    Note:
        Uses weight tying between token embeddings and language model head
        for improved parameter efficiency.
    """

    def __init__(
        self,
        vocab_size: int,
        latent_dim: int,
        num_heads: int,
        num_layers: int,
        max_seq_len: int = 512,
        drop_out: float = 0.1,
        mlp_ratio: int = 4,
        num_experts: int = 1,
        use_memory: bool = False,
        memory_size: int = 4096,
        memory_layers: Optional[list[int]] = None,
    ) -> None:
        super().__init__()


        self.vocab_size = vocab_size
        self.latent_dim = latent_dim
        self.num_heads = num_heads
        self.num_layers = num_layers
        self.max_seq_len = max_seq_len
        self.drop_out = drop_out
        self.mlp_ratio = mlp_ratio
        self.num_experts = num_experts
        
        # Initialize Memory if requested
        # We share one large memory store across all layers (or could be per layer, but shared is standard for RAG)
        self.use_memory = use_memory
        self.memory = None
        self.memory_head = None
        
        # If use_memory is True but no specific layers requested, apply to ALL layers (classic behavior)
        # If specific layers requested, use that list.
        if memory_layers is None:
            # Default to all layers if not specified
            self.memory_layer_indices = set(range(num_layers))
        else:
            self.memory_layer_indices = set(memory_layers)

        
        if use_memory:
            from composennent.modules.memory import KeyValueMemory, MemoryHead
            self.memory = KeyValueMemory(key_dim=latent_dim, value_dim=latent_dim, memory_size=memory_size)
            
            # The head that allows the model to write to its own memory
            self.memory_head = MemoryHead(hidden_dim=latent_dim, key_dim=latent_dim, value_dim=latent_dim)


        self.token_embedding = nn.Embedding(vocab_size, latent_dim)
        self.position_embedding = nn.Embedding(max_seq_len, latent_dim)
        self.dropout = nn.Dropout(drop_out)

        self.layers = nn.ModuleList([
            Decoder(
                latent_dim, 
                num_heads, 
                drop_out, 
                mlp_ratio, 
                num_experts=num_experts,
                # Pass memory ONLY if this layer index is in our active set
                memory_composennent=self.memory if (use_memory and i in self.memory_layer_indices) else None
            )
            for i in range(num_layers)
        ])

        self.ln_f = nn.LayerNorm(latent_dim)
        self.lm_head = nn.Linear(latent_dim, vocab_size, bias=False)

        # Weight tying: share embeddings with output projection
        self.lm_head.weight = self.token_embedding.weight
        
        # Store memory config for saving/loading
        self.memory_size = memory_size
        self.memory_layers = memory_layers

        # Apply proper weight initialization to prevent exploding gradients
        self.init_weights()

    def get_config(self) -> dict:
        """Get model configuration including memory settings."""
        config = super().get_config()
        config.update({
            "use_memory": self.use_memory,
            "memory_size": self.memory_size,
            "memory_layers": self.memory_layers,
        })
        return config

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        **kwargs,
    ) -> torch.Tensor:
        """Forward pass for language modeling.

        Args:
            input_ids: Token indices of shape (batch, seq_len).
            attention_mask: Attention mask (1=attend, 0=ignore).

        Returns:
            Logits over vocabulary of shape (batch, seq_len, vocab_size).
        """
        batch_size, seq_len = input_ids.shape
        positions = torch.arange(seq_len, device=input_ids.device).unsqueeze(0)

        x = self.token_embedding(input_ids) + self.position_embedding(positions)
        x = self.dropout(x)

        mask = causal_mask(seq_len, x.device)

        # Convert attention_mask (1=attend, 0=ignore) to key_padding_mask (True=ignore)
        key_padding_mask = None
        if attention_mask is not None:
            key_padding_mask = attention_mask == 0

        for layer in self.layers:
            # CausalDecoder now returns (output, attn_weights, cache)
            layer_out = layer(x, tgt_mask=mask, tgt_key_padding_mask=key_padding_mask)
            x = layer_out[0] if isinstance(layer_out, tuple) else layer_out

        x = self.ln_f(x)
        logits = self.lm_head(x)
        
        # === SELF-MODIFYING MEMORY LOGIC ===
        # If enabled, check if the model wants to write to memory based on its FINAL thought (x)
        # We usually check only for the LAST token in the sequence during inference.
        if self.use_memory and self.memory_head is not None:
            # We look at the decision for the *last token*
            last_hidden_state = x[:, -1, :] # (batch, hidden_dim)
            
            gate, key, value = self.memory_head(last_hidden_state)
            
            # During inference, if gate is open, we write!
            if not self.training:
                # We can do this cleanly in a no_grad context context if we want, 
                # but memory.write already calls detach().
                
                # Check threshold (e.g., sigmoid > 0.5)
                # We iterate over batch to allow per-sample decision
                if (gate > 0.5).any():
                     # To keep batching simple in this demo, we write if ANY in batch trigger,
                     # or we filter. Memory.write expects full batch or we slice.
                     # Let's just always write but pass the 'gate' to memory?
                     # No, KeyValueMemory.write is hard-write.
                     # Let's filter indices where gate > 0.5
                     
                     mask = (gate > 0.5).squeeze(-1) # (batch,)
                     if mask.any():
                         self.memory.write(key[mask], value[mask])
        # ===================================

        return logits

    def generate_cached(
        self,
        prompt: str,
        tokenizer,
        max_length: int = 100,
        temperature: float = 1.0,
        top_k: int = 50,
        top_p: float = 0.9,
    ) -> str:
        """Generate text with KV-cache for O(N) efficiency.
        
        Uses cached key/value states to avoid recomputing attention
        for previous tokens. Much faster than standard generate().
        
        Args:
            prompt: Input text.
            tokenizer: Tokenizer instance.
            max_length: Maximum tokens to generate.
            temperature: Sampling temperature.
            top_k: Top-k filtering.
            top_p: Nucleus sampling threshold.
            
        Returns:
            Generated text.
        """
        self.eval()
        device = next(self.parameters()).device
        
        # Tokenize
        input_ids = tokenizer.encode(prompt)
        input_ids = torch.tensor([input_ids], device=device)
        
        generated = input_ids.tolist()[0]
        past_key_values: List[Tuple[torch.Tensor, torch.Tensor]] = [None] * self.num_layers
        
        with torch.no_grad():
            for step in range(max_length):
                # First step: process full prompt
                # Subsequent steps: only process last token (with cache)
                if step == 0:
                    curr_input = torch.tensor([generated], device=device)
                    seq_len = len(generated)
                    positions = torch.arange(seq_len, device=device).unsqueeze(0)
                else:
                    curr_input = torch.tensor([[generated[-1]]], device=device)
                    # Position is the current sequence length - 1
                    positions = torch.tensor([[len(generated) - 1]], device=device)
                
                # Embed
                x = self.token_embedding(curr_input) + self.position_embedding(positions)
                x = self.dropout(x)
                
                # For cached generation, we only need causal mask for new tokens
                seq_len = curr_input.size(1)
                total_len = len(generated)
                
                # Create causal mask for the new tokens
                if step == 0:
                    mask = causal_mask(seq_len, device)
                else:
                    # Single new token can attend to all previous + itself
                    mask = None  # No mask needed for single token
                
                # Process through layers with caching
                new_past_key_values = []
                for i, layer in enumerate(self.layers):
                    layer_out = layer(
                        x,
                        tgt_mask=mask,
                        past_key_value=past_key_values[i],
                        use_cache=True,
                    )
                    x = layer_out[0]
                    new_past_key_values.append(layer_out[2])  # Cache is third element
                
                past_key_values = new_past_key_values
                
                # Get logits for last position
                x = self.ln_f(x)
                logits = self.lm_head(x)[:, -1, :] / temperature
                
                # Top-k filtering
                if top_k > 0:
                    indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
                    logits[indices_to_remove] = float('-inf')
                
                # Top-p filtering  
                if top_p < 1.0:
                    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
                    cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
                    sorted_indices_to_remove = cumulative_probs > top_p
                    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                    sorted_indices_to_remove[..., 0] = 0
                    indices_to_remove = sorted_indices_to_remove.scatter(1, sorted_indices, sorted_indices_to_remove)
                    logits[indices_to_remove] = float('-inf')
                
                probs = torch.softmax(logits, dim=-1)
                next_token = torch.multinomial(probs, num_samples=1).item()
                
                generated.append(next_token)
                
                # Check for EOS
                eos_id = getattr(tokenizer, 'eos_id', None) or getattr(tokenizer, 'eos_token_id', None)
                if eos_id is not None and next_token == eos_id:
                    break
        
        return tokenizer.decode(generated)

    def save(self, path: str):
        """Save model weights and configuration."""
        super().save(path)

    @classmethod
    def load(cls, path: str, device: str = "cpu", **model_kwargs):
        """Load model from saved checkpoint."""
        return super().load(path, device=device, **model_kwargs)
