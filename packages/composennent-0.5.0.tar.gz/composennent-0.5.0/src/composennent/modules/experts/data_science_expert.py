"""Data Science Expert - LoRA adapter for data analysis tasks."""

import torch
import torch.nn as nn
from typing import Dict, Any

from .expert_module import LoRAAdapter


class DataScienceExpert(LoRAAdapter):
    """LoRA adapter for data science and analytics tasks.
    
    Improves the model's ability to analyze data, write pandas/SQL queries,
    create visualizations, and explain statistical concepts.
    
    Args:
        latent_dim: Model hidden dimension.
        rank: LoRA rank. Default: 32.
        alpha: LoRA scaling factor. Default: 64.
        dropout: Dropout probability. Default: 0.1.
        
    Example:
        >>> ds = DataScienceExpert(latent_dim=768)
        >>> model.learn(ds)
        >>> output = model.generate("Write pandas code to group by category")
    """
    
    modality = "data_science"
    
    def __init__(
        self,
        latent_dim: int,
        rank: int = 32,
        alpha: float = 64.0,
        dropout: float = 0.1,
    ):
        super().__init__(latent_dim, rank=rank, alpha=alpha, dropout=dropout)
        
        # Analytical reasoning layer
        self.analytical_layer = nn.Sequential(
            nn.Linear(latent_dim, latent_dim),
            nn.GELU(),
            nn.Linear(latent_dim, latent_dim),
        )
    
    def adapt(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Apply data science-aware adaptation."""
        # LoRA output
        lora_out = self.lora_B(self.lora_A(self.dropout(hidden_states)))
        
        # Analytical enhancement
        analytical = self.analytical_layer(hidden_states)
        
        # Combine: base + LoRA + analytical residual
        return hidden_states + self.scaling * lora_out + 0.1 * analytical
