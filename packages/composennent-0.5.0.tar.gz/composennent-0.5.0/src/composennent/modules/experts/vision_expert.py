"""Vision Expert - ViT-style image encoder for multi-modal models.

Encodes images into context embeddings that can be prepended to
token embeddings in any BaseLanguageModel.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any

from .expert_module import EncoderExpert


class VisionExpert(EncoderExpert):
    """Vision Transformer encoder for image understanding.
    
    Converts images into a sequence of embeddings that the language model
    can attend to. Based on ViT architecture with patch embedding.
    
    Args:
        image_size: Input image size (assumes square). Default: 224.
        patch_size: Size of each patch. Default: 16.
        latent_dim: Output embedding dimension (must match model). Default: 768.
        num_layers: Number of transformer layers. Default: 6.
        num_heads: Number of attention heads. Default: 8.
        in_channels: Number of input channels. Default: 3.
        dropout: Dropout probability. Default: 0.1.
        
    Example:
        >>> vision = VisionExpert(image_size=224, latent_dim=768)
        >>> model.learn(vision)
        >>> output = model.generate("Describe this image", images=my_image)
    """
    
    modality = "vision"
    
    def __init__(
        self,
        image_size: int = 224,
        patch_size: int = 16,
        latent_dim: int = 768,
        num_layers: int = 6,
        num_heads: int = 8,
        in_channels: int = 3,
        dropout: float = 0.1,
    ):
        super().__init__(latent_dim)
        
        self.image_size = image_size
        self.patch_size = patch_size
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.in_channels = in_channels
        
        self.num_patches = (image_size // patch_size) ** 2
        
        # Patch embedding
        self.patch_embed = nn.Conv2d(
            in_channels, latent_dim,
            kernel_size=patch_size,
            stride=patch_size,
        )
        
        # Learnable position embeddings
        self.pos_embed = nn.Parameter(
            torch.randn(1, self.num_patches + 1, latent_dim) * 0.02
        )
        
        # CLS token for global representation
        self.cls_token = nn.Parameter(torch.randn(1, 1, latent_dim) * 0.02)
        
        # Transformer layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=latent_dim,
            nhead=num_heads,
            dim_feedforward=latent_dim * 4,
            dropout=dropout,
            activation='gelu',
            batch_first=True,
            norm_first=True,  # Pre-norm like modern ViT
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)
        
        self.norm = nn.LayerNorm(latent_dim)
        self.dropout = nn.Dropout(dropout)
    
    def encode(self, images: torch.Tensor) -> torch.Tensor:
        """Encode images to context embeddings.
        
        Args:
            images: Input images (batch, channels, height, width).
            
        Returns:
            Context embeddings (batch, num_patches+1, latent_dim).
        """
        batch_size = images.shape[0]
        
        # Patch embedding: (B, C, H, W) -> (B, latent_dim, H/P, W/P)
        x = self.patch_embed(images)
        
        # Flatten patches: (B, latent_dim, H/P, W/P) -> (B, num_patches, latent_dim)
        x = x.flatten(2).transpose(1, 2)
        
        # Add CLS token
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat([cls_tokens, x], dim=1)
        
        # Add position embeddings
        x = x + self.pos_embed[:, :x.size(1), :]
        x = self.dropout(x)
        
        # Transformer encoding
        x = self.transformer(x)
        x = self.norm(x)
        
        return x
    
    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config.update({
            "image_size": self.image_size,
            "patch_size": self.patch_size,
            "num_layers": self.num_layers,
            "num_heads": self.num_heads,
            "in_channels": self.in_channels,
        })
        return config
