"""Math Expert - LoRA adapter for mathematical reasoning."""

import torch
import torch.nn as nn
from typing import Dict, Any

from .expert_module import LoRAAdapter


class MathExpert(LoRAAdapter):
    """LoRA adapter for mathematical reasoning and computation.
    
    Improves the model's ability to solve math problems, perform calculations,
    and understand mathematical notation.
    
    Args:
        latent_dim: Model hidden dimension.
        rank: LoRA rank. Default: 32.
        alpha: LoRA scaling factor. Default: 64.
        dropout: Dropout probability. Default: 0.1.
        
    Example:
        >>> math = MathExpert(latent_dim=768)
        >>> model.learn(math)
        >>> output = model.generate("Solve: 2x + 5 = 15")
    """
    
    modality = "math"
    
    def __init__(
        self,
        latent_dim: int,
        rank: int = 32,
        alpha: float = 64.0,
        dropout: float = 0.1,
    ):
        super().__init__(latent_dim, rank=rank, alpha=alpha, dropout=dropout)
        
        # Numerical precision layer - helps with arithmetic
        self.precision_layer = nn.Sequential(
            nn.Linear(latent_dim, latent_dim),
            nn.LayerNorm(latent_dim),
            nn.GELU(),
        )
    
    def adapt(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Apply math-aware adaptation."""
        # Precision-enhanced input
        precise = self.precision_layer(hidden_states)
        
        # LoRA on precision-enhanced states  
        lora_out = self.lora_B(self.lora_A(self.dropout(precise)))
        
        return hidden_states + self.scaling * lora_out
