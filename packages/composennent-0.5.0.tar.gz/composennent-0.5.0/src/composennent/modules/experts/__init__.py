"""Expert layers and modular expert modules.

This module provides:
- MoE layers: SparseMoELayer, SoftMaxRouter
- Modular experts: VisionExpert, SpeechExpert, CodeExpert, etc.
"""

from .expert_layer import SparseMoELayer
from .router import SoftMaxRouter

# Modular expert system
from .expert_module import ExpertModule, EncoderExpert, AdapterExpert, LoRAAdapter
from .vision_expert import VisionExpert
from .speech_expert import SpeechExpert
from .code_expert import CodeExpert
from .math_expert import MathExpert
from .data_science_expert import DataScienceExpert
from .linguistics_expert import LinguisticsExpert

__all__ = [
    # MoE
    "SparseMoELayer",
    "SoftMaxRouter",
    # Base classes
    "ExpertModule",
    "EncoderExpert", 
    "AdapterExpert",
    "LoRAAdapter",
    # Modality experts
    "VisionExpert",
    "SpeechExpert",
    # Domain experts
    "CodeExpert",
    "MathExpert",
    "DataScienceExpert",
    "LinguisticsExpert",
]
