"""Expert Module Base Classes for Modular AI Architecture.

This module provides the foundation for pluggable expert modules that can be
attached to any BaseLanguageModel (GPT, EncoderDecoderModel, etc.) without
retraining the base model.

Two types of experts:
- EncoderExpert: Encodes new modalities (vision, speech) → context embeddings
- AdapterExpert: Adapts hidden states for domains (math, code) → LoRA-style
"""

import torch
import torch.nn as nn
from abc import abstractmethod
from typing import Literal, Dict, Any

from composennent.modules.block import Block


class ExpertModule(Block):
    """Abstract base class for all expert modules.
    
    Expert modules can be attached to any model inheriting from BaseLanguageModel
    using the `model.learn(expert)` method. They provide specialized capabilities
    without retraining the base model.
    
    Attributes:
        modality: Unique identifier for this expert (e.g., "vision", "math").
        expert_type: Either "encoder" (prepends context) or "adapter" (modifies hidden).
        
    Example:
        >>> class MyExpert(ExpertModule):
        ...     modality = "custom"
        ...     expert_type = "adapter"
        ...     
        ...     def forward(self, x):
        ...         return self.process(x)
    """
    
    modality: str = "base"
    expert_type: Literal["encoder", "adapter"] = "encoder"
    
    def __init__(self, latent_dim: int):
        super().__init__()
        self.latent_dim = latent_dim
    
    @abstractmethod
    def get_config(self) -> Dict[str, Any]:
        """Return configuration for save/load."""
        return {
            "modality": self.modality,
            "expert_type": self.expert_type,
            "latent_dim": self.latent_dim,
        }


class EncoderExpert(ExpertModule):
    """Expert that encodes new modality inputs into context embeddings.
    
    Use this for adding new input modalities like vision, speech, or audio.
    The encoded output is prepended to the token embeddings as context.
    
    Subclasses must implement:
        - encode(inputs) -> torch.Tensor of shape (batch, seq, latent_dim)
        
    Example:
        >>> class VisionExpert(EncoderExpert):
        ...     modality = "vision"
        ...     
        ...     def encode(self, images):
        ...         # images: (batch, 3, H, W) -> (batch, num_patches, latent_dim)
        ...         return self.vit(images)
    """
    
    expert_type: Literal["encoder", "adapter"] = "encoder"
    
    @abstractmethod
    def encode(self, inputs: torch.Tensor) -> torch.Tensor:
        """Encode modality-specific inputs to context embeddings.
        
        Args:
            inputs: Modality-specific input tensor (e.g., images, audio).
            
        Returns:
            Context embeddings of shape (batch, seq_len, latent_dim).
            These will be prepended to the token embeddings.
        """
        ...
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass delegates to encode."""
        return self.encode(x)


class AdapterExpert(ExpertModule):
    """Expert that adapts hidden states for domain-specific tasks.
    
    Use this for improving performance on specific domains like math,
    code, data science, or linguistics without changing base weights.
    Implements LoRA-style low-rank adaptation.
    
    Subclasses must implement:
        - adapt(hidden_states) -> torch.Tensor (modified hidden states)
        
    Example:
        >>> class MathExpert(AdapterExpert):
        ...     modality = "math"
        ...     
        ...     def adapt(self, hidden):
        ...         # Apply LoRA transformation
        ...         return hidden + self.lora_B(self.lora_A(hidden))
    """
    
    expert_type: Literal["encoder", "adapter"] = "adapter"
    
    @abstractmethod
    def adapt(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Adapt hidden states for domain-specific behavior.
        
        Args:
            hidden_states: Model hidden states (batch, seq, latent_dim).
            
        Returns:
            Modified hidden states of same shape.
        """
        ...
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass delegates to adapt."""
        return self.adapt(x)


class LoRAAdapter(AdapterExpert):
    """Low-Rank Adaptation layer for domain experts.
    
    Implements the LoRA technique: output = x + scale * B(A(x))
    where A projects down to rank r, and B projects back up.
    
    Args:
        latent_dim: Model hidden dimension.
        rank: Low-rank decomposition rank (default: 16).
        alpha: Scaling factor (default: 32).
        dropout: Dropout probability (default: 0.1).
        
    Example:
        >>> adapter = LoRAAdapter(latent_dim=768, rank=16)
        >>> output = adapter(hidden_states)
    """
    
    def __init__(
        self,
        latent_dim: int,
        rank: int = 16,
        alpha: float = 32.0,
        dropout: float = 0.1,
    ):
        super().__init__(latent_dim)
        self.rank = rank
        self.alpha = alpha
        self.scaling = alpha / rank
        
        # Low-rank matrices
        self.lora_A = nn.Linear(latent_dim, rank, bias=False)
        self.lora_B = nn.Linear(rank, latent_dim, bias=False)
        self.dropout = nn.Dropout(dropout)
        
        # Initialize A with Kaiming, B with zeros (start as identity)
        nn.init.kaiming_uniform_(self.lora_A.weight, a=5**0.5)
        nn.init.zeros_(self.lora_B.weight)
    
    def adapt(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Apply LoRA adaptation."""
        lora_out = self.lora_B(self.lora_A(self.dropout(hidden_states)))
        return hidden_states + self.scaling * lora_out
    
    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config.update({
            "rank": self.rank,
            "alpha": self.alpha,
        })
        return config
