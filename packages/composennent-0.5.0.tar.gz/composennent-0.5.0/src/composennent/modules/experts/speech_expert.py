"""Speech Expert - Whisper-style audio encoder for speech understanding.

Encodes audio (mel spectrograms) into context embeddings for speech-to-text
and audio understanding tasks.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any

from .expert_module import EncoderExpert


class SpeechExpert(EncoderExpert):
    """Whisper-style audio encoder for speech understanding.
    
    Converts mel spectrograms into a sequence of embeddings that the
    language model can attend to for transcription or audio understanding.
    
    Args:
        n_mels: Number of mel frequency bins. Default: 80.
        n_ctx: Maximum context length (audio frames). Default: 1500.
        latent_dim: Output embedding dimension. Default: 768.
        num_layers: Number of transformer layers. Default: 4.
        num_heads: Number of attention heads. Default: 8.
        dropout: Dropout probability. Default: 0.1.
        
    Example:
        >>> speech = SpeechExpert(n_mels=80, latent_dim=768)
        >>> model.learn(speech)
        >>> output = model.generate("Transcribe:", audio=mel_spectrogram)
    """
    
    modality = "speech"
    
    def __init__(
        self,
        n_mels: int = 80,
        n_ctx: int = 1500,
        latent_dim: int = 768,
        num_layers: int = 4,
        num_heads: int = 8,
        dropout: float = 0.1,
    ):
        super().__init__(latent_dim)
        
        self.n_mels = n_mels
        self.n_ctx = n_ctx
        self.num_layers = num_layers
        self.num_heads = num_heads
        
        # Conv layers (Whisper-style downsampling)
        self.conv1 = nn.Conv1d(n_mels, latent_dim, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(latent_dim, latent_dim, kernel_size=3, stride=2, padding=1)
        
        # Position embedding  
        self.pos_embed = nn.Embedding(n_ctx // 2, latent_dim)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=latent_dim,
            nhead=num_heads,
            dim_feedforward=latent_dim * 4,
            dropout=dropout,
            activation='gelu',
            batch_first=True,
            norm_first=True,
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers)
        
        self.norm = nn.LayerNorm(latent_dim)
        self.dropout = nn.Dropout(dropout)
    
    def encode(self, audio: torch.Tensor) -> torch.Tensor:
        """Encode mel spectrogram to context embeddings.
        
        Args:
            audio: Mel spectrogram (batch, n_mels, time).
            
        Returns:
            Context embeddings (batch, time//2, latent_dim).
        """
        # Conv layers
        x = F.gelu(self.conv1(audio))
        x = F.gelu(self.conv2(x))
        
        # (B, latent_dim, T//2) -> (B, T//2, latent_dim)
        x = x.transpose(1, 2)
        
        # Position embeddings
        seq_len = x.size(1)
        positions = torch.arange(seq_len, device=x.device).unsqueeze(0)
        x = x + self.pos_embed(positions)
        x = self.dropout(x)
        
        # Transformer
        x = self.transformer(x)
        x = self.norm(x)
        
        return x
    
    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config.update({
            "n_mels": self.n_mels,
            "n_ctx": self.n_ctx,
            "num_layers": self.num_layers,
            "num_heads": self.num_heads,
        })
        return config
