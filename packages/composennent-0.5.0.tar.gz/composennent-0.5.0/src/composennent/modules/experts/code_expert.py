"""Code Expert - LoRA adapter for code generation and understanding."""

import torch
import torch.nn as nn
from typing import Dict, Any

from .expert_module import LoRAAdapter


class CodeExpert(LoRAAdapter):
    """LoRA adapter for code generation and programming tasks.
    
    Improves the model's ability to generate, understand, and debug code
    without retraining the base model weights.
    
    Args:
        latent_dim: Model hidden dimension.
        rank: LoRA rank (higher = more capacity). Default: 32.
        alpha: LoRA scaling factor. Default: 64.
        dropout: Dropout probability. Default: 0.1.
        
    Example:
        >>> code = CodeExpert(latent_dim=768)
        >>> model.learn(code)
        >>> output = model.generate("Write a Python function to sort a list")
    """
    
    modality = "code"
    
    def __init__(
        self,
        latent_dim: int,
        rank: int = 32,
        alpha: float = 64.0,
        dropout: float = 0.1,
    ):
        super().__init__(latent_dim, rank=rank, alpha=alpha, dropout=dropout)
        
        # Additional code-specific layers for syntax awareness
        self.syntax_gate = nn.Sequential(
            nn.Linear(latent_dim, latent_dim // 4),
            nn.GELU(),
            nn.Linear(latent_dim // 4, latent_dim),
            nn.Sigmoid(),
        )
    
    def adapt(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """Apply code-aware adaptation."""
        # Base LoRA
        lora_out = self.lora_B(self.lora_A(self.dropout(hidden_states)))
        
        # Syntax-aware gating
        gate = self.syntax_gate(hidden_states)
        
        return hidden_states + self.scaling * gate * lora_out
