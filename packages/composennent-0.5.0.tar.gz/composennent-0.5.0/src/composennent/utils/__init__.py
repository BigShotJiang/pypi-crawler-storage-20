"""Utility functions and helpers."""
from .text_preprocessing import pre_tokenize, normalize_text
from .gradient_utils import (
    compute_gradient_norms,
    compute_layer_gradient_norms,
    check_vanishing_gradients,
    check_exploding_gradients,
    gradient_health_check,
    GradientMonitor,
)
from .function_calling import (
    FunctionCall,
    FunctionDefinition,
    FunctionRegistry,
    parse_function_call,
    format_function_result,
    create_function_call_training_example,
    FunctionCallingAgent,
    FUNCTION_START,
    FUNCTION_END,
    RESULT_START,
    RESULT_END,
)
from .quantization import (
    quantize_dynamic,
    quantize_4bit,
    estimate_memory_savings,
    save_quantized,
    load_quantized,
)

__all__ = [
    # Text preprocessing
    "pre_tokenize", 
    "normalize_text",
    # Gradient utilities
    "compute_gradient_norms",
    "compute_layer_gradient_norms",
    "check_vanishing_gradients",
    "check_exploding_gradients",
    "gradient_health_check",
    "GradientMonitor",
    # Function calling
    "FunctionCall",
    "FunctionDefinition",
    "FunctionRegistry",
    "parse_function_call",
    "format_function_result",
    "create_function_call_training_example",
    "FunctionCallingAgent",
    "FUNCTION_START",
    "FUNCTION_END",
    "RESULT_START",
    "RESULT_END",
    # Quantization
    "quantize_dynamic",
    "quantize_4bit",
    "estimate_memory_savings",
    "save_quantized",
    "load_quantized",
]