"""
    cli.core.webhooks

    Webhook client for sending test results to external systems.
"""

import time
from urllib.parse import urlparse

import click
import requests


def validate_webhook_url(url: str) -> bool:
    """
    Validate webhook URL format.

    Args:
        url: The URL to validate

    Returns:
        True if URL is valid, False otherwise
    """
    if not url:
        return False

    try:
        parsed = urlparse(url)
        # Must have scheme and netloc
        if not parsed.scheme or not parsed.netloc:
            return False
        # Only allow http/https
        if parsed.scheme not in ('http', 'https'):
            return False
        return True
    except Exception:
        return False


def send_webhook(
    url: str,
    data: dict,
    headers: dict | None = None,
    timeout: int = 30,
    retries: int = 3,
) -> bool:
    """
    Send data to webhook endpoint with retry logic.

    Args:
        url: Webhook URL to POST to
        data: Dictionary to send as JSON
        headers: Optional headers to include (e.g., auth tokens)
        timeout: Request timeout in seconds
        retries: Number of retry attempts

    Returns:
        True if webhook was sent successfully, False otherwise
    """
    if not validate_webhook_url(url):
        click.secho(f'Invalid webhook URL: {url}', fg='red', err=True)
        return False

    request_headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'lager-cli',
    }
    if headers:
        request_headers.update(headers)

    last_error = None
    for attempt in range(retries):
        try:
            resp = requests.post(
                url,
                json=data,
                headers=request_headers,
                timeout=timeout,
            )

            if resp.status_code >= 200 and resp.status_code < 300:
                return True

            # Log non-success status codes
            last_error = f'HTTP {resp.status_code}'
            if resp.status_code >= 400 and resp.status_code < 500:
                # Client errors - don't retry
                click.secho(
                    f'Webhook failed with {last_error}: {resp.text[:200]}',
                    fg='red',
                    err=True,
                )
                return False

            # Server errors - retry with backoff
            click.secho(
                f'Webhook returned {last_error}, retrying... ({attempt + 1}/{retries})',
                fg='yellow',
                err=True,
            )

        except requests.exceptions.Timeout:
            last_error = 'timeout'
            click.secho(
                f'Webhook timed out, retrying... ({attempt + 1}/{retries})',
                fg='yellow',
                err=True,
            )

        except requests.exceptions.ConnectionError as e:
            last_error = f'connection error: {e}'
            click.secho(
                f'Webhook connection failed, retrying... ({attempt + 1}/{retries})',
                fg='yellow',
                err=True,
            )

        except requests.exceptions.RequestException as e:
            last_error = str(e)
            click.secho(
                f'Webhook error: {e}, retrying... ({attempt + 1}/{retries})',
                fg='yellow',
                err=True,
            )

        # Exponential backoff: 1s, 2s, 4s
        if attempt < retries - 1:
            backoff = 2 ** attempt
            time.sleep(backoff)

    click.secho(f'Webhook failed after {retries} attempts: {last_error}', fg='red', err=True)
    return False
