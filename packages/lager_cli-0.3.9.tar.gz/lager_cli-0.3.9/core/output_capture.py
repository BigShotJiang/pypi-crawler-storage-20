"""
    cli.core.output_capture

    Output capture and persistence for lager python executions.
"""

import csv
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Callable, Optional

import click

from .utils import StreamDatatypes
from .webhooks import send_webhook
from ..schemas.test_result import TestResult


class OutputCapture:
    """
    Captures output from lager python executions and persists results.

    Integrates with run_python_internal() via callback mechanism.
    """

    def __init__(
        self,
        result: TestResult,
        save_file: Optional[str] = None,
        save_format: str = 'json',
        webhook_url: Optional[str] = None,
        webhook_headers: Optional[dict] = None,
        include_stdout: bool = False,
        include_stderr: bool = True,
    ):
        """
        Initialize output capture.

        Args:
            result: TestResult instance to populate
            save_file: Path to save results (None to skip saving)
            save_format: Output format: 'json', 'jsonl', or 'csv'
            webhook_url: URL to POST results (None to skip)
            webhook_headers: Headers to include in webhook request
            include_stdout: Whether to capture stdout in result
            include_stderr: Whether to capture stderr in result
        """
        self.result = result
        self.save_file = save_file
        self.save_format = save_format
        self.webhook_url = webhook_url
        self.webhook_headers = webhook_headers or {}
        self.include_stdout = include_stdout
        self.include_stderr = include_stderr

        # Internal buffers
        self._stdout_buffer = b''
        self._stderr_buffer = b''
        self._structured_outputs: list[Any] = []

        # Timing
        self._start_time = time.time()

    def create_callback(self) -> Callable:
        """
        Create a callback function compatible with run_python_internal().

        Returns a callback with signature:
            callback(datatype, content, context) -> (done, context)

        The callback:
        - Captures stdout/stderr to internal buffers
        - Stores structured output from OUTPUT channel
        - Still displays output to terminal in real-time
        - Returns control to caller on EXIT
        """
        def callback(datatype: StreamDatatypes, content: Any, context: Any):
            if context is None:
                context = {}

            if datatype == StreamDatatypes.EXIT:
                # Store exit code in context for finalize()
                context['exit_code'] = content
                return (True, context)

            elif datatype == StreamDatatypes.STDOUT:
                # Buffer stdout
                self._stdout_buffer += content
                # Still display to terminal
                click.echo(content.decode('utf-8', errors='ignore'), nl=False)

            elif datatype == StreamDatatypes.STDERR:
                # Buffer stderr
                self._stderr_buffer += content
                # Still display to stderr
                click.echo(content.decode('utf-8', errors='ignore'), nl=False, err=True)

            elif datatype == StreamDatatypes.OUTPUT:
                # Store structured output
                self._structured_outputs.append(content)
                # Still display to terminal
                click.echo(content)

            return (False, context)

        return callback

    def finalize(self, exit_code: int, duration_ms: Optional[float] = None) -> None:
        """
        Process captured output and populate result.

        Args:
            exit_code: Process exit code
            duration_ms: Execution duration in milliseconds (calculated if not provided)
        """
        # Set basic results
        self.result.exit_code = exit_code
        self.result.success = (exit_code == 0)

        # Calculate duration if not provided
        if duration_ms is not None:
            self.result.duration_ms = duration_ms
        else:
            elapsed = time.time() - self._start_time
            self.result.duration_ms = elapsed * 1000

        # Process stdout
        if self.include_stdout and self._stdout_buffer:
            self.result.stdout = self._stdout_buffer.decode('utf-8', errors='replace')

        # Process stderr
        if self.include_stderr and self._stderr_buffer:
            self.result.stderr = self._stderr_buffer.decode('utf-8', errors='replace')
            # Extract errors from stderr
            self._extract_errors()

        # Try to extract JSON from stdout (for scripts using print(json.dumps(...)))
        self._extract_structured_from_stdout()

        # Process structured output
        if self._structured_outputs:
            if len(self._structured_outputs) == 1:
                self.result.structured_output = self._structured_outputs[0]
            else:
                self.result.structured_output = self._structured_outputs

            # Try to extract measurements from structured output
            self._extract_measurements()

        # Generate summary
        self.result.summary = self.result.generate_summary()

    def _extract_errors(self) -> None:
        """Extract error messages from stderr."""
        if not self.result.stderr:
            return

        # Common error patterns
        error_patterns = [
            r'(?:Error|Exception|Traceback).*?(?=\n\n|\Z)',
            r'AssertionError:.*',
            r'ValueError:.*',
            r'TypeError:.*',
            r'KeyError:.*',
            r'RuntimeError:.*',
            r'FileNotFoundError:.*',
            r'ConnectionError:.*',
        ]

        for pattern in error_patterns:
            matches = re.findall(pattern, self.result.stderr, re.MULTILINE | re.DOTALL)
            for match in matches:
                # Clean up and truncate long errors
                error = match.strip()[:500]
                if error and error not in self.result.errors:
                    self.result.errors.append(error)

    def _extract_structured_from_stdout(self) -> None:
        """
        Try to parse stdout for JSON and extract structured data.

        This allows scripts to use simple print(json.dumps(...)) to output
        structured data that gets captured in the result.
        """
        if not self._stdout_buffer:
            return

        stdout_text = self._stdout_buffer.decode('utf-8', errors='replace')

        # Try to find JSON objects in stdout (could be mixed with other output)
        # Look for lines that are valid JSON objects
        for line in stdout_text.split('\n'):
            line = line.strip()
            if line.startswith('{') and line.endswith('}'):
                try:
                    data = json.loads(line)
                    if isinstance(data, dict):
                        self._structured_outputs.append(data)
                except json.JSONDecodeError:
                    continue

    def _extract_measurements(self) -> None:
        """Extract measurements from structured output."""
        if not self.result.structured_output:
            return

        output = self.result.structured_output

        # Handle single dict output
        if isinstance(output, dict):
            self._extract_measurements_from_dict(output)
        # Handle list of outputs
        elif isinstance(output, list):
            for item in output:
                if isinstance(item, dict):
                    self._extract_measurements_from_dict(item)

    def _extract_measurements_from_dict(self, data: dict) -> None:
        """Extract measurements from a dictionary."""
        # Look for 'measurements' key
        if 'measurements' in data and isinstance(data['measurements'], list):
            for m in data['measurements']:
                if isinstance(m, dict) and 'name' in m and 'value' in m:
                    self.result.add_measurement(
                        name=m['name'],
                        value=m['value'],
                        unit=m.get('unit'),
                        description=m.get('description'),
                    )

        # Look for common measurement patterns in flat dict
        for key, value in data.items():
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                # Skip if already captured via measurements list
                if any(m.name == key for m in self.result.measurements):
                    continue
                # Skip metadata-like keys
                if key in ('exit_code', 'duration', 'timestamp', 'version'):
                    continue
                # Add as measurement
                self.result.add_measurement(name=key, value=float(value))

    def save(self) -> Optional[Path]:
        """
        Save result to file.

        Returns:
            Path to saved file, or None if save was not configured
        """
        if not self.save_file:
            return None

        path = Path(self.save_file)

        try:
            if self.save_format == 'json':
                self._save_json(path)
            elif self.save_format == 'jsonl':
                self._save_jsonl(path)
            elif self.save_format == 'csv':
                self._save_csv(path)
            else:
                click.secho(f'Unknown save format: {self.save_format}', fg='red', err=True)
                return None

            return path

        except IOError as e:
            click.secho(f'Failed to save results: {e}', fg='red', err=True)
            return None

    def _save_json(self, path: Path) -> None:
        """Save as formatted JSON (overwrites file)."""
        with open(path, 'w') as f:
            f.write(self.result.to_json())
            f.write('\n')

    def _save_jsonl(self, path: Path) -> None:
        """Save as JSONL (appends to file)."""
        with open(path, 'a') as f:
            f.write(self.result.to_jsonl())
            f.write('\n')

    def _save_csv(self, path: Path) -> None:
        """Save as CSV (creates with header or appends)."""
        file_exists = path.exists() and path.stat().st_size > 0

        with open(path, 'a', newline='') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(TestResult.csv_headers())
            writer.writerow(self.result.to_csv_row())

    def send_to_webhook(self) -> bool:
        """
        Send result to webhook endpoint.

        Returns:
            True if webhook was sent successfully, False otherwise
        """
        if not self.webhook_url:
            return True  # No webhook configured is not an error

        return send_webhook(
            url=self.webhook_url,
            data=self.result.to_dict(),
            headers=self.webhook_headers,
        )
