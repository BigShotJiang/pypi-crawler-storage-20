"""
    cli.schemas.test_result

    Data structures for capturing and persisting test results from lager python executions.
    Designed for LLM queryability with rich metadata and semantic context.
"""

import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Optional


@dataclass
class ExecutionContext:
    """Context about how the test was executed."""
    box: Optional[str] = None
    script: Optional[str] = None
    args: list[str] = field(default_factory=list)
    env_vars: dict[str, str] = field(default_factory=dict)
    docker_image: Optional[str] = None
    timeout: Optional[int] = None

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None and v != [] and v != {}}


@dataclass
class DeviceInfo:
    """Information about the device under test."""
    device_id: Optional[str] = None
    device_type: Optional[str] = None
    firmware_version: Optional[str] = None
    serial_number: Optional[str] = None

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class Measurement:
    """A single measurement from a test."""
    name: str
    value: float
    unit: Optional[str] = None
    description: Optional[str] = None
    timestamp: Optional[str] = None

    def to_dict(self) -> dict:
        result = {'name': self.name, 'value': self.value}
        if self.unit:
            result['unit'] = self.unit
        if self.description:
            result['description'] = self.description
        if self.timestamp:
            result['timestamp'] = self.timestamp
        return result


@dataclass
class TestResult:
    """
    Structured test result from a lager python execution.

    Designed for:
    - Local persistence (JSON, JSONL, CSV)
    - Webhook delivery to external systems
    - LLM queryability with rich metadata
    """
    # Identity
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    test_name: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat() + 'Z')

    # Execution context
    execution: ExecutionContext = field(default_factory=ExecutionContext)
    device: DeviceInfo = field(default_factory=DeviceInfo)

    # Timing
    duration_ms: Optional[float] = None

    # Results
    exit_code: Optional[int] = None
    success: Optional[bool] = None

    # Output capture
    stdout: Optional[str] = None
    stderr: Optional[str] = None
    structured_output: Optional[Any] = None

    # Extracted data
    measurements: list[Measurement] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    # Metadata
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    # LLM-friendly summary
    summary: Optional[str] = None

    def add_measurement(self, name: str, value: float, unit: Optional[str] = None,
                        description: Optional[str] = None) -> None:
        """Add a measurement to the result."""
        self.measurements.append(Measurement(
            name=name,
            value=value,
            unit=unit,
            description=description,
            timestamp=datetime.utcnow().isoformat() + 'Z',
        ))

    def generate_summary(self) -> str:
        """Generate an LLM-friendly summary of the test result."""
        parts = []

        # Status
        status = "PASSED" if self.success else "FAILED"
        parts.append(f"Test '{self.test_name or 'unnamed'}' {status}")

        # Duration
        if self.duration_ms is not None:
            if self.duration_ms < 1000:
                parts.append(f"in {self.duration_ms:.0f}ms")
            else:
                parts.append(f"in {self.duration_ms / 1000:.1f}s")

        # Box
        if self.execution.box:
            parts.append(f"on box '{self.execution.box}'")

        # Device
        if self.device.device_id:
            parts.append(f"(device: {self.device.device_id})")

        summary = ' '.join(parts)

        # Additional context
        extras = []
        if self.measurements:
            extras.append(f"recording {len(self.measurements)} measurement(s)")
        if self.errors:
            extras.append(f"with {len(self.errors)} error(s)")
        if self.warnings:
            extras.append(f"with {len(self.warnings)} warning(s)")

        if extras:
            summary += ' ' + ', '.join(extras) + '.'
        else:
            summary += '.'

        return summary

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        result = {
            'id': self.id,
            'test_name': self.test_name,
            'timestamp': self.timestamp,
            'duration_ms': self.duration_ms,
            'execution': self.execution.to_dict(),
            'device': self.device.to_dict(),
            'exit_code': self.exit_code,
            'success': self.success,
        }

        # Optional fields - only include if present
        if self.stdout is not None:
            result['stdout'] = self.stdout
        if self.stderr is not None:
            result['stderr'] = self.stderr
        if self.structured_output is not None:
            result['structured_output'] = self.structured_output

        # Lists - only include if non-empty
        if self.measurements:
            result['measurements'] = [m.to_dict() for m in self.measurements]
        if self.errors:
            result['errors'] = self.errors
        if self.warnings:
            result['warnings'] = self.warnings
        if self.tags:
            result['tags'] = self.tags
        if self.metadata:
            result['metadata'] = self.metadata

        # Generate summary if not set
        if self.summary:
            result['summary'] = self.summary
        else:
            result['summary'] = self.generate_summary()

        return result

    def to_json(self, indent: int = 2) -> str:
        """Serialize to formatted JSON string."""
        return json.dumps(self.to_dict(), indent=indent)

    def to_jsonl(self) -> str:
        """Serialize to single-line JSON (for JSONL files)."""
        return json.dumps(self.to_dict(), separators=(',', ':'))

    def to_csv_row(self) -> list:
        """
        Convert to a flat list for CSV output.

        Returns values in this order:
        id, test_name, timestamp, duration_ms, box, script, device_id,
        exit_code, success, measurement_count, error_count, summary
        """
        return [
            self.id,
            self.test_name or '',
            self.timestamp,
            self.duration_ms if self.duration_ms is not None else '',
            self.execution.box or '',
            self.execution.script or '',
            self.device.device_id or '',
            self.exit_code if self.exit_code is not None else '',
            'true' if self.success else 'false' if self.success is not None else '',
            len(self.measurements),
            len(self.errors),
            self.summary or self.generate_summary(),
        ]

    @staticmethod
    def csv_headers() -> list[str]:
        """Return CSV column headers matching to_csv_row() output."""
        return [
            'id',
            'test_name',
            'timestamp',
            'duration_ms',
            'box',
            'script',
            'device_id',
            'exit_code',
            'success',
            'measurement_count',
            'error_count',
            'summary',
        ]
