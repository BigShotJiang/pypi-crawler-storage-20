"""
    cli.schemas

    Data structures for structured output and test results.
"""

from .test_result import (
    TestResult,
    ExecutionContext,
    DeviceInfo,
    Measurement,
)

__all__ = [
    'TestResult',
    'ExecutionContext',
    'DeviceInfo',
    'Measurement',
]
