yallm
=====
yet another LLM
