"""infomeasure package version."""

__version__ = "0.5.1"
