"""
Module to include the functionality related
to easings.

Thanks for the inspiration:
- https://github.com/semitable/easing-functions/blob/master/easing_functions
"""
from yta_math_easings.linear import LinearEasing
from yta_math_easings.slow_into import SlowIntoEasing
from yta_math_easings.smooth import SmoothEasing
from yta_math_easings.smooth_step import SmoothStepEasing

# TODO: Add more from 'yta_math.rate_functions'


__all__ = [
    'LinearEasing',
    'SlowIntoEasing',
    'SmoothEasing',
    'SmoothStepEasing'
]