"""
    lager.commands.box.hello

    Test box connectivity and show version
"""
import click
import requests
from ...box_storage import resolve_and_validate_box_with_name


@click.command()
@click.pass_context
@click.option("--box", required=False, help="Lagerbox name or IP")
def hello(ctx, box):
    """Test box connectivity and show version

    Checks if the box is online and displays version information.

    Examples:
        lager hello --box JUL-3
        lager hello --box 192.168.1.100
        lager hello  # Uses default box
    """
    # Resolve and validate the box
    resolved_box, box_name = resolve_and_validate_box_with_name(ctx, box)

    # Port for the Python service
    port = 5000

    # Display header
    click.echo()
    click.echo(f'Box: {box_name}')
    click.echo(f'IP: {resolved_box}')

    try:
        # Query the /cli-version endpoint for version info first
        version_url = f'http://{resolved_box}:{port}/cli-version'
        version_response = requests.get(version_url, timeout=10)

        if version_response.status_code == 200:
            data = version_response.json()
            box_version = data.get('box_version')

            if box_version:
                click.echo(f'Version: {box_version}')
            else:
                click.echo(f'Version: {click.style("Unknown", fg="yellow")}')
        elif version_response.status_code == 404:
            click.echo(f'Version: {click.style("Unknown", fg="yellow")}')
        else:
            click.echo(f'Version: {click.style("Unknown", fg="yellow")}')

        # Test connectivity with /hello endpoint
        hello_url = f'http://{resolved_box}:{port}/hello'
        hello_response = requests.get(hello_url, timeout=10)

        click.echo()
        if hello_response.status_code == 200:
            click.secho(f'{box_name} is online and responding!', fg='green')
        else:
            click.secho(f'{box_name} responded with HTTP {hello_response.status_code}', fg='yellow')

    except requests.exceptions.Timeout:
        click.secho('Connection timed out', fg='red', err=True)
        click.echo()
        click.echo(f'Could not connect to {resolved_box}', err=True)
        click.echo('The box may be offline or the services may not be running.', err=True)
        ctx.exit(1)

    except requests.exceptions.ConnectionError:
        click.secho('Connection failed', fg='red', err=True)
        click.echo()
        click.echo(f'Could not connect to {resolved_box}', err=True)
        click.echo('The box may be offline or the services may not be running.', err=True)
        ctx.exit(1)

    except Exception as e:
        click.secho(f'Error: {str(e)}', fg='red', err=True)
        ctx.exit(1)

    click.echo()
