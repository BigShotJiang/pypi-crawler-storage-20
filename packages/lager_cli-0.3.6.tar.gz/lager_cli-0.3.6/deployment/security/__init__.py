"""Security scripts subpackage."""
