"""Integration tests for yamlgraph."""
