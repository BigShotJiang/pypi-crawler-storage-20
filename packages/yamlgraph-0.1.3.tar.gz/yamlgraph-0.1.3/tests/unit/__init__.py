"""Unit tests for yamlgraph."""
