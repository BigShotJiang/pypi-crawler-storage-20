######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-19T04:51:37.356381                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

