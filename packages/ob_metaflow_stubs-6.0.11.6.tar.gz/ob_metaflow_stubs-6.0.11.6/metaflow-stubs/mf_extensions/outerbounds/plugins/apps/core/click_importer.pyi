######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-19T04:51:37.375844                                                            #
######################################################################################################

from __future__ import annotations


from ......_vendor import click as metaflow_click
from ......_vendor import click as click

