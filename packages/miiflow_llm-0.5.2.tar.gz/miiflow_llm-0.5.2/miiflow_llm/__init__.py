"""
DEPRECATED: miiflow-llm has been renamed to miiflow-agent.

Please update your dependencies:
    pip uninstall miiflow-llm
    pip install miiflow-agent

And update your imports:
    from miiflow_agent import Agent, LLMClient
"""

import warnings

warnings.warn(
    "miiflow-llm is deprecated and has been renamed to miiflow-agent. "
    "Please install miiflow-agent instead: pip install miiflow-agent",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from miiflow_agent for backwards compatibility
from miiflow_agent import *
