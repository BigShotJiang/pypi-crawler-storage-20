# miiflow-llm (DEPRECATED)

> **This package has been renamed to [`miiflow-agent`](https://pypi.org/project/miiflow-agent/).**

## Migration

Update your dependencies:

```bash
# Remove old package
pip uninstall miiflow-llm

# Install new package
pip install miiflow-agent
```

Update your imports:

```python
# Old
from miiflow_llm import Agent, LLMClient

# New
from miiflow_agent import Agent, LLMClient
```

## Why the rename?

The package has evolved from a simple LLM client to a full agent orchestration framework with:
- ReAct agents
- Plan & Execute orchestration
- Multi-Agent orchestration
- Tool system with auto schema generation

The name `miiflow-agent` better reflects its current capabilities.

## Links

- **New Package**: https://pypi.org/project/miiflow-agent/
- **GitHub**: https://github.com/Miiflow/miiflow-agent
- **Documentation**: https://github.com/Miiflow/miiflow-agent#readme
