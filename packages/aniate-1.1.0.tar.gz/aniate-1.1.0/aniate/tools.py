"""
Tools - Thin client that executes tools via server
No system prompts here - all logic lives on the backend
"""
import requests
from rich.console import Console
from rich.markdown import Markdown
from pathlib import Path
from typing import Optional, List

from aniate.config import SERVER_URL
from aniate.auth import get_session

console = Console()


def list_tools():
    """Fetch available tools from server."""
    try:
        response = requests.get(f"{SERVER_URL}/tools", timeout=10)
        if response.ok:
            return response.json().get("tools", [])
        return []
    except:
        return []


def run_tool(slug: str, content: str = "", instructions: str = ""):
    """Execute a tool via the server."""
    session = get_session()
    if not session:
        console.print("[dim]Authentication required. Run: ant login[/dim]")
        return None
    
    try:
        response = requests.post(
            f"{SERVER_URL}/tool/{slug}",
            headers={"Authorization": f"Bearer {session['access_token']}"},
            json={"content": content, "instructions": instructions},
            timeout=60
        )
        
        if response.status_code == 404:
            console.print(f"[dim]Tool '{slug}' not found.[/dim]")
            return None
            
        if response.ok:
            data = response.json()
            return data.get("output")
        else:
            console.print(f"[red]Error:[/red] {response.text}")
            return None
            
    except requests.exceptions.Timeout:
        console.print("[dim]Request timed out.[/dim]")
        return None
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        return None


def tool_command(slug: str, args: Optional[List[str]] = None):
    """Generic tool command handler."""
    args = args or []
    
    # Check if first arg is a file
    content = ""
    instructions = ""
    
    if args:
        first_arg = args[0]
        path = Path(first_arg)
        
        if path.exists() and path.is_file():
            # First arg is a file
            try:
                content = path.read_text()
                instructions = " ".join(args[1:]) if len(args) > 1 else ""
                console.print(f"[dim]{path.name}[/dim]")
            except Exception as e:
                console.print(f"[red]Cannot read file:[/red] {e}")
                return
        else:
            # No file, treat all args as instructions
            instructions = " ".join(args)
    
    if not content and not instructions:
        console.print(f"[dim]Usage: ant {slug} <file> [instructions][/dim]")
        console.print(f"[dim]       ant {slug} \"your question\"[/dim]")
        return
    
    # Execute via server
    output = run_tool(slug, content, instructions)
    
    if output:
        console.print()
        console.print(Markdown(output))
        console.print()
