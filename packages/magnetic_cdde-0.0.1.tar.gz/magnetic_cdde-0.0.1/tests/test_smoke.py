import contextlib
import io
import os
from pathlib import Path
import tempfile
import unittest

import magnetic_cdde
from magnetic_cdde import cli


class CliSmokeTestCase(unittest.TestCase):
    def test_version_constant(self) -> None:
        self.assertEqual(magnetic_cdde.__version__, "0.0.1")

    def test_version_banner(self) -> None:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = cli.main(["--version"])
        self.assertEqual(rc, 0)
        out = buf.getvalue().rstrip("\n")
        self.assertEqual(out, "magnetic (magnetic-cdde) 0.0.1")

    def test_init_creates_vessel(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            old_cwd = os.getcwd()
            os.chdir(tmpdir)
            try:
                self.assertEqual(cli.main(["init"]), 0)
            finally:
                os.chdir(old_cwd)

            readme_path = Path(tmpdir) / ".magnetic" / "README.md"
            self.assertTrue(readme_path.exists())

    def test_test_command_runs_unittest(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            old_cwd = os.getcwd()
            os.chdir(tmpdir)
            try:
                tests_dir = Path("tests")
                tests_dir.mkdir()
                test_file = tests_dir / "test_trivial.py"
                test_file.write_text(
                    "\n".join(
                        [
                            "import unittest",
                            "",
                            "",
                            "class TrivialTestCase(unittest.TestCase):",
                            "    def test_passes(self):",
                            "        self.assertTrue(True)",
                            "",
                        ]
                    ),
                    encoding="utf-8",
                )
                self.assertEqual(cli.main(["test"]), 0)
            finally:
                os.chdir(old_cwd)
