# Magnetic

Magnetic is a tool for **Conversation-Driven Development (CDDE)**: a way of building
software where structured conversation is the primary driver of design,
decision-making, and change.

Magnetic treats thinking as first-class work. You collaborate with a thought
partner to reason about intent, architecture, and tradeoffs, then deliberately
translate that intent into changes on disk.

## What “Conversation-Driven Development” means

In CDDE, conversation precedes execution. Code, configuration, and documentation
are the outputs of that conversation, not the starting point.

Magnetic provides an environment where those conversations can be:
- persistent
- grounded in the local filesystem
- executed deliberately
- audited after the fact

This is not an IDE, and it is not an autonomous agent. The human remains in
control at all times.

## What Magnetic adds on top

Magnetic is not just a place to have conversations. It defines a **disciplined
workflow** for turning intent into execution:

- explicit planning before changes are made
- bounded units of work
- traceable execution steps
- a clear separation between deciding *what* to do and actually *doing* it

These workflow concepts are optional but central to Magnetic’s philosophy.

## Why “Magnetic”

Magnetic is named for the idea of attraction and correction.

The system is designed to gently pull development back toward clarity, intent,
and discipline when things drift. This idea is reflected directly in its core
concepts:

- A **Vessel** is the field in which work happens.
- A **Voyage** is a deliberate movement toward a goal.
- A **Leg** is a concrete step taken in a chosen direction.

Together, these terms form a shared mental model: development as navigation
rather than improvisation. Magnetic does not force a path, but it continually
nudges work back toward its intended bearing.

## Core terms

- Magnetic: the overall system and conventions.
- Vessel: the project workspace rooted at `.magnetic/`.
- Voyage: a bounded unit of work within a Vessel.
- Leg: a concrete execution step within a Voyage.
- Roles: Captain (human authority), First Mate (planner), Bosun (executor).

## Quickstart

```bash
pip install magnetic-cdde
magnetic init
```

PyPI distribution: magnetic-cdde

Dev install:

```bash
pip install -e .
```

Tests:

```bash
magnetic test
```

## Status

Pre-alpha scaffolding. The tool is evolving.
