from magnetic_cdde.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
