import argparse
import subprocess
import sys
from pathlib import Path

from magnetic_cdde import __version__


def init_cmd(args: argparse.Namespace) -> int:
    vessel_dir = Path.cwd() / ".magnetic"
    vessel_dir.mkdir(parents=True, exist_ok=True)

    readme_path = vessel_dir / "README.md"
    if not readme_path.exists():
        readme_path.write_text(
            "This directory is the Magnetic Vessel root for this project.\n",
            encoding="utf-8",
        )

    print("Initialized Magnetic vessel at .magnetic/")
    return 0


def test_cmd(args: argparse.Namespace) -> int:
    tests_dir = Path("tests")
    if not tests_dir.is_dir():
        print("Error: tests/ directory not found.", file=sys.stderr)
        return 2

    cmd = [
        sys.executable,
        "-m",
        "unittest",
        "discover",
        "-s",
        "tests",
        "-p",
        "test*.py",
    ]
    if args.quiet:
        cmd.append("-q")
    elif args.verbose:
        cmd.append("-v")

    completed = subprocess.run(cmd, check=False)
    return completed.returncode


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="magnetic")
    parser.add_argument(
        "--version",
        action="version",
        version=f"magnetic (magnetic-cdde) {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="Initialize a Magnetic vessel")
    init_parser.set_defaults(func=init_cmd)

    test_parser = subparsers.add_parser(
        "test",
        help="Run test suite with unittest discovery",
    )
    test_group = test_parser.add_mutually_exclusive_group()
    test_group.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Run tests with less output",
    )
    test_group.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Run tests with more output",
    )
    test_parser.set_defaults(func=test_cmd)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        if isinstance(exc.code, int):
            return exc.code
        return 1
    return args.func(args)
