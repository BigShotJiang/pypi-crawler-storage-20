"""Symbol ID generation and resolution utilities.

This module implements the standardized symbol ID format and collision handling
as specified in the planning document.

Symbol ID Format: {file_path}::{scope_chain}::{symbol_name}
Example: src/auth/manager.py::AuthManager::verify_token
Collision Handling: Append arity suffix (e.g., ::calculate#2)
"""

import re
from typing import Dict, Optional


def generate_symbol_id(file_path: str, scope_chain: str, symbol_name: str) -> str:
    """Generate a symbol ID in the standardized format.

    Format: {file_path}::{scope_chain}::{symbol_name}
    When scope_chain is empty, format is: {file_path}::::{symbol_name}

    Args:
        file_path: Relative path to the file containing the symbol
        scope_chain: Scope chain (class names, etc.). Empty string for top-level symbols.
                    Use "::" to separate nested scopes (e.g., "OuterClass::InnerClass").
        symbol_name: Name of the symbol (function, class, method, etc.)

    Returns:
        Symbol ID string in format {file_path}::{scope_chain}::{symbol_name}

    Examples:
        >>> generate_symbol_id("test.py", "", "calculate")
        'test.py::::calculate'
        >>> generate_symbol_id("src/auth/manager.py", "AuthManager", "verify_token")
        'src/auth/manager.py::AuthManager::verify_token'
    """
    # Always format as three parts separated by ::
    # If scope_chain is empty, the middle part is empty string
    return f"{file_path}::{scope_chain}::{symbol_name}"


def handle_collision(
    file_path: str, scope_chain: str, symbol_name: str, arity: int
) -> str:
    """Handle symbol ID collisions by appending arity suffix.

    Appends #N suffix to symbol_name where N is the arity (overload number).
    First occurrence (arity=1) should use generate_symbol_id() without suffix.
    Subsequent overloads use this function.

    Args:
        file_path: Relative path to the file containing the symbol
        scope_chain: Scope chain (class names, etc.). Empty string for top-level symbols.
        symbol_name: Name of the symbol
        arity: Overload number (1-based, but arity > 1 for collisions)

    Returns:
        Symbol ID with arity suffix: {file_path}::{scope_chain}::{symbol_name}#{arity}

    Examples:
        >>> handle_collision("test.py", "", "calculate", 2)
        'test.py::::calculate#2'
        >>> handle_collision("test.py", "Calculator", "add", 2)
        'test.py::Calculator::add#2'
    """
    # Append arity suffix to symbol_name
    symbol_with_suffix = f"{symbol_name}#{arity}"
    return generate_symbol_id(file_path, scope_chain, symbol_with_suffix)


def parse_symbol_id(symbol_id: str) -> Dict[str, str]:
    """Parse a symbol ID into its components.

    Extracts file_path, scope_chain, symbol_name, and optionally arity suffix.

    Args:
        symbol_id: Symbol ID string to parse

    Returns:
        Dictionary with keys:
        - file_path: File path component
        - scope_chain: Scope chain component (may be empty string)
        - symbol_name: Symbol name (without arity suffix if present)
        - arity: Arity number if suffix present, None otherwise

    Examples:
        >>> parse_symbol_id("test.py::::calculate")
        {'file_path': 'test.py', 'scope_chain': '', 'symbol_name': 'calculate', 'arity': None}
        >>> parse_symbol_id("test.py::::calculate#2")
        {'file_path': 'test.py', 'scope_chain': '', 'symbol_name': 'calculate', 'arity': 2}
        >>> parse_symbol_id("src/auth/manager.py::AuthManager::verify_token")
        {'file_path': 'src/auth/manager.py', 'scope_chain': 'AuthManager', 'symbol_name': 'verify_token', 'arity': None}
    """
    # Split by :: to get three parts
    parts = symbol_id.split("::")
    if len(parts) != 3:
        raise ValueError(f"Invalid symbol ID format: {symbol_id}")

    file_path = parts[0]
    scope_chain = parts[1]
    symbol_with_suffix = parts[2]

    # Check for arity suffix in symbol name (e.g., "calculate#2")
    arity = None
    symbol_name = symbol_with_suffix

    # Match pattern: symbol_name#number
    match = re.match(r"^(.+)#(\d+)$", symbol_with_suffix)
    if match:
        symbol_name = match.group(1)
        arity = int(match.group(2))

    return {
        "file_path": file_path,
        "scope_chain": scope_chain,
        "symbol_name": symbol_name,
        "arity": arity,
    }


def validate_symbol_id(symbol_id: str) -> bool:
    """Validate that a symbol ID matches the expected format.

    Valid format: {file_path}::{scope_chain}::{symbol_name}
    Optional arity suffix: {symbol_name}#{number}

    Args:
        symbol_id: Symbol ID string to validate

    Returns:
        True if valid, False otherwise

    Examples:
        >>> validate_symbol_id("test.py::::calculate")
        True
        >>> validate_symbol_id("test.py::::calculate#2")
        True
        >>> validate_symbol_id("test.py::function")
        False  # Only one ::
        >>> validate_symbol_id("::function")
        False  # Missing file_path
    """
    # Must have exactly 2 occurrences of ::
    if symbol_id.count("::") != 2:
        return False

    try:
        parts = parse_symbol_id(symbol_id)
    except (ValueError, IndexError):
        return False

    # Check required components are present
    if not parts["file_path"]:
        return False

    if parts["symbol_name"] is None or parts["symbol_name"] == "":
        return False

    # Scope chain can be empty (valid for top-level symbols)

    return True
