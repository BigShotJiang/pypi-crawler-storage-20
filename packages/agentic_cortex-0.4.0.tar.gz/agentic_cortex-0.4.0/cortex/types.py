"""Type definitions and interfaces for Cortex.

This module defines the core data structures and interfaces that match the
planning documentation schema exactly. Testing agents should reference these
types to understand expected data shapes.
"""

from dataclasses import dataclass
from typing import List, Protocol, Optional
from datetime import datetime


@dataclass
class Symbol:
    """Represents a code symbol (function, class, method, etc.).

    Matches the SQLite symbols table schema from the planning document.
    """

    id: str  # Format: {file_path}::{scope_chain}::{symbol_name}
    file_path: str  # Relative path to file
    kind: str  # 'function', 'class', 'method', 'interface'
    signature: Optional[str]  # Function/class signature string
    docstring: Optional[str]  # Extracted docstring
    start_line: int  # Line number start (1-indexed)
    end_line: int  # Line number end (1-indexed)
    checksum: str  # Hash of the body content for change detection
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


@dataclass
class Edge:
    """Represents a relationship between two symbols.

    Matches the SQLite edges table schema from the planning document.
    """

    source_id: str  # Foreign key to symbols.id
    target_id: str  # Foreign key to symbols.id
    type: str  # 'CALLS', 'INHERITS', 'IMPORTS', 'IMPLEMENTS'
    weight: int = 1  # Optional frequency metric


@dataclass
class VectorRecord:
    """Represents a semantic memory record in LanceDB.

    Matches the LanceDB schema from the planning document.
    """

    vector: List[float]  # 384-dimension float array (all-MiniLM-L6-v2)
    text_content: str  # The text content being embedded
    anchor_symbol_id: str  # Links to symbols.id in SQLite
    created_at: Optional[datetime] = None


# Working Memory categories
MEMORY_CATEGORIES = {
    "session": "Temporary context for current session (auto-expires)",
    "decision": "Architectural/design decisions made",
    "context": "Project-level context that persists",
    "task": "Current work in progress, next steps",
    "preference": "User preferences learned over time",
    "hypothesis": "Debugging state - ruled out causes, investigation notes (auto-expires)",
}


@dataclass
class WorkingMemory:
    """Represents a general working memory record (not anchored to code).

    Unlike VectorRecord which must anchor to a symbol, WorkingMemory stores
    general context like session state, decisions, and preferences.

    Can optionally link to symbols for cross-referencing (e.g., decisions
    that affect specific functions can be surfaced in explore_symbol).
    """

    id: str  # UUID
    category: str  # 'session', 'decision', 'context', 'task', 'preference', 'hypothesis'
    content: str  # The memory content
    vector: List[float]  # 384-dimension for semantic search
    priority: int = 3  # 1-5, higher = surface first
    tags: Optional[List[str]] = None  # For filtering ("auth", "refactor", etc.)
    linked_symbols: Optional[List[str]] = None  # Symbol IDs this memory relates to
    created_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None  # For session-scoped memories


class Parser(Protocol):
    """Interface for AST parsers.

    Parsers extract symbols from source code using Tree-sitter or similar.
    """

    def parse(self, source: str, file_path: str = "") -> List[Symbol]:
        """Parse source code and extract symbols.

        Args:
            source: The source code to parse
            file_path: Optional file path for symbol ID generation

        Returns:
            List of extracted symbols
        """
        ...


class SkeletonGenerator(Protocol):
    """Interface for skeleton code generators.

    Generators create skeleton code (body-stripped) from symbols.
    """

    def generate(self, symbols: List[Symbol], source: str) -> str:
        """Generate skeleton code from symbols.

        Args:
            symbols: List of symbols to include in skeleton
            source: Original source code for reconstruction

        Returns:
            Skeleton code string with bodies replaced by ... or pass
        """
        ...
