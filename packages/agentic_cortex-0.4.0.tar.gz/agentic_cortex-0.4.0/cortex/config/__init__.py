"""Configuration loading and management for Cortex."""

import yaml
from pathlib import Path
from typing import Tuple

from .schema import Config, ProjectConfig, FilesConfig, DatabaseConfig


def find_cortex_root(start_dir: Path) -> Path:
    """Locate .cortex/ directory by walking up the directory tree.

    Args:
        start_dir: Starting directory to search from

    Returns:
        Path to .cortex/ directory

    Raises:
        FileNotFoundError: If .cortex/ directory is not found
    """
    current = Path(start_dir).resolve()

    # Walk up the directory tree
    while current != current.parent:  # Stop at filesystem root
        cortex_dir = current / ".cortex"
        if cortex_dir.exists() and cortex_dir.is_dir():
            return cortex_dir
        current = current.parent

    raise FileNotFoundError(
        f"Could not find .cortex/ directory starting from {start_dir}"
    )


def load_config(cortex_dir: Path) -> Config:
    """Load configuration from .cortex/config.yaml.

    If cortex_dir is not a .cortex/ directory, walks up to find it.

    Args:
        cortex_dir: Path to .cortex/ directory or any subdirectory

    Returns:
        Config object with validated configuration

    Raises:
        FileNotFoundError: If .cortex/ or config.yaml not found
        ValueError: If config validation fails
    """
    # If not already a .cortex/ directory, find it
    if cortex_dir.name != ".cortex":
        cortex_dir = find_cortex_root(cortex_dir)

    config_file = cortex_dir / "config.yaml"
    if not config_file.exists():
        raise FileNotFoundError(
            f"Configuration file not found: {config_file}"
        )

    # Load YAML
    try:
        with open(config_file, "r") as f:
            data = yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in config file: {e}") from e

    if data is None:
        raise ValueError("Config file is empty")

    # Validate and create Config object
    try:
        config = Config(**data)
    except Exception as e:
        raise ValueError(f"Configuration validation failed: {e}") from e

    return config


def generate_default_config(project_dir: Path) -> Config:
    """Generate default configuration for a project.

    Args:
        project_dir: Path to project root directory

    Returns:
        Config object with default values
    """
    project_name = project_dir.name

    return Config(
        project=ProjectConfig(
            name=project_name,
            roots=["."],
        ),
        files=FilesConfig(),
        database=DatabaseConfig(),
    )


def get_db_paths(config: Config, cortex_root: Path) -> Tuple[Path, Path]:
    """Resolve database paths from config relative to cortex_root.

    Args:
        config: Config object
        cortex_root: Path to .cortex/ directory

    Returns:
        Tuple of (sqlite_path, lancedb_path) as absolute Path objects
    """
    # Remove .cortex/ prefix if present in paths
    sqlite_path_str = config.database.sqlite_path
    if sqlite_path_str.startswith(".cortex/"):
        sqlite_path_str = sqlite_path_str[len(".cortex/"):]
    elif sqlite_path_str.startswith("./.cortex/"):
        sqlite_path_str = sqlite_path_str[len("./.cortex/"):]

    lancedb_path_str = config.database.lancedb_path
    if lancedb_path_str.startswith(".cortex/"):
        lancedb_path_str = lancedb_path_str[len(".cortex/"):]
    elif lancedb_path_str.startswith("./.cortex/"):
        lancedb_path_str = lancedb_path_str[len("./.cortex/"):]

    sqlite_path = cortex_root / sqlite_path_str
    lancedb_path = cortex_root / lancedb_path_str

    return sqlite_path, lancedb_path
