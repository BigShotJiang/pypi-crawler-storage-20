"""Pydantic models for Cortex configuration schema validation."""

from typing import List
from pydantic import BaseModel, Field


class ProjectConfig(BaseModel):
    """Project metadata configuration."""

    name: str = Field(..., description="Project name")
    roots: List[str] = Field(
        default_factory=lambda: ["."], description="Root directories to watch"
    )


class FilesConfig(BaseModel):
    """File inclusion/exclusion patterns configuration."""

    include: List[str] = Field(
        default_factory=lambda: ["**/*.py", "**/*.ts", "**/*.js"],
        description="File patterns to include",
    )
    exclude: List[str] = Field(
        default_factory=lambda: [
            # Version control
            "**/.git/**",
            # Python
            "**/.venv/**",
            "**/venv/**",
            "**/__pycache__/**",
            "**/.mypy_cache/**",
            "**/.pytest_cache/**",
            "**/.ruff_cache/**",
            "**/dist/**",
            "**/build/**",
            "**/*.egg-info/**",
            # JavaScript/Node
            "**/node_modules/**",
            # Testing/migrations (often noisy)
            "**/tests/**",
            "**/migrations/**",
            # IDE/editor
            "**/.idea/**",
            "**/.vscode/**",
        ],
        description="File patterns to exclude",
    )


class DatabaseConfig(BaseModel):
    """Database paths configuration."""

    sqlite_path: str = Field(
        default=".cortex/cortex.db", description="SQLite database path (relative to .cortex/)"
    )
    lancedb_path: str = Field(
        default=".cortex/lancedb", description="LanceDB directory path (relative to .cortex/)"
    )


class Config(BaseModel):
    """Main Cortex configuration model."""

    project: ProjectConfig = Field(..., description="Project configuration")
    files: FilesConfig = Field(default_factory=FilesConfig, description="File patterns")
    database: DatabaseConfig = Field(
        default_factory=DatabaseConfig, description="Database paths"
    )
