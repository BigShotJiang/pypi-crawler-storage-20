"""Global Cortex configuration management.

Handles user-level configuration stored in ~/.config/cortex/global.yaml,
including PyTorch variant preference and GPU detection.
"""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional, Literal
from dataclasses import dataclass

import yaml


PyTorchVariant = Literal["rocm", "nvidia", "cpu"]


@dataclass
class GlobalConfig:
    """Global Cortex configuration."""
    pytorch_variant: PyTorchVariant
    installed_version: Optional[str] = None


def get_global_config_dir() -> Path:
    """Get the global config directory path."""
    # Use XDG_CONFIG_HOME if set, otherwise ~/.config
    xdg_config = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config:
        base = Path(xdg_config)
    else:
        base = Path.home() / ".config"
    return base / "cortex"


def get_global_config_path() -> Path:
    """Get the global config file path."""
    return get_global_config_dir() / "global.yaml"


def global_config_exists() -> bool:
    """Check if global config exists (indicates first-run completed)."""
    return get_global_config_path().exists()


def load_global_config() -> Optional[GlobalConfig]:
    """Load global config if it exists."""
    config_path = get_global_config_path()
    if not config_path.exists():
        return None

    with open(config_path) as f:
        data = yaml.safe_load(f)

    return GlobalConfig(
        pytorch_variant=data.get("pytorch_variant", "cpu"),
        installed_version=data.get("installed_version"),
    )


def save_global_config(config: GlobalConfig) -> None:
    """Save global config."""
    config_dir = get_global_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    config_path = get_global_config_path()
    data = {
        "pytorch_variant": config.pytorch_variant,
        "installed_version": config.installed_version,
    }

    with open(config_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False)


def detect_gpu() -> tuple[Optional[PyTorchVariant], str]:
    """Detect available GPU and recommend PyTorch variant.

    Returns:
        Tuple of (recommended_variant, description)
    """
    # Check for AMD/ROCm
    rocm_smi = shutil.which("rocm-smi")
    # Also check standard ROCm installation paths
    if not rocm_smi:
        for rocm_path in ["/opt/rocm/bin/rocm-smi", "/opt/rocm-*/bin/rocm-smi"]:
            from glob import glob
            matches = glob(rocm_path)
            if matches:
                rocm_smi = matches[0]
                break
    if rocm_smi:
        try:
            result = subprocess.run(
                [rocm_smi, "--showproductname"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                # Try to extract GPU name
                lines = result.stdout.strip().split("\n")
                gpu_name = "AMD GPU"
                for line in lines:
                    if "GPU" in line or "Radeon" in line or "RX" in line:
                        gpu_name = line.strip()
                        break
                return "rocm", f"AMD ({gpu_name})"
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    # Check for NVIDIA
    nvidia_smi = shutil.which("nvidia-smi")
    if nvidia_smi:
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                gpu_name = result.stdout.strip().split("\n")[0]
                return "nvidia", f"NVIDIA ({gpu_name})"
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

    return "cpu", "No GPU detected"


def get_pytorch_index_url(variant: PyTorchVariant) -> Optional[str]:
    """Get the PyPI index URL for a PyTorch variant.

    Returns:
        Index URL for the variant, or None for default (NVIDIA CUDA from PyPI)
    """
    if variant == "rocm":
        return "https://download.pytorch.org/whl/rocm6.2"
    elif variant == "cpu":
        return "https://download.pytorch.org/whl/cpu"
    else:
        # NVIDIA CUDA is the default on PyPI
        return None


def get_current_version() -> Optional[str]:
    """Get the currently installed version of agentic-cortex."""
    try:
        from importlib.metadata import version
        return version("agentic-cortex")
    except Exception:
        return None
