"""Cortex: Local-first agentic memory architecture for coding agents."""

__version__ = "0.1.0"
