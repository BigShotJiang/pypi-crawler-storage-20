"""Vector store implementation using LanceDB.

This module provides the VectorStore class for storing and searching vector embeddings
anchored to symbol IDs, as specified in the planning document.
"""

import logging
from typing import List
from datetime import datetime
import time

import lancedb

logger = logging.getLogger(__name__)

from cortex.db.lancedb import initialize_lancedb
from cortex.types import VectorRecord


class VectorStore:
    """Vector store for semantic memory with symbol anchoring.

    Stores vector embeddings in LanceDB and anchors them to symbol IDs in SQLite.
    Provides insert and search operations for semantic similarity search.
    """

    def __init__(self, db_path: str = ":memory:", table_name: str = "vector_store"):
        """Initialize the vector store.

        Args:
            db_path: Path to LanceDB database directory. Use ":memory:" for temporary.
            table_name: Name of the LanceDB table to use.
        """
        self._db_path = db_path
        self.table_name = table_name
        self.table = initialize_lancedb(db_path, table_name)

    def insert(self, record: VectorRecord) -> None:
        """Insert a vector record into the store.

        Args:
            record: VectorRecord to insert (vector, text_content, anchor_symbol_id)

        Raises:
            Exception: If insert fails after retries due to commit conflicts
        """
        # Set created_at timestamp if not provided
        created_at = record.created_at
        if created_at is None:
            created_at = datetime.now()

        # Convert VectorRecord to LanceDB format
        # LanceDB expects list of dicts or arrow table
        # Timestamp must be int64 nanoseconds for PyArrow timestamp("ns")
        data = {
            "vector": record.vector,
            "text_content": record.text_content,
            "anchor_symbol_id": record.anchor_symbol_id,
            "created_at": int(created_at.timestamp() * 1e9),  # Convert to int64 nanoseconds
        }

        # Insert into LanceDB table with retry logic for commit conflicts
        # LanceDB can have transient commit conflicts when multiple operations
        # access the table concurrently. Retry with exponential backoff.
        max_retries = 5
        last_error = None
        for attempt in range(max_retries):
            try:
                self.table.add([data])
                return
            except Exception as e:
                last_error = e
                error_msg = str(e).lower()

                # Check if it's a commit conflict error (case-insensitive)
                if (
                    "commit conflict" in error_msg
                    or "concurrent transaction" in error_msg
                    or "overwrite" in error_msg
                ):
                    if attempt < max_retries - 1:
                        # Exponential backoff: 0.1s, 0.2s, 0.4s, 0.8s, 1.6s
                        wait_time = 0.1 * (2**attempt)
                        time.sleep(wait_time)

                        # Re-open table to get fresh connection (might help with conflicts)
                        # IMPORTANT: Only open existing table, never create/overwrite during retries
                        try:
                            # Re-open existing table without calling initialize_lancedb
                            # This avoids any potential create/overwrite operations
                            db_path = getattr(self, "_db_path", None)
                            if db_path and db_path != ":memory:":
                                db = lancedb.connect(str(db_path))
                                self.table = db.open_table(self.table_name)
                            # If in-memory or path invalid, keep existing table
                        except (ValueError, OSError):
                            # Re-open failed (table not found, permission error, etc.)
                            # Continue with existing table reference
                            pass
                        continue

                # If not a commit conflict or out of retries, re-raise
                raise
        # If we exhausted retries, raise the last error
        if last_error:
            raise last_error

    def search(
        self, query_vector: List[float], limit: int = 10, anchor_symbol_id: str | None = None
    ) -> List[VectorRecord]:
        """Search for similar vectors ordered by similarity.

        Args:
            query_vector: Query embedding vector (384 dimensions)
            limit: Maximum number of results to return
            anchor_symbol_id: Optional filter to search only vectors anchored to this symbol ID

        Returns:
            List of VectorRecord objects ordered by similarity (most similar first)
        """
        # Build query
        query = self.table.search(query_vector).limit(limit)

        # Apply anchor filter if provided
        if anchor_symbol_id is not None:
            query = query.where(f"anchor_symbol_id = '{anchor_symbol_id}'")

        # Execute search and convert to Arrow table
        # Use to_arrow() to avoid pandas dependency
        arrow_table = None
        try:
            arrow_table = query.to_arrow()
            # Check if table is empty
            if arrow_table.num_rows == 0:
                return []
        except AttributeError:
            # Fallback to to_pandas() if to_arrow() not available
            # This requires pandas but is a fallback
            try:
                import pandas  # noqa: F401

                results = query.to_pandas()
                records = []
                for _, row in results.iterrows():
                    created_at_ns = row["created_at"]
                    if hasattr(created_at_ns, "value"):  # pandas Timestamp
                        created_at_ns = created_at_ns.value
                    created_at = datetime.fromtimestamp(created_at_ns / 1e9)
                    vector = row["vector"]
                    if hasattr(vector, "tolist"):  # numpy array
                        vector = vector.tolist()
                    record = VectorRecord(
                        vector=vector,
                        text_content=row["text_content"],
                        anchor_symbol_id=row["anchor_symbol_id"],
                        created_at=created_at,
                    )
                    records.append(record)
                return records
            except (ImportError, AttributeError, KeyError) as e:
                # Pandas not available, method missing, or column not found
                # Return empty list as graceful fallback for search operations
                logger.debug("Pandas fallback failed in vector search: %s", e)
                return []
        except (ValueError, OSError, KeyError) as e:
            # Query failed (invalid query, connection error, or missing data)
            # Return empty list as graceful fallback for search operations
            logger.debug("Vector search query failed: %s", e)
            return []

        if arrow_table is None:
            return []

        # Convert Arrow table to VectorRecord objects
        records = []
        for batch in arrow_table.to_batches():
            for i in range(batch.num_rows):
                # Extract values from Arrow batch
                vector_col = batch.column(0)[i]  # vector column
                text_content = batch.column(1)[i].as_py()  # text_content
                anchor_symbol_id = batch.column(2)[i].as_py()  # anchor_symbol_id

                # Timestamp: access .value directly to get nanoseconds as int
                timestamp_scalar = batch.column(3)[i]  # created_at scalar
                created_at_ns = timestamp_scalar.value  # Get nanoseconds as int64

                # Convert vector - Arrow FixedSizeList to Python list
                if hasattr(vector_col, "values"):
                    # FixedSizeList has .values attribute
                    vector = vector_col.values.to_pylist()
                else:
                    # Try to_pylist() first
                    try:
                        vector = vector_col.to_pylist()
                    except AttributeError:
                        # Fallback: convert to Python list manually
                        vector = [float(vector_col[i]) for i in range(len(vector_col))]

                # Convert timestamp from nanoseconds to datetime
                created_at = datetime.fromtimestamp(created_at_ns / 1e9)

                record = VectorRecord(
                    vector=vector,
                    text_content=text_content,
                    anchor_symbol_id=anchor_symbol_id,
                    created_at=created_at,
                )
                records.append(record)

        return records
