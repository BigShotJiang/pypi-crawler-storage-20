"""Embedding generation using all-MiniLM-L6-v2 model.

This module provides 384-dimension vector embeddings using the all-MiniLM-L6-v2
model from sentence-transformers, as specified in the planning document.
"""

from typing import List
from sentence_transformers import SentenceTransformer


# Global model instance - loaded lazily on first use
_model: SentenceTransformer | None = None

# Model name from planning doc: clarifications.md specifies all-MiniLM-L6-v2
MODEL_NAME = "all-MiniLM-L6-v2"


def _get_model() -> SentenceTransformer:
    """Get or initialize the embedding model.

    Returns:
        SentenceTransformer model instance (all-MiniLM-L6-v2)
    """
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    return _model


def generate_embedding(text: str) -> List[float]:
    """Generate a 384-dimension embedding vector for the given text.

    Uses all-MiniLM-L6-v2 model which produces 384-dimension vectors as specified
    in the planning document (clarifications.md line 52).

    Args:
        text: Input text to embed

    Returns:
        List of 384 float values representing the embedding vector

    Note:
        The model is loaded lazily on first call. Subsequent calls reuse the same
        model instance for efficiency.
    """
    model = _get_model()
    # sentence-transformers encode returns numpy array, convert to list of floats
    embedding = model.encode(text, convert_to_numpy=True)
    # Convert to list of floats (384 dimensions)
    return embedding.tolist()
