"""Working Memory store for general context not anchored to code.

This module provides storage for session context, decisions, preferences,
and other working memory that doesn't need to be tied to specific symbols.
"""

import logging
import tempfile
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Union

import lancedb
import pyarrow as pa

from cortex.types import WorkingMemory, MEMORY_CATEGORIES
from cortex.vector.embeddings import generate_embedding

logger = logging.getLogger(__name__)


def initialize_working_memory_table(
    db_path: Union[str, Path, None] = None, table_name: str = "working_memory"
) -> lancedb.table.Table:
    """Initialize a LanceDB table for working memory.

    Creates a table with the following schema:
    - id: TEXT (UUID)
    - category: TEXT ('session', 'decision', 'context', 'task', 'preference', 'hypothesis')
    - content: TEXT
    - vector: 384-dimension float array
    - priority: INT (1-5)
    - tags: LIST[TEXT]
    - linked_symbols: LIST[TEXT] (symbol IDs this memory relates to)
    - created_at: TIMESTAMP
    - expires_at: TIMESTAMP (nullable)

    Args:
        db_path: Path to LanceDB database directory. Use None for in-memory.
        table_name: Name of the table to create or open.

    Returns:
        LanceDB table with schema initialized
    """
    schema = pa.schema(
        [
            pa.field("id", pa.string()),
            pa.field("category", pa.string()),
            pa.field("content", pa.string()),
            pa.field("vector", pa.list_(pa.float32(), 384)),
            pa.field("priority", pa.int32()),
            pa.field("tags", pa.list_(pa.string())),
            pa.field("linked_symbols", pa.list_(pa.string())),
            pa.field("created_at", pa.timestamp("ns")),
            pa.field("expires_at", pa.timestamp("ns")),
        ]
    )

    if db_path is None or db_path == ":memory:":
        temp_dir = tempfile.mkdtemp(prefix="cortex_working_memory_")
        db = lancedb.connect(temp_dir)
    else:
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        db = lancedb.connect(str(db_path))

    try:
        table = db.open_table(table_name)
    except ValueError:
        try:
            table = db.create_table(table_name, schema=schema, mode="create")
        except ValueError:
            table = db.open_table(table_name)

    return table


class WorkingMemoryStore:
    """Store for general working memory not anchored to code symbols.

    Provides storage and retrieval for:
    - Session context (temporary, auto-expires)
    - Decisions (persistent architectural choices)
    - Context (persistent project knowledge)
    - Tasks (work in progress, handoff notes)
    - Preferences (learned user preferences)
    """

    # Default TTL for session memories (24 hours)
    SESSION_TTL_HOURS = 24
    # Default TTL for hypothesis/debugging memories (4 hours)
    HYPOTHESIS_TTL_HOURS = 4

    def __init__(self, db_path: str = ":memory:", table_name: str = "working_memory"):
        """Initialize the working memory store.

        Args:
            db_path: Path to LanceDB database directory.
            table_name: Name of the LanceDB table to use.
        """
        self.table = initialize_working_memory_table(db_path, table_name)
        self.db_path = db_path

    def store(
        self,
        content: str,
        category: str = "context",
        priority: int = 3,
        tags: Optional[List[str]] = None,
        linked_symbols: Optional[List[str]] = None,
        expires_at: Optional[datetime] = None,
    ) -> WorkingMemory:
        """Store a new working memory.

        Args:
            content: The memory content to store
            category: One of 'session', 'decision', 'context', 'task', 'preference', 'hypothesis'
            priority: 1-5, higher values surface first in retrieval
            tags: Optional list of tags for filtering
            linked_symbols: Optional list of symbol IDs this memory relates to
            expires_at: Optional expiration time (auto-set for 'session'/'hypothesis')

        Returns:
            The created WorkingMemory record

        Raises:
            ValueError: If category is not valid
        """
        if category not in MEMORY_CATEGORIES:
            raise ValueError(
                f"Invalid category '{category}'. Must be one of: {list(MEMORY_CATEGORIES.keys())}"
            )

        # Clamp priority to valid range
        priority = max(1, min(5, priority))

        # Auto-set expiration for session and hypothesis memories
        if category == "session" and expires_at is None:
            expires_at = datetime.now() + timedelta(hours=self.SESSION_TTL_HOURS)
        elif category == "hypothesis" and expires_at is None:
            expires_at = datetime.now() + timedelta(hours=self.HYPOTHESIS_TTL_HOURS)

        # Generate embedding
        vector = generate_embedding(content)

        # Create record
        memory_id = str(uuid.uuid4())
        now = datetime.now()

        memory = WorkingMemory(
            id=memory_id,
            category=category,
            content=content,
            vector=vector,
            priority=priority,
            tags=tags or [],
            linked_symbols=linked_symbols or [],
            created_at=now,
            expires_at=expires_at,
        )

        # Insert into LanceDB
        self.table.add(
            [
                {
                    "id": memory.id,
                    "category": memory.category,
                    "content": memory.content,
                    "vector": memory.vector,
                    "priority": memory.priority,
                    "tags": memory.tags or [],
                    "linked_symbols": memory.linked_symbols or [],
                    "created_at": memory.created_at,
                    "expires_at": memory.expires_at,
                }
            ]
        )

        return memory

    def recall(
        self,
        query: str,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        limit: int = 5,
        include_expired: bool = False,
    ) -> List[WorkingMemory]:
        """Recall memories by semantic similarity.

        Args:
            query: Search query for semantic matching
            category: Optional category filter
            tags: Optional tags filter (matches any)
            limit: Maximum number of results
            include_expired: Whether to include expired memories

        Returns:
            List of WorkingMemory records, ordered by relevance
        """
        query_vector = generate_embedding(query)

        # Build search query
        search = self.table.search(query_vector).limit(limit * 2)  # Over-fetch for filtering

        try:
            results = search.to_arrow()
        except Exception:
            return []

        if len(results) == 0:
            return []

        # Convert to Python lists for processing
        ids = results["id"].to_pylist()
        categories_col = results["category"].to_pylist()
        contents = results["content"].to_pylist()
        vectors = results["vector"].to_pylist()
        priorities = results["priority"].to_pylist()
        tags_col = results["tags"].to_pylist()
        linked_symbols_col = results["linked_symbols"].to_pylist() if "linked_symbols" in results.column_names else [[] for _ in ids]
        created_ats = results["created_at"].to_pylist()
        expires_ats = results["expires_at"].to_pylist()

        memories = []
        now = datetime.now()

        for i in range(len(ids)):
            # Filter by expiration
            expires = expires_ats[i]
            if not include_expired and expires is not None:
                if hasattr(expires, "timestamp") and expires < now:
                    continue

            # Filter by category
            if category and categories_col[i] != category:
                continue

            # Filter by tags (match any)
            row_tags = tags_col[i] or []
            if tags and not any(t in row_tags for t in tags):
                continue

            # Convert timestamps
            created_at = created_ats[i]
            if hasattr(created_at, "to_pydatetime"):
                created_at = created_at.to_pydatetime()

            if hasattr(expires, "to_pydatetime"):
                expires = expires.to_pydatetime()

            memory = WorkingMemory(
                id=ids[i],
                category=categories_col[i],
                content=contents[i],
                vector=list(vectors[i]) if vectors[i] else [],
                priority=int(priorities[i]),
                tags=list(row_tags),
                linked_symbols=list(linked_symbols_col[i] or []),
                created_at=created_at,
                expires_at=expires,
            )
            memories.append(memory)

            if len(memories) >= limit:
                break

        # Sort by priority (descending) then by created_at (descending)
        memories.sort(key=lambda m: (-m.priority, -(m.created_at.timestamp() if m.created_at else 0)))

        return memories

    def list_memories(
        self,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        include_expired: bool = False,
    ) -> List[WorkingMemory]:
        """List all memories, optionally filtered.

        Args:
            category: Optional category filter
            tags: Optional tags filter (matches any)
            include_expired: Whether to include expired memories

        Returns:
            List of WorkingMemory records, ordered by priority then recency
        """
        try:
            all_data = self.table.to_arrow()
        except Exception:
            return []

        if len(all_data) == 0:
            return []

        memories = []
        now = datetime.now()

        # Convert to Python for filtering
        ids = all_data["id"].to_pylist()
        categories = all_data["category"].to_pylist()
        contents = all_data["content"].to_pylist()
        vectors = all_data["vector"].to_pylist()
        priorities = all_data["priority"].to_pylist()
        tags_list = all_data["tags"].to_pylist()
        linked_symbols_list = all_data["linked_symbols"].to_pylist() if "linked_symbols" in all_data.column_names else [[] for _ in ids]
        created_ats = all_data["created_at"].to_pylist()
        expires_ats = all_data["expires_at"].to_pylist()

        for i in range(len(ids)):
            # Filter by expiration
            expires = expires_ats[i]
            if not include_expired and expires is not None:
                if hasattr(expires, "timestamp"):
                    if expires < now:
                        continue
                elif expires:
                    continue

            # Filter by category
            if category and categories[i] != category:
                continue

            # Filter by tags
            row_tags = tags_list[i] or []
            if tags and not any(t in row_tags for t in tags):
                continue

            created_at = created_ats[i]
            if hasattr(created_at, "to_pydatetime"):
                created_at = created_at.to_pydatetime()

            memory = WorkingMemory(
                id=ids[i],
                category=categories[i],
                content=contents[i],
                vector=list(vectors[i]) if vectors[i] else [],
                priority=int(priorities[i]),
                tags=list(row_tags),
                linked_symbols=list(linked_symbols_list[i] or []),
                created_at=created_at,
                expires_at=expires,
            )
            memories.append(memory)

        # Sort by priority (descending) then by created_at (descending)
        memories.sort(key=lambda m: (-m.priority, -(m.created_at.timestamp() if m.created_at else 0)))

        return memories

    def forget(self, memory_id: str) -> bool:
        """Remove a specific memory by ID.

        Args:
            memory_id: The UUID of the memory to remove

        Returns:
            True if memory was found and removed, False otherwise
        """
        try:
            # LanceDB delete syntax
            self.table.delete(f"id = '{memory_id}'")
            return True
        except Exception as e:
            logger.warning(f"Failed to delete memory {memory_id}: {e}")
            return False

    def clear_expired(self) -> int:
        """Remove all expired memories.

        Returns:
            Number of memories removed
        """
        now = datetime.now()
        try:
            # Count before
            all_data = self.table.to_arrow()
            before_count = len(all_data)

            # Delete expired
            # Note: LanceDB timestamp comparison can be tricky
            # We'll filter and rebuild to be safe
            self.table.delete(f"expires_at IS NOT NULL")

            # Re-add non-expired ones
            memories_to_keep = []
            for i in range(len(all_data)):
                expires = all_data["expires_at"][i].as_py()
                if expires is None or expires >= now:
                    memories_to_keep.append(
                        {
                            "id": all_data["id"][i].as_py(),
                            "category": all_data["category"][i].as_py(),
                            "content": all_data["content"][i].as_py(),
                            "vector": all_data["vector"][i].as_py(),
                            "priority": all_data["priority"][i].as_py(),
                            "tags": all_data["tags"][i].as_py() or [],
                            "created_at": all_data["created_at"][i].as_py(),
                            "expires_at": expires,
                        }
                    )

            if memories_to_keep:
                self.table.add(memories_to_keep)

            return before_count - len(memories_to_keep)
        except Exception as e:
            logger.warning(f"Failed to clear expired memories: {e}")
            return 0

    def clear_session(self) -> int:
        """Clear all session, task, and hypothesis memories.

        Useful for starting a fresh session while preserving
        decisions, context, and preferences.

        Returns:
            Number of memories removed
        """
        try:
            all_data = self.table.to_arrow()
            before_count = len(all_data)

            # Delete session, task, and hypothesis categories
            self.table.delete("category = 'session' OR category = 'task' OR category = 'hypothesis'")

            after_data = self.table.to_arrow()
            return before_count - len(after_data)
        except Exception as e:
            logger.warning(f"Failed to clear session memories: {e}")
            return 0

    def count(self, category: Optional[str] = None) -> int:
        """Count memories, optionally by category.

        Args:
            category: Optional category to count

        Returns:
            Number of memories
        """
        try:
            if category:
                # Filter by category
                all_data = self.table.to_arrow()
                categories = all_data["category"].to_pylist()
                return sum(1 for c in categories if c == category)
            else:
                return self.table.count_rows()
        except Exception:
            return 0

    def get_memories_for_symbol(
        self,
        symbol_id: str,
        include_expired: bool = False,
    ) -> List[WorkingMemory]:
        """Get all memories linked to a specific symbol.

        Used by explore_symbol to surface relevant decisions/context.

        Args:
            symbol_id: The symbol ID to find memories for
            include_expired: Whether to include expired memories

        Returns:
            List of WorkingMemory records linked to this symbol
        """
        all_memories = self.list_memories(include_expired=include_expired)

        return [
            m for m in all_memories
            if m.linked_symbols and symbol_id in m.linked_symbols
        ]

    def get_startup_context(self, limit: int = 10) -> List[WorkingMemory]:
        """Get high-priority memories for session startup.

        Returns a curated set of memories to restore context:
        - All high-priority (4-5) persistent memories (decisions, context, preferences)
        - Recent task memories (if any)
        - Recent session memories (if any)

        Ordered by priority then recency.

        Args:
            limit: Maximum number of memories to return

        Returns:
            List of WorkingMemory records for startup context
        """
        all_memories = self.list_memories(include_expired=False)

        if not all_memories:
            return []

        # Separate by type
        high_priority = [m for m in all_memories if m.priority >= 4 and m.category in ("decision", "context", "preference")]
        tasks = [m for m in all_memories if m.category == "task"]
        sessions = [m for m in all_memories if m.category == "session"]
        hypotheses = [m for m in all_memories if m.category == "hypothesis"]

        # Build result: high priority first, then recent tasks/sessions/hypotheses
        result = []
        result.extend(high_priority)
        result.extend(tasks[:3])  # Recent tasks
        result.extend(sessions[:2])  # Recent session context
        result.extend(hypotheses[:2])  # Active debugging state

        # Sort by priority then recency
        result.sort(key=lambda m: (-m.priority, -(m.created_at.timestamp() if m.created_at else 0)))

        return result[:limit]

    def persist_to_decision(self, memory_id: str, new_content: Optional[str] = None) -> Optional[WorkingMemory]:
        """Promote a session/task memory to a persistent decision.

        Useful at session end to preserve important insights.

        Args:
            memory_id: The ID of the memory to promote
            new_content: Optional updated content (refines the memory)

        Returns:
            The new decision memory, or None if original not found
        """
        # Find the original memory
        all_memories = self.list_memories(include_expired=True)
        original = None
        for m in all_memories:
            if m.id == memory_id:
                original = m
                break

        if not original:
            return None

        # Create new decision with content from original or updated
        content = new_content if new_content else original.content

        new_memory = self.store(
            content=content,
            category="decision",
            priority=max(original.priority, 4),  # Decisions are at least priority 4
            tags=original.tags,
            linked_symbols=original.linked_symbols,
        )

        # Remove the original
        self.forget(memory_id)

        return new_memory
