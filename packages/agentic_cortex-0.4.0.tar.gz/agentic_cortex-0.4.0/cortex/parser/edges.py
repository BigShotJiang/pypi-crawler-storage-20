"""Edge extraction for building call graphs, import relationships, inheritance, and data flow.

This module extracts edges from the AST:

CALLS edges:
- Same-file function calls: local_func() → file_path::::local_func
- Same-class method calls: self.method() → file_path::ClassName::method

IMPORTS edges:
- import os → file_path IMPORTS os
- from pathlib import Path → file_path IMPORTS pathlib::Path
- from cortex.parser import X → file_path IMPORTS cortex.parser::X

INHERITS edges:
- class Child(Parent) → file_path::::Child INHERITS Parent
- class Child(Base, Mixin) → creates edge for each base class
- Resolves to full symbol ID if parent class is in same file

READS edges:
- Function references module-level constant → func READS CONSTANT
- Only tracks ALL_CAPS constants to reduce noise
- Helps understand configuration dependencies

Future enhancements:
- Import resolution to actual file paths
- Cross-file call resolution using import information
- Cross-file inheritance resolution using import information
"""

from typing import List, Set, Tuple, Optional
from tree_sitter import Node

from cortex.types import Symbol, Edge
from cortex.parser.extraction import get_node_text


def extract_edges(
    root: Node,
    source: str,
    file_path: str,
    symbols: List[Symbol],
) -> List[Edge]:
    """Extract CALLS, IMPORTS, INHERITS, and READS edges from parsed AST.

    Finds function/method calls, import statements, class inheritance,
    and references to module-level constants.

    Args:
        root: Root AST node (module)
        source: Full source code string
        file_path: File path for symbol ID generation
        symbols: List of symbols already extracted from this file

    Returns:
        List of Edge objects representing relationships
    """
    # Build lookup tables for resolution
    # Simple function names in this file
    file_functions: Set[str] = set()
    # Class method names: {class_name: {method_name}}
    class_methods: dict[str, Set[str]] = {}
    # Class names in this file (for inheritance resolution)
    file_classes: Set[str] = set()
    # Module-level constants (ALL_CAPS names)
    file_constants: Set[str] = set()

    for sym in symbols:
        if sym.kind == "function":
            # Extract just the function name from ID
            name = sym.id.split("::")[-1]
            file_functions.add(name)
        elif sym.kind == "method":
            # Extract class name and method name from ID
            # Format: file_path::ClassName::method_name
            parts = sym.id.split("::")
            if len(parts) >= 3:
                class_name = parts[-2]
                method_name = parts[-1]
                if class_name not in class_methods:
                    class_methods[class_name] = set()
                class_methods[class_name].add(method_name)
        elif sym.kind == "class":
            # Extract class name for inheritance resolution
            name = sym.id.split("::")[-1]
            file_classes.add(name)
        elif sym.kind == "constant":
            # Track module-level constants for READS edges
            name = sym.id.split("::")[-1]
            # Only track ALL_CAPS constants (reduce noise)
            if name.isupper():
                file_constants.add(name)

    edges: List[Edge] = []

    # Traverse AST to find all function/method definitions and their calls
    _extract_calls_from_node(
        root, source, file_path, "", None, file_functions, class_methods, edges
    )

    # Extract IMPORTS edges from import statements
    _extract_imports_from_node(root, source, file_path, edges)

    # Extract INHERITS edges from class definitions
    _extract_inherits_from_node(root, source, file_path, file_classes, edges)

    # Extract READS edges for module-level constant references
    if file_constants:
        _extract_reads_from_node(root, source, file_path, file_constants, edges)

    return edges


def _extract_calls_from_node(
    node: Node,
    source: str,
    file_path: str,
    scope_chain: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
    edges: List[Edge],
) -> None:
    """Recursively extract calls from AST nodes.

    Args:
        node: Current AST node
        source: Full source code string
        file_path: File path for symbol IDs
        scope_chain: Current scope chain for caller ID
        current_class: Name of current class (for self.method resolution)
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names
        edges: List to append edges to
    """
    node_type = node.type

    if node_type == "function_definition":
        # Extract function name and update scope
        func_name = _get_identifier_name(node, source)
        if func_name:
            # Determine caller ID based on scope
            if current_class:
                caller_id = f"{file_path}::{current_class}::{func_name}"
            else:
                caller_id = f"{file_path}::::{func_name}"

            # Process function body for calls
            for child in node.children:
                if child.type == "block":
                    _extract_calls_from_block(
                        child,
                        source,
                        file_path,
                        caller_id,
                        current_class,
                        file_functions,
                        class_methods,
                        edges,
                    )
        return  # Don't recurse further - we handled the block

    elif node_type == "class_definition":
        # Extract class name and update context
        class_name = _get_identifier_name(node, source)
        if class_name:
            # Recurse into class body with new context
            for child in node.children:
                if child.type == "block":
                    _extract_calls_from_node(
                        child,
                        source,
                        file_path,
                        scope_chain,
                        class_name,  # Set current class
                        file_functions,
                        class_methods,
                        edges,
                    )
        return

    # Recurse into children
    for child in node.children:
        _extract_calls_from_node(
            child,
            source,
            file_path,
            scope_chain,
            current_class,
            file_functions,
            class_methods,
            edges,
        )


def _extract_calls_from_block(
    block: Node,
    source: str,
    file_path: str,
    caller_id: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
    edges: List[Edge],
) -> None:
    """Extract calls from a function/method block.

    Args:
        block: Block node containing function body
        source: Full source code string
        file_path: File path for symbol IDs
        caller_id: Symbol ID of the calling function/method
        current_class: Current class name (for self.method resolution)
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names
        edges: List to append edges to
    """
    _find_calls_recursive(
        block,
        source,
        file_path,
        caller_id,
        current_class,
        file_functions,
        class_methods,
        edges,
    )


def _find_calls_recursive(
    node: Node,
    source: str,
    file_path: str,
    caller_id: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
    edges: List[Edge],
) -> None:
    """Recursively find call nodes and create edges.

    Args:
        node: Current AST node
        source: Full source code string
        file_path: File path for symbol IDs
        caller_id: Symbol ID of the calling function/method
        current_class: Current class name (for self.method resolution)
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names
        edges: List to append edges to
    """
    if node.type == "call":
        # Found a call - try to resolve it
        target_id = _resolve_call(
            node, source, file_path, current_class, file_functions, class_methods
        )
        if target_id:
            edges.append(Edge(source_id=caller_id, target_id=target_id, type="CALLS"))

    # Recurse into children (but not into nested function definitions)
    for child in node.children:
        if child.type not in ("function_definition", "class_definition"):
            _find_calls_recursive(
                child,
                source,
                file_path,
                caller_id,
                current_class,
                file_functions,
                class_methods,
                edges,
            )


def _resolve_call(
    call_node: Node,
    source: str,
    file_path: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
) -> Optional[str]:
    """Resolve a call node to a target symbol ID.

    Args:
        call_node: Call AST node
        source: Full source code string
        file_path: File path for symbol IDs
        current_class: Current class name
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names

    Returns:
        Target symbol ID if resolvable, None otherwise
    """
    # Get the function part of the call
    func_node = None
    for child in call_node.children:
        if child.type in ("identifier", "attribute"):
            func_node = child
            break

    if func_node is None:
        return None

    if func_node.type == "identifier":
        # Simple function call: func_name()
        func_name = get_node_text(func_node, source)
        if func_name in file_functions:
            return f"{file_path}::::{func_name}"

    elif func_node.type == "attribute":
        # Attribute call: obj.method() or self.method()
        func_text = get_node_text(func_node, source)

        # Check for self.method() pattern
        if func_text.startswith("self.") and current_class:
            method_name = func_text[5:]  # Remove "self."
            # Check if this method exists in current class
            if current_class in class_methods and method_name in class_methods[current_class]:
                return f"{file_path}::{current_class}::{method_name}"

    return None


def _get_identifier_name(node: Node, source: str) -> Optional[str]:
    """Get the identifier name from a function/class definition node."""
    for child in node.children:
        if child.type == "identifier":
            return get_node_text(child, source)
    return None


def _extract_imports_from_node(
    root: Node,
    source: str,
    file_path: str,
    edges: List[Edge],
) -> None:
    """Extract IMPORTS edges from import statements.

    Handles:
    - import os → file_path IMPORTS os
    - from pathlib import Path → file_path IMPORTS pathlib::Path
    - from x.y import z → file_path IMPORTS x.y::z

    Args:
        root: Root AST node (module)
        source: Full source code string
        file_path: File path (source of the import edge)
        edges: List to append edges to
    """
    for child in root.children:
        if child.type == "import_statement":
            # import os, import sys, import foo.bar
            _extract_simple_import(child, source, file_path, edges)
        elif child.type == "import_from_statement":
            # from x import y, from x.y import z, from . import x
            _extract_from_import(child, source, file_path, edges)


def _extract_simple_import(
    node: Node,
    source: str,
    file_path: str,
    edges: List[Edge],
) -> None:
    """Extract edges from 'import x' statements.

    Args:
        node: import_statement node
        source: Full source code string
        file_path: File path (source of the import edge)
        edges: List to append edges to
    """
    for child in node.children:
        if child.type == "dotted_name":
            module_name = get_node_text(child, source)
            edges.append(Edge(
                source_id=file_path,
                target_id=module_name,
                type="IMPORTS",
            ))
        elif child.type == "aliased_import":
            # import foo as bar
            for subchild in child.children:
                if subchild.type == "dotted_name":
                    module_name = get_node_text(subchild, source)
                    edges.append(Edge(
                        source_id=file_path,
                        target_id=module_name,
                        type="IMPORTS",
                    ))
                    break


def _extract_from_import(
    node: Node,
    source: str,
    file_path: str,
    edges: List[Edge],
) -> None:
    """Extract edges from 'from x import y' statements.

    Args:
        node: import_from_statement node
        source: Full source code string
        file_path: File path (source of the import edge)
        edges: List to append edges to
    """
    # Find the module being imported from
    module_name = None
    is_relative = False

    for child in node.children:
        if child.type == "dotted_name" and module_name is None:
            # First dotted_name is the module (for absolute imports)
            module_name = get_node_text(child, source)
        elif child.type == "relative_import":
            # Relative import: from . import x or from ..foo import x
            is_relative = True
            # Extract the module part if present
            for subchild in child.children:
                if subchild.type == "dotted_name":
                    rel_module = get_node_text(subchild, source)
                    # Prefix with dots to indicate relative
                    prefix = get_node_text(child, source)
                    dots = prefix.replace(rel_module, "").strip()
                    module_name = dots + rel_module
                    break
                elif subchild.type == "import_prefix":
                    # Just dots, no module name (from . import x)
                    module_name = get_node_text(subchild, source)

    if module_name is None:
        return

    # Find all imported names
    found_from = False
    for child in node.children:
        if child.type == "import":
            found_from = True
            continue

        if not found_from:
            continue

        # After 'import' keyword, collect all imported names
        if child.type == "dotted_name":
            imported_name = get_node_text(child, source)
            target_id = f"{module_name}::{imported_name}"
            edges.append(Edge(
                source_id=file_path,
                target_id=target_id,
                type="IMPORTS",
            ))
        elif child.type == "aliased_import":
            # from x import y as z
            for subchild in child.children:
                if subchild.type == "dotted_name":
                    imported_name = get_node_text(subchild, source)
                    target_id = f"{module_name}::{imported_name}"
                    edges.append(Edge(
                        source_id=file_path,
                        target_id=target_id,
                        type="IMPORTS",
                    ))
                    break


def _extract_inherits_from_node(
    root: Node,
    source: str,
    file_path: str,
    file_classes: Set[str],
    edges: List[Edge],
) -> None:
    """Extract INHERITS edges from class definitions.

    Handles:
    - class Child(Parent) → Child INHERITS Parent
    - class Child(Base, Mixin) → Child INHERITS Base, Child INHERITS Mixin
    - class Child(module.Parent) → Child INHERITS module.Parent
    - class Child(Generic[T]) → Child INHERITS Generic (strips type params)

    Args:
        root: Root AST node (module)
        source: Full source code string
        file_path: File path for symbol IDs
        file_classes: Set of class names defined in this file (for resolution)
        edges: List to append edges to
    """
    for child in root.children:
        if child.type == "class_definition":
            _extract_class_inheritance(child, source, file_path, file_classes, edges)


def _extract_class_inheritance(
    node: Node,
    source: str,
    file_path: str,
    file_classes: Set[str],
    edges: List[Edge],
) -> None:
    """Extract INHERITS edges from a single class definition.

    Args:
        node: class_definition node
        source: Full source code string
        file_path: File path for symbol IDs
        file_classes: Set of class names defined in this file
        edges: List to append edges to
    """
    # Get the class name
    class_name = None
    argument_list = None

    for child in node.children:
        if child.type == "identifier" and class_name is None:
            class_name = get_node_text(child, source)
        elif child.type == "argument_list":
            argument_list = child

    if class_name is None or argument_list is None:
        return

    # Build source ID for the child class
    # Module-level classes use format: file_path::::ClassName (empty scope chain)
    child_class_id = f"{file_path}::::{class_name}"

    # Extract each base class from the argument list
    for child in argument_list.children:
        base_class_name = _extract_base_class_name(child, source)
        if base_class_name:
            # Try to resolve to a full symbol ID if in same file
            if base_class_name in file_classes:
                target_id = f"{file_path}::::{base_class_name}"
            else:
                # Unresolved - just use the name as-is
                target_id = base_class_name

            edges.append(Edge(
                source_id=child_class_id,
                target_id=target_id,
                type="INHERITS",
            ))


def _extract_base_class_name(node: Node, source: str) -> Optional[str]:
    """Extract the base class name from an argument_list child node.

    Handles:
    - identifier: Parent → "Parent"
    - attribute: module.Parent → "module.Parent"
    - subscript: Generic[T] → "Generic" (strips type params)

    Args:
        node: Child node of argument_list
        source: Full source code string

    Returns:
        Base class name or None if not a valid base class node
    """
    if node.type == "identifier":
        return get_node_text(node, source)

    elif node.type == "attribute":
        # module.ClassName - return full dotted name
        return get_node_text(node, source)

    elif node.type == "subscript":
        # Generic[T] - extract just the base name (first identifier)
        for child in node.children:
            if child.type == "identifier":
                return get_node_text(child, source)

    return None


def _extract_reads_from_node(
    root: Node,
    source: str,
    file_path: str,
    file_constants: Set[str],
    edges: List[Edge],
) -> None:
    """Extract READS edges for module-level constant references.

    Finds functions/methods that reference module-level ALL_CAPS constants
    and creates READS edges to track these dependencies.

    Args:
        root: Root AST node (module)
        source: Full source code string
        file_path: File path for symbol IDs
        file_constants: Set of ALL_CAPS constant names in this file
        edges: List to append edges to
    """
    for child in root.children:
        if child.type == "function_definition":
            # Module-level function
            func_name = _get_identifier_name(child, source)
            if func_name:
                caller_id = f"{file_path}::::{func_name}"
                _find_constant_refs(child, source, file_path, caller_id, file_constants, edges)

        elif child.type == "class_definition":
            # Extract class name for method IDs
            class_name = _get_identifier_name(child, source)
            if class_name:
                # Process methods in the class
                for class_child in child.children:
                    if class_child.type == "block":
                        _extract_reads_from_class(
                            class_child, source, file_path, class_name, file_constants, edges
                        )


def _extract_reads_from_class(
    block: Node,
    source: str,
    file_path: str,
    class_name: str,
    file_constants: Set[str],
    edges: List[Edge],
) -> None:
    """Extract READS edges from methods in a class.

    Args:
        block: Class block node
        source: Full source code string
        file_path: File path for symbol IDs
        class_name: Name of the containing class
        file_constants: Set of ALL_CAPS constant names
        edges: List to append edges to
    """
    for child in block.children:
        if child.type == "function_definition":
            method_name = _get_identifier_name(child, source)
            if method_name:
                caller_id = f"{file_path}::{class_name}::{method_name}"
                _find_constant_refs(child, source, file_path, caller_id, file_constants, edges)


def _find_constant_refs(
    node: Node,
    source: str,
    file_path: str,
    caller_id: str,
    file_constants: Set[str],
    edges: List[Edge],
    local_names: Optional[Set[str]] = None,
) -> None:
    """Find references to constants in a function/method body.

    Args:
        node: Current AST node
        source: Full source code string
        file_path: File path for symbol IDs
        caller_id: Symbol ID of the containing function/method
        file_constants: Set of ALL_CAPS constant names
        edges: List to append edges to
        local_names: Set of locally defined names (to exclude)
    """
    if local_names is None:
        local_names = set()

    # Track which constants we've already seen (avoid duplicates)
    seen_constants: Set[str] = set()

    def visit(n: Node, locals_set: Set[str]) -> None:
        if n.type == "identifier":
            name = get_node_text(n, source)

            # Skip if it's a local name
            if name in locals_set:
                return

            # Skip if parent indicates this is a definition, not a reference
            parent = n.parent
            if parent:
                # Skip function/class name definitions
                if parent.type in ("function_definition", "class_definition"):
                    return
                # Skip parameter names
                if parent.type in ("parameters", "typed_parameter", "default_parameter"):
                    return
                # Skip if this is the target of an assignment
                if parent.type == "assignment":
                    # Check if this is the left side (first child)
                    for i, child in enumerate(parent.children):
                        if child == n and i == 0:
                            # This is an assignment target - add to locals
                            locals_set.add(name)
                            return
                # Skip for loop variable
                if parent.type == "for_statement":
                    # First identifier child is the loop variable
                    for child in parent.children:
                        if child.type == "identifier" and child == n:
                            locals_set.add(name)
                            return
                        break  # Only check first identifier

            # Check if this references a known constant
            if name in file_constants and name not in seen_constants:
                seen_constants.add(name)
                target_id = f"{file_path}::::{name}"
                edges.append(Edge(
                    source_id=caller_id,
                    target_id=target_id,
                    type="READS",
                ))

        # Don't recurse into nested function definitions
        if n.type == "function_definition":
            return

        for child in n.children:
            visit(child, locals_set)

    # Find the function body (block) and process it
    for child in node.children:
        if child.type == "block":
            visit(child, local_names.copy())
            break
