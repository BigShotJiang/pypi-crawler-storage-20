"""Generic edge extraction using language configuration.

This module provides a config-driven edge extractor that works with any
language that has a proper edge configuration in its YAML file.

The extraction logic is language-agnostic - it uses node type names from
the config to traverse the AST and extract edges.
"""

from typing import List, Set, Dict, Any, Optional
from tree_sitter import Node

from cortex.types import Symbol, Edge
from cortex.parser.extraction import get_node_text


class GenericEdgeExtractor:
    """Config-driven edge extractor for any supported language."""

    def __init__(self, edge_config: Dict[str, Any], language_id: str):
        """Initialize extractor with language-specific edge configuration.

        Args:
            edge_config: Edge extraction config from YAML (the 'edges' section)
            language_id: Language identifier for debugging
        """
        self.config = edge_config
        self.language_id = language_id

        # Extract sub-configs with defaults
        self.imports_config = edge_config.get("imports", {})
        self.calls_config = edge_config.get("calls", {})
        self.inherits_config = edge_config.get("inherits", {})
        self.reads_config = edge_config.get("reads", {})

    def extract_edges(
        self,
        root: Node,
        source: str,
        file_path: str,
        symbols: List[Symbol],
    ) -> List[Edge]:
        """Extract all edge types from parsed AST.

        Args:
            root: Root AST node (module)
            source: Full source code string
            file_path: File path for symbol ID generation
            symbols: List of symbols already extracted from this file

        Returns:
            List of Edge objects representing relationships
        """
        # Build lookup tables from symbols
        file_functions: Set[str] = set()
        class_methods: Dict[str, Set[str]] = {}
        file_classes: Set[str] = set()
        file_constants: Set[str] = set()

        for sym in symbols:
            name = sym.id.split("::")[-1]
            if sym.kind == "function":
                file_functions.add(name)
            elif sym.kind == "method":
                parts = sym.id.split("::")
                if len(parts) >= 3:
                    class_name = parts[-2]
                    method_name = parts[-1]
                    if class_name not in class_methods:
                        class_methods[class_name] = set()
                    class_methods[class_name].add(method_name)
            elif sym.kind == "class":
                file_classes.add(name)
            elif sym.kind == "constant":
                if name.isupper():
                    file_constants.add(name)

        edges: List[Edge] = []

        # Build import mapping for cross-file call resolution
        # Maps imported names to their resolved symbol IDs
        import_mapping: Dict[str, str] = {}

        # Extract each edge type using config
        if self.imports_config:
            self._extract_imports(root, source, file_path, edges, import_mapping)

        if self.calls_config:
            self._extract_calls(
                root, source, file_path, file_functions, class_methods,
                import_mapping, edges
            )

        if self.inherits_config:
            self._extract_inherits(root, source, file_path, file_classes, edges)

        if self.reads_config and file_constants:
            self._extract_reads(root, source, file_path, file_constants, edges)

        return edges

    def _extract_imports(
        self,
        root: Node,
        source: str,
        file_path: str,
        edges: List[Edge],
        import_mapping: Dict[str, str],
    ) -> None:
        """Extract IMPORTS edges using config-defined node types.

        Also populates import_mapping for cross-file call resolution.
        """
        cfg = self.imports_config

        # Handle Python-style imports
        if "simple_import" in cfg:
            simple_cfg = cfg["simple_import"]
            node_type = simple_cfg.get("node_type", "import_statement")
            module_node_type = simple_cfg.get("module_node", "dotted_name")
            aliased_node_type = simple_cfg.get("aliased_node", "aliased_import")

            for child in root.children:
                if child.type == node_type:
                    self._extract_python_simple_import(
                        child, source, file_path, module_node_type, aliased_node_type,
                        edges, import_mapping
                    )

        if "from_import" in cfg:
            from_cfg = cfg["from_import"]
            node_type = from_cfg.get("node_type", "import_from_statement")

            for child in root.children:
                if child.type == node_type:
                    self._extract_python_from_import(
                        child, source, file_path, from_cfg, edges, import_mapping
                    )

        # Handle TypeScript/ES module imports
        if "import_statement" in cfg:
            ts_cfg = cfg["import_statement"]
            node_type = ts_cfg.get("node_type", "import_statement")

            for child in root.children:
                if child.type == node_type:
                    self._extract_ts_import(
                        child, source, file_path, ts_cfg, edges, import_mapping
                    )

    def _extract_python_simple_import(
        self,
        node: Node,
        source: str,
        file_path: str,
        module_node_type: str,
        aliased_node_type: str,
        edges: List[Edge],
        import_mapping: Dict[str, str],
    ) -> None:
        """Extract edges from Python 'import x' statements.

        Also populates import_mapping for cross-file call resolution.
        For 'import foo.bar', maps 'foo' and 'bar' to their module paths.
        For 'import foo.bar as baz', maps 'baz' to 'foo.bar'.
        """
        for child in node.children:
            if child.type == module_node_type:
                module_name = get_node_text(child, source)
                edges.append(Edge(
                    source_id=file_path,
                    target_id=module_name,
                    type="IMPORTS",
                ))
                # Map the top-level name to just that top-level module
                # e.g., 'import os.path' -> 'os' maps to 'os'
                # This way os.path.join() resolves to os.path::join, not os.path.path::join
                top_name = module_name.split(".")[0]
                import_mapping[top_name] = top_name

            elif child.type == aliased_node_type:
                alias_name = None
                module_name = None
                for subchild in child.children:
                    if subchild.type == module_node_type:
                        module_name = get_node_text(subchild, source)
                    elif subchild.type == "identifier":
                        # This is the alias (the 'as X' part)
                        alias_name = get_node_text(subchild, source)

                if module_name:
                    edges.append(Edge(
                        source_id=file_path,
                        target_id=module_name,
                        type="IMPORTS",
                    ))
                    # Map alias to module, or top-level name if no alias
                    if alias_name:
                        import_mapping[alias_name] = module_name
                    else:
                        top_name = module_name.split(".")[0]
                        import_mapping[top_name] = module_name

    def _extract_python_from_import(
        self,
        node: Node,
        source: str,
        file_path: str,
        cfg: Dict[str, str],
        edges: List[Edge],
        import_mapping: Dict[str, str],
    ) -> None:
        """Extract edges from Python 'from x import y' statements.

        Also populates import_mapping for cross-file call resolution.
        For 'from foo import bar', maps 'bar' to 'foo::bar'.
        For 'from foo import bar as baz', maps 'baz' to 'foo::bar'.
        """
        module_node_type = cfg.get("module_node", "dotted_name")
        relative_node_type = cfg.get("relative_node", "relative_import")
        aliased_node_type = cfg.get("aliased_node", "aliased_import")

        module_name = None

        for child in node.children:
            if child.type == module_node_type and module_name is None:
                module_name = get_node_text(child, source)
            elif child.type == relative_node_type:
                for subchild in child.children:
                    if subchild.type == module_node_type:
                        rel_module = get_node_text(subchild, source)
                        prefix = get_node_text(child, source)
                        dots = prefix.replace(rel_module, "").strip()
                        module_name = dots + rel_module
                        break
                    elif subchild.type == cfg.get("import_prefix_node", "import_prefix"):
                        module_name = get_node_text(subchild, source)

        if module_name is None:
            return

        # Collect imported names
        found_import = False
        for child in node.children:
            if child.type == "import":
                found_import = True
                continue

            if not found_import:
                continue

            if child.type == module_node_type:
                imported_name = get_node_text(child, source)
                target = f"{module_name}::{imported_name}"
                edges.append(Edge(
                    source_id=file_path,
                    target_id=target,
                    type="IMPORTS",
                ))
                # Map the imported name to the full target
                import_mapping[imported_name] = target

            elif child.type == aliased_node_type:
                imported_name = None
                alias_name = None
                for subchild in child.children:
                    if subchild.type == module_node_type:
                        imported_name = get_node_text(subchild, source)
                    elif subchild.type == "identifier":
                        alias_name = get_node_text(subchild, source)

                if imported_name:
                    target = f"{module_name}::{imported_name}"
                    edges.append(Edge(
                        source_id=file_path,
                        target_id=target,
                        type="IMPORTS",
                    ))
                    # Map alias (or original name if no alias) to target
                    mapping_name = alias_name if alias_name else imported_name
                    import_mapping[mapping_name] = target

    def _extract_ts_import(
        self,
        node: Node,
        source: str,
        file_path: str,
        cfg: Dict[str, str],
        edges: List[Edge],
        import_mapping: Dict[str, str],
    ) -> None:
        """Extract edges from TypeScript/ES module import statements.

        Also populates import_mapping for cross-file call resolution.
        For 'import { foo } from "./bar"', maps 'foo' to './bar::foo'.
        For 'import foo from "./bar"', maps 'foo' to './bar::foo'.
        """
        module_path_type = cfg.get("module_path_node", "string")
        import_clause_type = cfg.get("import_clause_node", "import_clause")
        named_imports_type = cfg.get("named_imports_node", "named_imports")
        import_specifier_type = cfg.get("import_specifier_node", "import_specifier")
        namespace_import_type = cfg.get("namespace_import_node", "namespace_import")
        identifier_type = cfg.get("identifier_node", "identifier")

        # Find module path
        module_path = None
        for child in node.children:
            if child.type == module_path_type:
                # Extract string content (remove quotes)
                raw = get_node_text(child, source)
                module_path = raw.strip("'\"")
                break

        if not module_path:
            return

        # Find what's being imported
        for child in node.children:
            if child.type == import_clause_type:
                self._extract_ts_import_clause(
                    child, source, file_path, module_path,
                    named_imports_type, import_specifier_type,
                    namespace_import_type, identifier_type, edges,
                    import_mapping
                )

    def _extract_ts_import_clause(
        self,
        node: Node,
        source: str,
        file_path: str,
        module_path: str,
        named_imports_type: str,
        import_specifier_type: str,
        namespace_import_type: str,
        identifier_type: str,
        edges: List[Edge],
        import_mapping: Dict[str, str],
    ) -> None:
        """Extract imported names from TypeScript import clause.

        Also populates import_mapping for cross-file call resolution.
        """
        for child in node.children:
            if child.type == identifier_type:
                # Default import: import foo from 'bar'
                name = get_node_text(child, source)
                target = f"{module_path}::{name}"
                edges.append(Edge(
                    source_id=file_path,
                    target_id=target,
                    type="IMPORTS",
                ))
                import_mapping[name] = target

            elif child.type == named_imports_type:
                # Named imports: import { a, b } from 'bar'
                # Also handles: import { a as b } from 'bar'
                for specifier in child.children:
                    if specifier.type == import_specifier_type:
                        original_name = None
                        alias_name = None
                        for i, id_node in enumerate(specifier.children):
                            if id_node.type == identifier_type:
                                if i == 0:
                                    original_name = get_node_text(id_node, source)
                                else:
                                    alias_name = get_node_text(id_node, source)

                        if original_name:
                            target = f"{module_path}::{original_name}"
                            edges.append(Edge(
                                source_id=file_path,
                                target_id=target,
                                type="IMPORTS",
                            ))
                            # Map alias (or original name) to target
                            mapping_name = alias_name if alias_name else original_name
                            import_mapping[mapping_name] = target

            elif child.type == namespace_import_type:
                # Namespace import: import * as foo from 'bar'
                edges.append(Edge(
                    source_id=file_path,
                    target_id=module_path,
                    type="IMPORTS",
                ))
                # For namespace imports, we could map 'foo' to module_path
                # but we'd need member access resolution (foo.bar -> bar)
                for id_node in child.children:
                    if id_node.type == identifier_type:
                        alias_name = get_node_text(id_node, source)
                        # Map namespace alias to module path (for foo.bar resolution)
                        import_mapping[alias_name] = module_path
                        break

    def _extract_calls(
        self,
        root: Node,
        source: str,
        file_path: str,
        file_functions: Set[str],
        class_methods: Dict[str, Set[str]],
        import_mapping: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Extract CALLS edges using config-defined node types."""
        cfg = self.calls_config

        function_def_type = cfg.get("function_def", "function_definition")
        class_def_type = cfg.get("class_def", "class_definition")
        body_type = cfg.get("body_node", "block")

        self._extract_calls_recursive(
            root, source, file_path, "", None,
            file_functions, class_methods, import_mapping, cfg, edges
        )

    def _extract_calls_recursive(
        self,
        node: Node,
        source: str,
        file_path: str,
        scope_chain: str,
        current_class: Optional[str],
        file_functions: Set[str],
        class_methods: Dict[str, Set[str]],
        import_mapping: Dict[str, str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Recursively extract calls from AST nodes."""
        function_def_type = cfg.get("function_def", "function_definition")
        class_def_type = cfg.get("class_def", "class_definition")
        method_def_type = cfg.get("method_def", function_def_type)
        body_type = cfg.get("body_node", "block")
        identifier_type = cfg.get("identifier_node", "identifier")

        if node.type == function_def_type or node.type == method_def_type:
            func_name = self._get_identifier(node, source, identifier_type)
            # Try property_identifier for TypeScript methods
            if not func_name:
                func_name = self._get_identifier(node, source, "property_identifier")
            if func_name:
                if current_class:
                    caller_id = f"{file_path}::{current_class}::{func_name}"
                else:
                    caller_id = f"{file_path}::::{func_name}"

                for child in node.children:
                    if child.type == body_type:
                        self._find_calls_in_body(
                            child, source, file_path, caller_id, current_class,
                            file_functions, class_methods, import_mapping, cfg, edges
                        )
            return

        elif node.type == class_def_type:
            class_name_type = cfg.get("class_name_node", identifier_type)
            # Try both the specific class name type and generic identifier
            class_name = self._get_identifier(node, source, class_name_type)
            if not class_name:
                class_name = self._get_identifier(node, source, identifier_type)

            if class_name:
                for child in node.children:
                    if child.type in (body_type, "class_body"):
                        self._extract_calls_recursive(
                            child, source, file_path, scope_chain, class_name,
                            file_functions, class_methods, import_mapping, cfg, edges
                        )
            return

        for child in node.children:
            self._extract_calls_recursive(
                child, source, file_path, scope_chain, current_class,
                file_functions, class_methods, import_mapping, cfg, edges
            )

    def _find_calls_in_body(
        self,
        node: Node,
        source: str,
        file_path: str,
        caller_id: str,
        current_class: Optional[str],
        file_functions: Set[str],
        class_methods: Dict[str, Set[str]],
        import_mapping: Dict[str, str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Find call expressions in a function body."""
        call_type = cfg.get("call_node", "call")
        function_def_type = cfg.get("function_def", "function_definition")
        class_def_type = cfg.get("class_def", "class_definition")

        if node.type == call_type:
            target_id = self._resolve_call(
                node, source, file_path, current_class,
                file_functions, class_methods, import_mapping, cfg
            )
            if target_id:
                edges.append(Edge(source_id=caller_id, target_id=target_id, type="CALLS"))

        # Recurse but skip nested definitions
        for child in node.children:
            if child.type not in (function_def_type, class_def_type):
                self._find_calls_in_body(
                    child, source, file_path, caller_id, current_class,
                    file_functions, class_methods, import_mapping, cfg, edges
                )

    def _resolve_call(
        self,
        call_node: Node,
        source: str,
        file_path: str,
        current_class: Optional[str],
        file_functions: Set[str],
        class_methods: Dict[str, Set[str]],
        import_mapping: Dict[str, str],
        cfg: Dict[str, str],
    ) -> Optional[str]:
        """Resolve a call to a target symbol ID.

        Resolution order:
        1. Local functions in same file
        2. self/this methods in current class
        3. Imported functions via import_mapping (cross-file resolution)
        4. Module.function() patterns via import_mapping
        """
        identifier_type = cfg.get("identifier_node", "identifier")
        attribute_type = cfg.get("attribute_node", "attribute")
        member_expr_type = cfg.get("member_expression_node", "member_expression")
        self_ref = cfg.get("self_reference", "self")

        # Get the function part of the call
        func_node = None
        for child in call_node.children:
            if child.type in (identifier_type, attribute_type, member_expr_type):
                func_node = child
                break

        if func_node is None:
            return None

        if func_node.type == identifier_type:
            func_name = get_node_text(func_node, source)
            # 1. Check local functions first
            if func_name in file_functions:
                return f"{file_path}::::{func_name}"
            # 3. Check import mapping for cross-file resolution
            if func_name in import_mapping:
                import_target = import_mapping[func_name]
                return self._import_target_to_symbol_id(import_target)

        elif func_node.type in (attribute_type, member_expr_type):
            func_text = get_node_text(func_node, source)

            # 2. Check for self.method() or this.method() pattern
            if func_text.startswith(f"{self_ref}.") and current_class:
                method_name = func_text[len(self_ref) + 1:]
                if current_class in class_methods and method_name in class_methods[current_class]:
                    return f"{file_path}::{current_class}::{method_name}"

            # 4. Check for module.function() pattern
            # e.g., os.path.join() where 'os' is in import_mapping
            if "." in func_text:
                parts = func_text.split(".")
                module_name = parts[0]
                if module_name in import_mapping:
                    import_target = import_mapping[module_name]
                    # Append the remaining path
                    # e.g., import_mapping["os"] = "os", call is "os.path.join"
                    # -> target is "os.path::join"
                    remaining = ".".join(parts[1:-1])
                    func_name = parts[-1]
                    if remaining:
                        full_target = f"{import_target}.{remaining}::{func_name}"
                    else:
                        full_target = f"{import_target}::{func_name}"
                    return self._import_target_to_symbol_id(full_target)

        return None

    def _import_target_to_symbol_id(self, target: str) -> Optional[str]:
        """Convert an import target to a potential symbol ID.

        Import targets come in forms like:
        - Python: "cortex.core.graph::GraphQuery" -> "cortex/core/graph.py::::GraphQuery"
        - Python: "os.path::join" -> external (return as-is)
        - TypeScript: "./utils::helper" -> "./utils::::helper" (relative path)
        - TypeScript: "@scope/pkg::func" -> external (return as-is)

        Returns the target as-is if it can't be converted to a file path.
        """
        if "::" not in target:
            # Module-level import (e.g., "import os"), not a specific symbol
            return None

        module_part, symbol_name = target.rsplit("::", 1)

        # Handle relative imports (Python and TypeScript)
        if module_part.startswith("."):
            # Relative import - leave as symbolic reference
            # Resolution to actual file path requires knowing the source file's location
            return f"{module_part}::::{symbol_name}"

        # Handle Python dot-notation modules
        if "." in module_part and not module_part.startswith("@"):
            # Convert dot notation to file path
            # cortex.core.graph -> cortex/core/graph.py
            file_path = module_part.replace(".", "/") + ".py"
            return f"{file_path}::::{symbol_name}"

        # External package or simple module name - return as symbolic reference
        # This allows impact_analysis to still find the reference even if
        # we can't resolve it to a file in the project
        return target

    def _extract_inherits(
        self,
        root: Node,
        source: str,
        file_path: str,
        file_classes: Set[str],
        edges: List[Edge],
    ) -> None:
        """Extract INHERITS edges using config-defined node types."""
        cfg = self.inherits_config
        class_def_type = cfg.get("class_def", "class_definition")

        for child in root.children:
            if child.type == class_def_type:
                self._extract_class_inheritance(child, source, file_path, file_classes, cfg, edges)

    def _extract_class_inheritance(
        self,
        node: Node,
        source: str,
        file_path: str,
        file_classes: Set[str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Extract INHERITS edges from a class definition."""
        class_name_type = cfg.get("class_name_node", "identifier")
        identifier_type = cfg.get("base_identifier", "identifier")
        bases_type = cfg.get("bases_node", "argument_list")
        heritage_type = cfg.get("heritage_node")  # TypeScript-specific
        extends_type = cfg.get("extends_clause")  # TypeScript-specific

        # Get class name
        class_name = self._get_identifier(node, source, class_name_type)
        if not class_name:
            class_name = self._get_identifier(node, source, "identifier")

        if not class_name:
            return

        child_class_id = f"{file_path}::::{class_name}"

        # Python-style: argument_list contains base classes
        for child in node.children:
            if child.type == bases_type:
                self._extract_bases_from_list(
                    child, source, file_path, child_class_id, file_classes, cfg, edges
                )
            # TypeScript-style: class_heritage contains extends/implements
            elif heritage_type and child.type == heritage_type:
                self._extract_ts_heritage(
                    child, source, file_path, child_class_id, file_classes, cfg, edges
                )

    def _extract_bases_from_list(
        self,
        node: Node,
        source: str,
        file_path: str,
        child_class_id: str,
        file_classes: Set[str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Extract base classes from Python-style argument list."""
        identifier_type = cfg.get("base_identifier", "identifier")
        attribute_type = cfg.get("base_attribute", "attribute")
        subscript_type = cfg.get("base_subscript", "subscript")

        for child in node.children:
            base_name = self._extract_base_name(child, source, identifier_type, attribute_type, subscript_type)
            if base_name:
                if base_name in file_classes:
                    target_id = f"{file_path}::::{base_name}"
                else:
                    target_id = base_name

                edges.append(Edge(
                    source_id=child_class_id,
                    target_id=target_id,
                    type="INHERITS",
                ))

    def _extract_ts_heritage(
        self,
        node: Node,
        source: str,
        file_path: str,
        child_class_id: str,
        file_classes: Set[str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Extract base classes from TypeScript class_heritage."""
        extends_type = cfg.get("extends_clause", "extends_clause")
        identifier_type = cfg.get("base_identifier", "identifier")

        for child in node.children:
            if child.type == extends_type:
                for id_node in child.children:
                    if id_node.type == identifier_type:
                        base_name = get_node_text(id_node, source)
                        if base_name in file_classes:
                            target_id = f"{file_path}::::{base_name}"
                        else:
                            target_id = base_name

                        edges.append(Edge(
                            source_id=child_class_id,
                            target_id=target_id,
                            type="INHERITS",
                        ))

    def _extract_base_name(
        self,
        node: Node,
        source: str,
        identifier_type: str,
        attribute_type: str,
        subscript_type: str,
    ) -> Optional[str]:
        """Extract base class name from various node types."""
        if node.type == identifier_type:
            return get_node_text(node, source)
        elif node.type == attribute_type:
            return get_node_text(node, source)
        elif node.type == subscript_type:
            # Generic[T] - get just the base name
            for child in node.children:
                if child.type == identifier_type:
                    return get_node_text(child, source)
        return None

    def _extract_reads(
        self,
        root: Node,
        source: str,
        file_path: str,
        file_constants: Set[str],
        edges: List[Edge],
    ) -> None:
        """Extract READS edges for constant references."""
        cfg = self.reads_config
        function_def_type = cfg.get("function_def", "function_definition")
        class_def_type = cfg.get("class_def", "class_definition")
        method_def_type = cfg.get("method_def", function_def_type)
        body_type = cfg.get("body_node", "block")
        identifier_type = cfg.get("identifier_node", "identifier")

        for child in root.children:
            if child.type == function_def_type:
                func_name = self._get_identifier(child, source, identifier_type)
                if func_name:
                    caller_id = f"{file_path}::::{func_name}"
                    self._find_constant_refs(
                        child, source, file_path, caller_id, file_constants, cfg, edges
                    )

            elif child.type == class_def_type:
                class_name = self._get_identifier(child, source, identifier_type)
                if class_name:
                    for class_child in child.children:
                        if class_child.type in (body_type, "class_body"):
                            self._extract_reads_from_class(
                                class_child, source, file_path, class_name,
                                file_constants, cfg, edges
                            )

    def _extract_reads_from_class(
        self,
        block: Node,
        source: str,
        file_path: str,
        class_name: str,
        file_constants: Set[str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Extract READS edges from methods in a class."""
        function_def_type = cfg.get("function_def", "function_definition")
        method_def_type = cfg.get("method_def", function_def_type)
        identifier_type = cfg.get("identifier_node", "identifier")

        for child in block.children:
            if child.type in (function_def_type, method_def_type):
                method_name = self._get_identifier(child, source, identifier_type)
                if not method_name:
                    # Try property_identifier for TypeScript
                    method_name = self._get_identifier(child, source, "property_identifier")
                if method_name:
                    caller_id = f"{file_path}::{class_name}::{method_name}"
                    self._find_constant_refs(
                        child, source, file_path, caller_id, file_constants, cfg, edges
                    )

    def _find_constant_refs(
        self,
        node: Node,
        source: str,
        file_path: str,
        caller_id: str,
        file_constants: Set[str],
        cfg: Dict[str, str],
        edges: List[Edge],
    ) -> None:
        """Find references to constants in a function body."""
        body_type = cfg.get("body_node", "block")
        identifier_type = cfg.get("identifier_node", "identifier")
        assignment_type = cfg.get("assignment_node", "assignment")
        params_types = {
            cfg.get("parameters_node", "parameters"),
            cfg.get("typed_parameter_node", "typed_parameter"),
            cfg.get("default_parameter_node", "default_parameter"),
            cfg.get("formal_parameters", "formal_parameters"),
            cfg.get("required_parameter", "required_parameter"),
            cfg.get("optional_parameter", "optional_parameter"),
        }
        function_def_type = cfg.get("function_def", "function_definition")
        class_def_type = cfg.get("class_def", "class_definition")

        seen_constants: Set[str] = set()
        local_names: Set[str] = set()

        def visit(n: Node) -> None:
            if n.type == identifier_type:
                name = get_node_text(n, source)

                if name in local_names:
                    return

                parent = n.parent
                if parent:
                    if parent.type in (function_def_type, class_def_type):
                        return
                    if parent.type in params_types:
                        return
                    # Check for assignment target
                    if parent.type == assignment_type:
                        for i, child in enumerate(parent.children):
                            if child == n and i == 0:
                                local_names.add(name)
                                return
                    # Check for variable declarator (TypeScript)
                    if parent.type == "variable_declarator":
                        for i, child in enumerate(parent.children):
                            if child == n and i == 0:
                                local_names.add(name)
                                return

                if name in file_constants and name not in seen_constants:
                    seen_constants.add(name)
                    target_id = f"{file_path}::::{name}"
                    edges.append(Edge(
                        source_id=caller_id,
                        target_id=target_id,
                        type="READS",
                    ))

            if n.type in (function_def_type, class_def_type):
                return

            for child in n.children:
                visit(child)

        # Find body and process
        for child in node.children:
            if child.type in (body_type, "statement_block"):
                visit(child)
                break

    def _get_identifier(self, node: Node, source: str, identifier_type: str) -> Optional[str]:
        """Get identifier name from a node."""
        for child in node.children:
            if child.type == identifier_type:
                return get_node_text(child, source)
        return None
