"""Shared extraction utilities for Tree-sitter AST traversal.

This module provides common helper functions for extracting symbol information
from Tree-sitter AST nodes, used by both GenericParser and PythonParser.
"""

import hashlib
from typing import Optional

from tree_sitter import Node


def get_node_text(node: Node, source: str) -> str:
    """Extract text content from a Tree-sitter node.

    Uses byte offsets from the node to slice the source string directly.

    Args:
        node: Tree-sitter node
        source: Full source code string

    Returns:
        Text content of the node
    """
    return source[node.start_byte:node.end_byte]


def extract_identifier_name(node: Node, source: str) -> Optional[str]:
    """Extract the identifier name from a function or class definition node.

    Searches for the first child node of type 'identifier' and extracts its text.

    Args:
        node: Tree-sitter node (typically function_definition or class_definition)
        source: Full source code string

    Returns:
        Identifier name string, or None if no identifier found
    """
    for child in node.children:
        if child.type == "identifier":
            return get_node_text(child, source)
    return None


def extract_signature(node: Node, source: str, keyword: str) -> str:
    """Extract signature from a function or class definition.

    Extracts text from the start of the node up to (but not including) the colon.
    Falls back to a simple signature if no colon is found.

    Args:
        node: Tree-sitter node (function_definition or class_definition)
        source: Full source code string
        keyword: Definition keyword ("def" or "class") for fallback

    Returns:
        Signature string (e.g., "def foo(x, y)" or "class Bar(Base)")
    """
    signature_end = None
    for child in node.children:
        if child.type == ":":
            signature_end = child.start_byte
            break

    if signature_end is not None:
        return source[node.start_byte:signature_end].strip()

    # Fallback: construct simple signature
    name = extract_identifier_name(node, source)
    if name:
        return f"{keyword} {name}"
    return ""


def extract_body_text(node: Node, source: str) -> str:
    """Extract the body content from a function or class definition.

    Finds the 'block' child node and extracts its full text content.

    Args:
        node: Tree-sitter node (function_definition or class_definition)
        source: Full source code string

    Returns:
        Body text content, or empty string if no block found
    """
    for child in node.children:
        if child.type == "block":
            return get_node_text(child, source)
    return ""


def extract_docstring(node: Node, source: str) -> Optional[str]:
    """Extract docstring from a function or class definition.

    Looks for the first expression_statement containing a string literal
    in the block body. Handles triple-quoted (\"\"\" and ''') and
    single-quoted strings.

    Args:
        node: Tree-sitter node (function_definition or class_definition)
        source: Full source code string

    Returns:
        Docstring content with quotes stripped, or None if not found
    """
    # Find the block node
    block_node = None
    for child in node.children:
        if child.type == "block":
            block_node = child
            break

    if not block_node:
        return None

    # Look for first expression_statement with string
    for child in block_node.children:
        if child.type == "expression_statement":
            for expr_child in child.children:
                if expr_child.type == "string":
                    docstring_text = get_node_text(expr_child, source).strip()
                    # Strip quotes based on format
                    if docstring_text.startswith('"""') and docstring_text.endswith('"""'):
                        return docstring_text[3:-3].strip()
                    elif docstring_text.startswith("'''") and docstring_text.endswith("'''"):
                        return docstring_text[3:-3].strip()
                    elif docstring_text.startswith('"') and docstring_text.endswith('"'):
                        return docstring_text[1:-1].strip()
                    elif docstring_text.startswith("'") and docstring_text.endswith("'"):
                        return docstring_text[1:-1].strip()
                    return docstring_text
            break  # Only check first expression_statement

    return None


def calculate_checksum(body_text: str) -> str:
    """Calculate SHA-256 checksum of normalized body content.

    Normalizes whitespace by collapsing multiple whitespace to single space
    and stripping each line before hashing.

    Args:
        body_text: Body content string to hash

    Returns:
        Hexadecimal SHA-256 hash string, or empty string if body is empty
    """
    if not body_text:
        return ""

    # Normalize: strip each line, filter empty lines, join with newlines
    lines = body_text.split("\n")
    normalized_lines = [line.strip() for line in lines if line.strip()]
    normalized = "\n".join(normalized_lines)

    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()
