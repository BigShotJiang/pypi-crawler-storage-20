"""Base parser interface for extensible language support.

This module provides the base parser interface that all language-specific
parsers must implement, as specified in the planning document.
"""

from cortex.types import Parser

__all__ = ["Parser"]
