"""LanceDB vector database initialization for Cortex.

This module implements the Tier 3 (Semantic Memory) storage using LanceDB
with 384-dimensional embeddings from all-MiniLM-L6-v2 model.
"""

import tempfile
from pathlib import Path
from typing import Union

import lancedb
import pyarrow as pa


def initialize_lancedb(
    db_path: Union[str, Path, None] = None, table_name: str = "vector_store"
) -> lancedb.table.Table:
    """Initialize a LanceDB table with the Cortex vector schema.

    Creates a table with the following schema:
    - vector: 384-dimension float array (all-MiniLM-L6-v2)
    - text_content: TEXT
    - anchor_symbol_id: TEXT (links to symbols.id)
    - created_at: TIMESTAMP

    Args:
        db_path: Path to LanceDB database directory. Use None for in-memory/temporary.
        table_name: Name of the table to create or open.

    Returns:
        LanceDB table with schema initialized

    Note:
        Schema matches planning doc: SPEC_PART_1.md lines 57-65
        Vector dimensions: 384 (all-MiniLM-L6-v2) from clarifications.md line 52
    """
    # Define schema matching planning doc
    # Vector: 384 dimensions (all-MiniLM-L6-v2)
    # From clarifications.md: "all-MiniLM-L6-v2: The industry standard... outputs 384 dimensions"
    schema = pa.schema(
        [
            pa.field("vector", pa.list_(pa.float32(), 384)),  # 384-dim vector
            pa.field("text_content", pa.string()),  # TEXT
            pa.field("anchor_symbol_id", pa.string()),  # Links to symbols.id
            pa.field("created_at", pa.timestamp("ns")),  # TIMESTAMP
        ]
    )

    # Initialize database
    if db_path is None or db_path == ":memory:":
        # For in-memory, use temporary directory
        temp_dir = tempfile.mkdtemp(prefix="cortex_lancedb_")
        db = lancedb.connect(temp_dir)
    else:
        db_path = Path(db_path)
        db_path.parent.mkdir(parents=True, exist_ok=True)
        db = lancedb.connect(str(db_path))

    # Create table if it doesn't exist, or open existing
    # Use atomic pattern: try to open first (most common case), then create if needed
    # This minimizes race conditions by preferring open over create
    try:
        # Try to open existing table first (most common case, avoids race conditions)
        table = db.open_table(table_name)
    except ValueError:
        # Table doesn't exist (LanceDB raises ValueError: "Table 'X' was not found")
        # Use "create" mode which fails if table exists (prevents overwrite)
        try:
            table = db.create_table(table_name, schema=schema, mode="create")
        except ValueError:
            # Race condition: another process created the table between our open and create.
            # LanceDB raises ValueError: "Table 'X' already exists"
            # This is expected in concurrent scenarios - re-open the now-existing table.
            table = db.open_table(table_name)

    return table
