"""SQLite database schema and initialization for Cortex.

This module implements the Tier 1 (Structural Map) and Tier 2 (Relationship Graph)
storage using SQLite as specified in the planning document.
"""

import sqlite3
from pathlib import Path
from typing import Union


def create_schema(conn: sqlite3.Connection) -> None:
    """Create the SQLite schema for symbols and edges tables.

    Creates the following tables:
    - symbols: Stores code symbols (functions, classes, methods, etc.)
    - edges: Stores relationships between symbols (CALLS, INHERITS, IMPORTS)

    Args:
        conn: SQLite database connection
    """
    cursor = conn.cursor()

    # Create symbols table
    # Schema from planning doc: SPEC_PART_1.md lines 29-45
    # Note: Explicit NOT NULL on PRIMARY KEY so SQLite sets the NOT NULL flag
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS symbols (
            id TEXT NOT NULL PRIMARY KEY,
            file_path TEXT NOT NULL,
            kind TEXT NOT NULL,
            signature TEXT,
            docstring TEXT,
            start_line INTEGER NOT NULL,
            end_line INTEGER NOT NULL,
            checksum TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Create edges table
    # Schema from planning doc: SPEC_PART_1.md lines 47-55
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS edges (
            source_id TEXT NOT NULL,
            target_id TEXT NOT NULL,
            type TEXT NOT NULL,
            weight INTEGER DEFAULT 1,
            PRIMARY KEY (source_id, target_id, type),
            FOREIGN KEY (source_id) REFERENCES symbols(id),
            FOREIGN KEY (target_id) REFERENCES symbols(id)
        )
    """)

    # Create indexes on symbols table
    # From planning doc: cortex_local-first_memory_architecture_e8e50552.plan.md lines 171-172
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_symbols_file_path ON symbols(file_path)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_symbols_kind ON symbols(kind)
    """)

    # Create indexes on edges table
    # From planning doc: cortex_local-first_memory_architecture_e8e50552.plan.md lines 185-187
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id)
    """)
    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(type)
    """)

    # Enable foreign key constraints
    cursor.execute("PRAGMA foreign_keys = ON")

    conn.commit()


def initialize_db(db_path: Union[str, Path], check_same_thread: bool = False) -> sqlite3.Connection:
    """Initialize a SQLite database with the Cortex schema.

    Args:
        db_path: Path to database file (required, no fallbacks).
        check_same_thread: If False, allows the connection to be used from multiple threads.
            Default is True for safety, but set to False if using with file watchers.

    Returns:
        SQLite connection with schema initialized

    Raises:
        ValueError: If db_path is None or empty
    """
    if db_path is None:
        raise ValueError("db_path is required. Use config to get database paths.")
    
    if isinstance(db_path, str) and db_path.strip() == "":
        raise ValueError("db_path cannot be empty. Use config to get database paths.")

    conn = sqlite3.connect(str(db_path), check_same_thread=check_same_thread)
    create_schema(conn)
    return conn
