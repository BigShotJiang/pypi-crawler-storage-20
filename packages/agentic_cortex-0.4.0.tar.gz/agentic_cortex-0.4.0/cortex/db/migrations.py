"""Migration system for database schema updates.

This module provides a migration system for tracking and applying schema changes
to the SQLite and LanceDB databases.
"""

import sqlite3
from typing import List, Callable
from pathlib import Path


class Migration:
    """Represents a single database migration."""

    def __init__(self, version: int, name: str, up: Callable[[sqlite3.Connection], None]):
        """Initialize a migration.

        Args:
            version: Migration version number (sequential)
            name: Human-readable migration name
            up: Function that applies the migration to a connection
        """
        self.version = version
        self.name = name
        self.up = up


class MigrationRunner:
    """Manages and applies database migrations."""

    def __init__(self, conn: sqlite3.Connection):
        """Initialize migration runner.

        Args:
            conn: SQLite database connection
        """
        self.conn = conn
        self._ensure_migrations_table()

    def _ensure_migrations_table(self) -> None:
        """Create migrations tracking table if it doesn't exist."""
        cursor = self.conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.conn.commit()

    def get_current_version(self) -> int:
        """Get the current schema version.

        Returns:
            Current migration version, or 0 if no migrations applied
        """
        cursor = self.conn.cursor()
        cursor.execute("SELECT MAX(version) FROM schema_migrations")
        result = cursor.fetchone()
        return result[0] if result[0] is not None else 0

    def apply_migrations(self, migrations: List[Migration]) -> None:
        """Apply pending migrations.

        Args:
            migrations: List of migrations to apply (in order)
        """
        current_version = self.get_current_version()
        cursor = self.conn.cursor()

        for migration in migrations:
            if migration.version > current_version:
                try:
                    migration.up(self.conn)
                    cursor.execute(
                        "INSERT INTO schema_migrations (version, name) VALUES (?, ?)",
                        (migration.version, migration.name),
                    )
                    self.conn.commit()
                    current_version = migration.version
                except Exception as e:
                    self.conn.rollback()
                    raise RuntimeError(
                        f"Migration {migration.version} ({migration.name}) failed: {e}"
                    ) from e
