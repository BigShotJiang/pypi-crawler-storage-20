"""File system watcher using Watchdog.

This module implements file change detection with debouncing for Cortex.
Detects file creation, modification, and deletion events.
"""

import logging
import threading
import time
from pathlib import Path
from typing import Callable, Optional, Set
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

logger = logging.getLogger(__name__)


class FileWatcher:
    """File system watcher with debouncing.

    Monitors a directory for file changes and calls a callback after
    a debounce period (default 500ms).

    Args:
        watch_dir: Directory path to watch
        callback: Function called with file path (relative to watch_dir) when changes detected
        debounce_ms: Debounce window in milliseconds (default 500)
        file_patterns: Optional set of file extensions to watch (e.g., {'.py', '.ts'})
    """

    def __init__(
        self,
        watch_dir: Path,
        callback: Callable[[str], None],
        debounce_ms: int = 500,
        file_patterns: Optional[Set[str]] = None,
        auto_start: bool = True,
    ):
        self.watch_dir = Path(watch_dir)
        self.callback = callback
        self.debounce_ms = debounce_ms
        self.file_patterns = file_patterns or {".py"}  # Default to Python files

        self.observer: Optional[Observer] = None
        self.pending_files: dict[str, float] = {}  # file_path -> last_change_time
        self.pending_lock = threading.Lock()
        self.debounce_thread: Optional[threading.Thread] = None
        self.running = False

        if auto_start:
            self.start()

    def start(self) -> None:
        """Start watching the directory."""
        if self.observer is not None:
            return  # Already started

        self.running = True
        self.observer = Observer()

        handler = _FileChangeHandler(self)
        self.observer.schedule(handler, str(self.watch_dir), recursive=True)
        self.observer.start()

        # Start debounce thread
        self.debounce_thread = threading.Thread(target=self._debounce_loop, daemon=True)
        self.debounce_thread.start()

        # Small delay to ensure observer is ready
        time.sleep(0.01)

    def stop(self) -> None:
        """Stop watching the directory."""
        self.running = False
        if self.observer:
            self.observer.stop()
            self.observer.join()
            self.observer = None

        # Wait for debounce thread
        if self.debounce_thread:
            self.debounce_thread.join(timeout=1.0)
            self.debounce_thread = None

    def _handle_file_change(self, file_path: Path) -> None:
        """Handle a file change event (called by FileChangeHandler)."""
        # Check if file matches our patterns
        if file_path.suffix not in self.file_patterns:
            return

        # Get relative path
        try:
            relative_path = str(file_path.relative_to(self.watch_dir))
        except ValueError:
            # File is outside watch directory
            return

        # Record the change time
        with self.pending_lock:
            self.pending_files[relative_path] = time.time()

    def _debounce_loop(self) -> None:
        """Debounce loop that processes pending file changes."""
        while self.running:
            time.sleep(0.05)  # Check every 50ms

            current_time = time.time()
            debounce_seconds = self.debounce_ms / 1000.0

            with self.pending_lock:
                # Find files that haven't changed for debounce_ms
                ready_files = []
                for file_path, last_change in list(self.pending_files.items()):
                    if current_time - last_change >= debounce_seconds:
                        ready_files.append(file_path)
                        del self.pending_files[file_path]

            # Call callback for ready files
            for file_path in ready_files:
                try:
                    self.callback(file_path)
                except Exception as e:
                    # Intentionally broad: watcher must continue regardless of callback failures
                    logger.debug(f"Callback error for {file_path}: {e}")
                    pass


class _FileChangeHandler(FileSystemEventHandler):
    """Watchdog event handler that forwards events to FileWatcher."""

    def __init__(self, watcher: FileWatcher):
        self.watcher = watcher

    def on_created(self, event: FileSystemEvent) -> None:
        """Handle file creation."""
        if not event.is_directory:
            self.watcher._handle_file_change(Path(event.src_path))

    def on_modified(self, event: FileSystemEvent) -> None:
        """Handle file modification."""
        if not event.is_directory:
            self.watcher._handle_file_change(Path(event.src_path))

    def on_deleted(self, event: FileSystemEvent) -> None:
        """Handle file deletion."""
        if not event.is_directory:
            self.watcher._handle_file_change(Path(event.src_path))

    def on_moved(self, event: FileSystemEvent) -> None:
        """Handle file move/rename."""
        if not event.is_directory:
            # Handle both old and new paths
            if hasattr(event, "src_path") and event.src_path:
                self.watcher._handle_file_change(Path(event.src_path))
            if hasattr(event, "dest_path") and event.dest_path:
                self.watcher._handle_file_change(Path(event.dest_path))
