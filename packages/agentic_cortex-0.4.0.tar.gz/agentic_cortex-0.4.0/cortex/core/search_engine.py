"""Search engine implementing weighted interleave hybrid search.

This module implements the SearchEngine class with weighted interleave algorithm:
- FTS5 structural search (70% weight)
- Vector semantic search (30% weight)
- Fallback to vector-only if FTS returns 0 results
"""

import sqlite3
from typing import List, Dict, Optional

from cortex.vector.store import VectorStore
from cortex.vector.embeddings import generate_embedding
from cortex.types import VectorRecord


class SearchEngine:
    """Search engine implementing weighted interleave hybrid search.
    
    Combines FTS5 structural search with vector semantic search using
    weighted interleave algorithm (70% FTS, 30% Vector).
    """

    def __init__(self, conn: sqlite3.Connection, store: VectorStore):
        """Initialize search engine with database connections.
        
        Args:
            conn: SQLite database connection
            store: VectorStore instance for semantic search
        """
        self.conn = conn
        self.store = store
        self._ensure_fts5_index()

    def _ensure_fts5_index(self) -> None:
        """Ensure FTS5 index exists (create if needed)."""
        cursor = self.conn.cursor()
        
        # Check if symbol_search table exists
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='symbol_search'"
        )
        if cursor.fetchone():
            return
        
        # Check if symbols table exists (required for content-based FTS5)
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='symbols'"
        )
        if not cursor.fetchone():
            # Symbols table doesn't exist yet, create empty FTS5 table
            cursor.execute("""
                CREATE VIRTUAL TABLE symbol_search USING fts5(
                    id UNINDEXED,
                    signature,
                    docstring
                )
            """)
            self.conn.commit()
            return
        
        # Create FTS5 virtual table (content-based)
        cursor.execute("""
            CREATE VIRTUAL TABLE symbol_search USING fts5(
                id UNINDEXED,
                signature,
                docstring,
                content='symbols',
                content_rowid='rowid'
            )
        """)
        
        # Populate FTS5 index from existing symbols
        cursor.execute("""
            INSERT INTO symbol_search(id, signature, docstring)
            SELECT 
                id,
                COALESCE(signature, '') || ' ' || id,
                COALESCE(docstring, '')
            FROM symbols
        """)
        
        self.conn.commit()

    def _search_fts5(self, query: str, limit: int) -> List[Dict[str, any]]:
        """Search using FTS5 structural search.
        
        Args:
            query: Search query string
            limit: Maximum number of results
            
        Returns:
            List of dictionaries with 'id' and 'rank' (score) keys
        """
        cursor = self.conn.cursor()
        
        # Ensure index exists
        self._ensure_fts5_index()
        
        # FTS5 search query - uses bm25() for scoring
        # Per spec format: "SELECT id, rank FROM symbol_search WHERE symbol_search MATCH {query} ORDER BY rank"
        # Note: bm25() provides ranking (lower = better match)
        query_sql = """
            SELECT 
                id,
                bm25(symbol_search) as rank
            FROM symbol_search
            WHERE symbol_search MATCH ?
            ORDER BY rank
            LIMIT ?
        """
        
        cursor.execute(query_sql, (query, limit))
        rows = cursor.fetchall()
        
        # Convert to list of dictionaries
        results = []
        for row in rows:
            results.append({
                "id": row[0],
                "rank": row[1],  # FTS5 bm25() score (lower = better match)
            })
        
        return results

    def _search_vector(self, query: str, limit: int) -> List[Dict[str, any]]:
        """Search using vector semantic search.
        
        Args:
            query: Search query string
            limit: Maximum number of results
            
        Returns:
            List of dictionaries with 'anchor_symbol_id' and 'score' (similarity) keys
        """
        # Generate embedding for query
        query_vector = generate_embedding(query)
        
        # Search vector store
        results = self.store.search(query_vector, limit=limit)
        
        # Convert VectorRecord objects to dictionaries with similarity scores
        vector_results = []
        for idx, record in enumerate(results):
            # Validate that record is a VectorRecord object
            if not isinstance(record, VectorRecord):
                # Skip invalid records
                continue
                
            # LanceDB returns most similar first
            # Calculate similarity score: higher index = lower similarity
            # Normalize to 0-1 range (1.0 for best match, decreasing)
            similarity_score = 1.0 - (idx / max(len(results), 1))
            
            vector_results.append({
                "anchor_symbol_id": record.anchor_symbol_id,
                "text_content": record.text_content,
                "score": similarity_score,
                "created_at": record.created_at,
            })
        
        return vector_results

    def _normalize_scores(self, results: List[Dict], score_key: str, invert: bool = False) -> List[Dict]:
        """Normalize scores to 0.0-1.0 range.
        
        Args:
            results: List of result dictionaries with scores
            score_key: Key name for the score in each dictionary
            invert: If True, invert scores (for FTS5 where lower rank = better)
            
        Returns:
            List of results with normalized scores in 'normalized_score' key
        """
        if not results:
            return []
        
        # Extract scores
        scores = [r[score_key] for r in results]
        
        # Find min/max
        min_score = min(scores)
        max_score = max(scores)
        score_range = max_score - min_score if max_score != min_score else 1.0
        
        # Normalize to 0-1 range
        normalized_results = []
        for result in results:
            score = result[score_key]
            
            if invert:
                # Invert: lower score = higher normalized (for FTS5 rank)
                normalized = (max_score - score) / score_range if score_range > 0 else 0.5
            else:
                # Direct normalization (for vector similarity)
                normalized = (score - min_score) / score_range if score_range > 0 else 0.5
            
            # Ensure in 0-1 range
            normalized = max(0.0, min(1.0, normalized))
            
            result_copy = result.copy()
            result_copy["normalized_score"] = normalized
            normalized_results.append(result_copy)
        
        return normalized_results

    def search(self, query_string: str, limit: int = 10) -> List[Dict[str, any]]:
        """Main search method implementing weighted interleave algorithm.
        
        Per spec:
        1. FTS5 Query: Run SQL against 'symbol_search' virtual table
        2. Vector Query: Embed query_string and query LanceDB
        3. Normalize scores: Both sources to 0.0-1.0 range
        4. Merge: Combine results, boost if ID appears in both
           Score = (FTS_Score * 0.7) + (Vector_Score * 0.3)
        5. Fallback: If FTS returns 0 results, return Vector results only
        
        Args:
            query_string: Search query string
            limit: Maximum number of results to return
            
        Returns:
            List of dictionaries with search results, ordered by combined score (descending)
            Each result contains: 'id', 'score', 'file_path', 'kind', 'signature', 'docstring', etc.
        """
        # Step 1: FTS5 Query
        fts5_results = self._search_fts5(query_string, limit=limit * 2)
        
        # Step 5: Fallback - if FTS returns 0, return Vector results only
        if len(fts5_results) == 0:
            vector_results = self._search_vector(query_string, limit=limit)
            # Convert vector results to final format
            cursor = self.conn.cursor()
            final_results = []
            
            # Check if symbols table exists
            cursor.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='symbols'"
            )
            symbols_table_exists = cursor.fetchone() is not None
            
            for vr in vector_results:
                symbol_id = vr["anchor_symbol_id"]
                
                if symbols_table_exists:
                    # Get full symbol details from database
                    cursor.execute(
                        "SELECT id, file_path, kind, signature, docstring, start_line, end_line, checksum FROM symbols WHERE id = ?",
                        (symbol_id,),
                    )
                    row = cursor.fetchone()
                    if row:
                        final_results.append({
                            "id": row[0],
                            "file_path": row[1],
                            "kind": row[2],
                            "signature": row[3],
                            "docstring": row[4],
                            "start_line": row[5],
                            "end_line": row[6],
                            "checksum": row[7],
                            "score": vr["score"],  # Use vector score directly
                        })
                else:
                    # Symbols table doesn't exist, return minimal result
                    final_results.append({
                        "id": symbol_id,
                        "anchor_symbol_id": symbol_id,
                        "text_content": vr.get("text_content", ""),
                        "score": vr["score"],
                    })
            return final_results[:limit]
        
        # Step 2: Vector Query
        vector_results = self._search_vector(query_string, limit=limit * 2)
        
        # Step 3: Normalize scores
        # FTS5: lower rank = better, so invert
        fts5_normalized = self._normalize_scores(fts5_results, "rank", invert=True)
        # Vector: higher score = better, so no inversion
        vector_normalized = self._normalize_scores(vector_results, "score", invert=False)
        
        # Step 4: Merge results
        # Build map of symbol_id -> combined result
        combined: Dict[str, Dict[str, any]] = {}
        
        # Check if symbols table exists
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='symbols'"
        )
        symbols_table_exists = cursor.fetchone() is not None

        # Add FTS5 results
        for result in fts5_normalized:
            symbol_id = result["id"]
            
            if symbols_table_exists:
                cursor.execute(
                    "SELECT file_path, kind, signature, docstring, start_line, end_line, checksum FROM symbols WHERE id = ?",
                    (symbol_id,),
                )
                row = cursor.fetchone()
                if row:
                    combined[symbol_id] = {
                        "id": symbol_id,
                        "file_path": row[0],
                        "kind": row[1],
                        "signature": row[2],
                        "docstring": row[3],
                        "start_line": row[4],
                        "end_line": row[5],
                        "checksum": row[6],
                        "fts5_score": result["normalized_score"],
                        "vector_score": 0.0,
                        "score": 0.0,  # Will calculate
                    }
            else:
                # Symbols table doesn't exist, create minimal result
                combined[symbol_id] = {
                    "id": symbol_id,
                    "fts5_score": result["normalized_score"],
                    "vector_score": 0.0,
                    "score": 0.0,  # Will calculate
                }
        
        # Add/update with vector results
        for result in vector_normalized:
            symbol_id = result["anchor_symbol_id"]
            if symbol_id in combined:
                # Boost: symbol appears in both
                combined[symbol_id]["vector_score"] = result["normalized_score"]
            else:
                # New symbol from vector search
                if symbols_table_exists:
                    cursor.execute(
                        "SELECT file_path, kind, signature, docstring, start_line, end_line, checksum FROM symbols WHERE id = ?",
                        (symbol_id,),
                    )
                    row = cursor.fetchone()
                    if row:
                        combined[symbol_id] = {
                            "id": symbol_id,
                            "file_path": row[0],
                            "kind": row[1],
                            "signature": row[2],
                            "docstring": row[3],
                            "start_line": row[4],
                            "end_line": row[5],
                            "checksum": row[6],
                            "fts5_score": 0.0,
                            "vector_score": result["normalized_score"],
                            "score": 0.0,
                        }
                else:
                    # Symbols table doesn't exist, create minimal result
                    combined[symbol_id] = {
                        "id": symbol_id,
                        "anchor_symbol_id": symbol_id,
                        "text_content": result.get("text_content", ""),
                        "fts5_score": 0.0,
                        "vector_score": result["normalized_score"],
                        "score": 0.0,
                    }
        
        # Calculate combined scores: (FTS_Score * 0.7) + (Vector_Score * 0.3)
        for symbol_id, result in combined.items():
            fts5_score = result.get("fts5_score", 0.0)
            vector_score = result.get("vector_score", 0.0)
            result["score"] = (fts5_score * 0.7) + (vector_score * 0.3)
        
        # Sort by combined score (descending)
        final_results = list(combined.values())
        final_results.sort(key=lambda x: x["score"], reverse=True)
        
        return final_results[:limit]
