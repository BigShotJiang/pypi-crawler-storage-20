"""Graph query engine for dependency analysis and context injection.

This module implements the GraphQuery class for:
- Upstream dependency analysis (who calls this function)
- Downstream dependency analysis (what does this function call)
- Symbol neighborhood queries (combined relational context)
- Context injection for semantic anchoring by file
"""

import logging
import sqlite3
from typing import List, Dict, Optional
from pathlib import Path

from cortex.vector.store import VectorStore

logger = logging.getLogger(__name__)


class GraphQuery:
    """Graph query engine for dependency analysis and context injection.

    Provides methods for:
    - Upstream analysis: Find who calls a specific function
    - Downstream analysis: Find what a function calls
    - Neighborhood: Get combined relational context for a symbol
    - File symbols: Get all symbols co-located in a file
    - Context injection: Get relevant memories for symbols in a file
    """

    def __init__(self, conn: sqlite3.Connection):
        """Initialize graph query engine.
        
        Args:
            conn: SQLite database connection
        """
        self.conn = conn

    def get_upstream(self, symbol_id: str, depth: int = 2) -> List[str]:
        """Find upstream callers (who calls this function).
        
        Per spec: Traverses the graph backwards from the target symbol
        to find all symbols that call it, up to the specified depth.
        
        Args:
            symbol_id: Symbol ID to find callers for
            depth: Maximum traversal depth (default: 2 per spec)
            
        Returns:
            List of symbol IDs that call the given symbol (upstream callers)
            
        Note:
            Uses recursive CTE to traverse edges backwards:
            - Base case: edges where target_id = symbol_id (direct callers)
            - Recursive case: edges where target_id matches previous source_id
        """
        cursor = self.conn.cursor()
        
        # Build recursive CTE query per spec
        # Finds upstream callers: edges where target_id matches our symbol
        query = """
            WITH RECURSIVE callers(source_id, target_id, depth) AS (
                -- Base case: direct callers (depth 1)
                SELECT source_id, target_id, 1
                FROM edges
                WHERE target_id = ?
                
                UNION ALL
                
                -- Recursive case: callers of callers
                SELECT e.source_id, e.target_id, c.depth + 1
                FROM edges e
                JOIN callers c ON e.target_id = c.source_id
                WHERE c.depth < ?
            )
            SELECT DISTINCT source_id FROM callers
        """
        
        cursor.execute(query, (symbol_id, depth))
        rows = cursor.fetchall()
        
        # Extract symbol IDs
        caller_ids = [row[0] for row in rows]

        return caller_ids

    def get_downstream(self, symbol_id: str, depth: int = 2) -> List[str]:
        """Find downstream callees (what does this function call).

        Traverses the graph forward from the source symbol to find all
        symbols that it calls, up to the specified depth.

        Args:
            symbol_id: Symbol ID to find callees for
            depth: Maximum traversal depth (default: 2)

        Returns:
            List of symbol IDs that the given symbol calls (downstream callees)
        """
        cursor = self.conn.cursor()

        # Recursive CTE to find downstream callees
        # Edges: source_id CALLS target_id, so we follow source_id -> target_id
        query = """
            WITH RECURSIVE callees(source_id, target_id, depth) AS (
                -- Base case: direct callees (depth 1)
                SELECT source_id, target_id, 1
                FROM edges
                WHERE source_id = ? AND type = 'CALLS'

                UNION ALL

                -- Recursive case: callees of callees
                SELECT e.source_id, e.target_id, c.depth + 1
                FROM edges e
                JOIN callees c ON e.source_id = c.target_id
                WHERE c.depth < ? AND e.type = 'CALLS'
            )
            SELECT DISTINCT target_id FROM callees
        """

        cursor.execute(query, (symbol_id, depth))
        rows = cursor.fetchall()

        return [row[0] for row in rows]

    def get_file_symbols(self, file_path: str) -> List[Dict[str, any]]:
        """Get all symbols in a file (co-location query).

        Returns symbols grouped by kind with their signatures,
        useful for understanding what's defined alongside a symbol.

        Args:
            file_path: File path to get symbols for

        Returns:
            List of dicts with 'id', 'kind', 'signature', 'start_line'
        """
        cursor = self.conn.cursor()

        cursor.execute(
            """
            SELECT id, kind, signature, start_line
            FROM symbols
            WHERE file_path = ?
            ORDER BY start_line
            """,
            (file_path,),
        )

        return [
            {"id": row[0], "kind": row[1], "signature": row[2], "start_line": row[3]}
            for row in cursor.fetchall()
        ]

    def get_neighborhood(
        self, symbol_id: str, include_file_symbols: bool = True
    ) -> Dict[str, any]:
        """Get the relational neighborhood of a symbol.

        Returns a combined view of:
        - Upstream callers (who calls this)
        - Downstream callees (what this calls)
        - Co-located symbols (other symbols in same file)
        - Symbol metadata (kind, signature, file)

        This is the "graph context" that helps understand a symbol's role.

        Args:
            symbol_id: Symbol ID to get neighborhood for
            include_file_symbols: Whether to include co-located symbols

        Returns:
            Dict with 'symbol', 'callers', 'callees', 'file_symbols'
        """
        cursor = self.conn.cursor()

        # Get symbol metadata
        cursor.execute(
            """
            SELECT id, file_path, kind, signature, docstring, start_line, end_line
            FROM symbols
            WHERE id = ?
            """,
            (symbol_id,),
        )
        row = cursor.fetchone()

        if not row:
            return {"error": f"Symbol not found: {symbol_id}"}

        symbol_info = {
            "id": row[0],
            "file_path": row[1],
            "kind": row[2],
            "signature": row[3],
            "docstring": row[4],
            "start_line": row[5],
            "end_line": row[6],
        }

        # Get callers and callees
        callers = self.get_upstream(symbol_id, depth=2)
        callees = self.get_downstream(symbol_id, depth=2)

        result = {
            "symbol": symbol_info,
            "callers": callers,
            "callees": callees,
        }

        # Optionally include co-located symbols
        if include_file_symbols:
            file_symbols = self.get_file_symbols(symbol_info["file_path"])
            # Exclude the symbol itself from co-located list
            result["file_symbols"] = [
                s for s in file_symbols if s["id"] != symbol_id
            ]

        # Include file imports
        result["imports"] = self.get_file_imports(symbol_info["file_path"])

        # Include inheritance info for classes
        if symbol_info["kind"] == "class":
            result["inherits_from"] = self.get_parent_classes(symbol_id)
            result["inherited_by"] = self.get_child_classes(symbol_id.split("::")[-1])

        # Include constant dependencies for functions/methods
        if symbol_info["kind"] in ("function", "method"):
            const_deps = self.get_constant_dependencies(symbol_id)
            if const_deps:
                result["reads_constants"] = const_deps

        # Include readers for constants
        if symbol_info["kind"] == "constant":
            readers = self.get_constant_readers(symbol_id)
            if readers:
                result["read_by"] = readers

        return result

    def get_file_imports(self, file_path: str) -> List[str]:
        """Get all modules/symbols that a file imports.

        Args:
            file_path: File path to get imports for

        Returns:
            List of imported module/symbol identifiers
        """
        cursor = self.conn.cursor()

        cursor.execute(
            """
            SELECT DISTINCT target_id
            FROM edges
            WHERE source_id = ? AND type = 'IMPORTS'
            ORDER BY target_id
            """,
            (file_path,),
        )

        return [row[0] for row in cursor.fetchall()]

    def get_importers(self, module_pattern: str) -> List[str]:
        """Get all files that import a module or symbol.

        Useful for understanding the blast radius of changing a module's API.

        Args:
            module_pattern: Module name or pattern to search for.
                           Supports LIKE patterns (e.g., 'cortex.parser%')

        Returns:
            List of file paths that import the module
        """
        cursor = self.conn.cursor()

        # Use LIKE for pattern matching
        if '%' in module_pattern or '_' in module_pattern:
            cursor.execute(
                """
                SELECT DISTINCT source_id
                FROM edges
                WHERE target_id LIKE ? AND type = 'IMPORTS'
                ORDER BY source_id
                """,
                (module_pattern,),
            )
        else:
            # Exact match or prefix match
            cursor.execute(
                """
                SELECT DISTINCT source_id
                FROM edges
                WHERE (target_id = ? OR target_id LIKE ?) AND type = 'IMPORTS'
                ORDER BY source_id
                """,
                (module_pattern, f"{module_pattern}::%"),
            )

        return [row[0] for row in cursor.fetchall()]

    def get_module_dependencies(self, file_path: str) -> Dict[str, List[str]]:
        """Get a structured view of a file's dependencies.

        Groups imports by:
        - stdlib: Standard library modules
        - internal: Same-project imports (cortex.*)
        - external: Third-party packages

        Args:
            file_path: File path to analyze

        Returns:
            Dict with 'stdlib', 'internal', 'external' lists
        """
        imports = self.get_file_imports(file_path)

        # Known stdlib modules (incomplete but covers common ones)
        stdlib_modules = {
            'os', 'sys', 'pathlib', 'typing', 'dataclasses', 'json', 'yaml',
            'sqlite3', 'hashlib', 'datetime', 'time', 'logging', 'argparse',
            'collections', 'functools', 'itertools', 'contextlib', 're',
            'glob', 'shutil', 'subprocess', 'abc', 'copy', 'enum',
        }

        result = {
            "stdlib": [],
            "internal": [],
            "external": [],
        }

        for imp in imports:
            # Get the top-level module
            top_module = imp.split("::")[0].split(".")[0]

            if top_module in stdlib_modules:
                result["stdlib"].append(imp)
            elif top_module == "cortex" or imp.startswith("."):
                result["internal"].append(imp)
            else:
                result["external"].append(imp)

        return result

    def get_parent_classes(self, symbol_id: str) -> List[str]:
        """Get parent classes that a class inherits from.

        Args:
            symbol_id: Symbol ID of the class (e.g., 'file.py::MyClass')

        Returns:
            List of parent class identifiers (may be full symbol IDs or unresolved names)
        """
        cursor = self.conn.cursor()

        cursor.execute(
            """
            SELECT target_id
            FROM edges
            WHERE source_id = ? AND type = 'INHERITS'
            ORDER BY target_id
            """,
            (symbol_id,),
        )

        return [row[0] for row in cursor.fetchall()]

    def get_child_classes(self, class_pattern: str) -> List[str]:
        """Get classes that inherit from a given class.

        Args:
            class_pattern: Class name or pattern to search for.
                          Supports LIKE patterns (e.g., 'BaseModel')

        Returns:
            List of symbol IDs for classes that inherit from this class
        """
        cursor = self.conn.cursor()

        # Use LIKE for pattern matching
        if '%' in class_pattern or '_' in class_pattern:
            cursor.execute(
                """
                SELECT DISTINCT source_id
                FROM edges
                WHERE target_id LIKE ? AND type = 'INHERITS'
                ORDER BY source_id
                """,
                (class_pattern,),
            )
        else:
            # Match exact name or full symbol ID
            cursor.execute(
                """
                SELECT DISTINCT source_id
                FROM edges
                WHERE (target_id = ? OR target_id LIKE ?) AND type = 'INHERITS'
                ORDER BY source_id
                """,
                (class_pattern, f"%::{class_pattern}"),
            )

        return [row[0] for row in cursor.fetchall()]

    def get_class_hierarchy(self, symbol_id: str, depth: int = 3) -> Dict[str, any]:
        """Get the inheritance hierarchy for a class.

        Returns both parent classes (what this inherits) and child classes
        (what inherits from this).

        Args:
            symbol_id: Symbol ID of the class
            depth: Maximum depth to traverse (default: 3)

        Returns:
            Dict with 'parents' (recursive) and 'children' (direct only)
        """
        # Get direct parents
        parents = self.get_parent_classes(symbol_id)

        # Recursively get grandparents up to depth
        all_parents = list(parents)
        current_level = parents
        for _ in range(depth - 1):
            next_level = []
            for parent in current_level:
                grandparents = self.get_parent_classes(parent)
                for gp in grandparents:
                    if gp not in all_parents:
                        all_parents.append(gp)
                        next_level.append(gp)
            current_level = next_level
            if not current_level:
                break

        # Get direct children (classes that inherit from this)
        # Extract just the class name for matching
        class_name = symbol_id.split("::")[-1]
        children = self.get_child_classes(class_name)

        return {
            "parents": all_parents,
            "children": children,
        }

    def get_constant_readers(self, constant_name: str) -> List[str]:
        """Get functions/methods that read a constant.

        Useful for understanding the impact of changing a constant's value.

        Args:
            constant_name: Name of the constant or full symbol ID

        Returns:
            List of symbol IDs for functions that read this constant
        """
        cursor = self.conn.cursor()

        # Match by name or full ID
        cursor.execute(
            """
            SELECT DISTINCT source_id
            FROM edges
            WHERE (target_id = ? OR target_id LIKE ?) AND type = 'READS'
            ORDER BY source_id
            """,
            (constant_name, f"%::::{constant_name}"),
        )

        return [row[0] for row in cursor.fetchall()]

    def get_constant_dependencies(self, symbol_id: str) -> List[str]:
        """Get constants that a function/method reads.

        Args:
            symbol_id: Symbol ID of the function/method

        Returns:
            List of constant symbol IDs that this function reads
        """
        cursor = self.conn.cursor()

        cursor.execute(
            """
            SELECT target_id
            FROM edges
            WHERE source_id = ? AND type = 'READS'
            ORDER BY target_id
            """,
            (symbol_id,),
        )

        return [row[0] for row in cursor.fetchall()]

    def get_context_memories(
        self, file_path: str, store: VectorStore, limit: int = 3
    ) -> List[Dict[str, any]]:
        """Get context memories (semantic anchoring) for symbols in a file.
        
        Per spec: When opening a file, find relevant "tribal knowledge" by:
        1. Identifying all Symbol IDs in the file
        2. Querying LanceDB for items where 'anchor_symbol_id' matches any of these IDs
        3. Returning top 3 most recent/relevant notes
        
        Args:
            file_path: File path to get context memories for
            store: VectorStore instance
            limit: Maximum number of memories to return (default: 3 per spec)
            
        Returns:
            List of dictionaries with memory content and metadata
            Each dict contains: 'anchor_symbol_id', 'text_content', 'created_at', etc.
        """
        cursor = self.conn.cursor()
        
        # Step 1: Get all Symbol IDs for symbols in the file
        cursor.execute("SELECT id FROM symbols WHERE file_path = ?", (file_path,))
        rows = cursor.fetchall()
        symbol_ids = [row[0] for row in rows]
        
        if not symbol_ids:
            return []
        
        # Step 2: Query LanceDB for memories anchored to any of these symbol IDs
        # Query vector store table directly to find all memories for these symbols
        all_memories = []
        
        try:
            # Get the table from store
            table = store.table
            
            # Query all records and filter by anchor_symbol_id
            # LanceDB supports filtering via .where() or we can use to_arrow() and filter in Python
            try:
                # Get all data from table
                all_data = table.to_arrow()
                
                if len(all_data) > 0:
                    # Convert to Python lists for filtering
                    anchor_ids = all_data["anchor_symbol_id"].to_pylist()
                    text_contents = all_data["text_content"].to_pylist()
                    created_ats_list = all_data["created_at"]
                    
                    # Filter memories that match any of our symbol IDs
                    symbol_ids_set = set(symbol_ids)
                    for idx, anchor_id in enumerate(anchor_ids):
                        if anchor_id in symbol_ids_set:
                            # Extract this memory
                            text_content = text_contents[idx] if idx < len(text_contents) else ""
                            
                            # Handle created_at timestamp
                            created_at = None
                            try:
                                if hasattr(created_ats_list, '__getitem__'):
                                    created_at_val = created_ats_list[idx]
                                    # Convert PyArrow timestamp to datetime if needed
                                    if hasattr(created_at_val, 'as_py'):
                                        created_at = created_at_val.as_py()
                                    elif hasattr(created_at_val, 'value'):
                                        # Nanosecond timestamp
                                        ns = created_at_val.value
                                        from datetime import datetime
                                        created_at = datetime.fromtimestamp(ns / 1e9)
                                    else:
                                        created_at = created_at_val
                            except (AttributeError, TypeError, ValueError):
                                # Timestamp conversion can fail on various data formats
                                pass
                            
                            memory = {
                                "anchor_symbol_id": anchor_id,
                                "text_content": text_content,
                                "created_at": created_at,
                            }
                            all_memories.append(memory)
            except (AttributeError, KeyError, IndexError):
                # Table data access failures - return empty list as fallback
                pass
        except (AttributeError, OSError):
            # Store or table access failures - return empty list as fallback
            pass
        
        # Step 3: Return top limit most recent/relevant notes
        # Sort by created_at (most recent first) if available
        try:
            all_memories.sort(
                key=lambda x: x.get("created_at") or 0,
                reverse=True  # Most recent first
            )
        except (TypeError, ValueError):
            # Sorting can fail on incompatible types - keep original order
            pass
        
        return all_memories[:limit]
