"""Benchmark module for comparing traditional vs Cortex token consumption.

This module defines benchmark scenarios and measures token costs for:
1. Traditional approach: reading full files
2. Cortex approach: skeleton + selective hydration

The benchmark is designed to be run as an MCP tool, providing quantitative
and qualitative comparison of the two approaches.
"""

import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import time

# Token estimation: ~4 characters per token (conservative estimate)
CHARS_PER_TOKEN = 4


def estimate_tokens(text: str) -> int:
    """Estimate token count from text."""
    return len(text) // CHARS_PER_TOKEN


@dataclass
class ScenarioResult:
    """Result of running a single benchmark scenario."""
    name: str
    description: str

    # Traditional approach metrics
    traditional_files_read: list[str] = field(default_factory=list)
    traditional_chars: int = 0
    traditional_tokens: int = 0
    traditional_output: str = ""
    traditional_content: str = ""  # Actual content read (for verification)

    # Cortex approach metrics
    cortex_operations: list[str] = field(default_factory=list)
    cortex_chars: int = 0
    cortex_tokens: int = 0
    cortex_output: str = ""
    cortex_content: str = ""  # Actual content returned (for verification)

    # Timing
    traditional_time_ms: float = 0
    cortex_time_ms: float = 0

    @property
    def token_savings_percent(self) -> float:
        if self.traditional_tokens == 0:
            return 0.0
        return (1 - self.cortex_tokens / self.traditional_tokens) * 100

    @property
    def token_savings_absolute(self) -> int:
        return self.traditional_tokens - self.cortex_tokens


@dataclass
class BenchmarkResult:
    """Complete benchmark result."""
    project_path: str
    scenarios: list[ScenarioResult] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def total_traditional_tokens(self) -> int:
        return sum(s.traditional_tokens for s in self.scenarios)

    @property
    def total_cortex_tokens(self) -> int:
        return sum(s.cortex_tokens for s in self.scenarios)

    @property
    def overall_savings_percent(self) -> float:
        if self.total_traditional_tokens == 0:
            return 0.0
        return (1 - self.total_cortex_tokens / self.total_traditional_tokens) * 100


class Benchmarker:
    """Runs benchmark scenarios comparing traditional vs Cortex approaches."""

    def __init__(self, project_root: Path, conn: sqlite3.Connection):
        self.project_root = project_root
        self.conn = conn

    def run_all_scenarios(self) -> BenchmarkResult:
        """Run all benchmark scenarios."""
        result = BenchmarkResult(project_path=str(self.project_root))

        # Get list of indexed files
        cursor = self.conn.cursor()
        cursor.execute("SELECT DISTINCT file_path FROM symbols ORDER BY file_path")
        indexed_files = [row[0] for row in cursor.fetchall()]

        if not indexed_files:
            result.warnings.append("No indexed files found. Run 'cortex init' first.")
            return result

        # Scenario 1: Understand a single file
        result.scenarios.append(self._scenario_understand_file(indexed_files))

        # Scenario 2: Find a specific function
        result.scenarios.append(self._scenario_find_function())

        # Scenario 3: Explore a module (multiple files)
        result.scenarios.append(self._scenario_explore_module(indexed_files))

        # Scenario 4: Impact analysis (find callers)
        result.scenarios.append(self._scenario_impact_analysis())

        # Scenario 5: Full codebase overview
        result.scenarios.append(self._scenario_codebase_overview(indexed_files))

        return result

    def _read_file(self, file_path: str) -> str:
        """Read a file and return its contents."""
        full_path = self.project_root / file_path
        if full_path.exists():
            return full_path.read_text()
        return ""

    def _get_skeleton(self, file_path: str) -> str:
        """Get skeleton for a file from the database."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT kind, signature, docstring, start_line, end_line
            FROM symbols
            WHERE file_path = ?
            ORDER BY start_line
        """, (file_path,))

        symbols = cursor.fetchall()
        if not symbols:
            return ""

        lines = []
        for kind, signature, docstring, start_line, end_line in symbols:
            if signature:
                lines.append(signature)
            if docstring:
                # Truncate long docstrings
                doc_preview = docstring[:200] + "..." if len(docstring) > 200 else docstring
                lines.append(f'    """{doc_preview}"""')
            lines.append('    ...')
            lines.append('')

        return '\n'.join(lines)

    def _get_symbol_source(self, symbol_id: str) -> str:
        """Get full source for a symbol."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT file_path, start_line, end_line
            FROM symbols
            WHERE id = ?
        """, (symbol_id,))

        row = cursor.fetchone()
        if not row:
            return ""

        file_path, start_line, end_line = row
        full_path = self.project_root / file_path

        if not full_path.exists():
            return ""

        lines = full_path.read_text().split('\n')
        return '\n'.join(lines[start_line - 1:end_line])

    def _scenario_understand_file(self, indexed_files: list[str]) -> ScenarioResult:
        """Scenario: Understand a single file's structure and key functions."""
        # Pick a medium-sized file
        file_sizes = []
        for f in indexed_files[:20]:  # Check first 20
            content = self._read_file(f)
            file_sizes.append((f, len(content)))

        file_sizes.sort(key=lambda x: x[1], reverse=True)
        # Pick something in the middle
        target_file = file_sizes[len(file_sizes) // 2][0] if file_sizes else indexed_files[0]

        result = ScenarioResult(
            name="Understand single file",
            description=f"Understand the structure and key functions in {target_file}",
        )

        # Traditional: read the entire file
        start = time.time()
        full_content = self._read_file(target_file)
        result.traditional_time_ms = (time.time() - start) * 1000
        result.traditional_files_read = [target_file]
        result.traditional_chars = len(full_content)
        result.traditional_tokens = estimate_tokens(full_content)
        result.traditional_output = f"Read full file: {len(full_content)} chars"
        result.traditional_content = full_content  # Capture actual content

        # Cortex: skeleton + hydrate 2 key functions
        start = time.time()
        skeleton = self._get_skeleton(target_file)

        # Get 2 symbols to hydrate
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT id FROM symbols
            WHERE file_path = ? AND kind IN ('function', 'method')
            LIMIT 2
        """, (target_file,))
        symbol_ids = [row[0] for row in cursor.fetchall()]

        hydrated = ""
        for sid in symbol_ids:
            hydrated += self._get_symbol_source(sid) + "\n\n"

        cortex_combined = f"=== SKELETON ===\n{skeleton}\n\n=== HYDRATED SYMBOLS ===\n{hydrated}"

        result.cortex_time_ms = (time.time() - start) * 1000
        result.cortex_operations = [
            f"read_file_skeleton({target_file})",
            *[f"inspect_symbol({sid})" for sid in symbol_ids],
        ]
        result.cortex_chars = len(skeleton) + len(hydrated)
        result.cortex_tokens = estimate_tokens(skeleton + hydrated)
        result.cortex_output = f"Skeleton: {len(skeleton)} chars + Hydrated {len(symbol_ids)} symbols: {len(hydrated)} chars"
        result.cortex_content = cortex_combined  # Capture actual content

        return result

    def _scenario_find_function(self) -> ScenarioResult:
        """Scenario: Find a specific function by name."""
        result = ScenarioResult(
            name="Find specific function",
            description="Find a function by name and understand its implementation",
        )

        # Find a function to search for
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT id, file_path, signature
            FROM symbols
            WHERE kind = 'function'
            LIMIT 1
        """)
        row = cursor.fetchone()

        if not row:
            result.traditional_output = "No functions found"
            result.cortex_output = "No functions found"
            return result

        symbol_id, file_path, signature = row
        func_name = symbol_id.split("::")[-1] if "::" in symbol_id else symbol_id

        # Traditional: would need to grep and read matching files
        # Simulate reading 3 files to find the function
        start = time.time()
        cursor.execute("SELECT DISTINCT file_path FROM symbols LIMIT 3")
        files_to_search = [r[0] for r in cursor.fetchall()]

        total_content = ""
        for f in files_to_search:
            total_content += f"=== {f} ===\n{self._read_file(f)}\n\n"

        result.traditional_time_ms = (time.time() - start) * 1000
        result.traditional_files_read = files_to_search
        result.traditional_chars = len(total_content)
        result.traditional_tokens = estimate_tokens(total_content)
        result.traditional_output = f"Searched {len(files_to_search)} files for '{func_name}'"
        result.traditional_content = total_content  # Capture actual content

        # Cortex: search + hydrate
        start = time.time()
        # Search returns symbol IDs directly (minimal tokens)
        search_result = f"Found: {symbol_id}"

        # Hydrate the specific function
        source = self._get_symbol_source(symbol_id)

        cortex_combined = f"=== SEARCH RESULT ===\n{search_result}\n\n=== HYDRATED SOURCE ===\n{source}"

        result.cortex_time_ms = (time.time() - start) * 1000
        result.cortex_operations = [
            f"search_codebase('{func_name}')",
            f"inspect_symbol({symbol_id})",
        ]
        result.cortex_chars = len(search_result) + len(source)
        result.cortex_tokens = estimate_tokens(search_result + source)
        result.cortex_output = f"Search result: {len(search_result)} chars + Source: {len(source)} chars"
        result.cortex_content = cortex_combined  # Capture actual content

        return result

    def _scenario_explore_module(self, indexed_files: list[str]) -> ScenarioResult:
        """Scenario: Explore a module (multiple related files)."""
        result = ScenarioResult(
            name="Explore module",
            description="Understand a module with multiple files",
        )

        # Find files in a common directory
        dir_counts = {}
        for f in indexed_files:
            dir_path = str(Path(f).parent)
            dir_counts[dir_path] = dir_counts.get(dir_path, 0) + 1

        # Pick directory with 3-5 files
        target_dir = None
        target_files = []
        for d, count in sorted(dir_counts.items(), key=lambda x: x[1], reverse=True):
            if 3 <= count <= 5:
                target_dir = d
                target_files = [f for f in indexed_files if str(Path(f).parent) == d]
                break

        if not target_files:
            target_files = indexed_files[:4]
            target_dir = "multiple directories"

        # Traditional: read all files
        start = time.time()
        total_content = ""
        for f in target_files:
            total_content += f"=== {f} ===\n{self._read_file(f)}\n\n"

        result.traditional_time_ms = (time.time() - start) * 1000
        result.traditional_files_read = target_files
        result.traditional_chars = len(total_content)
        result.traditional_tokens = estimate_tokens(total_content)
        result.traditional_output = f"Read {len(target_files)} files in {target_dir}"
        result.traditional_content = total_content  # Capture actual content

        # Cortex: skeletons + selective hydration
        start = time.time()
        skeletons = ""
        for f in target_files:
            skeletons += f"# {f}\n" + self._get_skeleton(f) + "\n\n"

        # Hydrate 2 key functions across all files
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT id FROM symbols
            WHERE file_path IN ({})
            AND kind IN ('function', 'method', 'class')
            LIMIT 2
        """.format(','.join('?' * len(target_files))), target_files)
        symbol_ids = [row[0] for row in cursor.fetchall()]

        hydrated = ""
        for sid in symbol_ids:
            hydrated += f"=== {sid} ===\n{self._get_symbol_source(sid)}\n\n"

        cortex_combined = f"=== SKELETONS ===\n{skeletons}\n\n=== HYDRATED SYMBOLS ===\n{hydrated}"

        result.cortex_time_ms = (time.time() - start) * 1000
        result.cortex_operations = [
            *[f"read_file_skeleton({f})" for f in target_files],
            *[f"inspect_symbol({sid})" for sid in symbol_ids],
        ]
        result.cortex_chars = len(skeletons) + len(hydrated)
        result.cortex_tokens = estimate_tokens(skeletons + hydrated)
        result.cortex_output = f"Skeletons: {len(skeletons)} chars + Hydrated {len(symbol_ids)} symbols"
        result.cortex_content = cortex_combined  # Capture actual content

        return result

    def _scenario_impact_analysis(self) -> ScenarioResult:
        """Scenario: Find all callers of a function (impact analysis)."""
        result = ScenarioResult(
            name="Impact analysis",
            description="Find all callers of a function before modifying it",
        )

        # Find a function that has edges (callers)
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT e.target_id, s.file_path
            FROM edges e
            JOIN symbols s ON e.target_id = s.id
            WHERE e.type = 'CALLS'
            LIMIT 1
        """)
        row = cursor.fetchone()

        if not row:
            # No call graph data, simulate
            cursor.execute("SELECT id, file_path FROM symbols WHERE kind = 'function' LIMIT 1")
            row = cursor.fetchone()

        if not row:
            result.traditional_output = "No functions found"
            result.cortex_output = "No functions found"
            return result

        target_id, file_path = row

        # Traditional: grep for function name across all files, then read matches
        start = time.time()
        cursor.execute("SELECT DISTINCT file_path FROM symbols")
        all_files = [r[0] for r in cursor.fetchall()]

        # Simulate reading 5 files that might contain calls
        files_to_read = all_files[:5]
        total_content = ""
        for f in files_to_read:
            total_content += f"=== {f} ===\n{self._read_file(f)}\n\n"

        result.traditional_time_ms = (time.time() - start) * 1000
        result.traditional_files_read = files_to_read
        result.traditional_chars = len(total_content)
        result.traditional_tokens = estimate_tokens(total_content)
        result.traditional_output = f"Grep + read {len(files_to_read)} files to find callers"
        result.traditional_content = total_content  # Capture actual content

        # Cortex: impact_analysis returns caller IDs directly
        start = time.time()
        cursor.execute("""
            SELECT source_id FROM edges
            WHERE target_id = ? AND type = 'CALLS'
        """, (target_id,))
        callers = [r[0] for r in cursor.fetchall()]

        # Result is just IDs - minimal tokens
        impact_result = f"Callers of {target_id}:\n" + "\n".join(f"  - {c}" for c in callers) if callers else f"No callers found for {target_id}"

        result.cortex_time_ms = (time.time() - start) * 1000
        result.cortex_operations = [f"impact_analysis({target_id})"]
        result.cortex_chars = len(impact_result)
        result.cortex_tokens = estimate_tokens(impact_result)
        result.cortex_output = f"Impact analysis returned {len(callers)} caller IDs"
        result.cortex_content = impact_result  # Capture actual content

        return result

    def _scenario_codebase_overview(self, indexed_files: list[str]) -> ScenarioResult:
        """Scenario: Get an overview of the entire codebase."""
        result = ScenarioResult(
            name="Codebase overview",
            description="Understand the overall structure of the codebase",
        )

        # Traditional: read all files
        start = time.time()
        total_content = ""
        for f in indexed_files[:20]:  # Cap at 20 files
            total_content += f"=== {f} ===\n{self._read_file(f)}\n\n"

        result.traditional_time_ms = (time.time() - start) * 1000
        result.traditional_files_read = indexed_files[:20]
        result.traditional_chars = len(total_content)
        result.traditional_tokens = estimate_tokens(total_content)
        result.traditional_output = f"Read {min(len(indexed_files), 20)} files"
        result.traditional_content = total_content  # Capture actual content

        # Cortex: all skeletons
        start = time.time()
        skeletons = ""
        for f in indexed_files[:20]:
            skeletons += f"# {f}\n" + self._get_skeleton(f) + "\n\n"

        result.cortex_time_ms = (time.time() - start) * 1000
        result.cortex_operations = [f"read_file_skeleton({f})" for f in indexed_files[:20]]
        result.cortex_chars = len(skeletons)
        result.cortex_tokens = estimate_tokens(skeletons)
        result.cortex_output = f"Read {min(len(indexed_files), 20)} skeletons"
        result.cortex_content = skeletons  # Capture actual content

        return result


def _truncate_content(content: str, max_lines: int = 50, max_chars: int = 3000) -> str:
    """Truncate content for verbose display."""
    if not content:
        return "(empty)"

    lines = content.split('\n')
    if len(lines) > max_lines:
        truncated_lines = lines[:max_lines]
        truncated_lines.append(f"\n... (truncated, {len(lines) - max_lines} more lines)")
        content = '\n'.join(truncated_lines)

    if len(content) > max_chars:
        content = content[:max_chars] + f"\n... (truncated, {len(content) - max_chars} more chars)"

    return content


def format_benchmark_report(result: BenchmarkResult, verbose: bool = False) -> str:
    """Format benchmark result as a readable report.

    Args:
        result: The benchmark result to format
        verbose: If True, include actual content previews for verification
    """
    lines = [
        "=" * 70,
        "CORTEX BENCHMARK REPORT",
        "=" * 70,
        f"Project: {result.project_path}",
        f"Mode: {'VERBOSE (content previews included)' if verbose else 'Summary'}",
        "",
    ]

    if result.warnings:
        lines.append("WARNINGS:")
        for w in result.warnings:
            lines.append(f"  - {w}")
        lines.append("")

    # Summary table
    lines.extend([
        "-" * 70,
        "SCENARIO SUMMARY",
        "-" * 70,
        f"{'Scenario':<30} {'Traditional':>12} {'Cortex':>12} {'Savings':>10}",
        "-" * 70,
    ])

    for s in result.scenarios:
        lines.append(
            f"{s.name:<30} {s.traditional_tokens:>12,} {s.cortex_tokens:>12,} {s.token_savings_percent:>9.1f}%"
        )

    lines.extend([
        "-" * 70,
        f"{'TOTAL':<30} {result.total_traditional_tokens:>12,} {result.total_cortex_tokens:>12,} {result.overall_savings_percent:>9.1f}%",
        "",
    ])

    # Detailed results
    lines.extend([
        "-" * 70,
        "DETAILED RESULTS",
        "-" * 70,
    ])

    for s in result.scenarios:
        lines.extend([
            "",
            f"## {s.name}",
            f"   {s.description}",
            "",
            "   Traditional approach:",
            f"     Files: {', '.join(s.traditional_files_read[:3])}{'...' if len(s.traditional_files_read) > 3 else ''}",
            f"     Tokens: {s.traditional_tokens:,}",
            f"     Output: {s.traditional_output}",
            "",
            "   Cortex approach:",
            f"     Operations: {len(s.cortex_operations)} calls",
            f"     Tokens: {s.cortex_tokens:,}",
            f"     Output: {s.cortex_output}",
            "",
            f"   Savings: {s.token_savings_percent:.1f}% ({s.token_savings_absolute:,} tokens)",
        ])

        # Add content previews in verbose mode
        if verbose:
            lines.extend([
                "",
                "   --- TRADITIONAL CONTENT PREVIEW ---",
                "",
            ])
            # Indent each line of the truncated content
            for line in _truncate_content(s.traditional_content).split('\n'):
                lines.append(f"   {line}")

            lines.extend([
                "",
                "   --- CORTEX CONTENT PREVIEW ---",
                "",
            ])
            for line in _truncate_content(s.cortex_content).split('\n'):
                lines.append(f"   {line}")

    # Qualitative assessment
    lines.extend([
        "",
        "=" * 70,
        "QUALITATIVE ASSESSMENT",
        "=" * 70,
        "",
        "Both approaches provide equivalent information for code understanding tasks.",
        "Cortex achieves this with significantly fewer tokens by:",
        "",
        "1. Skeleton reads: Show structure without implementation details",
        "2. Selective hydration: Load only the specific code needed",
        "3. Impact analysis: Return caller IDs without reading files",
        "4. Search: Find code by intent without scanning all files",
        "",
        f"Overall token reduction: {result.overall_savings_percent:.1f}%",
        "",
    ])

    if verbose:
        lines.extend([
            "=" * 70,
            "VERIFICATION NOTES",
            "=" * 70,
            "",
            "The content previews above allow you to verify that:",
            "1. Traditional approach: Files were actually read (not empty/placeholder)",
            "2. Cortex approach: Skeletons show structure, hydrated code is real",
            "3. Both approaches access the same underlying code",
            "",
            "Compare the content volumes to understand the token savings.",
            "",
        ])

    return '\n'.join(lines)
