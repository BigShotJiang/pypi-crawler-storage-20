"""Symbol inspection and hydration.

This module implements Protocol A (Header List / Anti-Token Churn):
- read_file_skeleton(): Returns skeleton code (signatures + docstrings, no bodies)
- inspect_symbol(): Returns hydrated code (full implementation) for a specific symbol
"""

import sqlite3
from pathlib import Path
from typing import List

from cortex.parser.python import PythonParser
from cortex.skeleton.generator import SkeletonGeneratorImpl
from cortex.symbols.id import parse_symbol_id
from cortex.types import Symbol


def read_file_skeleton(conn: sqlite3.Connection, file_path: str) -> str:
    """Read skeleton code for a file.

    Returns skeleton code with signatures and docstrings preserved,
    but function/method bodies replaced with '...' or 'pass'.

    Args:
        conn: SQLite database connection
        file_path: Relative path to the file

    Returns:
        Skeleton code string

    Note:
        This implements Protocol A from the spec: returns only interfaces
        (signatures + docstrings) without implementation bodies.
    """
    # Query all symbols for this file
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, kind, signature, docstring, start_line, end_line, checksum FROM symbols WHERE file_path = ? ORDER BY start_line",
        (file_path,),
    )
    rows = cursor.fetchall()

    if not rows:
        return ""

    # Convert rows to Symbol objects
    symbols: List[Symbol] = []
    for row in rows:
        symbol_id, kind, signature, docstring, start_line, end_line, checksum = row
        symbol = Symbol(
            id=symbol_id,
            file_path=file_path,
            kind=kind,
            signature=signature,
            docstring=docstring,
            start_line=start_line,
            end_line=end_line,
            checksum=checksum,
        )
        symbols.append(symbol)

    # Read source file
    source = _read_source_file(file_path)
    if not source:
        # If file doesn't exist, reconstruct from symbols (fallback)
        return _reconstruct_skeleton_from_symbols(symbols)

    # Generate skeleton using skeleton generator
    generator = SkeletonGeneratorImpl()
    skeleton = generator.generate(symbols, source)

    return skeleton


def inspect_symbol(conn: sqlite3.Connection, symbol_id: str) -> str:
    """Inspect a symbol and return its hydrated (full) code.

    Returns the complete implementation code for a specific symbol,
    including the full function/method body.

    Args:
        conn: SQLite database connection
        symbol_id: Symbol ID in format {file_path}::{scope_chain}::{symbol_name}

    Returns:
        Full code string for the symbol

    Note:
        This implements Protocol A hydration: returns full body after
        agent decides which symbol to edit based on skeleton.
    """
    # Query symbol from database
    cursor = conn.cursor()
    cursor.execute(
        "SELECT file_path, kind, signature, docstring, start_line, end_line FROM symbols WHERE id = ?",
        (symbol_id,),
    )
    row = cursor.fetchone()

    if not row:
        raise ValueError(f"Symbol not found: {symbol_id}")

    file_path, kind, signature, docstring, start_line, end_line = row

    # Read source file
    source = _read_source_file(file_path)
    if source:
        # Extract lines for this symbol (1-indexed to 0-indexed conversion)
        lines = source.split("\n")
        symbol_lines = lines[start_line - 1 : end_line]
        return "\n".join(symbol_lines)
    else:
        # Fallback: reconstruct from symbol metadata when file not available
        return _reconstruct_code_from_symbol(symbol_id, kind, signature, docstring)


def _read_source_file(file_path: str) -> str | None:
    """Read source file from file system.

    Args:
        file_path: Relative path to the file

    Returns:
        File contents as string, or None if file doesn't exist
    """
    try:
        path = Path(file_path)
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        # File access or encoding failures - return None as documented
        return None


def _reconstruct_skeleton_from_symbols(symbols: List[Symbol]) -> str:
    """Reconstruct skeleton code from symbols when source file is unavailable.

    This is a fallback that creates a minimal skeleton from symbol metadata.

    Args:
        symbols: List of symbols

    Returns:
        Reconstructed skeleton code string
    """
    lines = []
    for symbol in symbols:
        # Add signature
        if symbol.signature:
            lines.append(symbol.signature + ":")
        else:
            # Fallback: construct from symbol ID
            parts = parse_symbol_id(symbol.id)
            if symbol.kind == "function":
                lines.append(f"def {parts['symbol_name']}():")
            elif symbol.kind == "method":
                lines.append(f"def {parts['symbol_name']}(self):")
            elif symbol.kind == "class":
                lines.append(f"class {parts['symbol_name']}:")

        # Add docstring if present
        if symbol.docstring:
            # Format docstring (assume triple quotes)
            lines.append(f'    """{symbol.docstring}"""')

        # Add body placeholder
        if symbol.kind == "class":
            lines.append("    pass")
        else:
            lines.append("    ...")

        # Add blank line between symbols
        lines.append("")

    return "\n".join(lines)


def _reconstruct_code_from_symbol(
    symbol_id: str, kind: str, signature: str | None, docstring: str | None
) -> str:
    """Reconstruct code from symbol metadata when source file is unavailable.

    This is a fallback that creates code from symbol metadata.

    Args:
        symbol_id: Symbol ID
        kind: Symbol kind (function, method, class)
        signature: Function/class signature
        docstring: Docstring if present

    Returns:
        Reconstructed code string
    """
    lines = []

    # Add signature
    if signature:
        lines.append(signature + ":")
    else:
        # Fallback: construct from symbol ID
        parts = parse_symbol_id(symbol_id)
        if kind == "function":
            lines.append(f"def {parts['symbol_name']}():")
        elif kind == "method":
            lines.append(f"def {parts['symbol_name']}(self):")
        elif kind == "class":
            lines.append(f"class {parts['symbol_name']}:")

    # Add docstring if present
    if docstring:
        lines.append(f'    """{docstring}"""')

    # Add body placeholder (for hydrated code, we use pass as placeholder)
    if kind == "class":
        lines.append("    pass")
    else:
        lines.append("    pass  # Implementation")

    return "\n".join(lines)
