"""CLI command for 'cortex start'."""

import fnmatch
import sys
from pathlib import Path

from cortex.config import find_cortex_root, load_config, get_db_paths
from cortex.mcp.server import run_server
from cortex.watcher.monitor import FileWatcher
from cortex.watcher.sync import sync_file
from cortex.parser.registry import LanguageRegistry
from cortex.db import initialize_db


def start_command(project_root: Path) -> None:
    """Start the Cortex MCP server.

    Loads config from .cortex/, initializes file watcher in background thread,
    and starts MCP server in stdio mode.

    Args:
        project_root: Path to project root directory (or any subdirectory)
    """
    # Find .cortex/ directory (walk up tree if needed)
    cortex_dir = None
    try:
        cortex_dir = find_cortex_root(project_root)
    except FileNotFoundError:
        # If not found from provided path, and the provided path is the current working directory
        # (i.e., default "." was used), try to find .cortex/ by walking up from cwd
        # This helps when MCP server runs from a different directory than expected
        # Only do this fallback if project_root resolves to cwd (meaning "." was the default)
        if project_root.resolve() == Path.cwd().resolve():
            # Already tried from cwd, so just raise the error
            raise FileNotFoundError(
                f"Could not find .cortex/ directory starting from {project_root}. "
                f"Run 'cortex init' in your project directory, or run 'cortex start' from the project directory."
            )
        else:
            # Explicit path was provided, so only search from that path
            raise FileNotFoundError(
                f"Could not find .cortex/ directory starting from {project_root}. "
                f"Run 'cortex init' in your project directory."
            )

    # Load config
    config = load_config(cortex_dir)

    # Get database paths from config
    sqlite_path, lancedb_path = get_db_paths(config, cortex_dir)

    # Initialize database connections
    db_conn = initialize_db(str(sqlite_path), check_same_thread=False)
    vector_store_path = str(lancedb_path)

    # Get project root (parent of .cortex/)
    actual_project_root = cortex_dir.parent

    # Initialize language registry (create directory if it doesn't exist)
    languages_dir = cortex_dir / "languages"
    if not languages_dir.exists():
        languages_dir.mkdir(parents=True, exist_ok=True)

    registry = LanguageRegistry(languages_dir)
    try:
        registry.load_languages()
    except ValueError:
        # No language files yet - registry will work but won't parse anything
        pass

    # Create file watcher callback
    def file_change_callback(file_path_str: str) -> None:
        """Handle file change events from watcher."""
        try:
            # Get absolute path
            file_path = actual_project_root / file_path_str

            # Check if file matches include/exclude patterns using fnmatch
            # Convert to relative path from project root for pattern matching
            rel_path_str = file_path_str

            # Check include patterns
            matched_include = False
            for include_pattern in config.files.include:
                if fnmatch.fnmatch(rel_path_str, include_pattern) or fnmatch.fnmatch(
                    str(file_path), include_pattern
                ):
                    matched_include = True
                    break

            if not matched_include:
                return

            # Check exclude patterns
            matched_exclude = False
            for exclude_pattern in config.files.exclude:
                if fnmatch.fnmatch(rel_path_str, exclude_pattern) or fnmatch.fnmatch(
                    str(file_path), exclude_pattern
                ):
                    matched_exclude = True
                    break

            if matched_exclude:
                return

            # Get parser for this file
            parser = registry.get_parser_for_file(file_path_str)
            if parser is None:
                return

            # Read and parse file
            try:
                source = file_path.read_text(encoding="utf-8")
                symbols = parser.parse(source, file_path_str)

                if symbols:
                    sync_file(db_conn, file_path_str, symbols)
            except (OSError, UnicodeDecodeError, ValueError):
                # Skip files that can't be read/parsed
                pass

        except Exception as e:
            # Catch all exceptions to prevent watcher crash - intentionally broad
            import logging

            logging.getLogger(__name__).debug(f"Callback error: {e}")
            pass

    # Extract file extensions from include patterns for watcher
    # This is a heuristic to reduce unnecessary file system events
    # The callback will do full pattern matching anyway
    file_extensions = set()
    for pattern in config.files.include:
        # Extract extension from common patterns like "**/*.py", "*.py", etc.
        if pattern.endswith(".py") or ".py" in pattern:
            file_extensions.add(".py")
        if pattern.endswith(".ts") or ".ts" in pattern:
            file_extensions.add(".ts")
        if pattern.endswith(".tsx") or ".tsx" in pattern:
            file_extensions.add(".tsx")
        if pattern.endswith(".js") or ".js" in pattern:
            file_extensions.add(".js")
        if pattern.endswith(".jsx") or ".jsx" in pattern:
            file_extensions.add(".jsx")

    # Initialize file watcher for each root directory
    watchers = []
    for root_pattern in config.project.roots:
        if root_pattern == ".":
            watch_dir = actual_project_root
        else:
            watch_dir = actual_project_root / root_pattern

        if watch_dir.exists():
            # Create watcher (runs in background thread automatically)
            watcher = FileWatcher(
                watch_dir,
                callback=file_change_callback,
                file_patterns=file_extensions or {".py"},  # Default to Python if no patterns
                auto_start=True,
            )
            watchers.append(watcher)

    # Start MCP server in stdio mode (this blocks until server exits)
    # Note: run_server is now synchronous (FastMCP handles async internally)
    # Check if stdin is available and readable (skip in test environments)
    try:
        # Try to check if stdin is readable
        if sys.stdin and hasattr(sys.stdin, "readable"):
            if sys.stdin.readable():
                # stdin is readable - start server (will block until server exits)
                run_server(db_path=str(sqlite_path), lancedb_path=vector_store_path)
            else:
                # In test environment - initialization complete, but don't start server
                # The test verifies that config was loaded and components initialized
                pass
        else:
            # stdin not available - likely in test environment
            pass
    except (AttributeError, OSError):
        # In test environment where stdin check fails
        pass
