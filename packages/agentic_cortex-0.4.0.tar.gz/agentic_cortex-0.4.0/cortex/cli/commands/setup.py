"""First-run setup and self-update functionality.

Handles:
- First-run GPU detection and PyTorch installation
- Self-update with correct PyTorch variant
"""

import subprocess
import sys
from typing import Optional

from cortex.config.global_config import (
    PyTorchVariant,
    GlobalConfig,
    global_config_exists,
    load_global_config,
    save_global_config,
    detect_gpu,
    get_pytorch_index_url,
    get_current_version,
)


def print_banner(text: str) -> None:
    """Print a banner message."""
    width = max(len(text) + 4, 50)
    print("=" * width)
    print(f"  {text}")
    print("=" * width)


def run_first_time_setup(
    force_variant: Optional[PyTorchVariant] = None,
    non_interactive: bool = False,
) -> GlobalConfig:
    """Run first-time setup flow.

    Args:
        force_variant: If set, skip detection and use this variant
        non_interactive: If True, don't prompt for confirmation

    Returns:
        The created GlobalConfig
    """
    print_banner("Cortex First-Time Setup")
    print()

    if force_variant:
        variant = force_variant
        print(f"Using forced PyTorch variant: {variant}")
    else:
        # Detect GPU
        print("Detecting GPU...", end=" ", flush=True)
        detected_variant, description = detect_gpu()
        print(f"Found: {description}")
        print()

        if detected_variant == "cpu":
            print("No GPU detected. Will use CPU-only PyTorch.")
            print("(Embeddings will be slower but functional)")
            variant = "cpu"
        else:
            variant = detected_variant
            print(f"Recommended: {variant.upper()} PyTorch for GPU-accelerated embeddings")

        print()

        if not non_interactive:
            # Prompt for confirmation
            prompt = f"Install with {variant.upper()} support? [Y/n/cpu/rocm/nvidia]: "
            response = input(prompt).strip().lower()

            if response in ("", "y", "yes"):
                pass  # Keep detected variant
            elif response == "cpu":
                variant = "cpu"
            elif response == "rocm":
                variant = "rocm"
            elif response in ("nvidia", "cuda"):
                variant = "nvidia"
            elif response == "n":
                print("Setup cancelled.")
                sys.exit(1)
            else:
                print(f"Unknown option: {response}")
                sys.exit(1)

    print()

    # Perform installation
    _install_with_variant(variant)

    # Save config
    config = GlobalConfig(
        pytorch_variant=variant,
        installed_version=get_current_version(),
    )
    save_global_config(config)

    print()
    print(f"Setup complete. PyTorch variant: {variant}")
    print()

    return config


def _install_with_variant(variant: PyTorchVariant) -> None:
    """Install/reinstall agentic-cortex with the specified PyTorch variant."""
    print(f"Installing agentic-cortex with {variant.upper()} PyTorch...")
    print()

    index_url = get_pytorch_index_url(variant)

    # Build the uv tool install command
    cmd = ["uv", "tool", "install", "agentic-cortex", "--force"]

    if index_url:
        cmd.extend(["--extra-index-url", index_url])

    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            print()
            print("Warning: Installation may have had issues.")
            print("You can try manually with:")
            print(f"  {' '.join(cmd)}")
    except FileNotFoundError:
        print("Error: 'uv' not found. Please install uv first:")
        print("  curl -LsSf https://astral.sh/uv/install.sh | sh")
        sys.exit(1)


def update_command(
    force_variant: Optional[PyTorchVariant] = None,
) -> None:
    """Update agentic-cortex to the latest version.

    Args:
        force_variant: If set, switch to this PyTorch variant
    """
    config = load_global_config()

    if config is None:
        print("No existing installation found. Running first-time setup...")
        print()
        run_first_time_setup(force_variant=force_variant)
        return

    current_version = get_current_version()
    print(f"Current version: {current_version or 'unknown'}")
    print(f"PyTorch variant: {config.pytorch_variant}")
    print()

    # Determine variant to use
    if force_variant:
        variant = force_variant
        if variant != config.pytorch_variant:
            print(f"Switching PyTorch variant: {config.pytorch_variant} -> {variant}")
    else:
        variant = config.pytorch_variant

    # Perform update
    print("Checking for updates...")
    print()

    index_url = get_pytorch_index_url(variant)

    # Use uv tool upgrade
    cmd = ["uv", "tool", "upgrade", "agentic-cortex"]

    if index_url:
        cmd.extend(["--extra-index-url", index_url])

    try:
        result = subprocess.run(cmd, check=False)
        if result.returncode != 0:
            # upgrade might fail if not installed as tool, try install --force
            print("Trying reinstall...")
            _install_with_variant(variant)
    except FileNotFoundError:
        print("Error: 'uv' not found. Please install uv first:")
        print("  curl -LsSf https://astral.sh/uv/install.sh | sh")
        sys.exit(1)

    # Update config with new version
    new_version = get_current_version()
    config.pytorch_variant = variant
    config.installed_version = new_version
    save_global_config(config)

    print()
    if new_version != current_version:
        print(f"Updated: {current_version} -> {new_version}")
    else:
        print("Already at latest version.")


def needs_first_run_setup() -> bool:
    """Check if first-run setup is needed."""
    return not global_config_exists()
