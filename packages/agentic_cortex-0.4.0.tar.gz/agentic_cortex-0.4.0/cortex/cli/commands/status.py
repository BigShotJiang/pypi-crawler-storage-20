"""CLI command for 'cortex status'."""

import sys
from pathlib import Path
import sqlite3
from datetime import datetime

from cortex.config import find_cortex_root, load_config, get_db_paths
from cortex.db import initialize_lancedb


def _format_size(size_bytes: int) -> str:
    """Format size in bytes to human-readable format.

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted size string (e.g., "1.5 MB")
    """
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


def _get_directory_size(path: Path) -> int:
    """Calculate total size of directory.

    Args:
        path: Directory path

    Returns:
        Total size in bytes
    """
    total = 0
    if path.exists():
        if path.is_file():
            return path.stat().st_size
        for entry in path.rglob("*"):
            if entry.is_file():
                total += entry.stat().st_size
    return total


def status_command(project_root: Path) -> None:
    """Display Cortex project status and statistics.

    Shows file count, symbol count, memory count, database sizes, and last indexed timestamp.

    Args:
        project_root: Path to project root directory (or any subdirectory)
    """
    # Find .cortex/ directory (walk up tree if needed)
    try:
        cortex_dir = find_cortex_root(project_root)
    except FileNotFoundError:
        print("Error: Could not find .cortex/ directory. Run 'cortex init' first.", file=sys.stderr)
        sys.exit(1)

    # Load config
    try:
        config = load_config(cortex_dir)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: Failed to load config: {e}", file=sys.stderr)
        sys.exit(1)

    # Get database paths from config
    sqlite_path, lancedb_path = get_db_paths(config, cortex_dir)

    # Connect to SQLite database (or use default values if not initialized)
    if not sqlite_path.exists():
        file_count = 0
        symbol_count = 0
        last_indexed = None
    else:
        conn = sqlite3.connect(str(sqlite_path), check_same_thread=False)

        # Get file count (distinct file_path values)
        cursor = conn.cursor()
        # Check if symbols table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='symbols'")
        if cursor.fetchone():
            cursor.execute("SELECT COUNT(DISTINCT file_path) FROM symbols")
            file_count = cursor.fetchone()[0] or 0

            # Get symbol count
            cursor.execute("SELECT COUNT(*) FROM symbols")
            symbol_count = cursor.fetchone()[0] or 0

            # Get last indexed timestamp (MAX(updated_at))
            # Check if updated_at column exists first
            cursor.execute("PRAGMA table_info(symbols)")
            columns = [row[1] for row in cursor.fetchall()]

            if "updated_at" in columns:
                cursor.execute("SELECT MAX(updated_at) FROM symbols")
                last_indexed = cursor.fetchone()[0]
            else:
                # Fallback to created_at if updated_at doesn't exist
                if "created_at" in columns:
                    cursor.execute("SELECT MAX(created_at) FROM symbols")
                    last_indexed = cursor.fetchone()[0]
                else:
                    last_indexed = None
        else:
            file_count = 0
            symbol_count = 0
            last_indexed = None

        conn.close()

    # Get memory count from LanceDB
    memory_count = 0
    try:
        if lancedb_path.exists():
            vector_store = initialize_lancedb(str(lancedb_path))
            # Query all records to count
            try:
                # Try to get table length via count_rows()
                memory_count = vector_store.table.count_rows()
            except (AttributeError, OSError):
                # If table is empty or not accessible, count will be 0
                memory_count = 0
    except (ImportError, OSError):
        # LanceDB not initialized or not accessible
        memory_count = 0

    # Get database sizes
    sqlite_size = sqlite_path.stat().st_size if sqlite_path.exists() else 0
    lancedb_size = _get_directory_size(lancedb_path) if lancedb_path.exists() else 0

    # Format timestamp
    if last_indexed:
        try:
            # Try to parse timestamp
            if isinstance(last_indexed, str):
                dt = datetime.fromisoformat(last_indexed.replace(" ", "T", 1))
            else:
                dt = datetime.fromtimestamp(last_indexed)
            timestamp_str = dt.strftime("%Y-%m-%d %H:%M:%S")
        except (ValueError, TypeError, OSError):
            timestamp_str = str(last_indexed)
    else:
        timestamp_str = "Never"

    # Display statistics
    print("\n" + "=" * 50)
    print("Cortex Project Status")
    print("=" * 50)
    print(f"\nProject: {config.project.name}")
    print(f"Root: {cortex_dir.parent}")
    print("\n" + "-" * 50)
    print("Statistics:")
    print(f"  Files indexed:     {file_count}")
    print(f"  Symbols indexed:   {symbol_count}")
    print(f"  Memories stored:   {memory_count}")
    print("\n" + "-" * 50)
    print("Database Sizes:")
    print(f"  SQLite:            {_format_size(sqlite_size)}")
    print(f"  LanceDB:           {_format_size(lancedb_size)}")
    print("\n" + "-" * 50)
    print(f"Last indexed:        {timestamp_str}")
    print("=" * 50 + "\n")
