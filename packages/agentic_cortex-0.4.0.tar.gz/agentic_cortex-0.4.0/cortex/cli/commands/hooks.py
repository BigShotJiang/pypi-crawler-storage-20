"""CLI command for 'cortex hooks' - generate Claude Code hook configuration."""

import json
import sys
from pathlib import Path


# Hook configuration for Claude Code
HOOKS_CONFIG = {
    "hooks": {
        "PreToolUse": [
            {
                "matcher": "Task|Bash|Edit|Write",
                "hooks": [
                    {
                        "type": "command",
                        "command": "# Cortex context auto-injection handled by startup hook"
                    }
                ]
            }
        ],
        "PostToolUse": [],
        "Notification": [],
        "Stop": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": "echo '[Cortex] Session ending. Consider running persist_memory for important insights.'"
                    }
                ]
            }
        ]
    }
}


STARTUP_PROMPT = """At the start of each session, automatically restore context by calling:

1. get_startup_context() - to recall working memory (decisions, tasks, context)
2. If working on a specific file, also call get_context_memories(file_path) for symbol-anchored notes

This ensures continuity across sessions without manual context restoration."""


def hooks_command(output_format: str = "instructions") -> None:
    """Generate Claude Code hook configuration.

    Args:
        output_format: 'instructions' for human-readable, 'json' for config file
    """
    if output_format == "json":
        print(json.dumps(HOOKS_CONFIG, indent=2))
        return

    # Human-readable instructions
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                     Cortex + Claude Code Integration                         ║
╚══════════════════════════════════════════════════════════════════════════════╝

Cortex provides working memory that persists across sessions. To get the most
out of it, configure Claude Code to auto-restore context on session start.

┌──────────────────────────────────────────────────────────────────────────────┐
│ OPTION 1: Add to CLAUDE.md (Recommended)                                     │
└──────────────────────────────────────────────────────────────────────────────┘

Add this to your project's CLAUDE.md file:

```markdown
## Session Context

At the start of each session:
1. Call `get_startup_context()` to restore working memory
2. For file-specific work, call `get_context_memories(file_path)`

Before ending a session:
1. Store important context: `store_memory("...", category="decision")`
2. For temporary context: `store_memory("...", category="session")`
```

┌──────────────────────────────────────────────────────────────────────────────┐
│ OPTION 2: User Prompt Hook (Auto-injection)                                  │
└──────────────────────────────────────────────────────────────────────────────┘

Add to your Claude Code settings (~/.claude/settings.json):

```json
{
  "hooks": {
    "user-prompt-submit": [
      {
        "matcher": ".*",
        "hooks": [
          {
            "type": "command",
            "command": "echo 'Remember: Use get_startup_context() at session start'"
          }
        ]
      }
    ]
  }
}
```

┌──────────────────────────────────────────────────────────────────────────────┐
│ Working Memory Quick Reference                                               │
└──────────────────────────────────────────────────────────────────────────────┘

STORING MEMORIES:
  store_memory("Chose JWT for auth", category="decision", priority=5)
  store_memory("Next: add rate limiting", category="task")
  store_memory("Ruled out race condition", category="hypothesis")
  store_memory("User prefers TypeScript", category="preference")

RECALLING MEMORIES:
  get_startup_context()              # Session start - curated context
  recall_memories("authentication")  # Semantic search
  list_memories(category="decision") # Browse by category

LINKING TO CODE:
  store_memory("JWT chosen for stateless scaling",
               category="decision",
               linked_symbols="auth.py::::login,auth.py::::verify")

  # Then explore_symbol("auth.py::::login") shows this decision

SESSION MANAGEMENT:
  persist_memory(memory_id)  # Promote session→decision
  clear_session()            # Fresh start (keeps decisions/context/preferences)

""")


def print_claude_md_snippet() -> None:
    """Print a snippet to add to CLAUDE.md for working memory integration."""
    print("""
## Cortex Working Memory

This project uses Cortex for persistent working memory across sessions.

### Session Start
At the beginning of each session, restore context:
```
get_startup_context()
```

### During Work
- Store decisions: `store_memory("...", category="decision", priority=5)`
- Track debugging: `store_memory("Ruled out X", category="hypothesis")`
- Link to code: `store_memory("...", linked_symbols="file.py::::func")`

### Session End
Before ending, persist important insights:
```
list_memories(category="session")
persist_memory(memory_id)  # For memories worth keeping
```

### Categories
| Category | Persists | Purpose |
|----------|----------|---------|
| decision | Yes | Architectural choices |
| context | Yes | Project knowledge |
| preference | Yes | User preferences |
| task | No | Work in progress |
| session | No | Temporary context |
| hypothesis | No | Debugging state |
""")
