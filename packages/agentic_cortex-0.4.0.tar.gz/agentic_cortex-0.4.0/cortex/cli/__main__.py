"""CLI entry point for `python -m cortex.cli`."""

from cortex.cli import main


if __name__ == "__main__":
    main()
