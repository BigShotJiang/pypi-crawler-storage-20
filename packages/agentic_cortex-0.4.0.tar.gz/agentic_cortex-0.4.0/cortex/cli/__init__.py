"""Cortex CLI module with argparse-based command routing."""

import argparse
import sys
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path

from cortex.cli.commands.init import init_command
from cortex.cli.commands.start import start_command
from cortex.cli.commands.status import status_command
from cortex.cli.commands.reindex import reindex_command
from cortex.cli.commands.hooks import hooks_command, print_claude_md_snippet
from cortex.cli.commands.setup import (
    needs_first_run_setup,
    run_first_time_setup,
    update_command,
)


def get_version() -> str:
    """Get the installed package version."""
    try:
        return version("agentic-cortex")
    except PackageNotFoundError:
        return "0.0.0-dev"


def main():
    """Main entry point for Cortex CLI."""
    parser = argparse.ArgumentParser(
        prog="cortex",
        description="Cortex: Local-first agentic memory architecture for coding agents",
    )
    parser.add_argument(
        "-V", "--version",
        action="version",
        version=f"cortex {get_version()}",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # init command
    init_parser = subparsers.add_parser("init", help="Initialize a Cortex project in the current directory")
    init_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Project root directory (default: current directory)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing .cortex/ directory",
    )
    # GPU variant flags for first-run setup
    init_gpu_group = init_parser.add_mutually_exclusive_group()
    init_gpu_group.add_argument(
        "--rocm",
        action="store_true",
        help="Use ROCm PyTorch (AMD GPUs)",
    )
    init_gpu_group.add_argument(
        "--nvidia", "--cuda",
        action="store_true",
        dest="nvidia",
        help="Use CUDA PyTorch (NVIDIA GPUs)",
    )
    init_gpu_group.add_argument(
        "--cpu",
        action="store_true",
        help="Use CPU-only PyTorch",
    )
    
    # start command
    start_parser = subparsers.add_parser("start", help="Start the Cortex MCP server")
    start_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Project root directory or any subdirectory (default: current directory)",
    )
    
    # status command
    status_parser = subparsers.add_parser("status", help="Display Cortex project status and statistics")
    status_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Project root directory or any subdirectory (default: current directory)",
    )
    
    # reindex command
    reindex_parser = subparsers.add_parser("reindex", help="Reindex the codebase (truncate Tier 1&2, preserve Tier 3)")
    reindex_parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Project root directory or any subdirectory (default: current directory)",
    )

    # update command
    update_parser = subparsers.add_parser("update", help="Update Cortex to the latest version")
    update_gpu_group = update_parser.add_mutually_exclusive_group()
    update_gpu_group.add_argument(
        "--rocm",
        action="store_true",
        help="Switch to ROCm PyTorch (AMD GPUs)",
    )
    update_gpu_group.add_argument(
        "--nvidia", "--cuda",
        action="store_true",
        dest="nvidia",
        help="Switch to CUDA PyTorch (NVIDIA GPUs)",
    )
    update_gpu_group.add_argument(
        "--cpu",
        action="store_true",
        help="Switch to CPU-only PyTorch",
    )

    # hooks command
    hooks_parser = subparsers.add_parser("hooks", help="Show Claude Code hook integration instructions")
    hooks_parser.add_argument(
        "--json",
        action="store_true",
        help="Output hook configuration as JSON",
    )
    hooks_parser.add_argument(
        "--claude-md",
        action="store_true",
        help="Output snippet for CLAUDE.md",
    )

    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        if args.command == "init":
            # Check for first-run setup
            if needs_first_run_setup():
                # Determine forced variant from flags
                force_variant = None
                if args.rocm:
                    force_variant = "rocm"
                elif args.nvidia:
                    force_variant = "nvidia"
                elif args.cpu:
                    force_variant = "cpu"

                run_first_time_setup(force_variant=force_variant)
                print()

            # Now run normal init
            init_command(Path(args.path).resolve(), force=args.force)
            print(f"✓ Cortex initialized in {Path(args.path).resolve()}")
            print()
            print("Next steps:")
            print("  1. Start the MCP server: cortex start")
            print("  2. Configure Claude Code integration: cortex hooks")
            print("  3. Add working memory snippet to CLAUDE.md: cortex hooks --claude-md")

        elif args.command == "start":
            # For start command, resolve the path and let find_cortex_root handle walking up
            start_command(Path(args.path).resolve())

        elif args.command == "status":
            status_command(Path(args.path).resolve())

        elif args.command == "reindex":
            reindex_command(Path(args.path).resolve())
            print("✓ Reindexing complete")

        elif args.command == "update":
            # Determine forced variant from flags
            force_variant = None
            if args.rocm:
                force_variant = "rocm"
            elif args.nvidia:
                force_variant = "nvidia"
            elif args.cpu:
                force_variant = "cpu"

            update_command(force_variant=force_variant)

        elif args.command == "hooks":
            if args.claude_md:
                print_claude_md_snippet()
            elif args.json:
                hooks_command(output_format="json")
            else:
                hooks_command(output_format="instructions")

    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
