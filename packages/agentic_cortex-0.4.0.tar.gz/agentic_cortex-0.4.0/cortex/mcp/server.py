"""MCP server implementation for Cortex using FastMCP.

This module implements the MCP server entry point that wires up resources and tools,
handles stdio transport, and manages database connections using FastMCP framework.
"""

from pathlib import Path
from typing import Any, Optional

from fastmcp import FastMCP
from fastmcp.dependencies import Depends

from cortex.db.sqlite import initialize_db
from cortex.core.search_engine import SearchEngine
from cortex.core.graph import GraphQuery
from cortex.core.inspection import read_file_skeleton
from cortex.vector.store import VectorStore
from cortex.vector.working_memory import WorkingMemoryStore
from cortex.types import MEMORY_CATEGORIES
from cortex.mcp.resources import (
    get_skeleton_resource,
    get_relevant_memories_resource,
)
from cortex.mcp.tools import (
    search_codebase_tool as _search_codebase_tool,
    inspect_symbol_tool as _inspect_symbol_tool,
    impact_analysis_tool as _impact_analysis_tool,
    attach_memory_tool as _attach_memory_tool,
)
from cortex.core.benchmark import Benchmarker, format_benchmark_report


# FastMCP server instance
mcp = FastMCP(name="Cortex", version="0.1.0")

# Module-level storage for initialized resources (set by run_server)
_db_conn: Optional[Any] = None
_vector_store: Optional[VectorStore] = None
_working_memory: Optional[WorkingMemoryStore] = None
_search_engine: Optional[SearchEngine] = None
_graph_query: Optional[GraphQuery] = None
_project_root: Optional[Path] = None


# Dependency injection functions
def get_db_conn():
    """Get SQLite database connection."""
    if _db_conn is None:
        raise ValueError("Database connection not initialized. Call run_server() first.")
    return _db_conn


def get_vector_store() -> VectorStore:
    """Get VectorStore instance."""
    if _vector_store is None:
        raise ValueError("Vector store not initialized. Call run_server() first.")
    return _vector_store


def get_working_memory() -> WorkingMemoryStore:
    """Get WorkingMemoryStore instance."""
    if _working_memory is None:
        raise ValueError("Working memory not initialized. Call run_server() first.")
    return _working_memory


def get_search_engine() -> SearchEngine:
    """Get SearchEngine instance."""
    if _search_engine is None:
        raise ValueError("SearchEngine not initialized. Call run_server() first.")
    return _search_engine


def get_graph_query() -> GraphQuery:
    """Get GraphQuery instance."""
    if _graph_query is None:
        raise ValueError("GraphQuery not initialized. Call run_server() first.")
    return _graph_query


def get_project_root() -> Path:
    """Get project root path."""
    if _project_root is None:
        raise ValueError("Project root not initialized. Call run_server() first.")
    return _project_root


# Tools
@mcp.tool(
    name="search_codebase",
    description="""
    The PRIMARY search tool. Use this FIRST.
    Finds code by name (fuzzy match) or by concept (semantic match).
    Returns a list of 'Symbol IDs' that you can inspect later.
    """,
)
async def search_codebase_tool(
    query: str,
    type: Optional[str] = None,
    search_engine: SearchEngine = Depends(get_search_engine),
) -> str:
    result = _search_codebase_tool(query, type, search_engine)
    symbol_ids = result.get("results") or result.get("symbols") or result.get("matches") or []
    return "\n".join(symbol_ids) if symbol_ids else "No results found"


@mcp.tool(
    name="read_file_skeleton",
    description="""
    TOKEN-EFFICIENT file reader.
    Returns the file structure (classes, functions, docstrings) but HIDES the implementation bodies with '...'.

    ALWAYS use this tool INSTEAD of 'read_file' when first exploring a file.
    It saves context window space.
    If you need to see the logic of a specific function, use 'inspect_symbol' next.
    """,
)
async def read_file_skeleton_tool(
    file_path: str,
    conn: Any = Depends(get_db_conn),
) -> str:
    """Read file skeleton (structure without implementation bodies)."""
    skeleton = read_file_skeleton(conn, file_path)
    return skeleton


@mcp.tool(
    name="inspect_symbol",
    description="""
    The 'Hydration' tool.
    Reveals the full source code (implementation) of a SPECIFIC symbol (function or class).

    Use this ONLY after using 'read_file_skeleton' or 'search_codebase' to get a Symbol ID.
    Do not use this to read entire files.
    """,
)
async def inspect_symbol_tool(
    symbol_id: str,
    conn: Any = Depends(get_db_conn),
) -> str:
    result = _inspect_symbol_tool(symbol_id, conn)
    return result.get("code") or result.get("contents") or result.get("text") or ""


@mcp.tool(
    name="impact_analysis",
    description="""
    Safety check.
    Before editing a function, call this to see a graph of who calls it (upstream dependencies).
    Prevents breaking changes in other files.
    """,
)
async def impact_analysis_tool(
    symbol_id: str,
    depth: Optional[int] = None,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    result = _impact_analysis_tool(symbol_id, depth, graph_query)
    impacted = result.get("impact") or result.get("symbols") or result.get("downstream") or []
    return "\n".join(impacted) if impacted else "No upstream callers found"


@mcp.tool
async def attach_memory(
    symbol_id: str,
    content: str,
    store: VectorStore = Depends(get_vector_store),
) -> str:
    """Attach a memory (semantic note) to a symbol."""
    result = _attach_memory_tool(symbol_id, content, store)

    if result.get("success") or result.get("status") == "success":
        return f"Memory attached to {symbol_id} successfully"
    else:
        return f"Failed to attach memory to {symbol_id}"


@mcp.tool(
    name="get_memories",
    description="""
    Retrieve memories (semantic notes) attached to a symbol.

    Use this to recall context that was previously attached via attach_memory.
    Memories are "tribal knowledge" - notes, insights, warnings, or context
    that help understand a symbol beyond what's in the code.

    Can also retrieve memories for all symbols in a file by passing a file path.
    """,
)
async def get_memories_tool(
    symbol_id: str,
    store: VectorStore = Depends(get_vector_store),
) -> str:
    """Retrieve memories attached to a symbol."""
    try:
        table = store.table
        all_data = table.to_arrow()

        if len(all_data) == 0:
            return "No memories found in store"

        # Get columns
        anchor_ids = all_data["anchor_symbol_id"].to_pylist()
        text_contents = all_data["text_content"].to_pylist()

        # Find memories matching this symbol
        memories = []
        for idx, anchor_id in enumerate(anchor_ids):
            if anchor_id == symbol_id:
                memories.append(text_contents[idx])

        if memories:
            lines = [f"=== Memories for {symbol_id} ===", ""]
            for i, mem in enumerate(memories, 1):
                lines.append(f"[{i}] {mem}")
                lines.append("")
            return "\n".join(lines)
        else:
            return f"No memories attached to {symbol_id}"

    except (AttributeError, KeyError, OSError) as e:
        return f"Error retrieving memories: {e}"


@mcp.tool(
    name="get_context_memories",
    description="""
    Get "tribal knowledge" memories for all symbols in a file.

    When opening a file, use this to discover relevant context that was
    previously attached to symbols in that file. This surfaces notes,
    warnings, and insights that help understand the code.

    Per the Cortex semantic anchoring spec:
    1. Finds all Symbol IDs in the file
    2. Queries for memories anchored to any of those symbols
    3. Returns the top 3 most recent/relevant notes

    Use this BEFORE making changes to a file to understand:
    - Previous decisions and reasoning
    - Known issues or gotchas
    - Context that isn't in the code

    Example:
    - get_context_memories("cortex/parser/generic.py")
    """,
)
async def get_context_memories_tool(
    file_path: str,
    limit: int = 3,
    graph_query: GraphQuery = Depends(get_graph_query),
    store: VectorStore = Depends(get_vector_store),
) -> str:
    """Get context memories for all symbols in a file."""
    memories = graph_query.get_context_memories(file_path, store, limit=limit)

    if not memories:
        return f"No context memories found for symbols in '{file_path}'"

    lines = [f"=== Context Memories for {file_path} ===", ""]

    for i, mem in enumerate(memories, 1):
        lines.append(f"[{i}] Symbol: {mem.get('anchor_symbol_id', 'unknown')}")
        lines.append(f"    Content: {mem.get('text_content', '')}")
        if mem.get("created_at"):
            lines.append(f"    Created: {mem['created_at']}")
        lines.append("")

    return "\n".join(lines)


# =============================================================================
# Working Memory Tools - General context not anchored to code
# =============================================================================


@mcp.tool(
    name="store_memory",
    description="""
    Store a general working memory (not anchored to code).

    Use this for context that isn't tied to specific symbols:
    - Session context: "Working on implementing auth feature"
    - Decisions: "Chose JWT over sessions for stateless scaling"
    - Tasks: "Next steps: 1. Add tests, 2. Update docs"
    - Preferences: "User prefers minimal comments"
    - Hypotheses: "Ruled out race condition - logs show sequential execution"

    Categories:
    - session: Temporary context (auto-expires after 24h)
    - decision: Persistent architectural choices
    - context: Persistent project knowledge
    - task: Work in progress, handoff notes
    - preference: Learned user preferences
    - hypothesis: Debugging state (auto-expires after 4h)

    Higher priority memories surface first in recall (1-5, default 3).
    Tags help filter memories later.

    linked_symbols: Optional comma-separated symbol IDs that this memory relates to.
    These will surface in explore_symbol for those symbols.
    Example: "auth.py::::login,auth.py::::verify_token"
    """,
)
async def store_memory_tool(
    content: str,
    category: str = "context",
    priority: int = 3,
    tags: str = "",
    linked_symbols: str = "",
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Store a working memory."""
    try:
        # Parse tags from comma-separated string
        tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
        # Parse linked_symbols from comma-separated string
        symbols_list = [s.strip() for s in linked_symbols.split(",") if s.strip()] if linked_symbols else []

        memory = working_memory.store(
            content=content,
            category=category,
            priority=priority,
            tags=tag_list,
            linked_symbols=symbols_list,
        )

        expires_info = ""
        if memory.expires_at:
            expires_info = f" (expires: {memory.expires_at.strftime('%Y-%m-%d %H:%M')})"

        linked_info = ""
        if memory.linked_symbols:
            linked_info = f"\nLinked to: {', '.join(memory.linked_symbols)}"

        return f"Memory stored [{memory.category}] (priority {memory.priority}){expires_info}{linked_info}\nID: {memory.id}"

    except ValueError as e:
        return f"Error: {e}"


@mcp.tool(
    name="recall_memories",
    description="""
    Recall working memories by semantic similarity.

    Search across stored memories to find relevant context.
    Use at session start to restore context, or during work
    to recall decisions and preferences.

    Examples:
    - recall_memories("authentication") - Find auth-related context
    - recall_memories("user preferences", category="preference")
    - recall_memories("next steps", category="task")
    """,
)
async def recall_memories_tool(
    query: str,
    category: str = "",
    tags: str = "",
    limit: int = 5,
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Recall memories by semantic search."""
    # Parse optional filters
    cat_filter = category if category else None
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else None

    memories = working_memory.recall(
        query=query,
        category=cat_filter,
        tags=tag_list,
        limit=limit,
    )

    if not memories:
        return f"No memories found matching '{query}'"

    lines = [f"=== Recalled Memories ({len(memories)}) ===", ""]

    for i, mem in enumerate(memories, 1):
        lines.append(f"[{i}] [{mem.category}] (priority {mem.priority})")
        lines.append(f"    {mem.content}")
        if mem.tags:
            lines.append(f"    Tags: {', '.join(mem.tags)}")
        if mem.created_at:
            lines.append(f"    Created: {mem.created_at.strftime('%Y-%m-%d %H:%M')}")
        lines.append(f"    ID: {mem.id}")
        lines.append("")

    return "\n".join(lines)


@mcp.tool(
    name="list_memories",
    description="""
    List all working memories, optionally filtered by category.

    Use to see what's stored:
    - list_memories() - All memories
    - list_memories(category="decision") - Just decisions
    - list_memories(category="session") - Session context

    Available categories: session, decision, context, task, preference
    """,
)
async def list_memories_tool(
    category: str = "",
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """List all working memories."""
    cat_filter = category if category else None

    memories = working_memory.list_memories(category=cat_filter)

    if not memories:
        if cat_filter:
            return f"No memories in category '{cat_filter}'"
        return "No memories stored"

    # Group by category
    by_category: dict = {}
    for mem in memories:
        if mem.category not in by_category:
            by_category[mem.category] = []
        by_category[mem.category].append(mem)

    lines = [f"=== Working Memories ({len(memories)} total) ===", ""]

    for cat in ["decision", "context", "preference", "hypothesis", "task", "session"]:
        if cat in by_category:
            lines.append(f"--- {cat.upper()} ({len(by_category[cat])}) ---")
            for mem in by_category[cat][:5]:  # Limit per category
                preview = mem.content[:80] + "..." if len(mem.content) > 80 else mem.content
                lines.append(f"  [{mem.priority}] {preview}")
                lines.append(f"      ID: {mem.id}")
            if len(by_category[cat]) > 5:
                lines.append(f"  ... and {len(by_category[cat]) - 5} more")
            lines.append("")

    return "\n".join(lines)


@mcp.tool(
    name="forget_memory",
    description="""
    Remove a specific memory by ID.

    Use recall_memories or list_memories to find the ID first.
    """,
)
async def forget_memory_tool(
    memory_id: str,
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Remove a specific memory."""
    success = working_memory.forget(memory_id)

    if success:
        return f"Memory {memory_id} removed"
    else:
        return f"Memory {memory_id} not found or could not be removed"


@mcp.tool(
    name="clear_session",
    description="""
    Clear all session, task, and hypothesis memories.

    Use when starting fresh while preserving:
    - Decisions (architectural choices)
    - Context (project knowledge)
    - Preferences (learned preferences)

    This removes:
    - Session memories (temporary context)
    - Task memories (work in progress)
    - Hypothesis memories (debugging state)
    """,
)
async def clear_session_tool(
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Clear session, task, and hypothesis memories."""
    removed = working_memory.clear_session()
    return f"Cleared {removed} session/task/hypothesis memories. Decisions, context, and preferences preserved."


@mcp.tool(
    name="get_startup_context",
    description="""
    Get working memory context for session startup.

    Call this at the beginning of a session to restore context:
    - High-priority decisions and context
    - Recent task memories (what was in progress)
    - Active session context
    - Current debugging hypotheses

    Returns a curated set of memories ordered by priority and recency.
    Useful for hooks that auto-inject context on session start.
    """,
)
async def get_startup_context_tool(
    limit: int = 10,
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Get startup context from working memory."""
    memories = working_memory.get_startup_context(limit=limit)

    if not memories:
        return "No working memory context found. This is a fresh start."

    lines = ["=== Session Context ===", ""]

    for mem in memories:
        category_icon = {
            "decision": "[D]",
            "context": "[C]",
            "preference": "[P]",
            "task": "[T]",
            "session": "[S]",
            "hypothesis": "[H]",
        }.get(mem.category, "[?]")

        lines.append(f"{category_icon} (p{mem.priority}) {mem.content}")
        if mem.linked_symbols:
            lines.append(f"    Linked: {', '.join(mem.linked_symbols[:3])}")
        lines.append("")

    return "\n".join(lines)


@mcp.tool(
    name="persist_memory",
    description="""
    Promote a session/task memory to a persistent decision.

    Use at session end to preserve important insights:
    1. Call list_memories(category="session") or list_memories(category="task")
    2. Find memories worth keeping
    3. Call persist_memory(memory_id) to promote to decision

    The original memory is removed and a new decision is created
    with the same content, tags, and linked symbols.
    """,
)
async def persist_memory_tool(
    memory_id: str,
    new_content: str = "",
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Promote a memory to decision category."""
    new_memory = working_memory.persist_to_decision(
        memory_id,
        new_content=new_content if new_content else None,
    )

    if new_memory:
        return f"Memory promoted to decision (priority {new_memory.priority})\nNew ID: {new_memory.id}"
    else:
        return f"Memory {memory_id} not found"


@mcp.tool(
    name="explore_symbol",
    description="""
    Get the relational neighborhood of a symbol.

    This is the KEY tool for understanding a symbol's role in the codebase.
    Returns a combined view of:
    - Symbol metadata (kind, signature, docstring)
    - Upstream callers (who calls this function)
    - Downstream callees (what this function calls)
    - Co-located symbols (other symbols in the same file)
    - Linked memories (decisions/context related to this symbol)

    Use this BEFORE making changes to understand:
    - What would break if you modify this? (callers)
    - What does this depend on? (callees)
    - What else is defined nearby? (co-located)
    - What decisions were made about this? (memories)

    Much more useful than impact_analysis alone because it shows
    the full context in both directions.
    """,
)
async def explore_symbol_tool(
    symbol_id: str,
    graph_query: GraphQuery = Depends(get_graph_query),
    working_memory: WorkingMemoryStore = Depends(get_working_memory),
) -> str:
    """Get the relational neighborhood of a symbol."""
    neighborhood = graph_query.get_neighborhood(symbol_id)

    if "error" in neighborhood:
        return neighborhood["error"]

    # Format as readable output
    lines = []
    sym = neighborhood["symbol"]

    lines.append(f"=== {sym['id']} ===")
    lines.append(f"Kind: {sym['kind']}")
    lines.append(f"File: {sym['file_path']} (lines {sym['start_line']}-{sym['end_line']})")
    if sym.get("signature"):
        lines.append(f"Signature: {sym['signature']}")
    if sym.get("docstring"):
        doc_preview = sym["docstring"][:200] + "..." if len(sym["docstring"]) > 200 else sym["docstring"]
        lines.append(f"Docstring: {doc_preview}")

    lines.append("")
    lines.append("--- CALLERS (who calls this) ---")
    if neighborhood["callers"]:
        for caller in neighborhood["callers"]:
            lines.append(f"  <- {caller}")
    else:
        lines.append("  (none)")

    lines.append("")
    lines.append("--- CALLEES (what this calls) ---")
    if neighborhood["callees"]:
        for callee in neighborhood["callees"]:
            lines.append(f"  -> {callee}")
    else:
        lines.append("  (none)")

    lines.append("")
    lines.append("--- CO-LOCATED SYMBOLS (same file) ---")
    if neighborhood.get("file_symbols"):
        for s in neighborhood["file_symbols"][:10]:  # Limit to 10
            sig_preview = s["signature"][:50] + "..." if s["signature"] and len(s["signature"]) > 50 else s["signature"]
            lines.append(f"  {s['kind']}: {sig_preview}")
        if len(neighborhood["file_symbols"]) > 10:
            lines.append(f"  ... and {len(neighborhood['file_symbols']) - 10} more")
    else:
        lines.append("  (none)")

    lines.append("")
    lines.append("--- FILE IMPORTS ---")
    if neighborhood.get("imports"):
        # Group imports for readability
        internal = [i for i in neighborhood["imports"] if i.startswith("cortex") or i.startswith(".")]
        external = [i for i in neighborhood["imports"] if i not in internal]
        if internal:
            lines.append("  Internal:")
            for imp in internal[:8]:
                lines.append(f"    {imp}")
            if len(internal) > 8:
                lines.append(f"    ... and {len(internal) - 8} more")
        if external:
            lines.append("  External:")
            for imp in external[:8]:
                lines.append(f"    {imp}")
            if len(external) > 8:
                lines.append(f"    ... and {len(external) - 8} more")
    else:
        lines.append("  (none)")

    # Show linked memories (decisions/context related to this symbol)
    linked_memories = working_memory.get_memories_for_symbol(symbol_id)
    lines.append("")
    lines.append("--- LINKED MEMORIES ---")
    if linked_memories:
        for mem in linked_memories[:5]:  # Limit to 5
            category_icon = {"decision": "[D]", "context": "[C]", "preference": "[P]"}.get(mem.category, "[?]")
            preview = mem.content[:100] + "..." if len(mem.content) > 100 else mem.content
            lines.append(f"  {category_icon} {preview}")
        if len(linked_memories) > 5:
            lines.append(f"  ... and {len(linked_memories) - 5} more")
    else:
        lines.append("  (none)")

    return "\n".join(lines)


@mcp.tool(
    name="get_importers",
    description="""
    Find all files that import a module.

    Essential for understanding blast radius before changing a module's API.
    Use this to answer: "What would break if I change this module?"

    Examples:
    - get_importers("cortex.parser") - Who imports from cortex.parser?
    - get_importers("typing") - Who uses typing module?

    Supports pattern matching with % wildcard:
    - get_importers("cortex.%") - Who imports anything from cortex?
    """,
)
async def get_importers_tool(
    module: str,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    """Find files that import a module."""
    importers = graph_query.get_importers(module)

    if importers:
        lines = [f"Files that import '{module}':"]
        for imp in importers:
            lines.append(f"  {imp}")
        return "\n".join(lines)
    else:
        return f"No files import '{module}'"


@mcp.tool(
    name="get_class_hierarchy",
    description="""
    Find the inheritance hierarchy for a class.

    Shows both parent classes (what this inherits from) and child classes
    (what inherits from this).

    Examples:
    - get_class_hierarchy("file.py::::Config") - Full inheritance tree
    - Useful for understanding class relationships and design patterns
    """,
)
async def get_class_hierarchy_tool(
    symbol_id: str,
    depth: Optional[int] = None,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    """Get inheritance hierarchy for a class."""
    actual_depth = depth if depth is not None else 3
    hierarchy = graph_query.get_class_hierarchy(symbol_id, depth=actual_depth)

    lines = [f"Inheritance hierarchy for '{symbol_id}':"]

    if hierarchy["parents"]:
        lines.append("\nInherits from:")
        for parent in hierarchy["parents"]:
            lines.append(f"  {parent}")
    else:
        lines.append("\nInherits from: (none - base class)")

    if hierarchy["children"]:
        lines.append("\nInherited by:")
        for child in hierarchy["children"]:
            lines.append(f"  {child}")
    else:
        lines.append("\nInherited by: (no subclasses found)")

    return "\n".join(lines)


@mcp.tool(
    name="get_callees",
    description="""
    Find what a function calls (downstream dependencies).

    Complements impact_analysis (which finds callers/upstream).
    Use this to trace execution flow forward:
    - What functions does this call?
    - What's the call chain from here?

    For a complete picture, use explore_symbol instead which shows
    both callers AND callees together.
    """,
)
async def get_callees_tool(
    symbol_id: str,
    depth: Optional[int] = None,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    """Find what a function calls."""
    actual_depth = depth if depth is not None else 2
    callees = graph_query.get_downstream(symbol_id, depth=actual_depth)

    if callees:
        return "\n".join(callees)
    else:
        return f"No callees found for {symbol_id}"


@mcp.tool(
    name="benchmark",
    description="""
    Run a benchmark comparing traditional file reading vs Cortex's token-efficient approach.

    ⚠️  WARNING: This tool is EXPENSIVE in terms of token consumption.
    It intentionally reads files using both traditional and Cortex approaches
    to demonstrate the savings. Only run this when you specifically want to
    measure and compare token consumption.

    REQUIRED: You must pass confirm=true to run this benchmark.

    Parameters:
    - confirm: Must be true to run the benchmark (safety guard)
    - verbose: If true, includes actual content previews for verification

    The benchmark runs several scenarios:
    1. Understanding a single file
    2. Finding a specific function
    3. Exploring a module (multiple files)
    4. Impact analysis (finding callers)
    5. Full codebase overview

    Returns a detailed report comparing token consumption and savings.
    With verbose=true, also shows content previews for subjective analysis.
    """,
)
async def benchmark_tool(
    confirm: bool = False,
    verbose: bool = False,
    conn: Any = Depends(get_db_conn),
    project_root: Path = Depends(get_project_root),
) -> str:
    """Run benchmark comparing traditional vs Cortex approaches."""
    if not confirm:
        return """⚠️  BENCHMARK REQUIRES CONFIRMATION

This benchmark is intentionally expensive - it reads files using BOTH
traditional and Cortex approaches to measure token savings.

To run the benchmark, call again with confirm=true:

    benchmark(confirm=true)

For verification with content previews (even more tokens):

    benchmark(confirm=true, verbose=true)

Expected cost: ~70,000 tokens (varies by codebase size)
Expected cost with verbose: ~150,000 tokens (includes content previews)
Expected result: Detailed comparison showing typical 80-90% token savings
"""

    benchmarker = Benchmarker(project_root, conn)
    result = benchmarker.run_all_scenarios()
    return format_benchmark_report(result, verbose=verbose)


# Resources
@mcp.resource("cortex://{filepath*}/skeleton")
async def get_skeleton(
    filepath: str,
    conn: Any = Depends(get_db_conn),
) -> str:
    """Skeleton code for a file."""
    resource_uri = f"cortex://{filepath}/skeleton"
    result = get_skeleton_resource(resource_uri, conn)
    return result.get("contents") or result.get("text") or result.get("body") or ""


@mcp.resource("cortex://graph/callers/{symbol_id}")
async def get_callers(
    symbol_id: str,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    """Callers (upstream dependencies) for a symbol."""
    # Use GraphQuery to get upstream callers
    callers = graph_query.get_upstream(symbol_id, depth=2)
    return "\n".join(callers) if callers else "No callers found"


@mcp.resource("cortex://memory/relevant/{symbol_id}")
async def get_relevant_memories(
    symbol_id: str,
    store: VectorStore = Depends(get_vector_store),
) -> str:
    """Relevant memories anchored to a symbol."""
    resource_uri = f"cortex://memory/relevant/{symbol_id}"
    result = get_relevant_memories_resource(resource_uri, store)
    memories = result.get("memories") or result.get("contents") or result.get("texts") or []
    return "\n".join(memories) if memories else "No memories found"


def run_server(
    db_path: Optional[str] = None,
    lancedb_path: Optional[str] = None,
) -> None:
    """Run the MCP server with stdio transport.

    Loads config from .cortex/ directory to get database paths.
    If db_path or lancedb_path are provided, they override config values.

    Args:
        db_path: Optional path to SQLite database file (overrides config)
        lancedb_path: Optional path to LanceDB directory (overrides config)
    """
    global _db_conn, _vector_store, _working_memory, _search_engine, _graph_query, _project_root

    from cortex.config import find_cortex_root, load_config, get_db_paths

    # Load config from .cortex/ directory
    try:
        # Try to find .cortex/ from current working directory
        cwd = Path.cwd()
        cortex_dir = find_cortex_root(cwd)
        _project_root = cortex_dir.parent  # Project root is parent of .cortex/
        config = load_config(cortex_dir)
        config_sqlite_path, config_lancedb_path = get_db_paths(config, cortex_dir)

        # Use provided paths or fall back to config paths
        final_db_path = db_path or str(config_sqlite_path)
        final_lancedb_path = lancedb_path or str(config_lancedb_path)
    except (FileNotFoundError, ValueError):
        # If config not found, require explicit paths
        if db_path is None:
            raise ValueError(
                "Could not find .cortex/ directory. Either run 'cortex init' first, "
                "or provide db_path and lancedb_path explicitly."
            )
        final_db_path = db_path
        final_lancedb_path = lancedb_path

    # Initialize database connections
    _db_conn = initialize_db(final_db_path)
    _vector_store = VectorStore(final_lancedb_path)

    # Initialize working memory store (uses same LanceDB directory, different table)
    _working_memory = WorkingMemoryStore(final_lancedb_path)

    # Initialize SearchEngine and GraphQuery
    _search_engine = SearchEngine(_db_conn, _vector_store)
    _graph_query = GraphQuery(_db_conn)

    # Run FastMCP server (this blocks until server exits)
    mcp.run()


if __name__ == "__main__":
    # When run directly, try to load from config
    # This allows the server to be started without explicit paths
    run_server()
