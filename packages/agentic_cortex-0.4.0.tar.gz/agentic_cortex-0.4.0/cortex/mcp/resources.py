"""MCP resource handlers for Cortex.

This module implements MCP resources as specified in the planning document:
- cortex://{filepath}/skeleton: Returns AST-generated skeleton
- cortex://graph/callers/{symbol_id}: Returns upstream dependencies
- cortex://memory/relevant/{symbol_id}: Returns semantic notes anchored to a symbol
"""

import sqlite3
import re
from typing import Dict, Any

from cortex.core.inspection import read_file_skeleton
from cortex.vector.store import VectorStore
from cortex.vector.embeddings import generate_embedding


def get_skeleton_resource(resource_uri: str, conn: sqlite3.Connection) -> Dict[str, Any]:
    """Get skeleton resource for a file.

    Resource URI format: cortex://{filepath}/skeleton

    Args:
        resource_uri: Resource URI (e.g., "cortex://test.py/skeleton")
        conn: SQLite database connection

    Returns:
        Dictionary with skeleton code in 'contents', 'text', or 'body' field
    """
    # Parse URI: cortex://{filepath}/skeleton
    match = re.match(r"cortex://(.+)/skeleton", resource_uri)
    if not match:
        raise ValueError(f"Invalid skeleton resource URI: {resource_uri}")

    file_path = match.group(1)

    # Get skeleton using core inspection
    skeleton = read_file_skeleton(conn, file_path)

    # Return in MCP resource format
    return {
        "contents": skeleton,
        "text": skeleton,
        "body": skeleton,
    }


def get_callers_resource(resource_uri: str, conn: sqlite3.Connection) -> Dict[str, Any]:
    """Get callers resource (upstream dependencies) for a symbol.

    Resource URI format: cortex://graph/callers/{symbol_id}

    Args:
        resource_uri: Resource URI (e.g., "cortex://graph/callers/test.py::::calculate")
        conn: SQLite database connection

    Returns:
        Dictionary with list of caller symbol IDs in 'callers', 'symbols', or 'contents' field
    """
    # Parse URI: cortex://graph/callers/{symbol_id}
    match = re.match(r"cortex://graph/callers/(.+)", resource_uri)
    if not match:
        raise ValueError(f"Invalid callers resource URI: {resource_uri}")

    symbol_id = match.group(1)

    # Query for callers (symbols that have edges where target_id = symbol_id and type = 'CALLS')
    cursor = conn.cursor()
    cursor.execute(
        """
        SELECT DISTINCT source_id
        FROM edges
        WHERE target_id = ? AND type = 'CALLS'
        ORDER BY source_id
        """,
        (symbol_id,),
    )

    callers = [row[0] for row in cursor.fetchall()]

    # Return in MCP resource format
    return {
        "callers": callers,
        "symbols": callers,
        "contents": callers,
    }


def get_relevant_memories_resource(resource_uri: str, store: VectorStore) -> Dict[str, Any]:
    """Get relevant memories resource for a symbol.

    Resource URI format: cortex://memory/relevant/{symbol_id}

    Args:
        resource_uri: Resource URI (e.g., "cortex://memory/relevant/test.py::::calculate")
        store: VectorStore instance

    Returns:
        Dictionary with list of memory text content in 'memories', 'contents', or 'texts' field
    """
    # Parse URI: cortex://memory/relevant/{symbol_id}
    match = re.match(r"cortex://memory/relevant/(.+)", resource_uri)
    if not match:
        raise ValueError(f"Invalid relevant memories resource URI: {resource_uri}")

    symbol_id = match.group(1)

    # Search for memories anchored to this symbol
    # Use a dummy query vector - we'll filter by anchor_symbol_id
    dummy_vector = generate_embedding("")  # Empty query, will be filtered by anchor
    results = store.search(dummy_vector, limit=100, anchor_symbol_id=symbol_id)

    # Extract text content from results
    memories = [record.text_content for record in results]

    # Return in MCP resource format
    return {
        "memories": memories,
        "contents": memories,
        "texts": memories,
    }
