"""MCP tool implementations for Cortex.

This module implements MCP tools as specified in the planning document:
- search_codebase(query, type): Hybrid FTS5 + Vector search using SearchEngine. Returns Symbol IDs.
- inspect_symbol(symbol_id): Returns actual source code lines (Hydration).
- impact_analysis(symbol_id, depth): Upstream dependency analysis using GraphQuery.get_upstream().
- attach_memory(symbol_id, content): Embeds content and links it to a symbol.
"""

from typing import Dict, Any, Optional

from cortex.core.inspection import inspect_symbol
from cortex.core.search_engine import SearchEngine
from cortex.core.graph import GraphQuery
from cortex.vector.store import VectorStore
from cortex.vector.embeddings import generate_embedding
from cortex.types import VectorRecord


def search_codebase_tool(
    query: str, type: Optional[str], search_engine: SearchEngine
) -> Dict[str, Any]:
    """Search codebase using hybrid FTS5 + vector search.

    Args:
        query: Search query string
        type: Optional symbol type filter (e.g., "function", "class")
        search_engine: SearchEngine instance

    Returns:
        Dictionary with search results in 'results', 'symbols', or 'matches' field
    """
    # Perform hybrid search using SearchEngine
    results = search_engine.search(query, limit=50)

    # Filter by type if specified
    if type:
        results = [r for r in results if r.get("kind") == type]

    # Extract symbol IDs from results
    symbol_ids = []
    for result in results:
        symbol_id = result.get("id") or result.get("anchor_symbol_id")
        if symbol_id:
            symbol_ids.append(symbol_id)

    # Return in MCP tool format
    return {
        "results": symbol_ids,
        "symbols": symbol_ids,
        "matches": symbol_ids,
    }


def inspect_symbol_tool(symbol_id: str, conn) -> Dict[str, Any]:
    """Inspect a symbol and return its full source code (hydration).

    Args:
        symbol_id: The unique ID of the symbol
        conn: SQLite database connection

    Returns:
        Dictionary with symbol code in 'code', 'contents', or 'text' field
    """
    # Get full symbol code using core inspection
    code = inspect_symbol(conn, symbol_id)

    # Return in MCP tool format
    return {
        "code": code,
        "contents": code,
        "text": code,
    }


def impact_analysis_tool(
    symbol_id: str, depth: Optional[int], graph_query: GraphQuery
) -> Dict[str, Any]:
    """Analyze upstream dependencies (who calls this function).

    Args:
        symbol_id: The unique ID of the symbol to analyze
        depth: Optional maximum depth to traverse (default: 2 per spec)
        graph_query: GraphQuery instance

    Returns:
        Dictionary with list of upstream caller symbol IDs in 'impact', 'symbols', or 'downstream' field
    """
    # Perform upstream analysis using GraphQuery
    # Note: depth defaults to 2 per spec
    effective_depth = depth if depth is not None else 2
    upstream_symbols = graph_query.get_upstream(symbol_id, depth=effective_depth)

    # Return in MCP tool format
    return {
        "impact": upstream_symbols,
        "symbols": upstream_symbols,
        "downstream": upstream_symbols,  # Keep for backward compatibility
    }


def attach_memory_tool(symbol_id: str, content: str, store: VectorStore) -> Dict[str, Any]:
    """Attach a memory (semantic note) to a symbol.

    Embeds the content and links it to the symbol ID in the vector store.

    Args:
        symbol_id: The unique ID of the symbol to attach memory to
        content: The memory text content
        store: VectorStore instance

    Returns:
        Dictionary with success status in 'success' or 'status' field
    """
    # Generate embedding for the content
    vector = generate_embedding(content)

    # Create vector record anchored to symbol
    record = VectorRecord(
        vector=vector,
        text_content=content,
        anchor_symbol_id=symbol_id,
    )

    # Insert into vector store
    store.insert(record)

    # Return success status
    return {
        "success": True,
        "status": "success",
    }
