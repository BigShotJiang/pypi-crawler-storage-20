"""Skeleton generation for code files."""

from cortex.skeleton.generator import SkeletonGeneratorImpl
from cortex.types import SkeletonGenerator

__all__ = ["SkeletonGeneratorImpl", "SkeletonGenerator"]
