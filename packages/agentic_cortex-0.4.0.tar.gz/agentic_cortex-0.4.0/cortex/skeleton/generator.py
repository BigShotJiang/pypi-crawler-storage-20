"""Skeleton code generator.

This module implements skeleton generation: parsing AST, extracting definitions,
preserving signatures/docstrings/decorators, and replacing bodies with .../pass.
"""

from typing import List, Set
import tree_sitter_python as tspython
from tree_sitter import Language, Parser as TSParser, Node

from cortex.types import Symbol, SkeletonGenerator


class SkeletonGeneratorImpl:
    """Skeleton generator implementation for Python.

    Generates skeleton code by preserving signatures, docstrings, and decorators,
    but replacing function bodies with '...' and class bodies with 'pass' (or structured).
    """

    def __init__(self):
        """Initialize the skeleton generator."""
        PY_LANGUAGE = Language(tspython.language())
        self.parser = TSParser(PY_LANGUAGE)

    def generate(self, symbols: List[Symbol], source: str) -> str:
        """Generate skeleton code from symbols.

        Args:
            symbols: List of symbols to include in skeleton
            source: Original source code for reconstruction

        Returns:
            Skeleton code string with bodies replaced by ... or pass
        """
        # Parse source to get AST
        tree = self.parser.parse(bytes(source, "utf8"))
        root = tree.root_node

        # Create a map of (start_line, kind) -> symbol for matching
        symbol_map: dict[tuple[int, str], Symbol] = {}
        for symbol in symbols:
            key = (symbol.start_line, symbol.kind)
            symbol_map[key] = symbol

        # Modify AST to strip bodies
        modified_lines = self._process_node(root, source, symbol_map, {})

        # Reconstruct code from modified lines
        return self._reconstruct_code(source, modified_lines)

    def _process_node(
        self,
        node: Node,
        source: str,
        symbol_map: dict[tuple[int, str], Symbol],
        modified_lines: dict,
    ) -> dict:
        """Process a node and its children, marking lines to modify.

        Args:
            node: Tree-sitter node to process
            source: Original source code
            symbol_map: Dictionary mapping (start_line, kind) to Symbol
            modified_lines: Dictionary mapping line numbers to replacement text

        Returns:
            Updated modified_lines dictionary
        """
        node_start_line = node.start_point[0] + 1  # Convert to 1-indexed

        if node.type == "function_definition":
            # Check if this function matches a symbol
            kind = "method" if self._is_in_class(node) else "function"
            key = (node_start_line, kind)
            if key in symbol_map:
                self._strip_function_body(node, source, modified_lines)

        elif node.type == "class_definition":
            # Check if this class matches a symbol
            key = (node_start_line, "class")
            if key in symbol_map:
                # Strip method bodies within this class
                self._strip_class_body(node, source, symbol_map, modified_lines)

        # Process children
        for child in node.children:
            self._process_node(child, source, symbol_map, modified_lines)

        return modified_lines

    def _is_in_class(self, node: Node) -> bool:
        """Check if a function node is inside a class.

        Args:
            node: function_definition node

        Returns:
            True if function is inside a class
        """
        current = node.parent
        while current:
            if current.type == "class_definition":
                return True
            current = current.parent
        return False

    def _strip_function_body(self, node: Node, source: str, modified_lines: dict) -> None:
        """Strip function body and replace with '...', preserving docstring and nested definitions.

        Args:
            node: function_definition node
            source: Original source code
            modified_lines: Dictionary to update with line modifications
        """
        # Find the block node (body)
        block_node = None
        for child in node.children:
            if child.type == "block":
                block_node = child
                break

        if not block_node:
            return

        # Get the indentation of the function definition
        func_start_line = node.start_point[0]
        func_line = source.split("\n")[func_start_line]
        indent = len(func_line) - len(func_line.lstrip())
        indent_str = " " * (indent + 4)  # Standard Python indent is 4 spaces

        # Check if first statement in body is a docstring
        docstring_node = None
        body_content_start_line = block_node.start_point[0] + 1
        body_end_line = block_node.end_point[0] + 1

        # Find nested function/class definitions to preserve
        nested_defs = []
        for child in block_node.children:
            if child.type in ("function_definition", "class_definition"):
                nested_defs.append(child)

        # Look for docstring (expression_statement with string)
        for child in block_node.children:
            if child.type == "expression_statement":
                for expr_child in child.children:
                    if expr_child.type == "string":
                        docstring_node = expr_child
                        break
                if docstring_node:
                    break

        # Collect line ranges to preserve (docstring + nested definitions)
        preserve_ranges = []
        if docstring_node:
            preserve_ranges.append((docstring_node.start_point[0] + 1, docstring_node.end_point[0] + 1))
        for nested_def in nested_defs:
            preserve_ranges.append((nested_def.start_point[0] + 1, nested_def.end_point[0] + 1))

        # Sort preserve ranges by start line
        preserve_ranges.sort()

        # Mark lines for modification
        current_line = body_content_start_line
        preserve_idx = 0

        while current_line <= body_end_line:
            # Check if this line should be preserved
            should_preserve = False
            if preserve_idx < len(preserve_ranges):
                preserve_start, preserve_end = preserve_ranges[preserve_idx]
                if preserve_start <= current_line <= preserve_end:
                    should_preserve = True
                    if current_line == preserve_end:
                        preserve_idx += 1
                elif current_line > preserve_end:
                    preserve_idx += 1

            if not should_preserve:
                # Check if this is the first non-preserved line (should get "...")
                # Only add "..." if we haven't added it yet for this body
                prev_preserved = False
                if preserve_ranges:
                    for p_start, p_end in preserve_ranges:
                        if current_line - 1 >= p_start and current_line - 1 <= p_end:
                            prev_preserved = True
                            break

                if current_line == body_content_start_line or (prev_preserved and current_line > body_content_start_line):
                    # First line of body or first line after preserved content
                    modified_lines[current_line] = f"{indent_str}..."
                else:
                    # Delete this line
                    modified_lines[current_line] = None

            current_line += 1

        # If no preserved content and no modifications yet, add "..." at start
        if not preserve_ranges and body_content_start_line not in modified_lines:
            modified_lines[body_content_start_line] = f"{indent_str}..."
            for line_num in range(body_content_start_line + 1, body_end_line + 1):
                modified_lines[line_num] = None

    def _strip_class_body(
        self,
        node: Node,
        source: str,
        symbol_map: dict[tuple[int, str], Symbol],
        modified_lines: dict,
    ) -> None:
        """Strip class body, preserving method signatures but stripping bodies.

        Args:
            node: class_definition node
            source: Original source code
            symbol_map: Dictionary mapping (start_line, kind) to Symbol
            modified_lines: Dictionary to update with line modifications
        """
        # Find block node (class body)
        block_node = None
        for child in node.children:
            if child.type == "block":
                block_node = child
                break

        if not block_node:
            return

        # Process each statement in the class body
        for child in block_node.children:
            if child.type == "function_definition":
                # Check if this method matches a symbol
                method_start_line = child.start_point[0] + 1
                key = (method_start_line, "method")
                if key in symbol_map:
                    # This is a method - strip its body
                    self._strip_function_body(child, source, modified_lines)
            # For other statements (assignments, etc.), keep them as-is

    def _reconstruct_code(self, source: str, modified_lines: dict) -> str:
        """Reconstruct code from source with modifications.

        Args:
            source: Original source code
            modified_lines: Dictionary mapping line numbers (1-indexed) to replacement text or None

        Returns:
            Reconstructed skeleton code
        """
        lines = source.split("\n")
        result_lines = []

        for i, line in enumerate(lines):
            line_num = i + 1  # Convert to 1-indexed

            if line_num in modified_lines:
                replacement = modified_lines[line_num]
                if replacement is None:
                    # Skip this line (deleted)
                    continue
                else:
                    # Replace with modified line
                    result_lines.append(replacement)
            else:
                # Keep original line
                result_lines.append(line)

        return "\n".join(result_lines)
