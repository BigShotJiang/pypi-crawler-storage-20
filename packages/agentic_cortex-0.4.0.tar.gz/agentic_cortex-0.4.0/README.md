# Agentic Cortex

Local-first agentic memory architecture for coding agents.

[![PyPI version](https://badge.fury.io/py/agentic-cortex.svg)](https://badge.fury.io/py/agentic-cortex)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

Cortex eliminates token churn by replacing full-codebase context dumps with a deterministic, multi-tiered retrieval system:

- **Tier 1 (SQLite)**: Structural map of symbols, files, and hierarchy
- **Tier 2 (SQLite)**: Relationship graph for dependency traversal
- **Tier 3 (LanceDB)**: Semantic memory store with vector embeddings

## Installation

Install as a CLI tool (recommended):

```bash
uv tool install agentic-cortex
```

Or with pipx:

```bash
pipx install agentic-cortex
```

This makes the `cortex` command available system-wide.

### Development Setup

```bash
git clone https://github.com/noematicsllc/memory_layer.git
cd memory_layer
uv sync
```

### PyTorch Configuration

Cortex uses sentence-transformers for embeddings, which requires PyTorch. By default, CUDA PyTorch is installed. For other setups:

**AMD GPU (ROCm):**
```bash
uv pip install --index-url https://download.pytorch.org/whl/rocm6.2 torch
```

**CPU-only:**
```bash
uv pip install --index-url https://download.pytorch.org/whl/cpu torch
```

## Quickstart

Initialize Cortex in your project:

```bash
cd my-repo
cortex init
```

Start the Cortex MCP server:

```bash
cortex start
```

## MCP Configuration

Add Cortex to your MCP client configuration (e.g., `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "cortex": {
      "command": "cortex",
      "args": ["start"]
    }
  }
}
```

## Development

Run the MCP server directly:

```bash
uv run python -m cortex.cli start
```

## Architecture

See the implementation plan for detailed architecture documentation.
