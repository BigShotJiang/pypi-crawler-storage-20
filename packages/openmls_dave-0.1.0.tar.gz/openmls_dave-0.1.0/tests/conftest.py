"""
Pytest configuration and fixtures.
"""

import pytest

from openmls_dave import (
    DaveSession,
    KeyRatchet,
    MlsClient,
)
from openmls_dave import MlsGroupWrapper as MlsGroup
from openmls_dave import (
    SFrameContext,
)


def to_bytes(data):
    """Convert data to bytes if it's a list."""
    if isinstance(data, list):
        return bytes(data)
    return data


@pytest.fixture
def client_alice():
    """Create an MLS client for Alice."""
    return MlsClient.from_string("alice")


@pytest.fixture
def client_bob():
    """Create an MLS client for Bob."""
    return MlsClient.from_string("bob")


@pytest.fixture
def client_charlie():
    """Create an MLS client for Charlie."""
    return MlsClient.from_string("charlie")


@pytest.fixture
def group_id():
    """Generate a test group ID."""
    return b"test-group-12345"


@pytest.fixture
def base_key():
    """Generate a test base key."""
    return bytes(range(32))


@pytest.fixture
def alice_group(client_alice, group_id):
    """Create a group with Alice as the initial member."""
    return MlsGroup(client_alice, group_id)


@pytest.fixture
def sframe_context(base_key):
    """Create an SFrame context for testing."""
    return SFrameContext(base_key, key_id=1)


@pytest.fixture
def key_ratchet(base_key):
    """Create a key ratchet for testing."""
    return KeyRatchet(base_key)


@pytest.fixture
def session_alice():
    """Create a DAVE session for Alice."""
    return DaveSession(user_id=12345)


@pytest.fixture
def session_bob():
    """Create a DAVE session for Bob."""
    return DaveSession(user_id=67890)


@pytest.fixture
def session_charlie():
    """Create a DAVE session for Charlie."""
    return DaveSession(user_id=11111)


@pytest.fixture
def sample_audio_frame():
    """Generate sample audio frame data."""
    return b"\x00" * 960  # 20ms of silence at 48kHz mono


@pytest.fixture
def sample_video_frame():
    """Generate sample video frame data."""
    return bytes(range(256)) * 100  # ~25KB frame
