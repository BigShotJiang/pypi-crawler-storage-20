"""
Tests for MLS client functionality.
"""

import pytest

from openmls_dave import MlsClient


def to_bytes(data):
    """Convert data to bytes if it's a list."""
    if isinstance(data, list):
        return bytes(data)
    return data


class TestMlsClient:
    """Tests for MlsClient class."""

    def test_create_client_from_bytes(self):
        """Test creating a client with bytes identity."""
        identity = b"user123"
        client = MlsClient(identity)

        assert to_bytes(client.identity) == identity

    def test_create_client_from_string(self):
        """Test creating a client with string identity."""
        identity = "alice"
        client = MlsClient.from_string(identity)

        assert to_bytes(client.identity) == identity.encode()
        assert client.identity_str == identity

    def test_client_has_public_key(self, client_alice):
        """Test that client has a public key."""
        public_key = to_bytes(client_alice.public_key)

        assert isinstance(public_key, bytes)
        assert len(public_key) > 0

    def test_different_clients_have_different_keys(self, client_alice, client_bob):
        """Test that different clients have different keys."""
        assert to_bytes(client_alice.public_key) != to_bytes(client_bob.public_key)

    def test_generate_key_package(self, client_alice):
        """Test generating a key package."""
        key_package = to_bytes(client_alice.generate_key_package())

        assert isinstance(key_package, bytes)
        assert len(key_package) > 0

    def test_generate_multiple_key_packages(self, client_alice):
        """Test generating multiple key packages."""
        packages = client_alice.generate_key_packages(3)

        assert len(packages) == 3
        # Each package should be unique
        assert len(set(tuple(to_bytes(p)) for p in packages)) == 3

    def test_client_repr(self, client_alice):
        """Test client string representation."""
        repr_str = repr(client_alice)

        assert "MlsClient" in repr_str
        assert "alice" in repr_str

    def test_empty_identity(self):
        """Test creating a client with empty identity."""
        client = MlsClient(b"")
        assert to_bytes(client.identity) == b""

    def test_unicode_identity(self):
        """Test creating a client with unicode identity."""
        identity = "用户123"
        client = MlsClient.from_string(identity)

        assert to_bytes(client.identity) == identity.encode("utf-8")

    def test_binary_identity(self):
        """Test creating a client with arbitrary binary identity."""
        identity = bytes([0x00, 0xFF, 0x80, 0x7F])
        client = MlsClient(identity)

        assert to_bytes(client.identity) == identity
