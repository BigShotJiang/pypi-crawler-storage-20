"""
OpenMLS DAVE - Discord Audio/Video End-to-end Encryption

A Python library providing MLS (Message Layer Security) and SFrame bindings
for implementing Discord's DAVE protocol.
"""

from openmls_dave._lib import (
    # Client
    MlsClient,
    # Group
    MlsGroupWrapper,
    CommitResult,
    ProcessedMessage,
    # SFrame
    SFrameContext,
    SFrameHeader,
    SFrameMultiContext,
    # Key Ratchet
    KeyRatchet,
    SenderKeyRatchet,
    KeyRatchetManager,
    # Constants
    DAVE_PROTOCOL_VERSION,
    SFRAME_LABEL,
    MEDIA_KEY_LENGTH,
)

from openmls_dave.session import DaveSession, DaveParticipant, SessionState

__version__ = "0.1.0"
__all__ = [
    # Core classes
    "MlsClient",
    "MlsGroupWrapper",
    "CommitResult",
    "ProcessedMessage",
    # SFrame
    "SFrameContext",
    "SFrameHeader",
    "SFrameMultiContext",
    # Key management
    "KeyRatchet",
    "SenderKeyRatchet",
    "KeyRatchetManager",
    # High-level API
    "DaveSession",
    "DaveParticipant",
    "SessionState",
    # Constants
    "DAVE_PROTOCOL_VERSION",
    "SFRAME_LABEL",
    "MEDIA_KEY_LENGTH",
]
