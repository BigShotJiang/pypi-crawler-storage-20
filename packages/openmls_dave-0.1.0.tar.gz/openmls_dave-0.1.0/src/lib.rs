mod client;
mod error;
mod group;
mod key_ratchet;
mod sframe;

use pyo3::prelude::*;

pub use client::MlsClient;
pub use group::{CommitResult, MlsGroupWrapper, ProcessedMessage};
pub use key_ratchet::{KeyRatchet, KeyRatchetManager, SenderKeyRatchet};
pub use sframe::{SFrameContext, SFrameHeader, SFrameMultiContext};

/// OpenMLS DAVE - Discord Audio/Video End-to-end Encryption bindings
#[pymodule]
fn _lib(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Client
    m.add_class::<MlsClient>()?;

    // Group
    m.add_class::<MlsGroupWrapper>()?;
    m.add_class::<CommitResult>()?;
    m.add_class::<ProcessedMessage>()?;

    // SFrame
    m.add_class::<SFrameContext>()?;
    m.add_class::<SFrameHeader>()?;
    m.add_class::<SFrameMultiContext>()?;

    // Key Ratchet
    m.add_class::<KeyRatchet>()?;
    m.add_class::<SenderKeyRatchet>()?;
    m.add_class::<KeyRatchetManager>()?;

    // Constants
    m.add("DAVE_PROTOCOL_VERSION", group::DAVE_PROTOCOL_VERSION)?;
    m.add("SFRAME_LABEL", group::SFRAME_LABEL)?;
    m.add("MEDIA_KEY_LENGTH", group::MEDIA_KEY_LENGTH)?;

    Ok(())
}