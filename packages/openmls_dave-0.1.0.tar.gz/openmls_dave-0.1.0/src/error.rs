use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum DaveError {
    #[error("MLS error: {0}")]
    Mls(String),

    #[error("Crypto error: {0}")]
    Crypto(String),

    #[error("Serialization error: {0}")]
    Serialization(String),

    #[error("Invalid state: {0}")]
    InvalidState(String),

    #[error("Invalid key ID: {0}")]
    InvalidKeyId(u64),

    #[error("Decryption failed: {0}")]
    DecryptionFailed(String),

    #[error("Invalid frame format: {0}")]
    InvalidFrame(String),
}

impl From<DaveError> for PyErr {
    fn from(err: DaveError) -> PyErr {
        match err {
            DaveError::InvalidKeyId(_) | DaveError::InvalidFrame(_) => {
                PyValueError::new_err(err.to_string())
            }
            _ => PyRuntimeError::new_err(err.to_string()),
        }
    }
}

pub type DaveResult<T> = Result<T, DaveError>;