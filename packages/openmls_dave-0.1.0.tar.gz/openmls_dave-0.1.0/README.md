# openmls_dave
My own implementation of [Discord Audio & Video End-to-End Encryption (DAVE) Protocol](https://daveprotocol.com/)
, using [OpenMLS](https://openmls.tech/), Python and Rust.

I don't intentionally try to use this mainstream, this project mostly will serve as a learning
experience with Rust, and OpenMLS.

This uses [uv](https://github.com/astral-sh/uv) extensively, and uses [ty](https://github.com/astral-sh/ty) to typecheck. 
This also uses maturin to compile Rust bindings, alongside PyO3 to interface with the py/pyi code.

~~(Admittedly, because of how my computer was setup I had to redo git credentials and I somehow nuked commit times
for the first three commits after initial, but I digress)~~

This also uses black and isort for coding style.

There's no official documentation yet; this is a WIP (whenever I have time available)
(I still need to look into DAVE's voice opcodes, etc.), and this README.md will be redone
(eventually)

However, installation of this library is:

```bash
pip install openmls_dave
```

## Features

- MLS (RFC 9420) group key agreement
- SFrame media encryption
- Forward secrecy on membership changes
- Full type hints (via .pyi)
