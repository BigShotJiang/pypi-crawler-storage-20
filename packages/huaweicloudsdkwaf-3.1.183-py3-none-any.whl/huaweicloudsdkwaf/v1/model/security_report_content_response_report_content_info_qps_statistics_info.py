# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class SecurityReportContentResponseReportContentInfoQpsStatisticsInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'average_info_list': 'list[SecurityReportContentResponseReportContentInfoQpsStatisticsInfoAverageInfoList]',
        'peak_info_list': 'list[SecurityReportContentResponseReportContentInfoQpsStatisticsInfoPeakInfoList]'
    }

    attribute_map = {
        'average_info_list': 'average_info_list',
        'peak_info_list': 'peak_info_list'
    }

    def __init__(self, average_info_list=None, peak_info_list=None):
        r"""SecurityReportContentResponseReportContentInfoQpsStatisticsInfo

        The model defined in huaweicloud sdk

        :param average_info_list: **参数解释：** 平均QPS统计列表，包含各维度按时间线的平均QPS数据。 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及
        :type average_info_list: list[:class:`huaweicloudsdkwaf.v1.SecurityReportContentResponseReportContentInfoQpsStatisticsInfoAverageInfoList`]
        :param peak_info_list: **参数解释：** 峰值QPS统计列表，包含各维度按时间线的峰值QPS数据。 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及
        :type peak_info_list: list[:class:`huaweicloudsdkwaf.v1.SecurityReportContentResponseReportContentInfoQpsStatisticsInfoPeakInfoList`]
        """
        
        

        self._average_info_list = None
        self._peak_info_list = None
        self.discriminator = None

        if average_info_list is not None:
            self.average_info_list = average_info_list
        if peak_info_list is not None:
            self.peak_info_list = peak_info_list

    @property
    def average_info_list(self):
        r"""Gets the average_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.

        **参数解释：** 平均QPS统计列表，包含各维度按时间线的平均QPS数据。 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :return: The average_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.
        :rtype: list[:class:`huaweicloudsdkwaf.v1.SecurityReportContentResponseReportContentInfoQpsStatisticsInfoAverageInfoList`]
        """
        return self._average_info_list

    @average_info_list.setter
    def average_info_list(self, average_info_list):
        r"""Sets the average_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.

        **参数解释：** 平均QPS统计列表，包含各维度按时间线的平均QPS数据。 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :param average_info_list: The average_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.
        :type average_info_list: list[:class:`huaweicloudsdkwaf.v1.SecurityReportContentResponseReportContentInfoQpsStatisticsInfoAverageInfoList`]
        """
        self._average_info_list = average_info_list

    @property
    def peak_info_list(self):
        r"""Gets the peak_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.

        **参数解释：** 峰值QPS统计列表，包含各维度按时间线的峰值QPS数据。 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :return: The peak_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.
        :rtype: list[:class:`huaweicloudsdkwaf.v1.SecurityReportContentResponseReportContentInfoQpsStatisticsInfoPeakInfoList`]
        """
        return self._peak_info_list

    @peak_info_list.setter
    def peak_info_list(self, peak_info_list):
        r"""Sets the peak_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.

        **参数解释：** 峰值QPS统计列表，包含各维度按时间线的峰值QPS数据。 **约束限制：** 不涉及 **取值范围：** 不涉及 **默认取值：** 不涉及

        :param peak_info_list: The peak_info_list of this SecurityReportContentResponseReportContentInfoQpsStatisticsInfo.
        :type peak_info_list: list[:class:`huaweicloudsdkwaf.v1.SecurityReportContentResponseReportContentInfoQpsStatisticsInfoPeakInfoList`]
        """
        self._peak_info_list = peak_info_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SecurityReportContentResponseReportContentInfoQpsStatisticsInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
