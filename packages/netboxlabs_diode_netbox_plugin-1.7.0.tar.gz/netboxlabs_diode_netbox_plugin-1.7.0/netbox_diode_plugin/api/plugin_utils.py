"""Diode plugin helpers."""

# Generated code. DO NOT EDIT.
# Timestamp: 2026-01-12 17:44:14Z

from dataclasses import dataclass
import datetime
import decimal
from functools import lru_cache
import json
import logging
import re
from typing import Type

from core.models import ObjectType as NetBoxType
from django.contrib.contenttypes.models import ContentType
from django.db import models
import netaddr
from rest_framework.exceptions import ValidationError

logger = logging.getLogger(__name__)


@lru_cache(maxsize=256)
def get_object_type_model(object_type: str) -> Type[models.Model]:
    """Get the model class for a given object type."""
    app_label, model_name = object_type.split(".")
    object_content_type = NetBoxType.objects.get_by_natural_key(app_label, model_name)
    return object_content_type.model_class()


@lru_cache(maxsize=256)
def get_object_type(model_class: Type[models.Model]) -> str:
    """Get the object type for a given model class."""
    content_type = ContentType.objects.get_for_model(model_class)
    return content_type.app_label + "." + content_type.model


@lru_cache(maxsize=256)
def content_type_id(object_type: str) -> int:
    """Get the content type id for a given object type."""
    app_label, model_name = object_type.split(".")
    object_content_type = NetBoxType.objects.get_by_natural_key(app_label, model_name)
    return object_content_type.id


@dataclass
class RefInfo:
    object_type: str
    field_name: str
    is_generic: bool = False
    is_many: bool = False


CUSTOM_FIELD_OBJECT_REFERENCE_TYPE = "diode.custom_field_object_reference"

_JSON_REF_INFO = {
    "diode.custom_field_object_reference": {
        "asn": RefInfo(object_type="ipam.asn", field_name="object", is_generic=True),
        "asn_range": RefInfo(
            object_type="ipam.asnrange", field_name="object", is_generic=True
        ),
        "aggregate": RefInfo(
            object_type="ipam.aggregate", field_name="object", is_generic=True
        ),
        "cable": RefInfo(
            object_type="dcim.cable", field_name="object", is_generic=True
        ),
        "cable_path": RefInfo(
            object_type="dcim.cablepath", field_name="object", is_generic=True
        ),
        "cable_termination": RefInfo(
            object_type="dcim.cabletermination", field_name="object", is_generic=True
        ),
        "circuit": RefInfo(
            object_type="circuits.circuit", field_name="object", is_generic=True
        ),
        "circuit_group": RefInfo(
            object_type="circuits.circuitgroup", field_name="object", is_generic=True
        ),
        "circuit_group_assignment": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="object",
            is_generic=True,
        ),
        "circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="object",
            is_generic=True,
        ),
        "circuit_type": RefInfo(
            object_type="circuits.circuittype", field_name="object", is_generic=True
        ),
        "cluster": RefInfo(
            object_type="virtualization.cluster", field_name="object", is_generic=True
        ),
        "cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="object",
            is_generic=True,
        ),
        "cluster_type": RefInfo(
            object_type="virtualization.clustertype",
            field_name="object",
            is_generic=True,
        ),
        "console_port": RefInfo(
            object_type="dcim.consoleport", field_name="object", is_generic=True
        ),
        "console_server_port": RefInfo(
            object_type="dcim.consoleserverport", field_name="object", is_generic=True
        ),
        "contact": RefInfo(
            object_type="tenancy.contact", field_name="object", is_generic=True
        ),
        "contact_assignment": RefInfo(
            object_type="tenancy.contactassignment",
            field_name="object",
            is_generic=True,
        ),
        "contact_group": RefInfo(
            object_type="tenancy.contactgroup", field_name="object", is_generic=True
        ),
        "contact_role": RefInfo(
            object_type="tenancy.contactrole", field_name="object", is_generic=True
        ),
        "device": RefInfo(
            object_type="dcim.device", field_name="object", is_generic=True
        ),
        "device_bay": RefInfo(
            object_type="dcim.devicebay", field_name="object", is_generic=True
        ),
        "device_role": RefInfo(
            object_type="dcim.devicerole", field_name="object", is_generic=True
        ),
        "device_type": RefInfo(
            object_type="dcim.devicetype", field_name="object", is_generic=True
        ),
        "fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="object", is_generic=True
        ),
        "fhrp_group_assignment": RefInfo(
            object_type="ipam.fhrpgroupassignment", field_name="object", is_generic=True
        ),
        "front_port": RefInfo(
            object_type="dcim.frontport", field_name="object", is_generic=True
        ),
        "ike_policy": RefInfo(
            object_type="vpn.ikepolicy", field_name="object", is_generic=True
        ),
        "ike_proposal": RefInfo(
            object_type="vpn.ikeproposal", field_name="object", is_generic=True
        ),
        "ip_address": RefInfo(
            object_type="ipam.ipaddress", field_name="object", is_generic=True
        ),
        "ip_range": RefInfo(
            object_type="ipam.iprange", field_name="object", is_generic=True
        ),
        "ip_sec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="object", is_generic=True
        ),
        "ip_sec_profile": RefInfo(
            object_type="vpn.ipsecprofile", field_name="object", is_generic=True
        ),
        "ip_sec_proposal": RefInfo(
            object_type="vpn.ipsecproposal", field_name="object", is_generic=True
        ),
        "interface": RefInfo(
            object_type="dcim.interface", field_name="object", is_generic=True
        ),
        "inventory_item": RefInfo(
            object_type="dcim.inventoryitem", field_name="object", is_generic=True
        ),
        "inventory_item_role": RefInfo(
            object_type="dcim.inventoryitemrole", field_name="object", is_generic=True
        ),
        "l2vpn": RefInfo(object_type="vpn.l2vpn", field_name="object", is_generic=True),
        "l2vpn_termination": RefInfo(
            object_type="vpn.l2vpntermination", field_name="object", is_generic=True
        ),
        "location": RefInfo(
            object_type="dcim.location", field_name="object", is_generic=True
        ),
        "mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="object", is_generic=True
        ),
        "manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="object", is_generic=True
        ),
        "module": RefInfo(
            object_type="dcim.module", field_name="object", is_generic=True
        ),
        "module_bay": RefInfo(
            object_type="dcim.modulebay", field_name="object", is_generic=True
        ),
        "module_type": RefInfo(
            object_type="dcim.moduletype", field_name="object", is_generic=True
        ),
        "platform": RefInfo(
            object_type="dcim.platform", field_name="object", is_generic=True
        ),
        "power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="object", is_generic=True
        ),
        "power_outlet": RefInfo(
            object_type="dcim.poweroutlet", field_name="object", is_generic=True
        ),
        "power_panel": RefInfo(
            object_type="dcim.powerpanel", field_name="object", is_generic=True
        ),
        "power_port": RefInfo(
            object_type="dcim.powerport", field_name="object", is_generic=True
        ),
        "prefix": RefInfo(
            object_type="ipam.prefix", field_name="object", is_generic=True
        ),
        "provider": RefInfo(
            object_type="circuits.provider", field_name="object", is_generic=True
        ),
        "provider_account": RefInfo(
            object_type="circuits.provideraccount", field_name="object", is_generic=True
        ),
        "provider_network": RefInfo(
            object_type="circuits.providernetwork", field_name="object", is_generic=True
        ),
        "rir": RefInfo(object_type="ipam.rir", field_name="object", is_generic=True),
        "rack": RefInfo(object_type="dcim.rack", field_name="object", is_generic=True),
        "rack_reservation": RefInfo(
            object_type="dcim.rackreservation", field_name="object", is_generic=True
        ),
        "rack_role": RefInfo(
            object_type="dcim.rackrole", field_name="object", is_generic=True
        ),
        "rack_type": RefInfo(
            object_type="dcim.racktype", field_name="object", is_generic=True
        ),
        "rear_port": RefInfo(
            object_type="dcim.rearport", field_name="object", is_generic=True
        ),
        "region": RefInfo(
            object_type="dcim.region", field_name="object", is_generic=True
        ),
        "role": RefInfo(object_type="ipam.role", field_name="object", is_generic=True),
        "route_target": RefInfo(
            object_type="ipam.routetarget", field_name="object", is_generic=True
        ),
        "service": RefInfo(
            object_type="ipam.service", field_name="object", is_generic=True
        ),
        "site": RefInfo(object_type="dcim.site", field_name="object", is_generic=True),
        "site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="object", is_generic=True
        ),
        "tag": RefInfo(object_type="extras.tag", field_name="object", is_generic=True),
        "tenant": RefInfo(
            object_type="tenancy.tenant", field_name="object", is_generic=True
        ),
        "tenant_group": RefInfo(
            object_type="tenancy.tenantgroup", field_name="object", is_generic=True
        ),
        "tunnel": RefInfo(
            object_type="vpn.tunnel", field_name="object", is_generic=True
        ),
        "tunnel_group": RefInfo(
            object_type="vpn.tunnelgroup", field_name="object", is_generic=True
        ),
        "tunnel_termination": RefInfo(
            object_type="vpn.tunneltermination", field_name="object", is_generic=True
        ),
        "vlan": RefInfo(object_type="ipam.vlan", field_name="object", is_generic=True),
        "vlan_group": RefInfo(
            object_type="ipam.vlangroup", field_name="object", is_generic=True
        ),
        "vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="object",
            is_generic=True,
        ),
        "vlan_translation_rule": RefInfo(
            object_type="ipam.vlantranslationrule", field_name="object", is_generic=True
        ),
        "vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="object",
            is_generic=True,
        ),
        "vrf": RefInfo(object_type="ipam.vrf", field_name="object", is_generic=True),
        "virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis", field_name="object", is_generic=True
        ),
        "virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit", field_name="object", is_generic=True
        ),
        "virtual_circuit_termination": RefInfo(
            object_type="circuits.virtualcircuittermination",
            field_name="object",
            is_generic=True,
        ),
        "virtual_circuit_type": RefInfo(
            object_type="circuits.virtualcircuittype",
            field_name="object",
            is_generic=True,
        ),
        "virtual_device_context": RefInfo(
            object_type="dcim.virtualdevicecontext",
            field_name="object",
            is_generic=True,
        ),
        "virtual_disk": RefInfo(
            object_type="virtualization.virtualdisk",
            field_name="object",
            is_generic=True,
        ),
        "virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="object",
            is_generic=True,
        ),
        "wireless_lan": RefInfo(
            object_type="wireless.wirelesslan", field_name="object", is_generic=True
        ),
        "wireless_lan_group": RefInfo(
            object_type="wireless.wirelesslangroup",
            field_name="object",
            is_generic=True,
        ),
        "wireless_link": RefInfo(
            object_type="wireless.wirelesslink", field_name="object", is_generic=True
        ),
        "custom_field": RefInfo(
            object_type="extras.customfield", field_name="object", is_generic=True
        ),
        "custom_field_choice_set": RefInfo(
            object_type="extras.customfieldchoiceset",
            field_name="object",
            is_generic=True,
        ),
        "journal_entry": RefInfo(
            object_type="extras.journalentry", field_name="object", is_generic=True
        ),
        "module_type_profile": RefInfo(
            object_type="dcim.moduletypeprofile", field_name="object", is_generic=True
        ),
        "custom_link": RefInfo(
            object_type="extras.customlink", field_name="object", is_generic=True
        ),
        "owner": RefInfo(
            object_type="users.owner", field_name="object", is_generic=True
        ),
        "owner_group": RefInfo(
            object_type="users.ownergroup", field_name="object", is_generic=True
        ),
    },
    "circuits.circuit": {
        "assignments": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="assignments",
            is_many=True,
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "provider": RefInfo(object_type="circuits.provider", field_name="provider"),
        "provider_account": RefInfo(
            object_type="circuits.provideraccount", field_name="provider_account"
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "type": RefInfo(object_type="circuits.circuittype", field_name="type"),
    },
    "circuits.circuitgroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "circuits.circuitgroupassignment": {
        "group": RefInfo(object_type="circuits.circuitgroup", field_name="group"),
        "member_circuit": RefInfo(
            object_type="circuits.circuit", field_name="member", is_generic=True
        ),
        "member_virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit", field_name="member", is_generic=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "circuits.circuittermination": {
        "circuit": RefInfo(object_type="circuits.circuit", field_name="circuit"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "termination_location": RefInfo(
            object_type="dcim.location", field_name="termination", is_generic=True
        ),
        "termination_provider_network": RefInfo(
            object_type="circuits.providernetwork",
            field_name="termination",
            is_generic=True,
        ),
        "termination_region": RefInfo(
            object_type="dcim.region", field_name="termination", is_generic=True
        ),
        "termination_site": RefInfo(
            object_type="dcim.site", field_name="termination", is_generic=True
        ),
        "termination_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="termination", is_generic=True
        ),
    },
    "circuits.circuittype": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "circuits.provider": {
        "accounts": RefInfo(
            object_type="circuits.provideraccount", field_name="accounts", is_many=True
        ),
        "asns": RefInfo(object_type="ipam.asn", field_name="asns", is_many=True),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "circuits.provideraccount": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "provider": RefInfo(object_type="circuits.provider", field_name="provider"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "circuits.providernetwork": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "provider": RefInfo(object_type="circuits.provider", field_name="provider"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "circuits.virtualcircuit": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "provider_account": RefInfo(
            object_type="circuits.provideraccount", field_name="provider_account"
        ),
        "provider_network": RefInfo(
            object_type="circuits.providernetwork", field_name="provider_network"
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "type": RefInfo(object_type="circuits.virtualcircuittype", field_name="type"),
    },
    "circuits.virtualcircuittermination": {
        "interface": RefInfo(object_type="dcim.interface", field_name="interface"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit", field_name="virtual_circuit"
        ),
    },
    "circuits.virtualcircuittype": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.cable": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "dcim.cabletermination": {
        "cable": RefInfo(object_type="dcim.cable", field_name="cable"),
        "termination_circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="termination",
            is_generic=True,
        ),
        "termination_console_port": RefInfo(
            object_type="dcim.consoleport", field_name="termination", is_generic=True
        ),
        "termination_console_server_port": RefInfo(
            object_type="dcim.consoleserverport",
            field_name="termination",
            is_generic=True,
        ),
        "termination_front_port": RefInfo(
            object_type="dcim.frontport", field_name="termination", is_generic=True
        ),
        "termination_interface": RefInfo(
            object_type="dcim.interface", field_name="termination", is_generic=True
        ),
        "termination_power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="termination", is_generic=True
        ),
        "termination_power_outlet": RefInfo(
            object_type="dcim.poweroutlet", field_name="termination", is_generic=True
        ),
        "termination_power_port": RefInfo(
            object_type="dcim.powerport", field_name="termination", is_generic=True
        ),
        "termination_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="termination", is_generic=True
        ),
    },
    "dcim.consoleport": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.consoleserverport": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.device": {
        "cluster": RefInfo(object_type="virtualization.cluster", field_name="cluster"),
        "device_type": RefInfo(object_type="dcim.devicetype", field_name="device_type"),
        "location": RefInfo(object_type="dcim.location", field_name="location"),
        "oob_ip": RefInfo(object_type="ipam.ipaddress", field_name="oob_ip"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "platform": RefInfo(object_type="dcim.platform", field_name="platform"),
        "primary_ip4": RefInfo(object_type="ipam.ipaddress", field_name="primary_ip4"),
        "primary_ip6": RefInfo(object_type="ipam.ipaddress", field_name="primary_ip6"),
        "rack": RefInfo(object_type="dcim.rack", field_name="rack"),
        "role": RefInfo(object_type="dcim.devicerole", field_name="role"),
        "site": RefInfo(object_type="dcim.site", field_name="site"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis", field_name="virtual_chassis"
        ),
    },
    "dcim.devicebay": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "installed_device": RefInfo(
            object_type="dcim.device", field_name="installed_device"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.devicerole": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.devicerole", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.devicetype": {
        "default_platform": RefInfo(
            object_type="dcim.platform", field_name="default_platform"
        ),
        "manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="manufacturer"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.frontport": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "rear_port": RefInfo(object_type="dcim.rearport", field_name="rear_port"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.interface": {
        "bridge": RefInfo(object_type="dcim.interface", field_name="bridge"),
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "lag": RefInfo(object_type="dcim.interface", field_name="lag"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.interface", field_name="parent"),
        "primary_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="primary_mac_address"
        ),
        "qinq_svlan": RefInfo(object_type="ipam.vlan", field_name="qinq_svlan"),
        "tagged_vlans": RefInfo(
            object_type="ipam.vlan", field_name="tagged_vlans", is_many=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "untagged_vlan": RefInfo(object_type="ipam.vlan", field_name="untagged_vlan"),
        "vdcs": RefInfo(
            object_type="dcim.virtualdevicecontext", field_name="vdcs", is_many=True
        ),
        "vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="vlan_translation_policy",
        ),
        "vrf": RefInfo(object_type="ipam.vrf", field_name="vrf"),
        "wireless_lans": RefInfo(
            object_type="wireless.wirelesslan", field_name="wireless_lans", is_many=True
        ),
    },
    "dcim.inventoryitem": {
        "component_console_port": RefInfo(
            object_type="dcim.consoleport", field_name="component", is_generic=True
        ),
        "component_console_server_port": RefInfo(
            object_type="dcim.consoleserverport",
            field_name="component",
            is_generic=True,
        ),
        "component_front_port": RefInfo(
            object_type="dcim.frontport", field_name="component", is_generic=True
        ),
        "component_interface": RefInfo(
            object_type="dcim.interface", field_name="component", is_generic=True
        ),
        "component_power_outlet": RefInfo(
            object_type="dcim.poweroutlet", field_name="component", is_generic=True
        ),
        "component_power_port": RefInfo(
            object_type="dcim.powerport", field_name="component", is_generic=True
        ),
        "component_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="component", is_generic=True
        ),
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="manufacturer"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.inventoryitem", field_name="parent"),
        "role": RefInfo(object_type="dcim.inventoryitemrole", field_name="role"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.inventoryitemrole": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.location": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.location", field_name="parent"),
        "site": RefInfo(object_type="dcim.site", field_name="site"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "dcim.macaddress": {
        "assigned_object_interface": RefInfo(
            object_type="dcim.interface", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="assigned_object",
            is_generic=True,
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.manufacturer": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.module": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module_bay": RefInfo(object_type="dcim.modulebay", field_name="module_bay"),
        "module_type": RefInfo(object_type="dcim.moduletype", field_name="module_type"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.modulebay": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "installed_module": RefInfo(
            object_type="dcim.module", field_name="installed_module"
        ),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.moduletype": {
        "manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="manufacturer"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "profile": RefInfo(object_type="dcim.moduletypeprofile", field_name="profile"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.moduletypeprofile": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.platform": {
        "manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="manufacturer"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.platform", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.powerfeed": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "power_panel": RefInfo(object_type="dcim.powerpanel", field_name="power_panel"),
        "rack": RefInfo(object_type="dcim.rack", field_name="rack"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "dcim.poweroutlet": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "power_port": RefInfo(object_type="dcim.powerport", field_name="power_port"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.powerpanel": {
        "location": RefInfo(object_type="dcim.location", field_name="location"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "site": RefInfo(object_type="dcim.site", field_name="site"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.powerport": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.rack": {
        "location": RefInfo(object_type="dcim.location", field_name="location"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "rack_type": RefInfo(object_type="dcim.racktype", field_name="rack_type"),
        "role": RefInfo(object_type="dcim.rackrole", field_name="role"),
        "site": RefInfo(object_type="dcim.site", field_name="site"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "dcim.rackreservation": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "rack": RefInfo(object_type="dcim.rack", field_name="rack"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "dcim.rackrole": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.racktype": {
        "manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="manufacturer"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.rearport": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "module": RefInfo(object_type="dcim.module", field_name="module"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.region": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.region", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.site": {
        "asns": RefInfo(object_type="ipam.asn", field_name="asns", is_many=True),
        "group": RefInfo(object_type="dcim.sitegroup", field_name="group"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "region": RefInfo(object_type="dcim.region", field_name="region"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "dcim.sitegroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="dcim.sitegroup", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.virtualchassis": {
        "master": RefInfo(object_type="dcim.device", field_name="master"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "dcim.virtualdevicecontext": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "primary_ip4": RefInfo(object_type="ipam.ipaddress", field_name="primary_ip4"),
        "primary_ip6": RefInfo(object_type="ipam.ipaddress", field_name="primary_ip6"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "extras.customfield": {
        "choice_set": RefInfo(
            object_type="extras.customfieldchoiceset", field_name="choice_set"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
    },
    "extras.customfieldchoiceset": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
    },
    "extras.customlink": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
    },
    "extras.journalentry": {
        "assigned_object_asn": RefInfo(
            object_type="ipam.asn", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_asn_range": RefInfo(
            object_type="ipam.asnrange", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_aggregate": RefInfo(
            object_type="ipam.aggregate", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_cable": RefInfo(
            object_type="dcim.cable", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_cable_path": RefInfo(
            object_type="dcim.cablepath", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_cable_termination": RefInfo(
            object_type="dcim.cabletermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit": RefInfo(
            object_type="circuits.circuit",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_group": RefInfo(
            object_type="circuits.circuitgroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_group_assignment": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_type": RefInfo(
            object_type="circuits.circuittype",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_cluster": RefInfo(
            object_type="virtualization.cluster",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_cluster_type": RefInfo(
            object_type="virtualization.clustertype",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_console_port": RefInfo(
            object_type="dcim.consoleport",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_console_server_port": RefInfo(
            object_type="dcim.consoleserverport",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_contact": RefInfo(
            object_type="tenancy.contact", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_contact_assignment": RefInfo(
            object_type="tenancy.contactassignment",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_contact_group": RefInfo(
            object_type="tenancy.contactgroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_contact_role": RefInfo(
            object_type="tenancy.contactrole",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_custom_field": RefInfo(
            object_type="extras.customfield",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_custom_field_choice_set": RefInfo(
            object_type="extras.customfieldchoiceset",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_device": RefInfo(
            object_type="dcim.device", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_device_bay": RefInfo(
            object_type="dcim.devicebay", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_device_role": RefInfo(
            object_type="dcim.devicerole", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_device_type": RefInfo(
            object_type="dcim.devicetype", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_fhrp_group_assignment": RefInfo(
            object_type="ipam.fhrpgroupassignment",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_front_port": RefInfo(
            object_type="dcim.frontport", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ike_policy": RefInfo(
            object_type="vpn.ikepolicy", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ike_proposal": RefInfo(
            object_type="vpn.ikeproposal", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_address": RefInfo(
            object_type="ipam.ipaddress", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_range": RefInfo(
            object_type="ipam.iprange", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_sec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_sec_profile": RefInfo(
            object_type="vpn.ipsecprofile",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_ip_sec_proposal": RefInfo(
            object_type="vpn.ipsecproposal",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_interface": RefInfo(
            object_type="dcim.interface", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_inventory_item": RefInfo(
            object_type="dcim.inventoryitem",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_inventory_item_role": RefInfo(
            object_type="dcim.inventoryitemrole",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_journal_entry": RefInfo(
            object_type="extras.journalentry",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_l2vpn": RefInfo(
            object_type="vpn.l2vpn", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_l2vpn_termination": RefInfo(
            object_type="vpn.l2vpntermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_location": RefInfo(
            object_type="dcim.location", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_manufacturer": RefInfo(
            object_type="dcim.manufacturer",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_module": RefInfo(
            object_type="dcim.module", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_module_bay": RefInfo(
            object_type="dcim.modulebay", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_module_type": RefInfo(
            object_type="dcim.moduletype", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_module_type_profile": RefInfo(
            object_type="dcim.moduletypeprofile",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_platform": RefInfo(
            object_type="dcim.platform", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_power_outlet": RefInfo(
            object_type="dcim.poweroutlet",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_power_panel": RefInfo(
            object_type="dcim.powerpanel", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_power_port": RefInfo(
            object_type="dcim.powerport", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_prefix": RefInfo(
            object_type="ipam.prefix", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_provider": RefInfo(
            object_type="circuits.provider",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_provider_account": RefInfo(
            object_type="circuits.provideraccount",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_provider_network": RefInfo(
            object_type="circuits.providernetwork",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_rir": RefInfo(
            object_type="ipam.rir", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rack": RefInfo(
            object_type="dcim.rack", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rack_reservation": RefInfo(
            object_type="dcim.rackreservation",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_rack_role": RefInfo(
            object_type="dcim.rackrole", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rack_type": RefInfo(
            object_type="dcim.racktype", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_region": RefInfo(
            object_type="dcim.region", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_role": RefInfo(
            object_type="ipam.role", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_route_target": RefInfo(
            object_type="ipam.routetarget",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_service": RefInfo(
            object_type="ipam.service", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_site": RefInfo(
            object_type="dcim.site", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tag": RefInfo(
            object_type="extras.tag", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tenant": RefInfo(
            object_type="tenancy.tenant", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tenant_group": RefInfo(
            object_type="tenancy.tenantgroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_tunnel": RefInfo(
            object_type="vpn.tunnel", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tunnel_group": RefInfo(
            object_type="vpn.tunnelgroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tunnel_termination": RefInfo(
            object_type="vpn.tunneltermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vlan": RefInfo(
            object_type="ipam.vlan", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vlan_group": RefInfo(
            object_type="ipam.vlangroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vlan_translation_rule": RefInfo(
            object_type="ipam.vlantranslationrule",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vrf": RefInfo(
            object_type="ipam.vrf", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_circuit_termination": RefInfo(
            object_type="circuits.virtualcircuittermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_circuit_type": RefInfo(
            object_type="circuits.virtualcircuittype",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_device_context": RefInfo(
            object_type="dcim.virtualdevicecontext",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_disk": RefInfo(
            object_type="virtualization.virtualdisk",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_wireless_lan": RefInfo(
            object_type="wireless.wirelesslan",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_wireless_lan_group": RefInfo(
            object_type="wireless.wirelesslangroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_wireless_link": RefInfo(
            object_type="wireless.wirelesslink",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_custom_link": RefInfo(
            object_type="extras.customlink",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_owner": RefInfo(
            object_type="users.owner", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_owner_group": RefInfo(
            object_type="users.ownergroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "ipam.aggregate": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "rir": RefInfo(object_type="ipam.rir", field_name="rir"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "ipam.asn": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "rir": RefInfo(object_type="ipam.rir", field_name="rir"),
        "sites": RefInfo(object_type="dcim.site", field_name="sites", is_many=True),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "ipam.asnrange": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "rir": RefInfo(object_type="ipam.rir", field_name="rir"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "ipam.fhrpgroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "ipam.fhrpgroupassignment": {
        "group": RefInfo(object_type="ipam.fhrpgroup", field_name="group"),
        "interface_asn": RefInfo(
            object_type="ipam.asn", field_name="interface", is_generic=True
        ),
        "interface_asn_range": RefInfo(
            object_type="ipam.asnrange", field_name="interface", is_generic=True
        ),
        "interface_aggregate": RefInfo(
            object_type="ipam.aggregate", field_name="interface", is_generic=True
        ),
        "interface_cable": RefInfo(
            object_type="dcim.cable", field_name="interface", is_generic=True
        ),
        "interface_cable_path": RefInfo(
            object_type="dcim.cablepath", field_name="interface", is_generic=True
        ),
        "interface_cable_termination": RefInfo(
            object_type="dcim.cabletermination", field_name="interface", is_generic=True
        ),
        "interface_circuit": RefInfo(
            object_type="circuits.circuit", field_name="interface", is_generic=True
        ),
        "interface_circuit_group": RefInfo(
            object_type="circuits.circuitgroup", field_name="interface", is_generic=True
        ),
        "interface_circuit_group_assignment": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="interface",
            is_generic=True,
        ),
        "interface_circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="interface",
            is_generic=True,
        ),
        "interface_circuit_type": RefInfo(
            object_type="circuits.circuittype", field_name="interface", is_generic=True
        ),
        "interface_cluster": RefInfo(
            object_type="virtualization.cluster",
            field_name="interface",
            is_generic=True,
        ),
        "interface_cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="interface",
            is_generic=True,
        ),
        "interface_cluster_type": RefInfo(
            object_type="virtualization.clustertype",
            field_name="interface",
            is_generic=True,
        ),
        "interface_console_port": RefInfo(
            object_type="dcim.consoleport", field_name="interface", is_generic=True
        ),
        "interface_console_server_port": RefInfo(
            object_type="dcim.consoleserverport",
            field_name="interface",
            is_generic=True,
        ),
        "interface_contact": RefInfo(
            object_type="tenancy.contact", field_name="interface", is_generic=True
        ),
        "interface_contact_assignment": RefInfo(
            object_type="tenancy.contactassignment",
            field_name="interface",
            is_generic=True,
        ),
        "interface_contact_group": RefInfo(
            object_type="tenancy.contactgroup", field_name="interface", is_generic=True
        ),
        "interface_contact_role": RefInfo(
            object_type="tenancy.contactrole", field_name="interface", is_generic=True
        ),
        "interface_device": RefInfo(
            object_type="dcim.device", field_name="interface", is_generic=True
        ),
        "interface_device_bay": RefInfo(
            object_type="dcim.devicebay", field_name="interface", is_generic=True
        ),
        "interface_device_role": RefInfo(
            object_type="dcim.devicerole", field_name="interface", is_generic=True
        ),
        "interface_device_type": RefInfo(
            object_type="dcim.devicetype", field_name="interface", is_generic=True
        ),
        "interface_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="interface", is_generic=True
        ),
        "interface_fhrp_group_assignment": RefInfo(
            object_type="ipam.fhrpgroupassignment",
            field_name="interface",
            is_generic=True,
        ),
        "interface_front_port": RefInfo(
            object_type="dcim.frontport", field_name="interface", is_generic=True
        ),
        "interface_ike_policy": RefInfo(
            object_type="vpn.ikepolicy", field_name="interface", is_generic=True
        ),
        "interface_ike_proposal": RefInfo(
            object_type="vpn.ikeproposal", field_name="interface", is_generic=True
        ),
        "interface_ip_address": RefInfo(
            object_type="ipam.ipaddress", field_name="interface", is_generic=True
        ),
        "interface_ip_range": RefInfo(
            object_type="ipam.iprange", field_name="interface", is_generic=True
        ),
        "interface_ip_sec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="interface", is_generic=True
        ),
        "interface_ip_sec_profile": RefInfo(
            object_type="vpn.ipsecprofile", field_name="interface", is_generic=True
        ),
        "interface_ip_sec_proposal": RefInfo(
            object_type="vpn.ipsecproposal", field_name="interface", is_generic=True
        ),
        "interface_interface": RefInfo(
            object_type="dcim.interface", field_name="interface", is_generic=True
        ),
        "interface_inventory_item": RefInfo(
            object_type="dcim.inventoryitem", field_name="interface", is_generic=True
        ),
        "interface_inventory_item_role": RefInfo(
            object_type="dcim.inventoryitemrole",
            field_name="interface",
            is_generic=True,
        ),
        "interface_l2vpn": RefInfo(
            object_type="vpn.l2vpn", field_name="interface", is_generic=True
        ),
        "interface_l2vpn_termination": RefInfo(
            object_type="vpn.l2vpntermination", field_name="interface", is_generic=True
        ),
        "interface_location": RefInfo(
            object_type="dcim.location", field_name="interface", is_generic=True
        ),
        "interface_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="interface", is_generic=True
        ),
        "interface_manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="interface", is_generic=True
        ),
        "interface_module": RefInfo(
            object_type="dcim.module", field_name="interface", is_generic=True
        ),
        "interface_module_bay": RefInfo(
            object_type="dcim.modulebay", field_name="interface", is_generic=True
        ),
        "interface_module_type": RefInfo(
            object_type="dcim.moduletype", field_name="interface", is_generic=True
        ),
        "interface_platform": RefInfo(
            object_type="dcim.platform", field_name="interface", is_generic=True
        ),
        "interface_power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="interface", is_generic=True
        ),
        "interface_power_outlet": RefInfo(
            object_type="dcim.poweroutlet", field_name="interface", is_generic=True
        ),
        "interface_power_panel": RefInfo(
            object_type="dcim.powerpanel", field_name="interface", is_generic=True
        ),
        "interface_power_port": RefInfo(
            object_type="dcim.powerport", field_name="interface", is_generic=True
        ),
        "interface_prefix": RefInfo(
            object_type="ipam.prefix", field_name="interface", is_generic=True
        ),
        "interface_provider": RefInfo(
            object_type="circuits.provider", field_name="interface", is_generic=True
        ),
        "interface_provider_account": RefInfo(
            object_type="circuits.provideraccount",
            field_name="interface",
            is_generic=True,
        ),
        "interface_provider_network": RefInfo(
            object_type="circuits.providernetwork",
            field_name="interface",
            is_generic=True,
        ),
        "interface_rir": RefInfo(
            object_type="ipam.rir", field_name="interface", is_generic=True
        ),
        "interface_rack": RefInfo(
            object_type="dcim.rack", field_name="interface", is_generic=True
        ),
        "interface_rack_reservation": RefInfo(
            object_type="dcim.rackreservation", field_name="interface", is_generic=True
        ),
        "interface_rack_role": RefInfo(
            object_type="dcim.rackrole", field_name="interface", is_generic=True
        ),
        "interface_rack_type": RefInfo(
            object_type="dcim.racktype", field_name="interface", is_generic=True
        ),
        "interface_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="interface", is_generic=True
        ),
        "interface_region": RefInfo(
            object_type="dcim.region", field_name="interface", is_generic=True
        ),
        "interface_role": RefInfo(
            object_type="ipam.role", field_name="interface", is_generic=True
        ),
        "interface_route_target": RefInfo(
            object_type="ipam.routetarget", field_name="interface", is_generic=True
        ),
        "interface_service": RefInfo(
            object_type="ipam.service", field_name="interface", is_generic=True
        ),
        "interface_site": RefInfo(
            object_type="dcim.site", field_name="interface", is_generic=True
        ),
        "interface_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="interface", is_generic=True
        ),
        "interface_tag": RefInfo(
            object_type="extras.tag", field_name="interface", is_generic=True
        ),
        "interface_tenant": RefInfo(
            object_type="tenancy.tenant", field_name="interface", is_generic=True
        ),
        "interface_tenant_group": RefInfo(
            object_type="tenancy.tenantgroup", field_name="interface", is_generic=True
        ),
        "interface_tunnel": RefInfo(
            object_type="vpn.tunnel", field_name="interface", is_generic=True
        ),
        "interface_tunnel_group": RefInfo(
            object_type="vpn.tunnelgroup", field_name="interface", is_generic=True
        ),
        "interface_tunnel_termination": RefInfo(
            object_type="vpn.tunneltermination", field_name="interface", is_generic=True
        ),
        "interface_vlan": RefInfo(
            object_type="ipam.vlan", field_name="interface", is_generic=True
        ),
        "interface_vlan_group": RefInfo(
            object_type="ipam.vlangroup", field_name="interface", is_generic=True
        ),
        "interface_vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="interface",
            is_generic=True,
        ),
        "interface_vlan_translation_rule": RefInfo(
            object_type="ipam.vlantranslationrule",
            field_name="interface",
            is_generic=True,
        ),
        "interface_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="interface",
            is_generic=True,
        ),
        "interface_vrf": RefInfo(
            object_type="ipam.vrf", field_name="interface", is_generic=True
        ),
        "interface_virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis", field_name="interface", is_generic=True
        ),
        "interface_virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit",
            field_name="interface",
            is_generic=True,
        ),
        "interface_virtual_circuit_termination": RefInfo(
            object_type="circuits.virtualcircuittermination",
            field_name="interface",
            is_generic=True,
        ),
        "interface_virtual_circuit_type": RefInfo(
            object_type="circuits.virtualcircuittype",
            field_name="interface",
            is_generic=True,
        ),
        "interface_virtual_device_context": RefInfo(
            object_type="dcim.virtualdevicecontext",
            field_name="interface",
            is_generic=True,
        ),
        "interface_virtual_disk": RefInfo(
            object_type="virtualization.virtualdisk",
            field_name="interface",
            is_generic=True,
        ),
        "interface_virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="interface",
            is_generic=True,
        ),
        "interface_wireless_lan": RefInfo(
            object_type="wireless.wirelesslan", field_name="interface", is_generic=True
        ),
        "interface_wireless_lan_group": RefInfo(
            object_type="wireless.wirelesslangroup",
            field_name="interface",
            is_generic=True,
        ),
        "interface_wireless_link": RefInfo(
            object_type="wireless.wirelesslink", field_name="interface", is_generic=True
        ),
        "interface_custom_field": RefInfo(
            object_type="extras.customfield", field_name="interface", is_generic=True
        ),
        "interface_custom_field_choice_set": RefInfo(
            object_type="extras.customfieldchoiceset",
            field_name="interface",
            is_generic=True,
        ),
        "interface_journal_entry": RefInfo(
            object_type="extras.journalentry", field_name="interface", is_generic=True
        ),
        "interface_module_type_profile": RefInfo(
            object_type="dcim.moduletypeprofile",
            field_name="interface",
            is_generic=True,
        ),
        "interface_custom_link": RefInfo(
            object_type="extras.customlink", field_name="interface", is_generic=True
        ),
        "interface_owner": RefInfo(
            object_type="users.owner", field_name="interface", is_generic=True
        ),
        "interface_owner_group": RefInfo(
            object_type="users.ownergroup", field_name="interface", is_generic=True
        ),
    },
    "ipam.ipaddress": {
        "assigned_object_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_interface": RefInfo(
            object_type="dcim.interface", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="assigned_object",
            is_generic=True,
        ),
        "nat_inside": RefInfo(object_type="ipam.ipaddress", field_name="nat_inside"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "vrf": RefInfo(object_type="ipam.vrf", field_name="vrf"),
    },
    "ipam.iprange": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "role": RefInfo(object_type="ipam.role", field_name="role"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "vrf": RefInfo(object_type="ipam.vrf", field_name="vrf"),
    },
    "ipam.prefix": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "role": RefInfo(object_type="ipam.role", field_name="role"),
        "scope_location": RefInfo(
            object_type="dcim.location", field_name="scope", is_generic=True
        ),
        "scope_region": RefInfo(
            object_type="dcim.region", field_name="scope", is_generic=True
        ),
        "scope_site": RefInfo(
            object_type="dcim.site", field_name="scope", is_generic=True
        ),
        "scope_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="scope", is_generic=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "vlan": RefInfo(object_type="ipam.vlan", field_name="vlan"),
        "vrf": RefInfo(object_type="ipam.vrf", field_name="vrf"),
    },
    "ipam.rir": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "ipam.role": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "ipam.routetarget": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "ipam.service": {
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "ipaddresses": RefInfo(
            object_type="ipam.ipaddress", field_name="ipaddresses", is_many=True
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent_object_device": RefInfo(
            object_type="dcim.device", field_name="parent_object", is_generic=True
        ),
        "parent_object_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="parent_object", is_generic=True
        ),
        "parent_object_virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="parent_object",
            is_generic=True,
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine", field_name="virtual_machine"
        ),
    },
    "ipam.vlan": {
        "group": RefInfo(object_type="ipam.vlangroup", field_name="group"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "qinq_svlan": RefInfo(object_type="ipam.vlan", field_name="qinq_svlan"),
        "role": RefInfo(object_type="ipam.role", field_name="role"),
        "site": RefInfo(object_type="dcim.site", field_name="site"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "ipam.vlangroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "scope_cluster": RefInfo(
            object_type="virtualization.cluster", field_name="scope", is_generic=True
        ),
        "scope_cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="scope",
            is_generic=True,
        ),
        "scope_location": RefInfo(
            object_type="dcim.location", field_name="scope", is_generic=True
        ),
        "scope_rack": RefInfo(
            object_type="dcim.rack", field_name="scope", is_generic=True
        ),
        "scope_region": RefInfo(
            object_type="dcim.region", field_name="scope", is_generic=True
        ),
        "scope_site": RefInfo(
            object_type="dcim.site", field_name="scope", is_generic=True
        ),
        "scope_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="scope", is_generic=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "ipam.vlantranslationpolicy": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
    },
    "ipam.vlantranslationrule": {
        "policy": RefInfo(
            object_type="ipam.vlantranslationpolicy", field_name="policy"
        ),
    },
    "ipam.vrf": {
        "export_targets": RefInfo(
            object_type="ipam.routetarget", field_name="export_targets", is_many=True
        ),
        "import_targets": RefInfo(
            object_type="ipam.routetarget", field_name="import_targets", is_many=True
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "tenancy.contact": {
        "group": RefInfo(object_type="tenancy.contactgroup", field_name="group"),
        "groups": RefInfo(
            object_type="tenancy.contactgroup", field_name="groups", is_many=True
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "tenancy.contactassignment": {
        "contact": RefInfo(object_type="tenancy.contact", field_name="contact"),
        "object_asn": RefInfo(
            object_type="ipam.asn", field_name="object", is_generic=True
        ),
        "object_asn_range": RefInfo(
            object_type="ipam.asnrange", field_name="object", is_generic=True
        ),
        "object_aggregate": RefInfo(
            object_type="ipam.aggregate", field_name="object", is_generic=True
        ),
        "object_cable": RefInfo(
            object_type="dcim.cable", field_name="object", is_generic=True
        ),
        "object_cable_path": RefInfo(
            object_type="dcim.cablepath", field_name="object", is_generic=True
        ),
        "object_cable_termination": RefInfo(
            object_type="dcim.cabletermination", field_name="object", is_generic=True
        ),
        "object_circuit": RefInfo(
            object_type="circuits.circuit", field_name="object", is_generic=True
        ),
        "object_circuit_group": RefInfo(
            object_type="circuits.circuitgroup", field_name="object", is_generic=True
        ),
        "object_circuit_group_assignment": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="object",
            is_generic=True,
        ),
        "object_circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="object",
            is_generic=True,
        ),
        "object_circuit_type": RefInfo(
            object_type="circuits.circuittype", field_name="object", is_generic=True
        ),
        "object_cluster": RefInfo(
            object_type="virtualization.cluster", field_name="object", is_generic=True
        ),
        "object_cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="object",
            is_generic=True,
        ),
        "object_cluster_type": RefInfo(
            object_type="virtualization.clustertype",
            field_name="object",
            is_generic=True,
        ),
        "object_console_port": RefInfo(
            object_type="dcim.consoleport", field_name="object", is_generic=True
        ),
        "object_console_server_port": RefInfo(
            object_type="dcim.consoleserverport", field_name="object", is_generic=True
        ),
        "object_contact": RefInfo(
            object_type="tenancy.contact", field_name="object", is_generic=True
        ),
        "object_contact_assignment": RefInfo(
            object_type="tenancy.contactassignment",
            field_name="object",
            is_generic=True,
        ),
        "object_contact_group": RefInfo(
            object_type="tenancy.contactgroup", field_name="object", is_generic=True
        ),
        "object_contact_role": RefInfo(
            object_type="tenancy.contactrole", field_name="object", is_generic=True
        ),
        "object_device": RefInfo(
            object_type="dcim.device", field_name="object", is_generic=True
        ),
        "object_device_bay": RefInfo(
            object_type="dcim.devicebay", field_name="object", is_generic=True
        ),
        "object_device_role": RefInfo(
            object_type="dcim.devicerole", field_name="object", is_generic=True
        ),
        "object_device_type": RefInfo(
            object_type="dcim.devicetype", field_name="object", is_generic=True
        ),
        "object_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="object", is_generic=True
        ),
        "object_fhrp_group_assignment": RefInfo(
            object_type="ipam.fhrpgroupassignment", field_name="object", is_generic=True
        ),
        "object_front_port": RefInfo(
            object_type="dcim.frontport", field_name="object", is_generic=True
        ),
        "object_ike_policy": RefInfo(
            object_type="vpn.ikepolicy", field_name="object", is_generic=True
        ),
        "object_ike_proposal": RefInfo(
            object_type="vpn.ikeproposal", field_name="object", is_generic=True
        ),
        "object_ip_address": RefInfo(
            object_type="ipam.ipaddress", field_name="object", is_generic=True
        ),
        "object_ip_range": RefInfo(
            object_type="ipam.iprange", field_name="object", is_generic=True
        ),
        "object_ip_sec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="object", is_generic=True
        ),
        "object_ip_sec_profile": RefInfo(
            object_type="vpn.ipsecprofile", field_name="object", is_generic=True
        ),
        "object_ip_sec_proposal": RefInfo(
            object_type="vpn.ipsecproposal", field_name="object", is_generic=True
        ),
        "object_interface": RefInfo(
            object_type="dcim.interface", field_name="object", is_generic=True
        ),
        "object_inventory_item": RefInfo(
            object_type="dcim.inventoryitem", field_name="object", is_generic=True
        ),
        "object_inventory_item_role": RefInfo(
            object_type="dcim.inventoryitemrole", field_name="object", is_generic=True
        ),
        "object_l2vpn": RefInfo(
            object_type="vpn.l2vpn", field_name="object", is_generic=True
        ),
        "object_l2vpn_termination": RefInfo(
            object_type="vpn.l2vpntermination", field_name="object", is_generic=True
        ),
        "object_location": RefInfo(
            object_type="dcim.location", field_name="object", is_generic=True
        ),
        "object_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="object", is_generic=True
        ),
        "object_manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="object", is_generic=True
        ),
        "object_module": RefInfo(
            object_type="dcim.module", field_name="object", is_generic=True
        ),
        "object_module_bay": RefInfo(
            object_type="dcim.modulebay", field_name="object", is_generic=True
        ),
        "object_module_type": RefInfo(
            object_type="dcim.moduletype", field_name="object", is_generic=True
        ),
        "object_platform": RefInfo(
            object_type="dcim.platform", field_name="object", is_generic=True
        ),
        "object_power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="object", is_generic=True
        ),
        "object_power_outlet": RefInfo(
            object_type="dcim.poweroutlet", field_name="object", is_generic=True
        ),
        "object_power_panel": RefInfo(
            object_type="dcim.powerpanel", field_name="object", is_generic=True
        ),
        "object_power_port": RefInfo(
            object_type="dcim.powerport", field_name="object", is_generic=True
        ),
        "object_prefix": RefInfo(
            object_type="ipam.prefix", field_name="object", is_generic=True
        ),
        "object_provider": RefInfo(
            object_type="circuits.provider", field_name="object", is_generic=True
        ),
        "object_provider_account": RefInfo(
            object_type="circuits.provideraccount", field_name="object", is_generic=True
        ),
        "object_provider_network": RefInfo(
            object_type="circuits.providernetwork", field_name="object", is_generic=True
        ),
        "object_rir": RefInfo(
            object_type="ipam.rir", field_name="object", is_generic=True
        ),
        "object_rack": RefInfo(
            object_type="dcim.rack", field_name="object", is_generic=True
        ),
        "object_rack_reservation": RefInfo(
            object_type="dcim.rackreservation", field_name="object", is_generic=True
        ),
        "object_rack_role": RefInfo(
            object_type="dcim.rackrole", field_name="object", is_generic=True
        ),
        "object_rack_type": RefInfo(
            object_type="dcim.racktype", field_name="object", is_generic=True
        ),
        "object_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="object", is_generic=True
        ),
        "object_region": RefInfo(
            object_type="dcim.region", field_name="object", is_generic=True
        ),
        "object_role": RefInfo(
            object_type="ipam.role", field_name="object", is_generic=True
        ),
        "object_route_target": RefInfo(
            object_type="ipam.routetarget", field_name="object", is_generic=True
        ),
        "object_service": RefInfo(
            object_type="ipam.service", field_name="object", is_generic=True
        ),
        "object_site": RefInfo(
            object_type="dcim.site", field_name="object", is_generic=True
        ),
        "object_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="object", is_generic=True
        ),
        "object_tag": RefInfo(
            object_type="extras.tag", field_name="object", is_generic=True
        ),
        "object_tenant": RefInfo(
            object_type="tenancy.tenant", field_name="object", is_generic=True
        ),
        "object_tenant_group": RefInfo(
            object_type="tenancy.tenantgroup", field_name="object", is_generic=True
        ),
        "object_tunnel": RefInfo(
            object_type="vpn.tunnel", field_name="object", is_generic=True
        ),
        "object_tunnel_group": RefInfo(
            object_type="vpn.tunnelgroup", field_name="object", is_generic=True
        ),
        "object_tunnel_termination": RefInfo(
            object_type="vpn.tunneltermination", field_name="object", is_generic=True
        ),
        "object_vlan": RefInfo(
            object_type="ipam.vlan", field_name="object", is_generic=True
        ),
        "object_vlan_group": RefInfo(
            object_type="ipam.vlangroup", field_name="object", is_generic=True
        ),
        "object_vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="object",
            is_generic=True,
        ),
        "object_vlan_translation_rule": RefInfo(
            object_type="ipam.vlantranslationrule", field_name="object", is_generic=True
        ),
        "object_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="object",
            is_generic=True,
        ),
        "object_vrf": RefInfo(
            object_type="ipam.vrf", field_name="object", is_generic=True
        ),
        "object_virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis", field_name="object", is_generic=True
        ),
        "object_virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit", field_name="object", is_generic=True
        ),
        "object_virtual_circuit_termination": RefInfo(
            object_type="circuits.virtualcircuittermination",
            field_name="object",
            is_generic=True,
        ),
        "object_virtual_circuit_type": RefInfo(
            object_type="circuits.virtualcircuittype",
            field_name="object",
            is_generic=True,
        ),
        "object_virtual_device_context": RefInfo(
            object_type="dcim.virtualdevicecontext",
            field_name="object",
            is_generic=True,
        ),
        "object_virtual_disk": RefInfo(
            object_type="virtualization.virtualdisk",
            field_name="object",
            is_generic=True,
        ),
        "object_virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="object",
            is_generic=True,
        ),
        "object_wireless_lan": RefInfo(
            object_type="wireless.wirelesslan", field_name="object", is_generic=True
        ),
        "object_wireless_lan_group": RefInfo(
            object_type="wireless.wirelesslangroup",
            field_name="object",
            is_generic=True,
        ),
        "object_wireless_link": RefInfo(
            object_type="wireless.wirelesslink", field_name="object", is_generic=True
        ),
        "object_custom_field": RefInfo(
            object_type="extras.customfield", field_name="object", is_generic=True
        ),
        "object_custom_field_choice_set": RefInfo(
            object_type="extras.customfieldchoiceset",
            field_name="object",
            is_generic=True,
        ),
        "object_journal_entry": RefInfo(
            object_type="extras.journalentry", field_name="object", is_generic=True
        ),
        "object_module_type_profile": RefInfo(
            object_type="dcim.moduletypeprofile", field_name="object", is_generic=True
        ),
        "object_custom_link": RefInfo(
            object_type="extras.customlink", field_name="object", is_generic=True
        ),
        "object_owner": RefInfo(
            object_type="users.owner", field_name="object", is_generic=True
        ),
        "object_owner_group": RefInfo(
            object_type="users.ownergroup", field_name="object", is_generic=True
        ),
        "role": RefInfo(object_type="tenancy.contactrole", field_name="role"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "tenancy.contactgroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="tenancy.contactgroup", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "tenancy.contactrole": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "tenancy.tenant": {
        "group": RefInfo(object_type="tenancy.tenantgroup", field_name="group"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "tenancy.tenantgroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="tenancy.tenantgroup", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "users.owner": {
        "group": RefInfo(object_type="users.ownergroup", field_name="group"),
    },
    "virtualization.cluster": {
        "group": RefInfo(object_type="virtualization.clustergroup", field_name="group"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "scope_location": RefInfo(
            object_type="dcim.location", field_name="scope", is_generic=True
        ),
        "scope_region": RefInfo(
            object_type="dcim.region", field_name="scope", is_generic=True
        ),
        "scope_site": RefInfo(
            object_type="dcim.site", field_name="scope", is_generic=True
        ),
        "scope_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="scope", is_generic=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "type": RefInfo(object_type="virtualization.clustertype", field_name="type"),
    },
    "virtualization.clustergroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "virtualization.clustertype": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "virtualization.virtualdisk": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine", field_name="virtual_machine"
        ),
    },
    "virtualization.virtualmachine": {
        "cluster": RefInfo(object_type="virtualization.cluster", field_name="cluster"),
        "device": RefInfo(object_type="dcim.device", field_name="device"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "platform": RefInfo(object_type="dcim.platform", field_name="platform"),
        "primary_ip4": RefInfo(object_type="ipam.ipaddress", field_name="primary_ip4"),
        "primary_ip6": RefInfo(object_type="ipam.ipaddress", field_name="primary_ip6"),
        "role": RefInfo(object_type="dcim.devicerole", field_name="role"),
        "site": RefInfo(object_type="dcim.site", field_name="site"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "virtualization.vminterface": {
        "bridge": RefInfo(
            object_type="virtualization.vminterface", field_name="bridge"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(
            object_type="virtualization.vminterface", field_name="parent"
        ),
        "primary_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="primary_mac_address"
        ),
        "qinq_svlan": RefInfo(object_type="ipam.vlan", field_name="qinq_svlan"),
        "tagged_vlans": RefInfo(
            object_type="ipam.vlan", field_name="tagged_vlans", is_many=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "untagged_vlan": RefInfo(object_type="ipam.vlan", field_name="untagged_vlan"),
        "virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine", field_name="virtual_machine"
        ),
        "vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="vlan_translation_policy",
        ),
        "vrf": RefInfo(object_type="ipam.vrf", field_name="vrf"),
    },
    "vpn.ikepolicy": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "proposals": RefInfo(
            object_type="vpn.ikeproposal", field_name="proposals", is_many=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.ikeproposal": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.ipsecpolicy": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "proposals": RefInfo(
            object_type="vpn.ipsecproposal", field_name="proposals", is_many=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.ipsecprofile": {
        "ike_policy": RefInfo(object_type="vpn.ikepolicy", field_name="ike_policy"),
        "ipsec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="ipsec_policy"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.ipsecproposal": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.l2vpn": {
        "export_targets": RefInfo(
            object_type="ipam.routetarget", field_name="export_targets", is_many=True
        ),
        "import_targets": RefInfo(
            object_type="ipam.routetarget", field_name="import_targets", is_many=True
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "vpn.l2vpntermination": {
        "assigned_object_interface": RefInfo(
            object_type="dcim.interface", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vlan": RefInfo(
            object_type="ipam.vlan", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_asn": RefInfo(
            object_type="ipam.asn", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_asn_range": RefInfo(
            object_type="ipam.asnrange", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_aggregate": RefInfo(
            object_type="ipam.aggregate", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_cable": RefInfo(
            object_type="dcim.cable", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_cable_path": RefInfo(
            object_type="dcim.cablepath", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_cable_termination": RefInfo(
            object_type="dcim.cabletermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit": RefInfo(
            object_type="circuits.circuit",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_group": RefInfo(
            object_type="circuits.circuitgroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_group_assignment": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_circuit_type": RefInfo(
            object_type="circuits.circuittype",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_cluster": RefInfo(
            object_type="virtualization.cluster",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_cluster_type": RefInfo(
            object_type="virtualization.clustertype",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_console_port": RefInfo(
            object_type="dcim.consoleport",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_console_server_port": RefInfo(
            object_type="dcim.consoleserverport",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_contact": RefInfo(
            object_type="tenancy.contact", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_contact_assignment": RefInfo(
            object_type="tenancy.contactassignment",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_contact_group": RefInfo(
            object_type="tenancy.contactgroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_contact_role": RefInfo(
            object_type="tenancy.contactrole",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_custom_field": RefInfo(
            object_type="extras.customfield",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_custom_field_choice_set": RefInfo(
            object_type="extras.customfieldchoiceset",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_device": RefInfo(
            object_type="dcim.device", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_device_bay": RefInfo(
            object_type="dcim.devicebay", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_device_role": RefInfo(
            object_type="dcim.devicerole", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_device_type": RefInfo(
            object_type="dcim.devicetype", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_fhrp_group_assignment": RefInfo(
            object_type="ipam.fhrpgroupassignment",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_front_port": RefInfo(
            object_type="dcim.frontport", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ike_policy": RefInfo(
            object_type="vpn.ikepolicy", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ike_proposal": RefInfo(
            object_type="vpn.ikeproposal", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_address": RefInfo(
            object_type="ipam.ipaddress", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_range": RefInfo(
            object_type="ipam.iprange", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_sec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_ip_sec_profile": RefInfo(
            object_type="vpn.ipsecprofile",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_ip_sec_proposal": RefInfo(
            object_type="vpn.ipsecproposal",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_inventory_item": RefInfo(
            object_type="dcim.inventoryitem",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_inventory_item_role": RefInfo(
            object_type="dcim.inventoryitemrole",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_journal_entry": RefInfo(
            object_type="extras.journalentry",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_l2vpn": RefInfo(
            object_type="vpn.l2vpn", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_l2vpn_termination": RefInfo(
            object_type="vpn.l2vpntermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_location": RefInfo(
            object_type="dcim.location", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_manufacturer": RefInfo(
            object_type="dcim.manufacturer",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_module": RefInfo(
            object_type="dcim.module", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_module_bay": RefInfo(
            object_type="dcim.modulebay", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_module_type": RefInfo(
            object_type="dcim.moduletype", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_module_type_profile": RefInfo(
            object_type="dcim.moduletypeprofile",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_platform": RefInfo(
            object_type="dcim.platform", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_power_outlet": RefInfo(
            object_type="dcim.poweroutlet",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_power_panel": RefInfo(
            object_type="dcim.powerpanel", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_power_port": RefInfo(
            object_type="dcim.powerport", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_prefix": RefInfo(
            object_type="ipam.prefix", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_provider": RefInfo(
            object_type="circuits.provider",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_provider_account": RefInfo(
            object_type="circuits.provideraccount",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_provider_network": RefInfo(
            object_type="circuits.providernetwork",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_rir": RefInfo(
            object_type="ipam.rir", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rack": RefInfo(
            object_type="dcim.rack", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rack_reservation": RefInfo(
            object_type="dcim.rackreservation",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_rack_role": RefInfo(
            object_type="dcim.rackrole", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rack_type": RefInfo(
            object_type="dcim.racktype", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_region": RefInfo(
            object_type="dcim.region", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_role": RefInfo(
            object_type="ipam.role", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_route_target": RefInfo(
            object_type="ipam.routetarget",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_service": RefInfo(
            object_type="ipam.service", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_site": RefInfo(
            object_type="dcim.site", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tag": RefInfo(
            object_type="extras.tag", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tenant": RefInfo(
            object_type="tenancy.tenant", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tenant_group": RefInfo(
            object_type="tenancy.tenantgroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_tunnel": RefInfo(
            object_type="vpn.tunnel", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tunnel_group": RefInfo(
            object_type="vpn.tunnelgroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_tunnel_termination": RefInfo(
            object_type="vpn.tunneltermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vlan_group": RefInfo(
            object_type="ipam.vlangroup", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vlan_translation_rule": RefInfo(
            object_type="ipam.vlantranslationrule",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_vrf": RefInfo(
            object_type="ipam.vrf", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_circuit_termination": RefInfo(
            object_type="circuits.virtualcircuittermination",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_circuit_type": RefInfo(
            object_type="circuits.virtualcircuittype",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_device_context": RefInfo(
            object_type="dcim.virtualdevicecontext",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_disk": RefInfo(
            object_type="virtualization.virtualdisk",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_wireless_lan": RefInfo(
            object_type="wireless.wirelesslan",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_wireless_lan_group": RefInfo(
            object_type="wireless.wirelesslangroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_wireless_link": RefInfo(
            object_type="wireless.wirelesslink",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_custom_link": RefInfo(
            object_type="extras.customlink",
            field_name="assigned_object",
            is_generic=True,
        ),
        "assigned_object_owner": RefInfo(
            object_type="users.owner", field_name="assigned_object", is_generic=True
        ),
        "assigned_object_owner_group": RefInfo(
            object_type="users.ownergroup",
            field_name="assigned_object",
            is_generic=True,
        ),
        "l2vpn": RefInfo(object_type="vpn.l2vpn", field_name="l2vpn"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.tunnel": {
        "group": RefInfo(object_type="vpn.tunnelgroup", field_name="group"),
        "ipsec_profile": RefInfo(
            object_type="vpn.ipsecprofile", field_name="ipsec_profile"
        ),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
    "vpn.tunnelgroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "vpn.tunneltermination": {
        "outside_ip": RefInfo(object_type="ipam.ipaddress", field_name="outside_ip"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "termination_asn": RefInfo(
            object_type="ipam.asn", field_name="termination", is_generic=True
        ),
        "termination_asn_range": RefInfo(
            object_type="ipam.asnrange", field_name="termination", is_generic=True
        ),
        "termination_aggregate": RefInfo(
            object_type="ipam.aggregate", field_name="termination", is_generic=True
        ),
        "termination_cable": RefInfo(
            object_type="dcim.cable", field_name="termination", is_generic=True
        ),
        "termination_cable_path": RefInfo(
            object_type="dcim.cablepath", field_name="termination", is_generic=True
        ),
        "termination_cable_termination": RefInfo(
            object_type="dcim.cabletermination",
            field_name="termination",
            is_generic=True,
        ),
        "termination_circuit": RefInfo(
            object_type="circuits.circuit", field_name="termination", is_generic=True
        ),
        "termination_circuit_group": RefInfo(
            object_type="circuits.circuitgroup",
            field_name="termination",
            is_generic=True,
        ),
        "termination_circuit_group_assignment": RefInfo(
            object_type="circuits.circuitgroupassignment",
            field_name="termination",
            is_generic=True,
        ),
        "termination_circuit_termination": RefInfo(
            object_type="circuits.circuittermination",
            field_name="termination",
            is_generic=True,
        ),
        "termination_circuit_type": RefInfo(
            object_type="circuits.circuittype",
            field_name="termination",
            is_generic=True,
        ),
        "termination_cluster": RefInfo(
            object_type="virtualization.cluster",
            field_name="termination",
            is_generic=True,
        ),
        "termination_cluster_group": RefInfo(
            object_type="virtualization.clustergroup",
            field_name="termination",
            is_generic=True,
        ),
        "termination_cluster_type": RefInfo(
            object_type="virtualization.clustertype",
            field_name="termination",
            is_generic=True,
        ),
        "termination_console_port": RefInfo(
            object_type="dcim.consoleport", field_name="termination", is_generic=True
        ),
        "termination_console_server_port": RefInfo(
            object_type="dcim.consoleserverport",
            field_name="termination",
            is_generic=True,
        ),
        "termination_contact": RefInfo(
            object_type="tenancy.contact", field_name="termination", is_generic=True
        ),
        "termination_contact_assignment": RefInfo(
            object_type="tenancy.contactassignment",
            field_name="termination",
            is_generic=True,
        ),
        "termination_contact_group": RefInfo(
            object_type="tenancy.contactgroup",
            field_name="termination",
            is_generic=True,
        ),
        "termination_contact_role": RefInfo(
            object_type="tenancy.contactrole", field_name="termination", is_generic=True
        ),
        "termination_device": RefInfo(
            object_type="dcim.device", field_name="termination", is_generic=True
        ),
        "termination_device_bay": RefInfo(
            object_type="dcim.devicebay", field_name="termination", is_generic=True
        ),
        "termination_device_role": RefInfo(
            object_type="dcim.devicerole", field_name="termination", is_generic=True
        ),
        "termination_device_type": RefInfo(
            object_type="dcim.devicetype", field_name="termination", is_generic=True
        ),
        "termination_fhrp_group": RefInfo(
            object_type="ipam.fhrpgroup", field_name="termination", is_generic=True
        ),
        "termination_fhrp_group_assignment": RefInfo(
            object_type="ipam.fhrpgroupassignment",
            field_name="termination",
            is_generic=True,
        ),
        "termination_front_port": RefInfo(
            object_type="dcim.frontport", field_name="termination", is_generic=True
        ),
        "termination_ike_policy": RefInfo(
            object_type="vpn.ikepolicy", field_name="termination", is_generic=True
        ),
        "termination_ike_proposal": RefInfo(
            object_type="vpn.ikeproposal", field_name="termination", is_generic=True
        ),
        "termination_ip_address": RefInfo(
            object_type="ipam.ipaddress", field_name="termination", is_generic=True
        ),
        "termination_ip_range": RefInfo(
            object_type="ipam.iprange", field_name="termination", is_generic=True
        ),
        "termination_ip_sec_policy": RefInfo(
            object_type="vpn.ipsecpolicy", field_name="termination", is_generic=True
        ),
        "termination_ip_sec_profile": RefInfo(
            object_type="vpn.ipsecprofile", field_name="termination", is_generic=True
        ),
        "termination_ip_sec_proposal": RefInfo(
            object_type="vpn.ipsecproposal", field_name="termination", is_generic=True
        ),
        "termination_interface": RefInfo(
            object_type="dcim.interface", field_name="termination", is_generic=True
        ),
        "termination_inventory_item": RefInfo(
            object_type="dcim.inventoryitem", field_name="termination", is_generic=True
        ),
        "termination_inventory_item_role": RefInfo(
            object_type="dcim.inventoryitemrole",
            field_name="termination",
            is_generic=True,
        ),
        "termination_l2vpn": RefInfo(
            object_type="vpn.l2vpn", field_name="termination", is_generic=True
        ),
        "termination_l2vpn_termination": RefInfo(
            object_type="vpn.l2vpntermination",
            field_name="termination",
            is_generic=True,
        ),
        "termination_location": RefInfo(
            object_type="dcim.location", field_name="termination", is_generic=True
        ),
        "termination_mac_address": RefInfo(
            object_type="dcim.macaddress", field_name="termination", is_generic=True
        ),
        "termination_manufacturer": RefInfo(
            object_type="dcim.manufacturer", field_name="termination", is_generic=True
        ),
        "termination_module": RefInfo(
            object_type="dcim.module", field_name="termination", is_generic=True
        ),
        "termination_module_bay": RefInfo(
            object_type="dcim.modulebay", field_name="termination", is_generic=True
        ),
        "termination_module_type": RefInfo(
            object_type="dcim.moduletype", field_name="termination", is_generic=True
        ),
        "termination_platform": RefInfo(
            object_type="dcim.platform", field_name="termination", is_generic=True
        ),
        "termination_power_feed": RefInfo(
            object_type="dcim.powerfeed", field_name="termination", is_generic=True
        ),
        "termination_power_outlet": RefInfo(
            object_type="dcim.poweroutlet", field_name="termination", is_generic=True
        ),
        "termination_power_panel": RefInfo(
            object_type="dcim.powerpanel", field_name="termination", is_generic=True
        ),
        "termination_power_port": RefInfo(
            object_type="dcim.powerport", field_name="termination", is_generic=True
        ),
        "termination_prefix": RefInfo(
            object_type="ipam.prefix", field_name="termination", is_generic=True
        ),
        "termination_provider": RefInfo(
            object_type="circuits.provider", field_name="termination", is_generic=True
        ),
        "termination_provider_account": RefInfo(
            object_type="circuits.provideraccount",
            field_name="termination",
            is_generic=True,
        ),
        "termination_provider_network": RefInfo(
            object_type="circuits.providernetwork",
            field_name="termination",
            is_generic=True,
        ),
        "termination_rir": RefInfo(
            object_type="ipam.rir", field_name="termination", is_generic=True
        ),
        "termination_rack": RefInfo(
            object_type="dcim.rack", field_name="termination", is_generic=True
        ),
        "termination_rack_reservation": RefInfo(
            object_type="dcim.rackreservation",
            field_name="termination",
            is_generic=True,
        ),
        "termination_rack_role": RefInfo(
            object_type="dcim.rackrole", field_name="termination", is_generic=True
        ),
        "termination_rack_type": RefInfo(
            object_type="dcim.racktype", field_name="termination", is_generic=True
        ),
        "termination_rear_port": RefInfo(
            object_type="dcim.rearport", field_name="termination", is_generic=True
        ),
        "termination_region": RefInfo(
            object_type="dcim.region", field_name="termination", is_generic=True
        ),
        "termination_role": RefInfo(
            object_type="ipam.role", field_name="termination", is_generic=True
        ),
        "termination_route_target": RefInfo(
            object_type="ipam.routetarget", field_name="termination", is_generic=True
        ),
        "termination_service": RefInfo(
            object_type="ipam.service", field_name="termination", is_generic=True
        ),
        "termination_site": RefInfo(
            object_type="dcim.site", field_name="termination", is_generic=True
        ),
        "termination_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="termination", is_generic=True
        ),
        "termination_tag": RefInfo(
            object_type="extras.tag", field_name="termination", is_generic=True
        ),
        "termination_tenant": RefInfo(
            object_type="tenancy.tenant", field_name="termination", is_generic=True
        ),
        "termination_tenant_group": RefInfo(
            object_type="tenancy.tenantgroup", field_name="termination", is_generic=True
        ),
        "termination_tunnel": RefInfo(
            object_type="vpn.tunnel", field_name="termination", is_generic=True
        ),
        "termination_tunnel_group": RefInfo(
            object_type="vpn.tunnelgroup", field_name="termination", is_generic=True
        ),
        "termination_tunnel_termination": RefInfo(
            object_type="vpn.tunneltermination",
            field_name="termination",
            is_generic=True,
        ),
        "termination_vlan": RefInfo(
            object_type="ipam.vlan", field_name="termination", is_generic=True
        ),
        "termination_vlan_group": RefInfo(
            object_type="ipam.vlangroup", field_name="termination", is_generic=True
        ),
        "termination_vlan_translation_policy": RefInfo(
            object_type="ipam.vlantranslationpolicy",
            field_name="termination",
            is_generic=True,
        ),
        "termination_vlan_translation_rule": RefInfo(
            object_type="ipam.vlantranslationrule",
            field_name="termination",
            is_generic=True,
        ),
        "termination_vm_interface": RefInfo(
            object_type="virtualization.vminterface",
            field_name="termination",
            is_generic=True,
        ),
        "termination_vrf": RefInfo(
            object_type="ipam.vrf", field_name="termination", is_generic=True
        ),
        "termination_virtual_chassis": RefInfo(
            object_type="dcim.virtualchassis", field_name="termination", is_generic=True
        ),
        "termination_virtual_circuit": RefInfo(
            object_type="circuits.virtualcircuit",
            field_name="termination",
            is_generic=True,
        ),
        "termination_virtual_circuit_termination": RefInfo(
            object_type="circuits.virtualcircuittermination",
            field_name="termination",
            is_generic=True,
        ),
        "termination_virtual_circuit_type": RefInfo(
            object_type="circuits.virtualcircuittype",
            field_name="termination",
            is_generic=True,
        ),
        "termination_virtual_device_context": RefInfo(
            object_type="dcim.virtualdevicecontext",
            field_name="termination",
            is_generic=True,
        ),
        "termination_virtual_disk": RefInfo(
            object_type="virtualization.virtualdisk",
            field_name="termination",
            is_generic=True,
        ),
        "termination_virtual_machine": RefInfo(
            object_type="virtualization.virtualmachine",
            field_name="termination",
            is_generic=True,
        ),
        "termination_wireless_lan": RefInfo(
            object_type="wireless.wirelesslan",
            field_name="termination",
            is_generic=True,
        ),
        "termination_wireless_lan_group": RefInfo(
            object_type="wireless.wirelesslangroup",
            field_name="termination",
            is_generic=True,
        ),
        "termination_wireless_link": RefInfo(
            object_type="wireless.wirelesslink",
            field_name="termination",
            is_generic=True,
        ),
        "termination_custom_field": RefInfo(
            object_type="extras.customfield", field_name="termination", is_generic=True
        ),
        "termination_custom_field_choice_set": RefInfo(
            object_type="extras.customfieldchoiceset",
            field_name="termination",
            is_generic=True,
        ),
        "termination_journal_entry": RefInfo(
            object_type="extras.journalentry", field_name="termination", is_generic=True
        ),
        "termination_module_type_profile": RefInfo(
            object_type="dcim.moduletypeprofile",
            field_name="termination",
            is_generic=True,
        ),
        "termination_custom_link": RefInfo(
            object_type="extras.customlink", field_name="termination", is_generic=True
        ),
        "termination_owner": RefInfo(
            object_type="users.owner", field_name="termination", is_generic=True
        ),
        "termination_owner_group": RefInfo(
            object_type="users.ownergroup", field_name="termination", is_generic=True
        ),
        "tunnel": RefInfo(object_type="vpn.tunnel", field_name="tunnel"),
    },
    "wireless.wirelesslan": {
        "group": RefInfo(object_type="wireless.wirelesslangroup", field_name="group"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "scope_location": RefInfo(
            object_type="dcim.location", field_name="scope", is_generic=True
        ),
        "scope_region": RefInfo(
            object_type="dcim.region", field_name="scope", is_generic=True
        ),
        "scope_site": RefInfo(
            object_type="dcim.site", field_name="scope", is_generic=True
        ),
        "scope_site_group": RefInfo(
            object_type="dcim.sitegroup", field_name="scope", is_generic=True
        ),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
        "vlan": RefInfo(object_type="ipam.vlan", field_name="vlan"),
    },
    "wireless.wirelesslangroup": {
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "parent": RefInfo(object_type="wireless.wirelesslangroup", field_name="parent"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
    },
    "wireless.wirelesslink": {
        "interface_a": RefInfo(object_type="dcim.interface", field_name="interface_a"),
        "interface_b": RefInfo(object_type="dcim.interface", field_name="interface_b"),
        "owner": RefInfo(object_type="users.owner", field_name="owner"),
        "tags": RefInfo(object_type="extras.tag", field_name="tags", is_many=True),
        "tenant": RefInfo(object_type="tenancy.tenant", field_name="tenant"),
    },
}


def get_json_ref_info(
    object_type: str | Type[models.Model], json_field_name: str
) -> RefInfo | None:
    if not isinstance(object_type, str):
        object_type = get_object_type(object_type)
    return _JSON_REF_INFO.get(object_type, {}).get(json_field_name)


_LEGAL_FIELDS = {
    "circuits.circuit": frozenset(
        [
            "assignments",
            "cid",
            "comments",
            "commit_rate",
            "custom_fields",
            "description",
            "distance",
            "distance_unit",
            "install_date",
            "owner",
            "provider",
            "provider_account",
            "status",
            "tags",
            "tenant",
            "termination_date",
            "type",
        ]
    ),
    "circuits.circuitgroup": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
            "tenant",
        ]
    ),
    "circuits.circuitgroupassignment": frozenset(
        ["group", "member_id", "member_type", "priority", "tags"]
    ),
    "circuits.circuittermination": frozenset(
        [
            "circuit",
            "custom_fields",
            "description",
            "mark_connected",
            "port_speed",
            "pp_info",
            "tags",
            "term_side",
            "termination_id",
            "termination_type",
            "upstream_speed",
            "xconnect_id",
        ]
    ),
    "circuits.circuittype": frozenset(
        [
            "color",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "circuits.provider": frozenset(
        [
            "accounts",
            "asns",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "circuits.provideraccount": frozenset(
        [
            "account",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "provider",
            "tags",
        ]
    ),
    "circuits.providernetwork": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "provider",
            "service_id",
            "tags",
        ]
    ),
    "circuits.virtualcircuit": frozenset(
        [
            "cid",
            "comments",
            "custom_fields",
            "description",
            "owner",
            "provider_account",
            "provider_network",
            "status",
            "tags",
            "tenant",
            "type",
        ]
    ),
    "circuits.virtualcircuittermination": frozenset(
        ["custom_fields", "description", "interface", "role", "tags", "virtual_circuit"]
    ),
    "circuits.virtualcircuittype": frozenset(
        [
            "color",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "dcim.cable": frozenset(
        [
            "a_terminations",
            "b_terminations",
            "color",
            "comments",
            "custom_fields",
            "description",
            "label",
            "length",
            "length_unit",
            "owner",
            "profile",
            "status",
            "tags",
            "tenant",
            "type",
        ]
    ),
    "dcim.cablepath": frozenset(["is_active", "is_complete", "is_split"]),
    "dcim.cabletermination": frozenset(
        ["cable", "cable_end", "termination_id", "termination_type"]
    ),
    "dcim.consoleport": frozenset(
        [
            "custom_fields",
            "description",
            "device",
            "label",
            "mark_connected",
            "module",
            "name",
            "owner",
            "speed",
            "tags",
            "type",
        ]
    ),
    "dcim.consoleserverport": frozenset(
        [
            "custom_fields",
            "description",
            "device",
            "label",
            "mark_connected",
            "module",
            "name",
            "owner",
            "speed",
            "tags",
            "type",
        ]
    ),
    "dcim.device": frozenset(
        [
            "airflow",
            "asset_tag",
            "cluster",
            "comments",
            "custom_fields",
            "description",
            "device_type",
            "face",
            "latitude",
            "location",
            "longitude",
            "name",
            "oob_ip",
            "owner",
            "platform",
            "position",
            "primary_ip4",
            "primary_ip6",
            "rack",
            "role",
            "serial",
            "site",
            "status",
            "tags",
            "tenant",
            "vc_position",
            "vc_priority",
            "virtual_chassis",
        ]
    ),
    "dcim.devicebay": frozenset(
        [
            "custom_fields",
            "description",
            "device",
            "installed_device",
            "label",
            "name",
            "owner",
            "tags",
        ]
    ),
    "dcim.devicerole": frozenset(
        [
            "color",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
            "vm_role",
        ]
    ),
    "dcim.devicetype": frozenset(
        [
            "airflow",
            "comments",
            "custom_fields",
            "default_platform",
            "description",
            "exclude_from_utilization",
            "is_full_depth",
            "manufacturer",
            "model",
            "owner",
            "part_number",
            "slug",
            "subdevice_role",
            "tags",
            "u_height",
            "weight",
            "weight_unit",
        ]
    ),
    "dcim.frontport": frozenset(
        [
            "color",
            "custom_fields",
            "description",
            "device",
            "label",
            "mark_connected",
            "module",
            "name",
            "owner",
            "positions",
            "rear_port",
            "rear_port_position",
            "tags",
            "type",
        ]
    ),
    "dcim.interface": frozenset(
        [
            "bridge",
            "custom_fields",
            "description",
            "device",
            "duplex",
            "enabled",
            "label",
            "lag",
            "mark_connected",
            "mgmt_only",
            "mode",
            "module",
            "mtu",
            "name",
            "owner",
            "parent",
            "poe_mode",
            "poe_type",
            "primary_mac_address",
            "qinq_svlan",
            "rf_channel",
            "rf_channel_frequency",
            "rf_channel_width",
            "rf_role",
            "speed",
            "tagged_vlans",
            "tags",
            "tx_power",
            "type",
            "untagged_vlan",
            "vdcs",
            "vlan_translation_policy",
            "vrf",
            "wireless_lans",
            "wwn",
        ]
    ),
    "dcim.inventoryitem": frozenset(
        [
            "asset_tag",
            "component_id",
            "component_type",
            "custom_fields",
            "description",
            "device",
            "discovered",
            "label",
            "manufacturer",
            "name",
            "owner",
            "parent",
            "part_id",
            "role",
            "serial",
            "status",
            "tags",
        ]
    ),
    "dcim.inventoryitemrole": frozenset(
        [
            "color",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "dcim.location": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "facility",
            "name",
            "owner",
            "parent",
            "site",
            "slug",
            "status",
            "tags",
            "tenant",
        ]
    ),
    "dcim.macaddress": frozenset(
        [
            "assigned_object_id",
            "assigned_object_type",
            "comments",
            "custom_fields",
            "description",
            "mac_address",
            "owner",
            "tags",
        ]
    ),
    "dcim.manufacturer": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "slug", "tags"]
    ),
    "dcim.module": frozenset(
        [
            "asset_tag",
            "comments",
            "custom_fields",
            "description",
            "device",
            "module_bay",
            "module_type",
            "owner",
            "serial",
            "status",
            "tags",
        ]
    ),
    "dcim.modulebay": frozenset(
        [
            "custom_fields",
            "description",
            "device",
            "installed_module",
            "label",
            "module",
            "name",
            "owner",
            "position",
            "tags",
        ]
    ),
    "dcim.moduletype": frozenset(
        [
            "airflow",
            "attributes",
            "comments",
            "custom_fields",
            "description",
            "manufacturer",
            "model",
            "owner",
            "part_number",
            "profile",
            "tags",
            "weight",
            "weight_unit",
        ]
    ),
    "dcim.moduletypeprofile": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "schema", "tags"]
    ),
    "dcim.platform": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "manufacturer",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
        ]
    ),
    "dcim.powerfeed": frozenset(
        [
            "amperage",
            "comments",
            "custom_fields",
            "description",
            "mark_connected",
            "max_utilization",
            "name",
            "owner",
            "phase",
            "power_panel",
            "rack",
            "status",
            "supply",
            "tags",
            "tenant",
            "type",
            "voltage",
        ]
    ),
    "dcim.poweroutlet": frozenset(
        [
            "color",
            "custom_fields",
            "description",
            "device",
            "feed_leg",
            "label",
            "mark_connected",
            "module",
            "name",
            "owner",
            "power_port",
            "status",
            "tags",
            "type",
        ]
    ),
    "dcim.powerpanel": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "location",
            "name",
            "owner",
            "site",
            "tags",
        ]
    ),
    "dcim.powerport": frozenset(
        [
            "allocated_draw",
            "custom_fields",
            "description",
            "device",
            "label",
            "mark_connected",
            "maximum_draw",
            "module",
            "name",
            "owner",
            "tags",
            "type",
        ]
    ),
    "dcim.rack": frozenset(
        [
            "airflow",
            "asset_tag",
            "comments",
            "custom_fields",
            "desc_units",
            "description",
            "facility_id",
            "form_factor",
            "location",
            "max_weight",
            "mounting_depth",
            "name",
            "outer_depth",
            "outer_height",
            "outer_unit",
            "outer_width",
            "owner",
            "rack_type",
            "role",
            "serial",
            "site",
            "starting_unit",
            "status",
            "tags",
            "tenant",
            "u_height",
            "weight",
            "weight_unit",
            "width",
        ]
    ),
    "dcim.rackreservation": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "owner",
            "rack",
            "status",
            "tags",
            "tenant",
            "units",
        ]
    ),
    "dcim.rackrole": frozenset(
        [
            "color",
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "dcim.racktype": frozenset(
        [
            "comments",
            "custom_fields",
            "desc_units",
            "description",
            "form_factor",
            "manufacturer",
            "max_weight",
            "model",
            "mounting_depth",
            "outer_depth",
            "outer_height",
            "outer_unit",
            "outer_width",
            "owner",
            "slug",
            "starting_unit",
            "tags",
            "u_height",
            "weight",
            "weight_unit",
            "width",
        ]
    ),
    "dcim.rearport": frozenset(
        [
            "color",
            "custom_fields",
            "description",
            "device",
            "label",
            "mark_connected",
            "module",
            "name",
            "owner",
            "positions",
            "tags",
            "type",
        ]
    ),
    "dcim.region": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
        ]
    ),
    "dcim.site": frozenset(
        [
            "asns",
            "comments",
            "custom_fields",
            "description",
            "facility",
            "group",
            "latitude",
            "longitude",
            "name",
            "owner",
            "physical_address",
            "region",
            "shipping_address",
            "slug",
            "status",
            "tags",
            "tenant",
            "time_zone",
        ]
    ),
    "dcim.sitegroup": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
        ]
    ),
    "dcim.virtualchassis": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "domain",
            "master",
            "name",
            "owner",
            "tags",
        ]
    ),
    "dcim.virtualdevicecontext": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "device",
            "identifier",
            "name",
            "owner",
            "primary_ip4",
            "primary_ip6",
            "status",
            "tags",
            "tenant",
        ]
    ),
    "extras.customfield": frozenset(
        [
            "choice_set",
            "comments",
            "default",
            "description",
            "filter_logic",
            "group_name",
            "is_cloneable",
            "label",
            "name",
            "object_types",
            "owner",
            "related_object_filter",
            "related_object_type",
            "required",
            "search_weight",
            "type",
            "ui_editable",
            "ui_visible",
            "unique",
            "validation_maximum",
            "validation_minimum",
            "validation_regex",
            "weight",
        ]
    ),
    "extras.customfieldchoiceset": frozenset(
        [
            "base_choices",
            "description",
            "extra_choices",
            "name",
            "order_alphabetically",
            "owner",
        ]
    ),
    "extras.customlink": frozenset(
        [
            "button_class",
            "enabled",
            "group_name",
            "link_text",
            "link_url",
            "name",
            "new_window",
            "object_types",
            "owner",
            "weight",
        ]
    ),
    "extras.journalentry": frozenset(
        [
            "assigned_object_id",
            "assigned_object_type",
            "comments",
            "custom_fields",
            "kind",
            "tags",
        ]
    ),
    "extras.tag": frozenset(
        ["color", "description", "name", "object_types", "slug", "weight"]
    ),
    "ipam.aggregate": frozenset(
        [
            "comments",
            "custom_fields",
            "date_added",
            "description",
            "owner",
            "prefix",
            "rir",
            "tags",
            "tenant",
        ]
    ),
    "ipam.asn": frozenset(
        [
            "asn",
            "comments",
            "custom_fields",
            "description",
            "owner",
            "rir",
            "sites",
            "tags",
            "tenant",
        ]
    ),
    "ipam.asnrange": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "end",
            "name",
            "owner",
            "rir",
            "slug",
            "start",
            "tags",
            "tenant",
        ]
    ),
    "ipam.fhrpgroup": frozenset(
        [
            "auth_key",
            "auth_type",
            "comments",
            "custom_fields",
            "description",
            "group_id",
            "name",
            "owner",
            "protocol",
            "tags",
        ]
    ),
    "ipam.fhrpgroupassignment": frozenset(
        ["group", "interface_id", "interface_type", "priority"]
    ),
    "ipam.ipaddress": frozenset(
        [
            "address",
            "assigned_object_id",
            "assigned_object_type",
            "comments",
            "custom_fields",
            "description",
            "dns_name",
            "nat_inside",
            "owner",
            "role",
            "status",
            "tags",
            "tenant",
            "vrf",
        ]
    ),
    "ipam.iprange": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "end_address",
            "mark_populated",
            "mark_utilized",
            "owner",
            "role",
            "start_address",
            "status",
            "tags",
            "tenant",
            "vrf",
        ]
    ),
    "ipam.prefix": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "is_pool",
            "mark_utilized",
            "owner",
            "prefix",
            "role",
            "scope_id",
            "scope_type",
            "status",
            "tags",
            "tenant",
            "vlan",
            "vrf",
        ]
    ),
    "ipam.rir": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "is_private",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "ipam.role": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "slug",
            "tags",
            "weight",
        ]
    ),
    "ipam.routetarget": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "tags", "tenant"]
    ),
    "ipam.service": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "device",
            "ipaddresses",
            "name",
            "owner",
            "parent_object_id",
            "parent_object_type",
            "ports",
            "protocol",
            "tags",
            "virtual_machine",
        ]
    ),
    "ipam.vlan": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "group",
            "name",
            "owner",
            "qinq_role",
            "qinq_svlan",
            "role",
            "site",
            "status",
            "tags",
            "tenant",
            "vid",
        ]
    ),
    "ipam.vlangroup": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "scope_id",
            "scope_type",
            "slug",
            "tags",
            "tenant",
            "vid_ranges",
        ]
    ),
    "ipam.vlantranslationpolicy": frozenset(
        ["comments", "description", "name", "owner"]
    ),
    "ipam.vlantranslationrule": frozenset(
        ["description", "local_vid", "policy", "remote_vid"]
    ),
    "ipam.vrf": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "enforce_unique",
            "export_targets",
            "import_targets",
            "name",
            "owner",
            "rd",
            "tags",
            "tenant",
        ]
    ),
    "tenancy.contact": frozenset(
        [
            "address",
            "comments",
            "custom_fields",
            "description",
            "email",
            "group",
            "groups",
            "link",
            "name",
            "owner",
            "phone",
            "tags",
            "title",
        ]
    ),
    "tenancy.contactassignment": frozenset(
        [
            "contact",
            "custom_fields",
            "object_id",
            "object_type",
            "priority",
            "role",
            "tags",
        ]
    ),
    "tenancy.contactgroup": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
        ]
    ),
    "tenancy.contactrole": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "slug", "tags"]
    ),
    "tenancy.tenant": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "group",
            "name",
            "owner",
            "slug",
            "tags",
        ]
    ),
    "tenancy.tenantgroup": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
        ]
    ),
    "users.owner": frozenset(["description", "group", "name"]),
    "users.ownergroup": frozenset(["description", "name"]),
    "virtualization.cluster": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "group",
            "name",
            "owner",
            "scope_id",
            "scope_type",
            "status",
            "tags",
            "tenant",
            "type",
        ]
    ),
    "virtualization.clustergroup": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "slug", "tags"]
    ),
    "virtualization.clustertype": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "slug", "tags"]
    ),
    "virtualization.virtualdisk": frozenset(
        [
            "custom_fields",
            "description",
            "name",
            "owner",
            "size",
            "tags",
            "virtual_machine",
        ]
    ),
    "virtualization.virtualmachine": frozenset(
        [
            "cluster",
            "comments",
            "custom_fields",
            "description",
            "device",
            "disk",
            "memory",
            "name",
            "owner",
            "platform",
            "primary_ip4",
            "primary_ip6",
            "role",
            "serial",
            "site",
            "start_on_boot",
            "status",
            "tags",
            "tenant",
            "vcpus",
        ]
    ),
    "virtualization.vminterface": frozenset(
        [
            "bridge",
            "custom_fields",
            "description",
            "enabled",
            "mode",
            "mtu",
            "name",
            "owner",
            "parent",
            "primary_mac_address",
            "qinq_svlan",
            "tagged_vlans",
            "tags",
            "untagged_vlan",
            "virtual_machine",
            "vlan_translation_policy",
            "vrf",
        ]
    ),
    "vpn.ikepolicy": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "mode",
            "name",
            "owner",
            "preshared_key",
            "proposals",
            "tags",
            "version",
        ]
    ),
    "vpn.ikeproposal": frozenset(
        [
            "authentication_algorithm",
            "authentication_method",
            "comments",
            "custom_fields",
            "description",
            "encryption_algorithm",
            "group",
            "name",
            "owner",
            "sa_lifetime",
            "tags",
        ]
    ),
    "vpn.ipsecpolicy": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "pfs_group",
            "proposals",
            "tags",
        ]
    ),
    "vpn.ipsecprofile": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "ike_policy",
            "ipsec_policy",
            "mode",
            "name",
            "owner",
            "tags",
        ]
    ),
    "vpn.ipsecproposal": frozenset(
        [
            "authentication_algorithm",
            "comments",
            "custom_fields",
            "description",
            "encryption_algorithm",
            "name",
            "owner",
            "sa_lifetime_data",
            "sa_lifetime_seconds",
            "tags",
        ]
    ),
    "vpn.l2vpn": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "export_targets",
            "identifier",
            "import_targets",
            "name",
            "owner",
            "slug",
            "status",
            "tags",
            "tenant",
            "type",
        ]
    ),
    "vpn.l2vpntermination": frozenset(
        ["assigned_object_id", "assigned_object_type", "custom_fields", "l2vpn", "tags"]
    ),
    "vpn.tunnel": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "encapsulation",
            "group",
            "ipsec_profile",
            "name",
            "owner",
            "status",
            "tags",
            "tenant",
            "tunnel_id",
        ]
    ),
    "vpn.tunnelgroup": frozenset(
        ["comments", "custom_fields", "description", "name", "owner", "slug", "tags"]
    ),
    "vpn.tunneltermination": frozenset(
        [
            "custom_fields",
            "outside_ip",
            "role",
            "tags",
            "termination_id",
            "termination_type",
            "tunnel",
        ]
    ),
    "wireless.wirelesslan": frozenset(
        [
            "auth_cipher",
            "auth_psk",
            "auth_type",
            "comments",
            "custom_fields",
            "description",
            "group",
            "owner",
            "scope_id",
            "scope_type",
            "ssid",
            "status",
            "tags",
            "tenant",
            "vlan",
        ]
    ),
    "wireless.wirelesslangroup": frozenset(
        [
            "comments",
            "custom_fields",
            "description",
            "name",
            "owner",
            "parent",
            "slug",
            "tags",
        ]
    ),
    "wireless.wirelesslink": frozenset(
        [
            "auth_cipher",
            "auth_psk",
            "auth_type",
            "comments",
            "custom_fields",
            "description",
            "distance",
            "distance_unit",
            "interface_a",
            "interface_b",
            "owner",
            "ssid",
            "status",
            "tags",
            "tenant",
        ]
    ),
}


def legal_fields(object_type: str | Type[models.Model]) -> frozenset[str]:
    if not isinstance(object_type, str):
        object_type = get_object_type(object_type)
    return _LEGAL_FIELDS.get(object_type, frozenset())


def legal_object_types() -> frozenset[str]:
    return frozenset(_LEGAL_FIELDS.keys())


_OBJECT_TYPE_PRIMARY_VALUE_FIELD_MAP = {
    "ipam.asn": "asn",
    "dcim.devicetype": "model",
    "circuits.circuit": "cid",
    "ipam.ipaddress": "address",
    "dcim.macaddress": "mac_address",
    "dcim.moduletype": "model",
    "ipam.prefix": "prefix",
    "dcim.racktype": "model",
    "circuits.virtualcircuit": "cid",
    "wireless.wirelesslan": "ssid",
}


def get_primary_value(data: dict, object_type: str) -> str | None:
    field = _OBJECT_TYPE_PRIMARY_VALUE_FIELD_MAP.get(object_type, "name")
    return data.get(field)


def transform_timestamp_to_date_only(value: str) -> str:
    return datetime.datetime.fromisoformat(value).strftime("%Y-%m-%d")


def transform_float_to_decimal(value: float) -> decimal.Decimal:
    try:
        return decimal.Decimal(str(value))
    except decimal.InvalidOperation:
        raise ValueError(f"Invalid decimal value: {value}")


def int_from_int64string(value: str) -> int:
    return int(value)


def ip_network_defaulting(value: str) -> str:
    try:
        return str(netaddr.IPNetwork(value))
    except netaddr.AddrFormatError:
        raise ValueError(f"Invalid IP network value: {value}")


def parse_json(value: str) -> dict:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def collect_tuples(value, tuple_length, sort=False, reverse=False, base_transform=None):
    if len(value) % tuple_length != 0:
        raise ValueError(f"Array length is not a multiple of {tuple_length}")
    if base_transform is None:
        base_transform = lambda v: v
    vs = [
        [base_transform(v) for v in value[i : i + tuple_length]]
        for i in range(0, len(value), tuple_length)
    ]
    return sorted(vs, reverse=reverse) if sort else vs


def delimited_tuples(
    value, tuple_length, delimiter, sort=False, reverse=False, base_transform=None
):
    if base_transform is None:
        base_transform = lambda v: v
    vs = []
    for v in value:
        vt = re.split(r"(?<!\\)" + delimiter, v, maxsplit=tuple_length - 1)
        if len(vt) < tuple_length:
            vt = [v] * tuple_length
        else:
            vt = [value.replace("\\" + delimiter, delimiter) for value in vt]
        vs.append(vt)
    vs = [[base_transform(v) for v in vt] for vt in vs]
    return sorted(vs, reverse=reverse) if sort else vs


def for_all(transform, sort=False, reverse=False):
    tx = transform or (lambda v: v)

    def wrapper(value):
        if isinstance(value, list):
            vs = [tx(v) for v in value]
            return sorted(vs, reverse=reverse) if sort else vs
        return tx(value)

    return wrapper


_FORMAT_TRANSFORMATIONS = {
    "circuits.circuit": {
        "commit_rate": int_from_int64string,
        "distance": transform_float_to_decimal,
        "install_date": transform_timestamp_to_date_only,
        "termination_date": transform_timestamp_to_date_only,
    },
    "circuits.circuittermination": {
        "port_speed": int_from_int64string,
        "upstream_speed": int_from_int64string,
    },
    "dcim.cable": {
        "length": transform_float_to_decimal,
    },
    "dcim.consoleport": {
        "speed": int_from_int64string,
    },
    "dcim.consoleserverport": {
        "speed": int_from_int64string,
    },
    "dcim.device": {
        "latitude": transform_float_to_decimal,
        "longitude": transform_float_to_decimal,
        "position": transform_float_to_decimal,
        "vc_position": int_from_int64string,
        "vc_priority": int_from_int64string,
    },
    "dcim.devicetype": {
        "u_height": transform_float_to_decimal,
        "weight": transform_float_to_decimal,
    },
    "dcim.frontport": {
        "positions": int_from_int64string,
        "rear_port_position": int_from_int64string,
    },
    "dcim.interface": {
        "mtu": int_from_int64string,
        "rf_channel_frequency": transform_float_to_decimal,
        "rf_channel_width": transform_float_to_decimal,
        "speed": int_from_int64string,
        "tx_power": int_from_int64string,
    },
    "dcim.moduletype": {
        "attributes": parse_json,
        "weight": transform_float_to_decimal,
    },
    "dcim.moduletypeprofile": {
        "schema": parse_json,
    },
    "dcim.powerfeed": {
        "amperage": int_from_int64string,
        "max_utilization": int_from_int64string,
        "voltage": int_from_int64string,
    },
    "dcim.powerport": {
        "allocated_draw": int_from_int64string,
        "maximum_draw": int_from_int64string,
    },
    "dcim.rack": {
        "max_weight": int_from_int64string,
        "mounting_depth": int_from_int64string,
        "outer_depth": int_from_int64string,
        "outer_height": int_from_int64string,
        "outer_width": int_from_int64string,
        "starting_unit": int_from_int64string,
        "u_height": int_from_int64string,
        "weight": transform_float_to_decimal,
        "width": int_from_int64string,
    },
    "dcim.rackreservation": {
        "units": for_all(int_from_int64string, False, False),
    },
    "dcim.racktype": {
        "max_weight": int_from_int64string,
        "mounting_depth": int_from_int64string,
        "outer_depth": int_from_int64string,
        "outer_height": int_from_int64string,
        "outer_width": int_from_int64string,
        "starting_unit": int_from_int64string,
        "u_height": int_from_int64string,
        "weight": transform_float_to_decimal,
        "width": int_from_int64string,
    },
    "dcim.rearport": {
        "positions": int_from_int64string,
    },
    "dcim.site": {
        "latitude": transform_float_to_decimal,
        "longitude": transform_float_to_decimal,
    },
    "dcim.virtualdevicecontext": {
        "identifier": int_from_int64string,
    },
    "extras.customfield": {
        "default": parse_json,
        "object_types": for_all(None, True, False),
        "related_object_filter": parse_json,
        "search_weight": int_from_int64string,
        "validation_maximum": transform_float_to_decimal,
        "validation_minimum": transform_float_to_decimal,
        "weight": int_from_int64string,
    },
    "extras.customfieldchoiceset": {
        "extra_choices": lambda v: delimited_tuples(v, 2, ":", False, False, None),
    },
    "extras.customlink": {
        "object_types": for_all(None, True, False),
        "weight": int_from_int64string,
    },
    "extras.tag": {
        "object_types": for_all(None, True, False),
        "weight": int_from_int64string,
    },
    "ipam.aggregate": {
        "date_added": transform_timestamp_to_date_only,
        "prefix": ip_network_defaulting,
    },
    "ipam.asn": {
        "asn": int_from_int64string,
    },
    "ipam.asnrange": {
        "end": int_from_int64string,
        "start": int_from_int64string,
    },
    "ipam.fhrpgroup": {
        "group_id": int_from_int64string,
    },
    "ipam.fhrpgroupassignment": {
        "priority": int_from_int64string,
    },
    "ipam.ipaddress": {
        "address": ip_network_defaulting,
    },
    "ipam.iprange": {
        "end_address": ip_network_defaulting,
        "start_address": ip_network_defaulting,
    },
    "ipam.prefix": {
        "prefix": ip_network_defaulting,
    },
    "ipam.role": {
        "weight": int_from_int64string,
    },
    "ipam.service": {
        "ports": for_all(int_from_int64string, False, False),
    },
    "ipam.vlan": {
        "vid": int_from_int64string,
    },
    "ipam.vlangroup": {
        "vid_ranges": lambda v: collect_tuples(v, 2, True, False, int_from_int64string),
    },
    "ipam.vlantranslationrule": {
        "local_vid": int_from_int64string,
        "remote_vid": int_from_int64string,
    },
    "virtualization.virtualdisk": {
        "size": int_from_int64string,
    },
    "virtualization.virtualmachine": {
        "disk": int_from_int64string,
        "memory": int_from_int64string,
        "vcpus": transform_float_to_decimal,
    },
    "virtualization.vminterface": {
        "mtu": int_from_int64string,
    },
    "vpn.ikepolicy": {
        "version": int_from_int64string,
    },
    "vpn.ikeproposal": {
        "group": int_from_int64string,
        "sa_lifetime": int_from_int64string,
    },
    "vpn.ipsecpolicy": {
        "pfs_group": int_from_int64string,
    },
    "vpn.ipsecproposal": {
        "sa_lifetime_data": int_from_int64string,
        "sa_lifetime_seconds": int_from_int64string,
    },
    "vpn.l2vpn": {
        "identifier": int_from_int64string,
    },
    "vpn.tunnel": {
        "tunnel_id": int_from_int64string,
    },
    "wireless.wirelesslink": {
        "distance": transform_float_to_decimal,
    },
}


def apply_format_transformations(data: dict, object_type: str):
    for key, transform in _FORMAT_TRANSFORMATIONS.get(object_type, {}).items():
        val = data.get(key, None)
        if val is None:
            continue
        try:
            data[key] = transform(val)
        except ValidationError:
            raise
        except ValueError as e:
            sanitized_object_type = object_type.replace("\n", "").replace("\r", "")
            sanitized_val = str(val).replace("\n", "").replace("\r", "")
            logger.error(
                f"Error processing field {key} in {sanitized_object_type} with value {sanitized_val}: {e}"
            )
            raise ValidationError(
                f"Invalid value for field {key} in {sanitized_object_type}."
            )
        except Exception as e:
            raise ValidationError(f"Invalid value for field {key} in {object_type}")
