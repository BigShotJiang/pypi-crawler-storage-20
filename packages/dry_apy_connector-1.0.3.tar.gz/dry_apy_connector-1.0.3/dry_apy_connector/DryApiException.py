class DryApiException(Exception):
    pass
