import os.path
import shutil
import sys
from pathlib import Path
from textwrap import dedent
from typing import List

from mfcli.client.chroma_db import ChromaClient
from mfcli.models.datasheet import Datasheet
from mfcli.models.project import Project
from mfcli.utils.config import get_config
from mfcli.utils.directory_manager import app_dirs, init_directory_structure
from mfcli.utils.logger import get_logger, setup_logging
from mfcli.utils.orm import Session
from mfcli.utils.query_service import QueryService

logger = get_logger(__name__)

warning_message = dedent(
    """
    
    WARNING: This will permanently delete all mfcli data, including datasheets, cheat sheets, and project data. 
    Should we proceed? (Y/n):
    
    """
)


class DataCleaner:
    def __init__(self, db: Session):
        self._db = db
        self._query_service = QueryService(db)
        self._config = get_config()

    @staticmethod
    def _remove_dir(dir_path: Path):
        if not os.path.isdir(dir_path):
            logger.warning(f"Directory does not exist: {dir_path}")
            return
        try:
            shutil.rmtree(dir_path)
        except Exception as e:
            logger.exception(e)
            logger.error(f"Error deleting directory: {dir_path}")

    @staticmethod
    def _remove_file(file_path: Path):
        if not os.path.isfile(file_path):
            logger.debug(f"File does not exist: {file_path}")
            return
        try:
            os.remove(file_path)
            logger.debug(f"Removed file: {file_path}")
        except Exception as e:
            logger.exception(e)
            logger.error(f"Error deleting file: {file_path}")

    def clean(self):
        logger.info("Cleaning mfcli data")
        
        # Clear all datasheet entries from the database
        datasheets: List[Datasheet] = self._query_service.query_all(Datasheet)
        if datasheets:
            logger.debug(f"Deleting {len(datasheets)} datasheet entries from database")
            for datasheet in datasheets:
                self._db.delete(datasheet)
            self._db.commit()
            logger.info(f"Deleted {len(datasheets)} datasheet entries")
        
        projects: List[Project] = self._query_service.query_all(Project)
        for project in projects:
            init_directory_structure(project.repo_dir)
            config_dir = Path(project.repo_dir) / ".multifactor"
            chroma_db = ChromaClient(project.index_id)
            chroma_db.delete_collection()
            
            # Remove config files
            if app_dirs.config_file_path:
                logger.debug(f"Removing config file: {app_dirs.config_file_path}")
                self._remove_file(app_dirs.config_file_path)
            if app_dirs.file_docket_path:
                logger.debug(f"Removing file docket: {app_dirs.file_docket_path}")
                self._remove_file(app_dirs.file_docket_path)
            
            for dir_path in [
                config_dir,
                app_dirs.agent_instructions_dir,
                app_dirs.data_sheets_dir,
                app_dirs.fw_tasks_dir,
                app_dirs.generated_files_dir,
                app_dirs.reqs_dir,
                app_dirs.cheat_sheets_dir,
                app_dirs.pdf_parts_dir
            ]:
                logger.debug(f"Removing directory: {dir_path}")
                self._remove_dir(dir_path)
            self._db.delete(project)
            self._db.commit()
        logger.info("All mfcli data has been cleaned")


def run_data_cleaner():
    with Session() as db:
        DataCleaner(db).clean()


def clean_app_data(user_accepted: bool = False):
    setup_logging()
    if not user_accepted:
        user_input = input(warning_message)
        if not user_input.strip() == 'Y':
            logger.debug("User cancelled")
            sys.exit()
    run_data_cleaner()
