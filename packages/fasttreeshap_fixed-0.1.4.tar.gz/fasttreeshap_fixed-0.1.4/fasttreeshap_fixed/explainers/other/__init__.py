from ._ubjson import decode_ubjson_buffer

__all__ = ["decode_ubjson_buffer"]

