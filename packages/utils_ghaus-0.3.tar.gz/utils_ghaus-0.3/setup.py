from setuptools import setup, find_packages

setup(
    name="utils_ghaus",
    version="0.3",
    packages=find_packages(),
    description="A simple utility library for basic math and string operation.",
    author="Ghaus Ali",
)
