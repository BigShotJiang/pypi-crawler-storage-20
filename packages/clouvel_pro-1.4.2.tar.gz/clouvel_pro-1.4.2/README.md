# Clouvel Pro

> Shovel 워크플로우 + 프리미엄 기능

**Private 레포** - 라이선스 필요

---

## 설치

```bash
# PyPI에서 설치 (라이선스 활성화 후)
pip install clouvel-pro

# 또는 GitHub에서 직접
pip install git+https://github.com/Whitening-Sinabro/clouvel-pro.git
```

---

## 라이선스 활성화

```bash
# 환경변수로 설정
export CLOUVEL_LICENSE="CLOUVEL-PERSONAL-XXXXX"

# 또는 MCP 도구로 활성화
activate_license(license_key="CLOUVEL-PERSONAL-XXXXX")
```

---

## 가격

| 티어 | 가격 | 인원 |
|------|------|------|
| Personal | $29 | 1명 |
| Team | $79 | 10명 |
| Enterprise | $199 | 무제한 |

구매: https://clouvel.lemonsqueezy.com

---

## Pro 기능

### 1. Shovel 자동 설치

```
install_shovel(path="./my-project")
```

생성되는 구조:
```
.claude/
├── commands/      (슬래시 커맨드)
│   ├── gate.md
│   ├── plan.md
│   ├── implement.md
│   ├── verify.md
│   ├── learn-error.md
│   └── ...
├── templates/
├── evidence/
├── logs/
├── plans/
└── settings.json
```

### 2. Error Learning

에러 패턴 자동 학습 + 방지 규칙 생성

```
log_error(path=".", error_text="TypeError: ...")
analyze_error(path=".", include_history=true)
add_prevention_rule(path=".", error_type="type_error", rule="...")
get_error_summary(path=".", days=30)
```

### 3. 커맨드 동기화

```
sync_commands(path=".", mode="merge")
```

---

## MCP 서버 설정

### Claude Desktop

`claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "clouvel-pro": {
      "command": "clouvel-pro",
      "env": {
        "CLOUVEL_LICENSE": "CLOUVEL-PERSONAL-XXXXX"
      }
    }
  }
}
```

### Claude Code

```bash
claude mcp add clouvel-pro -- clouvel-pro
```

---

## Shovel 워크플로우

```
/start → /plan → /implement → /gate → /commit
```

| 커맨드 | 설명 |
|--------|------|
| /start | 프로젝트 온보딩 |
| /plan | 계획 수립 (7 Theories) |
| /implement | 구현 실행 |
| /gate | lint → test → build |
| /verify | Context Bias 검증 |
| /commit | Gate PASS 후 커밋 |
| /learn-error | 에러 학습 |

---

## Free vs Pro

| 기능 | Free (clouvel) | Pro (clouvel-pro) |
|------|----------------|-------------------|
| can_code | ✅ | ✅ |
| PRD 템플릿 | ✅ | ✅ |
| Gate | ✅ | ✅ |
| Verify | ✅ | ✅ |
| Planning | ✅ | ✅ |
| Agents | ✅ | ✅ |
| Hooks | ✅ | ✅ |
| **Shovel 자동 설치** | ❌ | ✅ |
| **Error Learning** | ❌ | ✅ |
| **커맨드 동기화** | ❌ | ✅ |

---

## 지원

- Issues: (private repo)
- Email: support@clouvel.dev

---

## 라이선스

Proprietary - 상용 라이선스 필요
