"""
polydup - Python bindings and CLI wrapper for duplicate code detection

This module provides both:
1. Python library bindings for the PolyDup duplicate code detector
2. A CLI wrapper that delegates to the Rust binary (if installed)

For CLI usage:
    python -m polydup scan ./src

For library usage in Python:
    import polydup
    duplicates = polydup.find_duplicates(['src/'], 50, 0.85)
"""

import shutil
import subprocess
import sys


def main():
    """CLI entry point that wraps the Rust binary."""
    # Check if the polydup binary is available
    binary = shutil.which("polydup")

    if binary:
        # Delegate to the Rust CLI
        try:
            result = subprocess.run([binary] + sys.argv[1:])
            sys.exit(result.returncode)
        except KeyboardInterrupt:
            sys.exit(130)
        except Exception as e:
            print(f"Error running polydup: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        # Binary not found - provide helpful instructions
        print("polydup CLI binary not found.", file=sys.stderr)
        print(file=sys.stderr)
        print("The polydup pip package provides Python library bindings.", file=sys.stderr)
        print("For CLI functionality, install the Rust binary:", file=sys.stderr)
        print(file=sys.stderr)
        print("    cargo install polydup", file=sys.stderr)
        print(file=sys.stderr)
        print("Or use the Python library directly:", file=sys.stderr)
        print(file=sys.stderr)
        print("    import polydup", file=sys.stderr)
        print("    duplicates = polydup.find_duplicates(['src/'], min_block_size=50, similarity=0.85)", file=sys.stderr)
        print(file=sys.stderr)
        print("For more information: https://github.com/wiesnerbernard/polydup", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
