"""Tests for CLI interface."""

import pytest
from click.testing import CliRunner

from src.cli import main, validate_project_name


def test_validate_project_name():
    """Test project name validation."""
    # Valid names
    assert validate_project_name("my-project") is True
    assert validate_project_name("my_project") is True
    assert validate_project_name("MyProject") is True
    assert validate_project_name("project123") is True
    assert validate_project_name("_project") is True
    
    # Invalid names
    assert validate_project_name("") is False
    assert validate_project_name("my project") is False  # spaces
    assert validate_project_name("123project") is False  # starts with number
    assert validate_project_name("my-project!") is False  # special char


def test_cli_help():
    """Test CLI help command."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "API Template PY" in result.output


def test_cli_version():
    """Test CLI version command."""
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0


def test_create_command_help():
    """Test create command help."""
    runner = CliRunner()
    result = runner.invoke(main, ["create", "--help"])
    assert result.exit_code == 0
    assert "Create a new API project" in result.output


def test_create_command_non_interactive_missing_name():
    """Test create command in non-interactive mode without project name."""
    runner = CliRunner()
    result = runner.invoke(main, ["create", "--non-interactive"])
    assert result.exit_code == 1
    assert "Project name is required" in result.output


def test_create_command_non_interactive_invalid_name():
    """Test create command with invalid project name."""
    runner = CliRunner()
    result = runner.invoke(main, ["create", "my project", "--non-interactive"])
    assert result.exit_code == 1
    assert "Invalid project name" in result.output


def test_create_command_non_interactive_success(tmp_path):
    """Test successful project creation in non-interactive mode."""
    runner = CliRunner()
    
    # Change to temp directory
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(
            main,
            [
                "create",
                "test-project",
                "--description", "Test project",
                "--author", "Test Author",
                "--email", "test@example.com",
                "--python-version", "3.10",
                "--non-interactive",
            ],
        )
        
        assert result.exit_code == 0
        assert "Project created successfully" in result.output
        
        # Check that project directory was created
        import os
        assert os.path.exists("test-project")
        assert os.path.exists("test-project/pyproject.toml")


def test_create_command_existing_directory(tmp_path):
    """Test create command with existing directory."""
    runner = CliRunner()
    
    with runner.isolated_filesystem(temp_dir=tmp_path):
        # Create directory first
        import os
        os.makedirs("test-project")
        
        result = runner.invoke(
            main,
            [
                "create",
                "test-project",
                "--non-interactive",
            ],
        )
        
        assert result.exit_code == 1
        assert "already exists" in result.output

