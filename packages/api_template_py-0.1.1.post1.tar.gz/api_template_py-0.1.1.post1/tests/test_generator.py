"""Tests for project generator."""

import shutil
from pathlib import Path

import pytest

from src.generator import ProjectGenerator


@pytest.fixture
def test_config():
    """Test project configuration."""
    return {
        "project_name": "test-project",
        "project_slug": "test_project",
        "project_description": "Test project description",
        "author_name": "Test Author",
        "author_email": "test@example.com",
        "python_version": "3.10",
        "init_git": False,
    }


@pytest.fixture
def test_output_dir(tmp_path):
    """Create and cleanup test output directory."""
    output_dir = tmp_path / "test_output"
    output_dir.mkdir(exist_ok=True)
    yield output_dir
    # Cleanup
    if output_dir.exists():
        shutil.rmtree(output_dir)


def test_generator_initialization(test_config):
    """Test generator initialization."""
    generator = ProjectGenerator(test_config)
    assert generator.config == test_config
    assert generator.env is not None


def test_directory_structure_creation(test_config, test_output_dir):
    """Test that directory structure is created correctly."""
    target_dir = test_output_dir / test_config["project_name"]
    generator = ProjectGenerator(test_config)
    generator._create_directory_structure(target_dir)
    
    # Check main directories exist
    assert target_dir.exists()
    assert (target_dir / "src").exists()
    assert (target_dir / "src" / "api").exists()
    assert (target_dir / "src" / "api" / "v1").exists()
    assert (target_dir / "src" / "services").exists()
    assert (target_dir / "src" / "repositories").exists()
    assert (target_dir / "src" / "models").exists()
    assert (target_dir / "src" / "core").exists()
    assert (target_dir / "tests").exists()


def test_file_generation(test_config, test_output_dir):
    """Test that files are generated from templates."""
    target_dir = test_output_dir / test_config["project_name"]
    generator = ProjectGenerator(test_config)
    generator._create_directory_structure(target_dir)
    generator._generate_files(target_dir)
    
    # Check root files
    assert (target_dir / "pyproject.toml").exists()
    assert (target_dir / "README.md").exists()
    assert (target_dir / ".gitignore").exists()
    assert (target_dir / ".env.example").exists()
    
    # Check main.py
    assert (target_dir / "src" / "main.py").exists()
    
    # Check API layer
    assert (target_dir / "src" / "api" / "__init__.py").exists()
    assert (target_dir / "src" / "api" / "dependencies.py").exists()
    assert (target_dir / "src" / "api" / "v1" / "health.py").exists()
    assert (target_dir / "src" / "api" / "v1" / "items.py").exists()
    
    # Check service layer
    assert (target_dir / "src" / "services" / "base_service.py").exists()
    assert (target_dir / "src" / "services" / "item_service.py").exists()
    
    # Check repository layer
    assert (target_dir / "src" / "repositories" / "interfaces.py").exists()
    assert (target_dir / "src" / "repositories" / "item_repository.py").exists()
    
    # Check models
    assert (target_dir / "src" / "models" / "domain.py").exists()
    assert (target_dir / "src" / "models" / "schemas.py").exists()
    
    # Check core
    assert (target_dir / "src" / "core" / "config.py").exists()
    assert (target_dir / "src" / "core" / "exceptions.py").exists()


def test_template_rendering(test_config, test_output_dir):
    """Test that templates are rendered with correct values."""
    target_dir = test_output_dir / test_config["project_name"]
    generator = ProjectGenerator(test_config)
    generator._create_directory_structure(target_dir)
    generator._generate_files(target_dir)
    
    # Check pyproject.toml contains project name
    pyproject = (target_dir / "pyproject.toml").read_text(encoding='utf-8')
    assert f'name = "{test_config["project_name"]}"' in pyproject
    assert f'"{test_config["author_name"]}"' in pyproject
    assert f'"{test_config["author_email"]}"' in pyproject
    
    # Check README contains project name
    readme = (target_dir / "README.md").read_text(encoding='utf-8')
    assert test_config["project_name"] in readme
    
    # Check main.py imports use src folder
    main_py = (target_dir / "src" / "main.py").read_text(encoding='utf-8')
    assert "from src.api.v1 import" in main_py
    assert "from src.core.config import" in main_py


def test_full_generation(test_config, test_output_dir):
    """Test full project generation."""
    target_dir = test_output_dir / test_config["project_name"]
    generator = ProjectGenerator(test_config)
    generator.generate(target_dir)
    
    # Verify project structure exists
    assert target_dir.exists()
    assert (target_dir / "pyproject.toml").exists()
    assert (target_dir / "src" / "main.py").exists()

