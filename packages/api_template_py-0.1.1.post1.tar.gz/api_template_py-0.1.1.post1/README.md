# API Template PY

[![PyPI version](https://badge.fury.io/py/api-template-py.svg)](https://badge.fury.io/py/api-template-py)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![uv](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json)](https://github.com/astral-sh/uv)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A powerful CLI tool to scaffold Python API projects following **Clean Architecture** principles with **FastAPI**.

## Features

- **Clean Architecture**: Clear separation of concerns with layered architecture
- **FastAPI**: Modern, fast, and production-ready web framework
- **Complete Project Structure**: Pre-configured with all necessary layers
- **Interactive CLI**: Beautiful terminal UI with prompts and colors
- **Dependency Injection**: Built-in DI pattern for loose coupling
- **Type Hints**: Full type safety throughout the codebase

## Installation

### Using uv (Recommended)

```bash
# Install uv if you haven't already
pip install uv

# Run directly with uv (no installation needed)
uv run api-template --version
```

### Using pip

```bash
pip install api-template-py
```

## Quick Start

### Create a New Project

```bash
# Interactive mode
uv run api-template create

# Non-interactive mode
uv run api-template create test-project --non-interactive
```

### Run Your New Project

```bash
cd test-project
uv run uvicorn src.main:app --reload
```

Your API will be available at:
- **API**: http://localhost:8000
- **Interactive Docs**: http://localhost:8000/docs

## CLI Commands

### `api-template create`

**Options:**
- `PROJECT_NAME` - Project name (optional, will prompt if not provided)
- `--description, -d` - Project description
- `--author, -a` - Author name
- `--email, -e` - Author email
- `--python-version, -p` - Python version (3.10, 3.11, 3.12)
- `--no-git` - Skip git initialization
- `--non-interactive` - Non-interactive mode

**Examples:**

```bash
# Interactive mode
uv run api-template create

# With project name
uv run api-template create my-api

# Full non-interactive
uv run api-template create my-api \
  --description "My API" \
  --author "Jane Doe" \
  --email "jane@example.com" \
  --python-version 3.11 \
  --non-interactive
```

## License

MIT License - see the [LICENSE](LICENSE) file for details.

