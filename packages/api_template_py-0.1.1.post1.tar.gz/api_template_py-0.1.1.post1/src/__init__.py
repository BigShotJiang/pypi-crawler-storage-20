"""API Template PY - A CLI tool to scaffold Python API projects following Clean Architecture."""

__version__ = "0.1.0"
__author__ = "API Template PY Contributors"

