"""Project generator for API Template PY."""

import subprocess
from pathlib import Path
from typing import Dict, Any

from jinja2 import Environment, PackageLoader, select_autoescape
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


class ProjectGenerator:
    """Generates a new API project from templates."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize generator with project configuration.
        
        Args:
            config: Project configuration dictionary
        """
        self.config = config
        self.env = Environment(
            loader=PackageLoader("src", "templates"),
            autoescape=select_autoescape(),
            trim_blocks=True,
            lstrip_blocks=True,
        )
    
    def generate(self, target_dir: Path) -> None:
        """Generate the project structure.
        
        Args:
            target_dir: Target directory for the project
        """
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            # Create directory structure
            task = progress.add_task("Creating directory structure...", total=None)
            self._create_directory_structure(target_dir)
            progress.remove_task(task)
            
            # Generate files from templates
            task = progress.add_task("Generating files from templates...", total=None)
            self._generate_files(target_dir)
            progress.remove_task(task)
            
            # Initialize git if requested
            if self.config.get("init_git", False):
                task = progress.add_task("Initializing git repository...", total=None)
                self._init_git(target_dir)
                progress.remove_task(task)
    
    def _create_directory_structure(self, target_dir: Path) -> None:
        """Create the project directory structure.
        
        Args:
            target_dir: Target directory for the project
        """
        # Create main directories using 'src' as the source folder name
        directories = [
            target_dir,
            target_dir / "src",
            target_dir / "src" / "api",
            target_dir / "src" / "api" / "v1",
            target_dir / "src" / "services",
            target_dir / "src" / "repositories",
            target_dir / "src" / "models",
            target_dir / "src" / "core",
            target_dir / "tests",
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def _generate_files(self, target_dir: Path) -> None:
        """Generate files from Jinja2 templates.
        
        Args:
            target_dir: Target directory for the project
        """
        # Define files to generate using 'src' as the source folder name
        files_to_generate = [
            # Root files
            ("pyproject.toml.j2", target_dir / "pyproject.toml"),
            ("README.md.j2", target_dir / "README.md"),
            ("gitignore.j2", target_dir / ".gitignore"),
            ("env.example.j2", target_dir / ".env.example"),
            ("main.py.j2", target_dir / "src" / "main.py"),
            
            # API layer
            ("api/__init__.py.j2", target_dir / "src" / "api" / "__init__.py"),
            ("api/dependencies.py.j2", target_dir / "src" / "api" / "dependencies.py"),
            ("api/v1/__init__.py.j2", target_dir / "src" / "api" / "v1" / "__init__.py"),
            ("api/v1/health.py.j2", target_dir / "src" / "api" / "v1" / "health.py"),
            ("api/v1/items.py.j2", target_dir / "src" / "api" / "v1" / "items.py"),
            
            # Service layer
            ("services/__init__.py.j2", target_dir / "src" / "services" / "__init__.py"),
            ("services/base_service.py.j2", target_dir / "src" / "services" / "base_service.py"),
            ("services/item_service.py.j2", target_dir / "src" / "services" / "item_service.py"),
            
            # Repository layer
            ("repositories/__init__.py.j2", target_dir / "src" / "repositories" / "__init__.py"),
            ("repositories/interfaces.py.j2", target_dir / "src" / "repositories" / "interfaces.py"),
            ("repositories/base_repository.py.j2", target_dir / "src" / "repositories" / "base_repository.py"),
            ("repositories/item_repository.py.j2", target_dir / "src" / "repositories" / "item_repository.py"),
            
            # Models
            ("models/__init__.py.j2", target_dir / "src" / "models" / "__init__.py"),
            ("models/domain.py.j2", target_dir / "src" / "models" / "domain.py"),
            ("models/schemas.py.j2", target_dir / "src" / "models" / "schemas.py"),
            
            # Core
            ("core/__init__.py.j2", target_dir / "src" / "core" / "__init__.py"),
            ("core/config.py.j2", target_dir / "src" / "core" / "config.py"),
            ("core/constants.py.j2", target_dir / "src" / "core" / "constants.py"),
            ("core/exceptions.py.j2", target_dir / "src" / "core" / "exceptions.py"),
            ("core/middleware.py.j2", target_dir / "src" / "core" / "middleware.py"),
            
            # Tests
            ("tests/__init__.py.j2", target_dir / "tests" / "__init__.py"),
            ("tests/test_items.py.j2", target_dir / "tests" / "test_items.py"),
        ]
        
        # Generate each file
        for template_name, output_path in files_to_generate:
            template = self.env.get_template(template_name)
            content = template.render(**self.config)
            output_path.write_text(content, encoding="utf-8")
    
    def _init_git(self, target_dir: Path) -> None:
        """Initialize git repository.
        
        Args:
            target_dir: Target directory for the project
        """
        try:
            subprocess.run(
                ["git", "init"],
                cwd=target_dir,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "add", "."],
                cwd=target_dir,
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["git", "commit", "-m", "Initial commit from api-template-py"],
                cwd=target_dir,
                check=True,
                capture_output=True,
            )
        except (subprocess.CalledProcessError, FileNotFoundError):
            # Git not available or command failed - not critical
            console.print("[yellow]Git initialization skipped (git not available)[/yellow]")

