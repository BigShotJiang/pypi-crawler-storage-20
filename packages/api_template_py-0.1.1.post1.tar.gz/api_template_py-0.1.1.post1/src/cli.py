"""CLI interface for API Template PY."""

import re
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt, Confirm

from .generator import ProjectGenerator

# Console with better encoding support for Windows
console = Console(force_terminal=True, legacy_windows=False)


def validate_project_name(name: str) -> bool:
    """Validate project name to ensure it's a valid Python package name.
    
    Args:
        name: The project name to validate
        
    Returns:
        True if valid, False otherwise
    """
    # Must be valid Python identifier (no spaces, starts with letter/underscore)
    if not re.match(r'^[a-zA-Z_][a-zA-Z0-9_-]*$', name):
        return False
    # Should not be empty
    if not name or len(name) == 0:
        return False
    return True


def get_project_info() -> dict:
    """Interactively collect project information from user.
    
    Returns:
        Dictionary containing project configuration
    """
    console.print("\n[bold cyan]API Template PY - Clean Architecture Project Generator[/bold cyan]\n")
    
    # Project name
    while True:
        project_name = Prompt.ask(
            "[yellow]Project name[/yellow]",
            default="my-api-project"
        )
        if validate_project_name(project_name):
            break
        console.print("[red]Invalid project name. Use only letters, numbers, underscores, and hyphens. Must start with a letter or underscore.[/red]")
    
    # Project description
    project_description = Prompt.ask(
        "[yellow]Project description[/yellow]",
        default="A FastAPI project following Clean Architecture"
    )
    
    # Author name
    author_name = Prompt.ask(
        "[yellow]Author name[/yellow]",
        default="Your Name"
    )
    
    # Author email
    author_email = Prompt.ask(
        "[yellow]Author email[/yellow]",
        default="your.email@example.com"
    )
    
    # Python version
    python_version = Prompt.ask(
        "[yellow]Minimum Python version[/yellow]",
        default="3.10",
        choices=["3.10", "3.11", "3.12"]
    )
    
    # Initialize git
    init_git = Confirm.ask(
        "[yellow]Initialize git repository?[/yellow]",
        default=True
    )
    
    return {
        "project_name": project_name,
        "project_slug": project_name.replace("-", "_"),
        "project_description": project_description,
        "author_name": author_name,
        "author_email": author_email,
        "python_version": python_version,
        "init_git": init_git,
    }


@click.group()
@click.version_option(version="0.1.0", prog_name="api-template-py")
def main():
    """API Template PY - Generate Clean Architecture FastAPI projects."""
    pass


@main.command()
@click.argument("project_name", required=False)
@click.option(
    "--description",
    "-d",
    help="Project description",
)
@click.option(
    "--author",
    "-a",
    help="Author name",
)
@click.option(
    "--email",
    "-e",
    help="Author email",
)
@click.option(
    "--python-version",
    "-p",
    type=click.Choice(["3.10", "3.11", "3.12"]),
    help="Minimum Python version",
)
@click.option(
    "--no-git",
    is_flag=True,
    help="Skip git initialization",
)
@click.option(
    "--non-interactive",
    is_flag=True,
    help="Run in non-interactive mode (use defaults or provided options)",
)
def create(
    project_name: Optional[str],
    description: Optional[str],
    author: Optional[str],
    email: Optional[str],
    python_version: Optional[str],
    no_git: bool,
    non_interactive: bool,
):
    """Create a new API project with Clean Architecture.
    
    Examples:
        api-template create my-project
        api-template create my-project --author "John Doe" --email "john@example.com"
        api-template create --non-interactive my-project
    """
    try:
        # Get project information
        if non_interactive:
            # Non-interactive mode: use provided options or defaults
            if not project_name:
                console.print("[red]Project name is required in non-interactive mode[/red]")
                sys.exit(1)
            
            if not validate_project_name(project_name):
                console.print("[red]Invalid project name[/red]")
                sys.exit(1)
            
            config = {
                "project_name": project_name,
                "project_slug": project_name.replace("-", "_"),
                "project_description": description or "A FastAPI project following Clean Architecture",
                "author_name": author or "Your Name",
                "author_email": email or "your.email@example.com",
                "python_version": python_version or "3.10",
                "init_git": not no_git,
            }
        else:
            # Interactive mode
            if project_name:
                # Validate provided name
                if not validate_project_name(project_name):
                    console.print("[red]Invalid project name[/red]")
                    sys.exit(1)
            
            # Get all info interactively (with some pre-filled if provided)
            config = get_project_info()
            
            # Override with command-line options if provided
            if project_name:
                config["project_name"] = project_name
                config["project_slug"] = project_name.replace("-", "_")
            if description:
                config["project_description"] = description
            if author:
                config["author_name"] = author
            if email:
                config["author_email"] = email
            if python_version:
                config["python_version"] = python_version
            if no_git:
                config["init_git"] = False
        
        # Check if directory already exists
        target_dir = Path.cwd() / config["project_name"]
        if target_dir.exists():
            console.print(f"[red]Directory '{config['project_name']}' already exists![/red]")
            sys.exit(1)
        
        # Generate project
        console.print(f"\n[cyan]Building project '{config['project_name']}'...[/cyan]\n")
        
        generator = ProjectGenerator(config)
        generator.generate(target_dir)
        
        # Success message
        console.print(Panel.fit(
            f"[green]Project created successfully![/green]\n\n"
            f"[yellow]Next steps:[/yellow]\n"
            f"  cd {config['project_name']}\n"
            f"  python -m venv .venv\n"
            f"  source .venv/bin/activate  [dim]# Windows: .venv\\Scripts\\activate[/dim]\n"
            f"  pip install -e .\n"
            f"  uvicorn src.main:app --reload\n\n"
            f"[cyan]Your API will be available at:[/cyan] http://localhost:8000\n"
            f"[cyan]API docs:[/cyan] http://localhost:8000/docs",
            title="[bold green]Success![/bold green]",
            border_style="green"
        ))
        
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
        sys.exit(130)
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()

