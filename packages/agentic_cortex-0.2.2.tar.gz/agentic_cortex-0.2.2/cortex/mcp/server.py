"""MCP server implementation for Cortex using FastMCP.

This module implements the MCP server entry point that wires up resources and tools,
handles stdio transport, and manages database connections using FastMCP framework.
"""

from pathlib import Path
from typing import Any, Optional

from fastmcp import FastMCP
from fastmcp.dependencies import Depends

from cortex.db.sqlite import initialize_db
from cortex.core.search_engine import SearchEngine
from cortex.core.graph import GraphQuery
from cortex.core.inspection import read_file_skeleton
from cortex.vector.store import VectorStore
from cortex.mcp.resources import (
    get_skeleton_resource,
    get_relevant_memories_resource,
)
from cortex.mcp.tools import (
    search_codebase_tool as _search_codebase_tool,
    inspect_symbol_tool as _inspect_symbol_tool,
    impact_analysis_tool as _impact_analysis_tool,
    attach_memory_tool as _attach_memory_tool,
)
from cortex.core.benchmark import Benchmarker, format_benchmark_report


# FastMCP server instance
mcp = FastMCP(name="Cortex", version="0.1.0")

# Module-level storage for initialized resources (set by run_server)
_db_conn: Optional[Any] = None
_vector_store: Optional[VectorStore] = None
_search_engine: Optional[SearchEngine] = None
_graph_query: Optional[GraphQuery] = None
_project_root: Optional[Path] = None


# Dependency injection functions
def get_db_conn():
    """Get SQLite database connection."""
    if _db_conn is None:
        raise ValueError("Database connection not initialized. Call run_server() first.")
    return _db_conn


def get_vector_store() -> VectorStore:
    """Get VectorStore instance."""
    if _vector_store is None:
        raise ValueError("Vector store not initialized. Call run_server() first.")
    return _vector_store


def get_search_engine() -> SearchEngine:
    """Get SearchEngine instance."""
    if _search_engine is None:
        raise ValueError("SearchEngine not initialized. Call run_server() first.")
    return _search_engine


def get_graph_query() -> GraphQuery:
    """Get GraphQuery instance."""
    if _graph_query is None:
        raise ValueError("GraphQuery not initialized. Call run_server() first.")
    return _graph_query


def get_project_root() -> Path:
    """Get project root path."""
    if _project_root is None:
        raise ValueError("Project root not initialized. Call run_server() first.")
    return _project_root


# Tools
@mcp.tool(
    name="search_codebase",
    description="""
    The PRIMARY search tool. Use this FIRST.
    Finds code by name (fuzzy match) or by concept (semantic match).
    Returns a list of 'Symbol IDs' that you can inspect later.
    """,
)
async def search_codebase_tool(
    query: str,
    type: Optional[str] = None,
    search_engine: SearchEngine = Depends(get_search_engine),
) -> str:
    result = _search_codebase_tool(query, type, search_engine)
    symbol_ids = result.get("results") or result.get("symbols") or result.get("matches") or []
    return "\n".join(symbol_ids) if symbol_ids else "No results found"


@mcp.tool(
    name="read_file_skeleton",
    description="""
    TOKEN-EFFICIENT file reader.
    Returns the file structure (classes, functions, docstrings) but HIDES the implementation bodies with '...'.

    ALWAYS use this tool INSTEAD of 'read_file' when first exploring a file.
    It saves context window space.
    If you need to see the logic of a specific function, use 'inspect_symbol' next.
    """,
)
async def read_file_skeleton_tool(
    file_path: str,
    conn: Any = Depends(get_db_conn),
) -> str:
    """Read file skeleton (structure without implementation bodies)."""
    skeleton = read_file_skeleton(conn, file_path)
    return skeleton


@mcp.tool(
    name="inspect_symbol",
    description="""
    The 'Hydration' tool.
    Reveals the full source code (implementation) of a SPECIFIC symbol (function or class).

    Use this ONLY after using 'read_file_skeleton' or 'search_codebase' to get a Symbol ID.
    Do not use this to read entire files.
    """,
)
async def inspect_symbol_tool(
    symbol_id: str,
    conn: Any = Depends(get_db_conn),
) -> str:
    result = _inspect_symbol_tool(symbol_id, conn)
    return result.get("code") or result.get("contents") or result.get("text") or ""


@mcp.tool(
    name="impact_analysis",
    description="""
    Safety check.
    Before editing a function, call this to see a graph of who calls it (upstream dependencies).
    Prevents breaking changes in other files.
    """,
)
async def impact_analysis_tool(
    symbol_id: str,
    depth: Optional[int] = None,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    result = _impact_analysis_tool(symbol_id, depth, graph_query)
    impacted = result.get("impact") or result.get("symbols") or result.get("downstream") or []
    return "\n".join(impacted) if impacted else "No upstream callers found"


@mcp.tool
async def attach_memory(
    symbol_id: str,
    content: str,
    store: VectorStore = Depends(get_vector_store),
) -> str:
    """Attach a memory (semantic note) to a symbol."""
    result = _attach_memory_tool(symbol_id, content, store)

    if result.get("success") or result.get("status") == "success":
        return f"Memory attached to {symbol_id} successfully"
    else:
        return f"Failed to attach memory to {symbol_id}"


@mcp.tool(
    name="benchmark",
    description="""
    Run a benchmark comparing traditional file reading vs Cortex's token-efficient approach.

    ⚠️  WARNING: This tool is EXPENSIVE in terms of token consumption.
    It intentionally reads files using both traditional and Cortex approaches
    to demonstrate the savings. Only run this when you specifically want to
    measure and compare token consumption.

    REQUIRED: You must pass confirm=true to run this benchmark.

    The benchmark runs several scenarios:
    1. Understanding a single file
    2. Finding a specific function
    3. Exploring a module (multiple files)
    4. Impact analysis (finding callers)
    5. Full codebase overview

    Returns a detailed report comparing token consumption and savings.
    """,
)
async def benchmark_tool(
    confirm: bool = False,
    conn: Any = Depends(get_db_conn),
    project_root: Path = Depends(get_project_root),
) -> str:
    """Run benchmark comparing traditional vs Cortex approaches."""
    if not confirm:
        return """⚠️  BENCHMARK REQUIRES CONFIRMATION

This benchmark is intentionally expensive - it reads files using BOTH
traditional and Cortex approaches to measure token savings.

To run the benchmark, call again with confirm=true:

    benchmark(confirm=true)

Expected cost: ~70,000 tokens (varies by codebase size)
Expected result: Detailed comparison showing typical 80-90% token savings
"""

    benchmarker = Benchmarker(project_root, conn)
    result = benchmarker.run_all_scenarios()
    return format_benchmark_report(result)


# Resources
@mcp.resource("cortex://{filepath*}/skeleton")
async def get_skeleton(
    filepath: str,
    conn: Any = Depends(get_db_conn),
) -> str:
    """Skeleton code for a file."""
    resource_uri = f"cortex://{filepath}/skeleton"
    result = get_skeleton_resource(resource_uri, conn)
    return result.get("contents") or result.get("text") or result.get("body") or ""


@mcp.resource("cortex://graph/callers/{symbol_id}")
async def get_callers(
    symbol_id: str,
    graph_query: GraphQuery = Depends(get_graph_query),
) -> str:
    """Callers (upstream dependencies) for a symbol."""
    # Use GraphQuery to get upstream callers
    callers = graph_query.get_upstream(symbol_id, depth=2)
    return "\n".join(callers) if callers else "No callers found"


@mcp.resource("cortex://memory/relevant/{symbol_id}")
async def get_relevant_memories(
    symbol_id: str,
    store: VectorStore = Depends(get_vector_store),
) -> str:
    """Relevant memories anchored to a symbol."""
    resource_uri = f"cortex://memory/relevant/{symbol_id}"
    result = get_relevant_memories_resource(resource_uri, store)
    memories = result.get("memories") or result.get("contents") or result.get("texts") or []
    return "\n".join(memories) if memories else "No memories found"


def run_server(
    db_path: Optional[str] = None,
    lancedb_path: Optional[str] = None,
) -> None:
    """Run the MCP server with stdio transport.

    Loads config from .cortex/ directory to get database paths.
    If db_path or lancedb_path are provided, they override config values.

    Args:
        db_path: Optional path to SQLite database file (overrides config)
        lancedb_path: Optional path to LanceDB directory (overrides config)
    """
    global _db_conn, _vector_store, _search_engine, _graph_query, _project_root

    from cortex.config import find_cortex_root, load_config, get_db_paths

    # Load config from .cortex/ directory
    try:
        # Try to find .cortex/ from current working directory
        cwd = Path.cwd()
        cortex_dir = find_cortex_root(cwd)
        _project_root = cortex_dir.parent  # Project root is parent of .cortex/
        config = load_config(cortex_dir)
        config_sqlite_path, config_lancedb_path = get_db_paths(config, cortex_dir)

        # Use provided paths or fall back to config paths
        final_db_path = db_path or str(config_sqlite_path)
        final_lancedb_path = lancedb_path or str(config_lancedb_path)
    except (FileNotFoundError, ValueError):
        # If config not found, require explicit paths
        if db_path is None:
            raise ValueError(
                "Could not find .cortex/ directory. Either run 'cortex init' first, "
                "or provide db_path and lancedb_path explicitly."
            )
        final_db_path = db_path
        final_lancedb_path = lancedb_path

    # Initialize database connections
    _db_conn = initialize_db(final_db_path)
    _vector_store = VectorStore(final_lancedb_path)

    # Note: initialize_lancedb() is called by VectorStore.__init__, no need to call again

    # Initialize SearchEngine and GraphQuery
    _search_engine = SearchEngine(_db_conn, _vector_store)
    _graph_query = GraphQuery(_db_conn)

    # Run FastMCP server (this blocks until server exits)
    mcp.run()


if __name__ == "__main__":
    # When run directly, try to load from config
    # This allows the server to be started without explicit paths
    run_server()
