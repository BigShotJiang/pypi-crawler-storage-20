import logging
from pathlib import Path
from typing import List, Optional
import time

import pandas as pd
import pyreadstat
from openpyxl import Workbook

logger = logging.getLogger(__name__)

# Excel 单个 sheet 的最大行数上限（openpyxl/pandas 与 Excel 规范一致）
MAX_EXCEL_ROWS = 1_048_576

def _sanitize_sheet_name(name: str) -> str:
    """
    清理并裁剪 Excel sheet 名称，使其满足 Excel 的命名限制。
    - 长度最多 31 字符
    - 不允许的字符： : \\ / ? * [ ]
    - 去除首尾单引号
    """
    invalid_chars = ":\\/?*[]"
    cleaned = "".join("_" if c in invalid_chars else c for c in name)
    cleaned = cleaned.strip("'")
    return cleaned[:31] if len(cleaned) > 31 else cleaned

def _write_df_to_sheet_openpyxl(wb: Workbook, sheet_name: str, df: pd.DataFrame) -> None:
    """
    使用 openpyxl 写入一个 DataFrame 到指定 sheet（write_only 模式下更快更省内存）。
    - 首行写入列名
    - 逐行追加数据，避免一次性构建巨大结构
    """
    ws = wb.create_sheet(title=sheet_name)
    ws.append(list(df.columns))
    for row in df.itertuples(index=False, name=None):
        ws.append(list(row))

def _write_df_chunked_openpyxl(wb: Workbook, df: pd.DataFrame, base_sheet_name: str) -> None:
    """
    将 DataFrame 按 Excel 行数上限分片写入多个 sheet，避免超限写入失败。
    - 当行数未超限时，写入一个 sheet
    - 当超限时，写入 base_sheet_name_1, base_sheet_name_2, ...
    """
    total_rows = len(df)
    base = _sanitize_sheet_name(base_sheet_name) or "Sheet"

    if total_rows <= MAX_EXCEL_ROWS:
        _write_df_to_sheet_openpyxl(wb, base, df)
        logger.info(f"  - 写入 sheet '{base}'，行数: {total_rows}")
        return

    chunks = (total_rows + MAX_EXCEL_ROWS - 1) // MAX_EXCEL_ROWS
    for i in range(chunks):
        start = i * MAX_EXCEL_ROWS
        end = min((i + 1) * MAX_EXCEL_ROWS, total_rows)
        part = df.iloc[start:end]
        sheet_name = _sanitize_sheet_name(f"{base}_{i+1}")
        _write_df_to_sheet_openpyxl(wb, sheet_name, part)
        logger.info(f"  - 写入分片 sheet '{sheet_name}'，行数: {len(part)}（范围: {start}~{end}）")

def convert_sas_file_to_excel(output_file: str, input_file: str, sheet_name: Optional[str] = None) -> None:
    """
    将单个 .sas7bdat 数据集写入一个 Excel 文件中的单个 sheet（或分片多个 sheet）。
    
    Args:
        output_file: 输出 Excel 文件路径。
        input_file: 输入 .sas7bdat 文件路径。
        sheet_name: 可选的 sheet 名称；未提供时使用文件名 stem。
    """
    input_path = Path(input_file)
    if not input_path.exists():
        raise FileNotFoundError(f"输入文件不存在: {input_file}")

    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"正在读取 SAS 文件: {input_file}")
    t0 = time.perf_counter()
    try:
        df, _meta = pyreadstat.read_sas7bdat(str(input_path))
    except Exception as e:
        logger.error(f"读取 {input_file} 失败: {e}")
        raise
    t_read = time.perf_counter() - t0

    # 解析 sheet 名称
    base_sheet = sheet_name or input_path.stem
    base_sheet = _sanitize_sheet_name(base_sheet)
    if not base_sheet:
        base_sheet = "Sheet"

    logger.info(f"正在写入 Excel 文件: {output_file}")
    t1 = time.perf_counter()
    try:
        wb = Workbook(write_only=True)
        _write_df_chunked_openpyxl(wb, df, base_sheet)
        wb.save(str(output_path))
    except Exception as e:
        logger.error(f"写入 {output_file} 失败: {e}")
        raise
    t_write = time.perf_counter() - t1
    t_total = time.perf_counter() - t0
    logger.info(f"成功写入: {output_file}")
    logger.info(f"[耗时] 读取: {t_read:.3f}s | 写入: {t_write:.3f}s | 总计: {t_total:.3f}s")

def merge_sas_files_to_excel(output_file: str, input_files: List[str]) -> None:
    """
    将多个 .sas7bdat 文件合并到一个 Excel 文件的多个 sheet 中。
    sheet 名默认为文件名 stem，自动清理并裁剪。
    
    Args:
        output_file: 输出 Excel 文件路径。
        input_files: 输入 .sas7bdat 文件路径列表。
    """
    if not input_files:
        raise ValueError("输入文件列表为空")

    output_path = Path(output_file)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"正在合并 {len(input_files)} 个 SAS 文件到: {output_file}")
    t_total_start = time.perf_counter()
    per_file_times = []
    try:
        wb = Workbook(write_only=True)
        for file_path in input_files:
            t0 = time.perf_counter()
            path_obj = Path(file_path)
            if not path_obj.exists():
                logger.warning(f"文件不存在，跳过: {file_path}")
                continue
            logger.info(f"正在读取: {file_path}")
            try:
                df, _meta = pyreadstat.read_sas7bdat(str(path_obj))
            except Exception as e:
                logger.error(f"读取 {file_path} 失败: {e}")
                raise
            t_read = time.perf_counter() - t0
            sheet_name = _sanitize_sheet_name(path_obj.stem) or "Sheet"
            _write_df_chunked_openpyxl(wb, df, sheet_name)
            t_write = time.perf_counter() - (t0 + t_read)
            t_total = time.perf_counter() - t0
            per_file_times.append((path_obj.name, t_read, t_write, t_total))
        wb.save(str(output_path))
    except Exception as e:
        logger.error(f"写入 {output_file} 失败: {e}")
        raise
    t_total = time.perf_counter() - t_total_start
    logger.info(f"成功合并到: {output_file}")
    logger.info(f"[总耗时] merge_sas_files_to_excel: {t_total:.3f}s")
    if per_file_times:
        logger.info("[单文件耗时汇总] 文件名 | 读取(s) | 写入(s) | 总计(s)")
        for name, tr, tw, tt in per_file_times:
            logger.info(f"  - {name} | {tr:.3f} | {tw:.3f} | {tt:.3f}")

def convert_sas_dir_to_excel(output_file: str, input_dir: str, pattern: str = "*.sas7bdat") -> None:
    """
    扫描目录中所有匹配的 .sas7bdat 文件，写入到一个 Excel 文件。
    
    Args:
        output_file: 输出 Excel 文件路径。
        input_dir: 输入目录路径。
        pattern: 匹配模式，默认 '*.sas7bdat'。
    """
    dir_path = Path(input_dir)
    if not dir_path.exists():
        raise FileNotFoundError(f"输入目录不存在: {input_dir}")
    files = sorted(str(p) for p in dir_path.glob(pattern))
    if not files:
        raise ValueError(f"目录中未找到匹配文件: {input_dir} / {pattern}")
    t0 = time.perf_counter()
    merge_sas_files_to_excel(output_file, files)
    t_total = time.perf_counter() - t0
    logger.info(f"[总耗时] convert_sas_dir_to_excel: {t_total:.3f}s")
