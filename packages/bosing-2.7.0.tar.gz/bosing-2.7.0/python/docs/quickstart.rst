简单示例
========

简单的 Hann 脉冲
----------------

.. plot:: ../examples/hann.py
    :include-source:


插值包络
--------

.. plot:: ../examples/interp.py
    :include-source:


重叠脉冲
--------

.. plot:: ../examples/overlap.py
    :include-source:


变长脉冲
--------

.. plot:: ../examples/flexible.py
    :include-source:


获取 `Element` 长度
-------------------

.. plot:: ../examples/flexible_length.py
    :include-source:


画图展示编排结果
----------------

.. plot:: ../examples/plot.py
    :include-source:


生成包络与指令
--------------

.. plot:: ../examples/envelopes_instructions.py
    :include-source:
