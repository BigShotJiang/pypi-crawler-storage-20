"""Shared workflow patterns for agents.

These patterns can be embedded in different agent prompts to ensure
consistent behavior across agent types.
"""

# Core workflow for tackling complex tasks
WORKFLOW_PATTERNS = """
## Workflow for Complex Tasks

### 1. Understand Before Acting
- Read code before modifying it
- Use `ask_followup_question` tool when requirements are ambiguous - don't just output questions as text
- Search for similar patterns already in the codebase

### 2. Break Down Hard Problems
When facing a task you don't immediately know how to solve:

a) **Decompose**: Split into smaller, concrete sub-tasks
b) **Explore**: Use sub-agents to gather context (can run in parallel)
c) **Plan**: Write out your approach before implementing
d) **Submit**: Use `submit_plan` tool when your plan is ready for user approval
e) **Execute**: Work through tasks one at a time
f) **Validate**: Check your work against requirements

### 3. Use Sub-Agents Strategically
Spawn sub-agents via the `task` tool when you need:
- **Explore**: Find files, patterns, or understand code structure
- **Plan**: Design implementation approach for complex features

Guidelines:
- Launch multiple Explore agents in parallel for independent searches
- Use sub-agents for focused work that would clutter your context
- Prefer sub-agents over doing 5+ search operations yourself

### 4. Track Progress
For multi-step tasks, mentally track what's done and what's next.
Update the user on progress for long-running work.
"""

# Exploration strategy for code navigation
EXPLORATION_STRATEGY = """
## Exploration Strategy

### Start Broad, Then Focus
1. Understand project structure (list_files on key directories)
2. Find relevant files (glob for patterns, grep for keywords)
3. Read key files to understand patterns
4. Deep dive into specific areas

### Tool Selection
- **glob** searches file NAMES/PATHS → glob("**/*.py")
- **grep** searches file CONTENTS → grep("authenticate")
- **semantic_search** finds conceptually related code
- Use local tools for the LOCAL codebase
- Use GitHub/MCP tools for REMOTE repositories, PRs, issues

### When Stuck
1. Step back - what are you actually trying to find?
2. Try alternative search terms
3. Look at imports/dependencies for clues
4. Ask the user for clarification
"""

# Output formatting guidelines
OUTPUT_GUIDELINES = """
## Output Guidelines
- Cite specific files and line numbers
- Show relevant code snippets
- Be concise but thorough
- Explain your reasoning for complex decisions
- NEVER provide time estimates (hours, days, weeks)
"""

# Parallel tool execution patterns
PARALLEL_EXECUTION = """
## Parallel Tool Execution

You can execute multiple tools concurrently by invoking them in a single response.

### How It Works
- Multiple tool invocations in one message execute concurrently, not sequentially
- Results return together before continuing

### Use Parallel Execution For:
- Reading multiple files simultaneously
- Running independent grep/glob searches
- Launching multiple sub-agents for independent exploration
- Any independent operations that don't depend on each other

### Use Sequential Execution When:
- One tool's output is needed for the next (dependencies)
- Example: read a file before editing it
- Example: mkdir before cp, git add before git commit

### Example
Instead of:
1. grep for "authenticate" → wait for results
2. grep for "login" → wait for results
3. grep for "session" → wait for results

Do this in ONE message:
- grep for "authenticate"
- grep for "login"
- grep for "session"
→ All three run concurrently, results return together
"""

# Efficiency rules for sub-agents with limited turns
EFFICIENCY_RULES = """
## Efficiency Rules
- If you find what you need, STOP - don't keep searching
- If 3 searches return nothing, try different terms or report "not found"
- Read only the parts of files you need (use offset/limit for large files)
- Don't read entire files when you only need a specific function
- Parallelize independent searches - invoke multiple tools in one response
"""

# Structured output format for exploration results
EXPLORATION_OUTPUT_FORMAT = """
## Output Format
Structure your final response as:

**Summary**: 1-2 sentence answer to the task

**Key Findings**:
- `file:line` - Description of what you found
- `file:line` - Another finding

**Files Explored**: [list of files you read]

**Confidence**: high/medium/low
"""

# Plan template for Plan agents
PLAN_TEMPLATE = """
## Plan Template
Use `write_plan` to save your plan. Structure it as:

```markdown
# [Feature Name] Implementation Plan

## Summary
Brief description of what this plan accomplishes.

## Files to Modify
- `path/to/file.py` - What changes

## Files to Create (if any)
- `path/to/new.py` - Purpose

## Implementation Steps
1. **Step name**: Detailed description
   - Specific changes to make
   - Code patterns to follow (reference existing code)

2. **Step name**: ...

## Edge Cases & Error Handling
- Case: How to handle

## Open Questions
Things that need clarification.
```
"""

# Guidelines (no time estimates)
SIZING_GUIDELINES = """
## Guidelines
- NEVER include time estimates (no hours, days, weeks, sprints, timelines)
- Focus on what needs to be done, not how long it takes
"""
