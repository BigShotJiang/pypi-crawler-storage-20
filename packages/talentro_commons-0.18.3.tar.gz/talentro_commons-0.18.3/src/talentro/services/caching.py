import json
import os

from functools import wraps
from typing import Any

from aiocache import Cache, RedisCache
from aiocache.serializers import PickleSerializer
from starlette.requests import Request

from ..util.singleton import SingletonMeta


class CacheService(metaclass=SingletonMeta):

    def __init__(self):
        endpoint = os.environ.get('CACHE_ENDPOINT', 'localhost')
        port = os.environ.get('CACHE_PORT', 6379)

        self._cache = RedisCache(endpoint=endpoint, port=port, serializer=PickleSerializer())

    async def get(self, key: str) -> Any:
        namespace = key.split(":")[0]

        if value := await self._cache.get(key, namespace=namespace):
            return value

        return None

    async def set(self, key, value, ttl=300):
        namespace = key.split(":")[0]
        return await self._cache.set(key, value, ttl=ttl, namespace=namespace)

    async def delete(self, key):
        namespace = key.split(":")[0]
        await self._cache.delete(key, namespace=namespace)


def cache_response(namespace: str, ttl: int = 300, organization_specific: bool = True):
    """
    Caching decorator for FastAPI endpoints.

    ttl: Time to live for the cache in seconds.
    namespace: Namespace for cache keys in Redis.
    """
    def decorator(func):

        @wraps(func)
        async def wrapper(*args, **kwargs):
            for arg in args:
                print(type(arg))
                print(arg)

            try:
                cache: CacheService = CacheService()
            except Exception as e:
                print(f"Error creating cache: {e}")
                return await func(*args, **kwargs)

            # Get request object
            request: Request = kwargs.get("request")
            if not request:
                for arg in args:
                    if isinstance(arg, Request):
                        request = arg
                        break

            cache_key = f"{namespace}"

            # If organization is specific, add organization id to the cache key
            if organization_specific:
                organization_id = kwargs.get("x_organization_id")
                cache_key += f":org:{organization_id}"

            # Add the route to the cache key
            if request:
                route_path = request.url.path
                if route_path:
                    cache_key += f":route:{route_path}"

            print(f"Cache key {cache_key}")

            # Try to retrieve data from cache
            try:
                if cached_value := await cache.get(cache_key):
                    return cached_value  # Return cached data
            except Exception as e:
                print(f"Error retrieving data from cache: {e}")

            response = await func(*args, **kwargs)

            try:
                # Store the response in Redis with a TTL
                await cache.set(cache_key, response, ttl=ttl)
            except Exception as e:
                print(f"Error caching data: {e}")

            return response

        return wrapper

    return decorator
