# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "anchorbrowser"
__version__ = "0.7.3"  # x-release-please-version
