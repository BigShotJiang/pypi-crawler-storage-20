#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud CLI Commands

This module provides Click commands for Prisma Cloud Compute integration:
- authenticate: Authenticate and cache session token
- sync_hosts: Sync host assets and vulnerabilities
- sync_images: Sync container image assets and vulnerabilities
- sync_sbom: Sync SBOM data as software inventory

For legacy CSV import functionality, see regscale.integrations.commercial.prisma.legacy
"""

import json
import logging
from typing import Optional

import click

from regscale.core.app.api import Api
from regscale.models.app_models.click import regscale_ssp_id
from regscale.integrations.commercial.prisma.auth import (
    authenticate_with_cache,
)
from regscale.integrations.commercial.prisma.scanner import PrismaCloudScanner
from regscale.integrations.commercial.prisma.sbom_processor import (
    create_software_inventory_from_sbom,
    attach_sbom_as_evidence,
    get_sbom_summary,
    extract_sbom_archive,
)
from regscale.integrations.commercial.prisma.variables import PrismaVariables

logger = logging.getLogger("regscale")


# =============================================================================
# Authentication Commands
# =============================================================================


@click.command(name="authenticate")
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Prisma Cloud Console URL (e.g., https://console.example.com:8083). "
    "Defaults to prismaConsoleUrl from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Prisma Cloud username. Defaults to prismaUsername from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    prompt=False,
    help="Prisma Cloud password. Defaults to prismaPassword from init.yaml. If not provided, will prompt.",
)
@click.option(
    "--force-refresh",
    is_flag=True,
    default=False,
    help="Force re-authentication even if cached token exists.",
)
def authenticate(
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    force_refresh: bool,
):
    """
    Authenticate to Prisma Cloud Compute and cache session token.

    This command authenticates to Prisma Cloud and caches the bearer token
    locally for 24 hours. The token will be used automatically by other commands.

    Examples:
        # Authenticate using init.yaml settings
        regscale prisma authenticate

        # Authenticate with explicit credentials
        regscale prisma authenticate --console-url https://console.example.com:8083 \\
            --username admin --password mypassword

        # Force refresh of cached token
        regscale prisma authenticate --force-refresh
    """
    try:
        # Use variables from init.yaml if not provided
        console_url = console_url or str(PrismaVariables.prismaConsoleUrl)  # type: ignore
        username = username or str(PrismaVariables.prismaUsername)  # type: ignore

        # Prompt for password if not provided
        if not password:
            password = str(PrismaVariables.prismaPassword) or click.prompt(  # type: ignore
                "Prisma Cloud Password", hide_input=True
            )

        click.echo(f"Authenticating to Prisma Cloud: {console_url}")

        # Authenticate with caching
        token = authenticate_with_cache(
            console_url=console_url,
            username=username,
            password=password,
            verify_ssl=bool(PrismaVariables.prismaVerifySsl),  # type: ignore
            timeout=int(PrismaVariables.prismaApiTimeout),  # type: ignore
            force_refresh=force_refresh,
        )

        click.echo(click.style("✓ Authentication successful!", fg="green"))
        click.echo(f"Token cached for 24 hours (length: {len(token)} characters)")
        click.echo("Token will be used automatically by sync commands")

    except Exception as e:
        logger.error(f"Authentication failed: {e}")
        click.echo(click.style(f"✗ Authentication failed: {e}", fg="red"), err=True)
        raise click.Abort()


# =============================================================================
# Asset and Finding Sync Commands
# =============================================================================


@click.command(name="sync_hosts")
@regscale_ssp_id()
@click.option(
    "--filters",
    type=str,
    required=False,
    help='JSON filter string for Prisma API query (e.g., \'{"collections": ["prod"]}\')',
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data for each host.",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@click.option(
    "--use-csv",
    is_flag=True,
    default=False,
    help="Use CSV download endpoint for bulk data retrieval (faster for large datasets).",
)
def sync_hosts(
    regscale_ssp_id: int,
    filters: Optional[str],
    enable_software_inventory: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
):
    """
    Sync host assets and vulnerabilities from Prisma Cloud.

    This command:
    1. Authenticates to Prisma Cloud (uses cached token if available)
    2. Fetches host scan results from Prisma API
    3. Creates/updates assets in RegScale
    4. Creates/updates vulnerabilities and findings in RegScale
    5. Optionally creates software inventory from SBOM data

    Examples:
        # Basic sync with defaults from init.yaml
        regscale prisma sync_hosts --regscale_ssp_id 123

        # Sync with filters
        regscale prisma sync_hosts --regscale_ssp_id 123 \\
            --filters '{"collections": ["production"]}'

        # Sync with software inventory
        regscale prisma sync_hosts --regscale_ssp_id 123 --enable-software-inventory
    """
    try:
        click.echo("=" * 80)
        click.echo("Prisma Cloud Host Sync")
        click.echo("=" * 80)

        # Parse filters if provided
        filter_dict = None
        if filters:
            try:
                filter_dict = json.loads(filters)
                click.echo(f"Using filters: {json.dumps(filter_dict, indent=2)}")
            except json.JSONDecodeError as e:
                click.echo(click.style(f"✗ Invalid JSON in filters: {e}", fg="red"), err=True)
                raise click.Abort()

        # Initialize scanner
        mode_desc = "CSV mode" if use_csv else "JSON API mode"
        click.echo(f"Using {mode_desc} for data retrieval")
        scanner = PrismaCloudScanner(plan_id=regscale_ssp_id, scan_type="hosts", use_csv=use_csv)

        # Authenticate
        click.echo("Authenticating to Prisma Cloud...")
        scanner.authenticate(console_url=console_url, username=username, password=password)

        # Sync assets and findings
        click.echo(f"\nSyncing hosts to RegScale SSP {regscale_ssp_id}...")
        scanner.sync_assets(filters=filter_dict)

        click.echo("\nSyncing host vulnerabilities to RegScale...")
        scanner.sync_findings(filters=filter_dict)

        # Software inventory
        if enable_software_inventory:
            click.echo("\n" + "=" * 80)
            click.echo("Software Inventory Creation (SBOM)")
            click.echo("=" * 80)
            click.echo("Note: SBOM processing for hosts requires separate sync_sbom command per host.")
            click.echo("Use: regscale prisma sync_sbom --resource-type host --resource-id <hostname>")

        click.echo("\n" + click.style("✓ Host sync completed successfully!", fg="green"))

    except Exception as e:
        logger.error(f"Host sync failed: {e}")
        click.echo(click.style(f"✗ Host sync failed: {e}", fg="red"), err=True)
        raise click.Abort()


@click.command(name="sync_images")
@regscale_ssp_id()
@click.option(
    "--filters",
    type=str,
    required=False,
    help='JSON filter string for Prisma API query (e.g., \'{"collections": ["prod"]}\')',
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data for each image.",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
@click.option(
    "--use-csv",
    is_flag=True,
    default=False,
    help="Use CSV download endpoint for bulk data retrieval (faster for large datasets).",
)
def sync_images(
    regscale_ssp_id: int,
    filters: Optional[str],
    enable_software_inventory: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    use_csv: bool,
):
    """
    Sync container image assets and vulnerabilities from Prisma Cloud.

    This command:
    1. Authenticates to Prisma Cloud (uses cached token if available)
    2. Fetches container image scan results from Prisma API
    3. Creates/updates container image assets in RegScale
    4. Creates/updates vulnerabilities and findings in RegScale
    5. Optionally creates software inventory from SBOM data

    Examples:
        # Basic sync with defaults from init.yaml
        regscale prisma sync_images --regscale_ssp_id 123

        # Sync with filters
        regscale prisma sync_images --regscale_ssp_id 123 \\
            --filters '{"collections": ["production"]}'

        # Sync with software inventory
        regscale prisma sync_images --regscale_ssp_id 123 --enable-software-inventory
    """
    try:
        click.echo("=" * 80)
        click.echo("Prisma Cloud Container Image Sync")
        click.echo("=" * 80)

        # Parse filters if provided
        filter_dict = None
        if filters:
            try:
                filter_dict = json.loads(filters)
                click.echo(f"Using filters: {json.dumps(filter_dict, indent=2)}")
            except json.JSONDecodeError as e:
                click.echo(click.style(f"✗ Invalid JSON in filters: {e}", fg="red"), err=True)
                raise click.Abort()

        # Initialize scanner
        mode_desc = "CSV mode" if use_csv else "JSON API mode"
        click.echo(f"Using {mode_desc} for data retrieval")
        scanner = PrismaCloudScanner(plan_id=regscale_ssp_id, scan_type="images", use_csv=use_csv)

        # Authenticate
        click.echo("Authenticating to Prisma Cloud...")
        scanner.authenticate(console_url=console_url, username=username, password=password)

        # Sync assets and findings
        click.echo(f"\nSyncing images to RegScale SSP {regscale_ssp_id}...")
        scanner.sync_assets(filters=filter_dict)

        click.echo("\nSyncing image vulnerabilities to RegScale...")
        scanner.sync_findings(filters=filter_dict)

        # Software inventory
        if enable_software_inventory:
            click.echo("\n" + "=" * 80)
            click.echo("Software Inventory Creation (SBOM)")
            click.echo("=" * 80)
            click.echo("Note: SBOM processing for images requires separate sync_sbom command per image.")
            click.echo("Use: regscale prisma sync_sbom --resource-type image --resource-id <image_id>")

        click.echo("\n" + click.style("✓ Image sync completed successfully!", fg="green"))

    except Exception as e:
        logger.error(f"Image sync failed: {e}")
        click.echo(click.style(f"✗ Image sync failed: {e}", fg="red"), err=True)
        raise click.Abort()


# =============================================================================
# SBOM Sync Command
# =============================================================================


@click.command(name="sync_sbom")
@regscale_ssp_id()
@click.option(
    "--resource-type",
    type=click.Choice(["host", "image", "all"], case_sensitive=False),
    default="all",
    help="Resource type to sync SBOMs for: host, image, or all (default: all).",
)
@click.option(
    "--resource-id",
    type=str,
    required=False,
    help="Specific resource identifier (optional for bulk download). Required when --no-bulk-download is used.",
)
@click.option(
    "--bulk-download",
    is_flag=True,
    default=True,
    help="Use bulk download endpoints for all SBOMs (recommended, default: True). "
    "Based on P1 customer feedback, this resolves HTTP 404 errors.",
)
@click.option(
    "--asset-id",
    type=int,
    required=False,
    help="RegScale Asset ID to associate software inventory with. If not provided, will search for asset by identifier.",
)
@click.option(
    "--enable-software-inventory",
    is_flag=True,
    default=False,
    help="Create software inventory records from SBOM data.",
)
@click.option(
    "--attach-evidence",
    is_flag=True,
    default=False,
    help="Attach SBOM JSON as evidence to the asset (requires --enable-software-inventory).",
)
@click.option(
    "--console-url",
    type=str,
    required=False,
    help="Override Prisma Console URL from init.yaml.",
)
@click.option(
    "--username",
    type=str,
    required=False,
    help="Override Prisma username from init.yaml.",
)
@click.option(
    "--password",
    type=str,
    required=False,
    hide_input=True,
    help="Override Prisma password from init.yaml.",
)
def sync_sbom(
    regscale_ssp_id: int,
    resource_type: str,
    resource_id: Optional[str],
    bulk_download: bool,
    asset_id: Optional[int],
    enable_software_inventory: bool,
    attach_evidence: bool,
    console_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
):
    """
    Sync SBOM (Software Bill of Materials) data from Prisma Cloud.

    Two modes:
    1. Bulk download (default): Downloads all SBOMs at once using bulk endpoints
    2. Individual: Downloads SBOM for specific resource (requires --resource-id and --no-bulk-download)

    Based on Platform One (P1) customer feedback, bulk download mode is recommended
    as it resolves HTTP 404 errors encountered with individual SBOM endpoints.

    Examples:
        # Bulk download all host SBOMs (recommended)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type host

        # Bulk download all image SBOMs with software inventory creation
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type image \\
            --enable-software-inventory

        # Download all SBOMs (hosts + images)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type all

        # Individual SBOM download (legacy mode, may return 404)
        regscale prisma sync_sbom --regscale_ssp_id 123 --resource-type host \\
            --resource-id "web-server-01.example.com" --no-bulk-download --asset-id 456
    """
    try:
        click.echo("=" * 80)
        click.echo(f"Prisma Cloud SBOM Sync ({resource_type.upper()})")
        click.echo("=" * 80)

        # Initialize scanner
        scanner = PrismaCloudScanner(plan_id=regscale_ssp_id, scan_type="sbom")

        # Authenticate
        click.echo("\nAuthenticating to Prisma Cloud...")
        scanner.authenticate(console_url=console_url, username=username, password=password)

        if bulk_download:
            # === BULK DOWNLOAD MODE (Recommended) ===
            _sync_sbom_bulk_mode(
                scanner=scanner,
                resource_type=resource_type,
                enable_software_inventory=enable_software_inventory,
            )
        else:
            # === INDIVIDUAL MODE (Legacy) ===
            if not resource_id:
                click.echo(
                    click.style(
                        "Error: --resource-id is required when --no-bulk-download is used.",
                        fg="red",
                    ),
                    err=True,
                )
                raise click.Abort()

            _sync_sbom_individual_mode(
                scanner=scanner,
                resource_type=resource_type,
                resource_id=resource_id,
                asset_id=asset_id,
                enable_software_inventory=enable_software_inventory,
                attach_evidence=attach_evidence,
            )

        click.echo("\n" + click.style("✓ SBOM sync completed successfully!", fg="green"))

    except Exception as e:
        logger.error(f"SBOM sync failed: {e}")
        click.echo(click.style(f"✗ SBOM sync failed: {e}", fg="red"), err=True)
        raise click.Abort()


def _sync_sbom_bulk_mode(
    scanner: PrismaCloudScanner,
    resource_type: str,
    enable_software_inventory: bool,
):
    """
    Handle bulk SBOM download mode.

    :param PrismaCloudScanner scanner: Initialized scanner with authenticated client
    :param str resource_type: "host", "image", or "all"
    :param bool enable_software_inventory: Create software inventory records
    """
    total_sboms = 0
    total_packages = 0

    # Download host SBOMs
    if resource_type in ["host", "all"]:
        host_stats = _download_and_process_sboms(
            scanner=scanner,
            resource_category="hosts",
            enable_software_inventory=enable_software_inventory,
        )
        total_sboms += host_stats["sbom_count"]
        total_packages += host_stats["package_count"]

    # Download image SBOMs
    if resource_type in ["image", "all"]:
        image_stats = _download_and_process_sboms(
            scanner=scanner,
            resource_category="images",
            enable_software_inventory=enable_software_inventory,
        )
        total_sboms += image_stats["sbom_count"]
        total_packages += image_stats["package_count"]

    # Summary
    click.echo("\n" + "=" * 80)
    click.echo(click.style(f"Total SBOMs processed: {total_sboms}", fg="cyan"))
    click.echo(click.style(f"Total software components: {total_packages}", fg="cyan"))


def _download_and_process_sboms(
    scanner: PrismaCloudScanner,
    resource_category: str,
    enable_software_inventory: bool,
) -> dict:
    """
    Download and process SBOMs for a resource category.

    :param PrismaCloudScanner scanner: Initialized scanner
    :param str resource_category: "hosts" or "images"
    :param bool enable_software_inventory: Whether to create inventory
    :return: Dictionary with sbom_count and package_count
    :rtype: dict
    """
    stats = {"sbom_count": 0, "package_count": 0}

    click.echo(f"\nDownloading bulk SBOM data for {resource_category}...")
    try:
        # Download tar.gz archive
        if resource_category == "hosts":
            tar_gz_data = scanner.client.get_sbom_download_hosts()
        else:
            tar_gz_data = scanner.client.get_sbom_download_images()

        click.echo(f"  Downloaded: {len(tar_gz_data)} bytes")

        # Extract SBOMs
        click.echo("  Extracting SBOM archive...")
        sbom_map = extract_sbom_archive(tar_gz_data)
        click.echo(click.style(f"  ✓ Extracted {len(sbom_map)} {resource_category} SBOMs", fg="green"))

        # Process each SBOM
        for resource_id, sbom_data in sbom_map.items():
            summary = get_sbom_summary(sbom_data)
            click.echo(f"\n  {resource_category[:-1].capitalize()}: {resource_id}")
            click.echo(f"    Components: {summary['total_components']}")

            if enable_software_inventory:
                click.echo(
                    click.style(
                        "    Warning: Software inventory creation requires --asset-id. Skipping.",
                        fg="yellow",
                    )
                )

            stats["sbom_count"] += 1
            stats["package_count"] += summary["total_components"]

    except Exception as e:
        logger.error(f"Failed to download {resource_category} SBOMs: {e}")
        click.echo(click.style(f"  ✗ Failed to download {resource_category} SBOMs: {e}", fg="yellow"))

    return stats


def _sync_sbom_individual_mode(
    scanner: PrismaCloudScanner,
    resource_type: str,
    resource_id: str,
    asset_id: Optional[int],
    enable_software_inventory: bool,
    attach_evidence: bool,
):
    """
    Handle individual SBOM download mode (legacy).

    :param PrismaCloudScanner scanner: Initialized scanner with authenticated client
    :param str resource_type: "host" or "image"
    :param str resource_id: Resource identifier
    :param Optional[int] asset_id: RegScale Asset ID
    :param bool enable_software_inventory: Create software inventory records
    :param bool attach_evidence: Attach SBOM as evidence
    """
    api = Api()
    click.echo(f"Resource: {resource_id}")

    # Fetch SBOM
    click.echo(f"\nFetching SBOM for {resource_type}: {resource_id}...")
    click.echo(
        click.style(
            "Warning: Individual SBOM endpoint may return HTTP 404. Use bulk download mode (default).",
            fg="yellow",
        )
    )

    sbom_data = scanner.client.get_sbom(resource_type, resource_id)

    # Display SBOM summary
    summary = get_sbom_summary(sbom_data)
    click.echo("\nSBOM Summary:")
    click.echo(f"  Format: {summary['bom_format']} {summary['spec_version']}")
    click.echo(f"  Total Components: {summary['total_components']}")
    click.echo(f"  Target: {summary['target_name']} {summary['target_version']}")

    # Create software inventory if enabled
    if enable_software_inventory:
        if not asset_id:
            click.echo(
                click.style(
                    "Warning: Asset ID not provided. Please provide --asset-id for software inventory creation.",
                    fg="yellow",
                )
            )
        else:
            click.echo(f"\nCreating software inventory for asset {asset_id}...")
            count = create_software_inventory_from_sbom(
                api=api,
                asset_id=asset_id,
                sbom_data=sbom_data,
                deduplicate=True,
            )
            click.echo(click.style(f"✓ Created {count} software inventory records", fg="green"))

            # Attach evidence if requested
            if attach_evidence:
                click.echo("\nAttaching SBOM as evidence...")
                success = attach_sbom_as_evidence(
                    api=api,
                    asset_id=asset_id,
                    sbom_data=sbom_data,
                    file_name=f"prisma_sbom_{resource_type}_{resource_id.replace('/', '_')}.json",
                )
                if success:
                    click.echo(click.style("✓ SBOM attached as evidence", fg="green"))
                else:
                    click.echo(click.style("✗ Failed to attach SBOM as evidence", fg="yellow"))


# Export all commands for registration
__all__ = [
    "authenticate",
    "sync_hosts",
    "sync_images",
    "sync_sbom",
]
