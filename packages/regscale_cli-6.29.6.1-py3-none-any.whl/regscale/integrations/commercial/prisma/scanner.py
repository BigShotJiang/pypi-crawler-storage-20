#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prisma Cloud Scanner Integration

This module provides the main scanner integration class for Prisma Cloud Compute,
implementing the ScannerIntegration framework for standardized asset and finding
processing.
"""

import logging
from datetime import datetime
from typing import Dict, Iterator, List, Optional

from regscale.integrations.commercial.prisma.auth import authenticate_with_cache
from regscale.integrations.commercial.prisma.client import PrismaCloudClient
from regscale.integrations.commercial.prisma.deduplicator import PrismaDeduplicator
from regscale.integrations.commercial.prisma.variables import PrismaVariables
from regscale.integrations.commercial.prisma_modules import (
    extract_fqdn,
    map_cvss_to_severity,
    parse_operating_system,
    truncate_description,
    validate_cvss_score,
)
from regscale.integrations.scanner_integration import (
    IntegrationAsset,
    IntegrationFinding,
    ScannerIntegration,
    validate_cve,
)
from regscale.models import regscale_models

logger = logging.getLogger("regscale")


class PrismaCloudScanner(ScannerIntegration):
    """
    Scanner integration for Prisma Cloud Compute.

    Supports three scan types:
    - hosts: VM/host vulnerability scanning
    - images: Container image vulnerability scanning
    - sbom: Software Bill of Materials processing
    """

    title = "Prisma Cloud"
    asset_identifier_field = "otherTrackingNumber"
    issue_identifier_field = "cve"

    # Map Prisma severity strings to RegScale IssueSeverity enum
    finding_severity_map = {
        "critical": regscale_models.IssueSeverity.Critical,
        "high": regscale_models.IssueSeverity.High,
        "medium": regscale_models.IssueSeverity.Moderate,
        "moderate": regscale_models.IssueSeverity.Moderate,
        "low": regscale_models.IssueSeverity.Low,
        "info": regscale_models.IssueSeverity.Low,
        "unknown": regscale_models.IssueSeverity.NotAssigned,
    }

    def __init__(self, plan_id: int, scan_type: str = "hosts", use_csv: bool = False):
        """
        Initialize Prisma Cloud Scanner.

        :param int plan_id: RegScale Security Plan ID
        :param str scan_type: Type of scan ("hosts", "images", or "sbom")
        :param bool use_csv: Use CSV download endpoints for bulk data retrieval (default False)
        """
        super().__init__(plan_id)
        self.scan_type = scan_type
        self.use_csv = use_csv
        self.client: Optional[PrismaCloudClient] = None
        self.deduplicator = PrismaDeduplicator()

        # Validate scan type
        if scan_type not in ["hosts", "images", "sbom"]:
            raise ValueError(f"Invalid scan_type: {scan_type}. Must be 'hosts', 'images', or 'sbom'")

        mode = "CSV" if use_csv else "JSON API"
        logger.info(f"Initialized Prisma Cloud Scanner for scan type: {scan_type} (mode: {mode})")

    def authenticate(
        self,
        console_url: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        force_refresh: bool = False,
    ) -> None:
        """
        Authenticate to Prisma Cloud Compute and initialize API client.

        :param Optional[str] console_url: Console URL (uses PrismaVariables if not provided)
        :param Optional[str] username: Username (uses PrismaVariables if not provided)
        :param Optional[str] password: Password (uses PrismaVariables if not provided)
        :param bool force_refresh: Force re-authentication even if cached token exists
        """
        # Use variables from init.yaml if not provided
        console_url = console_url or str(PrismaVariables.prismaConsoleUrl)  # type: ignore
        username = username or str(PrismaVariables.prismaUsername)  # type: ignore
        password = password or str(PrismaVariables.prismaPassword)  # type: ignore

        logger.info(f"Authenticating to Prisma Cloud: {console_url}")

        # Authenticate with caching
        token = authenticate_with_cache(
            console_url=console_url,
            username=username,
            password=password,
            verify_ssl=bool(PrismaVariables.prismaVerifySsl),  # type: ignore
            timeout=int(PrismaVariables.prismaApiTimeout),  # type: ignore
            force_refresh=force_refresh,
        )

        # Initialize API client
        self.client = PrismaCloudClient(
            console_url=console_url,
            token=token,
            verify_ssl=bool(PrismaVariables.prismaVerifySsl),  # type: ignore
            timeout=int(PrismaVariables.prismaApiTimeout),  # type: ignore
            max_retries=int(PrismaVariables.prismaApiRetries),  # type: ignore
        )

        logger.info("Successfully authenticated and initialized Prisma Cloud API client")

    def fetch_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetch assets from Prisma Cloud based on scan_type.

        Routes to CSV or JSON API methods based on use_csv flag.

        :yields: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        :raises RuntimeError: If not authenticated
        """
        if self.client is None:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        # Route to CSV or JSON API methods
        if self.use_csv:
            yield from self._fetch_assets_from_csv(**kwargs)
            return

        if self.scan_type == "hosts":
            yield from self._fetch_host_assets(**kwargs)
        elif self.scan_type == "images":
            yield from self._fetch_image_assets(**kwargs)
        elif self.scan_type == "sbom":
            logger.warning("SBOM scan type does not fetch assets directly. Use sync_sbom command instead.")

    def _apply_deduplication(self, findings: List[Dict]) -> List[Dict]:
        """
        Apply deduplication to findings based on configuration.

        :param List[Dict] findings: Raw finding dictionaries
        :return: Deduplicated findings
        :rtype: List[Dict]
        """
        if not bool(PrismaVariables.prismaDeduplicateFindings):  # type: ignore
            return findings

        dedup_mode = str(PrismaVariables.prismaDeduplicationMode).lower()  # type: ignore
        logger.info("Deduplicating %d findings using mode: %s", len(findings), dedup_mode)

        if dedup_mode == "by_cve":
            deduplicated = self.deduplicator.deduplicate_by_cve(findings)
        else:
            deduplicated = self.deduplicator.deduplicate_findings(findings)

        stats = self.deduplicator.get_stats()
        logger.info(
            "Deduplication complete: %d -> %d findings (%s%% reduction)",
            stats["original_count"],
            stats["deduplicated_count"],
            stats["reduction_percentage"],
        )
        return deduplicated

    def fetch_findings(self, **kwargs) -> Iterator[IntegrationFinding]:
        """
        Fetch findings from Prisma Cloud based on scan_type.

        Routes to CSV or JSON API methods based on use_csv flag.
        Applies client-side deduplication if enabled.

        :yields: IntegrationFinding objects
        :rtype: Iterator[IntegrationFinding]
        :raises RuntimeError: If not authenticated
        """
        if self.client is None:
            raise RuntimeError("Not authenticated. Call authenticate() first.")

        # Collect all findings first for deduplication
        all_findings = []

        # Route to CSV or JSON API methods
        if self.use_csv:
            for finding_dict in self._fetch_findings_from_csv(**kwargs):
                all_findings.append(finding_dict)
        elif self.scan_type == "hosts":
            for finding_dict in self._fetch_host_findings(**kwargs):
                all_findings.append(finding_dict)
        elif self.scan_type == "images":
            for finding_dict in self._fetch_image_findings(**kwargs):
                all_findings.append(finding_dict)
        elif self.scan_type == "sbom":
            logger.warning("SBOM scan type does not fetch findings directly. Use sync_sbom command instead.")
            return

        # Apply deduplication
        all_findings = self._apply_deduplication(all_findings)

        # Convert dictionaries to IntegrationFinding objects and yield
        for finding_dict in all_findings:
            yield self._dict_to_integration_finding(finding_dict)

    def _fetch_host_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """Fetch host assets from Prisma Cloud."""
        logger.info("Fetching host assets from Prisma Cloud...")

        filters = kwargs.get("filters")
        page_size = int(PrismaVariables.prismaPageSize)  # type: ignore

        for host_data in self.client.get_hosts(filters=filters, page_size=page_size):
            asset = self._parse_host_asset(host_data)
            if asset:
                yield asset

    def _fetch_image_assets(self, **kwargs) -> Iterator[IntegrationAsset]:
        """Fetch container image assets from Prisma Cloud."""
        logger.info("Fetching image assets from Prisma Cloud...")

        filters = kwargs.get("filters")
        page_size = int(PrismaVariables.prismaPageSize)  # type: ignore

        for image_data in self.client.get_images(filters=filters, page_size=page_size):
            asset = self._parse_image_asset(image_data)
            if asset:
                yield asset

    def _fetch_host_findings(self, **kwargs) -> Iterator[Dict]:
        """Fetch host vulnerability findings from Prisma Cloud."""
        logger.info("Fetching host findings from Prisma Cloud...")

        filters = kwargs.get("filters")
        page_size = int(PrismaVariables.prismaPageSize)  # type: ignore

        for host_data in self.client.get_hosts(filters=filters, page_size=page_size):
            hostname = host_data.get("hostname", "unknown")
            vulnerabilities = host_data.get("vulnerabilities", [])

            for vuln in vulnerabilities:
                finding_dict = self._parse_vulnerability(vuln, hostname, asset_type="host")
                if finding_dict:
                    yield finding_dict

    def _fetch_image_findings(self, **kwargs) -> Iterator[Dict]:
        """Fetch container image vulnerability findings from Prisma Cloud."""
        logger.info("Fetching image findings from Prisma Cloud...")

        filters = kwargs.get("filters")
        page_size = int(PrismaVariables.prismaPageSize)  # type: ignore

        for image_data in self.client.get_images(filters=filters, page_size=page_size):
            image_name = image_data.get("imageName", image_data.get("_id", "unknown"))
            vulnerabilities = image_data.get("vulnerabilities", [])

            for vuln in vulnerabilities:
                finding_dict = self._parse_vulnerability(vuln, image_name, asset_type="image")
                if finding_dict:
                    yield finding_dict

    def _parse_host_asset(self, host_data: Dict) -> Optional[IntegrationAsset]:
        """
        Parse Prisma host JSON to IntegrationAsset.

        :param Dict host_data: Raw host data from Prisma API
        :return: IntegrationAsset or None if parsing fails
        :rtype: Optional[IntegrationAsset]
        """
        try:
            hostname = host_data.get("hostname", "")
            if not hostname:
                logger.warning("Host data missing hostname, skipping")
                return None

            # Extract OS information
            distro = host_data.get("distro", "")
            os_distro = host_data.get("osDistro", "")
            os_version = host_data.get("osDistroVersion", "")
            os_release = host_data.get("osDistroRelease", "")

            # Parse operating system
            os_string = distro or f"{os_distro} {os_version} {os_release}".strip()
            operating_system = parse_operating_system(os_string) if os_string else None

            # Extract FQDN
            fqdn = extract_fqdn(hostname)

            # Build asset properties
            return IntegrationAsset(
                name=hostname,
                identifier=hostname,
                asset_type="Virtual Machine (VM)",
                asset_category="Server",
                asset_owner_id=self.assessor_id,
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
                operating_system=operating_system,
                fqdn=fqdn,
                status="Active (On Network)",
                date_last_updated=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                component_names=["Prisma Cloud Host"],
            )

        except Exception as e:
            logger.error(f"Error parsing host asset: {e}")
            return None

    def _parse_image_asset(self, image_data: Dict) -> Optional[IntegrationAsset]:
        """
        Parse Prisma container image JSON to IntegrationAsset.

        :param Dict image_data: Raw image data from Prisma API
        :return: IntegrationAsset or None if parsing fails
        :rtype: Optional[IntegrationAsset]
        """
        try:
            image_name = image_data.get("imageName", "")
            image_id = image_data.get("_id", "")

            if not image_name and not image_id:
                logger.warning("Image data missing name and ID, skipping")
                return None

            asset_name = image_name or image_id

            return IntegrationAsset(
                name=asset_name,
                identifier=image_id or image_name,
                asset_type="Container Image",
                asset_category="Software",
                asset_owner_id=self.assessor_id,
                parent_id=self.plan_id,
                parent_module=regscale_models.SecurityPlan.get_module_slug(),
                other_tracking_number=image_id,
                status="Active (On Network)",
                date_last_updated=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                component_names=["Prisma Cloud Image"],
            )

        except Exception as e:
            logger.error(f"Error parsing image asset: {e}")
            return None

    def _parse_vulnerability(self, vuln_data: Dict, asset_identifier: str, asset_type: str) -> Optional[Dict]:
        """
        Parse Prisma vulnerability to finding dictionary (for deduplication).

        Returns a dictionary instead of IntegrationFinding to allow deduplication.

        :param Dict vuln_data: Raw vulnerability data from Prisma API
        :param str asset_identifier: Host or image identifier
        :param str asset_type: Type of asset ("host" or "image")
        :return: Finding dictionary or None if parsing fails
        :rtype: Optional[Dict]
        """
        try:
            # Extract CVE
            cve = vuln_data.get("cve", "")
            if not cve:
                logger.debug("Vulnerability missing CVE, skipping")
                return None

            # Validate CVE format
            cve = validate_cve(cve)
            if not cve:
                logger.warning(f"Invalid CVE format: {vuln_data.get('cve')}")
                return None

            # Extract CVSS score
            cvss_score = validate_cvss_score(vuln_data.get("cvss"))

            # Extract severity and map to RegScale
            severity_str = vuln_data.get("severity", "unknown").lower()
            severity = self.finding_severity_map.get(severity_str, regscale_models.IssueSeverity.NotAssigned)

            # If we have CVSS but no severity, derive from CVSS
            if cvss_score and severity == regscale_models.IssueSeverity.NotAssigned:
                severity = map_cvss_to_severity(cvss_score)

            # Extract package information
            package_name = vuln_data.get("packageName", "")
            package_version = vuln_data.get("packageVersion", "")
            package_type = vuln_data.get("packageType", "")

            # Extract fix information
            status = vuln_data.get("status", "")
            fixed_version = ""
            if "fixed in" in status.lower():
                # Extract version from "fixed in X.Y.Z"
                parts = status.split("fixed in")
                if len(parts) > 1:
                    fixed_version = parts[1].strip()

            # Extract dates
            discovered_date = vuln_data.get("discovered", "")
            published_date = vuln_data.get("published")
            fix_date = vuln_data.get("fixDate")

            # Convert timestamps to date strings
            if isinstance(published_date, int):
                published_date = datetime.fromtimestamp(published_date).strftime("%Y-%m-%d")
            if isinstance(fix_date, int):
                fix_date = datetime.fromtimestamp(fix_date).strftime("%Y-%m-%d")

            # Extract risk factors
            risk_factors = vuln_data.get("riskFactors", {})
            risk_factor_list = list(risk_factors.keys()) if risk_factors else []
            risk_factors_str = ", ".join(risk_factor_list)

            # Build description
            description = vuln_data.get("description", "")
            description = truncate_description(description, max_length=5000)

            # Build title
            title = vuln_data.get("title") or f"{cve} - {package_name or 'Unknown Package'}"

            # Build recommendation
            recommendation = ""
            if fixed_version:
                recommendation = f"Update {package_name} to version {fixed_version}"
            elif status:
                recommendation = status

            # Return finding dictionary for deduplication
            return {
                "cve": cve,
                "asset_identifier": asset_identifier,
                "asset_id": asset_identifier,
                "asset_type": asset_type,
                "severity": severity_str,
                "cvss_score": cvss_score,
                "cvss_v3_score": cvss_score,
                "title": title,
                "description": description,
                "package_name": package_name,
                "package_version": package_version,
                "package_type": package_type,
                "fixed_version": fixed_version,
                "discovered_date": discovered_date,
                "published_date": published_date,
                "fix_date": fix_date,
                "risk_factors": risk_factors_str,
                "status": status,
                "recommendation_for_mitigation": recommendation,
                "link": vuln_data.get("link", ""),
                "vec_str": vuln_data.get("vecStr", ""),
            }

        except Exception as e:
            logger.error(f"Error parsing vulnerability: {e}")
            return None

    def _dict_to_integration_finding(self, finding_dict: Dict) -> IntegrationFinding:
        """
        Convert finding dictionary to IntegrationFinding object.

        :param Dict finding_dict: Finding dictionary from _parse_vulnerability or deduplicator
        :return: IntegrationFinding object
        :rtype: IntegrationFinding
        """
        # Map severity string to enum
        severity_str = finding_dict.get("severity", "unknown").lower()
        severity = self.finding_severity_map.get(severity_str, regscale_models.IssueSeverity.NotAssigned)

        return IntegrationFinding(
            title=finding_dict.get("title", ""),
            description=finding_dict.get("description", ""),
            severity=severity,
            cve=finding_dict.get("cve", ""),
            cvss_v3_score=finding_dict.get("cvss_v3_score"),
            asset_identifier=finding_dict.get("asset_identifier", ""),
            package_name=finding_dict.get("package_name", ""),
            package_version=finding_dict.get("package_version", ""),
            fixed_version=finding_dict.get("fixed_version", ""),
            recommendation_for_mitigation=finding_dict.get("recommendation_for_mitigation", ""),
            external_id=finding_dict.get("link", ""),
            status=regscale_models.ControlTestResultStatus.FAIL,
        )

    def _fetch_assets_from_csv(self, **kwargs) -> Iterator[IntegrationAsset]:
        """
        Fetch assets using CSV download endpoints.

        Alternative to fetch_assets() for bulk CSV imports. Uses Platform One (P1)
        customer's proven workflow with CSV download endpoints.

        :yields: IntegrationAsset objects
        :rtype: Iterator[IntegrationAsset]
        """
        from regscale.integrations.commercial.prisma.csv_parser import (
            parse_prisma_csv,
            expand_host_lists,
            csv_to_integration_assets,
        )

        logger.info(f"Fetching assets from CSV download endpoint (scan_type: {self.scan_type})...")

        # Download CSV data
        if self.scan_type == "hosts":
            csv_data = self.client.get_hosts_csv()
        elif self.scan_type == "images":
            csv_data = self.client.get_images_csv()
        else:
            logger.error(f"CSV mode not supported for scan_type: {self.scan_type}")
            return

        # Parse CSV
        rows = parse_prisma_csv(csv_data)
        logger.info(f"Parsed {len(rows)} rows from CSV data")

        # Expand host lists if present
        expanded_rows = list(expand_host_lists(rows))
        logger.info(f"Expanded to {len(expanded_rows)} rows (host list expansion)")

        # Convert to assets
        assets = csv_to_integration_assets(expanded_rows, self.scan_type)
        logger.info(f"Converted to {len(assets)} unique assets")

        # Convert to IntegrationAsset objects and yield
        for asset_dict in assets:
            yield self._dict_to_integration_asset_from_csv(asset_dict)

    def _fetch_findings_from_csv(self, **kwargs) -> Iterator[Dict]:
        """
        Fetch findings using CSV download endpoints.

        Alternative to fetch_findings() for bulk CSV imports. Uses Platform One (P1)
        customer's proven workflow with CSV download endpoints.

        :yields: Finding dictionaries
        :rtype: Iterator[Dict]
        """
        from regscale.integrations.commercial.prisma.csv_parser import (
            parse_prisma_csv,
            expand_host_lists,
            csv_to_integration_findings,
        )

        logger.info(f"Fetching findings from CSV download endpoint (scan_type: {self.scan_type})...")

        # Download CSV data
        if self.scan_type == "hosts":
            csv_data = self.client.get_hosts_csv()
        elif self.scan_type == "images":
            csv_data = self.client.get_images_csv()
        else:
            logger.error(f"CSV mode not supported for scan_type: {self.scan_type}")
            return

        # Parse and expand
        rows = parse_prisma_csv(csv_data)
        expanded_rows = list(expand_host_lists(rows))
        logger.info(f"Expanded {len(rows)} CSV rows to {len(expanded_rows)} rows (host list expansion)")

        # Convert to findings
        findings = csv_to_integration_findings(expanded_rows)
        logger.info(f"Converted to {len(findings)} findings from CSV data")

        # Yield findings
        for finding in findings:
            yield finding

    def _dict_to_integration_asset_from_csv(self, asset_dict: Dict) -> IntegrationAsset:
        """
        Convert CSV asset dictionary to IntegrationAsset object.

        :param Dict asset_dict: Asset dictionary from csv_parser
        :return: IntegrationAsset object
        :rtype: IntegrationAsset
        """
        return IntegrationAsset(
            identifier=asset_dict.get("identifier", ""),
            name=asset_dict.get("name", ""),
            description=f"{asset_dict.get('type', 'asset')} - {asset_dict.get('distro', 'Unknown')}",
            asset_type=asset_dict.get("type", ""),
        )
