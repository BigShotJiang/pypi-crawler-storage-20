#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pipeline Compliance Integration Module

Provides component-level compliance tracking for CI/CD pipelines (GitLab, GitHub).
Solves the "Last-In-Wins" problem when multiple repositories feed into a single SSP.
"""

from regscale.integrations.commercial.pipeline_compliance.cli import pipeline
from regscale.integrations.commercial.pipeline_compliance.service import (
    PipelineComplianceService,
)
from regscale.integrations.commercial.pipeline_compliance.providers import (
    PipelineProvider,
    GitLabProvider,
    GitHubProvider,
)

__all__ = [
    "pipeline",
    "PipelineComplianceService",
    "PipelineProvider",
    "GitLabProvider",
    "GitHubProvider",
]
