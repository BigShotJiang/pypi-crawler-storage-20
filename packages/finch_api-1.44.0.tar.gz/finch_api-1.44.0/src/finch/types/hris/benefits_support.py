# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel
from .benefit_features_and_operations import BenefitFeaturesAndOperations

__all__ = ["BenefitsSupport"]


class BenefitsSupport(BaseModel):
    """Each benefit type and their supported features.

    If the benefit type is not supported, the property will be null
    """

    commuter: Optional[BenefitFeaturesAndOperations] = None

    custom_post_tax: Optional[BenefitFeaturesAndOperations] = None

    custom_pre_tax: Optional[BenefitFeaturesAndOperations] = None

    fsa_dependent_care: Optional[BenefitFeaturesAndOperations] = None

    fsa_medical: Optional[BenefitFeaturesAndOperations] = None

    hsa_post: Optional[BenefitFeaturesAndOperations] = None

    hsa_pre: Optional[BenefitFeaturesAndOperations] = None

    s125_dental: Optional[BenefitFeaturesAndOperations] = None

    s125_medical: Optional[BenefitFeaturesAndOperations] = None

    s125_vision: Optional[BenefitFeaturesAndOperations] = None

    simple: Optional[BenefitFeaturesAndOperations] = None

    simple_ira: Optional[BenefitFeaturesAndOperations] = None

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[str, Optional[BenefitFeaturesAndOperations]] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(self, attr: str) -> Optional[BenefitFeaturesAndOperations]: ...
    else:
        __pydantic_extra__: Dict[str, Optional[BenefitFeaturesAndOperations]]
