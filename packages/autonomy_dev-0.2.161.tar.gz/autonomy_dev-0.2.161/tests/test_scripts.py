"""Test the fixtures."""
