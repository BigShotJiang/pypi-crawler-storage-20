"""Package manager service."""
