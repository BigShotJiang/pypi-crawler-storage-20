"""Dependencies service package."""
