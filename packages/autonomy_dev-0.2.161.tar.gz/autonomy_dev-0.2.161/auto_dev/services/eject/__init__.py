"""Eject service package."""
