"""
Aniate Tool System - Local-first with marketplace sync

Architecture:
- Tools downloaded once → ~/.aniate/tools/
- Execution uses LOCAL config (no network latency)
- Updates sync in background

No SQL per call. No server dependency. Instant execution.
"""
import json
import requests
from rich.console import Console
from rich.markdown import Markdown
from rich.table import Table
from pathlib import Path
from typing import Optional, List, Dict
import os

from aniate.config import SERVER_URL, GROQ_API_KEY
from aniate.auth import get_session

console = Console()

# Local tool storage - ~/.aniate/tools/
ANIATE_DIR = Path.home() / ".aniate"
TOOLS_DIR = ANIATE_DIR / "tools"
TOOLS_DIR.mkdir(parents=True, exist_ok=True)


def _get_groq_client():
    """Lazy load Groq client - only when actually needed."""
    from groq import Groq
    return Groq(api_key=GROQ_API_KEY)


# ============================================
# LOCAL TOOL CACHE
# ============================================

def get_local_tool(slug: str) -> Optional[Dict]:
    """Get tool config from local cache. No network."""
    tool_file = TOOLS_DIR / f"{slug}.json"
    if tool_file.exists():
        return json.loads(tool_file.read_text())
    return None


def save_local_tool(slug: str, config: Dict):
    """Save tool config to local cache."""
    tool_file = TOOLS_DIR / f"{slug}.json"
    tool_file.write_text(json.dumps(config, indent=2))


def list_local_tools() -> List[Dict]:
    """List all locally installed tools."""
    tools = []
    for f in TOOLS_DIR.glob("*.json"):
        try:
            tools.append(json.loads(f.read_text()))
        except:
            pass
    return tools


# ============================================
# MARKETPLACE
# ============================================

def fetch_marketplace() -> List[Dict]:
    """Fetch available tools from marketplace (metadata only)."""
    try:
        response = requests.get(f"{SERVER_URL}/marketplace", timeout=10)
        if response.ok:
            return response.json().get("tools", [])
    except:
        pass
    return []


def install_tool(slug: str):
    """Install a tool from the marketplace. One-time download."""
    session = get_session()
    if not session:
        console.print("[dim]Authentication required. Run: ant login[/dim]")
        return
    
    existing = get_local_tool(slug)
    if existing:
        console.print(f"[dim]{slug} installed. Use 'ant update' to refresh.[/dim]")
        return
    
    console.print(f"[dim]Installing {slug}...[/dim]")
    
    try:
        response = requests.get(
            f"{SERVER_URL}/tool/{slug}/download",
            headers={"Authorization": f"Bearer {session['access_token']}"},
            timeout=30
        )
        
        if response.status_code == 404:
            console.print(f"[dim]'{slug}' not found.[/dim]")
            return
        
        if response.ok:
            config = response.json()
            save_local_tool(slug, config)
            console.print(f"[green]Installed.[/green] {config.get('name', slug)}")
            console.print(f"[dim]Run: ant {slug}[/dim]")
        else:
            console.print(f"[red]Failed.[/red]")
            
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")


def uninstall_tool(slug: str):
    """Remove a locally installed tool."""
    tool_file = TOOLS_DIR / f"{slug}.json"
    if tool_file.exists():
        tool_file.unlink()
        console.print(f"[dim]Removed.[/dim] {slug}")
    else:
        console.print(f"[dim]'{slug}' not installed.[/dim]")


def update_tools():
    """Sync all installed tools with latest versions."""
    session = get_session()
    if not session:
        console.print("[dim]Authentication required. Run: ant login[/dim]")
        return
    
    local_tools = list_local_tools()
    if not local_tools:
        console.print("[dim]No tools installed. Run: ant marketplace[/dim]")
        return
    
    console.print("[dim]Syncing...[/dim]")
    updated = 0
    
    for tool in local_tools:
        slug = tool.get("slug")
        try:
            response = requests.get(
                f"{SERVER_URL}/tool/{slug}/download",
                headers={"Authorization": f"Bearer {session['access_token']}"},
                timeout=30
            )
            if response.ok:
                new_config = response.json()
                if new_config.get("version", 0) > tool.get("version", 0):
                    save_local_tool(slug, new_config)
                    console.print(f"  [green]↑[/green] {slug}")
                    updated += 1
        except:
            pass
    
    if updated:
        console.print(f"[green]Updated {updated} tool(s).[/green]")
    else:
        console.print("[dim]All tools up to date.[/dim]")


def marketplace():
    """Browse the tool marketplace."""
    console.print("\n[bold white]MARKETPLACE[/bold white]")
    console.print("[dim]" + "-" * 40 + "[/dim]\n")
    
    remote_tools = fetch_marketplace()
    local_slugs = {t.get("slug") for t in list_local_tools()}
    
    if not remote_tools:
        console.print("[dim]Could not reach marketplace.[/dim]")
        return
    
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Status", style="dim", width=3)
    table.add_column("Tool", style="white", width=15)
    table.add_column("Description", style="dim")
    
    for tool in remote_tools:
        slug = tool.get("slug", "")
        status = "[green]●[/green]" if slug in local_slugs else "[dim]○[/dim]"
        table.add_row(status, slug, tool.get("description", ""))
    
    console.print(table)
    console.print()
    console.print("[dim]● installed  ○ available[/dim]")
    console.print("[dim]Install: ant install <tool>[/dim]\n")


def tools_list():
    """List installed tools."""
    tools = list_local_tools()
    
    if not tools:
        console.print("[dim]No tools. Run: ant marketplace[/dim]")
        return
    
    console.print("\n[bold white]INSTALLED[/bold white]")
    console.print("[dim]" + "-" * 40 + "[/dim]\n")
    
    for tool in tools:
        console.print(f"  [white]{tool.get('slug', ''):15}[/white] [dim]{tool.get('description', '')}[/dim]")
    console.print()


# ============================================
# TOOL EXECUTION - LOCAL, NO NETWORK
# ============================================

def run_tool(slug: str, content: str = "", instructions: str = ""):
    """Execute tool using LOCAL config. No server call for prompt."""
    
    # Get from local cache
    tool = get_local_tool(slug)
    
    if not tool:
        console.print(f"[dim]Tool '{slug}' not installed.[/dim]")
        console.print(f"[dim]Run: ant install {slug}[/dim]")
        return None
    
    # Build message
    user_message = content
    if instructions:
        user_message = f"{content}\n\nInstructions: {instructions}" if content else instructions
    
    messages = [
        {"role": "system", "content": tool.get("system_prompt", "You are a helpful assistant.")},
        {"role": "user", "content": user_message}
    ]
    
    # Execute locally with Groq (lazy loaded)
    try:
        client = _get_groq_client()
        completion = client.chat.completions.create(
            model=tool.get("model", "llama-3.1-8b-instant"),
            messages=messages,
            max_completion_tokens=2048,
            temperature=0.7,
        )
        return completion.choices[0].message.content
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        return None


def tool_command(slug: str, args: Optional[List[str]] = None):
    """Generic tool command handler."""
    args = args or []
    
    content = ""
    instructions = ""
    
    if args:
        first_arg = args[0]
        path = Path(first_arg)
        
        if path.exists() and path.is_file():
            try:
                content = path.read_text()
                instructions = " ".join(args[1:]) if len(args) > 1 else ""
                console.print(f"[dim]{path.name}[/dim]")
            except Exception as e:
                console.print(f"[red]Cannot read file:[/red] {e}")
                return
        else:
            instructions = " ".join(args)
    
    if not content and not instructions:
        console.print(f"[dim]Usage: ant {slug} <file> [instructions][/dim]")
        console.print(f"[dim]       ant {slug} \"your question\"[/dim]")
        return
    
    output = run_tool(slug, content, instructions)
    
    if output:
        console.print()
        console.print(Markdown(output))
        console.print()
