from setuptools import setup, find_packages

setup(
    name="custom_commons",
    version="0.1.0",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    python_requires=">=3.6.8",
    install_requires=[
        "requests>=2.20.0",
        "aiohttp>=3.5.0",
        "dataclasses;python_version<'3.7'",
        "aiohttp-socks>=0.5.0",
    ],
    extras_require={
        "proxy": [
            "PySocks>=1.6.0",
        ],
    },
)
