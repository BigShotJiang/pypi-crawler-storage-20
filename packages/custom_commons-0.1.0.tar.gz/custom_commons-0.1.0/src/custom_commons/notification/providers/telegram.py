"""텔레그램 알림 Provider"""

from typing import Dict, List, Optional, Union

import aiohttp
import requests

from ..base import NotificationProvider
from ..exceptions import ProviderConfigError, SendFailedError
from ..models import NotificationMessage, NotificationResult, NotificationStatus


class TelegramProvider(NotificationProvider):
    """텔레그램 알림 Provider

    텔레그램 Bot API를 사용하여 메시지를 발송합니다.

    Example:
        # 기본 사용
        provider = TelegramProvider(
            bot_token="123456:ABC-DEF...",
            default_chat_ids=["chat_id_1", "chat_id_2"]
        )

        # SOCKS5 프록시 사용
        provider = TelegramProvider(
            bot_token="123456:ABC-DEF...",
            proxy="socks5://127.0.0.1:1080"
        )

        # 인증이 필요한 프록시
        provider = TelegramProvider(
            bot_token="123456:ABC-DEF...",
            proxy="socks5://user:pass@127.0.0.1:1080"
        )

    Args:
        bot_token: 텔레그램 봇 토큰 (@BotFather에서 발급)
        default_chat_ids: 기본 수신 채팅 ID 목록 (recipients 미지정 시 사용)
        parse_mode: 메시지 파싱 모드 (HTML, Markdown, MarkdownV2)
        timeout: API 요청 타임아웃 (초)
        proxy: SOCKS5 프록시 URL (예: socks5://host:port)
        proxy_chain: 다중 SOCKS5 프록시 체인 (최소 2개, proxy와 동시 사용 불가)

    Example:
        # 프록시 체인 사용
        provider = TelegramProvider(
            bot_token="123456:ABC-DEF...",
            proxy_chain=[
                "socks5://first-proxy:1080",
                "socks5://second-proxy:1081",
            ]
        )
    """

    def __init__(
        self,
        bot_token: str,
        default_chat_ids: Optional[List[str]] = None,
        parse_mode: str = "HTML",
        timeout: float = 10.0,
        proxy: Optional[str] = None,
        proxy_chain: Optional[List[str]] = None,
    ):
        # type: (...) -> None
        self._bot_token = bot_token
        self._default_chat_ids = default_chat_ids or []
        self._parse_mode = parse_mode
        self._timeout = timeout
        self._proxy = proxy
        self._proxy_chain = proxy_chain
        self._api_base = "https://api.telegram.org/bot{}".format(bot_token)

        # proxy_chain 설정 시 유효성 검증
        if self._proxy_chain:
            self._validate_proxy_chain()

    @property
    def name(self):
        # type: () -> str
        return "telegram"

    def validate_config(self):
        # type: () -> bool
        """봇 토큰이 설정되어 있는지 검증합니다."""
        if not self._bot_token:
            raise ProviderConfigError("봇 토큰이 설정되지 않았습니다.")
        if not self._bot_token.count(":") == 1:
            raise ProviderConfigError("봇 토큰 형식이 올바르지 않습니다.")
        return True

    def _validate_proxy_chain(self):
        # type: () -> None
        """proxy_chain 설정의 유효성을 검증합니다."""
        # proxy와 proxy_chain 동시 사용 불가
        if self._proxy:
            raise ProviderConfigError(
                "proxy와 proxy_chain은 동시에 사용할 수 없습니다."
            )

        # 최소 2개 필요
        if len(self._proxy_chain) < 2:
            raise ProviderConfigError(
                "proxy_chain은 최소 2개의 프록시가 필요합니다."
            )

        # SOCKS5만 허용
        for proxy_url in self._proxy_chain:
            if not proxy_url.lower().startswith("socks5://"):
                raise ProviderConfigError(
                    "proxy_chain은 SOCKS5 프록시만 지원합니다: {}".format(proxy_url)
                )

    def _get_chat_ids(self, message):
        # type: (NotificationMessage) -> List[str]
        """메시지에서 chat_id 목록을 추출합니다."""
        chat_ids = message.recipients or self._default_chat_ids
        if not chat_ids:
            raise SendFailedError("수신자(chat_id)가 지정되지 않았습니다.")
        return chat_ids

    def _build_payload(self, chat_id, message):
        # type: (str, NotificationMessage) -> dict
        """API 요청 payload를 생성합니다."""
        payload = {
            "chat_id": chat_id,
            "text": message.content,
            "parse_mode": self._parse_mode,
        }

        # metadata에서 추가 옵션 적용
        if message.metadata:
            if "disable_notification" in message.metadata:
                payload["disable_notification"] = message.metadata["disable_notification"]
            if "reply_to_message_id" in message.metadata:
                payload["reply_to_message_id"] = message.metadata["reply_to_message_id"]

        return payload

    def _get_requests_proxies(self):
        # type: () -> Optional[Dict[str, str]]
        """requests용 프록시 설정을 반환합니다."""
        if not self._proxy:
            return None
        return {
            "http": self._proxy,
            "https": self._proxy,
        }

    def _build_result(self, chat_ids, success_count, failed_ids, message_ids):
        # type: (List[str], int, List[str], List[str]) -> NotificationResult
        """발송 결과를 생성합니다."""
        if success_count == len(chat_ids):
            status = NotificationStatus.SUCCESS
        elif success_count > 0:
            status = NotificationStatus.PARTIAL
        else:
            status = NotificationStatus.FAILED

        return NotificationResult(
            status=status,
            provider=self.name,
            message_id=",".join(message_ids) if message_ids else None,
            error_message="실패한 chat_ids: {}".format(failed_ids) if failed_ids else None,
            details={
                "total": len(chat_ids),
                "success": success_count,
                "failed": len(failed_ids),
                "failed_ids": failed_ids,
            },
        )

    def _send_with_chain_sync(self, message):
        # type: (NotificationMessage) -> NotificationResult
        """프록시 체인으로 동기 발송합니다. (내부적으로 asyncio 사용)"""
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(self._send_with_chain_async(message))
        finally:
            loop.close()

    async def _send_with_chain_async(self, message):
        # type: (NotificationMessage) -> NotificationResult
        """aiohttp-socks ChainProxyConnector를 사용하여 비동기 체인 발송합니다."""
        try:
            from aiohttp_socks import ChainProxyConnector
        except ImportError:
            raise ProviderConfigError(
                "비동기 프록시 체인 사용을 위해 aiohttp-socks>=0.5.0 패키지가 필요합니다. "
                "pip install aiohttp-socks"
            )

        chat_ids = self._get_chat_ids(message)
        success_count = 0
        failed_ids = []  # type: List[str]
        message_ids = []  # type: List[str]

        timeout = aiohttp.ClientTimeout(total=self._timeout)

        # 프록시 체인 설정
        connector = ChainProxyConnector.from_urls(self._proxy_chain)

        async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
            for chat_id in chat_ids:
                try:
                    payload = self._build_payload(chat_id, message)
                    async with session.post(
                        "{}/sendMessage".format(self._api_base),
                        json=payload,
                    ) as response:
                        response.raise_for_status()
                        result_data = await response.json()

                        if result_data.get("ok"):
                            success_count += 1
                            msg_id = result_data.get("result", {}).get("message_id")
                            if msg_id:
                                message_ids.append(str(msg_id))
                        else:
                            failed_ids.append(chat_id)

                except aiohttp.ClientError:
                    failed_ids.append(chat_id)

        return self._build_result(chat_ids, success_count, failed_ids, message_ids)

    def send(self, message):
        # type: (Union[str, NotificationMessage]) -> NotificationResult
        """텔레그램 메시지를 동기 방식으로 발송합니다."""
        if isinstance(message, str):
            message = NotificationMessage(message)

        # proxy_chain 사용 시 별도 메서드로 처리
        if self._proxy_chain:
            return self._send_with_chain_sync(message)

        chat_ids = self._get_chat_ids(message)
        success_count = 0
        failed_ids = []  # type: List[str]
        message_ids = []  # type: List[str]

        proxies = self._get_requests_proxies()

        for chat_id in chat_ids:
            try:
                payload = self._build_payload(chat_id, message)
                response = requests.post(
                    "{}/sendMessage".format(self._api_base),
                    json=payload,
                    timeout=self._timeout,
                    proxies=proxies,
                )
                response.raise_for_status()

                result_data = response.json()
                if result_data.get("ok"):
                    success_count += 1
                    msg_id = result_data.get("result", {}).get("message_id")
                    if msg_id:
                        message_ids.append(str(msg_id))
                else:
                    failed_ids.append(chat_id)

            except requests.RequestException:
                failed_ids.append(chat_id)

        return self._build_result(chat_ids, success_count, failed_ids, message_ids)

    async def send_async(self, message):
        # type: (Union[str, NotificationMessage]) -> NotificationResult
        """텔레그램 메시지를 비동기 방식으로 발송합니다."""
        if isinstance(message, str):
            message = NotificationMessage(message)

        # proxy_chain 사용 시 별도 메서드로 처리
        if self._proxy_chain:
            return await self._send_with_chain_async(message)

        chat_ids = self._get_chat_ids(message)
        success_count = 0
        failed_ids = []  # type: List[str]
        message_ids = []  # type: List[str]

        timeout = aiohttp.ClientTimeout(total=self._timeout)

        # 프록시 설정
        connector = None
        if self._proxy:
            try:
                from aiohttp_socks import ProxyConnector
                connector = ProxyConnector.from_url(self._proxy)
            except ImportError:
                raise ProviderConfigError(
                    "비동기 프록시 사용을 위해 aiohttp-socks 패키지가 필요합니다. "
                    "pip install aiohttp-socks"
                )

        async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
            for chat_id in chat_ids:
                try:
                    payload = self._build_payload(chat_id, message)
                    async with session.post(
                        "{}/sendMessage".format(self._api_base),
                        json=payload,
                    ) as response:
                        response.raise_for_status()
                        result_data = await response.json()

                        if result_data.get("ok"):
                            success_count += 1
                            msg_id = result_data.get("result", {}).get("message_id")
                            if msg_id:
                                message_ids.append(str(msg_id))
                        else:
                            failed_ids.append(chat_id)

                except aiohttp.ClientError:
                    failed_ids.append(chat_id)

        return self._build_result(chat_ids, success_count, failed_ids, message_ids)
