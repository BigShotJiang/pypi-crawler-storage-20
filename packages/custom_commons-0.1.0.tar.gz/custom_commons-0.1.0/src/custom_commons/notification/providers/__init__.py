"""알림 Provider 모음

새로운 Provider 추가 시 이 파일에 import를 추가하세요.
"""

from .telegram import TelegramProvider

__all__ = [
    "TelegramProvider",
]
