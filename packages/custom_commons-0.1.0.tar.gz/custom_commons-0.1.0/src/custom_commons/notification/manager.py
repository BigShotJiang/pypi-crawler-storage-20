"""알림 관리자 - 여러 Provider를 통합 관리"""

import asyncio
import logging
from typing import Dict, List, Optional

from .base import NotificationProvider
from .exceptions import NotificationError, ProviderNotFoundError
from .models import NotificationMessage, NotificationResult, NotificationStatus


class NotificationManager:
    """알림 관리자 클래스 (Facade Pattern)

    여러 알림 Provider를 등록하고 통합 관리합니다.

    Example:
        manager = NotificationManager()
        manager.register_provider(SMSProvider(api_key="..."))
        manager.register_provider(TelegramProvider(bot_token="..."))

        # 동기 발송
        result = manager.send("sms", NotificationMessage(
            recipients=["010-1234-5678"],
            content="알림 메시지입니다."
        ))

        # 비동기 발송
        result = await manager.send_async("telegram", message)
    """

    def __init__(self, logger: Optional[logging.Logger] = None) -> None:
        """NotificationManager 초기화

        Args:
            logger: 로깅에 사용할 Logger 객체 (선택사항)
        """
        self._providers: Dict[str, NotificationProvider] = {}
        self._logger = logger or logging.getLogger(__name__)

    def register_provider(self, provider: NotificationProvider) -> None:
        """알림 Provider를 등록합니다.

        Args:
            provider: 등록할 NotificationProvider 인스턴스

        Raises:
            NotificationError: Provider 설정이 유효하지 않은 경우
        """
        if not provider.validate_config():
            raise NotificationError(
                f"Provider '{provider.name}' 설정이 유효하지 않습니다."
            )

        self._providers[provider.name] = provider
        self._logger.info(f"알림 Provider 등록: {provider.name}")

    def unregister_provider(self, name: str) -> None:
        """Provider 등록을 해제합니다.

        Args:
            name: 해제할 Provider 이름
        """
        if name in self._providers:
            del self._providers[name]
            self._logger.info(f"알림 Provider 해제: {name}")

    def get_provider(self, name: str) -> NotificationProvider:
        """등록된 Provider를 조회합니다.

        Args:
            name: Provider 이름

        Returns:
            NotificationProvider: 해당 Provider 인스턴스

        Raises:
            ProviderNotFoundError: Provider가 등록되지 않은 경우
        """
        if name not in self._providers:
            raise ProviderNotFoundError(f"등록되지 않은 Provider: {name}")
        return self._providers[name]

    def list_providers(self) -> List[str]:
        """등록된 모든 Provider 이름 목록을 반환합니다.

        Returns:
            List[str]: Provider 이름 목록
        """
        return list(self._providers.keys())

    def send(self, provider_name: str, message: NotificationMessage) -> NotificationResult:
        """지정된 Provider로 알림을 동기 발송합니다.

        Args:
            provider_name: 사용할 Provider 이름
            message: 발송할 메시지

        Returns:
            NotificationResult: 발송 결과
        """
        provider = self.get_provider(provider_name)

        try:
            self._logger.debug(
                f"알림 발송 시작: provider={provider_name}, "
                f"recipients={message.recipients}"
            )
            result = provider.send(message)
            self._logger.info(
                f"알림 발송 완료: provider={provider_name}, "
                f"status={result.status.value}"
            )
            return result
        except Exception as e:
            self._logger.error(
                f"알림 발송 실패: provider={provider_name}, error={str(e)}"
            )
            return NotificationResult(
                status=NotificationStatus.FAILED,
                provider=provider_name,
                error_message=str(e),
            )

    async def send_async(
        self, provider_name: str, message: NotificationMessage
    ) -> NotificationResult:
        """지정된 Provider로 알림을 비동기 발송합니다.

        Args:
            provider_name: 사용할 Provider 이름
            message: 발송할 메시지

        Returns:
            NotificationResult: 발송 결과
        """
        provider = self.get_provider(provider_name)

        try:
            self._logger.debug(
                f"알림 비동기 발송 시작: provider={provider_name}, "
                f"recipients={message.recipients}"
            )
            result = await provider.send_async(message)
            self._logger.info(
                f"알림 비동기 발송 완료: provider={provider_name}, "
                f"status={result.status.value}"
            )
            return result
        except Exception as e:
            self._logger.error(
                f"알림 비동기 발송 실패: provider={provider_name}, error={str(e)}"
            )
            return NotificationResult(
                status=NotificationStatus.FAILED,
                provider=provider_name,
                error_message=str(e),
            )

    def send_all(self, message: NotificationMessage) -> Dict[str, NotificationResult]:
        """등록된 모든 Provider로 알림을 동기 발송합니다.

        Args:
            message: 발송할 메시지

        Returns:
            Dict[str, NotificationResult]: Provider별 발송 결과
        """
        results = {}
        for name in self._providers:
            results[name] = self.send(name, message)
        return results

    async def send_all_async(
        self, message: NotificationMessage
    ) -> Dict[str, NotificationResult]:
        """등록된 모든 Provider로 알림을 비동기 발송합니다.

        모든 Provider에 동시에 발송합니다.

        Args:
            message: 발송할 메시지

        Returns:
            Dict[str, NotificationResult]: Provider별 발송 결과
        """
        tasks = {
            name: self.send_async(name, message) for name in self._providers
        }
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)

        return {
            name: (
                result
                if isinstance(result, NotificationResult)
                else NotificationResult(
                    status=NotificationStatus.FAILED,
                    provider=name,
                    error_message=str(result),
                )
            )
            for name, result in zip(tasks.keys(), results)
        }
