"""Notification 모듈 - 다채널 알림 발송

사용법:
    from custom_commons.notification import (
        NotificationManager,
        NotificationMessage,
        NotificationProvider,
    )

    # Provider 구현
    class MyProvider(NotificationProvider):
        @property
        def name(self) -> str:
            return "my_channel"
        ...

    # 사용
    manager = NotificationManager()
    manager.register_provider(MyProvider())
    result = manager.send("my_channel", NotificationMessage(
        recipients=["user@example.com"],
        content="알림 내용"
    ))
"""

from .base import NotificationProvider
from .exceptions import (
    NotificationError,
    ProviderConfigError,
    ProviderNotFoundError,
    SendFailedError,
)
from .manager import NotificationManager
from .models import NotificationMessage, NotificationResult, NotificationStatus

__all__ = [
    # Manager
    "NotificationManager",
    # Base class
    "NotificationProvider",
    # Models
    "NotificationMessage",
    "NotificationResult",
    "NotificationStatus",
    # Exceptions
    "NotificationError",
    "ProviderNotFoundError",
    "ProviderConfigError",
    "SendFailedError",
]
