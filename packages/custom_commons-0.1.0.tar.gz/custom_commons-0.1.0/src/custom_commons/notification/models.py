"""알림 관련 데이터 모델"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional


class NotificationStatus(Enum):
    """알림 발송 상태"""

    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"
    PARTIAL = "partial"


@dataclass
class NotificationMessage:
    """알림 메시지 모델

    Args:
        content: 메시지 내용
        recipients: 수신자 목록 (전화번호, 채팅ID 등). Provider에 기본값 설정 시 생략 가능
        title: 제목 (이메일, 슬랙 등에서 사용)
        metadata: 추가 메타데이터

    Example:
        # 간단한 생성
        msg = NotificationMessage("메시지 내용")

        # 수신자 지정
        msg = NotificationMessage("메시지 내용", recipients=["chat_id"])
    """

    content: str
    recipients: Optional[List[str]] = None
    title: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if isinstance(self.recipients, str):
            self.recipients = [self.recipients]
        if self.recipients is None:
            self.recipients = []


@dataclass
class NotificationResult:
    """알림 발송 결과

    Args:
        status: 발송 상태
        provider: 사용된 Provider 이름
        message_id: 외부 서비스에서 반환한 메시지 ID
        sent_at: 발송 시각
        error_message: 오류 메시지 (실패 시)
        details: 추가 상세 정보
    """

    status: NotificationStatus
    provider: str
    message_id: Optional[str] = None
    sent_at: datetime = field(default_factory=datetime.now)
    error_message: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_success(self) -> bool:
        """발송 성공 여부"""
        return self.status == NotificationStatus.SUCCESS
