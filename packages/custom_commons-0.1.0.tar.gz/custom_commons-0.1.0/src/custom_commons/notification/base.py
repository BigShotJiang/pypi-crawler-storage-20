"""알림 Provider 추상 베이스 클래스"""

from abc import ABC, abstractmethod
from typing import Union

from .models import NotificationMessage, NotificationResult


class NotificationProvider(ABC):
    """알림 Provider 추상 클래스 (Strategy Pattern)

    새로운 알림 채널을 추가하려면 이 클래스를 상속받아 구현합니다.

    Example:
        class TelegramProvider(NotificationProvider):
            @property
            def name(self) -> str:
                return "telegram"

            def validate_config(self) -> bool:
                return bool(self._bot_token)

            def send(self, message: NotificationMessage) -> NotificationResult:
                # 동기 발송 로직
                ...

            async def send_async(self, message: NotificationMessage) -> NotificationResult:
                # 비동기 발송 로직
                ...

        # 간단한 사용
        provider.send("메시지 내용")
        provider.send(NotificationMessage("메시지", recipients=["chat_id"]))
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider 이름 (예: 'sms', 'telegram', 'email')"""
        pass

    @abstractmethod
    def validate_config(self) -> bool:
        """Provider 설정이 유효한지 검증합니다.

        Returns:
            bool: 설정 유효 여부

        Raises:
            ProviderConfigError: 설정이 유효하지 않은 경우
        """
        pass

    @abstractmethod
    def send(self, message: Union[str, NotificationMessage]) -> NotificationResult:
        """알림을 동기 방식으로 발송합니다.

        Args:
            message: 발송할 메시지 (문자열 또는 NotificationMessage)

        Returns:
            NotificationResult: 발송 결과
        """
        pass

    @abstractmethod
    async def send_async(self, message: Union[str, NotificationMessage]) -> NotificationResult:
        """알림을 비동기 방식으로 발송합니다.

        Args:
            message: 발송할 메시지 (문자열 또는 NotificationMessage)

        Returns:
            NotificationResult: 발송 결과
        """
        pass

    def is_available(self) -> bool:
        """Provider가 사용 가능한 상태인지 확인합니다.

        기본 구현은 validate_config()를 호출합니다.
        필요시 오버라이드하여 추가 검증 로직을 구현할 수 있습니다.

        Returns:
            bool: 사용 가능 여부
        """
        try:
            return self.validate_config()
        except Exception:
            return False
