"""알림 모듈 예외 클래스"""


class NotificationError(Exception):
    """알림 관련 기본 예외"""

    pass


class ProviderNotFoundError(NotificationError):
    """Provider를 찾을 수 없음"""

    pass


class ProviderConfigError(NotificationError):
    """Provider 설정 오류"""

    pass


class SendFailedError(NotificationError):
    """알림 발송 실패"""

    pass
