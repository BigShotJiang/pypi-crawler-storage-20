"""
Custom Commons - 공통 모듈 패키지

사용법:
    from custom_commons import LoggerManager
    manager = LoggerManager(log_dir="logs")
    logger = manager.get_logger("app")

    from custom_commons import NotificationManager, NotificationMessage
    notifier = NotificationManager()
"""

__version__ = "0.1.0"

# 주요 기능 노출
from .database import get_connection
from .notification import NotificationManager, NotificationMessage
from .utils import LoggerManager, load_config

__all__ = [
    "get_connection",
    "LoggerManager",
    "load_config",
    "NotificationManager",
    "NotificationMessage",
]
