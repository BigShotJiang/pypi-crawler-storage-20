"""API 클라이언트"""


class APIClient:
    """API 클라이언트 클래스"""
    
    def __init__(self, base_url: str):
        """
        Args:
            base_url: API 기본 URL
        """
        self.base_url = base_url
    
    def get(self, endpoint: str):
        """GET 요청"""
        # TODO: 실제 구현 필요
        pass
    
    def post(self, endpoint: str, data: dict):
        """POST 요청"""
        # TODO: 실제 구현 필요
        pass

