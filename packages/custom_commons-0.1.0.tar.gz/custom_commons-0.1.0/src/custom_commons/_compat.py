"""파이썬 버전 호환성 처리"""

import sys

PY36_PLUS = sys.version_info >= (3, 6)
PY37_PLUS = sys.version_info >= (3, 7)
PY38_PLUS = sys.version_info >= (3, 8)
PY39_PLUS = sys.version_info >= (3, 9)
PY310_PLUS = sys.version_info >= (3, 10)
PY311_PLUS = sys.version_info >= (3, 11)

# 필요시 버전별 호환 코드 추가
# 예시:
# if PY39_PLUS:
#     from typing import Annotated
# else:
#     from typing_extensions import Annotated

