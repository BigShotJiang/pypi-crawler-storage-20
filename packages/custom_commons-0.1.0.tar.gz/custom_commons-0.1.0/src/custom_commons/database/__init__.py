"""Database 모듈"""

from .connection import get_connection

__all__ = ["get_connection"]

