"""로깅 유틸리티"""

import logging
import os
from logging.handlers import TimedRotatingFileHandler


class LoggerManager:
    """로거 관리 클래스 - 파일 로깅 및 로테이션 지원"""

    def __init__(self, name: str, log_dir: str, log_file: str = "app.log", retention_days: int = 7, encoding: str = "utf-8", log_level: int = logging.DEBUG):
        """
        :param name: 로거 이름
        :param log_dir: 로그 파일이 저장될 디렉토리
        :param log_file: 로그 파일 이름
        :param retention_days: 로그 보관 주기 (n일)
        :param encoding: 로그 파일 인코딩
        :param log_level: 로그 레벨
        
        Note:
            - name == "" → 모든 라이브러리 로그 다 찍힘
            - name == __name__ → 해당 모듈 및 하위 모듈 로그만 찍힘
        """
        self.name = name
        self.log_dir = log_dir
        self.log_file = os.path.join(self.log_dir, log_file)
        self.retention_days = retention_days
        self.encoding = encoding
        self.log_level = log_level
        # 로그 저장 디렉토리 생성
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

    def get_logger(self) -> logging.Logger:
        """
        로거를 생성하고 반환합니다.
        
        :return: 설정된 Logger 객체
        """
        if self.name == "__main__":
            self.name = ""
        logger = logging.getLogger(self.name)

        # 이미 핸들러가 설정되어 있다면 중복 추가 방지
        if logger.handlers:
            return logger

        logger.setLevel(self.log_level)
        formatter = logging.Formatter(
            '[%(asctime)s.%(msecs)03d] [%(levelname)s] '
            '[%(pathname)s:%(lineno)d - %(funcName)s] - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

        # 날짜별 분할 및 자동 삭제 핸들러 설정
        # when='midnight': 매일 자정에 로그 파일 분할
        # interval=1: 1일 간격
        # backupCount: 보관할 파일 개수 (n일 지나면 자동 삭제)
        file_handler = TimedRotatingFileHandler(
            filename=self.log_file,
            when='midnight',
            interval=1,
            backupCount=self.retention_days,
            encoding=self.encoding
        )
        file_handler.setFormatter(formatter)
        file_handler.suffix = "%Y%m%d"  # 파일명 뒤에 날짜 붙이기

        # 콘솔 출력용 핸들러
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)

        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        # 로거 설정 로깅(이름, 로그 파일 경로, 인코딩, 로그 레벨)
        logger.info(f"LoggerManager: '{self.name}' 로거 설정 완료, 로그 파일 경로: {self.log_file}, 인코딩: {self.encoding}, 로그 레벨: {logger.level}")
        return logger
