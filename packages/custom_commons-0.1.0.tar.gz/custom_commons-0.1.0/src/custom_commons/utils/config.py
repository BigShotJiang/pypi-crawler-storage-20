"""설정 파일 유틸리티"""

import json
from pathlib import Path


def load_config(path: str) -> dict:
    """
    JSON 설정 파일을 로드합니다.
    
    Args:
        path: 설정 파일 경로
    
    Returns:
        설정 딕셔너리
    """
    config_path = Path(path)
    
    if not config_path.exists():
        raise FileNotFoundError(f"설정 파일을 찾을 수 없습니다: {path}")
    
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)

