"""알림 모듈 테스트"""

import json

import pytest
import responses
from aioresponses import aioresponses

from custom_commons.notification import (
    NotificationManager,
    NotificationMessage,
    NotificationProvider,
    NotificationResult,
    NotificationStatus,
    ProviderConfigError,
    ProviderNotFoundError,
)
from custom_commons.notification.providers import TelegramProvider


# ============================================================================
# NotificationMessage 테스트
# ============================================================================


def test_notification_message_content_only():
    """content만으로 생성 가능한지 확인"""
    msg = NotificationMessage("테스트 메시지")
    assert msg.content == "테스트 메시지"
    assert msg.recipients == []


def test_notification_message_single_recipient():
    """단일 수신자를 리스트로 변환하는지 확인"""
    msg = NotificationMessage("테스트", recipients="chat_123")
    assert msg.recipients == ["chat_123"]


def test_notification_message_multiple_recipients():
    """복수 수신자 처리 확인"""
    msg = NotificationMessage(
        content="테스트",
        recipients=["chat_1", "chat_2"],
        title="제목",
    )
    assert len(msg.recipients) == 2
    assert msg.title == "제목"


# ============================================================================
# NotificationResult 테스트
# ============================================================================


def test_notification_result_is_success():
    """성공 상태 확인"""
    result = NotificationResult(
        status=NotificationStatus.SUCCESS,
        provider="test",
    )
    assert result.is_success is True


def test_notification_result_is_failed():
    """실패 상태 확인"""
    result = NotificationResult(
        status=NotificationStatus.FAILED,
        provider="test",
        error_message="오류 발생",
    )
    assert result.is_success is False
    assert result.error_message == "오류 발생"


# ============================================================================
# NotificationManager 테스트
# ============================================================================


class MockProvider(NotificationProvider):
    """테스트용 Mock Provider"""

    def __init__(self, name="mock", should_fail=False):
        # type: (str, bool) -> None
        self._name = name
        self._should_fail = should_fail

    @property
    def name(self):
        # type: () -> str
        return self._name

    def validate_config(self):
        # type: () -> bool
        return True

    def send(self, message):
        # type: (NotificationMessage) -> NotificationResult
        if self._should_fail:
            return NotificationResult(
                status=NotificationStatus.FAILED,
                provider=self.name,
                error_message="Mock 실패",
            )
        return NotificationResult(
            status=NotificationStatus.SUCCESS,
            provider=self.name,
            message_id="mock_123",
        )

    async def send_async(self, message):
        # type: (NotificationMessage) -> NotificationResult
        return self.send(message)


def test_manager_register_provider():
    """Provider 등록 확인"""
    manager = NotificationManager()
    provider = MockProvider()

    manager.register_provider(provider)

    assert "mock" in manager.list_providers()


def test_manager_unregister_provider():
    """Provider 등록 해제 확인"""
    manager = NotificationManager()
    provider = MockProvider()

    manager.register_provider(provider)
    manager.unregister_provider("mock")

    assert "mock" not in manager.list_providers()


def test_manager_get_provider():
    """Provider 조회 확인"""
    manager = NotificationManager()
    provider = MockProvider()

    manager.register_provider(provider)
    retrieved = manager.get_provider("mock")

    assert retrieved is provider


def test_manager_get_provider_not_found():
    """미등록 Provider 조회 시 예외 확인"""
    manager = NotificationManager()

    with pytest.raises(ProviderNotFoundError):
        manager.get_provider("nonexistent")


def test_manager_send():
    """동기 발송 확인"""
    manager = NotificationManager()
    manager.register_provider(MockProvider())

    result = manager.send(
        "mock",
        NotificationMessage(recipients=["user"], content="테스트"),
    )

    assert result.is_success
    assert result.provider == "mock"


def test_manager_send_all():
    """모든 Provider로 발송 확인"""
    manager = NotificationManager()
    manager.register_provider(MockProvider(name="provider1"))
    manager.register_provider(MockProvider(name="provider2"))

    results = manager.send_all(
        NotificationMessage(recipients=["user"], content="테스트"),
    )

    assert len(results) == 2
    assert results["provider1"].is_success
    assert results["provider2"].is_success


@pytest.mark.asyncio
async def test_manager_send_async():
    """비동기 발송 확인"""
    manager = NotificationManager()
    manager.register_provider(MockProvider())

    result = await manager.send_async(
        "mock",
        NotificationMessage(recipients=["user"], content="테스트"),
    )

    assert result.is_success


@pytest.mark.asyncio
async def test_manager_send_all_async():
    """모든 Provider로 비동기 발송 확인"""
    manager = NotificationManager()
    manager.register_provider(MockProvider(name="provider1"))
    manager.register_provider(MockProvider(name="provider2"))

    results = await manager.send_all_async(
        NotificationMessage(recipients=["user"], content="테스트"),
    )

    assert len(results) == 2
    assert results["provider1"].is_success
    assert results["provider2"].is_success


# ============================================================================
# TelegramProvider 테스트
# ============================================================================


def test_telegram_provider_validate_config():
    """텔레그램 설정 검증"""
    provider = TelegramProvider(bot_token="123456:ABC-DEF")
    assert provider.validate_config() is True


def test_telegram_provider_validate_config_empty_token():
    """빈 토큰 검증"""
    provider = TelegramProvider(bot_token="")

    with pytest.raises(ProviderConfigError, match="봇 토큰이 설정되지 않았습니다"):
        provider.validate_config()


def test_telegram_provider_validate_config_invalid_format():
    """잘못된 토큰 형식 검증"""
    provider = TelegramProvider(bot_token="invalid_token")

    with pytest.raises(ProviderConfigError, match="봇 토큰 형식이 올바르지 않습니다"):
        provider.validate_config()


def test_telegram_provider_name():
    """Provider 이름 확인"""
    provider = TelegramProvider(bot_token="123456:ABC")
    assert provider.name == "telegram"


@responses.activate
def test_telegram_provider_send_success():
    """텔레그램 발송 성공 테스트"""
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": True, "result": {"message_id": 12345}},
        status=200,
    )

    provider = TelegramProvider(bot_token="123456:ABC")
    result = provider.send(
        NotificationMessage(
            recipients=["chat_123"],
            content="테스트 메시지",
        )
    )

    assert result.is_success
    assert result.message_id == "12345"
    assert result.details["success"] == 1


@responses.activate
def test_telegram_provider_send_multiple_recipients():
    """여러 수신자에게 발송 테스트"""
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": True, "result": {"message_id": 111}},
        status=200,
    )
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": True, "result": {"message_id": 222}},
        status=200,
    )

    provider = TelegramProvider(bot_token="123456:ABC")
    result = provider.send(
        NotificationMessage(
            recipients=["chat_1", "chat_2"],
            content="테스트",
        )
    )

    assert result.is_success
    assert result.details["total"] == 2
    assert result.details["success"] == 2


@responses.activate
def test_telegram_provider_send_partial_failure():
    """부분 실패 테스트"""
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": True, "result": {"message_id": 111}},
        status=200,
    )
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": False, "description": "Bad Request"},
        status=200,
    )

    provider = TelegramProvider(bot_token="123456:ABC")
    result = provider.send(
        NotificationMessage(
            recipients=["chat_1", "chat_2"],
            content="테스트",
        )
    )

    assert result.status == NotificationStatus.PARTIAL
    assert result.details["success"] == 1
    assert result.details["failed"] == 1


@responses.activate
def test_telegram_provider_send_with_default_chat_ids():
    """기본 chat_id 사용 테스트"""
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": True, "result": {"message_id": 999}},
        status=200,
    )

    provider = TelegramProvider(
        bot_token="123456:ABC",
        default_chat_ids=["default_chat"],
    )
    result = provider.send(
        NotificationMessage(
            recipients=[],  # 빈 recipients
            content="테스트",
        )
    )

    assert result.is_success


@pytest.mark.asyncio
async def test_telegram_provider_send_async():
    """비동기 발송 테스트"""
    with aioresponses() as m:
        m.post(
            "https://api.telegram.org/bot123456:ABC/sendMessage",
            payload={"ok": True, "result": {"message_id": 54321}},
        )

        provider = TelegramProvider(bot_token="123456:ABC")
        result = await provider.send_async(
            NotificationMessage(
                recipients=["chat_123"],
                content="비동기 테스트",
            )
        )

        assert result.is_success
        assert result.message_id == "54321"


@responses.activate
def test_telegram_provider_with_metadata():
    """metadata 옵션 테스트"""
    responses.add(
        responses.POST,
        "https://api.telegram.org/bot123456:ABC/sendMessage",
        json={"ok": True, "result": {"message_id": 123}},
        status=200,
    )

    provider = TelegramProvider(bot_token="123456:ABC")
    result = provider.send(
        NotificationMessage(
            recipients=["chat_123"],
            content="테스트",
            metadata={
                "disable_notification": True,
                "reply_to_message_id": 100,
            },
        )
    )

    assert result.is_success

    # 요청 payload 확인
    request_body = json.loads(responses.calls[0].request.body)
    assert request_body["disable_notification"] is True
    assert request_body["reply_to_message_id"] == 100


# ============================================================================
# TelegramProvider proxy_chain 테스트
# ============================================================================


def test_telegram_provider_proxy_and_proxy_chain_conflict():
    """proxy와 proxy_chain 동시 설정 시 예외 발생"""
    with pytest.raises(ProviderConfigError, match="동시에 사용할 수 없습니다"):
        TelegramProvider(
            bot_token="123456:ABC",
            proxy="socks5://proxy1:1080",
            proxy_chain=["socks5://proxy1:1080", "socks5://proxy2:1081"],
        )


def test_telegram_provider_proxy_chain_minimum_two():
    """proxy_chain은 최소 2개 필요"""
    with pytest.raises(ProviderConfigError, match="최소 2개"):
        TelegramProvider(
            bot_token="123456:ABC",
            proxy_chain=["socks5://proxy1:1080"],
        )


def test_telegram_provider_proxy_chain_socks5_only():
    """proxy_chain은 SOCKS5만 지원"""
    with pytest.raises(ProviderConfigError, match="SOCKS5 프록시만 지원"):
        TelegramProvider(
            bot_token="123456:ABC",
            proxy_chain=[
                "socks5://proxy1:1080",
                "http://proxy2:8080",  # HTTP 프록시
            ],
        )


def test_telegram_provider_proxy_chain_valid():
    """유효한 proxy_chain 설정"""
    provider = TelegramProvider(
        bot_token="123456:ABC",
        proxy_chain=[
            "socks5://proxy1:1080",
            "socks5://proxy2:1081",
        ],
    )
    assert provider._proxy_chain == [
        "socks5://proxy1:1080",
        "socks5://proxy2:1081",
    ]


def test_telegram_provider_proxy_chain_three_proxies():
    """3개 이상 프록시 체인도 허용"""
    provider = TelegramProvider(
        bot_token="123456:ABC",
        proxy_chain=[
            "socks5://proxy1:1080",
            "socks5://proxy2:1081",
            "socks5://proxy3:1082",
        ],
    )
    assert len(provider._proxy_chain) == 3
