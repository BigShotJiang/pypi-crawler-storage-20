import pytest
import custom_commons


@pytest.fixture
def custom_logger(tmp_path):
    """테스트용 로거 - tmp_path에 로그 파일 생성"""
    manager = custom_commons.utils.LoggerManager(__name__, log_dir=str(tmp_path))
    return manager.get_logger()


def test_logger_create(custom_logger):
    """테스트용 로거 생성 확인"""
    assert custom_logger is not None


def test_logger_encoding(tmp_path):
    """로그 파일이 올바른 인코딩으로 생성되는지 확인"""
    manager = custom_commons.utils.LoggerManager(
        name="encoding_test",
        log_dir=str(tmp_path),
        encoding="euc-kr"
    )
    logger = manager.get_logger()
    # 한글 로그 작성
    logger.info("한글 테스트 메시지")
    # 로그 파일 확인
    log_file = tmp_path / "app.log"
    assert log_file.exists()
    
    # euc-kr 인코딩으로 읽을 수 있는지 확인
    content = log_file.read_text(encoding="euc-kr")
    assert "한글 테스트 메시지" in content


def test_logger_file_creation(tmp_path):
    """로그 파일이 제대로 생성되는지 확인"""
    log_file_name = "testname.log"
    manager = custom_commons.utils.LoggerManager(name="file_test", log_dir=str(tmp_path), log_file=log_file_name)
    logger = manager.get_logger()
    
    # 로그 작성
    logger.info("Test message")
    logger.warning("Warning message")
    logger.error("Error message")
    
    # 파일 생성 확인
    log_file = tmp_path / log_file_name
    assert log_file.exists()
    print(log_file.read_text())

    # 파일 내용 확인
    content = log_file.read_text()
    assert "Test message" in content
    assert "WARNING" in content
    assert "ERROR" in content


# 마지막에 테스트용으로 생성한 로그 파일 삭제 -> 자동으로 삭제됨됨
