# Common Modules

공통 모듈 패키지

## 설치

```bash
# GitLab에서 직접 설치
pip install git+ssh://git@gitlab.company.com/team/common_modules.git

# 또는 로컬에서 개발 모드 설치
pip install -e .
```

## 사용법

```python
from common_modules import get_connection, setup_logger, load_config
from common_modules.api import APIClient
```

