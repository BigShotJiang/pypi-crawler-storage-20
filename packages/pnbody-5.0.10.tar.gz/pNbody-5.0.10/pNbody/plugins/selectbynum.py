###########################################################################################
#  package:   pNbody
#  file:      selectbynum.py
#  brief:
#  copyright: GPLv3
#             Copyright (C) 2019 EPFL (Ecole Polytechnique Federale de Lausanne)
#             LASTRO - Laboratory of Astrophysics of EPFL
#  author:    Yves Revaz <yves.revaz@epfl.ch>
#
# This file is part of pNbody.
###########################################################################################
from Nbody import *
from Numeric import *

num = []
name = askopenfilename(initialdir='.')

if name != "":
    self.nb = self.nb.selectp(file=name)

    # redisplay
    self.display_info()
    self.display()
