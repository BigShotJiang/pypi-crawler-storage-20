IdsType = list[str]
