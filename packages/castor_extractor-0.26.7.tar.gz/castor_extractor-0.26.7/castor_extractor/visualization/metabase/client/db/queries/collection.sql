SELECT
    *
FROM
    {schema}.collection
