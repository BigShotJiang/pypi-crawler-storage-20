/*---------------------------------------------------------------------------*\
            Copyright (c) 2025, Henning Scheufler
-------------------------------------------------------------------------------
License
    This file is part of the pybFoam source code library, which is an
	unofficial extension to OpenFOAM.
    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.
    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Description
    Python module for OpenFOAM sampling functionality

\*---------------------------------------------------------------------------*/

#include "bind_sampling.hpp"

namespace py = pybind11;

PYBIND11_MODULE(_sampling, m) {
    m.doc() = "OpenFOAM sampling and surface functionality";
    
    Foam::bindSampledSurface(m);
    Foam::bindMeshSearch(m);
    Foam::bindSampledSet(m);
    Foam::bindInterpolation(m);
    Foam::bindSamplingFunctions(m);
}
