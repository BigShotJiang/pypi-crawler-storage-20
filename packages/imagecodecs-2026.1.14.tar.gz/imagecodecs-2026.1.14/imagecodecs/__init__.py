# imagecodecs/__init__.py

from __future__ import annotations

from .imagecodecs import (  # jpeg_check,; jpeg_version,; JpegError,; JPEG,
    NONE,
    NUMPY,
    DelayedImportError,
    NoneError,
    NumpyError,
    __all__,
    __dir__,
    __doc__,
    __getattr__,
    __version__,
    _codecs,
    _extensions,
    imagefileext,
    imread,
    imwrite,
    jpeg_decode,
    jpeg_encode,
    none_check,
    none_decode,
    none_encode,
    none_version,
    numpy_check,
    numpy_decode,
    numpy_encode,
    numpy_version,
    version,
)

# constants are repeated for documentation

__version__ = __version__
"""Imagecodecs version string."""
