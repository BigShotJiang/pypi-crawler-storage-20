import datetime
from typing import Any, Type, get_origin, get_args

from ..errors import InvalidQueryParamError

SEPARATOR = "||"

def convert_from_URL(key: str, value: str, target_type: Type, value_map: dict = None) -> Any:
    """Converts URL string to Python object with error handling."""

    try:

        # ---
        # Value mapping handling.
        # Value map is a way to convert strings to other values before type conversion.
        # e.g.: value_map = {"active": "1", "inactive": "0"} will convert "active" to "1" before type conversion.
        if value_map is not None:
            if value in value_map:

                # Convert it
                value = value_map[value]

        # ---
        # Type conversion

        # Simple types
        if target_type == bool:
            return value.lower() in ('true', '1', 't', 'yes', 'on')
        if target_type == int:
            return int(value)
        if target_type == float:
            return float(value)
        if target_type == datetime.date:
            return datetime.date.fromisoformat(value)
        if target_type == datetime.datetime:
            return datetime.datetime.fromisoformat(value)
        if target_type == datetime.time:
            return datetime.time.fromisoformat(value)
        
        # ---
        # Iterable types handling
        origin = get_origin(target_type) # If the type is "list[str]" returns "list"

        if origin in (list, tuple, set):

            # Separating the string into list using split with the separator
            items_str = [v for v in value.split(SEPARATOR) if v]

            # Default item type
            item_type = str

            # Gets the internal args of a type. If the type is "list[str]" returns "str"
            type_args = get_args(target_type)

            # If there are args, gets the first
            if type_args:
                item_type = type_args[0]
            
            # Recursive call for items
            items_converted = [convert_from_URL(f"{key}[{i}]", item, item_type) for i, item in enumerate(items_str)]
            
            # Try to cast the list to the original iterable type
            if origin == tuple: return tuple(items_converted)
            if origin == set: return set(items_converted)

            # Fallback to list
            return items_converted

        return value # Fallback to string
    
    except Exception as e:

        # Raise package-specific Invalid Query Param Error
        raise InvalidQueryParamError(key, value, target_type, e)
    

def convert_to_URL(key: str, value: Any, value_map: dict = None) -> str:
    """Converts Python object to URL string with error handling."""

    try:

        # ---
        # Type conversion
        
        # Default conversion to string
        converted_value = str(value)

        if isinstance(value, bool):
            converted_value = "true" if value else "false"
        if isinstance(value, (int, float)):
            converted_value = str(value)
        if isinstance(value, (datetime.date, datetime.datetime, datetime.time)):
            converted_value = value.isoformat()

        # ---
        # Iterable types handling
        if isinstance(value, (list, tuple, set)):

            # Recursive call for items
            items_str = [convert_to_URL(item, value_map) for item in value]

            # Join items with separator
            converted_value = SEPARATOR.join(items_str)

        # ---
        # Value mapping handling.
        # Value map is a way to convert values to other values before type conversion.
        # e.g.: value_map = {"1": "active", "0": "inactive"} will convert "1" to "active" before type conversion.
        if value_map is not None:
            reverse_map = {v: k for k, v in value_map.items()}
            if converted_value in reverse_map:
                converted_value = reverse_map[converted_value]

        # Return the converted and/or mapped value
        return converted_value
    
    except Exception as e:

        # Raise package-specific Invalid Query Param Error
        raise InvalidQueryParamError(key, value, str, e)