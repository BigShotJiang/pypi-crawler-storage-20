class LoraException(Exception):
    pass
