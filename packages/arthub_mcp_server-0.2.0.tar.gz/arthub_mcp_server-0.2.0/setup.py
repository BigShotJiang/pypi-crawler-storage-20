"""Setup script for arthub_mcp_server package."""

# Import built-in modules
from setuptools import setup

# Use pyproject.toml for configuration
setup()

