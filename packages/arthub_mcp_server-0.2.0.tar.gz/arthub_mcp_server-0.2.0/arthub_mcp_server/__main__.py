"""Main entry point for ArthHub MCP Server."""

# Import local modules
from arthub_mcp_server.server import main

if __name__ == "__main__":
    main()

