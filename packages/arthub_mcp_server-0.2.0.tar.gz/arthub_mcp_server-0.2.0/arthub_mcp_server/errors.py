"""Error handling for ArthHub MCP Server."""

# Import built-in modules
from enum import Enum


class ErrorCode(str, Enum):
    """Error codes for ArthHub operations."""

    # Configuration errors
    CONFIG_ERROR = "config_error"
    AUTH_ERROR = "auth_error"

    # File errors
    FILE_ERROR = "file_error"

    # API errors
    API_FAILURE = "api_failure"
    NETWORK_ERROR = "network_error"

    # Generic errors
    UNKNOWN = "unknown"


class ArthubError(Exception):
    """Base exception for ArthHub MCP Server."""

    def __init__(self, message: str, code: ErrorCode = ErrorCode.UNKNOWN):
        """Initialize ArthubError.

        Args:
            message: Error message
            code: Error code

        """
        super().__init__(message)
        self.message = message
        self.code = code

    def __str__(self) -> str:
        """Return string representation."""
        return f"[{self.code.value}] {self.message}"

