"""ArthHub MCP Server.

This module provides a FastMCP server for interacting with ArthHub storage system.
It supports uploading, downloading, and managing files and directories in ArthHub repositories.
"""

# Import third-party modules
from loguru import logger

# Import local modules
from arthub_mcp_server import __version__
from arthub_mcp_server.app import APP_NAME
from arthub_mcp_server.app import mcp
from arthub_mcp_server.log_config import setup_logging

# Import tools to register them
from arthub_mcp_server import directory  # noqa: F401
from arthub_mcp_server import download  # noqa: F401
from arthub_mcp_server import upload  # noqa: F401


def main() -> None:
    """Start the MCP server."""
    # Setup logging
    setup_logging()

    logger.info(f"Starting {APP_NAME} v{__version__}")

    # Run the MCP server
    mcp.run()


if __name__ == "__main__":
    main()

