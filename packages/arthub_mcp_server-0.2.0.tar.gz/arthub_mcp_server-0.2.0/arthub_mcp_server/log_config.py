"""Logging configuration for ArthHub MCP Server."""

# Import built-in modules
import sys

# Import third-party modules
from loguru import logger


def setup_logging(level: str = "INFO") -> None:
    """Setup logging configuration.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR)

    """
    # Remove default handler
    logger.remove()

    # Add custom handler with format
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        level=level,
        colorize=True,
    )

