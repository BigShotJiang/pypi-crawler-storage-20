"""Application configuration for ArthHub MCP Server."""

# Import third-party modules
from mcp.server.fastmcp import FastMCP

# Constants
APP_NAME = "arthub_mcp_server"
APP_DESCRIPTION = """ArthHub MCP Server for managing files and directories in ArthHub storage system.

## Configuration

Configure the server using environment variables:
- `ARTHUB_EMAIL` - Your ArthHub account email
- `ARTHUB_PASSWORD` - Your ArthHub account password
- `ARTHUB_PUBLIC_KEY` - ArthHub login public key (contact administrators to obtain)
- `ARTHUB_PUBLIC_TOKEN` - Alternative authentication using public token (optional)
- `ARTHUB_API_CONFIG` - API configuration name, defaults to "api_config_qq" for extranet access

## Authentication Methods

### Method 1: Email and Password
Set environment variables:
- ARTHUB_EMAIL
- ARTHUB_PASSWORD
- ARTHUB_PUBLIC_KEY

### Method 2: Public Token
Set environment variable:
- ARTHUB_PUBLIC_TOKEN

## Available Tools

### upload_file
Upload a file or directory to ArthHub storage. Supports both single files and batch directory uploads.

Parameters:
- asset_hub (str): Name of the asset repository
- remote_dir_path (str): Remote directory path where the content will be uploaded
- local_file_path (str): Local file or directory path to upload
- description (str, optional): Description for the uploaded content
- same_name_override (bool, optional): Override existing file with same name, defaults to False
- need_convert (bool, optional): Whether to convert the files, defaults to True

### download_file
Download a file or directory from ArthHub storage.

Parameters:
- asset_hub (str): Name of the asset repository
- remote_node_path (str): Remote node path to download (file or directory)
- local_dir_path (str): Local directory path to save the downloaded content
- same_name_override (bool, optional): Override existing file with same name, defaults to True
- download_multi_version (bool, optional): Download all versions of multi-version files, defaults to False

### create_directory
Create a directory in ArthHub storage.

Parameters:
- asset_hub (str): Name of the asset repository
- remote_dir_path (str): Remote directory path to create

### delete_node
Delete a node (file or directory) from ArthHub storage.

Parameters:
- asset_hub (str): Name of the asset repository
- remote_node_path (str): Remote node path to delete (file or directory)

### get_node_info
Get information about a node (file or directory) in ArthHub storage.

Parameters:
- asset_hub (str): Name of the asset repository
- remote_node_path (str): Remote node path to query (file or directory)

### get_child_nodes
Query child nodes (files and subdirectories) under a specified directory path in ArthHub.
This tool allows you to explore and traverse the directory structure.

Parameters:
- asset_hub (str): Name of the asset repository
- remote_node_path (str): Remote directory path to query (empty string for root)
- is_recursive (bool, optional): Whether to recursively get all descendants, defaults to False (only direct children)
- simplified_meta (bool, optional): Whether to use simplified metadata for lower bandwidth, defaults to True

Use this tool to:
- List all files and folders in a directory (non-recursive mode)
- Recursively traverse the entire directory tree to get complete structure (recursive mode)
- Build a map of repository contents before batch processing

## Use Cases

### Directory Exploration
Use `get_child_nodes` to explore the directory structure:
- Query direct children: `get_child_nodes(asset_hub="trial", remote_node_path="project/images", is_recursive=False)`
- Recursively traverse: `get_child_nodes(asset_hub="trial", remote_node_path="project", is_recursive=True)`

### Batch Processing Workflow
1. Use `get_child_nodes` to recursively explore directory structure and locate target files
2. Download specific files from ArthHub using `download_file`
3. Process files locally (e.g., image cropping, video editing)
4. Upload processed files back to ArthHub using `upload_file`
5. Optionally delete temporary files using `delete_node`

Example: Recursively find all JPG images in a directory, download them, batch crop, and upload back.
"""

# Initialize FastMCP server
mcp = FastMCP(
    name=APP_NAME,
    instructions=APP_DESCRIPTION,
)

