"""ArthHub MCP Server.

A Model Context Protocol (MCP) server for interacting with ArthHub storage system.
"""

# Import local modules
from arthub_mcp_server.__version__ import __version__

__all__ = ["__version__"]

