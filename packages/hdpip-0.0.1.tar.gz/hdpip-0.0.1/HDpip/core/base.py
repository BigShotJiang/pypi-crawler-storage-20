"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0

本文件包含本包所有的基础功能，~~全是屎山💩~~。
"""

import pathlib
import os
import sys
import platform
import pip
import subprocess

class HDpipError(Exception):
    """
    抛出一个HDpip错误，初始化函数可以接受一个`message`参数。

    例如：
    ```
    raise HDpip.core.base.HDpipError("炸了！")
    ```

    ***您不应该使用它**，如果您不是HDpip的开发者。*
    """

    def __init__(self, message = None) -> None:
        self.message = message
        super().__init__(self.message)

def unfinshed() -> None:
    """
    用于未完成功能的占位，使用`HDpipError`抛出一个错误。
    """

    raise HDpipError("\033[1m\033[91m不是，哥们，你写了这个功能吗？！\033[0m")

def getBaseDir() -> pathlib.Path:
    """
    获取HDpip的根目录，即`main.py`所在目录。
    
    :return: 路径
    :rtype: Path
    """

    return pathlib.Path(__file__).parents[1]

def getPython() -> pathlib.Path:
    """
    获取运行HDpip的Python的路径。
    
    :return: 路径
    :rtype: Path
    """

    return pathlib.Path(sys.executable)

def switchVersionToList(ver: str | tuple[str, int] | list[str, int]) -> list[int]:
    """
    输入一个类型为`str（分隔符为.）`、`tuple`或`list`的版本，且对每个元素`int`化，返回其列表形式。
    
    :param ver: 输入的版本，如`"0.1.0"`
    :type ver: str | tuple[str, int] | list [str, int]
    :return: 输出的版本，如`[0, 1, 0]`
    :rtype: list[int]
    """

    result = []
    if type(ver) == str:
        result = ver.split(".")
    elif type(ver) == tuple:
        result = list(ver)
    elif type(ver) == list:
        result = ver
    else:
        raise TypeError(f"版本转换为列表支持str、tuple或list类型，但您输入的是{type(ver).__name__}类型！")
    for i in range(0, len(result)):
        result[i] = int(result[i])
    return result


def switchVersionToStr(ver: tuple[str, int] | list[str, int]) -> str:
    """
    输入一个类型为`tuple`或`list`的版本，返回其`str（分隔符为.）`形式。
    
    :param ver: 输入的版本，如[0, 1, 0]
    :type ver: tuple[str, int] | list [str]
    :return: 输出的版本，如`"0.1.0"`
    :rtype: str
    """

    result = ""
    if type(ver) == tuple:
        ver = list(ver)
    elif type(ver) == list:
        pass
    else:
        raise TypeError(f"版本转换为字符串支持tuple或list类型，但您输入的是{type(ver).__name__}类型！")
    for i in range(0, len(ver)):
        result += str(ver[i])
        if not i == len(ver) - 1:
            result += "."
    return result

def compareUpdate(ver1: list[int], ver2: list[int]) -> bool:
    """
    输入两个版本列表，返回是否需要更新。
    
    :param ver1: 当前版本
    :type ver1: list[int]
    :param ver2: 对比版本
    :type ver2: list[int]
    :return: 是否需要更新
    :rtype: bool
    """

    for i1, i2 in zip(ver1, ver2):
        if i1 < i2:
            return True
    return False

def getPythonVersion() -> list[int]:
    """
    获取运行HDpip的Python的版本。
    
    :return: 版本列表
    :rtype: list[int]
    """

    return switchVersionToList(platform.python_version_tuple())

def getPipVersion() -> list[int]:
    """
    获取运行HDpip的Python所对应的pip的版本。
    
    :return: 版本列表
    :rtype: list[int]
    """

    return switchVersionToList(pip.__version__)

def openInExplorer(path: str | pathlib.Path) -> None:
    """
    在文件资源管理器中打开一个文件夹或文件（Windows下选中，Linux或MacOS下打开父文件夹。）。
    
    :param path: 要打开的文件夹
    :type path: str | pathlib.Path
    """

    path = pathlib.Path(path).resolve()
    system = platform.system()
    if system != "Windows" and path.is_file():
        path = path.parent.resolve()
    
    try:
        if system == "Windows":
            if path.is_file():
                os.system(f"explorer /select, \"{path}\"")
            else:
                os.startfile(path)
        elif system == "Linux":
            os.system(f"xdg-open \"{path}\"")
        elif system == "Darwin":
            os.system(f"open \"{path}\"")
        else:
            raise HDpipError(f"不支持的系统：{system}！")
    except Exception as error:
        raise HDpipError(f"打开\"{path}\"失败！\n错误如下：\n{error}")

def shell(command: str, realtime: bool = True, callback = print) -> subprocess.Popen:
    """
    使用系统shell运行一条指令，每输出一行，如果启用实时模式，运行以更新行为输入的回调函数，并返回管道。

    **注意，*禁止运行交互式命令！***

    例如：
    ```
    with open("result.txt", "a", encoding = "utf-8") as file:
        print(HDpip.core.base.shell(
            "ping 127.0.0.1", 
            lambda line: file.write(f"{line}\n")
        ).returncode)
    ```
    
    :param command: 命令
    :type command: str
    :param realtime: 实时模式
    :type realtime: bool
    :param callback: 回调函数
    :return: 管道
    :rtype: subprocess.Popen
    """
    
    popen = subprocess.Popen(
        command, 
        stdout = subprocess.PIPE, 
        universal_newlines = realtime
    )
    if realtime:
        for line in popen.stdout:
            callback(line.strip())
    popen.wait()
    return popen

def shellDecode(raw: str | bytes) -> str:
    """
    对`HDpip.core.base.shell`的输出进行解码。
    
    :param raw: 原始数据
    :type raw: str | bytes
    :return: 解码结果
    :rtype: str
    """

    return bytes(raw).decode("cp936")

def repeatedSpilt(string: str, spilt_symbol: list[str]) -> list[str]:
    if len(spilt_symbol) == 0:
        HDpipError("分隔符列表不能为空！")
    elif len(spilt_symbol) > 1:
        for i in range(1, len(spilt_symbol)):
            string = string.replace(spilt_symbol[i], spilt_symbol[0])
    return string.split(spilt_symbol[0])

def isDev() -> bool:
    return (pathlib.Path(f"{getBaseDir}").parent / "dev").resolve().is_file()