# Agentic Cortex

Local-first agentic memory architecture for coding agents.

[![PyPI version](https://badge.fury.io/py/agentic-cortex.svg)](https://badge.fury.io/py/agentic-cortex)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Overview

Cortex eliminates token churn by replacing full-codebase context dumps with a deterministic, multi-tiered retrieval system:

- **Tier 1 (SQLite)**: Structural map of symbols, files, and hierarchy
- **Tier 2 (SQLite)**: Relationship graph for dependency traversal
- **Tier 3 (LanceDB)**: Semantic memory store with vector embeddings

## Installation

This project uses [uv](https://github.com/astral-sh/uv) for package management.

**Important**: PyTorch is not included in the main dependencies to allow flexible installation (CPU-only, CUDA, or ROCm). Install PyTorch separately based on your system.

### AMD GPU Installation (Recommended for AMD Systems)

For AMD GPUs with ROCm support, install ROCm PyTorch for GPU acceleration:

**Option 1: Using the helper script (recommended)**
```bash
# First, create the environment and install dependencies
uv sync

# Then install ROCm PyTorch (this will override any CUDA torch)
./install_rocm.sh
```

**Option 2: Manual installation**
```bash
# First, sync all dependencies
uv sync

# Then install ROCm PyTorch (auto-detects your ROCm version)
# For ROCm 7.x, use rocm6.2 (latest available PyTorch wheels)
uv pip install --index-url https://download.pytorch.org/whl/rocm6.2 torch
```

**Important Notes**:
- PyTorch ROCm wheels are available for `rocm6.0`, `rocm6.1`, `rocm6.2`. ROCm 7.x systems should use `rocm6.2` wheels (backward compatible).
- The lock file contains CUDA PyTorch by default. After running `uv sync`, you'll need to reinstall ROCm PyTorch using the script or manual command above.
- **Note**: `uv run` may reinstall CUDA torch from the lock file. After installing ROCm PyTorch, use `.venv/bin/python` directly or re-run the install script if needed.
- To verify ROCm is working: `.venv/bin/python -c "import torch; print(torch.version.hip)"` should show a HIP version string (not None).

### CPU-Only Installation

For systems without GPU support or if you prefer CPU-only:

```bash
# Install CPU-only PyTorch first
uv pip install --index-url https://download.pytorch.org/whl/cpu torch

# Then install the rest of the dependencies
uv sync
```

### Standard Installation (NVIDIA CUDA)

For systems with NVIDIA GPUs:

```bash
uv sync
```

**Important**: The default PyTorch installation on Linux includes CUDA dependencies which won't work on AMD systems. AMD users should use either ROCm (for GPU) or CPU-only installation above.

## Installation

Install from PyPI:

```bash
pip install agentic-cortex
```

Or with uv:

```bash
uv pip install agentic-cortex
```

For development:

```bash
git clone https://github.com/noematicsllc/memory_layer.git
cd memory_layer
uv sync
```

## Quickstart

Initialize Cortex in your project:

```bash
cd my-repo
cortex init
```

Start the Cortex MCP server:

```bash
cortex start
```

## MCP Configuration

Add Cortex to your MCP client configuration (e.g., `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "cortex": {
      "command": "cortex",
      "args": ["start"]
    }
  }
}
```

## Development

Run the MCP server directly:

```bash
uv run python -m cortex.cli start
```

## Architecture

See the implementation plan for detailed architecture documentation.
