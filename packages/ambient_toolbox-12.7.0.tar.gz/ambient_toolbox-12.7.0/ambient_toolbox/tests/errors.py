class TestSetupConfigurationError(RuntimeError):
    pass
