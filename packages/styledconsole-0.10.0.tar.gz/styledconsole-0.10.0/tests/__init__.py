"""Test suite for StyledConsole."""
