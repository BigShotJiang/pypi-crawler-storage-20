"""Package version."""

VERSION = "2.6.2"
