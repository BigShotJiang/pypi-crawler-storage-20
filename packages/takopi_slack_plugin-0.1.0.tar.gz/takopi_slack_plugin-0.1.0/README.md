# takopi-slack-plugin

slack transport plugin for takopi. socket mode only, replies in threads, and
stores per-thread context + resume tokens.

## features

- socket mode only; listens in a single channel or dm
- thread sessions (context + resume tokens) stored at
  `~/.takopi/slack_thread_sessions_state.json`
- slash commands + message shortcuts for overrides and plugin commands
- cancel button on progress messages
- message overflow: split or trim long responses

## requirements

- python 3.14+
- takopi >=0.20.0
- slack bot token with `chat:write`, `commands`, `app_mentions:read`, and
  the matching history scopes for your channel type (`channels:history`,
  `groups:history`, `im:history`, `mpim:history`)
- slack app token (`xapp-`) with `connections:write`

## install

install into the same python environment as takopi.

```sh
uv tool install -U takopi --with takopi-slack-plugin
```

or, with a virtualenv:

```sh
pip install takopi-slack-plugin
```

## setup

create a slack app and enable socket mode.

1. create an app-level token with `connections:write`
2. add the bot scopes listed above and install the app
3. enable events for `app_mention` plus the right `message.*` event for your
   channel type
4. enable interactivity & shortcuts, create a slash command (for example
   `/takopi`), and optionally add a message shortcut with callback id
   `takopi:<plugin_id>`
5. invite the bot to the target channel

add to `~/.takopi/takopi.toml`:

```toml
transport = "slack"

[transports.slack]
bot_token = "xoxb-..."
app_token = "xapp-..."
channel_id = "C12345678"
message_overflow = "split"
```

set `message_overflow = "trim"` if you prefer truncation instead of followups.

if you use a plugin allowlist, enable this distribution:

```toml
[plugins]
enabled = ["takopi-slack-plugin"]
```

## usage

```sh
takopi --transport slack
```

if you already set `transport = "slack"`, `takopi` is enough.

root messages must include both a project and worktree directive in the first
line. messages that do not match are ignored.

example:

```
@takopi /zkp2p-clients @feat/web/monad-usdt0 add a retry to the api call
```

thread replies reuse stored context, so you can reply without repeating
directives.

slash command built-ins:

```
/takopi status
/takopi engine <engine|clear>
/takopi model <engine> <model|clear>
/takopi reasoning <engine> <level|clear>
/takopi session clear
```

message shortcuts pass the selected message text as arguments to the plugin
command identified by `takopi:<plugin_id>`.

progress messages include a cancel button; enable interactivity & shortcuts so
clicks are delivered in socket mode.

## license

mit
