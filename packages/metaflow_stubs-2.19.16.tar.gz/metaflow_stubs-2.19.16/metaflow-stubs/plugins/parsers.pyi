######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.16                                                                                #
# Generated on 2026-01-13T22:32:39.357780                                                            #
######################################################################################################

from __future__ import annotations


from .._vendor import yaml as yaml

def yaml_parser(content: str) -> dict:
    """
    Parse YAML content to a dictionary.
    
    Parameters
    ----------
    content : str
    
    Returns
    -------
    dict
    """
    ...

