######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.16                                                                                #
# Generated on 2026-01-13T22:32:39.401558                                                            #
######################################################################################################

from __future__ import annotations


from . import aws_secrets_manager_secrets_provider as aws_secrets_manager_secrets_provider

