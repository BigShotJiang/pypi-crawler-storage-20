######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.16                                                                                #
# Generated on 2026-01-13T22:32:39.388495                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

