######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.16                                                                                #
# Generated on 2026-01-13T22:32:39.413592                                                            #
######################################################################################################

from __future__ import annotations


from . import base_sensor as base_sensor
from . import external_task_sensor as external_task_sensor
from .external_task_sensor import ExternalTaskSensorDecorator as ExternalTaskSensorDecorator
from . import s3_sensor as s3_sensor
from .s3_sensor import S3KeySensorDecorator as S3KeySensorDecorator

SUPPORTED_SENSORS: list

