######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.16                                                                                #
# Generated on 2026-01-13T22:32:39.378749                                                            #
######################################################################################################

from __future__ import annotations



def copy_tree(src, dst, update = False):
    ...

def sync_local_metadata_to_datastore(metadata_local_dir, task_ds):
    ...

def sync_local_metadata_from_datastore(metadata_local_dir, task_ds):
    ...

