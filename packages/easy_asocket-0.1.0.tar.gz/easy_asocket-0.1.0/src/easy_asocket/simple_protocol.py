"""
SimpleProtocol - Application layer transmission protocol implementation in Python

Protocol structure: [Header(2)][Direction(1)][MessageID(2)][Length(4)][CMD(2)][Data(N)][CRC16(2)][Footer(2)]
"""

import struct
from typing import Tuple, List


class SimpleProtocol:
    """SimpleProtocol implementation with CRC16 checksum"""
    
    # Protocol fixed header and footer
    HEADER_BYTE1 = 0xAA
    HEADER_BYTE2 = 0x55
    FOOTER_BYTE1 = 0x55
    FOOTER_BYTE2 = 0xAA
    
    # Direction byte values
    DIRECTION_REQUEST = 0x00   # 发起消息/主动方
    DIRECTION_RESPONSE = 0x01  # 回复消息/被动方
    
    # Protocol structure sizes
    HEADER_SIZE = 2
    DIRECTION_SIZE = 1  # uint8_t
    MESSAGE_ID_SIZE = 2  # uint16_t
    LENGTH_SIZE = 4  # uint32_t
    CMD_SIZE = 2      # uint16_t
    CRC16_SIZE = 2    # uint16_t
    FOOTER_SIZE = 2
    MIN_PACKET_SIZE = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + CRC16_SIZE + FOOTER_SIZE
    
    def __init__(self):
        """Initialize SimpleProtocol instance"""
        self._msg_id = 0
        self._cmd = 0x00
        self._direction = self.DIRECTION_REQUEST
        self._data = bytearray()
    
    def encode(self) -> bytes:
        """
        Encode protocol data into byte array
        
        Returns:
            Encoded protocol packet (bytes)
        """
        data_len = len(self._data)
        
        # Calculate total length: Header(2) + Direction(1) + MessageID(2) + Length(4) + CMD(2) + Data(N) + CRC16(2) + Footer(2)
        total_size = self.HEADER_SIZE + self.DIRECTION_SIZE + self.MESSAGE_ID_SIZE + self.LENGTH_SIZE + self.CMD_SIZE + data_len + self.CRC16_SIZE + self.FOOTER_SIZE
        packet = bytearray(total_size)
        
        offset = 0
        
        # Write Header
        packet[offset] = self.HEADER_BYTE1
        packet[offset + 1] = self.HEADER_BYTE2
        offset += self.HEADER_SIZE
        
        # Write Direction
        packet[offset] = self._direction
        offset += self.DIRECTION_SIZE
        
        # Write MessageID
        SimpleProtocol.uint16_to_bytes(self._msg_id, packet, offset)
        offset += self.MESSAGE_ID_SIZE
        
        # Write Length (data part length, excluding Header, Direction, MessageID, Length, CMD, CRC16, Footer)
        SimpleProtocol.uint32_to_bytes(data_len, packet, offset)
        offset += self.LENGTH_SIZE
        
        # Write CMD
        SimpleProtocol.uint16_to_bytes(self._cmd, packet, offset)
        offset += self.CMD_SIZE
        
        # Write Data
        if data_len > 0:
            packet[offset:offset + data_len] = self._data
            offset += data_len
        
        # Calculate CRC16 for Direction + MessageID + Length + CMD + Data
        crc_data_start = self.HEADER_SIZE
        crc_data_len = self.DIRECTION_SIZE + self.MESSAGE_ID_SIZE + self.LENGTH_SIZE + self.CMD_SIZE + data_len
        crc16 = SimpleProtocol.calculate_crc16(packet[crc_data_start:crc_data_start + crc_data_len])
        
        # Write CRC16
        SimpleProtocol.uint16_to_bytes(crc16, packet, offset)
        offset += self.CRC16_SIZE
        
        # Write Footer
        packet[offset] = self.FOOTER_BYTE1
        packet[offset + 1] = self.FOOTER_BYTE2
        
        return bytes(packet)
    
    @staticmethod
    def decode(bytearray_data: bytes) -> Tuple[bool, 'SimpleProtocol']:
        """
        Decode protocol data from byte array
        
        Args:
            bytearray_data: Protocol packet (bytes)
            
        Returns:
            Tuple of (success, SimpleProtocol instance)
        """
        p = SimpleProtocol()
        if not SimpleProtocol.validate(bytearray_data):
            return (False, p)
        
        p._direction = bytearray_data[SimpleProtocol.HEADER_SIZE]
        p._msg_id = SimpleProtocol.bytes_to_uint16(bytearray_data[SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE:])
        length = SimpleProtocol.bytes_to_uint32(bytearray_data[SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE:])
        p._cmd = SimpleProtocol.bytes_to_uint16(bytearray_data[SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE:])
        p._data = bytearray(bytearray_data[SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE:SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + length])
        return (True, p)
    
    @staticmethod
    def validate(bytearray_data: bytes) -> bool:
        """
        Validate protocol packet
        
        Args:
            bytearray_data: Protocol packet (bytes)
            
        Returns:
            True if packet is valid, False otherwise
        """
        # Check minimum length
        if len(bytearray_data) < SimpleProtocol.MIN_PACKET_SIZE:
            return False
        
        # Check Header
        if bytearray_data[0] != SimpleProtocol.HEADER_BYTE1 or bytearray_data[1] != SimpleProtocol.HEADER_BYTE2:
            return False
        
        # Read Length and validate
        data_len = SimpleProtocol.bytes_to_uint32(bytearray_data[SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE:])
        expected_size = SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + data_len + SimpleProtocol.CRC16_SIZE + SimpleProtocol.FOOTER_SIZE
        
        if len(bytearray_data) != expected_size:
            return False
        
        # Verify CRC16
        # CRC16 covers: Direction + MessageID + Length + CMD + Data
        crc_data_start = SimpleProtocol.HEADER_SIZE
        crc_data_len = SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + data_len
        calculated_crc = SimpleProtocol.calculate_crc16(bytearray_data[crc_data_start:crc_data_start + crc_data_len])
        
        # Read stored CRC16
        crc_offset = SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + data_len
        stored_crc = SimpleProtocol.bytes_to_uint16(bytearray_data[crc_offset:])
        
        if calculated_crc != stored_crc:
            return False
        
        # Check Footer
        footer_offset = len(bytearray_data) - SimpleProtocol.FOOTER_SIZE
        if bytearray_data[footer_offset] != SimpleProtocol.FOOTER_BYTE1 or bytearray_data[footer_offset + 1] != SimpleProtocol.FOOTER_BYTE2:
            return False
        
        return True
    
    @staticmethod
    def validate_two_regions(ptr1: bytes, ptr2: bytes = None) -> bool:
        """
        Validate protocol packet split across two memory regions
        
        Args:
            ptr1: First memory region (bytes)
            ptr2: Second memory region (bytes, optional)
            
        Returns:
            True if packet is valid, False otherwise
        """
        len1 = len(ptr1)
        len2 = len(ptr2) if ptr2 is not None else 0
        total_length = len1 + len2
        
        # Helper function to read byte at offset
        def read_byte(offset: int) -> int:
            if offset < len1:
                return ptr1[offset]
            else:
                if ptr2 is None or len2 == 0:
                    return 0
                return ptr2[offset - len1]
        
        # Helper function to read uint16 at offset
        def read_uint16(offset: int) -> int:
            bytes_data = bytes([read_byte(offset + i) for i in range(2)])
            return SimpleProtocol.bytes_to_uint16(bytes_data)
        
        # Helper function to read uint32 at offset
        def read_uint32(offset: int) -> int:
            bytes_data = bytes([read_byte(offset + i) for i in range(4)])
            return SimpleProtocol.bytes_to_uint32(bytes_data)
        
        # Helper function to calculate CRC16 for two regions
        def calculate_crc16_two_regions(start_offset: int, total_len: int) -> int:
            crc = 0xFFFF
            table = SimpleProtocol.get_crc16_table()
            
            for i in range(total_len):
                byte_val = read_byte(start_offset + i)
                crc = ((crc << 8) ^ table[((crc >> 8) ^ byte_val) & 0xFF]) & 0xFFFF
            
            return crc
        
        # Check minimum length
        if total_length < SimpleProtocol.MIN_PACKET_SIZE:
            return False
        
        # Check Header
        if read_byte(0) != SimpleProtocol.HEADER_BYTE1 or read_byte(1) != SimpleProtocol.HEADER_BYTE2:
            return False
        
        # Read Length and validate
        length_field_offset = SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE
        data_len = read_uint32(length_field_offset)
        expected_size = SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + data_len + SimpleProtocol.CRC16_SIZE + SimpleProtocol.FOOTER_SIZE
        
        if total_length != expected_size:
            return False
        
        # Verify CRC16
        # CRC16 covers: Direction + MessageID + Length + CMD + Data
        crc_data_start = SimpleProtocol.HEADER_SIZE
        crc_data_len = SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + data_len
        calculated_crc = calculate_crc16_two_regions(crc_data_start, crc_data_len)
        
        # Read stored CRC16
        crc_offset = SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE + SimpleProtocol.CMD_SIZE + data_len
        stored_crc = read_uint16(crc_offset)
        
        if calculated_crc != stored_crc:
            return False
        
        # Check Footer
        footer_offset = total_length - SimpleProtocol.FOOTER_SIZE
        if read_byte(footer_offset) != SimpleProtocol.FOOTER_BYTE1 or read_byte(footer_offset + 1) != SimpleProtocol.FOOTER_BYTE2:
            return False
        
        return True
    
    def set_cmd(self, cmd: int) -> None:
        """Set command"""
        self._cmd = cmd
    
    def set_msgid(self, msg_id: int) -> None:
        """Set message ID"""
        self._msg_id = msg_id
    
    def set_direction(self, direction: int) -> None:
        """Set direction"""
        self._direction = direction
    
    def set_data(self, data) -> None:
        """
        Set data
        
        Args:
            data: Data content (bytes, bytearray, or list of int)
        """
        if isinstance(data, list):
            self._data = bytearray(data)
        elif isinstance(data, bytes):
            self._data = bytearray(data)
        elif isinstance(data, bytearray):
            self._data = data
        else:
            raise TypeError("data must be bytes, bytearray, or list of int")
    
    def get_cmd(self) -> int:
        """Get command"""
        return self._cmd
    
    def get_msgid(self) -> int:
        """Get message ID"""
        return self._msg_id
    
    def get_direction(self) -> int:
        """Get direction"""
        return self._direction
    
    def get_data(self) -> bytearray:
        """Get data reference"""
        return self._data
    
    def get_data_copy(self) -> bytes:
        """Get data copy"""
        return bytes(self._data)
    
    # Utility functions for byte conversion
    @staticmethod
    def bytes_to_uint16(bytes_data: bytes) -> int:
        """Convert 2 bytes to uint16 (big-endian)"""
        if len(bytes_data) < 2:
            return 0
        return struct.unpack_from('>H', bytes_data, 0)[0]
    
    @staticmethod
    def bytes_to_uint32(bytes_data: bytes) -> int:
        """Convert 4 bytes to uint32 (big-endian)"""
        if len(bytes_data) < 4:
            return 0
        return struct.unpack_from('>I', bytes_data, 0)[0]
    
    @staticmethod
    def uint16_to_bytes(value: int, buffer: bytearray, offset: int) -> None:
        """Convert uint16 to 2 bytes (big-endian) and write to buffer"""
        struct.pack_into('>H', buffer, offset, value & 0xFFFF)
    
    @staticmethod
    def uint32_to_bytes(value: int, buffer: bytearray, offset: int) -> None:
        """Convert uint32 to 4 bytes (big-endian) and write to buffer"""
        struct.pack_into('>I', buffer, offset, value & 0xFFFFFFFF)
    
    @staticmethod
    def get_crc16_table() -> List[int]:
        """Get CRC16 lookup table"""
        return SimpleProtocol._crc16_table
    
    @staticmethod
    def calculate_crc16(data: bytes) -> int:
        """
        Calculate CRC16-CCITT checksum using lookup table
        
        Args:
            data: Data to calculate CRC16 for (bytes)
            
        Returns:
            CRC16 checksum value (uint16)
        """
        crc = 0xFFFF
        table = SimpleProtocol.get_crc16_table()
        
        for byte_val in data:
            crc = ((crc << 8) ^ table[((crc >> 8) ^ byte_val) & 0xFF]) & 0xFFFF
        
        return crc
    
    @staticmethod
    def _generate_crc16_table() -> List[int]:
        """
        Generate CRC16-CCITT lookup table
        
        Returns:
            CRC16 lookup table (256 elements)
        """
        table = []
        polynomial = 0x1021
        
        for i in range(256):
            crc = i << 8
            for _ in range(8):
                if crc & 0x8000:
                    crc = (crc << 1) ^ polynomial
                else:
                    crc <<= 1
                crc &= 0xFFFF
            table.append(crc)
        
        return table
    
    # CRC16 lookup table (generated once at class definition time)
    _crc16_table = _generate_crc16_table()
