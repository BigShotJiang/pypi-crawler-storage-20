from .simple_protocol import SimpleProtocol
from .easysocket import SocketClient, SocketServer, set_terminal_verbose, get_terminal_verbose, ClientSession
import os

def cppdir():
    file_dir = os.path.abspath(os.path.dirname(__file__))
    path = os.path.abspath(os.path.join(file_dir,"data/cpp"))
    path = path.replace("\\","/")
    print(path)

__all__ = [
    "SimpleProtocol",
    "SocketClient",
    "SocketServer",
    "set_terminal_verbose",
    "get_terminal_verbose",
    "ClientSession",
    "cppdir"
]
