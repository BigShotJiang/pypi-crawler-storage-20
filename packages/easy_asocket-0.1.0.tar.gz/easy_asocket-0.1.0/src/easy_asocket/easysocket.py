import asyncio
import time
from collections import deque
from typing import Optional, Callable, Tuple
from .simple_protocol import SimpleProtocol

# Verbose control
_terminal_verbose = True

def set_terminal_verbose(enabled: bool):
    """Set terminal verbose output."""
    global _terminal_verbose
    _terminal_verbose = enabled

def get_terminal_verbose() -> bool:
    """Get terminal verbose output status."""
    return _terminal_verbose


class IDPool:
    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self.borrowed = []
        self.failed_map = {}  # id -> timestamp
        self.failed_timeout = 10.0  # 10 seconds (in seconds for Python)
    
    def get_id(self) -> Tuple[bool, int]:
        """
        Get an available ID from the pool.
        
        Returns:
            Tuple of (success, id). If success is False, id is 0.
        """
        self.release_failed_id()
        if len(self.borrowed) >= self.max_size:
            return (False, 0)
        
        for i in range(self.max_size):
            if i not in self.borrowed:
                self.borrowed.append(i)
                return (True, i)
        
        return (False, 0)
    
    def return_id(self, id: int):
        """Return an ID to the pool."""
        if id in self.borrowed:
            self.borrowed.remove(id)
    
    def failed_id(self, id: int):
        """Mark an ID as failed and record the timestamp."""
        self.failed_map[id] = time.monotonic()
    
    def release_failed_id(self):
        """Release failed IDs that have exceeded the timeout."""
        current_time = time.monotonic()
        expired_ids = []
        for id, timestamp in self.failed_map.items():
            if current_time - timestamp > self.failed_timeout:
                expired_ids.append(id)
        
        for id in expired_ids:
            self.return_id(id)
            del self.failed_map[id]
    
    def is_borrowed(self, id: int) -> bool:
        """Check if an ID is currently borrowed."""
        return id in self.borrowed


class SocketClient:
    def __init__(self, host: str, port: int):
        """
        Initialize SocketClient.
        
        Args:
            host: Server host address
            port: Server port number
        """
        self.host = host
        self.port = port
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None
        self.id_pool = IDPool()
        self.request_map = {}  # msg_id -> asyncio.Future
        self.request_callback: Optional[Callable[[SimpleProtocol], None]] = None
        
        # Buffer for received data
        self.pkg_buff = deque(maxlen=4 * 1024 * 1024)  # 4MB circular buffer
        self.recv_buff_size = 1024
        
        # Connection status
        self._connected = False
        self._read_task: Optional[asyncio.Task] = None
    
    async def connect(self):
        """Connect to the server."""
        try:
            self.reader, self.writer = await asyncio.open_connection(self.host, self.port)
            self._connected = True
            if _terminal_verbose:
                print("Connect success")
            # Start reading task
            self._read_task = asyncio.create_task(self._async_read_loop())
        except Exception as e:
            self._connected = False
            if _terminal_verbose:
                print(f"Connect failed: {e}")
            raise
    
    async def _async_read_loop(self):
        """Async read loop to continuously read data from socket."""
        try:
            while self._connected and self.reader is not None:
                try:
                    data = await self.reader.read(self.recv_buff_size)
                    if not data:
                        # Connection closed
                        if _terminal_verbose:
                            print("Connection closed by peer")
                        break
                    
                    # Add data to circular buffer
                    for byte_val in data:
                        self.pkg_buff.append(byte_val)
                    
                    # Process packages
                    await self._process_pkg()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    if _terminal_verbose:
                        print(f"Read error: {e}")
                    break
        except Exception as e:
            if _terminal_verbose:
                print(f"Read loop error: {e}")
        finally:
            self._connected = False
    
    async def _process_pkg(self):
        """Process received packages from buffer."""
        # Process packets continuously until no more complete packets are found
        while True:
            # If buffer is smaller than minimum packet size, return
            if len(self.pkg_buff) < SimpleProtocol.MIN_PACKET_SIZE:
                return
            
            # Convert deque to list for easier indexing (but keep it as deque for efficient popleft)
            buff_list = list(self.pkg_buff)
            
            # Find packet header
            found_packet = False
            i = 0
            while i < len(buff_list):
                # Look for header 0xAA 0x55
                if buff_list[i] == SimpleProtocol.HEADER_BYTE1:
                    if i + 1 < len(buff_list) and buff_list[i + 1] == SimpleProtocol.HEADER_BYTE2:
                        # Found header, check if we have enough bytes to read Length field
                        offset_from_header = i
                        length_field_offset = offset_from_header + SimpleProtocol.HEADER_SIZE + \
                                             SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE
                        
                        if len(buff_list) < length_field_offset + SimpleProtocol.LENGTH_SIZE:
                            break  # Not enough data yet
                        
                        # Read length field
                        length_bytes = bytes(buff_list[length_field_offset:length_field_offset + SimpleProtocol.LENGTH_SIZE])
                        data_len = SimpleProtocol.bytes_to_uint32(length_bytes)
                        
                        # Calculate total packet size
                        total_pkg_size = (SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE +
                                         SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE +
                                         SimpleProtocol.CMD_SIZE + data_len + SimpleProtocol.CRC16_SIZE +
                                         SimpleProtocol.FOOTER_SIZE)
                        
                        if len(buff_list) < offset_from_header + total_pkg_size:
                            break  # Not enough data yet
                        
                        # Extract packet bytes
                        pkg_bytes = bytes(buff_list[offset_from_header:offset_from_header + total_pkg_size])
                        
                        # Validate packet
                        if SimpleProtocol.validate(pkg_bytes):
                            # Decode packet
                            success, pkg = SimpleProtocol.decode(pkg_bytes)
                            if success:
                                if pkg.get_direction() == SimpleProtocol.DIRECTION_RESPONSE:
                                    # Handle response
                                    msg_id = pkg.get_msgid()
                                    if msg_id in self.request_map:
                                        future = self.request_map[msg_id]
                                        if not future.done():
                                            future.set_result(pkg)
                                    else:
                                        if _terminal_verbose:
                                            print(f"Request not found: {msg_id}")
                                else:
                                    # Handle request (server sends request to client)
                                    if self.request_callback is not None:
                                        self.request_callback(pkg)
                                
                                # Remove processed packet from buffer
                                # Remove bytes before header
                                for _ in range(offset_from_header):
                                    if self.pkg_buff:
                                        self.pkg_buff.popleft()
                                # Remove packet itself
                                for _ in range(total_pkg_size):
                                    if self.pkg_buff:
                                        self.pkg_buff.popleft()
                                
                                found_packet = True
                                break  # Restart from beginning to process next packet
                            else:
                                # Decode failed, skip one byte
                                if _terminal_verbose:
                                    print("Process pkg failed: decode failed")
                                if self.pkg_buff:
                                    self.pkg_buff.popleft()
                                found_packet = True  # Continue processing
                                break
                        else:
                            # Validation failed, skip one byte
                            if _terminal_verbose:
                                print("Process pkg failed: validation failed")
                            if self.pkg_buff:
                                self.pkg_buff.popleft()
                            found_packet = True  # Continue processing
                            break
                
                i += 1
            
            # If no packet was found or processed, exit loop
            if not found_packet:
                # If buffer is getting large, remove invalid data
                if len(self.pkg_buff) > SimpleProtocol.MIN_PACKET_SIZE * 10:
                    # Remove bytes until we find a valid header or buffer is small enough
                    removed = 0
                    while len(self.pkg_buff) > SimpleProtocol.MIN_PACKET_SIZE and removed < 100:
                        if self.pkg_buff and self.pkg_buff[0] != SimpleProtocol.HEADER_BYTE1:
                            self.pkg_buff.popleft()
                            removed += 1
                        else:
                            break
                break
    
    async def request(self, data: SimpleProtocol, expect_response: bool = False, timeout: float = 5.0) -> Tuple[bool, SimpleProtocol]:
        """
        Send a request.
        
        Args:
            data: SimpleProtocol instance with data to send
            expect_response: Whether to wait for response
            timeout: Timeout in seconds (default: 5.0)
        
        Returns:
            Tuple of (success, SimpleProtocol). success is True if response received successfully,
            False if ID pool is full, expect_response is False, timeout, or other errors.
        """
        if not self._connected or self.writer is None:
            raise RuntimeError("Not connected")
        
        # Get ID from pool
        success, msg_id = self.id_pool.get_id()
        if not success:
            if _terminal_verbose:
                print("ID pool is full")
            return (False, SimpleProtocol())
        
        # Set message ID and direction
        data.set_msgid(msg_id)
        data.set_direction(SimpleProtocol.DIRECTION_REQUEST)
        
        if not expect_response:
            # Just send, don't wait for response
            try:
                encoded_data = data.encode()
                self.writer.write(encoded_data)
                await self.writer.drain()
                if _terminal_verbose:
                    print(f"Write success: {len(encoded_data)} bytes")
            except Exception as e:
                if _terminal_verbose:
                    print(f"Write failed: {e}")
                self.id_pool.return_id(msg_id)
                raise
            self.id_pool.return_id(msg_id)
            return (False, SimpleProtocol())
        
        # Create future for response
        future = asyncio.Future()
        self.request_map[msg_id] = future
        
        # Send request
        try:
            encoded_data = data.encode()
            self.writer.write(encoded_data)
            await self.writer.drain()
            if _terminal_verbose:
                print(f"Write success: {len(encoded_data)} bytes")
        except Exception as e:
            if _terminal_verbose:
                print(f"Write failed: {e}")
            if msg_id in self.request_map:
                del self.request_map[msg_id]
            self.id_pool.return_id(msg_id)
            raise
        
        try:
            # Wait for response with timeout
            response = await asyncio.wait_for(future, timeout=timeout)
            # Clean up on success
            if msg_id in self.request_map:
                del self.request_map[msg_id]
            self.id_pool.return_id(msg_id)
            return (True, response)
        except asyncio.TimeoutError:
            # Timeout, mark as failed
            if msg_id in self.request_map:
                del self.request_map[msg_id]
            self.id_pool.failed_id(msg_id)
            return (False, SimpleProtocol())
    
    async def response(self, data: SimpleProtocol):
        """
        Send a response.
        
        Args:
            data: SimpleProtocol instance with response data
        """
        if not self._connected or self.writer is None:
            raise RuntimeError("Not connected")
        
        data.set_direction(SimpleProtocol.DIRECTION_RESPONSE)
        try:
            encoded_data = data.encode()
            self.writer.write(encoded_data)
            await self.writer.drain()
            if _terminal_verbose:
                print(f"Write success: {len(encoded_data)} bytes")
        except Exception as e:
            if _terminal_verbose:
                print(f"Write failed: {e}")
            raise
    
    def set_request_callback(self, callback: Callable[[SimpleProtocol], None]):
        """
        Set callback function for incoming requests.
        
        Args:
            callback: Function that takes a SimpleProtocol instance as argument
        """
        self.request_callback = callback
    
    def is_connected(self) -> bool:
        """
        Check if the client is connected.
        
        Returns:
            True if connected, False otherwise
        """
        return self._connected and self.writer is not None and not self.writer.is_closing()
    
    async def close(self):
        """Close the connection."""
        self._connected = False
        
        if self._read_task is not None:
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass
        
        if self.writer is not None:
            self.writer.close()
            try:
                await self.writer.wait_closed()
            except Exception:
                pass
        
        self.reader = None
        self.writer = None


class SocketServer:
    def __init__(self, port: int):
        """
        Initialize SocketServer.
        
        Args:
            port: Server port number
        """
        self.port = port
        self.server: Optional[asyncio.Server] = None
        self.clients: dict[int, 'ClientSession'] = {}
        self.client_id_pool = IDPool()
        self._running = False
    
    async def start(self):
        """Start the server and begin accepting connections."""
        if self._running:
            return
        
        self.server = await asyncio.start_server(
            self._handle_client,
            '0.0.0.0',
            self.port
        )
        self._running = True
        if _terminal_verbose:
            print(f"Server started on port {self.port}")
        
        async with self.server:
            await self.server.serve_forever()
    
    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        """Handle a new client connection."""
        success, client_id = self.client_id_pool.get_id()
        if not success:
            if _terminal_verbose:
                print("Client ID pool is full, cannot accept new client")
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
            return
        
        session = ClientSession(reader, writer, client_id, self)
        self.clients[client_id] = session
        
        if _terminal_verbose:
            print(f"Client connected, ID: {client_id}")
        
        try:
            await session.start()
        except Exception as e:
            if _terminal_verbose:
                print(f"Client {client_id} error: {e}")
        finally:
            # Clean up when client disconnects
            if client_id in self.clients:
                del self.clients[client_id]
            self.client_id_pool.return_id(client_id)
            if _terminal_verbose:
                print(f"Client {client_id} disconnected")
    
    async def stop(self):
        """Stop the server and close all connections."""
        self._running = False
        
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        
        # Close all client connections and return IDs to pool
        for client_id, session in list(self.clients.items()):
            await session.close()
            self.client_id_pool.return_id(client_id)
        
        self.clients.clear()
        if _terminal_verbose:
            print("Server stopped")


class ClientSession:
    """Internal class to handle individual client sessions."""
    
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, 
                 client_id: int, server: SocketServer):
        """
        Initialize ClientSession.
        
        Args:
            reader: StreamReader for reading from client
            writer: StreamWriter for writing to client
            client_id: Unique ID for this client
            server: Reference to the SocketServer instance
        """
        self.reader = reader
        self.writer = writer
        self.client_id = client_id
        self.server = server
        self.id_pool = IDPool()
        self.request_map = {}  # msg_id -> asyncio.Future
        self.request_callback: Optional[Callable[[SimpleProtocol], None]] = None
        
        # Buffer for received data
        self.pkg_buff = deque(maxlen=4 * 1024 * 1024)  # 4MB circular buffer
        self.recv_buff_size = 1024
        
        # Connection status
        self._connected = True
        self._read_task: Optional[asyncio.Task] = None
    
    def get_client_id(self) -> int:
        """Get the client ID."""
        return self.client_id
    
    async def start(self):
        """Start reading from the client."""
        self._read_task = asyncio.create_task(self._async_read_loop())
        try:
            await self._read_task
        except asyncio.CancelledError:
            pass
    
    async def _async_read_loop(self):
        """Async read loop to continuously read data from socket."""
        try:
            while self._connected and self.reader is not None:
                try:
                    data = await self.reader.read(self.recv_buff_size)
                    if not data:
                        # Connection closed
                        if _terminal_verbose:
                            print(f"Client {self.client_id} disconnected")
                        break
                    
                    # Add data to circular buffer
                    for byte_val in data:
                        self.pkg_buff.append(byte_val)
                    
                    # Process packages
                    await self._process_pkg()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    if _terminal_verbose:
                        print(f"Read failed from client {self.client_id}: {e}")
                    break
        except Exception as e:
            if _terminal_verbose:
                print(f"Read loop error from client {self.client_id}: {e}")
        finally:
            self._connected = False
    
    async def _process_pkg(self):
        """Process received packages from buffer."""
        # Process packets continuously until no more complete packets are found
        while True:
            # If buffer is smaller than minimum packet size, return
            if len(self.pkg_buff) < SimpleProtocol.MIN_PACKET_SIZE:
                return
            
            # Convert deque to list for easier indexing
            buff_list = list(self.pkg_buff)
            
            # Find packet header
            found_packet = False
            i = 0
            while i < len(buff_list):
                # Look for header 0xAA 0x55
                if buff_list[i] == SimpleProtocol.HEADER_BYTE1:
                    if i + 1 < len(buff_list) and buff_list[i + 1] == SimpleProtocol.HEADER_BYTE2:
                        # Found header, check if we have enough bytes to read Length field
                        offset_from_header = i
                        length_field_offset = offset_from_header + SimpleProtocol.HEADER_SIZE + \
                                             SimpleProtocol.DIRECTION_SIZE + SimpleProtocol.MESSAGE_ID_SIZE
                        
                        if len(buff_list) < length_field_offset + SimpleProtocol.LENGTH_SIZE:
                            break  # Not enough data yet
                        
                        # Read length field
                        length_bytes = bytes(buff_list[length_field_offset:length_field_offset + SimpleProtocol.LENGTH_SIZE])
                        data_len = SimpleProtocol.bytes_to_uint32(length_bytes)
                        
                        # Calculate total packet size
                        total_pkg_size = (SimpleProtocol.HEADER_SIZE + SimpleProtocol.DIRECTION_SIZE +
                                         SimpleProtocol.MESSAGE_ID_SIZE + SimpleProtocol.LENGTH_SIZE +
                                         SimpleProtocol.CMD_SIZE + data_len + SimpleProtocol.CRC16_SIZE +
                                         SimpleProtocol.FOOTER_SIZE)
                        
                        if len(buff_list) < offset_from_header + total_pkg_size:
                            break  # Not enough data yet
                        
                        # Extract packet bytes
                        pkg_bytes = bytes(buff_list[offset_from_header:offset_from_header + total_pkg_size])
                        
                        # Validate packet
                        if SimpleProtocol.validate(pkg_bytes):
                            # Decode packet
                            success, pkg = SimpleProtocol.decode(pkg_bytes)
                            if success:
                                if pkg.get_direction() == SimpleProtocol.DIRECTION_REQUEST:
                                    # Handle request from client
                                    if self.request_callback is not None:
                                        self.request_callback(pkg)
                                else:
                                    # Handle response (if server also sends requests)
                                    msg_id = pkg.get_msgid()
                                    if msg_id in self.request_map:
                                        future = self.request_map[msg_id]
                                        if not future.done():
                                            future.set_result(pkg)
                                    else:
                                        if _terminal_verbose:
                                            print(f"Request not found for response: {msg_id} from client {self.client_id}")
                                
                                # Remove processed packet from buffer
                                # Remove bytes before header
                                for _ in range(offset_from_header):
                                    if self.pkg_buff:
                                        self.pkg_buff.popleft()
                                # Remove packet itself
                                for _ in range(total_pkg_size):
                                    if self.pkg_buff:
                                        self.pkg_buff.popleft()
                                
                                found_packet = True
                                break  # Restart from beginning to process next packet
                            else:
                                # Decode failed, skip one byte
                                if _terminal_verbose:
                                    print("Process pkg failed: decode failed")
                                if self.pkg_buff:
                                    self.pkg_buff.popleft()
                                found_packet = True  # Continue processing
                                break
                        else:
                            # Validation failed, skip one byte
                            if _terminal_verbose:
                                print("Process pkg failed: validation failed")
                            if self.pkg_buff:
                                self.pkg_buff.popleft()
                            found_packet = True  # Continue processing
                            break
                
                i += 1
            
            # If no packet was found or processed, exit loop
            if not found_packet:
                # If buffer is getting large, remove invalid data
                if len(self.pkg_buff) > SimpleProtocol.MIN_PACKET_SIZE * 10:
                    # Remove bytes until we find a valid header or buffer is small enough
                    removed = 0
                    while len(self.pkg_buff) > SimpleProtocol.MIN_PACKET_SIZE and removed < 100:
                        if self.pkg_buff and self.pkg_buff[0] != SimpleProtocol.HEADER_BYTE1:
                            self.pkg_buff.popleft()
                            removed += 1
                        else:
                            break
                break
    
    async def request(self, data: SimpleProtocol, expect_response: bool = False, timeout: float = 5.0) -> Tuple[bool, SimpleProtocol]:
        """
        Send a request.
        
        Args:
            data: SimpleProtocol instance with data to send
            expect_response: Whether to wait for response
            timeout: Timeout in seconds (default: 5.0)
        
        Returns:
            Tuple of (success, SimpleProtocol). success is True if response received successfully,
            False if ID pool is full, expect_response is False, timeout, or other errors.
        """
        if not self._connected or self.writer is None:
            raise RuntimeError("Not connected")
        
        # Get ID from pool
        success, msg_id = self.id_pool.get_id()
        if not success:
            if _terminal_verbose:
                print(f"ID pool is full for client {self.client_id}")
            return (False, SimpleProtocol())
        
        # Set message ID and direction
        data.set_msgid(msg_id)
        data.set_direction(SimpleProtocol.DIRECTION_REQUEST)
        
        if not expect_response:
            # Just send, don't wait for response
            try:
                encoded_data = data.encode()
                self.writer.write(encoded_data)
                await self.writer.drain()
                if _terminal_verbose:
                    print(f"Write success to client {self.client_id}: {len(encoded_data)} bytes")
            except Exception as e:
                if _terminal_verbose:
                    print(f"Write failed to client {self.client_id}: {e}")
                self.id_pool.return_id(msg_id)
                raise
            self.id_pool.return_id(msg_id)
            return (False, SimpleProtocol())
        
        # Create future for response
        future = asyncio.Future()
        self.request_map[msg_id] = future
        
        # Send request
        try:
            encoded_data = data.encode()
            self.writer.write(encoded_data)
            await self.writer.drain()
            if _terminal_verbose:
                print(f"Write success to client {self.client_id}: {len(encoded_data)} bytes")
        except Exception as e:
            if _terminal_verbose:
                print(f"Write failed to client {self.client_id}: {e}")
            if msg_id in self.request_map:
                del self.request_map[msg_id]
            self.id_pool.return_id(msg_id)
            raise
        
        try:
            # Wait for response with timeout
            response = await asyncio.wait_for(future, timeout=timeout)
            # Clean up on success
            if msg_id in self.request_map:
                del self.request_map[msg_id]
            self.id_pool.return_id(msg_id)
            return (True, response)
        except asyncio.TimeoutError:
            # Timeout, mark as failed
            if msg_id in self.request_map:
                del self.request_map[msg_id]
            self.id_pool.failed_id(msg_id)
            return (False, SimpleProtocol())
    
    async def response(self, data: SimpleProtocol):
        """
        Send a response to the client.
        
        Args:
            data: SimpleProtocol instance with response data
        """
        if not self._connected or self.writer is None:
            raise RuntimeError("Not connected")
        
        data.set_direction(SimpleProtocol.DIRECTION_RESPONSE)
        try:
            encoded_data = data.encode()
            self.writer.write(encoded_data)
            await self.writer.drain()
            if _terminal_verbose:
                print(f"Write success to client {self.client_id}: {len(encoded_data)} bytes")
        except Exception as e:
            if _terminal_verbose:
                print(f"Write failed to client {self.client_id}: {e}")
            raise
    
    def set_request_callback(self, callback: Callable[[SimpleProtocol], None]):
        """
        Set callback function for incoming requests.
        
        Args:
            callback: Function that takes a SimpleProtocol instance as argument
        """
        self.request_callback = callback
    
    def is_connected(self) -> bool:
        """
        Check if the session is connected.
        
        Returns:
            True if connected, False otherwise
        """
        return self._connected and self.writer is not None and not self.writer.is_closing()
    
    async def close(self):
        """Close the connection."""
        self._connected = False
        
        if self._read_task is not None:
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass
        
        if self.writer is not None:
            self.writer.close()
            try:
                await self.writer.wait_closed()
            except Exception:
                pass
        
        self.reader = None
        self.writer = None