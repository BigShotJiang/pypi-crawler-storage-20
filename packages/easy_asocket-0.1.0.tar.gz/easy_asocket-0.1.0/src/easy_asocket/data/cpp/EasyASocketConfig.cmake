# EasyASocketConfig.cmake
# Config file for EasyASocket library (Config mode)
# This is a header-only library
#
# This file can be used with find_package(EasyASocket CONFIG)

# Get the directory where this config file is located
get_filename_component(EasyASocket_CMAKE_DIR "${CMAKE_CURRENT_LIST_FILE}" PATH)

# Set include directories
set(EasyASocket_INCLUDE_DIRS "${EasyASocket_CMAKE_DIR}/../include")
if(NOT EXISTS "${EasyASocket_INCLUDE_DIRS}")
    set(EasyASocket_INCLUDE_DIRS "${EasyASocket_CMAKE_DIR}/include")
endif()

# Create interface library target (header-only)
if(NOT TARGET EasyASocket::EasyASocket)
    add_library(EasyASocket::EasyASocket INTERFACE IMPORTED)
    set_target_properties(EasyASocket::EasyASocket PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${EasyASocket_INCLUDE_DIRS}"
    )
endif()

# Set found variable
set(EasyASocket_FOUND TRUE)