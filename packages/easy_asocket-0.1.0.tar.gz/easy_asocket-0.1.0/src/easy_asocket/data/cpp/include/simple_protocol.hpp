#pragma once

#include <array>
#include <cstdint>
#include <cstring>
#include <vector>
namespace EasyASocket
{

void printHex(const std::vector<uint8_t> &data);
class SimpleProtocol
{
  public:
    // Protocol fixed header and footer
    static constexpr uint8_t HEADER_BYTE1 = 0xAA;
    static constexpr uint8_t HEADER_BYTE2 = 0x55;
    static constexpr uint8_t FOOTER_BYTE1 = 0x55;
    static constexpr uint8_t FOOTER_BYTE2 = 0xAA;

    // Direction byte values
    static constexpr uint8_t DIRECTION_REQUEST = 0x00;  // 发起消息/主动方
    static constexpr uint8_t DIRECTION_RESPONSE = 0x01; // 回复消息/被动方

    // Protocol structure: [Header(2)][Direction(1)][MessageID(2)][Length(4)][CMD(2)][Data(N)][CRC16(2)][Footer(2)]
    static constexpr size_t HEADER_SIZE = 2;
    static constexpr size_t DIRECTION_SIZE = 1;  // uint8_t
    static constexpr size_t MESSAGE_ID_SIZE = 2; // uint16_t
    static constexpr size_t LENGTH_SIZE = 4;     // uint32_t
    static constexpr size_t CMD_SIZE = 2;        // uint16_t
    static constexpr size_t CRC16_SIZE = 2;      // uint16_t
    static constexpr size_t FOOTER_SIZE = 2;
    static constexpr size_t MIN_PACKET_SIZE = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + CRC16_SIZE + FOOTER_SIZE;

    SimpleProtocol() = default;
    ~SimpleProtocol() = default;

    std::vector<uint8_t> encode();
    static std::tuple<bool, SimpleProtocol> decode(const std::vector<uint8_t> &bytearray);
    static bool validate(const std::vector<uint8_t> &bytearray);
    static bool validate(uint8_t *ptr1, size_t len1, uint8_t *ptr2, size_t len2);

    void set_cmd(uint16_t cmd);
    void set_msgid(uint16_t msg_id);
    void set_direction(uint8_t direction);
    void set_data(std::vector<uint8_t> data);
    void set_data(char *data, uint32_t length);

    uint16_t get_cmd();
    uint16_t get_msgid();
    uint8_t get_direction();
    std::vector<uint8_t> &get_data();
    std::vector<uint8_t> get_data_copy();

    // Utility functions for byte conversion
    static uint16_t bytesToUint16(const uint8_t *bytes);
    static uint32_t bytesToUint32(const uint8_t *bytes);
    static void uint16ToBytes(uint16_t value, uint8_t *bytes);
    static void uint32ToBytes(uint32_t value, uint8_t *bytes);
    static const std::array<uint16_t, 256> &getCRC16Table();
    static uint16_t calculateCRC16(const uint8_t *data, size_t len);

  private:
    // * data
    uint16_t msg_id{0};
    uint16_t cmd{0x00};
    uint8_t direction{DIRECTION_REQUEST};
    std::vector<std::uint8_t> data;
};
} // namespace SimpleProtocol