#pragma once

#include "easy_asocket.hpp"
#include "simple_protocol.hpp"
#include "simple_protocol_impl.hpp"
#include <iostream>
#include <memory>
#include <thread>

namespace EasyASocket
{

// ========== 常量定义 ==========
namespace Constants
{
    constexpr size_t PKG_BUFFER_CAPACITY = 1024 * 1024 * 4; // 4MB 包缓冲区容量
    constexpr size_t RECV_BUFFER_SIZE = 1024;              // 接收缓冲区大小
    constexpr uint32_t LENGTH_FIELD_SIZE = 4;                // Length字段大小（字节）
}

// ========== 全局变量 ==========
inline std::shared_ptr<asio::io_context> global_io_ctx = nullptr;
inline std::thread *ctx_backend_thread = nullptr;
inline bool global_terminal_verbose = true;

inline std::shared_ptr<asio::io_context> get_global_io_ctx()
{
    if (global_io_ctx == nullptr)
    {
        global_io_ctx = std::make_shared<asio::io_context>();
    }
    return global_io_ctx;
}

inline void run_ctx_backend()
{
    if (ctx_backend_thread == nullptr)
    {
        ctx_backend_thread = new std::thread([]() {
            if (global_io_ctx != nullptr)
            {
                global_io_ctx->run();
            }
        });
    }
}

inline void stop_ctx()
{
    if (ctx_backend_thread != nullptr && global_io_ctx != nullptr)
    {
        global_io_ctx->stop();
        ctx_backend_thread->join();
        delete ctx_backend_thread;
        ctx_backend_thread = nullptr;
    }
}

inline void set_terminal_verbose(bool enabled)
{
    global_terminal_verbose = enabled;
}

inline bool get_terminal_verbose()
{
    return global_terminal_verbose;
}

inline IDPool::IDPool(int max_size) : max_size(max_size)
{
    borrowed.reserve(max_size);
}

inline std::tuple<bool, size_t> IDPool::get_id()
{
    std::lock_guard<std::mutex> lock(mutex_);
    release_failed_id();
    if (borrowed.size() >= max_size)
    {
        return std::make_tuple(false, 0);
    }
    // 优化：如果 borrowed 为空，直接返回 0
    if (borrowed.empty())
    {
        borrowed.push_back(0);
        return std::make_tuple(true, 0);
    }
    // 优化：从 borrowed 的最大值+1 开始查找，减少查找次数
    size_t start_id = borrowed.back() + 1;
    for (size_t i = 0; i < max_size; ++i)
    {
        size_t id = (start_id + i) % max_size;
        if (!is_borrowed(id))
        {
            borrowed.push_back(id);
            return std::make_tuple(true, id);
        }
    }
    return std::make_tuple(false, 0);
}

inline void IDPool::return_id(size_t id)
{
    std::lock_guard<std::mutex> lock(mutex_);
    if (is_borrowed(id))
    {
        borrowed.erase(std::find(borrowed.begin(), borrowed.end(), id));
    }
}

inline void IDPool::failed_id(size_t id)
{
    std::lock_guard<std::mutex> lock(mutex_);
    failed_map[id] = std::chrono::steady_clock::now();
}

inline void IDPool::release_failed_id()
{
    // 注意：这个方法应该在已经持有锁的情况下调用
    const auto now = std::chrono::steady_clock::now();
    const auto timeout_duration = std::chrono::milliseconds(failed_timeout);
    
    for (auto it = failed_map.begin(); it != failed_map.end();)
    {
        if (now - it->second > timeout_duration)
        {
            return_id(it->first);
            it = failed_map.erase(it);
        }
        else
        {
            ++it;
        }
    }
}

inline bool IDPool::is_borrowed(size_t id)
{
    // 注意：这个方法应该在已经持有锁的情况下调用
    return std::find(borrowed.begin(), borrowed.end(), id) != borrowed.end();
}

inline SocketClient::SocketClient(std::string host, uint16_t port, std::shared_ptr<asio::io_context> io_ctx)
{
    pkg_buff.set_capacity(Constants::PKG_BUFFER_CAPACITY);
    recv_buff.resize(Constants::RECV_BUFFER_SIZE);
    
    this->io_ctx = (io_ctx == nullptr) ? get_global_io_ctx() : io_ctx;
    this->endpoint = asio::ip::tcp::endpoint(asio::ip::address::from_string(host), port);
    this->socket = std::make_shared<asio::ip::tcp::socket>(*this->io_ctx);
    
    async_connect();
    async_read();
}

inline std::tuple<bool, SimpleProtocol> SocketClient::request(SimpleProtocol &p, bool except_response, uint32_t timeout)
{
    auto [ret, id] = id_pool.get_id();
    if (!ret)
    {
        if (global_terminal_verbose)
        {
            std::cout << "ID pool is full" << std::endl;
        }
        return std::make_tuple(false, SimpleProtocol());
    }
    p.set_msgid(id);
    p.set_direction(SimpleProtocol::SimpleProtocol::DIRECTION_REQUEST);
    auto data = p.encode();
    if (!except_response)
    {
        async_write(data);
        return std::make_tuple(false, SimpleProtocol());
    }
    request_map[id] = std::promise<SimpleProtocol>();
    auto future = request_map[id].get_future();
    async_write(data); // 发送请求数据
    if (future.wait_for(std::chrono::milliseconds(timeout)) == std::future_status::timeout)
    {
        request_map.erase(id);
        id_pool.failed_id(id);
        return std::make_tuple(false, SimpleProtocol());
    }
    auto result = future.get();
    request_map.erase(id);
    id_pool.return_id(id);
    return std::make_tuple(true, result);
}

inline void SocketClient::response(SimpleProtocol &p){
    p.set_direction(SimpleProtocol::DIRECTION_RESPONSE);
    auto data = p.encode();
    async_write(data);
}

inline void SocketClient::set_request_callback(std::function<void(SimpleProtocol &p)> callback)
{
    this->request_callback = callback;
}

inline bool SocketClient::is_connected() const
{
    return socket != nullptr && socket->is_open();
}

inline void SocketClient::async_connect()
{
    socket->async_connect(endpoint, [this](const boost::system::error_code &error) {
        if (error)
        {
            if (global_terminal_verbose)
            {
                std::cout << "Connect failed: " << error.message() << std::endl;
            }
        }
        else
        {
            if (global_terminal_verbose)
            {
                std::cout << "Connect success" << std::endl;
            }
        }
    });
}

// ========== 辅助函数命名空间 ==========
namespace Helper
{
    inline void log_verbose(const std::string &message)
    {
        if (global_terminal_verbose)
        {
            std::cout << message << std::endl;
        }
    }
    
    inline bool is_connection_error(const boost::system::error_code &error)
    {
        return error == asio::error::eof || 
               error == asio::error::connection_reset || 
               error == asio::error::broken_pipe || 
               error == asio::error::connection_aborted;
    }
    
    // 包解析辅助结构
    struct PacketParseResult
    {
        bool found_header{false};
        size_t header_offset{0};
        uint32_t data_length{0};
        size_t total_packet_size{0};
        bool has_enough_data{false};
    };
    
    // 查找包头
    template<typename Iterator>
    inline bool find_packet_header(Iterator &it, Iterator end, size_t &header_offset)
    {
        while (it != end)
        {
            if (*it == SimpleProtocol::SimpleProtocol::HEADER_BYTE1)
            {
                auto next_it = std::next(it);
                if (next_it != end && *next_it == SimpleProtocol::SimpleProtocol::HEADER_BYTE2)
                {
                    header_offset = std::distance(it, it); // 需要传入begin迭代器计算
                    return true;
                }
            }
            ++it;
        }
        return false;
    }
    
    // 计算包的总大小
    inline size_t calculate_packet_size(uint32_t data_length)
    {
        return SimpleProtocol::SimpleProtocol::HEADER_SIZE +
               SimpleProtocol::SimpleProtocol::DIRECTION_SIZE +
               SimpleProtocol::SimpleProtocol::MESSAGE_ID_SIZE +
               SimpleProtocol::SimpleProtocol::LENGTH_SIZE +
               SimpleProtocol::SimpleProtocol::CMD_SIZE +
               data_length +
               SimpleProtocol::SimpleProtocol::CRC16_SIZE +
               SimpleProtocol::SimpleProtocol::FOOTER_SIZE;
    }
    
    // 从缓冲区中移除已处理的包
    template<typename Buffer>
    inline void remove_processed_packet(Buffer &buffer, size_t header_offset, size_t packet_size)
    {
        // 移除包头之前的数据
        for (size_t i = 0; i < header_offset && !buffer.empty(); ++i)
        {
            buffer.pop_front();
        }
        // 移除包数据
        for (size_t i = 0; i < packet_size && !buffer.empty(); ++i)
        {
            buffer.pop_front();
        }
    }
}

inline void SocketClient::async_write(const std::vector<uint8_t> &data)
{
    if (socket == nullptr || !socket->is_open())
    {
        Helper::log_verbose("Cannot write: socket is not open");
        return;
    }
    
    try
    {
        auto data_copy = std::make_shared<std::vector<uint8_t>>(data);
        asio::async_write(*socket, asio::buffer(*data_copy), 
            [this, data_copy](const boost::system::error_code &error, size_t bytes_transferred) {
                if (error)
                {
                    Helper::log_verbose("Write failed: " + error.message());
                }
                else
                {
                    Helper::log_verbose("Write success: " + std::to_string(bytes_transferred) + " bytes");
                }
            });
    }
    catch (const std::exception &e)
    {
        Helper::log_verbose("Exception in async_write: " + std::string(e.what()));
    }
    catch (...)
    {
        Helper::log_verbose("Unknown exception in async_write");
    }
}

inline void SocketClient::async_read()
{
    socket->async_read_some(asio::buffer(recv_buff), [this](const boost::system::error_code &error, size_t bytes_transferred) {
        if (error)
        {
            if (Helper::is_connection_error(error))
            {
                Helper::log_verbose("Connection closed by peer");
            }
            else
            {
                Helper::log_verbose("Read failed: " + error.message());
            }
            return;
        }
        
        // 将接收到的数据添加到包缓冲区
        for (size_t i = 0; i < bytes_transferred; ++i)
        {
            pkg_buff.push_back(recv_buff[i]);
        }
        
        process_pkg();
        async_read();
    });
}

inline void SocketClient::process_pkg()
{
    // 检查是否有足够的数据来构成最小包
    if (pkg_buff.size() < SimpleProtocol::SimpleProtocol::MIN_PACKET_SIZE)
    {
        return;
    }

    auto it = pkg_buff.begin();
    const auto buff_begin = pkg_buff.begin();
    
    while (it != pkg_buff.end())
    {
        // 查找包头 0xAA 0x55
        if (*it == SimpleProtocol::SimpleProtocol::HEADER_BYTE1)
        {
            auto next_it = std::next(it);
            if (next_it != pkg_buff.end() && *next_it == SimpleProtocol::SimpleProtocol::HEADER_BYTE2)
            {
                const size_t header_offset = std::distance(buff_begin, it);
                
                // 计算Length字段的位置
                const size_t length_field_offset = header_offset + 
                    SimpleProtocol::SimpleProtocol::HEADER_SIZE + 
                    SimpleProtocol::SimpleProtocol::DIRECTION_SIZE +
                    SimpleProtocol::SimpleProtocol::MESSAGE_ID_SIZE;

                // 检查是否有足够的数据读取Length字段
                if (pkg_buff.size() < length_field_offset + SimpleProtocol::SimpleProtocol::LENGTH_SIZE)
                {
                    return;
                }

                // 读取数据长度
                auto length_it = buff_begin;
                std::advance(length_it, length_field_offset);
                if (std::distance(length_it, pkg_buff.end()) < Constants::LENGTH_FIELD_SIZE)
                {
                    return;
                }
                
                const uint32_t data_length = SimpleProtocol::SimpleProtocol::bytesToUint32(&(*length_it));
                const size_t total_packet_size = Helper::calculate_packet_size(data_length);

                // 检查是否有完整的包数据
                if (pkg_buff.size() < header_offset + total_packet_size)
                {
                    return;
                }

                // 准备验证包数据
                auto packet_start_it = buff_begin;
                std::advance(packet_start_it, header_offset);

                const size_t remaining_after_start = std::distance(packet_start_it, pkg_buff.end());
                uint8_t *ptr1 = &(*packet_start_it);
                const size_t len1 = (remaining_after_start >= total_packet_size) ? total_packet_size : remaining_after_start;
                uint8_t *ptr2 = (len1 < total_packet_size) ? &(*buff_begin) : nullptr;
                const size_t len2 = (len1 < total_packet_size) ? (total_packet_size - len1) : 0;

                // 验证包
                const bool is_valid = SimpleProtocol::SimpleProtocol::validate(ptr1, len1, ptr2, len2);

                if (is_valid)
                {
                    // 解码包
                    auto packet_end_it = std::next(packet_start_it, total_packet_size);
                    std::vector<uint8_t> packet_vec(packet_start_it, packet_end_it);
                    auto [decode_success, pkg] = SimpleProtocol::SimpleProtocol::decode(packet_vec);
                    
                    if (decode_success)
                    {
                        // 处理响应包
                        if (pkg.get_direction() == SimpleProtocol::SimpleProtocol::DIRECTION_RESPONSE)
                        {
                            auto request_it = request_map.find(pkg.get_msgid());
                            if (request_it != request_map.end())
                            {
                                request_it->second.set_value(pkg);
                            }
                            else
                            {
                                Helper::log_verbose("Request not found: " + std::to_string(pkg.get_msgid()));
                            }
                        }
                    }
                    else
                    {
                        Helper::log_verbose("Process pkg failed: decode failed");
                    }
                }
                else
                {
                    Helper::log_verbose("Process pkg failed: validation failed");
                }

                // 移除已处理的包
                Helper::remove_processed_packet(pkg_buff, header_offset, total_packet_size);
                it = pkg_buff.begin();
                continue;
            }
        }
        ++it;
    }
}

// ========== SocketServer Implementation ==========

inline SocketServer::SocketServer(uint16_t port, std::shared_ptr<asio::io_context> io_ctx)
{
    if (io_ctx == nullptr)
    {
        this->io_ctx = get_global_io_ctx();
    }
    else
    {
        this->io_ctx = io_ctx;
    }
    this->acceptor = std::make_shared<asio::ip::tcp::acceptor>(*this->io_ctx, asio::ip::tcp::endpoint(asio::ip::tcp::v4(), port));
}

inline SocketServer::~SocketServer()
{
    stop();
}

inline void SocketServer::start()
{
    async_accept();
}

inline void SocketServer::stop()
{
    if (acceptor != nullptr && acceptor->is_open())
    {
        acceptor->close();
    }
    // Return all client IDs to the pool before clearing
    {
        std::lock_guard<std::mutex> lock(clients_mutex);
        for (const auto& [client_id, session] : clients)
        {
            client_id_pool.return_id(client_id);
        }
        clients.clear();
    }
}


inline void SocketServer::async_accept()
{
    auto socket = std::make_shared<asio::ip::tcp::socket>(*io_ctx);
    acceptor->async_accept(*socket, [this, socket](const boost::system::error_code &error) {
        if (error)
        {
            Helper::log_verbose("Accept failed: " + error.message());
        }
        else
        {
            auto [ret, client_id] = client_id_pool.get_id();
            if (!ret)
            {
                Helper::log_verbose("Client ID pool is full, cannot accept new client");
            }
            else
            {
                auto session = std::make_shared<ClientSession>(socket, client_id, this);
                {
                    std::lock_guard<std::mutex> lock(clients_mutex);
                    clients[client_id] = session;
                }
                Helper::log_verbose("Client connected, ID: " + std::to_string(client_id));
                session->start();
            }
        }
        async_accept(); // 继续接受新连接
    });
}

// ========== ClientSession Implementation ==========

inline ClientSession::ClientSession(std::shared_ptr<asio::ip::tcp::socket> socket, size_t client_id, SocketServer *server)
    : socket(socket), client_id(client_id), server(server)
{
    pkg_buff.set_capacity(Constants::PKG_BUFFER_CAPACITY);
    recv_buff.resize(Constants::RECV_BUFFER_SIZE);
}

inline void ClientSession::start()
{
    async_read();
}

inline std::tuple<bool, SimpleProtocol> ClientSession::request(SimpleProtocol &p, bool except_response, uint32_t timeout)
{
    // 检查连接状态
    if (!is_connected())
    {
        Helper::log_verbose("Client " + std::to_string(client_id) + " is not connected, cannot send request");
        return std::make_tuple(false, SimpleProtocol());
    }
    
    auto [ret, id] = id_pool.get_id();
    if (!ret)
    {
        Helper::log_verbose("ID pool is full for client " + std::to_string(client_id));
        return std::make_tuple(false, SimpleProtocol());
    }
    p.set_msgid(id);
    p.set_direction(SimpleProtocol::SimpleProtocol::DIRECTION_REQUEST);
    auto data = p.encode();
    if (!except_response)
    {
        async_write(data);
        return std::make_tuple(false, SimpleProtocol());
    }
    
    // 优化：合并锁区域，减少加锁次数
    std::future<SimpleProtocol> future;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        request_map[id] = std::promise<SimpleProtocol>();
        future = request_map[id].get_future();
    }
    
    async_write(data); // 发送请求数据
    
    // 等待响应（在锁外等待，避免阻塞其他操作）
    auto wait_result = future.wait_for(std::chrono::milliseconds(timeout));
    
    // 优化：统一处理超时和成功情况，减少锁操作
    std::lock_guard<std::mutex> lock(mutex_);
    auto it = request_map.find(id);
    
    if (wait_result == std::future_status::timeout)
    {
        // 超时处理
        if (it != request_map.end())
        {
            request_map.erase(it);
        }
        id_pool.failed_id(id);
        return std::make_tuple(false, SimpleProtocol());
    }
    
    if (it == request_map.end())
    {
        // 请求已被取消（可能是客户端断开）
        id_pool.failed_id(id);
        return std::make_tuple(false, SimpleProtocol());
    }
    
    // 获取结果（在锁内获取，确保一致性）
    auto result = future.get();
    request_map.erase(it);
    id_pool.return_id(id);
    
    // 检查响应是否有效：如果 msg_id 不匹配，说明可能是连接断开导致的默认值
    if (result.get_msgid() != id)
    {
        return std::make_tuple(false, SimpleProtocol());
    }
    return std::make_tuple(true, result);
}

inline void ClientSession::response(SimpleProtocol &p)
{
    p.set_direction(SimpleProtocol::SimpleProtocol::DIRECTION_RESPONSE);
    auto data = p.encode();
    async_write(data);
}

inline void ClientSession::set_request_callback(std::function<void(SimpleProtocol &p)> callback)
{
    std::lock_guard<std::mutex> lock(mutex_);
    this->request_callback = callback;
}

inline bool ClientSession::is_connected() const
{
    try
    {
        // socket 是 shared_ptr，访问是安全的，但需要确保 socket 对象本身不被并发修改
        // 由于 socket 是 const 成员，这里只需要读取，应该是安全的
        return socket != nullptr && socket->is_open();
    }
    catch (...)
    {
        // 如果检查socket状态时发生异常，认为已断开连接
        return false;
    }
}

// ========== ClientSession 辅助函数 ==========
// 注意：这些函数需要访问 ClientSession 的私有成员，因此需要在类定义之后实现
// 取消所有未完成的请求（在连接断开时调用）
inline void cancel_all_pending_requests(ClientSession* session)
{
    if (session == nullptr) return;
    
    try
    {
        std::lock_guard<std::mutex> lock(session->mutex_);
        for (auto &[promise_id, promise] : session->request_map)
        {
            try
            {
                promise.set_value(SimpleProtocol());
            }
            catch (...)
            {
                // promise 可能已经被设置或销毁，忽略异常
            }
        }
        session->request_map.clear();
    }
    catch (...)
    {
        // 如果 mutex_ 或 request_map 访问失败，忽略
    }
}

// 从服务器中移除客户端会话
inline void remove_from_server(ClientSession* session)
{
    if (session == nullptr || session->server == nullptr) return;
    
    try
    {
        // 优化：使用公共方法，避免直接访问私有成员
        session->server->remove_client(session->client_id);
    }
    catch (...)
    {
        // 如果 server 已经被销毁或访问失败，忽略
    }
}

inline void ClientSession::async_write(const std::vector<uint8_t> &data)
{
    if (socket == nullptr || !socket->is_open())
    {
        Helper::log_verbose("Cannot write to client " + std::to_string(client_id) + ": socket is not open");
        return;
    }
    
    try
    {
        auto data_copy = std::make_shared<std::vector<uint8_t>>(data);
        const size_t id = client_id;
        
        asio::async_write(*socket, asio::buffer(*data_copy), 
            [this, data_copy, id](const boost::system::error_code &error, size_t bytes_transferred) {
                try
                {
                    if (error)
                    {
                        Helper::log_verbose("Write failed to client " + std::to_string(id) + ": " + error.message());
                        
                        // 如果是连接断开错误，取消所有未完成的请求
                        if (Helper::is_connection_error(error))
                        {
                            cancel_all_pending_requests(this);
                        }
                    }
                    else
                    {
                        Helper::log_verbose("Write success to client " + std::to_string(id) + ": " + 
                                          std::to_string(bytes_transferred) + " bytes");
                    }
                }
                catch (const std::exception& e)
                {
                    Helper::log_verbose("Exception in async_write callback for client " + std::to_string(id) + ": " + e.what());
                }
                catch (...)
                {
                    Helper::log_verbose("Unknown exception in async_write callback for client " + std::to_string(id));
                }
            });
    }
    catch (const std::exception &e)
    {
        Helper::log_verbose("Exception in async_write for client " + std::to_string(client_id) + ": " + e.what());
    }
    catch (...)
    {
        Helper::log_verbose("Unknown exception in async_write for client " + std::to_string(client_id));
    }
}

inline void ClientSession::async_read()
{
    const size_t id = client_id;
    SocketServer* server_ptr = server;
    
    socket->async_read_some(asio::buffer(recv_buff), 
        [this, server_ptr, id](const boost::system::error_code &error, size_t bytes_transferred) {
            try
            {
                if (error)
                {
                    if (Helper::is_connection_error(error))
                    {
                        Helper::log_verbose("Client " + std::to_string(id) + " disconnected");
                        cancel_all_pending_requests(this);
                        remove_from_server(this);
                    }
                    else
                    {
                        Helper::log_verbose("Read failed from client " + std::to_string(id) + ": " + error.message());
                    }
                    return;
                }
                
                // 将接收到的数据添加到包缓冲区
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    // 优化：预分配空间（如果可能），减少重新分配
                    for (size_t i = 0; i < bytes_transferred; ++i)
                    {
                        pkg_buff.push_back(recv_buff[i]);
                    }
                }
                
                process_pkg();
                async_read(); // 继续读取
            }
            catch (...)
            {
                Helper::log_verbose("Error processing data for client " + std::to_string(id) + ", stopping read");
            }
        });
}

inline void ClientSession::process_pkg()
{
    // 优化：使用循环处理多个包，但尽量减少锁持有时间
    while (true)
    {
        std::vector<uint8_t> packet_data;  // 用于存储复制的包数据
        size_t header_offset = 0;
        size_t total_packet_size = 0;
        bool found_packet = false;
        
        // 第一步：快速检查并复制包数据（最小化锁持有时间）
        {
            std::lock_guard<std::mutex> lock(mutex_);
            
            // 检查是否有足够的数据来构成最小包
            if (pkg_buff.size() < SimpleProtocol::SimpleProtocol::MIN_PACKET_SIZE)
            {
                return;
            }

            auto it = pkg_buff.begin();
            const auto buff_begin = pkg_buff.begin();
            
            // 查找包头
            while (it != pkg_buff.end())
            {
                if (*it == SimpleProtocol::SimpleProtocol::HEADER_BYTE1)
                {
                    auto next_it = std::next(it);
                    if (next_it != pkg_buff.end() && *next_it == SimpleProtocol::SimpleProtocol::HEADER_BYTE2)
                    {
                        header_offset = std::distance(buff_begin, it);
                        
                        // 计算Length字段的位置
                        const size_t length_field_offset = header_offset + 
                            SimpleProtocol::SimpleProtocol::HEADER_SIZE + 
                            SimpleProtocol::SimpleProtocol::DIRECTION_SIZE +
                            SimpleProtocol::SimpleProtocol::MESSAGE_ID_SIZE;

                        // 检查是否有足够的数据读取Length字段
                        if (pkg_buff.size() < length_field_offset + SimpleProtocol::SimpleProtocol::LENGTH_SIZE)
                        {
                            return;
                        }

                        // 读取数据长度
                        auto length_it = buff_begin;
                        std::advance(length_it, length_field_offset);
                        if (std::distance(length_it, pkg_buff.end()) < Constants::LENGTH_FIELD_SIZE)
                        {
                            return;
                        }
                        
                        const uint32_t data_length = SimpleProtocol::SimpleProtocol::bytesToUint32(&(*length_it));
                        total_packet_size = Helper::calculate_packet_size(data_length);

                        // 检查是否有完整的包数据
                        if (pkg_buff.size() < header_offset + total_packet_size)
                        {
                            return;
                        }

                        // 快速复制包数据到锁外处理
                        auto packet_start_it = buff_begin;
                        std::advance(packet_start_it, header_offset);
                        auto packet_end_it = std::next(packet_start_it, total_packet_size);
                        packet_data.assign(packet_start_it, packet_end_it);
                        found_packet = true;
                        break;
                    }
                }
                ++it;
            }
            
            if (!found_packet)
            {
                return;  // 没有找到完整的包
            }
        }  // 锁在这里释放，后续处理在锁外进行
        
        // 第二步：在锁外进行验证和解码（耗时操作）
        const size_t remaining_after_start = packet_data.size();
        uint8_t *ptr1 = packet_data.data();
        const size_t len1 = remaining_after_start;
        uint8_t *ptr2 = nullptr;
        const size_t len2 = 0;

        // 验证包
        const bool is_valid = SimpleProtocol::SimpleProtocol::validate(ptr1, len1, ptr2, len2);

        if (!is_valid)
        {
            Helper::log_verbose("Process pkg failed: validation failed");
            // 移除无效包
            {
                std::lock_guard<std::mutex> lock(mutex_);
                Helper::remove_processed_packet(pkg_buff, header_offset, total_packet_size);
            }
            continue;  // 继续处理下一个包
        }

        // 解码包
        auto [decode_success, pkg] = SimpleProtocol::SimpleProtocol::decode(packet_data);
        
        if (!decode_success)
        {
            Helper::log_verbose("Process pkg failed: decode failed");
            // 移除解码失败的包
            {
                std::lock_guard<std::mutex> lock(mutex_);
                Helper::remove_processed_packet(pkg_buff, header_offset, total_packet_size);
            }
            continue;  // 继续处理下一个包
        }
        
        // 第三步：处理解码后的包（需要访问共享状态时再加锁）
        std::function<void(SimpleProtocol &p)> callback;
        bool is_response = false;
        size_t msg_id = 0;
        std::promise<SimpleProtocol>* promise_ptr = nullptr;
        
        {
            std::lock_guard<std::mutex> lock(mutex_);
            
            if (pkg.get_direction() == SimpleProtocol::SimpleProtocol::DIRECTION_REQUEST)
            {
                // 收到请求，准备回调
                callback = request_callback;
                is_response = false;
            }
            else
            {
                // 收到响应，查找对应的promise
                is_response = true;
                msg_id = pkg.get_msgid();
                auto request_it = request_map.find(msg_id);
                if (request_it != request_map.end())
                {
                    promise_ptr = &request_it->second;
                }
                else
                {
                    Helper::log_verbose("Request not found for response: " + 
                                       std::to_string(msg_id) + 
                                       " from client " + std::to_string(client_id));
                }
            }
            
            // 移除已处理的包
            Helper::remove_processed_packet(pkg_buff, header_offset, total_packet_size);
        }  // 锁释放
        
        // 第四步：在锁外设置promise或调用回调
        if (is_response && promise_ptr != nullptr)
        {
            try
            {
                promise_ptr->set_value(pkg);
            }
            catch (...)
            {
                // promise 可能已经被设置，忽略异常
            }
        }
        else if (!is_response && callback != nullptr)
        {
            // 收到请求，记录日志并调用回调
            if (global_terminal_verbose)
            {
                std::cout << "Received request from client " << client_id << " content:";
                printHex(pkg.get_data());
            }
            try
            {
                callback(pkg);
            }
            catch (...)
            {
                // 忽略回调中的异常
            }
        }
        
        // 继续处理下一个包（如果有）
    }
}

inline std::unordered_map<size_t, std::shared_ptr<ClientSession>> SocketServer::get_clients() const
{
    std::lock_guard<std::mutex> lock(clients_mutex);
    return clients; // Return a copy (snapshot)
}

inline void SocketServer::remove_client(size_t client_id)
{
    std::lock_guard<std::mutex> lock(clients_mutex);
    clients.erase(client_id);
    client_id_pool.return_id(client_id);
}

} // namespace SimpleProtocol

