#pragma once

#include <boost/asio.hpp>
#include <boost/circular_buffer.hpp>
#include <future>
#include <memory>
#include <tuple>
#include <unordered_map>
#include <vector>
#include "simple_protocol.hpp"
#include <chrono>
#include <mutex>

namespace EasyASocket
{

namespace asio = boost::asio;

std::shared_ptr<asio::io_context> get_global_io_ctx();

void run_ctx_backend();
void stop_ctx();

// Verbose control
void set_terminal_verbose(bool enabled);
bool get_terminal_verbose();

class IDPool
{
  public:
    IDPool(int max_size = 1000);
    ~IDPool() = default;

    std::tuple<bool, size_t> get_id();
    void return_id(size_t id);
    void failed_id(size_t id);
    
  private:
    size_t max_size{1000};
    std::vector<size_t> borrowed;
    bool is_borrowed(size_t id);
    std::unordered_map<size_t, std::chrono::time_point<std::chrono::steady_clock>> failed_map;
    void release_failed_id();
    uint32_t failed_timeout{10000}; // 10 seconds
    mutable std::mutex mutex_; // 保护所有成员变量的互斥锁
};

class SocketClient
{
  public:
    SocketClient(std::string host, uint16_t port, std::shared_ptr<asio::io_context> io_ctx = nullptr);
    ~SocketClient() = default;

    std::tuple<bool, SimpleProtocol> request(SimpleProtocol &p,bool except_response=false,uint32_t timeout=5000);
    void response(SimpleProtocol &p);

    void set_request_callback(std::function<void(SimpleProtocol &p)> callback);
    bool is_connected() const;

  private:
    // net
    std::shared_ptr<asio::io_context> io_ctx;
    asio::ip::tcp::endpoint endpoint;
    std::shared_ptr<asio::ip::tcp::socket> socket;
    IDPool id_pool;
    std::unordered_map<size_t, std::promise<SimpleProtocol>> request_map;

    void async_connect();
    void async_write(const std::vector<uint8_t> &data);
    void async_read();
    void process_pkg();

    std::function<void(SimpleProtocol &p)> request_callback{nullptr};

    // data
    std::vector<uint8_t> recv_buff;
    boost::circular_buffer<uint8_t> pkg_buff;
};

class SocketServer;

// 前向声明辅助函数
class ClientSession;
void cancel_all_pending_requests(ClientSession* session);
void remove_from_server(ClientSession* session);

class ClientSession
{
  public:
    ClientSession(std::shared_ptr<asio::ip::tcp::socket> socket, size_t client_id, SocketServer *server);
    ~ClientSession() = default;

    void start();
    size_t get_client_id() const { return client_id; }

    std::tuple<bool, SimpleProtocol> request(SimpleProtocol &p, bool except_response = false, uint32_t timeout = 5000);
    void response(SimpleProtocol &p);
    void set_request_callback(std::function<void(SimpleProtocol &p)> callback);
    bool is_connected() const;

  private:
    friend class SocketServer;
    friend void cancel_all_pending_requests(ClientSession* session);
    friend void remove_from_server(ClientSession* session);
    void async_read();
    void process_pkg();
    void async_write(const std::vector<uint8_t> &data);

    std::shared_ptr<asio::ip::tcp::socket> socket;
    size_t client_id;
    SocketServer *server;
    IDPool id_pool;
    std::unordered_map<size_t, std::promise<SimpleProtocol>> request_map;
    std::function<void(SimpleProtocol &p)> request_callback{nullptr};
    std::vector<uint8_t> recv_buff;
    boost::circular_buffer<uint8_t> pkg_buff;
    mutable std::mutex mutex_; // 保护 request_map, id_pool, pkg_buff 等成员变量
};

class SocketServer
{
  public:
    SocketServer(uint16_t port, std::shared_ptr<asio::io_context> io_ctx = nullptr);
    ~SocketServer();

    void start();
    void stop();
    std::unordered_map<size_t, std::shared_ptr<ClientSession>> get_clients() const;
    // 内部方法：移除客户端（供友元函数使用）
    void remove_client(size_t client_id);

  private:
    friend class ClientSession;
    void async_accept();

    // net
    std::shared_ptr<asio::io_context> io_ctx;
    std::shared_ptr<asio::ip::tcp::acceptor> acceptor;
    std::unordered_map<size_t, std::shared_ptr<ClientSession>> clients;
    mutable std::mutex clients_mutex;
    IDPool client_id_pool;

};

} // namespace SimpleProtocol