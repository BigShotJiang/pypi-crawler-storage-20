#pragma once

#include "simple_protocol.hpp"
#include <iostream>
#include <iomanip>

namespace EasyASocket
{
inline void printHex(const std::vector<uint8_t> &data)
{
    {
        std::cout << "Hex: ";
        for (size_t i = 0; i < data.size(); ++i)
        {
            std::cout << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(data[i]) << " ";
        }
        std::cout << std::dec << std::endl;
    }
}

inline std::vector<uint8_t> SimpleProtocol::encode()
{
    // Calculate total length: Header(2) + Direction(1) + MessageID(2) + Length(4) + CMD(2) + Data(N) + CRC16(2) + Footer(2)
    size_t total_size = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data.size() + CRC16_SIZE + FOOTER_SIZE;
    std::vector<uint8_t> bytearray(total_size);
    size_t offset = 0;

    // Write Header
    bytearray[offset++] = HEADER_BYTE1;
    bytearray[offset++] = HEADER_BYTE2;

    // Write Direction
    bytearray[offset++] = direction;

    // Write MessageID
    SimpleProtocol::uint16ToBytes(msg_id, &bytearray[offset]);
    offset += MESSAGE_ID_SIZE;

    // Write Length (data part length, excluding Header, Direction, MessageID, Length, CMD, CRC16, Footer)
    SimpleProtocol::uint32ToBytes(static_cast<uint32_t>(data.size()), &bytearray[offset]);
    offset += LENGTH_SIZE;

    // Write CMD
    SimpleProtocol::uint16ToBytes(cmd, &bytearray[offset]);
    offset += CMD_SIZE;

    // Write Data
    if (data.size() > 0)
    {
        std::memcpy(&bytearray[offset], data.data(), data.size());
        offset += data.size();
    }

    // Calculate CRC16 for Direction + MessageID + Length + CMD + Data
    uint16_t crc16 = SimpleProtocol::calculateCRC16(&bytearray[HEADER_SIZE], DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data.size());

    // Write CRC16
    SimpleProtocol::uint16ToBytes(crc16, &bytearray[offset]);
    offset += CRC16_SIZE;

    // Write Footer
    bytearray[offset++] = FOOTER_BYTE1;
    bytearray[offset++] = FOOTER_BYTE2;

    return bytearray;
}

inline std::tuple<bool, SimpleProtocol> SimpleProtocol::decode(const std::vector<uint8_t> &bytearray)
{
    SimpleProtocol p;
    if (!validate(bytearray))
    {
        return std::make_tuple(false, p);
    }
    p.direction = bytearray[HEADER_SIZE];
    p.msg_id = bytesToUint16(&bytearray[HEADER_SIZE + DIRECTION_SIZE]);
    auto length = bytesToUint32(&bytearray[HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE]);
    p.cmd = bytesToUint16(&bytearray[HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE]);
    p.data.resize(length);
    memcpy(p.data.data(), &bytearray[HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE], length);
    return std::make_tuple(true, p);
}

inline bool SimpleProtocol::validate(const std::vector<uint8_t> &bytearray)
{
    // Check minimum length
    if (bytearray.size() < MIN_PACKET_SIZE)
    {
        return false;
    }

    // Check Header
    if (bytearray[0] != HEADER_BYTE1 || bytearray[1] != HEADER_BYTE2)
    {
        return false;
    }

    // Read Length and validate
    uint32_t data_len = SimpleProtocol::bytesToUint32(&bytearray[HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE]);
    size_t expected_size = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data_len + CRC16_SIZE + FOOTER_SIZE;

    if (bytearray.size() != expected_size)
    {
        return false;
    }

    // Verify CRC16
    // CRC16 covers: Direction + MessageID + Length + CMD + Data
    size_t crc_data_start = HEADER_SIZE;
    size_t crc_data_len = DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data_len;
    uint16_t calculated_crc = SimpleProtocol::calculateCRC16(&bytearray[crc_data_start], crc_data_len);

    // Read stored CRC16
    size_t crc_offset = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data_len;
    uint16_t stored_crc = SimpleProtocol::bytesToUint16(&bytearray[crc_offset]);

    if (calculated_crc != stored_crc)
    {
        return false;
    }

    // Check Footer
    size_t footer_offset = bytearray.size() - FOOTER_SIZE;
    if (bytearray[footer_offset] != FOOTER_BYTE1 || bytearray[footer_offset + 1] != FOOTER_BYTE2)
    {
        return false;
    }

    return true;
}

inline bool SimpleProtocol::validate(uint8_t *ptr1, size_t len1, uint8_t *ptr2, size_t len2)
{
    size_t total_length = len1 + len2;

    // Lambda helper functions
    auto readByte = [ptr1, len1, ptr2, len2](size_t offset) -> uint8_t {
        if (offset < len1)
        {
            return ptr1[offset];
        }
        else
        {
            if (ptr2 == nullptr || len2 == 0)
            {
                return 0;
            }
            return ptr2[offset - len1];
        }
    };

    auto readUint16 = [&readByte](size_t offset) -> uint16_t {
        uint8_t bytes[2];
        for (size_t i = 0; i < 2; ++i)
        {
            bytes[i] = readByte(offset + i);
        }
        return SimpleProtocol::bytesToUint16(bytes);
    };

    auto readUint32 = [&readByte](size_t offset) -> uint32_t {
        uint8_t bytes[4];
        for (size_t i = 0; i < 4; ++i)
        {
            bytes[i] = readByte(offset + i);
        }
        return SimpleProtocol::bytesToUint32(bytes);
    };

    auto calculateCRC16TwoRegions = [&readByte](size_t start_offset, size_t total_len) -> uint16_t {
        uint16_t crc = 0xFFFF;
        const auto &table = SimpleProtocol::getCRC16Table();

        for (size_t i = 0; i < total_len; ++i)
        {
            uint8_t byte = readByte(start_offset + i);
            crc = ((crc << 8) ^ table[((crc >> 8) ^ byte) & 0xFF]) & 0xFFFF;
        }

        return crc;
    };

    // Check minimum length
    if (total_length < MIN_PACKET_SIZE)
    {
        return false;
    }

    // Check Header
    if (readByte(0) != HEADER_BYTE1 || readByte(1) != HEADER_BYTE2)
    {
        return false;
    }

    // Read Length and validate
    size_t length_field_offset = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE;
    uint32_t data_len = readUint32(length_field_offset);
    size_t expected_size = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data_len + CRC16_SIZE + FOOTER_SIZE;

    if (total_length != expected_size)
    {
        return false;
    }

    // Verify CRC16
    // CRC16 covers: Direction + MessageID + Length + CMD + Data
    size_t crc_data_start = HEADER_SIZE;
    size_t crc_data_len = DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data_len;
    uint16_t calculated_crc = calculateCRC16TwoRegions(crc_data_start, crc_data_len);

    // Read stored CRC16
    size_t crc_offset = HEADER_SIZE + DIRECTION_SIZE + MESSAGE_ID_SIZE + LENGTH_SIZE + CMD_SIZE + data_len;
    uint16_t stored_crc = readUint16(crc_offset);

    if (calculated_crc != stored_crc)
    {
        return false;
    }

    // Check Footer
    size_t footer_offset = total_length - FOOTER_SIZE;
    if (readByte(footer_offset) != FOOTER_BYTE1 || readByte(footer_offset + 1) != FOOTER_BYTE2)
    {
        return false;
    }

    return true;
}

inline void SimpleProtocol::set_cmd(uint16_t cmd)
{
    this->cmd = cmd;
}

inline void SimpleProtocol::set_msgid(uint16_t msg_id)
{
    this->msg_id = msg_id;
}

inline void SimpleProtocol::set_direction(uint8_t direction)
{
    this->direction = direction;
}

inline void SimpleProtocol::set_data(std::vector<uint8_t> data)
{
    this->data = data;
}

inline void SimpleProtocol::set_data(char *data, uint32_t length)
{
    this->data.resize(length);
    memcpy(this->data.data(), data, length);
}

inline uint16_t SimpleProtocol::get_cmd()
{
    return cmd;
}

inline uint16_t SimpleProtocol::get_msgid()
{
    return msg_id;
}

inline uint8_t SimpleProtocol::get_direction()
{
    return direction;
}

inline std::vector<uint8_t> SimpleProtocol::get_data_copy()
{
    return data;
}

inline std::vector<uint8_t> &SimpleProtocol::get_data()
{
    return data;
}

inline void SimpleProtocol::uint16ToBytes(uint16_t value, uint8_t *bytes)
{
    bytes[0] = static_cast<uint8_t>((value >> 8) & 0xFF);
    bytes[1] = static_cast<uint8_t>(value & 0xFF);
}

inline uint16_t SimpleProtocol::bytesToUint16(const uint8_t *bytes)
{
    return static_cast<uint16_t>((static_cast<uint16_t>(bytes[0]) << 8) | bytes[1]);
}

inline void SimpleProtocol::uint32ToBytes(uint32_t value, uint8_t *bytes)
{
    bytes[0] = static_cast<uint8_t>((value >> 24) & 0xFF);
    bytes[1] = static_cast<uint8_t>((value >> 16) & 0xFF);
    bytes[2] = static_cast<uint8_t>((value >> 8) & 0xFF);
    bytes[3] = static_cast<uint8_t>(value & 0xFF);
}

inline uint32_t SimpleProtocol::bytesToUint32(const uint8_t *bytes)
{
    return static_cast<uint32_t>((static_cast<uint16_t>(bytes[0]) << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3]);
}

inline const std::array<uint16_t, 256> &SimpleProtocol::getCRC16Table()
{
    static std::array<uint16_t, 256> table;
    static bool initialized = false;

    if (!initialized)
    {
        constexpr uint16_t polynomial = 0x1021;

        for (size_t i = 0; i < 256; ++i)
        {
            uint16_t crc = static_cast<uint16_t>(i << 8);
            for (int j = 0; j < 8; ++j)
            {
                if (crc & 0x8000)
                {
                    crc = (crc << 1) ^ polynomial;
                }
                else
                {
                    crc <<= 1;
                }
            }
            table[i] = crc;
        }

        initialized = true;
    }

    return table;
}

inline uint16_t SimpleProtocol::calculateCRC16(const uint8_t *data, size_t len)
{
    uint16_t crc = 0xFFFF;
    const auto &table = getCRC16Table();

    for (size_t i = 0; i < len; ++i)
    {
        crc = ((crc << 8) ^ table[((crc >> 8) ^ data[i]) & 0xFF]) & 0xFFFF;
    }

    return crc;
}

} // namespace SimpleProtocol

