from typing import NamedTuple

Point = tuple[float, float]
ColRow = tuple[int, int]


class LineSegment(NamedTuple):
    start: Point
    end: Point
