from dataclasses import dataclass
from typing import Union

import moderngl


@dataclass
class _OpenGLTextureBinded:
    """
    *For internal use only*

    Texture to use within an OpenGL class, binding
    a location and simplifying the way we handle
    it.
    """

    def __init__(
        self,
        # Can I pass the object that holds this (?)
        # opengl_context: moderngl.Context,
        uniforms: 'Uniforms',
        name: str,
        unit: int,
    ):
        # TODO: Validate parameters (?)

        self.name: str = name
        """
        The name of the uniform associated with this
        texture.
        """
        self.unit: int = unit
        """
        The unit (or location) of this texture within
        the OpenGL context.
        """
        # No longer being used as we don't accept numpys
        # self._handler: _OpenGLTextureHandler = _OpenGLTextureHandler(self._node.context)
        # """
        # The handler of this texture.
        # """

        # Assign the unit to the uniform
        uniforms.set(self.name, self.unit)

    def update(
        self,
        input: moderngl.Texture
    ) -> '_OpenGLTextureBinded':
        """
        Update the content of the texture and set it to be
        used in its unit.
        """
        # We are no longer accepting 'ndarray'
        # input = (
        #     self._handler.update(input)
        #     if PythonValidator.is_numpy_array(input) else
        #     input
        # )
        input.use(location = self.unit)

        return self

class _Textures:
    """
    *For internal use only*

    Class to wrap the functionality related to
    handling the opengl program textures.
    """

    @property
    def textures(
        self
    ) -> dict:
        """
        The internal dictionary to handle the different
        textures, mapping them by their names.
        """
        if not hasattr(self, '_textures'):
            self._textures = {}

        return self._textures

    def __init__(
        self,
        # opengl_context: moderngl.Context,
        uniforms: 'Uniforms'
    ):
        # self._opengl_context: moderngl.Context = opengl_context
        # """
        # The context that will be used for this instance.
        # """
        self._uniforms: 'Uniforms' = uniforms
        """
        The uniforms we need to associate the textures with.
        """
        # Force creation
        self.textures

    def get(
        self,
        name: str
    ) -> Union[_OpenGLTextureBinded, None]:
        """
        Get the texture with the given `name`.
        """
        return self.textures.get(name, None)
    
    def add(
        self,
        name: str,
        unit: Union[int, None] = None
    ) -> '_Textures':
        """
        Add a new texture binded to the internal dict. This
        will replace and old texture if the `name` provided
        was previously stored.
        """
        unit = (
            len(self.textures)
            if unit is None else
            unit
        )

        self._textures[name] = _OpenGLTextureBinded(
            # opengl_context = self._opengl_context,
            uniforms = self._uniforms,
            name = name,
            unit = unit
        )

        return self
    
    def update(
        self,
        name: str,
        input: moderngl.Texture
    ) -> '_Textures':
        """
        Update the content of the texture with the given
        `name` by setting the provided `input` and set
        it to be used in its unit (location).
        """
        self.get(name).update(input)

        return self