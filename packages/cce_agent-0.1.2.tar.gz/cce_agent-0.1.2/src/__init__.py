"""CCE Agent package root."""
