"""Validation utilities for Coze package.

This module provides common validation functions used across the Coze package
to ensure parameter integrity and provide consistent error messages.
"""

from typing import Any


def validate_required_string(value: Any, param_name: str) -> str:
    """Validate that a required string parameter is not None, empty, or whitespace-only.
    
    This function provides consistent validation for required string parameters
    across the Coze package.
    
    Parameters
    ----------
    value : Any
        The value to validate
    param_name : str
        The name of the parameter (for error messages)
        
    Returns
    -------
    str
        The validated non-empty string value (stripped of leading/trailing whitespace)
        
    Raises
    ------
    ValueError
        If value is None, not a string, empty, or contains only whitespace
    """
    if not value or not isinstance(value, str) or not value.strip():
        raise ValueError(
            f"{param_name} is required and must be a non-empty string. "
            f"Provide {param_name} when creating CozeAgent instance."
        )
    return value.strip()


def validate_coze_client(coze_client: Any) -> None:
    """Validate that a Coze client instance is properly configured.
    
    This function checks:
    1. The client is not None
    2. The client has a valid auth object
    3. If using TokenAuth, the token is not empty
    
    Parameters
    ----------
    coze_client : Any
        The Coze client instance to validate
        
    Raises
    ------
    ValueError
        If the client is invalid or improperly configured
    """
    if not coze_client:
        raise ValueError(
            "coze_client is required. "
            "Provide a Coze client instance created with TokenAuth."
        )
    
    # Check if client has _auth attribute (Coze object structure)
    if not hasattr(coze_client, "_auth"):
        raise ValueError(
            "coze_client must be a valid Coze instance. "
            "The provided object does not have the expected structure."
        )
    
    auth = coze_client._auth
    
    # Validate TokenAuth token if applicable
    if hasattr(auth, "token"):
        # TokenAuth has a token property
        try:
            token = auth.token
            if not token or not isinstance(token, str) or not token.strip():
                raise ValueError(
                    "coze_client is configured with an invalid token. "
                    "The TokenAuth token must be a non-empty string. "
                    "Ensure the Coze client is created with a valid token: "
                    "Coze(auth=TokenAuth(token='your-valid-token'), ...)"
                )
        except Exception as e:
            if isinstance(e, ValueError):
                raise
            # If accessing token property fails, it might be a different auth type
            # We'll let it pass and let the API call fail with a more specific error
            pass
    
    # Validate base_url if accessible
    if hasattr(coze_client, "_base_url"):
        base_url = coze_client._base_url
        if not base_url or not isinstance(base_url, str) or not base_url.strip():
            raise ValueError(
                "coze_client is configured with an invalid base_url. "
                "The base_url must be a non-empty string. "
                "Ensure the Coze client is created with a valid base_url: "
                "Coze(auth=..., base_url='https://api.coze.cn')"
            )
