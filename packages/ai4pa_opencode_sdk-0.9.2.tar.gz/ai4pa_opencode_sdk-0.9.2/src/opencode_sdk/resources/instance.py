# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import instance_dispose_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.instance_dispose_response import InstanceDisposeResponse

__all__ = ["InstanceResource", "AsyncInstanceResource"]


class InstanceResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> InstanceResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/kaaass/opencode-sdk#accessing-raw-response-data-eg-headers
        """
        return InstanceResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> InstanceResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/kaaass/opencode-sdk#with_streaming_response
        """
        return InstanceResourceWithStreamingResponse(self)

    def dispose(
        self,
        *,
        directory: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InstanceDisposeResponse:
        """
        Clean up and dispose the current OpenCode instance, releasing all resources.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/instance/dispose",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"directory": directory}, instance_dispose_params.InstanceDisposeParams),
            ),
            cast_to=InstanceDisposeResponse,
        )


class AsyncInstanceResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncInstanceResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/kaaass/opencode-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncInstanceResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncInstanceResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/kaaass/opencode-sdk#with_streaming_response
        """
        return AsyncInstanceResourceWithStreamingResponse(self)

    async def dispose(
        self,
        *,
        directory: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> InstanceDisposeResponse:
        """
        Clean up and dispose the current OpenCode instance, releasing all resources.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/instance/dispose",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"directory": directory}, instance_dispose_params.InstanceDisposeParams
                ),
            ),
            cast_to=InstanceDisposeResponse,
        )


class InstanceResourceWithRawResponse:
    def __init__(self, instance: InstanceResource) -> None:
        self._instance = instance

        self.dispose = to_raw_response_wrapper(
            instance.dispose,
        )


class AsyncInstanceResourceWithRawResponse:
    def __init__(self, instance: AsyncInstanceResource) -> None:
        self._instance = instance

        self.dispose = async_to_raw_response_wrapper(
            instance.dispose,
        )


class InstanceResourceWithStreamingResponse:
    def __init__(self, instance: InstanceResource) -> None:
        self._instance = instance

        self.dispose = to_streamed_response_wrapper(
            instance.dispose,
        )


class AsyncInstanceResourceWithStreamingResponse:
    def __init__(self, instance: AsyncInstanceResource) -> None:
        self._instance = instance

        self.dispose = async_to_streamed_response_wrapper(
            instance.dispose,
        )
