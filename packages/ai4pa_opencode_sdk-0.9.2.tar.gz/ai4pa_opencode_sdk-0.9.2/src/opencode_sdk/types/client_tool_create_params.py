# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, TypedDict

__all__ = ["ClientToolCreateParams"]


class ClientToolCreateParams(TypedDict, total=False):
    id: Required[str]

    description: Required[str]

    parameters: Required[Dict[str, object]]

    directory: str
