# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["Session", "Time", "Revert", "Share", "Summary", "SummaryDiff"]


class Time(BaseModel):
    created: float

    updated: float

    archived: Optional[float] = None

    compacting: Optional[float] = None


class Revert(BaseModel):
    message_id: str = FieldInfo(alias="messageID")

    diff: Optional[str] = None

    part_id: Optional[str] = FieldInfo(alias="partID", default=None)

    snapshot: Optional[str] = None


class Share(BaseModel):
    url: str


class SummaryDiff(BaseModel):
    additions: float

    after: str

    before: str

    deletions: float

    file: str


class Summary(BaseModel):
    additions: float

    deletions: float

    files: float

    diffs: Optional[List[SummaryDiff]] = None


class Session(BaseModel):
    id: str

    directory: str

    project_id: str = FieldInfo(alias="projectID")

    time: Time

    title: str

    version: str

    parent_id: Optional[str] = FieldInfo(alias="parentID", default=None)

    revert: Optional[Revert] = None

    share: Optional[Share] = None

    summary: Optional[Summary] = None
