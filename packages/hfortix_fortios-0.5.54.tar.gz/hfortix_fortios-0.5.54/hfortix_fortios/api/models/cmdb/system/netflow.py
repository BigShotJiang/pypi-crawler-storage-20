"""
Pydantic Models for CMDB - system/netflow

Runtime validation models for system/netflow configuration.
Generated from FortiOS schema version unknown.
"""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator
from typing import Any, Literal, Optional

# ============================================================================
# Child Table Models
# ============================================================================

class NetflowExclusionFilters(BaseModel):
    """
    Child table model for exclusion-filters.
    
    Exclusion filters
    """
    
    class Config:
        """Pydantic model configuration."""
        extra = "allow"  # Allow additional fields from API
        str_strip_whitespace = True
    
    id: int = Field(ge=0, le=4294967295, default=0, description="Filter ID.")    
    source_ip: str | None = Field(default="", description="Session source address.")    
    destination_ip: str | None = Field(default="", description="Session destination address.")    
    source_port: str | None = Field(default="", description="Session source port number or range.")    
    destination_port: str | None = Field(default="", description="Session destination port number or range.")    
    protocol: int | None = Field(ge=0, le=255, default=255, description="Session IP protocol (0 - 255, default = 255, meaning any).")
class NetflowCollectors(BaseModel):
    """
    Child table model for collectors.
    
    Netflow collectors.
    """
    
    class Config:
        """Pydantic model configuration."""
        extra = "allow"  # Allow additional fields from API
        str_strip_whitespace = True
    
    id: int = Field(ge=1, le=6, default=0, description="ID.")    
    collector_ip: str = Field(max_length=63, default="", description="Collector IP.")    
    collector_port: int | None = Field(ge=0, le=65535, default=2055, description="NetFlow collector port number.")    
    source_ip: str | None = Field(max_length=63, default="", description="Source IP address for communication with the NetFlow agent.")    
    source_ip_interface: str | None = Field(max_length=15, default="", description="Name of the interface used to determine the source IP for exporting packets.")  # datasource: ['system.interface.name']    
    interface_select_method: Literal["auto", "sdwan", "specify"] | None = Field(default="auto", description="Specify how to select outgoing interface to reach server.")    
    interface: str = Field(max_length=15, default="", description="Specify outgoing interface to reach server.")  # datasource: ['system.interface.name']    
    vrf_select: int | None = Field(ge=0, le=511, default=0, description="VRF ID used for connection to server.")
# ============================================================================
# Enum Definitions (for fields with 4+ allowed values)
# ============================================================================


# ============================================================================
# Main Model
# ============================================================================

class NetflowModel(BaseModel):
    """
    Pydantic model for system/netflow configuration.
    
    Configure NetFlow.
    
    Validation Rules:        - active_flow_timeout: min=60 max=3600 pattern=        - inactive_flow_timeout: min=10 max=600 pattern=        - template_tx_timeout: min=60 max=86400 pattern=        - template_tx_counter: min=10 max=6000 pattern=        - session_cache_size: pattern=        - exclusion_filters: pattern=        - collectors: pattern=    """
    
    class Config:
        """Pydantic model configuration."""
        extra = "allow"  # Allow additional fields from API
        str_strip_whitespace = True
        validate_assignment = True  # Validate on attribute assignment
        use_enum_values = True  # Use enum values instead of names
    
    # ========================================================================
    # Model Fields
    # ========================================================================
    
    active_flow_timeout: int | None = Field(ge=60, le=3600, default=1800, description="Timeout to report active flows (60 - 3600 sec, default = 1800).")    
    inactive_flow_timeout: int | None = Field(ge=10, le=600, default=15, description="Timeout for periodic report of finished flows (10 - 600 sec, default = 15).")    
    template_tx_timeout: int | None = Field(ge=60, le=86400, default=1800, description="Timeout for periodic template flowset transmission (60 - 86400 sec, default = 1800).")    
    template_tx_counter: int | None = Field(ge=10, le=6000, default=20, description="Counter of flowset records before resending a template flowset record.")    
    session_cache_size: Literal["min", "default", "max"] | None = Field(default="default", description="Maximum RAM usage allowed for Netflow session cache.")    
    exclusion_filters: list[ExclusionFilters] = Field(default=None, description="Exclusion filters")    
    collectors: list[Collectors] = Field(default=None, description="Netflow collectors.")    
    # ========================================================================
    # Custom Validators
    # ========================================================================
    
    # ========================================================================
    # Helper Methods
    # ========================================================================
    
    def to_fortios_dict(self) -> dict[str, Any]:
        """
        Convert model to FortiOS API payload format.
        
        Returns:
            Dict suitable for POST/PUT operations
        """
        # Export with exclude_none to avoid sending null values
        return self.model_dump(exclude_none=True, by_alias=True)
    
    @classmethod
    def from_fortios_response(cls, data: dict[str, Any]) -> "":
        """
        Create model instance from FortiOS API response.
        
        Args:
            data: Response data from API
            
        Returns:
            Validated model instance
        """
        return cls(**data)
    # ========================================================================
    # Datasource Validation Methods
    # ========================================================================    
    async def validate_collectors_references(self, client: Any) -> list[str]:
        """
        Validate collectors references exist in FortiGate.
        
        This method checks if referenced objects exist by calling exists() on
        the appropriate API endpoints. This is an OPTIONAL validation step that
        can be called before posting to the API to catch reference errors early.
        
        Datasource endpoints checked:
        - system/interface        
        Args:
            client: FortiOS client instance (from fgt._client)
            
        Returns:
            List of validation error messages (empty if all valid)
            
        Example:
            >>> from hfortix_fortios import FortiOS
            >>> 
            >>> fgt = FortiOS(host="192.168.1.1", token="your-token")
            >>> policy = NetflowModel(
            ...     collectors=[{"interface": "invalid-name"}],
            ... )
            >>> 
            >>> # Validate before posting
            >>> errors = await policy.validate_collectors_references(fgt._client)
            >>> if errors:
            ...     print("Validation failed:", errors)
            ... else:
            ...     result = await fgt.api.cmdb.system.netflow.post(policy.to_fortios_dict())
        """
        errors = []
        
        # Validate child table items
        values = getattr(self, "collectors", [])
        if not values:
            return errors
        
        for item in values:
            if isinstance(item, dict):
                value = item.get("interface")
            else:
                value = getattr(item, "interface", None)
            
            if not value:
                continue
            
            # Check all datasource endpoints
            found = False
            if await client.api.cmdb.system.interface.exists(value):
                found = True
            
            if not found:
                errors.append(
                    f"Collectors '{value}' not found in "
                    "system/interface"
                )        
        return errors    
    async def validate_all_references(self, client: Any) -> list[str]:
        """
        Validate ALL datasource references in this model.
        
        Convenience method that runs all validate_*_references() methods
        and aggregates the results.
        
        Args:
            client: FortiOS client instance (from fgt._client)
            
        Returns:
            List of all validation errors found
            
        Example:
            >>> errors = await policy.validate_all_references(fgt._client)
            >>> if errors:
            ...     for error in errors:
            ...         print(f"  - {error}")
        """
        all_errors = []
        
        errors = await self.validate_collectors_references(client)
        all_errors.extend(errors)        
        return all_errors

# ============================================================================
# Type Aliases for Convenience
# ============================================================================

Dict = dict[str, Any]  # For backward compatibility

# ============================================================================
# Module Exports
# ============================================================================

__all__ = [
    "NetflowModel",    "NetflowExclusionFilters",    "NetflowCollectors",]


# ============================================================================
# Generated by hfortix generator v0.6.0
# Schema: 1.7.0
# Generated: 2026-01-10T08:58:10.964624Z
# ============================================================================