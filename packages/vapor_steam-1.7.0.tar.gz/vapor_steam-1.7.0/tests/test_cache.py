"""Tests related to caching."""

from __future__ import annotations

import io
import json
from datetime import datetime, timedelta

import pytest
from typing_extensions import Self

from vapor.cache_handler import Cache
from vapor.data_structures import AntiCheatData, AntiCheatStatus, Game


class BytesIOPath:
	"""A Path-like object that writes to a BytesIO object instead of the filesystem."""

	def __init__(self, bytes_io: io.BytesIO) -> None:
		"""Construct a BytesIOPath object."""
		self.bytes_io = bytes_io

	def read_text(self) -> str:
		"""Seek to 0 and return the reading of the BytesIO."""
		self.bytes_io.seek(0)
		return self.bytes_io.read().decode()

	def write_text(self, text: str) -> None:
		"""Write text to the BytesIO object."""
		self.bytes_io.seek(0)
		self.bytes_io.truncate()
		self.bytes_io.write(text.encode())

	def __enter__(self) -> Self:
		"""Return self."""
		return self

	def __exit__(self, exc_type, exc_value, traceback) -> None:
		"""Close the BytesIO object."""
		self.bytes_io.close()


@pytest.fixture
def cache() -> Cache:
	"""Fixture for the Cache object."""
	return Cache()


@pytest.fixture
def cache_data() -> dict:
	"""Fixture for getting the cache data."""
	return {
		'game_cache': {
			'123456': {
				'name': 'Game 1',
				'rating': 'gold',
				'playtime': 100,
				'timestamp': (datetime.now() - timedelta(days=8)).strftime(
					'%Y-%m-%d %H:%M:%S',
				),
			},
			'483': {
				'name': 'Game 2',
				'rating': 'platinum',
				'playtime': 100,
				'timestamp': (datetime.now() - timedelta(days=1)).strftime(
					'%Y-%m-%d %H:%M:%S',
				),
			},
		},
		'anticheat_cache': {
			'data': {'789012': 'Denied'},
			'timestamp': (datetime.now() - timedelta(days=8)).strftime(
				'%Y-%m-%d %H:%M:%S',
			),
		},
	}


def test_cache_properties_without_loading(cache: Cache) -> None:
	"""Test that Cache properties are correctly before cache has been loaded."""
	assert not cache.has_game_cache
	assert not cache.has_anticheat_cache


def test_load_cache(cache, cache_data) -> None:
	"""Test that the Cache loads data correctly."""
	with io.BytesIO(json.dumps(cache_data).encode()) as f:
		cache.cache_path = BytesIOPath(f)
		cache.load_cache(prune=False)

		assert cache.has_game_cache
		assert cache.has_anticheat_cache
		assert cache.get_game_data('123456') is not None
		assert cache.get_anticheat_data('789012') is not None
		assert cache.get_game_data('0') is None
		assert cache.get_anticheat_data('0') is None


def test_loading_bad_file(cache) -> None:
	"""Test that Cache behaves properly when a bad file is loaded."""
	cache.cache_path = ''

	cache_before = cache
	cache.load_cache(prune=False)

	assert cache == cache_before


def test_prune_bad_file(cache) -> None:
	"""Test that pruning a bad file doesn't crash."""
	cache.cache_path = ''

	cache_before = cache
	cache.prune_cache()

	assert cache == cache_before


def test_invalid_datetimes(cache, cache_data) -> None:
	"""Test that invalid datetimes are handled correctly."""
	cache_data['game_cache']['999'] = {
		'name': 'invalid datetime game',
		'rating': 'platinum',
		'playtime': 9,
		'timestamp': 'this is wrong',
	}

	cache_data['anticheat_cache']['timestamp'] = 'this is also wrong'

	with io.BytesIO(json.dumps(cache_data).encode()) as f:
		cache.cache_path = BytesIOPath(f)

		cache.prune_cache()

		f.seek(0)
		updated_data = json.loads(f.read())
		assert '999' not in updated_data['game_cache']
		assert 'anticheat_cache' not in updated_data


def test_update_cache(cache, cache_data) -> None:
	"""Test that cache updates are performed correctly."""
	with io.BytesIO(json.dumps(cache_data).encode()) as f:
		cache.cache_path = BytesIOPath(f)
		cache.update_cache(
			game_list=[
				Game(name='Game 3', rating='silver', playtime=200, app_id='654321'),
				Game(name='Game 2', rating='silver', playtime=200, app_id='483'),
			],
			anti_cheat_list=[
				AntiCheatData(app_id='987654', status=AntiCheatStatus.DENIED),
			],
		)

		f.seek(0)
		updated_data = json.loads(f.read())
		assert '654321' in updated_data['game_cache']
		assert '987654' in updated_data['anticheat_cache']['data']
		assert 'playtime' not in updated_data['game_cache']['654321']
		assert (
			updated_data['game_cache']['483']['timestamp']
			== cache_data['game_cache']['483']['timestamp']
		)


def test_prune_cache(cache, cache_data) -> None:
	"""Test that cache prunes are performed correctly."""
	with io.BytesIO(json.dumps(cache_data).encode()) as f:
		cache.cache_path = BytesIOPath(f)
		cache.load_cache(prune=True)

		f.seek(0)
		pruned_data = json.loads(f.read())

		assert '123456' not in pruned_data['game_cache']
		assert '483' in pruned_data['game_cache']

		assert 'anticheat_cache' not in pruned_data
