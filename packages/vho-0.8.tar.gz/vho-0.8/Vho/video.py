import torch
import random
import os
import imageio
from diffusers import AnimateDiffPipeline, DPMSolverMultistepScheduler, MotionAdapter
from deep_translator import GoogleTranslator

device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

TR_STYLE_MAP = {
    "gerçekçi": "realistic",
    "sinematik": "cinematic lighting",
    "anime": "anime style",
    "çizgi film": "cartoon style",
    "karanlık": "dark dramatic mood",
    "neon": "neon cyberpunk lighting",
    "portre": "portrait photography",
    "detaylı": "highly detailed",
    "fantastik": "fantasy art",
    "bilim kurgu": "science fiction",
    "minimal": "minimalist composition"
}

QUALITY_LOCK = (
    "masterpiece, ultra high quality, professional cinematic visuals, "
    "sharp focus, perfect lighting, high detail"
)

NEGATIVE_LOCK = (
    "worst quality, low quality, lowres, blurry, jpeg artifacts, "
    "bad anatomy, bad proportions, extra fingers, missing fingers, "
    "extra limbs, fused fingers, malformed hands, "
    "deformed face, asymmetrical face, cross eye, lazy eye, "
    "distorted body, mutated, ugly"
)

translator = GoogleTranslator(source="tr", target="en")

def _build_prompt(prompt_tr: str) -> str:
    translated = translator.translate(prompt_tr)
    prompt_lower = prompt_tr.lower()
    styles = []
    for tr, en in TR_STYLE_MAP.items():
        if tr in prompt_lower:
            styles.append(en)
    parts = [translated]
    if styles:
        parts.append(", ".join(styles))
    parts.append(QUALITY_LOCK)
    return ", ".join(parts)

_video_pipe = None

def _load_video_pipe():
    global _video_pipe
    if _video_pipe is not None:
        return _video_pipe
    motion_adapter = MotionAdapter.from_pretrained(
        "guoyww/animatediff-motion-adapter-v1-5",
        torch_dtype=dtype
    )
    pipe = AnimateDiffPipeline.from_pretrained(
        "runwayml/stable-diffusion-v1-5",
        motion_adapter=motion_adapter,
        torch_dtype=dtype,
        safety_checker=None
    ).to(device)
    pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
    pipe.enable_attention_slicing()
    _video_pipe = pipe
    return _video_pipe

def create_video(
    prompt: str,
    fps: int = 8,
    kalite: float = 7.5,
    cfg: float = 7.5,
    seed: int | None = None,
    filename: str = "vho1.mp4"
) -> str:
    NUM_FRAMES = 24
    if seed is None:
        seed = random.randint(0, 999999999)
    generator = torch.Generator(device=device).manual_seed(seed)
    steps = int(20 + (kalite * 2))
    final_prompt = _build_prompt(prompt)
    pipe = _load_video_pipe()
    frames = pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_LOCK,
        num_frames=NUM_FRAMES,
        num_inference_steps=steps,
        guidance_scale=float(cfg),
        generator=generator
    ).frames[0]
    imageio.mimsave(
        filename,
        frames,
        fps=fps,
        codec="libx264",
        quality=8
    )
    return os.path.abspath(filename)