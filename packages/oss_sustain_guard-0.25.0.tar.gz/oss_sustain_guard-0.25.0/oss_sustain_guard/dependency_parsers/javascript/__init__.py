"""JavaScript toolchain dependency parsers."""
