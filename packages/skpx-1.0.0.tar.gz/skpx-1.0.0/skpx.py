import argparse, requests, os, sys, time, subprocess, re

# YOUR ACTUAL FIREBASE LINK
BASE_URL = "https://skpx-9ac28-default-rtdb.firebaseio.com/scripts/"

class SKPX:
    def __init__(self):
        # ANSI Professional Colors
        self.c = {"p": "\033[38;5;135m", "g": "\033[38;5;82m", "r": "\033[38;5;196m", "c": "\033[38;5;51m", "b": "\033[1m", "0": "\033[0m"}
        self.tag = f"{self.c['b']}{self.c['p']}[SKPX]{self.c['0']}"

    def _install_deps(self, code):
        """Auto-detect and install required libraries"""
        deps = re.findall(r"^(?:import|from)\s+(\w+)", code, re.MULTILINE)
        ignore = sys.builtin_module_names
        needed = [d for d in set(deps) if d not in ignore and d not in sys.modules]
        if needed:
            print(f"{self.tag} {self.c['p']}Installing dependencies: {needed}...{self.c['0']}")
            subprocess.check_call([sys.executable, "-m", "pip", "install", *needed], stdout=subprocess.DEVNULL)

    def up(self, alias, path):
        if not os.path.exists(path):
            print(f"{self.c['r']}Error: File not found.{self.c['0']}"); return
        with open(path, "r", encoding="utf-8") as f:
            code = f.read()
        print(f"{self.tag} Uploading '{alias}' to Firebase...")
        payload = {"code": code, "size": len(code), "author": os.getlogin(), "time": time.time()}
        r = requests.put(f"{BASE_URL}{alias}.json", json=payload)
        if r.status_code == 200:
            print(f"{self.c['g']}✔ SUCCESSFULLY PUBLISHED! Others can run: 'skpx run {alias}'{self.c['0']}")

    def run(self, alias):
        print(f"{self.tag} Fetching '{alias}' from cloud...")
        r = requests.get(f"{BASE_URL}{alias}.json")
        data = r.json()
        if not data:
            print(f"{self.c['r']}Error: Script '{alias}' not found in your database.{self.c['0']}"); return
        
        # UI Progress Bar
        for i in range(1, 11):
            bar = '█' * (i*2) + '░' * (20 - i*2)
            sys.stdout.write(f"\r{self.tag} Loading: |{bar}| {i*10}%")
            sys.stdout.flush(); time.sleep(0.03)
        
        print(f"\n{self.c['c']}{'━'*50}{self.c['0']}")
        self._install_deps(data['code'])
        try:
            exec(data['code'], {"__name__": "__main__"})
        except Exception as e:
            print(f"{self.c['r']}Runtime Error: {e}{self.c['0']}")
        print(f"{self.c['c']}{'━'*50}{self.c['0']}")

    def ls(self):
        print(f"{self.tag} Scanning Cloud Registry...")
        r = requests.get(f"{BASE_URL}.json?shallow=true").json()
        if r:
            for k in r.keys(): print(f" {self.c['g']}•{self.c['0']} {k}")
        else: print("Database is empty.")

def main():
    engine = SKPX()
    parser = argparse.ArgumentParser(description="SKPX: Cloud Script Engine")
    sub = parser.add_subparsers(dest="cmd")
    for c in ["up", "run", "ls"]:
        p = sub.add_parser(c)
        if c != "ls": p.add_argument("name")
        if c == "up": p.add_argument("file")
    
    args = parser.parse_args()
    if args.cmd == "up": engine.up(args.name, args.file)
    elif args.cmd == "run": engine.run(args.name)
    elif args.cmd == "ls": engine.ls()
    else: parser.print_help()

if __name__ == "__main__":
    main()
