# SKPX 🚀
**SKPX** is a minimalist, ultra-lightweight global registry for Python scripts.

## Installation
```bash
pip install skpx
