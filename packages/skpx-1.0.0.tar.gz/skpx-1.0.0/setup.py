from setuptools import setup

setup(
    name="skpx",
    version="1.0.0",
    py_modules=["skpx"],
    install_requires=["requests"],
    entry_points={
        "console_scripts": [
            "skpx=skpx:main",
        ],
    },
)