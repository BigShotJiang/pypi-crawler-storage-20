"Matrix exponential using uniformization method"

import equinox as eqx
import jax
import jax.numpy as jnp
from beartype import beartype
from beartype.typing import Callable
from jax import lax, vmap
from jax.scipy.stats import poisson
from jaxtyping import Array, ArrayLike, Float, ScalarLike
from plum import dispatch


@dispatch
def expm_unif(
    t: ScalarLike,
    A: Callable[[Float[ArrayLike, "n"]], Float[ArrayLike, "n"]],
    v: Float[ArrayLike, "n"],
    alpha: ScalarLike,
    eps: float = 1e-6,
) -> Float[Array, "n"]:
    return expm_unif(jnp.atleast_1d(t), A, v, alpha, eps)[0]


@dispatch
def expm_unif(
    t: Float[ArrayLike, "t"],
    A: Callable[[Float[ArrayLike, "n"]], Float[ArrayLike, "n"]],
    v: Float[ArrayLike, "n"],
    alpha: ScalarLike,
    eps: float = 1e-6,
) -> Float[Array, "t n"]:
    """Compute matrix exponential via uniformization.

    Args:
        t: Time scalar.
        A: Function that computes action A @ v, where A is an intensity matrix
              (i.e., a generator matrix of a CTMC)
        v: Vector to be multiplied.
        alpha: max(abs(diag(A)))
        eps: Tolerance for the uniformization method.

    Returns:
        expm(t*A) @ v: Matrix exponential applied to vector v.

    Notes:
        This implements Algorithm 1 of "INEXACT UNIFORMIZATION METHOD FOR COMPUTING
        TRANSIENT DISTRIBUTIONS OF MARKOV CHAINS", Sidje et al., SIAM J. Sci. Comput.,
        2007, with a few modifications for numerical stability.
    """

    def P(v):
        # P = I + A / alpha
        return v + A(v) / alpha

    THETA = 100.0
    m = jnp.ceil(alpha * t / THETA).astype(int)
    m0 = jnp.isclose(m, 0.0)
    msafe = jnp.where(m0, 1, m)
    t = jnp.where(m0, 0.0, t / msafe)

    ell = lax.while_loop(
        lambda ell: poisson.cdf(ell, alpha * t.max()) < 1 - eps,
        lambda ell: ell + 1,
        0,
    )

    M = m.max()

    def f(t):
        s = alpha * t
        # beta_0 = e^{-lambda}
        beta0 = jnp.exp(-s)

        def body2(k, state):
            w, f_vec, beta = state
            beta = beta * (s / k)  # beta_k = beta_{k-1} * s/k
            f_vec = P(f_vec)  # apply P once
            w = w + beta * f_vec  # accumulate beta_k * P^k v
            # f_vec = eqx.error_if(f_vec, jnp.abs(f_vec).max() > 1.0, "Overflow in expm_unif")
            # w = eqx.error_if(w, jnp.abs(w).max() > 1e10, "Overflow in expm_unif")
            return (w, f_vec, beta)

        def body1(i, w):
            # start from current state w; we want exp(tQ) w
            # g_0 = beta0 * w
            w_scaled0 = beta0 * w
            # f_vec_0 = w (this will be transformed by P)
            w_scaled, _, _ = lax.fori_loop(
                1,
                ell + 1,
                body2,
                (w_scaled0, w, beta0),
            )
            # w_scaled = eqx.error_if(w_scaled, jnp.abs(w_scaled).max() > 1e10, "Overflow in expm_unif")
            # jax.debug.print("Intermediate result at step {}/{}: {}", i, M, w_scaled)
            return w_scaled

        return lax.fori_loop(1, M + 1, body1, v)

    return vmap(f)(t)
