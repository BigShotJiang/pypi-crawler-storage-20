import os
from functools import singledispatch

import jax
import jax.numpy as jnp
import numpy as np
from beartype import beartype
from jax.experimental.sparse import BCOO
from jaxtyping import Array, ArrayLike, Float, Int, ScalarLike
from plum import dispatch

from .expm_unif import expm_unif


@dispatch
def expm_multiply(
    Q: Float[ArrayLike, "n n"],
    t: Float[ArrayLike, "t"],
    v: Float[ArrayLike, "n"],
) -> Float[Array, "t n"]:
    """Compute the action of the matrix exponential on a vector.

    This is a generic function that is specialized for different types
    of matrix representations.

    Args:
        Q: 2D array representing the matrix Q. The matrix is assumed to be square and
           have non-negative off-diagonal entries (i.e., the generator of a CTMC).
        t: Scalar multiplier for the matrix Q in the exponential.
        v: 1D array representing the vector to be multiplied.

    Returns:
        The result of exp(t*Q) @ v.
    """
    return _expm_multiply_dense(Q, t, v)


@dispatch
def expm_multiply(
    Q: Float[ArrayLike, "n n"],
    t: ScalarLike,
    v: Float[ArrayLike, "n"],
) -> Float[Array, "n"]:
    return _expm_multiply_dense(Q, jnp.atleast_1d(t), v)[0]


@dispatch
def expm_multiply(
    coo: tuple[Float[ArrayLike, "nnz"], Int[ArrayLike, "nnz 2"]],
    t: Float[ArrayLike, "t"],
    v: Float[ArrayLike, "n"],
) -> Float[Array, "t n"]:
    return _expm_multiply_sparse(coo, t, v)


@dispatch
def expm_multiply(
    coo: tuple[Float[ArrayLike, "nnz"], Int[ArrayLike, "nnz 2"]],
    t: ScalarLike,
    v: Float[ArrayLike, "n"],
) -> Float[Array, "n"]:
    return expm_multiply(coo, jnp.atleast_1d(t), v)[0]


@dispatch
def expm_multiply(
    Q: BCOO, t: Float[ArrayLike, "t"], v: Float[ArrayLike, "n"]
) -> Float[ArrayLike, "t n"]:
    return expm_multiply((Q.data, Q.indices), t, v)


@dispatch
def expm_multiply(
    Q: BCOO, t: ScalarLike, v: Float[ArrayLike, "n"]
) -> Float[ArrayLike, "n"]:
    return expm_multiply((Q.data, Q.indices), jnp.atleast_1d(t), v)[0]


@jax.custom_vjp
@beartype
def _expm_multiply_dense(
    Q: Float[ArrayLike, "n n"],
    t: Float[ArrayLike, "t"],
    v: Float[ArrayLike, "n"],
) -> Float[Array, "t n"]:
    """Compute the action of the matrix exponential on a vector.

    This function computes exp(t*Q) @ v where Q is a dense matrix.

    Args:
        Q: 2D array representing the matrix Q.
        t: Scalar multiplier for the matrix Q in the exponential.
        v: 1D array representing the vector to be multiplied.
    Returns:
        The result of exp(t*Q) @ v.
    """
    n = v.shape[0]
    alpha = (-jnp.diag(Q)).max()
    return expm_unif(t, Q.__matmul__, v, alpha)


def _expm_multiply_fwd(Q_or_coo, t, v):
    y = expm_multiply(Q_or_coo, t, v)
    return y, (Q_or_coo, t, v, y)


def _expm_multiply_dense_bwd(res, gs):
    Q, ts, v, ys = res
    t_bar, v_bar = _expm_multiply_bwd_base(res, gs)

    m = int(os.environ.get("EXPM_UNIF_QUAD_NODES", 8))
    xi, wts = gauss_legendre_0_1(m)

    @jax.vmap
    def cot(t, g):
        s_nodes = t * xi
        # dQ = ∫ ψ(s) φ(s)^T ds
        # phi(s) = e^{sQ}v
        # psi(s) = e^{(t-s)Q^T}u
        phi = expm_multiply(Q, s_nodes, v)  # (m, n)
        psi = expm_multiply(Q.T, t - s_nodes, g)  # (m, n)

        # gradient w.r.t. Q = ∫ ψ(s) φ(s)^T ds
        return t * jnp.einsum("m,mi,mj->ij", wts, psi, phi)

    Q_bar = cot(ts, gs).sum(axis=0)

    return Q_bar, t_bar, v_bar


_expm_multiply_dense.defvjp(_expm_multiply_fwd, _expm_multiply_dense_bwd)


@jax.custom_vjp
@beartype
def _expm_multiply_sparse(
    coo: tuple[Float[ArrayLike, "nnz"], Int[ArrayLike, "nnz 2"]],
    t: Float[ArrayLike, "t"],
    v: Float[ArrayLike, "n"],
) -> Float[Array, "t n"]:
    """Compute the action of the matrix exponential of a sparse matrix on a vector.

    This function computes exp(t*A) @ v where A is a sparse matrix represented
    in coordinate (COO) format by its non-zero values and their coordinates.

    Args:
        data: 1D array of non-zero values of the sparse matrix A.
        indices: 2D array of shape (2, nnz) where nnz is the number
                             of non-zero entries. The first row contains row indices
                             and the second row contains column indices.
        t: Scalar multiplier for the matrix A in the exponential.
        v: 1D array representing the vector to be multiplied.

    Returns:
        The result of exp(t*A) @ v.
    """
    n = v.shape[0]
    Q = BCOO(coo, shape=(n, n))
    data, indices = coo

    # compute alpha = max(abs(diag(Q))) accounting for
    # possible duplicate entries in COO format
    x, y = indices.T
    s = jnp.abs(data) * (x == y)
    M = jax.ops.segment_sum(s, x, n)
    alpha = M.max()
    return expm_unif(t, Q.__matmul__, v, alpha)


def _expm_multiply_bwd_base(res, gs):
    Q, ts, v, ys = res

    # 1. Cotangent w.r.t. v
    Z = jax.vmap(lambda t, g: expm_multiply(Q.T, t, g))(ts, gs)
    v_bar = Z.sum(axis=0)

    # 2. Cotangent w.r.t. t
    t_bar = jnp.einsum("tn,tn->t", gs, (Q @ ys.T).T)

    return t_bar, v_bar


def _expm_multiply_sparse_bwd(res, gs):
    (data, indices), ts, v, ys = res
    n = v.shape[0]
    Q = BCOO((data, indices), shape=(n, n))
    t_bar, v_bar = _expm_multiply_bwd_base((Q, ts, v, ys), gs)

    m = int(os.environ.get("EXPM_UNIF_QUAD_NODES", 8))
    xi, wts = gauss_legendre_0_1(m)

    @jax.vmap
    def cot(t, g):
        s_nodes = t * xi
        # phi(s) = e^{sQ}v
        # psi(s) = e^{(t-s)Q^T}u
        phi = expm_multiply(Q, s_nodes, v)  # (m, n)
        psi = expm_multiply(Q.T, t - s_nodes, g)  # (m, n)

        i = indices[:, 0]
        j = indices[:, 1]
        psi_i = psi[:, i]  # (m, E)
        phi_j = phi[:, j]  # (m, E)

        # gradient w.r.t. each data_k = ∫ ψ_i(s) φ_j(s) ds
        return t * (wts[:, None] * (psi_i * phi_j)).sum(axis=0)  # (E,)

    data_bar = cot(ts, gs).sum(axis=0)

    # No gradient w.r.t. indices (integer)
    return ((data_bar, None), t_bar, v_bar)


_expm_multiply_sparse.defvjp(_expm_multiply_fwd, _expm_multiply_sparse_bwd)


def gauss_legendre_0_1(m: int = 6):
    xs, ws = np.polynomial.legendre.leggauss(m)
    xi = 0.5 * (xs + 1.0)
    w = 0.5 * ws
    return xi, w
