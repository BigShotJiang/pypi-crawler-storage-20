"""
Tests para cpcontest
"""