"""Natural Payments MCP server using FastMCP.

Provides tools for AI agents to interact with Natural's payment APIs.
No AI/LLM dependencies - agents fill structured parameters directly.
"""

from __future__ import annotations

from typing import Literal

from fastmcp import FastMCP

from naturalpay.client import NaturalClient


def create_server(api_key: str | None = None, server_url: str | None = None) -> FastMCP:
    """Create a Natural Payments MCP server.

    Args:
        api_key: API key (defaults to NATURAL_API_KEY env var)
        server_url: Server URL (defaults to NATURAL_SERVER_URL env var)

    Returns:
        Configured FastMCP server instance
    """
    mcp = FastMCP("Natural Payments")

    # Lazy client initialization
    _client: NaturalClient | None = None

    def get_client() -> NaturalClient:
        nonlocal _client
        if _client is None:
            _client = NaturalClient(api_key=api_key, base_url=server_url)
        return _client

    # =========================================================================
    # PAYMENT TOOLS
    # =========================================================================

    @mcp.tool()
    async def create_payment(
        amount: float,
        agent_id: str,
        customer_party_id: str,
        recipient_email: str | None = None,
        recipient_phone: str | None = None,
        currency: str = "USD",
        memo: str | None = None,
    ) -> dict:
        """Send a payment to a recipient.

        Either recipient_email or recipient_phone must be provided.

        Args:
            amount: Payment amount (e.g., 50.00)
            agent_id: Agent ID making the payment (agt_xxx)
            customer_party_id: Customer party ID on whose behalf (pty_xxx)
            recipient_email: Recipient's email address
            recipient_phone: Recipient's phone number
            currency: Currency code (default: USD)
            memo: Payment description/memo

        Returns:
            Payment result with transfer_id, status, amount, etc.
        """
        if not recipient_email and not recipient_phone:
            raise ValueError("Either recipient_email or recipient_phone is required")

        client = get_client()
        result = await client.payments.create(
            recipient_email=recipient_email,
            recipient_phone=recipient_phone,
            amount=amount,
            currency=currency,
            memo=memo,
            agent_id=agent_id,
            customer_party_id=customer_party_id,
        )
        return result.model_dump(exclude_none=True)

    @mcp.tool()
    async def get_payment_status(transfer_id: str) -> dict:
        """Get the status of a payment by transfer ID.

        Args:
            transfer_id: The transfer ID returned from send_payment

        Returns:
            Payment details including status, amount, recipient, timestamps
        """
        client = get_client()
        result = await client.payments.retrieve(transfer_id)
        return result.model_dump(exclude_none=True)

    @mcp.tool()
    async def cancel_payment(transfer_id: str) -> dict:
        """Cancel a pending payment.

        Only pending payments can be cancelled. Completed or processing
        payments cannot be reversed.

        Args:
            transfer_id: The transfer ID to cancel

        Returns:
            Cancellation result with status and message
        """
        client = get_client()
        result = await client.payments.cancel(transfer_id)
        return result.model_dump()

    # =========================================================================
    # WALLET TOOLS
    # =========================================================================

    @mcp.tool()
    async def get_account_balance() -> dict:
        """Get the current wallet balance.

        Returns:
            Wallet balance with available amount and breakdown by account type
        """
        client = get_client()
        result = await client.account.balance()
        return {
            "wallet_id": result.wallet_id,
            "available_usd": result.available_usd,
            "balances": [
                {
                    "asset_code": bal.asset_code,
                    "available": bal.available.amount_dollars,
                    "breakdown": {
                        "operating_funded": bal.breakdown.operating_funded.amount_dollars,
                        "operating_advanced": bal.breakdown.operating_advanced.amount_dollars,
                        "escrow_funded_settled": bal.breakdown.escrow_funded_settled.amount_dollars,
                        "escrow_advanced": bal.breakdown.escrow_advanced.amount_dollars,
                        "holds_outbound": bal.breakdown.holds_outbound.amount_dollars,
                    },
                }
                for bal in result.balances
            ],
        }

    @mcp.tool()
    async def list_transactions(
        limit: int = 10,
        agent_id: str | None = None,
        customer_party_id: str | None = None,
        customer_filter: str | None = None,
    ) -> list[dict]:
        """List recent transactions.

        For full functionality, provide agent_id and customer_party_id
        to establish agent context for accessing delegated transactions.

        Args:
            limit: Maximum number of transactions (default: 10, max: 100)
            agent_id: Agent ID for agent-context authentication
            customer_party_id: Customer party ID when acting on behalf of customer
            customer_filter: Filter by customer agent_id (or '_self' for partner only)

        Returns:
            List of transactions with details
        """
        client = get_client()
        results = await client.transactions.list(
            limit=limit,
            customer_filter=customer_filter,
            agent_id=agent_id,
            customer_party_id=customer_party_id,
        )
        return [tx.model_dump(exclude_none=True) for tx in results]

    # =========================================================================
    # AGENT TOOLS
    # =========================================================================

    @mcp.tool()
    async def list_agents(
        status: str | None = None,
        limit: int = 50,
    ) -> dict:
        """List agents for the partner.

        Args:
            status: Filter by status (ACTIVE or REVOKED)
            limit: Maximum number of agents (default: 50, max: 100)

        Returns:
            List of agents with their details
        """
        client = get_client()
        result = await client.agents.list(status=status, limit=limit)
        return result.model_dump(exclude_none=True)

    return mcp


def serve(
    transport: Literal["stdio", "sse", "streamable-http"] = "stdio",
    *,
    host: str = "127.0.0.1",
    port: int = 8080,
    api_key: str | None = None,
    server_url: str | None = None,
) -> None:
    """Run the Natural Payments MCP server.

    Args:
        transport: Transport type (stdio, sse, streamable-http)
        host: Host to bind to (for HTTP transports)
        port: Port to bind to (for HTTP transports)
        api_key: API key (defaults to NATURAL_API_KEY env var)
        server_url: Server URL (defaults to NATURAL_SERVER_URL env var)
    """
    mcp = create_server(api_key=api_key, server_url=server_url)

    if transport == "stdio":
        mcp.run()
    elif transport == "sse":
        mcp.run(transport="sse", host=host, port=port)
    elif transport == "streamable-http":
        mcp.run(transport="streamable-http", host=host, port=port)
    else:
        raise ValueError(f"Unknown transport: {transport}")
