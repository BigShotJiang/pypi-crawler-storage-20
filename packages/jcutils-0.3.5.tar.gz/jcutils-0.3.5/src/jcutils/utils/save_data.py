"""
Created on 2017/11/22 0022 17:31
@author: lijc210@163.com
Desc:
"""

import codecs
import csv
from typing import Any, List, Optional


def to_csv(save_file: str = "", data_list: Optional[List[List[Any]]] = None) -> None:
    """
    将数据列表保存到CSV文件中

    :param save_file: 要保存的CSV文件路径
    :param data_list: 要写入的数据列表，二维列表
    :return: None
    """
    if data_list is None:
        data_list = []

    with codecs.open(save_file, "wb", "GB18030") as csvfile:
        spamwriter: csv.writer = csv.writer(csvfile, dialect="excel")
        spamwriter.writerows(data_list)


if __name__ == "__main__":
    data_list: List[List[Any]] = [["id", "name"], [1, "张三"], [2, "李四"]]
    to_csv(save_file="test.csv", data_list=data_list)
