"""
@author: lijc210@163.com
@file: ftp_client.py
@time: 2020/05/22
@desc: FTP客户端工具类，提供FTP文件传输功能
"""

from ftplib import FTP
from typing import List, Optional


class FtpClient:
    """
    FTP客户端类，封装了常用的FTP操作

    提供以下功能：
    - 连接到FTP服务器
    - 列出目录中的文件
    - 从服务器下载文件
    - 上传文件到服务器
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
    ) -> None:
        """
        初始化FTP客户端

        :param host: FTP服务器地址
        :param port: FTP服务器端口，默认21
        :param username: 登录用户名
        :param password: 登录密码
        """
        self.host: Optional[str] = host
        self.port: Optional[int] = port
        self.username: Optional[str] = username
        self.password: Optional[str] = password
        self.ftp: FTP = self.connect()

    def connect(self) -> FTP:
        """
        连接到FTP服务器

        :return: FTP连接对象
        :raises ConnectionRefusedError: 当连接失败时抛出
        :raises Exception: 当登录失败时抛出
        """
        ftp: FTP = FTP()
        # 打开调试级别2，显示详细信息
        # ftp.set_debuglevel(2)
        if self.host and self.port:
            ftp.connect(self.host, self.port)
            if self.username and self.password:
                ftp.login(self.username, self.password)
        return ftp

    def nlst(self) -> List[str]:
        """
        返回当前目录下的文件和文件夹列表

        :return: 文件和文件夹名称列表
        """
        return self.ftp.nlst()

    def download(self, remote_path: Optional[str] = None, local_path: Optional[str] = None) -> None:
        """
        从FTP服务器下载文件

        :param remote_path: 服务器上的文件路径
        :param local_path: 本地保存路径
        :raises FileNotFoundError: 当远程文件不存在时抛出
        :raises Exception: 当下载失败时抛出
        """
        if not remote_path or not local_path:
            raise ValueError("remote_path 和 local_path 不能为空")

        # 设置的缓冲区大小
        bufsize: int = 1024
        fp: object = open(local_path, "wb")
        try:
            self.ftp.retrbinary("RETR " + remote_path, fp.write, bufsize)  # type: ignore
        finally:
            self.ftp.set_debuglevel(0)  # 参数为0，关闭调试模式
            fp.close()

    def upload(self, local_path: Optional[str] = None, remote_path: Optional[str] = None) -> None:
        """
        上传文件到FTP服务器

        :param local_path: 本地文件路径
        :param remote_path: 服务器保存路径
        :raises FileNotFoundError: 当本地文件不存在时抛出
        :raises Exception: 当上传失败时抛出
        """
        if not local_path or not remote_path:
            raise ValueError("local_path 和 remote_path 不能为空")

        bufsize: int = 1024
        fp: object = open(local_path, "rb")
        try:
            self.ftp.storbinary("STOR " + remote_path, fp, bufsize)  # type: ignore
        finally:
            self.ftp.set_debuglevel(0)
            fp.close()

    def mkdir(self, dirname: str) -> None:
        """
        在服务器上创建目录

        :param dirname: 目录名称
        """
        self.ftp.mkd(dirname)

    def rmdir(self, dirname: str) -> None:
        """
        删除服务器上的目录（目录必须为空）

        :param dirname: 目录名称
        """
        self.ftp.rmd(dirname)

    def delete(self, filename: str) -> None:
        """
        删除服务器上的文件

        :param filename: 文件名称
        """
        self.ftp.delete(filename)

    def rename(self, from_name: str, to_name: str) -> None:
        """
        重命名服务器上的文件或目录

        :param from_name: 原名称
        :param to_name: 新名称
        """
        self.ftp.rename(from_name, to_name)

    def size(self, filename: str) -> int:
        """
        获取服务器上文件的大小

        :param filename: 文件名称
        :return: 文件大小（字节）
        """
        return self.ftp.size(filename)

    def cwd(self, dirname: str) -> None:
        """
        切换服务器上的当前工作目录

        :param dirname: 目录名称
        """
        self.ftp.cwd(dirname)

    def pwd(self) -> str:
        """
        获取服务器上的当前工作目录路径

        :return: 当前工作目录路径
        """
        return self.ftp.pwd()

    def close(self) -> None:
        """
        关闭FTP连接
        """
        try:
            self.ftp.quit()
        except Exception:
            # 如果quit失败，尝试关闭连接
            try:
                self.ftp.close()
            except Exception:
                pass

    def __enter__(self) -> "FtpClient":
        """
        上下文管理器入口，支持with语句

        :return: 自身
        """
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        """
        上下文管理器退出，自动关闭连接
        """
        self.close()


if __name__ == "__main__":
    # 使用示例
    try:
        # ##### 连接（使用上下文管理器）
        with FtpClient(host="127.0.0.1", port=21, username="anonymous", password="anonymous@") as ftp_client:
            # ##### 列出文件
            print("=== 文件列表 ===")
            files: List[str] = ftp_client.nlst()
            for f in files:
                print(f"- {f}")

            # ##### 获取当前目录
            print(f"\n当前目录: {ftp_client.pwd()}")

            # ##### 上传文件
            print("\n=== 上传文件 ===")
            # ftp_client.upload("local_file.txt", "remote_file.txt")
            print("上传文件: local_file.txt -> remote_file.txt")

            # ##### 下载文件
            print("\n=== 下载文件 ===")
            # ftp_client.download("remote_file.txt", "local_file.txt")
            print("下载文件: remote_file.txt -> local_file.txt")

            # ##### 获取文件大小
            print(f"\n文件大小: {ftp_client.size('remote_file.txt')} 字节")

            # ##### 重命名文件
            # ftp_client.rename("remote_file.txt", "renamed_file.txt")
            print("重命名文件: remote_file.txt -> renamed_file.txt")

        # 连接会在退出with块时自动关闭
        print("\nFTP连接已关闭")

    except Exception as e:
        print(f"发生错误: {e}")
