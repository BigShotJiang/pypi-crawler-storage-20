"""
@File    :   geapi.py
@Time    :   2021/01/23 18:41:53
@Author  :   lijc210@163.com
@Desc    :   高德地图地理编码API工具
             根据地址获取经纬度坐标
             用于批量处理地址转换
"""

import sys
from typing import Any, Dict, Iterator, List, Optional, Tuple

import requests

georegeo_url = "https://restapi.amap.com/v3/geocode/geo?parameters"
key = "ec67ff42f93e2088681011e54edf688d"


def api_geocode(address: str, city: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    根据地址获取地理编码信息（正向地理编码）

    :param address: 要查询的地址，如 "文昌市白龙白龙建材城"
    :param city: 可选，指定查询的城市，如 "文昌市"
    :return: 高德地图 API 返回的地理编码信息字典，查询失败返回 None
             返回数据结构示例：
             {
                 "formatted_address": "海南省文昌市...",
                 "country": "中国",
                 "province": "海南省",
                 "citycode": "0898",
                 "adcode": "469005",
                 "location": "110.877513,19.611765",
                 "level": "兴趣点",
                 "status": 1,
                 ...
             }
    """
    try:
        resp = requests.get(georegeo_url, params={"key": key, "address": address, "city": city})
        assert resp.status_code == 200
        rel_json: Dict[str, Any] = resp.json()
        assert rel_json["status"] == "1" and rel_json["info"] == "OK"
        rel_array: List[Dict[str, Any]] = rel_json["geocodes"]
        assert len(rel_array) > 0
        rel: Dict[str, Any] = rel_array[0]
        rel["status"] = 1
        return rel
    except Exception:
        # traceback.print_exc()
        return None


def req_gaode(address: str, city: Optional[str] = None) -> Tuple[str, str]:
    """
    根据地址获取经纬度坐标

    :param address: 要查询的地址
    :param city: 可选，指定查询的城市
    :return: 包含经度和纬度的元组 (经度, 纬度)，失败返回 ("-1", "-1")
    """
    try:
        resp_rel: Optional[Dict[str, Any]] = api_geocode(city=city, address=address) or {}

        location: Optional[str] = resp_rel.get("location")
        if location and len(location.split(",")) == 2:
            lng, lat = [float(it) for it in location.split(",")]
            return str(lng), str(lat)
        else:
            return "-1", "-1"
    except Exception:
        return "-1", "-1"


def read_input(file: Any) -> Iterator[List[str]]:
    """
    从文件中逐行读取输入数据

    :param file: 文件对象（如 sys.stdin）
    :yield: 分割后的行数据列表，第一列为ID，第二列为地址
    """
    for line in file:
        if line and line.strip():  # 略过空行
            yield line.rstrip().split("\t")


def main() -> None:
    """
    主函数，从标准输入读取地址并输出对应的经纬度

    输入格式：每行包含ID和地址（tab 分隔）
    输出格式：每行输出ID、经度和纬度（\001 分隔）
    """
    data: Iterator[List[str]] = read_input(sys.stdin)
    for line in data:
        if len(line) >= 2:
            zx_need_id: str = line[0]
            address: str = line[1]
            lng, lat = req_gaode(address)
            print(str(zx_need_id) + "\001" + "\001".join([lng, lat]))


if __name__ == "__main__":
    # 交互式测试
    print("=== 测试地理编码API功能 ===")

    # 测试单个地址
    test_address = "文昌市白龙白龙建材城"
    print(f"\n查询地址: {test_address}")
    result: Optional[Dict[str, Any]] = api_geocode(test_address)
    if result:
        print(f"查询结果: {result}")
    else:
        print("查询失败")

    # 测试获取坐标
    print(f"\n获取坐标: {test_address}")
    lng, lat = req_gaode(test_address)
    print(f"经度: {lng}, 纬度: {lat}")

    # 测试多个地址
    test_addresses = [
        "北京市天安门",
        "上海市东方明珠",
        "广州市塔",
        "深圳市市民中心",
    ]

    print("\n=== 批量测试 ===")
    for addr in test_addresses:
        lng, lat = req_gaode(addr)
        print(f"{addr}: 经度={lng}, 纬度={lat}")

    # 测试指定城市
    print("\n=== 测试指定城市 ===")
    result_with_city: Optional[Dict[str, Any]] = api_geocode("白龙白龙建材城", city="文昌市")
    if result_with_city:
        print(f"指定城市查询结果: {result_with_city}")
    else:
        print("指定城市查询失败")

    # 测试批量处理模式（模拟标准输入）
    print("\n=== 测试批量处理模式 ===")
    import io

    test_input = "001\t北京市天安门\n002\t上海市东方明珠\n003\t广州市塔\n"
    test_file = io.StringIO(test_input)

    print("输入数据:")
    print(test_input)

    print("输出结果:")
    for line in read_input(test_file):
        if len(line) >= 2:
            zx_need_id = line[0]
            address = line[1]
            lng, lat = req_gaode(address)
            print(f"{zx_need_id}\001{lng}\001{lat}")

    # 注意：取消下面的注释来运行批量处理模式
    # main()
    # print(req_gaode('文昌市白龙白龙建材城'))
