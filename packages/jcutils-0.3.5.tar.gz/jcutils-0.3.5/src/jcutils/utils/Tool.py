"""
@Time   : 2018/12/14
@author : lijc210@163.com
@Desc:  : 功能描述 - 工具类和装饰器集合
"""

import logging
import platform
import signal
from contextlib import contextmanager
from functools import wraps
from logging.handlers import TimedRotatingFileHandler
from typing import Any, Callable, Generator, Optional, Type, TypeVar

T = TypeVar("T")


def retry(
    num: int = 0, ex: Type[BaseException] = BaseException, is_raise: bool = True, ex_def: Any = None
) -> Callable[[Callable[..., T]], Callable[..., Optional[T]]]:
    """
    报错自动重试装饰器

    :param num: 重试次数
    :param ex: 指定要捕获的异常类型
    :param is_raise: 重试后是否抛出异常
    :param ex_def: 重试指定次数后还是异常时的默认返回值
    :return: 装饰器函数
    """

    def decorator(func: Callable[..., T]) -> Callable[..., Optional[T]]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Optional[T]:
            result: Optional[T] = None
            for _i in range(0, num + 1):
                try:
                    result = func(*args, **kwargs)
                except BaseException as e:
                    result = e  # type: ignore
                if not isinstance(result, ex):
                    break

            if isinstance(result, BaseException):
                if is_raise:
                    raise result
                else:
                    return ex_def
            else:
                return result

        return wrapper

    return decorator


def use_platform() -> str:
    """
    获取当前平台类型

    :return: 平台标识符，"win"表示Windows，"linux"表示Linux，"other"表示其他
    """
    sysstr: str = platform.system()
    if sysstr == "Windows":
        return "win"
    elif sysstr == "Linux":
        return "linux"
    else:
        return "other"


class CheloExtendedLogger(logging.Logger):
    """
    自定义日志记录器类，扩展了标准logger功能

    自动根据平台配置日志文件路径，支持控制台和文件双重输出
    """

    def __init__(self, name: str) -> None:
        """
        初始化自定义日志记录器

        :param name: 日志记录器名称
        """
        logging.Logger.__init__(self, name, logging.INFO)

        formatter: logging.Formatter = logging.Formatter("%(asctime)s [%(filename)s,%(lineno)d] %(message)s")
        platform_sys: str = use_platform()
        log_file_path: str
        if platform_sys == "win":
            log_file_path = r"D:\weibo\log\%s.log" % name
        else:
            log_file_path = "/var/log/%s.log" % name
        fh: TimedRotatingFileHandler = TimedRotatingFileHandler(
            log_file_path, when="midnight", encoding="utf-8"
        )  # 用于输出到文件
        fh.setFormatter(formatter)
        self.addHandler(fh)  # 用于输出到文件

        hdr: logging.StreamHandler = logging.StreamHandler()  # 用于输出到控制台
        hdr.setFormatter(formatter)
        self.addHandler(hdr)  # 用于输出到控制台


class TimeoutException(Exception):
    """
    超时异常类

    当代码执行时间超过指定限制时抛出此异常
    """

    pass


@contextmanager
def time_limit(seconds: int) -> Generator[None, None, None]:
    """
    上下文管理器，用于限制代码块的执行时间

    使用Unix信号机制实现超时控制，在Unix/Linux系统上可用

    :param seconds: 超时时间（秒）
    :yields: None
    :raises TimeoutException: 当代码执行超过指定时间限制时抛出
    :raises NotImplementedError: 在不支持SIGALRM的平台上（如Windows）
    """

    def signal_handler(signum: int, frame: Any) -> None:
        raise TimeoutException("Timed out!")

    try:
        signal.signal(signal.SIGALRM, signal_handler)
        signal.alarm(seconds)
        yield
    finally:
        signal.alarm(0)


if __name__ == "__main__":
    # 测试retry装饰器
    count = 0

    @retry(num=3, ex=ValueError, is_raise=False, ex_def="failed")
    def test_retry() -> str:
        global count
        count += 1
        print(f"尝试次数: {count}")
        if count < 3:
            raise ValueError("测试异常")
        return "success"

    result = test_retry()
    print(f"重试结果: {result}")

    # 测试use_platform
    print(f"当前平台: {use_platform()}")

    # 测试CheloExtendedLogger
    logger = CheloExtendedLogger("test_logger")
    logger.info("这是一条测试日志")

    # 测试time_limit上下文管理器（仅在Unix/Linux上有效）
    import sys

    if sys.platform != "win32":
        try:
            with time_limit(1):
                print("代码执行中...")
                import time

                time.sleep(0.5)
                print("代码执行完成！")
        except TimeoutException:
            print("代码执行超时！")
