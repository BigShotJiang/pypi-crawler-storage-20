    Gary Oberbrunner (13):
          Make release workflow wait for CI to pass
          Add comprehensive User Guide documentation
          Add multi-toolchain support for mixed-language builds
          Add Windows resource compiler support for MSVC toolchain
          Enable MSVC in CI for Windows resource compiler tests
          Add cross-platform support for C examples and MSVC archiver fix
          Add clang-cl toolchain and simplify cross-platform defaults
          Enable concat example on Windows
          Add support for assembly and Metal shader source files
          Add AuxiliaryInputHandler for .def file support on Windows
          Add CHANGELOG.md documenting changes since v0.1.2
          Release v0.1.3
          Unify CI and release into single workflow

