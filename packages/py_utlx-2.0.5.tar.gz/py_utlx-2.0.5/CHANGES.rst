Changelog
=========

2.0.5 (2026-01-10)
------------------
- utlx.platform.*.capi  - added in_addr_t
- utlx.platform.windows - added winapi
- utlx.platform.macos   - added macos_version()
- utlx.platform.windows.winapi - added OpenProcessToken(),
  GetTokenInformation()
- run(): cleanup and improvements.
- Much better typing.
- Some minor cleanup and unifications.
- Version number alignment (-> 2.x.x).
- Copyright year update.
- The documentation has been moved from Read the Docs to GitHub Pages.
- Added the 'tool.tox.env.cleanup' test environment.
- Setup update (mainly dependencies) and bug fixes.

1.0.0 (2025-09-09)
------------------
- Making and mark the package typed.
- 100% code linting.
- 100% code coverage.
- Setup update (mainly dependencies).

0.1.0 (2025-09-01)
------------------
- First public release.

0.0.0 (2025-07-17)
------------------
- Initial commit.
