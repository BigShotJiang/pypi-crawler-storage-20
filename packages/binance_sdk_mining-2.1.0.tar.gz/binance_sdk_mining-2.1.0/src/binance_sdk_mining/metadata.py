NAME = "binance-sdk-mining"
