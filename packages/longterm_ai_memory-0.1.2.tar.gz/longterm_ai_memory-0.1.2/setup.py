from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="longterm_ai_memory",
    version="0.1.2",
    author="Omkar Patil",
    author_email="omkar1344patil@gmail.com",
    description="Semantic memory layer for AI applications with vector storage and LLM-based extraction",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/omkar1344patil/longterm_ai_memory",
    packages=find_packages(),
    install_requires=[
        "pinecone>=8.0.0",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0"
    ],
    python_requires=">=3.8",
)