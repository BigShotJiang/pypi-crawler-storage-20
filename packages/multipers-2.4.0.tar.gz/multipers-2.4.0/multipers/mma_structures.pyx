




"""!
@package mma
@brief Files containing the C++ cythonized functions.
@author David Loiseaux
@copyright Copyright (c) 2022 Inria.
"""

# distutils: language = c++

###########################################################################
## PYTHON LIBRARIES
import gudhi as gd
import numpy as np
from typing import Union, Literal
from collections.abc import Callable, Iterable, Sequence
import pickle
import multipers.grids as mpg

###########################################################################
## CPP CLASSES
from libc.stdint cimport intptr_t
from libc.stdint cimport uintptr_t

###########################################################################
## CYTHON TYPES
from libcpp.vector cimport vector
from libcpp.utility cimport pair
#from libcpp.list cimport list as clist
from libcpp cimport bool
from libcpp cimport int
from cython.operator cimport dereference
from libcpp.utility cimport move
cimport cython
#########################################################################
## Multipersistence Module Approximation Classes
from multipers.mma_structures cimport *
from multipers.filtration_conversions cimport *
cimport numpy as cnp


#########################################################################
## Small hack for typing
from gudhi import SimplexTree
from multipers.simplex_tree_multi import SimplexTreeMulti
from joblib import Parallel, delayed

available_pymodules = [
    PyModule_f64,
    PyModule_f32,
    PyModule_i32,
    PyModule_i64,
]

PyModule_type = Union[
    PyModule_f64,
    PyModule_f32,
    PyModule_i32,
    PyModule_i64,
]
cdef class PySummand_f64:
    r"""
    Stores a Summand of a PyModule
    """
    cdef Summand[double] sum

    def get_birth_list(self): 
        cdef vector[One_critical_filtration[double]] v = self.sum.get_birth_list()
        return _vff21cview_f64(v, copy = True)

    def get_death_list(self):
        cdef vector[One_critical_filtration[double]] v = self.sum.get_death_list()
        return _vff21cview_f64(v, copy = True)
    @property
    def degree(self)->int:
        return self.sum.get_dimension()

    cdef set(self, Summand[double]& summand):
        self.sum = summand
        return self
    def get_bounds(self):
        cdef pair[vector[double],vector[double]] cbounds
        with nogil:
            cbounds = self.sum.get_bounds().get_bounding_corners()
        # return _ff21cview_f64(&cbounds.first).copy(), _ff21cview_f64(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    @property
    def dtype(self):
      return np.float64

    def num_parameters(self):
        cdef vector[One_critical_filtration[double]] v = self.sum.get_birth_list()
        if v[0].is_finite():
            return v[0].num_parameters()
        v = self.sum.get_death_list()
        return v[0].num_parameters()
    def __eq__(self, PySummand_f64 other):
        return self.sum == other.sum 




cdef inline get_summand_filtration_values_f64(Summand[double] summand):
    r"""
    Returns a list (over parameter) of the filtrations values of this parameter.
    """
    cdef vector[One_critical_filtration[double]] vb = summand.get_birth_list()
    cdef vector[One_critical_filtration[double]] vd = summand.get_death_list()

    if vb[0].is_finite():
        if vd[0].is_finite():
            pts = np.concatenate([_vff21cview_f64(vb, copy=True),
                                  _vff21cview_f64(vd, copy=True)],axis=0)
        else:
            pts = np.array(_vff21cview_f64(vb, copy=True))
    else:
        if vd[0].is_finite():
            pts = np.array(_vff21cview_f64(vd, copy=True))
        else:
            return []
    
    num_parameters = pts.shape[1]
    out = [np.unique(pts[:,parameter]) for parameter in range(num_parameters)]
    out = [f[:-1] if len(f)>0 and f[-1] == np.inf else f for f in out]
    out = [f[1:]  if len(f)>0 and f[0] == -np.inf else f for f in out]
    return out

cdef class PyBox_f64:
    cdef Box[double] box
    def __cinit__(self, vector[double]& bottomCorner, vector[double]& topCorner):
        self.box = Box[double](bottomCorner, topCorner)
    @property
    def num_parameters(self):
        cdef size_t dim = self.box.get_lower_corner().size()
        if dim == self.box.get_upper_corner().size():	return dim
        else:	print("Bad box definition.")
    def contains(self, x):
        return self.box.contains(x)
    cdef set(self, Box[double]& b):
        self.box = b
        return self

    def get(self):
        return [<vector[double]>self.box.get_lower_corner(), <vector[double]>self.box.get_upper_corner()]
    def to_multipers(self):
        #assert (self.get_dimension() == 2) "Multipers only works in dimension  2 !"
        return np.array(self.get()).flatten(order = 'F')
    @property
    def dtype(self):
      return np.float64



cdef class PyModule_f64:
    r"""
    Stores a representation of a n-persistence module.
    """
    cdef Module[double] cmod
    
    @property
    def dtype(self):
        return np.float64

    cdef set(self, Module[double] m):
        self.cmod = m

    def __eq__(self, PyModule_f64 other):
        return self.cmod == other.cmod

    def merge(self, PyModule_f64 other, int dim=-1):
        r"""
        Merges two modules into one
        """
        cdef Module[double] c_other = other.cmod
        with nogil:
            for summand in c_other:
                self.cmod.add_summand(summand, dim)
        return self
    def _add_mmas(self, mmas):
        for mma in mmas:
            self.merge(mma)
        return self

    def permute_summands(self, permutation):
        cdef int[:] c_perm = np.asarray(permutation, dtype=np.int32) 
        other = PyModule_f64()
        other.cmod = self.cmod.permute_summands(permutation)
        return other

    def _set_from_ptr(self, intptr_t module_ptr):
        r"""
        Copy module from a memory pointer. Unsafe.
        """
        self.cmod = move(dereference(<Module[double]*>(module_ptr)))
    def _get_ptr(self):
        cdef intptr_t ptr = <intptr_t>(&self.cmod)
        return ptr
    def set_box(self, box):
        assert len(box) == 2, "Box format is [low, hight]"
        pybox = PyBox_f64(box[0], box[1])
        cdef Box[double] cbox = pybox.box
        with nogil:
            self.cmod.set_box(cbox)
        return self
    def get_module_of_degree(self, int degree)->PyModule_f64: # TODO : in c++ ?
        r"""
        Returns a copy of a module of fixed degree.
        """
        pmodule = PyModule_f64()
        cdef Box[double] c_box = self.cmod.get_box()
        with nogil:
            pmodule.cmod.set_box(c_box) 
            for summand in self.cmod:
                if summand.get_dimension() == degree:
                    pmodule.cmod.add_summand(summand)
        return pmodule
    def get_module_of_degrees(self, degrees:Iterable[int])->PyModule_f64: # TODO : in c++ ?
        r"""
        Returns a copy of the summands of degrees in `degrees`
        """
        pmodule = PyModule_f64()
        cdef Box[double] c_box = self.cmod.get_box()
        pmodule.cmod.set_box(c_box)
        cdef vector[int] cdegrees = degrees
        with nogil:
            for summand in self.cmod:
                for d in cdegrees:
                    if d == summand.get_dimension():
                        pmodule.cmod.add_summand(summand)
        return pmodule
    def __len__(self)->int:
        return self.cmod.size()
    def get_bottom(self)->np.ndarray:
        r"""
        Bottom of the box of the module
        """
        return np.asarray(<vector[double]>(self.cmod.get_box().get_lower_corner()))
    def get_top(self)->np.ndarray:
        r"""
        Top of the box of the module
        """
        return np.asarray(<vector[double]>(self.cmod.get_box().get_upper_corner()))
    def get_box(self)->np.ndarray:
        r"""
        Returns the current bounding box of the module.
        """
        return np.asarray([self.get_bottom(), self.get_top()])
    @property
    def max_degree(self)->int:
        r"""
        Returns the maximum degree of the module.
        """
        return self.cmod.get_dimension()
    @property
    def num_parameters(self)->int:
        cdef size_t dim = self.cmod.get_box().get_lower_corner().size()
        assert dim == self.cmod.get_box().get_upper_corner().size(), "Bad box definition, cannot infer num_parameters."
        return dim
    def dump(self, path:str|None=None):
        r"""
        Dumps the module into a pickle-able format.

        Parameters
        ----------

        path:str=None (optional) saves the pickled module in specified path

        Returns
        -------
        
        list of list, encoding the module, which can be retrieved with the function `from_dump`.
        """
        ## TODO : optimize, but not really used.
        return dump_cmod_f64(self.cmod) 
    def __getstate__(self):
        return self.dump()
    def __setstate__(self,dump):
        cdef Module[double] cmod = cmod_from_dump_f64(dump)
        self.cmod = cmod
        return
    def __getitem__(self, int i) -> PySummand_f64:
        if i == slice(None):
            return self
        summand = PySummand_f64()
        summand.set(self.cmod.at(i % self.cmod.size()))
        return summand
    def __iter__(self):
        cdef int num_summands = self.cmod.size()
        for i in range(num_summands):
            summand = PySummand_f64()
            summand.set(self.cmod.at(i)) ## hmm copy. maybe do summand from ptr
            yield summand

    def get_bounds(self):
        r"""
        Computes bounds from the summands' bounds.
        Useful to change this' box.
        """
        cdef pair[vector[double],vector[double]] cbounds
        with nogil:
            cbounds = self.cmod.get_bounds().get_bounding_corners()
        # return _ff21cview_f64(&cbounds.first).copy(), _ff21cview_f64(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    def rescale(self,rescale_factors, int degree=-1):
        r"""
        Rescales the fitlration values of the summands by this rescaling vector.
        """
        cdef vector[double] crescale_factors = rescale_factors
        with nogil:
            self.cmod.rescale(crescale_factors,degree)
    def translate(self,translation, int degree=-1):
        r"""
        Translates the module in the filtration space by this vector.
        """
        cdef vector[double] ctranslation = translation
        with nogil:
            self.cmod.translate(ctranslation,degree)

    def get_filtration_values(self, bool unique=True):
        r"""
        Retrieves all filtration values of the summands of the module.

        Output format 
        -------------

        list of filtration values for parameter.
        """
        if len(self) ==0:
            return np.empty((self.num_parameters,0))
        values = tuple(
                tuple(stuff) 
                if len(stuff:=get_summand_filtration_values_f64(summand)) == self.num_parameters else list(stuff) + [[]]*(self.num_parameters - len(stuff)) for summand in self.cmod)
        try:
          values = tuple(np.concatenate([
            f[parameter]
            for f in values
            ], axis=0) for parameter in range(self.num_parameters)
          )
        except:
          return values
        if unique:
            return [np.unique(f) for f in values]
        return values

    def plot(self, int degree=-1,**kwargs)->None:
        r"""Shows the module on a plot. Each color corresponds to an apprimation summand of the module, and its shape corresponds to its support.
        Only works with 2-parameter modules.

        Parameters
        ----------
        degree = -1 : integer
            If positive returns only the image of dimension `dimension`.
        box=None : of the form [[b_x,b_y], [d_x,d_y]] where b,d are the bottom and top corner of the rectangle.
            If non-None, will plot the module on this specific rectangle.
        min_persistence =0 : float
            Only plots the summand with a persistence above this threshold.
        separated=False : bool
            If true, plot each summand in a different plot.
        alpha=1 : float
            Transparancy parameter
        save = False : string
            if nontrivial, will save the figure at this path


        Returns
        -------
        The figure of the plot.
        """
        from multipers.plots import plot2d_PyModule
        import matplotlib.pyplot as plt
        box = kwargs.pop('box', self.get_box())
        if (len(box[0]) != 2):
            print("Filtration size :", len(box[0]), " != 2")
            return
        if(degree < 0):
            dims = np.unique(self.get_dimensions())
            separated = kwargs.pop("separated", False)
            ndim = len(dims)
            scale = kwargs.pop("scale", 4)
            if separated:
                fig = None
                axes = None
            elif ndim > 1:
              fig, axes = plt.subplots(1,ndim, figsize=(ndim*scale,scale))
            else:
              fig = plt.gcf()
              axes = [plt.gca()]
            for dim_idx in range(ndim):
                if not separated:
                    plt.sca(axes[dim_idx])
                self.plot(dims[dim_idx],box=box, separated = separated, **kwargs)
            return
        corners = self.cmod.get_corners_of_dimension(degree)
        interleavings = self.get_module_of_degree(degree).get_interleavings()
        plot2d_PyModule(corners, box=box, dimension=degree, interleavings = interleavings, **kwargs)
        return
    def degree_splits(self):
        return np.asarray(self.cmod.get_degree_splits(), dtype=np.int64)
    def evaluate_in_grid(self, grid):
        grid = mpg.sanitize_grid(grid, numpyfy=True)
        cdef size_t num_parameters = len(grid)
        if num_parameters != self.num_parameters:
            raise ValueError(f"Invalid grid size. Got {len(grid)=} != {self.num_parameters=}")
        cdef vector[vector[double]] cgrid = vector[vector[double]](num_parameters)
        for i in range(num_parameters):
            cgrid[i] = grid[i]
        self.cmod.evaluate_in_grid(cgrid)
        return self
        


    def _compute_pixels(self,coordinates:np.ndarray,
                                         degrees=None, box=None, double delta=.1, 
                                         double p=1., bool normalize=False, int n_jobs=0):
        r"""
        Computes the image of the module at the given coordinates
        """
        if degrees is not None: assert np.all(degrees[:-1] <= degrees[1:]), "Degrees have to be sorted"
        cdef vector[int] cdegrees = np.arange(self.max_degree +1) if degrees is None else degrees
        pybox = PyBox_f64(*self.get_box()) if box is None else PyBox_f64(*box)
        cdef Box[double] cbox = pybox.box
        cdef vector[vector[double]] ccoords = coordinates
        cdef vector[vector[double]] out 
        with nogil:
            out = self.cmod.compute_pixels(ccoords, cdegrees, cbox, delta, p, normalize, n_jobs)
        return np.asarray(out)
    def barcode(self, basepoint, int degree = -1,*, bool threshold = False): # TODO direction vector interface
        r"""Computes the barcode of module along a lines.

        Parameters
        ----------
        
        basepoint  : vector
            basepoint of the lines on which to compute the barcodes, i.e. a point on the line
        degree = -1 : integer
            Homology degree on which to compute the bars. If negative, every dimension is computed
        box (default) :
            box on which to compute the barcodes if basepoints is not specified. Default is a linspace of lines crossing that box.
        threshold = False : 
            Thre

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be plot-able.

        Returns
        -------
        
        PyMultiDiagrams
            Structure that holds the barcodes. Barcodes can be retrieved with a .get_points() or a .to_multipers() or a .plot().
        """
        out = PyMultiDiagram_f64()
        out.set(self.cmod.get_barcode(Line[double](_py2p_f64(np.asarray(basepoint, dtype=np.float64))), degree, threshold))
        return out
    @staticmethod
    cdef _threshold_bc(bc): 
        return tuple(np.fromiter((a for a in stuff if a[0] < np.inf),  dtype=np.dtype((np.float64,2)) ) for stuff in bc)
    @staticmethod
    def _bc_to_full(bcs, basepoint, direction=None):
        # i, (b sv d), coords 
        basepoint = np.asarray(basepoint)[None,None,:]
        direction = 1 if direction is None else np.asarray(direction)[None,None,:]
        return tuple(bc[:,:,None]*direction + basepoint for bc in bcs)
    def barcode2(self, basepoint, direction=None, int degree = -1,*, bool threshold = False, bool keep_inf = True, bool full = False): # TODO direction vector interface
        r"""
        Compute the 1d-barcode a diagonal line based on basepoint, with some direction.
        
        Parameters
        ----------

         - basepoint: 1d array
         - directiont: 1d array or None, if None: diagonal
         - degree: int the degree to compute (-1 means all)
         - threshold: bool if True, threshold the barcode to the modules box
         - keep_inf: bool if False, removes trivial bars
                     Note that this removes the order w.r.t. the summands in that case
         - full:bool if True, returns the coordinates of the barcode instead of the coordinate in the line.

        The output is of the form

        tuple[np.ndarray of shape (num_bars,2)] or tuple[array of shape (num_bar, 2, num_parameters)]
        """
        basepoint = np.asarray(basepoint, dtype=np.float64)
        if direction is None:
            bc = tuple(np.asarray(x).reshape(-1,2) for x in self.cmod.get_barcode2(Line[double](_py2p_f64(basepoint)), degree))
        else:
            direction = np.asarray(direction, dtype = np.float64)
            bc = tuple(np.asarray(x).reshape(-1,2) for x in self.cmod.get_barcode2(Line[double](_py2p_f64(basepoint), _py2p_f64(direction)), degree))
        if not keep_inf:
            bc = PyModule_f64._threshold_bc(bc)
        if full:
            bc = PyModule_f64._bc_to_full(bc, basepoint, direction)

        return bc

    def get_dimensions(self):
        cdef int num_summands =  len(self)
        out = np.empty(shape=num_summands, dtype=np.int32)
        cdef int32_t[:] c_out = out
        for i in range(num_summands):
            c_out[i] = self.cmod.at(i).get_dimension()
        return out

    def barcodes(self, int degree, basepoints = None, num=100, box = None,threshold = False):
        r"""Computes barcodes of module along a set of lines.

        Parameters
        ----------
        
        basepoints = None : list of vectors
            basepoints of the lines on which to compute the barcodes.
        degree = -1 : integer
            Homology degree on which to compute the bars. If negative, every dimension is computed
        box (default) :
            box on which to compute the barcodes if basepoints is not specified. Default is a linspace of lines crossing that box.
        num:int=100
            if basepoints is not specified, defines the number of lines to consider.
        threshold = False : threshold t
            Resolution of the image(s).

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be plot-able.

        Returns
        -------
        
        PyMultiDiagrams
            Structure that holds the barcodes. Barcodes can be retrieved with a .get_points() or a .to_multipers() or a .plot().
        """
        out = PyMultiDiagrams_f64()
        if box is None:
            box = [self.get_bottom(), self.get_top()]
        if (len(box[0]) != 2) and (basepoints is None):
            raise ValueError("Basepoints has to be specified for filtration dimension >= 3 !")
        elif basepoints is None:
            h = box[1][1] - box[0][1]
            basepoints = np.linspace([box[0][0] - h,box[0][1]], [box[1][0],box[0][1]], num=num) 
        else :
            num=len(basepoints)

        cdef double[:,:] basepoints_view = np.asarray(basepoints, dtype = np.float64)
        cdef vector[Point[double]] cbasepoints = _py2vp_f64(basepoints_view)

        out.set(self.cmod.get_barcodes(cbasepoints, degree, threshold))
        return out

    def barcodes2(self, int degree = -1, basepoints = None, int num=100, box = None, bool threshold = False):
        r"""Computes barcodes of module along a set of lines.

        Parameters
        ----------

        basepoints = None : list of vectors
            basepoints of the lines on which to compute the barcodes.
        degree = -1 : integer
            Homology degree on which to compute the bars. If negative, every dimension is computed
        box (default) :
            box on which to compute the barcodes if basepoints is not specified. Default is a linspace of lines crossing that box.
        num:int=100
            if basepoints is not specified, defines the number of lines to consider.
        threshold = False : threshold t
            Resolution of the image(s).

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be plot-able.

        Returns
        -------
        
        tuple of 1d barcodes, based on basepoint, with direction (1,1)
        """
        if box is None:
            box = [self.get_bottom(), self.get_top()]
        if (len(box[0]) != 2) and (basepoints is None):
            raise ValueError("Basepoints has to be specified for filtration dimension >= 3 !")
        elif basepoints is None:
            h = box[1][1] - box[0][1]
            basepoints = np.linspace([box[0][0] - h,box[0][1]], [box[1][0],box[0][1]], num=num) 
        else :
            num=len(basepoints)

        basepoints = np.asarray(basepoints, dtype=np.float64)
        cdef vector[Line[double]] cbasepoints
        for i in range(num):
            cbasepoints.push_back(Line[double](_py2p_f64(basepoints[i])))
        return tuple(np.asarray(bc) for bc in self.cmod.get_barcodes2(cbasepoints, degree))   

    def landscape(self, degree:int, k:int=0,box:Sequence|np.ndarray|None=None, resolution:Sequence=[100,100], bool plot=False):
        r"""Computes the multiparameter landscape from a PyModule. Python interface only bifiltrations.

        Parameters
        ----------

        degree : integer
            The homology degree of the landscape.
        k = 0 : int
            the k-th landscape
        resolution = [50,50] : pair of integers
            Resolution of the image.
        box = None : in the format [[a,b], [c,d]]
            If nontrivial, compute the landscape of this box. Default is the PyModule box.
        plot = True : Boolean
            If true, plots the images;
        Returns
        -------
        
        The landscape of the module.

        """
        import matplotlib.pyplot as plt
        if box is None:
            box = self.get_box()
        cdef Box[double] c_box = Box[double](box)
        out = np.array(self.cmod.get_landscape(degree, k, c_box, resolution))
        if plot:
            aspect = (box[1][0]-box[0][0]) / (box[1][1]-box[0][1])
            extent = [box[0][0], box[1][0], box[0][1], box[1][1]]
            plt.imshow(out.T, origin="lower", extent=extent, aspect=aspect)
        return out

    def landscapes(self, degree:int, ks:list|np.ndarray=[0],box=None, resolution:list|np.ndarray=[100,100], bool plot=False):
        r"""Computes the multiparameter landscape from a PyModule. Python interface only bifiltrations.

        Parameters
        ----------
        
         - degree : integer
            The homology degree of the landscape.
         - ks = 0 : list of int
            the k-th landscape
         - resolution = [50,50] : pair of integers
            Resolution of the image.
         - box = None : in the format [[a,b], [c,d]]
            If nontrivial, compute the landscape of this box. Default is the PyModule box.
         - plot = True : bool
            If true, plots the images;
        Returns
        -------
        
        The landscapes of the module with parameters ks.

        """
        import matplotlib.pyplot as plt
        if box is None:
            box = self.get_box()
        out = np.array(self.cmod.get_landscapes(degree, ks, Box[double](box), resolution))
        if plot:
            to_plot = np.sum(out, axis=0)
            aspect = (box[1][0]-box[0][0]) / (box[1][1]-box[0][1])
            extent = [box[0][0], box[1][0], box[0][1], box[1][1]]
            plt.imshow(to_plot.T, origin="lower", extent=extent, aspect=aspect)
        return out


    def representation(self, degrees=None, double bandwidth=0.1,
            resolution:Sequence[int]|int=50, 
            kernel:Literal["gaussian","linear","linear2","exponential"]|Callable = "gaussian",
            bool signed=False,
            bool normalize=False, bool plot=False, 
            bool save=False, int dpi=200,double p=2., box=None, 
            bool flatten=False, int n_jobs=0,
            grid = None)->np.ndarray:
        r"""Computes a representation of the module, using 

        [A Framework for Fast and Stable Representations of Multiparameter Persistent Homology Decompositions, Neurips2023]

        Parameters
        ----------
        
         - degrees = None : integer list
            If given returns only the image(s) of homology degrees `degrees`.
         - bandwidth = 0.1 : float
            Image parameter. 
         - resolution = [100,100] : pair of integers
            Resolution of the image(s).
         - normalize = True : Boolean
            Ensures that the image belongs to [0,1].
         - plot = False : Boolean
            If true, plots the images;
         - flatten=False :
            If True, reshapes the output to a flattened shape.
         - kernel: Either linear, gaussian, or callable
           The kernel to apply to the matrix $(d(x,I), x \in \mathrm{pixels}, I\in \mathrm{summands})$.
           signature should be : (distance matrix, summand_weights, bandwidth, p) -> representation

        Returns
        -------
        
        The list of images, or the image of fixed dimension.
        """
        import matplotlib.pyplot as plt
        # box = kwargs.get("box",[self.get_bottom(),self.get_top()])
        if box is None:
            box = self.get_box()
        num_parameters = self.num_parameters
        if degrees is None:
            degrees = np.arange(self.max_degree +1)
        num_degrees = len(degrees)
        try:
            int(resolution)
            resolution = [resolution]*num_parameters
        except:
            pass

        if grid is None:
            grid = [np.linspace(*np.asarray(box)[:,parameter], num=res) for parameter, res in zip(range(num_parameters), resolution)]
        else:
            resolution = tuple(len(g) for g in grid)
        coordinates = mpg.todense(grid)

        if kernel == "linear":
            assert not signed, "This kernel is not compatible with signed."
            concatenated_images = self._compute_pixels(coordinates, degrees=degrees, box=box, delta=bandwidth, p=p, normalize=normalize,n_jobs=n_jobs)
        else:
            if kernel == "linear2":
                def todo(PyModule_f64 mod_degree):
                  x = mod_degree.distance_to(coordinates,signed=signed)
                  w = mod_degree.get_interleavings()[None]**p
                  s = np.where(x>=0,1,-1) if signed else 1 
                  x = np.abs(x)
                  return (s*np.where(x<bandwidth,(bandwidth-x)/bandwidth,0)*w).sum(1)
            elif kernel == "gaussian":
                def todo(PyModule_f64 mod_degree):
                  x = mod_degree.distance_to(coordinates,signed=signed)
                  w = mod_degree.get_interleavings()[None]**p
                  s = np.where(x>=0,1,-1) if signed else 1 
                  return (s*np.exp( -.5*((x/bandwidth)**2))*w).sum(1)
            elif kernel == "exponential":
                def todo(PyModule_f64 mod_degree):
                  x = mod_degree.distance_to(coordinates,signed=signed)
                  w = mod_degree.get_interleavings()[None]**p
                  s = np.where(x>=0,1,-1) if signed else 1 
                  x = np.abs(x)
                  return (s*np.exp( -((np.abs(x)/bandwidth)))*w).sum(1)
            else:
                assert callable(kernel), r"""
                    Kernel should be 
                    gaussian, linear, linear2, exponential or callable,
                    with signature
                     (array[shape=(N, M)], array[shape=(M)])-> array(shape=(N)),
                    the first argument being a distance matrix (pts) vs (summands of the module)
                    and the second argument is a weight vector (weight(summand) for summand in module).
                    Note that the distance can be signed.
                    """
                def todo(PyModule_f64 mod_degree):
                      x = mod_degree.distance_to(coordinates,signed=signed, n_jobs=n_jobs)
                      w = mod_degree.get_interleavings()[None]**p
                      return kernel(x/bandwidth,w)
            concatenated_images = np.stack(
                Parallel(n_jobs = n_jobs if n_jobs else -1, backend= "threading")(
                  delayed(todo)(self.get_module_of_degree(degree))
                  for degree in degrees
                )
              )

        if flatten:
            image_vector = concatenated_images.reshape((len(degrees),-1))
            if plot:
                raise ValueError("Unflatten to plot.")
            return image_vector
        else:
            image_vector = concatenated_images.reshape((len(degrees),*resolution))
        if plot:
            assert num_parameters == 2, "Plot only available for 2-parameter modules"
            import multipers.plots
            i=0
            n_plots = len(image_vector)
            scale = 4
            if n_plots >1:
              fig, axs = plt.subplots(1,n_plots, figsize=(n_plots*scale,scale))
            else:
              fig = plt.gcf()
              axs = [plt.gca()]
            for image, degree, i in zip(image_vector, degrees, range(num_degrees)):
                ax = axs[i]
                temp = multipers.plots.plot_surface(grid, image, ax=ax)
                plt.colorbar(temp, ax = ax)
                if degree < 0 :
                    ax.set_title(rf"$H_{i}$ $2$-persistence image")
                if degree >= 0:
                    ax.set_title(rf"$H_{degree}$ $2$-persistence image")
        return image_vector

    def euler_char(self, points:list|np.ndarray) -> np.ndarray:
        r""" Computes the Euler Characteristic of the filtered complex at given (multiparameter) time

        Parameters
        ----------
        
        points: list[float] | list[list[float]] | np.ndarray
            List of filtration values on which to compute the euler characteristic.
            WARNING FIXME : the points have to have the same dimension as the simplextree.	

        Returns
        -------
        
        The list of euler characteristic values
        """
        if len(points) == 0:
            return []
        if type(points[0]) is float:
            points = [points]
        if type(points) is np.ndarray:
            assert len(points.shape) in [1,2]
            if len(points.shape) == 1:
                points = [points]

        cdef double[:,:] points_view = np.asarray(points, dtype = np.float64)
        cdef vector[One_critical_filtration[double]] c_points = _py2v1c_f64(points_view)
        # cdef One_critical_filtration temp
        # for point in points:
        #     temp.clear()
        #     for truc in point:
        #         temp.push_back(<double>(truc))
        #     c_points.push_back(temp)
        cdef Module[double] c_mod = self.cmod
        with nogil:
            c_euler = c_mod.euler_curve(c_points)
        euler = c_euler
        return np.asarray(euler, dtype=int)
    def to_idx(self,grid):
        cdef vector[vector[double]] cgrid = grid
        cdef vector[vector[pair[vector[vector[int]],vector[vector[int]]]]] out
        with nogil:
            out = self.cmod.to_idx(cgrid)
        return tuple(tuple((np.asarray(I.first,dtype=np.int64), np.asarray(I.second, dtype=np.int64)) for I in Is_of_degree) for Is_of_degree in out)
    
    @cython.wraparound(False)
    @cython.boundscheck(False)
    def to_flat_idx(self,grid):
        if len(self) == 0:
            return np.empty((2,0), dtype = np.int32), np.empty((0, self.num_parameters), dtype = np.int32),  np.empty((0, self.num_parameters), dtype = np.int32)
        cdef vector[vector[double]] cgrid = grid
        cdef vector[vector[vector[int]]] out
        cdef int num_summands, num_births, num_deaths
        cdef int num_parameters = self.num_parameters
        with nogil:
            out = self.cmod.to_flat_idx(cgrid)
            num_summands = out[0][0].size()
            num_births = out[1].size()
            num_deaths = out[2].size()
        idx = np.empty((2, num_summands),dtype=np.int32 )
        births = np.empty((num_births,num_parameters),dtype=np.int32)
        deaths = np.empty((num_deaths,num_parameters),dtype=np.int32)

        cdef int32_t[:,:] idx_view = idx
        cdef int32_t[:,:] births_view = births
        cdef int32_t[:,:] deaths_view = deaths

        with nogil:
            for i in range(num_summands):
                idx_view[0,i] = out[0][0][i]
                idx_view[1,i] = out[0][1][i]
            for i in range(num_births):
                for j in range(num_parameters):
                    births_view[i,j] = out[1][i][j]
            for i in range(num_deaths):
                for j in range(num_parameters):
                    deaths_view[i,j] = out[2][i][j]

        return idx, births,deaths

    def distances_idx_to(self, pts, bool full=False, int n_jobs=1):
        pts = np.asarray(pts)
        if pts.ndim == 1:
            pts = pts[None]
        cdef vector[vector[double]] cpts = pts
        cdef vector[vector[vector[int]]] out
        with nogil:
            out = self.cmod.compute_distances_idx_to(cpts,full, n_jobs)
        return np.asarray(out, dtype=np.int32)

    def distance_to(self, pts, bool signed=False, int n_jobs = 0)->np.ndarray:
        r"""
        Distance from a point to each summand's support. 
        Signed distance is the distance to the boundary,
        with negative values inside the summands.

        pts of shape (num_pts, num_parameters)

        output shape : (num_pts,num_summands)
        """
        pts = np.asarray(pts)
        if pts.ndim == 1:
            pts = pts[None]
        assert pts.shape[-1] == self.num_parameters
        cdef vector[vector[double]] cpts = pts
        # cdef vector[vector[double]] out
        to_fill = np.empty(shape=(cpts.size(),len(self)), dtype = np.float64)
        cdef double[:,:] c_to_fill = to_fill
        cdef double* data_ptr = &c_to_fill[0,0]
        with nogil:
            self.cmod.compute_distances_to(data_ptr, cpts,signed, n_jobs)
        return to_fill

    def get_interleavings(self,box=None):
        if box is None:
            box = self.get_box()
        cdef Box[double] cbox = Box[double](box)
        return np.asarray(self.cmod.get_interleavings(cbox))

cdef class PyMultiDiagramPoint_f64:
    cdef MultiDiagram_point[One_critical_filtration[double]] point
    cdef set(self, MultiDiagram_point[One_critical_filtration[double]] pt):
        self.point = pt
        return self

    def get_degree(self):
        return self.point.get_dimension()
    def get_birth(self):
        cdef One_critical_filtration[double] v = self.point.get_birth()
        return _ff21cview_f64(&v, copy=True)
    def get_death(self):
        cdef One_critical_filtration[double] v = self.point.get_death()
        return _ff21cview_f64(&v, copy=True)


cdef class PyMultiDiagram_f64:
    r"""
    Stores the diagram of a PyModule on a line
    """
    cdef MultiDiagram[One_critical_filtration[double], double] multiDiagram
    cdef set(self, MultiDiagram[One_critical_filtration[double], double] m):
        self.multiDiagram = m
        return self
    def get_points(self, degree:int=-1) -> np.ndarray:
        cdef vector[pair[vector[double],vector[double]]] out = self.multiDiagram.get_points(degree)
        if len(out) == 0 and len(self) == 0:
            return np.empty() # TODO Retrieve good number of parameters if there is no points in diagram
        if len(out) == 0:
            return np.empty((0,2,self.multiDiagram.at(0).get_dimension())) # gets the number of parameters
        return np.array(out)
    def to_multipers(self, dimension:int):
        return self.multiDiagram.to_multipers(dimension)
    def __len__(self) -> int:
        return self.multiDiagram.size()
    def __getitem__(self,i:int) -> PyMultiDiagramPoint_f64:
        return PyMultiDiagramPoint_f64().set(self.multiDiagram.at(i % self.multiDiagram.size()))
cdef class PyMultiDiagrams_f64:
    """
    Stores the barcodes of a PyModule on multiple lines
    """
    cdef MultiDiagrams[One_critical_filtration[double], double] multiDiagrams
    cdef set(self,MultiDiagrams[One_critical_filtration[double], double] m):
        self.multiDiagrams = m
        return self
    def to_multipers(self):
        out = self.multiDiagrams.to_multipers()
        return [np.asarray(summand) for summand in out]
    def __getitem__(self,i:int):
        if i >=0 :
            return PyMultiDiagram_f64().set(self.multiDiagrams.at(i))
        else:
            return PyMultiDiagram_f64().set(self.multiDiagrams.at( self.multiDiagrams.size() - i))
    def __len__(self):
        return self.multiDiagrams.size()
    def get_points(self, degree:int=-1):
        return self.multiDiagrams.get_points()
    cdef _get_plot_bars(self, dimension:int=-1, min_persistence:float=0):
        return self.multiDiagrams._for_python_plot(dimension, min_persistence);
    def plot(self, degree:int=-1, min_persistence:float=0):
        """
        Plots the barcodes.

        Parameters
        ----------
        
         - degree:int=-1
            Only plots the bars of specified homology degree. Useful when the multidiagrams contains multiple dimenions
         - min_persistence:float=0
            Only plot bars of length greater than this value. Useful to reduce the time to plot.

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be displayed !

        """
        from cycler import cycler
        import matplotlib
        import matplotlib.pyplot as plt
        if len(self) == 0: return
        _cmap = matplotlib.colormaps["Spectral"]
        multibarcodes_, colors = self._get_plot_bars(degree, min_persistence)
        n_summands = np.max(colors)+1 if len(colors)>0 else 1

        plt.rc('axes', prop_cycle = cycler('color', [_cmap(i/n_summands) for i in colors]))
        return plt.plot(*multibarcodes_)


cdef dump_summand_f64(Summand[double]& summand):
    cdef vector[One_critical_filtration[double]] births = summand.get_birth_list()
    cdef vector[One_critical_filtration[double]] deaths = summand.get_death_list()
    return (
            np.array(_vff21cview_f64(births)),
            np.array(_vff21cview_f64(deaths)),
            summand.get_dimension(),
            )

cdef inline Summand[double] summand_from_dump_f64(summand_dump):
    cdef vector[double] births = _py2p2_f64(summand_dump[0])
    cdef vector[double] deaths = _py2p2_f64(summand_dump[1]) 
    cdef int dim = summand_dump[2]
    return Summand[double](births, deaths, summand_dump[0].shape[1], dim)

cdef dump_cmod_f64(Module[double]& mod):
    cdef Box[double] cbox = mod.get_box()
    cdef int dim = mod.get_dimension()
    # cannot cast const vector[double]& to vector[double] without the explicit cast
    cdef vector[double] bottom_corner = <vector[double]>cbox.get_lower_corner()
    cdef vector[double] top_corner = <vector[double]>cbox.get_upper_corner()
    box = np.asarray([bottom_corner, top_corner])
    summands = tuple(dump_summand_f64(summand) for summand in mod)
    return box, summands

cdef Module[double] cmod_from_dump_f64(module_dump):
    box = module_dump[0]
    summands = module_dump[1]
    cdef Module[double] out_module = Module[double]()
    out_module.set_box(Box[double](box))
    for i in range(len(summands)):
        out_module.add_summand(summand_from_dump_f64(summands[i]))
    return out_module


def from_dump_f64(dump)->PyModule_f64:
    r"""Retrieves a PyModule from a previous dump.

    Parameters
    ----------

    dump: either the output of the dump function, or a file containing the output of a dump.
        The dumped module to retrieve

    Returns
    -------
    
    PyModule
        The retrieved module.
    """
    # TODO : optimize...
    mod = PyModule_f64()
    if type(dump) is str:
        dump = pickle.load(open(dump, "rb"))
    cdef Module[double] cmod = cmod_from_dump_f64(dump)
    mod.cmod = cmod
    return mod

cdef class PySummand_f32:
    r"""
    Stores a Summand of a PyModule
    """
    cdef Summand[float] sum

    def get_birth_list(self): 
        cdef vector[One_critical_filtration[float]] v = self.sum.get_birth_list()
        return _vff21cview_f32(v, copy = True)

    def get_death_list(self):
        cdef vector[One_critical_filtration[float]] v = self.sum.get_death_list()
        return _vff21cview_f32(v, copy = True)
    @property
    def degree(self)->int:
        return self.sum.get_dimension()

    cdef set(self, Summand[float]& summand):
        self.sum = summand
        return self
    def get_bounds(self):
        cdef pair[vector[float],vector[float]] cbounds
        with nogil:
            cbounds = self.sum.get_bounds().get_bounding_corners()
        # return _ff21cview_f32(&cbounds.first).copy(), _ff21cview_f32(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    @property
    def dtype(self):
      return np.float32

    def num_parameters(self):
        cdef vector[One_critical_filtration[float]] v = self.sum.get_birth_list()
        if v[0].is_finite():
            return v[0].num_parameters()
        v = self.sum.get_death_list()
        return v[0].num_parameters()
    def __eq__(self, PySummand_f32 other):
        return self.sum == other.sum 




cdef inline get_summand_filtration_values_f32(Summand[float] summand):
    r"""
    Returns a list (over parameter) of the filtrations values of this parameter.
    """
    cdef vector[One_critical_filtration[float]] vb = summand.get_birth_list()
    cdef vector[One_critical_filtration[float]] vd = summand.get_death_list()

    if vb[0].is_finite():
        if vd[0].is_finite():
            pts = np.concatenate([_vff21cview_f32(vb, copy=True),
                                  _vff21cview_f32(vd, copy=True)],axis=0)
        else:
            pts = np.array(_vff21cview_f32(vb, copy=True))
    else:
        if vd[0].is_finite():
            pts = np.array(_vff21cview_f32(vd, copy=True))
        else:
            return []
    
    num_parameters = pts.shape[1]
    out = [np.unique(pts[:,parameter]) for parameter in range(num_parameters)]
    out = [f[:-1] if len(f)>0 and f[-1] == np.inf else f for f in out]
    out = [f[1:]  if len(f)>0 and f[0] == -np.inf else f for f in out]
    return out

cdef class PyBox_f32:
    cdef Box[float] box
    def __cinit__(self, vector[float]& bottomCorner, vector[float]& topCorner):
        self.box = Box[float](bottomCorner, topCorner)
    @property
    def num_parameters(self):
        cdef size_t dim = self.box.get_lower_corner().size()
        if dim == self.box.get_upper_corner().size():	return dim
        else:	print("Bad box definition.")
    def contains(self, x):
        return self.box.contains(x)
    cdef set(self, Box[float]& b):
        self.box = b
        return self

    def get(self):
        return [<vector[float]>self.box.get_lower_corner(), <vector[float]>self.box.get_upper_corner()]
    def to_multipers(self):
        #assert (self.get_dimension() == 2) "Multipers only works in dimension  2 !"
        return np.array(self.get()).flatten(order = 'F')
    @property
    def dtype(self):
      return np.float32



cdef class PyModule_f32:
    r"""
    Stores a representation of a n-persistence module.
    """
    cdef Module[float] cmod
    
    @property
    def dtype(self):
        return np.float32

    cdef set(self, Module[float] m):
        self.cmod = m

    def __eq__(self, PyModule_f32 other):
        return self.cmod == other.cmod

    def merge(self, PyModule_f32 other, int dim=-1):
        r"""
        Merges two modules into one
        """
        cdef Module[float] c_other = other.cmod
        with nogil:
            for summand in c_other:
                self.cmod.add_summand(summand, dim)
        return self
    def _add_mmas(self, mmas):
        for mma in mmas:
            self.merge(mma)
        return self

    def permute_summands(self, permutation):
        cdef int[:] c_perm = np.asarray(permutation, dtype=np.int32) 
        other = PyModule_f32()
        other.cmod = self.cmod.permute_summands(permutation)
        return other

    def _set_from_ptr(self, intptr_t module_ptr):
        r"""
        Copy module from a memory pointer. Unsafe.
        """
        self.cmod = move(dereference(<Module[float]*>(module_ptr)))
    def _get_ptr(self):
        cdef intptr_t ptr = <intptr_t>(&self.cmod)
        return ptr
    def set_box(self, box):
        assert len(box) == 2, "Box format is [low, hight]"
        pybox = PyBox_f32(box[0], box[1])
        cdef Box[float] cbox = pybox.box
        with nogil:
            self.cmod.set_box(cbox)
        return self
    def get_module_of_degree(self, int degree)->PyModule_f32: # TODO : in c++ ?
        r"""
        Returns a copy of a module of fixed degree.
        """
        pmodule = PyModule_f32()
        cdef Box[float] c_box = self.cmod.get_box()
        with nogil:
            pmodule.cmod.set_box(c_box) 
            for summand in self.cmod:
                if summand.get_dimension() == degree:
                    pmodule.cmod.add_summand(summand)
        return pmodule
    def get_module_of_degrees(self, degrees:Iterable[int])->PyModule_f32: # TODO : in c++ ?
        r"""
        Returns a copy of the summands of degrees in `degrees`
        """
        pmodule = PyModule_f32()
        cdef Box[float] c_box = self.cmod.get_box()
        pmodule.cmod.set_box(c_box)
        cdef vector[int] cdegrees = degrees
        with nogil:
            for summand in self.cmod:
                for d in cdegrees:
                    if d == summand.get_dimension():
                        pmodule.cmod.add_summand(summand)
        return pmodule
    def __len__(self)->int:
        return self.cmod.size()
    def get_bottom(self)->np.ndarray:
        r"""
        Bottom of the box of the module
        """
        return np.asarray(<vector[float]>(self.cmod.get_box().get_lower_corner()))
    def get_top(self)->np.ndarray:
        r"""
        Top of the box of the module
        """
        return np.asarray(<vector[float]>(self.cmod.get_box().get_upper_corner()))
    def get_box(self)->np.ndarray:
        r"""
        Returns the current bounding box of the module.
        """
        return np.asarray([self.get_bottom(), self.get_top()])
    @property
    def max_degree(self)->int:
        r"""
        Returns the maximum degree of the module.
        """
        return self.cmod.get_dimension()
    @property
    def num_parameters(self)->int:
        cdef size_t dim = self.cmod.get_box().get_lower_corner().size()
        assert dim == self.cmod.get_box().get_upper_corner().size(), "Bad box definition, cannot infer num_parameters."
        return dim
    def dump(self, path:str|None=None):
        r"""
        Dumps the module into a pickle-able format.

        Parameters
        ----------

        path:str=None (optional) saves the pickled module in specified path

        Returns
        -------
        
        list of list, encoding the module, which can be retrieved with the function `from_dump`.
        """
        ## TODO : optimize, but not really used.
        return dump_cmod_f32(self.cmod) 
    def __getstate__(self):
        return self.dump()
    def __setstate__(self,dump):
        cdef Module[float] cmod = cmod_from_dump_f32(dump)
        self.cmod = cmod
        return
    def __getitem__(self, int i) -> PySummand_f32:
        if i == slice(None):
            return self
        summand = PySummand_f32()
        summand.set(self.cmod.at(i % self.cmod.size()))
        return summand
    def __iter__(self):
        cdef int num_summands = self.cmod.size()
        for i in range(num_summands):
            summand = PySummand_f32()
            summand.set(self.cmod.at(i)) ## hmm copy. maybe do summand from ptr
            yield summand

    def get_bounds(self):
        r"""
        Computes bounds from the summands' bounds.
        Useful to change this' box.
        """
        cdef pair[vector[float],vector[float]] cbounds
        with nogil:
            cbounds = self.cmod.get_bounds().get_bounding_corners()
        # return _ff21cview_f32(&cbounds.first).copy(), _ff21cview_f32(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    def rescale(self,rescale_factors, int degree=-1):
        r"""
        Rescales the fitlration values of the summands by this rescaling vector.
        """
        cdef vector[float] crescale_factors = rescale_factors
        with nogil:
            self.cmod.rescale(crescale_factors,degree)
    def translate(self,translation, int degree=-1):
        r"""
        Translates the module in the filtration space by this vector.
        """
        cdef vector[float] ctranslation = translation
        with nogil:
            self.cmod.translate(ctranslation,degree)

    def get_filtration_values(self, bool unique=True):
        r"""
        Retrieves all filtration values of the summands of the module.

        Output format 
        -------------

        list of filtration values for parameter.
        """
        if len(self) ==0:
            return np.empty((self.num_parameters,0))
        values = tuple(
                tuple(stuff) 
                if len(stuff:=get_summand_filtration_values_f32(summand)) == self.num_parameters else list(stuff) + [[]]*(self.num_parameters - len(stuff)) for summand in self.cmod)
        try:
          values = tuple(np.concatenate([
            f[parameter]
            for f in values
            ], axis=0) for parameter in range(self.num_parameters)
          )
        except:
          return values
        if unique:
            return [np.unique(f) for f in values]
        return values

    def plot(self, int degree=-1,**kwargs)->None:
        r"""Shows the module on a plot. Each color corresponds to an apprimation summand of the module, and its shape corresponds to its support.
        Only works with 2-parameter modules.

        Parameters
        ----------
        degree = -1 : integer
            If positive returns only the image of dimension `dimension`.
        box=None : of the form [[b_x,b_y], [d_x,d_y]] where b,d are the bottom and top corner of the rectangle.
            If non-None, will plot the module on this specific rectangle.
        min_persistence =0 : float
            Only plots the summand with a persistence above this threshold.
        separated=False : bool
            If true, plot each summand in a different plot.
        alpha=1 : float
            Transparancy parameter
        save = False : string
            if nontrivial, will save the figure at this path


        Returns
        -------
        The figure of the plot.
        """
        from multipers.plots import plot2d_PyModule
        import matplotlib.pyplot as plt
        box = kwargs.pop('box', self.get_box())
        if (len(box[0]) != 2):
            print("Filtration size :", len(box[0]), " != 2")
            return
        if(degree < 0):
            dims = np.unique(self.get_dimensions())
            separated = kwargs.pop("separated", False)
            ndim = len(dims)
            scale = kwargs.pop("scale", 4)
            if separated:
                fig = None
                axes = None
            elif ndim > 1:
              fig, axes = plt.subplots(1,ndim, figsize=(ndim*scale,scale))
            else:
              fig = plt.gcf()
              axes = [plt.gca()]
            for dim_idx in range(ndim):
                if not separated:
                    plt.sca(axes[dim_idx])
                self.plot(dims[dim_idx],box=box, separated = separated, **kwargs)
            return
        corners = self.cmod.get_corners_of_dimension(degree)
        interleavings = self.get_module_of_degree(degree).get_interleavings()
        plot2d_PyModule(corners, box=box, dimension=degree, interleavings = interleavings, **kwargs)
        return
    def degree_splits(self):
        return np.asarray(self.cmod.get_degree_splits(), dtype=np.int64)
    def evaluate_in_grid(self, grid):
        grid = mpg.sanitize_grid(grid, numpyfy=True)
        cdef size_t num_parameters = len(grid)
        if num_parameters != self.num_parameters:
            raise ValueError(f"Invalid grid size. Got {len(grid)=} != {self.num_parameters=}")
        cdef vector[vector[float]] cgrid = vector[vector[float]](num_parameters)
        for i in range(num_parameters):
            cgrid[i] = grid[i]
        self.cmod.evaluate_in_grid(cgrid)
        return self
        


    def _compute_pixels(self,coordinates:np.ndarray,
                                         degrees=None, box=None, float delta=.1, 
                                         float p=1., bool normalize=False, int n_jobs=0):
        r"""
        Computes the image of the module at the given coordinates
        """
        if degrees is not None: assert np.all(degrees[:-1] <= degrees[1:]), "Degrees have to be sorted"
        cdef vector[int] cdegrees = np.arange(self.max_degree +1) if degrees is None else degrees
        pybox = PyBox_f32(*self.get_box()) if box is None else PyBox_f32(*box)
        cdef Box[float] cbox = pybox.box
        cdef vector[vector[float]] ccoords = coordinates
        cdef vector[vector[float]] out 
        with nogil:
            out = self.cmod.compute_pixels(ccoords, cdegrees, cbox, delta, p, normalize, n_jobs)
        return np.asarray(out)
    def barcode(self, basepoint, int degree = -1,*, bool threshold = False): # TODO direction vector interface
        r"""Computes the barcode of module along a lines.

        Parameters
        ----------
        
        basepoint  : vector
            basepoint of the lines on which to compute the barcodes, i.e. a point on the line
        degree = -1 : integer
            Homology degree on which to compute the bars. If negative, every dimension is computed
        box (default) :
            box on which to compute the barcodes if basepoints is not specified. Default is a linspace of lines crossing that box.
        threshold = False : 
            Thre

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be plot-able.

        Returns
        -------
        
        PyMultiDiagrams
            Structure that holds the barcodes. Barcodes can be retrieved with a .get_points() or a .to_multipers() or a .plot().
        """
        out = PyMultiDiagram_f32()
        out.set(self.cmod.get_barcode(Line[float](_py2p_f32(np.asarray(basepoint, dtype=np.float32))), degree, threshold))
        return out
    @staticmethod
    cdef _threshold_bc(bc): 
        return tuple(np.fromiter((a for a in stuff if a[0] < np.inf),  dtype=np.dtype((np.float32,2)) ) for stuff in bc)
    @staticmethod
    def _bc_to_full(bcs, basepoint, direction=None):
        # i, (b sv d), coords 
        basepoint = np.asarray(basepoint)[None,None,:]
        direction = 1 if direction is None else np.asarray(direction)[None,None,:]
        return tuple(bc[:,:,None]*direction + basepoint for bc in bcs)
    def barcode2(self, basepoint, direction=None, int degree = -1,*, bool threshold = False, bool keep_inf = True, bool full = False): # TODO direction vector interface
        r"""
        Compute the 1d-barcode a diagonal line based on basepoint, with some direction.
        
        Parameters
        ----------

         - basepoint: 1d array
         - directiont: 1d array or None, if None: diagonal
         - degree: int the degree to compute (-1 means all)
         - threshold: bool if True, threshold the barcode to the modules box
         - keep_inf: bool if False, removes trivial bars
                     Note that this removes the order w.r.t. the summands in that case
         - full:bool if True, returns the coordinates of the barcode instead of the coordinate in the line.

        The output is of the form

        tuple[np.ndarray of shape (num_bars,2)] or tuple[array of shape (num_bar, 2, num_parameters)]
        """
        basepoint = np.asarray(basepoint, dtype=np.float32)
        if direction is None:
            bc = tuple(np.asarray(x).reshape(-1,2) for x in self.cmod.get_barcode2(Line[float](_py2p_f32(basepoint)), degree))
        else:
            direction = np.asarray(direction, dtype = np.float32)
            bc = tuple(np.asarray(x).reshape(-1,2) for x in self.cmod.get_barcode2(Line[float](_py2p_f32(basepoint), _py2p_f32(direction)), degree))
        if not keep_inf:
            bc = PyModule_f32._threshold_bc(bc)
        if full:
            bc = PyModule_f32._bc_to_full(bc, basepoint, direction)

        return bc

    def get_dimensions(self):
        cdef int num_summands =  len(self)
        out = np.empty(shape=num_summands, dtype=np.int32)
        cdef int32_t[:] c_out = out
        for i in range(num_summands):
            c_out[i] = self.cmod.at(i).get_dimension()
        return out

    def barcodes(self, int degree, basepoints = None, num=100, box = None,threshold = False):
        r"""Computes barcodes of module along a set of lines.

        Parameters
        ----------
        
        basepoints = None : list of vectors
            basepoints of the lines on which to compute the barcodes.
        degree = -1 : integer
            Homology degree on which to compute the bars. If negative, every dimension is computed
        box (default) :
            box on which to compute the barcodes if basepoints is not specified. Default is a linspace of lines crossing that box.
        num:int=100
            if basepoints is not specified, defines the number of lines to consider.
        threshold = False : threshold t
            Resolution of the image(s).

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be plot-able.

        Returns
        -------
        
        PyMultiDiagrams
            Structure that holds the barcodes. Barcodes can be retrieved with a .get_points() or a .to_multipers() or a .plot().
        """
        out = PyMultiDiagrams_f32()
        if box is None:
            box = [self.get_bottom(), self.get_top()]
        if (len(box[0]) != 2) and (basepoints is None):
            raise ValueError("Basepoints has to be specified for filtration dimension >= 3 !")
        elif basepoints is None:
            h = box[1][1] - box[0][1]
            basepoints = np.linspace([box[0][0] - h,box[0][1]], [box[1][0],box[0][1]], num=num) 
        else :
            num=len(basepoints)

        cdef float[:,:] basepoints_view = np.asarray(basepoints, dtype = np.float32)
        cdef vector[Point[float]] cbasepoints = _py2vp_f32(basepoints_view)

        out.set(self.cmod.get_barcodes(cbasepoints, degree, threshold))
        return out

    def barcodes2(self, int degree = -1, basepoints = None, int num=100, box = None, bool threshold = False):
        r"""Computes barcodes of module along a set of lines.

        Parameters
        ----------

        basepoints = None : list of vectors
            basepoints of the lines on which to compute the barcodes.
        degree = -1 : integer
            Homology degree on which to compute the bars. If negative, every dimension is computed
        box (default) :
            box on which to compute the barcodes if basepoints is not specified. Default is a linspace of lines crossing that box.
        num:int=100
            if basepoints is not specified, defines the number of lines to consider.
        threshold = False : threshold t
            Resolution of the image(s).

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be plot-able.

        Returns
        -------
        
        tuple of 1d barcodes, based on basepoint, with direction (1,1)
        """
        if box is None:
            box = [self.get_bottom(), self.get_top()]
        if (len(box[0]) != 2) and (basepoints is None):
            raise ValueError("Basepoints has to be specified for filtration dimension >= 3 !")
        elif basepoints is None:
            h = box[1][1] - box[0][1]
            basepoints = np.linspace([box[0][0] - h,box[0][1]], [box[1][0],box[0][1]], num=num) 
        else :
            num=len(basepoints)

        basepoints = np.asarray(basepoints, dtype=np.float32)
        cdef vector[Line[float]] cbasepoints
        for i in range(num):
            cbasepoints.push_back(Line[float](_py2p_f32(basepoints[i])))
        return tuple(np.asarray(bc) for bc in self.cmod.get_barcodes2(cbasepoints, degree))   

    def landscape(self, degree:int, k:int=0,box:Sequence|np.ndarray|None=None, resolution:Sequence=[100,100], bool plot=False):
        r"""Computes the multiparameter landscape from a PyModule. Python interface only bifiltrations.

        Parameters
        ----------

        degree : integer
            The homology degree of the landscape.
        k = 0 : int
            the k-th landscape
        resolution = [50,50] : pair of integers
            Resolution of the image.
        box = None : in the format [[a,b], [c,d]]
            If nontrivial, compute the landscape of this box. Default is the PyModule box.
        plot = True : Boolean
            If true, plots the images;
        Returns
        -------
        
        The landscape of the module.

        """
        import matplotlib.pyplot as plt
        if box is None:
            box = self.get_box()
        cdef Box[float] c_box = Box[float](box)
        out = np.array(self.cmod.get_landscape(degree, k, c_box, resolution))
        if plot:
            aspect = (box[1][0]-box[0][0]) / (box[1][1]-box[0][1])
            extent = [box[0][0], box[1][0], box[0][1], box[1][1]]
            plt.imshow(out.T, origin="lower", extent=extent, aspect=aspect)
        return out

    def landscapes(self, degree:int, ks:list|np.ndarray=[0],box=None, resolution:list|np.ndarray=[100,100], bool plot=False):
        r"""Computes the multiparameter landscape from a PyModule. Python interface only bifiltrations.

        Parameters
        ----------
        
         - degree : integer
            The homology degree of the landscape.
         - ks = 0 : list of int
            the k-th landscape
         - resolution = [50,50] : pair of integers
            Resolution of the image.
         - box = None : in the format [[a,b], [c,d]]
            If nontrivial, compute the landscape of this box. Default is the PyModule box.
         - plot = True : bool
            If true, plots the images;
        Returns
        -------
        
        The landscapes of the module with parameters ks.

        """
        import matplotlib.pyplot as plt
        if box is None:
            box = self.get_box()
        out = np.array(self.cmod.get_landscapes(degree, ks, Box[float](box), resolution))
        if plot:
            to_plot = np.sum(out, axis=0)
            aspect = (box[1][0]-box[0][0]) / (box[1][1]-box[0][1])
            extent = [box[0][0], box[1][0], box[0][1], box[1][1]]
            plt.imshow(to_plot.T, origin="lower", extent=extent, aspect=aspect)
        return out


    def representation(self, degrees=None, double bandwidth=0.1,
            resolution:Sequence[int]|int=50, 
            kernel:Literal["gaussian","linear","linear2","exponential"]|Callable = "gaussian",
            bool signed=False,
            bool normalize=False, bool plot=False, 
            bool save=False, int dpi=200,double p=2., box=None, 
            bool flatten=False, int n_jobs=0,
            grid = None)->np.ndarray:
        r"""Computes a representation of the module, using 

        [A Framework for Fast and Stable Representations of Multiparameter Persistent Homology Decompositions, Neurips2023]

        Parameters
        ----------
        
         - degrees = None : integer list
            If given returns only the image(s) of homology degrees `degrees`.
         - bandwidth = 0.1 : float
            Image parameter. 
         - resolution = [100,100] : pair of integers
            Resolution of the image(s).
         - normalize = True : Boolean
            Ensures that the image belongs to [0,1].
         - plot = False : Boolean
            If true, plots the images;
         - flatten=False :
            If True, reshapes the output to a flattened shape.
         - kernel: Either linear, gaussian, or callable
           The kernel to apply to the matrix $(d(x,I), x \in \mathrm{pixels}, I\in \mathrm{summands})$.
           signature should be : (distance matrix, summand_weights, bandwidth, p) -> representation

        Returns
        -------
        
        The list of images, or the image of fixed dimension.
        """
        import matplotlib.pyplot as plt
        # box = kwargs.get("box",[self.get_bottom(),self.get_top()])
        if box is None:
            box = self.get_box()
        num_parameters = self.num_parameters
        if degrees is None:
            degrees = np.arange(self.max_degree +1)
        num_degrees = len(degrees)
        try:
            int(resolution)
            resolution = [resolution]*num_parameters
        except:
            pass

        if grid is None:
            grid = [np.linspace(*np.asarray(box)[:,parameter], num=res) for parameter, res in zip(range(num_parameters), resolution)]
        else:
            resolution = tuple(len(g) for g in grid)
        coordinates = mpg.todense(grid)

        if kernel == "linear":
            assert not signed, "This kernel is not compatible with signed."
            concatenated_images = self._compute_pixels(coordinates, degrees=degrees, box=box, delta=bandwidth, p=p, normalize=normalize,n_jobs=n_jobs)
        else:
            if kernel == "linear2":
                def todo(PyModule_f32 mod_degree):
                  x = mod_degree.distance_to(coordinates,signed=signed)
                  w = mod_degree.get_interleavings()[None]**p
                  s = np.where(x>=0,1,-1) if signed else 1 
                  x = np.abs(x)
                  return (s*np.where(x<bandwidth,(bandwidth-x)/bandwidth,0)*w).sum(1)
            elif kernel == "gaussian":
                def todo(PyModule_f32 mod_degree):
                  x = mod_degree.distance_to(coordinates,signed=signed)
                  w = mod_degree.get_interleavings()[None]**p
                  s = np.where(x>=0,1,-1) if signed else 1 
                  return (s*np.exp( -.5*((x/bandwidth)**2))*w).sum(1)
            elif kernel == "exponential":
                def todo(PyModule_f32 mod_degree):
                  x = mod_degree.distance_to(coordinates,signed=signed)
                  w = mod_degree.get_interleavings()[None]**p
                  s = np.where(x>=0,1,-1) if signed else 1 
                  x = np.abs(x)
                  return (s*np.exp( -((np.abs(x)/bandwidth)))*w).sum(1)
            else:
                assert callable(kernel), r"""
                    Kernel should be 
                    gaussian, linear, linear2, exponential or callable,
                    with signature
                     (array[shape=(N, M)], array[shape=(M)])-> array(shape=(N)),
                    the first argument being a distance matrix (pts) vs (summands of the module)
                    and the second argument is a weight vector (weight(summand) for summand in module).
                    Note that the distance can be signed.
                    """
                def todo(PyModule_f32 mod_degree):
                      x = mod_degree.distance_to(coordinates,signed=signed, n_jobs=n_jobs)
                      w = mod_degree.get_interleavings()[None]**p
                      return kernel(x/bandwidth,w)
            concatenated_images = np.stack(
                Parallel(n_jobs = n_jobs if n_jobs else -1, backend= "threading")(
                  delayed(todo)(self.get_module_of_degree(degree))
                  for degree in degrees
                )
              )

        if flatten:
            image_vector = concatenated_images.reshape((len(degrees),-1))
            if plot:
                raise ValueError("Unflatten to plot.")
            return image_vector
        else:
            image_vector = concatenated_images.reshape((len(degrees),*resolution))
        if plot:
            assert num_parameters == 2, "Plot only available for 2-parameter modules"
            import multipers.plots
            i=0
            n_plots = len(image_vector)
            scale = 4
            if n_plots >1:
              fig, axs = plt.subplots(1,n_plots, figsize=(n_plots*scale,scale))
            else:
              fig = plt.gcf()
              axs = [plt.gca()]
            for image, degree, i in zip(image_vector, degrees, range(num_degrees)):
                ax = axs[i]
                temp = multipers.plots.plot_surface(grid, image, ax=ax)
                plt.colorbar(temp, ax = ax)
                if degree < 0 :
                    ax.set_title(rf"$H_{i}$ $2$-persistence image")
                if degree >= 0:
                    ax.set_title(rf"$H_{degree}$ $2$-persistence image")
        return image_vector

    def euler_char(self, points:list|np.ndarray) -> np.ndarray:
        r""" Computes the Euler Characteristic of the filtered complex at given (multiparameter) time

        Parameters
        ----------
        
        points: list[float] | list[list[float]] | np.ndarray
            List of filtration values on which to compute the euler characteristic.
            WARNING FIXME : the points have to have the same dimension as the simplextree.	

        Returns
        -------
        
        The list of euler characteristic values
        """
        if len(points) == 0:
            return []
        if type(points[0]) is float:
            points = [points]
        if type(points) is np.ndarray:
            assert len(points.shape) in [1,2]
            if len(points.shape) == 1:
                points = [points]

        cdef float[:,:] points_view = np.asarray(points, dtype = np.float32)
        cdef vector[One_critical_filtration[float]] c_points = _py2v1c_f32(points_view)
        # cdef One_critical_filtration temp
        # for point in points:
        #     temp.clear()
        #     for truc in point:
        #         temp.push_back(<float>(truc))
        #     c_points.push_back(temp)
        cdef Module[float] c_mod = self.cmod
        with nogil:
            c_euler = c_mod.euler_curve(c_points)
        euler = c_euler
        return np.asarray(euler, dtype=int)
    def to_idx(self,grid):
        cdef vector[vector[float]] cgrid = grid
        cdef vector[vector[pair[vector[vector[int]],vector[vector[int]]]]] out
        with nogil:
            out = self.cmod.to_idx(cgrid)
        return tuple(tuple((np.asarray(I.first,dtype=np.int64), np.asarray(I.second, dtype=np.int64)) for I in Is_of_degree) for Is_of_degree in out)
    
    @cython.wraparound(False)
    @cython.boundscheck(False)
    def to_flat_idx(self,grid):
        if len(self) == 0:
            return np.empty((2,0), dtype = np.int32), np.empty((0, self.num_parameters), dtype = np.int32),  np.empty((0, self.num_parameters), dtype = np.int32)
        cdef vector[vector[float]] cgrid = grid
        cdef vector[vector[vector[int]]] out
        cdef int num_summands, num_births, num_deaths
        cdef int num_parameters = self.num_parameters
        with nogil:
            out = self.cmod.to_flat_idx(cgrid)
            num_summands = out[0][0].size()
            num_births = out[1].size()
            num_deaths = out[2].size()
        idx = np.empty((2, num_summands),dtype=np.int32 )
        births = np.empty((num_births,num_parameters),dtype=np.int32)
        deaths = np.empty((num_deaths,num_parameters),dtype=np.int32)

        cdef int32_t[:,:] idx_view = idx
        cdef int32_t[:,:] births_view = births
        cdef int32_t[:,:] deaths_view = deaths

        with nogil:
            for i in range(num_summands):
                idx_view[0,i] = out[0][0][i]
                idx_view[1,i] = out[0][1][i]
            for i in range(num_births):
                for j in range(num_parameters):
                    births_view[i,j] = out[1][i][j]
            for i in range(num_deaths):
                for j in range(num_parameters):
                    deaths_view[i,j] = out[2][i][j]

        return idx, births,deaths

    def distances_idx_to(self, pts, bool full=False, int n_jobs=1):
        pts = np.asarray(pts)
        if pts.ndim == 1:
            pts = pts[None]
        cdef vector[vector[float]] cpts = pts
        cdef vector[vector[vector[int]]] out
        with nogil:
            out = self.cmod.compute_distances_idx_to(cpts,full, n_jobs)
        return np.asarray(out, dtype=np.int32)

    def distance_to(self, pts, bool signed=False, int n_jobs = 0)->np.ndarray:
        r"""
        Distance from a point to each summand's support. 
        Signed distance is the distance to the boundary,
        with negative values inside the summands.

        pts of shape (num_pts, num_parameters)

        output shape : (num_pts,num_summands)
        """
        pts = np.asarray(pts)
        if pts.ndim == 1:
            pts = pts[None]
        assert pts.shape[-1] == self.num_parameters
        cdef vector[vector[float]] cpts = pts
        # cdef vector[vector[float]] out
        to_fill = np.empty(shape=(cpts.size(),len(self)), dtype = np.float32)
        cdef float[:,:] c_to_fill = to_fill
        cdef float* data_ptr = &c_to_fill[0,0]
        with nogil:
            self.cmod.compute_distances_to(data_ptr, cpts,signed, n_jobs)
        return to_fill

    def get_interleavings(self,box=None):
        if box is None:
            box = self.get_box()
        cdef Box[float] cbox = Box[float](box)
        return np.asarray(self.cmod.get_interleavings(cbox))

cdef class PyMultiDiagramPoint_f32:
    cdef MultiDiagram_point[One_critical_filtration[float]] point
    cdef set(self, MultiDiagram_point[One_critical_filtration[float]] pt):
        self.point = pt
        return self

    def get_degree(self):
        return self.point.get_dimension()
    def get_birth(self):
        cdef One_critical_filtration[float] v = self.point.get_birth()
        return _ff21cview_f32(&v, copy=True)
    def get_death(self):
        cdef One_critical_filtration[float] v = self.point.get_death()
        return _ff21cview_f32(&v, copy=True)


cdef class PyMultiDiagram_f32:
    r"""
    Stores the diagram of a PyModule on a line
    """
    cdef MultiDiagram[One_critical_filtration[float], float] multiDiagram
    cdef set(self, MultiDiagram[One_critical_filtration[float], float] m):
        self.multiDiagram = m
        return self
    def get_points(self, degree:int=-1) -> np.ndarray:
        cdef vector[pair[vector[float],vector[float]]] out = self.multiDiagram.get_points(degree)
        if len(out) == 0 and len(self) == 0:
            return np.empty() # TODO Retrieve good number of parameters if there is no points in diagram
        if len(out) == 0:
            return np.empty((0,2,self.multiDiagram.at(0).get_dimension())) # gets the number of parameters
        return np.array(out)
    def to_multipers(self, dimension:int):
        return self.multiDiagram.to_multipers(dimension)
    def __len__(self) -> int:
        return self.multiDiagram.size()
    def __getitem__(self,i:int) -> PyMultiDiagramPoint_f32:
        return PyMultiDiagramPoint_f32().set(self.multiDiagram.at(i % self.multiDiagram.size()))
cdef class PyMultiDiagrams_f32:
    """
    Stores the barcodes of a PyModule on multiple lines
    """
    cdef MultiDiagrams[One_critical_filtration[float], float] multiDiagrams
    cdef set(self,MultiDiagrams[One_critical_filtration[float], float] m):
        self.multiDiagrams = m
        return self
    def to_multipers(self):
        out = self.multiDiagrams.to_multipers()
        return [np.asarray(summand) for summand in out]
    def __getitem__(self,i:int):
        if i >=0 :
            return PyMultiDiagram_f32().set(self.multiDiagrams.at(i))
        else:
            return PyMultiDiagram_f32().set(self.multiDiagrams.at( self.multiDiagrams.size() - i))
    def __len__(self):
        return self.multiDiagrams.size()
    def get_points(self, degree:int=-1):
        return self.multiDiagrams.get_points()
    cdef _get_plot_bars(self, dimension:int=-1, min_persistence:float=0):
        return self.multiDiagrams._for_python_plot(dimension, min_persistence);
    def plot(self, degree:int=-1, min_persistence:float=0):
        """
        Plots the barcodes.

        Parameters
        ----------
        
         - degree:int=-1
            Only plots the bars of specified homology degree. Useful when the multidiagrams contains multiple dimenions
         - min_persistence:float=0
            Only plot bars of length greater than this value. Useful to reduce the time to plot.

        Warning
        -------
        
        If the barcodes are not thresholded, essential barcodes will not be displayed !

        """
        from cycler import cycler
        import matplotlib
        import matplotlib.pyplot as plt
        if len(self) == 0: return
        _cmap = matplotlib.colormaps["Spectral"]
        multibarcodes_, colors = self._get_plot_bars(degree, min_persistence)
        n_summands = np.max(colors)+1 if len(colors)>0 else 1

        plt.rc('axes', prop_cycle = cycler('color', [_cmap(i/n_summands) for i in colors]))
        return plt.plot(*multibarcodes_)


cdef dump_summand_f32(Summand[float]& summand):
    cdef vector[One_critical_filtration[float]] births = summand.get_birth_list()
    cdef vector[One_critical_filtration[float]] deaths = summand.get_death_list()
    return (
            np.array(_vff21cview_f32(births)),
            np.array(_vff21cview_f32(deaths)),
            summand.get_dimension(),
            )

cdef inline Summand[float] summand_from_dump_f32(summand_dump):
    cdef vector[float] births = _py2p2_f32(summand_dump[0])
    cdef vector[float] deaths = _py2p2_f32(summand_dump[1]) 
    cdef int dim = summand_dump[2]
    return Summand[float](births, deaths, summand_dump[0].shape[1], dim)

cdef dump_cmod_f32(Module[float]& mod):
    cdef Box[float] cbox = mod.get_box()
    cdef int dim = mod.get_dimension()
    # cannot cast const vector[float]& to vector[float] without the explicit cast
    cdef vector[float] bottom_corner = <vector[float]>cbox.get_lower_corner()
    cdef vector[float] top_corner = <vector[float]>cbox.get_upper_corner()
    box = np.asarray([bottom_corner, top_corner])
    summands = tuple(dump_summand_f32(summand) for summand in mod)
    return box, summands

cdef Module[float] cmod_from_dump_f32(module_dump):
    box = module_dump[0]
    summands = module_dump[1]
    cdef Module[float] out_module = Module[float]()
    out_module.set_box(Box[float](box))
    for i in range(len(summands)):
        out_module.add_summand(summand_from_dump_f32(summands[i]))
    return out_module


def from_dump_f32(dump)->PyModule_f32:
    r"""Retrieves a PyModule from a previous dump.

    Parameters
    ----------

    dump: either the output of the dump function, or a file containing the output of a dump.
        The dumped module to retrieve

    Returns
    -------
    
    PyModule
        The retrieved module.
    """
    # TODO : optimize...
    mod = PyModule_f32()
    if type(dump) is str:
        dump = pickle.load(open(dump, "rb"))
    cdef Module[float] cmod = cmod_from_dump_f32(dump)
    mod.cmod = cmod
    return mod

cdef class PySummand_i32:
    r"""
    Stores a Summand of a PyModule
    """
    cdef Summand[int32_t] sum

    def get_birth_list(self): 
        cdef vector[One_critical_filtration[int32_t]] v = self.sum.get_birth_list()
        return _vff21cview_i32(v, copy = True)

    def get_death_list(self):
        cdef vector[One_critical_filtration[int32_t]] v = self.sum.get_death_list()
        return _vff21cview_i32(v, copy = True)
    @property
    def degree(self)->int:
        return self.sum.get_dimension()

    cdef set(self, Summand[int32_t]& summand):
        self.sum = summand
        return self
    def get_bounds(self):
        cdef pair[vector[int32_t],vector[int32_t]] cbounds
        with nogil:
            cbounds = self.sum.get_bounds().get_bounding_corners()
        # return _ff21cview_i32(&cbounds.first).copy(), _ff21cview_i32(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    @property
    def dtype(self):
      return np.int32

    def num_parameters(self):
        cdef vector[One_critical_filtration[int32_t]] v = self.sum.get_birth_list()
        if v[0].is_finite():
            return v[0].num_parameters()
        v = self.sum.get_death_list()
        return v[0].num_parameters()
    def __eq__(self, PySummand_i32 other):
        return self.sum == other.sum 




cdef inline get_summand_filtration_values_i32(Summand[int32_t] summand):
    r"""
    Returns a list (over parameter) of the filtrations values of this parameter.
    """
    cdef vector[One_critical_filtration[int32_t]] vb = summand.get_birth_list()
    cdef vector[One_critical_filtration[int32_t]] vd = summand.get_death_list()

    if vb[0].is_finite():
        if vd[0].is_finite():
            pts = np.concatenate([_vff21cview_i32(vb, copy=True),
                                  _vff21cview_i32(vd, copy=True)],axis=0)
        else:
            pts = np.array(_vff21cview_i32(vb, copy=True))
    else:
        if vd[0].is_finite():
            pts = np.array(_vff21cview_i32(vd, copy=True))
        else:
            return []
    
    num_parameters = pts.shape[1]
    out = [np.unique(pts[:,parameter]) for parameter in range(num_parameters)]
    out = [f[:-1] if len(f)>0 and f[-1] == np.inf else f for f in out]
    out = [f[1:]  if len(f)>0 and f[0] == -np.inf else f for f in out]
    return out

cdef class PyBox_i32:
    cdef Box[int32_t] box
    def __cinit__(self, vector[int32_t]& bottomCorner, vector[int32_t]& topCorner):
        self.box = Box[int32_t](bottomCorner, topCorner)
    @property
    def num_parameters(self):
        cdef size_t dim = self.box.get_lower_corner().size()
        if dim == self.box.get_upper_corner().size():	return dim
        else:	print("Bad box definition.")
    def contains(self, x):
        return self.box.contains(x)
    cdef set(self, Box[int32_t]& b):
        self.box = b
        return self

    def get(self):
        return [<vector[int32_t]>self.box.get_lower_corner(), <vector[int32_t]>self.box.get_upper_corner()]
    def to_multipers(self):
        #assert (self.get_dimension() == 2) "Multipers only works in dimension  2 !"
        return np.array(self.get()).flatten(order = 'F')
    @property
    def dtype(self):
      return np.int32



cdef class PyModule_i32:
    r"""
    Stores a representation of a n-persistence module.
    """
    cdef Module[int32_t] cmod
    
    @property
    def dtype(self):
        return np.int32

    cdef set(self, Module[int32_t] m):
        self.cmod = m

    def __eq__(self, PyModule_i32 other):
        return self.cmod == other.cmod

    def merge(self, PyModule_i32 other, int dim=-1):
        r"""
        Merges two modules into one
        """
        cdef Module[int32_t] c_other = other.cmod
        with nogil:
            for summand in c_other:
                self.cmod.add_summand(summand, dim)
        return self
    def _add_mmas(self, mmas):
        for mma in mmas:
            self.merge(mma)
        return self

    def permute_summands(self, permutation):
        cdef int[:] c_perm = np.asarray(permutation, dtype=np.int32) 
        other = PyModule_i32()
        other.cmod = self.cmod.permute_summands(permutation)
        return other

    def _set_from_ptr(self, intptr_t module_ptr):
        r"""
        Copy module from a memory pointer. Unsafe.
        """
        self.cmod = move(dereference(<Module[int32_t]*>(module_ptr)))
    def _get_ptr(self):
        cdef intptr_t ptr = <intptr_t>(&self.cmod)
        return ptr
    def set_box(self, box):
        assert len(box) == 2, "Box format is [low, hight]"
        pybox = PyBox_i32(box[0], box[1])
        cdef Box[int32_t] cbox = pybox.box
        with nogil:
            self.cmod.set_box(cbox)
        return self
    def get_module_of_degree(self, int degree)->PyModule_i32: # TODO : in c++ ?
        r"""
        Returns a copy of a module of fixed degree.
        """
        pmodule = PyModule_i32()
        cdef Box[int32_t] c_box = self.cmod.get_box()
        with nogil:
            pmodule.cmod.set_box(c_box) 
            for summand in self.cmod:
                if summand.get_dimension() == degree:
                    pmodule.cmod.add_summand(summand)
        return pmodule
    def get_module_of_degrees(self, degrees:Iterable[int])->PyModule_i32: # TODO : in c++ ?
        r"""
        Returns a copy of the summands of degrees in `degrees`
        """
        pmodule = PyModule_i32()
        cdef Box[int32_t] c_box = self.cmod.get_box()
        pmodule.cmod.set_box(c_box)
        cdef vector[int] cdegrees = degrees
        with nogil:
            for summand in self.cmod:
                for d in cdegrees:
                    if d == summand.get_dimension():
                        pmodule.cmod.add_summand(summand)
        return pmodule
    def __len__(self)->int:
        return self.cmod.size()
    def get_bottom(self)->np.ndarray:
        r"""
        Bottom of the box of the module
        """
        return np.asarray(<vector[int32_t]>(self.cmod.get_box().get_lower_corner()))
    def get_top(self)->np.ndarray:
        r"""
        Top of the box of the module
        """
        return np.asarray(<vector[int32_t]>(self.cmod.get_box().get_upper_corner()))
    def get_box(self)->np.ndarray:
        r"""
        Returns the current bounding box of the module.
        """
        return np.asarray([self.get_bottom(), self.get_top()])
    @property
    def max_degree(self)->int:
        r"""
        Returns the maximum degree of the module.
        """
        return self.cmod.get_dimension()
    @property
    def num_parameters(self)->int:
        cdef size_t dim = self.cmod.get_box().get_lower_corner().size()
        assert dim == self.cmod.get_box().get_upper_corner().size(), "Bad box definition, cannot infer num_parameters."
        return dim
    def dump(self, path:str|None=None):
        r"""
        Dumps the module into a pickle-able format.

        Parameters
        ----------

        path:str=None (optional) saves the pickled module in specified path

        Returns
        -------
        
        list of list, encoding the module, which can be retrieved with the function `from_dump`.
        """
        ## TODO : optimize, but not really used.
        return dump_cmod_i32(self.cmod) 
    def __getstate__(self):
        return self.dump()
    def __setstate__(self,dump):
        cdef Module[int32_t] cmod = cmod_from_dump_i32(dump)
        self.cmod = cmod
        return
    def __getitem__(self, int i) -> PySummand_i32:
        if i == slice(None):
            return self
        summand = PySummand_i32()
        summand.set(self.cmod.at(i % self.cmod.size()))
        return summand
    def __iter__(self):
        cdef int num_summands = self.cmod.size()
        for i in range(num_summands):
            summand = PySummand_i32()
            summand.set(self.cmod.at(i)) ## hmm copy. maybe do summand from ptr
            yield summand

    def get_bounds(self):
        r"""
        Computes bounds from the summands' bounds.
        Useful to change this' box.
        """
        cdef pair[vector[int32_t],vector[int32_t]] cbounds
        with nogil:
            cbounds = self.cmod.get_bounds().get_bounding_corners()
        # return _ff21cview_i32(&cbounds.first).copy(), _ff21cview_i32(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    def rescale(self,rescale_factors, int degree=-1):
        r"""
        Rescales the fitlration values of the summands by this rescaling vector.
        """
        cdef vector[int32_t] crescale_factors = rescale_factors
        with nogil:
            self.cmod.rescale(crescale_factors,degree)
    def translate(self,translation, int degree=-1):
        r"""
        Translates the module in the filtration space by this vector.
        """
        cdef vector[int32_t] ctranslation = translation
        with nogil:
            self.cmod.translate(ctranslation,degree)

    def get_filtration_values(self, bool unique=True):
        r"""
        Retrieves all filtration values of the summands of the module.

        Output format 
        -------------

        list of filtration values for parameter.
        """
        if len(self) ==0:
            return np.empty((self.num_parameters,0))
        values = tuple(
                tuple(stuff) 
                if len(stuff:=get_summand_filtration_values_i32(summand)) == self.num_parameters else list(stuff) + [[]]*(self.num_parameters - len(stuff)) for summand in self.cmod)
        try:
          values = tuple(np.concatenate([
            f[parameter]
            for f in values
            ], axis=0) for parameter in range(self.num_parameters)
          )
        except:
          return values
        if unique:
            return [np.unique(f) for f in values]
        return values

    def plot(self, int degree=-1,**kwargs)->None:
        r"""Shows the module on a plot. Each color corresponds to an apprimation summand of the module, and its shape corresponds to its support.
        Only works with 2-parameter modules.

        Parameters
        ----------
        degree = -1 : integer
            If positive returns only the image of dimension `dimension`.
        box=None : of the form [[b_x,b_y], [d_x,d_y]] where b,d are the bottom and top corner of the rectangle.
            If non-None, will plot the module on this specific rectangle.
        min_persistence =0 : float
            Only plots the summand with a persistence above this threshold.
        separated=False : bool
            If true, plot each summand in a different plot.
        alpha=1 : float
            Transparancy parameter
        save = False : string
            if nontrivial, will save the figure at this path


        Returns
        -------
        The figure of the plot.
        """
        from multipers.plots import plot2d_PyModule
        import matplotlib.pyplot as plt
        box = kwargs.pop('box', self.get_box())
        if (len(box[0]) != 2):
            print("Filtration size :", len(box[0]), " != 2")
            return
        if(degree < 0):
            dims = np.unique(self.get_dimensions())
            separated = kwargs.pop("separated", False)
            ndim = len(dims)
            scale = kwargs.pop("scale", 4)
            if separated:
                fig = None
                axes = None
            elif ndim > 1:
              fig, axes = plt.subplots(1,ndim, figsize=(ndim*scale,scale))
            else:
              fig = plt.gcf()
              axes = [plt.gca()]
            for dim_idx in range(ndim):
                if not separated:
                    plt.sca(axes[dim_idx])
                self.plot(dims[dim_idx],box=box, separated = separated, **kwargs)
            return
        corners = self.cmod.get_corners_of_dimension(degree)
        interleavings = self.get_module_of_degree(degree).get_interleavings()
        plot2d_PyModule(corners, box=box, dimension=degree, interleavings = interleavings, **kwargs)
        return
    def degree_splits(self):
        return np.asarray(self.cmod.get_degree_splits(), dtype=np.int64)


cdef dump_summand_i32(Summand[int32_t]& summand):
    cdef vector[One_critical_filtration[int32_t]] births = summand.get_birth_list()
    cdef vector[One_critical_filtration[int32_t]] deaths = summand.get_death_list()
    return (
            np.array(_vff21cview_i32(births)),
            np.array(_vff21cview_i32(deaths)),
            summand.get_dimension(),
            )

cdef inline Summand[int32_t] summand_from_dump_i32(summand_dump):
    cdef vector[int32_t] births = _py2p2_i32(summand_dump[0])
    cdef vector[int32_t] deaths = _py2p2_i32(summand_dump[1]) 
    cdef int dim = summand_dump[2]
    return Summand[int32_t](births, deaths, summand_dump[0].shape[1], dim)

cdef dump_cmod_i32(Module[int32_t]& mod):
    cdef Box[int32_t] cbox = mod.get_box()
    cdef int dim = mod.get_dimension()
    # cannot cast const vector[int32_t]& to vector[int32_t] without the explicit cast
    cdef vector[int32_t] bottom_corner = <vector[int32_t]>cbox.get_lower_corner()
    cdef vector[int32_t] top_corner = <vector[int32_t]>cbox.get_upper_corner()
    box = np.asarray([bottom_corner, top_corner])
    summands = tuple(dump_summand_i32(summand) for summand in mod)
    return box, summands

cdef Module[int32_t] cmod_from_dump_i32(module_dump):
    box = module_dump[0]
    summands = module_dump[1]
    cdef Module[int32_t] out_module = Module[int32_t]()
    out_module.set_box(Box[int32_t](box))
    for i in range(len(summands)):
        out_module.add_summand(summand_from_dump_i32(summands[i]))
    return out_module


def from_dump_i32(dump)->PyModule_i32:
    r"""Retrieves a PyModule from a previous dump.

    Parameters
    ----------

    dump: either the output of the dump function, or a file containing the output of a dump.
        The dumped module to retrieve

    Returns
    -------
    
    PyModule
        The retrieved module.
    """
    # TODO : optimize...
    mod = PyModule_i32()
    if type(dump) is str:
        dump = pickle.load(open(dump, "rb"))
    cdef Module[int32_t] cmod = cmod_from_dump_i32(dump)
    mod.cmod = cmod
    return mod

cdef class PySummand_i64:
    r"""
    Stores a Summand of a PyModule
    """
    cdef Summand[int64_t] sum

    def get_birth_list(self): 
        cdef vector[One_critical_filtration[int64_t]] v = self.sum.get_birth_list()
        return _vff21cview_i64(v, copy = True)

    def get_death_list(self):
        cdef vector[One_critical_filtration[int64_t]] v = self.sum.get_death_list()
        return _vff21cview_i64(v, copy = True)
    @property
    def degree(self)->int:
        return self.sum.get_dimension()

    cdef set(self, Summand[int64_t]& summand):
        self.sum = summand
        return self
    def get_bounds(self):
        cdef pair[vector[int64_t],vector[int64_t]] cbounds
        with nogil:
            cbounds = self.sum.get_bounds().get_bounding_corners()
        # return _ff21cview_i64(&cbounds.first).copy(), _ff21cview_i64(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    @property
    def dtype(self):
      return np.int64

    def num_parameters(self):
        cdef vector[One_critical_filtration[int64_t]] v = self.sum.get_birth_list()
        if v[0].is_finite():
            return v[0].num_parameters()
        v = self.sum.get_death_list()
        return v[0].num_parameters()
    def __eq__(self, PySummand_i64 other):
        return self.sum == other.sum 




cdef inline get_summand_filtration_values_i64(Summand[int64_t] summand):
    r"""
    Returns a list (over parameter) of the filtrations values of this parameter.
    """
    cdef vector[One_critical_filtration[int64_t]] vb = summand.get_birth_list()
    cdef vector[One_critical_filtration[int64_t]] vd = summand.get_death_list()

    if vb[0].is_finite():
        if vd[0].is_finite():
            pts = np.concatenate([_vff21cview_i64(vb, copy=True),
                                  _vff21cview_i64(vd, copy=True)],axis=0)
        else:
            pts = np.array(_vff21cview_i64(vb, copy=True))
    else:
        if vd[0].is_finite():
            pts = np.array(_vff21cview_i64(vd, copy=True))
        else:
            return []
    
    num_parameters = pts.shape[1]
    out = [np.unique(pts[:,parameter]) for parameter in range(num_parameters)]
    out = [f[:-1] if len(f)>0 and f[-1] == np.inf else f for f in out]
    out = [f[1:]  if len(f)>0 and f[0] == -np.inf else f for f in out]
    return out

cdef class PyBox_i64:
    cdef Box[int64_t] box
    def __cinit__(self, vector[int64_t]& bottomCorner, vector[int64_t]& topCorner):
        self.box = Box[int64_t](bottomCorner, topCorner)
    @property
    def num_parameters(self):
        cdef size_t dim = self.box.get_lower_corner().size()
        if dim == self.box.get_upper_corner().size():	return dim
        else:	print("Bad box definition.")
    def contains(self, x):
        return self.box.contains(x)
    cdef set(self, Box[int64_t]& b):
        self.box = b
        return self

    def get(self):
        return [<vector[int64_t]>self.box.get_lower_corner(), <vector[int64_t]>self.box.get_upper_corner()]
    def to_multipers(self):
        #assert (self.get_dimension() == 2) "Multipers only works in dimension  2 !"
        return np.array(self.get()).flatten(order = 'F')
    @property
    def dtype(self):
      return np.int64



cdef class PyModule_i64:
    r"""
    Stores a representation of a n-persistence module.
    """
    cdef Module[int64_t] cmod
    
    @property
    def dtype(self):
        return np.int64

    cdef set(self, Module[int64_t] m):
        self.cmod = m

    def __eq__(self, PyModule_i64 other):
        return self.cmod == other.cmod

    def merge(self, PyModule_i64 other, int dim=-1):
        r"""
        Merges two modules into one
        """
        cdef Module[int64_t] c_other = other.cmod
        with nogil:
            for summand in c_other:
                self.cmod.add_summand(summand, dim)
        return self
    def _add_mmas(self, mmas):
        for mma in mmas:
            self.merge(mma)
        return self

    def permute_summands(self, permutation):
        cdef int[:] c_perm = np.asarray(permutation, dtype=np.int32) 
        other = PyModule_i64()
        other.cmod = self.cmod.permute_summands(permutation)
        return other

    def _set_from_ptr(self, intptr_t module_ptr):
        r"""
        Copy module from a memory pointer. Unsafe.
        """
        self.cmod = move(dereference(<Module[int64_t]*>(module_ptr)))
    def _get_ptr(self):
        cdef intptr_t ptr = <intptr_t>(&self.cmod)
        return ptr
    def set_box(self, box):
        assert len(box) == 2, "Box format is [low, hight]"
        pybox = PyBox_i64(box[0], box[1])
        cdef Box[int64_t] cbox = pybox.box
        with nogil:
            self.cmod.set_box(cbox)
        return self
    def get_module_of_degree(self, int degree)->PyModule_i64: # TODO : in c++ ?
        r"""
        Returns a copy of a module of fixed degree.
        """
        pmodule = PyModule_i64()
        cdef Box[int64_t] c_box = self.cmod.get_box()
        with nogil:
            pmodule.cmod.set_box(c_box) 
            for summand in self.cmod:
                if summand.get_dimension() == degree:
                    pmodule.cmod.add_summand(summand)
        return pmodule
    def get_module_of_degrees(self, degrees:Iterable[int])->PyModule_i64: # TODO : in c++ ?
        r"""
        Returns a copy of the summands of degrees in `degrees`
        """
        pmodule = PyModule_i64()
        cdef Box[int64_t] c_box = self.cmod.get_box()
        pmodule.cmod.set_box(c_box)
        cdef vector[int] cdegrees = degrees
        with nogil:
            for summand in self.cmod:
                for d in cdegrees:
                    if d == summand.get_dimension():
                        pmodule.cmod.add_summand(summand)
        return pmodule
    def __len__(self)->int:
        return self.cmod.size()
    def get_bottom(self)->np.ndarray:
        r"""
        Bottom of the box of the module
        """
        return np.asarray(<vector[int64_t]>(self.cmod.get_box().get_lower_corner()))
    def get_top(self)->np.ndarray:
        r"""
        Top of the box of the module
        """
        return np.asarray(<vector[int64_t]>(self.cmod.get_box().get_upper_corner()))
    def get_box(self)->np.ndarray:
        r"""
        Returns the current bounding box of the module.
        """
        return np.asarray([self.get_bottom(), self.get_top()])
    @property
    def max_degree(self)->int:
        r"""
        Returns the maximum degree of the module.
        """
        return self.cmod.get_dimension()
    @property
    def num_parameters(self)->int:
        cdef size_t dim = self.cmod.get_box().get_lower_corner().size()
        assert dim == self.cmod.get_box().get_upper_corner().size(), "Bad box definition, cannot infer num_parameters."
        return dim
    def dump(self, path:str|None=None):
        r"""
        Dumps the module into a pickle-able format.

        Parameters
        ----------

        path:str=None (optional) saves the pickled module in specified path

        Returns
        -------
        
        list of list, encoding the module, which can be retrieved with the function `from_dump`.
        """
        ## TODO : optimize, but not really used.
        return dump_cmod_i64(self.cmod) 
    def __getstate__(self):
        return self.dump()
    def __setstate__(self,dump):
        cdef Module[int64_t] cmod = cmod_from_dump_i64(dump)
        self.cmod = cmod
        return
    def __getitem__(self, int i) -> PySummand_i64:
        if i == slice(None):
            return self
        summand = PySummand_i64()
        summand.set(self.cmod.at(i % self.cmod.size()))
        return summand
    def __iter__(self):
        cdef int num_summands = self.cmod.size()
        for i in range(num_summands):
            summand = PySummand_i64()
            summand.set(self.cmod.at(i)) ## hmm copy. maybe do summand from ptr
            yield summand

    def get_bounds(self):
        r"""
        Computes bounds from the summands' bounds.
        Useful to change this' box.
        """
        cdef pair[vector[int64_t],vector[int64_t]] cbounds
        with nogil:
            cbounds = self.cmod.get_bounds().get_bounding_corners()
        # return _ff21cview_i64(&cbounds.first).copy(), _ff21cview_i64(&cbounds.second).copy()
        return np.asarray(cbounds.first), np.asarray(cbounds.second)
    def rescale(self,rescale_factors, int degree=-1):
        r"""
        Rescales the fitlration values of the summands by this rescaling vector.
        """
        cdef vector[int64_t] crescale_factors = rescale_factors
        with nogil:
            self.cmod.rescale(crescale_factors,degree)
    def translate(self,translation, int degree=-1):
        r"""
        Translates the module in the filtration space by this vector.
        """
        cdef vector[int64_t] ctranslation = translation
        with nogil:
            self.cmod.translate(ctranslation,degree)

    def get_filtration_values(self, bool unique=True):
        r"""
        Retrieves all filtration values of the summands of the module.

        Output format 
        -------------

        list of filtration values for parameter.
        """
        if len(self) ==0:
            return np.empty((self.num_parameters,0))
        values = tuple(
                tuple(stuff) 
                if len(stuff:=get_summand_filtration_values_i64(summand)) == self.num_parameters else list(stuff) + [[]]*(self.num_parameters - len(stuff)) for summand in self.cmod)
        try:
          values = tuple(np.concatenate([
            f[parameter]
            for f in values
            ], axis=0) for parameter in range(self.num_parameters)
          )
        except:
          return values
        if unique:
            return [np.unique(f) for f in values]
        return values

    def plot(self, int degree=-1,**kwargs)->None:
        r"""Shows the module on a plot. Each color corresponds to an apprimation summand of the module, and its shape corresponds to its support.
        Only works with 2-parameter modules.

        Parameters
        ----------
        degree = -1 : integer
            If positive returns only the image of dimension `dimension`.
        box=None : of the form [[b_x,b_y], [d_x,d_y]] where b,d are the bottom and top corner of the rectangle.
            If non-None, will plot the module on this specific rectangle.
        min_persistence =0 : float
            Only plots the summand with a persistence above this threshold.
        separated=False : bool
            If true, plot each summand in a different plot.
        alpha=1 : float
            Transparancy parameter
        save = False : string
            if nontrivial, will save the figure at this path


        Returns
        -------
        The figure of the plot.
        """
        from multipers.plots import plot2d_PyModule
        import matplotlib.pyplot as plt
        box = kwargs.pop('box', self.get_box())
        if (len(box[0]) != 2):
            print("Filtration size :", len(box[0]), " != 2")
            return
        if(degree < 0):
            dims = np.unique(self.get_dimensions())
            separated = kwargs.pop("separated", False)
            ndim = len(dims)
            scale = kwargs.pop("scale", 4)
            if separated:
                fig = None
                axes = None
            elif ndim > 1:
              fig, axes = plt.subplots(1,ndim, figsize=(ndim*scale,scale))
            else:
              fig = plt.gcf()
              axes = [plt.gca()]
            for dim_idx in range(ndim):
                if not separated:
                    plt.sca(axes[dim_idx])
                self.plot(dims[dim_idx],box=box, separated = separated, **kwargs)
            return
        corners = self.cmod.get_corners_of_dimension(degree)
        interleavings = self.get_module_of_degree(degree).get_interleavings()
        plot2d_PyModule(corners, box=box, dimension=degree, interleavings = interleavings, **kwargs)
        return
    def degree_splits(self):
        return np.asarray(self.cmod.get_degree_splits(), dtype=np.int64)


cdef dump_summand_i64(Summand[int64_t]& summand):
    cdef vector[One_critical_filtration[int64_t]] births = summand.get_birth_list()
    cdef vector[One_critical_filtration[int64_t]] deaths = summand.get_death_list()
    return (
            np.array(_vff21cview_i64(births)),
            np.array(_vff21cview_i64(deaths)),
            summand.get_dimension(),
            )

cdef inline Summand[int64_t] summand_from_dump_i64(summand_dump):
    cdef vector[int64_t] births = _py2p2_i64(summand_dump[0])
    cdef vector[int64_t] deaths = _py2p2_i64(summand_dump[1]) 
    cdef int dim = summand_dump[2]
    return Summand[int64_t](births, deaths, summand_dump[0].shape[1], dim)

cdef dump_cmod_i64(Module[int64_t]& mod):
    cdef Box[int64_t] cbox = mod.get_box()
    cdef int dim = mod.get_dimension()
    # cannot cast const vector[int64_t]& to vector[int64_t] without the explicit cast
    cdef vector[int64_t] bottom_corner = <vector[int64_t]>cbox.get_lower_corner()
    cdef vector[int64_t] top_corner = <vector[int64_t]>cbox.get_upper_corner()
    box = np.asarray([bottom_corner, top_corner])
    summands = tuple(dump_summand_i64(summand) for summand in mod)
    return box, summands

cdef Module[int64_t] cmod_from_dump_i64(module_dump):
    box = module_dump[0]
    summands = module_dump[1]
    cdef Module[int64_t] out_module = Module[int64_t]()
    out_module.set_box(Box[int64_t](box))
    for i in range(len(summands)):
        out_module.add_summand(summand_from_dump_i64(summands[i]))
    return out_module


def from_dump_i64(dump)->PyModule_i64:
    r"""Retrieves a PyModule from a previous dump.

    Parameters
    ----------

    dump: either the output of the dump function, or a file containing the output of a dump.
        The dumped module to retrieve

    Returns
    -------
    
    PyModule
        The retrieved module.
    """
    # TODO : optimize...
    mod = PyModule_i64()
    if type(dump) is str:
        dump = pickle.load(open(dump, "rb"))
    cdef Module[int64_t] cmod = cmod_from_dump_i64(dump)
    mod.cmod = cmod
    return mod



global PyModule_type, PySummand_type
PyModule_type = Union[
    PyModule_f64,
    PyModule_f32,
    PyModule_i32,
    PyModule_i64,
]
PySummand_type = Union[
    PySummand_f64,
    PySummand_f32,
    PySummand_i32,
    PySummand_i64,
]

PyBox_type = Union[
    PyBox_f64,
    PyBox_f32,
    PyBox_i32,
    PyBox_i64,
]


PyMultiDiagram_type = Union[
    PyMultiDiagram_f64,
    PyMultiDiagram_f32,
]


PyMultiDiagrams_type = Union[
    PyMultiDiagrams_f64,
    PyMultiDiagrams_f32,
]

def is_mma(stuff):
    return (False 
        or isinstance(stuff,PyModule_f64)
        or isinstance(stuff,PyModule_f32)
        or isinstance(stuff,PyModule_i32)
        or isinstance(stuff,PyModule_i64)
    )
