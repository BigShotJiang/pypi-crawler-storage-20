from copy import deepcopy
from typing import Optional

import numpy as np

import multipers.slicer as mps
from multipers.simplex_tree_multi import is_simplextree_multi
from multipers.slicer import (
    _column_type,
    _filtration_container_type,
    _valid_dtype,
    _valid_pers_backend,
    is_slicer,
)


## TODO : maybe optimize this with cython
def _blocks2boundary_dimension_grades(
    blocks,
    filtration_type=np.float64,
    num_parameters: int = -1,
    inplace: bool = False,
    is_kcritical: bool = False,
):
    """
    Turns blocks, aka scc, into the input of non-simplicial slicers.
    """
    if num_parameters < 0:
        for b in blocks:
            if len(b[0]) > 0:
                if is_kcritical:
                    num_parameters = np.asarray(b[0][0]).shape[1]
                else:
                    num_parameters = np.asarray(b[0]).shape[1]
                break
        if num_parameters < 0:
            raise ValueError("Empty Filtration")
    rblocks = blocks if inplace else deepcopy(blocks)
    rblocks.reverse()
    block_sizes = [len(b[0]) for b in rblocks]
    S = np.cumsum([0, 0] + block_sizes)
    if is_kcritical:
        multifiltration = tuple(
            stuff
            for b in rblocks
            for stuff in (b[0] if len(b[0]) > 0 else [np.empty((0, num_parameters))])
        )

    else:
        multifiltration = np.concatenate(
            tuple(
                b[0] if len(b[0]) > 0 else np.empty((0, num_parameters))
                for b in rblocks
            ),
            dtype=filtration_type,
        )
    boundary = tuple(x + S[i] for i, b in enumerate(rblocks) for x in b[1])
    dimensions = np.fromiter(
        (i for i, b in enumerate(rblocks) for _ in range(len(b[0]))), dtype=int
    )
    return boundary, dimensions, multifiltration


def _slicer_from_simplextree(st, backend, vineyard):
    if vineyard:
        if backend == "matrix":
            slicer = mps._SlicerVineSimplicial(st)
        elif backend == "clement":
            raise ValueError("This one takes a minpres")
        elif backend == "graph":
            slicer = mps._SlicerVineGraph(st)
        else:
            raise ValueError(f"Inimplemented backend {backend}.")
    else:
        if backend == "matrix":
            slicer = mps._SlicerNoVineSimplicial(st)
        elif backend == "clement":
            raise ValueError("Clement is Vineyard")
        elif backend == "graph":
            raise ValueError("Graph is Vineyard")
        else:
            raise ValueError(f"Inimplemented backend {backend}.")
    return slicer


def _slicer_from_blocks(
    blocks,
    pers_backend: _valid_pers_backend,
    vineyard: bool,
    is_kcritical: bool,
    dtype: _valid_dtype,
    col: _column_type,
    filtration_container: _filtration_container_type,
):
    boundary, dimensions, multifiltrations = _blocks2boundary_dimension_grades(
        blocks,
        inplace=False,
        is_kcritical=is_kcritical,
    )
    slicer = mps.get_matrix_slicer(
        vineyard,
        is_kcritical,
        dtype,
        col,
        pers_backend,
        filtration_container,
    )(boundary, dimensions, multifiltrations)
    return slicer


def Slicer(
    st=None,
    vineyard: Optional[bool] = None,
    reduce: bool = False,
    reduce_backend: Optional[str] = None,
    dtype: Optional[_valid_dtype] = None,
    kcritical: Optional[bool] = None,
    column_type: Optional[_column_type] = None,
    backend: Optional[_valid_pers_backend] = None,
    filtration_container: Optional[str] = None,
    max_dim: Optional[int] = None,
    return_type_only: bool = False,
    _shift_dimension: int = 0,
) -> mps.Slicer_type:
    """
    Given a simplextree or blocks (a.k.a scc for python),
    returns a structure that can compute persistence on line (or more)
    slices, eventually vineyard update, etc.

    This can be used to compute interval-decomposable module approximations
    or signed measures, using, e.g.
     - `multipers.module_approximation(this, *args)`
     - `multipers.signed_measure(this, *args)`

    Note : it is recommended and sometime required to apply
        a minimal presentation before computing these functions !
    `mp.slicer.minimal_presentation(slicer, *args, **kwargs)`

    Input
    -----
     - st : SimplexTreeMulti or scc-like blocks or path to scc file
     - backend: slicer backend, e.g, "matrix", "clement", "graph"
     - vineyard: vineyard capable (may slow down computations if true)
    Output
    ------
    The corresponding slicer.
    """
    if reduce:
        from warnings import warn

        warn(
            "Deprecated argument `reduce`. just reduce it afterwards.",
            DeprecationWarning,
        )
    if max_dim is not None:
        raise DeprecationWarning("deprecated parameter.")
    if is_slicer(st, allow_minpres=False) or is_simplextree_multi(st):
        dtype = st.dtype if dtype is None else dtype
        is_kcritical = st.is_kcritical if kcritical is None else kcritical
        filtration_container = (
            st.filtration_container
            if filtration_container is None
            else filtration_container
        )
    else:
        dtype = np.float64 if dtype is None else dtype
        is_kcritical = False if kcritical is None else kcritical
        filtration_container = (
            "contiguous" if filtration_container is None else filtration_container
        )

    if is_slicer(st, allow_minpres=False):
        vineyard = st.is_vine if vineyard is None else vineyard
        column_type = st.col_type if column_type is None else column_type
        backend = st.pers_backend if backend is None else backend
    else:
        vineyard = False if vineyard is None else vineyard
        column_type = "INTRUSIVE_SET" if column_type is None else column_type
        backend = "Matrix" if backend is None else backend

    _Slicer = mps.get_matrix_slicer(
        is_vineyard=vineyard,
        is_k_critical=is_kcritical,
        dtype=dtype,
        col=column_type,
        pers_backend=backend,
        filtration_container=filtration_container,
    )
    if return_type_only:
        return _Slicer

    if st is None:
        return _Slicer()
    elif mps.is_slicer(st):
        slicer = _Slicer(st)
    elif is_simplextree_multi(st) and backend == "Graph":
        slicer = _slicer_from_simplextree(st, backend, vineyard)
        if st.is_squeezed:
            slicer.filtration_grid = st.filtration_grid

    elif isinstance(st, str):
        slicer = _Slicer()._build_from_scc_file(st, shift_dimension=_shift_dimension)
    elif is_simplextree_multi(st):
        slicer = _Slicer().build_from_simplex_tree(st)
        if st.is_squeezed:
            slicer.filtration_grid = st.filtration_grid
    elif backend == "Graph":
        raise ValueError(
            """
Graph is simplicial, incompatible with minpres.
You can try using `multipers.slicer.to_simplextree`."""
        )
    else:
        blocks = st
        slicer = _slicer_from_blocks(
            blocks,
            backend,
            vineyard,
            is_kcritical,
            dtype,
            column_type,
            filtration_container,
        )
    if reduce:
        slicer = mps.minimal_presentation(
            slicer,
            backend=reduce_backend,
            slicer_backend=backend,
            vineyard=vineyard,
        )
    return slicer
