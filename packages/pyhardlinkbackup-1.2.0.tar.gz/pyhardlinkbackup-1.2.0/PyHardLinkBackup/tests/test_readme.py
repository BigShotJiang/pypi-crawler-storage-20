from bx_py_utils.auto_doc import assert_readme_block
from bx_py_utils.path import assert_is_file
from cli_base.cli_tools.test_utils.rich_test_utils import NoColorEnvRich, invoke
from manageprojects.tests.base import BaseTestCase

from PyHardLinkBackup import constants
from PyHardLinkBackup.cli_dev import PACKAGE_ROOT


def assert_cli_help_in_readme(text_block: str, marker: str):
    README_PATH = PACKAGE_ROOT / 'README.md'
    assert_is_file(README_PATH)

    text_block = text_block.replace(constants.CLI_EPILOG, '')
    text_block = f'```\n{text_block.strip()}\n```'
    assert_readme_block(
        readme_path=README_PATH,
        text_block=text_block,
        start_marker_line=f'[comment]: <> (✂✂✂ auto generated {marker} start ✂✂✂)',
        end_marker_line=f'[comment]: <> (✂✂✂ auto generated {marker} end ✂✂✂)',
    )


class ReadmeTestCase(BaseTestCase):

    def test_main_help(self):
        with NoColorEnvRich():
            stdout = invoke(cli_bin=PACKAGE_ROOT / 'cli.py', args=['--help'], strip_line_prefix='usage: ')

        self.assert_in_content(
            got=stdout,
            parts=(
                'usage: ./cli.py [-h]',
                ' version ',
                'Print version and exit',
                constants.CLI_EPILOG,
            ),
        )

        # Installed via pipx is called 'phlb', not 'cli.py':
        stdout = stdout.replace('./cli.py', 'phlb')

        assert_cli_help_in_readme(text_block=stdout, marker='main help')

    def test_backup_help(self):
        with NoColorEnvRich():
            stdout = invoke(cli_bin=PACKAGE_ROOT / 'cli.py', args=['backup', '--help'], strip_line_prefix='usage: ')
        self.assert_in_content(
            got=stdout,
            parts=(
                'usage: ./cli.py backup [-h] ',
                'Backup the source directory to the destination',
            ),
        )

        # Installed via pipx is called 'phlb', not 'cli.py':
        stdout = stdout.replace('./cli.py', 'phlb')

        assert_cli_help_in_readme(text_block=stdout, marker='backup help')

    def test_dev_help(self):
        with NoColorEnvRich():
            stdout = invoke(cli_bin=PACKAGE_ROOT / 'dev-cli.py', args=['--help'], strip_line_prefix='usage: ')
        self.assert_in_content(
            got=stdout,
            parts=(
                'usage: ./dev-cli.py [-h]',
                ' lint ',
                ' coverage ',
                ' update-readme-history ',
                ' publish ',
                constants.CLI_EPILOG,
            ),
        )
        assert_cli_help_in_readme(text_block=stdout, marker='dev help')
