"""ogrep test suite."""
