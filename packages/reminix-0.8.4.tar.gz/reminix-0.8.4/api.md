# Projects

Types:

```python
from reminix.types import ProjectRetrieveCurrentResponse
```

Methods:

- <code title="get /projects/current">client.projects.<a href="./src/reminix/resources/projects.py">retrieve_current</a>() -> <a href="./src/reminix/types/project_retrieve_current_response.py">ProjectRetrieveCurrentResponse</a></code>

# Agents

Types:

```python
from reminix.types import Context, StreamChunk, AgentChatResponse, AgentInvokeResponse
```

Methods:

- <code title="post /agents/{name}/chat">client.agents.<a href="./src/reminix/resources/agents.py">chat</a>(name, \*\*<a href="src/reminix/types/agent_chat_params.py">params</a>) -> <a href="./src/reminix/types/agent_chat_response.py">AgentChatResponse</a></code>
- <code title="post /agents/{name}/invoke">client.agents.<a href="./src/reminix/resources/agents.py">invoke</a>(name, \*\*<a href="src/reminix/types/agent_invoke_params.py">params</a>) -> <a href="./src/reminix/types/agent_invoke_response.py">AgentInvokeResponse</a></code>
