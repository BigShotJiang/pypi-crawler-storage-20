_D="Mapping extension clé du catalogue de readers. Ex: `{'dat1': 'csv_comma', 'dat2': 'csv_semicolon'}`"
_C='Mapping d\'extensions source - cible. Ex `{"txt": "csv"}`.'
_B='forbid'
_A=None
from pydantic import BaseModel,Field
from typing import Literal
DEFAULT_EXTENTION_ACTIVE=True
NoReaderFoundMethodType=Literal['Error','Ignore','Fallback']
class FileReaderNoReaderFoundConfig(BaseModel,extra=_B):method:NoReaderFoundMethodType=Field(default='Error',description="Méthode à éxécuter si aucun reader n'est trouvé");fallback:str|_A=Field(default=_A,description="Si la méthode est `Fallback`, code du Reader (`txt`, `csv`, ...) à utiliser si aucun Reader n'est trouvé.")
class FileReaderExtensionsConfig(BaseModel,extra=_B):active:bool=Field(default=True,description='Recherche un reader par rapport à son extension.');mapping:dict|_A=Field(default=_A,description=_C);readers_catalog:dict[str,str]|_A=Field(default=_A,description=_D)
class FileReaderConfig(BaseModel,extra=_B):encoding:str=Field(default='utf-8',description='Encodage utilisé pour lire les fichiers.');extension_unknown_ignore:bool=Field(default=False,description="Si aucun reader n'est trouvé pour une extension, passe au suivant sans générer d'erreur.");extension_fallback:str|_A=Field(default=_A,description="Si aucun reader n'est trouvé pour une extension, utilise cette extension pour déterminer le reader.");extension_mapping:dict|_A=Field(default=_A,description=_C);extension_readers_catalog:dict[str,str]|_A=Field(default=_A,description=_D);custom_curve_parser:str|dict[str,str]|_A=Field(default=_A,description="Représente le chemin d'un fichier/module python suivi par :: suivi par le nom d'une fonction à appeller pour parser les courbes d'un fichier. Le chemin peut être absolu ou relatif. Dans le cas, d'un chemin relatif, il testera le `working directory` et le `origin working directory`. Ex: `custom_parser.py::parse_curves`")