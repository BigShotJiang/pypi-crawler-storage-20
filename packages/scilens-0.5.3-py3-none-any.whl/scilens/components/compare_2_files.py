import os,re,logging,fnmatch
from scilens.run.task_context import TaskContext
from scilens.readers.reader_interface import ReaderInterface
from scilens.components.file_reader import FileReader
from scilens.components.compare_models import SEVERITY_ERROR,SEVERITY_WARNING
from scilens.components.compare_errors import CompareErrors
from scilens.components.compare_floats import CompareFloats
from scilens.config.models.compare import CompareConfig
class Compare2Files:
	def __init__(A,context):A.context=context
	def compare(H,path_test,path_ref):
		k='status';j='severity';i='comparison_errors';h='comparison';Z=path_test;Y='err_index';X='reader';W='skipped';V=None;U=path_ref;T='metrics';S='error';R=True;Q='ref';M='path';L='test';A={L:{},Q:{},h:V,i:V};I={L:{M:Z},Q:{M:U}};B=H.context.config.compare;J=B.sources.not_matching_source_ignore_pattern
		for(C,N)in I.items():
			if not N.get(M)or not os.path.exists(N[M]):
				if J:
					if J=='*':A[W]=R;return A
					else:
						l=os.path.basename(U if C==L else Z);m=re.search(J,l)
						if m:A[W]=R;return A
				A[S]=f"file {C} does not exist";return A
		n=FileReader(H.context.working_dir,H.context.config.file_reader,H.context.config.readers,config_alternate_path=H.context.origin_working_dir)
		for(C,N)in I.items():I[C][X]=n.read(N[M])
		D=I[L][X];F=I[Q][X]
		if not D or not F:A[W]=R;return A
		A[L]=D.info();A[Q]=F.info()
		if D.read_error:A[S]=D.read_error;return A
		o=os.path.basename(U);a=B.float_thresholds
		if B.name_patterns_thresholds:
			for(J,p)in B.name_patterns_thresholds.items():
				if fnmatch.fnmatch(o,J):a=p;break
		E=CompareErrors(B.errors_limit,B.ignore_warnings);b=CompareFloats(E,a);c=D.compare(b,F,param_is_ref=R);G=E.root_group;O=V
		if B.metrics_compare and(D.metrics or F.metrics):
			s,O=E.add_group(T,T,parent=G)
			if B.metrics_thresholds:d=CompareFloats(E,B.metrics_thresholds)
			else:d=b
			d.compare_dicts(D.metrics,F.metrics,O)
		K={'total_diffs':G.total_diffs}
		if G.info:K.update(G.info)
		if c:K.update(c)
		if O:
			P={}
			for e in[SEVERITY_ERROR,SEVERITY_WARNING]:
				for(q,f)in enumerate(E.errors[e]):
					if f.group==O.id:P[f.info['key']]={j:e,Y:q}
			K[T]={}
			for C in D.metrics.keys():K[T][C]={k:P[C][j],Y:P[C][Y]}if C in P else{k:'success'}
		A[h]=K;A[i]=E.get_data()
		if G.error:A[S]=G.error;return A
		D.close();F.close();g=len(E.errors[SEVERITY_ERROR])
		if g>0:r=f"{g} comparison errors";A[S]=r
		return A