"""
The MIT License (MIT)

Copyright (c) 2015-present Rapptz

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from __future__ import annotations

from typing import Literal, TypedDict, List, Optional
from typing_extensions import NotRequired

from .user import PartialUser
from .snowflake import Snowflake


class TeamMember(TypedDict):
    user: PartialUser
    membership_state: int
    permissions: List[str]
    team_id: Snowflake


class Team(TypedDict):
    id: Snowflake
    name: str
    owner_user_id: Snowflake
    icon: Optional[str]
    payout_account_status: NotRequired[Optional[Literal[1, 2, 3, 4, 5, 6]]]
    stripe_connect_account_id: NotRequired[Optional[str]]
    members: NotRequired[List[TeamMember]]


class TeamPayout(TypedDict):
    id: Snowflake
    user_id: Snowflake
    amount: int
    status: Literal[1, 2, 3, 4, 5]
    period_start: str
    period_end: Optional[str]
    payout_date: Optional[str]
    latest_tipalti_submission_response: NotRequired[dict]
