__version__ = "0.1.2"

from .core import CKRLexer, CKRParser, CKREvaluator, CKRError, CKRRuntimeError, CKRSyntaxError
