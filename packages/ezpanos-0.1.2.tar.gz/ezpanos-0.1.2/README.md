# EZPanos

#### An Ergonomic and lightweight PanOS Utility Tool

## Installation
``` bash 
pip install ezpanos
```

## Quick Start
``` python
import ezpanos

creds = {
    "username": input("Username: "),
    "password": getpass.getpass("Password: ")
}
connection = PanOS(endpoint, creds=creds)
print(connection.execute("show system info"))

```

## Using an API token

By default, the PanOS class will use username/password to generate an authentication token from PanOS. This can however, be overridden if you already have it.

``` python
import ezpanos

creds = {"api_key": "xxxxxxxxxxxxx"}

connection = PanOS(endpoint, creds=creds)

```



Currently not feature rich but an ideal platform for executing arbitrary PanOS commands against firewalls and Panorama instances for a wide variety of use cases.