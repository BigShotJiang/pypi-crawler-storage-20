"""Test suite for escape."""
