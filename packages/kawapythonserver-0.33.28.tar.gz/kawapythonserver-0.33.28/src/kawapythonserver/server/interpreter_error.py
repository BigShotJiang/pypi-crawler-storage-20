class InterpreterError(Exception):
    pass
