"""AFD test suite."""
