"""Twig - A terminal TUI for managing Git branches."""

from .app import TwigApp

__version__ = "0.2.1"
__all__ = ["TwigApp"]
