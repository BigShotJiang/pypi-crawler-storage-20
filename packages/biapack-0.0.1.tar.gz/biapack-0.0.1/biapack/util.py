from mcp.server.fastmcp import FastMCP
from .header_params import HeaderParams

import boto3
import os

class Util():

    def __init__(self, mcp: FastMCP):
        self.mcp = mcp

    def __get_from_ssm(self, parameter_name: str) -> str:
        """Busca o parâmetro no AWS SSM Parameter Store"""
        ctx = self.mcp.get_context()
        headers = ctx.request_context.request.headers
        prefix = headers.get("prefix", None)
        client = boto3.client('ssm', region_name="sa-east-1")
        response = client.get_parameter(
            Name=f"{prefix}/{parameter_name}",
            WithDecryption=True
        )
        return response.get('Parameter').get('Value')

    def get_header_params(self) -> HeaderParams:
        """Retorna os parâmetros do contexto da requisição"""
        ctx = self.mcp.get_context()
        headers = ctx.request_context.request.headers

        return HeaderParams(
            current_host=headers.get("current_host", None),
            user_email=headers.get("user_email", None),
            jwt_token=headers.get("jwt_token", None),
            jsessionid=headers.get("jsessionid", None),
            organization_id=int(headers.get("organization_id", 0)),
            codparc=int(headers.get("codparc", 0)),
            iam_user_id=int(headers.get("iam_user_id", 0)),
            gateway_token=headers.get("gateway_token", None)
        )
    
    def get_parameter(self, parameter_name: str) -> str:
        return os.getenv(
            parameter_name,
            self.__get_from_ssm(parameter_name)
        )