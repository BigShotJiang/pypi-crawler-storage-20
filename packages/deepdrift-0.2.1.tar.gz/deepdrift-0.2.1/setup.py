from setuptools import setup, find_packages
from pathlib import Path

# Читаем текст из README.md
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="deepdrift",
    version="0.2.1",  # <-- Поднимаем версию!
    description="A Layer-Wise Diagnostic Framework for Neural Network Robustness",
    long_description=long_description,  # <-- Вставляем текст из README
    long_description_content_type='text/markdown', # <-- Говорим, что это Markdown
    author="Alexey Evtushenko",
    author_email="alexey@deepdrift.ai",
    url="https://github.com/Eutonics/DeepDrift", # Ссылка на гитхаб (появится кнопка на PyPI)
    packages=find_packages(),
    install_requires=[
        "torch>=1.10.0",
        "torchvision>=0.11.0",
        "numpy",
        "tqdm",
        "matplotlib",
        "seaborn"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)