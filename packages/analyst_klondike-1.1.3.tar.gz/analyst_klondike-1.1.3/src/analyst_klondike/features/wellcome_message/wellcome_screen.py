from importlib.metadata import version
from rich.text import Text
import pyfiglet
from textual import on
from textual.widgets import Footer, Static, Markdown, Button
from textual.containers import VerticalScroll, Horizontal, Container
from textual.app import ComposeResult
from textual.screen import ModalScreen

from analyst_klondike.features.demo_quiz.demo import start_demo_quiz


all_fonts = pyfiglet.FigletFont.getFonts()


COLORS = [
    "#881177",
    "#aa3355",
    "#cc6666",
    "#ee9944",
    "#eedd00",
    "#99dd55",
    "#44dd88",
    "#22ccbb",
    "#00bbcc",
    "#0099cc",
    "#3366bb",
    "#663399",
]


def _get_title(title: str, font: str) -> Text:
    large_text = str(pyfiglet.figlet_format(title, font=font, width=1000))
    lines = [line for line in large_text.splitlines(
        keepends=True) if line.strip() != ""]
    return Text.assemble(*zip(lines, COLORS))


HELP_MD = """
Вас приветствует **Клондайк аналитика {ak_ver}** - интерактивный тренажер Python на вашем компьютере.

### Команды

- `Ctrl +` увеличить масштаб.
- `Ctrl -` уменьшить масштаб.
- `F1` Открыть справку.
- `F5` Запустить программу.
- `Ctrl O` Открыть файл с задачами.
- `Ctrl S` Сохранить текущий файл.
- `F10` Закрыть программу.


### Демо

Чтобы ознакомиться с возможностями программы, пройдите [демо-тест](demo).

### Как решать задачи на тренажере:
‣ Скачать файл с задачами на компьютер. Например, my_tasks.yaml

‣ Перейти в каталог, где находится загруженный файл, набрав команду в терминале:

`cd ~/path/to/my/downloaded_file`

Можно убедиться, что файл действительно есть в каталоге, набрав команду ls:

‣ Запустить программу, указав файл с задачами. Не забываем про расширение файла. Команда:

`analyst_klodike my_tasks.yaml`

‣ Допускается запуск тренажера без указания файла. После запуска программы нажмите кнопку "Открыть тест", чтобы выбрать файл с задачами. Для этого напишите в терминале:

`analyst_klodike`

Успехов!

### Условия использования
Данная программа - коммерческий продукт. Никакая ее часть не может быть использована без разрешения автора. Исходный код программы является закрытым. Никая часть исходного кода не может быть использована без разрешения автора. Исключительные права на эту программу принадлежат Малюге Илье Викторовичу (info@клондайк-аналитика.рф).
"""


class WellcomeScreen(ModalScreen[bool]):

    CSS_PATH = "styles.tcss"

    BINDINGS = [
        ("escape", "dismiss")
    ]

    def compose(self) -> ComposeResult:
        yield Footer()
        with Container(id="dialog-container") as dialog_container:
            with VerticalScroll():
                yield Static(_get_title("Klondike", "ansi_shadow"), classes="title")
                yield Static(_get_title("code editor", "pagga"), classes="subtitle")
                yield Markdown(HELP_MD.format(ak_ver=version("analyst_klondike")), open_links=False)
            with Horizontal(id="button-container"):
                yield Button("Демо", id="demo_button", variant='success', compact=True)
                yield Container(classes="separator")
                yield Button("Закрыть", id="close_button", variant="primary", compact=True)
        dialog_container.border_title = "Справка"
        # yield Markdown(HELP_MD)
        # # with Center():
        # #     for font in all_fonts:
        # #         yield Static(font)
        # #         yield Static(_get_title(font))

    def on_markdown_link_clicked(self, event: Markdown.LinkClicked) -> None:
        if event.href == "demo":
            close_wellcome_screen()
            start_demo_quiz()

    @on(Button.Pressed, "#demo_button")
    def on_save_button_clicked(self) -> None:
        close_wellcome_screen()
        start_demo_quiz()

    @on(Button.Pressed, "#close_button")
    def on_close_button_clicked(self) -> None:
        self.dismiss()


def push_wellcome_screen():
    # pylint: disable=import-outside-toplevel
    from analyst_klondike.ui.runner_app import get_app
    app = get_app()
    app.push_screen(WellcomeScreen())


def close_wellcome_screen():
    # pylint: disable=import-outside-toplevel
    from analyst_klondike.ui.runner_app import get_app
    app = get_app()
    if isinstance(app.screen_stack[-1], WellcomeScreen):
        app.pop_screen()
