from functools import wraps
from typing import Any, Callable
from analyst_klondike.state.app_state import AppState
from analyst_klondike.state.base_action import BaseAction


def for_actions(*actions: type[BaseAction]) -> Any:

    def decorator(f: Callable[[Any, AppState], None]):

        @wraps(f)
        def wrapper(self: Any, state: AppState | None):
            if state is None:
                raise ValueError("Must provide state to have last action type")
            if state.last_action_type in [a.type for a in actions]:
                f(self, state)

        return wrapper

    return decorator


def exclude_actions(*actions: type[BaseAction]) -> Any:
    def decorator(f: Callable[[Any, AppState], None]):

        @wraps(f)
        def wrapper(self: Any, state: AppState | None):
            if state is None:
                raise ValueError("Must provide state to have last action type")
            if state.last_action_type not in [a.type for a in actions]:
                f(self, state)

        return wrapper

    return decorator


__all__ = [
    "for_actions",
    "exclude_actions"
]
