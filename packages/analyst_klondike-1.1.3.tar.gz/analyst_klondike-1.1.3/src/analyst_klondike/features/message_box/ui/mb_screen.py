from textual import on
from textual.app import ComposeResult
from textual.containers import (
    Vertical,
    Horizontal,
    Container,
    VerticalScroll)
from textual.widgets import Button, Static
from textual.screen import ModalScreen
from analyst_klondike.state.app_state import AppState, get_state


class MessageBoxScreen(ModalScreen[AppState]):

    def __init__(self,
                 name: str | None = None,
                 id: str | None = None,
                 classes: str | None = None,
                 message: str | None = None) -> None:
        super().__init__(name, id, classes)
        self._message = message or ""

    CSS_PATH = "mb_screen.tcss"

    BINDINGS = [
        ("escape", "dismiss")
    ]

    def compose(self) -> ComposeResult:
        yield Container(id="shadow")
        with Vertical(id="dialog"):
            with VerticalScroll():
                yield Static(self._message)
            with Horizontal(id="buttons"):
                yield Button(id="ok_button",
                             label="ОК",
                             variant="success")

    @on(Button.Pressed, "#ok_button")
    def ok_button_click(self) -> None:
        state = get_state()
        self.dismiss(state)
