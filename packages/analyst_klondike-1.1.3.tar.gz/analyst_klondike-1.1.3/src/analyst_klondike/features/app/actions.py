from dataclasses import dataclass
from analyst_klondike.state.base_action import BaseAction


@dataclass
class ChangeThemeAction(BaseAction):
    type = "CHANGE_THEME_ACTION"
    theme: str
    is_dark: bool


@dataclass
class EditorScreenReadyAction(BaseAction):
    type = "EDITOR_SCREEN_READY_ACTION"


@dataclass
class ChangeAppTitleAction(BaseAction):
    type = "CHANGE_APP_TITLE_ACTION"
    title: str
    sub_title: str


@dataclass
class SetWorkingDirectoryAction(BaseAction):
    type = "SET_WORKING_DIRECTORY_ACTION"
    path: str


@dataclass
class SetAppCurrentVersion(BaseAction):
    type = "SET_APP_CURRENT_VERSION"
    version: str
