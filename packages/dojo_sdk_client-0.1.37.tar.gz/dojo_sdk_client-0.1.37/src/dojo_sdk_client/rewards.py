import logging
import traceback

from dojo_sdk_core import TaskDefinition
from dojo_sdk_core.dojos.rewards.backend import Backend

logger = logging.getLogger(__name__)


class ExecBackend(Backend):
    """Backend implementation for executing storage queries during reward calculation."""

    def __init__(self, engine, exec_id: str):
        self.engine = engine
        self.exec_id = exec_id

    def query(self, query):
        return self.engine.query_storage_sync(self.exec_id, query)["data"]


def _rewards_v2(
    task_def: TaskDefinition,
    sanitized_state: dict,
    exec_id: str,
    engine,
) -> tuple[float, str]:
    """Reward function for v2 tasks.

    V2 tasks use the task definition's reward_v2 function which takes
    an ExecBackend and the sanitized state.
    """
    reward_v2, reward_v2_reason = task_def.reward_v2(
        ExecBackend(engine, exec_id),
        sanitized_state,
    )

    if reward_v2 < 1.0:
        reward_v2 = 0.0

    return reward_v2, reward_v2_reason


async def _rewards_v1(
    task_def: TaskDefinition,
    sanitized_state: dict,
    exec_id: str,
    engine,
) -> tuple[float, str]:
    """Reward function for v1 tasks.

    V1 tasks use separate frontend and backend validation functions.
    Frontend validation compares initial state to final state.
    Backend validation queries storage and validates the results.
    """
    validate_frontend = task_def.reward.get("validate_frontend")
    validate_backend = task_def.reward.get("validate_backend")
    state_keys = task_def.reward.get("state_key")

    backend_weight = 0.5
    frontend_weight = 0.5

    if state_keys == {} or state_keys is None or len(state_keys) == 0:
        backend_weight = 0
        frontend_weight = 1

    # Frontend validation
    try:
        reward_frontend_score, frontend_reason = validate_frontend(task_def.initial_state, sanitized_state)
    except Exception as e:
        logger.error(f"Error validating frontend for task {exec_id}: {e} {traceback.format_exc()}")
        reward_frontend_score = 0.0
        frontend_reason = "Error validating frontend"

    # Backend validation
    state_key = task_def.reward.get("state_key")
    if state_key == {} or state_key is None:
        reward_backend_score, backend_reason = 0.0, "No backend validation required"
    else:
        result = {}
        for key, query_def in state_key.items():
            collection = query_def.get("collection")

            if not collection:
                continue

            query_def.setdefault("filter", {})

            response = await engine.query_storage(exec_id, query_def)
            result[key] = response.get("data", [])

        try:
            reward_backend_score, backend_reason = validate_backend(result)
        except Exception as e:
            logger.error(f"Error validating backend for task {exec_id}: {e} {traceback.format_exc()}")
            reward_backend_score = 0.0
            backend_reason = "Error validating backend"

    # Calculate weighted reward
    reward = (reward_frontend_score * frontend_weight + reward_backend_score * backend_weight) / (
        frontend_weight + backend_weight
    )
    reason = f"frontend: {frontend_reason} backend: {backend_reason}"

    if reward < 1.0:
        reward = 0.0

    return reward, reason


async def calculate_rewards(
    task_def: TaskDefinition,
    sanitized_state: dict,
    exec_id: str,
    engine,
) -> tuple[float, str]:
    """Calculate the reward for a task based on its version.

    Args:
        task_def: The task definition containing reward configuration
        sanitized_state: The sanitized final state of the task
        exec_id: The execution ID for storage queries
        engine: The engine instance for executing storage queries

    Returns:
        A tuple of (reward_score, reason_string)
    """
    if task_def.version == "2.0":
        return _rewards_v2(task_def, sanitized_state, exec_id, engine)
    else:
        return await _rewards_v1(task_def, sanitized_state, exec_id, engine)
