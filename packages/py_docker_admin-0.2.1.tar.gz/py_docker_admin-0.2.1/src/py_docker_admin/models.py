# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Pydantic models for py-docker-admin configuration."""

from pydantic import BaseModel, Field, field_validator
from typing import List, Optional
import re

class DockerConfig(BaseModel):
    """Configuration for Docker installation."""

    install: bool = Field(
        default=True,
        description="Whether to install Docker"
    )
    restart_service: bool = Field(
        default=True,
        description="Whether to restart Docker service after installation"
    )
    add_user_to_group: bool = Field(
        default=True,
        description="Whether to add current user to docker group"
    )

class PortainerConfig(BaseModel):
    """Configuration for Portainer installation and setup."""

    container_name: str = Field(
        default="portainer",
        description="Name for the Portainer container"
    )
    port: int = Field(
        default=9000,
        description="Port to expose Portainer on",
        ge=1024,
        le=65535
    )
    admin_username: str = Field(
        default="admin",
        description="Admin username for Portainer"
    )
    admin_password: str = Field(
        default="",
        description="Admin password for Portainer"
    )
    volume: str = Field(
        default="/var/run/docker.sock:/var/run/docker.sock",
        description="Volume mapping for Docker socket"
    )
    remove_existing: bool = Field(
        default=False,
        description="Remove existing Portainer container if found"
    )

    @field_validator('admin_password')
    def validate_password(cls, v: str) -> str:
        """Validate that password meets minimum requirements."""
        if not v:
            raise ValueError("Admin password cannot be empty")
        if len(v) < 8:
            raise ValueError("Admin password must be at least 8 characters")
        return v

class StackConfig(BaseModel):
    """Configuration for a single stack to be deployed."""

    name: str = Field(
        description="Name of the stack"
    )
    compose_file: str = Field(
        description="Path to docker-compose file"
    )
    env_file: Optional[str] = Field(
        default=None,
        description="Path to environment file (optional)"
    )
    endpoint_id: Optional[int] = Field(
        default=None,
        description="Portainer endpoint ID (optional)"
    )

class MainConfig(BaseModel):
    """Main configuration model combining all configurations."""

    docker: DockerConfig = Field(
        default_factory=DockerConfig,
        description="Docker installation configuration"
    )
    portainer: PortainerConfig = Field(
        default_factory=PortainerConfig,
        description="Portainer configuration"
    )
    stacks: List[StackConfig] = Field(
        default_factory=list,
        description="List of stacks to deploy"
    )

    @classmethod
    def from_yaml(cls, yaml_content: str) -> 'MainConfig':
        """Create configuration from YAML content."""
        import yaml
        config_dict = yaml.safe_load(yaml_content)
        return cls(**config_dict)

    def to_yaml(self) -> str:
        """Convert configuration to YAML string."""
        import yaml
        return yaml.safe_dump(self.model_dump(), sort_keys=False)
