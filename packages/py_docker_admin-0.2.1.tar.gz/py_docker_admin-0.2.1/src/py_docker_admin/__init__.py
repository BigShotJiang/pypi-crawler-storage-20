# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""py-docker-admin - Automate Docker and Portainer installation and stack deployment."""

from .cli import app
from .models import MainConfig, DockerConfig, PortainerConfig, StackConfig
from .exceptions import (
    DockerAdminError,
    DockerInstallationError,
    PortainerInstallationError,
    PortainerAPIError,
    StackCreationError,
    ConfigurationError,
    DockerNotRunningError
)

__version__ = "0.1.0"
__all__ = [
    "app",
    "MainConfig",
    "DockerConfig",
    "PortainerConfig",
    "StackConfig",
    "DockerAdminError",
    "DockerInstallationError",
    "PortainerInstallationError",
    "PortainerAPIError",
    "StackCreationError",
    "ConfigurationError",
    "DockerNotRunningError"
]
