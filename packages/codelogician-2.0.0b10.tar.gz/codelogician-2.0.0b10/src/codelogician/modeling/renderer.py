#
#   Imandra Inc.
#
#   renderer.py
#

from rich import box
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

from ..strategy.cl_agent_state import frm_status_to_rich
from ..util import maybe_else
from .model import Model


def render_model(model: Model):
    table = Table(
        title=Text(f'Model: {model.rel_path}', style='bold italic magenta'),
        box=box.MINIMAL_DOUBLE_HEAD,
        show_lines=True,
    )

    table.add_column('Name')
    table.add_column('Attribute')

    src_code_str = 'N/A' if model.src_code is None else model.src_code
    user_iml_code_str = (
        'N/A' if model.user_iml_edit is None else model.user_iml_edit.user_iml_entry
    )
    user_iml_code_last_change = (
        'N/A' if model.user_iml_edit is None else str(model.user_iml_edit.time_of_edit)
    )

    needs_frm_str = 'Yes' if model.static_frm_reasons == [] else 'No'
    frozen_str = 'Yes' if model.iml_code_frozen else 'No'

    iml_code_str = 'N/A' if not model.iml_code() else str(model.iml_code())

    eval_result_str = 'N/A' if not model.agent_state else model.agent_state.eval_res

    # fmt: off
    table.add_row('Relative path',              Text(model.rel_path, style='bold')                      )
    table.add_row('Formalization status',       frm_status_to_rich(model.formalization_status())        )
    table.add_row('Eval result',                Text(eval_result_str, style='bold')                    )
    table.add_row('Needs formalization?',       Text(needs_frm_str, style='bold')                      )
    table.add_row('Formalization reasons',      Text(str(model.static_frm_reasons))                     )
    table.add_row('Frozen?',                    Text(frozen_str)                                       )
    table.add_row('Src last changed',           Text(f'{model.src_code_last_changed}', style='bold')    )
    table.add_row('Src code',                   Syntax(src_code_str, 'python')                         )
    table.add_row('IML code',                   Syntax(iml_code_str, 'ocaml')                          )
    table.add_row('User IML code',              Syntax(user_iml_code_str, 'ocaml')                     )
    table.add_row('User IML code last changed', Text(f'{user_iml_code_last_change}', style='bold')     )
    table.add_row('Src Code Embeddings',        Text(f'{bool(model.src_code_embeddings)}', style='bold'))
    table.add_row('IML Code Ebeddings',         Text(f'{bool(model.iml_code_embeddings)}', style='bold'))
    table.add_row('Context',                    Text(f'{model.context}', style='bold')                  )
    table.add_row('Task ID',                    Text(f'{model.outstanding_task_ID}', style='bold')      )
    table.add_row('Deps',                       Text(f'{model.dependencies}', style='bold')             )
    table.add_row('Opaques',                    Text(f'{model.opaque_funcs()}', style='bold')           )
    table.add_row('Verification Goals',         Text(f'{model.verification_goals()}', style='bold')     )
    table.add_row('Decompositions',             Text(f'{model.decomps()}', style='bold')                )
    # fmt: on

    return table


def render_model_list(models: list[Model]):
    table = Table(
        title=Text('Models list', style='bold italic magenta'),
        box=box.MINIMAL_DOUBLE_HEAD,
        show_lines=True,
    )

    # fmt: off
    table.add_column('ID'                       , justify='right', no_wrap=True )
    table.add_column('Frm Status'               , justify='right', no_wrap=True )
    table.add_column('Frozen'                   , justify='right', no_wrap=True )
    table.add_column('Needs frm?'               , justify='right', no_wrap=True )
    table.add_column('Frm Needs'                , justify='right', no_wrap=False)
    table.add_column('Rel path'                 , justify='right', no_wrap=True )
    table.add_column('Src Last Changed'         , justify='right', no_wrap=True )
    table.add_column('User IML Code'            , justify='right', no_wrap=True )
    table.add_column('User IML Code Last Chged' , justify='right', no_wrap=True )
    table.add_column('Src Code Embds'           , justify='right', no_wrap=True )
    table.add_column('IML Code Embds'           , justify='right', no_wrap=True )
    table.add_column('Context'                  , justify='right' )
    table.add_column('Task ID'                  , justify='right' )
    table.add_column('Dependencies'             , justify='right', no_wrap=False)
    table.add_column('Num opaques'              , justify='right' )
    table.add_column('Num VGs'                  , justify='right' )
    table.add_column('Num Decomps'              , justify='right' )

    def yes_no(b): return 'Yes' if b else 'No'
    def edit_time(e): return str(e.time_of_edit)
    # fmt: on

    for m_id, m in enumerate(models):
        table.add_row(
            Text(f'{m_id}', style='bold'),
            frm_status_to_rich(m.formalization_status()),
            Text(f'{yes_no(m.iml_code_frozen)}', style='bold'),
            Text(f'{yes_no(m.static_frm_reasons)}', style='bold'),
            Text(f'{map(str, m.static_frm_reasons)}', style='bold'),
            Text(f'{m.rel_path}', style='bold'),
            Text(f'{m.src_code_last_changed}', style='bold'),
            Text(f'{m.user_iml_edit is not None}', style='bold'),
            Text(f'{maybe_else("N/A", edit_time, m.user_iml_edit)}', style='bold'),
            Text(f'{bool(m.src_code_embeddings)}', style='bold'),
            Text(f'{bool(m.iml_code_embeddings)}', style='bold'),
            Text(f'{m.context}', style='bold'),
            Text(f'{m.outstanding_task_ID}', style='bold'),
            Text(f'{m.dependencies}', style='bold'),
            Text(f'{len(m.opaque_funcs())}', style='bold'),
            Text(f'{len(m.verification_goals())}', style='bold'),
            Text(f'{len(m.decomps())}', style='bold'),
        )

    return table
