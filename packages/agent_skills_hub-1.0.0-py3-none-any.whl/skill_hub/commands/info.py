"""
查看技能信息命令模块
"""

import os
from pathlib import Path


def show_skill_info(target=None):
    """
    显示技能的 SKILL.md 内容
    :param target: 技能标识 (格式: skill@repo)
    """
    if not target:
        print("请指定要查看的技能 (格式: skill@repo)")
        return

    if '@' not in target:
        print("无效的技能格式，请使用 skill@repo 格式")
        return

    skill_name, repo = target.split('@', 1)
    
    # 解析 repo 为 owner/repo_name 格式
    repo_parts = repo.split('/')
    if len(repo_parts) != 2:
        print(f"无效的仓库格式: {repo}，应为 owner/repo_name 格式")
        return
    
    owner, repo_name = repo_parts
    
    # 构建技能目录路径
    skill_hub_dir = Path.home() / '.skill-hub'
    repo_dir = skill_hub_dir / owner / repo_name
    
    # 检查仓库目录是否存在
    if not repo_dir.exists():
        print(f"仓库 {owner}/{repo_name} 不存在")
        return

    # 检查仓库根目录是否有SKILL.md（整个仓库作为一个技能的情况）
    root_skill_md = repo_dir / 'SKILL.md'
    if root_skill_md.exists() and skill_name == repo_name:
        # 这种情况是整个仓库作为一个技能
        _show_skill_content(repo_dir, target)
        return

    # 在仓库目录下查找技能
    skill_dir = repo_dir / skill_name
    if skill_dir.exists():
        # 检查当前目录是否有SKILL.md
        skill_md_path = skill_dir / 'SKILL.md'
        if skill_md_path.exists():
            _show_skill_content(skill_dir, target)
            return
        else:
            # 检查子目录中是否有SKILL.md
            for sub_dir in skill_dir.iterdir():
                if sub_dir.is_dir():
                    sub_skill_md_path = sub_dir / 'SKILL.md'
                    if sub_skill_md_path.exists():
                        _show_skill_content(sub_dir, target)
                        return
    
    print(f"技能 {target} 未安装或路径不存在")


def _show_skill_content(skill_dir, target):
    """
    显示技能内容的辅助函数
    """
    # 查找 SKILL.md 文件
    skill_md_path = skill_dir / 'SKILL.md'
    
    if not skill_md_path.exists():
        print(f"在技能 {target} 中未找到 SKILL.md 文件")
        return

    # 使用 less 命令打开 SKILL.md 文件
    import subprocess
    import os
    
    # 尝试使用 less 命令打开文件
    try:
        # 设置 LESS 环境变量以改善显示效果
        env = os.environ.copy()
        env['LESS'] = 'FRX'  # F: quit if one screen, R: raw control chars, X: don't clear screen
        subprocess.run(['less', str(skill_md_path)], check=True, env=env)
    except subprocess.CalledProcessError:
        print(f"无法使用 less 打开文件: {skill_md_path}")
    except FileNotFoundError:
        print(f"less 命令未找到，显示文件内容:\n")
        with open(skill_md_path, 'r', encoding='utf-8') as f:
            content = f.read()
            print(content)