"""
管理技能命令模块
"""

import os
import curses
from pathlib import Path


def manage_skills():
    """管理skill"""
    skill_hub_dir = Path.home() / '.skill-hub'
    
    if not skill_hub_dir.exists():
        print("没有已安装的技能")
        return
    
    # 获取已安装的技能列表
    installed_skills = []
    for owner_dir in skill_hub_dir.iterdir():
        if owner_dir.is_dir():
            owner_name = owner_dir.name
            # 遍历所有仓库目录
            for repo_dir in owner_dir.iterdir():
                if repo_dir.is_dir():
                    repo_name = repo_dir.name
                    # 检查仓库目录下是否有SKILL.md（整个仓库作为一个技能的情况）
                    root_skill_md = repo_dir / 'SKILL.md'
                    if root_skill_md.exists():
                        # 整个仓库作为技能，skill_name与repo_name相同
                        skill_name = repo_name
                        installed_skills.append({
                            'name': f"{skill_name}@{owner_name}/{repo_name}",
                            'path': repo_dir
                        })
                    else:
                        # 遍历仓库目录下的所有子文件夹（可能包含多个技能）
                        for skill_dir in repo_dir.iterdir():
                            if skill_dir.is_dir():
                                skill_name = skill_dir.name
                                # 检查这个技能目录下是否有SKILL.md
                                skill_md_path = skill_dir / 'SKILL.md'
                                if skill_md_path.exists():
                                    installed_skills.append({
                                        'name': f"{skill_name}@{owner_name}/{repo_name}",
                                        'path': skill_dir
                                    })
                                else:
                                    # 检查子目录中是否有SKILL.md
                                    for sub_dir in skill_dir.iterdir():
                                        if sub_dir.is_dir():
                                            sub_skill_md_path = sub_dir / 'SKILL.md'
                                            if sub_skill_md_path.exists():
                                                # 这里应该用子目录的名字作为技能名
                                                sub_skill_name = sub_dir.name
                                                installed_skills.append({
                                                    'name': f"{sub_skill_name}@{owner_name}/{repo_name}",
                                                    'path': sub_dir
                                                })
    
    if not installed_skills:
        print("没有已安装的技能")
        return
    
    # 启动交互界面
    curses.wrapper(lambda stdscr: _skill_management_ui(stdscr, installed_skills))


def _skill_management_ui(stdscr, skills):
    """技能管理交互界面"""
    # 初始化curses
    curses.curs_set(0)  # 隐藏光标
    stdscr.nodelay(0)
    stdscr.timeout(-1)  # 阻塞等待输入
    
    current_row = 0
    viewing_skill = None  # 当前查看的技能详情
    search_mode = False
    search_query = ""
    filtered_skills = skills
    viewing_offset = 0  # 详情页偏移量，用于上下滚动
    
    while True:
        stdscr.clear()
        
        if viewing_skill is not None:
            # 显示技能详情
            detail_title = f"技能详情: {viewing_skill['name']} (按 ESC 返回列表)"
            stdscr.addstr(0, 0, detail_title[:curses.COLS-1])
            stdscr.addstr(1, 0, "使用箭头键上下滚动，ESC 返回列表")
            stdscr.addstr(2, 0, "="*50)
            
            # 读取并显示SKILL.md内容
            skill_md_path = viewing_skill['path'] / 'SKILL.md'
            if skill_md_path.exists():
                try:
                    with open(skill_md_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                    
                    # 计算显示区域的高度
                    display_start = viewing_offset
                    display_end = min(display_start + (curses.LINES - 5), len(lines))
                    
                    for i, line in enumerate(lines[display_start:display_end]):
                        stdscr.addstr(i + 3, 0, line.rstrip()[:curses.COLS-1])
                    
                    # 显示滚动提示
                    if display_end < len(lines):
                        stdscr.addstr(curses.LINES - 1, 0, f"-- 更多内容 ({display_end}/{len(lines)}) --"[:curses.COLS-1])
                except Exception as e:
                    error_msg = f"读取技能描述文件失败: {e}"[:curses.COLS-1]
                    if curses.LINES > 3:
                        stdscr.addstr(3, 0, error_msg)
            else:
                if curses.LINES > 3:
                    stdscr.addstr(3, 0, "未找到 SKILL.md 文件"[:curses.COLS-1])
            
            stdscr.refresh()
            
            # 等待用户按键
            key = stdscr.getch()
            
            if key == 27:  # ESC键返回列表
                viewing_skill = None
                viewing_offset = 0  # 重置偏移量
            elif key == curses.KEY_UP:
                # 向上滚动
                if viewing_offset > 0:
                    viewing_offset -= 1
            elif key == curses.KEY_DOWN:
                # 向下滚动
                skill_md_path = viewing_skill['path'] / 'SKILL.md'
                if skill_md_path.exists():
                    with open(skill_md_path, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                    if viewing_offset < len(lines) - (curses.LINES - 5):
                        viewing_offset += 1
        else:
            # 显示技能列表
            if search_mode:
                prompt = f"搜索技能 (输入查询词, Enter确认, ESC退出搜索): {search_query}"
            else:
                prompt = "技能管理 (上下移动, d 删除, 回车查看, 其他字母开始搜索, ESC 退出):"
            
            stdscr.addstr(0, 0, prompt[:curses.COLS-1])
            
            # 只显示适合屏幕大小的技能列表项
            max_display_items = curses.LINES - 3  # 保留顶部标题和底部空间
            for idx in range(min(len(filtered_skills), max_display_items)):
                skill = filtered_skills[idx]
                prefix = "> " if idx == current_row else "  "
                # 确保技能名称不会超出屏幕宽度
                display_text = (prefix + skill['name'])[:curses.COLS-1]
                if idx == current_row:
                    stdscr.addstr(idx + 2, 0, display_text, curses.A_REVERSE)
                else:
                    stdscr.addstr(idx + 2, 0, display_text)
            
            # 显示搜索模式提示
            if search_mode:
                stdscr.addstr(curses.LINES - 1, 0, "搜索模式: 直接输入进行搜索，ESC取消"[:curses.COLS-1])
            
            stdscr.refresh()
            
            # 获取用户输入
            key = stdscr.getch()
            
            if search_mode:
                # 处理搜索模式输入
                if key == 27:  # ESC键取消搜索
                    search_mode = False
                    search_query = ""
                    filtered_skills = skills
                    current_row = 0
                elif key == curses.KEY_BACKSPACE or key == 127 or key == 8:  # 退格键
                    if search_query:
                        search_query = search_query[:-1]
                    # 实时更新搜索结果
                    if search_query.strip():
                        filtered_skills = [skill for skill in skills if search_query.lower() in skill['name'].lower()]
                    else:
                        filtered_skills = skills
                    current_row = 0
                elif 32 <= key <= 126:  # 可打印字符
                    search_query += chr(key)
                    # 实时更新搜索结果
                    filtered_skills = [skill for skill in skills if search_query.lower() in skill['name'].lower()]
                    current_row = 0
                continue  # 继续循环，不执行下面的普通按键处理
            
            if key == ord('q') or key == 27:  # q键或ESC键退出
                break
            elif key == curses.KEY_UP:
                current_row = max(0, current_row - 1)
            elif key == curses.KEY_DOWN:
                current_row = min(len(filtered_skills) - 1, current_row + 1)
            elif key == ord('\n') or key == ord('\r'):  # 回车键查看详情
                if filtered_skills:
                    viewing_skill = filtered_skills[current_row]
                    viewing_offset = 0  # 重置详情页偏移量
            elif key == ord('d'):  # d键删除
                if filtered_skills:
                    skill_to_remove = filtered_skills[current_row]
                    stdscr.clear()
                    confirm_msg = f"确定要删除 {skill_to_remove['name']} 吗? (y/N)"
                    stdscr.addstr(0, 0, confirm_msg[:curses.COLS-1])
                    stdscr.refresh()
                    
                    confirm_key = stdscr.getch()
                    if confirm_key in [ord('y'), ord('Y')]:
                        from skill_hub.commands.uninstall import uninstall_specific_skill
                        if '@' in skill_to_remove['name']:
                            parts = skill_to_remove['name'].split('@', 1)
                            if '/' in parts[1]:  # 如果是 owner/repo_name 格式
                                skill_name = parts[0]
                                repo_parts = parts[1].split('/', 1)
                                repo_full = f"{repo_parts[0]}/{repo_parts[1]}"
                                uninstall_specific_skill(skill_name, repo_full)
                            else:  # 如果是简单格式
                                skill_name, repo = parts
                                uninstall_specific_skill(skill_name, repo)
                            
                            # 从列表中移除
                            index_to_remove = next((i for i, skill in enumerate(skills) if skill['name'] == skill_to_remove['name']), -1)
                            if index_to_remove != -1:
                                del skills[index_to_remove]
                            
                            # 重新过滤列表
                            if search_query.strip():
                                filtered_skills = [skill for skill in skills if search_query.lower() in skill['name'].lower()]
                            else:
                                filtered_skills = skills
                            
                            current_row = min(current_row, len(filtered_skills) - 1)
                            
                        if curses.LINES > 2:  # 确保有足够的行来显示消息
                            stdscr.addstr(2, 0, "删除完成，按任意键继续..."[:curses.COLS-1])
                        stdscr.refresh()
                        stdscr.getch()
            else:
                # 检查是否是字母，如果是则进入搜索模式
                if 65 <= key <= 90 or 97 <= key <= 122:  # A-Z 或 a-z
                    search_mode = True
                    search_query = chr(key)
                    filtered_skills = [skill for skill in skills if search_query.lower() in skill['name'].lower()]
                    current_row = 0