"""
搜索技能命令模块
"""

import requests
import curses
from pathlib import Path
import threading
import queue


def search_skills():
    """搜索skill"""
    try:
        # 获取技能列表
        response = requests.get('https://skill-hub.oss-cn-shanghai.aliyuncs.com/skill.list')
        skills = [line.strip() for line in response.text.strip().split('\n') if line.strip()]
        
        if not skills:
            print("没有找到可用的技能")
            return
        
        # 启动交互界面
        curses.wrapper(lambda stdscr: _skill_selection_ui(stdscr, skills))
        
    except Exception as e:
        print(f"获取技能列表失败: {e}")


def _skill_selection_ui(stdscr, skills):
    """技能选择交互界面"""
    # 初始化curses
    curses.curs_set(0)  # 隐藏光标
    stdscr.nodelay(0)
    stdscr.timeout(-1)  # 阻塞等待输入
    
    current_row = 0
    search_text = ""
    filtered_skills = skills[:]
    
    while True:
        stdscr.clear()
        
        # 获取屏幕尺寸
        height, width = stdscr.getmaxyx()
        
        # 显示标题和搜索框
        stdscr.addstr(0, 0, "选择技能 (ESC 退出, 回车安装, 输入搜索):")
        
        # 截断搜索文本以适应屏幕宽度
        display_search = search_text + "_"
        if len(display_search) > width - 9:  # 9是"搜索: "的长度
            display_search = display_search[:width - 9]
        
        stdscr.addstr(1, 0, f"搜索: {display_search}")
        
        # 根据搜索文本过滤技能列表
        if search_text:
            filtered_skills = [skill for skill in skills if search_text.lower() in skill.lower()]
        else:
            filtered_skills = skills[:]
        
        # 显示技能列表，确保不超过屏幕高度
        max_display_items = height - 4  # 留出标题和搜索框的空间
        for idx in range(min(len(filtered_skills), max_display_items)):
            skill = filtered_skills[idx]
            prefix = "> " if idx == current_row else "  "
            try:
                if idx == current_row:
                    stdscr.addstr(idx + 3, 0, prefix + skill, curses.A_REVERSE)
                else:
                    stdscr.addstr(idx + 3, 0, prefix + skill)
            except:
                # 如果添加字符串失败（例如超出边界），则跳过
                break
        
        stdscr.refresh()
        
        # 获取用户输入
        key = stdscr.getch()
        
        # 处理ESC键退出
        if key == 27:  # ESC键
            break
        # 处理回车键安装
        elif key in [curses.KEY_ENTER, ord('\n'), ord('\r')]:
            if filtered_skills and len(filtered_skills) > current_row >= 0:
                selected_skill = filtered_skills[current_row]
                
                # 创建队列用于线程间通信
                result_queue = queue.Queue()
                
                def install_worker():
                    try:
                        # 执行静默安装
                        from skill_hub.commands.install import install_specific_skill_silent
                        if '@' in selected_skill:
                            skill_name, repo = selected_skill.split('@', 1)
                            install_specific_skill_silent(skill_name, repo)
                        result_queue.put(('success', f"技能 {selected_skill} 安装完成"))
                    except Exception as e:
                        result_queue.put(('error', f"安装失败: {str(e)}"))
                
                # 启动安装线程
                install_thread = threading.Thread(target=install_worker)
                install_thread.daemon = True
                install_thread.start()
                
                # 显示安装进度
                stdscr.clear()
                stdscr.addstr(0, 0, f"正在安装技能: {selected_skill}")
                stdscr.addstr(2, 0, "请稍候...")
                stdscr.refresh()
                
                # 等待安装完成
                install_thread.join(timeout=60)  # 60秒超时
                
                stdscr.clear()
                if install_thread.is_alive():
                    stdscr.addstr(0, 0, "安装超时，请稍后重试")
                else:
                    try:
                        status, message = result_queue.get_nowait()
                        stdscr.addstr(0, 0, message)
                    except queue.Empty:
                        stdscr.addstr(0, 0, "安装完成")
                
                stdscr.addstr(2, 0, "按任意键继续...")
                stdscr.refresh()
                stdscr.getch()
        # 处理字母数字搜索
        elif 32 <= key <= 126:  # ASCII字符范围
            search_text += chr(key)
            current_row = 0  # 重置选中项
        # 处理退格键
        elif key == curses.KEY_BACKSPACE or key == 127 or key == 8:
            search_text = search_text[:-1]
            current_row = 0  # 重置选中项
        # 处理方向键
        elif key == curses.KEY_UP:
            current_row = max(0, current_row - 1)
        elif key == curses.KEY_DOWN:
            current_row = min(len(filtered_skills) - 1, current_row + 1)
        # 处理其他控制键
        elif key == curses.KEY_DC:  # Delete键
            search_text = ""
            current_row = 0