"""
arifos_core/asi/empathy - Empathy Architecture (540)

Three-layer empathy model for κᵣ conductance.
"""

from arifos.asi.empathy.empathy_architect import (
    EmpathyArchitect,
    EmpathyArchitectureBundle,
    Layer1Recognition,
    Layer2Understanding,
    Layer3Response,
    EmpathyRequirement,
    Stakes
)

__all__ = [
    "EmpathyArchitect",
    "EmpathyArchitectureBundle",
    "Layer1Recognition",
    "Layer2Understanding",
    "Layer3Response",
    "EmpathyRequirement",
    "Stakes"
]
