from typing import Any, Optional, TypeVar

import numpy as np
from numpy.typing import NDArray

from finchge.fitness import FitnessEvaluator
from finchge.grammar.grammar_helper import BNFGrammar
from finchge.individual import Individual
from finchge.utils.cache_manager import CacheManager

T = TypeVar("T")


class Population:
    """
    Represents a population of individuals in a genetic or evolutionary algorithm.

    A `Population` manages a collection of `Individual` instances along with the
    configuration, grammar, and fitness evaluation machinery required to evolve them.
    It is responsible for initializing individuals, evaluating fitness, and serving
    as the primary container passed between algorithm operators (selection, crossover,
    mutation, and replacement).

    Fitness values are not assigned at construction time. Instead, they are computed
    lazily via `eval()` after genotype-to-phenotype mapping. This design supports both
    single-objective and multi-objective algorithms (e.g., NSGA-II, NSGA-III).

    Args:
        config (dict[str, Any]):
            Configuration dictionary for the evolutionary run. Must include keys such
            as population size, genome length, and codon size.

        fitness_evaluator (FitnessEvaluator):
            Evaluator responsible for computing fitness values from phenotypes. May
            support single or multiple objectives.

        grammar (BNFGrammar):
            Grammar used to map genotypes to phenotypes and (optionally) derivation trees.

        genome (Optional[list[NDArray[np.int_]]]):
            Optional list of genotypes to initialize the population with. Each genotype
            is represented as a NumPy array of integers. If not provided, genotypes are
            generated randomly according to the configuration.

        phenome (Optional[list[str]]):
            Optional list of phenotypes corresponding to the provided genotypes. If not
            provided, phenotypes are generated during evaluation.

        used_codons (Optional[list[int]]):
            Optional list indicating how many codons were consumed during genotype-to-
            phenotype mapping for each individual.

        trees (Optional[list[str]]):
            Optional list of serialized derivation trees (e.g., JSON strings) associated
            with each individual.

        cache_manager (Optional[CacheManager[Any, Any]]):
            Optional cache manager used to store and retrieve previously evaluated
            fitness values, keyed by phenotype. This can significantly reduce repeated
            fitness evaluations.

        **kwargs (Any):
            Additional keyword arguments reserved for extensibility or integration with
            higher-level frameworks. These are currently ignored.

    Attributes:
        individuals (list[Individual]):
            The list of individuals in the population.

        config (dict[str, Any]):
            Configuration dictionary for the population.

        fitness_evaluator (FitnessEvaluator):
            Evaluator used to compute fitness values.

        grammar (BNFGrammar):
            Grammar used for genotype-to-phenotype mapping.

        cache_manager (Optional[CacheManager[Any, Any]]):
            Cache manager used for memoizing fitness evaluations, if provided.
    """

    def __init__(
        self,
        config: dict[str, Any],
        fitness_evaluator: FitnessEvaluator,
        grammar: BNFGrammar,
        genome: Optional[list[NDArray[np.int_]]] = None,
        phenome: Optional[list[str]] = None,
        used_codons: Optional[list[int]] = None,
        trees: Optional[list[str]] = None,
        cache_manager: Optional[CacheManager[Any, Any]] = None,
        **kwargs: Any,
    ) -> None:
        self.config = config
        self.fitness_evaluator = fitness_evaluator
        self.grammar = grammar
        self.cache_manager = cache_manager
        self.individuals: list[Individual] = []

        # Initialize genome if not provided
        if genome is None:
            genome = [
                np.random.randint(
                    0,
                    self.config["codon_size"] + 1,
                    size=self.config["genome_length"],
                    dtype=np.int_,
                )
                for _ in range(self.config["population_size"])
            ]
        else:
            genome = [np.asarray(g, dtype=np.int_) for g in genome]

        # Initialize other components
        if phenome is None:
            phenome = [""] * self.config["population_size"]
        if used_codons is None:
            used_codons = [len(g) for g in genome]
        if trees is None:
            trees = ["" for _ in genome]

        # Initialize population
        for gen, phen, uc, tree_ in zip(genome, phenome, used_codons, trees):
            self.individuals.append(
                Individual(
                    genotype=gen,
                    phenotype=phen,
                    used_codons=uc,
                    invalid=False,
                    tree=tree_,
                )
            )

        for key, value in kwargs.items():
            setattr(self, key, value)

    def eval(self) -> None:
        """Evaluate all individuals in the population"""
        for individual in self.individuals:
            (
                individual.phenotype,
                individual.used_genotype,
                individual.used_codons,
                individual.invalid,
                individual.tree,
            ) = self.grammar.map_genotype_to_phenotype(individual.genotype)

            if not individual.invalid:
                # fitness are always represented as a list even for single objective
                cache_key = f"{individual.phenotype}_fitness"
                fitness_values = (
                    self.cache_manager.get(cache_key) if self.cache_manager else None
                )

                if fitness_values is None:
                    fitness_values = self.fitness_evaluator.evaluate(
                        individual.phenotype
                    )
                    if self.cache_manager:
                        self.cache_manager.set(cache_key, fitness_values)
                individual.fitness = fitness_values

            else:
                individual.fitness.clear()
