from abc import ABC, abstractmethod
from typing import Any

from finchge.population import Population


class BaseAlgorithm(ABC):
    """Abstract base class for Search Algorithm"""

    @abstractmethod
    def sort_population(self, population: Population) -> None:
        pass

    @abstractmethod
    def get_best(self, population: Population) -> Any:
        pass

    @abstractmethod
    def evolve_one_generation(self, population: Population) -> Population:
        pass
