import ast
import configparser
from typing import Any


def load_config(config_file: str = "config.ini") -> dict[str, Any]:
    config = _read_config_file(config_file)
    ge = config.get("ge")
    if not isinstance(ge, dict):
        raise ValueError("Config file must contain a [ge] section")
    return ge


def _read_config_file(config_file: str) -> dict[str, Any]:
    """Reads and parses the config file.
    :param config_file: (str) the path of a .ini file.
    :return cfg: (dict) the dictionary of information in config_file.
    """

    def _safe_eval(value: Any) -> Any:
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return value

    def _build_dict(items: list[Any]) -> dict[str, Any]:
        return {item[0]: _safe_eval(item[1]) for item in items}

    cf = configparser.ConfigParser()
    cf.read(config_file)
    cfg = {sec: _build_dict(cf.items(sec)) for sec in cf.sections()}
    return cfg
