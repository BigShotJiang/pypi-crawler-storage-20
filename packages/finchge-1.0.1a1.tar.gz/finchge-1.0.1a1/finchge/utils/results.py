import csv
import os
import statistics
from typing import Any

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize
from tabulate import tabulate  # type: ignore

from finchge.grammar.tree_node import TreeNode
from finchge.individual import Individual
from finchge.utils.loghelper import get_log_dir, get_logger

matplotlib.use("Agg")  # Switch to non-GUI backend


class ResultHelper:
    def __init__(self, project_id: str = "finch") -> None:
        self.project_id = project_id
        self.logger = get_logger(project_id)

    def generate_summary(self, objective_names: list[str]) -> None:
        """
        Generate and save summary statistics for multi-objective genetic evolution.

        Args:
            objective_names (list): Names of the objective functions
        """
        # read from generations.csv
        csv_file_path = f"{get_log_dir(self.project_id)}/generations.csv"
        fitness_data: dict[str, Any] = {name: [] for name in objective_names}
        used_codons_data = []
        tree_depths = []
        generations = []

        # read csv
        try:
            with open(csv_file_path, mode="r") as file:
                reader = csv.DictReader(file)  # Standard CSV format
                for row in reader:
                    generations.append(int(row["generation"]))

                    # all  objectives
                    for objective_name in objective_names:
                        try:
                            fitness_data[objective_name].append(
                                float(row[objective_name])
                            )
                        except (ValueError, KeyError):
                            self.logger.warning(
                                f"Parsing failed for {objective_name}, set to 0"
                            )
                            fitness_data[objective_name].append(0)

                    #  used codons
                    try:
                        used_codons_data.append(int(row["used_codons"]))
                    except (ValueError, KeyError):
                        self.logger.warning(
                            f"Parsing failed for used_codons in generation {row.get('generation', 'unknown')}, set to -1"
                        )
                        used_codons_data.append(-1)

                    #  tree depth
                    try:
                        tree_depths.append(int(row["tree_depth"]))
                    except (ValueError, KeyError):
                        self.logger.warning(
                            f"Parsing failed for tree_depth in generation {row.get('generation', 'unknown')}, set to 0"
                        )
                        tree_depths.append(0)
        except FileNotFoundError:
            self.logger.error(f"CSV file not found: {csv_file_path}")
            return

        # Ensure we have data to process
        if not all(fitness_data.values()) or not used_codons_data or not tree_depths:
            self.logger.error("Not enough data to generate summary")
            return

        # Calculate statistics
        max_fitness = {
            name: round(max(values), 4) if values else 0
            for name, values in fitness_data.items()
        }
        min_fitness = {
            name: round(min(values), 4) if values else 0
            for name, values in fitness_data.items()
        }
        avg_fitness = {
            name: round(statistics.mean(values), 4) if values else 0
            for name, values in fitness_data.items()
        }
        std_fitness = {
            name: round(statistics.stdev(values), 4) if len(values) > 1 else 0
            for name, values in fitness_data.items()
        }

        # Prepare tables
        headers = ["Metric", *objective_names]
        fitness_stats = [
            ["Max", *[max_fitness[name] for name in objective_names]],
            ["Min", *[min_fitness[name] for name in objective_names]],
            ["Average", *[avg_fitness[name] for name in objective_names]],
            ["Std Dev", *[std_fitness[name] for name in objective_names]],
        ]

        other_stats = [
            [
                "Used Codons",
                min(used_codons_data) if used_codons_data else 0,
                max(used_codons_data) if used_codons_data else 0,
            ],
            [
                "Tree Depth",
                min(tree_depths) if tree_depths else 0,
                max(tree_depths) if tree_depths else 0,
            ],
        ]
        other_headers = ["Metric", "Min", "Max"]

        # tabulate summary text
        summary = "\nFitness Statistics:\n"
        summary += tabulate(fitness_stats, headers=headers, tablefmt="pretty")
        summary += "\n\nOther Statistics:\n"
        summary += tabulate(other_stats, headers=other_headers, tablefmt="pretty")

        # print and save summary
        print(summary)
        self.logger.info(summary)
        summary_path = f"{get_log_dir(self.project_id)}/summary.txt"
        with open(summary_path, "w") as f:
            f.write(summary)
        self.logger.info(f"Summary saved to {summary_path}")

        # fitness chart for single objective optimization only.
        if len(objective_names) == 1:
            fitness_data_obj1 = fitness_data[
                objective_names[0]
            ]  # one fitness in the list
            if fitness_data_obj1:
                self.plot_fitness_chart(fitness_data_obj1)
                best_fitness_idx = fitness_data_obj1.index(max(fitness_data_obj1))
                best_generation = generations[best_fitness_idx]

                # tree for best generation

                best_tree_path = (
                    f"{get_log_dir(self.project_id)}/trees/{best_generation}.json"
                )
                try:
                    with open(best_tree_path, "r") as file:
                        best_tree_json = file.read()
                    self.plot_tree(best_tree_json)
                except FileNotFoundError:
                    self.logger.info(
                        f"Skipping plotting phenotype mapping tree: Tree file for generation {best_generation} not found. Please ensure logging is not excluded for tree files in config."
                    )

    def visualize_pareto_front(self, objective_names: list[str]) -> None:
        if len(objective_names) < 2:
            raise ValueError("objective_names must contain at least two objectives")

        pareto_csv_path: str = f"{get_log_dir(self.project_id)}/generations.csv"
        df: pd.DataFrame = pd.read_csv(pareto_csv_path)

        os.makedirs(get_log_dir(self.project_id), exist_ok=True)

        # Extract generations safely
        generations = df["generation"]
        unique_gens: list[int] = sorted(int(g) for g in generations.unique())

        fig, ax1 = plt.subplots(figsize=(10, 8))

        # Colormap colors
        cmap = plt.get_cmap("jet")
        colors = cmap(np.linspace(0.0, 1.0, len(unique_gens)))

        # Scatter all solutions
        all_data: pd.DataFrame = df[objective_names + ["generation"]]

        ax1.scatter(
            all_data[objective_names[0]],
            all_data[objective_names[1]],
            c=all_data["generation"],
            cmap="viridis",
            alpha=0.2,
            s=15,
            marker=".",
        )

        # Plot Pareto fronts per generation
        for i, gen in enumerate(unique_gens):
            gen_data: pd.DataFrame = df[df["generation"] == gen]
            gen_data_sorted: pd.DataFrame = gen_data.sort_values(by=objective_names[0])

            ax1.step(
                gen_data_sorted[objective_names[0]],
                gen_data_sorted[objective_names[1]],
                linestyle="--",
                where="pre",
                color=colors[i],
                lw=0.35,
                alpha=0.25,
            )

            ax1.plot(
                gen_data_sorted[objective_names[0]],
                gen_data_sorted[objective_names[1]],
                "o",
                color=colors[i],
                ms=1,
            )

        ax1.set_xlabel(objective_names[0], fontsize=14)
        ax1.set_ylabel(objective_names[1], fontsize=14)
        ax1.set_title("Pareto Fronts by Generation")

        # Colorbar
        norm = Normalize(vmin=0, vmax=len(unique_gens) - 1)
        sm = ScalarMappable(norm=norm, cmap=cmap)

        sm.set_array([])

        cbar = plt.colorbar(sm, ax=ax1, ticks=[0, len(unique_gens) - 1])
        cbar.ax.set_ylabel("Generation", rotation=90)

        plt.tight_layout()

        base_path = get_log_dir(self.project_id)
        plt.savefig(f"{base_path}/pareto_front_evolution.pdf")
        plt.savefig(f"{base_path}/pareto_front_evolution.png", dpi=300)
        plt.close(fig)

        self.logger.info(
            f"Pareto front evolution plot saved to: {base_path}/pareto_front_evolution.pdf"
        )

    def plot_fitness_chart(self, data: list[float]) -> None:
        plt.plot(data)
        plt.title("Fitness")
        plt.xlabel("Generations")
        plt.ylabel("Fitness value")
        plt.savefig(f"{get_log_dir(self.project_id)}/fitness_chart.png")
        plt.close()
        self.logger.info(
            f"Fitness chart saved to {get_log_dir(self.project_id)}/fitness_chart.png"
        )

    def plot_tree(self, tree_json: str) -> None:
        tree: TreeNode = TreeNode.from_json(tree_json)

        fig, ax = plt.subplots(figsize=(10, 6))

        def process_node(
            node: TreeNode,
            x: float,
            y: float,
            level: int = 0,
        ) -> None:
            # Draw node
            ax.scatter(x, y, s=500, c=[[level]], cmap="viridis", zorder=3)
            ax.text(x, y + 0.05, str(node.symbol), ha="center", va="bottom")

            n_children: int = len(node.children)
            if n_children > 0:
                spacing: float = 2.0 / (n_children + 1)
                for i, child in enumerate(node.children):
                    child_x: float = x + 1.0
                    child_y: float = y - 1.0 + (i + 1) * spacing

                    # Draw edge
                    ax.plot([x, child_x], [y, child_y], color="black", linewidth=1)

                    process_node(child, child_x, child_y, level + 1)

        process_node(tree, 0.0, 0.0)

        ax.axis("off")
        ax.set_aspect("equal", adjustable="datalim")

        out = f"{get_log_dir(self.project_id)}/fitness_tree.png"
        plt.savefig(out, bbox_inches="tight")
        plt.close(fig)

    def save_pareto_front(
        self, pareto_front: list[Individual], objective_names: list[str]
    ) -> None:
        pareto_csv_path = f"{get_log_dir()}/pareto_front.csv"

        # fitness objectives + phenotype
        headers = objective_names + ["phenotype"]

        with open(pareto_csv_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            for ind in pareto_front:
                if ind.fitness is None:
                    fitness = []
                elif isinstance(ind.fitness, list):
                    fitness = ind.fitness
                else:
                    fitness = [ind.fitness]

                row = fitness + [ind.phenotype]
                writer.writerow(row)

        self.visualize_pareto_front(objective_names)
