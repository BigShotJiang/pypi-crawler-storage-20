from setuptools import setup

setup(
    name="abram_printer_tools",
    version="1.1.3",
    description="A library made by a 10-year-old to print text in cool ways",
    author="Abram Jindal",
    py_modules=["printing"],
    install_requires=["rich"],
)