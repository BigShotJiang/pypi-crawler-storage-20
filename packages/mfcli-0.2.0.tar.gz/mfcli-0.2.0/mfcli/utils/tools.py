import mimetypes


def get_mime_type_from_bytes(file_bytes: bytes, filename: str = None):
    """
    Get MIME type from file bytes using Python's built-in mimetypes module
    and file signature detection.
    
    :param file_bytes: Bytes of the file
    :param filename: Optional filename to help with detection
    :return: MIME type string
    """
    # Check for common file signatures
    if len(file_bytes) >= 5 and file_bytes.startswith(b'%PDF-'):
        return 'application/pdf'
    elif len(file_bytes) >= 4 and file_bytes.startswith(b'PK\x03\x04'):
        # ZIP-based formats (could be various formats)
        return 'application/zip'
    elif len(file_bytes) >= 8 and file_bytes.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'image/png'
    elif len(file_bytes) >= 3 and file_bytes.startswith(b'\xff\xd8\xff'):
        return 'image/jpeg'
    
    # If filename is provided, try to guess from extension
    if filename:
        mime_type, _ = mimetypes.guess_type(filename)
        if mime_type:
            return mime_type
    
    # Default fallback
    return 'application/octet-stream'
