from mfcli.models.pipeline_run import PipelineRun
from mfcli.models.project import Project
from mfcli.utils.logger import get_logger
from mfcli.utils.orm import Session

logger = get_logger(__name__)


def create_pipeline_run(db: Session, project: Project) -> PipelineRun:
    logger.debug("Creating pipeline run")
    run = PipelineRun()
    run.project = project
    db.add(run)
    db.flush()
    logger.debug(f"Pipeline run created: {run.id}")
    db.commit()
    return run
