import time
from collections.abc import Callable
from typing import Any

from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.webdriver import MobileWebElement, WebDriver
from selenium.common.exceptions import (InvalidElementStateException, NoSuchElementException,
                                        StaleElementReferenceException)
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions.pointer_input import PointerInput


class AppiumUtility:

  def __init__(self, driver: WebDriver):
    self.driver = driver
    self.focus_elem_retries = 5
    self.focus_elem_delay = 1

  def launch_app(self, app_id: str):
    print(f"Launching app: {app_id}")
    self.driver.activate_app(app_id)

  def press_key(self, key: str):
    print(f"Pressing key: {key}")
    key_map = {
      "home": 3,
      "back": 4,
      "enter": 66,
      "backspace": 67,
    }
    self.driver.press_keycode(key_map[key])

  def hide_keyboard(self):
    print("Hiding keyboard")
    self.driver.hide_keyboard()

  def sleep(self, seconds: float):
    print(f"Sleeping for {seconds} seconds")
    time.sleep(seconds)

  def click_by_text(self, text: str, regex: bool = False):
    print(f"Clicking element with text: {text} (regex={regex})")
    el = self._find_by_text(text, regex=regex)
    el.click()

  def click_by_id(self, resource_id: str):
    print(f"Clicking element with resource-id: {resource_id}")
    self.driver.find_element(AppiumBy.ID, resource_id).click()

  def click_by_content_desc(self, content_desc: str, regex: bool = False):
    print(f"Clicking element with content-desc: {content_desc} (regex={regex})")
    el = self._find_by_desc(content_desc, regex=regex)
    el.click()

  def click_by_xpath(self, xpath: str):
    print(f"Clicking element with xpath: {xpath}")
    self.driver.find_element(AppiumBy.XPATH, xpath).click()

  def click_by_percent(self, x_percent: float, y_percent: float):
    print(f"Clicking at percent: ({x_percent}, {y_percent})")
    size = self.driver.get_window_size()
    x = int(size["width"] * x_percent)
    y = int(size["height"] * y_percent)

    finger = PointerInput("touch", "finger")
    actions = ActionChains(self.driver)

    actions.w3c_actions.devices = [finger]

    finger.create_pointer_move(x=x, y=y)
    finger.create_pointer_down()
    finger.create_pointer_up(button=0)

    actions.perform()

  def input_text(self, text: str):
    print(f"Inputting text: {text}")
    self._with_focused_element_and_retry(
      self.focus_elem_retries,
      self.focus_elem_delay,
      lambda el: el.send_keys(text),
    )

  def erase_text(self):
    print("Erasing text from focused element")
    self._with_focused_element_and_retry(
      self.focus_elem_retries,
      self.focus_elem_delay,
      lambda el: el.clear(),
    )

  def _with_focused_element_and_retry(
    self,
    retries: int,
    delay: float,
    func: Callable[[MobileWebElement], Any],
  ):
    last_error = None

    for attempt in range(1, retries + 1):
      try:
        return func(self._find_focused_input_element())
      except (NoSuchElementException, StaleElementReferenceException,
              InvalidElementStateException) as e:
        last_error = e
        if attempt < retries:
          time.sleep(delay)

    raise RuntimeError(f"Failed to find focused element after {retries} retries") from last_error

  def swipe_percent(self, start_x, start_y, end_x, end_y, duration=300):
    print(f"Swiping from percent ({start_x}, {start_y}) to ({end_x}, {end_y}) over {duration}ms")
    size = self.driver.get_window_size()

    sx = int(size["width"] * start_x)
    sy = int(size["height"] * start_y)
    ex = int(size["width"] * end_x)
    ey = int(size["height"] * end_y)

    finger = PointerInput("touch", "finger")
    actions = ActionChains(self.driver)
    actions.w3c_actions.devices = [finger]

    # Move finger instantly to start position
    finger.create_pointer_move(duration=0, x=sx, y=sy)

    # Touch down
    finger.create_pointer_down()

    # Swipe over `duration` ms (ADB-style)
    finger.create_pointer_move(
      duration=duration,  # milliseconds — same as adb
      x=ex,
      y=ey)

    # Lift finger
    finger.create_pointer_up(button=0)

    actions.perform()

  def scroll_percent(self, start_x, start_y, end_x, end_y, duration=300):
    print(f"Scrolling from percent ({start_x}, {start_y}) to ({end_x}, {end_y}) over {duration}ms")
    return self.swipe_percent(start_x, start_y, end_x, end_y, duration)

  def scroll_until_text_visible(self, text: str, regex: bool = False):
    print(f"Scrolling until text visible: {text} (regex={regex})")
    selector = (f'new UiSelector().textMatches("{text}")'
                if regex else f'new UiSelector().textContains("{text}")')

    scrollable_cmd = ("new UiScrollable(new UiSelector().scrollable(true))"
                      f".scrollIntoView({selector})")

    self.driver.find_element(
      AppiumBy.ANDROID_UIAUTOMATOR,
      scrollable_cmd,
    )

  def assert_text_not_visible(self, text: str, regex: bool = False):
    print(f"Asserting text not visible: {text} (regex={regex})")
    els = self._finds_by_text(text, regex=regex)
    if els:
      raise AssertionError(f"text visible: {text}")

  def assert_text_visible(self, text: str, regex: bool = False):
    print(f"Asserting text visible: {text} (regex={regex})")
    els = self._finds_by_text(text, regex=regex)
    if not els:
      raise AssertionError(f"text not visible: {text}")

  def _find_by_text(self, text: str, regex: bool = False):
    if regex:
      return self.driver.find_element(
        AppiumBy.ANDROID_UIAUTOMATOR,
        f'new UiSelector().textMatches("{text}")',
      )
    return self.driver.find_element(
      AppiumBy.ANDROID_UIAUTOMATOR,
      f'new UiSelector().textContains("{text}")',
    )

  def _find_by_desc(self, text: str, regex: bool = False):
    if regex:
      return self.driver.find_element(
        AppiumBy.ANDROID_UIAUTOMATOR,
        f'new UiSelector().descriptionMatches("{text}")',
      )
    return self.driver.find_element(
      AppiumBy.ANDROID_UIAUTOMATOR,
      f'new UiSelector().descriptionContains("{text}")',
    )

  def _find_focused_input_element(self, default_index: int | None = None):
    elems = self.driver.find_elements(
      AppiumBy.ANDROID_UIAUTOMATOR,
      "new UiSelector().focused(true)",
    )

    for el in elems:
      class_name = el.get_attribute("class")
      if class_name in ["android.widget.EditText", "android.widget.TextView"]:
        return el

    if default_index is not None and 0 <= default_index < len(elems):
      return elems[default_index]

    raise NoSuchElementException("No focused input element found")

  def _finds_by_text(self, text: str, regex: bool = False):
    if regex:
      return self.driver.find_elements(
        AppiumBy.ANDROID_UIAUTOMATOR,
        f'new UiSelector().textMatches("{text}")',
      )
    return self.driver.find_elements(
      AppiumBy.ANDROID_UIAUTOMATOR,
      f'new UiSelector().textContains("{text}")',
    )
