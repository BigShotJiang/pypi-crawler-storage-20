"""Output modules for NetworkDoctor"""








