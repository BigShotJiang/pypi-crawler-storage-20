"""CLI module for NetworkDoctor"""








