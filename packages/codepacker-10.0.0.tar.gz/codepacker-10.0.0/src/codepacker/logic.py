import os, hashlib, json, uuid, zipfile, shutil, io, tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import random

class MoonspicCore:
    def __init__(self):
        self.code_exts = {'.py', '.txt', '.js', '.html', '.css', '.json', '.sh', '.md', '.yaml', '.xml', '.c', '.cpp', '.h'}
        self.delimiter = "#MOONSPIC_CODEPACKER#"

    def get_sha512(self, data):
        return hashlib.sha512(data if isinstance(data, bytes) else data.encode()).hexdigest()

    def pack(self, src_path, out_dir):
        src, out = Path(src_path).resolve(), Path(out_dir).resolve()
        stage = out / f"STAGE_{uuid.uuid4().hex[:6]}"
        stage.mkdir(parents=True, exist_ok=True)
        meta = {"project_name": src.name, "files": {}, "delimiter": self.delimiter}
        code_blocks = []
        assets_buffer = io.BytesIO()
        with zipfile.ZipFile(assets_buffer, 'w') as az:
            for r, _, files in os.walk(src):
                for f in files:
                    fp = Path(r) / f
                    rel = str(fp.relative_to(src))
                    f_id = str(uuid.uuid4())[:8]
                    raw_data = fp.read_bytes()
                    if fp.suffix.lower() in self.code_exts:
                        content = raw_data.decode('utf-8', errors='ignore')
                        code_blocks.append(f"{self.delimiter} {f_id};{rel}\n{content}")
                    else:
                        az.write(fp, rel)
        (stage / "CODE.txt").write_text("\n".join(code_blocks))
        (stage / "META.json").write_text(json.dumps(meta, indent=4))
        (stage / "Assets.zip").write_bytes(assets_buffer.getvalue())
        final_zip = out / f"{src.name}_BUNDLE.zip"
        with zipfile.ZipFile(final_zip, 'w') as fz:
            for f in ["CODE.txt", "META.json", "Assets.zip"]: fz.write(stage / f, f)
        shutil.rmtree(stage)
        return str(final_zip)

    def unpack(self, zip_path, target_dir):
        base_target = Path(target_dir).resolve()
        temp = base_target / "TEMP_UNPACK"
        if temp.exists(): shutil.rmtree(temp)
        temp.mkdir(parents=True, exist_ok=True)
        shutil.unpack_archive(zip_path, temp)
        meta = json.loads((temp / "META.json").read_text())
        proj_folder = meta.get("project_name", "restored_project")
        actual_dest = base_target / proj_folder
        if actual_dest.exists(): shutil.rmtree(actual_dest)
        actual_dest.mkdir(parents=True, exist_ok=True)
        if (temp / "Assets.zip").exists():
            with zipfile.ZipFile(temp / "Assets.zip", 'r') as az: az.extractall(actual_dest)
        if (temp / "CODE.txt").exists():
            parts = (temp / "CODE.txt").read_text().split(meta.get("delimiter", self.delimiter))
            for part in parts:
                if not part.strip() or ";" not in part: continue
                header, body = part.split("\n", 1)
                rel = header.strip().split(";")[1]
                out_f = actual_dest / rel.strip()
                out_f.parent.mkdir(parents=True, exist_ok=True)
                out_f.write_text(body.strip())
        shutil.rmtree(temp)
        return str(actual_dest)

    def calculate_content_hash(self, directory):
        hasher = hashlib.sha512()
        base = Path(directory).resolve()
        for fp in sorted([f for f in base.rglob('*') if f.is_file()]):
            hasher.update(str(fp.relative_to(base)).encode())
            hasher.update(fp.read_bytes())
        return hasher.hexdigest()
    
    
class GUI:
    def start(self):
        root = tk.Tk(); root.title("Moonspic v9.6.0"); root.geometry("800x650")
        core = MoonspicCore()
        nb = ttk.Notebook(root); nb.pack(expand=1, fill='both', padx=10, pady=10)
        t1, t2, t3, t4 = ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb), ttk.Frame(nb)
        nb.add(t1, text=" Pack "); nb.add(t2, text=" Unpack "); nb.add(t3, text=" IntegrityMatch "); nb.add(t4, text=" Config ")

        # 1. PACK TAB (Restored)
        in_v, out_v = tk.StringVar(), tk.StringVar()
        tk.Label(t1, text="Source Folder:").pack(pady=5); tk.Entry(t1, textvariable=in_v, width=70).pack()
        tk.Button(t1, text="Browse", command=lambda: [in_v.set(filedialog.askdirectory()), out_v.set(str(Path(in_v.get()).parent)) if in_v.get() else None]).pack()
        tk.Label(t1, text="Output Directory:").pack(pady=5); tk.Entry(t1, textvariable=out_v, width=70).pack()
        tk.Button(t1, text="GENERATE BUNDLE", bg="black", fg="white", font=('bold'), command=lambda: messagebox.showinfo("OK", f"Created: {core.pack(in_v.get(), out_v.get())}")).pack(pady=20)

        # 2. UNPACK TAB (Restored)
        z_v, d_v = tk.StringVar(), tk.StringVar()
        tk.Label(t2, text="Bundle ZIP:").pack(pady=5); tk.Entry(t2, textvariable=z_v, width=70).pack()
        tk.Button(t2, text="Browse ZIP", command=lambda: [z_v.set(filedialog.askopenfilename()), d_v.set(str(Path(z_v.get()).parent)) if z_v.get() else None]).pack()
        tk.Label(t2, text="Restore Destination:").pack(pady=5); tk.Entry(t2, textvariable=d_v, width=70).pack()
        tk.Button(t2, text="RESTORE PROJECT", bg="blue", fg="white", font=('bold'), command=lambda: [core.unpack(z_v.get(), d_v.get()), messagebox.showinfo("OK", "Restored")]).pack(pady=20)

        # 3. INTEGRITY TAB (Updated with Automated Paths)
        tk.Label(t3, text="Verification & Random Testing Suite", font=('Arial', 14, 'bold')).pack(pady=10)
        
        # Folder Verification Section
        f_src, f_out = tk.StringVar(), tk.StringVar()
        tk.Label(t3, text="Verify Project Folder:", fg="blue").pack()
        tk.Entry(t3, textvariable=f_src, width=70).pack()
        tk.Button(t3, text="Select Project", command=lambda: [f_src.set(filedialog.askdirectory()), f_out.set(str(Path(f_src.get()).parent / "INTEGRITY_RESULTS")) if f_src.get() else None]).pack()
        tk.Label(t3, text="Test Results Location:").pack()
        tk.Entry(t3, textvariable=f_out, width=70).pack()
        tk.Button(t3, text="Browse Results Path", command=lambda: f_out.set(filedialog.askdirectory())).pack()
        
        def run_folder_test():
            if not f_src.get() or not f_out.get(): return
            h1 = core.calculate_content_hash(f_src.get())
            bundle = core.pack(f_src.get(), f_out.get())
            restored = core.unpack(bundle, f_out.get())
            h2 = core.calculate_content_hash(restored)
            res = "✅ MATCH" if h1 == h2 else "❌ MISMATCH"
            messagebox.showinfo("Result", f"{res}\n\nOriginal: {h1[:16]}...\nRestored: {h2[:16]}...")

        tk.Button(t3, text="START FOLDER VERIFICATION", bg="green", fg="white", command=run_folder_test).pack(pady=5)
        
        tk.Label(t3, text="-----------------------------------------").pack()

        # Random Test Section
        r_out = tk.StringVar()
        tk.Label(t3, text="Random Test Output Directory:", fg="purple").pack()
        tk.Entry(t3, textvariable=r_out, width=70).pack()
        tk.Button(t3, text="Browse Random Test Location", command=lambda: r_out.set(filedialog.askdirectory())).pack()
        
        def run_random_test():
            dest = Path(r_out.get()) if r_out.get() else Path.cwd() / "RANDOM_TEST_ROOT"
            if dest.exists(): shutil.rmtree(dest)
            proj = dest / "ProjectX"
            proj.mkdir(parents=True); (proj/"src").mkdir(); (proj/"assets").mkdir()
            (proj/"src/app.py").write_text("print('Integrity Pass')")
            (proj/"assets/data.bin").write_bytes(os.urandom(512))
            
            h1 = core.calculate_content_hash(proj)
            bundle = core.pack(proj, dest)
            restored = core.unpack(bundle, dest)
            h2 = core.calculate_content_hash(restored)
            res = "✅ MATCH" if h1 == h2 else "❌ MISMATCH"
            messagebox.showinfo("Random Test", f"Created & Verified ProjectX at {dest}\nResult: {res}")

        tk.Button(t3, text="GENERATE & RUN RANDOM TEST", bg="#2c3e50", fg="white", command=run_random_test).pack(pady=10)

        # 4. CONFIG TAB
        tk.Label(t4, text="MoonspicAI v9.6.0", font=('Arial', 16, 'bold')).pack(pady=20)
        tk.Label(t4, text="Delimiter: #MOONSPIC_CODEPACKER#").pack()
        tk.Label(t4, text="Identity: Author Unknown\nRepo: Private").pack(pady=10)
        
        root.mainloop()

        
def start():
    gui = GUI()
    gui.start()

