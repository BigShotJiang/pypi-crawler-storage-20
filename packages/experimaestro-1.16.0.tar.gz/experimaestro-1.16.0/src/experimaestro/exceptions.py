class HandledException(Exception):
    pass
