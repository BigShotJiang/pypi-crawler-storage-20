# Spark CLI

🔥 Your intelligent code snippet manager for developers

Spark helps you save, organize, and quickly access your frequently used commands and code snippets. Never forget that perfect command again!

[![PyPI version](https://badge.fury.io/py/spark-cli.svg)](https://badge.fury.io/py/spark-cli)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

**Available on PyPI:** `pip install spark-cli`

## Features

- 💾 **Save snippets** with optional tags for organization
- 🔍 **Smart search** - Find snippets by command or tag content
- 📋 **Quick copy** - Copy snippets to clipboard with one command
- 🏷️ **Tag system** - Organize snippets with comma-separated tags
- 🗑️ **Flexible deletion** - Delete by ID or by text content (with preview)
- 🎨 **Beautiful output** - Colorful, table-based display using Rich
- ⚠️ **Duplicate detection** - Warns if you try to save a duplicate command
- 🔄 **Auto-migration** - Database schema updates automatically

## Installation

### From PyPI (Recommended)

```bash
pip install spark-cli
```

After installation, the `spark` command is available globally.

### From source

```bash
git clone https://github.com/yourusername/spark-cli.git
cd spark-cli
pip install -e .
```

## Quick Start

After installation, Spark is ready to use. The database is automatically created in `~/.spark/snippets.db`.

```bash
# Save your first snippet
spark save "docker-compose up -d"

# Save with tags
spark save "git log --oneline -10" --tags "git,log,history"

# Find snippets
spark find docker

# List all snippets
spark list

# List snippets by tag
spark list --tag docker

# Copy to clipboard
spark copy 1

# Delete a snippet
spark delete 1

# Delete by text content
spark delete "docker"
```

## Commands

### `spark save <command> [--tags]`

Save a new code snippet.

```bash
spark save "npm install" --tags "npm,node,install"
```

**Features:**
- Duplicate detection: If a command already exists, Spark will warn you and ask for confirmation
- Tags are optional: You can save snippets with or without tags
- Tags are comma-separated: `--tags "tag1,tag2,tag3"`

### `spark find <search-term>`

Search for snippets containing the search term in either the command or tags.

```bash
spark find docker
spark find git
```

### `spark list [--tag <tag>]`

List all snippets, optionally filtered by tag.

```bash
spark list
spark list --tag docker
```

### `spark copy <id>`

Copy a snippet to your clipboard by ID.

```bash
spark copy 1
```

### `spark delete <id|text>`

Delete a snippet by ID or by text content. When deleting by text, Spark shows all matching snippets and asks for confirmation.

```bash
# Delete by ID (immediate)
spark delete 1

# Delete by text (shows preview table and asks for confirmation)
spark delete "docker"
```

**Note:** When deleting by text, all snippets containing that text will be shown. You can confirm or cancel the deletion.

### `spark clear`

Delete all snippets and reset the database. This also resets the ID counter back to 1.

```bash
spark clear
```

**Warning:** This action cannot be undone!

## Examples

### Organizing Docker Commands

```bash
spark save "docker-compose up -d" --tags "docker,compose,dev"
spark save "docker ps -a" --tags "docker,ps,containers"
spark save "docker logs <container>" --tags "docker,logs,debug"

# Find all docker commands
spark list --tag docker
```

### Git Workflow Snippets

```bash
spark save "git log --oneline -10" --tags "git,log,history"
spark save "git checkout -b feature/new-feature" --tags "git,branch,workflow"
spark save "git push origin HEAD" --tags "git,push,remote"

# Search for git commands
spark find git
```

## Data Storage

Spark stores all snippets in a local SQLite database located at:
- **Linux/macOS**: `~/.spark/snippets.db`
- **Windows**: `%USERPROFILE%\.spark\snippets.db`

Your data stays local and private.

## Requirements

- Python 3.8+
- typer
- rich
- pyperclip

## Version

Current version: **0.1.0**

Check for updates:
```bash
pip install --upgrade spark-cli
```

## Contributing

Contributions are welcome! Feel free to open an issue or submit a pull request.

**Ideas for contributions:**
- Import from bash history
- Export/backup functionality
- Statistics and usage tracking
- Shell completion scripts
- VS Code extension

## License

MIT License - see [LICENSE](LICENSE) file for details.

## Acknowledgments

Inspired by tools like `pet` and `cheat.sh`, but designed to be more personal and intelligent.

## Links

- **PyPI Package:** https://pypi.org/project/spark-cli/
- **GitHub Repository:** https://github.com/yourusername/spark-cli (update this with your actual repo URL)
