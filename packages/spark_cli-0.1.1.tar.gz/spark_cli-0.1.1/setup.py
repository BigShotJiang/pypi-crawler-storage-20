from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="spark-cli",
    version="0.1.1",
    author="Your Name",
    author_email="your.email@example.com",
    description="Your intelligent code snippet manager",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/spark-cli",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
        "pyperclip>=1.8.0",
    ],
    entry_points={
        "console_scripts": [
            "spark=spark.cli:app",
        ],
    },
    python_requires=">=3.8",
)
