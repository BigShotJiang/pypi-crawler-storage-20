"""
Claude Board CLI

Command-line interface for Claude Board:
- serve: Start the web server
- install: Install hooks into Claude Code settings
- uninstall: Remove hooks from Claude Code settings
- status: Show current status
- config: Show/edit configuration

Future commands:
- ble: Bluetooth device management
"""

import os
import signal
import socket
import sys
from pathlib import Path
from typing import List, Optional, Tuple

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

import qrcode

from . import __app_name__, __version__
from .config import (
    CLAUDE_LOCAL_SETTINGS_FILE,
    CLAUDE_SETTINGS_FILE,
    AppConfig,
    ClaudeSettingsManager,
)

# Default paths
DEFAULT_SOCKET_PATH = Path.home() / ".claude-board" / "claude-board.sock"
DEFAULT_PID_FILE = Path.home() / ".claude-board" / "claude-board.pid"

# Initialize CLI app
app = typer.Typer(
    name=__app_name__,
    help="Physical console for Claude Code - approve/deny permissions from your phone or (future) hardware device.",
    add_completion=False,
)
console = Console()


def version_callback(value: bool):
    if value:
        console.print(f"[bold]{__app_name__}[/bold] version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
):
    """
    Claude Board - Permission approval console for Claude Code

    Use your phone or a physical device to approve/deny Claude Code's
    permission requests.
    """
    pass


def get_primary_interface() -> Optional[str]:
    """
    Get the primary network interface using the default route.

    On macOS: uses 'route -n get default'
    On Linux: uses 'ip route show default'

    Returns:
        The interface name (e.g., 'en0', 'eth0') or None if not found.
    """
    import subprocess

    try:
        if sys.platform == "darwin":
            # macOS: use route -n get default
            result = subprocess.run(
                ["route", "-n", "get", "default"],
                capture_output=True,
                text=True,
                timeout=5
            )
            for line in result.stdout.split("\n"):
                line = line.strip()
                if line.startswith("interface:"):
                    return line.split(":", 1)[1].strip()
        else:
            # Linux: use ip route show default
            result = subprocess.run(
                ["ip", "route", "show", "default"],
                capture_output=True,
                text=True,
                timeout=5
            )
            # Output: "default via 192.168.1.1 dev eth0 proto ..."
            parts = result.stdout.strip().split()
            if "dev" in parts:
                dev_idx = parts.index("dev")
                if dev_idx + 1 < len(parts):
                    return parts[dev_idx + 1]
    except Exception:
        pass

    return None


def get_network_interfaces() -> List[Tuple[str, str, bool]]:
    """
    Get all network interfaces with their IP addresses.

    Returns:
        List of tuples: (interface_name, ip_address, is_primary)
        Sorted with primary interface first.
    """
    import subprocess

    interfaces = []

    # Get the primary interface from default route
    primary_iface = get_primary_interface()

    # Get all interfaces using system commands
    try:
        if sys.platform == "darwin":
            # macOS: use ifconfig
            result = subprocess.run(
                ["ifconfig"],
                capture_output=True,
                text=True,
                timeout=5
            )
            current_iface = None
            for line in result.stdout.split("\n"):
                if line and not line.startswith("\t") and not line.startswith(" "):
                    # Interface line: "en0: flags=..."
                    current_iface = line.split(":")[0]
                elif "inet " in line and current_iface:
                    # IP line: "	inet 192.168.1.100 netmask..."
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        ip = parts[1]
                        # Skip loopback
                        if not ip.startswith("127."):
                            is_primary = (current_iface == primary_iface)
                            interfaces.append((current_iface, ip, is_primary))
        else:
            # Linux: use ip addr
            result = subprocess.run(
                ["ip", "addr"],
                capture_output=True,
                text=True,
                timeout=5
            )
            current_iface = None
            for line in result.stdout.split("\n"):
                if ": " in line and not line.startswith(" "):
                    # Interface line: "2: eth0: <BROADCAST..."
                    parts = line.split(": ")
                    if len(parts) >= 2:
                        current_iface = parts[1].split("@")[0]
                elif "inet " in line and current_iface:
                    # IP line: "    inet 192.168.1.100/24..."
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        ip = parts[1].split("/")[0]
                        # Skip loopback
                        if not ip.startswith("127."):
                            is_primary = (current_iface == primary_iface)
                            interfaces.append((current_iface, ip, is_primary))
    except Exception:
        pass

    # Fallback: if no primary found but we have interfaces, try socket method
    if interfaces and not any(is_primary for _, _, is_primary in interfaces):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            primary_ip = s.getsockname()[0]
            s.close()
            # Mark the interface with this IP as primary
            interfaces = [
                (iface, ip, ip == primary_ip)
                for iface, ip, _ in interfaces
            ]
        except Exception:
            pass

    # Sort: primary first, then by interface name
    interfaces.sort(key=lambda x: (not x[2], x[0]))

    return interfaces


def get_local_ip() -> str:
    """Get the local IP address for mobile access (legacy function)"""
    interfaces = get_network_interfaces()
    for iface, ip, is_primary in interfaces:
        if is_primary:
            return ip
    if interfaces:
        return interfaces[0][1]
    return "unknown"


def _write_pid_file(pid: int) -> None:
    """Write PID to file for daemon management"""
    DEFAULT_PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    DEFAULT_PID_FILE.write_text(str(pid))


def _read_pid_file() -> Optional[int]:
    """Read PID from file, return None if not exists or invalid"""
    if not DEFAULT_PID_FILE.exists():
        return None
    try:
        pid = int(DEFAULT_PID_FILE.read_text().strip())
        # Check if process is running
        os.kill(pid, 0)
        return pid
    except (ValueError, ProcessLookupError, PermissionError):
        # Invalid PID or process not running
        DEFAULT_PID_FILE.unlink(missing_ok=True)
        return None


def _remove_pid_file() -> None:
    """Remove PID file"""
    DEFAULT_PID_FILE.unlink(missing_ok=True)


def _format_network_urls(port: int) -> str:
    """Format network URLs for display with primary interface first"""
    interfaces = get_network_interfaces()
    lines = [f"[dim]Local:[/dim]      http://localhost:{port}"]

    for i, (iface, ip, is_primary) in enumerate(interfaces):
        if is_primary:
            lines.append(f"[bold]Network:[/bold]    http://{ip}:{port}  [green]← primary ({iface})[/green]")
        else:
            lines.append(f"[dim]Network:[/dim]    http://{ip}:{port}  [dim]({iface})[/dim]")

    return "\n".join(lines)


def _print_qr_code(url: str) -> None:
    """Print QR code to terminal for easy mobile access"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=1,
        border=2,
    )
    qr.add_data(url)
    qr.make(fit=True)

    # Print QR code using Unicode block characters
    # Use inverted colors (white on black background) for better scanning
    # We use the half-block technique for better terminal rendering
    matrix = qr.get_matrix()
    rows = len(matrix)

    # Process two rows at a time using half-blocks
    # Inverted: QR dark modules become spaces, light modules become blocks
    output_lines = []
    for y in range(0, rows, 2):
        line = ""
        for x in range(len(matrix[0])):
            top = matrix[y][x] if y < rows else False
            bottom = matrix[y + 1][x] if y + 1 < rows else False

            # Inverted logic for white-on-black display
            if not top and not bottom:
                line += "█"  # Full block (both light in QR = black in terminal)
            elif not top:
                line += "▀"  # Upper half block
            elif not bottom:
                line += "▄"  # Lower half block
            else:
                line += " "  # Empty (both dark in QR = white/empty in terminal)
        output_lines.append(line)

    # Print with some padding
    console.print("\n[dim]Scan to open on mobile:[/dim]")
    console.print(f"  [dim]{url}[/dim]")
    console.print()
    for line in output_lines:
        console.print(f"  {line}")
    console.print()


@app.command()
def serve(
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        "-h",
        help="Host to bind to (0.0.0.0 for all interfaces).",
    ),
    port: int = typer.Option(
        8765,
        "--port",
        "-p",
        help="Port to listen on.",
    ),
    open_browser: bool = typer.Option(
        False,
        "--open",
        "-o",
        help="Open browser after starting server.",
    ),
    daemon: bool = typer.Option(
        False,
        "--daemon",
        "-d",
        help="Run server in background (daemon mode).",
    ),
    rpc_socket: Optional[str] = typer.Option(
        None,
        "--rpc-socket",
        help=f"Unix socket path for RPC API (default: {DEFAULT_SOCKET_PATH}).",
    ),
):
    """
    Start the Claude Board web server.

    The server receives permission requests from Claude Code hooks
    and serves a web UI for approving/denying them.

    Use --daemon to run in background. The server exposes a Unix socket
    RPC API for programmatic control (useful for GUI tools).
    """
    from .server import run_server

    # Check if already running
    existing_pid = _read_pid_file()
    if existing_pid:
        console.print(f"[yellow]Server already running (PID: {existing_pid})[/yellow]")
        console.print(f"Use [bold]claude-board stop[/bold] to stop it first.")
        raise typer.Exit(1)

    # Determine socket path
    socket_path = Path(rpc_socket) if rpc_socket else DEFAULT_SOCKET_PATH

    network_urls = _format_network_urls(port)

    if daemon:
        # Fork to background using double fork technique
        try:
            pid = os.fork()
            if pid > 0:
                # Parent process - wait for grandchild to write PID file
                import time
                for _ in range(20):  # Wait up to 2 seconds
                    time.sleep(0.1)
                    daemon_pid = _read_pid_file()
                    if daemon_pid:
                        # Also check if server is actually responding
                        try:
                            import urllib.request
                            with urllib.request.urlopen(f"http://localhost:{port}/api/health", timeout=1):
                                break
                        except Exception:
                            continue

                daemon_pid = _read_pid_file()
                if daemon_pid:
                    console.print(Panel.fit(
                        f"[bold green]Claude Board Server (daemon)[/bold green]\n\n"
                        f"{network_urls}\n\n"
                        f"[dim]RPC Socket:[/dim]  {socket_path}\n"
                        f"[dim]PID:[/dim]         {daemon_pid}\n\n"
                        f"[yellow]Open the URL on your phone to approve/deny requests[/yellow]\n\n"
                        f"Stop with: [bold]claude-board stop[/bold]",
                        title="Server Started",
                        border_style="green",
                    ))

                    # Print QR code for primary network interface
                    interfaces = get_network_interfaces()
                    for iface, ip, is_primary in interfaces:
                        if is_primary:
                            _print_qr_code(f"http://{ip}:{port}")
                            break

                    if open_browser:
                        import webbrowser
                        webbrowser.open(f"http://localhost:{port}")

                    raise typer.Exit(0)
                else:
                    console.print("[red]Failed to start daemon[/red]")
                    console.print(f"[dim]Check log: {DEFAULT_PID_FILE.parent / 'server.log'}[/dim]")
                    raise typer.Exit(1)
        except OSError as e:
            console.print(f"[red]Fork failed: {e}[/red]")
            raise typer.Exit(1)

        # First child process - detach from terminal
        os.setsid()

        # Second fork to prevent zombie processes
        try:
            pid = os.fork()
            if pid > 0:
                # First child exits, grandchild continues
                sys.exit(0)
        except OSError:
            sys.exit(1)

        # Grandchild process - this is the actual daemon
        # Write PID file first
        _write_pid_file(os.getpid())

        # Redirect standard file descriptors
        sys.stdout.flush()
        sys.stderr.flush()

        # Close stdin, redirect stdout/stderr to log file
        log_file = DEFAULT_PID_FILE.parent / "server.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)

        with open("/dev/null", "r") as devnull:
            os.dup2(devnull.fileno(), sys.stdin.fileno())
        with open(log_file, "a") as log:
            os.dup2(log.fileno(), sys.stdout.fileno())
            os.dup2(log.fileno(), sys.stderr.fileno())

        # Run server
        try:
            config = AppConfig()
            config.server.host = host
            config.server.port = port
            run_server(host=host, port=port, config=config, socket_path=socket_path)
        finally:
            _remove_pid_file()
            # Clean up socket file
            if socket_path.exists():
                socket_path.unlink()
    else:
        # Foreground mode
        console.print(Panel.fit(
            f"[bold green]Claude Board Server[/bold green]\n\n"
            f"{network_urls}\n\n"
            f"[dim]RPC Socket:[/dim]  {socket_path}\n\n"
            f"[yellow]Open the URL on your phone to approve/deny requests[/yellow]\n\n"
            f"Press [bold]Ctrl+C[/bold] to stop",
            title="Starting Server",
            border_style="green",
        ))

        # Print QR code for primary network interface
        interfaces = get_network_interfaces()
        for iface, ip, is_primary in interfaces:
            if is_primary:
                _print_qr_code(f"http://{ip}:{port}")
                break

        if open_browser:
            import webbrowser
            webbrowser.open(f"http://localhost:{port}")

        # Write PID file even in foreground mode
        _write_pid_file(os.getpid())

        try:
            config = AppConfig()
            config.server.host = host
            config.server.port = port
            run_server(host=host, port=port, config=config, socket_path=socket_path)
        except KeyboardInterrupt:
            console.print("\n[yellow]Server stopped.[/yellow]")
        finally:
            _remove_pid_file()
            # Clean up socket file
            if socket_path.exists():
                socket_path.unlink()


@app.command()
def stop():
    """
    Stop the running Claude Board server (daemon mode).
    """
    pid = _read_pid_file()
    if not pid:
        console.print("[yellow]No server is running.[/yellow]")
        raise typer.Exit(0)

    try:
        os.kill(pid, signal.SIGTERM)
        console.print(f"[green]Server stopped (PID: {pid})[/green]")
        _remove_pid_file()
        # Clean up socket file
        if DEFAULT_SOCKET_PATH.exists():
            DEFAULT_SOCKET_PATH.unlink()
    except ProcessLookupError:
        console.print("[yellow]Server process not found, cleaning up...[/yellow]")
        _remove_pid_file()
    except PermissionError:
        console.print(f"[red]Permission denied to stop server (PID: {pid})[/red]")
        raise typer.Exit(1)


@app.command()
def install(
    scope: str = typer.Option(
        "user",
        "--scope",
        "-s",
        help="Where to install hooks: 'user' (~/.claude/settings.json) or 'local' (project .claude/settings.local.json).",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Reinstall even if already installed.",
    ),
):
    """
    Install Claude Board hooks into Claude Code settings.

    This adds hooks that redirect permission requests to the Claude Board
    server. Your existing hooks are preserved.

    After installing, restart Claude Code to load the new hooks.
    """
    # Determine settings file
    if scope == "user":
        settings_file = CLAUDE_SETTINGS_FILE
    elif scope == "local":
        settings_file = CLAUDE_LOCAL_SETTINGS_FILE
    else:
        console.print(f"[red]Invalid scope: {scope}. Use 'user' or 'local'.[/red]")
        raise typer.Exit(1)

    manager = ClaudeSettingsManager(settings_file)

    # Check if already installed
    if manager.is_installed() and not force:
        console.print("[yellow]Claude Board hooks are already installed.[/yellow]")
        console.print("Use [bold]--force[/bold] to reinstall.")
        raise typer.Exit(0)

    # Install hooks
    try:
        manager.install_hooks()
        console.print(Panel.fit(
            f"[bold green]Hooks installed successfully![/bold green]\n\n"
            f"[dim]Settings file:[/dim] {settings_file}\n\n"
            f"[yellow]Important:[/yellow] Restart Claude Code to load the hooks.\n\n"
            f"Then start the server with:\n"
            f"  [bold]claude-board serve[/bold]",
            title="Installation Complete",
            border_style="green",
        ))
    except Exception as e:
        console.print(f"[red]Failed to install hooks: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def uninstall(
    scope: str = typer.Option(
        "user",
        "--scope",
        "-s",
        help="Where to uninstall from: 'user' or 'local'.",
    ),
    all_scopes: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Uninstall from all scopes (user and local).",
    ),
):
    """
    Remove Claude Board hooks from Claude Code settings.

    Your other hooks are preserved.
    """
    scopes_to_uninstall = []

    if all_scopes:
        scopes_to_uninstall = [
            ("user", CLAUDE_SETTINGS_FILE),
            ("local", CLAUDE_LOCAL_SETTINGS_FILE),
        ]
    elif scope == "user":
        scopes_to_uninstall = [("user", CLAUDE_SETTINGS_FILE)]
    elif scope == "local":
        scopes_to_uninstall = [("local", CLAUDE_LOCAL_SETTINGS_FILE)]
    else:
        console.print(f"[red]Invalid scope: {scope}[/red]")
        raise typer.Exit(1)

    uninstalled = []
    for scope_name, settings_file in scopes_to_uninstall:
        manager = ClaudeSettingsManager(settings_file)
        if manager.is_installed():
            try:
                manager.uninstall_hooks()
                uninstalled.append(scope_name)
            except Exception as e:
                console.print(f"[red]Failed to uninstall from {scope_name}: {e}[/red]")

    if uninstalled:
        console.print(f"[green]Hooks uninstalled from: {', '.join(uninstalled)}[/green]")
        console.print("[yellow]Restart Claude Code to apply changes.[/yellow]")
    else:
        console.print("[yellow]No hooks were installed.[/yellow]")


@app.command()
def status():
    """
    Show the current status of Claude Board.

    Displays:
    - Hook installation status
    - Server availability
    - Configuration
    """
    # Check hooks status
    table = Table(title="Claude Board Status")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="green")

    # User hooks
    user_manager = ClaudeSettingsManager(CLAUDE_SETTINGS_FILE)
    user_status = user_manager.get_hooks_status()
    table.add_row(
        "User hooks (~/.claude/settings.json)",
        "[green]Installed[/green]" if user_status.installed else "[dim]Not installed[/dim]"
    )

    # Local hooks
    local_manager = ClaudeSettingsManager(CLAUDE_LOCAL_SETTINGS_FILE)
    local_status = local_manager.get_hooks_status()
    table.add_row(
        "Local hooks (.claude/settings.local.json)",
        "[green]Installed[/green]" if local_status.installed else "[dim]Not installed[/dim]"
    )

    # Server status
    config = AppConfig()
    server_url = f"http://localhost:{config.server.port}"
    server_running = False
    try:
        import urllib.request
        with urllib.request.urlopen(f"{server_url}/api/health", timeout=2) as resp:
            data = resp.read()
            table.add_row("Server", f"[green]Running[/green] at {server_url}")
            server_running = True
    except Exception:
        table.add_row("Server", f"[dim]Not running[/dim] (start with [bold]claude-board serve[/bold])")

    # Network info - show all interfaces
    interfaces = get_network_interfaces()
    if interfaces:
        for i, (iface, ip, is_primary) in enumerate(interfaces):
            label = "Primary Network" if is_primary else f"Network ({iface})"
            url = f"http://{ip}:{config.server.port}"
            if is_primary:
                table.add_row(label, f"[bold]{url}[/bold]")
            else:
                table.add_row(label, f"[dim]{url}[/dim]")
    else:
        table.add_row("Network", "[dim]Unknown[/dim]")

    # RPC Socket status
    if DEFAULT_SOCKET_PATH.exists():
        table.add_row("RPC Socket", f"[green]{DEFAULT_SOCKET_PATH}[/green]")
    else:
        table.add_row("RPC Socket", f"[dim]Not active[/dim]")

    console.print(table)

    # Show detailed hook info if installed
    if user_status.installed or local_status.installed:
        console.print("\n[dim]Installed hooks:[/dim]")
        for hook in user_status.our_hooks + local_status.our_hooks:
            console.print(f"  • {hook.event}: {hook.matcher}")

        if user_status.other_hooks_count + local_status.other_hooks_count > 0:
            total_other = user_status.other_hooks_count + local_status.other_hooks_count
            console.print(f"\n[dim]Other hooks preserved: {total_other}[/dim]")

    # Show QR code if server is running
    if server_running and interfaces:
        for iface, ip, is_primary in interfaces:
            if is_primary:
                _print_qr_code(f"http://{ip}:{config.server.port}")
                break


@app.command()
def config(
    show: bool = typer.Option(
        True,
        "--show/--no-show",
        help="Show current configuration.",
    ),
    port: Optional[int] = typer.Option(
        None,
        "--port",
        "-p",
        help="Set default server port.",
    ),
    yolo: Optional[bool] = typer.Option(
        None,
        "--yolo/--no-yolo",
        help="Set default YOLO mode.",
    ),
):
    """
    Show or modify Claude Board configuration.
    """
    app_config = AppConfig()

    # Apply changes
    changed = False
    if port is not None:
        app_config.server.port = port
        changed = True
    if yolo is not None:
        app_config.yolo_mode_default = yolo
        changed = True

    if changed:
        # Save to user config directory
        config_path = Path.home() / ".claude-board" / "config.json"
        app_config.save(config_path)
        console.print(f"[green]Configuration saved to {config_path}[/green]")

    if show:
        table = Table(title="Configuration")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")

        table.add_row("Server Host", app_config.server.host)
        table.add_row("Server Port", str(app_config.server.port))
        table.add_row("Hook Timeout", f"{app_config.server.hook_timeout}s")
        table.add_row("YOLO Default", str(app_config.yolo_mode_default))
        table.add_row("Safe Tools", ", ".join(app_config.hooks.safe_tools[:5]) + "...")
        table.add_row("Bluetooth", "[dim]Not yet implemented[/dim]")

        console.print(table)


@app.command()
def qr(
    port: Optional[int] = typer.Option(
        None,
        "--port",
        "-p",
        help="Port number (default: from config or 8765).",
    ),
):
    """
    Display QR code for mobile access.

    Shows a scannable QR code for the primary network interface URL.
    Useful for quickly connecting from a mobile device.
    """
    app_config = AppConfig()
    actual_port = port or app_config.server.port

    interfaces = get_network_interfaces()
    if not interfaces:
        console.print("[red]No network interfaces found.[/red]")
        raise typer.Exit(1)

    # Find primary interface
    primary_url = None
    for iface, ip, is_primary in interfaces:
        if is_primary:
            primary_url = f"http://{ip}:{actual_port}"
            console.print(f"[bold]Primary interface:[/bold] {iface} ({ip})")
            break

    if not primary_url:
        # Fallback to first interface
        iface, ip, _ = interfaces[0]
        primary_url = f"http://{ip}:{actual_port}"
        console.print(f"[bold]Interface:[/bold] {iface} ({ip})")

    _print_qr_code(primary_url)

    # Show all interfaces
    if len(interfaces) > 1:
        console.print("[dim]Other interfaces:[/dim]")
        for iface, ip, is_primary in interfaces:
            if not is_primary:
                console.print(f"  [dim]{iface}: http://{ip}:{actual_port}[/dim]")


# Future: Bluetooth commands
@app.command(hidden=True)
def ble():
    """
    [Future] Bluetooth device management.

    This command will be available in Phase 2 when Bluetooth
    support is implemented.
    """
    console.print(Panel.fit(
        "[yellow]Bluetooth support is planned for Phase 2.[/yellow]\n\n"
        "The physical console will feature:\n"
        "• 4 mechanical key switches (Approve, Deny, Retry, YOLO)\n"
        "• E-ink display for task status\n"
        "• Bluetooth LE connection\n"
        "• Battery powered\n\n"
        "[dim]Stay tuned![/dim]",
        title="Coming Soon",
        border_style="yellow",
    ))


@app.command()
def rpc(
    method: str = typer.Argument(
        ...,
        help="RPC method to call (get_state, approve, deny, set_yolo, reset, health)",
    ),
    params: Optional[str] = typer.Argument(
        None,
        help="JSON params for the method (e.g., '{\"request_id\": \"abc\"}')",
    ),
    socket_path: Optional[str] = typer.Option(
        None,
        "--socket",
        "-s",
        help=f"Unix socket path (default: {DEFAULT_SOCKET_PATH})",
    ),
):
    """
    Call the Claude Board RPC API.

    This allows programmatic control of the server from scripts or GUI tools.

    Examples:
        claude-board rpc health
        claude-board rpc get_state
        claude-board rpc approve '{"request_id": "abc123"}'
        claude-board rpc set_yolo '{"enabled": true}'
    """
    import json as json_module

    sock_path = Path(socket_path) if socket_path else DEFAULT_SOCKET_PATH

    if not sock_path.exists():
        console.print(f"[red]RPC socket not found: {sock_path}[/red]")
        console.print("Is the server running? Start with: [bold]claude-board serve[/bold]")
        raise typer.Exit(1)

    # Parse params
    parsed_params = {}
    if params:
        try:
            parsed_params = json_module.loads(params)
        except json_module.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON params: {e}[/red]")
            raise typer.Exit(1)

    # Build JSON-RPC request
    request = {
        "jsonrpc": "2.0",
        "method": method,
        "params": parsed_params,
        "id": 1
    }

    try:
        # Connect to Unix socket
        import socket as sock_module
        client = sock_module.socket(sock_module.AF_UNIX, sock_module.SOCK_STREAM)
        client.connect(str(sock_path))
        client.settimeout(5.0)

        # Send request
        client.sendall((json_module.dumps(request) + "\n").encode("utf-8"))

        # Read response
        response_data = b""
        while True:
            chunk = client.recv(4096)
            if not chunk:
                break
            response_data += chunk
            if b"\n" in response_data:
                break

        client.close()

        # Parse response
        response = json_module.loads(response_data.decode("utf-8"))

        if "error" in response:
            console.print(f"[red]Error:[/red] {response['error']['message']}")
            raise typer.Exit(1)

        # Pretty print result
        result = response.get("result", {})
        console.print_json(json_module.dumps(result, indent=2, default=str))

    except FileNotFoundError:
        console.print(f"[red]Socket not found: {sock_path}[/red]")
        raise typer.Exit(1)
    except ConnectionRefusedError:
        console.print(f"[red]Connection refused. Is the server running?[/red]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]RPC error: {e}[/red]")
        raise typer.Exit(1)


@app.command(hidden=True)
def hook(
    hook_type: str = typer.Argument(
        "permission",
        help="Hook type: 'permission', 'todo', or 'stop'",
    ),
):
    """
    Internal command called by Claude Code hooks.

    This is not meant to be called directly by users.
    It reads JSON from stdin and outputs JSON to stdout.
    """
    import sys

    if hook_type == "permission":
        from .hooks.permission_hook import main as permission_main
        permission_main()
    elif hook_type == "todo":
        from .hooks.todo_hook import main as todo_main
        todo_main()
    elif hook_type == "stop":
        from .hooks.stop_hook import main as stop_main
        stop_main()
    else:
        print(f"Unknown hook type: {hook_type}", file=sys.stderr)
        sys.exit(1)


# Session state directory
SESSIONS_DIR = Path.home() / ".claude-board" / "sessions"


@app.command()
def chat(
    mode: str = typer.Option(
        "interactive",
        "--mode",
        "-m",
        help="Session mode: 'interactive' (with terminal UI) or 'headless' (background only).",
    ),
    resume: Optional[str] = typer.Option(
        None,
        "--resume",
        "-r",
        help="Resume a session. Use without value to show picker, or specify session ID/name.",
        is_flag=False,
        flag_value="__picker__",
    ),
    name: Optional[str] = typer.Option(
        None,
        "--name",
        "-n",
        help="Name for the new session (for easier identification).",
    ),
    attach_session: Optional[str] = typer.Option(
        None,
        "--attach",
        "-a",
        help="Attach to an existing claude-board session by ID or name.",
        is_flag=False,
        flag_value="__auto__",
    ),
    list_sessions: bool = typer.Option(
        False,
        "--list",
        "-l",
        help="List all active sessions.",
    ),
    kill_session: Optional[str] = typer.Option(
        None,
        "--kill",
        "-k",
        help="Kill a session by ID or name.",
    ),
    send_prompt: Optional[str] = typer.Option(
        None,
        "--send",
        "-s",
        help="Send a prompt to a session without attaching.",
    ),
    session_target: Optional[str] = typer.Option(
        None,
        "--session",
        help="Target session for --send or --kill (ID or name).",
    ),
    project_path: Optional[str] = typer.Option(
        None,
        "--project",
        "-p",
        help="Project directory (defaults to current directory).",
    ),
):
    """
    Start or manage Claude Code chat sessions.

    Sessions can run in the background and be attached/detached,
    allowing you to continue conversations from both terminal and Web UI.

    Examples:

        # Start a new interactive session
        claude-board chat

        # Start with a name
        claude-board chat --name my-feature

        # Start and resume Claude Code's last session
        claude-board chat --resume

        # Resume a specific Claude Code session
        claude-board chat --resume abc123

        # List all active sessions
        claude-board chat --list

        # Attach to an existing session
        claude-board chat --attach my-feature

        # Send a prompt without attaching
        claude-board chat --send "Fix the bug" --session my-feature

        # Run in headless mode (no terminal UI)
        claude-board chat --mode headless

        # Kill a session
        claude-board chat --kill my-feature
    """
    import asyncio

    # Handle --list
    if list_sessions:
        _list_chat_sessions()
        return

    # Handle --kill
    if kill_session:
        asyncio.run(_kill_chat_session(kill_session))
        return

    # Handle --send
    if send_prompt:
        if not session_target:
            console.print("[red]Error: --send requires --session to specify target session[/red]")
            raise typer.Exit(1)
        asyncio.run(_send_to_session(session_target, send_prompt))
        return

    # Handle --attach
    if attach_session:
        asyncio.run(_attach_to_session(attach_session))
        return

    # Start a new session or create one
    asyncio.run(_start_chat_session(
        mode=mode,
        resume=resume,
        name=name,
        project_path=project_path or os.getcwd(),
    ))


def _list_chat_sessions() -> None:
    """List all active chat sessions via server API"""
    import json
    import urllib.error
    import urllib.request

    config = AppConfig()
    base_url = f"http://127.0.0.1:{config.server.port}"

    try:
        req = urllib.request.Request(f"{base_url}/api/sessions")
        with urllib.request.urlopen(req, timeout=10) as response:
            data = json.loads(response.read().decode("utf-8"))
            sessions = data.get("sessions", [])
    except urllib.error.URLError:
        console.print("[red]Server not running. Start it with: claude-board serve[/red]")
        raise typer.Exit(1)

    if not sessions:
        console.print("[dim]No active sessions.[/dim]")
        console.print("Start a new session with: [bold]claude-board chat[/bold]")
        return

    table = Table(title="Active Chat Sessions")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Project", style="blue")
    table.add_column("State", style="yellow")
    table.add_column("Clients", style="magenta")
    table.add_column("Created", style="dim")

    for session in sessions:
        created_raw = session.get("created_at", "")
        created_str = str(created_raw) if created_raw else ""
        if created_str:
            from datetime import datetime
            try:
                dt = datetime.fromisoformat(created_str)
                created_str = dt.strftime("%H:%M:%S")
            except Exception:
                pass

        clients = f"T:{session.get('terminal_clients', 0)} W:{session.get('web_clients', 0)}"

        table.add_row(
            str(session.get("session_id", ""))[:8],
            str(session.get("name") or "-"),
            str(session.get("project_name", "")),
            str(session.get("state", "")),
            clients,
            created_str,
        )

    console.print(table)


async def _kill_chat_session(session_id: str) -> None:
    """Kill a chat session via server API"""
    import urllib.error
    import urllib.request

    config = AppConfig()
    base_url = f"http://127.0.0.1:{config.server.port}"

    try:
        # Use DELETE request to stop the session
        req = urllib.request.Request(
            f"{base_url}/api/sessions/{session_id}",
            method="DELETE",
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            response.read()
            console.print(f"[green]Session '{session_id}' stopped.[/green]")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            console.print(f"[red]Session '{session_id}' not found.[/red]")
        else:
            console.print(f"[red]Failed to stop session: {e}[/red]")
        raise typer.Exit(1)
    except urllib.error.URLError:
        console.print("[red]Server not running. Start it with: claude-board serve[/red]")
        raise typer.Exit(1)


async def _send_to_session(session_id: str, prompt: str) -> None:
    """Send a prompt to a session via server API"""
    import json
    import urllib.error
    import urllib.request

    config = AppConfig()
    base_url = f"http://127.0.0.1:{config.server.port}"

    try:
        data = json.dumps({"prompt": prompt}).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/api/sessions/{session_id}/prompt",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            response.read()
            console.print(f"[green]Prompt sent to session '{session_id}'.[/green]")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            console.print(f"[red]Session '{session_id}' not found.[/red]")
        elif e.code == 400:
            console.print(f"[red]Session '{session_id}' is not running.[/red]")
        else:
            console.print(f"[red]Failed to send prompt: {e}[/red]")
        raise typer.Exit(1)
    except urllib.error.URLError:
        console.print("[red]Server not running. Start it with: claude-board serve[/red]")
        raise typer.Exit(1)


async def _attach_to_session(session_id: str) -> None:
    """Attach to an existing session via WebSocket"""
    import json
    import urllib.error
    import urllib.request

    from .chat.terminal_client import WebSocketTerminalClient

    config = AppConfig()
    base_url = f"http://127.0.0.1:{config.server.port}"

    # Handle auto-attach (if only one session)
    if session_id == "__auto__":
        try:
            req = urllib.request.Request(f"{base_url}/api/sessions")
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode("utf-8"))
                sessions = [s for s in data.get("sessions", []) if s.get("is_alive")]
        except urllib.error.URLError:
            console.print("[red]Server not running. Start it with: claude-board serve[/red]")
            raise typer.Exit(1)

        if not sessions:
            console.print("[red]No active sessions to attach to.[/red]")
            console.print("Start a new session with: [bold]claude-board chat[/bold]")
            raise typer.Exit(1)
        if len(sessions) > 1:
            console.print("[yellow]Multiple sessions available. Please specify one:[/yellow]")
            _list_chat_sessions()
            raise typer.Exit(1)
        session_id = sessions[0].get("session_id", "")
        session_name = sessions[0].get("name") or session_id
    else:
        # Verify session exists
        try:
            req = urllib.request.Request(f"{base_url}/api/sessions/{session_id}")
            with urllib.request.urlopen(req, timeout=10) as response:
                session_data = json.loads(response.read().decode("utf-8"))
                session_name = session_data.get("name") or session_id
                if not session_data.get("is_alive"):
                    console.print(f"[red]Session '{session_id}' is not running.[/red]")
                    raise typer.Exit(1)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                console.print(f"[red]Session '{session_id}' not found.[/red]")
            else:
                console.print(f"[red]Failed to get session: {e}[/red]")
            raise typer.Exit(1)
        except urllib.error.URLError:
            console.print("[red]Server not running. Start it with: claude-board serve[/red]")
            raise typer.Exit(1)

    console.print(f"[green]Attaching to session '{session_name}'...[/green]")
    console.print("[dim]Press Ctrl+Q to detach[/dim]\n")

    # Attach using WebSocket terminal client
    client = WebSocketTerminalClient(base_url, session_id)
    exit_code = await client.attach()

    if exit_code == 0:
        console.print("\n[green]Detached from session.[/green]")
    elif exit_code == 2:
        console.print("\n[yellow]Session ended.[/yellow]")
    else:
        console.print("\n[red]Error during session.[/red]")


async def _start_chat_session(
    mode: str,
    resume: Optional[str],
    name: Optional[str],
    project_path: str,
) -> None:
    """Start a new chat session - local PTY for interactive, server for headless"""
    # Determine resume option for Claude Code
    claude_resume: str | bool | None = None
    if resume == "__picker__":
        claude_resume = True  # Show interactive picker
    elif resume:
        claude_resume = resume  # Specific session ID

    if mode == "interactive":
        # Interactive mode: run directly with local PTY (no server needed)
        await _run_local_interactive_session(
            resume=claude_resume,
            project_path=project_path,
        )
    else:
        # Headless mode: use server
        await _run_headless_session(
            resume=claude_resume,
            name=name,
            project_path=project_path,
        )


async def _run_local_interactive_session(
    resume: str | bool | None,
    project_path: str,
) -> None:
    """Run Claude Code directly with local PTY - no server/WebSocket overhead"""
    import fcntl
    import pty
    import select
    import shutil
    import struct
    import termios
    import tty

    # Show startup info
    console.print(Panel.fit(
        f"[bold green]Starting Claude Code Session[/bold green]\n\n"
        f"[dim]Project:[/dim]  {project_path}\n"
        f"[dim]Resume:[/dim]   {resume or 'new session'}\n\n"
        f"[yellow]Press Ctrl+Q to exit[/yellow]",
        title="Claude Board Chat",
        border_style="green",
    ))

    # Find claude executable
    claude_path = shutil.which("claude")
    if not claude_path:
        console.print("[red]Claude Code CLI not found in PATH[/red]")
        raise typer.Exit(1)

    # Build command
    cmd = [claude_path]
    if resume is True:
        cmd.append("--resume")
    elif isinstance(resume, str) and resume:
        cmd.extend(["--resume", resume])

    # Save original terminal settings
    old_settings = termios.tcgetattr(sys.stdin)

    # Create PTY
    master_fd, slave_fd = pty.openpty()

    try:
        # Set PTY size to match current terminal
        size = os.get_terminal_size()
        winsize = struct.pack("HHHH", size.lines, size.columns, 0, 0)
        fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, winsize)

        # Fork child process
        pid = os.fork()
        if pid == 0:
            # Child process
            os.close(master_fd)
            os.setsid()
            os.dup2(slave_fd, 0)
            os.dup2(slave_fd, 1)
            os.dup2(slave_fd, 2)
            os.close(slave_fd)

            # Change to project directory
            os.chdir(project_path)

            # Set environment
            env = {
                **os.environ,
                "TERM": os.environ.get("TERM", "xterm-256color"),
                "COLORTERM": os.environ.get("COLORTERM", "truecolor"),
                "FORCE_COLOR": "1",
                "CLICOLOR": "1",
                "CLICOLOR_FORCE": "1",
            }

            os.execve(claude_path, cmd, env)

        # Parent process
        os.close(slave_fd)

        # Set terminal to raw mode
        tty.setraw(sys.stdin)

        # Set up SIGWINCH handler for terminal resize
        import signal

        def handle_sigwinch(signum, frame):
            try:
                size = os.get_terminal_size()
                winsize = struct.pack("HHHH", size.lines, size.columns, 0, 0)
                fcntl.ioctl(master_fd, termios.TIOCSWINSZ, winsize)
            except (OSError, ValueError):
                pass

        old_sigwinch = signal.signal(signal.SIGWINCH, handle_sigwinch)

        # I/O loop
        try:
            while True:
                r, _, _ = select.select([sys.stdin, master_fd], [], [], 0.1)

                if sys.stdin in r:
                    data = os.read(sys.stdin.fileno(), 1024)
                    if not data:
                        break
                    # Ctrl+Q to detach (but in local mode, just exit)
                    if b'\x11' in data:
                        break
                    os.write(master_fd, data)

                if master_fd in r:
                    try:
                        data = os.read(master_fd, 4096)
                        if data:
                            os.write(sys.stdout.fileno(), data)
                        else:
                            break
                    except OSError:
                        break

                # Check if child process is still running
                result = os.waitpid(pid, os.WNOHANG)
                if result[0] != 0:
                    # Child exited, read any remaining output
                    while True:
                        r, _, _ = select.select([master_fd], [], [], 0.1)
                        if not r:
                            break
                        try:
                            data = os.read(master_fd, 4096)
                            if data:
                                os.write(sys.stdout.fileno(), data)
                            else:
                                break
                        except OSError:
                            break
                    break

        finally:
            signal.signal(signal.SIGWINCH, old_sigwinch)

    finally:
        # Restore terminal settings
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)
        os.close(master_fd)

        # Ensure child is cleaned up
        try:
            os.waitpid(pid, 0)
        except ChildProcessError:
            pass

    console.print("\n[dim]Session ended.[/dim]")


async def _run_headless_session(
    resume: str | bool | None,
    name: Optional[str],
    project_path: str,
) -> None:
    """Run session in headless mode via server"""
    import json
    import urllib.error
    import urllib.request

    from .config import AppConfig

    config = AppConfig()
    server_url = f"http://127.0.0.1:{config.server.port}"

    console.print(Panel.fit(
        f"[bold green]Starting Claude Code Session (Headless)[/bold green]\n\n"
        f"[dim]Project:[/dim]  {project_path}\n"
        f"[dim]Resume:[/dim]   {resume or 'new session'}",
        title="Claude Board Chat",
        border_style="green",
    ))

    try:
        data = json.dumps({
            "name": name,
            "project_path": project_path,
            "resume": resume,
            "rows": 24,
            "cols": 80,
        }).encode("utf-8")

        req = urllib.request.Request(
            f"{server_url}/api/sessions",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode("utf-8"))

        if result.get("status") != "ok":
            console.print(f"[red]Failed to create session: {result}[/red]")
            raise typer.Exit(1)

        session_info = result["session"]
        session_id = session_info["session_id"]

    except urllib.error.URLError as e:
        console.print(f"[red]Cannot connect to server. Is 'claude-board serve' running?[/red]")
        console.print(f"[dim]Error: {e}[/dim]")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"[red]Failed to create session: {e}[/red]")
        raise typer.Exit(1)

    console.print(f"\n[green]Session started: {session_id}[/green]")
    console.print("\n[green]Session running in background.[/green]")
    console.print(f"Attach with: [bold]claude-board chat --attach {session_id}[/bold]")
    console.print(f"Send prompt: [bold]claude-board chat --send 'your prompt' --session {session_id}[/bold]")
    console.print(f"Kill: [bold]claude-board chat --kill {session_id}[/bold]")


def cli():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    cli()
