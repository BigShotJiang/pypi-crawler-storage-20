"""
Per-Epoch Quality Assessment

Lightweight quality checks that run every epoch during ES training.
Provides immediate feedback on embedding health without expensive computations.
"""

import logging
from typing import Dict, Tuple, Optional, List

logger = logging.getLogger(__name__)


def compute_epoch_quality_score(
    epoch_idx: int,
    current_emb_std: Optional[float],
    baseline_emb_std: Optional[float],
    gradient_norm: Optional[float],
    val_loss: Optional[float],
    prev_val_loss: Optional[float],
    ww_instability: bool = False
) -> Tuple[float, str, List[str]]:
    """
    Compute a lightweight quality score for the current epoch.
    
    This runs every epoch and provides immediate feedback on training health
    without the overhead of full quality assessment.
    
    Args:
        epoch_idx: Current epoch number
        current_emb_std: Current embedding std/dim (from collapse diagnostics)
        baseline_emb_std: Baseline embedding std/dim (from early epochs, e.g. epoch 5)
        gradient_norm: Unclipped gradient norm
        val_loss: Current validation loss
        prev_val_loss: Previous epoch validation loss
        ww_instability: Whether WeightWatcher detected instability this epoch
    
    Returns:
        Tuple of (score: float 0-100, grade: str A-F, warnings: List[str])
    
    Score breakdown:
        - Embedding health (40 points): Based on std/dim
        - Gradient health (30 points): Based on gradient norm stability
        - Loss progress (30 points): Based on validation loss improvement
    """
    score = 0.0
    warnings = []
    
    # =========================================================================
    # COMPONENT 1: EMBEDDING HEALTH (40 points)
    # =========================================================================
    embedding_score = 0.0
    
    if current_emb_std is not None:
        # Absolute std/dim thresholds
        if current_emb_std >= 0.04:
            embedding_score = 40.0  # Excellent
        elif current_emb_std >= 0.03:
            embedding_score = 32.0  # Good (80%)
            warnings.append(f"⚠️  Embedding std/dim slightly low: {current_emb_std:.4f} (target: >0.04)")
        elif current_emb_std >= 0.02:
            embedding_score = 24.0  # Fair (60%)
            warnings.append(f"⚠️  Embedding compression detected: {current_emb_std:.4f} (target: >0.04)")
        elif current_emb_std >= 0.01:
            embedding_score = 12.0  # Poor (30%)
            warnings.append(f"❌ Moderate embedding collapse: {current_emb_std:.4f} (target: >0.04)")
        else:
            embedding_score = 0.0  # Critical
            warnings.append(f"❌ CRITICAL: Severe embedding collapse: {current_emb_std:.4f} (target: >0.04)")
        
        # Check for progressive collapse (if we have baseline)
        if baseline_emb_std is not None and baseline_emb_std > 0:
            decline_pct = ((baseline_emb_std - current_emb_std) / baseline_emb_std) * 100
            if decline_pct > 50:
                embedding_score *= 0.5  # Penalize 50% for progressive collapse
                warnings.append(f"❌ Progressive collapse: {decline_pct:.1f}% decline from baseline")
            elif decline_pct > 20:
                embedding_score *= 0.8  # Penalize 20% for variance degradation
                warnings.append(f"⚠️  Variance degrading: {decline_pct:.1f}% decline from baseline")
    else:
        # No embedding data available
        embedding_score = 20.0  # Neutral score (50% of max)
    
    score += embedding_score
    
    # =========================================================================
    # COMPONENT 2: GRADIENT HEALTH (30 points)
    # =========================================================================
    gradient_score = 0.0
    
    if gradient_norm is not None:
        # Reasonable gradient norms for ES training (calibrated for real datasets with 100+ columns)
        # These thresholds are much higher than SP training because ES has many more parameters
        if gradient_norm < 0.01:
            gradient_score = 10.0  # Very small gradients (33%)
            warnings.append(f"⚠️  Very small gradients: {gradient_norm:.6f} (may indicate dead network)")
        elif gradient_norm < 5000:
            gradient_score = 30.0  # Healthy range for ES training
        elif gradient_norm < 15000:
            gradient_score = 25.0  # Elevated but manageable (83%)
            # No warning - this is normal for large ES
        elif gradient_norm < 50000:
            gradient_score = 15.0  # High - watch it (50%)
            warnings.append(f"⚠️  High gradient norm: {gradient_norm:.2f}")
        elif gradient_norm < 100000:
            gradient_score = 5.0  # Very high - instability risk (17%)
            warnings.append(f"❌ Very high gradient norm: {gradient_norm:.2f} (instability risk)")
        else:
            gradient_score = 0.0  # Exploding
            warnings.append(f"❌ CRITICAL: Gradient explosion: {gradient_norm:.2e}")
    else:
        # No gradient data available
        gradient_score = 15.0  # Neutral score (50% of max)
    
    # Penalize if WeightWatcher detected instability
    if ww_instability:
        gradient_score *= 0.5  # Cut gradient score in half
        warnings.append("⚠️  WeightWatcher detected instability")
    
    score += gradient_score
    
    # =========================================================================
    # COMPONENT 3: LOSS PROGRESS (30 points)
    # =========================================================================
    loss_score = 0.0
    
    if val_loss is not None and prev_val_loss is not None:
        if val_loss < prev_val_loss:
            # Loss improving
            improvement_pct = ((prev_val_loss - val_loss) / prev_val_loss) * 100
            if improvement_pct > 5:
                loss_score = 30.0  # Excellent improvement
            elif improvement_pct > 1:
                loss_score = 25.0  # Good improvement (83%)
            elif improvement_pct > 0:
                loss_score = 20.0  # Marginal improvement (67%)
        elif val_loss == prev_val_loss:
            loss_score = 15.0  # Stagnant (50%)
            warnings.append("⚠️  Validation loss stagnant")
        else:
            # Loss getting worse
            degradation_pct = ((val_loss - prev_val_loss) / prev_val_loss) * 100
            if degradation_pct < 5:
                loss_score = 10.0  # Minor degradation (33%)
                warnings.append("⚠️  Validation loss slightly worse")
            elif degradation_pct < 10:
                loss_score = 5.0  # Moderate degradation (17%)
                warnings.append("❌ Validation loss degrading")
            else:
                loss_score = 0.0  # Severe degradation
                warnings.append("❌ CRITICAL: Validation loss significantly worse")
    elif val_loss is not None:
        # First epoch or no previous loss
        loss_score = 15.0  # Neutral score (50% of max)
    else:
        # No validation loss available
        loss_score = 15.0  # Neutral score (50% of max)
    
    score += loss_score
    
    # =========================================================================
    # CONVERT SCORE TO GRADE
    # =========================================================================
    if score >= 90:
        grade = "A"
    elif score >= 80:
        grade = "B"
    elif score >= 70:
        grade = "C"
    elif score >= 60:
        grade = "D"
    else:
        grade = "F"
    
    return score, grade, warnings


def log_epoch_quality(
    epoch_idx: int,
    n_epochs: int,
    score: float,
    grade: str,
    warnings: List[str],
    current_emb_std: Optional[float] = None,
    gradient_norm: Optional[float] = None,
    val_loss: Optional[float] = None
) -> None:
    """
    Log the per-epoch quality assessment in a compact, readable format.
    
    Args:
        epoch_idx: Current epoch number
        n_epochs: Total epochs
        score: Quality score (0-100)
        grade: Letter grade (A-F)
        warnings: List of warning messages
        current_emb_std: Current embedding std/dim (for display)
        gradient_norm: Current gradient norm (for display)
        val_loss: Current validation loss (for display)
    """
    # Compact one-line summary
    grade_emoji = {
        "A": "✅",
        "B": "👍",
        "C": "⚠️ ",
        "D": "❌",
        "F": "💥"
    }
    
    emoji = grade_emoji.get(grade, "❓")
    
    # Build metrics string
    metrics = []
    if current_emb_std is not None:
        metrics.append(f"std/dim={current_emb_std:.4f}")
    if gradient_norm is not None:
        if gradient_norm < 1000:
            metrics.append(f"grad={gradient_norm:.2f}")
        else:
            metrics.append(f"grad={gradient_norm:.2e}")
    if val_loss is not None:
        metrics.append(f"val_loss={val_loss:.4f}")
    
    metrics_str = ", ".join(metrics) if metrics else "no metrics"
    
    logger.info(f"{emoji} Epoch {epoch_idx}/{n_epochs} Quality: {grade} ({score:.0f}/100) | {metrics_str}")
    
    # Log warnings if any (indented for readability)
    if warnings:
        for warning in warnings:
            logger.info(f"   {warning}")


def should_stop_training(
    consecutive_failing_epochs: int,
    max_failing_epochs: int = 10
) -> bool:
    """
    Determine if training should stop based on consecutive failing quality checks.
    
    Args:
        consecutive_failing_epochs: Number of consecutive epochs with F grade
        max_failing_epochs: Maximum consecutive failures before stopping
    
    Returns:
        bool: True if training should stop
    """
    return consecutive_failing_epochs >= max_failing_epochs
