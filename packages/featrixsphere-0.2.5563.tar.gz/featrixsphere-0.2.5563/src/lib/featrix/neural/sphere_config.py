#!/usr/bin/env python3
"""
Sphere Configuration Management

Loads configuration from /sphere/app/config.json if it exists, otherwise uses defaults.
Makes it easy to experiment with different model configurations without code changes.
"""

import json
import logging
import os
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Default configuration path
DEFAULT_CONFIG_PATH = "/sphere/app/config.json"

# Default values if config file is missing
DEFAULT_CONFIG = {
    "d_model": 128,  # Embedding dimension size
    "normalize_column_encoders": False,  # Phase 1 fix: only normalize in joint encoder
    "normalize_joint_encoder": True,  # Should almost always be True
    "use_semantic_set_initialization": True,  # Initialize set embeddings from BERT (also enables OOV handling)
    "enable_spectral_norm_clipping": True,  # Enable spectral norm clipping during training
    "spectral_norm_clip_threshold": 12.0,  # Maximum spectral norm before clipping (if enabled)
    "adaptive_scalar_hidden_dim": 16,  # Hidden dimension for AdaptiveScalarEncoder MLPs (default: 16 for speed)
    "use_delimiter_preprocessing": False,  # Preprocess delimited strings ("a,b,c" → "a\nb\nc") before BERT encoding
    "enable_predictor_architecture_selection": False,  # DISABLED: Architecture selection wastes 30+ epochs for <1% improvement
    "string_server_host": "taco.local",  # String server host: "taco", "taco.local", or "localhost" (None = use local model)
    "es_weight_initialization": "random",  # "random" = standard pytorch init, "pca_string" = init from PCA of string embeddings
    "use_bf16": False,  # BF16 mixed precision training (RTX 4090/Ampere+ only, saves ~50% memory)
    "enable_predictor_attention": True,  # Enable attention mechanism in predictor MLPs (improves AUC ~5%)
    "predictor_attention_heads": 4,  # Number of attention heads for predictor (only used if enable_predictor_attention=True)
    "disable_curriculum_learning": False,  # Disable loss weight curriculum (use constant 1.0 weights for spread/marginal/joint)
    "freeze_es_warmup_enabled": True,  # Freeze embedding space for first 5% of SP training epochs (only if > 5 epochs)
    "max_sp_epochs": None,  # Override max epochs for single predictor training (None = use default from training args)
    "max_es_epochs": None,  # Override max epochs for embedding space training (None = use default from training args)
    "enable_embedding_diversity_loss": True,  # ENABLED BY DEFAULT: Prevents global embedding collapse (std/dim → 0)
    "embedding_diversity_weight": 1.0,  # Weight for diversity loss (if enabled) - matches spread_loss_weight for equal importance
    "use_muon_optimizer": False,  # Use Muon optimizer instead of AdamW (experimental, may improve convergence)
    "enable_reconstruction_loss": False,  # Add direct value reconstruction loss to marginal loss (ablation testing)
    "reconstruction_loss_weight": 1.0,  # Weight for reconstruction loss (if enabled)
    # Future parameters can be added here:
    # "learning_rate": 0.001,
    # "batch_size": 256,
    # "dropout": 0.1,
}


class SphereConfig:
    """
    Singleton configuration manager for Sphere.
    
    Usage:
        config = SphereConfig.get_instance()
        d_model = config.get_d_model()
    """
    
    _instance: Optional['SphereConfig'] = None
    _config: Dict[str, Any] = None
    _config_path: str = DEFAULT_CONFIG_PATH
    
    def __init__(self):
        """Private constructor. Use get_instance() instead."""
        if SphereConfig._instance is not None:
            raise RuntimeError("Use SphereConfig.get_instance() instead of direct instantiation")
        self._load_config()
    
    @classmethod
    def get_instance(cls, config_path: str = None) -> 'SphereConfig':
        """
        Get the singleton instance of SphereConfig.
        
        Args:
            config_path: Optional custom path to config file (for testing)
        
        Returns:
            SphereConfig instance
        """
        if cls._instance is None:
            if config_path:
                cls._config_path = config_path
            cls._instance = cls()
        return cls._instance
    
    @classmethod
    def reset(cls):
        """Reset the singleton (useful for testing)."""
        cls._instance = None
        cls._config = None
        cls._config_path = DEFAULT_CONFIG_PATH
    
    def _load_config(self):
        """Load configuration from file or use defaults."""
        config_file = Path(self._config_path)
        
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    self._config = json.load(f)
                logger.info(f"📋 Loaded Sphere configuration from {config_file}")
                logger.info(f"   Configuration: {json.dumps(self._config, indent=2)}")
                
                # Merge with defaults (in case config file doesn't have all keys)
                for key, default_value in DEFAULT_CONFIG.items():
                    if key not in self._config:
                        logger.info(f"   Using default for missing key '{key}': {default_value}")
                        self._config[key] = default_value
                        
            except json.JSONDecodeError as e:
                logger.error(f"❌ Failed to parse config file {config_file}: {e}")
                logger.info(f"   Using default configuration")
                self._config = DEFAULT_CONFIG.copy()
            except Exception as e:
                logger.error(f"❌ Error reading config file {config_file}: {e}")
                logger.info(f"   Using default configuration")
                self._config = DEFAULT_CONFIG.copy()
        else:
            logger.info(f"ℹ️  No config file found at {config_file}")
            logger.info(f"   Using default configuration: {json.dumps(DEFAULT_CONFIG, indent=2)}")
            self._config = DEFAULT_CONFIG.copy()
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value by key.
        
        Args:
            key: Configuration key
            default: Default value if key not found
        
        Returns:
            Configuration value or default
        """
        return self._config.get(key, default)
    
    def set(self, key: str, value: Any) -> Any:
        """
        Set a configuration value (for testing/runtime override).
        
        Args:
            key: Configuration key
            value: Value to set
        
        Returns:
            Previous value (or None if key didn't exist)
        
        Example:
            config = get_config()
            old_value = config.set("es_weight_initialization", "pca_string")
            # ... do something ...
            config.set("es_weight_initialization", old_value)  # restore
        """
        old_value = self._config.get(key)
        self._config[key] = value
        logger.info(f"📋 Config override: {key} = {value} (was: {old_value})")
        return old_value
    
    def get_d_model(self) -> int:
        """Get the d_model (embedding dimension) parameter."""
        return self._config.get("d_model", DEFAULT_CONFIG["d_model"])
    
    def get_normalize_column_encoders(self) -> bool:
        """
        Get whether to normalize individual column encoder outputs.
        
        When False: Column encoders return unnormalized vectors (Phase 1 fix)
        When True: Column encoders normalize their outputs (legacy behavior)
        
        Default: True (for backward compatibility)
        
        This controls the redundant normalization that limits sphere coverage.
        Setting to False removes column-level normalization, keeping only the
        final joint encoder normalization.
        """
        return self._config.get("normalize_column_encoders", DEFAULT_CONFIG["normalize_column_encoders"])
    
    def get_normalize_joint_encoder(self) -> bool:
        """
        Get whether to normalize joint encoder output.
        
        This should almost always be True to ensure embeddings lie on unit sphere.
        
        Default: True
        
        Only set to False for experimental purposes or specific use cases
        where unnormalized embeddings are desired.
        """
        return self._config.get("normalize_joint_encoder", DEFAULT_CONFIG["normalize_joint_encoder"])
    
    def use_semantic_set_initialization(self) -> bool:
        """
        Get whether to initialize set embeddings using BERT vectors from string cache.
        
        When True:
        - Set embeddings are initialized with semantic vectors (e.g., colors, sizes in order)
        - Out-of-vocabulary values at inference can use BERT projection instead of UNKNOWN
        - Faster convergence and better rare value handling
        
        Default: False (backward compatible)
        
        Requires string cache to be enabled during training.
        """
        return self._config.get("use_semantic_set_initialization", DEFAULT_CONFIG.get("use_semantic_set_initialization", False))
    
    def use_delimiter_preprocessing(self) -> bool:
        """
        Get whether to preprocess delimited strings before BERT encoding.
        
        When True:
        - Detect common delimiters (comma, semicolon, pipe, slash, tab) in string columns
        - Preprocess: "a,b,c" → "a\\nb\\nc" before BERT encoding
        - Results in better embeddings for multi-valued fields
        - Requires 30%+ of values to have delimiter to activate
        
        When False:
        - No delimiter detection or preprocessing
        - Strings are encoded by BERT as-is
        - DELIMITER strategy in adaptive encoder still learns when to trust BERT's raw encoding
        
        Default: False (conservative - no preprocessing)
        
        Note: Enabling this CHANGES string cache keys for columns with detected delimiters.
        Existing trained models with cached strings may need retraining.
        Only detects "safe" delimiters: , ; | / :: // \\t (not - or _ due to false positive risk)
        """
        return self._config.get("use_delimiter_preprocessing", DEFAULT_CONFIG.get("use_delimiter_preprocessing", False))
    
    def get_enable_spectral_norm_clipping(self) -> bool:
        """
        Get whether to enable spectral norm clipping during training.
        
        When True:
        - Spectral norms of layers exceeding the threshold are clipped
        - Helps stabilize training by preventing extreme weight values
        
        When False:
        - No spectral norm clipping is applied
        - Layers can have arbitrarily large spectral norms
        
        Default: True (for stability)
        
        Note: This can be disabled to allow more exploration during training,
        but may lead to instability in some cases.
        """
        return self._config.get("enable_spectral_norm_clipping", DEFAULT_CONFIG.get("enable_spectral_norm_clipping", True))
    
    def get_spectral_norm_clip_threshold(self) -> float:
        """
        Get the spectral norm clipping threshold.
        
        If spectral norm clipping is enabled, layers with spectral norms
        exceeding this threshold will be clipped down to this value.
        
        Default: 12.0
        
        Higher values allow larger weight magnitudes.
        Lower values enforce more conservative weight constraints.
        """
        return self._config.get("spectral_norm_clip_threshold", DEFAULT_CONFIG.get("spectral_norm_clip_threshold", 12.0))
    
    def get_adaptive_scalar_hidden_dim(self) -> int:
        """
        Get the hidden dimension size for AdaptiveScalarEncoder MLPs.
        
        Each strategy (linear, log, robust, rank, periodic) uses an MLP with this hidden size.
        Smaller values = faster training but potentially less expressive.
        
        Default: 16 (good balance of speed and quality)
        
        Common values:
        - 16: Fast, 4× faster than 64 (recommended for most use cases)
        - 32: Medium, 2× faster than 64 (good accuracy/speed tradeoff)
        - 64: Slow, most expressive (use if accuracy is critical)
        """
        return self._config.get("adaptive_scalar_hidden_dim", DEFAULT_CONFIG.get("adaptive_scalar_hidden_dim", 16))
    
    def get_string_server_host(self) -> Optional[str]:
        """
        Get the string server host configuration.
        
        Returns:
            "taco" - Use remote string server (tries taco.local first, then taco, then proxy)
            "taco.local" - Use remote string server directly at taco.local:9000
            "localhost" - Use local string server at localhost:9000
            None - Use local sentence transformer model (legacy behavior)
        
        Default: "taco.local" (uses remote string server)
        """
        return self._config.get("string_server_host", DEFAULT_CONFIG.get("string_server_host", "taco.local"))
    
    def get_enable_predictor_architecture_selection(self) -> bool:
        """
        Get whether to enable automatic predictor architecture selection during EmbeddingSpace training.
        
        When True:
        - The system will train multiple candidate predictor architectures for a few epochs
        - Selects the best architecture based on validation loss
        - Affects both column predictors and joint predictor
        - Only runs on fresh training (not when resuming from checkpoint)
        
        When False:
        - Uses default predictor architecture (no selection)
        - Faster training start (skips architecture selection phase)
        
        Default: False (DISABLED - architecture selection provides <1% improvement for 30+ epochs overhead)
        
        Note: Architecture selection adds ~15 epochs × 2-4 candidates = ~30-60 epochs of overhead
        before main training begins, but typically only shows <1% validation loss improvement.
        """
        return self._config.get("enable_predictor_architecture_selection", DEFAULT_CONFIG.get("enable_predictor_architecture_selection", False))
    
    def get_es_weight_initialization(self) -> str:
        """
        Get the embedding space weight initialization strategy.
        
        Options:
        - "random": Standard PyTorch initialization (default)
        - "pca_string": Initialize weights using PCA of string embeddings from sentence transformer
        
        Default: "random"
        
        The PCA initialization uses statistics from sentence transformer embeddings to set
        initial weight distributions. This can help with convergence but requires access
        to the string server for BERT embeddings.
        
        Can be overridden by FEATRIX_ES_WEIGHT_INIT environment variable for testing.
        """
        # Check environment variable first (for ablation testing)
        env_value = os.getenv("FEATRIX_ES_WEIGHT_INIT")
        if env_value in ("random", "pca_string"):
            return env_value
        return self._config.get("es_weight_initialization", DEFAULT_CONFIG.get("es_weight_initialization", "random"))
    
    def get_use_bf16(self) -> bool:
        """
        Get whether to use BF16 mixed precision training.
        
        When True:
        - Training uses BF16 (bfloat16) mixed precision on supported GPUs
        - Saves ~50% memory (activations stored in 16-bit instead of 32-bit)
        - Requires Ampere or newer GPU (RTX 30xx+, RTX 40xx, A100, H100)
        - Better numerical stability than FP16 (no GradScaler needed)
        - Similar or slightly faster than FP32
        
        When False:
        - Training uses FP32 (standard 32-bit floating point)
        - More memory usage but works on all GPUs
        
        Default: False (off, for compatibility)
        
        Note: If enabled on incompatible GPU, automatically falls back to FP32.
        Recommended for RTX 4090 and other Ampere+ GPUs when hitting memory limits.
        """
        return self._config.get("use_bf16", DEFAULT_CONFIG.get("use_bf16", False))
    
    def get_enable_predictor_attention(self) -> bool:
        """
        Get whether to enable attention mechanism in predictor MLPs.
        
        Can be set via:
        1. Environment variable: FEATRIX_ENABLE_PREDICTOR_ATTENTION=1 or 0 (highest priority)
        2. config.json: "enable_predictor_attention": true
        
        When True:
        - Predictor MLPs include multi-head self-attention layers between feedforward blocks
        - Allows the model to learn relationships between different embedding dimensions
        - Can improve performance on complex tasks by learning which dimensions to attend to
        - Adds computational overhead (~10-20% slower training)
        
        When False:
        - Predictor uses standard feedforward MLP (no attention)
        - Faster training, standard behavior
        
        Default: False (disabled, experimental feature)
        
        Note: This is an experimental feature. Enable to test if attention improves
        predictor performance on your specific tasks. Requires n_hidden_layers > 0 to have effect.
        """
        # Check environment variable first (highest priority)
        env_val = os.environ.get("FEATRIX_ENABLE_PREDICTOR_ATTENTION", "").strip()
        if env_val == "1":
            return True
        elif env_val == "0":
            return False
        # Fall back to config
        return self._config.get("enable_predictor_attention", DEFAULT_CONFIG.get("enable_predictor_attention", False))
    
    def get_predictor_attention_heads(self) -> int:
        """
        Get the number of attention heads for predictor attention mechanism.
        
        Only used when enable_predictor_attention=True.
        
        Default: 4
        
        Common values:
        - 2: Fewer parameters, faster training
        - 4: Good balance (default)
        - 8: More expressive, slower training
        """
        return self._config.get("predictor_attention_heads", DEFAULT_CONFIG.get("predictor_attention_heads", 4))
    
    def get_disable_curriculum_learning(self) -> bool:
        """
        Get whether to disable curriculum learning (loss weight scheduling).
        
        Can be set via:
        1. Environment variable: FEATRIX_DISABLE_CURRICULUM=1 (highest priority)
        2. config.json: "disable_curriculum_learning": true
        
        When True:
        - All loss weights (spread, marginal, joint) are fixed at 1.0 throughout training
        - No phase-based loss weighting or transitions
        - Useful for debugging or comparing with/without curriculum
        
        When False:
        - Uses the default 3-phase curriculum learning schedule:
          Phase 1 (0-30%): Spread focus (10:0.02:0.5)
          Phase 2 (30-85%): Reconstruction focus (1:0.25:2) - marginal+joint aligned
          Phase 3 (85-100%): Refinement (2:0.15:2)
        - Smooth cosine transitions between phases
        
        Default: False (curriculum learning enabled)
        """
        # Environment variable takes priority over config.json
        env_val = os.environ.get("FEATRIX_DISABLE_CURRICULUM", "").lower()
        if env_val in ("1", "true", "yes"):
            return True
        if env_val in ("0", "false", "no"):
            return False
        # Fall back to config.json
        return self._config.get("disable_curriculum_learning", DEFAULT_CONFIG.get("disable_curriculum_learning", False))
    
    def get_max_sp_epochs(self) -> int:
        """
        Get the maximum number of epochs for single predictor training.
        
        Can be set via:
        1. Environment variable: FEATRIX_MAX_SP_EPOCHS=<int> (highest priority)
        2. config.json: "max_sp_epochs": <int>
        
        When set to a positive integer:
        - Overrides the epochs parameter passed to training
        - Useful for quick I/O testing (e.g., set to 3 to test save/load quickly)
        
        When None or 0:
        - Use the epochs parameter from training args (default behavior)
        
        Default: None (use training args)
        """
        # Environment variable takes priority
        env_val = os.environ.get("FEATRIX_MAX_SP_EPOCHS", "").strip()
        if env_val:
            try:
                val = int(env_val)
                if val > 0:
                    return val
            except ValueError:
                pass
        # Fall back to config.json
        val = self._config.get("max_sp_epochs", DEFAULT_CONFIG.get("max_sp_epochs", None))
        if val and val > 0:
            return val
        return None
    
    def get_max_es_epochs(self) -> int:
        """
        Get the maximum number of epochs for embedding space training.
        
        Can be set via:
        1. Environment variable: FEATRIX_MAX_ES_EPOCHS=<int> (highest priority)
        2. config.json: "max_es_epochs": <int>
        
        When set to a positive integer:
        - Overrides the epochs parameter passed to training
        - Useful for quick I/O testing (e.g., set to 3 to test save/load quickly)
        
        When None or 0:
        - Use the epochs parameter from training args (default behavior)
        
        Default: None (use training args)
        """
        # Environment variable takes priority
        env_val = os.environ.get("FEATRIX_MAX_ES_EPOCHS", "").strip()
        if env_val:
            try:
                val = int(env_val)
                if val > 0:
                    return val
            except ValueError:
                pass
        # Fall back to config.json
        val = self._config.get("max_es_epochs", DEFAULT_CONFIG.get("max_es_epochs", None))
        if val and val > 0:
            return val
        return None
    
    def auto_compute_d_model(self, num_columns: int) -> int:
        """
        Auto-compute d_model based on number of columns (if not manually set).
        
        Tiers (multiples of 64):
        - < 10 columns:  64
        - < 30 columns:  128
        - < 60 columns:  192
        - >= 60 columns: 256
        
        Args:
            num_columns: Number of columns in dataset
        
        Returns:
            Recommended d_model
        """
        # Check if manually overridden in config
        if "d_model" in self._config:
            return self._config["d_model"]
        
        # Auto-compute based on tiers
        if num_columns < 10:
            return 64
        elif num_columns < 30:
            return 128
        elif num_columns < 60:
            return 192
        else:
            return 256
    
    def get_all(self) -> Dict[str, Any]:
        """Get all configuration as a dictionary."""
        return self._config.copy()
    
    def get_enable_embedding_diversity_loss(self) -> bool:
        """
        Get whether to enable embedding diversity loss during ES training.
        
        Can be set via:
        1. Environment variable: FEATRIX_ENABLE_EMBEDDING_DIVERSITY_LOSS=1 or 0 (highest priority)
        2. config.json: "enable_embedding_diversity_loss": true
        
        When True:
        - Adds a variance-based diversity loss to encourage embeddings to spread out
        - Helps prevent embedding collapse where all embeddings become similar
        - Loss penalizes low per-dimension variance across the batch
        
        When False:
        - Only uses standard losses (spread, joint, marginal)
        - No explicit diversity enforcement
        
        Default: True (ENABLED - critical for preventing global collapse)
        
        Background: Introduced to address embedding collapse issues where validation
        loss looked good but embeddings were compressed to a small region of space
        (e.g., alphafreight-mini with std/dim=0.0028). Spread loss prevents LOCAL
        collapse (within batch) but not GLOBAL collapse (across all batches).
        
        Note: This is essential for training stability. Only disable for ablation studies.
        """
        # Check environment variable first (highest priority)
        env_val = os.environ.get("FEATRIX_ENABLE_EMBEDDING_DIVERSITY_LOSS", "").strip()
        if env_val == "1":
            return True
        elif env_val == "0":
            return False
        # Fall back to config.json
        return self._config.get("enable_embedding_diversity_loss", DEFAULT_CONFIG.get("enable_embedding_diversity_loss", True))
    
    def get_embedding_diversity_weight(self) -> float:
        """
        Get the weight for embedding diversity loss (if enabled).
        
        Can be set via:
        1. Environment variable: FEATRIX_EMBEDDING_DIVERSITY_WEIGHT=<float> (highest priority)
        2. config.json: "embedding_diversity_weight": <float>
        
        This controls how strongly the diversity loss affects training.
        Typical values: 0.5-2.0
        - Too low (<0.5): diversity loss has minimal effect, collapse may still occur
        - Good range (0.5-2.0): balanced with other losses (spread, joint, marginal)
        - Too high (>2.0): may interfere with primary objectives
        
        Default: 1.0 (equal weight with spread_loss_weight)
        
        Rationale: Diversity loss prevents GLOBAL collapse (all batches in same region)
        while spread loss prevents LOCAL collapse (rows in same batch being identical).
        These are equally important failure modes, hence equal default weights.
        
        Only used if get_enable_embedding_diversity_loss() returns True.
        """
        # Check environment variable first (highest priority)
        env_val = os.environ.get("FEATRIX_EMBEDDING_DIVERSITY_WEIGHT", "").strip()
        if env_val:
            try:
                val = float(env_val)
                if val > 0:
                    return val
            except ValueError:
                pass
        # Fall back to config.json
        return self._config.get("embedding_diversity_weight", DEFAULT_CONFIG.get("embedding_diversity_weight", 1.0))

    def get_use_muon_optimizer(self) -> bool:
        """
        Get whether to use Muon optimizer instead of AdamW.

        Can be set via:
        1. Environment variable: FEATRIX_USE_MUON=1 or 0 (highest priority)
        2. config.json: "use_muon_optimizer": true

        When True:
        - Uses Muon optimizer (requires muon package to be installed)
        - Muon is a momentum-based optimizer designed for neural network training
        - May provide faster convergence on some tasks
        - Falls back to AdamW if muon package is not available

        When False:
        - Uses AdamW optimizer (default behavior)
        - Priority: 8-bit AdamW > Fused AdamW > Regular AdamW

        Default: False (use AdamW)

        Note: This is an experimental feature. Muon may not work well with all
        architectures or learning rate schedules. Test thoroughly before using in production.
        """
        # Check environment variable first (highest priority)
        env_val = os.environ.get("FEATRIX_USE_MUON", "").strip()
        if env_val in ("1", "true", "yes"):
            return True
        elif env_val in ("0", "false", "no"):
            return False
        # Fall back to config.json
        return self._config.get("use_muon_optimizer", DEFAULT_CONFIG.get("use_muon_optimizer", False))

    def get_enable_reconstruction_loss(self) -> bool:
        """
        Get whether to enable direct value reconstruction loss in marginal loss.

        Can be set via:
        1. Environment variable: FEATRIX_ENABLE_RECONSTRUCTION_LOSS=1 or 0 (highest priority)
        2. config.json: "enable_reconstruction_loss": true

        When True:
        - Adds a direct value prediction head to each column predictor
        - Scalars: MSE loss between predicted and actual normalized value
        - Sets/Categoricals: CrossEntropy loss between predicted class logits and actual class
        - This provides direct supervision to ensure embeddings preserve value information

        When False:
        - Only uses InfoNCE contrastive loss (default behavior)
        - Marginal loss only requires predictions to be "closer" to correct targets in batch

        Default: False (for ablation testing - enable explicitly to test)

        Rationale: Contrastive loss alone can lead to mode collapse where predictions
        always output the "average" embedding. Direct reconstruction forces the model
        to preserve actual value information in the embeddings.
        """
        env_val = os.environ.get("FEATRIX_ENABLE_RECONSTRUCTION_LOSS", "").strip()
        if env_val in ("1", "true", "yes"):
            return True
        elif env_val in ("0", "false", "no"):
            return False
        return self._config.get("enable_reconstruction_loss", DEFAULT_CONFIG.get("enable_reconstruction_loss", False))

    def get_reconstruction_loss_weight(self) -> float:
        """
        Get the weight for reconstruction loss (if enabled).

        Can be set via:
        1. Environment variable: FEATRIX_RECONSTRUCTION_LOSS_WEIGHT=<float> (highest priority)
        2. config.json: "reconstruction_loss_weight": <float>

        This controls how strongly the reconstruction loss affects training relative to InfoNCE.
        Typical values: 0.1-2.0
        - Too low (<0.1): reconstruction has minimal effect
        - Good range (0.5-2.0): balanced with contrastive loss
        - Too high (>2.0): may dominate and ignore contrastive structure

        Default: 1.0 (equal weight with InfoNCE loss)

        Only used if get_enable_reconstruction_loss() returns True.
        """
        env_val = os.environ.get("FEATRIX_RECONSTRUCTION_LOSS_WEIGHT", "").strip()
        if env_val:
            try:
                val = float(env_val)
                if val > 0:
                    return val
            except ValueError:
                pass
        return self._config.get("reconstruction_loss_weight", DEFAULT_CONFIG.get("reconstruction_loss_weight", 1.0))

    def log_config(self, prefix: str = ""):
        """
        Log all configuration parameters.

        Args:
            prefix: Optional prefix for log messages
        """
        logger.info(f"{prefix}🔧 Sphere Configuration:")
        for key, value in self._config.items():
            logger.info(f"{prefix}   {key}: {value}")


def get_d_model() -> int:
    """
    Convenience function to get d_model from configuration.
    
    Returns:
        d_model value (default: 128)
    
    Example:
        from featrix.neural.sphere_config import get_d_model
        
        d_model = get_d_model()  # Gets from config.json or uses default
    """
    return SphereConfig.get_instance().get_d_model()


def get_config() -> SphereConfig:
    """
    Convenience function to get the configuration instance.
    
    Returns:
        SphereConfig instance
    
    Example:
        from featrix.neural.sphere_config import get_config
        
        config = get_config()
        d_model = config.get_d_model()
        learning_rate = config.get("learning_rate", 0.001)
    """
    return SphereConfig.get_instance()


if __name__ == "__main__":
    # Demo usage
    print("Sphere Configuration Demo")
    print("=" * 60)
    
    config = get_config()
    config.log_config()
    
    print(f"\nGetting specific values:")
    print(f"  d_model: {config.get_d_model()}")
    print(f"  custom_key (default=42): {config.get('custom_key', 42)}")

