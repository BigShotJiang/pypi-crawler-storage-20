from typing import Annotated

from pydantic import BaseModel, Field, computed_field

from fluxly.core.utils.types import DatetimeReadable, TimedeltaReadable


class NodeMetadata(BaseModel):
    start_time: Annotated[DatetimeReadable, Field(description="Start datetime of the node execution.")] = None
    end_time: Annotated[DatetimeReadable, Field(description="End datetime of the node execution.")] = None

    @computed_field
    @property
    def process_time(self) -> TimedeltaReadable:
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return None

    def __str__(self) -> str:
        return self.model_dump_json(indent=2)

    def __repr__(self) -> str:
        return self.__str__()
