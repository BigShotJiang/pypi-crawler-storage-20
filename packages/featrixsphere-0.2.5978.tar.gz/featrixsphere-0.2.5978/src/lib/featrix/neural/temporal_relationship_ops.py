#  -*- coding: utf-8 -*-
#
#  Copyright Featrix, Inc 2023-2025
#
#  Proprietary and Confidential. Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
"""
Temporal Relationship Operations

Type-aware relationship operations for timestamp columns:
1. Timestamp × Timestamp: Compute temporal deltas (days apart, same dow, etc.)
2. String × Timestamp: Inject textual temporal representations (month names, day names)

These operations augment the generic embedding operations in DynamicRelationshipExtractor
with domain-specific temporal knowledge.
"""
import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List, Optional, Tuple

from featrix.neural.model_config import ColumnType

logger = logging.getLogger(__name__)

# Feature indices in timestamp token (from TimestampCodec._extract_features)
# [seconds, minutes, hours, day_of_month, day_of_week, month, year,
#  day_of_year, week_of_year, timezone, year_since_2000, year_since_2020]
FEAT_SECONDS = 0
FEAT_MINUTES = 1
FEAT_HOURS = 2
FEAT_DAY_OF_MONTH = 3
FEAT_DAY_OF_WEEK = 4
FEAT_MONTH = 5
FEAT_YEAR = 6
FEAT_DAY_OF_YEAR = 7
FEAT_WEEK_OF_YEAR = 8
FEAT_TIMEZONE = 9
FEAT_YEAR_SINCE_2000 = 10
FEAT_YEAR_SINCE_2020 = 11

# Textual representations for temporal features
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]
QUARTER_NAMES = ["Q1", "Q2", "Q3", "Q4"]
TIME_OF_DAY_NAMES = ["Night", "Morning", "Afternoon", "Evening"]  # 0-5, 6-11, 12-17, 18-23
SEASON_NAMES = ["Winter", "Spring", "Summer", "Fall"]  # Based on month
WEEKEND_NAMES = ["Weekday", "Weekend"]


class TemporalRelationshipOps(nn.Module):
    """
    Type-aware temporal relationship operations.

    For timestamp × timestamp pairs:
    - Computes raw temporal deltas (days, hours, etc.)
    - Computes cycle alignment (same dow, same month, etc.)
    - Projects through learned MLP to d_model

    For string × timestamp pairs:
    - Generates textual representations of temporal features
    - Uses shared text encoding to bridge string and timestamp semantics
    """

    def __init__(
        self,
        d_model: int,
        col_types: Dict[str, ColumnType],
        col_names_in_order: List[str],
        string_encoder_fn: Optional[callable] = None,
    ):
        """
        Args:
            d_model: Model dimension
            col_types: Dict mapping column name to ColumnType
            col_names_in_order: Ordered list of column names
            string_encoder_fn: Function to encode text strings (from StringEncoder)
        """
        super().__init__()
        self.d_model = d_model
        self.col_types = col_types
        self.col_names = col_names_in_order
        self.string_encoder_fn = string_encoder_fn

        # Build column index -> type mapping
        self.col_idx_to_type: Dict[int, ColumnType] = {}
        for idx, name in enumerate(col_names_in_order):
            self.col_idx_to_type[idx] = col_types.get(name, ColumnType.FREE_STRING)

        # Identify timestamp and string column indices
        self.timestamp_cols = [
            idx for idx, ctype in self.col_idx_to_type.items()
            if ctype == ColumnType.TIMESTAMP
        ]
        self.string_cols = [
            idx for idx, ctype in self.col_idx_to_type.items()
            if ctype == ColumnType.FREE_STRING
        ]

        # Count timestamp pairs
        n_ts_pairs = len(self.timestamp_cols) * (len(self.timestamp_cols) - 1) // 2
        n_str_ts_pairs = len(self.string_cols) * len(self.timestamp_cols)

        if n_ts_pairs > 0 or n_str_ts_pairs > 0:
            logger.info(f"🕐 TemporalRelationshipOps: {len(self.timestamp_cols)} timestamp cols, "
                       f"{len(self.string_cols)} string cols")
            logger.info(f"   Timestamp×Timestamp pairs: {n_ts_pairs}")
            logger.info(f"   String×Timestamp pairs: {n_str_ts_pairs}")

        # ============================================================================
        # Timestamp × Timestamp: Temporal delta features
        # ============================================================================
        # Input features:
        # - delta_days (signed)
        # - delta_hours (signed)
        # - abs_delta_days
        # - same_day_of_week (binary)
        # - same_month (binary)
        # - same_year (binary)
        # - same_week (binary)
        # - order (A before B = 1, same = 0, B before A = -1)
        self.n_temporal_delta_features = 8

        self.temporal_delta_mlp = nn.Sequential(
            nn.Linear(self.n_temporal_delta_features, d_model // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model // 2, d_model),
        )

        # ============================================================================
        # String × Timestamp: Textual temporal embeddings
        # ============================================================================
        # We'll create embeddings for temporal text tokens that can be compared
        # with string embeddings. These are learned embeddings, not from StringEncoder.
        # This is simpler and avoids dependency on StringEncoder at init time.

        # Embed day names (7 days)
        self.day_name_embeddings = nn.Embedding(7, d_model)
        # Embed month names (12 months)
        self.month_name_embeddings = nn.Embedding(12, d_model)
        # Embed quarter names (4 quarters)
        self.quarter_embeddings = nn.Embedding(4, d_model)
        # Embed time of day (4 periods)
        self.time_of_day_embeddings = nn.Embedding(4, d_model)
        # Embed weekend/weekday (2)
        self.weekend_embeddings = nn.Embedding(2, d_model)

        # MLP to combine string embedding with temporal text embeddings
        # Input: string_emb (d_model) + temporal_text_emb (d_model)
        self.string_timestamp_mlp = nn.Sequential(
            nn.Linear(d_model * 2, d_model),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(d_model, d_model),
        )

    def compute_timestamp_timestamp_features(
        self,
        raw_features_a: torch.Tensor,  # (batch, 12) raw timestamp features
        raw_features_b: torch.Tensor,  # (batch, 12) raw timestamp features
    ) -> torch.Tensor:
        """
        Compute temporal delta features between two timestamps.

        Args:
            raw_features_a: Raw 12-feature timestamp tensor for column A
            raw_features_b: Raw 12-feature timestamp tensor for column B

        Returns:
            Tensor of shape (batch, n_temporal_delta_features)
        """
        batch_size = raw_features_a.shape[0]
        device = raw_features_a.device

        # Extract relevant features
        year_a = raw_features_a[:, FEAT_YEAR]
        year_b = raw_features_b[:, FEAT_YEAR]
        doy_a = raw_features_a[:, FEAT_DAY_OF_YEAR]  # Day of year (1-366)
        doy_b = raw_features_b[:, FEAT_DAY_OF_YEAR]
        hour_a = raw_features_a[:, FEAT_HOURS]
        hour_b = raw_features_b[:, FEAT_HOURS]
        dow_a = raw_features_a[:, FEAT_DAY_OF_WEEK]
        dow_b = raw_features_b[:, FEAT_DAY_OF_WEEK]
        month_a = raw_features_a[:, FEAT_MONTH]
        month_b = raw_features_b[:, FEAT_MONTH]
        week_a = raw_features_a[:, FEAT_WEEK_OF_YEAR]
        week_b = raw_features_b[:, FEAT_WEEK_OF_YEAR]

        # Compute deltas
        # Approximate delta_days: (year_diff * 365) + (doy_diff)
        delta_days = (year_a - year_b) * 365 + (doy_a - doy_b)
        delta_hours = delta_days * 24 + (hour_a - hour_b)
        abs_delta_days = torch.abs(delta_days)

        # Cycle alignment (binary features)
        same_dow = (dow_a.round() == dow_b.round()).float()
        same_month = (month_a.round() == month_b.round()).float()
        same_year = (year_a.round() == year_b.round()).float()
        same_week = (week_a.round() == week_b.round()).float()

        # Temporal order: A before B = 1, same = 0, B before A = -1
        order = torch.sign(delta_days)

        # Normalize continuous features to reasonable range
        # Use log1p for large ranges, clamp for stability
        delta_days_norm = torch.sign(delta_days) * torch.log1p(torch.abs(delta_days))
        delta_hours_norm = torch.sign(delta_hours) * torch.log1p(torch.abs(delta_hours))
        abs_delta_days_norm = torch.log1p(abs_delta_days)

        # Stack all features
        features = torch.stack([
            delta_days_norm,
            delta_hours_norm,
            abs_delta_days_norm,
            same_dow,
            same_month,
            same_year,
            same_week,
            order,
        ], dim=1)  # (batch, 8)

        return features

    def compute_timestamp_timestamp_relationship(
        self,
        raw_features_a: torch.Tensor,
        raw_features_b: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute relationship token for timestamp × timestamp pair.

        Args:
            raw_features_a: Raw 12-feature timestamp tensor for column A
            raw_features_b: Raw 12-feature timestamp tensor for column B

        Returns:
            Relationship embedding of shape (batch, d_model)
        """
        features = self.compute_timestamp_timestamp_features(raw_features_a, raw_features_b)
        return self.temporal_delta_mlp(features)

    def get_temporal_text_embeddings(
        self,
        raw_features: torch.Tensor,  # (batch, 12) raw timestamp features
    ) -> Dict[str, torch.Tensor]:
        """
        Get textual temporal embeddings for timestamp features.

        Args:
            raw_features: Raw 12-feature timestamp tensor

        Returns:
            Dict with keys: 'day_name', 'month_name', 'quarter', 'time_of_day', 'weekend'
            Each value is (batch, d_model) embedding
        """
        batch_size = raw_features.shape[0]
        device = raw_features.device

        # Extract and convert to indices
        dow = raw_features[:, FEAT_DAY_OF_WEEK].round().long().clamp(0, 6)
        month = (raw_features[:, FEAT_MONTH].round().long() - 1).clamp(0, 11)  # 1-12 -> 0-11
        hour = raw_features[:, FEAT_HOURS].round().long().clamp(0, 23)

        # Quarter from month (0-2 -> Q1, 3-5 -> Q2, etc.)
        quarter = (month // 3).clamp(0, 3)

        # Time of day from hour (0-5 -> Night, 6-11 -> Morning, etc.)
        time_of_day = (hour // 6).clamp(0, 3)

        # Weekend from day of week (5, 6 = weekend)
        is_weekend = (dow >= 5).long()

        return {
            'day_name': self.day_name_embeddings(dow),
            'month_name': self.month_name_embeddings(month),
            'quarter': self.quarter_embeddings(quarter),
            'time_of_day': self.time_of_day_embeddings(time_of_day),
            'weekend': self.weekend_embeddings(is_weekend),
        }

    def compute_string_timestamp_relationship(
        self,
        string_embedding: torch.Tensor,  # (batch, d_model) from StringEncoder
        raw_timestamp_features: torch.Tensor,  # (batch, 12) raw timestamp features
        temporal_aspect: str = 'all',  # 'day_name', 'month_name', 'quarter', 'time_of_day', 'weekend', or 'all'
    ) -> torch.Tensor:
        """
        Compute relationship token for string × timestamp pair.

        This bridges the semantic gap by comparing the string embedding
        with textual representations of the timestamp's temporal features.

        Args:
            string_embedding: Embedding from StringEncoder
            raw_timestamp_features: Raw 12-feature timestamp tensor
            temporal_aspect: Which temporal text to use

        Returns:
            Relationship embedding of shape (batch, d_model)
        """
        temporal_embs = self.get_temporal_text_embeddings(raw_timestamp_features)

        if temporal_aspect == 'all':
            # Combine all temporal text embeddings (mean pool)
            all_embs = torch.stack(list(temporal_embs.values()), dim=0)  # (5, batch, d_model)
            temporal_text_emb = all_embs.mean(dim=0)  # (batch, d_model)
        else:
            temporal_text_emb = temporal_embs.get(temporal_aspect, temporal_embs['day_name'])

        # Concatenate string embedding with temporal text embedding
        combined = torch.cat([string_embedding, temporal_text_emb], dim=-1)  # (batch, d_model * 2)
        return self.string_timestamp_mlp(combined)

    def is_timestamp_pair(self, col_i: int, col_j: int) -> bool:
        """Check if both columns are timestamps."""
        return (
            self.col_idx_to_type.get(col_i) == ColumnType.TIMESTAMP and
            self.col_idx_to_type.get(col_j) == ColumnType.TIMESTAMP
        )

    def is_string_timestamp_pair(self, col_i: int, col_j: int) -> Tuple[bool, Optional[int], Optional[int]]:
        """
        Check if one column is string and other is timestamp.

        Returns:
            (is_str_ts_pair, string_col_idx, timestamp_col_idx)
        """
        type_i = self.col_idx_to_type.get(col_i)
        type_j = self.col_idx_to_type.get(col_j)

        if type_i == ColumnType.FREE_STRING and type_j == ColumnType.TIMESTAMP:
            return True, col_i, col_j
        elif type_i == ColumnType.TIMESTAMP and type_j == ColumnType.FREE_STRING:
            return True, col_j, col_i
        else:
            return False, None, None
