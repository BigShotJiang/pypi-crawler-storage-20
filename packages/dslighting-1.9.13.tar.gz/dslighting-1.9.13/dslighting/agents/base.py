"""
DSLighting Core Agent Protocol

This module defines the core protocols for DSLighting 2.0:
- Action: Agent action representation
- Context: Unified context assembling all components
- BaseAgent: Protocol for agent implementation

Design Principles:
- Minimal core: Only 3 concepts
- Tool-based: Any innovation can be encapsulated as a Tool
- Backward compatible: 100% compatible with existing code
"""

from typing import Protocol, Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class Action:
    """
    Agent Action

    Represents an action taken by an agent, which is essentially
    a tool call with arguments.

    Attributes:
        tool: Name of the tool to call
        args: Arguments to pass to the tool

    Example:
        >>> action = Action(tool="train_model", args={"algorithm": "xgboost"})
        >>> action.tool
        'train_model'
        >>> action.args
        {'algorithm': 'xgboost'}
    """

    tool: str
    args: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"Action(tool={self.tool!r}, args={self.args!r})"


class Context:
    """
    Agent Context

    A unified context that assembles all bottom-layer components
    and provides them to the agent.

    The context includes:
    - Task information and data
    - Tools (built-in and custom)
    - Services (sandbox, LLM, file I/O, evaluator)
    - Agent state

    Example:
        >>> from dslighting import load_data
        >>> from dslighting.agents import Context
        >>>
        >>> data = load_data("bike-sharing-demand")
        >>> ctx = Context(
        ...     task="bike-sharing-demand",
        ...     data=data,
        ...     tools={},
        ...     sandbox=sandbox,
        ...     llm=llm_service
        ... )
        >>> ctx.task
        'bike-sharing-demand'
    """

    def __init__(
        self,
        task: str,
        data: Any,
        tools: Dict[str, 'Tool'],
        sandbox: Optional[Any] = None,
        llm: Optional[Any] = None,
        file_io: Optional[Any] = None,
        evaluator: Optional[Any] = None
    ):
        """
        Initialize Context

        Args:
            task: Task description or task ID
            data: Data loaded by DataLoader
            tools: Dictionary of available tools
            sandbox: Sandbox execution environment (optional)
            llm: LLM service (optional)
            file_io: File I/O service (optional)
            evaluator: Evaluator service (optional)
        """
        self.task = task
        self.data = data
        self.tools = tools
        self.sandbox = sandbox
        self.llm = llm
        self.file_io = file_io
        self.evaluator = evaluator

        # Agent state (can be modified by agent during execution)
        self.state: Dict[str, Any] = {}

    def register_tool(self, tool: 'Tool') -> None:
        """
        Register a new tool

        Args:
            tool: Tool instance to register

        Example:
            >>> from dslighting.tools import Tool
            >>>
            >>> my_tool = Tool(
            ...     name="my_tool",
            ...     description="My custom tool",
            ...     fn=lambda x: x * 2
            ... )
            >>> ctx.register_tool(my_tool)
            >>> "my_tool" in ctx.tools
            True
        """
        self.tools[tool.name] = tool

    def get_tool(self, name: str) -> Optional['Tool']:
        """
        Get a tool by name

        Args:
            name: Tool name

        Returns:
            Tool if found, None otherwise
        """
        return self.tools.get(name)

    def __repr__(self) -> str:
        return (
            f"Context(task={self.task!r}, "
            f"data_type={type(self.data).__name__}, "
            f"num_tools={len(self.tools)})"
        )


class BaseAgent(Protocol):
    """
    Agent Protocol

    Defines the interface that all agents must implement.
    An agent only needs to implement the plan() method.

    This is a Protocol (structural subtyping), so any class
    with a plan() method is automatically a BaseAgent.

    Example:
        >>> from dslighting.agents import BaseAgent, Context, Action
        >>>
        >>> class MyAgent:
        ...     def plan(self, ctx: Context) -> Action:
        ...         # Simple planning logic
        ...         return Action(tool="analyze", args={})
        >>>
        >>> agent = MyAgent()
        >>> ctx = Context(task="test", data=None, tools={})
        >>> action = agent.plan(ctx)
        >>> isinstance(action, Action)
        True
    """

    def plan(self, ctx: Context) -> Action:
        """
        Plan method: Given context, return action

        This is the core decision-making method of an agent.
        It should analyze the context and decide what action to take.

        Args:
            ctx: Current context with data, tools, and services

        Returns:
            Action to take

        Example:
            >>> def plan(self, ctx: Context) -> Action:
            ...     # Analyze task
            ...     if "classification" in ctx.task:
            ...         return Action(tool="train_classifier", args={})
            ...     else:
            ...         return Action(tool="train_regressor", args={})
        """
        raise NotImplementedError("Agent must implement plan() method")


# Backward compatibility: Import existing Agent from dslighting
# This ensures existing code continues to work
try:
    from dslighting import Agent as OldAgent
    _HAS_OLD_AGENT = True
except ImportError:
    _HAS_OLD_AGENT = False

__all__ = ["Action", "Context", "BaseAgent"]
