"""DocWrite: README.md # PyHardLinkBackup
    HardLink/Deduplication Backups with Python
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '1.6.0'
__author__ = 'Jens Diemer <PyHardLinkBackup@jensdiemer.de>'
