import argparse
def main():
    parser = argparse.ArgumentParser(description="Goblin")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--static")
    args = parser.parse_args()
    from .server import run_server
    run_server(host=args.host, port=args.port, static_dir=args.static)
if __name__ == "__main__": main()
