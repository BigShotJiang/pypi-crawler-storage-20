from typing import Any

from pydantic import ValidationError

from .errors import IonworksError
from .models import (
    CellInstance,
    CellInstanceDetail,
    CellSpecificationInstances,
    CellSpecificationInstancesWithSteps,
)


class CellInstanceClient:
    def __init__(self, client: Any):
        self.client = client

    def get(self, cell_instance_id: str) -> CellInstance:
        """
        Get a specific cell instance by ID.
        """
        endpoint = f"/cell_instances/{cell_instance_id}"
        try:
            response_data = self.client.get(endpoint)
            # Validate and parse the response
            return CellInstance(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid response format from {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def get_by_slug(self, cell_instance_slug: str) -> CellInstance:
        """
        Get a specific cell instance by slug.
        """
        endpoint = f"/cell_instances/slug/{cell_instance_slug}"
        try:
            response_data = self.client.get(endpoint)
            return CellInstance(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid response format from {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def list(self, cell_spec_id: str) -> list[CellInstance]:
        """
        List all cell instances for a cell specification by specification ID.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}/cell_instances"
        try:
            response_data = self.client.get(endpoint)
            if not isinstance(response_data, list):
                raise ValueError(
                    f"Unexpected response format from {endpoint}: expected a list, "
                    f"got {type(response_data).__name__}"
                )
            # Validate each item in the list
            return [CellInstance(**item) for item in response_data]
        except ValidationError as e:
            raise ValueError(f"Invalid item format in list from {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    # def list_with_steps(
    #     self, cell_instance_slug: str
    # ) -> list[CellMeasurementDetailBase]:
    #     """
    #     List all cell measurements for a cell instance with steps.
    #     """
    #     endpoint = (
    #         f"/cell_instances/{cell_instance_slug}/cell_measurements/with-steps"
    #     )
    #     response_data = self.client.get(endpoint)
    #     return [CellMeasurementDetailBase(**item) for item in response_data]

    def update(self, cell_instance_id: str, data: dict[str, Any]) -> CellInstance:
        """
        Update an existing cell instance.

        Parameters
        ----------
        cell_instance_id : str
            The ID of the cell instance to update.
        data : dict
            Dictionary containing the fields to update.

        Returns
        -------
        CellInstance
            The updated cell instance.
        """
        endpoint = f"/cell_instances/{cell_instance_id}"
        response_data = self.client.put(endpoint, data)
        return CellInstance(**response_data)

    def delete(self, cell_instance_id: str) -> None:
        """
        Delete a cell instance by ID.
        """
        endpoint = f"/cell_instances/{cell_instance_id}"
        self.client.delete(endpoint)

    # Renamed and moved method from Data class
    def detail(self, cell_instance_id: str) -> CellInstanceDetail:
        """
        Loads the full details for a cell instance from a single API endpoint,
        including its spec, instance data, steps DataFrame, and time series DataFrame.
        Uses the /detail endpoint.

        Args:
            organization: The organization slug.
            cell_instance_id: The cell instance ID.

        Returns:
            A FullCellInstance object containing validated data.

        Raises:
            RuntimeError: If the API call fails.
            ValueError: If the API response format is unexpected or parsing fails.
            ValidationError: If the response data doesn't match expected models.
        """
        endpoint = f"/cell_instances/{cell_instance_id}/detail"
        try:
            response_data = self.client.get(endpoint)
            return CellInstanceDetail(**response_data)

        except ValidationError as e:
            # Pydantic validation error during parsing
            raise ValueError(f"Response validation failed for {endpoint}: {e}") from e
        except ValueError as e:
            # Re-raise our explicit format validation errors
            raise e
        except Exception as e:
            # Catch client errors or any other unexpected issues
            raise RuntimeError(
                f"API call to {endpoint} failed or data processing error: {e}"
            ) from e

    def create(self, cell_spec_id: str, data: dict[str, Any]) -> CellInstance:
        """
        Create a new cell instance under a cell specification by
        specification ID.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}/cell_instances"
        response_data = self.client.post(endpoint, data)
        return CellInstance(**response_data)

    def create_or_get(self, cell_spec_id: str, data: dict[str, Any]) -> CellInstance:
        """
        Create a new cell instance if it doesn't exist, otherwise get the
        existing one.
        """
        try:
            return self.create(cell_spec_id, data)
        except IonworksError as e:
            if e.status_code == 409 and e.data is not None:
                existing_id = e.data.get("existing_cell_instance_id")
                if existing_id:
                    return self.get(existing_id)
            raise e

    def list_with_measurements(self, cell_spec_id: str) -> CellSpecificationInstances:
        """
        List all instances and measurements for a cell specification.
        Returns normalized data: separate lists for specification, instances, and
        measurements.
        """
        endpoint = (
            f"/cell_specifications/{cell_spec_id}/cell_instances/with-measurements"
        )
        try:
            response_data = self.client.get(endpoint)
            return CellSpecificationInstances(**response_data)
        except ValidationError as e:
            raise ValueError(f"Response validation failed for {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def list_with_measurements_and_steps(
        self, cell_spec_id: str
    ) -> CellSpecificationInstancesWithSteps:
        """
        List all instances, measurements, and steps for a cell specification.
        Returns normalized data: separate lists for specification, instances,
        measurements, and steps.
        """
        endpoint = (
            f"/cell_specifications/{cell_spec_id}/cell_instances"
            "/with-measurements-and-steps"
        )
        try:
            response_data = self.client.get(endpoint)
            return CellSpecificationInstancesWithSteps(**response_data)
        except ValidationError as e:
            raise ValueError(f"Response validation failed for {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e


class CellMeasurementClient:
    pass
