from typing import Any


class IonworksError(Exception):
    """Custom exception for Ionworks API errors.

    Attributes
    ----------
    message : str
        A string description of the error
    data : dict[str, Any] | None
        Structured error data if available (e.g., from API error response)
    status_code : int | None
        HTTP status code if applicable
    """

    def __init__(
        self,
        message: str | dict[str, Any],
        status_code: int | None = None,
    ):
        self.status_code = status_code

        # Parse message into string and optional data dict
        if isinstance(message, dict):
            self.message = message.get("message", str(message))
            self.data: dict[str, Any] | None = message
        else:
            self.message = message
            self.data = None

        super().__init__(self.message)

    def __str__(self):
        return f"error code: {self.status_code}, message: {self.message}"
