from typing import Any

from pydantic import ValidationError

from ionworks.errors import IonworksError

from .models import CellSpecification


class CellSpecificationClient:
    def __init__(self, client: Any):
        self.client = client

    def get(self, cell_spec_id: str) -> CellSpecification:
        """
        Get a specific cell specification by ID.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}"
        try:
            response_data = self.client.get(endpoint)
            # Validate and parse the response
            return CellSpecification(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid response format from {endpoint}: {e}") from e
        except Exception as e:  # Catch potential client errors
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def list(self) -> list[CellSpecification]:
        """
        List all cell specs.
        """
        endpoint = "/cell_specifications"
        try:
            response_data = self.client.get(endpoint)
            if not isinstance(response_data, list):
                raise ValueError(
                    f"Unexpected response format from {endpoint}: expected a list, "
                    f"got {type(response_data).__name__}"
                )
            # Validate each item in the list
            return [CellSpecification(**item) for item in response_data]
        except ValidationError as e:
            raise ValueError(f"Invalid item format in list from {endpoint}: {e}") from e
        except Exception as e:  # Catch potential client errors
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e

    def create(self, data: dict[str, Any]) -> CellSpecification:
        """
        Create a new cell spec.
        """
        endpoint = "/cell_specifications"
        response_data = self.client.post(endpoint, data)
        return CellSpecification(**response_data)

    def create_or_get(self, data: dict[str, Any]) -> CellSpecification:
        """
        Create a new cell spec if it doesn't exist, otherwise get the
        existing one.
        """
        try:
            return self.create(data)
        except IonworksError as e:
            if e.status_code == 409 and e.data is not None:
                existing_id = e.data.get("existing_cell_specification_id")
                if existing_id:
                    return self.get(existing_id)
            raise e

    def update(self, cell_spec_id: str, data: dict[str, Any]) -> CellSpecification:
        """
        Update an existing cell specification.

        Parameters
        ----------
        cell_spec_id : str
            The ID of the cell specification to update.
        data : dict
            Dictionary containing the fields to update. Supports nested
            component/material data for upsert.

        Returns
        -------
        CellSpecification
            The updated cell specification.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}"
        response_data = self.client.put(endpoint, data)
        return CellSpecification(**response_data)

    def delete(self, cell_spec_id: str) -> None:
        """
        Delete a cell specification by ID.
        """
        endpoint = f"/cell_specifications/{cell_spec_id}"
        self.client.delete(endpoint)

    def get_by_slug(self, cell_spec_slug: str) -> CellSpecification:
        """
        Get a specific cell specification by slug.
        """
        endpoint = f"/cell_specifications/slug/{cell_spec_slug}"
        try:
            response_data = self.client.get(endpoint)
            return CellSpecification(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid response format from {endpoint}: {e}") from e
        except Exception as e:
            raise RuntimeError(f"API call to {endpoint} failed: {e}") from e
