import os
from typing import Any, cast

from dotenv import load_dotenv
import requests

from .cell_instance import CellInstanceClient
from .cell_measurement import CellMeasurementClient
from .cell_specification import CellSpecificationClient
from .errors import IonworksError
from .job import JobClient
from .pipeline import PipelineClient
from .simulation import SimulationClient


class Ionworks:
    def __init__(self, api_key: str | None = None, api_url: str | None = None):
        """Initialize Ionworks client.

        Parameters
        ----------
        api_key : str, optional
            API key. If not provided, will look for IONWORKS_API_KEY env var
        api_url : str, optional
            API URL. If not provided, will look for IONWORKS_API_URL env var
        """
        load_dotenv()

        self.api_key = api_key or os.getenv("IONWORKS_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key must be provided either as argument or in IONWORKS_API_KEY "
                "environment variable"
            )

        self.api_url = (
            api_url or os.getenv("IONWORKS_API_URL") or "https://api.ionworks.com"
        )

        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
            }
        )

        # Initialize components
        self.job = JobClient(self)
        self.pipeline = PipelineClient(self)
        self.cell_spec = CellSpecificationClient(self)
        self.cell_instance = CellInstanceClient(self)
        self.cell_measurement = CellMeasurementClient(self)
        self.simulation = SimulationClient(self)
        # Backwards-compatible alias
        self.measurement = self.cell_measurement

    def request(
        self, method: str, endpoint: str, json_payload: dict[str, Any] | None = None
    ) -> Any:
        """Make a request to the Ionworks API with standardized error handling."""
        url = f"{self.api_url}{endpoint}"
        try:
            response = self.session.request(method, url, json=json_payload)
            response.raise_for_status()

            # For DELETE operations, don't try to parse JSON if response is empty
            if method.upper() == "DELETE":
                return None

            # Return JSON response if content type is JSON and response has content
            if (
                response.headers.get("Content-Type") == "application/json"
                and response.text
            ):
                return response.json()
            return response
        except requests.exceptions.HTTPError as e:
            try:
                error_detail = e.response.json().get("detail", str(e))
            except requests.exceptions.JSONDecodeError:
                error_detail = str(e)
            # Raise the custom error with just the detail message
            raise IonworksError(
                error_detail, status_code=e.response.status_code
            ) from None
        except requests.exceptions.RequestException as e:
            # Extract more detailed error information
            error_msg = f"Error during request to {url}"
            if hasattr(e, "response") and e.response is not None:
                error_msg += f" (status code: {e.response.status_code})"
                try:
                    error_detail = e.response.json().get("detail", e.response.text)
                    error_msg += f": {error_detail}"
                except requests.exceptions.JSONDecodeError:
                    error_msg += f": {e.response.text}"
            else:
                error_msg += f": {str(e)}"
            # Raise the custom error for general request issues
            raise IonworksError(error_msg) from None

    def get(self, endpoint: str) -> Any:
        """Make a GET request using the request helper."""
        return self.request("GET", endpoint)

    def post(self, endpoint: str, json_payload: dict[str, Any]) -> Any:
        """Make a POST request using the request helper."""
        return self.request("POST", endpoint, json_payload=json_payload)

    def put(self, endpoint: str, json_payload: dict[str, Any]) -> Any:
        """Make a PUT request using the request helper."""
        return self.request("PUT", endpoint, json_payload=json_payload)

    def delete(self, endpoint: str) -> None:
        """Make a DELETE request using the request helper."""
        self.request("DELETE", endpoint)

    def health_check(self) -> dict[str, Any]:
        """Check the health of the Ionworks API.

        Returns:
            dict[str, Any]: Health check response
        """
        response_data = self.get("/healthz")
        return cast(dict[str, Any], response_data)
