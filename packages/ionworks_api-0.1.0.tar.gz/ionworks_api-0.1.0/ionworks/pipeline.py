import os
import re
from typing import Any

from pydantic import (
    BaseModel,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

from .errors import IonworksError
from .validators import run_validators_outbound


def _prepare_payload(data: Any) -> Any:
    """Prepare payload for API submission using outbound validators pipeline."""
    return run_validators_outbound(data)


class DataFitConfig(BaseModel):
    objectives: dict[str, Any]
    parameters: dict[str, Any]
    cost: dict[str, Any] | None = None
    optimizer: dict[str, Any] | None = None
    existing_parameters: dict[str, Any] | None = None


class EntryConfig(BaseModel):
    values: dict[str, Any]


class BuiltInEntryConfig(BaseModel):
    name: str


class CalculationConfig(BaseModel):
    calculation: str
    electrode: str | None = None
    method: str | None = None
    existing_parameters: dict[str, Any] | None = None


class ValidationConfig(BaseModel):
    objectives: dict[str, Any]
    summary_stats: list[Any]
    existing_parameters: dict[str, Any] | None = None


class PipelineConfig(BaseModel):
    project_id: str | None = Field(
        default=None,
        description="The project id to submit the pipeline to. "
        "Can be found in the project settings page. "
        "If not provided, will use PROJECT_ID environment variable.",
    )
    elements: dict[str, Any] = Field(
        description="Dictionary of elements defining the pipeline. The key is the name "
        "of the element and the value is the configuration of the element. "
    )
    name: str | None = Field(default=None, description="The name of the pipeline.")
    description: str | None = Field(
        default=None, description="The description of the pipeline."
    )
    options: dict[str, Any] | None = Field(
        default=None,
        description="Dictionary of options for the pipeline. "
        "Options are used to configure the pipeline behavior. "
        "Available options are: "
        "live_progress_updates: bool ",
    )

    @field_validator("elements", mode="before")
    @classmethod
    def validate_elements_format(cls, v: Any) -> dict[str, Any]:
        """Validate that elements is a dict, not the old list format."""
        if isinstance(v, list):
            raise ValueError(
                "Pipeline elements must be provided as a dictionary, not a list. "
                "The format has changed from:\n"
                '  "elements": [{"name": {...}}, ...]\n'
                "to:\n"
                '  "elements": {"name": {...}, ...}\n'
                "Please update your pipeline configuration."
            )
        if not isinstance(v, dict):
            raise ValueError(
                f"Pipeline elements must be a dictionary, got {type(v).__name__}"
            )
        return v

    @model_validator(mode="after")
    def set_defaults(self) -> "PipelineConfig":
        """Set project_id from environment variable if not provided and defaults."""
        if self.project_id is None:
            env_project_id = os.getenv("PROJECT_ID")
            if env_project_id is None:
                raise ValueError(
                    "project_id is required. Either provide it in the config "
                    "or set the PROJECT_ID environment variable."
                )
            self.project_id = env_project_id
        # Ensure options is never None to avoid 422 errors
        if self.options is None:
            self.options = {}
        return self


class DataFitResponse(BaseModel):
    parameter_values: dict[str, Any]


class CalculationResponse(BaseModel):
    parameter_values: dict[str, Any]


class ValidationResponse(BaseModel):
    validation_results: dict[str, Any]
    summary_stats: dict[str, list[Any]]


class EntryResponse(BaseModel):
    parameter_values: dict[str, Any]


class PipelineSubmissionResponse(BaseModel):
    id: str
    name: str
    description: str | None = None
    status: str
    error: str | None = None


class PipelineResponse(BaseModel):
    result: dict[str, Any]
    element_results: dict[str, Any]


class PipelineClient:
    def __init__(self, client: Any):
        self.client = client

    def create(self, config: dict[str, Any]) -> PipelineSubmissionResponse:
        """Run a complete pipeline with the given configuration.

        Parameters
        ----------
        config : dict[str, Any]
            Dictionary containing configuration for the pipeline.

        Returns
        -------
        PipelineSubmissionResponse
            The pipeline submission response.

        Raises
        ------
        ValueError
            If the configuration is invalid.
        """
        try:
            validated_config = PipelineConfig(**config)
            payload = _prepare_payload(validated_config.model_dump())
            response_data = self.client.post("/pipelines", payload)
            return PipelineSubmissionResponse(**response_data)
        except ValidationError as e:
            raise ValueError(f"Invalid pipeline configuration: {e}") from e
        except IonworksError as e:
            error_msg = str(e.message)
            # Check for invalid UUID format in project_id
            uuid_match = re.search(
                r'invalid input syntax for type uuid: "([^"]*)"', error_msg
            )
            if uuid_match:
                invalid_id = uuid_match.group(1)
                raise ValueError(
                    f"Invalid project_id format: '{invalid_id}' is not a valid UUID. "
                    "Please provide a valid project ID from your project settings page."
                ) from e
            # Check for row-level security policy violation (project not accessible)
            if "violates row-level security policy" in error_msg:
                project_id = validated_config.project_id
                raise ValueError(
                    f"Access denied: The project '{project_id}' is not accessible "
                    "with your API key. Please verify that your API key has access "
                    "to this project."
                ) from e
            # Re-raise original error for other cases
            raise

    def list(self, project_id: str | None = None) -> list[PipelineSubmissionResponse]:
        """List all pipelines.

        Parameters
        ----------
        project_id : str, optional
            The project id to filter pipelines. If not provided, will use
            PROJECT_ID environment variable.

        Returns
        -------
        list[PipelineSubmissionResponse]
            List of pipeline submission responses.
        """
        if project_id is None:
            project_id = os.getenv("PROJECT_ID")
            if project_id is None:
                raise ValueError(
                    "project_id is required. Either provide it as an argument "
                    "or set the PROJECT_ID environment variable."
                )

        endpoint = f"/pipelines?project_id={project_id}"
        try:
            response_data = self.client.get(endpoint)
            if not isinstance(response_data, list):
                raise ValueError(
                    f"Unexpected response format from {endpoint}: expected a list, "
                    f"got {type(response_data).__name__}"
                )
            return [PipelineSubmissionResponse(**item) for item in response_data]
        except ValidationError as e:
            raise ValueError(f"Invalid item format in list from {endpoint}: {e}") from e

    def get(self, job_id: str) -> PipelineSubmissionResponse:
        """Get the pipeline response for the given job id.

        Parameters
        ----------
        job_id : str
            The job id.

        Returns
        -------
        PipelineSubmissionResponse
            The pipeline submission response.
        """
        response_data = self.client.get(f"/pipelines/{job_id}")
        return PipelineSubmissionResponse(**response_data)

    def result(self, job_id: str) -> PipelineResponse:
        """Get the result for the given job id.

        Parameters
        ----------
        job_id : str
            The job id.

        Returns
        -------
        PipelineResponse
            The pipeline results.
        """
        response_data = self.client.get(f"/pipelines/{job_id}/result")
        return PipelineResponse(**response_data)
