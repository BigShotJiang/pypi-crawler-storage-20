from typing import Any, Optional

from pydantic import BaseModel, ValidationError


# Model for the data required to create ANY job
class JobCreationPayload(BaseModel):
    job_type: str
    params: dict[str, Any]
    priority: int = 5  # Default priority
    callback_url: Optional[str] = None  # Optional callback


# Model for the detailed job response
class JobResponse(BaseModel):
    job_id: str
    status: str
    job_type: str
    params: dict[str, Any]
    priority: int
    created_at: str
    updated_at: str
    metadata: Optional[dict[str, Any]]
    error: Optional[str]
    result: Optional[dict[str, Any]]


class JobClient:
    def __init__(self, client: Any):
        self.client = client

    def create(self, payload: JobCreationPayload) -> JobResponse:
        """
        Submit a job using the provided payload.

        Parameters
        ----------
        payload : JobCreationPayload
            The configuration for the job to be created.

        Returns
        -------
        JobResponse
            Response containing the job_id and initial status.

        Raises
        ------
        requests.exceptions.RequestException
            If the API request fails.
        ValueError
            If the response parsing fails.
        """
        endpoint = "/jobs/"
        try:
            response_data = self.client.post(
                endpoint, json_payload=payload.model_dump(exclude_none=True)
            )
            # Pydantic validation is applied here
            return JobResponse(**response_data)
        except ValidationError as e:
            # Catch Pydantic validation errors specifically
            raise ValueError(
                f"Invalid response format received from {endpoint}: {e}"
            ) from e
        # RequestExceptions (including HTTPError) are handled by client._post

    def get(self, job_id: str) -> JobResponse:
        """
        Get the status and details of a specific job.
        """
        endpoint = f"/jobs/{job_id}"
        try:
            response_data = self.client.get(endpoint)
            return JobResponse(**response_data)
        except ValidationError as e:
            raise ValueError(
                f"Invalid response format received from {endpoint}: {e}"
            ) from e

    def list(self) -> list[JobResponse]:
        """
        List all jobs.
        """
        endpoint = "/jobs/"
        try:
            response_data = self.client.get(endpoint)
            # Ensure response_data is a list before list comprehension
            if not isinstance(response_data, list):
                raise ValueError(
                    f"Unexpected response format from {endpoint}: expected a list, "
                    "got {type(response_data).__name__}"
                )
            # Apply validation within list comprehension
            return [JobResponse(**job) for job in response_data]
        except ValidationError as e:
            raise ValueError(
                f"Invalid job data format received from {endpoint}: {e}"
            ) from e

    def cancel(self, job_id: str) -> JobResponse:
        """
        Cancel a job.
        """
        endpoint = f"/jobs/{job_id}/cancel"
        try:
            response_data = self.client.post(endpoint, json_payload={})
            return JobResponse(**response_data)
        except ValidationError as e:
            raise ValueError(
                f"Invalid response format received from {endpoint}: {e}"
            ) from e
