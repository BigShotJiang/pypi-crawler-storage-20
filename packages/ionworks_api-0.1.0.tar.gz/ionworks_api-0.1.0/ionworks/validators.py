"""
Reusable validator functions and composable pipelines for inbound/outbound value
normalization (e.g., converting between pandas DataFrames and dictionaries).
"""

import math
import pathlib
from typing import Any, Callable, Iterable

import numpy as np
import pandas as pd
import polars as pl
import pybamm
from pybamm.expression_tree.operations.serialise import convert_symbol_to_json

# --- Atomic validators ------------------------------------------------------ #


def df_to_dict_validator(v: Any) -> Any:
    """Convert DataFrame to dict with orient='list' for serialization."""
    if isinstance(v, pd.DataFrame):
        # Replace NaN with None for JSON compatibility
        return v.replace(np.nan, None).to_dict(orient="list")
    elif isinstance(v, pl.DataFrame):
        # Replace NaN with None for JSON compatibility, then convert to dict
        return v.fill_nan(None).to_dict(as_series=False)
    return v


def dict_to_df_validator(v: Any) -> Any:
    """Convert dict to DataFrame for data processing."""
    if isinstance(v, dict):
        try:
            return pd.DataFrame(v)
        except ValueError as e:
            if "If using all scalar values, you must pass an index" in str(e):
                # Handle case where all values are scalars by providing an index
                return pd.DataFrame(v, index=[0])
            else:
                raise
    return v


def parameter_validator(v: Any) -> Any:
    """Convert pybamm.Symbol values to JSON-serializable form."""
    if isinstance(v, pybamm.Symbol):
        return convert_symbol_to_json(v)
    return v


def float_sanitizer(v: Any) -> Any:
    """Sanitize float values to JSON-compatible forms. Currently removes NaN and
    infinity values."""
    if isinstance(v, float):
        if math.isinf(v):
            return "Infinity" if v > 0 else "-Infinity"
        elif np.isnan(v):
            return None
    elif isinstance(v, np.floating):
        if np.isinf(v):
            return "Infinity" if v > 0 else "-Infinity"
        elif np.isnan(v):
            return None
    return v


def bounds_tuple_validator(v: Any) -> Any:
    """Convert bounds 2-tuple to list for JSON serialization.

    Converts tuples with exactly 2 elements to lists. This is useful for
    bounds parameters that may be provided as tuples (lower, upper) but
    need to be serialized as lists.

    Parameters
    ----------
    v : Any
        Value to validate. If it's a tuple with 2 elements, converts to list.

    Returns
    -------
    Any
        List if input was a 2-tuple, otherwise unchanged.
    """
    if isinstance(v, tuple) and len(v) == 2:
        return list(v)
    return v


def file_scheme_validator(v: Any) -> Any:
    """
    Convert file:// and folder:// scheme paths to serialized dicts.

    Handles:
    - "file:" prefixed paths: loads CSV file as dict (serialized)
    - "folder:" prefixed paths: loads time_series.csv and steps.csv as dict
    - All other values: returned unchanged

    Raises
    ------
    FileNotFoundError
        If the file or folder path doesn't exist
    Exception
        If reading the CSV file fails for any other reason
    """
    if isinstance(v, str) and v.startswith("file:"):
        path = pathlib.Path(v.split(":")[1]).expanduser().resolve()
        if not path.exists() or not path.is_file():
            raise FileNotFoundError(f"CSV file not found: {v}")
        return df_to_dict_validator(pd.read_csv(path))
    elif isinstance(v, str) and v.startswith("folder:"):
        path = pathlib.Path(v.split(":")[1]).expanduser().resolve()
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError(f"Folder not found: {v}")
        return {
            "time_series": df_to_dict_validator(pd.read_csv(path / "time_series.csv")),
            "steps": df_to_dict_validator(pd.read_csv(path / "steps.csv")),
        }
    return v


# --- Pipeline composition helpers ------------------------------------------ #

Validator = Callable[[Any], Any]


def _apply_pipeline(value: Any, validators: Iterable[Validator]) -> Any:
    transformed = value
    for validator in validators:
        transformed = validator(transformed)
    return transformed


def _apply_recursive(value: Any, validators: Iterable[Validator]) -> Any:
    if isinstance(value, dict):
        return {key: _apply_recursive(val, validators) for key, val in value.items()}
    if isinstance(value, tuple):
        # Apply validators to tuple first (e.g., to convert bounds tuples to lists)
        transformed = _apply_pipeline(value, validators)
        # If validator converted tuple to list, process recursively
        if isinstance(transformed, list):
            return [_apply_recursive(item, validators) for item in transformed]
        # Otherwise, process tuple items recursively
        return [_apply_recursive(item, validators) for item in transformed]
    if isinstance(value, list):
        return [_apply_recursive(item, validators) for item in value]
    return _apply_pipeline(value, validators)


# --- Public pipelines ------------------------------------------------------- #

validators_outbound: list[Validator] = [
    float_sanitizer,
    bounds_tuple_validator,
    file_scheme_validator,
    df_to_dict_validator,
    parameter_validator,
]

validators_inbound: list[Validator] = [
    dict_to_df_validator,
]


def run_validators_outbound(v: Any) -> Any:
    """Recursively apply outbound validators to values and nested containers."""
    return _apply_recursive(v, validators_outbound)


def run_validators_inbound(v: Any) -> Any:
    """Recursively apply inbound validators to values and nested containers."""
    return _apply_recursive(v, validators_inbound)
