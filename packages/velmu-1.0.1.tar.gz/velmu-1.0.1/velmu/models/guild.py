"""
velmu.models.guild
~~~~~~~~~~~~~~~~~~

Guild and Role models.
"""
from typing import Optional, List, Dict, TYPE_CHECKING
from ..abc import Snowflake
from ..utils import parse_time
from .user import Member

if TYPE_CHECKING:
    from ..state import ConnectionState
    from .channel import Channel

class Role(Snowflake):
    """Represents a Guild Role."""
    
    __slots__ = ('_state', 'guild', 'id', 'name', 'color', 'hoist', 'position', 'permissions', 'managed', 'mentionable')
    
    def __init__(self, state: 'ConnectionState', data: dict, guild: 'Guild'):
        self._state = state
        self.guild = guild
        self.id = data.get('id')
        self._update(data)
        
    def _update(self, data: dict):
        self.name = data.get('name')
        self.color = data.get('color')
        self.hoist = data.get('hoist', False)
        self.position = data.get('position', 0)
        
        # Permissions conversion
        perm_value = data.get('permissions', 0)
        
        from ..permissions import Permissions
        
        # Handle list of strings (Velmu Backend format)
        if isinstance(perm_value, list):
            self.permissions = Permissions.from_backend_strings(perm_value)
        # Handle string integer (API sometimes sends strings for large bitfields)
        elif isinstance(perm_value, str):
            self.permissions = Permissions(int(perm_value))
        else:
            self.permissions = Permissions(perm_value)
        
        self.managed = data.get('managed', False)
        self.mentionable = data.get('mentionable', False)

    @property
    def mention(self) -> str:
        return f'<@&{self.id}>'

class Guild(Snowflake):
    """Represents a Velmu Guild (Server)."""
    
    __slots__ = (
        '_state', 'id', 'name', 'icon', 'owner_id', 'region', 
        'afk_channel_id', 'afk_timeout', 'member_count', 
        'verification_level', 'default_message_notifications',
        'explicit_content_filter', 'roles', 'emojis', 'features',
        'mfa_level', 'application_id', 'system_channel_id',
        'rules_channel_id', 'joined_at', 'large', 'unavailable',
        'member_count', '_channels', '_members'
    )
    
    def __init__(self, state: 'ConnectionState', data: dict):
        self._state = state
        self.id = data.get('id')
        self._channels: Dict[str, 'Channel'] = {}
        self._members: Dict[str, Member] = {}
        self.roles: Dict[str, Role] = {}
        self._update(data)
        
    def _update(self, data: dict):
        self.name = data.get('name')
        self.icon = data.get('icon')
        self.owner_id = data.get('ownerId')
        self.member_count = data.get('memberCount', 0)
    
        # Roles
        if 'roles' in data:
            for r_data in data['roles']:
                role = Role(self._state, r_data, self)
                self.roles[role.id] = role

    @property
    def icon_url(self) -> Optional[str]:
        if self.icon:
             # Assuming backend serves uploads; adjusting to basic URL or CDN pattern
             # For now, if icon is a full URL, return it. If hash, construct it.
             if self.icon.startswith('http'):
                 return self.icon
             # Default fallback or construction if needed. For now assuming full URL or None.
             return None 
        return None
        
        # Roles


    @property
    def channels(self) -> List['Channel']:
        return list(self._channels.values())

    @property
    def members(self) -> List[Member]:
        return list(self._members.values())

    @property
    def text_channels(self) -> List['Channel']:
        """Returns a list of text channels in the guild."""
        return [c for c in self.channels if str(c.type) == 'TEXT' or c.type == 0]

    @property
    def voice_channels(self) -> List['Channel']:
        """Returns a list of voice channels in the guild."""
        return [c for c in self.channels if str(c.type) == 'AUDIO' or str(c.type) == 'VOICE' or c.type == 2]

    @property
    def owner(self) -> Optional[Member]:
        return self.get_member(self.owner_id)

    def get_member(self, user_id: str) -> Optional[Member]:
        return self._members.get(user_id)

    async def fetch_member(self, user_id: str) -> Member:
        data = await self._state.http.get_member(self.id, user_id)
        member = Member(self._state, data, self)
        self._members[user_id] = member
        return member

    def get_role(self, role_id: str) -> Optional[Role]:
        return self.roles.get(role_id)
        
    def get_channel(self, channel_id: str) -> Optional['Channel']:
        return self._channels.get(channel_id)

    def __repr__(self):
        return f'<Guild id={self.id} name={self.name!r} chunked={len(self.members)}/{self.member_count}>'
