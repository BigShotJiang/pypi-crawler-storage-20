"""
velmu.models.channel
~~~~~~~~~~~~~~~~~~~~

Channel and Message models.
"""
from typing import Optional, List, Union, TYPE_CHECKING
from ..abc import Snowflake, Messageable
from ..utils import parse_time
from .user import User, Member
import asyncio

if TYPE_CHECKING:
    from ..state import ConnectionState
    from .guild import Guild

class ChannelType:
    GUILD_TEXT = 0
    DM = 1
    GUILD_VOICE = 2
    GROUP_DM = 3
    GUILD_CATEGORY = 4

class HistoryIterator:
    """Async iterator for channel history."""
    
    def __init__(self, channel, limit=100, before=None, after=None):
        self.channel = channel
        self.limit = limit
        self.before = before
        self.after = after
        
        self._messages = asyncio.Queue()
        self._retrieve_messages = True
    
    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._messages.empty():
            if not self._retrieve_messages:
                raise StopAsyncIteration
                
            await self._fill_messages()
            
            if self._messages.empty():
                raise StopAsyncIteration
        
        return await self._messages.get()

    async def _fill_messages(self):
        if self.limit <= 0:
            self._retrieve_messages = False
            return

        fetch_limit = min(self.limit, 100) 
        
        data = await self.channel._state.http.get_messages(
            self.channel.id, 
            limit=fetch_limit, 
            before=self.before,
            after=self.after
        )
        
        
        # Handle pagination object (items + cursor)
        if isinstance(data, dict) and 'items' in data:
            data = data['items']

        if not data:
            self._retrieve_messages = False
            return

        if not isinstance(data, list):
            # API returned something unexpected (error string?)
            print(f"History Error: Expected list, got {type(data)}: {data}")
            self._retrieve_messages = False
            return
            
        found = 0
        for msg_data in data:
            self._messages.put_nowait(Message(self.channel._state, msg_data, self.channel))
            found += 1
            
            # Update pointers (Legacy: usually traverse backwards)
            self.before = msg_data['id'] 
            
        self.limit -= found
        if self.limit <= 0 or found < fetch_limit:
            self._retrieve_messages = False

class Channel(Snowflake, Messageable):
    """Represents a Guild or DM Channel."""
    
    __slots__ = ('_state', 'id', 'name', 'type', 'guild_id', 'position', 'permission_overwrites', 'category_id', 'topic', 'last_message_id', 'nsfw')
    
    def __init__(self, state: 'ConnectionState', data: dict, guild: Optional['Guild'] = None):
        self._state = state
        self.id = data.get('id')
        self._update(data, guild)
        
    def _update(self, data: dict, guild: Optional['Guild'] = None):
        self.name = data.get('name')
        self.type = data.get('type')
        self.guild_id = data.get('guildId')
        self.position = data.get('position')
        self.topic = data.get('topic')
        self.category_id = data.get('categoryId')
        self.nsfw = data.get('nsfw', False)
        
    @property
    def guild(self) -> Optional['Guild']:
        if self.guild_id:
            return self._state.get_guild(self.guild_id)
        return None
        
    @property
    def mention(self) -> str:
        return f'<#{self.id}>'

    async def _get_channel(self):
        return self

    async def send(self, content=None, *, embed=None, **kwargs):
        """Sends a message to the channel."""
        # Convert embed object to dict if necessary
        if embed and hasattr(embed, 'to_dict'):
            embed = embed.to_dict()
            
        data = await self._state.http.send_message(self.id, content, embed)
        return Message(self._state, data, self)

    async def fetch_message(self, message_id: str) -> 'Message':
        data = await self._state.http.get_message(self.id, message_id)
        return Message(self._state, data, self)

    def history(self, *, limit: int = 100, before=None, after=None) -> HistoryIterator:
        """Returns an AsyncIterator for channel history."""
        return HistoryIterator(self, limit=limit, before=before, after=after)

class PartialMessageable(Snowflake, Messageable):
    """Represents a partial messageable entity (e.g. just a channel ID)."""
    
    __slots__ = ('_state', 'id', 'guild_id', 'type')
    
    def __init__(self, state, id: str, guild_id: Optional[str] = None, type: Optional[int] = None):
        self._state = state
        self.id = id
        self.guild_id = guild_id
        self.type = type
        
    async def _get_channel(self):
        return self

class Message(Snowflake):
    """Represents a Message in a Channel."""
    
    __slots__ = ('_state', 'id', 'content', 'channel_id', 'author', 'embeds', 'timestamp', 'edited_timestamp', 'tts', 'mention_everyone', 'mentions', 'mention_roles', 'attachments', 'pinned', 'webhook_id', 'type', 'activity', 'application', 'reference', 'flags')
    
    def __init__(self, state: 'ConnectionState', data: dict, channel: Optional[Channel] = None):
        self._state = state
        self.id = data.get('id')
        self.channel_id = data.get('channelId')
        self._update(data, channel)
        
    def _update(self, data: dict, channel: Optional[Channel] = None):
        self.content = data.get('content')
        self.timestamp = parse_time(data.get('timestamp'))
        self.embeds = data.get('embeds', [])
        
        # Author
        user_data = data.get('author')
        if user_data:
            self.author = User(self._state, user_data)
        else:
            # Fallback: Try to resolve from cache using userId
            user_id = data.get('userId')
            if user_id:
                self.author = self._state.get_user(user_id)
            else:
                self.author = None
        
    @property
    def channel(self) -> Optional[Channel]:
        return self._state.get_channel(self.channel_id)

    @property
    def guild(self) -> Optional['Guild']:
        channel = self.channel
        return channel.guild if channel else None

    async def delete(self):
        await self._state.http.delete_message(self.id)
        
    async def edit(self, content=None, embed=None):
        if embed and hasattr(embed, 'to_dict'):
            embed = embed.to_dict()
        return await self._state.http.edit_message(self.id, content, embed)
        
    async def reply(self, content=None, embed=None):
        return await self.channel.send(content, embed=embed)



