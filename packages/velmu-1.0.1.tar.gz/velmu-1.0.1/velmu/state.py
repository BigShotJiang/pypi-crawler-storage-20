"""
velmu.state
~~~~~~~~~~~

Internal state and cache management.
"""
import asyncio
import logging
from typing import Dict, Optional, TYPE_CHECKING
from .models import User, Guild, Channel

if TYPE_CHECKING:
    from .client import Client
    from .api import HTTPClient

_log = logging.getLogger(__name__)

class ConnectionState:
    """Manages the internal state of the client (Caches, HTTP, etc)."""
    
    def __init__(self, dispatch, http: 'HTTPClient'):
        self.dispatch = dispatch
        self.http = http
        self.user: Optional[User] = None
        
        # Caches
        self._users: Dict[str, User] = {}
        self._guilds: Dict[str, Guild] = {}
        self._channels: Dict[str, Channel] = {}
        
        # We can add more caches here (roles, members, etc)

    def clear(self):
        self.user = None
        self._users = {}
        self._guilds = {}
        self._channels = {}

    # --- Cache Methods ---
    
    def store_user(self, data):
        user_id = data.get('id')
        user = self._users.get(user_id)
        if user is None:
            user = User(state=self, data=data)
            self._users[user_id] = user
        else:
            user._update(data)
        return user

    def get_user(self, id: str) -> Optional[User]:
        return self._users.get(id)

    def store_channel(self, data):
        channel_id = data.get('id')
        guild_id = data.get('guildId')
        
        channel = self._channels.get(channel_id)
        if channel is None:
            channel = Channel(state=self, data=data)
            self._channels[channel_id] = channel
        else:
            channel._update(data)
            
        # Link to Guild
        if guild_id:
            guild = self._guilds.get(guild_id)
            if guild:
                guild._channels[channel_id] = channel
                
        return channel

    def store_member(self, guild, data):
        """Stores a Member and links it to the Guild."""
        # data is the full member object: { userId: ..., user: {...}, roles: [], ... }
        user_data = data.get('user')
        if not user_data and 'username' in data:
             # Handle flat user object if necessary (fallback)
             user_data = data
        
        if user_data:
            self.store_user(user_data)
            
        user_id = data.get('userId') or user_data.get('id')
        if not user_id:
            return None
            
        from .models import Member
        member = guild.get_member(user_id)
        if member is None:
            member = Member(state=self, data=data, guild=guild)
            guild._members[user_id] = member
        else:
            member._update(data)
            
        return member

    def get_channel(self, id: str) -> Optional[Channel]:
        return self._channels.get(id)

    def store_guild(self, data):
        guild_id = data.get('id')
        guild = self._guilds.get(guild_id)
        if guild is None:
            guild = Guild(state=self, data=data)
            self._guilds[guild_id] = guild
        else:
            guild._update(data)
        return guild

    def get_guild(self, id: str) -> Optional[Guild]:
        return self._guilds.get(id)

    # --- Event Parsers ---

    def parse_channel_create(self, data) -> Optional[Channel]:
        return self.store_channel(data)

    def parse_channel_update(self, data) -> Optional[Channel]:
        return self.store_channel(data)

    def parse_channel_delete(self, data) -> Optional[Channel]:
        channel_id = data.get('id')
        guild_id = data.get('guildId')
        
        channel = self._channels.pop(channel_id, None)
        
        if guild_id:
            guild = self.get_guild(guild_id)
            if guild and channel_id in guild._channels:
                del guild._channels[channel_id]
                
        return channel

    def parse_guild_member_add(self, data) -> Optional['User']: # Returns Member actually
        guild_id = data.get('guildId')
        guild = self.get_guild(guild_id)
        if guild:
            return self.store_member(guild, data)
        return None

    def parse_guild_member_remove(self, data):
        guild_id = data.get('guildId')
        user_id = data.get('userId') or data.get('user', {}).get('id')
        
        guild = self.get_guild(guild_id)
        if guild and user_id in guild._members:
            return guild._members.pop(user_id)
        return None

    def parse_guild_role_create(self, data):
        guild_id = data.get('guildId')
        role_data = data.get('role')
        
        guild = self.get_guild(guild_id)
        if guild and role_data:
            from .models.guild import Role
            role = Role(self, role_data, guild)
            guild.roles[role.id] = role
            # Also update guild's role list if it's stored separately? 
            # Guild.roles is a dict, so we are good.
            return role
        return None

    def parse_guild_role_update(self, data):
        guild_id = data.get('guildId')
        role_data = data.get('role')
        
        guild = self.get_guild(guild_id)
        if guild and role_data:
            role_id = role_data.get('id')
            role = guild.get_role(role_id)
            if role:
                role._update(role_data)
                return role
        return None

    def parse_guild_role_delete(self, data):
        guild_id = data.get('guildId')
        role_id = data.get('roleId')
        
        guild = self.get_guild(guild_id)
        if guild and role_id in guild.roles:
            return guild.roles.pop(role_id)
        return None

    def parse_presence_update(self, data):
        # Data: { userId, status, guildId, ... }
        user_id = data.get('userId') or data.get('user', {}).get('id')
        status = data.get('status')
        
        # 1. Update Global User
        user = self.get_user(user_id)
        if user:
            setattr(user, 'status', status)
            
        # 2. Fan-out: Update Member in ALL guilds (since they are separate instances)
        # Presence updates might be guild-specific in Discord, but for this bot simplified:
        # We propagate status to all known member instances.
        if user_id:
            for guild in self._guilds.values():
                member = guild.get_member(user_id)
                if member:
                    setattr(member, 'status', status)
                    
        return user
