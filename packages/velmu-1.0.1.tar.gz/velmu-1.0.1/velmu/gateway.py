"""
velmu.gateway
~~~~~~~~~~~~~

WebSocket Gateway connection manager.
"""
import asyncio
import logging
import time
import socketio
import aiohttp
from typing import Optional, TYPE_CHECKING
from .errors import GatewayError

if TYPE_CHECKING:
    from .client import Client
    from .state import ConnectionState
    from .flags import Intents

_log = logging.getLogger(__name__)

class GatewayOp:
    DISPATCH = 0
    HEARTBEAT = 1
    IDENTIFY = 2
    HELLO = 10
    HEARTBEAT_ACK = 11

class VelmuGateway:
    """Manages the WebSocket connection to the Velmu Gateway."""

    def __init__(self, state: 'ConnectionState', token: str, intents: 'Intents'):
        self.state = state
        self.token = token
        self.intents = intents
        # self.loop property removed, usage replaced by asyncio.create_task/get_running_loop
        self._sio = socketio.AsyncClient(logger=False, engineio_logger=False)
        self._heartbeat_task: Optional[asyncio.Task] = None
        self._connected = False
        self._closing = False
        
        # SIO Globals
        self._sio.on('connect', self.on_connect, namespace='/gateway-bot')
        self._sio.on('disconnect', self.on_disconnect, namespace='/gateway-bot')
        self._sio.on('payload', self.on_payload, namespace='/gateway-bot')
        self._sio.on('connect_error', self.on_connect_error, namespace='/gateway-bot')

    @property
    def latency(self) -> float:
        """Latency in seconds (Ping). PLACEHOLDER."""
        return 0.0

    async def connect(self, url: str):
        """Connect to the Gateway."""
        _log.info(f'Connecting to Gateway: {url}')
        try:
            await self._sio.connect(url, namespaces=['/gateway-bot'], transports=['websocket', 'polling'])
            await self._sio.wait()
        except asyncio.CancelledError:
            await self.close()
        except Exception as e:
            _log.error(f"Gateway connection failed: {e}")
            raise GatewayError(message=str(e))

    async def close(self):
        """Close the connection."""
        self._closing = True
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
        
        if self._sio.connected:
            await self._sio.disconnect()
        
        _log.info("Gateway closed.")

    async def send(self, op: int, data: dict):
        """Send a payload to the Gateway."""
        payload = {'op': op, 'd': data}
        await self._sio.emit('payload', payload, namespace='/gateway-bot')

    # --- Events ---

    async def on_connect(self):
        self._connected = True
        _log.info('Gateway connected. Identifying...')
        await self.identify()

    async def on_disconnect(self):
        self._connected = False
        if not self._closing:
            _log.warning('Gateway disconnected unexpectedly.')
        else:
            _log.info('Gateway disconnected.')

    async def on_connect_error(self, data):
        _log.error(f'Gateway Connection Error: {data}')

    async def on_payload(self, data):
        op = data.get('op')
        d = data.get('d')
        t = data.get('t')

        if op == GatewayOp.HELLO:
            interval = d['heartbeat_interval'] / 1000
            self._heartbeat_task = asyncio.create_task(self.heartbeat_loop(interval))
        
        elif op == GatewayOp.HEARTBEAT_ACK:
            pass # PONG
            
        elif op == GatewayOp.DISPATCH:
            self.state.dispatch(t, d)

    async def identify(self):
        """Send IDENTIFY payload."""
        payload = {
            'token': self.token,
            'intents': self.intents.value
        }
        await self.send(GatewayOp.IDENTIFY, payload)

    async def heartbeat_loop(self, interval: float):
        _log.debug(f'Heartbeat started (interval: {interval}s)')
        try:
            while True:
                await asyncio.sleep(interval)
                await self.send(GatewayOp.HEARTBEAT, {})
        except asyncio.CancelledError:
            pass
