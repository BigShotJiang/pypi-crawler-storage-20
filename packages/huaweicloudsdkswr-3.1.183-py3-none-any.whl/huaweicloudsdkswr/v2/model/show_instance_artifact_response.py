# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowInstanceArtifactResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'digest': 'str',
        'id': 'int',
        'repository_id': 'int',
        'repository_name': 'str',
        'type': 'str',
        'namespace_id': 'int',
        'media_type': 'str',
        'manifest_media_type': 'str',
        'pull_time': 'str',
        'push_time': 'str',
        'size': 'int',
        'tags': 'list[ArtifactTag]',
        'scan_overview': 'dict(str, NativeReportSummary)'
    }

    attribute_map = {
        'digest': 'digest',
        'id': 'id',
        'repository_id': 'repository_id',
        'repository_name': 'repository_name',
        'type': 'type',
        'namespace_id': 'namespace_id',
        'media_type': 'media_type',
        'manifest_media_type': 'manifest_media_type',
        'pull_time': 'pull_time',
        'push_time': 'push_time',
        'size': 'size',
        'tags': 'tags',
        'scan_overview': 'scan_overview'
    }

    def __init__(self, digest=None, id=None, repository_id=None, repository_name=None, type=None, namespace_id=None, media_type=None, manifest_media_type=None, pull_time=None, push_time=None, size=None, tags=None, scan_overview=None):
        r"""ShowInstanceArtifactResponse

        The model defined in huaweicloud sdk

        :param digest: 制品摘要
        :type digest: str
        :param id: 制品ID
        :type id: int
        :param repository_id: 仓库ID
        :type repository_id: int
        :param repository_name: 仓库名称
        :type repository_name: str
        :param type: 制品类型
        :type type: str
        :param namespace_id: 命名空间ID
        :type namespace_id: int
        :param media_type: 制品MIME类型
        :type media_type: str
        :param manifest_media_type: 制品元数据MIME类型
        :type manifest_media_type: str
        :param pull_time: 最近一次拉取时间
        :type pull_time: str
        :param push_time: 最近一次上传时间
        :type push_time: str
        :param size: 制品大小，单位：Byte
        :type size: int
        :param tags: 制品版本的Tag列表
        :type tags: list[:class:`huaweicloudsdkswr.v2.ArtifactTag`]
        :param scan_overview: 制品扫描摘要,支持制品扫描报告类型为application/vnd.security.vulnerability.report; version&#x3D;1.1的制品扫描摘要
        :type scan_overview: dict(str, NativeReportSummary)
        """
        
        super().__init__()

        self._digest = None
        self._id = None
        self._repository_id = None
        self._repository_name = None
        self._type = None
        self._namespace_id = None
        self._media_type = None
        self._manifest_media_type = None
        self._pull_time = None
        self._push_time = None
        self._size = None
        self._tags = None
        self._scan_overview = None
        self.discriminator = None

        if digest is not None:
            self.digest = digest
        if id is not None:
            self.id = id
        if repository_id is not None:
            self.repository_id = repository_id
        if repository_name is not None:
            self.repository_name = repository_name
        if type is not None:
            self.type = type
        if namespace_id is not None:
            self.namespace_id = namespace_id
        if media_type is not None:
            self.media_type = media_type
        if manifest_media_type is not None:
            self.manifest_media_type = manifest_media_type
        if pull_time is not None:
            self.pull_time = pull_time
        if push_time is not None:
            self.push_time = push_time
        if size is not None:
            self.size = size
        if tags is not None:
            self.tags = tags
        if scan_overview is not None:
            self.scan_overview = scan_overview

    @property
    def digest(self):
        r"""Gets the digest of this ShowInstanceArtifactResponse.

        制品摘要

        :return: The digest of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._digest

    @digest.setter
    def digest(self, digest):
        r"""Sets the digest of this ShowInstanceArtifactResponse.

        制品摘要

        :param digest: The digest of this ShowInstanceArtifactResponse.
        :type digest: str
        """
        self._digest = digest

    @property
    def id(self):
        r"""Gets the id of this ShowInstanceArtifactResponse.

        制品ID

        :return: The id of this ShowInstanceArtifactResponse.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this ShowInstanceArtifactResponse.

        制品ID

        :param id: The id of this ShowInstanceArtifactResponse.
        :type id: int
        """
        self._id = id

    @property
    def repository_id(self):
        r"""Gets the repository_id of this ShowInstanceArtifactResponse.

        仓库ID

        :return: The repository_id of this ShowInstanceArtifactResponse.
        :rtype: int
        """
        return self._repository_id

    @repository_id.setter
    def repository_id(self, repository_id):
        r"""Sets the repository_id of this ShowInstanceArtifactResponse.

        仓库ID

        :param repository_id: The repository_id of this ShowInstanceArtifactResponse.
        :type repository_id: int
        """
        self._repository_id = repository_id

    @property
    def repository_name(self):
        r"""Gets the repository_name of this ShowInstanceArtifactResponse.

        仓库名称

        :return: The repository_name of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._repository_name

    @repository_name.setter
    def repository_name(self, repository_name):
        r"""Sets the repository_name of this ShowInstanceArtifactResponse.

        仓库名称

        :param repository_name: The repository_name of this ShowInstanceArtifactResponse.
        :type repository_name: str
        """
        self._repository_name = repository_name

    @property
    def type(self):
        r"""Gets the type of this ShowInstanceArtifactResponse.

        制品类型

        :return: The type of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this ShowInstanceArtifactResponse.

        制品类型

        :param type: The type of this ShowInstanceArtifactResponse.
        :type type: str
        """
        self._type = type

    @property
    def namespace_id(self):
        r"""Gets the namespace_id of this ShowInstanceArtifactResponse.

        命名空间ID

        :return: The namespace_id of this ShowInstanceArtifactResponse.
        :rtype: int
        """
        return self._namespace_id

    @namespace_id.setter
    def namespace_id(self, namespace_id):
        r"""Sets the namespace_id of this ShowInstanceArtifactResponse.

        命名空间ID

        :param namespace_id: The namespace_id of this ShowInstanceArtifactResponse.
        :type namespace_id: int
        """
        self._namespace_id = namespace_id

    @property
    def media_type(self):
        r"""Gets the media_type of this ShowInstanceArtifactResponse.

        制品MIME类型

        :return: The media_type of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._media_type

    @media_type.setter
    def media_type(self, media_type):
        r"""Sets the media_type of this ShowInstanceArtifactResponse.

        制品MIME类型

        :param media_type: The media_type of this ShowInstanceArtifactResponse.
        :type media_type: str
        """
        self._media_type = media_type

    @property
    def manifest_media_type(self):
        r"""Gets the manifest_media_type of this ShowInstanceArtifactResponse.

        制品元数据MIME类型

        :return: The manifest_media_type of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._manifest_media_type

    @manifest_media_type.setter
    def manifest_media_type(self, manifest_media_type):
        r"""Sets the manifest_media_type of this ShowInstanceArtifactResponse.

        制品元数据MIME类型

        :param manifest_media_type: The manifest_media_type of this ShowInstanceArtifactResponse.
        :type manifest_media_type: str
        """
        self._manifest_media_type = manifest_media_type

    @property
    def pull_time(self):
        r"""Gets the pull_time of this ShowInstanceArtifactResponse.

        最近一次拉取时间

        :return: The pull_time of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._pull_time

    @pull_time.setter
    def pull_time(self, pull_time):
        r"""Sets the pull_time of this ShowInstanceArtifactResponse.

        最近一次拉取时间

        :param pull_time: The pull_time of this ShowInstanceArtifactResponse.
        :type pull_time: str
        """
        self._pull_time = pull_time

    @property
    def push_time(self):
        r"""Gets the push_time of this ShowInstanceArtifactResponse.

        最近一次上传时间

        :return: The push_time of this ShowInstanceArtifactResponse.
        :rtype: str
        """
        return self._push_time

    @push_time.setter
    def push_time(self, push_time):
        r"""Sets the push_time of this ShowInstanceArtifactResponse.

        最近一次上传时间

        :param push_time: The push_time of this ShowInstanceArtifactResponse.
        :type push_time: str
        """
        self._push_time = push_time

    @property
    def size(self):
        r"""Gets the size of this ShowInstanceArtifactResponse.

        制品大小，单位：Byte

        :return: The size of this ShowInstanceArtifactResponse.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        r"""Sets the size of this ShowInstanceArtifactResponse.

        制品大小，单位：Byte

        :param size: The size of this ShowInstanceArtifactResponse.
        :type size: int
        """
        self._size = size

    @property
    def tags(self):
        r"""Gets the tags of this ShowInstanceArtifactResponse.

        制品版本的Tag列表

        :return: The tags of this ShowInstanceArtifactResponse.
        :rtype: list[:class:`huaweicloudsdkswr.v2.ArtifactTag`]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this ShowInstanceArtifactResponse.

        制品版本的Tag列表

        :param tags: The tags of this ShowInstanceArtifactResponse.
        :type tags: list[:class:`huaweicloudsdkswr.v2.ArtifactTag`]
        """
        self._tags = tags

    @property
    def scan_overview(self):
        r"""Gets the scan_overview of this ShowInstanceArtifactResponse.

        制品扫描摘要,支持制品扫描报告类型为application/vnd.security.vulnerability.report; version=1.1的制品扫描摘要

        :return: The scan_overview of this ShowInstanceArtifactResponse.
        :rtype: dict(str, NativeReportSummary)
        """
        return self._scan_overview

    @scan_overview.setter
    def scan_overview(self, scan_overview):
        r"""Sets the scan_overview of this ShowInstanceArtifactResponse.

        制品扫描摘要,支持制品扫描报告类型为application/vnd.security.vulnerability.report; version=1.1的制品扫描摘要

        :param scan_overview: The scan_overview of this ShowInstanceArtifactResponse.
        :type scan_overview: dict(str, NativeReportSummary)
        """
        self._scan_overview = scan_overview

    def to_dict(self):
        import warnings
        warnings.warn("ShowInstanceArtifactResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowInstanceArtifactResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
