"""Vendored llama.cpp helpers."""
