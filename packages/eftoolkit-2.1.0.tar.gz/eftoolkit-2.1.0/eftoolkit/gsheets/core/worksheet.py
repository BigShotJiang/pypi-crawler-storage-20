"""Worksheet class for Google Sheets operations."""

from __future__ import annotations

import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pandas as pd

from eftoolkit.gsheets.types import CellLocation, CellRange, RangeType
from eftoolkit.gsheets.utils import (
    BATCH_HANDLERS,
    batch_handler,
    column_index_to_letter,
    parse_cell_reference,
)

if TYPE_CHECKING:
    from eftoolkit.gsheets.core.spreadsheet import Spreadsheet


class Worksheet:
    """A single worksheet (tab) within a Google Spreadsheet.

    Handles all read/write/format operations for one tab.
    Operations are queued and flushed via flush() or context manager exit.
    """

    def __init__(
        self,
        gspread_worksheet: Any,
        spreadsheet: Spreadsheet,
        *,
        local_preview: bool = False,
        preview_output: Path | None = None,
        worksheet_name: str | None = None,
    ) -> None:
        """Initialize worksheet.

        Args:
            gspread_worksheet: The underlying gspread Worksheet object.
            spreadsheet: Parent Spreadsheet instance.
            local_preview: If True, skip API calls and render to local HTML.
            preview_output: Path for HTML preview file.
            worksheet_name: Worksheet name (used in local_preview mode).
        """
        self._ws = gspread_worksheet
        self._spreadsheet = spreadsheet
        self._local_preview = local_preview
        self._worksheet_name = worksheet_name
        self._preview_output = preview_output or Path('sheet_preview.html')
        self._value_updates: list[dict] = []
        self._batch_requests: list[dict] = []
        self._preview_history: list[dict] = []  # Accumulates all writes for preview
        self._preview_column_widths: dict[int, int] = {}  # col_index -> width in pixels
        self._preview_notes: dict[tuple[int, int], str] = {}  # (row, col) -> note text

    def __enter__(self) -> Worksheet:
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Flush queued operations on clean exit."""
        if exc_type is None:
            self.flush()

    @property
    def title(self) -> str:
        """Worksheet title (tab name)."""
        if self._local_preview:
            return f'Local Preview - {self._worksheet_name}'
        return self._ws.title

    @property
    def is_local_preview(self) -> bool:
        """True if running in local preview mode."""
        return self._local_preview

    def read(self) -> pd.DataFrame:
        """Read worksheet to DataFrame (first row = headers)."""
        if self._local_preview:
            raise NotImplementedError('read not available in local preview mode')

        all_values = self._ws.get_all_values()
        if not all_values:
            return pd.DataFrame()
        return pd.DataFrame(data=all_values[1:], columns=all_values[0])

    def read_cell(self, cell: str) -> Any:
        """Read value of a single cell.

        Args:
            cell: A1 notation cell reference (e.g., 'V5', 'AA10').

        Returns:
            The cell's value (string, number, or empty string if blank).

        Example:
            value = ws.read_cell('V5')
        """
        if self._local_preview:
            raise NotImplementedError('read_cell not available in local preview mode')

        return self._ws.acell(cell).value

    def read_range(self, range_name: str) -> list[list[Any]]:
        """Read values from a cell range.

        Args:
            range_name: A1 notation range (e.g., 'V5:V10', 'A1:C3').

        Returns:
            2D list of values (list of rows, each row is a list of cell values).
            Empty cells are represented as empty strings.

        Example:
            values = ws.read_range('V5:V10')
            # Returns: [['value1'], ['value2'], ...]
        """
        if self._local_preview:
            raise NotImplementedError('read_range not available in local preview mode')

        return self._ws.get(range_name)

    def write_dataframe(
        self,
        df: pd.DataFrame,
        location: str = 'A1',
        *,
        include_header: bool = True,
        format_dict: dict[str, Any] | None = None,
    ) -> None:
        """Queue DataFrame write with optional formatting.

        Args:
            df: DataFrame to write.
            location: Cell location to start writing (e.g., 'A1').
            include_header: If True, include column names as first row.
            format_dict: Optional dict mapping range names to format dicts.
        """
        values = df.values.tolist()
        if include_header:
            values = [df.columns.tolist()] + values

        self._value_updates.append(
            {
                'range': f'{self.title}!{location}',
                'values': values,
            }
        )

        if format_dict:
            for range_name, fmt in format_dict.items():
                self._batch_requests.append(
                    {
                        'type': 'format',
                        'range': range_name,
                        'format': fmt,
                    }
                )

    def write_values(
        self,
        range_name: str,
        values: list[list[Any]],
    ) -> None:
        """Queue cell values update.

        Args:
            range_name: A1 notation range (e.g., 'A1:B2').
            values: 2D list of values to write.
        """
        # Prepend worksheet name if not already included
        if '!' not in range_name:
            range_name = f'{self.title}!{range_name}'
        self._value_updates.append({'range': range_name, 'values': values})

    def format_range(
        self,
        range_name: RangeType,
        format_dict: dict[str, Any],
    ) -> None:
        """Queue cell formatting.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange.
            format_dict: Format specification dict.
        """
        self._batch_requests.append(
            {
                'type': 'format',
                'range': range_name,
                'format': format_dict,
            }
        )

    def set_borders(
        self,
        range_name: RangeType,
        borders: dict[str, Any],
    ) -> None:
        """Queue border formatting.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange.
            borders: Border specification dict.
        """
        self._batch_requests.append(
            {
                'type': 'border',
                'range': range_name,
                'borders': borders,
            }
        )

    def set_column_width(
        self,
        column: str | int,
        width: int,
    ) -> None:
        """Queue column width update.

        Args:
            column: Column letter or 1-based index.
            width: Width in pixels.
        """
        self._batch_requests.append(
            {
                'type': 'column_width',
                'column': column,
                'width': width,
            }
        )

    def auto_resize_columns(
        self,
        start_col: int,
        end_col: int,
    ) -> None:
        """Queue column auto-resize.

        Args:
            start_col: 1-based start column index.
            end_col: 1-based end column index.
        """
        self._batch_requests.append(
            {
                'type': 'auto_resize',
                'start_col': start_col,
                'end_col': end_col,
            }
        )

    def set_notes(
        self,
        notes: dict[str, str],
    ) -> None:
        """Queue cell notes.

        Args:
            notes: Dict mapping cell references to note text.
        """
        self._batch_requests.append(
            {
                'type': 'notes',
                'notes': notes,
            }
        )

    def merge_cells(
        self,
        range_name: RangeType,
        merge_type: str = 'MERGE_ALL',
    ) -> None:
        """Queue cell merge.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange to merge.
            merge_type: One of 'MERGE_ALL', 'MERGE_COLUMNS', 'MERGE_ROWS'.
        """
        self._batch_requests.append(
            {
                'type': 'merge',
                'range': range_name,
                'merge_type': merge_type,
            }
        )

    def unmerge_cells(
        self,
        range_name: RangeType,
    ) -> None:
        """Queue cell unmerge.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange to unmerge.
        """
        self._batch_requests.append(
            {
                'type': 'unmerge',
                'range': range_name,
            }
        )

    def sort_range(
        self,
        range_name: RangeType,
        sort_specs: list[dict[str, Any]],
    ) -> None:
        """Queue range sort.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange to sort.
            sort_specs: List of sort specifications. Each spec should have:
                - 'column': 0-based column index within the range
                - 'ascending': True for ascending, False for descending (default True)

        Example:
            ws.sort_range('A1:C10', [{'column': 0, 'ascending': True}])
        """
        self._batch_requests.append(
            {
                'type': 'sort',
                'range': range_name,
                'sort_specs': sort_specs,
            }
        )

    def set_data_validation(
        self,
        range_name: RangeType,
        rule: dict[str, Any],
    ) -> None:
        """Queue data validation rule.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange for validation.
            rule: Validation rule dict. Common keys:
                - 'type': 'ONE_OF_LIST', 'ONE_OF_RANGE', 'NUMBER_BETWEEN', etc.
                - 'values': List of allowed values (for ONE_OF_LIST)
                - 'showDropdown': True to show dropdown (default True)
                - 'strict': True to reject invalid input (default True)

        Example:
            ws.set_data_validation('A1:A10', {
                'type': 'ONE_OF_LIST',
                'values': ['Yes', 'No', 'Maybe'],
                'showDropdown': True,
            })
        """
        self._batch_requests.append(
            {
                'type': 'data_validation',
                'range': range_name,
                'rule': rule,
            }
        )

    def clear_data_validation(
        self,
        range_name: RangeType,
    ) -> None:
        """Queue removal of data validation rules.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange to clear.
        """
        self._batch_requests.append(
            {
                'type': 'clear_data_validation',
                'range': range_name,
            }
        )

    def add_conditional_format(
        self,
        range_name: RangeType,
        rule: dict[str, Any],
    ) -> None:
        """Queue conditional formatting rule.

        Args:
            range_name: A1 notation range, CellLocation, or CellRange.
            rule: Conditional format rule dict. Should contain:
                - 'type': 'CUSTOM_FORMULA', 'NUMBER_GREATER', 'TEXT_CONTAINS', etc.
                - 'values': Condition values (e.g., formula string)
                - 'format': Cell format to apply when condition is met

        Example:
            ws.add_conditional_format('A1:A10', {
                'type': 'CUSTOM_FORMULA',
                'values': ['=A1>100'],
                'format': {'backgroundColor': {'red': 1, 'green': 0, 'blue': 0}},
            })
        """
        self._batch_requests.append(
            {
                'type': 'conditional_format',
                'range': range_name,
                'rule': rule,
            }
        )

    def insert_rows(
        self,
        start_row: int,
        num_rows: int = 1,
    ) -> None:
        """Queue row insertion.

        Args:
            start_row: 1-based row index where new rows will be inserted.
            num_rows: Number of rows to insert (default 1).
        """
        self._batch_requests.append(
            {
                'type': 'insert_rows',
                'start_row': start_row,
                'num_rows': num_rows,
            }
        )

    def delete_rows(
        self,
        start_row: int,
        num_rows: int = 1,
    ) -> None:
        """Queue row deletion.

        Args:
            start_row: 1-based row index of first row to delete.
            num_rows: Number of rows to delete (default 1).
        """
        self._batch_requests.append(
            {
                'type': 'delete_rows',
                'start_row': start_row,
                'num_rows': num_rows,
            }
        )

    def insert_columns(
        self,
        start_col: int,
        num_cols: int = 1,
    ) -> None:
        """Queue column insertion.

        Args:
            start_col: 1-based column index where new columns will be inserted.
            num_cols: Number of columns to insert (default 1).
        """
        self._batch_requests.append(
            {
                'type': 'insert_columns',
                'start_col': start_col,
                'num_cols': num_cols,
            }
        )

    def delete_columns(
        self,
        start_col: int,
        num_cols: int = 1,
    ) -> None:
        """Queue column deletion.

        Args:
            start_col: 1-based column index of first column to delete.
            num_cols: Number of columns to delete (default 1).
        """
        self._batch_requests.append(
            {
                'type': 'delete_columns',
                'start_col': start_col,
                'num_cols': num_cols,
            }
        )

    def freeze_rows(
        self,
        num_rows: int,
    ) -> None:
        """Queue freezing rows at the top of the worksheet.

        Args:
            num_rows: Number of rows to freeze (0 to unfreeze).
        """
        self._batch_requests.append(
            {
                'type': 'freeze_rows',
                'num_rows': num_rows,
            }
        )

    def freeze_columns(
        self,
        num_cols: int,
    ) -> None:
        """Queue freezing columns at the left of the worksheet.

        Args:
            num_cols: Number of columns to freeze (0 to unfreeze).
        """
        self._batch_requests.append(
            {
                'type': 'freeze_columns',
                'num_cols': num_cols,
            }
        )

    def add_raw_request(
        self,
        request: dict[str, Any],
    ) -> None:
        """Queue a raw batchUpdate request.

        Use this for operations not covered by other methods. The request
        will be passed directly to the Google Sheets batchUpdate API.

        Args:
            request: A single batchUpdate request dict. See Google Sheets API
                documentation for available request types:
                https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request

        Example:
            # Add a named range
            ws.add_raw_request({
                'addNamedRange': {
                    'namedRange': {
                        'name': 'MyRange',
                        'range': {
                            'sheetId': 0,
                            'startRowIndex': 0,
                            'endRowIndex': 10,
                            'startColumnIndex': 0,
                            'endColumnIndex': 5,
                        }
                    }
                }
            })
        """
        self._batch_requests.append(
            {
                'type': 'raw',
                'request': request,
            }
        )

    def flush(self) -> None:
        """Execute all queued operations.

        In normal mode: sends batched API calls to Google Sheets.
        In local_preview mode: renders HTML.
        """
        if self._local_preview:
            self._flush_to_preview()
        else:
            self._flush_to_api()

        self._value_updates.clear()
        self._batch_requests.clear()

    @staticmethod
    def _resolve_range(range_value: RangeType) -> str:
        """Convert CellLocation, CellRange, or string to A1 notation string.

        Args:
            range_value: A CellLocation, CellRange, or string in A1 notation.

        Returns:
            A1 notation string representation.
        """
        if isinstance(range_value, CellLocation | CellRange):
            return range_value.value
        return range_value

    def _flush_to_api(self) -> None:
        """Send queued operations to Google Sheets API."""
        if not self._ws:
            return

        # Flush value updates via parent spreadsheet's batch update
        if self._value_updates:
            self._spreadsheet._execute_with_retry(
                lambda: self._spreadsheet._gspread_spreadsheet.values_batch_update(
                    {
                        'valueInputOption': 'USER_ENTERED',
                        'data': self._value_updates,
                    }
                ),
                'values_batch_update',
            )

        # Flush batch requests using handler registry
        for req in self._batch_requests:
            req_type = req['type']
            method_name = BATCH_HANDLERS.get(req_type)
            if method_name is None:
                raise ValueError(f"Unknown batch request type: '{req_type}'")
            handler = getattr(self, method_name)
            handler(req)

    @batch_handler('format')
    def _handle_format(self, req: dict) -> None:
        """Handle format request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#repeatcellrequest
        """
        range_str = self._resolve_range(req['range'])
        self._spreadsheet._execute_with_retry(
            lambda: self._ws.format(range_str, req['format']),
            'format',
        )

    @batch_handler('border')
    def _handle_border(self, req: dict) -> None:
        """Handle border request via raw batch update.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#updatebordersrequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        borders = req['borders']
        border_request = {
            'updateBorders': {
                'range': range_obj,
                **borders,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [border_request]}
            ),
            'border',
        )

    @batch_handler('column_width')
    def _handle_column_width(self, req: dict) -> None:
        """Handle column width request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#updatedimensionpropertiesrequest
        """
        column = req['column']
        width = req['width']
        # Convert letter to 0-based index
        if isinstance(column, str):
            col_idx = 0
            for char in column.upper():
                col_idx = col_idx * 26 + (ord(char) - ord('A') + 1)
            col_idx -= 1
        else:
            col_idx = column - 1  # Convert 1-based to 0-based

        request = {
            'updateDimensionProperties': {
                'range': {
                    'sheetId': self._ws.id,
                    'dimension': 'COLUMNS',
                    'startIndex': col_idx,
                    'endIndex': col_idx + 1,
                },
                'properties': {
                    'pixelSize': width,
                },
                'fields': 'pixelSize',
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'column_width',
        )

    @batch_handler('auto_resize')
    def _handle_auto_resize(self, req: dict) -> None:
        """Handle auto resize columns request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#autoresizedimensionsrequest
        """
        start_col = req['start_col'] - 1  # Convert to 0-based
        end_col = req['end_col']  # end is exclusive, so no -1
        request = {
            'autoResizeDimensions': {
                'dimensions': {
                    'sheetId': self._ws.id,
                    'dimension': 'COLUMNS',
                    'startIndex': start_col,
                    'endIndex': end_col,
                }
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'auto_resize',
        )

    @batch_handler('notes')
    def _handle_notes(self, req: dict) -> None:
        """Handle notes request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#updatecellsrequest
        """
        for cell_ref, note_text in req['notes'].items():
            self._spreadsheet._execute_with_retry(
                lambda c=cell_ref, n=note_text: self._ws.update_note(c, n),
                'notes',
            )

    @batch_handler('merge')
    def _handle_merge(self, req: dict) -> None:
        """Handle merge cells request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#mergecellsrequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        request = {
            'mergeCells': {
                'range': range_obj,
                'mergeType': req['merge_type'],
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'merge',
        )

    @batch_handler('unmerge')
    def _handle_unmerge(self, req: dict) -> None:
        """Handle unmerge cells request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#unmergecellsrequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        request = {
            'unmergeCells': {
                'range': range_obj,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'unmerge',
        )

    @batch_handler('sort')
    def _handle_sort(self, req: dict) -> None:
        """Handle sort range request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#sortrangerequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        sort_specs = [
            {
                'dimensionIndex': spec['column'],
                'sortOrder': 'ASCENDING'
                if spec.get('ascending', True)
                else 'DESCENDING',
            }
            for spec in req['sort_specs']
        ]
        request = {
            'sortRange': {
                'range': range_obj,
                'sortSpecs': sort_specs,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'sort',
        )

    @batch_handler('data_validation')
    def _handle_data_validation(self, req: dict) -> None:
        """Handle data validation request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#setdatavalidationrequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        rule = req['rule']

        condition_type = rule.get('type', 'ONE_OF_LIST')
        condition_values = [{'userEnteredValue': v} for v in rule.get('values', [])]

        request = {
            'setDataValidation': {
                'range': range_obj,
                'rule': {
                    'condition': {
                        'type': condition_type,
                        'values': condition_values,
                    },
                    'showCustomUi': rule.get('showDropdown', True),
                    'strict': rule.get('strict', True),
                },
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'data_validation',
        )

    @batch_handler('clear_data_validation')
    def _handle_clear_data_validation(self, req: dict) -> None:
        """Handle clear data validation request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#setdatavalidationrequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        request = {
            'setDataValidation': {
                'range': range_obj,
                'rule': None,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'clear_data_validation',
        )

    @batch_handler('conditional_format')
    def _handle_conditional_format(self, req: dict) -> None:
        """Handle conditional format request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#addconditionalformatrulerequest
        """
        range_str = self._resolve_range(req['range'])
        range_obj = self._parse_range_to_grid_range(range_str)
        rule = req['rule']

        condition_type = rule.get('type', 'CUSTOM_FORMULA')
        condition_values = [{'userEnteredValue': v} for v in rule.get('values', [])]

        request = {
            'addConditionalFormatRule': {
                'rule': {
                    'ranges': [range_obj],
                    'booleanRule': {
                        'condition': {
                            'type': condition_type,
                            'values': condition_values,
                        },
                        'format': rule.get('format', {}),
                    },
                },
                'index': 0,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'conditional_format',
        )

    @batch_handler('insert_rows')
    def _handle_insert_rows(self, req: dict) -> None:
        """Handle insert rows request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#insertdimensionrequest
        """
        start_row = req['start_row'] - 1  # Convert to 0-based
        num_rows = req['num_rows']
        request = {
            'insertDimension': {
                'range': {
                    'sheetId': self._ws.id,
                    'dimension': 'ROWS',
                    'startIndex': start_row,
                    'endIndex': start_row + num_rows,
                },
                'inheritFromBefore': start_row > 0,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'insert_rows',
        )

    @batch_handler('delete_rows')
    def _handle_delete_rows(self, req: dict) -> None:
        """Handle delete rows request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#deletedimensionrequest
        """
        start_row = req['start_row'] - 1  # Convert to 0-based
        num_rows = req['num_rows']
        request = {
            'deleteDimension': {
                'range': {
                    'sheetId': self._ws.id,
                    'dimension': 'ROWS',
                    'startIndex': start_row,
                    'endIndex': start_row + num_rows,
                }
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'delete_rows',
        )

    @batch_handler('insert_columns')
    def _handle_insert_columns(self, req: dict) -> None:
        """Handle insert columns request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#insertdimensionrequest
        """
        start_col = req['start_col'] - 1  # Convert to 0-based
        num_cols = req['num_cols']
        request = {
            'insertDimension': {
                'range': {
                    'sheetId': self._ws.id,
                    'dimension': 'COLUMNS',
                    'startIndex': start_col,
                    'endIndex': start_col + num_cols,
                },
                'inheritFromBefore': start_col > 0,
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'insert_columns',
        )

    @batch_handler('delete_columns')
    def _handle_delete_columns(self, req: dict) -> None:
        """Handle delete columns request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#deletedimensionrequest
        """
        start_col = req['start_col'] - 1  # Convert to 0-based
        num_cols = req['num_cols']
        request = {
            'deleteDimension': {
                'range': {
                    'sheetId': self._ws.id,
                    'dimension': 'COLUMNS',
                    'startIndex': start_col,
                    'endIndex': start_col + num_cols,
                }
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'delete_columns',
        )

    @batch_handler('freeze_rows')
    def _handle_freeze_rows(self, req: dict) -> None:
        """Handle freeze rows request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#updatesheetpropertiesrequest
        """
        num_rows = req['num_rows']
        request = {
            'updateSheetProperties': {
                'properties': {
                    'sheetId': self._ws.id,
                    'gridProperties': {
                        'frozenRowCount': num_rows,
                    },
                },
                'fields': 'gridProperties.frozenRowCount',
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'freeze_rows',
        )

    @batch_handler('freeze_columns')
    def _handle_freeze_columns(self, req: dict) -> None:
        """Handle freeze columns request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request#updatesheetpropertiesrequest
        """
        num_cols = req['num_cols']
        request = {
            'updateSheetProperties': {
                'properties': {
                    'sheetId': self._ws.id,
                    'gridProperties': {
                        'frozenColumnCount': num_cols,
                    },
                },
                'fields': 'gridProperties.frozenColumnCount',
            }
        }
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [request]}
            ),
            'freeze_columns',
        )

    @batch_handler('raw')
    def _handle_raw(self, req: dict) -> None:
        """Handle raw batch update request.

        API: https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/request
        """
        self._spreadsheet._execute_with_retry(
            lambda: self._spreadsheet._gspread_spreadsheet.batch_update(
                {'requests': [req['request']]}
            ),
            'raw',
        )

    def _parse_range_to_grid_range(self, range_name: str) -> dict:
        """Parse A1 notation range to GridRange dict for batch_update requests.

        Args:
            range_name: A1 notation range (e.g., 'A1:C10', 'Sheet1!A1:C10', 'X5:X').
                Supports open-ended ranges like 'X5:X' (column X from row 5 to end).

        Returns:
            GridRange dict with sheetId, startRowIndex, endRowIndex,
            startColumnIndex, endColumnIndex. endRowIndex is omitted for
            open-ended ranges (meaning "to end of sheet").
        """
        # Strip sheet name if present
        if '!' in range_name:
            range_name = range_name.split('!', 1)[1]

        # Parse start and end cells
        if ':' in range_name:
            start_cell, end_cell = range_name.split(':')
        else:
            start_cell = end_cell = range_name

        start_row, start_col = parse_cell_reference(start_cell)
        end_row, end_col = parse_cell_reference(end_cell)

        result = {
            'sheetId': self._ws.id,
            'startRowIndex': start_row if start_row is not None else 0,
            'startColumnIndex': start_col,
            'endColumnIndex': end_col + 1,  # exclusive
        }

        # Only include endRowIndex if end_row is specified (not open-ended)
        if end_row is not None:
            result['endRowIndex'] = end_row + 1  # exclusive

        return result

    def _flush_to_preview(self) -> None:
        """Render queued operations to local HTML preview as a unified grid."""
        # Accumulate current updates into history
        self._preview_history.extend(self._value_updates)

        # Process batch requests for preview metadata
        for req in self._batch_requests:
            if req['type'] == 'column_width':
                col = req['column']
                # Convert letter to index if needed
                if isinstance(col, str):
                    col_idx = 0
                    for char in col.upper():
                        col_idx = col_idx * 26 + (ord(char) - ord('A') + 1)
                    col_idx -= 1
                else:
                    col_idx = col - 1  # Convert 1-indexed to 0-indexed
                self._preview_column_widths[col_idx] = req['width']
            elif req['type'] == 'notes':
                for cell_ref, note_text in req['notes'].items():
                    row, col = parse_cell_reference(cell_ref)
                    self._preview_notes[(row, col)] = note_text

        # Build a sparse grid from all updates
        grid: dict[tuple[int, int], str] = {}
        max_row = 0
        max_col = 0

        for update in self._preview_history:
            start_row, start_col = parse_cell_reference(update['range'])
            for row_offset, row_data in enumerate(update['values']):
                for col_offset, cell_value in enumerate(row_data):
                    r = start_row + row_offset
                    c = start_col + col_offset
                    grid[(r, c)] = str(cell_value) if cell_value is not None else ''
                    max_row = max(max_row, r)
                    max_col = max(max_col, c)

        # Build HTML with Google Sheets-like styling
        html = ['<!DOCTYPE html><html><head>']
        html.append('<meta charset="utf-8">')
        html.append(f'<title>{self.title}</title>')
        html.append('<style>')
        html.append(
            'body { font-family: Arial, sans-serif; margin: 0; padding: 20px; '
            'background-color: #f8f9fa; }'
        )
        html.append(
            'h1 { color: #202124; font-size: 18px; font-weight: 400; '
            'margin-bottom: 16px; }'
        )
        html.append(
            '.sheet-container { background: white; border-radius: 8px; '
            'box-shadow: 0 1px 3px rgba(0,0,0,0.12); overflow: auto; }'
        )
        html.append('table { border-collapse: collapse; border-spacing: 0; }')
        html.append(
            'td, th { border: 1px solid #e0e0e0; padding: 4px 8px; '
            'font-size: 13px; vertical-align: middle; '
            'white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }'
        )
        html.append(
            'th { background-color: #f8f9fa; color: #5f6368; '
            'font-weight: 500; text-align: center; position: sticky; top: 0; }'
        )
        html.append(
            '.row-header { background-color: #f8f9fa; color: #5f6368; '
            'font-weight: 500; text-align: center; min-width: 46px; '
            'position: sticky; left: 0; }'
        )
        html.append(
            '.corner { background-color: #f8f9fa; position: sticky; '
            'top: 0; left: 0; z-index: 2; }'
        )
        html.append(
            'td { background-color: white; text-align: left; min-width: 80px; }'
        )
        html.append('.has-note { background-color: #fff8e1; cursor: help; }')
        html.append(
            '.has-note::after { content: ""; position: absolute; '
            'top: 0; right: 0; border-width: 0 6px 6px 0; '
            'border-style: solid; border-color: #ffc107 #ffc107 '
            'transparent transparent; }'
        )
        html.append('td { position: relative; }')
        html.append('</style>')
        html.append('</head><body>')
        html.append(f'<h1>📊 {self.title}</h1>')
        html.append('<div class="sheet-container">')
        html.append('<table>')

        # Header row with column letters
        html.append('<tr>')
        html.append('<th class="corner"></th>')  # Corner cell
        for c in range(max_col + 1):
            width = self._preview_column_widths.get(c, 80)
            html.append(
                f'<th style="width: {width}px; min-width: {width}px;">'
                f'{column_index_to_letter(c)}</th>'
            )
        html.append('</tr>')

        # Data rows
        for r in range(max_row + 1):
            html.append('<tr>')
            html.append(f'<td class="row-header">{r + 1}</td>')
            for c in range(max_col + 1):
                cell_value = grid.get((r, c), '')
                note = self._preview_notes.get((r, c))
                width = self._preview_column_widths.get(c, 80)
                style = f'width: {width}px; max-width: {width}px;'
                if note:
                    # Escape HTML in note text
                    escaped_note = (
                        note.replace('&', '&amp;')
                        .replace('"', '&quot;')
                        .replace('<', '&lt;')
                        .replace('>', '&gt;')
                    )
                    html.append(
                        f'<td class="has-note" style="{style}" '
                        f'title="{escaped_note}">{cell_value}</td>'
                    )
                else:
                    html.append(f'<td style="{style}">{cell_value}</td>')
            html.append('</tr>')

        html.append('</table>')
        html.append('</div>')
        html.append('</body></html>')

        self._preview_output.parent.mkdir(parents=True, exist_ok=True)
        self._preview_output.write_text('\n'.join(html))

    def open_preview(self) -> None:
        """Open the preview HTML in browser (local_preview mode only)."""
        if not self._local_preview:
            raise RuntimeError('open_preview only available in local_preview mode')

        webbrowser.open(f'file://{self._preview_output.absolute()}')
