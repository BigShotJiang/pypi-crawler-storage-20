"""
Tests for FireFeed Core
"""