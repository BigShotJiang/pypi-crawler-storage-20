"""
Final Cleanup Transformer - Removes dirty fields before Terraform rendering.

VERSION: 3.7.4
STATUS: Production Ready

This transformer runs LAST in the pipeline to clean up:
1. Internal fields that leaked from earlier stages (e.g., SecurityGroupSplitter)
2. Fields that Terraform doesn't support for specific resource types
3. Temporary processing markers (fields starting with '_')
4. None/null values that would cause Terraform errors

CRITICAL: This transformer must be the LAST stage in the codify pipeline.

v3.7.4 FIX: Added aws_network_acl cleanup for API-native entry fields
            Added aws_lb_target_group matcher dict-to-string conversion
v3.7.2 FIX: Uses _get_terraform_type() to correctly identify resource types,
including dynamically typed resources like aws_security_group_rule.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from .base import BaseCodifyTransformer

if TYPE_CHECKING:
    from replimap.core.unified_storage import GraphEngineAdapter

logger = logging.getLogger(__name__)


class FinalCleanupTransformer(BaseCodifyTransformer):
    """
    Clean up dirty fields before Terraform code generation.

    This is the final safety net that removes:
    - Internal processing markers (fields starting with '_')
    - Resource-specific invalid fields (e.g., 'security_groups' in aws_security_group)
    - Any other fields that would cause terraform plan to fail

    MUST be the last transformer in the pipeline.
    """

    name = "FinalCleanupTransformer"

    # Fields to remove from specific resource types
    # These are fields that either:
    # - Leaked from earlier processing stages
    # - Are valid for other resource types but not this one
    # - Would cause terraform plan errors
    RESOURCE_CLEANUP_RULES: dict[str, set[str]] = {
        # security_groups is valid for aws_lb, but NOT for aws_security_group
        # It may leak from SecurityGroupSplitter or cross-type confusion
        "aws_security_group": {
            "security_groups",
            "ip_permissions",
            "ip_permissions_egress",
        },
        # aws_security_group_rule should not have these
        "aws_security_group_rule": {
            "security_groups",
        },
        # aws_lb_target_group: targets are managed separately
        "aws_lb_target_group": {
            "targets",
            "target_health_descriptions",
        },
        # v3.7.4: aws_network_acl - API returns Entries[] with these nested fields
        # Terraform expects ingress/egress blocks, not flat entry fields
        "aws_network_acl": {
            "entries",
            "rule_number",
            "rule_action",
            "protocol",
            "cidr_block",
            "ipv6_cidr_block",
            "egress",
            "icmp_type_code",
            "port_range",
            # Also the raw API field names (PascalCase)
            "Entries",
            "RuleNumber",
            "RuleAction",
            "Protocol",
            "CidrBlock",
            "Ipv6CidrBlock",
            "Egress",
            "IcmpTypeCode",
            "PortRange",
        },
        # v3.7.4: aws_vpc_endpoint - policy_document should be policy
        "aws_vpc_endpoint": {
            "policy_document",
            "PolicyDocument",
        },
    }

    # Fields that are always internal and should never appear in output
    ALWAYS_REMOVE_FIELDS: set[str] = {
        # Internal markers from SecurityGroupSplitter
        "_parent_sg_id",
        "_parent_sg_name",
    }

    def __init__(self) -> None:
        """Initialize the cleanup transformer."""
        self._fields_cleaned = 0
        self._resources_cleaned = 0

    def _get_terraform_type(self, resource: Any) -> str:
        """
        Get the Terraform type for a resource.

        v3.7.2 FIX: Some resources (like aws_security_group_rule, aws_iam_*_policy_attachment)
        have their Terraform type stored in config["_terraform_type"] because they're
        dynamically created by transformers like SecurityGroupSplitter or IamNormalizer.
        """
        config = resource.config or {}
        if "_terraform_type" in config:
            return config["_terraform_type"]
        return str(resource.resource_type)

    def transform(self, graph: GraphEngineAdapter) -> GraphEngineAdapter:
        """
        Clean up all resources before rendering.

        Args:
            graph: The graph to transform

        Returns:
            The cleaned graph
        """
        self._fields_cleaned = 0
        self._resources_cleaned = 0

        for resource in graph.iter_resources():
            if not resource.config:
                continue

            resource_type = self._get_terraform_type(resource)
            cleaned = self._cleanup_config(resource.config, resource_type)

            if cleaned:
                self._resources_cleaned += 1

        if self._fields_cleaned > 0:
            logger.info(
                f"FinalCleanupTransformer: cleaned {self._fields_cleaned} fields "
                f"from {self._resources_cleaned} resources"
            )

        return graph

    def _cleanup_config(self, config: dict[str, Any], resource_type: str) -> bool:
        """
        Clean up a single resource config.

        Args:
            config: Resource configuration dict
            resource_type: Terraform resource type

        Returns:
            True if any fields were cleaned
        """
        cleaned = False

        # 0. v3.7.4: Special handling for aws_lb_target_group matcher
        # If matcher is still a dict/list (transform didn't fire), convert to string
        if resource_type == "aws_lb_target_group" and "matcher" in config:
            matcher = config["matcher"]
            if isinstance(matcher, list) and matcher:
                # Unwrap list first
                matcher = matcher[0]
            if isinstance(matcher, dict):
                # Extract HttpCode or GrpcCode
                http_code = matcher.get("HttpCode") or matcher.get("http_code")
                grpc_code = matcher.get("GrpcCode") or matcher.get("grpc_code")
                if http_code:
                    config["matcher"] = str(http_code)
                    cleaned = True
                    logger.debug(f"Converted matcher dict to string: {http_code}")
                elif grpc_code:
                    config["matcher"] = str(grpc_code)
                    cleaned = True
                    logger.debug(f"Converted matcher dict to string: {grpc_code}")
                else:
                    # Fallback: first value
                    first_val = next(iter(matcher.values()), "200")
                    config["matcher"] = str(first_val)
                    cleaned = True
                    logger.debug(
                        f"Converted matcher dict to string (fallback): {first_val}"
                    )

        # 1. Remove internal markers (fields starting with '_')
        internal_fields = [k for k in config.keys() if k.startswith("_")]
        for field in internal_fields:
            del config[field]
            self._fields_cleaned += 1
            cleaned = True
            logger.debug(f"Removed internal field '{field}' from {resource_type}")

        # 1b. Remove None/null values (Terraform doesn't like explicit nulls)
        # This prevents errors like: Invalid value for "value" parameter
        null_fields = [k for k, v in config.items() if v is None]
        for field in null_fields:
            del config[field]
            self._fields_cleaned += 1
            cleaned = True
            logger.debug(f"Removed null field '{field}' from {resource_type}")

        # 2. Remove always-remove fields
        for field in self.ALWAYS_REMOVE_FIELDS:
            if field in config:
                del config[field]
                self._fields_cleaned += 1
                cleaned = True
                logger.debug(
                    f"Removed always-remove field '{field}' from {resource_type}"
                )

        # 3. Remove resource-specific invalid fields
        invalid_fields = self.RESOURCE_CLEANUP_RULES.get(resource_type, set())
        for field in invalid_fields:
            if field in config:
                del config[field]
                self._fields_cleaned += 1
                cleaned = True
                logger.debug(f"Removed invalid field '{field}' from {resource_type}")

        # 4. Recursively clean nested structures
        for _key, value in list(config.items()):
            if isinstance(value, dict):
                nested_cleaned = self._cleanup_nested(value)
                if nested_cleaned:
                    cleaned = True
            elif isinstance(value, list):
                for item in value:
                    if isinstance(item, dict):
                        nested_cleaned = self._cleanup_nested(item)
                        if nested_cleaned:
                            cleaned = True

        return cleaned

    def _cleanup_nested(self, nested: dict[str, Any]) -> bool:
        """
        Clean up internal fields from nested structures.

        Args:
            nested: Nested dict to clean

        Returns:
            True if any fields were cleaned
        """
        cleaned = False

        # Remove internal markers
        internal_fields = [k for k in nested.keys() if k.startswith("_")]
        for field in internal_fields:
            del nested[field]
            self._fields_cleaned += 1
            cleaned = True

        return cleaned

    @property
    def fields_cleaned(self) -> int:
        """Return the number of fields cleaned."""
        return self._fields_cleaned

    @property
    def resources_cleaned(self) -> int:
        """Return the number of resources cleaned."""
        return self._resources_cleaned
