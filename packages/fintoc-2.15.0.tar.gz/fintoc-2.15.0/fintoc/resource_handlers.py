"""Module for the methods that handle te resources."""

from fintoc.utils import objetize, objetize_generator


def resource_list(client, path, klass, handlers, methods, params):
    """List all the instances of a resource."""
    lazy = params.pop("lazy", True)
    data = client.request(path, paginated=True, params=params)
    if lazy:
        return objetize_generator(
            data,
            klass,
            client,
            handlers=handlers,
            methods=methods,
            path=path,
        )
    return [
        objetize(
            klass,
            client,
            element,
            handlers=handlers,
            methods=methods,
            path=path,
        )
        for element in data
    ]


def resource_get(client, path, id_, klass, handlers, methods, params):
    """Fetch a specific instance of a resource."""
    data = client.request(f"{path}/{id_}", method="get", params=params)
    return objetize(
        klass,
        client,
        data,
        handlers=handlers,
        methods=methods,
        path=path,
    )


def resource_create(
    client, path, klass, handlers, methods, params, idempotency_key=None
):
    """Create a new instance of a resource."""
    data = client.request(
        path, method="post", json=params, idempotency_key=idempotency_key
    )
    return objetize(
        klass,
        client,
        data,
        handlers=handlers,
        methods=methods,
        path=path,
    )


def resource_update(
    client, path, id_, klass, handlers, methods, params, custom_path=None
):
    """Update a specific instance of a resource."""
    update_path = custom_path if custom_path else f"{path}/{id_}"
    data = client.request(update_path, method="patch", json=params)
    return objetize(
        klass,
        client,
        data,
        handlers,
        methods,
        path,
    )


def resource_delete(client, path, id_, params):
    """Delete an instance of a resource."""
    return client.request(f"{path}/{id_}", method="delete", params=params)
