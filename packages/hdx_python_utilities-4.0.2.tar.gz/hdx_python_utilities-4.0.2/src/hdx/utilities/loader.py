"""Loading utilities for YAML, JSON etc."""

import json
from collections.abc import Mapping, MutableMapping, Sequence
from pathlib import Path
from typing import Any
from warnings import warn

from ruamel.yaml import YAML

from hdx.utilities.dictandlist import merge_dictionaries, merge_two_dictionaries


class LoadError(Exception):
    pass


def load_text(
    path: Path | str,
    encoding: str = "utf-8",
    strip: bool = False,
    replace_newlines: str | None = None,
    replace_line_separators: str | None = None,
    loaderror_if_empty: bool = True,
    default_line_separator: str = "\n",
) -> str:
    """Load file into a string removing newlines.

    Args:
        path: Path to file
        encoding: Encoding of file. Defaults to utf-8.
        strip: Whether to strip whitespace from start and end. Defaults to False.
        replace_newlines: String with which to replace newlines. Defaults to None (don't replace). (deprecated 2024-02-07)
        replace_line_separators: String with which to replace newlines. Defaults to None (don't replace).
        loaderror_if_empty: Whether to raise LoadError if file is empty. Default to True.
        default_line_separator: line separator to be replaced if replace_line_separators is not None

    Returns:
        String contents of file
    """
    if replace_newlines is not None:
        warn(
            "Keyword argument 'replace_newlines' to 'load_text' is deprecated on 2024-02-08 "
            "in favour of 'replace_line_separators'",
            DeprecationWarning,
            stacklevel=2,
        )
        replace_line_separators = replace_newlines
    with open(path, encoding=encoding) as f:
        string = f.read()
        if replace_line_separators is not None:
            string = string.replace(default_line_separator, replace_line_separators)
        if strip:
            string = string.strip()
    if not string:
        if loaderror_if_empty:
            raise LoadError(f"{path} file is empty!")
        return ""
    return string


def load_yaml(
    path: Path | str, encoding: str = "utf-8", loaderror_if_empty: bool = True
) -> Any:
    """Load YAML file into an ordered dictionary.

    Args:
        path: Path to YAML file
        encoding: Encoding of file. Defaults to utf-8.
        loaderror_if_empty: Whether to raise LoadError if file is empty. Default to True.

    Returns:
        The data from the YAML file
    """
    with open(path, encoding=encoding) as f:
        data = f.read()
        if not data:
            if loaderror_if_empty:
                raise LoadError(f"YAML file: {path} is empty!")
            return None
        yaml = YAML()
        yamlobj = yaml.load(data)
        return yamlobj


def load_json(
    path: Path | str, encoding: str = "utf-8", loaderror_if_empty: bool = True
) -> Any:
    """Load JSON file into an ordered dictionary (dict for Python 3.7+)

    Args:
        path: Path to JSON file
        encoding: Encoding of file. Defaults to utf-8.
        loaderror_if_empty: Whether to raise LoadError if file is empty. Default to True.

    Returns:
        The data from the JSON file
    """
    with open(path, encoding=encoding) as f:
        data = f.read()
        if not data:
            if loaderror_if_empty:
                raise LoadError(f"JSON file: {path} is empty!")
            return None
        jsonobj = json.loads(data)
        return jsonobj


def load_and_merge_yaml(
    paths: Sequence[str],
    encoding: str = "utf-8",
    loaderror_if_empty: bool = True,
) -> Mapping:
    """Load multiple YAML files that are in dictionary form and merge into one
    dictionary.

    Args:
        paths: Paths to YAML files
        encoding: Encoding of file. Defaults to utf-8.
        loaderror_if_empty: Whether to raise LoadError if any file is empty. Default to True.

    Returns:
        Dictionary of merged YAML files
    """
    configs = [
        load_yaml(path, encoding=encoding, loaderror_if_empty=loaderror_if_empty)
        for path in paths
    ]
    return merge_dictionaries(configs)


def load_and_merge_json(
    paths: Sequence[str],
    encoding: str = "utf-8",
    loaderror_if_empty: bool = True,
) -> Mapping:
    """Load multiple JSON files that are in dictionary form and merge into one
    dictionary.

    Args:
        paths: Paths to JSON files
        encoding: Encoding of file. Defaults to utf-8.
        loaderror_if_empty: Whether to raise LoadError if any file is empty. Default to True.

    Returns:
        Dictionary of merged JSON files
    """
    configs = [
        load_json(path, encoding=encoding, loaderror_if_empty=loaderror_if_empty)
        for path in paths
    ]
    return merge_dictionaries(configs)


def load_yaml_into_existing_dict(
    data: MutableMapping,
    path: Path | str,
    encoding: str = "utf-8",
    loaderror_if_empty: bool = True,
) -> MutableMapping:
    """Merge YAML file that is in dictionary form into existing dictionary.

    Args:
        data: Dictionary to merge into
        path: YAML file to load and merge
        encoding: Encoding of file. Defaults to utf-8.
        loaderror_if_empty: Whether to raise LoadError if file is empty. Default to True.

    Returns:
        YAML file merged into dictionary
    """
    yamldict = load_yaml(path, encoding=encoding, loaderror_if_empty=loaderror_if_empty)
    return merge_two_dictionaries(data, yamldict)


def load_json_into_existing_dict(
    data: MutableMapping,
    path: Path | str,
    encoding: str = "utf-8",
    loaderror_if_empty: bool = True,
) -> MutableMapping:
    """Merge JSON file that is in dictionary form into existing dictionary.

    Args:
        data: Dictionary to merge into
        path: JSON file to load and merge
        encoding: Encoding of file. Defaults to utf-8.
        loaderror_if_empty: Whether to raise LoadError if file is empty. Default to True.

    Returns:
        JSON file merged into dictionary
    """
    jsondict = load_json(path, encoding=encoding, loaderror_if_empty=loaderror_if_empty)
    return merge_two_dictionaries(data, jsondict)
