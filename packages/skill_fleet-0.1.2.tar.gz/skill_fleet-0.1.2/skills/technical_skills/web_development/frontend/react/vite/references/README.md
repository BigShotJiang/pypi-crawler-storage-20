# References

Reference documentation for `react-vite-tailwind-setup`.

## Contents

- [Quick Start](quick-start.md) - Get started quickly
- [Common Patterns](common-patterns.md) - Frequently used patterns
- [API Reference](api-reference.md) - Detailed API documentation
- [Troubleshooting](troubleshooting.md) - Common issues and solutions
