"""Init file for reticle detection module."""
