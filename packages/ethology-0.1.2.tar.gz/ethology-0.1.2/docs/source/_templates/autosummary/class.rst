{{ name | escape | underline}}

.. currentmodule:: {{ module }}

.. autoclass:: {{ objname }}
   {% if objname != 'ValidDataset' %}:members:{% endif %}
   {% if objname != 'ValidDataset' %}:inherited-members:{% endif %}
   {% if objname == 'ValidBboxAnnotationsDataFrame' %}:exclude-members: Config{% endif %}

   {% block methods %}
   {% set ns = namespace(has_public_methods=false) %}

   {% if methods %}
   {% for item in methods %}
   {% if not item.startswith('_') %}
   {% set ns.has_public_methods = true %}
   {% endif %}
   {%- endfor %}
   {% endif %}

   {% if ns.has_public_methods %}
   .. rubric:: {{ _('Methods') }}

   .. autosummary::
   {% for item in methods %}
   {% if not item.startswith('_') %}
      ~{{ name }}.{{ item }}
   {% endif %}
   {%- endfor %}
   {% endif %}
   {% endblock %}

.. minigallery:: {{ module }}.{{ objname }}
   :add-heading: Examples using ``{{ objname }}``
