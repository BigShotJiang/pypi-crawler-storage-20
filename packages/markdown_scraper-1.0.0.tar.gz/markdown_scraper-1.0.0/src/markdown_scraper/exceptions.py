class ScraperError(Exception):
    """Base exception for LLM Scraper Client."""

    pass


class ScraperHTTPError(ScraperError):
    """Raised when the API returns an error response."""

    def __init__(self, status_code, message):
        self.status_code = status_code
        self.message = message
        super().__init__(f"HTTP {status_code}: {message}")
