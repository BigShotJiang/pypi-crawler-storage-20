from __future__ import annotations

import re
from typing import Literal

from .models import FilterOp, QueryAST, RuleOp, SelectorExpr


def serialize_dsl(ir: QueryAST, include_meta: bool = True) -> str:
    """
    Serializes a QueryAST object into a compact text DSL.
    Format: [checksum:][@engine:]<selector>[:filter...][ !mutation...][::rule...]
    """
    # 1. Engine
    engine_prefix = ""
    if ir.selector.engine != "css":
        engine_prefix = f"@{ir.selector.engine}:"

    # 2. Base Query
    if isinstance(ir.selector.expr, list):
        if (
            not ir.cleanup
            and not ir.filters
            and not ir.rules
            and all(" " not in x for x in ir.selector.expr)
        ):
            # Highly compact form for base-only simple fallbacks
            expr_str = "|".join(ir.selector.expr)
        else:
            expr_str = "(" + " | ".join(ir.selector.expr) + ")"
    else:
        expr_str = ir.selector.expr

    body = f"{engine_prefix}{expr_str}"

    # 3. Filters
    for f in ir.filters:
        if f.expr:
            body += f":{f.op}({f.expr})"
        else:
            body += f":{f.op}"

    # 4. Mutations (Cleanup)
    if ir.cleanup:
        for c in ir.cleanup:
            # Cleanup is always serialized without its own meta-prefix
            c_dsl = serialize_dsl(c, include_meta=False)
            body += f" !cleanup({c_dsl})"

    # 5. Rules (Actions)
    for r in ir.rules:
        if r.args:
            if isinstance(r.args, list):
                # Convert list args to comma separated quoted strings
                args_str = ", ".join(f"'{a}'" if isinstance(a, str) else str(a) for a in r.args)
                body += f"::{r.op}({args_str})"
            else:
                body += f"::{r.op}({r.args})"
        else:
            body += f"::{r.op}"

    if not include_meta:
        return body.strip()

    # Final wire format with checksum
    checksum = ir.checksum or "0000"
    return f"ast:{checksum}:{body}"


def deserialize_dsl(text: str) -> QueryAST:
    """
    Parses a DSL string into a QueryAST object.
    Supports DSL semantic tokens (@, !, :, ::).
    """
    text = text.strip()

    # Strip ast prefix and checksum if present
    checksum = None
    if text.startswith("ast:"):
        header_match = re.match(r"^ast:([a-f0-9]{4,8}|0000):(.*)$", text)
        if header_match:
            checksum = header_match.group(1)
            text = header_match.group(2)

    # Parse Engine
    engine: Literal["css", "xpath", "regex"] = "css"
    if text.startswith("@"):
        engine_match = re.match(r"^@([a-z]+):(.*)$", text)
        if engine_match:
            engine_val = engine_match.group(1).lower()
            if engine_val in ("css", "xpath", "regex"):
                engine = engine_val  # type: ignore[assignment]
                text = engine_match.group(2).strip()

    # Tokenize
    parts = _split_dsl_tokens(text)
    if not parts:
        raise ValueError("Empty DSL")

    # 1. Base Selector
    selector_part = parts[0]
    if selector_part.startswith("(") and selector_part.endswith(")"):
        selector_part = selector_part[1:-1].strip()

    if "|" in selector_part:
        selector_expr = [p.strip() for p in selector_part.split("|")]
    else:
        selector_expr = selector_part

    # 2. Sequential components
    filters = []
    rules = []
    cleanup = []

    for p in parts[1:]:
        if p.startswith("!"):
            # Mutation (Cleanup)
            name, args = _parse_op_with_args(p[1:])
            if name == "cleanup" and args:
                cleanup.append(deserialize_dsl(args))
            else:
                rules.append(RuleOp(op=name, args=args))
        elif p.startswith("::"):
            # Action
            name, args = _parse_op_with_args(p[2:])
            rules.append(RuleOp(op=name, args=args))
        elif p.startswith(":"):
            # Filter
            name, args = _parse_op_with_args(p[1:])
            filters.append(FilterOp(op=name, expr=args))
        else:
            # Trailing CSS
            val = p.strip()
            if val:
                filters.append(FilterOp(op="descendant", expr=val))

    return QueryAST(
        selector=SelectorExpr(engine=engine, expr=selector_expr),
        filters=filters,
        rules=rules,
        cleanup=cleanup if cleanup else None,
        version="1",
        checksum=checksum,
    )


def _split_dsl_tokens(text: str) -> list[str]:
    """Splits DSL into base selector and individual token segments (!, :, ::)."""
    parts = []
    depth = 0
    current = ""
    i = 0
    while i < len(text):
        char = text[i]
        next_char = text[i + 1] if i + 1 < len(text) else ""

        if depth == 0:
            is_token = False
            token_len = 0

            if char == "!" and not current.endswith("\\"):
                is_token = True
                token_len = 1
            elif char == ":" and next_char == ":":
                is_token = True
                token_len = 2
            elif char == ":":
                # Only treat as token if it looks like :op or :op(
                lookahead = text[i + 1 : i + 20]
                if re.match(r"^[a-z0-9_-]+(\(|$)", lookahead):
                    is_token = True
                    token_len = 1

            elif char.isspace() or char in ".[#*>+~":
                if parts and not current.strip():
                    i += 1
                    continue
                elif parts:
                    is_token = True
                    token_len = 0

            if is_token:
                if current.strip():
                    parts.append(current.strip())

                if token_len == 2:
                    current = "::"
                elif token_len == 1:
                    current = char
                else:
                    current = ""

                i += token_len
                continue

        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1

        current += char
        i += 1

    if current.strip():
        parts.append(current.strip())

    return parts


def _parse_op_with_args(text: str) -> tuple[str, str | None]:
    """Parses 'name(args)' or just 'name'."""
    match = re.match(r"^([a-z0-9_-]+)(?:\((.*)\))?$", text.strip(), re.I)
    if not match:
        return text.strip(), None
    return match.group(1).lower(), match.group(2)
