from __future__ import annotations

from typing import Literal

from .dsl import deserialize_dsl, serialize_dsl
from .models import FilterOp, QueryAST, RuleOp, SelectorExpr


class Q:
    """Fluent builder for Markdown Scraper Query AST."""

    def __init__(
        self,
        expr: str | list[str] | None = None,
        engine: Literal["css", "xpath", "regex"] = "css",
    ):
        self._selector = SelectorExpr(engine=engine, expr=expr or "")
        self._filters: list[FilterOp] = []
        self._rules: list[RuleOp] = []
        self._cleanup: list[QueryAST] = []

    def css(self, expr: str | list[str]) -> Q:
        self._selector = SelectorExpr(engine="css", expr=expr)
        return self

    def xpath(self, expr: str | list[str]) -> Q:
        self._selector = SelectorExpr(engine="xpath", expr=expr)
        return self

    def regex(self, expr: str | list[str]) -> Q:
        self._selector = SelectorExpr(engine="regex", expr=expr)
        return self

    # Filters
    def has(self, expr: str) -> Q:
        self._filters.append(FilterOp(op="has", expr=expr))
        return self

    def not_(self, expr: str) -> Q:
        self._filters.append(FilterOp(op="not", expr=expr))
        return self

    def contains(self, text: str) -> Q:
        self._filters.append(FilterOp(op="contains", expr=text))
        return self

    def icontains(self, text: str) -> Q:
        self._filters.append(FilterOp(op="icontains", expr=text))
        return self

    def matches(self, regex: str) -> Q:
        self._filters.append(FilterOp(op="matches", expr=regex))
        return self

    def near(self, query: str) -> Q:
        self._filters.append(FilterOp(op="near", expr=query))
        return self

    def parent(self) -> Q:
        self._filters.append(FilterOp(op="parent"))
        return self

    def children(self) -> Q:
        self._filters.append(FilterOp(op="children"))
        return self

    def closest(self, expr: str) -> Q:
        self._filters.append(FilterOp(op="closest", expr=expr))
        return self

    def ancestor(self, n: int = 1) -> Q:
        self._filters.append(FilterOp(op="ancestor", expr=str(n)))
        return self

    def next(self, n: int = 1) -> Q:
        self._filters.append(FilterOp(op="next", expr=str(n)))
        return self

    def prev(self, n: int = 1) -> Q:
        self._filters.append(FilterOp(op="prev", expr=str(n)))
        return self

    def descendant(self, expr: str) -> Q:
        self._filters.append(FilterOp(op="descendant", expr=expr))
        return self

    def semantic(self, query: str) -> Q:
        self._filters.append(FilterOp(op="semantic", expr=query))
        return self

    # Actions / Rules
    def text(self) -> Q:
        self._rules.append(RuleOp(op="text"))
        return self

    def html(self) -> Q:
        self._rules.append(RuleOp(op="html"))
        return self

    def markdown(self) -> Q:
        self._rules.append(RuleOp(op="markdown"))
        return self

    def attr(self, name: str) -> Q:
        self._rules.append(RuleOp(op="attr", args=name))
        return self

    def all(self) -> Q:
        self._rules.append(RuleOp(op="all"))
        return self

    def first(self) -> Q:
        self._rules.append(RuleOp(op="first"))
        return self

    def last(self) -> Q:
        self._rules.append(RuleOp(op="last"))
        return self

    def count(self) -> Q:
        self._rules.append(RuleOp(op="count"))
        return self

    def table(self) -> Q:
        self._rules.append(RuleOp(op="table"))
        return self

    def json(self) -> Q:
        self._rules.append(RuleOp(op="json"))
        return self

    def strip(self) -> Q:
        self._rules.append(RuleOp(op="strip"))
        return self

    def url(self) -> Q:
        self._rules.append(RuleOp(op="url"))
        return self

    def slice(self, start: int | str, end: int | None = None) -> Q:
        if isinstance(start, str) and ":" in start:
            # support .slice("1:5")
            self._rules.append(RuleOp(op="slice", args=start))
        else:
            self._rules.append(
                RuleOp(op="slice", args=[start, end] if end is not None else [start])
            )
        return self

    def join(self, sep: str = ", ") -> Q:
        self._rules.append(RuleOp(op="join", args=sep))
        return self

    def replace(self, old: str, new: str) -> Q:
        self._rules.append(RuleOp(op="replace", args=[old, new]))
        return self

    def split(self, sep: str, index: int | None = None) -> Q:
        if index is not None:
            self._rules.append(RuleOp(op="split", args=[sep, index]))
        else:
            self._rules.append(RuleOp(op="split", args=sep))
        return self

    # Cleanup
    def cleanup(self, *queries: str | Q | QueryAST) -> Q:
        for q in queries:
            if isinstance(q, str):
                self._cleanup.append(deserialize_dsl(q))
            elif isinstance(q, Q):
                self._cleanup.append(q.build())
            else:
                self._cleanup.append(q)
        return self

    def build(self) -> QueryAST:
        return QueryAST(
            selector=self._selector,
            filters=self._filters,
            rules=self._rules,
            cleanup=self._cleanup if self._cleanup else None,
        )

    def __or__(self, other: str | Q) -> Q:
        """
        Operator overload for Fallback (OR) logic on the Base Selector.
        Allows: (Q(".a") | ".b") or (Q(".a") | Q(".b"))
        """
        current_expr = self._selector.expr
        if isinstance(current_expr, str):
            expr_list = [current_expr] if current_expr else []
        else:
            expr_list = list(current_expr)

        if isinstance(other, str):
            if other not in expr_list:
                expr_list.append(other)
        elif isinstance(other, Q):
            other_expr = other._selector.expr
            if isinstance(other_expr, str):
                if other_expr and other_expr not in expr_list:
                    expr_list.append(other_expr)
            else:
                for ex in other_expr:
                    if ex not in expr_list:
                        expr_list.append(ex)

        self._selector = SelectorExpr(engine=self._selector.engine, expr=expr_list)
        return self

    def __str__(self) -> str:
        return serialize_dsl(self.build(), include_meta=False)
