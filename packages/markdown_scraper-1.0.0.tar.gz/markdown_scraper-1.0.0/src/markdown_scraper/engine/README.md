# Standardized Query Selectors (V2)

This package implements the **LLM-Scraper Query AST (Abstract Syntax Tree)** and the **Secure DSL** format. It is designed to be a portable, self-contained module that can be shared between the server and client SDKs.

## Core Concepts

### 1. QueryAST
The `QueryAST` is the structured representation of a scraping query. It consists of multiple `SelectorExpr` nodes. Each expression can contain:
- `selector`: The base element selection (Engine + Expression).
- `filters`: A list of filter operations (e.g., `:has`, `:contains`) that narrow down the selected nodes.
- `rules`: A list of transformation operations (e.g., `::text`, `::markdown`) that extract or modify data.
- `cleanup`: A list of nested `QueryAST` selectors to remove from the DOM *before* extraction.

### 2. Secure DSL
The DSL is a compact wire format intended for safe transmission.
Format: `v2:[hmac_short_checksum]:[payload]`

#### Security Rules:
- **Engine Enforcement**: Every query must specify an engine or default to `css`.
  - `css!selector`: Standard CSS.
  - `xpath!selector`: Full XPath 1.0/2.0 support.
  - `regex!selector`: Node discovery via dynamic ID/Class or text patterns.
- **HMAC Checksum**: Prevents unauthorized client-side query modification. The checksum is the first 8 characters of an HMAC-SHA256 signature using the `DSL_SIGNING_SECRET`.
- **Sandbox Isolation**: Double-colon `::` is restricted to system-defined actions. Users cannot define custom actions that execute arbitrary code.

## Grammar & Syntax

### Comparison: Engine vs Filter

It is important to distinguish between using an engine for **node discovery**, using native **CSS pseudo-classes**, and using our custom **filters**.

| Feature | Syntax | Purpose |
|---------|--------|---------|
| **Regex Engine** | `regex!.item-[0-9]+` | Finds a "root" node via pattern matching (best for dynamic IDs/classes). |
| **Native CSS Pseudos**| `li:nth-child(2)` | Passed directly to the C-native engine for high performance. |
| **Custom Filters** | `div:icontains('text')`| Smart Python-based filtering (e.g., substring match, tree walking). |

> **Note**: The parser is "smart"—it automatically detects standard CSS pseudo-classes (like `:nth-child`, `:first-child`, `:hover`) and keeps them in the base engine query for maximum speed. Only specific system-defined filters (like `:has`, `:icontains`) are intercepted and processed by the Python pipeline.

### Chaining with Filters (`:`) and Actions (`::`)
`engine!selector:filter(arg):filter::action(arg)::action`

Example:
`div.main:has(p):icontains('news')::all::markdown`
1. Select `div.main`.
2. Keep only if it contains a `p`.
3. Keep only if text contains 'news' (case-insensitive).
4. Select *all* matching elements (instead of just the first).
5. Convert the result to Markdown.

### Cleanup Segment `{ ... }`
Cleanup allows removing "noise" nodes (ads, nav, scripts) before the main extraction runs.
`article { .ads | .social | script } :: text`

## Specification for Client SDKs

### Supported Filters (`:`)
| Name | Syntax | Description |
|------|--------|-------------|
| `has` | `:has(selector)` | Matches if any descendant matches the selector. |
| `not` | `:not(selector)` | Excludes elements matching the selector. |
| `contains` | `:contains('text')` | Case-sensitive substring match in text content. |
| `icontains` | `:icontains('text')` | Case-insensitive substring match. |
| `matches` / `regex` | `:matches('re')` | Matches text content against a regular expression. |
| `closest` | `:closest(selector)` | Finds the nearest ancestor matching the selector. |
| `parent` | `:parent` | Navigate to the immediate parent node. |
| `children` | `:children` | Select all immediate children of current nodes. |
| `ancestor` | `:ancestor(n)` | Navigate `n` levels up the tree. |
| `descendant` | `:descendant(sel)` | Find matching descendants (scoped find). |
| `near` | `:near(sel)` | Spatial/Structural proximity (experimental). |
| `semantic` | `:semantic('query')`| Uses LLM/Embedding to find nodes by meaning. |

### Supported Actions/Rules (`::`)
| Name | Syntax | Description |
|------|--------|-------------|
| `text` | `::text` | Extract plain text content. |
| `html` | `::html` | Extract inner/outer HTML string. |
| `markdown` | `::markdown` | Convert HTML to clean, readable Markdown. |
| `attr` | `::attr('name')` | Extract a specific attribute value (e.g., `href`). |
| `all` | `::all` | Return a list of all matches instead of the first one. |
| `first` / `last` | `::first` | Pick the first or last node from the current set. |
| `slice` | `::slice(1,3)` | Return a range of found nodes. |
| `count` | `::count` | Return the number of matching items. |
| `table` | `::table` | Extract HTML tables into structured JSON. |
| `url` | `::url` | Resolve relative URLs to absolute based on base URL. |
| `strip` | `::strip` | Trim whitespace from extracted text. |
| `replace` | `::replace('a', 'b')`| Simple string replacement on extracted text. |
| `join` | `::join(', ')` | Join multiple results into a single string. |
| `remove` | `::remove` | Used in cleanup to delete matching nodes. |

## Query Units (Budgeting)
Every query has a computational cost measured in **Query Units**. Clients should calculate this locally to warn users about expensive queries.

**Formula:**
`QueryUnits = (SelectorCost + ΣFilterCosts) * DepthMultiplier * RuleMultiplier`

- **SelectorCost**: CSS=2, Regex=3, XPath=4.
- **FilterCosts**: `has`=3, `semantic`=5, others=1-2.
- **DepthMultiplier**: `1.0 + log2(traversed_depth)`.
- **RuleMultiplier**: `all`=2.0, `markdown`=2.0, others=1.0.

## Implementation Guide for New Clients

1. **Define Models**: Create `QueryAST`, `SelectorExpr`, `FilterOp`, and `RuleOp` structures (equivalent to the Pydantic models in `v2.py`).
2. **Implement Builder**: Provide a fluent API like `Q(".item").has("a").text()`.
3. **Serialization**:
    - Build the `payload` string: `engine!expr:filter::action`.
    - Calculate HMAC checkum: `hmac_sha256(secret, payload).hexdigest()[:8]`.
    - Prepend header: `v2:[checksum]:[payload]`.
4. **Validation**: Ensure `::` actions are only from the approved list to avoid server-side rejections.
