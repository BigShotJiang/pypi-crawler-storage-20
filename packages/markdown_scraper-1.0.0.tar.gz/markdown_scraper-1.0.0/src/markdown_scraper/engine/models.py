"""
Selector AST models for Markdown Scraper.
"""

from __future__ import annotations

import math
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .constants import ACTION_PSEUDOS_CLASSES, FILTER_PSEUDOS_CLASSES


class SelectorExpr(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    engine: Literal["css", "xpath", "regex"] = "css"
    expr: str | list[str]


class FilterOp(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    op: str
    expr: str | None = None

    @field_validator("op")
    @classmethod
    def check_op(cls, v: str) -> str:
        if v not in FILTER_PSEUDOS_CLASSES:
            raise ValueError(f"Unknown filter op '{v}'. Allowed: {FILTER_PSEUDOS_CLASSES}")
        return v


class RuleOp(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    op: str
    args: Any | None = None

    @field_validator("op")
    @classmethod
    def check_op(cls, v: str) -> str:
        if v not in ACTION_PSEUDOS_CLASSES:
            raise ValueError(f"Unknown rule op '{v}'. Allowed: {ACTION_PSEUDOS_CLASSES}")
        return v


class QueryAST(BaseModel):
    """
    Top-level AST for a single chained query.
    Standardized for Markdown Scraper protocol.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    # Core Query Components
    selector: SelectorExpr = Field(..., description="Base selector and engine selection")
    filters: list[FilterOp] = Field(default_factory=list, description="Ordered chain of filters")
    rules: list[RuleOp] = Field(default_factory=list, description="Ordered chain of output actions")

    # Cleanup / Pre-processing (New QueryAST list is the standard)
    cleanup: list[QueryAST] | None = Field(
        None, description="Nested QueryASTs applied to remove nodes before main selection"
    )

    # Metadata
    version: str = Field("1", description="AST Schema version")
    checksum: str | None = Field(None, description="Optional checksum for execution caching")

    def serialize(self, include_meta: bool = False) -> str:
        """Helper to serialize this AST to DSL."""
        from .dsl import serialize_dsl

        return serialize_dsl(self, include_meta=include_meta)

    @classmethod
    def from_dsl(cls, dsl: str) -> QueryAST:
        """Helper to create an AST from DSL string."""
        from .dsl import deserialize_dsl

        return deserialize_dsl(dsl)

    def calculate_query_units(self) -> int:
        """Calculate Query Units for this query (static estimate)."""
        # 1. Selector Cost
        engine_costs = {"css": 2, "xpath": 4, "regex": 3}

        # Base selector cost
        if isinstance(self.selector.expr, list):
            # Fallback list: sum costs of all alternatives
            # We assume most will be CSS (2 QU each)
            selector_cost = sum(
                engine_costs.get(self.selector.engine, 2) for _ in self.selector.expr
            )
        else:
            selector_cost = engine_costs.get(self.selector.engine, 2)

        # 2. Filter Cost
        filter_costs = {
            "has": 3,
            "not": 1,
            "parent": 2,
            "children": 2,
            "icontains": 1,
            "contains": 1,
            "matches": 2,
            "semantic": 5,
        }

        total_filter_cost = 0
        traversed_depth = 1

        for f in self.filters:
            total_filter_cost += filter_costs.get(f.op, 2)
            if f.op in ("parent", "children", "ancestor", "closest"):
                traversed_depth += 1

        # 3. Depth Multiplier
        depth_multiplier = 1.0 + math.log2(max(1, traversed_depth))

        # 4. Rule Multiplier
        rule_costs = {
            "first": 1,
            "all": 2,
            "markdown": 3,  # Markdown is expensive
            "html": 2,
            "text": 1,
            "remove": 2,
        }

        rule_multiplier = 1.0
        for r in self.rules:
            rule_multiplier *= rule_costs.get(r.op, 1)

        base_query_units = (selector_cost + total_filter_cost) * depth_multiplier * rule_multiplier

        # 5. Include Cleanup Costs
        cleanup_query_units = 0
        if self.cleanup:
            for c in self.cleanup:
                cleanup_query_units += c.calculate_query_units()

        return int(math.ceil(base_query_units + cleanup_query_units))


# Rebuild the model to resolve recursive string type 'QueryAST'
QueryAST.model_rebuild()
