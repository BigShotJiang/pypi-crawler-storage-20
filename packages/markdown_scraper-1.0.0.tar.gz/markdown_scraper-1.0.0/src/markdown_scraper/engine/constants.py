# Central list of pseudo-classes supported by the system
from __future__ import annotations

FILTER_PSEUDOS_CLASSES = [
    "icontains",
    "contains",
    "has",
    "not",
    "closest",
    "parent",
    "near",
    "matches",
    "semantic",
    "descendant",
    "children",
    "ancestor",
    "next",
    "prev",
]

ACTION_PSEUDOS_CLASSES = [
    "text",
    "html",
    "attr",
    "markdown",
    "url",
    "strip",
    "split",
    "replace",
    "table",
    "json",
    "first",
    "last",
    "slice",
    "count",
    "join",
    "all",
]
