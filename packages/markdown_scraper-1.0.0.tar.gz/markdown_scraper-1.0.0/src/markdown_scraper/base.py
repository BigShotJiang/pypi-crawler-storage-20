from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class BaseScraperClient:
    """
    Base shared configuration and logic for Markdown Scraper clients.
    """

    DEFAULT_BASE_URL = "https://api.markdownscraper.com"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ):
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.headers = {"Content-Type": "application/json"}
        if self.api_key:
            auth_header = (
                self.api_key if self.api_key.startswith("Bearer ") else f"Bearer {self.api_key}"
            )
            self.headers["Authorization"] = auth_header

    def _serialize_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        """Deeply serialize Q and QueryAST objects into DSL strings."""
        try:
            from .engine import Q, QueryAST
        except ImportError:
            # Fallback for environments where engine might not be available or during init
            return schema

        def _serialize_recursive(obj: Any) -> Any:
            if isinstance(obj, (Q, QueryAST)):
                return str(obj)
            if isinstance(obj, dict):
                return {k: _serialize_recursive(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_serialize_recursive(i) for i in obj]
            return obj

        return _serialize_recursive(schema)

    def _get_scrape_endpoint(self, namespace: str) -> str:
        """Map namespace to API endpoint."""
        if namespace in ["article", "product", "serp"]:
            return f"/{namespace}"
        return "/article"

    def _prepare_extract_payload(
        self, url: str, schema: dict[str, Any], **kwargs
    ) -> dict[str, Any]:
        """Prepare payload for /extract endpoint. Supports Q objects in schema."""
        return {"url": url, "schema": self._serialize_schema(schema), **kwargs}

    def _prepare_map_payload(
        self,
        url: str,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
    ) -> dict[str, Any]:
        """Prepare payload for /map endpoint."""
        return {
            "url": url,
            "depth": depth,
            "ignore_sitemap": ignore_sitemap,
            "selectors": selectors,
        }
