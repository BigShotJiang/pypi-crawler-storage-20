from __future__ import annotations

from pydantic import Field

from .base import CommonMetadata, ContentItem


class ArticleMetadata(CommonMetadata):
    authors: list[str] | None = Field(default_factory=list)
    tags: list[str] | None = Field(default_factory=list)
    topics: list[str] | None = Field(default_factory=list)
    main_points: list[str] | None = Field(
        default_factory=list, description="Key takeaways or main points"
    )


class ArticleContent(ContentItem):
    metadata: ArticleMetadata = Field(default_factory=ArticleMetadata)

    model_config = {
        "title": "ArticleContent",
    }
