from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field, HttpUrl, field_validator

from .base import CommonMetadata, ContentItem


class SerpResultType(str, Enum):
    ORGANIC = "organic"
    AD = "ad"
    FEATURED_SNIPPET = "featured_snippet"
    VIDEO = "video"
    NEWS = "news"
    IMAGE = "image"
    UNKNOWN = "unknown"


class SearchEngine(str, Enum):
    GOOGLE = "google"
    BING = "bing"
    BAIDU = "baidu"
    DUCKDUCKGO = "duckduckgo"
    YANDEX = "yandex"
    YAHOO = "yahoo"
    UNKNOWN = "unknown"


class SerpResultItem(BaseModel):
    """Individual search result item."""

    title: str | None = Field(default=None)
    url: HttpUrl = Field(description="The URL of the search result")
    snippet: str | None = Field(default=None, description="Short description or snippet")
    position: int = Field(default=0, description="Rank position in the SERP")
    type: SerpResultType = Field(default=SerpResultType.ORGANIC, description="Type of result")
    source: str | None = Field(default=None, description="Site name or domain of the result")

    @field_validator("url", mode="before")
    @classmethod
    def _normalize_url(cls, v):
        if v is None:
            return None
        return str(v)


class SerpMetadata(CommonMetadata):
    """Metadata specific to Search Engine Results Pages (SERP)."""

    query: str | None = Field(default=None, description="The search query used")
    engine: SearchEngine = Field(default=SearchEngine.GOOGLE, description="Search engine name")
    total_results: int | None = Field(default=None, description="Approximate total results count")
    search_time: float | None = Field(
        default=None, description="Time taken by the engine to return results"
    )
    location: str | None = Field(default=None, description="Geographical location for the search")
    page_number: int = Field(default=1, description="Page number of the results")


class SerpContent(ContentItem):
    metadata: SerpMetadata = Field(default_factory=SerpMetadata)
    results: list[SerpResultItem] = Field(
        default_factory=list, description="List of search results"
    )

    model_config = {
        "title": "SerpContent",
    }
