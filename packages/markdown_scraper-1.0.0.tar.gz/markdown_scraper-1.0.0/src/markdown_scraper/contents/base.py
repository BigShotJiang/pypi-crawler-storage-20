from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator


class Provenance(BaseModel):
    source_url: HttpUrl | None = Field(default=None, description="Canonical URL")
    domain: str | None = Field(default=None, description="Root domain (e.g., example.com)")

    @field_validator("source_url", mode="before")
    @classmethod
    def _normalize_source_url(cls, v):
        if v is None:
            return v
        return str(v)


class CommonMetadata(BaseModel):
    title: str | None = Field(default=None, description="Title of the content")
    description: str | None = Field(default=None, description="Brief summary or description")
    language: str | None = Field(default=None, description="ISO-639-1 (or BCP-47) language code")
    canonical_url: HttpUrl | None = Field(default=None, description="Canonical source URL")
    word_count: int | None = Field(default=None, description="Word count of the main content")
    reading_time_minutes: float | None = Field(
        default=None, description="Estimated reading time in minutes"
    )
    published_at: datetime | str | None = Field(
        default=None, description="When content was published"
    )
    modified_at: datetime | str | None = Field(
        default=None, description="When content was last modified"
    )
    inferred_source: str | None = Field(default=None, description="Detected source/site name")
    query_units: int = Field(
        default=0, description="Query Units (QU) consumed by parsing this item"
    )
    provenance: Provenance = Field(
        default_factory=Provenance, description="Source provenance information"
    )

    model_config = ConfigDict(
        populate_by_name=True,
        extra="forbid",
        frozen=False,
        arbitrary_types_allowed=True,
    )

    @field_validator("canonical_url", mode="before")
    @classmethod
    def _normalize_url(cls, v):
        if v is None:
            return None
        return str(v)


class ContentItem(BaseModel):
    id: str | None = Field(None, description="Unique identifier.")
    text: str | None = Field(None, description="Optional text content.")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Associated metadata.")
    created_timestamp: float | None = Field(default=None, description="Creation timestamp.")
    updated_timestamp: float | None = Field(default=None, description="Last update timestamp.")
    raw: str | None = Field(default=None, description="Raw HTML if explicitly requested/saved.")

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow",
        frozen=False,
        arbitrary_types_allowed=True,
    )
