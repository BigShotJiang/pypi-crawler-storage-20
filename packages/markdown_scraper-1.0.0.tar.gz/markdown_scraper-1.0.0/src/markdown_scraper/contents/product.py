from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl

from .base import CommonMetadata, ContentItem


class ProductAvailability(str, Enum):
    IN_STOCK = "in_stock"
    OUT_OF_STOCK = "out_of_stock"
    PRE_ORDER = "pre_order"
    DISCONTINUED = "discontinued"
    UNKNOWN = "unknown"


class ProductPrice(BaseModel):
    currency: str | None = Field(
        default=None, description="ISO 4217 currency code (e.g., USD, VND)"
    )
    amount: float | None = Field(default=None, ge=0, description="Price value")
    list_price: float | None = Field(
        default=None, ge=0, description="Original/list price before discount"
    )
    availability: ProductAvailability | None = Field(
        default=None, description="Availability status"
    )
    sku: str | None = Field(default=None, description="Stock keeping unit")
    discount_percentage: float | None = Field(
        default=None, description="Calculated discount percentage"
    )
    model_config = {"frozen": False}


class ProductReview(BaseModel):
    rating: float | None = Field(default=None, ge=0, le=5, description="Review rating 0..5 stars")
    count: int | None = Field(default=None, ge=0, description="Number of reviews")
    avg_rating: float | None = Field(default=None, ge=0, le=5, description="Average rating")
    model_config = {"frozen": False}


class ProductVariant(BaseModel):
    id: str | None = Field(default=None)
    name: str | None = Field(default=None, description="Variant name (e.g. Color: Red, Size: XL)")
    sku: str | None = Field(default=None)
    price: ProductPrice | None = Field(default=None)
    images: list[HttpUrl] = Field(default_factory=list)
    is_available: bool = Field(default=True)


class ProductSeller(BaseModel):
    name: str | None = Field(
        default=None, description="Seller name (e.g. Amazon, 3rd party seller)"
    )
    id: str | None = Field(default=None)
    rating: float | None = Field(default=None)
    url: HttpUrl | None = Field(default=None)


class ProductMetadata(CommonMetadata):
    brand: str | None = Field(default=None, description="Product brand/manufacturer")
    category: list[str] | None = Field(default_factory=list, description="Product categories")
    sku: str | None = Field(default=None, description="Stock keeping unit")
    gtin: str | None = Field(default=None, description="GTIN/EAN/UPC identifier")
    tags: list[str] | None = Field(default_factory=list, description="Product tags/keywords")
    features: list[str] = Field(default_factory=list, description="Product features/bullet points")
    specs: dict[str, Any] | None = Field(
        default=None, description="Product specifications (key-value pairs)"
    )
    price: ProductPrice | None = Field(default=None, description="Pricing information")
    review: ProductReview | None = Field(default=None, description="Review and rating data")
    images: list[HttpUrl] | None = Field(default_factory=list, description="Product image URLs")
    seller: ProductSeller | None = Field(default=None)
    variants: list[ProductVariant] = Field(default_factory=list)


class ProductContent(ContentItem):
    metadata: ProductMetadata = Field(
        default_factory=ProductMetadata, description="Product-specific metadata"
    )
