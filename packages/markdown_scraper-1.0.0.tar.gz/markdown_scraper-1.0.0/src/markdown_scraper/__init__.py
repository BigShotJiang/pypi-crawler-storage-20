from __future__ import annotations

from .client import AsyncClient, MarkdownScraperClient, SyncClient
from .engine import Q, QueryAST
from .exceptions import ScraperError, ScraperHTTPError
from .validator import ScraperQueryResponse, ScraperQuerySchema

# Legacy support
AsyncMarkdownScraperClient = AsyncClient

__all__ = [
    "AsyncClient",
    "SyncClient",
    "MarkdownScraperClient",
    "AsyncMarkdownScraperClient",
    "ScraperError",
    "ScraperHTTPError",
    "Q",
    "QueryAST",
    "ScraperQuerySchema",
    "ScraperQueryResponse",
]
