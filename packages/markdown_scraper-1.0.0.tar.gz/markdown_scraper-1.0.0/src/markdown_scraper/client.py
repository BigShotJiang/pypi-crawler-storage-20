from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import httpx

from .base import BaseScraperClient
from .exceptions import ScraperHTTPError

logger = logging.getLogger(__name__)


try:
    from .contents import ArticleContent, ProductContent, SerpContent

    _HAS_CONTENT_MODELS = True
except ImportError:
    _HAS_CONTENT_MODELS = False


class AsyncClient(BaseScraperClient):
    """
    Asynchronous Python client for Markdown Scraper API.
    Transforms simple scraping into a Discovery-Driven Extraction pipeline.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        **client_kwargs,
    ):
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout)
        self.client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout,
            follow_redirects=True,
            **client_kwargs,
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self):
        await self.client.aclose()

    async def _request(self, method: str, endpoint: str, **kwargs) -> dict[str, Any]:
        try:
            response = await self.client.request(method, endpoint.lstrip("/"), **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP Error: {e.response.status_code} - {e.response.text}")
            raise ScraperHTTPError(e.response.status_code, e.response.text) from e
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            raise

    async def health(self) -> dict[str, Any]:
        """Check server health."""
        return await self._request("GET", "/health")

    async def scrape(self, url: str, namespace: str = "article", **kwargs) -> dict[str, Any]:
        """Scrapes a single URL using a specific namespace (article, product, etc.)."""
        endpoint = self._get_scrape_endpoint(namespace)
        return await self._request("POST", endpoint, json={"url": url, **kwargs})

    async def article(self, url: str, **kwargs) -> dict[str, Any] | ArticleContent:
        """Shortcut for scraping an Article."""
        res = await self.scrape(url, namespace="article", **kwargs)
        if _HAS_CONTENT_MODELS:
            return ArticleContent.model_validate(res["data"])
        return res

    async def product(self, url: str, **kwargs) -> dict[str, Any] | ProductContent:
        """Shortcut for scraping a Product."""
        res = await self.scrape(url, namespace="product", **kwargs)
        if _HAS_CONTENT_MODELS:
            return ProductContent.model_validate(res["data"])
        return res

    async def serp(self, url: str, **kwargs) -> dict[str, Any] | SerpContent:
        """Shortcut for scraping Search Engine Results (SERP)."""
        res = await self.scrape(url, namespace="serp", **kwargs)
        if _HAS_CONTENT_MODELS:
            return SerpContent.model_validate(res["data"])
        return res

    async def extract(
        self,
        url: str,
        schema: dict[str, Any],
        version: str | None = None,
        checksum: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """Scrapes a URL and extracts custom fields based on a JSON schema."""
        payload = self._prepare_extract_payload(url, schema, **kwargs)
        headers = {}
        if version:
            headers["X-Version"] = version
        if checksum:
            headers["X-Checksum"] = checksum

        return await self._request("POST", "/extract", json=payload, headers=headers)

    async def validate_dsl(self, dsl: str) -> dict[str, Any]:
        """Validates a single DSL string and returns AST and signature headers."""
        response = await self.client.request("OPTIONS", "/validate/dsl", json={"dsl": dsl})
        response.raise_for_status()
        data = response.json() if response.status_code != 204 else {}
        data["version"] = response.headers.get("X-Version")
        data["checksum"] = response.headers.get("X-Checksum")
        qu = response.headers.get("X-Query-Units")
        if qu:
            data["query_units"] = int(qu)
        return data

    async def validate_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        """Validates an entire extraction schema and returns version/checksum headers."""
        response = await self.client.request(
            "OPTIONS", "/validate/dsl", json={"schema": self._serialize_schema(schema)}
        )
        response.raise_for_status()
        data = response.json() if response.status_code != 204 else {}
        data["version"] = response.headers.get("X-Version")
        data["checksum"] = response.headers.get("X-Checksum")
        qu = response.headers.get("X-Query-Units")
        if qu:
            data["query_units"] = int(qu)
        return data

    async def discover(
        self,
        url: str,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
        **kwargs,
    ) -> list[dict[str, Any]]:
        """
        Discovery (The "Map" phase): Finds URLs via sitemaps, RSS, or link discovery.
        Returns a list of discovery objects {url, title, type, metadata}.
        """
        payload = self._prepare_map_payload(url, depth, ignore_sitemap, selectors)
        payload.update(kwargs)
        resp = await self._request("POST", "/map", json=payload)
        return resp.get("urls", [])

    async def get_result(self, result_id: str) -> dict[str, Any]:
        """Fetch a single persisted result by its ID."""
        return await self._request("GET", f"/results/{result_id}")

    async def farm(
        self,
        items: list[str] | list[dict[str, Any]],
        concurrency: int = 5,
        namespace: str = "article",
        **kwargs,
    ) -> AsyncIterator[dict[str, Any]]:
        """
        Farming (Micro-Orchestration): Concurrently scrapes a list of URLs or DiscoveryItems.
        Yields results one by one as they become available.
        """
        queue: asyncio.Queue[str] = asyncio.Queue()
        for item in items:
            url = item if isinstance(item, str) else item.get("url")
            if url:
                await queue.put(url)

        if queue.empty():
            return

        results_queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()
        semaphore = asyncio.Semaphore(concurrency)
        processed_urls: set[str] = set()

        async def worker():
            while not queue.empty():
                target_url = await queue.get()
                if target_url in processed_urls:
                    queue.task_done()
                    continue

                async with semaphore:
                    try:
                        result = await self.scrape(target_url, namespace=namespace, **kwargs)
                        processed_urls.add(target_url)
                        if result:
                            await results_queue.put(result)
                    except Exception as e:
                        logger.error(f"Failed to farm {target_url}: {e}")
                    finally:
                        queue.task_done()
            await results_queue.put(None)

        num_workers = min(concurrency, queue.qsize())
        tasks = [asyncio.create_task(worker()) for _ in range(num_workers)]

        workers_active = num_workers
        while workers_active > 0:
            res = await results_queue.get()
            if res is None:
                workers_active -= 1
            else:
                yield res

        await asyncio.gather(*tasks)

    async def discover_and_farm(
        self,
        seed_url: str,
        filter_func: Callable[[dict[str, Any]], bool] | None = None,
        concurrency: int = 5,
        depth: int = 1,
        namespace: str = "article",
        **kwargs,
    ) -> AsyncIterator[dict[str, Any]]:
        """High-level pipeline: Discover -> Filter -> Farm."""
        items = await self.discover(seed_url, depth=depth)
        if filter_func:
            items = [item for item in items if filter_func(item)]

        async for result in self.farm(
            items, concurrency=concurrency, namespace=namespace, **kwargs
        ):
            yield result


class SyncClient(BaseScraperClient):
    """
    Synchronous Python client for Markdown Scraper API.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
        **client_kwargs,
    ):
        super().__init__(api_key=api_key, base_url=base_url, timeout=timeout)
        self.client = httpx.Client(
            base_url=self.base_url,
            headers=self.headers,
            timeout=self.timeout,
            follow_redirects=True,
            **client_kwargs,
        )

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self):
        self.client.close()

    def _request(self, method: str, endpoint: str, **kwargs) -> dict[str, Any]:
        try:
            response = self.client.request(method, endpoint.lstrip("/"), **kwargs)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP Error: {e.response.status_code} - {e.response.text}")
            raise ScraperHTTPError(e.response.status_code, e.response.text) from e
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            raise

    def health(self) -> dict[str, Any]:
        """Check server health."""
        return self._request("GET", "/health")

    def scrape(self, url: str, namespace: str = "article", **kwargs) -> dict[str, Any]:
        """Scrapes a single URL using a specific namespace (article, product, etc.)."""
        endpoint = self._get_scrape_endpoint(namespace)
        return self._request("POST", endpoint, json={"url": url, **kwargs})

    def article(self, url: str, **kwargs) -> dict[str, Any] | ArticleContent:
        """Shortcut for scraping an Article."""
        res = self.scrape(url, namespace="article", **kwargs)
        if _HAS_CONTENT_MODELS:
            return ArticleContent.model_validate(res["data"])
        return res

    def product(self, url: str, **kwargs) -> dict[str, Any] | ProductContent:
        """Shortcut for scraping a Product."""
        res = self.scrape(url, namespace="product", **kwargs)
        if _HAS_CONTENT_MODELS:
            return ProductContent.model_validate(res["data"])
        return res

    def serp(self, url: str, **kwargs) -> dict[str, Any] | SerpContent:
        """Shortcut for scraping Search Engine Results (SERP)."""
        res = self.scrape(url, namespace="serp", **kwargs)
        if _HAS_CONTENT_MODELS:
            return SerpContent.model_validate(res["data"])
        return res

    def extract(
        self,
        url: str,
        schema: dict[str, Any],
        version: str | None = None,
        checksum: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """Scrapes a URL and extracts custom fields based on a JSON schema."""
        payload = self._prepare_extract_payload(url, schema, **kwargs)
        headers = {}
        if version:
            headers["X-Version"] = version
        if checksum:
            headers["X-Checksum"] = checksum

        return self._request("POST", "/extract", json=payload, headers=headers)

    def validate_dsl(self, dsl: str) -> dict[str, Any]:
        """Validates a single DSL string and returns AST and signature headers."""
        response = self.client.request("OPTIONS", "/validate/dsl", json={"dsl": dsl})
        response.raise_for_status()
        data = response.json() if response.status_code != 204 else {}
        data["version"] = response.headers.get("X-Version")
        data["checksum"] = response.headers.get("X-Checksum")
        qu = response.headers.get("X-Query-Units")
        if qu:
            data["query_units"] = int(qu)
        return data

    def validate_schema(self, schema: dict[str, Any]) -> dict[str, Any]:
        """Validates an entire extraction schema and returns version/checksum headers."""
        response = self.client.request(
            "OPTIONS", "/validate/dsl", json={"schema": self._serialize_schema(schema)}
        )
        response.raise_for_status()
        data = response.json() if response.status_code != 204 else {}
        data["version"] = response.headers.get("X-Version")
        data["checksum"] = response.headers.get("X-Checksum")
        qu = response.headers.get("X-Query-Units")
        if qu:
            data["query_units"] = int(qu)
        return data

    def discover(
        self,
        url: str,
        depth: int = 1,
        ignore_sitemap: bool = False,
        selectors: list[str] | None = None,
        **kwargs,
    ) -> list[dict[str, Any]]:
        """Discovery: Finds URLs via sitemaps, RSS, or link discovery."""
        payload = self._prepare_map_payload(url, depth, ignore_sitemap, selectors)
        payload.update(kwargs)
        resp = self._request("POST", "/map", json=payload)
        return resp.get("urls", [])

    def get_result(self, result_id: str) -> dict[str, Any]:
        """Fetch a single persisted result by its ID."""
        return self._request("GET", f"/results/{result_id}")

    def farm(
        self,
        items: list[str] | list[dict[str, Any]],
        concurrency: int = 5,
        namespace: str = "article",
        **kwargs,
    ) -> Iterator[dict[str, Any]]:
        """
        Farming: Concurrently scrapes a list of URLs using a thread pool.
        """
        urls = []
        for item in items:
            url = item if isinstance(item, str) else item.get("url")
            if url:
                urls.append(url)

        if not urls:
            return

        def _scrape_worker(u: str):
            try:
                return self.scrape(u, namespace=namespace, **kwargs)
            except Exception as e:
                logger.error(f"Failed to farm {u}: {e}")
                return None

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            future_to_url = {executor.submit(_scrape_worker, u): u for u in urls}
            for future in as_completed(future_to_url):
                result = future.result()
                if result:
                    yield result

    def discover_and_farm(
        self,
        seed_url: str,
        filter_func: Callable[[dict[str, Any]], bool] | None = None,
        concurrency: int = 5,
        depth: int = 1,
        namespace: str = "article",
        **kwargs,
    ) -> Iterator[dict[str, Any]]:
        """High-level pipeline: Discover -> Filter -> Farm."""
        items = self.discover(seed_url, depth=depth)
        if filter_func:
            items = [item for item in items if filter_func(item)]

        yield from self.farm(items, concurrency=concurrency, namespace=namespace, **kwargs)


# Alias for legacy or default usage
MarkdownScraperClient = AsyncClient
