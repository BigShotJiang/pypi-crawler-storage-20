from __future__ import annotations

from pydantic import BaseModel, Field

from .engine import QueryAST


class ScraperQuerySchema(BaseModel):
    """
    Standard API Schema for accepting and validating User DSL.
    When a user sends a DSL string, this schema parses it,
    calculates metadata, and returns the full AST.
    """

    dsl: str = Field(..., description="The Pseudo-DSL query string from user")

    def validate_and_process(self) -> ScraperQueryResponse:
        """
        Parses the DSL into a validated QueryAST with checksum and metadata.
        """
        # 1. Parse (Raises ValueError/Pydantic errors if invalid)
        ast = QueryAST.from_dsl(self.dsl)

        return ScraperQueryResponse(
            ast=ast,
            normalized_dsl=ast.serialize(include_meta=False),
            query_units=ast.calculate_query_units(),
            checksum=ast.checksum or "",
            version=ast.version,
        )


class ScraperQueryResponse(BaseModel):
    """
    Standard API Response for DSL Validation.
    """

    ast: QueryAST = Field(..., description="The full parsed AST object")
    normalized_dsl: str = Field(..., description="The DSL string in its standard format")
    query_units: int = Field(..., description="Estimated cost of this query")
    version: str = Field(..., description="AST Schema version")
    checksum: str = Field(..., description="Unique hash of the query structure")
