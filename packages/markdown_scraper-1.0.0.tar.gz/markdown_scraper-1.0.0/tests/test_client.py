from markdown_scraper import QueryAST


def test_client_init():
    from markdown_scraper import SyncClient

    client = SyncClient(base_url="http://localhost:8001", api_key="secret")
    assert client.base_url == "http://localhost:8001"
    assert client.headers["Authorization"] == "Bearer secret"


def test_client_header_normalization():
    from markdown_scraper import SyncClient

    client = SyncClient(base_url="http://test", api_key="Bearer already-has")
    assert client.headers["Authorization"] == "Bearer already-has"


def test_async_client_init():
    from markdown_scraper import AsyncClient

    client = AsyncClient(base_url="http://localhost:8001", api_key="secret")
    assert client.base_url == "http://localhost:8001"
    assert client.headers["Authorization"] == "Bearer secret"


def test_query_ast_conversion():
    dsl = "div:has(p)::markdown"
    ast = QueryAST.from_dsl(dsl)
    assert ast.selector.expr == "div"
    assert ast.filters[0].op == "has"
    assert ast.rules[0].op == "markdown"
    assert ast.serialize().strip() == dsl.strip()


def test_client_schema_serialization():
    from markdown_scraper import Q, SyncClient

    client = SyncClient(api_key="test")
    schema = {
        "title": Q(".title").text(),
        "tags": Q(".tag").all().text(),
        "metadata": {"author": Q(".author").text()},
    }

    serialized = client._serialize_schema(schema)
    assert serialized["title"] == ".title::text"
    assert serialized["tags"] == ".tag::all::text"
    assert serialized["metadata"]["author"] == ".author::text"
