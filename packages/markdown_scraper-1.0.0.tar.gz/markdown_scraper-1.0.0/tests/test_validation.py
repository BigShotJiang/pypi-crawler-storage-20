from markdown_scraper import ScraperQuerySchema


def test_dsl_validation_flow():
    # User sends a DSL string
    user_dsl = "article:has(p) ::markdown"

    # 1. API receives it via ScraperQuerySchema
    schema = ScraperQuerySchema(dsl=user_dsl)

    # 2. Process and Validate
    response = schema.validate_and_process()

    print(f"Normalized DSL: {response.normalized_dsl}")
    print(f"Checksum: {response.checksum}")
    print(f"Query Units: {response.query_units}")
    print(f"Version: {response.version}")

    assert response.version == "1"
    assert response.checksum == ""  # Checksum comes from server in real usage
    assert response.query_units > 0
    assert response.ast.selector.expr == "article"


if __name__ == "__main__":
    try:
        test_dsl_validation_flow()
        print("\nValidation Test Passed!")
    except Exception as e:
        print(f"\nValidation Test Failed: {e}")
        import traceback

        traceback.print_exc()
