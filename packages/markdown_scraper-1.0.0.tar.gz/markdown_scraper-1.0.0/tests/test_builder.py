from markdown_scraper import Q, QueryAST


def test_basic_css():
    q = Q().css("div").text()
    assert str(q) == "div::text"


def test_chaining_filters():
    q = Q().css("div").has("p").icontains("test").all().markdown()
    assert str(q) == "div:has(p):icontains(test)::all::markdown"


def test_xpath_engine():
    q = Q().xpath("//h1").attr("id")
    assert str(q) == "@xpath://h1::attr(id)"


def test_cleanup():
    q = Q().css("article").cleanup(Q().css(".ads"), Q().css("script")).text()
    assert str(q) == "article !cleanup(.ads) !cleanup(script)::text"

    # Test Deserialization
    ast = QueryAST.from_dsl(str(q))
    assert ast.selector.expr == "article"
    assert len(ast.cleanup) == 2
    assert ast.cleanup[0].selector.expr == ".ads"
    assert ast.cleanup[1].selector.expr == "script"
    assert len(ast.rules) == 1


def test_complex_args():
    q = Q().css("p").replace("old", "new").join(" | ")
    assert str(q) == "p::replace('old', 'new')::join( | )"


def test_list_base_selector():
    q = Q().css([".a", ".b", "#main"]).text()
    assert str(q) == "(.a | .b | #main)::text"

    # Test Deserialization
    ast = QueryAST.from_dsl(str(q))
    assert ast.selector.expr == [".a", ".b", "#main"]


def test_user_requested_format():
    dsl = ".a|.b|.c:has(p) ::markdown"
    ast = QueryAST.from_dsl(dsl)
    assert ast.selector.expr == [".a", ".b", ".c"]
    assert ast.filters[0].op == "has"
    assert ast.rules[0].op == "markdown"
    # Re-serialization should be compact
    assert ast.serialize() == "(.a | .b | .c):has(p)::markdown"


def test_operator_or():
    # Test (Q | str)
    q = (Q(".content") | ".article").text()
    assert str(q) == "(.content | .article)::text"

    # Test (Q | Q)
    q2 = (Q("h1") | Q("h2")).all()
    assert str(q2) == "(h1 | h2)::all"

    # Test Chained OR
    q3 = (Q(".a") | ".b" | ".c").has("p").markdown()
    assert str(q3) == "(.a | .b | .c):has(p)::markdown"


def test_next_prev():
    q = Q(".card").next().prev(2).markdown()
    assert str(q) == ".card:next(1):prev(2)::markdown"

    ast = QueryAST.from_dsl(str(q))
    assert ast.filters[0].op == "next"
    assert ast.filters[0].expr == "1"
    assert ast.filters[1].op == "prev"
    assert ast.filters[1].expr == "2"


def test_semantic_and_near():
    q = Q(".article").semantic("main topic").near("footer").text()
    assert str(q) == ".article:semantic(main topic):near(footer)::text"


def test_hierarchy_filters():
    q = Q("span").parent().closest("div").ancestor(2).children().text()
    assert str(q) == "span:parent:closest(div):ancestor(2):children::text"
