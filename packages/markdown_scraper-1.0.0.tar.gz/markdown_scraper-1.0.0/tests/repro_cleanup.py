from markdown_scraper import QueryAST


def test_cleanup_deserialization():
    dsl = "article { .ads | script } ::text"
    ast = QueryAST.from_dsl(dsl)

    assert ast.selector.expr == "article"
    assert ast.cleanup is not None
    assert len(ast.cleanup) == 2
    assert ast.cleanup[0].selector.expr == ".ads"
    assert ast.cleanup[1].selector.expr == "script"
    assert len(ast.rules) == 1
    assert ast.rules[0].op == "text"


if __name__ == "__main__":
    try:
        test_cleanup_deserialization()
        print("Test Passed!")
    except Exception as e:
        print(f"Test Failed: {e}")
        import traceback

        traceback.print_exc()
