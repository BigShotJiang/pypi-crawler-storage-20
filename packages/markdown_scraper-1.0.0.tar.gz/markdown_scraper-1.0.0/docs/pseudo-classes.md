# 🎯 Pseudo-Classes Guide

Advance your scraping with powerful custom pseudo-classes. These extensions allow for semantic selection and complex filtering that standard CSS cannot handle.

!!! executive "The Sequential Pipeline"
    The engine executes queries in a strict, logical order. Every query flows from left to right as a data stream:
    **Base Selector** ➜ **Filters** ➜ **Mutations** ➜ **Actions**.

---

## 🔗 Chained Syntax Overview

The Chained Pseudo-DSL is the core of our "Micro-Orchestrator" philosophy. It allows you to package complex extraction logic into a single string.

`[@engine:]selector:filter!mutation::action`

### The Component Stack
| Stage | Prefix | Role | Pro Tip |
| :--- | :--- | :--- | :--- |
| **Engine** | `@` | **Discovery** | Use `@regex:` for elements with dynamic IDs. |
| **Selector**| | **Targeting** | Start broad, then narrow down using filters. |
| **Filter** | `:` | **Logic** | Chain multiple `:not()` and `:has()` for precision. |
| **Mutation** | `!` | **Preparation**| Purge noise (ads, nav) before conversion. |
| **Action** | `::` | **Outcome** | Convert to `::markdown` for LLM consumption. |

---

## 📚 Filter Reference (`:`)

Filters reduce the set of selected nodes based on content or DOM relationships.

### 1. Text & Content
*   **`:contains('text')`**: Case-sensitive substring match.
*   **`:icontains('text')`**: **(Preferred)** Case-insensitive match. Robust against web content variations.
*   **`:matches('regex')`**: Match text content against a Regular Expression.
    *   *Example*: `span:matches('\d{4}-\d{2}')` for ISO dates.

### 2. Hierarchy & Siblings
*   **`:parent`**: Jump to the immediate parent.
*   **`:ancestor(n)`**: Jump exactly `N` levels up the tree.
*   **`:closest(selector)`**: Climb the tree until it finds a match. Extremely useful for finding container boxes.
*   **`:children`**: Select all immediate children.
*   **`:next`**: Move to the immediate **following sibling**.
*   **`:prev`**: Move to the immediate **previous sibling**.
*   **`:near(selector)`**: Matches if any sibling matches the selector (Experimental).

### 3. Logic & AI Density
*   **`:has(selector)`**: Only keep nodes that contain a specific descendant.
*   **`:not(selector)`**: Exclude nodes matching the criteria.
*   **`:semantic('auto')`**: Uses AI-density heuristics to ignore nav/footers and find the "main content" cluster automatically.

---

## 🛠️ Mutations Reference (`!`)

Mutations are "side-effect" filters. They physically modify the DOM branch currently being processed.

| Mutation | Example | Purpose |
| :--- | :--- | :--- |
| `!cleanup(sel)` | `!cleanup(.ads, script)` | Permanently removes specified children from the current scope. |

---

## ⚡ Action Reference (`::`)

Actions take the resulting nodes and produce final values. You can chain actions (e.g., `::text::strip::replace`).

### Extraction
*   **`::text`**: Extract normalized plain text.
*   **`::html`**: Extract inner/outer HTML.
*   **`::markdown`**: High-fidelity HTML to Markdown conversion.
*   **`::url`**: Resolves `src` or `href` to absolute URLs (supports lazy-load attributes).

### Formatting
*   **`::strip`**: Trim whitespace (optional chars argument).
*   **`::split(sep, index)`**: Split string and take a specific part.
*   **`::replace(old, new)`**: Standard or Regex replacement.

### Collection Operations
*   **`::first` / `::last`**: Keep only the first or last item in the list.
*   **`::slice(start, end)`**: Select a range of items.
*   **`::count`**: Return the number of matching items.
*   **`::join(sep)`**: Flatten a list of strings into one.
*   **`::all`**: Ensure the result is always a list (even for single matches).

---

## 🏗️ Full Pipeline Demo

Observe how a complex query flows through the stages:

**Query**:
`@regex:article-.* :has(h1) !cleanup(.ad-box) :next ::markdown`

**Visual Flow**:
1.  **Engine Discovery** (`@regex:`)  ➔ Finds all nodes matching the regex pattern.
2.  **Logical Filter** (`:has(h1)`) ➔ Drops any article that doesn't have a title.
3.  **Surgical Mutation** (`!cleanup`) ➔ Physically deletes ads from the DOM branch.
4.  **Spatial Shift** (`:next`) ➔ Moves focus to the element immediately following the article (e.g., "Related Reading").
5.  **Final Action** (`::markdown`) ➔ Converts that related reading section to Markdown.

---

## 🎯 Pro Tips
- **Chain ordering matters**: Filtering *before* mutating is faster.
- **Deduplication**: Filters like `:parent` and `:closest` automatically deduplicate results.
- **Native Speed**: `:nth-child` and `:first-of-type` are recognized as "Native CSS" and run at C-speed.
