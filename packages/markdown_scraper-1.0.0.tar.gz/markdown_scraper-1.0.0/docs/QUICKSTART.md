# 🚀 Quickstart Guide

Get started with the Markdown Scraper SDK in under 5 minutes.

## 1. Installation

```bash
# Using uv (Recommended)
uv add markdown-scraper

# Using pip
pip install markdown-scraper
```

## 2. Basic Extraction

The simplest way to extract clean markdown from any URL.

```python
import asyncio
from markdown_scraper import AsyncClient

async def main():
    async with AsyncClient(api_key="your_api_key") as client:
        # Standard article extraction
        result = await client.article("https://techcrunch.com/2024/01/01/sample-post")
        print(result.markdown)

asyncio.run(main())
```

## 3. Custom Schema Extraction

For complex sites, define a schema using the fluent `Q` builder.

```python
from markdown_scraper import AsyncClient, Q

my_schema = {
    "title": Q("h1").text(),
    "content": Q(".article-body").cleanup(".ads").markdown(),
    "tags": Q(".tags a").all().text()
}

async def scrape_custom():
    async with AsyncClient(api_key="your_api_key") as client:
        result = await client.extract("https://example.com/blog/1", schema=my_schema)
        print(result["data"]["title"])
```

## 4. Scaling with Discovery & Farm

Don't just scrape one page—harvest the whole site.

```python
async def harvest():
    async with AsyncClient(api_key="your_api_key") as client:
        # 1. Map the site
        urls = await client.discover("https://example.com/blog", depth=1)

        # 2. Harvest in parallel
        async for result in client.farm(urls, concurrency=10, schema=my_schema):
            save_result(result)
```

## 5. Production Optimization

Use `validate_schema` to get a checksum. This ensures the server uses a pre-optimized path for your queries.

```python
# During initialization
validation = await client.validate_schema(my_schema)
MY_CHECKSUM = validation["checksum"]

# During extraction
result = await client.extract(url, schema=my_schema, checksum=MY_CHECKSUM)
```

## Next Steps
- Explore the [API Reference](api.md)
- Learn about the [V1 Chained Protocol](dsl.md)
- Read about [Enterprise Scaling](scale.md)
