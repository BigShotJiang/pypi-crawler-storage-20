# 🧶 Markdown Scraper SDK: Micro-Orchestrator

Welcome to the professional Python documentation for the **Markdown Scraper SDK**. This library is engineered for RAG (Retrieval-Augmented Generation), LLM fine-tuning, and high-scale enterprise data extraction.

---

## 🏛️ Architecture: The Micro-Orchestrator Pattern

Most web scrapers operate as centralized bottlenecks. Markdown Scraper shifts the paradigm by treating the SDK as a **Micro-Orchestrator**.

1. **Local Intelligence**: The SDK manages concurrency, retry logic, and URL discovery on the edge (your infrastructure).
2. **Deterministic DSL**: Our **V1 Chained Protocol** ensures that the server performs purely functional extraction, leading to sub-millisecond execution.
3. **State-Free Extraction**: Avoid complex browser session management. The SDK delivers raw, high-fidelity data ready for your vectors.

---

## 🚀 Enterprise Workflows

### 🌳 Map-Farm Pattern
The cornerstone of high-scale extraction.
- **Map**: Use `client.discover()` to map out the topology of a website via sitemaps and link graphs.
- **Farm**: Use `client.farm()` to concurrently harvest thousands of pages with managed rate-limiting.

### 🛡️ Secure Handshake (Checksums)
In production environments, every millisecond counts. By using `client.validate_schema()`, you generate a cryptographic **Checksum** of your extraction logic. The server uses this checksum to bypass DSL parsing and hit optimized execution paths.

---

## 🧬 Core Concepts

| Concept | Description |
| :--- | :--- |
| **Q Builder** | A fluent API for creating surgical extraction rules. |
| **Mutations** | Actions like `!cleanup` that modify the DOM before it reaches the LLM. |
| **Filters** | Logic like `:has` and `:icontains` to find "needles in the haystack." |
| **Query Units (QU)** | A predictable pricing model based on the complexity of your selectors. |

---

## 🛣️ Next Steps

- **[Quick Start](README.md)**: Get up and running in 60 seconds.
- **[Fluent DSL Reference](api.md#q-builder-fluent-api)**: Master the art of surgical extraction.
- **[Discovery & Scaling](scale.md)**: Build massive data pipelines.
- **[API Reference](api.md)**: Complete method documentation.
