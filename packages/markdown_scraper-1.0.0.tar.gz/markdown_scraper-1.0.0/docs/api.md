# 🛠️ API Reference

The Markdown Scraper SDK provides a high-level, developer-friendly interface to our extraction engine.

## 🛰️ Clients

### `AsyncClient`
The primary client for high-performance applications.

**Constructor:**
```python
AsyncClient(
    api_key: str,
    base_url: str = "https://api.markdownscraper.com",
    timeout: int = 30
)
```

**Methods:**
- `async extract(url, schema, checksum=None) -> Dict`: Extract data from a single URL.
- `async discover(url, depth=1) -> List[DiscoveryItem]`: Map a domain's available URLs.
- `async farm(urls, concurrency=5, schema=None, checksum=None) -> AsyncIterator[Result]`: Parallel high-speed extraction.
- `async validate_schema(schema) -> Dict`: Server-side validation. Returns `checksum` and `query_units`.

---

### `SyncClient`
A synchronous wrapper for scripts and automation.

**Methods match `AsyncClient` but are blocking.**

---

## 🧬 Q Builder (Fluent API)

The `Q` builder allows for complex, type-safe DSL construction.

| Method | Returns | Description |
| :--- | :--- | :--- |
| `Q(selector)` | `Q` | Initialize with CSS, XPath (`@xpath:`), or Regex (`/re/`). |
| `.has(selector)` | `Q` | **Filter**: Keep nodes containing the sub-selector. |
| `.icontains(text)` | `Q` | **Filter**: Keep nodes containing text (case-insensitive). |
| `.matches(regex)` | `Q` | **Filter**: Keep nodes matching regex. |
| `.near(query)` | `Q` | **Filter**: Find nodes near a semantic context. |
| `.next(n)` | `Q` | **Filter**: Move to the N-th next sibling. |
| `.prev(n)` | `Q` | **Filter**: Move to the N-th previous sibling. |
| `.cleanup(*selectors)`| `Q` | **Mutation**: Remove matching sub-elements before extraction. |
| `.markdown()` | `QueryAST` | **Action**: Convert the selection to Markdown. |
| `.text()` | `QueryAST` | **Action**: Convert the selection to plain text. |
| `.html()` | `QueryAST` | **Action**: Return raw sanitized HTML. |

---

## 📦 Data Models

### `DiscoveryItem`
Returned by the `discover` method.
- `url`: The absolute URL discovered.
- `title`: The page title (if available via Sitemap/RSS).
- `type`: `sitemap`, `rss`, or `link`.
- `metadata`: Additional context (e.g., `lastmod`, `priority`).

### `Result`
Yielded by the `farm` method.
- `url`: Source URL.
- `status`: `success` | `error`.
- `data`: The extracted JSON (if status is success).
- `error`: Error message (if status is error).
- `timing`: Execution time in milliseconds.
- `query_units`: The QU cost for this specific page.

---

## 🔌 Integration Patterns

### FastAPI / Webhook Integration
```python
@app.post("/webhook/scrape")
async def handle_scrape(request: ScrapeRequest):
    async with AsyncClient(api_key=API_KEY) as client:
        result = await client.extract(request.url, schema=MY_SCHEMA)
        return result
```

### Prompt Engineering for RAG
```python
# Clean the text for better vector embeddings
clean_query = Q("article").cleanup("script", "style", ".ads").markdown()
```
