# 🚜 Usage Guide

The `markdown_scraper` SDK is designed as a **Micro-Orchestrator**. It doesn't just scrape data; it manages the entire lifecycle from discovery, validation, to parallel farming.

---

## 🏗️ High-Level Workflow

!!! abstract "The 4-Step Process"
    1.  **Shortcut**: Quickly check single pages (Article, Product, SERP).
    2.  **Discovery**: Find all relevant URLs (Sitemaps, RSS, or HTML Map).
    3.  **Validation**: Validate extraction schema with server for optimal checksum.
    4.  **Farming**: Concurrently extract content from all discovered URLs.

---

## 🚀 1. Shortcut Methods (Simples)
If you only need to fetch Article, Product, or Search Results, utilize the built-in shortcuts:

```python
from markdown_scraper import AsyncClient

async with AsyncClient(api_key="your_key") as client:
    # 📰 Get Article - Auto-detects title, content, author, date
    article = await client.article("https://techcrunch.com/2023/10/01/ai-news")
    print(article.title)
    print(article.metadata.authors)

    # 🛍️ Get Product - Auto-detects price, reviews, currency
    product = await client.product("https://amazon.com/dp/B08X")
    print(product.metadata.price.amount)

    # 🔍 Get Search Results (SERP)
    serp = await client.serp("https://google.com/search?q=python")
    for res in serp.results:
        print(f"[{res.position}] {res.title}: {res.url}")
```

---

## 🗺️ 2. Discovery (The "Map" Phase)
Find every corner of a domain in seconds using the `/map` engine.

```python
# Discovers all URLs (Sitemap + RSS + Recursive Discovery)
items = await client.discover("https://techcrunch.com", depth=1)

for item in items:
    print(f"Found {item['type']}: {item['url']}")
```

---

## 🛡️ 3. Schema Validation (The "Handshake")
Before scraping 1,000 pages, ensure your schema is valid. This step optimizes server performance by parsing DSL syntax beforehand.

!!! success "Performance Tip"
    Using checksums allows the server to skip periodic DSL parsing, significantly reducing latency.

```python
schema = {
    "title": "h1::text",
    "content": "article !cleanup(.ads) ::markdown",
    "date": ".publish-date::text"
}

# Validate DSL with server and get identifier checksum
validation = await client.validate_schema(schema)
checksum = validation["checksum"]

print(f"Schema validated. Checksum: {checksum}")
```

---

## 🚜 4. Parallel Farming (The "Extraction" Phase)
Scrape hundreds of pages concurrently with built-in rate limiting and orchestration.

```python
# Use checksum to bypass server-side DSL parsing
results = []
async for result in client.farm(
    items,
    concurrency=10,
    schema=schema,
    checksum=checksum
):
    print(f"Scraped: {result['url']}")
    results.append(result)
```

---

## 🧩 Fluent Query Builder
For complex logic, use the `Q` object to build readable query chains.

```python
from markdown_scraper import Q

# Build a sophisticated extraction pipeline
query = (
    (Q(".article-body") | ".post-content")  # Fallback Group
    .has("p")                               # Logic Filter: Only if it has paragraphs
    .cleanup(".ads", ".social-share")       # Surgical Cleanup
    .markdown()                             # High-quality Markdown export
)

# Insert into your schema
schema = {"body": query}
```

---

## 🔌 Sync Support
If you prefer not to use `asyncio`, the SDK provides an equivalent Synchronous Client.

```python
from markdown_scraper import SyncClient

client = SyncClient(api_key="your_key")
items = client.discover("https://example.com")
# ... methods are identical to AsyncClient
```
