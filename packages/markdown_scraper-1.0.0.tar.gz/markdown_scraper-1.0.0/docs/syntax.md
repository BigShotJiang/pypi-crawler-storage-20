# 🧪 Syntax Guide (Chained Pseudo-DSL)

Markdown Scraper uses a specialized language called **Chained Pseudo-DSL** designed for high-performance data extraction. It allows you to transform raw HTML into structured data using a single, readable, and powerful string.

---

## 🔗 Anatomy of a Query

The syntax follows a sequential pipeline, where each stage processes the result of the previous stage:

`[@engine:]<selector>[:filter...][!mutation...][::action...]`

### 1. Engines (`@`)
Defines the base search engine.
- **`@css:`** (Default): Ultra-fast CSS selector via Lexbor.
- **`@xpath:`** Traverse complex DOM trees with powerful XPath.
- **`@regex:`** Find nodes based on class, ID, or tag patterns.

### 2. Filters (`:`)
Refine the found nodes.
- **Content**: `:icontains('text')`, `:contains('text')`, `:matches('regex')`.
- **Relationship**: `:has(sel)`, `:not(sel)`, `:closest(sel)`, `:parent`, `:next`, `:prev`.
- **Logic**: `:semantic('auto')` — Use AI heuristics to find main content clusters.

### 3. Mutations (`!`)
Modify DOM structure **before** data extraction.
- **`!cleanup(selector)`**: Remove child nodes (ads, social buttons, scripts) from the current scope.

### 4. Actions (`::`)
Extract or transform the final data.
- **Extraction**: `::text`, `::html`, `::attr(name)`.
- **Transformation**: `::markdown`, `::table` (Clean MD table), `::url` (Smart absolute URL).
- **Formatters**: `::strip`, `::split(sep, index)`, `::replace(old, new)`.
- **List Ops**: `::first`, `::last`, `::slice(s, e)`, `::count`, `::join(sep)`.

---

## 🔥 Professional Examples

!!! example "Article Extraction"
    ```css
    article !cleanup(.ads, .related, aside) ::markdown
    ```
    *Find article, clean ads, and convert the rest to professional Markdown.*

!!! example "Smart Link Discovery"
    ```css
    .content a:icontains('download'):not(.premium) ::attr(href) ::url
    ```
    *Find download links that are not premium, get href, and convert to absolute URL.*

!!! example "AI-Density Content Finder"
    ```css
    body :semantic('auto') ::markdown
    ```
    *Automatically identify "Main Content" of the webpage and extract it.*

---

## 🏗️ Fallback Groups

Handle websites with changing structures (A/B testing) using priority groups.
- **Syntax**: `( selector_a | selector_b | selector_c )`
- **Example**: `(.main-v2 | .main-v1 | #content) ::text`

---

## 🛡️ Handshake Protocol

In production environments, DSL queries should be pre-validated with the server to optimize performance:
1. Use `client.validate_schema(schema)` to get a parsed `checksum`.
2. Send this `checksum` in subsequent extract requests to achieve O(1) processing speed.
