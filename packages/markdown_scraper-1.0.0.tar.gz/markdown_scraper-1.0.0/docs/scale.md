# 🚜 Mass Scale: The Map-Farm Pattern

Enterprise extraction requires more than just scraping one-off pages. It requires a systematic approach to "harvesting" entire domains. Markdown Scraper SDK facilitates this through the **Map-Farm** workflow.

## 📍 1. The Map Phase (Discovery)

Before you can scrape, you must discover. The `discover` method uses a multi-vector strategy to map a domain's topology.

### Deep Discovery
```python
urls = await client.discover(
    "https://example.com",
    depth=2,
    include_patterns=["/blog/*", "/articles/*"]
)
```

**Strategies used by Discovery:**
- **Sitemaps**: Parsing `sitemap.xml` for structured URL lists.
- **RSS Feeds**: Capturing the latest content updates.
- **Link Graph**: Heuristic-based link following to find pages missed by sitemaps.

---

## 🌽 2. The Farm Phase (Parallel Extraction)

Once you have your "Map" (list of URLs), the `farm` method begins the high-concurrency harvest.

### High-Concurrency Extraction
```python
async for result in client.farm(
    urls,
    concurrency=20,
    schema={
        "title": Q("h1").text(),
        "body": Q(".content").cleanup(".ads").markdown()
    }
):
    if result["status"] == "success":
        save_to_database(result["data"])
```

### Key Benefits of `farm()`:
1. **Adaptive Throttling**: Automatically manages concurrency to avoid IP blocking.
2. **Error Recovery**: Transparently handles retries and partial failures.
3. **Memory Efficiency**: Implements `AsyncIterator` to process streams of data without loading everything into RAM.

---

## 📈 Enterprise Scaling Tips

### Using Pre-validated Checksums
To maximize performance during a large "Farm" operation, always pre-validate your schema.

```python
# 1. Validate once
schema = {"content": Q("main").markdown()}
validation = await client.validate_schema(schema)
checksum = validation["checksum"]

# 2. Farm with checksum
async for result in client.farm(urls, schema=schema, checksum=checksum):
    process(result)
```

This ensures the server uses the **Optimized Execution Path** for every single URL in your list, reducing latency by up to 40%.
