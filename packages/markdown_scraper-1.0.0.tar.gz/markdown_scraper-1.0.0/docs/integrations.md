# 🔌 AI Integrations

Markdown Scraper is designed to be the perfect "Food" for LLMs. This guide shows how to integrate it seamlessly with popular AI frameworks.

---

## 🤖 OpenAI / Compatible APIs

The simplest way to use the scraper is to feed the `::markdown` output directly into a system prompt or user context.

```python
import os
from openai import AsyncOpenAI
from markdown_scraper import AsyncClient

# 1. Initialize Clients
ai_client = AsyncOpenAI(api_key=os.getenv("OPENAI_KEY"))
scraper = AsyncClient(
    base_url="https://api.markdownscraper.com",
    api_key=os.getenv("SCRAPER_KEY")
)

async def summarize_news(url: str):
    # 2. Scrape clean markdown
    # We use !cleanup to remove noise so we don't pay for useless tokens
    query = "article !cleanup(.ads, .nav) ::markdown"

    results = await scraper.extract(url, {"content": query})
    markdown_text = results["content"][0]

    # 3. Feed to LLM
    response = await ai_client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant. Summarize the following article."},
            {"role": "user", "content": markdown_text}
        ]
    )

    return response.choices[0].message.content
```

---

## 🦜 LangChain Integration

You can easily wrap Markdown Scraper as a custom `DocumentLoader` in LangChain.

```python
from typing import List
from langchain_core.documents import Document
from langchain_community.document_loaders.base import BaseLoader
from markdown_scraper import SyncClient

class MarkdownScraperLoader(BaseLoader):
    def __init__(self, urls: List[str], api_key: str):
        self.urls = urls
        self.client = SyncClient(api_key=api_key)

    def lazy_load(self):
        # Universal query for main content
        query = "body :semantic('auto') !cleanup(nav, footer) ::markdown"

        for url in self.urls:
            try:
                data = self.client.extract(url, {"text": query})
                content = data.get("text", [""])[0]

                yield Document(
                    page_content=content,
                    metadata={"source": url}
                )
            except Exception as e:
                print(f"Error scraping {url}: {e}")

# Usage
loader = MarkdownScraperLoader(["https://example.com/post/1"], api_key="...")
docs = loader.load()

print(f"Loaded {len(docs)} documents for RAG.")
```

---

## 🦙 LlamaIndex Integration

Use it as a data connector for your RAG pipelines.

```python
from llama_index.core import Document
from llama_index.core.readers.base import BaseReader
from markdown_scraper import SyncClient

class MarkdownScraperReader(BaseReader):
    def __init__(self, api_key: str):
        self.client = SyncClient(api_key=api_key)

    def load_data(self, urls: list[str]):
        documents = []
        # Smart selector
        query = "main::markdown"

        for url in urls:
            data = self.client.extract(url, {"text": query})
            text = data.get("text", [None])[0]

            if text:
                documents.append(Document(text=text, extra_info={"url": url}))

        return documents

# Usage
reader = MarkdownScraperReader(api_key="...")
documents = reader.load_data(urls=["https://news.ycombinator.com"])
index = VectorStoreIndex.from_documents(documents)
```

---

## ✨ Optimizing for Context Windows

LLMs have limited context windows. Use the Scraper's DSL to reduce token usage **before** the data hits your API.

| Technique | standard HTML | Markdown Scraper | Savings |
| :--- | :--- | :--- | :--- |
| **Raw HTML** | `<div class="x">...</div>` | `content::markdown` | ~40% tokens |
| **Noise Removal** | Ads, Nav, Footer included | `!cleanup(.ads, nav)` | ~60% tokens |
| **Surgical Extraction** | Full Page | `article::text` | ~90% tokens |

### The "Token-Saver" Query
Use this generic query to get the highest information density with the lowest token count:

```css
body :semantic('auto') !cleanup(script, style, .ads, footer, nav) ::markdown
```

---

## 🏗️ High-Scale RAG Pipeline (The Map-Farm Pattern)

For enterprise-scale RAG, don't scrape sequentially. Use the `discover` and `farm` methods to build a high-throughput ingestion pipeline.

```python
import asyncio
from markdown_scraper import AsyncClient, Q

async def ingest_site_to_vector_db(domain: str):
    async with AsyncClient(api_key="...") as scraper:
        # 1. Map: Find all relevant content pages
        print(f"Mapping {domain}...")
        urls = await scraper.discover(domain, depth=2)

        # 2. Verify: Pre-validate our high-fidelity schema
        schema = {
            "title": Q("h1").text(),
            "content": Q("article").cleanup(".sidebar", ".ads").markdown()
        }
        validation = await scraper.validate_schema(schema)

        # 3. Farm: Parallel extraction with optimized Checksums
        print(f"Harvesting {len(urls)} pages...")
        async for result in scraper.farm(
            urls,
            concurrency=25,
            schema=schema,
            checksum=validation["checksum"]
        ):
            if result["status"] == "success":
                await vector_db.upsert(
                    id=result["url"],
                    text=result["data"]["content"],
                    metadata=result["data"]["title"]
                )
```

By using the **Map-Farm** pattern with **Checksums**, you achieve the following:
1. **Concurrency**: Scale to huge domains without hitting local bottlenecks.
2. **Deterministic Output**: LLMs receive perfectly structured Markdown.
3. **Optimized Cost**: Using validated checksums ensures the server uses pre-parsed execution plans, minimizing latency and QU costs.
