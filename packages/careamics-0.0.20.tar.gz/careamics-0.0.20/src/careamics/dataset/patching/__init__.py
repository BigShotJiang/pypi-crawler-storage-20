"""Patching and tiling functions."""
