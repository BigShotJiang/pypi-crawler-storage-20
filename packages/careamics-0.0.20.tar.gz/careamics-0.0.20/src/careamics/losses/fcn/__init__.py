"""FCN losses."""
