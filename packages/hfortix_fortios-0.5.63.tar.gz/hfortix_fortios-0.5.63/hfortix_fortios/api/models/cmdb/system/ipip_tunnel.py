"""
Pydantic Models for CMDB - system/ipip_tunnel

Runtime validation models for system/ipip_tunnel configuration.
Generated from FortiOS schema version unknown.
"""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator
from typing import Any, Literal

# ============================================================================
# Enum Definitions (for fields with 4+ allowed values)
# ============================================================================


# ============================================================================
# Main Model
# ============================================================================


class IpipTunnelModel(BaseModel):
    """
    Pydantic model for system/ipip_tunnel configuration.

    Configure IP in IP Tunneling.

    Validation Rules:
        - name: max_length=15 pattern=
        - interface: max_length=15 pattern=
        - remote_gw: pattern=
        - local_gw: pattern=
        - use_sdwan: pattern=
        - auto_asic_offload: pattern=
    """

    class Config:
        """Pydantic model configuration."""
        extra = "allow"  # Allow additional fields from API
        str_strip_whitespace = True
        validate_assignment = True  # Validate on attribute assignment
        use_enum_values = True  # Use enum values instead of names

    # ========================================================================
    # Model Fields
    # ========================================================================
    name: str | None = Field(max_length=15, default="", description="IPIP Tunnel name.")
    interface: str = Field(max_length=15, default="", description="Interface name that is associated with the incoming traffic from available options.")  # datasource: ['system.interface.name']
    remote_gw: str = Field(default="0.0.0.0", description="IPv4 address for the remote gateway.")
    local_gw: str = Field(default="0.0.0.0", description="IPv4 address for the local gateway.")
    use_sdwan: Literal["disable", "enable"] | None = Field(default="disable", description="Enable/disable use of SD-WAN to reach remote gateway.")
    auto_asic_offload: Literal["enable", "disable"] | None = Field(default="enable", description="Enable/disable tunnel ASIC offloading.")
    # ========================================================================
    # Custom Validators
    # ========================================================================

    @field_validator('interface')
    @classmethod
    def validate_interface(cls, v: Any) -> Any:
        """
        Validate interface field.

        Datasource: ['system.interface.name']

        Note:
            This validator only checks basic constraints.
            To validate that referenced object exists, query the API.
        """
        # Basic validation passed via Field() constraints
        # Additional datasource validation could be added here
        return v
    # ========================================================================
    # Helper Methods
    # ========================================================================

    def to_fortios_dict(self) -> dict[str, Any]:
        """
        Convert model to FortiOS API payload format.

        Returns:
            Dict suitable for POST/PUT operations
        """
        # Export with exclude_none to avoid sending null values
        return self.model_dump(exclude_none=True, by_alias=True)

    @classmethod
    def from_fortios_response(cls, data: dict[str, Any]) -> "IpipTunnelModel":
        """
        Create model instance from FortiOS API response.

        Args:
            data: Response data from API

        Returns:
            Validated model instance
        """
        return cls(**data)
    # ========================================================================
    # Datasource Validation Methods
    # ========================================================================
    async def validate_interface_references(self, client: Any) -> list[str]:
        """
        Validate interface references exist in FortiGate.

        This method checks if referenced objects exist by calling exists() on
        the appropriate API endpoints. This is an OPTIONAL validation step that
        can be called before posting to the API to catch reference errors early.

        Datasource endpoints checked:
        - system/interface
        Args:
            client: FortiOS client instance (from fgt._client)

        Returns:
            List of validation error messages (empty if all valid)

        Example:
            >>> from hfortix_fortios import FortiOS
            >>>
            >>> fgt = FortiOS(host="192.168.1.1", token="your-token")
            >>> policy = IpipTunnelModel(
            ...     interface="invalid-name",
            ... )
            >>>
            >>> # Validate before posting
            >>> errors = await policy.validate_interface_references(fgt._client)
            >>> if errors:
            ...     print("Validation failed:", errors)
            ... else:
            ...     result = await fgt.api.cmdb.system.ipip_tunnel.post(policy.to_fortios_dict())
        """
        errors: list[str] = []

        # Validate scalar field
        value = getattr(self, "interface", None)
        if not value:
            return errors

        # Check all datasource endpoints
        found = False
        if await client.api.cmdb.system.interface.exists(value):
            found = True

        if not found:
            errors.append(
                f"Interface '{value}' not found in "
                "system/interface"
            )
        return errors
    async def validate_all_references(self, client: Any) -> list[str]:
        """
        Validate ALL datasource references in this model.

        Convenience method that runs all validate_*_references() methods
        and aggregates the results.

        Args:
            client: FortiOS client instance (from fgt._client)

        Returns:
            List of all validation errors found

        Example:
            >>> errors = await policy.validate_all_references(fgt._client)
            >>> if errors:
            ...     for error in errors:
            ...         print(f"  - {error}")
        """
        all_errors: list[str] = []
        errors = await self.validate_interface_references(client)
        all_errors.extend(errors)
        return all_errors

# ============================================================================
# Type Aliases for Convenience
# ============================================================================


IpipTunnelModelDict = dict[str, Any]  # For backward compatibility

# ============================================================================
# Module Exports
# ============================================================================

__all__ = [
    "IpipTunnelModel",]


# ============================================================================
# Generated by hfortix generator v0.6.0
# Schema: 1.7.0
# Generated: 2026-01-14T22:43:39.625391Z
# ============================================================================
