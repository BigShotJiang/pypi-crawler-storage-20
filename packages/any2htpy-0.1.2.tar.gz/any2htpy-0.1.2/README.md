# any2htpy

**any2htpy** is a principled converter for HTML/SVG and MathML to [htpy](https://htpy.dev) inspired by `html2htpy`, the built-in tool for `htpy`.

Unlike `html2htpy` any2htpy uses a feature-complete HTML parser called [justhtml](https://github.com/emilstenstrom/justhtml). 

## Features

- adheres to SVG and MathML 
- preserves case-sensitive attributes such as SVG `viewBox`
- preserves SVG path commands and other non-class attribute values with spaces 
- tries best-effort DOM for malformed HTML
- properly preserves whitespace for respective tags
- only supports `class_` syntax to allow stable parsing by TailwindCSS

A few things **any2htpy** needs to fix to be better suited for :

- auto-detect if code is just a fragment or a whole document
- boolean attributes are not yet detected (use `dict` syntax)
- special attribute detection for AlpineJS or HTMX 
    - specifically passing HTMX events `:` or AlpineJS `@`


Things that **any2htpy** will not do:

- add the `import htpy` code
- add the shorthand syntax of `htpy`


## Usage

```sh
usage: any2htpy [-h] [--input INPUT] [--stdin] [--debug] [--prefix PREFIX] [--fragment]

options:
  -h, --help       show this help message and exit
  --input INPUT    input as string or file
  --stdin          use stdin as input
  --debug          generate debug output
  --prefix PREFIX  use a prefix for the tags
  --fragment       use htpy fragment
```

### input through stdin

```sh
[me@machine ] echo "<p>Hello World</p>" | uv run any2htpy --stdin --prefix htpy
htpy.p["Hello World"]
```

## Disclaimer

As an AI-skeptic, specifically regarding code and software in general, justhtml is not exactly the obvious choice or more precisely the exact opposite one. However, the heavy test-rig with thousands of tests and the use as a parser **without** introducing it as a dependency in the resulting code make it a better choice than any other native Python parser library.

## License

Licensed under the terms of the MIT License 

## Copyright

Copyright (c) 2026 Hartmut Seichter
