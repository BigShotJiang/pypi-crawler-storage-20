"""Tests for youtube-mcp."""
