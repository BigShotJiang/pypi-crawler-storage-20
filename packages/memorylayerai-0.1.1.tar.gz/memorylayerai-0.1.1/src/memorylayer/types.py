"""Type definitions for the MemoryLayer SDK."""

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class Memory:
    """Memory object."""

    id: str
    content: str
    project_id: str
    created_at: str
    updated_at: str
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class CreateMemoryRequest:
    """Request to create a new memory."""

    content: str
    project_id: str
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class UpdateMemoryRequest:
    """Request to update an existing memory."""

    content: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class ListMemoriesRequest:
    """Request to list memories."""

    project_id: str
    limit: Optional[int] = None
    offset: Optional[int] = None
    filter: Optional[Dict[str, Any]] = None


@dataclass
class SearchRequest:
    """Search request."""

    query: str
    project_id: str
    limit: Optional[int] = None
    filter: Optional[Dict[str, Any]] = None
    threshold: Optional[float] = None


@dataclass
class SearchResult:
    """Search result."""

    memory: Memory
    score: float
    highlights: Optional[List[str]] = None


@dataclass
class SearchResponse:
    """Search response."""

    results: List[SearchResult]
    total: int


@dataclass
class IngestFileRequest:
    """Request to ingest a file."""

    file: Any  # File-like object or bytes
    project_id: str
    metadata: Optional[Dict[str, Any]] = None
    chunk_size: Optional[int] = None
    chunk_overlap: Optional[int] = None


@dataclass
class IngestTextRequest:
    """Request to ingest text."""

    text: str
    project_id: str
    metadata: Optional[Dict[str, Any]] = None
    chunk_size: Optional[int] = None
    chunk_overlap: Optional[int] = None


@dataclass
class IngestResponse:
    """Ingestion response."""

    memory_ids: List[str]
    chunks_created: int


@dataclass
class Message:
    """Message in a conversation."""

    role: str  # 'user', 'assistant', or 'system'
    content: str


@dataclass
class RouterRequest:
    """Router request."""

    messages: List[Message]
    project_id: str
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    stream: Optional[bool] = None


@dataclass
class Usage:
    """Token usage information."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class Choice:
    """Choice in a router response."""

    message: Message
    finish_reason: str


@dataclass
class RouterResponse:
    """Router response."""

    id: str
    choices: List[Choice]
    usage: Usage


@dataclass
class StreamDelta:
    """Delta in a streaming choice."""

    role: Optional[str] = None
    content: Optional[str] = None


@dataclass
class StreamChoice:
    """Choice in a streaming response."""

    delta: StreamDelta
    finish_reason: Optional[str] = None


@dataclass
class StreamChunk:
    """Streaming chunk from router."""

    id: str
    choices: List[StreamChoice]
