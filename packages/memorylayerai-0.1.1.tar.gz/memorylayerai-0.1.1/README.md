# memorylayerai

Official Python SDK for MemoryLayer - Add memory capabilities to your AI applications.

## Installation

```bash
pip install memorylayerai
```

## Quick Start

```python
from memorylayerai import MemoryLayerClient, CreateMemoryRequest
import os

client = MemoryLayerClient(
    api_key=os.environ['MEMORYLAYER_API_KEY']
)

# Add a memory
memory = client.memories.add(CreateMemoryRequest(
    content='User prefers dark mode',
    metadata={'category': 'preferences'},
    project_id='proj_abc123'
))

# Search memories
results = client.search.search(
    query='user preferences',
    project_id='proj_abc123'
)

print(results)
```

## Async Support

```python
from memorylayerai import AsyncMemoryLayerClient

async_client = AsyncMemoryLayerClient(
    api_key=os.environ['MEMORYLAYER_API_KEY']
)

# Use async methods
memory = await async_client.memories.add(...)
```

## Documentation

For full documentation, visit [https://docs.memorylayer.com](https://docs.memorylayer.com)

## License

MIT
