# -*- coding: utf-8 -*-
__version__ = '1.2'
from .cacheclass import cacheclass
cache=cacheclass()