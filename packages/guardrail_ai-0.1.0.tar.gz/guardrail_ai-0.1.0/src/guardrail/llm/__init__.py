"""LLM integration for GuardRail."""

