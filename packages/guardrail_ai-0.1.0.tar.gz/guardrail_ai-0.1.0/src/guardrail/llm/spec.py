"""LLM-based SpecCard generation."""

import json
from pathlib import Path
from typing import Optional

from guardrail.llm.client import LLMClient
from guardrail.models import SpecCard


class SpecGenerator:
    """Generates SpecCard JSON from function source using LLM."""

    SYSTEM_PROMPT = """You are an expert Python code analyzer. Your task is to analyze Python functions and generate detailed specifications in JSON format.

Generate a SpecCard JSON object with the following structure:
- function_name: Name of the function
- module_path: Module path (e.g., "my_module" or "my_package.my_module")
- signature: Full function signature as a string
- description: Clear description of what the function does
- inputs: List of objects with "name", "type" (if available), and "description" fields
- expected_behavior: List of 2-5 bullet points describing expected behavior
- edge_cases: List of 5-12 edge cases that should be tested
- side_effects: Boolean indicating if function has side effects
- side_effects_reason: String explaining side effects if any (null if none)
- confidence: "low", "medium", or "high" based on how clear the function is

Return ONLY valid JSON, no markdown, no code blocks, just the JSON object."""

    PROMPT_TEMPLATE = """Analyze the following Python function and generate a SpecCard JSON:

Function source code:
```python
{function_source}
```

File path: {file_path}

Generate a comprehensive SpecCard JSON for this function. Focus on:
1. Understanding the function's purpose and behavior
2. Identifying all input parameters and their types
3. Listing expected behaviors
4. Identifying edge cases (boundary conditions, error cases, special inputs)
5. Determining if there are any side effects

Return ONLY the JSON object, no other text."""

    def __init__(self, llm_client: Optional[LLMClient] = None):
        """
        Initialize spec generator.

        Args:
            llm_client: Optional LLM client. If None, creates one with default settings.
        """
        self.llm_client = llm_client or LLMClient()

    def generate_spec(
        self, function_source: str, file_path: Path, function_name: str
    ) -> SpecCard:
        """
        Generate SpecCard for a function.

        Args:
            function_source: Source code of the function.
            file_path: Path to the file containing the function.
            function_name: Name of the function.

        Returns:
            SpecCard object.

        Raises:
            ValueError: If generated JSON is invalid.
            RuntimeError: If LLM call fails.
        """
        # Convert file path to module path
        module_path = self._path_to_module_path(file_path)

        # Build prompt
        prompt = self.PROMPT_TEMPLATE.format(
            function_source=function_source, file_path=str(file_path)
        )

        # Generate spec using LLM
        response = self.llm_client.generate(
            prompt=prompt,
            system_prompt=self.SYSTEM_PROMPT,
            temperature=0.3,
            max_tokens=2000,
        )

        # Parse JSON response
        try:
            # Try to extract JSON if wrapped in markdown code blocks
            response = response.strip()
            if response.startswith("```"):
                # Remove markdown code blocks
                lines = response.split("\n")
                response = "\n".join(lines[1:-1]) if len(lines) > 2 else response
            if response.startswith("```json"):
                lines = response.split("\n")
                response = "\n".join(lines[1:-1]) if len(lines) > 2 else response

            spec_dict = json.loads(response)
        except json.JSONDecodeError as e:
            raise ValueError(
                f"Failed to parse LLM response as JSON: {e}\nResponse: {response[:500]}"
            ) from e

        # Validate and create SpecCard
        try:
            spec_card = SpecCard(**spec_dict)
            # Override with actual values
            spec_card.function_name = function_name
            spec_card.module_path = module_path
            return spec_card
        except Exception as e:
            raise ValueError(
                f"Failed to create SpecCard from LLM response: {e}\nResponse: {response[:500]}"
            ) from e

    def _path_to_module_path(self, file_path: Path) -> str:
        """
        Convert file path to module path.

        Args:
            file_path: Path to Python file.

        Returns:
            Module path string (e.g., "my_module" or "my_package.my_module").
        """
        # Remove .py extension
        stem = file_path.stem

        # If it's __init__.py, use parent directory
        if stem == "__init__":
            stem = file_path.parent.name

        # For now, just return the stem
        # In a full implementation, we'd resolve relative to project root
        return stem

