"""Report generation for GuardRail."""

from pathlib import Path
from typing import List, Optional

from guardrail.locator import FunctionInfo


class FixPromptGenerator:
    """Generates fix prompts for failing tests."""

    @staticmethod
    def generate_fix_prompt(
        function: FunctionInfo,
        test_code: str,
        failure_output: str,
        test_file_path: Path,
    ) -> str:
        """
        Generate a fix prompt for a failing test.

        Args:
            function: FunctionInfo object for the failing function.
            test_code: Generated test code that failed.
            failure_output: Pytest failure output.
            test_file_path: Path to the test file.

        Returns:
            Fix prompt string.
        """
        func_display = (
            f"{function.parent_class}.{function.name}"
            if function.is_method
            else function.name
        )

        prompt = f"""🔧 Fix Required for Function: {func_display}

The generated tests for this function are failing. Please fix the function to make the tests pass.

Function Code:
```python
{function.source}
```

Failing Test Code:
```python
{test_code}
```

Test Failure Output:
```
{failure_output}
```

Constraints:
- Modify only this function: {func_display}
- Make all tests pass
- Don't change the function signature
- Maintain the expected behavior described in the tests

Test file location: {test_file_path}

After fixing, run 'guardrail run -- <your-command>' again to verify.
"""

        return prompt

    @staticmethod
    def generate_summary_report(
        total_tests: int,
        passed: bool,
        failing_tests: List[str],
        fix_prompts: List[str],
    ) -> str:
        """
        Generate a summary report of test results.

        Args:
            total_tests: Total number of tests run.
            passed: Whether all tests passed.
            failing_tests: List of failing test names.
            fix_prompts: List of fix prompts.

        Returns:
            Summary report string.
        """
        if passed:
            return f"✅ All {total_tests} test(s) passed!"

        report = f"❌ {len(failing_tests)} test(s) failed out of {total_tests}:\n\n"
        for i, (test_name, prompt) in enumerate(zip(failing_tests, fix_prompts), 1):
            report += f"{i}. {test_name}\n"
            report += f"{prompt}\n"
            report += "-" * 80 + "\n\n"

        return report

