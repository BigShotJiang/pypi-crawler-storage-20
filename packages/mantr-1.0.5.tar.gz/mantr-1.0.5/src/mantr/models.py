"""Pydantic models for request/response validation"""

from typing import List, Optional
from pydantic import BaseModel, Field, field_validator


class PathResult(BaseModel):
    """A single path result from the semantic graph"""
    nodes: List[str] = Field(..., description="Sequence of nodes in the path")
    score: float = Field(..., ge=0.0, le=1.0, description="Relevance score (0-1)")
    depth: int = Field(..., ge=0, description="Path depth in the graph")


class WalkRequest(BaseModel):
    """Request payload for /v1/walk endpoint"""
    phonemes: List[str] = Field(..., min_length=1, description="Sanskrit phoneme concepts")
    pod: Optional[str] = Field(None, description="Context pod name")
    depth: int = Field(3, ge=1, le=10, description="Maximum traversal depth")
    limit: int = Field(100, ge=1, le=1000, description="Maximum results to return")
    
    @field_validator('phonemes')
    @classmethod
    def validate_phonemes(cls, v):
        if not v:
            raise ValueError("phonemes cannot be empty")
        return [p.strip().lower() for p in v if p.strip()]


class WalkResponse(BaseModel):
    """Response from /v1/walk endpoint"""
    paths: List[PathResult] = Field(default_factory=list, description="Discovered paths")
    latency_us: int = Field(..., alias="latency_us", description="Execution time in microseconds")
    credits_used: int = Field(..., description="Credits consumed")
    
    class Config:
        populate_by_name = True
