"""Custom exceptions for Mantr SDK"""


class MantrError(Exception):
    """Base exception for all Mantr SDK errors"""
    pass


class AuthenticationError(MantrError):
    """Raised when API key is invalid or missing"""
    pass


class InsufficientCreditsError(MantrError):
    """Raised when account has insufficient credits"""
    pass


class RateLimitError(MantrError):
    """Raised when rate limit is exceeded"""
    
    def __init__(self, message: str, retry_after: int = None):
        super().__init__(message)
        self.retry_after = retry_after
