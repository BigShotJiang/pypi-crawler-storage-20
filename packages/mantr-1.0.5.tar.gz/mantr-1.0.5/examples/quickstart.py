#!/usr/bin/env python3
"""Quickstart example for Mantr Python SDK"""

from mantr import MantrClient

def main():
    # Initialize client with your API key
    client = MantrClient(api_key='vak_live_YOUR_API_KEY_HERE')
    
    # Example 1: Simple walk
    print("🚀 Example 1: Simple Walk")
    result = client.walk(phonemes=['dharma', 'karma', 'yoga'])
    
    print(f"Found {len(result.paths)} paths")
    print(f"Latency: {result.latency_us}μs")
    print(f"Credits used: {result.credits_used}")
    
    for i, path in enumerate(result.paths[:3], 1):
        print(f"\nPath {i} (score: {path.score:.2f}):")
        print(f"  {' → '.join(path.nodes)}")
    
    # Example 2: Customized walk
    print("\n🎯 Example 2: Customized Walk")
    result = client.walk(
        phonemes=['sthiti', 'nasha'],
        depth=5,
        limit=50
    )
    
    print(f"Found {len(result.paths)} paths with depth=5, limit=50")
    
    # Example 3: Using context manager (auto-cleanup)
    print("\n✨ Example 3: Context Manager")
    with MantrClient(api_key='vak_live_YOUR_API_KEY_HERE') as client:
        result = client.walk(['jnana', 'shakti'])
        print(f"Paths found: {len(result.paths)}")

if __name__ == '__main__':
    main()
