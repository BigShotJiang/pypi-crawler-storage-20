#
#  Copyright 2026 by C Change Labs Inc. www.c-change-labs.com
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#
import pydantic

from openepd.model.category import CategoryMeta
from openepd.model.common import Amount
from openepd.model.specs.base import BaseOpenEpdHierarchicalSpec
from openepd.model.specs.enums import InsulatingMaterial, InsulationIntendedApplication
from openepd.model.validation.quantity import LengthMmStr


class MechanicalInsulationV1(BaseOpenEpdHierarchicalSpec):
    """
    Insulation products whose primary purpose is for mechanical systems rather than for building envelope.

    Includes HVAC, plumbing, and acoustic insulations.
    """

    _EXT_VERSION = "1.0"
    _CATEGORY_META = CategoryMeta(
        unique_name="MechanicalInsulation",
        display_name="Mechanical Insulation",
        description="Insulation products whose primary purpose is for mechanical systems rather than for building envelope. Includes HVAC, plumbing, and acoustic insulations.",
        masterformat="23 07 00 HVAC Insulation",
        declared_unit=Amount(qty=1, unit="m^2"),
    )

    # Own fields:
    r_value: float | None = pydantic.Field(default=None, description="", examples=[2.3])
    material: InsulatingMaterial | None = pydantic.Field(default=None, description="", examples=["Mineral Wool"])
    intended_application: list[InsulationIntendedApplication] | None = pydantic.Field(
        default=None, description="", examples=[["Wall & General"]]
    )
    thickness_per_declared_unit: LengthMmStr | None = pydantic.Field(default=None, description="", examples=["20 mm"])
