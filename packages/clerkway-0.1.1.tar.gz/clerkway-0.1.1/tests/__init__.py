"""Tests for clerkway."""
