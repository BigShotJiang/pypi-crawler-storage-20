# AWS Resource Naming
