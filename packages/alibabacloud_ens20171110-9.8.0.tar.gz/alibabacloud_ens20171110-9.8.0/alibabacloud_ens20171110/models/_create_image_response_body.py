# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CreateImageResponseBody(DaraModel):
    def __init__(
        self,
        code: int = None,
        image_id: str = None,
        request_id: str = None,
    ):
        # The returned service code. 0 indicates that the request was successful.
        self.code = code
        # The ID of the image.
        self.image_id = image_id
        # The request ID.
        self.request_id = request_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code is not None:
            result['Code'] = self.code

        if self.image_id is not None:
            result['ImageId'] = self.image_id

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Code') is not None:
            self.code = m.get('Code')

        if m.get('ImageId') is not None:
            self.image_id = m.get('ImageId')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

