# Chat API v1 module
