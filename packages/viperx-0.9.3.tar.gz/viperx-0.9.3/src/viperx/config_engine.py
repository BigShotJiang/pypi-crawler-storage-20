import yaml
from pathlib import Path
from rich.console import Console
from rich.panel import Panel

from viperx.core import ProjectGenerator
from viperx.constants import DEFAULT_LICENSE, DEFAULT_BUILDER, TYPE_CLASSIC, FRAMEWORK_PYTORCH

console = Console()

class ConfigEngine:
    """
    Orchestrates project creation and updates based on a declarative YAML config.
    Implements the 'Infrastructure as Code' pattern for ViperX.
    """
    
    def __init__(self, config_path: Path, verbose: bool = False):
        self.config_path = config_path
        self.verbose = verbose
        self.config = self._load_config()
        self.root_path = Path.cwd()

    def _load_config(self) -> dict:
        """Load and validate the YAML configuration."""
        if not self.config_path.exists():
            console.print(f"[bold red]Error:[/bold red] Config file not found at {self.config_path}")
            raise FileNotFoundError(f"Config file not found: {self.config_path}")
            
        with open(self.config_path, "r") as f:
            try:
                data = yaml.safe_load(f)
            except yaml.YAMLError as e:
                console.print(f"[bold red]Error:[/bold red] Invalid YAML format: {e}")
                raise ValueError("Invalid YAML")
                
        # Basic Validation
        if "project" not in data or "name" not in data["project"]:
            console.print("[bold red]Error:[/bold red] Config must contain 'project.name'")
            raise ValueError("Missing project.name")
            
        return data

    def apply(self):
        """Apply the configuration to the current directory."""
        project_conf = self.config.get("project", {})
        settings_conf = self.config.get("settings", {})
        workspace_conf = self.config.get("workspace", {})
        
        project_name = project_conf.get("name")
        target_dir = self.root_path / project_name
        
        # 1. Root Project Handling
        # If we are NOT already in the project dir (checking name), we might need to create it
        # Or if we are running in the root of where `viperx init` is called.
        
        # Heuristic: Are we already in a folder named 'project_name'?
        if self.root_path.name == project_name:
            # We are inside the project folder
            if not (self.root_path / "pyproject.toml").exists():
                 console.print(Panel(f"⚠️  [bold yellow]Current directory matches name but is not initialized. Hydrating:[/bold yellow] {project_name}", border_style="yellow"))
                 gen = ProjectGenerator(
                    name=project_name,
                    description=project_conf.get("description", ""),
                    type=settings_conf.get("type", TYPE_CLASSIC),
                    author=project_conf.get("author", None),
                    license=project_conf.get("license", DEFAULT_LICENSE),
                    builder=project_conf.get("builder", DEFAULT_BUILDER),
                    use_env=settings_conf.get("use_env", True),
                    use_config=settings_conf.get("use_config", True),
                    framework=settings_conf.get("framework", FRAMEWORK_PYTORCH),
                    verbose=self.verbose
                )
                 # generate() expects parent dir, and will operate on parent/name (which is self.root_path)
                 gen.generate(self.root_path.parent)
            else:
                console.print(Panel(f"♻️  [bold blue]Syncing Project:[/bold blue] {project_name}", border_style="blue"))
            current_root = self.root_path
        else:
            # We are outside, check if it exists
            if target_dir.exists() and (target_dir / "pyproject.toml").exists():
                console.print(Panel(f"♻️  [bold blue]Updating Existing Project:[/bold blue] {project_name}", border_style="blue"))
                current_root = target_dir
            else:
                if target_dir.exists():
                     console.print(Panel(f"⚠️  [bold yellow]Directory exists but not initialized. Hydrating:[/bold yellow] {project_name}", border_style="yellow"))
                else:
                     console.print(Panel(f"🚀 [bold green]Creating New Project:[/bold green] {project_name}", border_style="green"))
                
                # Create Root (or Hydrate)
                gen = ProjectGenerator(
                    name=project_name,
                    description=project_conf.get("description", ""),
                    type=settings_conf.get("type", TYPE_CLASSIC),
                    author=project_conf.get("author", None),
                    license=project_conf.get("license", DEFAULT_LICENSE),
                    builder=project_conf.get("builder", DEFAULT_BUILDER),
                    use_env=settings_conf.get("use_env", True),
                    use_config=settings_conf.get("use_config", True),
                    framework=settings_conf.get("framework", FRAMEWORK_PYTORCH),
                    verbose=self.verbose
                )
                gen.generate(self.root_path)
                current_root = target_dir
        
        # 2. Copy Config to Root (Source of Truth)
        # Only if we aren't reading the one already there
        system_config_path = current_root / "viperx.yaml"
        if self.config_path.absolute() != system_config_path.absolute():
            import shutil
            shutil.copy2(self.config_path, system_config_path)
            console.print(f"[dim]Saved configuration to {system_config_path.name}[/dim]")

        # 3. Handle Workspace Packages
        packages = workspace_conf.get("packages", [])
        if packages:
            console.print(f"\n📦 [bold]Processing {len(packages)} workspace packages...[/bold]")
            
            for pkg in packages:
                pkg_name = pkg.get("name")
                pkg_path = current_root / "src" / pkg_name.replace("-", "_") # Approximate check
                
                # We instantiate a generator for this package
                pkg_gen = ProjectGenerator(
                    name=pkg_name,
                    description=pkg.get("description", ""),
                    type=pkg.get("type", TYPE_CLASSIC),
                    author=project_conf.get("author", "Your Name"), # Inherit author
                    use_env=settings_conf.get("use_env", True),     # Inherit settings
                    use_config=settings_conf.get("use_config", True),
                    use_readme=pkg.get("use_readme", True),
                    framework=pkg.get("framework", FRAMEWORK_PYTORCH),
                    verbose=self.verbose
                )
                
                # Check if package seems to exist (ProjectGenerator handles upgrade logic too)
                pkg_gen.add_to_workspace(current_root)

        console.print(Panel(f"✨ [bold green]Configuration Applied Successfully![/bold green]\nProject is up to date with {self.config_path.name}", border_style="green"))
