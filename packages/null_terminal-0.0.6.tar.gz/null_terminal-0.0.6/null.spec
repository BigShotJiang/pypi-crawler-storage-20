# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec file for Null Terminal."""

import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# Collect all submodules from our packages
hiddenimports = []
for pkg in ['ai', 'commands', 'handlers', 'managers', 'mcp', 'prompts', 
            'screens', 'tools', 'utils', 'widgets']:
    hiddenimports.extend(collect_submodules(pkg))

# Also include textual and its dependencies
hiddenimports.extend(collect_submodules('textual'))
hiddenimports.extend(collect_submodules('rich'))

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('styles', 'styles'),  # Include TCSS files
        ('prompts', 'prompts'),  # Include prompt templates
    ],
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='null',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,  # TUI app needs console
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='NullTerminal',
)
