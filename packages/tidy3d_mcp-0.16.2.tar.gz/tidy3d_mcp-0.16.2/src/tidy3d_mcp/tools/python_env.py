from __future__ import annotations

from typing import Annotated, Any

from fastmcp.exceptions import ToolError
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent
from pydantic import Field

from ._dispatcher import invoke_extension_route

DetectionPayload = dict[str, Any]


async def detect_python_environment(
    resource: Annotated[str | None, Field(description='Optional resource URI to scope detection', default=None)] = None,
) -> ToolResult:
    """Resolve the active Python interpreter, environment manager, and project manager."""
    params: dict[str, object | None] = {}
    if resource:
        params['resource'] = resource
    result = invoke_extension_route('/python/detect', params, timeout=10.0)
    error_msg = result.get('error')
    if isinstance(error_msg, str) and error_msg:
        raise ToolError(f'python detection failed: {error_msg}')
    payload = result.get('result')
    structured: DetectionPayload = payload if isinstance(payload, dict) else {'detectionSource': 'none'}
    python_exec = structured.get('pythonExec')
    env_manager = structured.get('envManager')
    project_manager = structured.get('projectManager')
    summary_bits = []
    if python_exec:
        summary_bits.append(f'interpreter: {python_exec}')
    if env_manager:
        summary_bits.append(f'env manager: {env_manager}')
    if project_manager:
        summary_bits.append(f'project manager: {project_manager}')
    detection_source = structured.get('detectionSource')
    summary = '; '.join(summary_bits) or 'No Python environment detected'
    if detection_source:
        summary = f'{summary} (source={detection_source})'
    return ToolResult(
        content=[TextContent(type='text', text=summary)],
        structured_content=structured,
    )
