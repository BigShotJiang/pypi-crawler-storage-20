from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import time
import tomllib
import urllib.error
import urllib.request
import webbrowser

from fastmcp import FastMCP
from fastmcp.client.auth import BearerAuth
from fastmcp.client.transports import StreamableHttpTransport
from fastmcp.server.proxy import ProxyClient
from fastmcp.tools import Tool

from urllib.parse import urlencode
from pathlib import Path

from .tools import (
    configure_dispatcher,
    capture,
    detect_python_environment,
    rotate_viewer,
    set_bridge_url,
    show_structures,
    validate_simulation,
)


def _select_free_port() -> int:
    """Return a host-local TCP port that is currently unused."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as candidate:
        candidate.bind(('127.0.0.1', 0))
        _, port = candidate.getsockname()
    return int(port)


def _viewer_bridge_uri(port: int, host: str | None) -> str:
    """Build the deeplink URI used to request a viewer bridge."""
    params: dict[str, str] = {'port': str(port)}
    if host:
        params['host'] = host
    normalized = (host or '').lower()
    scheme: str | None
    if 'cursor' in normalized:
        scheme = 'cursor'
    elif 'vscode' in normalized:
        scheme = 'vscode'
    else:
        scheme = None
    query = urlencode(params)
    extension_id = 'Flexcompute.tidy3d'
    if scheme:
        return f'{scheme}://{extension_id}/bridge?{query}'
    return f'tidy3d://bridge?{query}'


def _open_deeplink(uri: str) -> None:
    """Launch the viewer deeplink or fail if unavailable."""
    launched = webbrowser.open(uri, new=0, autoraise=True)
    if not launched:
        raise RuntimeError('deeplink launch was rejected by the host OS')


def _await_bridge(port: int, timeout: float = 15.0) -> str:
    """Wait for the viewer bridge to bind and return its base URL."""
    deadline = time.monotonic() + timeout
    endpoint = f'http://127.0.0.1:{port}'
    while True:
        payload = json.dumps({}).encode('utf-8')
        request = urllib.request.Request(
            f'{endpoint}/viewer/ping',
            data=payload,
            headers={'Content-Type': 'application/json'},
            method='POST',
        )
        try:
            with urllib.request.urlopen(request, timeout=1.0):
                return endpoint
        except urllib.error.URLError:
            if time.monotonic() >= deadline:
                break
            time.sleep(0.25)
    raise RuntimeError('viewer bridge did not start within the expected window')


def _bootstrap_viewer_bridge(host: str | None) -> None:
    """Activate the viewer bridge via deeplink and persist its location."""
    port = _select_free_port()
    deeplink = _viewer_bridge_uri(port, host)
    _open_deeplink(deeplink)
    bridge_url = _await_bridge(port)
    set_bridge_url(bridge_url)


def _descriptor_path() -> Path:
    return Path.home() / '.tidy3d' / 'tidy3d-extension.json'


def _legacy_tidy3d_config_dir() -> Path:
    """Return the legacy Tidy3D config directory (~/.tidy3d)."""
    return Path.home() / '.tidy3d'


def _xdg_config_home() -> Path:
    """Return the XDG config home (~/.config) honoring XDG_CONFIG_HOME."""
    candidate = os.getenv('XDG_CONFIG_HOME', '').strip()
    if candidate:
        return Path(candidate).expanduser()
    return Path.home() / '.config'


def _canonical_tidy3d_config_dir() -> Path:
    """Return the canonical Tidy3D config directory (~/.config/tidy3d)."""
    return _xdg_config_home() / 'tidy3d'


def _tidy3d_config_paths() -> tuple[Path, ...]:
    """Return config file candidates in deterministic preference order."""
    config_dirs: list[Path] = []
    base_override = os.getenv('TIDY3D_BASE_DIR', '').strip()
    if base_override:
        base_dir = Path(base_override).expanduser()
        config_dirs.extend((base_dir / 'config', base_dir))
    config_dirs.extend((_canonical_tidy3d_config_dir(), _legacy_tidy3d_config_dir()))
    candidates: list[Path] = []
    for config_dir in config_dirs:
        candidates.extend((config_dir / 'config.toml', config_dir / 'config'))
    return tuple(dict.fromkeys(candidates))


def _api_key_from_env() -> str | None:
    """Return the API key from SIMCLOUD_APIKEY if set."""
    candidate = os.getenv('SIMCLOUD_APIKEY', '').strip()
    if candidate:
        return candidate
    return None


def _load_toml_config(config_path: Path) -> tuple[dict[str, object] | None, str | None]:
    """Load config_path as TOML; returns (data, error) for fallback-friendly resolution."""
    try:
        with config_path.open('rb') as handle:
            data = tomllib.load(handle)
    except (FileNotFoundError, IsADirectoryError, NotADirectoryError):
        return None, None
    except tomllib.TOMLDecodeError as exc:
        return None, f'Cannot parse {config_path}: {exc}'
    except OSError as exc:
        return None, f'Cannot read {config_path}: {exc}'
    if isinstance(data, dict):
        return data, None
    return None, f'Cannot parse {config_path}: expected a TOML table'


def _extract_api_key(config: dict[str, object]) -> str | None:
    """Extract the Tidy3D API key from TOML config data."""
    web = config.get('web')
    if isinstance(web, dict):
        candidate = web.get('apikey')
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    candidate = config.get('apikey')
    if isinstance(candidate, str) and candidate.strip():
        return candidate.strip()
    return None


def _resolve_api_key(explicit: str | None) -> str:
    """Resolve the API key from CLI, environment, or Tidy3D config."""
    if explicit is not None:
        candidate = explicit.strip()
        if not candidate:
            raise RuntimeError('API key provided via --api-key is empty or whitespace only')
        return candidate

    candidate = _api_key_from_env()
    if candidate:
        return candidate

    config_read_errors: list[str] = []
    for config_path in _tidy3d_config_paths():
        data, error = _load_toml_config(config_path)
        if error:
            config_read_errors.append(error)
            continue
        if data is None:
            continue
        candidate = _extract_api_key(data)
        if candidate:
            return candidate
    if config_read_errors:
        raise RuntimeError(
            'API key required. Provide --api-key, set SIMCLOUD_APIKEY, or configure '
            '~/.config/tidy3d/config.toml ([web].apikey) or ~/.tidy3d/config. '
            f'Failed to read some config locations:\n{"\n".join(config_read_errors)}'
        )
    raise RuntimeError(
        'API key required. Provide --api-key, set SIMCLOUD_APIKEY, or configure '
        '~/.config/tidy3d/config.toml ([web].apikey) or ~/.tidy3d/config'
    )


def _bridge_url_from_descriptor(host: str | None) -> str | None:
    target_host = host or 'vscode'
    try:
        raw = _descriptor_path().read_text(encoding='utf-8')
    except FileNotFoundError:
        return None
    except OSError:
        return None
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    candidate = payload.get(target_host)
    if not isinstance(candidate, dict):
        return None
    value = candidate.get('bridge_url')
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _resolve_requested_bridge(host: str | None, explicit: str | None) -> str | None:
    sources = [
        explicit,
        os.getenv('TIDY3D_VIEWER_BRIDGE_URL', '').strip() or None,
        _bridge_url_from_descriptor(host),
    ]
    for entry in sources:
        if entry:
            return entry
    return None


def main(argv: list[str] | None = None):
    """Launch the FastMCP proxy with host-aware bookkeeping."""
    parser = argparse.ArgumentParser(prog='tidy3d-mcp')
    parser.add_argument('--host', choices=('vscode', 'cursor'), default='vscode')
    parser.add_argument('--api-key', default=None)
    parser.add_argument('--viewer-bridge', default=None)
    parser.add_argument('--enable-viewer', action='store_true')
    args = parser.parse_args(argv)

    try:
        api_key = _resolve_api_key(args.api_key)
    except RuntimeError as exc:
        parser.error(str(exc))
    bridge_arg = _resolve_requested_bridge(args.host, args.viewer_bridge)
    configure_dispatcher(args.host, bridge_arg)
    viewer_enabled = bool(args.enable_viewer)
    if viewer_enabled:
        if bridge_arg:
            set_bridge_url(bridge_arg)
        else:
            try:
                _bootstrap_viewer_bridge(args.host)
            except Exception as exc:
                print(f'Viewer bridge initialization failed: {exc}', file=sys.stderr)
                set_bridge_url(None)
                viewer_enabled = False
    mcp_url = os.getenv('REMOTE_MCP_URL', 'https://flexagent.simulation.cloud/')
    auth = BearerAuth(token=api_key)
    # Production WAF blocks non-browser user agents; force a friendly default and allow overrides.
    user_agent = os.getenv('TIDY3D_MCP_USER_AGENT', '').strip() or 'Mozilla/5.0 (compatible; tidy3d-mcp)'
    headers = {'User-Agent': user_agent}
    transport = StreamableHttpTransport(mcp_url, headers=headers, auth=auth)
    proxy = FastMCP.as_proxy(ProxyClient(transport), name="Tidy3D")

    proxy.add_tool(Tool.from_function(detect_python_environment))
    if viewer_enabled:
        proxy.add_tool(Tool.from_function(validate_simulation))
        proxy.add_tool(Tool.from_function(rotate_viewer))
        proxy.add_tool(Tool.from_function(capture))
        proxy.add_tool(Tool.from_function(show_structures))

    proxy.run(show_banner=False)


if __name__ == '__main__':
    main()
