# -*- coding: utf-8 -*-
"""
    Setup file for nuls2-python (nuls2 package).
    Use setup.cfg to configure your project.

    This file was generated with PyScaffold 3.2.1.
    PyScaffold helps you to put up the scaffold of your new Python project.
    Learn more under: https://pyscaffold.org/
"""
import sys

from setuptools import setup


if __name__ == "__main__":
    setup(use_pyscaffold=True)
