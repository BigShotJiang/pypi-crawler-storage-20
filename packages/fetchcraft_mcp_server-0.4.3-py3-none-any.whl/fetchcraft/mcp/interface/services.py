"""
Service interfaces for the Fetchcraft MCP Server.

These abstract base classes define the contracts that service implementations
must follow. Users can provide custom implementations for dependency injection.
"""
from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any

from pydantic import BaseModel


class FindFilesResult(BaseModel):
    """Result model for find_files including pagination info."""
    nodes: List[Any]
    has_more: bool


class FindFilesService(ABC):
    """
    Abstract interface for file finding/search functionality.
    
    Implementations should provide semantic search capabilities
    over a document collection.
    """

    @abstractmethod
    async def find_files(
        self, 
        query: str, 
        num_results: int = 10, 
        offset: int = 0
    ) -> FindFilesResult:
        """
        Find files using semantic search with pagination.
        
        Args:
            query: The search query
            num_results: Number of results to return
            offset: Offset for pagination
            
        Returns:
            FindFilesResult with nodes and has_more flag
        """
        ...


class DocumentContent(BaseModel):
    """Response model for document content."""
    node_id: str
    filename: str
    source: str
    content: str
    metadata: Dict[str, Any] = {}


class QueryResponse(BaseModel):
    """Response model for query results."""
    answer: str
    citations: Dict[str, Any] = {}
    model: str


class QueryService(ABC):
    """
    Abstract interface for RAG query functionality.
    
    Implementations should provide question-answering capabilities
    using retrieval-augmented generation.
    """

    @abstractmethod
    async def query(
        self,
        question: str,
        top_k: int = 3,
        include_citations: bool = True
    ) -> QueryResponse:
        """
        Query the RAG system with a question.
        
        Args:
            question: The question to ask
            top_k: Number of documents to retrieve
            include_citations: Whether to include citations in response
            
        Returns:
            QueryResponse with answer, citations, and model info
        """
        ...


class DocumentPreviewService(ABC):
    """
    Abstract interface for document preview functionality.
    
    Implementations should provide document content retrieval
    for displaying full document previews.
    """

    @abstractmethod
    async def get_document(self, node_id: str) -> Optional[DocumentContent]:
        """
        Get document content by node ID.
        
        Args:
            node_id: The ID of the node to retrieve
            
        Returns:
            DocumentContent with full document content, or None if not found
        """
        ...
