"""Null check predicate."""
