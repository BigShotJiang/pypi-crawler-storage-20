"""Tests for sxth-mind."""
