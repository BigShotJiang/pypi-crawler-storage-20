mod selector;
mod tree_traversal;

use crate::selector::Selector;
use crate::tree_traversal::{calc_apply, calc_feature_delta_sum, calc_paths_sum};
use pyo3::prelude::*;

#[pymodule(gil_used = false)]
fn calc_trees(py: Python, m: &Bound<PyModule>) -> PyResult<()> {
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    m.add("selector_dtype", Selector::dtype(py)?)?;
    m.add_function(wrap_pyfunction!(calc_paths_sum, m)?)?;
    m.add_function(wrap_pyfunction!(calc_feature_delta_sum, m)?)?;
    m.add_function(wrap_pyfunction!(calc_apply, m)?)?;
    Ok(())
}
