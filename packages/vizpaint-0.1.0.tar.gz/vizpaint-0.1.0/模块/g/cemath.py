from math import pi
def a():
    a = int(input("请输入一个数："))
    b = int(input("请输入一个数："))
    c = a+b
    print("{a}和{b}的和是：{c}".format(a = a,b = b,c = c))
def b():
    a = int(input("请输入一个数："))
    b = int(input("请输入一个数："))
    c = a - b
    if c < 0:
        d = input(r"得数小于零，是否继续（y/n）?")
        if d == 'y':
            print("{a}和{b}的差是：{c}".format(a=a, b=b, c=c))
        else:
            if b == 'n':
                print("已退出")
def c():
    a = int(input("请输入一个数："))
    b = int(input("请输入一个数："))
    c = a * b
    print("{a}和{b}的积是：{c}".format(a=a, b=b, c=c))
def d():
    a = int(input("请输入一个数："))
    b = int(input("请输入一个数："))
    try:
        c = a / b
        print("{a}和{b}的商是：{c}".format(a=a, b=b, c=c))
    except:
        print('出现异常')
def pi():
    a = int(input("请输入半径："))
    b = pi
    c = a * b
    print("这个圆形的面积是：{:.2f}".format(c))
