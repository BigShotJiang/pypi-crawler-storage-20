import vizpaint
vizpaint.scatter_plot('a,', ' b', 'c', 'd', 1, 1, 1, 1)