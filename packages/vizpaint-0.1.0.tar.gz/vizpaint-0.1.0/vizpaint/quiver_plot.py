import numpy as np
import matplotlib as plt
def quiver_plot(x=None, y=None, u=None, v=None, title="Vector Field"):
    """绘制矢量场图"""
    fig, ax = plt.subplots(figsize=(10, 8))

    if x is None:
        x, y = np.meshgrid(np.arange(-2, 2, 0.2), np.arange(-2, 2, 0.2))
        u = np.cos(x + y)
        v = np.sin(x - y)

    quiver = ax.quiver(x, y, u, v)
    ax.set_title(title, fontsize=14)

    return fig, ax, quiver