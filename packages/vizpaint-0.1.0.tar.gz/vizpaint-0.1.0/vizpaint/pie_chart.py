# paint/pie_chart.py
import matplotlib.pyplot as plt


def pie_chart(a, b, c, d, e, f, g, h, i, j, k, l):
    """
    绘制饼图

    参数:
    a,b,c,d,e,f: 标签
    g,h,i,j,k,l: 对应的数值
    """
    labels = [a, b, c, d, e, f]
    sizes = [g, h, i, j, k, l]
    colors = ['green', 'blue', 'red', 'yellow', 'purple', 'orange']

    plt.figure(figsize=(8, 6))
    plt.pie(sizes, labels=labels, colors=colors,
            autopct='%1.1f%%', shadow=True, startangle=90)
    plt.axis('equal')

    plt.show()
