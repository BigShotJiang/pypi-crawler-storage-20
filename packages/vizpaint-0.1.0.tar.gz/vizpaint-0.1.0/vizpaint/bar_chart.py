# paint/bar_chart.py
import matplotlib.pyplot as plt
import numpy as np


def bar_chart(a, b, c, d, e, f):
    """
    绘制条形图

    参数:
    a,b,c,d,e: 条形的高度值
    f: 条形的颜色
    """
    n = 6  # 6个条形
    y = [a, b, c, d, e, 0]  # 你只给了5个值，所以第6个设为0
    index = np.arange(n)

    plt.figure(figsize=(10, 6))
    plt.bar(index, y, color=f, edgecolor='black', alpha=0.8)

    # 添加标签
    plt.xlabel('类别')
    plt.ylabel('数值')
    plt.title('条形图')
    plt.xticks(index, ['A', 'B', 'C', 'D', 'E', 'F'])

    # 在条形上显示数值
    for i, v in enumerate(y):
        plt.text(i, v + 0.02, str(v), ha='center', va='bottom')

    plt.tight_layout()
    plt.show()