# paint/area_chart.py
import matplotlib.pyplot as plt
import numpy as np


def area_chart(x_data=None, y_data_list=None, labels=None,
               title="Area Chart", xlabel="X", ylabel="Y",
               colors=None, alpha=0.5, stacked=False):
    """
    绘制面积图

    参数:
    x_data: X轴数据
    y_data_list: Y轴数据列表
    labels: 数据标签
    title: 图表标题
    xlabel: X轴标签
    ylabel: Y轴标签
    colors: 颜色列表
    alpha: 透明度
    stacked: 是否堆叠
    """
    fig, ax = plt.subplots(figsize=(10, 6))

    # 生成默认数据
    if x_data is None:
        x_data = np.arange(1, 11)
    if y_data_list is None:
        y_data_list = [
            np.random.randint(10, 50, 10),
            np.random.randint(20, 60, 10),
            np.random.randint(5, 40, 10)
        ]
        labels = ['Product A', 'Product B', 'Product C']

    # 设置默认颜色
    if colors is None:
        colors = plt.cm.Pastel1(np.linspace(0, 1, len(y_data_list)))

    # 绘制面积图
    if stacked:
        # 堆叠面积图
        y_stacked = np.vstack(y_data_list)
        ax.stackplot(x_data, y_stacked, labels=labels,
                     colors=colors, alpha=alpha)
    else:
        # 普通面积图
        for i, y_data in enumerate(y_data_list):
            ax.fill_between(x_data, 0, y_data,
                            alpha=alpha, color=colors[i % len(colors)],
                            label=labels[i] if labels else None)

    # 设置图表属性
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xlabel(xlabel, fontsize=12)
    ax.set_ylabel(ylabel, fontsize=12)

    ax.grid(True, linestyle='--', alpha=0.3)

    if labels:
        ax.legend(fontsize=10, loc='best')

    plt.tight_layout()
    return fig, ax