

# paint/__init__.py
""""
Paint Chart Package - 图表绘制工具包
提供丰富的图表绘制功能
"""

__version__ = "0.1.0"
__author__ = "Chart Package Team"

# 定义所有可导出的函数
__all__ = [
    # 基础图表
    'pie_chart',
    'bar_chart',
    'curve_statistical_chart',
    'scatter_plot',
    # 新增图表类型
    'line_plot',
    'histogram',
    'box_plot',
    'area_chart',
    'radar_chart',
    'heatmap',
    'pair_plot',
    'violin_plot',
    'bubble_chart',
    'stacked_bar_chart',
    # 实用函数
    'set_style',
    'show_all',
    'clear_all',
    'save_figure',
    'get_version',
    'create_subplots',
    'rose_chart',
    'surface_3d',
    'scatter_3d',
    'stream_plot',
    'treemap',
    'quiver_plot'
]

# 导入基础图表函数
from .pie_chart import pie_chart
from .bar_chart import bar_chart
from .curve_statistical_chart import curve_statistical_chart
from .scatter_plot import scatter_plot

# 导入新增图表函数
from .line_plot import line_plot
from .histogram import histogram
from .box_plot import box_plot
from .area_chart import area_chart
from .radar_chart import radar_chart
from .heatmap import heatmap
from .pair_plot import pair_plot
from .violin_plot import violin_plot
from .bubble_chart import bubble_chart
from .stacked_bar_chart import stacked_bar_chart
from .rose_chart import rose_chart
from .surface_3d import surface_3d
from .scatter_3d import scatter_3d
from .stream_plot import stream_plot
from .treemap import treemap
from .quiver_plot import quiver_plot


# 导入实用函数
import matplotlib.pyplot as plt
import numpy as np

def set_style(style='default'):
    """设置图表样式"""
    try:
        plt.style.use(style)
        return True
    except:
        plt.style.use('default')
        print(f"样式 '{style}' 不可用，使用默认样式")
        return False

def show_all():
    """显示所有图表"""
    plt.show()

def clear_all():
    """清除所有图表"""
    plt.close('all')

def save_figure(filename, dpi=300, transparent=False):
    """保存当前图表"""
    plt.savefig(filename, dpi=dpi, transparent=transparent,
                bbox_inches='tight')
    plt.close()

def get_version():
    """获取包版本"""
    return __version__

def create_subplots(nrows=1, ncols=1, figsize=(10, 8), **kwargs):
    """创建子图布局"""
    return plt.subplots(nrows, ncols, figsize=figsize, **kwargs)

# 包初始化消息
