from setuptools import setup, find_packages

setup(
    name="vizpaint", # 包名，在PyPI上必须唯一
    version="0.1.0",
    author="Your Name",
    description="A comprehensive data visualization library",
    packages=find_packages(),
    install_requires=["matplotlib>=3.3", "numpy"], # 关键依赖
    python_requires=">=3.7",
)