
# 打包上传 python setup.py sdist upload
# 打包并安装 python setup.py sdist install
# twine upload --repository-url https://test.pypi.org/legacy/ dist/* #上传到测试
# pip install --index-url https://pypi.org/simple/ kcwebs   #安装测试服务上的kcwebs pip3 install kcwebs==4.12.4 -i https://pypi.org/simple/
# 安装 python setup.py install
#############################################  pip3.8 install kcwebs==6.4.15 -i https://pypi.org/simple
import os,sys
from setuptools import setup, find_packages,Extension
current_dir = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, current_dir)
from kcwredis import kcwredisinfo
confkcws={}
confkcws['name']=kcwredisinfo['name']
confkcws['version']=kcwredisinfo['version']
confkcws['description']=kcwredisinfo['description']
confkcws['long_description']=kcwredisinfo['long_description']
confkcws['license']=kcwredisinfo['license']
confkcws['url']=kcwredisinfo['url']
confkcws['author']=kcwredisinfo['author']
confkcws['author_email']=kcwredisinfo['author_email']
confkcws['maintainer']=kcwredisinfo['maintainer']
confkcws['maintainer_email']=kcwredisinfo['maintainer_email']
def get_file(folder='./',lists=[]):
    lis=os.listdir(folder)
    for files in lis:
        if not os.path.isfile(folder+"/"+files):
            if files=='__pycache__' or files=='.git':
                pass
            else:
                lists.append(folder+"/"+files)
                get_file(folder+"/"+files,lists)
        else:
            pass
    return lists
def start():
    b=get_file("kcwredis",['kcwredis'])
    setup(
        name = confkcws["name"],
        version = confkcws["version"],
        keywords = "kcwredis"+confkcws['version'],
        description = confkcws["description"],
        long_description = confkcws["long_description"],
        license = confkcws["license"],
        author = confkcws["author"],
        author_email = confkcws["author_email"],
        maintainer = confkcws["maintainer"],
        maintainer_email = confkcws["maintainer_email"],
        url=confkcws['url'],
        packages =  b,

        
        install_requires = ['redis==3.3.8'], #第三方包
        package_data = {
            '': ['*.html', '*.js','*.css','*.jpg','*.png','*.gif'],
        }
    )
start()