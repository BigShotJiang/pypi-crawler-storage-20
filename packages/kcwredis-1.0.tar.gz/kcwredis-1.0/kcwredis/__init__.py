# -*- coding: utf-8 -*-
__version__ = '1.0'
kcwredisinfo={}
kcwredisinfo['name']='kcwredis'
kcwredisinfo['version']=__version__
kcwredisinfo['description']='kcwebs'
kcwredisinfo['long_description']=''
kcwredisinfo['license']='MIT License'
kcwredisinfo['url']=''
kcwredisinfo['author']='百里'
kcwredisinfo['author_email']='kcwebs@kwebapp.cn'
kcwredisinfo['maintainer']='坤坤'
kcwredisinfo['maintainer_email']='fk1402936534@qq.com'
from .redisclass import redisclass
redis=redisclass()