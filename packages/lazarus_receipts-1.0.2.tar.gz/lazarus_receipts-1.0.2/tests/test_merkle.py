"""Tests for Merkle proof verification."""

import pytest
from lazarus_receipts import (
    hash256,
    verify_merkle_proof_directional,
    verify_merkle_proof_legacy_sorted,
)


class TestDirectionalProof:
    """Tests for positional_v1_0_1 directional proofs."""

    def test_directional_proof_verifies(self):
        """Directional proof with correct sides verifies."""
        # Build a simple 2-leaf tree
        leaf_a = hash256(b"leaf_a")
        leaf_b = hash256(b"leaf_b")

        # Root = H(leaf_a || leaf_b) - leaf_a on left, leaf_b on right
        root = hash256(leaf_a + leaf_b)

        # Proof for leaf_a: sibling (leaf_b) is on RIGHT
        proof_a = [{"side": "R", "hash": leaf_b.hex()}]
        assert verify_merkle_proof_directional(leaf_a, root, proof_a) is True

        # Proof for leaf_b: sibling (leaf_a) is on LEFT
        proof_b = [{"side": "L", "hash": leaf_a.hex()}]
        assert verify_merkle_proof_directional(leaf_b, root, proof_b) is True

    def test_side_flip_fails(self):
        """Flipping side bit causes verification failure."""
        leaf_a = hash256(b"leaf_a")
        leaf_b = hash256(b"leaf_b")
        root = hash256(leaf_a + leaf_b)

        # Correct proof for leaf_a has side="R"
        # Flip to "L" - should fail
        wrong_proof = [{"side": "L", "hash": leaf_b.hex()}]
        assert verify_merkle_proof_directional(leaf_a, root, wrong_proof) is False

    def test_leaf_order_yields_different_root(self):
        """Different leaf order produces different root (positional rule)."""
        leaf_a = hash256(b"leaf_a")
        leaf_b = hash256(b"leaf_b")

        # H(A || B) != H(B || A) unless A == B
        root_ab = hash256(leaf_a + leaf_b)
        root_ba = hash256(leaf_b + leaf_a)

        assert root_ab != root_ba, "Positional rule: order matters"

        # Proof valid for one root fails for the other
        proof = [{"side": "R", "hash": leaf_b.hex()}]
        assert verify_merkle_proof_directional(leaf_a, root_ab, proof) is True
        assert verify_merkle_proof_directional(leaf_a, root_ba, proof) is False

    def test_empty_proof_fails(self):
        """Empty proof list fails."""
        leaf = hash256(b"leaf")
        root = hash256(b"root")
        assert verify_merkle_proof_directional(leaf, root, []) is False

    def test_missing_side_fails(self):
        """Proof node without side fails."""
        leaf = hash256(b"leaf")
        root = hash256(b"root")
        proof = [{"hash": leaf.hex()}]  # Missing "side"
        assert verify_merkle_proof_directional(leaf, root, proof) is False

    def test_missing_hash_fails(self):
        """Proof node without hash fails."""
        leaf = hash256(b"leaf")
        root = hash256(b"root")
        proof = [{"side": "L"}]  # Missing "hash"
        assert verify_merkle_proof_directional(leaf, root, proof) is False

    def test_three_level_tree(self):
        """Three-level tree proof verifies."""
        # Level 0 (leaves)
        leaf_a = hash256(b"a")
        leaf_b = hash256(b"b")
        leaf_c = hash256(b"c")
        leaf_d = hash256(b"d")

        # Level 1
        node_ab = hash256(leaf_a + leaf_b)
        node_cd = hash256(leaf_c + leaf_d)

        # Level 2 (root)
        root = hash256(node_ab + node_cd)

        # Proof for leaf_a: sibling_b on R, then node_cd on R
        proof_a = [
            {"side": "R", "hash": leaf_b.hex()},
            {"side": "R", "hash": node_cd.hex()},
        ]
        assert verify_merkle_proof_directional(leaf_a, root, proof_a) is True

        # Proof for leaf_d: sibling_c on L, then node_ab on L
        proof_d = [
            {"side": "L", "hash": leaf_c.hex()},
            {"side": "L", "hash": node_ab.hex()},
        ]
        assert verify_merkle_proof_directional(leaf_d, root, proof_d) is True


class TestLegacySorted:
    """Tests for legacy sorted proofs (deprecated)."""

    def test_legacy_sorted_emits_warning(self):
        """Legacy sorted function emits deprecation warning."""
        leaf = hash256(b"leaf")
        sibling = hash256(b"sibling")

        # Sorted: min first
        if leaf < sibling:
            root = hash256(leaf + sibling)
        else:
            root = hash256(sibling + leaf)

        with pytest.warns(DeprecationWarning, match="NOT auditor-grade"):
            result = verify_merkle_proof_legacy_sorted(
                leaf, root, [sibling.hex()]
            )
        assert result is True

    def test_legacy_sorted_loses_position(self):
        """Legacy sorted cannot distinguish leaf positions."""
        leaf_a = hash256(b"leaf_a")
        leaf_b = hash256(b"leaf_b")

        # Sorted always produces same result regardless of original order
        if leaf_a < leaf_b:
            root = hash256(leaf_a + leaf_b)
        else:
            root = hash256(leaf_b + leaf_a)

        # Both leaves verify against same root - position lost
        with pytest.warns(DeprecationWarning):
            result_a = verify_merkle_proof_legacy_sorted(
                leaf_a, root, [leaf_b.hex()]
            )
        with pytest.warns(DeprecationWarning):
            result_b = verify_merkle_proof_legacy_sorted(
                leaf_b, root, [leaf_a.hex()]
            )

        assert result_a is True
        assert result_b is True
