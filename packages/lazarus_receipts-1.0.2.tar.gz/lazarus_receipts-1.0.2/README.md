# lazarus-receipts

Python SDK for Lazarus Receipts verification.

## Installation

```bash
pip install lazarus-receipts
```

## Quick Start

```python
from lazarus_receipts import (
    verify_merkle_proof_directional,
    hash256,
    bytes_to_hex
)

# Verify a directional Merkle proof (positional_v1_0_1)
result = verify_merkle_proof_directional(
    leaf_hash,
    expected_root,
    [
        {"side": "L", "hash": sibling1_hex},
        {"side": "R", "hash": sibling2_hex}
    ]
)

if result:
    print("Proof verified!")
else:
    print("Verification failed")
```

## API

### `hash256(data: bytes) -> bytes`

SHA-256 hash.

### `receipt_hash_from_json_bytes(receipt_json: bytes) -> bytes`

Hash receipt JSON bytes (placeholder until canonicalization lands).

### `verify_merkle_proof_directional(leaf_hash, expected_root, proof_nodes)`

Verifies a Merkle proof using positional v1.0.1 rule:
- `L`: `cur = H(sibling || cur)`
- `R`: `cur = H(cur || sibling)`

### `verify_merkle_proof_legacy_sorted(leaf_hash, expected_root, siblings_hex)`

Legacy sorted-pair verification (NOT auditor-grade). Emits deprecation warning.

## License

Apache 2.0
