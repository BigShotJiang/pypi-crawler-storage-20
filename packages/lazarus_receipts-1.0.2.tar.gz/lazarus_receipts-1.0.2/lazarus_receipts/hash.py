"""Hash utilities for Lazarus Receipts."""

import hashlib


def hash256(data: bytes) -> bytes:
    """SHA-256 hash."""
    return hashlib.sha256(data).digest()


def hex_to_bytes(hex_str: str) -> bytes:
    """Convert hex string to bytes, validate 32-byte length."""
    buf = bytes.fromhex(hex_str)
    if len(buf) != 32:
        raise ValueError(f"Expected 32-byte hash, got {len(buf)} bytes")
    return buf


def bytes_to_hex(data: bytes) -> str:
    """Convert bytes to hex string."""
    return data.hex()


def receipt_hash_from_json_bytes(receipt_json: bytes) -> bytes:
    """Hash receipt JSON bytes.

    Placeholder until canonicalization is wired.
    """
    return hash256(receipt_json)
