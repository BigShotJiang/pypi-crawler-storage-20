"""Merkle proof verification for Lazarus Receipts."""

import warnings
from typing import List, Dict

from .hash import hash256, hex_to_bytes


def verify_merkle_proof_directional(
    leaf_hash: bytes,
    expected_root: bytes,
    proof_nodes: List[Dict[str, str]]
) -> bool:
    """Verify a Merkle proof using positional v1.0.1 rule.

    Directional proof nodes specify side:
    - "L": sibling is on left, cur = H(sibling || cur)
    - "R": sibling is on right, cur = H(cur || sibling)

    Args:
        leaf_hash: 32-byte leaf hash
        expected_root: 32-byte expected root hash
        proof_nodes: List of {"side": "L"|"R", "hash": "<hex>"}

    Returns:
        True if proof verifies, False otherwise
    """
    if not proof_nodes:
        return False

    # Validate all nodes have side and hash
    for node in proof_nodes:
        if not node.get("side") or not node.get("hash"):
            return False

    current = leaf_hash

    for node in proof_nodes:
        side = node["side"]
        sibling = hex_to_bytes(node["hash"])

        if side == "L":
            # Sibling on left: H(sibling || current)
            current = hash256(sibling + current)
        elif side == "R":
            # Sibling on right: H(current || sibling)
            current = hash256(current + sibling)
        else:
            return False

    return current == expected_root


def verify_merkle_proof_legacy_sorted(
    leaf_hash: bytes,
    expected_root: bytes,
    siblings_hex: List[str]
) -> bool:
    """Legacy sorted-pair Merkle verification.

    WARNING: NOT auditor-grade. Use verify_merkle_proof_directional instead.

    This uses sorted concatenation which loses positional information.
    Included only for backward compatibility with legacy systems.

    Args:
        leaf_hash: 32-byte leaf hash
        expected_root: 32-byte expected root hash
        siblings_hex: List of sibling hashes as hex strings

    Returns:
        True if proof verifies, False otherwise
    """
    warnings.warn(
        "legacy_sorted proofs are NOT auditor-grade. "
        "Use verify_merkle_proof_directional (positional_v1_0_1) instead.",
        DeprecationWarning,
        stacklevel=2
    )

    if not siblings_hex:
        return False

    current = leaf_hash

    for sib_hex in siblings_hex:
        sibling = hex_to_bytes(sib_hex)
        # Sorted concatenation - loses positional information
        if current < sibling:
            current = hash256(current + sibling)
        else:
            current = hash256(sibling + current)

    return current == expected_root
