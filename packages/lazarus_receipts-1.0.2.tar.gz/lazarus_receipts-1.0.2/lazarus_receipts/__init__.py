"""Lazarus Receipts SDK - Cryptographic receipt verification."""

from .hash import (
    hash256,
    hex_to_bytes,
    bytes_to_hex,
    receipt_hash_from_json_bytes,
)
from .merkle import (
    verify_merkle_proof_directional,
    verify_merkle_proof_legacy_sorted,
)

__version__ = "1.0.2"
__all__ = [
    "hash256",
    "hex_to_bytes",
    "bytes_to_hex",
    "receipt_hash_from_json_bytes",
    "verify_merkle_proof_directional",
    "verify_merkle_proof_legacy_sorted",
]
