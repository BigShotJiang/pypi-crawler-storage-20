# SwiftCl

[![MIT license](https://img.shields.io/badge/License-MIT-blue.svg)](https://lbesson.mit-license.org/)
[![image](https://img.shields.io/badge/arXiv-2412.08701-B31B1B.svg?logo=arxiv&style=flat)](https://arxiv.org/abs/2505.22718)
[![Docs](https://badgen.net/badge/icon/Documentation?icon=https://cdn.jsdelivr.net/npm/simple-icons@v13/icons/gitbook.svg&label)](https://cosmo-docs.phys.ethz.ch/SwiftCl/)
[![Source Code](https://badgen.net/badge/icon/Source%20Code?icon=gitlab&label)](https://cosmo-gitlab.phys.ethz.ch/cosmo_public/swiftcl/)

A pipeline for the computation of the angular power spectrum beyond the Limber approximation. We offer a wide range of probes such as galaxy clustering, including magnification bias, redshift-space distortions and primordial non-Gaussianity, weak lensing, including intrinsic alignment, CMB lensing and CMB integrated Sachs-Wolfe effect.

The code is presented in [Reymond et al. (2025)](https://arxiv.org/abs/2505.22718)


## Installation
The package can be installed via pip:
```
pip install swiftcl
```

## Usage
Notebooks showing the use of the code for the computation of the angular power spectrum for the different probes and showcasing a mock MCMC with emcee, HMC and Fisher matrix can be found in the notebooks folder.

## Contributions
Contributions are welcome ! If you'd like to contribute, please open an issue.
