__version__ = "2.1.5"
"""
Data Commons Client Package

This package provides a Python client for interacting with the Data Commons API.
"""

from datacommons_client.client import DataCommonsClient
from datacommons_client.endpoints.base import API
from datacommons_client.endpoints.node import NodeEndpoint
from datacommons_client.endpoints.observation import ObservationEndpoint
from datacommons_client.endpoints.resolve import ResolveEndpoint
from datacommons_client.utils.context import use_api_key

__all__ = [
    "DataCommonsClient",
    "API",
    "NodeEndpoint",
    "ObservationEndpoint",
    "ResolveEndpoint",
    "use_api_key",
]
