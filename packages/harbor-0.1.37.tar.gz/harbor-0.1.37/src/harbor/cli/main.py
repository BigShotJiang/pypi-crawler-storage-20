from typer import Typer

from harbor.cli.adapters import adapters_app
from harbor.cli.admin.admin import admin_app
from harbor.cli.cache import cache_app
from harbor.cli.datasets import datasets_app
from harbor.cli.view import view_command
from harbor.cli.jobs import jobs_app, start
from harbor.cli.sweeps import sweeps_app
from harbor.cli.tasks import tasks_app
from harbor.cli.traces import traces_app
from harbor.cli.trials import trials_app

app = Typer(no_args_is_help=True)
app.add_typer(adapters_app, name="adapters", help="Manage adapters.")
app.add_typer(tasks_app, name="tasks", help="Manage tasks.")
app.add_typer(datasets_app, name="datasets", help="Manage datasets.")
app.add_typer(jobs_app, name="jobs", help="Manage jobs.")
app.add_typer(trials_app, name="trials", help="Manage trials.")
app.add_typer(traces_app, name="traces", help="Trace export utilities.")
app.add_typer(
    sweeps_app, name="sweeps", help="Run successive sweeps to focus on successes."
)
app.add_typer(cache_app, name="cache", help="Manage Harbor cache.")
app.add_typer(admin_app, name="admin")

app.command(name="run", help="Start a job. Alias for `harbor jobs start`.")(start)
app.command(name="view", help="Start web server to browse trajectory files.")(
    view_command
)

if __name__ == "__main__":
    app()
