from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Set, Optional
import ast


@dataclass(frozen=True)
class ImportPolicy:
    allow_network: bool = False
    allow_subprocess: bool = False
    allow_ctypes: bool = False
    allow_signal: bool = False
    allow_resource: bool = False

    def denied_roots(self) -> Set[str]:
        denied = set()

        # If network is not allowed, block low-level socket.
        # This will also break most HTTP clients (requests/urllib3), which is the point.
        if not self.allow_network:
            denied.add("socket")

        if not self.allow_subprocess:
            denied.add("subprocess")

        if not self.allow_ctypes:
            denied.add("ctypes")

        if not self.allow_signal:
            denied.add("signal")

        if not self.allow_resource:
            denied.add("resource")

        return denied


def scan_import_roots(files_root: Path) -> Set[str]:
    """
    Best-effort static scan of imports in the user snapshot.
    - Relative imports (from .x import y) are treated as local and ignored.
    - Only the root module name is collected (e.g. "urllib3.util" -> "urllib3").
    """
    roots: Set[str] = set()
    py_files = [p for p in files_root.rglob("*.py") if p.is_file()]

    for p in py_files:
        try:
            src = p.read_text(encoding="utf-8")
        except Exception:
            # If we can't read the file, fail safe by rejecting.
            raise RuntimeError(f"Unable to read python file for import scan: {p}")

        try:
            tree = ast.parse(src, filename=str(p))
        except SyntaxError as e:
            raise RuntimeError(f"Syntax error while scanning imports in {p}: {e}")

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name = (alias.name or "").split(".")[0].strip()
                    if name:
                        roots.add(name)

            elif isinstance(node, ast.ImportFrom):
                # Relative import => local
                if getattr(node, "level", 0) and getattr(node, "level", 0) > 0:
                    continue
                mod = node.module
                if mod:
                    name = mod.split(".")[0].strip()
                    if name:
                        roots.add(name)

    return roots


def enforce_import_policy(files_root: Path, policy: ImportPolicy) -> None:
    roots = scan_import_roots(files_root)
    denied = policy.denied_roots()
    bad = sorted([r for r in roots if r in denied])
    if bad:
        raise PermissionError(f"Disallowed imports detected: {bad}")
