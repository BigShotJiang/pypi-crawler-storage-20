"""
Multi-agent system for groknroll

Provides build and plan agents with different permission levels.
"""

from groknroll.agents.base_agent import BaseAgent, AgentCapability
from groknroll.agents.build_agent import BuildAgent
from groknroll.agents.plan_agent import PlanAgent
from groknroll.agents.agent_manager import AgentManager

__all__ = [
    "BaseAgent",
    "AgentCapability",
    "BuildAgent",
    "PlanAgent",
    "AgentManager",
]
