"""
groknroll - The Ultimate CLI Coding Agent with RLM Core

Better than Claude Code. Local, unlimited context, autonomous.
Includes Recursive Language Models (RLM) for infinite context handling.
"""

__version__ = "2.0.0"
__author__ = "Michael Thornton"

# RLM Core exports
from groknroll.core.rlm import RLM
from groknroll.core.types import RLMChatCompletion, REPLResult, RLMIteration
from groknroll.core.exceptions import RLMError, REPLExecutionError, CostLimitExceededError

# groknroll CLI exports
from groknroll.core.agent import GroknrollAgent

# Oracle Agent exports
from groknroll.oracle import OracleAgent, CodebaseIndexer

__all__ = [
    # RLM Core
    "RLM",
    "RLMChatCompletion",
    "REPLResult",
    "RLMIteration",
    "RLMError",
    "REPLExecutionError",
    "CostLimitExceededError",
    # groknroll Agent
    "GroknrollAgent",
    # Oracle Agent
    "OracleAgent",
    "CodebaseIndexer",
]
