from .gift import *
import asyncio

api = Gift()
async def main():
    data = await api.estimatedPrice("PlushPepe-1")
    print(data)
          
asyncio.run(main()) 