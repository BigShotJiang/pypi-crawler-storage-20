"""SQL operations and canonicalization utilities."""

from typing import Callable, Optional

from fenic.api.functions import udf
from fenic.core.types import StringType
from sqlglot.errors import SqlglotError
from sqlglot.optimizer import annotate_types, canonicalize, qualify

from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import parse_sql_cached
from lineage.ingest.static_loaders.sqlglot.types import SqlglotSchema


def _canonicalize_sql(
    sql: str, dialect: str = "hive", schema: SqlglotSchema | None = None
) -> str:
    """Canonicalize SQL using sqlglot.

    Uses the global LRU-cached parser for performance.

    Args:
        sql: The SQL query string to canonicalize
        dialect: The SQL dialect to use (default: "hive")
        schema: Optional SqlglotSchema for column qualification.
                When provided, enables SELECT * expansion and column qualification.

    Returns:
        Canonicalized SQL string
    """
    # 1) Parse (uses global LRU cache)
    expr = parse_sql_cached(sql, dialect)

    # 2) Qualify tables/columns only if schema is provided
    if schema:
        schema_dict = schema.to_dict()
        try:
            expr = qualify.qualify(
                expr,
                schema=schema_dict,
                dialect=dialect,
                validate_qualify_columns=False,  # Don't fail on missing columns
            )
        except SqlglotError:
            # Fall back to unqualified if qualify fails
            pass

    # 3) Annotate types before canonicalize (required for datediff coercion)
    # Without this, canonicalize.canonicalize() fails with NoneType error
    # when processing datediff() arguments that lack type annotations.
    try:
        expr = annotate_types.annotate_types(expr, dialect=dialect)
    except SqlglotError:
        # Fall back to unannotated if type annotation fails
        pass

    # 4) Canonical form (standardizes expressions; semantics-preserving)
    expr = canonicalize.canonicalize(expr, dialect=dialect)
    # 5) Render SQL string in compact format.
    return expr.sql(dialect=dialect, pretty=False)

def create_schema_aware_canonicalize_udf(
    schema: Optional[SqlglotSchema] = None,
) -> Callable[[str, str], str]:
    """Create a Fenic UDF for SQL canonicalization with optional schema.

    The schema is captured in a closure, enabling parallel execution via Polars
    while having access to the full schema for SELECT * expansion.

    Args:
        schema: SqlglotSchema instance for SELECT * expansion and column qualification.

    Returns:
        A Fenic UDF function that can be used with df.with_column()

    Example:
        schema = artifacts.sqlglot_schema()
        canonicalize_udf = create_schema_aware_canonicalize_udf(schema)
        df = df.with_column("canonical_sql", canonicalize_udf(fc.col("sql"), fc.lit("snowflake")))
    """
    # Capture schema in closure
    captured_schema = schema

    @udf(return_type=StringType)
    def canonicalize_with_schema(sql: str, dialect: str = "hive") -> str:
        """Canonicalize SQL with schema-aware qualification."""
        try:
            return _canonicalize_sql(sql, dialect=dialect, schema=captured_schema)
        except Exception as e:
            # Return original SQL with error comment if parsing fails
            return f"-- Error canonicalizing: {str(e)}\n{sql}"

    return canonicalize_with_schema


# Default UDF without schema (for backwards compatibility)
@udf(return_type=StringType)
def canonicalize_sql_udf(sql: str, dialect: str = "hive") -> str:
    """Fenic UDF for SQL canonicalization (without schema).

    Args:
        sql: The SQL query string to canonicalize
        dialect: The SQL dialect to use (default: "hive").
                Options: "hive", "spark", "postgres", "mysql", "snowflake", etc.

    Returns:
        Canonicalized SQL string

    Note:
        For schema-aware canonicalization (SELECT * expansion), use
        create_schema_aware_canonicalize_udf() instead.
    """
    try:
        return _canonicalize_sql(sql, dialect=dialect, schema=None)
    except Exception as e:
        # Return original SQL with error comment if parsing fails
        return f"-- Error canonicalizing: {str(e)}\n{sql}"
