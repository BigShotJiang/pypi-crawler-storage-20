# AI Event Connector for Solace event brokers

This connector application makes it easy to connect your AI/ML models to Solace event brokers. It provides a simple way to build pipelines that consume events from Solace, process them with your AI/ML models, and then publish the results back to Solace. By doing this, you can greatly enhance the value of your event-driven architecture by adding AI/ML capabilities to your event-driven applications.

## Table of Contents

- [Overview](overview.md)
- [Getting Started](getting_started.md)
- [Configuration](configuration.md)
  - [Simplified App Mode](simplified-apps.md)
  - [Components](components/index.md)
  - [Transforms](transforms/index.md)
  - [SSL and Proxy Configuration](ssl_proxy_configuration.md)
  - [Logging](logging.md)
- [Custom Components](custom_components.md)
- [Tips and Tricks](tips_and_tricks.md)
- [Guides](guides/index.md)
  - [Broker Request-Response](guides/broker_request_response.md)
- [Examples](../examples/)
- [Contributing](../CONTRIBUTING.md)
- [License](../LICENSE)
