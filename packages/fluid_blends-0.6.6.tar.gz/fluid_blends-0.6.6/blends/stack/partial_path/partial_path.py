from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from blends.stack.partial_path.partial_stacks import PartialScopeStack, PartialSymbolStack
    from blends.stack.selection import PartialPathEdge


@dataclass(frozen=True, slots=True)
class PartialPath:
    start_node_index: int
    end_node_index: int
    symbol_stack_precondition: "PartialSymbolStack"
    symbol_stack_postcondition: "PartialSymbolStack"
    scope_stack_precondition: "PartialScopeStack"
    scope_stack_postcondition: "PartialScopeStack"
    edges: tuple["PartialPathEdge", ...] = ()

    def largest_symbol_stack_var(self) -> int:
        return max(
            self.symbol_stack_precondition.largest_symbol_stack_var(),
            self.symbol_stack_postcondition.largest_symbol_stack_var(),
        )

    def largest_scope_stack_var(self) -> int:
        return max(
            self.scope_stack_precondition.largest_scope_stack_var(),
            self.scope_stack_postcondition.largest_scope_stack_var(),
            self.symbol_stack_precondition.largest_scope_stack_var(),
            self.symbol_stack_postcondition.largest_scope_stack_var(),
        )

    def ensure_no_overlapping_variables(self, other: "PartialPath") -> "PartialPath":
        symbol_offset = other.largest_symbol_stack_var()
        scope_offset = other.largest_scope_stack_var()
        if symbol_offset == 0 and scope_offset == 0:
            return self
        return PartialPath(
            start_node_index=self.start_node_index,
            end_node_index=self.end_node_index,
            symbol_stack_precondition=self.symbol_stack_precondition.with_offset(
                symbol_offset, scope_offset
            ),
            symbol_stack_postcondition=self.symbol_stack_postcondition.with_offset(
                symbol_offset, scope_offset
            ),
            scope_stack_precondition=self.scope_stack_precondition.with_offset(scope_offset),
            scope_stack_postcondition=self.scope_stack_postcondition.with_offset(scope_offset),
            edges=self.edges,
        )
