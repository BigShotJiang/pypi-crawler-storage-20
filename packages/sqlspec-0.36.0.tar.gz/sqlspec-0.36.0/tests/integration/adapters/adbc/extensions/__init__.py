"""ADBC extension integration tests."""
