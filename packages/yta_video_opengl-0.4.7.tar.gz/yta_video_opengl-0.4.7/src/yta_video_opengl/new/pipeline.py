from yta_video_opengl.context import OpenGLContext
from yta_video_opengl.utils import get_fullscreen_quad_vao
from yta_validation.parameter import ParameterValidator
from yta_programming.singleton import SingletonABCMeta
from abc import abstractmethod
from typing import Union

import moderngl


class _OpenGLPipeline(metaclass = SingletonABCMeta):
    """
    *For internal use only*

    *Abstract class*

    *Singleton class*

    The pipeline to load the GPU program in memory,
    which is the expensive part and must be done only
    once per program. This class must be inherited by
    the specific implementations.
    """

    @property
    def vertex_shader(
        self
    ) -> str:
        """
        The code of the vertex shader. This is, by default,
        a rectangle made by 2 triangles that will fit the
        whole screen.

        Feel free to override this method if you need 
        something more complex, but this is very useful for
        our projects.

        Modifying this should need to modify the quad VAO
        that is generated automatically.
        """
        return (
            '''
            #version 330
            in vec2 in_vert;
            in vec2 in_texcoord;
            out vec2 v_uv;

            void main() {
                v_uv = in_texcoord;
                gl_Position = vec4(in_vert, 0.0, 1.0);
            }
            '''
        )
    
    @property
    @abstractmethod
    def fragment_shader(
        self
    ) -> str:
        """
        The code of the fragment shader.
        """
        pass

    def __init__(
        self,
        opengl_context: Union[moderngl.Context, None],
        # TODO: Can I remove '**kwargs' (?)
        **kwargs
    ):
        """
        Provide all the variables you want to be initialized
        as uniforms at the begining for the global OpenGL
        animation in the `**kwargs`.
        """
        ParameterValidator.validate_instance_of('opengl_context', opengl_context, moderngl.Context)
        # TODO: Validate size

        self.context: moderngl.Context = (
            OpenGLContext().context
            if opengl_context is None else
            opengl_context
        )
        """
        The context of the OpenGL program.
        """

        self.reset_program_and_quad_vao()

    @abstractmethod
    def _define_samplers(
        self
    ):
        """
        *For internal use only*

        Define the index of the samplers (`sampler2d`) based
        on the shaders code.

        This method must be overwritten by the specific
        implementations.
        """
        # self.program['original_texture'].value = 0
        # self.program['processed_texture'].value = 1
        # self.program['selection_mask_texture'].value = 2
        pass

    def reset_program_and_quad_vao(
        self
    ) -> '_OpenGLPipeline':
        """
        Initialize and set the program and the quad VAO
        needed to use the shades and render properly.

        Call this method within a test before any operation
        to make sure the quad VAO and the program have been
        loaded correctly. This can fail due to the fact that
        the tests are isolated and we are using singleton
        instances.
        """
        # Compile shaders within the program
        self.program: moderngl.Program = self.context.program(
            vertex_shader = self.vertex_shader,
            fragment_shader = self.fragment_shader
        )

        self._define_samplers()

        # Create the fullscreen quad VAO
        self.quad_vao = get_fullscreen_quad_vao(
            context = self.context,
            program = self.program
        )

        return self