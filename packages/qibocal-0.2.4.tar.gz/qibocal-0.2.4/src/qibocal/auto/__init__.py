"""Autocalibration runner."""
