import argparse
import asyncio
from functools import partial
import logging
from dataclasses import dataclass, field
from enum import Enum

from abc import ABC, abstractmethod
import os
import threading
from typing import Optional
import numpy as np

from omegaconf import DictConfig
from reactor_runtime import VideoModel
from reactor_runtime.context_api import ReactorContext
from reactor_runtime.model_state import ModelEvent, ModelState, ModelStateMachine
from reactor_runtime.output.frame_buffer import FrameBuffer
from reactor_runtime.utils.loader import build_model
from reactor_runtime.utils.messages import ApplicationMessage
import json

from reactor_runtime.context_api import _set_global_ctx
import uuid


logger = logging.getLogger(__name__)


class State(Enum):
    """Runtime state enumeration."""

    LOADING = "loading"
    IDLE = "idle"
    RUNNING = "running"
    RESETTING = "resetting"
    ERROR = "error"


class SessionInformation:
    """Information about the current session."""

    def __init__(self, loop: asyncio.AbstractEventLoop):
        self.session_duration_minutes: int = 0
        self.emitted_frames: int = 0
        self._loop = loop
        self._duration_task: Optional[asyncio.Task] = None

    def increment_emitted_frames(self) -> None:
        """Increment the emitted frames counter."""
        self.emitted_frames += 1

    def start_duration_counter(self) -> None:
        """Start the async task that increments duration every minute."""
        if self._duration_task is not None:
            return
        self._duration_task = self._loop.create_task(self._duration_counter())

    def stop_duration_counter(self) -> None:
        """Stop the duration counter task."""
        if self._duration_task is not None:
            self._duration_task.cancel()
            self._duration_task = None

    async def _duration_counter(self) -> None:
        """Async task that increments session duration every minute."""
        try:
            while True:
                await asyncio.sleep(60.0)
                self.session_duration_minutes += 1
                logger.debug(
                    f"Session duration: {self.session_duration_minutes} minutes"
                )
        except asyncio.CancelledError:
            pass

    def __str__(self) -> str:
        return json.dumps(
            {k: v for k, v in vars(self).items() if not k.startswith("_")}, indent=4
        )


@dataclass
class RuntimeConfig:
    """
    Base configuration for all runtime implementations.

    Contains the configuration that gets passed to the runtime constructor.
    Each runtime implementation should extend this with additional fields.
    """

    model_name: str
    model_args: DictConfig
    model_spec: str

    # Environment-based fields with immediate defaults
    deployment: str = field(default_factory=lambda: os.getenv("DEPLOYMENT", "unknown"))
    region_id: str = field(default_factory=lambda: os.getenv("REGION_ID", "unknown"))
    cloud_id: str = field(default_factory=lambda: os.getenv("CLOUD_ID", "unknown"))

    # node_id depends on other fields, so it must be built in __post_init__
    node_id: str = field(init=False)
    machine_id: str = field(init=False)

    orphan_timeout: float = (
        30.0  # Seconds to wait before stopping session when WebRTC disconnects
    )

    def __post_init__(self):
        """Build node_id from deployment info and model details."""
        self.machine_id = os.getenv("HOST", str(uuid.uuid4()))
        self.node_id = "@".join(
            [
                self.deployment,
                self.region_id,
                self.cloud_id,
                self.model_name,
                self.machine_id,
            ]
        )

    @staticmethod
    def parser() -> argparse.ArgumentParser:
        """
        Return an argument parser for runtime-specific CLI arguments.

        The parsed args will be used to construct the config.

        Returns:
            argparse.ArgumentParser with runtime-specific arguments
        """
        parser = argparse.ArgumentParser(add_help=False)
        parser.add_argument(
            "--orphan-timeout",
            type=float,
            default=30.0,
            help="Seconds to wait before stopping session when no client connection is established. Default: 30.0. Set to 0 to disable.",
        )
        return parser


class Runtime(ModelStateMachine, ABC):
    def __init__(self, config: RuntimeConfig):
        """
        Initialize the runtime with a configuration object.

        Args:
            config: RuntimeConfig containing model information and runtime-specific settings.
        """
        super().__init__(ModelState.CREATED)
        self.config = config
        self.model_loaded = False
        self.model: VideoModel = None
        self.model_thread: Optional[threading.Thread] = None
        self.loop = asyncio.get_running_loop()
        self.frame_buffer = FrameBuffer(
            callback=self._send_out_app_frame_sync,
            fps_debuff_factor=self.config.model_args.get("fps_debuff_factor", 1.0),
        )
        self.stop_evt = threading.Event()

        # Orphan timeout task - stops session if no client connection for too long
        self._orphan_task: Optional[asyncio.Task] = None

        # Session information tracking
        self._session_info: Optional[SessionInformation] = None

        try:
            self.load_model()
        except Exception as e:
            logger.critical(f"Failed to load model: {e}", exc_info=True)
            self.send(ModelEvent.INITIALIZATION_FAIL)
            raise

        self.send(ModelEvent.INITIALIZATION_SUCCESS)

    def get_session_info(self) -> Optional[SessionInformation]:
        """
        Get the current session information.

        Returns:
            SessionInformation if a session exists (or has completed), None otherwise.
        """
        return self._session_info

    def load_model(self) -> None:
        self.model = build_model(self.config.model_spec, self.config.model_args)
        self.model_loaded = True
        logger.info(
            f"Model {self.config.model_name} loaded successfully and now available for inference."
        )

    def _send_out_app_message_sync(self, data: dict) -> None:
        wrapped = ApplicationMessage(data=data).model_dump()
        try:
            logger.info(f"Sending app message to client: {wrapped}")
            self.loop.call_soon_threadsafe(
                asyncio.create_task, self.send_out_app_message(wrapped)
            )
        except Exception as e:
            logger.warning(f"Failed to send app message to client: {e}")

    def _build_context(self) -> ReactorContext:
        """
        Build the context that hooks the model to the runtime. Defines the bindings for the functions that the model,
        when running, will be able to call. The model internally calls messages to emit frames and emit messages.
        """
        self.frame_buffer.clear()
        self.stop_evt = threading.Event()
        ctx = ReactorContext(
            _send_fn=self._send_out_app_message_sync,
            _emit_block_fn=self.frame_buffer.push,
            _enable_monitoring_fn=self.frame_buffer.enable_monitoring,
            _disable_monitoring_fn=self.frame_buffer.disable_monitoring,
            _stop_evt=self.stop_evt,
        )
        _set_global_ctx(ctx)

    def _send_out_app_frame_sync(self, frame: np.ndarray) -> None:
        """
        Frames should be a NumPy ndarray (H, W, 3) in RGB.
        Silently fails if the event loop is closed (expected during shutdown).
        """
        # Check if loop is closed before creating the coroutine to avoid "never awaited" warning
        if self.loop.is_closed():
            return
        try:
            # Increment the session info frames counter
            if self._session_info is not None:
                self._session_info.increment_emitted_frames()

            # Send the frame to the client
            self.loop.call_soon_threadsafe(
                asyncio.create_task, self.send_out_app_frame(frame)
            )
        except RuntimeError:
            # Event loop is closed, this is expected during shutdown - silently ignore
            pass

    def on_enter_STREAMING(self, previous_state: ModelState) -> None:
        """
        Start the model's start_session() in a separate thread. Also start emission on the frame buffer,
        and build the context that hooks the model to the runtime.

        When the model thread exits (cleanly or with error), internal cleanup is performed first,
        then the abstract on_model_exit() method is called for implementation-specific cleanup.

        State transition: IDLE/ERROR -> RUNNING

        Returns:
            True if session started successfully, False if not in IDLE or ERROR state.
        """
        self._cancel_orphan_timeout()

        if previous_state != ModelState.WAITING:
            logger.warning(
                "Model thread already running, treating as a re-connection to already running session."
            )
            return

        # Start duration counter
        # We create the session info object using the minimum class, only if it is not present yet.
        if self._session_info is None:
            self._session_info = SessionInformation(self.loop)
        self._session_info.start_duration_counter()

        # Reset stop event and build context
        self._build_context()

        self.frame_buffer.clear()
        # Start frame buffer emission
        self.frame_buffer.start_emission()

        def run_model() -> None:
            error: Optional[Exception] = None
            try:
                self.model.start_session()
            except Exception as e:
                logger.critical(f"Model Error: {e}", exc_info=True)
                error = e
            finally:
                # This call is for the case in which the model:
                # - Exits with an error
                # - Exits on its own (not from an external stop request)
                if self.current_state != ModelState.CLOSING:
                    self.loop.call_soon_threadsafe(
                        partial(self.send, ModelEvent.STOP_SESSION, error=error)
                    )
                self._handle_model_thread_exit(error)

        self.model_thread = threading.Thread(
            target=run_model, daemon=False, name="model-session"
        )
        self.model_thread.start()
        logger.info("Model session started in background thread")

    def _handle_model_thread_exit(self, error: Optional[Exception]) -> None:
        """
        Internal handler called when the model thread exits.
        Performs internal cleanup first, then invokes the cleanup complete event.
        """

        # Perform internal cleanup
        if self._session_info is not None:
            self._session_info.stop_duration_counter()
            logger.info(f"Session ended: {self._session_info}")
            self._session_info = None
        self.frame_buffer.stop_emission()
        self.frame_buffer.clear()

        # Clean up thread reference (don't join here - we may be called from the thread itself)
        if self.model_thread is not None and not self.model_thread.is_alive():
            self.model_thread = None

        logger.info("Session cleanup completed")

    def on_enter_ORPHANED(self, previous_state: ModelState) -> None:
        """
        Handler called when the session enters the ORPHANED state.
        Starts the orphan timeout.
        """
        self._start_orphan_timeout()

    def on_enter_WAITING(self, previous_state: ModelState) -> None:
        """
        Handler called when the session enters the WAITING state.
        Starts the orphan timeout.
        """
        self._start_orphan_timeout()

    def on_enter_CLOSING(self, previous_state: ModelState) -> None:
        """
        Signals the model to stop, waits for the thread to exit,
        and performs cleanup.
        """
        self._cancel_orphan_timeout()
        # Signal model to stop
        self.stop_evt.set()

        # Wait for model thread to exit
        if self.model_thread is not None and self.model_thread.is_alive():
            # TODO(REA-156): Add safe timeout that handles case in which the thread hangs. This means manually calling cleanup if we kill the thread.
            logger.debug("Waiting for model thread to exit")
            self.model_thread.join()

            logger.debug("Model thread exited cleanly")

        self.loop.call_soon_threadsafe(self.send, ModelEvent.CLEANUP_COMPLETE)

    @abstractmethod
    async def send_out_app_message(self, data: ApplicationMessage) -> None:
        """
        Send an application message FROM the model TO the client.
        The message has already been wrapped in an ApplicationMessage envelope.
        This should be where the messages is sent out to the client.
        """
        pass

    @abstractmethod
    async def send_out_app_frame(self, frame: np.ndarray) -> None:
        """
        Send an application frame FROM the model TO the client.
        This function gets called internally by the frame buffer, so it means that the rate at which this get called
        is already internally handled to match the right FPS to make the generation smooth.
        Frames are a NumPy ndarray (H, W, 3) in RGB.
        """
        pass

    @abstractmethod
    async def run(self) -> None:
        pass

    # ===============================
    # Shutdown Cleanup
    # ===============================

    async def shutdown(self) -> None:
        """
        Perform graceful shutdown cleanup.
        Stops any running session, waits for READY state, then sends EVICTION.

        This method is shielded from cancellation to ensure EVICTION always happens.
        Subclasses should call this in their run() method's finally block.
        """
        try:
            await asyncio.shield(self._shutdown_cleanup())
        except asyncio.CancelledError:
            logger.info("Shutdown cleanup completed despite cancellation")

    async def _shutdown_cleanup(self) -> None:
        """
        Internal shutdown cleanup implementation.
        Override in subclasses to add additional cleanup steps.
        """
        try:
            if self.session_running or self.current_state == ModelState.WAITING:
                self.send(ModelEvent.STOP_SESSION)

            # Wait for state to settle - accept READY or terminal states
            while self.current_state not in (
                ModelState.READY,
                ModelState.TERMINATED,
                ModelState.CREATED,
            ):
                await asyncio.sleep(0.05)

            # Only send EVICTION if we're in READY (the only valid source state)
            if self.current_state == ModelState.READY:
                self.send(ModelEvent.EVICTION)

        except asyncio.CancelledError:
            # If cancelled during cleanup, still try to send EVICTION synchronously
            logger.warning("Shutdown cleanup was cancelled, attempting final eviction")
            if self.current_state == ModelState.READY:
                self.send(ModelEvent.EVICTION)
            raise

        logger.info("Runtime shutdown complete")

    # ===============================
    # Orphan Timeout Management
    # ===============================

    def _start_orphan_timeout(self) -> None:
        """
        Start the orphan timeout coroutine.

        If no Client Connection is established within the timeout period,
        the session will be stopped automatically.
        """

        if self.config.orphan_timeout <= 0:
            logger.debug("Orphan timeout disabled (orphan_timeout <= 0)")
            return

        # Cancel any existing orphan task
        self._cancel_orphan_timeout()

        async def orphan_timeout_coro():
            try:
                logger.info(f"Orphan timeout started ({self.config.orphan_timeout}s)")
                await asyncio.sleep(self.config.orphan_timeout)

                # TOCTOU race condition is checked by the state machine - entering WAITING / ORPHANED resets the timeout
                self.send(ModelEvent.TIMEOUT)

            except asyncio.CancelledError:
                logger.info("Orphan timeout cancelled")

        self._orphan_task = asyncio.create_task(orphan_timeout_coro())

    def _cancel_orphan_timeout(self) -> None:
        """Cancel the orphan timeout if running."""
        if self._orphan_task is not None:
            self._orphan_task.cancel()
            self._orphan_task = None
            logger.debug("Orphan timeout cancelled")
