"""
Configuration for the HTTP Runtime.
"""

import argparse
import os
from dataclasses import dataclass

from reactor_runtime.runtime_api import RuntimeConfig
from reactor_runtime.utils.webrtc import IceServerConfig, DEFAULT_STUN_SERVER


# Environment variable keys for WebRTC configuration
ENV_WEBRTC_PORT_MIN = "WEBRTC_PORT_MIN"
ENV_WEBRTC_PORT_MAX = "WEBRTC_PORT_MAX"
# Comma-separated list of STUN server URLs
ENV_STUN_SERVERS = "STUN_SERVERS"
# Comma-separated list of "username;credential;url" entries
ENV_TURN_SERVERS = "TURN_SERVERS"


@dataclass
class HttpRuntimeConfig(RuntimeConfig):
    """
    Configuration for the HTTP Runtime.

    Extends RuntimeConfig with HTTP-specific settings.
    """

    host: str = "0.0.0.0"
    port: int = 8080

    webrtc_port_min: int | None = None  # Minimum port for WebRTC ICE UDP binding
    webrtc_port_max: int | None = None  # Maximum port for WebRTC ICE UDP binding

    # ICE/TURN server configuration
    stun_servers: list[str] | None = None  # STUN server URLs (can specify multiple)
    turn_servers: list[str] | None = (
        None  # TURN servers in format "username;credential;url"
    )

    def __post_init__(self):
        """Validate configuration after initialization."""
        super().__post_init__()
        self._load_webrtc_ports_from_env()
        self._load_ice_servers_from_env()
        self._validate_webrtc_port_range()
        self._validate_turn_servers()

    def _load_webrtc_ports_from_env(self):
        """Load WebRTC port range from environment variables if not set via CLI."""
        if self.webrtc_port_min is None:
            env_val = os.getenv(ENV_WEBRTC_PORT_MIN)
            if env_val:
                try:
                    self.webrtc_port_min = int(env_val)
                except ValueError:
                    raise ValueError(
                        f"Invalid value for {ENV_WEBRTC_PORT_MIN}: '{env_val}' is not a valid integer"
                    )

        if self.webrtc_port_max is None:
            env_val = os.getenv(ENV_WEBRTC_PORT_MAX)
            if env_val:
                try:
                    self.webrtc_port_max = int(env_val)
                except ValueError:
                    raise ValueError(
                        f"Invalid value for {ENV_WEBRTC_PORT_MAX}: '{env_val}' is not a valid integer"
                    )

    def _load_ice_servers_from_env(self):
        """Load ICE server configuration from environment variables if not set via CLI."""
        # Load STUN servers (comma-separated URLs)
        if self.stun_servers is None:
            env_val = os.getenv(ENV_STUN_SERVERS)
            if env_val:
                self.stun_servers = [s.strip() for s in env_val.split(",") if s.strip()]

        # Load TURN servers (comma-separated "username;credential;url" entries)
        if self.turn_servers is None:
            env_val = os.getenv(ENV_TURN_SERVERS)
            if env_val:
                self.turn_servers = [s.strip() for s in env_val.split(",") if s.strip()]

    def _validate_webrtc_port_range(self):
        """Validate WebRTC port range configuration."""
        min_port = self.webrtc_port_min
        max_port = self.webrtc_port_max

        # Check if only one is set
        if (min_port is None) != (max_port is None):
            raise ValueError(
                "Both --webrtc-port-min and --webrtc-port-max must be specified together"
            )

        if min_port is not None and max_port is not None:
            # Validate port range values (1024-65535 to avoid privileged ports)
            if not (1024 <= min_port <= 65535):
                raise ValueError(
                    f"--webrtc-port-min must be between 1024 and 65535, got {min_port}"
                )
            if not (1024 <= max_port <= 65535):
                raise ValueError(
                    f"--webrtc-port-max must be between 1024 and 65535, got {max_port}"
                )
            if min_port > max_port:
                raise ValueError(
                    f"--webrtc-port-min ({min_port}) must be <= --webrtc-port-max ({max_port})"
                )

    def _validate_turn_servers(self):
        """Validate TURN server configuration format."""
        if not self.turn_servers:
            return

        for i, turn_server in enumerate(self.turn_servers):
            parts = turn_server.split(";", 2)
            if len(parts) != 3:
                raise ValueError(
                    f"Invalid TURN server format at index {i}: '{turn_server}'. "
                    f"Expected format: 'username;credential;url' (e.g., 'user;pass;turn:example.com:3478')"
                )
            username, credential, url = [p.strip() for p in parts]
            if not username or not credential or not url:
                raise ValueError(
                    f"Invalid TURN server at index {i}: username, credential, and URL are all required. "
                    f"Got: username='{username}', credential='***', url='{url}'"
                )

    @property
    def webrtc_port_range(self) -> tuple[int, int] | None:
        """Return the WebRTC port range as a tuple, or None if not configured."""
        if self.webrtc_port_min is not None and self.webrtc_port_max is not None:
            return (self.webrtc_port_min, self.webrtc_port_max)
        return None

    @property
    def ice_servers(self) -> list | None:
        """Return list of ICE server configurations, or None to use defaults."""
        servers = []

        # Add STUN servers if configured (can be multiple)
        if self.stun_servers:
            servers.extend(self.stun_servers)

        # Add TURN servers if configured (format: username;credential;url)
        if self.turn_servers:
            for turn_server in self.turn_servers:
                parts = turn_server.split(";", 2)
                username, credential, url = [p.strip() for p in parts]
                servers.append(
                    IceServerConfig(
                        urls=url,
                        username=username,
                        credential=credential,
                    )
                )

        return servers if servers else None

    @property
    def ice_servers_json(self) -> list[dict]:
        """
        Return ICE servers in browser-compatible JSON format for RTCPeerConnection.

        Returns:
            List of ICE server configurations in the format:
            [
                {"urls": "stun:..."},
                {"urls": "turn:...", "username": "...", "credential": "..."},
                ...
            ]
        """
        ice_servers = self.ice_servers
        result = []

        if ice_servers is None or len(ice_servers) == 0:
            # Default to Google's public STUN server
            result.append({"urls": DEFAULT_STUN_SERVER})
        else:
            for server in ice_servers:
                if isinstance(server, str):
                    # Simple STUN URL
                    result.append({"urls": server})
                elif isinstance(server, IceServerConfig):
                    # TURN server with credentials
                    entry: dict = {"urls": server.urls}
                    if server.username:
                        entry["username"] = server.username
                    if server.credential:
                        entry["credential"] = server.credential
                    result.append(entry)

        return result

    @staticmethod
    def parser() -> argparse.ArgumentParser:
        """
        Return an argument parser for HTTP runtime-specific arguments.

        Returns:
            argparse.ArgumentParser with HTTP-specific arguments
        """
        parser = RuntimeConfig.parser()
        parser.add_argument(
            "--host",
            type=str,
            default="0.0.0.0",
            help="Host to bind the HTTP server to. Default: 0.0.0.0",
        )
        parser.add_argument(
            "--port",
            type=int,
            default=8080,
            help="Port to bind the HTTP server to. Default: 8080",
        )
        parser.add_argument(
            "--webrtc-port-min",
            type=int,
            default=None,
            help="Minimum port for WebRTC ICE UDP binding. Default: None (ephemeral)",
        )
        parser.add_argument(
            "--webrtc-port-max",
            type=int,
            default=None,
            help="Maximum port for WebRTC ICE UDP binding. Default: None (ephemeral)",
        )
        parser.add_argument(
            "--stun-server",
            type=str,
            action="append",
            dest="stun_servers",
            default=None,
            help="STUN server URL (e.g., stun:stun.l.google.com:19302). Can be specified multiple times. Default: Google STUN",
        )
        parser.add_argument(
            "--turn-server",
            type=str,
            action="append",
            dest="turn_servers",
            default=None,
            help="TURN server in format 'username;credential;url' (e.g., 'user;pass;turn:example.com:3478'). Can be specified multiple times.",
        )
        return parser
