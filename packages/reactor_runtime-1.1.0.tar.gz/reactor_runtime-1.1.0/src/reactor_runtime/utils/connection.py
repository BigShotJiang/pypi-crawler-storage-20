"""
Custom aioice Connection with configurable port range.

This module extends the aioice Connection class to allow binding UDP sockets
to a specific port range instead of using ephemeral ports (port 0).

This is useful in containerized environments or when firewall rules require
predictable port ranges for WebRTC/ICE traffic.

Also provides patching utilities to inject port range support into aiortc's
RTCPeerConnection which doesn't natively support custom port ranges.
"""

import asyncio
import logging
import random
import socket
from typing import List, Optional, Tuple

from aioice import turn
from aioice.candidate import Candidate, candidate_foundation, candidate_priority
from aioice.ice import (
    Connection,
    StunProtocol,
    TransportPolicy,
    relayed_candidate,
    server_reflexive_candidate,
)
from aiortc import RTCIceGatherer, RTCIceServer
from aiortc.rtcicetransport import connection_kwargs

# Import aiortc modules for patching
import aiortc.rtcicetransport as _rtcicetransport
import aiortc.rtcpeerconnection as _rtcpeerconnection

logger = logging.getLogger(__name__)

# Store original RTCIceGatherer class for restoration
_original_gatherer_class = _rtcicetransport.RTCIceGatherer


class PortRangeConnection(Connection):
    """
    An ICE connection that binds UDP sockets to ports within a specified range.

    This extends the standard aioice Connection by overriding the candidate
    gathering process to bind sockets to ports within a configurable range
    instead of letting the OS assign ephemeral ports.

    :param port_range: A tuple (min_port, max_port) specifying the inclusive
                       range of ports to use for binding. If None, uses
                       ephemeral ports (default aioice behavior).
    :param port_bind_attempts: Maximum number of attempts to find an available
                               port within the range (default: 100).

    All other parameters are passed through to the parent Connection class.

    Example:
        connection = PortRangeConnection(
            ice_controlling=True,
            port_range=(5000, 5100),
        )
        await connection.gather_candidates()
    """

    def __init__(
        self,
        ice_controlling: bool,
        port_range: Optional[Tuple[int, int]] = None,
        port_bind_attempts: int = 100,
        **kwargs,
    ) -> None:
        super().__init__(ice_controlling=ice_controlling, **kwargs)
        self._port_range = port_range
        self._port_bind_attempts = port_bind_attempts

    async def get_component_candidates(
        self, component: int, addresses: list[str], timeout: int = 5
    ) -> list[Candidate]:
        """
        Gather candidates for a single component, binding to the configured port range.

        This method overrides the parent implementation to support custom port binding.
        If no port_range is configured, falls back to the default behavior (ephemeral ports).
        """
        # If no port range is configured, use the default implementation
        if self._port_range is None:
            return await super().get_component_candidates(component, addresses, timeout)

        candidates = []
        loop = asyncio.get_event_loop()

        min_port, max_port = self._port_range

        # Gather host candidates
        host_protocols = []
        for address in addresses:
            protocol = await self._create_bound_protocol(
                loop, address, min_port, max_port
            )
            if protocol is None:
                continue

            host_protocols.append(protocol)

            # Add host candidate
            candidate_address = protocol.transport.get_extra_info("sockname")
            protocol.local_candidate = Candidate(
                foundation=candidate_foundation("host", "udp", candidate_address[0]),
                component=component,
                transport="udp",
                priority=candidate_priority(component, "host"),
                host=candidate_address[0],
                port=candidate_address[1],
                type="host",
            )
            if self._transport_policy == TransportPolicy.ALL:
                candidates.append(protocol.local_candidate)

        self._protocols += host_protocols

        tasks: list[asyncio.Task[tuple[Candidate, Optional[StunProtocol]]]] = []

        # Query STUN server for server-reflexive candidates (IPv4 only)
        if self.stun_server:
            import ipaddress

            for protocol in host_protocols:
                if ipaddress.ip_address(protocol.local_candidate.host).version == 4:
                    tasks.append(
                        asyncio.create_task(
                            server_reflexive_candidate(protocol, self.stun_server)
                        )
                    )

        # Connect to TURN server
        if self.turn_server:
            tasks.append(
                asyncio.create_task(
                    relayed_candidate(
                        component=component,
                        protocol_factory=lambda: StunProtocol(self),
                        turn_server=self.turn_server,
                        turn_username=self.turn_username,
                        turn_password=self.turn_password,
                        turn_ssl=self.turn_ssl,
                        turn_transport=self.turn_transport,
                    )
                )
            )

        # Run tasks in parallel and handle exceptions
        if len(tasks):
            done, pending = await asyncio.wait(tasks, timeout=timeout)
            for task in done:
                if task.exception() is None:
                    candidate, protocol = task.result()
                    candidates.append(candidate)
                    if protocol is not None:
                        self._protocols.append(protocol)
            for task in pending:
                task.cancel()

        return candidates

    async def _create_bound_protocol(
        self,
        loop: asyncio.AbstractEventLoop,
        address: str,
        min_port: int,
        max_port: int,
    ) -> Optional[StunProtocol]:
        """
        Create a StunProtocol bound to a port within the specified range.

        Attempts to bind to random ports within the range until successful
        or the maximum number of attempts is reached.

        :param loop: The asyncio event loop.
        :param address: The local IP address to bind to.
        :param min_port: Minimum port number (inclusive).
        :param max_port: Maximum port number (inclusive).
        :returns: A StunProtocol instance if successful, None otherwise.
        """
        # Generate a shuffled list of ports to try
        ports = list(range(min_port, max_port + 1))
        random.shuffle(ports)

        # Limit attempts to avoid excessive iteration
        attempts = min(self._port_bind_attempts, len(ports))

        for port in ports[:attempts]:
            try:
                transport, protocol = await loop.create_datagram_endpoint(
                    lambda: StunProtocol(self), local_addr=(address, port)
                )
                sock = transport.get_extra_info("socket")
                if sock is not None:
                    sock.setsockopt(
                        socket.SOL_SOCKET, socket.SO_RCVBUF, turn.UDP_SOCKET_BUFFER_SIZE
                    )
                logger.debug(f"Bound ICE socket to {address}:{port}")
                return protocol
            except OSError as exc:
                # Port is likely in use, try the next one
                logger.debug(f"Could not bind to {address}:{port} - {exc}")
                continue

        logger.warning(
            f"Could not bind to any port in range {min_port}-{max_port} "
            f"for address {address} after {attempts} attempts"
        )
        return None


# =============================================================================
# RTCIceGatherer with Port Range Support
# =============================================================================


class PortRangeIceGatherer(RTCIceGatherer):
    """
    Custom RTCIceGatherer that uses PortRangeConnection for custom port binding.

    This subclass allows specifying a port range for ICE UDP socket binding,
    which is useful in containerized environments or when firewall rules
    require predictable port ranges.

    Usage:
        gatherer = PortRangeIceGatherer(
            iceServers=[RTCIceServer(urls="stun:stun.l.google.com:19302")],
            port_range=(5000, 5100),
        )
        await gatherer.gather()
    """

    def __init__(
        self,
        iceServers: Optional[List[RTCIceServer]] = None,
        port_range: Optional[Tuple[int, int]] = None,
    ) -> None:
        # Don't call super().__init__() as it creates its own connection
        # Instead, we manually initialize the parent class state
        from pyee.asyncio import AsyncIOEventEmitter

        AsyncIOEventEmitter.__init__(self)

        if iceServers is None:
            iceServers = self.getDefaultIceServers()
        ice_kwargs = connection_kwargs(iceServers)

        # NOTE: Do NOT accept or pass local_username/local_password.
        # The Connection generates its own random credentials.

        # Create our custom PortRangeConnection instead of the default Connection
        self._connection = PortRangeConnection(
            ice_controlling=False,
            port_range=port_range,
            **ice_kwargs,
        )
        self._remote_candidates_end = False
        self._RTCIceGatherer__state = "new"

        if port_range:
            logger.debug(
                f"Created PortRangeIceGatherer with port range {port_range[0]}-{port_range[1]}"
            )


def create_port_range_gatherer_class(port_range: Tuple[int, int]) -> type:
    """
    Create a custom RTCIceGatherer class that uses the specified port range.

    This factory function creates a class that can be used to temporarily
    replace aiortc's RTCIceGatherer, injecting our port range configuration.

    Args:
        port_range: Tuple of (min_port, max_port) for ICE UDP binding.

    Returns:
        A class that behaves like RTCIceGatherer but uses PortRangeConnection.
    """
    min_port, max_port = port_range

    class _PortRangeGatherer(RTCIceGatherer):
        def __init__(
            self,
            iceServers: Optional[List[RTCIceServer]] = None,
            local_username: Optional[str] = None,
            local_password: Optional[str] = None,
        ) -> None:
            from pyee.asyncio import AsyncIOEventEmitter

            AsyncIOEventEmitter.__init__(self)

            if iceServers is None:
                iceServers = self.getDefaultIceServers()
            ice_kwargs = connection_kwargs(iceServers)

            # NOTE: Do NOT pass local_username/local_password to Connection.
            # The original RTCIceGatherer ignores these parameters - they are
            # accepted for API compatibility but Connection generates its own
            # random credentials. Passing them causes validation errors.

            # Use PortRangeConnection with our configured port range
            self._connection = PortRangeConnection(
                ice_controlling=False,
                port_range=(min_port, max_port),
                **ice_kwargs,
            )
            self._remote_candidates_end = False
            self._RTCIceGatherer__state = "new"

    return _PortRangeGatherer


# =============================================================================
# Patching Context Manager for RTCPeerConnection
# =============================================================================


class PortRangeGathererPatch:
    """
    Context manager that temporarily patches aiortc to use PortRangeIceGatherer.

    This allows RTCPeerConnection to use our custom port range when creating
    ICE gatherers internally during offer/answer creation.

    RTCPeerConnection creates RTCIceGatherer instances internally and doesn't
    expose a way to customize the port range. This context manager temporarily
    replaces the RTCIceGatherer class in both aiortc modules where it's referenced.

    Usage:
        with PortRangeGathererPatch(port_range=(5000, 5100)):
            pc = RTCPeerConnection(...)
            await pc.setRemoteDescription(offer)
            answer = await pc.createAnswer()
            # ICE connections will bind to ports 5000-5100

    Args:
        port_range: Optional tuple (min_port, max_port) for ICE UDP binding.
                    If None, no patching occurs and default behavior is used.
    """

    def __init__(self, port_range: Optional[Tuple[int, int]] = None):
        self.port_range = port_range
        self._patched = False

    def __enter__(self):
        if self.port_range is not None:
            # Create and install our custom gatherer class
            patched_class = create_port_range_gatherer_class(self.port_range)

            # Patch BOTH modules - rtcicetransport AND rtcpeerconnection
            # RTCPeerConnection imports RTCIceGatherer at module load time,
            # so we must patch its reference too
            _rtcicetransport.RTCIceGatherer = patched_class
            _rtcpeerconnection.RTCIceGatherer = patched_class

            self._patched = True
            logger.debug(
                f"Patched RTCIceGatherer with port range "
                f"{self.port_range[0]}-{self.port_range[1]}"
            )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._patched:
            _rtcicetransport.RTCIceGatherer = _original_gatherer_class
            _rtcpeerconnection.RTCIceGatherer = _original_gatherer_class
            self._patched = False
            logger.debug("Restored original RTCIceGatherer")
        return False
