from __future__ import annotations

import argparse
import os
from pathlib import Path

from .config import DocmoodConfig
from .mood import DocstringMood, detect_docstring_mood
from .scan import scan_project


def main() -> None:  # pylint: disable=too-many-locals
    """Main entry point for the docmood package."""
    parser = argparse.ArgumentParser(prog="docmood")
    parser.add_argument(
        "path",
        nargs="?",
        default=".",
        help="Project directory to scan (default: current directory).",
    )
    args = parser.parse_args()

    root = Path(args.path).resolve()

    # Load configuration
    config = DocmoodConfig.load(root)

    # Print what we're checking for
    mood_name = config.expected_mood.value.replace("_", " ")
    print(f"[docmood] Checking that all method docstrings use {mood_name} mood")

    items = scan_project(root, skip_dirs=config.skip_dirs)
    failed_items = []
    unknown_items = []

    for item in items:
        relative_path = os.path.relpath(item.path, start=root)
        detected_mood = detect_docstring_mood(item.doc)

        # Track unknown mood docstrings separately
        if detected_mood == DocstringMood.UNKNOWN:
            unknown_items.append((relative_path, item.doc_lineno))

        # Check if it matches expected mood (considering allow_unknown config)
        if detected_mood != config.expected_mood:
            is_unknown_allowed = detected_mood == DocstringMood.UNKNOWN and config.allow_unknown
            if not is_unknown_allowed:
                failed_items.append((relative_path, item.doc_lineno, detected_mood))

    # Print warnings for unknown mood docstrings
    if unknown_items:
        unknown_count = len(unknown_items)
        plural = "s" if unknown_count != 1 else ""
        print(f"\n⚠ Warning: Found {unknown_count} docstring{plural} with unknown mood:")
        for filepath, lineno in unknown_items:
            print(f"  {filepath}:{lineno}")
        if config.allow_unknown:
            print("  (These are counted as passed because allow_unknown=true)")
        print()

    # Print statistics
    total = len(items)
    failed = len(failed_items)
    passed = total - failed

    if total == 0:
        print("[docmood] No docstrings found.")
    elif failed == 0:
        print(f"[docmood] Found {total} method doc{'s' if total != 1 else ''}, all passed!")
    else:
        percentage = (passed / total * 100) if total > 0 else 0
        print(f"[docmood] Found {total} method doc{'s' if total != 1 else ''}: "
              f"{passed}/{total} passed ({percentage:.0f}%)")
        print("\nFailed docstrings:")
        for filepath, lineno, detected_mood in failed_items:
            mood_display = detected_mood.value.replace("_", " ")
            print(f"  {filepath}:{lineno} (detected: {mood_display})")

    if failed > 0:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
