from __future__ import annotations

import configparser
import sys
from pathlib import Path
from typing import Optional

from .mood import DocstringMood

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None  # type: ignore[assignment]


_DEFAULT_SKIP_DIRS = [
    ".git",
    ".hg",
    ".svn",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".nox",
    "__pycache__",
    "build",
    "dist",
    "site-packages",
    "venv",
    ".venv",
]


class DocmoodConfig:  # pylint: disable=too-few-public-methods
    """Configuration for docmood tool."""

    def __init__(
        self,
        expected_mood: DocstringMood,
        allow_unknown: bool = True,
        additional_skip_dirs: Optional[list[str]] = None,
    ) -> None:
        """
        Create a configuration instance.

        Args:
            expected_mood: The expected mood for all docstrings.
            allow_unknown: Whether to treat unknown mood as passed (default: True).
            additional_skip_dirs: Additional directory names to skip (added to defaults).
        """
        self.expected_mood = expected_mood
        self.allow_unknown = allow_unknown
        # Combine default skip dirs with additional ones
        self.skip_dirs = list(_DEFAULT_SKIP_DIRS)
        if additional_skip_dirs:
            self.skip_dirs.extend(additional_skip_dirs)

    @classmethod
    def load(cls, root: Path) -> DocmoodConfig:
        """
        Load configuration from pyproject.toml or docmood.ini.

        Searches for configuration in the following order:
        1. pyproject.toml with [tool.docmood] section
        2. docmood.ini file

        Args:
            root: The root directory to search for configuration files.

        Returns:
            A DocmoodConfig instance with loaded settings.
        """
        # Try pyproject.toml first
        pyproject_path = root / "pyproject.toml"
        if pyproject_path.exists():
            config = cls._load_from_pyproject(pyproject_path)
            if config is not None:
                return config

        # Try docmood.ini
        ini_path = root / "docmood.ini"
        if ini_path.exists():
            config = cls._load_from_ini(ini_path)
            if config is not None:
                return config

        # Default to imperative mood with allow_unknown=True and no additional skip_dirs
        return cls(
            expected_mood=DocstringMood.IMPERATIVE,
            allow_unknown=True,
            additional_skip_dirs=None,
        )

    @classmethod
    def _load_from_pyproject(cls, path: Path) -> Optional[DocmoodConfig]:
        """Load configuration from pyproject.toml file."""
        if tomllib is None:
            return None

        try:
            with open(path, "rb") as f:
                data = tomllib.load(f)

            tool_config = data.get("tool", {}).get("docmood", {})
            if not tool_config:
                return None

            mood_str = tool_config.get("mood", "").lower()
            allow_unknown = tool_config.get("allow_unknown", True)
            additional_skip_dirs = tool_config.get("skip_dirs", None)

            return cls._parse_mood_config(mood_str, allow_unknown, additional_skip_dirs)

        except (OSError, ValueError, KeyError):
            return None

    @classmethod
    def _load_from_ini(cls, path: Path) -> Optional[DocmoodConfig]:
        """Load configuration from docmood.ini file."""
        try:
            parser = configparser.ConfigParser()
            parser.read(path)

            if not parser.has_section("docmood"):
                return None

            mood_str = parser.get("docmood", "mood", fallback="").lower()
            allow_unknown = parser.getboolean("docmood", "allow_unknown", fallback=True)

            # Parse skip_dirs as comma-separated list (additional dirs to skip)
            skip_dirs_str = parser.get("docmood", "skip_dirs", fallback="")
            additional_skip_dirs = None
            if skip_dirs_str:
                additional_skip_dirs = [d.strip() for d in skip_dirs_str.split(",") if d.strip()]

            return cls._parse_mood_config(mood_str, allow_unknown, additional_skip_dirs)

        except (OSError, configparser.Error):
            return None

    @classmethod
    def _parse_mood_config(
        cls,
        mood_str: str,
        allow_unknown: bool = True,
        additional_skip_dirs: Optional[list[str]] = None,
    ) -> Optional[DocmoodConfig]:
        """Parse mood string to DocstringMood enum."""
        mood_mapping = {
            "imperative": DocstringMood.IMPERATIVE,
            "third_person": DocstringMood.THIRD_PERSON,
            "third-person": DocstringMood.THIRD_PERSON,
        }

        mood = mood_mapping.get(mood_str)
        if mood is None:
            return None

        return cls(
            expected_mood=mood,
            allow_unknown=allow_unknown,
            additional_skip_dirs=additional_skip_dirs,
        )
