from setuptools import setup

setup(
    name="fdir-cli",
    version="3.1.0",
    py_modules=["fdir"],
    entry_points={
        "console_scripts": [
            "fdir = fdir:main",
        ],
    },
    python_requires=">=3.8",
    description="Find and organize anything on your system",
)