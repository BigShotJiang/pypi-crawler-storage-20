"""SSE event renderer for Rich terminal output."""

import json
import sys
import time
import threading
from typing import Iterator, Optional

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text


# Spinner frames for loading animation
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


class SSERenderer:
    """Renders SSE events to Rich terminal output with live updates.

    Features:
    - Animated spinner while tools execute
    - Special UI for spawning sub-agents
    - Clean, minimal output
    """

    def __init__(
        self,
        console: Optional[Console] = None,
        verbose: bool = True,
    ):
        """Initialize the renderer.

        Args:
            console: Rich console to render to (creates one if not provided)
            verbose: Whether to show tool calls and progress
        """
        self.console = console or Console()
        self.verbose = verbose
        self._partial_response = ""
        self._session_id = None
        self._spec = None
        self._spec_submitted = False
        self._plan_submitted = None  # Plan data when submit_plan tool is called
        self._plan_mode_requested = None  # Plan mode request data
        self._pending_clarification = None

        # Live display state
        self._current_tool = None
        self._tool_count = 0
        self._completed_tools: list[dict] = []
        self._spinner_idx = 0
        self._waiting_for_next = False

        # Sub-agent state (for inline updates)
        self._subagent_tool_count = 0
        self._subagent_current_tool = None
        self._subagent_type = None
        self._in_subagent_mode = False  # Track when sub-agent is running

        # Spinner animation thread
        self._spinner_thread: Optional[threading.Thread] = None
        self._spinner_running = False
        self._spinner_message = "thinking"
        self._spinner_lock = threading.Lock()

        # Extended thinking storage
        self._last_thinking: Optional[str] = None

    def render_stream(
        self,
        lines: Iterator[str],
        interrupt_event: Optional[threading.Event] = None,
    ) -> dict:
        """Render SSE stream to terminal.

        Args:
            lines: Iterator of SSE lines from HTTP response
            interrupt_event: Optional event to signal interruption (e.g., ESC pressed)

        Returns:
            Dict with session_id, content, spec, interrupted flag, and other metadata
        """
        current_event = None
        final_response = ""
        interrupted = False
        self._last_thinking = None  # Reset thinking storage
        self._pending_clarification = None  # Reset clarification state
        self._plan_submitted = None  # Reset plan state
        self._plan_mode_requested = None  # Reset plan mode request state

        # Start spinner while waiting for first event
        if self.verbose:
            self._start_spinner("thinking")

        try:
            for line in lines:
                # Check for interrupt signal
                if interrupt_event and interrupt_event.is_set():
                    self._stop_spinner()
                    self.console.print("\n[yellow]Interrupted[/yellow]")
                    interrupted = True
                    break

                line = line.strip()

                if line.startswith("event: "):
                    current_event = line[7:]
                elif line.startswith("data: "):
                    try:
                        data = json.loads(line[6:])
                        # Ensure data is a dict (could be null/None from JSON)
                        if data is None:
                            data = {}
                        if current_event:
                            result = self._handle_event(current_event, data)
                            if result:
                                final_response = result
                    except json.JSONDecodeError:
                        pass
                elif line == ": ping":
                    # SSE keep-alive - ensure spinner is running
                    if self.verbose and not self._spinner_running:
                        self._start_spinner("waiting")
        finally:
            # Always stop spinner when stream ends
            self._stop_spinner()

        return {
            "content": final_response,
            "session_id": self._session_id,
            "spec": self._spec,
            "spec_submitted": self._spec_submitted,
            "plan_submitted": self._plan_submitted,
            "plan_mode_requested": self._plan_mode_requested,
            "clarification": self._pending_clarification,
            "interrupted": interrupted,
            "thinking": self._last_thinking,
        }

    def _start_spinner(self, message: str = "thinking") -> None:
        """Start the animated spinner in a background thread."""
        if self._spinner_running:
            return

        self._spinner_message = message
        self._spinner_running = True
        self._spinner_thread = threading.Thread(target=self._spinner_loop, daemon=True)
        self._spinner_thread.start()

    def _stop_spinner(self) -> None:
        """Stop the spinner and clear the line."""
        if not self._spinner_running:
            return

        self._spinner_running = False
        if self._spinner_thread:
            self._spinner_thread.join(timeout=0.2)
            self._spinner_thread = None

        # Clear the spinner line
        with self._spinner_lock:
            sys.stdout.write("\r" + " " * 60 + "\r")
            sys.stdout.flush()

    def _spinner_loop(self) -> None:
        """Background thread that animates the spinner."""
        while self._spinner_running:
            with self._spinner_lock:
                self._spinner_idx = (self._spinner_idx + 1) % len(SPINNER_FRAMES)
                spinner = SPINNER_FRAMES[self._spinner_idx]
                sys.stdout.write(f"\r  \033[33m{spinner}\033[0m \033[2m{self._spinner_message}...\033[0m")
                sys.stdout.flush()
            time.sleep(0.1)

    def _show_waiting(self) -> None:
        """Show waiting animation (starts spinner if not running)."""
        if not self._spinner_running:
            self._start_spinner("waiting")

    def _clear_waiting(self) -> None:
        """Clear waiting line (stops spinner)."""
        self._stop_spinner()
        self._waiting_for_next = False

    def _handle_event(self, event_type: str, data: dict) -> Optional[str]:
        """Handle individual SSE event."""
        # Ensure data is a dict
        if not isinstance(data, dict):
            data = {}

        # Clear waiting indicator when new event arrives (but not for sub-agent events)
        subagent_id = data.get("subagent_id") if isinstance(data, dict) else None
        if not subagent_id and not self._in_subagent_mode:
            self._clear_waiting()

        if event_type == "session_start":
            self._render_session_start(data)
        elif event_type == "tool_start":
            self._render_tool_start(data)
        elif event_type == "tool_result":
            self._render_tool_result(data)
            # Start spinner while waiting for next tool/response
            self._waiting_for_next = True
            if self.verbose:
                self._start_spinner("thinking")
        elif event_type == "subagent_start":
            self._render_subagent_start(data)
        elif event_type == "subagent_end":
            self._render_subagent_end(data)
        elif event_type == "thinking":
            self._render_thinking(data)
        elif event_type == "assistant_text":
            self._render_assistant_text(data)
        elif event_type == "progress":
            self._render_progress(data)
        elif event_type == "partial_response":
            self._render_partial(data)
        elif event_type == "response":
            return self._render_response(data)
        elif event_type == "clarification":
            self._render_clarification(data)
        elif event_type == "plan_mode_requested":
            self._render_plan_mode_requested(data)
        elif event_type == "plan_submitted":
            self._render_plan_submitted(data)
        elif event_type == "error":
            self._render_error(data)
        elif event_type == "warning":
            self._render_warning(data)
        elif event_type == "session_end":
            self._render_session_end(data)
        elif event_type == "context_frame":
            self._render_context_frame(data)

        return None

    def _render_session_start(self, data: dict) -> None:
        """Render session start event."""
        if data.get("session_id"):
            self._session_id = data["session_id"]

        if not self.verbose:
            return

        agent = data.get("agent_name", "Agent")
        model = data.get("model", "unknown")

        # Extract model name from full path
        if "/" in model:
            model = model.split("/")[-1]

        self.console.print()
        self.console.print(f"[bold cyan]{agent}[/bold cyan] [dim]({model})[/dim]")
        self._tool_count = 0
        self._completed_tools = []

        # Start spinner while waiting for first tool
        self._start_spinner("thinking")

    def _render_tool_start(self, data: dict) -> None:
        """Render tool start event."""
        if not self.verbose:
            return

        name = data.get("name", "unknown")
        args = data.get("args", {})
        tool_id = data.get("tool_id")
        subagent_id = data.get("subagent_id")
        subagent_type = data.get("subagent_type")

        self._tool_count += 1

        # Store tool info for result rendering (keyed by tool_id for parallel support)
        if not hasattr(self, '_pending_tools'):
            self._pending_tools = {}
        # Use tool_id if available, otherwise fall back to name
        key = tool_id or name
        self._pending_tools[key] = {"name": name, "args": args, "start_time": time.time(), "tool_id": tool_id}
        self._current_tool = self._pending_tools[key]

        # Stop spinner when tool starts
        self._stop_spinner()

        # Special handling for task tool (spawning sub-agents)
        if name == "task":
            self._render_agent_spawn_start(args)
            return

        # Sub-agent events: update in place on single line
        if subagent_id:
            self._subagent_tool_count += 1
            self._subagent_current_tool = name
            self._render_subagent_progress(subagent_type or "Agent", name, args)
            return

        # Don't print anything here - wait for tool_result to print complete line
        # This handles parallel tool execution correctly

    def _render_subagent_progress(self, agent_type: str, tool_name: str, args: dict) -> None:
        """Render sub-agent progress on a single updating line."""
        self._spinner_idx = (self._spinner_idx + 1) % len(SPINNER_FRAMES)
        spinner = SPINNER_FRAMES[self._spinner_idx]

        # Use stored type if not provided
        agent_type = agent_type or self._subagent_type or "Agent"

        # Get a short summary of what's being done
        summary = ""
        if "path" in args:
            path = str(args["path"])
            # Shorten long paths
            if len(path) > 30:
                summary = "..." + path[-27:]
            else:
                summary = path
        elif "pattern" in args:
            summary = str(args["pattern"])[:25]

        # Build compact progress line
        line = f"    │ {spinner} ({agent_type}) {self._subagent_tool_count} tools... {tool_name} {summary}"
        # Use ANSI: move to column 0, clear line, print
        sys.stdout.write(f"\r\033[K{line}")
        sys.stdout.flush()

    def _render_agent_spawn_start(self, args: dict) -> None:
        """Track sub-agent spawn state (rendering done by subagent_start event)."""
        agent_type = args.get("subagent_type", "Explore")

        # Enter sub-agent mode: stop spinner, track state
        self._stop_spinner()
        self._in_subagent_mode = True

        # Reset sub-agent tracking
        self._subagent_tool_count = 0
        self._subagent_current_tool = None
        self._subagent_type = agent_type

        # Don't render here - subagent_start event will render the UI

    def _render_tool_result(self, data: dict) -> None:
        """Render tool result event."""
        name = data.get("name", "unknown")
        success = data.get("success", True)
        summary = data.get("summary")
        subagent_id = data.get("subagent_id")

        # Detect spec submission
        if name == "submit_spec" and success:
            self._spec_submitted = True
            spec_data = data.get("data", {})
            if spec_data:
                self._spec = spec_data.get("content")

        if not self.verbose:
            return

        # Special handling for task tool result
        if name == "task":
            self._render_agent_spawn_result(data)
            return

        # Sub-agent events: don't print result lines, just keep updating progress
        if subagent_id:
            return

        # Get tool info from pending tools (use tool_id if available)
        pending_tools = getattr(self, '_pending_tools', {})
        tool_id = data.get("tool_id")
        key = tool_id or name
        tool_info = pending_tools.pop(key, None) or self._current_tool or {}
        args = tool_info.get("args", {})

        # Calculate duration
        duration = ""
        start_time = tool_info.get("start_time")
        if start_time:
            elapsed = time.time() - start_time
            if elapsed >= 0.5:  # Only show if >= 0.5s
                duration = f" {elapsed:.1f}s"

        # Format args for display
        args_display = self._format_tool_args(name, args)

        # Build complete line: • ToolName(args)
        if success:
            # Format: • tool(args) result 1.2s
            result_text = f" [dim]{summary}[/dim]" if summary else ""
            duration_text = f" [dim]{duration}[/dim]" if duration else ""
            self.console.print(f"  [green]✓[/green] [bold]{name}[/bold]({args_display}){result_text}{duration_text}")
        else:
            error_text = summary or "failed"
            self.console.print(f"  [red]✗[/red] [bold]{name}[/bold]({args_display}) [red]{error_text}[/red]")

        self._completed_tools.append({
            "name": name,
            "success": success,
            "summary": summary,
        })
        self._current_tool = None

    def _render_agent_spawn_result(self, data: dict) -> None:
        """Render sub-agent spawn result with special UI."""
        success = data.get("success", True)
        result_data = data.get("data") or {}

        # Exit sub-agent mode
        self._in_subagent_mode = False

        # Clear the progress line and move to new line
        sys.stdout.write(f"\r\033[K")
        sys.stdout.flush()

        # Calculate duration
        duration = ""
        if self._current_tool and self._current_tool.get("start_time"):
            elapsed = time.time() - self._current_tool["start_time"]
            duration = f" [dim]({elapsed:.1f}s)[/dim]"

        if success:
            agent_type = result_data.get("agent_type", "Agent")
            iterations = result_data.get("iterations", 0)
            files_count = len(result_data.get("files_explored", []))

            self.console.print(
                f"    [green]✓[/green] {agent_type} completed{duration}"
            )
            # Show stats using our tracked tool count
            stats = []
            if iterations > 0:
                stats.append(f"{iterations} turns")
            if files_count > 0:
                stats.append(f"{files_count} files")
            if self._subagent_tool_count > 0:
                stats.append(f"{self._subagent_tool_count} tools")
            if stats:
                self.console.print(f"    [dim]{' · '.join(stats)}[/dim]")
        else:
            error = result_data.get("error", data.get("summary", "failed"))
            self.console.print(f"    [red]✗[/red] Agent failed: {error}")

        self.console.print()
        self._current_tool = None
        self._subagent_tool_count = 0
        self._subagent_type = None

    def _render_subagent_start(self, data: dict) -> None:
        """Render subagent start event - shows when Explore/Plan agent is spawned."""
        agent_type = data.get("agent_type", "Agent")
        prompt = data.get("prompt", "")
        description = data.get("description", "")

        # Stop any existing spinner
        self._stop_spinner()

        # Truncate prompt for display
        prompt_display = prompt[:80] + "..." if len(prompt) > 80 else prompt

        self.console.print()
        # Use different colors for different agent types
        if agent_type == "Plan":
            self.console.print(f"  [bold blue]◆ Spawning {agent_type} Agent[/bold blue]")
        else:
            self.console.print(f"  [bold magenta]◆ Spawning {agent_type} Agent[/bold magenta]")

        if description:
            self.console.print(f"    [dim]{description}[/dim]")
        self.console.print(f"    [cyan]→[/cyan] {prompt_display}")

        # Enter subagent mode for tool tracking
        self._in_subagent_mode = True
        self._subagent_type = agent_type
        self._subagent_tool_count = 0
        self._subagent_start_time = time.time()

    def _render_subagent_end(self, data: dict) -> None:
        """Render subagent end event - shows completion summary."""
        agent_type = data.get("agent_type", "Agent")
        success = data.get("success", True)
        iterations = data.get("iterations", 0)
        files_explored = data.get("files_explored", 0)
        execution_time = data.get("execution_time", 0)

        # Exit subagent mode
        self._in_subagent_mode = False

        if success:
            self.console.print(
                f"    [green]✓[/green] {agent_type} completed [dim]({execution_time:.1f}s)[/dim]"
            )
            # Show stats
            stats = []
            if iterations > 0:
                stats.append(f"{iterations} turns")
            if files_explored > 0:
                stats.append(f"{files_explored} files")
            if stats:
                self.console.print(f"    [dim]{' · '.join(stats)}[/dim]")
        else:
            self.console.print(f"    [red]✗[/red] {agent_type} failed")

        self.console.print()
        self._subagent_type = None
        self._subagent_tool_count = 0

    def _format_args_summary(self, args: dict) -> str:
        """Format args into a compact summary string."""
        if not args:
            return ""

        parts = []
        for _, v in list(args.items())[:2]:
            v_str = str(v)
            if len(v_str) > 40:
                v_str = v_str[:37] + "..."
            parts.append(f"[dim]{v_str}[/dim]")

        return " ".join(parts)

    def _format_tool_args(self, tool_name: str, args: dict) -> str:
        """Format tool args in Claude Code style: ToolName(key_arg_value).

        Shows the most relevant arg for each tool type.
        """
        if not args:
            return ""

        # Tool-specific formatting for cleaner display
        if tool_name in ("glob", "grep", "semantic_search"):
            pattern = args.get("pattern", args.get("query", ""))
            if pattern:
                return f'[dim]pattern:[/dim] "{pattern}"' if len(pattern) < 50 else f'[dim]pattern:[/dim] "{pattern[:47]}..."'
        elif tool_name in ("read_file", "write_to_file", "list_files"):
            path = args.get("path", "")
            if path:
                return f"[dim]{path}[/dim]"
        elif tool_name == "bash":
            cmd = args.get("command", "")
            if cmd:
                return f"[dim]{cmd[:60]}{'...' if len(cmd) > 60 else ''}[/dim]"
        elif tool_name == "edit_file":
            path = args.get("path", "")
            if path:
                return f"[dim]{path}[/dim]"

        # Default: show first arg value
        if args:
            first_val = str(list(args.values())[0])
            if len(first_val) > 50:
                first_val = first_val[:47] + "..."
            return f"[dim]{first_val}[/dim]"

        return ""

    def _render_thinking(self, data: dict) -> None:
        """Render thinking event.

        Handles both short progress messages and extended thinking content.
        """
        if not self.verbose:
            return

        message = data.get("message", "")

        # Check if this is extended thinking (long content) vs short progress message
        if len(message) > 200:
            # Extended thinking - show full content
            self._stop_spinner()
            lines = message.strip().split("\n")
            line_count = len(lines)
            char_count = len(message)

            self.console.print(f"  [dim]┃[/dim] [dim italic]💭 Thinking ({char_count:,} chars, {line_count} lines)[/dim italic]")
            for line in lines:
                self.console.print(f"  [dim]┃[/dim] [dim]   {line}[/dim]")

            # Store thinking for potential later display
            self._last_thinking = message
        else:
            # Short progress message
            self.console.print(f"  [dim]┃[/dim] [dim italic]💭 {message}[/dim italic]")

    def _render_assistant_text(self, data: dict) -> None:
        """Render intermediate assistant text (between tool calls)."""
        if not self.verbose:
            return

        content = data.get("content", "").strip()
        if not content:
            return

        # Stop spinner while showing text
        self._stop_spinner()

        # Show as bullet point like Claude Code (cyan for assistant reasoning)
        # Truncate long content
        if len(content) > 200:
            content = content[:197] + "..."
        self.console.print(f"  [cyan]•[/cyan] [italic]{content}[/italic]")

    def _render_progress(self, data: dict) -> None:
        """Render progress event."""
        if not self.verbose:
            return

        message = data.get("message", "")
        percent = data.get("percent")

        if percent is not None:
            bar_width = 20
            filled = int(bar_width * percent / 100)
            bar = "█" * filled + "░" * (bar_width - filled)
            self.console.print(f"  [dim]┃[/dim] [dim]{bar} {percent:.0f}% {message}[/dim]")
        else:
            self.console.print(f"  [dim]┃[/dim] [dim]{message}[/dim]")

    def _render_partial(self, data: dict) -> None:
        """Render partial response (streaming text)."""
        content = data.get("content", "")
        self._partial_response += content

    def _render_response(self, data: dict) -> str:
        """Render final response."""
        content = data.get("content", "")

        self.console.print()
        self.console.print(Markdown(content))

        return content

    def _render_clarification(self, data: dict) -> None:
        """Render clarification request."""
        question = data.get("question", "")
        context = data.get("context", "")
        options = data.get("options", [])

        self.console.print()
        self.console.print(Panel(
            question,
            title="[yellow]❓ Question[/yellow]",
            border_style="yellow",
            padding=(0, 1),
        ))

        if options:
            for i, opt in enumerate(options, 1):
                self.console.print(f"  [yellow][{i}][/yellow] {opt}")
            self.console.print()

        # Always store clarification (with or without options)
        self._pending_clarification = {
            "question": question,
            "context": context,
            "options": options,
        }

    def _render_plan_mode_requested(self, data: dict) -> None:
        """Render plan mode request event and store for menu display."""
        from rich.panel import Panel

        reason = data.get("reason", "")

        # Store the request data for the CLI to show the menu
        self._plan_mode_requested = data

        # Display the request
        self.console.print()
        self.console.print(Panel(
            f"[bold]Request to Enter Plan Mode[/bold]\n\n{reason}",
            title="[yellow]⚡ Plan Mode Request[/yellow]",
            border_style="yellow",
        ))

    def _render_plan_submitted(self, data: dict) -> None:
        """Render plan submission event and store for menu display."""
        from rich.panel import Panel
        from rich.markdown import Markdown

        plan = data.get("plan", "")

        # Store the plan data for the CLI to show the menu
        self._plan_submitted = data

        # Render plan as markdown in a panel
        self.console.print()
        self.console.print(Panel(
            Markdown(plan),
            title="[cyan]📋 Plan[/cyan]",
            border_style="cyan",
        ))
        self.console.print()

    def _render_error(self, data: dict) -> None:
        """Render error event."""
        message = data.get("message", "Unknown error")
        details = data.get("details")

        self.console.print(f"\n[red bold]✗ Error:[/red bold] {message}")

        if details:
            self.console.print(f"[dim]{details}[/dim]")

    def _render_warning(self, data: dict) -> None:
        """Render warning event."""
        message = data.get("message", "")
        self.console.print(f"[yellow]⚠ {message}[/yellow]")

    def _render_session_end(self, data: dict) -> None:
        """Render session end event."""
        if not self.verbose:
            return

        success = data.get("success", True)
        if not success:
            error = data.get("error", "Unknown error")
            self.console.print(f"\n[red]Session ended with error: {error}[/red]")

    def _render_context_frame(self, data: dict) -> None:
        """Render context frame update (post-agentic loop summary)."""
        adding = data.get("adding") or {}
        reading = data.get("reading") or {}

        # Get stats from the adding data
        step_count = adding.get("step_count", 0)
        entities_found = adding.get("entities_found", 0)
        context_tokens = adding.get("context_tokens", 0)
        context_breakdown = adding.get("context_breakdown", {})

        # Get reading stats
        item_count = reading.get("item_count", 0)

        # Only show if there's something to report
        if step_count == 0 and item_count == 0 and context_tokens == 0:
            return

        self.console.print()
        self.console.print("[dim]───── Context Frame ─────[/dim]")

        # Show total context
        if context_tokens > 0:
            self.console.print(f"  [bold]Total: {context_tokens:,} tokens[/bold]")

        # Show breakdown
        if context_breakdown:
            breakdown_parts = []
            for key, tokens in context_breakdown.items():
                if tokens > 0:
                    breakdown_parts.append(f"{key}: {tokens:,}")
            if breakdown_parts:
                self.console.print(f"  [dim]Breakdown: {' | '.join(breakdown_parts)}[/dim]")

        # Show other stats
        stats = []
        if step_count > 0:
            stats.append(f"{step_count} steps")
        if entities_found > 0:
            stats.append(f"{entities_found} entities")
        if item_count > 0:
            stats.append(f"{item_count} context items")

        if stats:
            self.console.print(f"  [dim]{' · '.join(stats)}[/dim]")
