"""Core utilities for Kroget."""
