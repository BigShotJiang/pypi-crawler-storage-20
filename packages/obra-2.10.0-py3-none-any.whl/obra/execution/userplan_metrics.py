"""UserPlan source type metrics for tracking distribution across the pipeline.

This module provides metrics instrumentation for UserPlan source types,
emitting Prometheus-style metrics via the event logging system.

Metrics:
    - obra_userplan_source_total: Counter for UserPlan creation by source type
      Labels: source_type (plan_file, objective, prd, prose_plan, intent, structured, import)

The metrics are emitted as structured events that can be:
- Aggregated in log analysis tools (e.g., grep/jq on hybrid.jsonl)
- Scraped by Prometheus via a metrics endpoint (if enabled)
- Used for dashboard visualization

Example:
    >>> from obra.execution.userplan_metrics import emit_userplan_source_metric
    >>> from obra.schemas.userplan_schema import SourceType
    >>> emit_userplan_source_metric(
    ...     source_type=SourceType.INTENT,
    ...     userplan_id="UP-20260117-abc",
    ... )

Related:
    - obra/hybrid/event_logger.py (event logging infrastructure)
    - obra/execution/intake.py (UserPlan intake and creation)
    - obra/execution/intent_to_userplan.py (intent to UserPlan generation)
    - obra/review/metrics.py (quality gate metrics - similar pattern)
    - obra/execution/derivation_metrics.py (derivation metrics - similar pattern)
"""

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.schemas.userplan_schema import SourceType

logger = logging.getLogger(__name__)

# Metric name following Prometheus naming convention
METRIC_USERPLAN_SOURCE_TOTAL = "obra_userplan_source_total"


@dataclass
class UserPlanSourceMetric:
    """Structured metric event for UserPlan source type tracking.

    Attributes:
        metric_name: Name of the metric (obra_userplan_source_total)
        value: Metric value (1 for counter increment)
        labels: Metric labels (source_type)
        userplan_id: ID of the UserPlan being created
        project_id: Project identifier
        is_generated: Whether the UserPlan was Obra-generated
        timestamp: ISO-8601 timestamp when metric was recorded
    """

    metric_name: str
    value: float
    labels: dict[str, str]
    userplan_id: str
    project_id: str | None = None
    is_generated: bool = False
    timestamp: str | None = None

    def __post_init__(self) -> None:
        if self.timestamp is None:
            self.timestamp = datetime.now(UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for event logging."""
        return {
            "metric_name": self.metric_name,
            "value": self.value,
            "labels": self.labels,
            "userplan_id": self.userplan_id,
            "project_id": self.project_id,
            "is_generated": self.is_generated,
            "timestamp": self.timestamp,
        }


def _get_source_type_label(source_type: "SourceType | None") -> str:
    """Convert SourceType enum to metric label string.

    Args:
        source_type: Source type enum or None

    Returns:
        Label string from SourceType.value, or "unknown" if None
    """
    if source_type is None:
        return "unknown"
    return source_type.value


def emit_userplan_source_metric(
    source_type: "SourceType | None",
    userplan_id: str,
    project_id: str | None = None,
    is_generated: bool = False,
    log_event: Any | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> UserPlanSourceMetric:
    """Emit UserPlan source type metric on creation.

    Increments the obra_userplan_source_total counter with the source_type label.
    This tracks the distribution of UserPlan sources across the pipeline.

    Args:
        source_type: SourceType of the UserPlan (plan_file, objective, prd, etc.)
        userplan_id: ID of the UserPlan being created
        project_id: Optional project identifier
        is_generated: Whether the UserPlan was Obra-generated (vs user-provided)
        log_event: Optional event logger callback
        trace_id: Optional trace ID for correlation
        parent_span_id: Optional parent span ID for correlation

    Returns:
        UserPlanSourceMetric instance that was emitted

    Example:
        >>> from obra.schemas.userplan_schema import SourceType
        >>> metric = emit_userplan_source_metric(
        ...     source_type=SourceType.INTENT,
        ...     userplan_id="UP-20260117-abc",
        ...     project_id="my-project",
        ...     is_generated=True,
        ... )
        >>> print(f"Emitted metric for source_type={metric.labels['source_type']}")
    """
    timestamp = datetime.now(UTC).isoformat()
    source_label = _get_source_type_label(source_type)

    metric = UserPlanSourceMetric(
        metric_name=METRIC_USERPLAN_SOURCE_TOTAL,
        value=1.0,  # Counter increment
        labels={
            "source_type": source_label,
        },
        userplan_id=userplan_id,
        project_id=project_id,
        is_generated=is_generated,
        timestamp=timestamp,
    )

    # Log metric event
    if log_event:
        try:
            log_event(
                "userplan_source_metric",
                session_id=None,
                trace_id=trace_id,
                parent_span_id=parent_span_id,
                **metric.to_dict(),
            )
        except Exception as e:
            logger.debug("Failed to log userplan source metric: %s", e)

    logger.debug(
        "Emitted userplan source metric for %s: source_type=%s, generated=%s",
        userplan_id,
        source_label,
        is_generated,
    )

    return metric


def get_userplan_source_summary(
    metrics: list[UserPlanSourceMetric],
) -> dict[str, Any]:
    """Aggregate UserPlan source metrics into a summary.

    Useful for batch analysis or dashboard display.

    Args:
        metrics: List of UserPlanSourceMetric instances

    Returns:
        Summary dict with:
        - total_userplans: Total number of UserPlans created
        - source_distribution: Count of UserPlans per source_type
        - generated_count: Number of Obra-generated UserPlans
        - user_provided_count: Number of user-provided UserPlans
    """
    if not metrics:
        return {
            "total_userplans": 0,
            "source_distribution": {},
            "generated_count": 0,
            "user_provided_count": 0,
        }

    # Count by source type
    source_distribution: dict[str, int] = {}
    generated_count = 0
    user_provided_count = 0

    for m in metrics:
        source_type = m.labels.get("source_type", "unknown")
        source_distribution[source_type] = source_distribution.get(source_type, 0) + 1

        if m.is_generated:
            generated_count += 1
        else:
            user_provided_count += 1

    return {
        "total_userplans": len(metrics),
        "source_distribution": source_distribution,
        "generated_count": generated_count,
        "user_provided_count": user_provided_count,
    }


__all__ = [
    "METRIC_USERPLAN_SOURCE_TOTAL",
    "UserPlanSourceMetric",
    "emit_userplan_source_metric",
    "get_userplan_source_summary",
]
