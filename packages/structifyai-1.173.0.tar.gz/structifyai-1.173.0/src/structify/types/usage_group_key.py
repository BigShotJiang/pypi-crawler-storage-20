# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["UsageGroupKey"]

UsageGroupKey: TypeAlias = Literal[
    "web", "pdf", "derive", "scrape", "apollo", "searchapi", "newsapi", "match", "connectorexplore", "other"
]
