# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["AdminDeleteJobsResponse"]


class AdminDeleteJobsResponse(BaseModel):
    deleted_jobs: int
