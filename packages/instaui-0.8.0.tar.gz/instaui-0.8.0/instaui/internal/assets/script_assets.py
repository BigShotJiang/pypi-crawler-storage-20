from typing import Any, Optional
from instaui.systems.dataclass_system import dataclass


@dataclass(frozen=True)
class ScriptTag:
    content: str
    script_attrs: Optional[dict[str, Any]] = None
