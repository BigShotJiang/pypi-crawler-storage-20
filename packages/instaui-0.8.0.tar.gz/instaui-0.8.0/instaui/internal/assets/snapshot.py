from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING, Optional
from instaui.systems.dataclass_system import dataclass

if TYPE_CHECKING:
    from .script_assets import ScriptTag
    from .plugin import PluginDependencyInfo
    from instaui.internal.assets.style_assets import StyleTag


@dataclass(frozen=True)
class AssetsSnapshot:
    js_links: list[str | Path]
    css_links: list[str | Path]
    style_tags: list[StyleTag]
    script_tags: list[ScriptTag]
    import_maps: dict[str, str | Path]
    favicon: Optional[str | Path]
    plugins: set[PluginDependencyInfo]
    component_dependencies: list[ComponentDependencySnapshot]


@dataclass(frozen=True)
class ComponentDependencySnapshot:
    tag: str
    esm: Path
