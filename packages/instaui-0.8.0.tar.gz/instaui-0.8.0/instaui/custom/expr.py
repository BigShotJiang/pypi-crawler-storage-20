from instaui.internal.ui._expr import static_expr

__all__ = ["static_expr"]
