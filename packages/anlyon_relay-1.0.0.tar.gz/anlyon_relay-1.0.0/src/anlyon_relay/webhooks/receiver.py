"""Webhook signature verification for the Anlyon Relay SDK."""

from __future__ import annotations

import hashlib
import hmac
import time
from dataclasses import dataclass

from ..core.errors import AnlyonError
from ..types.enums import ErrorCode


class SignatureVerificationError(AnlyonError):
    """Raised when webhook signature verification fails."""

    def __init__(self, message: str = "Signature verification failed") -> None:
        super().__init__(
            message=message,
            code=ErrorCode.VALIDATION_ERROR,
            status=400,
        )


@dataclass
class ReceiverConfig:
    """Configuration for the webhook receiver."""

    signing_secret: str
    clock_tolerance: int = 300  # 5 minutes in seconds


@dataclass
class WebhookVerificationResult:
    """Result of webhook signature verification."""

    valid: bool
    timestamp: int | None = None
    error: str | None = None


class Receiver:
    """Verifies webhook signatures from Anlyon Relay."""

    def __init__(self, config: ReceiverConfig) -> None:
        """Initialize the receiver.

        Args:
            config: Receiver configuration.
        """
        self._secret = config.signing_secret
        self._clock_tolerance = config.clock_tolerance

    def _parse_signature_header(self, header: str) -> tuple[int | None, list[str]]:
        """Parse the signature header.

        Header format: t=<timestamp>,v1=<signature1>,v1=<signature2>

        Args:
            header: The signature header value.

        Returns:
            Tuple of (timestamp, list of signatures).
        """
        timestamp: int | None = None
        signatures: list[str] = []

        for part in header.split(","):
            part = part.strip()
            if part.startswith("t="):
                try:
                    timestamp = int(part[2:])
                except ValueError:
                    pass
            elif part.startswith("v1="):
                signatures.append(part[3:])

        return timestamp, signatures

    def _compute_signature(self, timestamp: int, payload: str) -> str:
        """Compute the expected signature.

        Args:
            timestamp: The request timestamp.
            payload: The raw request body.

        Returns:
            The computed HMAC signature.
        """
        signed_payload = f"{timestamp}.{payload}"
        signature = hmac.new(
            self._secret.encode("utf-8"),
            signed_payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return signature

    def _secure_compare(self, a: str, b: str) -> bool:
        """Constant-time string comparison to prevent timing attacks.

        Args:
            a: First string.
            b: Second string.

        Returns:
            True if strings are equal.
        """
        return hmac.compare_digest(a, b)

    def verify(self, signature: str | None, body: str) -> bool:
        """Verify the webhook signature.

        Args:
            signature: The signature header value.
            body: The raw request body.

        Returns:
            True if the signature is valid.
        """
        if not signature:
            return False

        timestamp, signatures = self._parse_signature_header(signature)

        if timestamp is None:
            return False

        if not signatures:
            return False

        # Check timestamp is within tolerance
        current_time = int(time.time())
        if abs(current_time - timestamp) > self._clock_tolerance:
            return False

        # Compute expected signature
        expected_signature = self._compute_signature(timestamp, body)

        # Check if any of the provided signatures match
        for sig in signatures:
            if self._secure_compare(expected_signature, sig):
                return True

        return False

    def verify_or_throw(self, signature: str | None, body: str) -> None:
        """Verify the webhook signature or raise an error.

        Args:
            signature: The signature header value.
            body: The raw request body.

        Raises:
            SignatureVerificationError: If verification fails.
        """
        if not signature:
            raise SignatureVerificationError("Missing signature header")

        timestamp, signatures = self._parse_signature_header(signature)

        if timestamp is None:
            raise SignatureVerificationError("Missing timestamp in signature header")

        if not signatures:
            raise SignatureVerificationError("No signatures found in header")

        # Check timestamp is within tolerance
        current_time = int(time.time())
        if abs(current_time - timestamp) > self._clock_tolerance:
            raise SignatureVerificationError(
                f"Timestamp is too old or in the future. "
                f"Difference: {abs(current_time - timestamp)} seconds"
            )

        # Compute expected signature
        expected_signature = self._compute_signature(timestamp, body)

        # Check if any of the provided signatures match
        for sig in signatures:
            if self._secure_compare(expected_signature, sig):
                return

        raise SignatureVerificationError("Signature does not match")


def verify_webhook_signature(
    payload: str,
    signature_header: str,
    secret: str,
    tolerance_seconds: int = 300,
) -> WebhookVerificationResult:
    """Verify a webhook signature (legacy function).

    Args:
        payload: The raw request body.
        signature_header: The signature header value.
        secret: The signing secret.
        tolerance_seconds: Maximum allowed timestamp difference.

    Returns:
        Verification result.
    """
    try:
        receiver = Receiver(
            ReceiverConfig(
                signing_secret=secret,
                clock_tolerance=tolerance_seconds,
            )
        )

        # Parse header for timestamp
        timestamp: int | None = None
        for part in signature_header.split(","):
            part = part.strip()
            if part.startswith("t="):
                try:
                    timestamp = int(part[2:])
                except ValueError:
                    pass
                break

        if receiver.verify(signature_header, payload):
            return WebhookVerificationResult(valid=True, timestamp=timestamp)
        else:
            return WebhookVerificationResult(
                valid=False,
                timestamp=timestamp,
                error="Signature verification failed",
            )
    except SignatureVerificationError as e:
        return WebhookVerificationResult(valid=False, error=str(e))
    except Exception as e:
        return WebhookVerificationResult(valid=False, error=f"Unexpected error: {e}")
