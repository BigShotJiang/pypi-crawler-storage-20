"""Response wrapper types for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class ApiError(BaseModel):
    """API error details."""

    code: str = Field(..., description="Error code")
    message: str = Field(..., description="Error message")
    details: Any | None = Field(default=None, description="Additional error details")


class ApiResponse(BaseModel, Generic[T]):
    """Wrapper for API responses."""

    success: bool = Field(..., description="Whether the request was successful")
    data: T | None = Field(default=None, description="Response data")
    error: ApiError | None = Field(default=None, description="Error details if unsuccessful")

    model_config = {"arbitrary_types_allowed": True}


class Pagination(BaseModel):
    """Pagination information."""

    page: int = Field(..., description="Current page number")
    limit: int = Field(..., description="Items per page")
    total: int = Field(..., description="Total number of items")
    total_pages: int = Field(..., alias="totalPages", description="Total number of pages")
    has_next: bool = Field(..., alias="hasNext", description="Whether there's a next page")
    has_previous: bool = Field(..., alias="hasPrevious", description="Whether there's a previous page")

    model_config = {"populate_by_name": True}


class PaginatedResponse(BaseModel, Generic[T]):
    """Wrapper for paginated API responses."""

    success: bool = Field(..., description="Whether the request was successful")
    data: list[T] | None = Field(default=None, description="Response data")
    pagination: Pagination | None = Field(default=None, description="Pagination information")
    error: ApiError | None = Field(default=None, description="Error details if unsuccessful")

    model_config = {"arbitrary_types_allowed": True}
