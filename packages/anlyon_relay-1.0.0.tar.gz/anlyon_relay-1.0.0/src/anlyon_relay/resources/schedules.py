"""Schedules resource for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    CreateScheduleRequest,
    Schedule,
    SimpleMessage,
    UpdateScheduleRequest,
)
from ..types.responses import ApiResponse
from .base import AsyncBaseResource, BaseResource

if TYPE_CHECKING:
    from ..helpers.builders import ScheduleBuilder


class SchedulesResource(BaseResource):
    """Synchronous schedules resource client."""

    _base_path = "/api/v2/schedules"

    def create(self, request: CreateScheduleRequest) -> ApiResponse[Schedule]:
        """Create a new schedule.

        Args:
            request: Schedule creation request.

        Returns:
            API response with created schedule.
        """
        data = self._post(body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Schedule.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def create_schedule(self) -> "ScheduleBuilder":
        """Create a fluent schedule builder.

        Returns:
            A new ScheduleBuilder instance.
        """
        from ..helpers.builders import ScheduleBuilder

        return ScheduleBuilder(self)

    def list(self) -> ApiResponse[list[Schedule]]:
        """List all schedules.

        Returns:
            API response with list of schedules.
        """
        data = self._get()
        schedules = None
        if data.get("data"):
            schedules = [Schedule.model_validate(s) for s in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=schedules,
            error=data.get("error"),
        )

    def get(self, schedule_id: str) -> ApiResponse[Schedule]:
        """Get a specific schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with schedule.
        """
        data = self._get(schedule_id)
        result = None
        if data.get("data"):
            result = Schedule.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def update(
        self,
        schedule_id: str,
        request: UpdateScheduleRequest,
    ) -> ApiResponse[Schedule]:
        """Update a schedule.

        Args:
            schedule_id: Schedule identifier.
            request: Update request.

        Returns:
            API response with updated schedule.
        """
        data = self._patch(schedule_id, body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Schedule.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def delete(self, schedule_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with confirmation.
        """
        data = self._delete(schedule_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def pause(self, schedule_id: str) -> ApiResponse[SimpleMessage]:
        """Pause a schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with confirmation.
        """
        data = self._post(f"{schedule_id}/pause")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def resume(self, schedule_id: str) -> ApiResponse[SimpleMessage]:
        """Resume a paused schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with confirmation.
        """
        data = self._post(f"{schedule_id}/resume")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncSchedulesResource(AsyncBaseResource):
    """Asynchronous schedules resource client."""

    _base_path = "/api/v2/schedules"

    async def create(self, request: CreateScheduleRequest) -> ApiResponse[Schedule]:
        """Create a new schedule.

        Args:
            request: Schedule creation request.

        Returns:
            API response with created schedule.
        """
        data = await self._post(body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Schedule.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def create_schedule(self) -> "ScheduleBuilder":
        """Create a fluent schedule builder.

        Returns:
            A new ScheduleBuilder instance.
        """
        from ..helpers.builders import ScheduleBuilder

        return ScheduleBuilder(self)

    async def list(self) -> ApiResponse[list[Schedule]]:
        """List all schedules.

        Returns:
            API response with list of schedules.
        """
        data = await self._get()
        schedules = None
        if data.get("data"):
            schedules = [Schedule.model_validate(s) for s in data["data"]]
        return ApiResponse(
            success=data.get("success", True),
            data=schedules,
            error=data.get("error"),
        )

    async def get(self, schedule_id: str) -> ApiResponse[Schedule]:
        """Get a specific schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with schedule.
        """
        data = await self._get(schedule_id)
        result = None
        if data.get("data"):
            result = Schedule.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def update(
        self,
        schedule_id: str,
        request: UpdateScheduleRequest,
    ) -> ApiResponse[Schedule]:
        """Update a schedule.

        Args:
            schedule_id: Schedule identifier.
            request: Update request.

        Returns:
            API response with updated schedule.
        """
        data = await self._patch(schedule_id, body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = Schedule.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def delete(self, schedule_id: str) -> ApiResponse[SimpleMessage]:
        """Delete a schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._delete(schedule_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def pause(self, schedule_id: str) -> ApiResponse[SimpleMessage]:
        """Pause a schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._post(f"{schedule_id}/pause")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def resume(self, schedule_id: str) -> ApiResponse[SimpleMessage]:
        """Resume a paused schedule.

        Args:
            schedule_id: Schedule identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._post(f"{schedule_id}/resume")
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
