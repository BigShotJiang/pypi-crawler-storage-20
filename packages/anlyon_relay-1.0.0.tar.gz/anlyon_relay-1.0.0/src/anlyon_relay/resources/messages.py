"""Messages resource for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..core.http_client import AsyncHttpClient, HttpClient
from ..types.api import (
    BatchPublishResult,
    ListMessagesParams,
    Message,
    PublishMessageRequest,
    PublishResult,
    SimpleMessage,
)
from ..types.responses import ApiResponse, PaginatedResponse, Pagination
from .base import AsyncBaseResource, BaseResource

if TYPE_CHECKING:
    from ..helpers.builders import PublishMessageBuilder
    from ..helpers.pagination import AsyncPaginationIterator, PaginationIterator


class MessagesResource(BaseResource):
    """Synchronous messages resource client."""

    _base_path = "/api/v2/messages"

    def publish(self, request: PublishMessageRequest) -> ApiResponse[PublishResult]:
        """Publish a single message.

        Args:
            request: Message publish request.

        Returns:
            API response with publish result.
        """
        data = self._post("publish", body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = PublishResult.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def create_message(self) -> "PublishMessageBuilder":
        """Create a fluent message builder.

        Returns:
            A new PublishMessageBuilder instance.
        """
        from ..helpers.builders import PublishMessageBuilder

        return PublishMessageBuilder(self)

    def publish_batch(
        self,
        messages: list[PublishMessageRequest],
    ) -> ApiResponse[BatchPublishResult]:
        """Publish multiple messages in a batch.

        Args:
            messages: List of message publish requests.

        Returns:
            API response with batch publish result.
        """
        body = [msg.model_dump_api() for msg in messages]
        data = self._post("batch", body=body)
        result = None
        if data.get("data"):
            result = BatchPublishResult.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def list(
        self,
        params: ListMessagesParams | None = None,
    ) -> PaginatedResponse[Message]:
        """List messages with optional filters.

        Args:
            params: List parameters.

        Returns:
            Paginated response with messages.
        """
        query_params = params.to_query_params() if params else {}
        data = self._get(params=query_params)

        messages = None
        if data.get("data"):
            messages = [Message.model_validate(m) for m in data["data"]]

        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination.model_validate(pagination_data)

        return PaginatedResponse(
            success=data.get("success", True),
            data=messages,
            pagination=pagination,
            error=data.get("error"),
        )

    def list_all(
        self,
        params: ListMessagesParams | None = None,
    ) -> "PaginationIterator[Message]":
        """Create a pagination iterator for all messages.

        Args:
            params: List parameters (page will be ignored).

        Returns:
            A pagination iterator.
        """
        from ..helpers.pagination import PaginationIterator

        base_params = params.model_copy() if params else ListMessagesParams()

        def fetcher(page: int, limit: int) -> PaginatedResponse[Message]:
            base_params.page = page
            base_params.limit = limit
            return self.list(base_params)

        return PaginationIterator(fetcher, page_size=base_params.limit)

    def get(self, message_id: str) -> ApiResponse[Message]:
        """Get a specific message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with message.
        """
        data = self._get(message_id)
        result = None
        if data.get("data"):
            result = Message.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def cancel(self, message_id: str) -> ApiResponse[SimpleMessage]:
        """Cancel a pending message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with confirmation.
        """
        data = self._delete(message_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )


class AsyncMessagesResource(AsyncBaseResource):
    """Asynchronous messages resource client."""

    _base_path = "/api/v2/messages"

    async def publish(self, request: PublishMessageRequest) -> ApiResponse[PublishResult]:
        """Publish a single message.

        Args:
            request: Message publish request.

        Returns:
            API response with publish result.
        """
        data = await self._post("publish", body=request.model_dump_api())
        result = None
        if data.get("data"):
            result = PublishResult.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    def create_message(self) -> "PublishMessageBuilder":
        """Create a fluent message builder.

        Returns:
            A new PublishMessageBuilder instance.
        """
        from ..helpers.builders import PublishMessageBuilder

        return PublishMessageBuilder(self)

    async def publish_batch(
        self,
        messages: list[PublishMessageRequest],
    ) -> ApiResponse[BatchPublishResult]:
        """Publish multiple messages in a batch.

        Args:
            messages: List of message publish requests.

        Returns:
            API response with batch publish result.
        """
        body = [msg.model_dump_api() for msg in messages]
        data = await self._post("batch", body=body)
        result = None
        if data.get("data"):
            result = BatchPublishResult.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def list(
        self,
        params: ListMessagesParams | None = None,
    ) -> PaginatedResponse[Message]:
        """List messages with optional filters.

        Args:
            params: List parameters.

        Returns:
            Paginated response with messages.
        """
        query_params = params.to_query_params() if params else {}
        data = await self._get(params=query_params)

        messages = None
        if data.get("data"):
            messages = [Message.model_validate(m) for m in data["data"]]

        pagination_data = data.get("pagination")
        pagination = None
        if pagination_data:
            pagination = Pagination.model_validate(pagination_data)

        return PaginatedResponse(
            success=data.get("success", True),
            data=messages,
            pagination=pagination,
            error=data.get("error"),
        )

    def list_all(
        self,
        params: ListMessagesParams | None = None,
    ) -> "AsyncPaginationIterator[Message]":
        """Create an async pagination iterator for all messages.

        Args:
            params: List parameters (page will be ignored).

        Returns:
            An async pagination iterator.
        """
        from ..helpers.pagination import AsyncPaginationIterator

        base_params = params.model_copy() if params else ListMessagesParams()

        async def fetcher(page: int, limit: int) -> PaginatedResponse[Message]:
            base_params.page = page
            base_params.limit = limit
            return await self.list(base_params)

        return AsyncPaginationIterator(fetcher, page_size=base_params.limit)

    async def get(self, message_id: str) -> ApiResponse[Message]:
        """Get a specific message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with message.
        """
        data = await self._get(message_id)
        result = None
        if data.get("data"):
            result = Message.model_validate(data["data"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )

    async def cancel(self, message_id: str) -> ApiResponse[SimpleMessage]:
        """Cancel a pending message.

        Args:
            message_id: Message identifier.

        Returns:
            API response with confirmation.
        """
        data = await self._delete(message_id)
        result = None
        if data.get("data"):
            result = SimpleMessage.model_validate(data["data"])
        elif data.get("message"):
            result = SimpleMessage(message=data["message"])
        return ApiResponse(
            success=data.get("success", True),
            data=result,
            error=data.get("error"),
        )
