"""Pagination iterators for the Anlyon Relay SDK."""

from __future__ import annotations

from typing import (
    Any,
    AsyncIterator,
    Awaitable,
    Callable,
    Generic,
    Iterator,
    TypeVar,
)

from ..types.responses import PaginatedResponse

T = TypeVar("T")

PageFetcher = Callable[[int, int], PaginatedResponse[T]]
AsyncPageFetcher = Callable[[int, int], Awaitable[PaginatedResponse[T]]]


class PaginationIterator(Generic[T]):
    """Synchronous iterator for paginated results."""

    def __init__(
        self,
        fetcher: PageFetcher[T],
        page_size: int = 20,
    ) -> None:
        """Initialize the iterator.

        Args:
            fetcher: Function to fetch a page of results.
            page_size: Number of items per page.
        """
        self._fetcher = fetcher
        self._page_size = page_size
        self._current_page = 0
        self._items: list[T] = []
        self._item_index = 0
        self._exhausted = False

    def _fetch_next_page(self) -> bool:
        """Fetch the next page of results.

        Returns:
            True if there are more items, False if exhausted.
        """
        if self._exhausted:
            return False

        self._current_page += 1
        response = self._fetcher(self._current_page, self._page_size)

        if response.data:
            self._items = response.data
            self._item_index = 0

            # Check if there are more pages
            if response.pagination:
                self._exhausted = not response.pagination.has_next
            else:
                self._exhausted = len(response.data) < self._page_size

            return len(self._items) > 0

        self._exhausted = True
        return False

    def __iter__(self) -> Iterator[T]:
        """Return the iterator."""
        return self

    def __next__(self) -> T:
        """Get the next item.

        Returns:
            The next item.

        Raises:
            StopIteration: When all items have been iterated.
        """
        # Check if we need to fetch more items
        if self._item_index >= len(self._items):
            if not self._fetch_next_page():
                raise StopIteration

        item = self._items[self._item_index]
        self._item_index += 1
        return item

    def to_list(self) -> list[T]:
        """Collect all items into a list.

        Returns:
            List of all items.
        """
        return list(self)

    def to_array(self) -> list[T]:
        """Collect all items into a list (alias).

        Returns:
            List of all items.
        """
        return self.to_list()

    def take(self, n: int) -> list[T]:
        """Take up to n items.

        Args:
            n: Maximum number of items to take.

        Returns:
            List of up to n items.
        """
        items = []
        for item in self:
            items.append(item)
            if len(items) >= n:
                break
        return items

    def find(self, predicate: Callable[[T], bool]) -> T | None:
        """Find the first item matching a predicate.

        Args:
            predicate: Function to test each item.

        Returns:
            First matching item or None.
        """
        for item in self:
            if predicate(item):
                return item
        return None

    def for_each(self, callback: Callable[[T, int], None]) -> None:
        """Call a function for each item.

        Args:
            callback: Function to call with (item, index).
        """
        for index, item in enumerate(self):
            callback(item, index)

    def map(self, transform: Callable[[T], Any]) -> list[Any]:
        """Transform all items.

        Args:
            transform: Function to transform each item.

        Returns:
            List of transformed items.
        """
        return [transform(item) for item in self]

    def filter(self, predicate: Callable[[T], bool]) -> list[T]:
        """Filter items by predicate.

        Args:
            predicate: Function to test each item.

        Returns:
            List of matching items.
        """
        return [item for item in self if predicate(item)]

    def count(self) -> int:
        """Count all items.

        Returns:
            Total number of items.
        """
        return len(self.to_list())

    def any(self) -> bool:
        """Check if there are any items.

        Returns:
            True if there is at least one item.
        """
        try:
            next(iter(self))
            return True
        except StopIteration:
            return False

    def first(self) -> T | None:
        """Get the first item.

        Returns:
            First item or None.
        """
        try:
            return next(iter(self))
        except StopIteration:
            return None


class AsyncPaginationIterator(Generic[T]):
    """Asynchronous iterator for paginated results."""

    def __init__(
        self,
        fetcher: AsyncPageFetcher[T],
        page_size: int = 20,
    ) -> None:
        """Initialize the async iterator.

        Args:
            fetcher: Async function to fetch a page of results.
            page_size: Number of items per page.
        """
        self._fetcher = fetcher
        self._page_size = page_size
        self._current_page = 0
        self._items: list[T] = []
        self._item_index = 0
        self._exhausted = False

    async def _fetch_next_page(self) -> bool:
        """Fetch the next page of results.

        Returns:
            True if there are more items, False if exhausted.
        """
        if self._exhausted:
            return False

        self._current_page += 1
        response = await self._fetcher(self._current_page, self._page_size)

        if response.data:
            self._items = response.data
            self._item_index = 0

            # Check if there are more pages
            if response.pagination:
                self._exhausted = not response.pagination.has_next
            else:
                self._exhausted = len(response.data) < self._page_size

            return len(self._items) > 0

        self._exhausted = True
        return False

    def __aiter__(self) -> AsyncIterator[T]:
        """Return the async iterator."""
        return self

    async def __anext__(self) -> T:
        """Get the next item.

        Returns:
            The next item.

        Raises:
            StopAsyncIteration: When all items have been iterated.
        """
        # Check if we need to fetch more items
        if self._item_index >= len(self._items):
            if not await self._fetch_next_page():
                raise StopAsyncIteration

        item = self._items[self._item_index]
        self._item_index += 1
        return item

    async def to_list(self) -> list[T]:
        """Collect all items into a list.

        Returns:
            List of all items.
        """
        items = []
        async for item in self:
            items.append(item)
        return items

    async def to_array(self) -> list[T]:
        """Collect all items into a list (alias).

        Returns:
            List of all items.
        """
        return await self.to_list()

    async def take(self, n: int) -> list[T]:
        """Take up to n items.

        Args:
            n: Maximum number of items to take.

        Returns:
            List of up to n items.
        """
        items = []
        async for item in self:
            items.append(item)
            if len(items) >= n:
                break
        return items

    async def find(self, predicate: Callable[[T], bool]) -> T | None:
        """Find the first item matching a predicate.

        Args:
            predicate: Function to test each item.

        Returns:
            First matching item or None.
        """
        async for item in self:
            if predicate(item):
                return item
        return None

    async def for_each(
        self,
        callback: Callable[[T, int], None] | Callable[[T, int], Awaitable[None]],
    ) -> None:
        """Call a function for each item.

        Args:
            callback: Function to call with (item, index).
        """
        import asyncio

        index = 0
        async for item in self:
            result = callback(item, index)
            if asyncio.iscoroutine(result):
                await result
            index += 1

    async def map(self, transform: Callable[[T], Any]) -> list[Any]:
        """Transform all items.

        Args:
            transform: Function to transform each item.

        Returns:
            List of transformed items.
        """
        items = []
        async for item in self:
            items.append(transform(item))
        return items

    async def filter(self, predicate: Callable[[T], bool]) -> list[T]:
        """Filter items by predicate.

        Args:
            predicate: Function to test each item.

        Returns:
            List of matching items.
        """
        items = []
        async for item in self:
            if predicate(item):
                items.append(item)
        return items

    async def count(self) -> int:
        """Count all items.

        Returns:
            Total number of items.
        """
        return len(await self.to_list())

    async def any(self) -> bool:
        """Check if there are any items.

        Returns:
            True if there is at least one item.
        """
        try:
            async for _ in self:
                return True
            return False
        except StopAsyncIteration:
            return False

    async def first(self) -> T | None:
        """Get the first item.

        Returns:
            First item or None.
        """
        try:
            async for item in self:
                return item
            return None
        except StopAsyncIteration:
            return None
