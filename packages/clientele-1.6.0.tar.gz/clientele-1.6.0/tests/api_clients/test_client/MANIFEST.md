# Manifest

Generated with [https://github.com/phalt/clientele](https://github.com/phalt/clientele)

Install with pipx:

```sh
pipx install clientele
```

Or with uv:

```sh
uv tool install clientele
```

API VERSION: 0.1.0
OPENAPI VERSION: 3.0.2
CLIENTELE VERSION: 1.6.0

Regenerate using this command:

```sh
clientele scaffold-api -f example_openapi_specs/best.json -o tests/api_clients/test_client/  --regen
```

Explore this API interactively:

```sh
clientele explore -c .
```
