
{
    "version": "2026.1.17",
    "target": "default",
    "variant": "cpu"
}
