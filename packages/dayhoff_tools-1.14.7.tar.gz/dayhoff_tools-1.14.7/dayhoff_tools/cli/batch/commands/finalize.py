"""Finalize command for combining results and cleaning up."""

import shutil
from pathlib import Path

import click

from ..manifest import (
    BATCH_JOBS_BASE,
    JobStatus,
    delete_job_directory,
    get_job_dir,
    load_manifest,
    save_manifest,
)


@click.command()
@click.argument("job_id")
@click.option(
    "--output",
    required=True,
    type=click.Path(),
    help="Output path for combined results",
)
@click.option("--force", is_flag=True, help="Finalize even if some chunks failed")
@click.option(
    "--keep-intermediates",
    is_flag=True,
    help="Don't delete job directory after finalizing",
)
@click.option("--base-path", default=BATCH_JOBS_BASE, help="Base path for job data")
def finalize(job_id, output, force, keep_intermediates, base_path):
    """Combine results and clean up job intermediates.

    For embedding jobs, combines H5 files into a single output file.
    For structure prediction, moves outputs to the destination.

    \b
    Examples:
      dh batch finalize dma-embed-20260109-a3f2 --output /primordial/embeddings.h5
      dh batch finalize dma-embed-20260109-a3f2 --output /primordial/embeddings.h5 --force
      dh batch finalize dma-embed-20260109-a3f2 --output /primordial/out.h5 --keep-intermediates
    """
    # Load manifest
    try:
        manifest = load_manifest(job_id, base_path)
    except FileNotFoundError:
        click.echo(f"Job not found: {job_id}", err=True)
        raise SystemExit(1)

    # Check job status
    if manifest.status == JobStatus.FINALIZED:
        click.echo(f"Job {job_id} is already finalized.", err=True)
        raise SystemExit(1)

    job_dir = get_job_dir(job_id, base_path)
    output_dir = job_dir / "output"
    output_path = Path(output).resolve()

    # Check completion status
    incomplete = _check_completion(job_id, base_path)
    if incomplete:
        click.echo(f"Found {len(incomplete)} incomplete chunks: {incomplete[:10]}...")
        if not force:
            click.echo()
            click.echo("Use --force to finalize anyway, or retry failed chunks:")
            click.echo(f"  dh batch retry {job_id}")
            raise SystemExit(1)
        click.echo()
        click.echo(
            click.style("Warning: Finalizing with incomplete chunks", fg="yellow")
        )

    # Update status
    manifest.status = JobStatus.FINALIZING
    save_manifest(manifest, base_path)

    # Finalize based on pipeline type
    click.echo()
    if manifest.pipeline in ("embed-t5", "embed"):
        _finalize_embeddings(output_dir, output_path)
    elif manifest.pipeline == "boltz":
        _finalize_boltz(output_dir, output_path)
    else:
        _finalize_generic(output_dir, output_path)

    # Update manifest
    manifest.status = JobStatus.FINALIZED
    if manifest.output:
        manifest.output.destination = str(output_path)
        manifest.output.finalized = True
    save_manifest(manifest, base_path)

    click.echo()
    click.echo(click.style(f"✓ Results saved to: {output_path}", fg="green"))

    # Clean up
    if not keep_intermediates:
        click.echo(f"Cleaning up job directory: {job_dir}")
        delete_job_directory(job_id, base_path)
        click.echo(click.style("✓ Job directory deleted", fg="green"))
    else:
        click.echo(f"Job directory preserved: {job_dir}")


def _check_completion(job_id: str, base_path: str) -> list[int]:
    """Check which chunks are incomplete (no .done marker)."""
    job_dir = get_job_dir(job_id, base_path)
    input_dir = job_dir / "input"
    output_dir = job_dir / "output"

    if not input_dir.exists():
        return []

    incomplete = []
    for chunk_path in sorted(input_dir.glob("chunk_*.fasta")):
        idx_str = chunk_path.stem.split("_")[1]
        idx = int(idx_str)
        done_marker = output_dir / f"embed_{idx:03d}.done"
        if not done_marker.exists():
            incomplete.append(idx)

    return incomplete


def _finalize_embeddings(output_dir: Path, output_path: Path):
    """Combine H5 embedding files into a single output."""
    h5_files = sorted(output_dir.glob("embed_*.h5"))

    if not h5_files:
        click.echo("No H5 files found in output directory.", err=True)
        raise SystemExit(1)

    click.echo(f"Found {len(h5_files)} H5 files to combine")

    # Check if output already exists
    if output_path.exists():
        click.echo(f"Output file already exists: {output_path}", err=True)
        raise SystemExit(1)

    # Ensure output directory exists
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        from dayhoff_tools.h5 import (
            combine_h5_files,
            deduplicate_h5_file,
            optimize_protein_embedding_chunks,
        )
        import tempfile

        if len(h5_files) == 1:
            # Single file - just copy, no need to combine/dedup/optimize
            click.echo("Single chunk - copying directly...")
            shutil.copy2(h5_files[0], output_path)
        else:
            # Multiple files - combine, deduplicate, and optimize
            with tempfile.TemporaryDirectory() as tmpdir:
                combined_path = Path(tmpdir) / "combined.h5"
                deduped_path = Path(tmpdir) / "deduped.h5"

                # Combine H5 files
                click.echo("Combining H5 files...")
                h5_file_paths = [str(f) for f in h5_files]
                combine_h5_files(
                    input_files=h5_file_paths,
                    output_file=str(combined_path),
                )

                # Deduplicate
                click.echo("Deduplicating...")
                deduplicate_h5_file(str(combined_path), str(deduped_path))

                # Optimize chunks
                click.echo("Optimizing chunks...")
                optimize_protein_embedding_chunks(str(deduped_path), str(output_path))

        click.echo(click.style("✓ H5 files combined successfully", fg="green"))

    except ImportError:
        # Fall back to simple concatenation
        click.echo("h5 module not available, using simple copy...")
        if len(h5_files) == 1:
            shutil.copy2(h5_files[0], output_path)
        else:
            # For multiple files without h5 module, just copy first file
            # This is a fallback - the h5 module should be available
            click.echo(
                click.style(
                    "Warning: Cannot combine multiple H5 files without dayhoff_tools.h5 module. "
                    "Only copying first file.",
                    fg="yellow",
                )
            )
            shutil.copy2(h5_files[0], output_path)


def _finalize_boltz(output_dir: Path, output_path: Path):
    """Move Boltz output directories to destination."""
    # Find all output directories (one per complex)
    complex_dirs = [d for d in output_dir.iterdir() if d.is_dir()]

    if not complex_dirs:
        click.echo("No output directories found.", err=True)
        raise SystemExit(1)

    click.echo(f"Found {len(complex_dirs)} structure predictions to move")

    # Ensure output directory exists
    output_path.mkdir(parents=True, exist_ok=True)

    for complex_dir in complex_dirs:
        dest = output_path / complex_dir.name
        if dest.exists():
            click.echo(f"  Skipping {complex_dir.name} (already exists)")
            continue
        shutil.move(str(complex_dir), str(dest))
        click.echo(f"  Moved {complex_dir.name}")

    click.echo(click.style("✓ Structures moved successfully", fg="green"))


def _finalize_generic(output_dir: Path, output_path: Path):
    """Generic finalization - copy output directory."""
    if output_path.exists():
        click.echo(f"Output path already exists: {output_path}", err=True)
        raise SystemExit(1)

    click.echo(f"Copying output directory to {output_path}...")
    shutil.copytree(output_dir, output_path)
    click.echo(click.style("✓ Output copied successfully", fg="green"))
