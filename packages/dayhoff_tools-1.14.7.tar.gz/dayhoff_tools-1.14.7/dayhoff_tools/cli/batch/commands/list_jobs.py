"""List command for showing recent jobs."""

import click

from ..manifest import BATCH_JOBS_BASE, JobStatus, list_jobs as list_manifests
from .status import format_status, format_time_ago


@click.command("list")
@click.option("--user", help="Filter by username")
@click.option(
    "--status",
    "status_filter",
    type=click.Choice([s.value for s in JobStatus]),
    help="Filter by status",
)
@click.option("--pipeline", help="Filter by pipeline type")
@click.option(
    "--limit", default=20, type=int, help="Maximum number of jobs to show [default: 20]"
)
@click.option("--base-path", default=BATCH_JOBS_BASE, help="Base path for job data")
def list_jobs(user, status_filter, pipeline, limit, base_path):
    """List recent batch jobs.

    Shows a table of recent jobs with their status, pipeline type, and creation time.

    \b
    Examples:
      dh batch list                      # All recent jobs
      dh batch list --user dma           # Filter by user
      dh batch list --status running     # Filter by status
      dh batch list --pipeline embed-t5  # Filter by pipeline type
      dh batch list --limit 50           # Show more jobs
    """
    status_enum = JobStatus(status_filter) if status_filter else None

    manifests = list_manifests(
        base_path=base_path,
        user=user,
        status=status_enum,
        pipeline=pipeline,
        limit=limit,
    )

    if not manifests:
        click.echo("No jobs found.")
        if user or status_filter or pipeline:
            click.echo("Try removing filters to see all jobs.")
        return

    # Print header
    click.echo()
    click.echo(
        f"{'JOB ID':<35} {'STATUS':<12} {'PIPELINE':<12} {'USER':<10} {'CREATED':<12}"
    )
    click.echo("-" * 85)

    for manifest in manifests:
        click.echo(
            f"{manifest.job_id:<35} "
            f"{format_status(manifest.status):<21} "  # Extra space for ANSI color codes
            f"{manifest.pipeline:<12} "
            f"{manifest.user:<10} "
            f"{format_time_ago(manifest.created):<12}"
        )

    click.echo()
    click.echo(f"Showing {len(manifests)} jobs.")

    # Show filter hints
    hints = []
    if not user:
        hints.append("--user <name>")
    if not status_filter:
        hints.append("--status <status>")
    if not pipeline:
        hints.append("--pipeline <type>")

    if hints:
        click.echo(f"Filter with: {' '.join(hints)}")
