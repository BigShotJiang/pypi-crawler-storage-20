# My Python Library

A simple utility library for math and text operations.

## Installation

```bash
pip install umar-python-tools-2026