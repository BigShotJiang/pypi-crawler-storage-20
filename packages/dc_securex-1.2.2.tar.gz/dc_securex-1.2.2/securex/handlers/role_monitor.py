"""
Role position monitoring - background task that checks every 5 seconds.
"""
import discord
import asyncio
import json
from pathlib import Path
from typing import List, Tuple
from discord.ext import tasks


class RolePositionMonitor:
    """
    Background monitor that checks and restores role positions every 5 seconds.
    Uses Discord's bulk endpoint for efficient updates.
    """
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_dir = sdk.backup_dir
        self.enabled = False
        self._task = None
    
    def start(self):
        """Start the role position monitoring task"""
        if not self.enabled:
            self.enabled = True
            self._task = self.bot.loop.create_task(self._monitor_loop())
            print("🔍 Role Position Monitor: Started (5 second checks)")
    
    def stop(self):
        """Stop the monitoring task"""
        if self.enabled and self._task:
            self.enabled = False
            self._task.cancel()
            print("🛑 Role Position Monitor: Stopped")
    
    async def _monitor_loop(self):
        """Main monitoring loop - runs every 5 seconds"""
        await self.bot.wait_until_ready()
        
        while self.enabled and not self.bot.is_closed():
            try:
                await self._check_all_guilds()
                await asyncio.sleep(5)  # Check every 5 seconds
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error in role position monitor: {e}")
                await asyncio.sleep(5)
    
    async def _check_all_guilds(self):
        """Check role positions for all guilds"""
        for guild in self.bot.guilds:
            try:
                await self._check_guild_positions(guild)
            except Exception as e:
                print(f"Error checking positions for {guild.name}: {e}")
    
    async def _check_guild_positions(self, guild: discord.Guild):
        """Check and restore role positions for a specific guild"""
        try:
            # Get backup file
            backup_file = self.backup_dir / f"roles_{guild.id}.json"
            if not backup_file.exists():
                return
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Collect all mismatched roles
            role_position_pairs: List[Tuple[discord.Role, int]] = []
            
            for role_data in backup["roles"]:
                role = guild.get_role(role_data["id"])
                if not role:
                    continue  # Role was deleted
                
                # Check if position matches
                if role.position != role_data["position"]:
                    role_position_pairs.append((role, role_data["position"]))
            
            # If we found mismatches, restore using bulk endpoint
            if role_position_pairs:
                print(f"🔧 Restoring {len(role_position_pairs)} role positions in {guild.name}")
                
                try:
                    # Build payload for bulk update
                    positions_payload = [
                        {"id": role.id, "position": expected_pos}
                        for role, expected_pos in role_position_pairs
                    ]
                    
                    # Use Discord's bulk role positions endpoint
                    await guild.edit_role_positions(
                        positions=positions_payload,
                        reason="SecureX: Bulk position restore"
                    )
                    
                    print(f"✅ Restored {len(role_position_pairs)} role positions in {guild.name}")
                    
                except discord.Forbidden as e:
                    print(f"⚠️ Missing permissions to modify role positions: {e}")
                except Exception as e:
                    print(f"Error restoring role positions: {e}")
                    # Fallback to individual updates
                    await self._fallback_individual_updates(guild, role_position_pairs)
        
        except Exception as e:
            print(f"Error in _check_guild_positions: {e}")
    
    async def _fallback_individual_updates(self, guild: discord.Guild, role_position_pairs: List[Tuple[discord.Role, int]]):
        """Fallback to individual role updates if bulk fails"""
        print(f"⚠️ Falling back to individual updates for {len(role_position_pairs)} roles")
        
        for role, expected_pos in role_position_pairs:
            try:
                await role.edit(position=expected_pos, reason="SecureX: Position restore")
                await asyncio.sleep(0.5)  # Rate limit
            except Exception as e:
                print(f"Error updating {role.name}: {e}")
