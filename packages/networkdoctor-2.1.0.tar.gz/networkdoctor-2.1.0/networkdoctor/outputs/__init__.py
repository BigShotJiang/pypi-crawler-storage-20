"""Output modules for NetworkDoctor"""







