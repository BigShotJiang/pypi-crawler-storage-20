"""CLI module for NetworkDoctor"""







