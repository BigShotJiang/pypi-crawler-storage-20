# 🩺 NetworkDoctor - Ultimate AI-Powered Network Diagnostic Tool

**Created by: [frankvena25](https://github.com/frankvena25)**

NetworkDoctor is the world's most advanced network diagnostic tool that uses AI to diagnose, analyze, and fix network issues automatically. It's like having a network expert available 24/7, helping everyone from home users to enterprise IT teams solve network problems quickly and efficiently.

## 🌟 What Makes NetworkDoctor Unique?

NetworkDoctor doesn't just show you problems - it **understands** them, **explains** them in plain English, and provides **exact solutions** with commands you can copy-paste. It's the only tool that combines:

- ✅ **AI-Powered Root Cause Analysis** - Understands natural language ("Internet is slow")
- ✅ **10 Unique Features** - Features no other tool offers
- ✅ **Auto-Repair Capabilities** - Fixes common issues automatically
- ✅ **Predictive Failure Alerts** - Warns you before problems happen
- ✅ **Professional Reports** - Generate ISP complaint letters and IT reports instantly

## 🚀 Quick Start

### Installation

```bash
# Install from PyPI
pip install networkdoctor

# Or install from source
git clone https://github.com/frankvena25/NetworkDoctor.git
cd networkdoctor
pip install -r requirements.txt
pip install -e .
```

### Requirements

- Python 3.8 or higher
- Linux, macOS, or Windows
- Internet connection (optional - has offline mode)

### Basic Usage

```bash
# Scan a website
networkdoctor https://google.com

# Scan an IP address
networkdoctor 192.168.1.1

# Scan a domain
networkdoctor example.com

# Quick scan (30 seconds)
networkdoctor --quick example.com

# Full scan with all doctors
networkdoctor --full example.com

# Generate PDF report
networkdoctor example.com --output pdf --output-file report.pdf

# Use short command
ndoc example.com
```

## 🎯 What Does NetworkDoctor Do?

NetworkDoctor performs comprehensive network diagnosis across multiple dimensions:

### 1. **ISP Problem Detector**
Detects when your ISP is throttling your speed and generates complaint letters with evidence.

```bash
networkdoctor --doctors isp_throttle example.com
```

### 2. **Smart Route Analyzer**
Visualizes network routes on a world map, detects submarine cable crossings, and identifies where packets fail.

```bash
networkdoctor --doctors route_analyzer example.com
```

### 3. **Auto Network Repair Engine**
Automatically fixes DNS, MTU, gateway, proxy, and IPv6 issues (with admin privileges).

```bash
networkdoctor --doctors auto_repair example.com
```

### 4. **Server Self-Heal System**
Monitors CPU spikes, RAM leaks, and disk I/O issues, and automatically restarts safe services.

```bash
networkdoctor --doctors server_heal localhost
```

### 5. **WiFi Hack Checker**
Detects rogue devices, evil twin access points, and ARP spoofing attacks.

```bash
networkdoctor --doctors wifi localhost
```

### 6. **Internet Quality Score**
Scores your connection for gaming, streaming, Zoom calls, and cloud work.

```bash
networkdoctor --doctors quality_score example.com
```

### 7. **AI Root Cause Engine**
Understands natural language problems and provides exact solutions.

```bash
# You can describe problems in natural language
networkdoctor --problem "Internet is slow" example.com
```

### 8. **Offline Diagnosis Mode**
Full local network analysis without needing internet.

```bash
networkdoctor --doctors offline localhost
```

### 9. **Predictive Failure Alert**
Predicts router, ISP, and cable failures before they happen.

```bash
networkdoctor --doctors predictive example.com
```

### 10. **One-Click Full Report**
Generates professional PDF reports for ISP complaints and IT reports.

```bash
networkdoctor example.com --output pdf --output-file isp_complaint.pdf
```

## 📋 Complete Feature List

### Core Diagnostics
- DNS resolution and DNSSEC validation
- SSL/TLS certificate analysis
- Firewall and proxy detection
- Network performance metrics (latency, jitter, packet loss)
- Security vulnerability scanning
- Routing analysis (BGP, AS paths)
- WiFi signal strength and interference
- Cloud network diagnosis (AWS, Azure, GCP)
- VoIP quality analysis
- IoT device detection

### Output Formats
- **Terminal**: Beautiful colored output with tables
- **HTML**: Interactive reports with charts
- **PDF**: Professional reports for management
- **JSON**: Machine-readable output
- **CSV**: Data for analysis
- **Markdown**: Documentation-friendly format

### Advanced Features
- Continuous monitoring mode
- Multi-target scanning (CIDR, file input)
- Custom doctor selection
- Configurable timeouts and rate limits
- Result caching
- Integration with Prometheus, Slack, Email, Webhooks

## 📖 Detailed Usage Guide

### Scan Modes

```bash
# Quick scan (30 seconds)
networkdoctor --quick example.com

# Full scan (2 minutes)
networkdoctor --full example.com

# Deep scan (5+ minutes)
networkdoctor --deep example.com

# Continuous monitoring
networkdoctor --monitor example.com
```

### Selecting Doctors

```bash
# Run specific doctors only
networkdoctor --doctors dns,ssl,performance example.com

# Skip certain doctors
networkdoctor --skip security,firewall example.com

# Run unique features
networkdoctor --doctors isp_throttle,quality_score,root_cause example.com
```

### Output Options

```bash
# Terminal output (default)
networkdoctor example.com

# HTML report
networkdoctor --output html --output-file report.html example.com

# PDF report
networkdoctor --output pdf --output-file report.pdf example.com

# JSON output
networkdoctor --output json --output-file results.json example.com

# CSV output
networkdoctor --output csv --output-file data.csv example.com
```

### Configuration File

Create `config.yaml`:

```yaml
networkdoctor:
  scan_mode: full
  output_format: html
  doctors:
    dns: true
    ssl: true
    performance: true
    isp_throttle: true
    quality_score: true
  
  limits:
    max_targets: 100
    scan_timeout: 300
    rate_limit: 10
```

Use it:

```bash
networkdoctor --config config.yaml example.com
```

## 🛠️ Installation Guide

### Standard Installation

```bash
pip install networkdoctor
```

### Development Installation

```bash
# Clone repository
git clone https://github.com/frankvena25/NetworkDoctor.git
cd networkdoctor

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install in development mode
pip install -e .
```

### Docker Installation

```bash
# Build image
docker build -t networkdoctor -f docker/Dockerfile .

# Run container
docker run -it networkdoctor example.com
```

## 📊 Example Output

When you run NetworkDoctor, you'll see output like this:

```
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║  🩺 N E T W O R K D O C T O R 🩺                            ║
║  Created by: frankvena25                                     ║
║  Scanning: example.com                                       ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

🔍 Running 20 specialist doctors...

✅ DNS Doctor: DNSSEC validated, 45ms resolution
⚠️  SSL Doctor: Certificate expires in 15 days
🔴 ISP Throttle: Speed inconsistency detected (evidence collected)
✅ Quality Score: Gaming 85/100, Streaming 92/100, Zoom 88/100
✅ Auto Repair: DNS cache flushed, 2 issues fixed automatically

📋 EXECUTIVE SUMMARY:
Health Score: 78/100 (Needs Attention)
Critical Issues: 1
Time to Fix: ~30 minutes

🛠️ ACTION PLAN:

IMMEDIATE: Contact ISP about throttling
Evidence: report.pdf
Command: Send ISP complaint template included in report

URGENT: Renew SSL certificate
Command: certbot renew --force-renewal

ROOT CAUSE: ISP throttling detected with 85% confidence
Solution: Contact ISP with evidence, consider VPN if legal
```

## 🎨 Features in Detail

### ISP Throttle Detector

Detects when your ISP is throttling your connection:

- Performs multiple speed tests
- Analyzes patterns for throttling
- Generates ISP complaint letter template
- Provides evidence for regulatory complaints

### Internet Quality Score

Scores your connection for different use cases:

- **Gaming**: <20ms latency, <10ms jitter = 100/100
- **Streaming**: >25 Mbps = Excellent for 4K
- **Zoom**: <50ms latency, <20ms jitter = Crystal clear
- **Cloud Work**: >50 Mbps, <50ms latency = Optimal

### AI Root Cause Engine

Understands problems in plain English:

- Input: "Internet is slow"
- Output: Identifies bandwidth/ISP/latency issue
- Provides exact commands to fix

### Predictive Failure Alert

Warns you before failures:

- Router failure: Detects increasing latency/errors
- ISP downtime: Identifies timeout patterns
- Cable issues: Detects intermittent problems

## 🔧 Troubleshooting

### Common Issues

**Issue**: "Command not found: networkdoctor"
```bash
# Solution: Install or add to PATH
pip install networkdoctor
# or
pip install -e .
```

**Issue**: "Permission denied" for auto-repair
```bash
# Solution: Run with admin privileges
sudo networkdoctor --doctors auto_repair example.com
# or on Windows: Run as Administrator
```

**Issue**: Slow scans
```bash
# Solution: Use quick mode or limit doctors
networkdoctor --quick example.com
networkdoctor --doctors dns,ssl example.com
```

## 📚 Documentation

- [Installation Guide](docs/installation.md)
- [Usage Guide](docs/usage.md)
- [Module Reference](docs/modules.md)
- [API Reference](docs/api_reference.md)
- [Troubleshooting](docs/troubleshooting.md)

## 🤝 Contributing

We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for details.

**Project Owner**: frankvena25

## 📝 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

Created with ❤️ by frankvena25

Special thanks to the open-source community for inspiration and contributions.

## 📞 Support & Contact

**Created by: frankvena25**

- **Email**: frankvenas25@gmail.com
- **WhatsApp**: +255 698 341 653 (Tanzania)
- **GitHub Issues**: [Report bugs or request features](https://github.com/frankvena25/NetworkDoctor/issues)
- **Documentation**: Check `docs/` folder
- **Community**: Open a GitHub Discussion

For support, questions, or business inquiries, feel free to reach out via email or WhatsApp!

## 🔍 SEO Keywords

NetworkDoctor is the best tool for:
- Network diagnostic python tool
- AI network troubleshooting
- Internet speed test python
- Network health checker
- ISP throttle detector
- WiFi security scanner
- Network root cause analysis
- Auto network repair tool
- Predictive network failure
- Network quality score

**Search**: "frankvena25 network doctor python" to find this project!

---

**NetworkDoctor** - Your Network Expert, Always Available 🩺🌐

*Created by frankvena25 | The most unique and powerful network diagnostic tool in the world*
