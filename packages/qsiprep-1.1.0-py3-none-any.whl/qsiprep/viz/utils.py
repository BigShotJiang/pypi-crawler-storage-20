"""Visualization utilities."""

import numpy as np
from lxml import etree
from nilearn import image, plotting
from niworkflows.viz.utils import SVGNS, extract_svg, robust_set_limits, uuid4
from svgutils.transform import SVGFigure


def plot_denoise(
    lowb_nii,
    highb_nii,
    div_id,
    plot_params=None,
    highb_plot_params=None,
    order=('z', 'x', 'y'),
    cuts=None,
    estimate_brightness=False,
    label=None,
    lowb_contour=None,
    highb_contour=None,
    upper_label_suffix=': low-b',
    lower_label_suffix=': high-b',
    compress='auto',
    overlay=None,
    overlay_params=None,
):
    """
    Plot the foreground and background views.
    Default order is: axial, coronal, sagittal

    Updated version from sdcflows
    """
    plot_params = plot_params or {}
    highb_plot_params = highb_plot_params or {}

    # Use default MNI cuts if none defined
    if cuts is None:
        raise NotImplementedError

    # Do the low-b image first
    out_files = []
    if estimate_brightness:
        plot_params = robust_set_limits(
            lowb_nii.get_fdata(dtype='float32').reshape(-1), plot_params
        )
    # Plot each cut axis for low-b
    lowb_nii_data = lowb_nii.get_fdata(dtype='float32')
    if np.all(lowb_nii_data <= 1e-8):
        lowb_nii_cropped = lowb_nii
    else:
        lowb_nii_cropped = image.crop_img(lowb_nii)

    for i, mode in enumerate(list(order)):
        plot_params['display_mode'] = mode
        plot_params['cut_coords'] = cuts[mode]
        if i == 0:
            plot_params['title'] = label + upper_label_suffix
        else:
            plot_params['title'] = None

        # Generate nilearn figure
        display = plotting.plot_anat(lowb_nii_cropped, **plot_params)
        if lowb_contour is not None:
            display.add_contours(lowb_contour, linewidths=1)

        svg = extract_svg(display, compress=compress)
        display.close()

        # Find and replace the figure_1 id.
        xml_data = etree.fromstring(svg)  # noqa: S320
        find_text = etree.ETXPath(f"//{{{SVGNS}}}g[@id='figure_1']")
        find_text(xml_data)[0].set('id', f'{div_id}-{mode}-{uuid4()}')

        svg_fig = SVGFigure()
        svg_fig.root = xml_data
        out_files.append(svg_fig)

    # Plot each cut axis for high-b
    if estimate_brightness:
        highb_plot_params = robust_set_limits(
            highb_nii.get_fdata(dtype='float32').reshape(-1), highb_plot_params
        )

    highb_nii_data = highb_nii.get_fdata(dtype='float32')
    if np.all(highb_nii_data <= 1e-8):
        highb_nii_cropped = highb_nii
    else:
        highb_nii_cropped = image.crop_img(highb_nii)

    for i, mode in enumerate(list(order)):
        highb_plot_params['display_mode'] = mode
        highb_plot_params['cut_coords'] = cuts[mode]
        if i == 0:
            highb_plot_params['title'] = label + lower_label_suffix
        else:
            highb_plot_params['title'] = None

        # Generate nilearn figure
        display = plotting.plot_anat(highb_nii_cropped, **highb_plot_params)
        if highb_contour is not None:
            display.add_contours(highb_contour, linewidths=1)

        svg = extract_svg(display, compress=compress)
        display.close()

        # Find and replace the figure_1 id.
        xml_data = etree.fromstring(svg)  # noqa: S320
        find_text = etree.ETXPath(f"//{{{SVGNS}}}g[@id='figure_1']")
        find_text(xml_data)[0].set('id', f'{div_id}-{mode}-{uuid4()}')

        svg_fig = SVGFigure()
        svg_fig.root = xml_data
        out_files.append(svg_fig)

    return out_files


def plot_acpc(
    acpc_registered_img,
    div_id,
    plot_params=None,
    order=('z', 'x', 'y'),
    cuts=None,
    estimate_brightness=False,
    label=None,
    compress='auto',
):
    """
    Plot the results of an AC-PC transformation.
    """
    plot_params = plot_params or {}

    # Do the low-b image first
    out_files = []
    if estimate_brightness:
        plot_params = robust_set_limits(
            acpc_registered_img.get_fdata(dtype='float32').reshape(-1), plot_params
        )

    # Plot each cut axis for low-b
    acpc_registered_img_data = acpc_registered_img.get_fdata(dtype='float32')
    if np.all(acpc_registered_img_data <= 1e-8):
        acpc_registered_img_cropped = acpc_registered_img
    else:
        acpc_registered_img_cropped = image.crop_img(acpc_registered_img)

    for i, mode in enumerate(list(order)):
        plot_params['display_mode'] = mode
        plot_params['cut_coords'] = [-20.0, 0.0, 20.0]
        if i == 0:
            plot_params['title'] = label
        else:
            plot_params['title'] = None

        # Generate nilearn figure
        display = plotting.plot_anat(acpc_registered_img_cropped, **plot_params)
        for _coord, axis in display.axes.items():
            axis.ax.axvline(0, lw=1)
            axis.ax.axhline(0, lw=1)
        svg = extract_svg(display, compress=compress)
        display.close()

        # Find and replace the figure_1 id.
        xml_data = etree.fromstring(svg)  # noqa: S320
        find_text = etree.ETXPath(f"//{{{SVGNS}}}g[@id='figure_1']")
        find_text(xml_data)[0].set('id', f'{div_id}-{mode}-{uuid4()}')

        svg_fig = SVGFigure()
        svg_fig.root = xml_data
        out_files.append(svg_fig)

    return out_files
