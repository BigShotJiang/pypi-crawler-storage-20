# omega-models

Omega Models is a Python package that provides a collection of generated machine learning classifiers with a scikit-learn style API.

## Install

```bash
pip install omega-models
```

## Quick start

```python
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from omega_models import AdaptiveAbstractionForest

X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = AdaptiveAbstractionForest()
model.fit(X_train, y_train)
print("accuracy:", model.score(X_test, y_test))
```

## More examples

```python
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from omega_models import DirectionalForest

X, y = load_wine(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

model = DirectionalForest(n_estimators=200)
model.fit(X_train, y_train)
preds = model.predict(X_test)
print(preds[:10])
```

```python
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from omega_models import ResidualMLPEnsemble

X, y = load_digits(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=7)

model = ResidualMLPEnsemble()
model.fit(X_train, y_train)
print("score:", model.score(X_test, y_test))
```

## Available models

The public API re-exports models for convenient imports:

- `AdaptiveAbstractionForest`
- `AdaptiveAggressivenessClassifier`
- `AdaptiveDensityWeightedClassifier`
- `AdaptiveResidualLearningClassifier`
- `DimAwareForest`
- `DirectionalForest`
- `ResidualMLPEnsemble`

## Requirements

- Python 3.6+
- NumPy, SciPy, scikit-learn

## License

MIT License. See `LICENSE`.
