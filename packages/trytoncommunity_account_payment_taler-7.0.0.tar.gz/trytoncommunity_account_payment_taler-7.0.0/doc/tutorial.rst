.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

********
Tutorial
********

This section will show several practical uses
of the *Account Payment Taler* module.
Before trying these use cases, you need

* for the merchant:

  - ``account_payment_taler`` installed in you Tryton system,
  - an account at a bank supporting Taler,
  - a |TMB| instance,

* for the "customer":

  - a Taler Wallet, connected to
  - an account at a bank supporting Taler.

For this tutorial we use the Taler demo installation,
which provides a nice playground.
It also eases some steps.

.. important::
   The Taler demo installation uses *KUDOS* as currency.
   Anyhow, Tryton does not support currency codes with five characters.
   This is why you need to use special settings in Tryton (see below).

.. toctree::
   :maxdepth: 2

   tutorial-setup
   tutorial-payment
   tutorial-refund


.. include:: _common_definitions.txt

