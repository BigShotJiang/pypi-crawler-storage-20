.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

*****
Setup
*****

For being able to receipt payments using Taler_, one needs to
- create an account at some |TMB| instance,
- configure a *Taler Merchant Account* in Tryton, and
- configure at least one *Payment Journal* with payment method "Taler".


Terms:

:instance account:
   The account of your "instance" at the |TMB| of your choice.



.. _setup Instance Account:

Creating an account at some |TMB| instance
==========================================

.. hint:: If you just want to play with the |TMB| integration in Tryton,
          it's perfectly fine to create
          a demo bank account at the `demo bank`__
          and a backend account at the `demo backend`__.
          Please refer to the :doc:`tutorial` for details.

.. __: https://bank.demo.taler.net/
.. __: https://backend.demo.taler.net/

First of all you need a bank supporting Taler.
Given this you either need to setup a |TMB| yourself
(see the `Merchant Backend Operator Manual`_ for how to)
or find some service provider for a *|TMB| as a Service*.

In the |TMB| of your choice register an "instance" and
connect it with the bank account.
The later is required to actually receive the money.
See the `Merchant Backend Operator Manual`_ for details.


.. _Merchant Backend Operator Manual:
   https://docs.taler.net/taler-merchant-manual.html


.. _setup Taler Merchant Account:

Adding a Taler Merchant Account
===============================

You can create a new *Taler Merchant Account* from the
[:menuselection:`Financial --> Configuration --> Payments
--> Taler Merchant Accounts`]
main menu item.

* In :guilabel:`Merchant URL` enter the "instance URL"
  of your instance account and
  the respective :guilabel:`Access Token`.

* Test the connection

* Verify the pay, refund and write transfer delay.

* Save the record.


.. note::
   The |TMB| is not restricted to a single currency,
   thus the *Taler Merchant Account* isn't, too.


.. _setup Webhook:

Setting up a Webhook at the |TMB| instance
------------------------------------------

If you need to get informed promptly about the customer having paid,
set to a webhook:

In your |TMB| instance create two webhook

1. To get notified about payments received
   configure a webhook with these parameters:

   :Event: "Payment"
   :Method: "POST"
   :URL: *the ‘Webhook Endpoint’ from the ‘Taler Merchant Account’*
   :Http header: *leave empty*
   :Http body: ``{"event": "payment", "order_id": "{{order_id}}"}``

2. To get notified about payments received
   configure a webhook with these parameters:

   :Event: "Payment"
   :Method: "POST"
   :URL: *the ‘Webhook Endpoint’ from the ‘Taler Merchant Account’*
   :Http header: *leave empty*
   :Http body: ``{"event": "payment", "order_id": "{{order_id}}"}``


Fir more information please refer to the `Setting up a webhook`__
section in the Taler  Merchant Backend Operator Manual.

.. __: https://docs.taler.net/taler-merchant-manual.html
       #setting-up-a-webhook


Adding a Payment Journal for the Taler Merchant Account
=======================================================

Create a new *Payment Journal* with method "Taler" from the
[:menuselection:`Financial --> Configuration --> Payments
--> Payment Journals`]
main menu item

:Name: *Choose a meaningful name*
:Company: *should match the company you configured in your |TMB| instance*
:Currency: *choose a currency supported by some bank account
           in your |TMB| instance*
:Process method: "Taler"
:Taler Merchant Account: *select one*

.. tip:: Include the name of the currency in the name of the journal.



.. include:: _common_definitions.txt
