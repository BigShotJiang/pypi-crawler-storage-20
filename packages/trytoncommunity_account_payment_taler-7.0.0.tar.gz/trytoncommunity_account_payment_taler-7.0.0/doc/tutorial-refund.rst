.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

*******************
Refunding a Payment
*******************

This section shows how to
partially or fully refund a Taler payment
using the *Account Payment Taler* module.


.. _create_refund:

Creating a Taler Refund
=======================

To create a refund for a Taler payment
there are two way:

1. Create the refund from paid Taler payment.

2. Create the refund from scratch.

Create the Refund from a paid Taler Payment
--------------------------------------------

1. Got to the
   [:menuselection:`Financial --> Payments --> Receivable Payments`]
   main menu item
   and in there to the :guilabel:`All` tab.

2. Open the to payment you want to refund. Only *Succeeded* payments
   where the refund deadline is not yet reached can be refund.
   (Unfortunately the GUI does not show the later.)

   If you just followed the :ref:`tutorial_paying` part of the tutorial
   there might still have a refundable payment.
   Otherwise please refer to :ref:`create_receivable_payment`.

3. In the payment's record view got to the :guilabel:`Refunds` tab
   and in the :guilabel:`Refunds` list,
   create a now entry (plus-sign in the tool bar of the list).

4. Fill the form showing up

   * Enter an :guilabel:`ammount`.
   * Select a :guilabel:`Reason`.

   and confirm the form.

   Of course, the amount must not exceed the payments total amount.

   After confirming the dialog, the refund is listed
   in the :guilabel:`Refunds` list.

5. Save the payment record (floppy disk sign in the tool bar or :kbd:`Ctrl+S`)

6. In the :guilabel:`Refunds` list, :guilabel:`Approve`
   and :guilabel:`Process` the refund.


Great!
You now have a refund for the payment in your |TMB| instance.
If you want, you can check this now in the instance's web UI.

Now let the "customer" take the refund:

7. In Tryton, the payment is still visible.
   Switch to the :guilabel:`Description` tab
   and open the payment's :guilabel:`Status URL`
   by clicking on the symbol at the right end of the input field.

   Again, the status URL is served by the |TMB| instance
   and show a QR code and link – this time accepting the payment.

8. Use your Taler Wallet to obtain the refund.

9. In Tryton the payment's record is still show.
   Go there, switch to the :guilabel:`Refunds tab`
   and click the :guilabel:`Pull TalerRefunds` button near the bottom.
   This will fetch the status of the refund from the |TMB| instance.

   This should change the refund's :guilabel:`State` to ``Succeeded``.

Congratulations!
You processed you first Taler refund.


A Failed Refund
===============

Now let's see what happens if a customer does not obtain the refund
within the ``refund deadline``.
For this you will create another payment
with both a short pay deadline and a short refund deadline,
settle this payment and refund it,
*not obtain* the refund as customer,
wait until the refund deadline passed
and check the refunds's status.

1. Create another payment to be paid with Taler,
   but do no yet submit it.

2. Before submitting the payment,
   set the :guilabel:`Pay Deadline` to about only two minutes from now,
   and the :guilabel:`Refund Deadline` to about only four minutes from now.

   If you already submitted the payment, simply :guilabel:`Draft` it.
   If you already processes the payment, simply create another one.

3. After :guilabel:`Process`-ing the payment in Tryton
   settle the payment in your Wallet.

4. Now refund the payment in Tryton as described above.
   Anyhow, do not obtain the refund in your Wallet.

3. If you want, you can check this payment/order
   in your |TMB| instance's web UI.
   If the payment does not show up there,
   try reloading the page in the browser.

4. When the refund deadline has passed,
   click the :guilabel:`Pull Taler Refunds` button near the bottom
   of the :guilabel:`Refund`.
   Again, this will fetch the status of the refund from the |TMB| instance.

   Since the refund was not obtained,
   the :guilabel:`State` is expected change to ``Failed``.
   Anyhow, there will be no error message,
   since *payment* succeeded.


Recovering from a Failed Refund
===============================

A refund fails if the customer does not obtain the refund in time.
In this case the |TMB| does not offer any way to recover,
so you need to find a different way – outside Taler – to refund the payment.

.. include:: _common_definitions.txt
