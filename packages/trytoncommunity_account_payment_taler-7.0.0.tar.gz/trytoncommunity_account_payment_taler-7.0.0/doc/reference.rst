.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

*************
API Reference
*************

This section describes the models added or changed by the
*Account Payment Taler* module.

Taler Merchant Account
======================

The *Taler Merchant Account* stores the information like the
*Taler Merchant Backend URL*, the access token, the default pay delay, etc.
The Taler Merchant Account form has a button for testing the connection
(URL and access token).
The connection-test also queries the delays configured in the |TMB|
and sets these as defaults for the delay in the *Taler Merchant Account*
if no delays are configured yet.

The *Taler Merchant Account*'s webhook endpoint is the URL used by the |TMB|'s webhooks_.
If a webhook is setup, the |TMB| payments not update existing payments.
See :doc:`configuration` for details.

.. _webhooks: https://docs.taler.net/


Journal
=======

The journal has a new field to store the Taler account
if the process method is set to "taler".


Payment
=======

The Payment has gained additional fields specific to Taler payments:
- the order ID, used as a payment id by Tryton,
- Fulfillment Url and message,
- optional deadlines for payment, refund and wire-transfer.

If some of the deadlines are not set,
they are calculated when the payment is processed
based on the respective delay configured in the *Taler Merchant Account*.

The Tryton Payment also gained a checkout button which opens a HTML page
showing the Taler payment URL
(more precisely this is the order status URL)
as QR-code and link.
The customer can use this URL for settling the payment
using their Taler Wallet.

If webhooks are set up (see above),
the |TMB| will inform Tryton as soon as the customer paid
and Tryton will update the payment state.
Alternatively one can query the |TMB| using the "Taler pull" button of either
the payment or the payment group.

In case of an error, a new field displays the error message from the |TMB|.

A scheduled tasks run every 15 minutes
to push every "processing" payment.
Another scheduled task also runs every 15 minutes to pull updates for each
processing payment until they have succeeded or failed.

.. _payment method: https://developers.braintreepayments.com/guides/payment-methods


Refund
******

The (Taler) Refund is a new model for refunding Payments
in whole or in part.
For each refund one must specify the payment and the amount
and can select a reason.

The Refund also has a checkout button which opens a HTML page
showing the Taler refund URL
(more precisely this is the order status URL)
as QR-code and link.
The customer can use this URL for accepting the refund
using their Taler Wallet.

If webhooks are set up (see above),
the |TMB| will inform Tryton as soon as the customer accepted the refund
and Tryton will update the refund state.
Alternatively one can query the |TMB| using the "Taler pull" button of
the refund.

In case of an error, a field displays the error message from the |TMB|.

A scheduled tasks run every 15 minutes
to push every "processing" refund.
Another scheduled task also runs every 15 minutes to pull updates for each
processing refund until they have succeeded or failed.


.. For what to write into this file please read
   https://www.tryton.org/develop/guidelines/documentation#reference.rst
   and remove this comment afterwards.

.. include:: _common_definitions.txt
