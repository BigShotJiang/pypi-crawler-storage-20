.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

.. include:: ../README.rst

Read the introduction section at
https://docs.taler.net/taler-merchant-manual.html


.. toctree::
   :maxdepth: 2

   setup
   usage
   configuration
   design
   faq
   tutorial
   reference
   releases
