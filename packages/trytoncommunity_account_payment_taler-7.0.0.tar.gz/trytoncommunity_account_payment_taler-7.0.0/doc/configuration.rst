.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

*************
Configuration
*************

The *Account Payment Taler* module uses the section
``account_payment_taler`` in the `trytond configuration file`__
to retrieve some parameters:

**As of now there are no configuration parameters.**

.. __: https://docs.tryton.org/latest/server/topics/configuration.html


.. include:: _common_definitions.txt
