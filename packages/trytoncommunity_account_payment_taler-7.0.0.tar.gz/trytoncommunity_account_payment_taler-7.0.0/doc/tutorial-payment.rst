.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

.. _tutorial_paying:

*****************
Paying with Taler
*****************

This section shows how to
use the *Account Payment Taler* module to
create a payment to be paid using Taler.


.. _create_receivable_payment:

Creating a Taler Receivable Payment
===================================

To create a receivable payment which *might* be paid using Taler,
proceed as follows:

1. Got to the
   [:menuselection:`Financial --> Payments --> Receivable Payments`]
   main menu item
   and add a new record (plus-sign in the tool bar or :kbd:`Ctrl+R`).

2. As :guilabel:`Journal` select the ``Taler Payments (EUR)``
   (resp. the one with "EUR" replaces by your currency name or code).

3. As :guilabel:`Party` select any (customer) party or create a new one.

   No configuration is required for this party.

4. Leave :guilabel:`Line` empty,
   since you creating a payment not linked to any line.

5. Enter some small :guilabel:`Amount`.

   .. hint:: We recommend to use a few cents only,
             since you don't have much demo money in your wallet.

6. As :guilabel:`Description` enter some text.

7. Leave the :guilabel:`Fulfillment URL` empty,
   we are not using it in this tutorial.

    .. important::
       If the :guilabel:`Fulfillment URL` is used,
       it *must be unique* all over the lifetime of your |TMB| instance.
       Otherwise the customer's Wallet will tread the order as already paid.

       Thus it's a good idea to put the Taler Order ID into here
       even if it just a dummy,
       like ``https://tryton.community/?dummy=${ORDER_ID}``,

8. As :guilabel:`Fulfillment Message` enter some text.

9. In the :guilabel:`Deadlines` group, leave all entries empty.

   This will pull the default deadline delays from
   from the respective *Taler Merchant Account*
   when processing the payment
   (thus when pushing it from Tryton to the |TMB| instance).

10. There is no need to fill anything in the :guilabel:`Other Info` tab.

11. :guilabel:`Submit` and :guilabel:`Process` the payment.

    After you have been asked
    whether you actually want to process the payment,
    a new tab :guilabel:`Payment Groups` will be opened
    and list one group with Journal ``Taler Payments (…)``
    and Kind ``Receivable``.

    If you open this payment group, you will find one ``processing`` payment.

    .. tip:: If there no payment ``processing``,
             but ``failed``,
             something went wrong with processing the payment.
             For now, just continue this tutorial and
             see the tip in the next step how to handle this failure.

    You can also see a :guilabel:`Taler pull` button.
    This button can be used for update the status
    for all payments in the group.
    Since in our case the group contains a single order,
    it is not of much use.
    So just close the :guilabel:`Payment Groups` tab.

12. Switch to the :guilabel:`Receivable Payments` tab
    if it is not already shown.
    This is expected to show the payment you just created.

    Let's see how the display has changed:

    * There is a new :guilabel:`Taler` group
      which shows the :guilabel:`Order ID`.

    * In the :guilabel:`Taler Details` group, there are

      - The :guilabel:`Status URL` received from the |TMB|.

      - If there is an :guilabel:`Error message`,
        something went wrong with processing the payment.

        .. tip:: If there was an error, you should try to solve it
                 prior to continue with the tutorial.

    * In the :guilabel:`Deadlines` group, the deadlines are filled.

      .. note:: Due to a restriction of the |TMB| API,
                these are currently set only,
                if you set them when creating the payment,
                or if the default deadline delays are configured
                in the respective *Taler Merchant Account*.

Great!
You now have a payment (resp. "order", how Taler calls this)
in your |TMB| instance.
If you want, you can check this now in the instance's web UI.

Now let the "customer" pay:

13. In Tryton, the payment you just created is expected to be visible.
    Otherwise, open the :guilabel:`Receivable Payments`
    and in the :guilabel:`Processing` double-click the payment.

    Now open the payment's :guilabel:`Status URL`
    by clicking on the symbol at the right end of the input field.
    The status URL is served by the |TMB| instance
    and show a QR code and link for paying.

14. Use the demo money in your Taler Wallet to pay.

15. In Tryton the payment's record is still show.
    Go there and click the :guilabel:`Taler pull` button near the bottom.
    This will fetch the status of the payment from the |TMB| instance.

    This should change the :guilabel:`State` to ``Succeeded``.
    Also the a new tab :guilabel:`Refunds` shows up.
    We will look at this in the
    :doc:`refunds part of the tutorial <tutorial-refund>`.

Congratulations!
You processed you first Taler payment.


A Failed Payment
================

Now let's see what happens if a customer does not pay
within the ``pay deadline``.
For this you will create another payment with a short pay deadline,
wait until this deadline passed
and check the payment's status.

1. Create another payment to be paid with Taler,
   but do no yet submit it.
   You already did this a few minutes ago.
   In case you feel unsure,
   please refer to :ref:`create_receivable_payment`.

2. Before submitting the payment,
   set the :guilabel:`Pay Deadline` to about only two minutes from now.

   If you already submitted the payment, simply :guilabel:`Draft` it.
   If you already processes the payment, simply create another one.

3. If you want, you can check this payment/order
   in your |TMB| instance's web UI.
   If the payment does not show up there,
   try reloading the page in the browser.

4. When the pay deadline has passed,
   click the :guilabel:`Taler pull` button near the bottom.
   Again, this will fetch the status of the payment from the |TMB| instance.

   Since the payment was not paid,
   the :guilabel:`State` is expected change to ``Failed``.
   The error message will explain the reasons:
   "The proposal is not known to the backend" -
   which means the |TMB| already garbage collected the payment/order.


Recovering from a Failed Payment
================================

In the example above the payment failed,
since the customer did not pay.
Anyhow, there are more reasons a payment might fail,
esp. network errors.

In such cases you might want to retry the payment.
For this you can duplicate the failed payment,
set new deadlines (if you want) and process the payment again.

Let's try it with the failed payment form the last section:

1. If the failed payment from the last section is not still shown,
   open it: Switch to the :guilabel:`Receivable Payments` tab
   and in there to the :guilabel:`All` tab.
   Then double-click the failed payment.

2. Duplicate the record (:kbd:`Ctrl+D` or via the menu).

   You will see the info "Working on the duplicated record(s)"
   and the fields are editable again.
   Also the deadlines have been unset.

3. If desired, set new deadlines.
   Or leave empty to pull the default deadline delays from
   from the respective *Taler Merchant Account*.

4. :guilabel:`Submit` and :guilabel:`Process` the payment.

Done. Now you just need to pass the :guilabel:`Status URL` to your customer.

.. note:: As of now, the *Account Payment Taler* module
          doesn't provide means to actually send the URL.
          Anyhow you can use the :guilabel:`Taler checkout`
          to show a checkout page in your browser.


.. include:: _common_definitions.txt
