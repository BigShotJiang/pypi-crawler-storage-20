.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

******************************
Creating and Paying an Invoice
******************************

This section will show several practical uses
of the *Account Payment Taler* module.
Before trying these use cases, you need

[:menuselection:`Financial --> Invoices --> Customer Invoice`] and set it up:

Create an invoice as usual, but before posting:


.. include:: _common_definitions.txt

