.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

*****
Usage
*****

Creating a Taler receivable Payment
===================================

For creating a Taler receivable Payment proceed as follows:

* Create a new receivable payment
  [:menuselection:`Financial --> Payments --> Receivable Payments`]
  main menu item.

* As :guilabel:`Journal` select a Payment Journal with method "Taler".
  Additional Tale-related fields will show up.

* Select a :guilabel:`Party` and enter the :guilabel:`Amount` and optionally set the date.

* If the payment related to some Account Move Line
  select it in :guilabel:`Line`.

* Now fill the Taler related fields:

  - Either :guilabel:`Fulfillment URL` or :guilabel:`Fulfillment Message` is required.

    .. important::
       If the :guilabel:`Fulfillment URL` is used,
       it *must be unique* all over the lifetime of your |TMB| instance.
       Otherwise the customer's Wallet will tread the order as already paid.

       Thus it's a good idea to put the Taler Order ID into here
       even if it just a dummy,
       like ``https://tryton.community/?dummy=${ORDER_ID}``,

  - The :guilabel:`Pay Deadline`, :guilabel:`Refund Deadline`
    and :guilabel:`Wire Transfer Deadline`
    - if not given -
    will be calculated when pushing the payment (resp. the order) to the |TMB|.
    The calculation will be based on the respective *default delay*
    configured in the |TMB| Account references by the *Journal* selected.

    .. important::
       These deadlines are absolute time and date.
       When setting any of these deadlines here,
       make sure these are generous and
       take into account the time it takes you to approve and submit the
       payment to the |TMB|.

* *Submit*, *Approve* and *Process* the payment.

  The later will push the payment (resp. the order) to the |TMB|.
  If no deadlines have been given, these will be calculated now.

  If the payment can not be pushed to the |TMB|,
  the payment will :guilabel:`fail` and display the error message.


.. note::
   A scheduled job is running every 15 minutes to push
   *approved* payments to the |TMB|.
   So, if you don't in need of create the payments promptly,
   you can rely on this.


Update the status of the Payment
================================

There are different ways to update the payment's status from the |TMB|:

1. via the payment
2. via the payment group
3. via the webhook
4. via the scheduled job

In any case the payment will :guilabel:`succeed` when the customer paid.
For a successful payment, `refunds can be granted <granting refunds>`_.

The payment will :guilabel:`fail`
if the customer did not pay within the *Pay Deadline*.


Updating the status via the Payment
-----------------------------------

* List the receivable payments using
  [:menuselection:`Financial --> Payments --> Receivable Payments`]
  main menu item.

* Select the :guilabel:`Processing` payments
  by selecting the respective tab
  and select the payment you want to update.

* Click the :guilabel:`Taler pull` button to update the payment status.


Updating the status via the Payment Group
-----------------------------------------

* List the receivable payments using
  [:menuselection:`Financial --> Payments --> Payment Groups`]
  main menu item.

* Select the :guilabel:`Pending` payment groups
  by selecting the respective tab
  and select the payment group you want to update.

* Click the :guilabel:`Taler pull` button to update the status
  of each payment in this group.

* Reload the tab (:kbd:`Ctrl+R`) to udate the status summary
  (the text beside the :guilabel:`Taler pull` button).

.. hint::
   You can click on the status summary to inspect the payments
   in this payment.


Updating the status via the webhook
-----------------------------------

If a :guilabel:`Webhook Endpoint` is configured in
the *Taler Merchant Account* in Tryton
(see :ref:`setup Taler Merchant Account`)
and
a matching webhook is configured in the instance account in the |TMB|
(see :ref:`setup Webhook`),
the payment status is updated as soon as the customer pays.


Updating the status via the scheduled job
-----------------------------------------

A scheduled job is running every 15 minutes to fetch the status
of *pending* payments from the |TMB|.
So, if you don't need prompt status updates, you can rely on this.


.. _granting refunds:

Granting Refunds
================

Payments can be refunded in whole or in part.


Refunding via the Payment
--------------------------

* List the receivable payments using
  [:menuselection:`Financial --> Payments --> Receivable Payments`]
  main menu item.

* Select :guilabel:`All` payments by selecting the respective tab
  and select the payment you want to refund.

* Select the :guilabel:`Refunds` tab and in the :guilabel:`Refunds` area
  add a new refund (click :guilabel:`+`)

* In the form fill the :guilabel:`Amount` and
  optionally the :guilabel:`Reason`, :guilabel:`Submitted by` and
  :guilabel:`Approved by`.
  Submit the form by clicking :guilabel:`Add`.

* Save the Payment form (:kbd:`Ctrl+S`)
  to store the new refund for the payment.

* *Submit*, *Approve* and *Process* the Refund.


Refunding via the Taler Refund
------------------------------

You can also create and process a new refund using the
[:menuselection:`Financial --> Payments --> Taler Refunds`]
main menu item.

* Create a new Refund
  (click :guilabel:`+` in the toolbar
  or select :guilabel:`New` from the tab menu.

* In the form fill the :guilabel:`Payment` :guilabel:`Amount` and
  optionally the :guilabel:`Reason`, :guilabel:`Submitted by` and
  :guilabel:`Approved by`.
  Submit the form by clicking :guilabel:`Add`.

* Save the Payment form (:kbd:`Ctrl+S`)
  to store the new refund for the payment.

* *Submit*, *Approve* and *Process* the Refund.



Update the status of the Refund
================================

There are different ways to update the refund's status from the |TMB|:

1. via the payment
2. via the refund
3. via the webhook
4. via the scheduled job

In any case the refund will :guilabel:`succeed` when the customer paid.

The refund will :guilabel:`fail`
if the customer did not accept the refund within the *Refund Deadline*
of the respective payment.

.. note:: When updating the status of a refund,
          this will also update the status of all other refunds
          of the respective payment.


Updating the status via the Payment
-----------------------------------

* List the receivable refunds using
  [:menuselection:`Financial --> Payments --> Receivable Payments`]
  main menu item.

* Select the :guilabel:`Succeeded` payments groups
  by selecting the respective tab
  and open the payment you want to update the refund status for.

* Either

  - select :guilabel:`Pull Taler Refunds`
    from the :guilabel:`Action` entry
    in the toolbar,

  - or select the :guilabel:`Refunds` tab
    and click the :guilabel:`Pull Taler Refunds` button.


Updating the status via the Refund
-----------------------------------

* List the receivable refunds using
  [:menuselection:`Financial --> Payments --> Taler Refunds`]
  main menu item.

* Select the :guilabel:`Processing` refunds
  by selecting the respective tab
  and select the refund you want to update.

* Click the :guilabel:`Taler pull` button to update the refund status.


Updating the status via the webhook
-----------------------------------

If a :guilabel:`Webhook Endpoint` is configured in
the *Taler Merchant Account* in Tryton
(see :ref:`setup Taler Merchant Account`)
and
a matching webhook for refunds is configured
in the instance account in the |TMB|
(see :ref:`setup Webhook`),
the refund status is updated as soon as the customer accepts the refund.


Updating the status via the scheduled job
-----------------------------------------

A scheduled job is running every 15 minutes to fetch the status
of *pending* refunds from the |TMB|.
So, if you don't need prompt status updates, you can rely on this.


.. include:: _common_definitions.txt
