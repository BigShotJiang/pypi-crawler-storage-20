.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

******
Design
******

When creating a receiving payment to be settled using Taler,
this module sends a request to, and receives a response from,
the |TMB|.

Next, the module confirms the transaction again and redirects the
customer to his own wallet to confirm the transaction.

The module also provides the possibility for the administrator
to send the custumer a refund.

For refunds, the module sends a refund request to the |TMB|
and receives a refund-URI.  This URI is forwarded to the
customer via an e-mail to confirm the refund.

The status of payments and refunds can updated from the |TMB|
via webhooks, scheduled tasks or manually.


.. include:: _common_definitions.txt
