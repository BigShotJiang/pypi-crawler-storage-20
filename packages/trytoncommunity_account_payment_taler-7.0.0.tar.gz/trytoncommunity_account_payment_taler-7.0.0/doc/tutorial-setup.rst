.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

Setting up
**********

Setting up Taler as a Merchant
==============================

As a "merchant", to pay with Taler,
you need an account at a bank supporting Taler,
a |TMB| instance and connect these two.


Creating a Demo Bank Account
----------------------------

1. Register an account at https://bank.demo.taler.net/.
   Of course, note down the username and password (in a password-safe).
   This will also give you 100 KUDOS for starting.

2. In the top right corner click on the profile icon (the person)
   to get to the account details.

3. Scroll down to the :guilabel:`Merchant integration` section and
   keep the browser tab open (for now).


Creating a |TMB| Instance
----------------------------

1. Register an account at https://backend.demo.taler.net/.
   Of course, note down the username ("instance name")
   and password (in a password-safe).

   Depending on the exact configuration of that demo instance,
   you might need to click :guilabel:`Send me a message`
   to actually get the verification code sent to you.

2. After entering the verification code you should be show the
   :guilabel:`Account details` page.
   Enter the information from the demo bank account's
   :guilabel:`Merchant integration` section here
   and click :guilabel:`Confirm`.

   .. hint:: If you are not shown the *Account details* page,
             go to :guilabel:`Bank account` in the menu on the left
             and then in the top right corner click on the plus sign.


Setting up Taler as a "Customer"
================================

As a "customer", to pay with Taler, you need a Taler Wallet
and connect it to an account at a bank supporting Taler.
Anyhow, when using the demo instance,
the "customer" can just installs a Taler Wallet
and requests some "demo money".

1. Choose whether you want to install the Wallet into your
   Desktop browser or on you mobile device.

2. Go to https://wallet.taler.net, download the respective version of the
   Wallet and install it.

3. After opening,
   the Wallet should offer you to :guilabel:`Get demo money`.
   Click this option.

   After some seconds, the Wallet should show a balance of some KUDOS.


Setting up Tryton for Taler
===========================

Installing the *Account Payment Taler* module
---------------------------------------------

For completing this tutorial, these modules are required:

- ``trytoncommunity_account_payment_taler``: For using Taler, of course.
- ``trytond_account_invoice``: To test the invoice-centric workflow


How these are to be installed,
depends on how you are deploying your Tryton installation.
Assuming this you are using a *Virtual Environment*, it is as easy as running:

.. code:: shell

   $ /path/to/venv/bin/python -m pip install \
       trytond_account_invoice \
       trytoncommunity_account_payment_taler

If you are using a Docker/Container image,
add a line like the above to your Dockerfile/Containerfile.


Activating the *Account Payment Taler* module
---------------------------------------------

Restart you Tryton instance,
log into Tryton (either using the desktop client or the web interface)
using an administrative account (typically ``admin``), go to
[:menuselection:`Administration --> Modules --> Modules`]
and active the module.


Completing your Tryton Installation
------------------------------------

Still logged in as administrative user,
ensure you have configured
- a currency ([:menuselection:`Currencies --> Currencies`])
- a company ([:menuselection:`Companies --> Companies`])
- a "customer" party ([:menuselection:`Parties --> Parties`]).


Creating a *Taler Merchant Account*
------------------------------------

Still logged in as administrative user,
got to the
[:menuselection:`Financial --> Configuration --> Payments
--> Taler Merchant Accounts`] and set it up:

1. As :guilabel:`Name` enter ``Taler Merchant``.

2. As :guilabel:`Merchant URL` enter
   ``https://backend.demo.taler.net/instances/MY—INSTANCE`` and
   replace ``MY—INSTANCE`` by the instance name
   you noted obove.

3. As :guilabel:`Access Token` enter the password of the |TMB| instance
   you noted obove.

4. Click :guilabel:`Test connection`.
   If the connection fails,
   check the :guilabel:`Merchant URL` and :guilabel:`Access Token`.

   .. hint:: To view the access token value,
             check the box at the right end of the input field.

5. Set some default delays reasonable for this tutorial:

   * :guilabel:`Default Pay Delay`: ``00:10`` (10 Minutes)
   * :guilabel:`Default Refund Delay`:  ``00:20`` (20 Minutes)
   * :guilabel:`Default Write Transfer Delay`: ``00:25`` (25 Minutes)

   This will give you enough time to have a look at the |TMB| instance
   while working through this tutorial.

6. In the :guilabel:`For testing only` section
   as :guilabel:`Enforce Currency Code` enter ``KUDOS``

7. Save the record.


Setup Webhooks in the |TMB| Instance
------------------------------------

1. In Tryton, in the :guilabel:`Taler Merchant Account` tab,
   copy the :guilabel:`Webhook Endpoint` URL.

2. Switch to your |TMB| instance in the browser.

3. In the menu on the left choose :guilabel:`webhooks`
   and then in the top right corner click on the plus sign.

4. Fill the form with these values:

   :Event: ``tryton-payment``
   :Method: ``POST``
   :URL: *paste the ‘Webhook Endpoint’ URL here*
   :Http header: *leave empty*
   :Http body: ``{"event": "payment", "order_id": "{{order_id}}"}``

   Click :guilabel:`Confirm` when done.

5. Create another webhook:
   Again in the top right corner click on the plus sign,
   then fill the form with these values:

   :Event: ``tryton-refund``
   :Method: ``POST``
   :URL: *paste the ‘Webhook Endpoint’ URL here*
   :Http header: *leave empty*
   :Http body: ``{"event": "payment", "order_id": "{{order_id}}"}``

   Click :guilabel:`Confirm` when done.

6. Switch back to the Tryton UI.


Creating a *Payment Journal* for Taler
---------------------------------------

Tryton collects all payments in *Payment Journals*,
which bring together the company, the currency, the payment method
and further details depending on the payment method.

Still logged in as administrative user,
got to the
[:menuselection:`Financial --> Configuration --> Payments
--> Payment Journals`]
main menu item
and add a new record (plus-sign in the tool bar or :kbd:`Ctrl+R`).

1. As :guilabel:`Name` enter ``Taler Payments (EUR)``
   (replace "EUR" by your currency name or code).

2. As :guilabel:`Company` select the your company

3. As :guilabel:`Currency`

   .. important::
      For production use,

      choose a currency supported by some bank account
      in your |TMB| instance.

4. As :guilabel:`Process method` select ``Taler``.

5. In the :guilabel:`Taler` section
   as :guilabel:`Account` select the one created above (``Taler Merchant``).

6. Save the record.

Congratulation! You have set up Tryton for Taler.


.. include:: _common_definitions.txt
