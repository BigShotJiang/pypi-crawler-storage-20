.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later

**************************
Frequently Asked Questions
**************************

:Q: **Do I have to have a GNU Taler account to test the module?**
:A: Yes, you need to have a "bank" account to withdraw cash.
    You can setup one easily at https://bank.demo.taler.net/.

..

:Q: **Does the customer need to have the GNU Taler Wallet installed
    to pay with GNU Taler?**
:A: Yes, the customer needs the GNU Taler Wallet.
    The customer can get a wallet here: https://wallet.taler.net/

..

:Q: **Can I use this module with my Tryton-backed web-shop?**
:A: Yes.
    Anyhow depending on the implementation of the web-shop,
    some adjustments might be required in integrate
    Taler as an additional payment method.
    Please get in touch with the developers of your web-shop
    and point them to :doc:`integration`.

..

:Q: **Can I use this module to have Taler payment QR-codes
    in my PDF invoices?**
:A: Yes. Please refer to :doc:`integration` and
    to the sample invoice accompanying this module.

..

:Q: **Can I use this module to have Taler payment at my POS,
    including QR-codes for payment?**
:A: Yes.
    Depending on whether you are using the SAO-based web-ui,
    the Tryton desktop client or your custom POS solution,

..


.. include:: _common_definitions.txt
