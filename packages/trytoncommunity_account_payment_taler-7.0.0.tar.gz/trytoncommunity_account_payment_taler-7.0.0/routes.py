# This file is part of trytoncommunity-account-payment-taler.
# Licensed under the GNU General Public License v3 or later (GPLv3+).
# The COPYRIGHT file at the top level of this repository contains the
# full copyright notices and license terms.
# SPDX-License-Identifier: GPL-3.0-or-later

import base64
import json
import logging

import trytond.tools.qrcode
from trytond.protocols.wrappers import (
    HTTPStatus, Response, abort, with_pool, with_transaction)
from trytond.wsgi import app

logger = logging.getLogger(__name__)


@app.route(
    '/<database_name>/account_payment_taler/checkout/<order_id>',
    methods=['GET', 'POST'])
@with_pool
@with_transaction(context={'_skip_warnings': True})
def checkout(request, pool, order_id):
    """Return a HTML page showing the QR code for payment as well as an a
    button to pay using the wallet in browser.
    If method is POST, close the window.
    """
    Payment = pool.get('account.payment')
    try:
        order, = Payment.search([
                ('taler_order_id', '=', order_id),
                ])
    except ValueError:
        abort(HTTPStatus.FORBIDDEN)
    if request.method == 'POST':
        return Response(
            '<body onload="window.close()">',
            HTTPStatus.OK, mimetype='text/html')

    payment_uri = order.taler_payment_uri
    if not payment_uri:
        # order paid or claimed or simply outdated
        status_code = HTTPStatus.GONE
        report_name = 'account.payment.taler.checkout-gone'
        data = {}
    else:
        status_code = HTTPStatus.OK
        report_name = 'account.payment.taler.checkout'
        qr_code = trytond.tools.qrcode.generate_png(payment_uri).getvalue()
        # TODO language
        data = {
            'order_id': order_id,
            'payment_uri': payment_uri,
            'payment_uri_qrcode_base64':
            base64.b64encode(qr_code).decode('ascii'),
        }
    Report = pool.get(report_name, type='report')
    ext, content, _, _ = Report.execute([order.id], data)
    assert ext == 'html'
    return Response(content, status_code, mimetype='text/html')


@app.route(
    '/<database_name>/account_payment_taler/webhook/<account>',
    methods={'POST'})
@with_pool
@with_transaction(context={'_skip_warnings': True})
def webhooks_endpoint(request, pool, account):
    Account = pool.get('account.payment.taler.account')
    try:
        account, = Account.search([
            ('webhook_identifier', '=', account),
        ])
    except ValueError:
        abort(HTTPStatus.FORBIDDEN)
    request_body = request.get_data(as_text=True)
    try:
        payload = json.loads(request_body)
        event = payload['event']
    except (ValueError, TypeError, KeyError):
        logger.info("Callback received wrong data: %r", request_body)
        abort(HTTPStatus.BAD_REQUEST)
    if event == 'payment':
        try:
            order_id = payload['order_id'].strip()
        except (KeyError, AttributeError):
            order_id = None
        if not order_id:
            logger.info("Callback received wrong data: %s", payload)
            abort(HTTPStatus.BAD_REQUEST)
        account.webhook_payment(order_id)
    else:
        logger.info("No callback for event %r", event)
        abort(HTTPStatus.BAD_REQUEST)
    return Response(status=HTTPStatus.NO_CONTENT)
