############################
Account Payment Taler Module
############################

The *Account Payment Taler* module allows receipt of payments using Taler_.
It communicates with the `GNU Taler Merchant Backend`__
for creating "orders" and checks whether they are paid.
The module also provides the possibility to send refunds
and checks whether they have been acquired by the customer.

For your web-shop it provides a "checkout" page
containing the QR-code the customer's wallet needs to scan.
It also provides a sample report
showing how to integrate the Taler payment QR-code into PDF invoices.

Of course, the QR-code and the URL contained can also be send
to the customer via an e-mail.

.. _Taler: https://taler.net
__ https://docs/taler.net/…

.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU Free Documentation License v1.3 or any later version.
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GFDL-1.3-or-later
