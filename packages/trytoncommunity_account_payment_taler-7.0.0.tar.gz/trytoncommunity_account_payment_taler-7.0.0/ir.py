# This file is part of trytoncommunity-account-payment-taler.
# Licensed under the GNU General Public License v3 or later (GPLv3+).
# The COPYRIGHT file at the top level of this repository contains the
# full copyright notices and license terms.
# SPDX-License-Identifier: GPL-3.0-or-later

from trytond.pool import PoolMeta


class Cron(metaclass=PoolMeta):
    __name__ = 'ir.cron'

    @classmethod
    def __setup__(cls):
        super().__setup__()
        cls.method.selection.extend([
            ('account.payment|taler_push',
             "Create Orders at the Taler Merchant Backend based on payments"),
            ('account.payment|taler_pull',
             "Update payments/orders from Taler Merchant Backend"),
            ('account.payment.taler.refund|taler_push',
             "Create Refunds at the Taler Merchant Backend based on refunds"),
            ('account.payment.taler.refund|taler_pull',
             "Update refunds from Taler Merchant Backend"),
        ])
