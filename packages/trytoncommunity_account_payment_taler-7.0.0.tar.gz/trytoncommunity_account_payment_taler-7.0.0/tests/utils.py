# This file is part of trytoncommunity-account-payment-taler.
# Copyright (C) trytoncommunity-account-payment-taler authors
# Licensed under the GNU General Public License v3 or later (GPLv3+).
# The COPYRIGHT file at the top level of this repository contains the
# full copyright notices and license terms.
# SPDX-License-Identifier: GPL-3.0-or-later

from contextlib import contextmanager
from unittest.mock import MagicMock, patch

import requests


@contextmanager
def mock_head(status_code, **kwargs):
    mock_response = MagicMock()
    mock_response.status_code = status_code
    with patch.object(
            requests, 'head', return_value=mock_response,
            **kwargs) as mocked:
        yield mocked


@contextmanager
def mock_get(status_code, data, **kwargs):
    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.json.return_value = data
    with patch.object(
            requests, 'get', return_value=mock_response,
            **kwargs) as mocked:
        yield mocked


@contextmanager
def mock_post(status_code, data, **kwargs):
    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.json.return_value = data
    with patch.object(
            requests, 'post', return_value=mock_response,
            **kwargs) as mocked:
        yield mocked


@contextmanager
def mock_request(status_code, data, **kwargs):
    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.json.return_value = data
    with patch.object(
            requests, 'request', return_value=mock_response,
            **kwargs) as mocked:
        yield mocked
