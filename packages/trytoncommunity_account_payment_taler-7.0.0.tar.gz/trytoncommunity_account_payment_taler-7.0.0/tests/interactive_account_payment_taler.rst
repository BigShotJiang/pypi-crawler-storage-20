.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU General Public License v3 or later (GPLv3+).
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GPL-3.0-or-later

==============================
Account Payment Taler Scenario
==============================

Setup
=====

Imports::

    >>> import os
    >>> import time
    >>> import webbrowser
    >>> from decimal import Decimal
    >>> from datetime import timedelta
    >>> from proteus import Model
    >>> from trytond.tests.tools import activate_modules
    >>> from trytond.modules.company.tests.tools import create_company, \
    ...    get_company
    >>> from trytond.modules.account.tests.tools import create_chart, \
    ...    create_fiscalyear

    >>> PULL_SLEEP, MAX_SLEEP = 1, 100
    >>> INTERACTIVE_SLEEP, INTERACTIVE_MAX_SLEEP = 10, 20

Activate modules::

    >>> config = activate_modules('account_payment_taler')

Get company::

    >>> Company = Model.get('company.company')
    >>> _ = create_company()
    >>> company = get_company()

Create customer party::

    >>> Party = Model.get('party.party')
    >>> customer = Party(name="Customer")
    >>> customer.save()

Create fiscal year::

    >>> fiscalyear = create_fiscalyear()
    >>> fiscalyear.click('create_period')

Create chart of accounts::

    >>> _ = create_chart(company)

Get crons::

    >>> Cron = Model.get('ir.cron')
    >>> cron_payment_pull, = Cron.find([
    ...     ('method', '=', 'account.payment|taler_pull'),
    ...     ])
    >>> cron_refund, = Cron.find([
    ...     ('method', '=', 'account.payment.taler.refund|taler_push'),
    ...     ])
    >>> cron_refund_pull, = Cron.find([
    ...     ('method', '=', 'account.payment.taler.refund|taler_pull'),
    ...     ])
    >>> cron_refund_pull.companies.append(Company(company.id))

Create Taler account::

    >>> TalerAccount = Model.get('account.payment.taler.account')
    >>> taler_account = TalerAccount(name="Taler")
    >>> taler_account.merchant_url = os.getenv('TALER_MERCHANT_URL')
    >>> taler_account.access_token = os.getenv('TALER_ACCESS_TOKEN')
    >>> taler_account.enforced_currency = \
    ...         os.getenv('TRYTON_TALER_ENFORCED_CURRENCY', 'KUDOS')
    >>> taler_account.save()

Create payment journal::

    >>> PaymentJournal = Model.get('account.payment.journal')
    >>> payment_journal = PaymentJournal(name="Taler",
    ...     process_method='taler', currency=company.currency,
    ...     taler_account=taler_account)
    >>> payment_journal.save()

Create submitted payment::

    >>> Payment = Model.get('account.payment')
    >>> payment = Payment()
    >>> payment.journal = payment_journal
    >>> payment.kind = 'receivable'
    >>> payment.party = customer
    >>> payment.amount = Decimal('0.42')
    >>> payment.taler_fulfillment_message = "Here is Tryton!"
    >>> payment.save()  #  to get id
    >>> payment.description = f"Tryton Test Suite Payment {payment.id}"
    >>> payment.click('submit')
    >>> payment.state
    'submitted'

Tests
=====

Test connection::

    >>> bool(taler_account.configured)
    False
    >>> taler_account.click('test_merchant_connection')
    >>> len(taler_account.webhook_identifier)
    32
    >>> bool(taler_account.configured)
    True
    >>> taler_account.default_pay_delay.total_seconds() > 0
    True
    >>> taler_account.default_refund_delay.total_seconds() > 0
    True
    >>> taler_account.default_wire_transfer_delay.total_seconds() > 0
    True

The current version of the Merchant Backend defaults to buggy values.
Thus – and to be save – set these values::

    >>> taler_account.default_pay_delay = timedelta(minutes=5)
    >>> taler_account.default_refund_delay = timedelta(minutes=10)
    >>> taler_account.default_wire_transfer_delay = timedelta(minutes=15)
    >>> taler_account.save()

Process the payment::

    >>> _ = payment.click('process_wizard')
    >>> payment.state
    'processing'
    >>> bool(payment.taler_order_id)
    True
    >>> payment.amount
    Decimal('0.42')

Pay (interactive), poll the Merchant Backend until it reports the
payment/order to be paid::

    >>> _ = webbrowser.open(
    ...     f'{taler_account.merchant_url}/orders/{payment.taler_order_id}')
    >>> for _ in range(INTERACTIVE_MAX_SLEEP):
    ...     time.sleep(INTERACTIVE_SLEEP)
    ...     cron_payment_pull.click('run_once')
    ...     payment.reload()
    ...     if payment.state == 'succeeded':
    ...         break
    ... else:
    ...     "Order was not paid. Terminating this test scenario."
    >>> payment.reload()
    >>> payment.state
    'succeeded'
    >>> payment.amount
    Decimal('0.42')


Test refunding
==============

Refund some amount::

    >>> Refund = Model.get('account.payment.taler.refund')
    >>> refund1 = Refund()
    >>> refund1.payment = payment
    >>> refund1.amount = Decimal('0.21')
    >>> refund1.click('submit')
    >>> refund1.click('approve')
    >>> cron_refund.companies.append(Company(company.id))
    >>> cron_refund.click('run_once')

Update the refund record::

    >>> refund1.reload()
    >>> refund1.state
    'processing'
    >>> refund1.amount
    Decimal('0.21')
    >>> payment.reload() ; payment.state, payment.amount
    ('succeeded', Decimal('0.42'))

Pull an update while the customer has not paid yet::

    >>> cron_refund_pull.click('run_once')
    >>> refund1.reload() ; refund1.state, refund1.amount
    ('processing', Decimal('0.21'))
    >>> payment.reload() ; payment.state, payment.amount
    ('succeeded', Decimal('0.42'))

Take the refund (interactive), poll the Merchant Backend until it reports the
refund as taken::

    >>> _ = webbrowser.open(
    ...     f'{taler_account.merchant_url}/orders/{payment.taler_order_id}')
    >>> for _ in range(INTERACTIVE_MAX_SLEEP):
    ...     time.sleep(INTERACTIVE_SLEEP)
    ...     cron_refund_pull.click('run_once')
    ...     refund1.reload()
    ...     if refund1.state == 'succeeded':
    ...         break
    ... else:
    ...     "Refund was not accepted. Terminating this test scenario."
    >>> refund1.reload()
    >>> refund1.state
    'succeeded'
    >>> refund1.amount
    Decimal('0.21')
    >>> payment.reload() ; payment.state, payment.amount
    ('succeeded', Decimal('0.42'))

Refund another amount::

    >>> refund2 = Refund()
    >>> refund2.payment = payment
    >>> refund2.amount = round(payment.amount / 4, 2)
    >>> refund2.click('submit')
    >>> refund2.click('approve')
    >>> cron_refund.click('run_once')
    >>> refund2.reload() ; refund2.state, refund2.amount
    ('processing', Decimal('0.10'))
    >>> refund1.reload() ; refund1.state, refund1.amount
    ('succeeded', Decimal('0.21'))
    >>> payment.reload() ; payment.state, payment.amount
    ('succeeded', Decimal('0.42'))

Try to refund too much::

    >>> refund3 = Refund()
    >>> refund3.payment = payment
    >>> refund3.amount = payment.amount * 2
    >>> refund3.click('submit')
    >>> refund3.click('approve')
    >>> cron_refund.click('run_once')
    >>> refund3.reload()
    >>> refund3.state
    'failed'

The payment and the other refunds are still fine::

    >>> payment.reload() ; payment.state, payment.amount
    ('succeeded', Decimal('0.42'))
    >>> refund1.reload() ; refund1.state, refund1.amount
    ('succeeded', Decimal('0.21'))
    >>> refund2.reload() ; refund2.state, refund2.amount
    ('processing', Decimal('0.10'))
