.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU General Public License v3 or later (GPLv3+).
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GPL-3.0-or-later

============================================
Web-hooks for Account Payment Taler Scenario
============================================

Setup
=====

Imports::

    >>> import re
    >>> from decimal import Decimal
    >>> from unittest.mock import patch
    >>> from proteus import Model
    >>> from trytond.tests.tools import activate_modules
    >>> from trytond.modules.company.tests.tools import create_company, \
    ...    get_company
    >>> from trytond.protocols.wrappers import HTTPStatus, Response
    >>> from trytond.tests.test_tryton import Client, DB_NAME
    >>> from trytond.wsgi import app

    >>> from trytond.modules.account_payment_taler.taler_error_codes import \
    ...    ErrorCode
    >>> from trytond.modules.account_payment_taler.tests.utils import (
    ...    mock_head, mock_get, mock_request)

    >>> BASEURL = f'/{DB_NAME}/account_payment_taler/checkout'

Activate modules::

    >>> config = activate_modules('account_payment_taler')

Get company::

    >>> _ = create_company()
    >>> company = get_company()

Create customer party::

    >>> Party = Model.get('party.party')
    >>> customer = Party(name="Customer")
    >>> customer.save()

Create Taler account::

    >>> TalerAccount = Model.get('account.payment.taler.account')
    >>> taler_account = TalerAccount(name="Taler")
    >>> taler_account.merchant_url = 'http://localhost/instances/non-existant'
    >>> taler_account.access_token = 'wrong-token'
    >>> taler_account.enforced_currency = 'KUDOS'
    >>> taler_account.save()

Test connection and setup web-hook entry-point::

    >>> with (mock_head(200),
    ...       mock_get(200, {
    ...    'default_pay_delay': {'d_us': 5 * 60 * 1000},
    ...    'default_refund_delay': {'d_us': 6 * 60 * 1000},
    ...    'default_wire_transfer_delay': {'d_us': 7 * 60 * 1000},
    ... })):
    ...     taler_account.click('test_merchant_connection')
    ...
    >>> len(taler_account.webhook_identifier)
    32

Create payment journal::

    >>> PaymentJournal = Model.get('account.payment.journal')
    >>> payment_journal = PaymentJournal(name="Taler",
    ...     process_method='taler', currency=company.currency,
    ...     taler_account=taler_account)
    >>> payment_journal.save()

Create test client for accessing the route::

    >>> client = Client(app, Response)


Test route only supports GET and POST
=====================================

::

    >>> ORDER_ID = 'dummy'
    >>> CHECKOUT_URL = f'{BASEURL}/{ORDER_ID}'

    >>> resp = client.head(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True
    >>> resp = client.put(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.delete(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.options(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> resp = client.trace(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.patch(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True


Test route with only the Taler account configured
=================================================

::

    >>> from trytond.modules.account_payment_taler.payment \
    ...     import TalerMerchantAccount
    >>> whp = patch.object(TalerMerchantAccount, 'webhook_payment').start()

Accessing an unknown order is forbidden::

    >>> resp = client.get(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True
    >>> resp = client.post(CHECKOUT_URL, data='1234')
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True


Test web hook with an processing order
======================================

::

    >>> ORDER_ID = '1234-56789-abcd'
    >>> CHECKOUT_URL = f'{BASEURL}/{ORDER_ID}'

Create a payment::

    >>> Payment = Model.get('account.payment')
    >>> payment = Payment()
    >>> payment.journal = payment_journal
    >>> payment.kind = 'receivable'
    >>> payment.party = customer
    >>> payment.amount = Decimal('0.42')
    >>> payment.taler_fulfillment_message = "Here is Tryton!"
    >>> payment.description = f"Tryton Test Suite Payment for Checkout Route"
    >>> payment.click('submit')
    >>> payment.state
    'submitted'

Process the payment::

    >>> with mock_request(200, {'order_id': ORDER_ID}):
    ...     _ = payment.click('process_wizard')
    ...
    >>> payment.state
    'processing'
    >>> payment.taler_order_id == ORDER_ID
    True


Accessing an unknown order is forbidden::

    >>> resp = client.get(f'{BASEURL}/dummy')
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True
    >>> resp = client.post(f'{BASEURL}/dummy', data='1234')
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True


Test POST method
----------------

POST returns "close window"::

    >>> resp = client.post(CHECKOUT_URL, data='1234')
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> resp.headers['Content-Type'].startswith('text/html;')
    True
    >>> 'window.close()' in resp.text
    True

POST data is ignored::

    >>> resp = client.post(CHECKOUT_URL, json=[])
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> 'window.close()' in resp.text
    True

    >>> resp = client.post(CHECKOUT_URL, json=[1,2])
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> 'window.close()' in resp.text
    True

    >>> resp = client.post(CHECKOUT_URL, json=1234)
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> 'window.close()' in resp.text
    True

    >>> resp = client.post(CHECKOUT_URL, json={1:2})
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> 'window.close()' in resp.text
    True


Test GET method
---------------

GET returns checkout html page::

    >>> with mock_request(200, {'taler_pay_uri': 'dummy-uri'}):
    ...    resp = client.get(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> resp.headers['Content-Type'].startswith('text/html;')
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True
    >>> 'Pay with Taler' in resp.text
    True
    >>> '<img alt="Taler"' in resp.text
    True
    >>> m = re.search(r'class="qr-code"\s+src="data:image/png;base64,.{100,}"',
    ...         resp.text)
    >>> m is None
    False

GET data is ignored::

    >>> with mock_request(200, {'taler_pay_uri': 'dummy-uri'}):
    ...    resp = client.get(CHECKOUT_URL, data='1234')
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True

    >>> with mock_request(200, {'taler_pay_uri': 'dummy-uri'}):
    ...    resp = client.get(CHECKOUT_URL, json=[])
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True

    >>> with mock_request(200, {'taler_pay_uri': 'dummy-uri'}):
    ...    resp = client.get(CHECKOUT_URL, json=[1,2])
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True

    >>> with mock_request(200, {'taler_pay_uri': 'dummy-uri'}):
    ...    resp = client.get(CHECKOUT_URL, json=1234)
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True

    >>> with mock_request(200, {'taler_pay_uri': 'dummy-uri'}):
    ...    resp = client.get(CHECKOUT_URL, json={1:2})
    >>> resp.status_code == HTTPStatus.OK
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True


For an order not paid within pay daedline, the merchant backend will report
No found and "Merchant_Generic_Order_Unknown"::

    >>> with mock_request(HTTPStatus.NOT_FOUND,
    ...        {'code': ErrorCode.MERCHANT_GENERIC_ORDER_UNKNOWN}):
    ...    resp = client.get(CHECKOUT_URL)
    >>> resp.status_code == HTTPStatus.GONE
    True
    >>> resp.headers['Content-Type'].startswith('text/html;')
    True
    >>> '<title>Taler Payment</title>' in resp.text
    True
    >>> 'Pay with Taler' in resp.text
    False
    >>> '<img alt="Taler"' in resp.text
    True
    >>> 'class="qr-code"' in resp.text
    False
    >>> 'Already paid' in resp.text
    True
