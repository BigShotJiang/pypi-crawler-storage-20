.. This file is part of trytoncommunity-account-payment-taler.
   Copyright (C) trytoncommunity-account-payment-taler authors
   Licensed under the GNU General Public License v3 or later (GPLv3+).
   The COPYRIGHT file at the top level of this repository contains the
   full copyright notices and license terms.
   SPDX-License-Identifier: GPL-3.0-or-later

============================================
Web-hooks for Account Payment Taler Scenario
============================================

Setup
=====

Imports::

    >>> from decimal import Decimal
    >>> from unittest.mock import call, patch
    >>> from proteus import Model
    >>> from trytond.tests.tools import activate_modules
    >>> from trytond.modules.company.tests.tools import create_company, \
    ...    get_company
    >>> from trytond.protocols.wrappers import HTTPStatus, Response
    >>> from trytond.tests.test_tryton import Client
    >>> from trytond.wsgi import app

    >>> from trytond.modules.account_payment_taler.tests.utils import (
    ...     mock_head, mock_get, mock_request)

Activate modules::

    >>> config = activate_modules('account_payment_taler')

Get company::

    >>> _ = create_company()
    >>> company = get_company()

Create customer party::

    >>> Party = Model.get('party.party')
    >>> customer = Party(name="Customer")
    >>> customer.save()

Create Taler account::

    >>> TalerAccount = Model.get('account.payment.taler.account')
    >>> taler_account = TalerAccount(name="Taler")
    >>> taler_account.merchant_url = 'http://localhost/instances/non-existant'
    >>> taler_account.access_token = 'wrong-token'
    >>> taler_account.enforced_currency = 'KUDOS'
    >>> taler_account.save()

Test connection and setup web-hook entry-point::

    >>> with (mock_head(200),
    ...       mock_get(200, {
    ...    'default_pay_delay': {'d_us': 5 * 60 * 1000},
    ...    'default_refund_delay': {'d_us': 6 * 60 * 1000},
    ...    'default_wire_transfer_delay': {'d_us': 7 * 60 * 1000},
    ... })):
    ...     taler_account.click('test_merchant_connection')
    ...
    >>> len(taler_account.webhook_identifier)
    32

Create payment journal::

    >>> PaymentJournal = Model.get('account.payment.journal')
    >>> payment_journal = PaymentJournal(name="Taler",
    ...     process_method='taler', currency=company.currency,
    ...     taler_account=taler_account)
    >>> payment_journal.save()

Create test client for accessing the route::

    >>> client = Client(app, Response)


Test web hook only supports POST
================================

::

    >>> resp = client.get(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.head(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.put(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.delete(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.options(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> resp = client.trace(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True
    >>> resp = client.patch(taler_account.webhook_endpoint)
    >>> resp.status_code == HTTPStatus.METHOD_NOT_ALLOWED
    True

Test web hook with only the Taler account configured
====================================================

::

    >>> client = Client(app, Response)
    >>> ORDER_ID = 'dummy'
    >>> from trytond.modules.account_payment_taler.payment \
    ...     import TalerMerchantAccount
    >>> whp = patch.object(TalerMerchantAccount, 'webhook_payment').start()

Accessing an unknown webhook is forbidden:

    >>> resp = client.post(taler_account.webhook_endpoint + '-wrong',
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True
    >>> whp.call_count
    0

Bad request: body is not json::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    data='ajshfdkashfd')
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: body is not a json dict::

    >>> resp = client.post(taler_account.webhook_endpoint, json=[])
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> resp = client.post(taler_account.webhook_endpoint, json=[1, 2])
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: no event-type::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: unknown event-type or event-type has wrong type::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'dummy', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': None, 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 1234, 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': [1,2], 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': {1:2}, 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: order-id has wrong type::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': None})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': 1234})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': [1,2]})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': {1:2}})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Order unknown to Tryton::

    >>> whp.return_value = None
    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args
    (1, call('dummy'))
    >>> whp.reset_mock()


Test web hook with an processing order
======================================

::

    >>> ORDER_ID = '1234-56789-abcd'

Create a payment::

    >>> Payment = Model.get('account.payment')
    >>> payment = Payment()
    >>> payment.journal = payment_journal
    >>> payment.kind = 'receivable'
    >>> payment.party = customer
    >>> payment.amount = Decimal('0.42')
    >>> payment.taler_fulfillment_message = "Here is Tryton!"
    >>> payment.description = f"Tryton Test Suite Payment for Web-Hook"
    >>> payment.click('submit')
    >>> payment.state
    'submitted'

Process the payment::

    >>> with mock_request(200, {'order_id': ORDER_ID}):
    ...     _ = payment.click('process_wizard')
    ...
    >>> payment.state
    'processing'
    >>> payment.taler_order_id == ORDER_ID
    True


Accessing an unknown webhook is forbidden:

    >>> resp = client.post(taler_account.webhook_endpoint + '-wrong',
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.FORBIDDEN
    True
    >>> whp.call_count
    0

Bad request: body is not json::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    data='ajshfdkashfd')
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: body is not a json dict::

    >>> resp = client.post(taler_account.webhook_endpoint, json=[])
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint, json=[1, 2])
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: no event-type::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: unknown event-type or event-type has wrong type::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'dummy', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': None, 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 1234, 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': [1,2], 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': {1:2}, 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Bad request: order-id has wrong type::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': None})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': 1234})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': [1,2]})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': {1:2}})
    >>> resp.status_code == HTTPStatus.BAD_REQUEST
    True
    >>> whp.call_count
    0

Order unknown to Tryton::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': 'non-existant'})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args
    (1, call('non-existant'))
    >>> whp.reset_mock()

Now try the existing order::

    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args == call(ORDER_ID)
    (1, True)
    >>> whp.reset_mock()

Verify status_code in NO_CONTENT, no matter what webhook_payment() returns::

    >>> whp.return_value = None
    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args == call(ORDER_ID)
    (1, True)
    >>> whp.reset_mock()

    >>> whp.return_value = True
    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args == call(ORDER_ID)
    (1, True)
    >>> whp.reset_mock()

    >>> whp.return_value = False
    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args == call(ORDER_ID)
    (1, True)
    >>> whp.reset_mock()

    >>> whp.return_value = {1: 2, 3: 4}
    >>> resp = client.post(taler_account.webhook_endpoint,
    ...    json={'event': 'payment', 'order_id': ORDER_ID})
    >>> resp.status_code == HTTPStatus.NO_CONTENT
    True
    >>> whp.call_count, whp.call_args == call(ORDER_ID)
    (1, True)
    >>> whp.reset_mock()
