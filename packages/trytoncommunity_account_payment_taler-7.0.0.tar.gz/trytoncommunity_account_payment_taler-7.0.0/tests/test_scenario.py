# This file is part of trytoncommunity-account-payment-taler.
# Copyright (C) trytoncommunity-account-payment-taler authors
# Licensed under the GNU General Public License v3 or later (GPLv3+)..
# The COPYRIGHT file at the top level of this repository contains the
# full copyright notices and license terms.
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import sys

from trytond.tests.test_tryton import load_doc_tests


def load_tests(loader, tests, pattern):
    orig_namePatterns = loader.testNamePatterns
    if sys.version_info < (3, 9):
        # unittest.mock in Python 3.8 does not support MagicMock as a context,
        # thus the scenarios using utils.mock_… fail. For the sake of
        # simplicity of this code skip all scenarios for Python 3.8,
        # esp. since it is end-of-support already.
        loader.testNamePatterns = []
    else:
        loader.testNamePatterns = ['scenario_*.rst']
    if (os.getenv('TALER_MERCHANT_URL') and os.getenv('TALER_ACCESS_TOKEN')):
        loader.testNamePatterns.append('interactive_*.rst')
    suite = load_doc_tests(__name__, __file__, loader, tests, pattern)
    loader.testNamePatterns = orig_namePatterns
    return suite
