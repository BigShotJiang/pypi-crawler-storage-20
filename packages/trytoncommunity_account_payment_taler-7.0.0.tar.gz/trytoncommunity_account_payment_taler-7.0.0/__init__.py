# This file is part of trytoncommunity-account-payment-taler.
# Copyright (C) trytoncommunity-account-payment-taler authors
# Licensed under the GNU General Public License v3 or later (GPLv3+).
# The COPYRIGHT file at the top level of this repository contains the
# full copyright notices and license terms.
# SPDX-License-Identifier: GPL-3.0-or-later

from trytond.pool import Pool

from . import ir, payment, routes

__all__ = ['register', 'routes']


def register():
    Pool.register(
        payment.Journal,
        payment.Group,
        payment.Payment,
        payment.Refund,
        payment.TalerMerchantAccount,
        ir.Cron,
        module='account_payment_taler', type_='model')
    Pool.register(
        payment.Checkout,
        module='account_payment_taler', type_='wizard')
    Pool.register(
        payment.CheckoutPage,
        module='account_payment_taler', type_='report')
