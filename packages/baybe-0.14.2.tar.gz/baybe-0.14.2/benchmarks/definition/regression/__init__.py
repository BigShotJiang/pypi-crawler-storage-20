"""Regression benchmark definitions."""
