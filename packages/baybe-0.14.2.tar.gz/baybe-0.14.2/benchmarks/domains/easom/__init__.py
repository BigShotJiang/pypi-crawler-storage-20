"""Synthetic transfer learning benchmarks."""
