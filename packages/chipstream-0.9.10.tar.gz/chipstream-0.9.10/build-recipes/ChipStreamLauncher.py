from chipstream.gui import main

if __name__ == "__main__":
    main()
