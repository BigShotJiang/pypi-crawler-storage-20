# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict, Any

from alibabacloud_aiccs20191015 import models as main_models
from darabonba.model import DaraModel

class GetCustomerInfoResponseBody(DaraModel):
    def __init__(
        self,
        code: str = None,
        data: main_models.GetCustomerInfoResponseBodyData = None,
        message: str = None,
        request_id: str = None,
        success: bool = None,
    ):
        self.code = code
        self.data = data
        self.message = message
        self.request_id = request_id
        self.success = success

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.code is not None:
            result['Code'] = self.code

        if self.data is not None:
            result['Data'] = self.data.to_map()

        if self.message is not None:
            result['Message'] = self.message

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        if self.success is not None:
            result['Success'] = self.success

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Code') is not None:
            self.code = m.get('Code')

        if m.get('Data') is not None:
            temp_model = main_models.GetCustomerInfoResponseBodyData()
            self.data = temp_model.from_map(m.get('Data'))

        if m.get('Message') is not None:
            self.message = m.get('Message')

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        if m.get('Success') is not None:
            self.success = m.get('Success')

        return self

class GetCustomerInfoResponseBodyData(DaraModel):
    def __init__(
        self,
        customize_fields: Dict[str, Any] = None,
        nick: str = None,
        outer_id: str = None,
        photo: str = None,
        real_name: str = None,
        user_id: int = None,
    ):
        self.customize_fields = customize_fields
        self.nick = nick
        self.outer_id = outer_id
        self.photo = photo
        self.real_name = real_name
        self.user_id = user_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.customize_fields is not None:
            result['CustomizeFields'] = self.customize_fields

        if self.nick is not None:
            result['Nick'] = self.nick

        if self.outer_id is not None:
            result['OuterId'] = self.outer_id

        if self.photo is not None:
            result['Photo'] = self.photo

        if self.real_name is not None:
            result['RealName'] = self.real_name

        if self.user_id is not None:
            result['UserId'] = self.user_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('CustomizeFields') is not None:
            self.customize_fields = m.get('CustomizeFields')

        if m.get('Nick') is not None:
            self.nick = m.get('Nick')

        if m.get('OuterId') is not None:
            self.outer_id = m.get('OuterId')

        if m.get('Photo') is not None:
            self.photo = m.get('Photo')

        if m.get('RealName') is not None:
            self.real_name = m.get('RealName')

        if m.get('UserId') is not None:
            self.user_id = m.get('UserId')

        return self

