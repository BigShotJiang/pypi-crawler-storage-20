from __future__ import annotations

import os
from setuptools import setup
from setuptools.command.build_py import build_py as _build_py

class build_py(_build_py):
    def run(self):
        super().run()
        src = os.path.join(os.path.dirname(__file__), "zmfh_autoboot.pth")
        if os.path.exists(src):
            os.makedirs(self.build_lib, exist_ok=True)
            dst = os.path.join(self.build_lib, "zmfh_autoboot.pth")
            self.copy_file(src, dst)

setup(cmdclass={"build_py": build_py})
