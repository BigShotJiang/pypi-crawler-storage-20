# ZMFH

ZMFH is a Python import governance layer.

Goals:
- Auto-apply on install (no user code changes)
- Fail-open by default: ZMFH must not break Python or user projects
- Clear diagnostics when enabled

Quick start:
- Install: `pip install zmfh`
- Disable: `ZMFH_DISABLE=1`
- Diagnostics: `ZMFH_DIAG=1` then run `python -m zmfh doctor`

Status:
- v0.1.0 focuses on safe bootstrap + hook installation + diagnostics scaffolding.
