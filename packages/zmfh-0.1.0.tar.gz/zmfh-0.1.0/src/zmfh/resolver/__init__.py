"""Resolver namespace."""
