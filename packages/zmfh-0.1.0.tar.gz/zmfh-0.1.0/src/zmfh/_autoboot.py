"""Auto-bootstrap for ZMFH.

Imported via a .pth file so it runs at interpreter startup after installation.
Defensive: never raises on import.
"""

def _safe_boot():
    try:
        # Preferred hook API
        try:
            from . import hooks as _hooks  # type: ignore
            if hasattr(_hooks, "enable"):
                _hooks.enable()
                return
        except Exception:
            pass

        # Fallback bootstrap API
        try:
            from . import bootstrap as _bootstrap  # type: ignore
            if hasattr(_bootstrap, "boot"):
                _bootstrap.boot()
                return
        except Exception:
            pass
    except Exception:
        return

_safe_boot()
