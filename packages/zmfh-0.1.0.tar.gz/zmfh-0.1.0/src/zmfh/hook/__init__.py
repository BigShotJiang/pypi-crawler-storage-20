"""Import hook namespace."""
