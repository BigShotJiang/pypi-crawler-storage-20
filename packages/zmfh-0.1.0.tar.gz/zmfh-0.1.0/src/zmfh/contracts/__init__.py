"""Contracts namespace."""
