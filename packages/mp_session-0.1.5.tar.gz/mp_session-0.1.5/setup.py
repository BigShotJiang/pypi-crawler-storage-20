#!/usr/bin/env python3
from setuptools import setup, find_packages
from pathlib import Path

version_file = Path(__file__).parent / "VERSION"
version = version_file.read_text().strip() if version_file.exists() else "0.1.0"

readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

requirements_file = Path(__file__).parent / "sdk" / "requirements.txt"
requirements = []
if requirements_file.exists():
    requirements = [
        line.strip() 
        for line in requirements_file.read_text().splitlines() 
        if line.strip() and not line.startswith('#')
    ]

setup(
    name="mp-session",
    version=version,
    author="Rally82",
    description="Multi-platform session manager",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(where="sdk"),
    package_dir={"": "sdk"},
    package_data={
        "session_manager": [
            "native/platforms/*.yaml",
            "native/platforms/*/config.yaml",
        ],
    },
    install_requires=requirements,
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "sm=session_manager.cli:main",
        ],
    },
)
