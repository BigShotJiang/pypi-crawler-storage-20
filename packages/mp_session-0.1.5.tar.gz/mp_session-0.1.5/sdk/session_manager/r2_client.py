try:
    from .config_embedded import R2_CONFIG
except ImportError:
    R2_CONFIG = {}
import os
import yaml
import boto3
from typing import Optional
from pathlib import Path
def load_config() -> dict:
    user_config = Path.home() / ".session_manager" / "config.yaml"
    config = {}
    if user_config.exists():
        with open(user_config, 'r') as f:
            config = yaml.safe_load(f) or {}
    return config
class R2Client:
    def __init__(
        self,
        access_key_id: str = None,
        secret_access_key: str = None,
        endpoint_url: str = None,
        bucket_name: str = None
    ):
        if not access_key_id and R2_CONFIG:
            access_key_id = R2_CONFIG.get("access_key_id")
        if not secret_access_key and R2_CONFIG:
            secret_access_key = R2_CONFIG.get("secret_access_key")
        if not endpoint_url and R2_CONFIG:
            endpoint_url = R2_CONFIG.get("endpoint_url")
        if not bucket_name and R2_CONFIG:
            bucket_name = R2_CONFIG.get("bucket_name")
        config = load_config()
        r2_config = config.get('r2', {})
        self.access_key_id = (
            access_key_id or 
            r2_config.get('access_key_id') or 
            os.getenv('R2_ACCESS_KEY_ID')
        )
        self.secret_access_key = (
            secret_access_key or 
            r2_config.get('secret_access_key') or 
            os.getenv('R2_SECRET_ACCESS_KEY')
        )
        self.endpoint_url = (
            endpoint_url or 
            r2_config.get('endpoint_url') or 
            os.getenv('R2_ENDPOINT')
        )
        self.bucket_name = (
            bucket_name or 
            r2_config.get('bucket_name') or 
            os.getenv('R2_BUCKET_NAME')
        )
        if not all([self.access_key_id, self.secret_access_key, self.endpoint_url, self.bucket_name]):
            raise ValueError(
                "缺少 R2 配置。请设置：\n"
                "1. 参数传入，或\n"
                "2. 配置文件 ~/.session_manager/config.yaml，或\n"
                "3. 环境变量 R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_ENDPOINT, R2_BUCKET_NAME"
            )
        self.s3 = boto3.client(
            's3',
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key_id,
            aws_secret_access_key=self.secret_access_key,
            region_name='auto'
        )
    def upload_file(self, local_path: str, r2_path: str):
        self.s3.upload_file(local_path, self.bucket_name, r2_path)
    def download_file(self, r2_path: str, local_path: str):
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        self.s3.download_file(self.bucket_name, r2_path, local_path)
    def delete_file(self, r2_path: str):
        self.s3.delete_object(Bucket=self.bucket_name, Key=r2_path)
    def list_files(self, prefix: str = '', max_keys: int = 1000) -> list:
        response = self.s3.list_objects_v2(
            Bucket=self.bucket_name,
            Prefix=prefix,
            MaxKeys=max_keys
        )
        return response.get('Contents', [])
    def file_exists(self, r2_path: str) -> bool:
        try:
            self.s3.head_object(Bucket=self.bucket_name, Key=r2_path)
            return True
        except:
            return False
    def get_file_url(self, r2_path: str, expires_in: int = 3600) -> str:
        return self.s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': self.bucket_name, 'Key': r2_path},
            ExpiresIn=expires_in
        )