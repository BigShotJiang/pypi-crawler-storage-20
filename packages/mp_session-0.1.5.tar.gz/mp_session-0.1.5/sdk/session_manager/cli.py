#!/usr/bin/env python3
"""Session Manager CLI - sm 命令

用法:
    sm start <platform> <account_id> [options]
    sm stop <platform> [account_id]
    sm switch <platform> <account_id> [options]
    sm save <platform> <account_id> [options]
    sm load <platform> <account_id> [options]
    sm list [platform]
    sm status [platform] [account_id]
    sm config list
    sm config show <platform>
"""

import sys
import os
import argparse
from pathlib import Path

# 添加 SDK 路径
sys.path.insert(0, str(Path(__file__).parent.parent))

# 加载项目根目录的 .env 文件
def load_env():
    """加载 .env 文件到环境变量"""
    env_path = Path(__file__).parent.parent / '.env'
    if env_path.exists():
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    # 只设置未定义的环境变量
                    if key.strip() not in os.environ:
                        os.environ[key.strip()] = value.strip()

load_env()

from session_manager import NativeHelper, R2Client, PlatformConfig


def cmd_start(args):
    """启动应用"""
    r2 = R2Client()
    helper = NativeHelper(r2_client=r2)
    
    pid = helper.start(
        platform=args.platform,
        account_id=args.account_id,
        service=args.service,
        proxy=args.proxy,
        fingerprint=args.fingerprint,
        force=getattr(args, 'force', False)
    )
    
    print(f"✓ 启动成功: {args.platform}/{args.account_id} (PID: {pid})")


def cmd_stop(args):
    """停止应用"""
    helper = NativeHelper()
    helper.stop(args.platform, args.account_id)
    
    if args.account_id:
        print(f"✓ 已停止: {args.platform}/{args.account_id}")
    else:
        print(f"✓ 已停止所有 {args.platform} 进程")


def cmd_switch(args):
    """切换环境（环境变量方式）"""
    r2 = R2Client()
    helper = NativeHelper(r2_client=r2)
    
    env_vars = helper.switch(
        platform=args.platform,
        account_id=args.account_id,
        service=args.service
    )
    
    # 写入 env.sh
    env_file = Path.home() / ".session_manager" / "env.sh"
    env_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(env_file, 'w') as f:
        f.write("# Session Manager 环境变量\n")
        f.write(f"# 当前: {args.platform}/{args.account_id}\n\n")
        for key, value in env_vars.items():
            f.write(f'export {key}="{value}"\n')
    
    print(f"✓ 已切换到: {args.platform}/{args.account_id}")
    print(f"请执行: source {env_file}")


def cmd_save(args):
    """保存会话"""
    r2 = R2Client()
    helper = NativeHelper(r2_client=r2)
    
    # 如果没有指定路径，使用缓存路径（实际运行的会话）
    source_path = args.path
    if not source_path:
        cache_path = helper._get_cache_path(args.platform, args.account_id, args.service)
        # 获取平台配置的目录名（如 tdata）
        paths = helper.platform_config.get_paths(args.platform)
        if paths:
            from session_manager.native.helper import expand_path
            dir_name = Path(expand_path(paths[0])).name
            source_path = str(cache_path / dir_name)
    
    r2_path = helper.save(
        platform=args.platform,
        account_id=args.account_id,
        service=args.service,
        source_path=source_path,
        fingerprint=args.fingerprint
    )
    
    print(f"✓ 已保存: {r2_path}")


def cmd_load(args):
    """加载到缓存"""
    r2 = R2Client()
    helper = NativeHelper(r2_client=r2)
    
    local_path = helper.load(
        platform=args.platform,
        account_id=args.account_id,
        service=args.service
    )
    
    print(f"✓ 已加载到: {local_path}")


def cmd_list(args):
    """列出账号"""
    # 尝试从 API 获取
    api_url = os.getenv('SM_API_URL')
    if api_url:
        try:
            from session_manager import SessionManagerClient
            api_client = SessionManagerClient(base_url=api_url)
            accounts = api_client.list_accounts(platform=args.platform)
            
            if not accounts:
                print("没有找到账号")
                return
            
            print(f"账号列表 ({len(accounts)} 个):")
            for acc in accounts:
                services_info = ""
                if args.verbose:
                    # 查询该账号的服务
                    creds = api_client.list_credentials(
                        account_id=acc['id'],
                        client_type='native'
                    )
                    services = [c.get('service') for c in creds if c.get('service')]
                    if services:
                        services_info = f" [服务: {', '.join(services)}]"
                
                print(f"  {acc['id']}: {acc['username']} ({acc['platform']}){services_info}")
            return
        except Exception as e:
            print(f"Warning: API 查询失败: {e}")
            print("降级到 R2 列表...")
    
    # 降级：从 R2 列表
    try:
        r2 = R2Client()
        prefix = f"{args.platform}/" if args.platform else ""
        files = r2.list_files(prefix=prefix, max_keys=1000)
        
        # 解析路径获取账号
        accounts = set()
        for file in files:
            parts = file['Key'].split('/')
            if len(parts) >= 3:  # platform/account_id/client_type/...
                accounts.add(f"{parts[0]}/{parts[1]}")
        
        if not accounts:
            print("没有找到账号")
            return
        
        print(f"账号列表 ({len(accounts)} 个，从 R2):")
        for acc in sorted(accounts):
            print(f"  {acc}")
    
    except Exception as e:
        print(f"✗ 无法列出账号")
        print(f"提示: 请设置 SM_API_URL 环境变量或配置 R2")
        print(f"  export SM_API_URL=http://localhost:8000")
        if args.verbose:
            print(f"错误详情: {e}")


def cmd_status(args):
    """查看运行状态"""
    helper = NativeHelper()
    
    if args.platform and args.account_id:
        # 查询特定账号
        status = helper.get_status(args.platform, args.account_id)
        if status['running']:
            print(f"{args.platform}/{args.account_id}: 运行中 (PID: {status['pid']})")
        else:
            print(f"{args.platform}/{args.account_id}: 未运行")
    else:
        # 列出所有运行中的进程
        running = helper.list_running(args.platform)
        if not running:
            print("没有运行中的进程")
        else:
            for proc in running:
                status = "运行中" if proc['running'] else "已停止"
                print(f"{proc['platform']}/{proc['account_id']}: {status} (PID: {proc['pid']})")


def cmd_config_list(args):
    """列出所有平台"""
    config = PlatformConfig()
    platforms = config.list_platforms()
    
    print("支持的平台:")
    for platform in platforms:
        print(f"  - {platform}")


def cmd_config_show(args):
    """显示平台配置"""
    config = PlatformConfig()
    platform_config = config.get(args.platform)
    
    if not platform_config:
        print(f"✗ 未找到平台: {args.platform}")
        sys.exit(1)
    
    print(f"平台: {args.platform}")
    print(f"类型: {platform_config.get('type')}")
    print(f"路径: {config.get_paths(args.platform)}")
    print(f"启动命令: {config.get_launch_cmd(args.platform)}")
    
    proxy_config = config.get_proxy_config(args.platform)
    if proxy_config:
        print(f"代理支持: {proxy_config.get('method')}")
    
    fp_config = config.get_fingerprint_config(args.platform)
    if fp_config and fp_config.get('supported'):
        print(f"指纹支持: {fp_config.get('method')}")


def main():
    parser = argparse.ArgumentParser(
        prog='sm',
        description='Session Manager CLI'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='命令')
    
    # start 命令
    parser_start = subparsers.add_parser('start', help='启动应用')
    parser_start.add_argument('platform', help='平台名称')
    parser_start.add_argument('account_id', help='账号 ID')
    parser_start.add_argument('--service', help='服务名称')
    parser_start.add_argument('--proxy', help='代理地址（如 socks5://127.0.0.1:1080）')
    parser_start.add_argument('--fingerprint', action='store_true', help='使用指纹')
    parser_start.add_argument('--force', action='store_true', help='强制刷新缓存')
    parser_start.set_defaults(func=cmd_start)
    
    # stop 命令
    parser_stop = subparsers.add_parser('stop', help='停止应用')
    parser_stop.add_argument('platform', help='平台名称')
    parser_stop.add_argument('account_id', nargs='?', help='账号 ID（可选）')
    parser_stop.set_defaults(func=cmd_stop)
    
    # switch 命令
    parser_switch = subparsers.add_parser('switch', help='切换环境')
    parser_switch.add_argument('platform', help='平台名称')
    parser_switch.add_argument('account_id', help='账号 ID')
    parser_switch.add_argument('--service', help='服务名称')
    parser_switch.set_defaults(func=cmd_switch)
    
    # save 命令
    parser_save = subparsers.add_parser('save', help='保存会话')
    parser_save.add_argument('platform', help='平台名称')
    parser_save.add_argument('account_id', help='账号 ID')
    parser_save.add_argument('--service', help='服务名称')
    parser_save.add_argument('--path', help='源路径')
    parser_save.add_argument('--fingerprint', help='指纹 ID')
    parser_save.set_defaults(func=cmd_save)
    
    # load 命令
    parser_load = subparsers.add_parser('load', help='加载到缓存')
    parser_load.add_argument('platform', help='平台名称')
    parser_load.add_argument('account_id', help='账号 ID')
    parser_load.add_argument('--service', help='服务名称')
    parser_load.set_defaults(func=cmd_load)
    
    # list 命令
    parser_list = subparsers.add_parser('list', help='列出账号')
    parser_list.add_argument('platform', nargs='?', help='平台名称（可选）')
    parser_list.add_argument('-v', '--verbose', action='store_true', help='显示详细信息')
    parser_list.set_defaults(func=cmd_list)
    
    # status 命令
    parser_status = subparsers.add_parser('status', help='查看运行状态')
    parser_status.add_argument('platform', nargs='?', help='平台名称（可选）')
    parser_status.add_argument('account_id', nargs='?', help='账号 ID（可选）')
    parser_status.set_defaults(func=cmd_status)
    
    # config 命令
    parser_config = subparsers.add_parser('config', help='平台配置')
    config_subparsers = parser_config.add_subparsers(dest='config_command')
    
    parser_config_list = config_subparsers.add_parser('list', help='列出所有平台')
    parser_config_list.set_defaults(func=cmd_config_list)
    
    parser_config_show = config_subparsers.add_parser('show', help='显示平台配置')
    parser_config_show.add_argument('platform', help='平台名称')
    parser_config_show.set_defaults(func=cmd_config_show)
    
    # 解析参数
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # 执行命令
    try:
        args.func(args)
    except Exception as e:
        print(f"✗ 错误: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
