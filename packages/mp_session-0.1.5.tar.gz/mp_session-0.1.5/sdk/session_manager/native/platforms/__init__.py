"""platforms 模块 - 纯配置数据"""

# 平台配置文件存放在此目录
# 简单平台: platform_name.yaml
# 复杂平台: platform_name/config.yaml + adapter.py

__all__ = []
