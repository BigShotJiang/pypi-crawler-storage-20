"""平台配置加载和管理"""

import os
import yaml
from pathlib import Path
from typing import Dict, Optional, List, Any

# 默认配置目录
DEFAULT_CONFIG_DIR = Path.home() / ".session_manager"
PLATFORMS_DIR = Path(__file__).parent / "platforms"


def get_current_os() -> str:
    """获取当前操作系统"""
    import platform
    system = platform.system().lower()
    if system == "linux":
        return "linux"
    elif system == "darwin":
        return "darwin"
    elif system == "windows":
        return "windows"
    return system


def expand_path(path: str) -> str:
    """展开路径中的 ~ 和环境变量"""
    return os.path.expandvars(os.path.expanduser(path))


class PlatformConfig:
    """平台配置管理"""
    
    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or DEFAULT_CONFIG_DIR
        self.current_os = get_current_os()
        self._configs: Dict[str, dict] = {}
        self._load_builtin()
        self._load_user_config()
    
    def _load_builtin(self):
        """加载内置配置"""
        # 遍历 platforms 目录
        if not PLATFORMS_DIR.exists():
            return
        
        for item in PLATFORMS_DIR.iterdir():
            platform_name = None
            config_data = None
            
            # 情况1: 单文件配置 (telegram.yaml)
            if item.is_file() and item.suffix == '.yaml':
                platform_name = item.stem
                with open(item, 'r') as f:
                    config_data = yaml.safe_load(f)
            
            # 情况2: 目录配置 (cursor/config.yaml)
            elif item.is_dir():
                config_file = item / "config.yaml"
                if config_file.exists():
                    platform_name = item.name
                    with open(config_file, 'r') as f:
                        config_data = yaml.safe_load(f)
            
            if platform_name and config_data:
                self._configs[platform_name] = config_data
    
    def _load_user_config(self):
        """加载用户自定义配置"""
        user_config = self.config_dir / "platforms.yaml"
        if user_config.exists():
            with open(user_config, 'r') as f:
                data = yaml.safe_load(f) or {}
                # 用户配置覆盖内置配置
                for platform, config in data.get('platforms', {}).items():
                    if platform in self._configs:
                        self._configs[platform].update(config)
                    else:
                        self._configs[platform] = config
    
    def get(self, platform: str) -> Optional[dict]:
        """获取平台配置（已解析为当前 OS）"""
        if platform not in self._configs:
            return None
        
        config = self._configs[platform]
        native_config = config.get('native', {})
        
        # 优先使用 OS 特定配置，其次使用 all
        if self.current_os in native_config:
            return native_config[self.current_os]
        elif 'all' in native_config:
            return native_config['all']
        
        return None
    
    def get_paths(self, platform: str) -> List[str]:
        """获取平台数据路径（已展开）"""
        config = self.get(platform)
        if not config:
            return []
        
        paths = config.get('paths', [])
        if isinstance(paths, str):
            paths = [paths]
        
        return [expand_path(p) for p in paths]
    
    def get_launch_cmd(self, platform: str) -> Optional[str]:
        """获取启动命令模板"""
        config = self.get(platform)
        return config.get('launch_cmd') if config else None
    
    def get_proxy_config(self, platform: str) -> Optional[dict]:
        """获取代理配置"""
        config = self.get(platform)
        return config.get('proxy') if config else None
    
    def get_fingerprint_config(self, platform: str) -> Optional[dict]:
        """获取指纹配置"""
        config = self.get(platform)
        return config.get('fingerprint') if config else None
    
    def list_platforms(self) -> List[str]:
        """列出所有支持的平台"""
        return list(self._configs.keys())
    
    def register(self, platform: str, config: dict):
        """注册自定义平台配置"""
        self._configs[platform] = config
