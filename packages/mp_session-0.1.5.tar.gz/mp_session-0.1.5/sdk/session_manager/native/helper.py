"""Native 客户端 Helper

用于管理本地应用的会话数据（Telegram Desktop, Cursor, gcloud 等）
"""

import os
import json
import shutil
import tarfile
import tempfile
import subprocess
import fnmatch
import time
from pathlib import Path
from typing import Optional, List, Dict, Union, Any

from .config_loader import PlatformConfig, expand_path, get_current_os

# 默认缓存目录
DEFAULT_CACHE_DIR = Path.home() / ".session_manager" / "cache"


class NativeHelper:
    """Native 客户端会话管理"""
    
    def __init__(
        self,
        api_client=None,
        r2_client=None,
        cache_dir: Optional[Path] = None,
        platform_config: Optional[PlatformConfig] = None
    ):
        """
        Args:
            api_client: SessionManagerClient 实例（可选，用于数据库操作）
            r2_client: R2/S3 客户端（用于文件存储）
            cache_dir: 本地缓存目录
            platform_config: 平台配置（可选，默认加载内置配置）
        """
        self.api_client = api_client
        self.r2_client = r2_client
        self.cache_dir = cache_dir or DEFAULT_CACHE_DIR
        self.platform_config = platform_config or PlatformConfig()
        self.current_os = get_current_os()
        
        # 确保缓存目录存在
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # 运行中的进程
        self._processes: Dict[str, subprocess.Popen] = {}
    
    # ===== 核心操作 =====
    
    def load(
        self,
        platform: str,
        account_id: str,
        service: str = None,
        target_path: str = None,
        force: bool = False
    ) -> str:
        """从云端加载会话数据到本地
        
        Args:
            platform: 平台名称
            account_id: 账号 ID
            service: 服务名称（可选）
            target_path: 目标路径（可选，默认使用缓存目录）
            force: 强制重新下载（默认 False，复用缓存）
        
        Returns:
            解压后的数据路径
        """
        # 构造 R2 路径
        r2_path = self._build_r2_path(platform, account_id, service)
        
        # 确定本地路径
        if target_path:
            local_path = Path(expand_path(target_path))
        else:
            local_path = self._get_cache_path(platform, account_id, service)
        
        # 检查缓存是否有效
        if not force and self._is_cache_valid(local_path, platform):
            # 缓存有效，直接返回（复用）
            return str(local_path)
        
        # 缓存无效或强制刷新，清理并重新下载
        if local_path.exists():
            shutil.rmtree(local_path)
        
        # 下载并解压
        self._download_and_extract(r2_path, local_path)
        
        return str(local_path)
    
    def save(
        self,
        platform: str,
        account_id: str,
        service: str = None,
        source_path: str = None,
        fingerprint=None
    ) -> str:
        """保存会话数据到云端
        
        Args:
            platform: 平台名称
            account_id: 账号 ID
            service: 服务名称（可选）
            source_path: 源路径（可选，默认使用平台配置的路径）
            fingerprint: 指纹配置（None=不关联, "fp_id"=指定）
        
        Returns:
            R2 文件路径
        """
        # 获取源路径
        if source_path:
            paths = [expand_path(source_path)]
        else:
            paths = self.platform_config.get_paths(platform)
            if not paths:
                raise ValueError(f"未找到平台 {platform} 的配置")
            # 展开所有路径
            paths = [expand_path(p) for p in paths]
        
        # 获取过滤规则
        config = self.platform_config.get(platform)
        include = config.get('include', []) if config else []
        exclude = config.get('exclude', []) if config else []
        
        # 打包（支持多路径）
        archive_path = self._pack_directories(paths, include, exclude)
        
        # 上传到 R2
        r2_path = self._build_r2_path(platform, account_id, service)
        self._upload_file(archive_path, r2_path)
        
        # 清理临时文件
        os.unlink(archive_path)
        
        # 更新数据库（如果有 API 客户端）
        if self.api_client:
            try:
                self.api_client.create_or_update_credential(
                    account_id=account_id,
                    client_type='native',
                    service=service,
                    credential_file_path=r2_path,
                    fingerprint_id=fingerprint if isinstance(fingerprint, str) else None
                )
            except Exception as e:
                # 数据库更新失败不影响保存
                print(f"Warning: 数据库更新失败: {e}")
        
        return r2_path
    
    def start(
        self,
        platform: str,
        account_id: str,
        service: str = None,
        proxy=None,
        fingerprint=None,
        force: bool = False,
        **kwargs
    ) -> int:
        """启动应用
        
        Args:
            platform: 平台名称
            account_id: 账号 ID
            service: 服务名称（可选）
            proxy: 代理配置（None=不用, True=关联, "proxy_id"=指定）
            fingerprint: 指纹配置（None=不用, True=关联, "fp_id"=指定）
            force: 强制刷新缓存（默认 False）
            **kwargs: 其他启动参数
        
        Returns:
            进程 PID
        """
        # 加载数据到缓存
        data_path = self.load(platform, account_id, service, force=force)
        data_path = self.load(platform, account_id, service)
        
        # 获取平台配置
        config = self.platform_config.get(platform)
        if not config:
            raise ValueError(f"未找到平台 {platform} 的配置")
        
        # 应用指纹（如果需要）
        if fingerprint:
            self._apply_fingerprint(platform, data_path, fingerprint)
        
        # 构建启动命令
        launch_cmd = self._build_launch_cmd(
            platform, config, data_path, proxy, **kwargs
        )
        
        if not launch_cmd:
            raise ValueError(f"平台 {platform} 不支持启动操作")
        
        # 启动进程
        process = subprocess.Popen(
            launch_cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # 记录进程
        key = f"{platform}:{account_id}"
        self._processes[key] = process
        
        return process.pid
    
    def stop(self, platform: str, account_id: str = None):
        """停止应用
        
        Args:
            platform: 平台名称
            account_id: 账号 ID（可选，不指定则停止该平台所有进程）
        """
        if account_id:
            key = f"{platform}:{account_id}"
            if key in self._processes:
                self._processes[key].terminate()
                del self._processes[key]
        else:
            # 停止该平台所有进程
            keys_to_remove = [k for k in self._processes if k.startswith(f"{platform}:")]
            for key in keys_to_remove:
                self._processes[key].terminate()
                del self._processes[key]
    
    def switch(
        self,
        platform: str,
        account_id: str,
        service: str = None
    ) -> Dict[str, str]:
        """切换账号（环境变量方式）
        
        Args:
            platform: 平台名称
            account_id: 账号 ID
            service: 服务名称（可选）
        
        Returns:
            需要设置的环境变量
        """
        # 加载数据到缓存
        data_path = self.load(platform, account_id, service)
        
        # 获取平台配置
        config = self.platform_config.get(platform)
        if not config:
            raise ValueError(f"未找到平台 {platform} 的配置")
        
        env_vars = config.get('env_vars', {})
        if not env_vars:
            raise ValueError(f"平台 {platform} 不支持环境变量切换")
        
        # 替换占位符
        result = {}
        for key, value in env_vars.items():
            result[key] = value.replace('{data_path}', data_path)
        
        return result
    
    # ===== 查询操作 =====
    
    def list_services(self, platform: str, account_id: str) -> List[str]:
        """列出账号的所有服务"""
        # 优先从数据库查询
        if self.api_client:
            try:
                credentials = self.api_client.list_credentials(
                    account_id=account_id,
                    client_type='native'
                )
                services = [c.get('service') for c in credentials if c.get('service')]
                return list(set(services))
            except Exception:
                pass  # 降级到 R2
        
        # 降级：从 R2 列出
        prefix = f"{platform}/{account_id}/native/"
        files = self.r2_client.list_files(prefix=prefix) if self.r2_client else []
        
        # 解析路径获取 service
        services = set()
        for file in files:
            # 路径格式: platform/account_id/native/service/file 或 platform/account_id/native/file
            parts = file['Key'].split('/')
            if len(parts) == 5:  # 有 service
                services.add(parts[3])
        
        return list(services)
    
    def get_status(self, platform: str, account_id: str) -> Dict:
        """查询应用状态"""
        key = f"{platform}:{account_id}"
        if key in self._processes:
            process = self._processes[key]
            return {
                'running': process.poll() is None,
                'pid': process.pid
            }
        return {'running': False, 'pid': None}
    
    def list_running(self, platform: str = None) -> List[Dict]:
        """列出运行中的进程"""
        result = []
        for key, process in self._processes.items():
            p, a = key.split(':', 1)
            if platform and p != platform:
                continue
            result.append({
                'platform': p,
                'account_id': a,
                'pid': process.pid,
                'running': process.poll() is None
            })
        return result
    
    # ===== 扩展操作 =====
    
    def register_config(self, platform: str, config: dict):
        """注册自定义平台配置"""
        self.platform_config.register(platform, config)
    
    # ===== 内部方法 =====
    
    def _build_r2_path(
        self,
        platform: str,
        account_id: str,
        service: str = None
    ) -> str:
        """构造 R2 路径"""
        import platform as sys_platform
        
        # 获取系统平台
        system = sys_platform.system().lower()  # linux, darwin, windows
        
        # 根据是否有 service 决定路径层级
        if service:
            return f"{platform}/{account_id}/native/{service}/data-{system}.tar.gz"
        else:
            return f"{platform}/{account_id}/native/data-{system}.tar.gz"
    
    def _get_cache_path(
        self,
        platform: str,
        account_id: str,
        service: str = None
    ) -> Path:
        """获取本地缓存路径"""
        if service:
            return self.cache_dir / platform / account_id / service
        else:
            return self.cache_dir / platform / account_id
    
    def _pack_directories(
        self,
        source_paths: List[str],
        include: List[str] = None,
        exclude: List[str] = None
    ) -> str:
        """打包多个目录
        
        Args:
            source_paths: 源目录列表
            include: 包含规则（glob 模式）
            exclude: 排除规则（glob 模式）
        
        Returns:
            打包文件路径
        """
        # 创建临时文件
        fd, archive_path = tempfile.mkstemp(suffix='.tar.gz')
        os.close(fd)
        
        with tarfile.open(archive_path, 'w:gz') as tar:
            for source_path in source_paths:
                source = Path(source_path)
                if not source.exists():
                    print(f"Warning: 路径不存在，跳过: {source_path}")
                    continue
                
                # 获取目录名（如 tdata）
                dir_name = source.name
                
                # 遍历目录
                for root, dirs, files in os.walk(source):
                    for file in files:
                        file_path = Path(root) / file
                        rel_path = file_path.relative_to(source)
                        
                        # 检查过滤规则
                        if not self._should_include(str(rel_path), include, exclude):
                            continue
                        
                        # arcname 包含目录名：tdata/xxx
                        tar.add(file_path, arcname=f"{dir_name}/{rel_path}")
        
        return archive_path
    
    def _pack_directory(
        self,
        source_path: str,
        include: List[str] = None,
        exclude: List[str] = None
    ) -> str:
        """打包单个目录（兼容旧代码）"""
        return self._pack_directories([source_path], include, exclude)
    
    def _is_cache_valid(self, cache_path: Path, platform: str) -> bool:
        """检查缓存是否有效
        
        Args:
            cache_path: 缓存路径
            platform: 平台名称
        
        Returns:
            缓存是否有效
        """
        if not cache_path.exists():
            return False
        
        # 获取平台配置的路径，提取目录名
        paths = self.platform_config.get_paths(platform)
        if not paths:
            return False
        
        # 提取目录名（如 tdata）
        dir_name = Path(expand_path(paths[0])).name
        
        # 检查缓存中是否有该目录
        target_dir = cache_path / dir_name
        if not target_dir.exists() or not target_dir.is_dir():
            return False
        
        # 检查目录是否非空
        try:
            next(target_dir.iterdir())
            return True
        except StopIteration:
            return False
    
    def _should_include(
        self,
        path: str,
        include: List[str] = None,
        exclude: List[str] = None
    ) -> bool:
        """检查文件是否应该包含"""
        # 如果有 include 规则，必须匹配其中之一
        if include:
            matched = any(fnmatch.fnmatch(path, pattern) for pattern in include)
            if not matched:
                return False
        
        # 如果匹配 exclude 规则，排除
        if exclude:
            for pattern in exclude:
                if fnmatch.fnmatch(path, pattern):
                    return False
        
        return True
    
    def _download_and_extract(self, r2_path: str, local_path: Path):
        """从 R2 下载并解压"""
        # 清理目标目录（避免旧文件残留）
        if local_path.exists():
            shutil.rmtree(local_path)
        
        # 确保目录存在
        local_path.mkdir(parents=True, exist_ok=True)
        
        # 下载到临时文件
        fd, temp_path = tempfile.mkstemp(suffix='.tar.gz')
        os.close(fd)
        
        try:
            # TODO: 实现 R2 下载
            if self.r2_client:
                self.r2_client.download_file(r2_path, temp_path)
            else:
                raise NotImplementedError("R2 客户端未配置")
            
            # 解压
            with tarfile.open(temp_path, 'r:gz') as tar:
                tar.extractall(local_path)
        finally:
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def _upload_file(self, local_path: str, r2_path: str):
        """上传文件到 R2"""
        if self.r2_client:
            self.r2_client.upload_file(local_path, r2_path)
        else:
            raise NotImplementedError("R2 客户端未配置")
    
    def _build_launch_cmd(
        self,
        platform: str,
        config: dict,
        data_path: str,
        proxy=None,
        **kwargs
    ) -> Optional[str]:
        """构建启动命令"""
        launch_cmd = config.get('launch_cmd')
        if not launch_cmd:
            return None
        
        # 添加 DISPLAY 环境变量（如果存在）
        display = os.getenv('DISPLAY')
        if display:
            cmd = f"DISPLAY={display} {launch_cmd}"
        else:
            cmd = launch_cmd
        
        # 替换数据路径
        cmd = cmd.replace('{data_path}', data_path)
        
        # 添加代理参数
        if proxy:
            proxy_config = config.get('proxy', {})
            proxy_args = self._build_proxy_args(proxy, proxy_config)
            if proxy_args:
                cmd = f"{cmd} {proxy_args}"
        
        return cmd
    
    def _build_proxy_args(self, proxy, proxy_config: dict) -> str:
        """构建代理参数"""
        if not proxy_config:
            return ""
        
        method = proxy_config.get('method')
        
        # 获取代理信息
        proxy_info = self._resolve_proxy(proxy)
        if not proxy_info:
            return ""
        
        if method == 'args':
            template = proxy_config.get('args_template', '')
            return template.format(
                proxy_type=proxy_info.get('type', 'socks5'),
                proxy_host=proxy_info.get('host', ''),
                proxy_port=proxy_info.get('port', '')
            )
        
        return ""
    
    def _resolve_proxy(self, proxy) -> Optional[Dict]:
        """解析代理配置
        
        Args:
            proxy: None | True | "proxy_id" | "socks5://host:port" | dict
        
        Returns:
            代理信息 {'type', 'host', 'port', ...}
        """
        if proxy is None:
            return None
        
        if proxy is True:
            # TODO: 从账号关联获取代理
            return None
        
        if isinstance(proxy, dict):
            return proxy
        
        if isinstance(proxy, str):
            # 支持直接传入代理地址：socks5://127.0.0.1:1080
            if '://' in proxy:
                parts = proxy.split('://')
                if len(parts) == 2:
                    proxy_type = parts[0]  # socks5, http
                    host_port = parts[1].split(':')
                    if len(host_port) == 2:
                        return {
                            'type': proxy_type,
                            'host': host_port[0],
                            'port': host_port[1]
                        }
            
            # TODO: 从数据库获取代理配置
            if self.api_client:
                # proxy_data = self.api_client.get_proxy(proxy)
                pass
            return None
        
        return None
    
    def _apply_fingerprint(
        self,
        platform: str,
        data_path: str,
        fingerprint
    ):
        """应用指纹配置"""
        config = self.platform_config.get(platform)
        if not config:
            return
        
        fp_config = config.get('fingerprint', {})
        if not fp_config.get('supported'):
            return
        
        # 获取指纹信息
        fp_info = self._resolve_fingerprint(fingerprint)
        if not fp_info:
            return
        
        method = fp_config.get('method')
        
        if method == 'config_file':
            self._apply_fingerprint_config_file(
                data_path, fp_config, fp_info
            )
    
    def _resolve_fingerprint(self, fingerprint) -> Optional[Dict]:
        """解析指纹配置"""
        if fingerprint is None:
            return None
        
        if fingerprint is True:
            # TODO: 从凭据关联获取指纹
            return None
        
        if isinstance(fingerprint, str):
            # TODO: 从数据库获取指纹配置
            return None
        
        if isinstance(fingerprint, dict):
            return fingerprint
        
        return None
    
    def _apply_fingerprint_config_file(
        self,
        data_path: str,
        fp_config: dict,
        fp_info: dict
    ):
        """通过修改配置文件应用指纹"""
        files = fp_config.get('files', [])
        fields = fp_config.get('fields', {})
        
        for file_pattern in files:
            file_path = file_pattern.replace('{data_path}', data_path)
            file_path = expand_path(file_path)
            
            if not os.path.exists(file_path):
                continue
            
            try:
                with open(file_path, 'r') as f:
                    config_data = json.load(f)
                
                # 修改字段
                for field, template in fields.items():
                    value = template.format(**fp_info)
                    # 直接设置字段（不分割，因为可能是扁平的带点键名）
                    config_data[field] = value
                
                with open(file_path, 'w') as f:
                    json.dump(config_data, f, indent=2)
            except Exception as e:
                # 调试时可以打印错误
                # print(f"Warning: Failed to apply fingerprint to {file_path}: {e}")
                pass  # 忽略错误，继续处理其他文件
    
    def _set_nested_field(self, data: dict, field: str, value: Any):
        """设置嵌套字段值"""
        keys = field.split('.')
        current = data
        
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        current[keys[-1]] = value
