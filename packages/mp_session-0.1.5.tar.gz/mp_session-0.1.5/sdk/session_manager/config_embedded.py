R2_CONFIG = {
    'access_key_id': '70d35ef8d976f35c917c5b24661ff95e',
    'secret_access_key': '647b8aaecdb3cd7e60be9174e07e36ede6bb2821f965d875313f30911c4d9ff0',
    'endpoint_url': 'https://a6b3c4bcdd4b615fca5fa084839f4606.r2.cloudflarestorage.com',
    'bucket_name': '4dev'
}
DATABASE_URL = 'postgresql://postgres.qcndlgxehjvlzbwrkszh:abcde0230%40T@aws-1-ap-southeast-1.pooler.supabase.com:6543/postgres'
API_SECRET_KEY = 'change_this_to_a_secure_key'