# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Stages: Added, Changed, Removed, Fixed

## [Unreleased]

## [0.2.2] - 2026-01-18

- Fix section filter for nuttx 12.12.0
- Fix file name src/my-apps/Makefile

## [0.2.1] - 2026-01-18

### Added

- Add template for my-apps


## [0.2.0] - 2025-12-07

### Added
- Kconfig support for my board
- Changelog file (changelog.md)
- New command `board` for board configuration
- GitHub Actions workflow for publishing

### Changed
- Updated board configuration handling (handlers, kconfig, vars)

## [0.1.0] - 2025-12-03

### Added

- First release
