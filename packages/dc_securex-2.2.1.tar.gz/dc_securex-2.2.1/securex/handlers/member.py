"""
Member protection handler (bot/ban/kick protection).
"""
import discord
import asyncio
from ..models import ThreatEvent


class MemberHandler:
    """Handles member-related protection"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_member_join(self, member: discord.Member):
        """Detect and ban unauthorized/unverified bot additions"""
        try:
            if not member.bot:
                return  # Only check bots
            
            guild = member.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.bot_add):
                if entry.target.id == member.id:
                    is_verified = member.public_flags.verified_bot
                    is_allowed = await self._is_authorized(guild, entry.user.id)
                    
                    should_ban = not is_verified or not is_allowed
                    
                    if should_ban:
                        await member.ban(reason="SecureX: Unauthorized/unverified bot")
                        
                        threat = ThreatEvent(
                            type="bot_join",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=member.id,
                            target_name=member.name,
                            prevented=True,
                            restored=False,
                            details={"verified": is_verified}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_join handler: {e}")
    
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        """Detect and revert unauthorized bans"""
        try:
            await asyncio.sleep(0.5)
            
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.ban):
                if entry.target.id == user.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Ban attacker
                        await guild.ban(entry.user, reason="SecureX: Unauthorized ban action")
                        # Unban victim
                        await guild.unban(user, reason="SecureX: Restoring banned member")
                        
                        threat = ThreatEvent(
                            type="member_ban",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=user.id,
                            target_name=str(user),
                            prevented=True,
                            restored=True,
                            details={"victim": str(user)}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_ban handler: {e}")
    
    async def on_member_remove(self, member: discord.Member):
        """Detect and punish unauthorized kicks"""
        try:
            guild = member.guild
            await asyncio.sleep(0.5)
            
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.kick):
                if entry.target.id == member.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Ban attacker
                        await guild.ban(entry.user, reason="SecureX: Unauthorized kick action")
                        
                        threat = ThreatEvent(
                            type="member_kick",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=member.id,
                            target_name=str(member),
                            prevented=True,
                            restored=False,
                            details={"victim": str(member)}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_remove handler: {e}")
    
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Revert unauthorized role additions and remove dangerous roles from attacker"""
        try:
            # Check if roles changed
            if before.roles == after.roles:
                return
            
            guild = after.guild
            await asyncio.sleep(0.5)
            
            # Find what roles were added
            added_roles = set(after.roles) - set(before.roles)
            if not added_roles:
                return  # No roles added, only removed
            
            # Check audit logs for member role update
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_role_update):
                if entry.target.id == after.id:
                    # Check if the person who added roles is unauthorized
                    if not await self._is_authorized(guild, entry.user.id):
                        print(f"🔄 Unauthorized role change by {entry.user.name} on {after.name}")
                        
                        # STEP 1: Revert the role additions
                        for role in added_roles:
                            try:
                                await after.remove_roles(role, reason="SecureX: Reverting unauthorized role addition")
                                print(f"↩️  Removed {role.name} from {after.name}")
                            except Exception as e:
                                print(f"Error removing role: {e}")
                        
                        # STEP 2: Get the attacker member object
                        attacker = guild.get_member(entry.user.id)
                        
                        # STEP 3: Remove ALL dangerous roles from attacker
                        if attacker:
                            dangerous_roles = []
                            for role in attacker.roles:
                                # Check if role has dangerous permissions
                                if (role.permissions.administrator or 
                                    role.permissions.manage_guild or
                                    role.permissions.manage_roles or
                                    role.permissions.manage_channels or
                                    role.permissions.ban_members or
                                    role.permissions.kick_members or
                                    role.permissions.manage_webhooks):
                                    dangerous_roles.append(role)
                            
                            # Remove dangerous roles from attacker
                            if dangerous_roles:
                                try:
                                    await attacker.remove_roles(*dangerous_roles, reason="SecureX: Removing dangerous permissions from violator")
                                    print(f"🛡️  Removed {len(dangerous_roles)} dangerous role(s) from {entry.user.name}")
                                except Exception as e:
                                    print(f"Error removing dangerous roles: {e}")
                            
                            # STEP 4: Timeout attacker
                            try:
                                import datetime
                                timeout_duration = datetime.timedelta(seconds=self.sdk.timeout_duration)
                                await attacker.timeout(timeout_duration, reason="SecureX: Unauthorized role modification")
                                print(f"⏱️  Timed out {entry.user.name} for {self.sdk.timeout_duration}s")
                            except Exception as e:
                                print(f"Error timing out attacker: {e}")

                        
                        # Create threat event
                        threat = ThreatEvent(
                            type="member_update",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=after.id,
                            target_name=str(after),
                            prevented=True,
                            restored=True,
                            details={"roles_reverted": [r.name for r in added_roles]}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_update handler: {e}")
