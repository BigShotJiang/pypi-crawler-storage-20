# Topsis-Devansh-102317041

**Topsis-Devansh-102317041** is a Python library for handling Multiple Criteria Decision Making (MCDM) problems by using the Technique for Order of Preference by Similarity to Ideal Solution (TOPSIS).

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install this package.

```bash
pip install Topsis-Devansh-102317041

Usage
You can use this package via the command line interface (CLI).

Command Line
Bash

topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>
Example:

Bash

topsis data.csv "1,1,1,2" "+,+,-,+" result.csv
License
MIT