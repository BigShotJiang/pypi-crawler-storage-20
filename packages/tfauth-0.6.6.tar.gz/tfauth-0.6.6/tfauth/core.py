import os
import pyotp
import random
import string
from datetime import datetime

class TFAuth:
    def __init__(self):
        # Атрибуты системы
        self.version = "2.4.0"
        self.TAPI = "TAPI_MASTER_999" 
        self.GITHUB_CONFIG_URL = "https://raw.githubusercontent.com/user/repo/main/config.json"
        
        # UI Настройки
        self.color1 = "#3b82f6"  # Основной акцентный синий
        self.color2 = "#0f172a"  # Глубокий темный фон
        self.footer_text = "Identity Management System"
        
        # Пути
        self.success_login = "successl.html"
        
        # Секреты
        self.otp_secret = pyotp.random_base32()
        self.recovery_codes = ["-".join(["".join(random.choices(string.digits, k=4)) for _ in range(2)]) for _ in range(3)]

    def _get_styles(self, is_success=False):
        accent = "#10b981" if is_success else self.color1
        return f"""
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
            
            * {{ margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }}
            
            body {{ 
                background: radial-gradient(circle at top right, {self.color2}, #020617);
                height: 100vh; display: flex; justify-content: center; align-items: center; color: #f8fafc;
            }}

            .glass-card {{
                background: rgba(30, 41, 59, 0.4);
                backdrop-filter: blur(20px);
                -webkit-backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.1);
                width: 100%; max-width: 400px;
                padding: 40px; border-radius: 28px;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
                text-align: center;
            }}

            h2 {{ font-weight: 700; font-size: 24px; margin-bottom: 8px; letter-spacing: -0.5px; }}
            .desc {{ font-size: 14px; color: #94a3b8; margin-bottom: 30px; }}

            .input-box {{ margin-bottom: 18px; text-align: left; }}
            .input-box label {{ display: block; font-size: 12px; font-weight: 600; color: #64748b; margin-bottom: 6px; text-transform: uppercase; }}
            .input-box input {{
                width: 100%; padding: 14px 16px; background: rgba(0, 0, 0, 0.2);
                border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 12px;
                color: #fff; font-size: 15px; transition: all 0.2s; outline: none;
            }}
            .input-box input:focus {{ border-color: {accent}; background: rgba(0, 0, 0, 0.3); }}

            .btn-action {{
                width: 100%; padding: 16px; background: {accent}; color: #fff;
                border: none; border-radius: 12px; font-weight: 600; font-size: 15px;
                cursor: pointer; transition: all 0.3s; margin-top: 10px;
            }}
            .btn-action:hover {{ opacity: 0.9; transform: translateY(-1px); }}
            .btn-action:disabled {{ background: #1e293b; color: #475569; cursor: not-allowed; }}

            .footer {{ margin-top: 32px; padding-top: 24px; border-top: 1px solid rgba(255, 255, 255, 0.05); font-size: 12px; color: #475569; }}
            
            .hidden {{ display: none !important; }}
            .status-tag {{ font-size: 10px; font-weight: 700; color: {accent}; margin-bottom: 15px; display: block; text-transform: uppercase; }}
            
            #error-screen {{ 
                position: absolute; top: 0; left: 0; width: 100%; height: 100%; 
                background: #0f172a; border-radius: 28px; z-index: 10;
                display: none; flex-direction: column; justify-content: center; align-items: center; padding: 30px;
            }}
        </style>
        """

    def generate_html(self, idx="index.html"):
        totp = pyotp.TOTP(self.otp_secret)
        otp_uri = totp.provisioning_uri(name="SecureAccess", issuer_name="TFAuth")
        
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Identity Portal</title>
    <script src="https://cdn.jsdelivr.net/npm/otplib@12.0.1/otplib-browser.js"></script>
    {self._get_styles(is_success=False)}
</head>
<body>
    <div class="glass-card">
        <div id="error-screen">
            <h3 style="color:#ef4444; margin-bottom:10px;">Security Alert</h3>
            <p style="font-size:13px; color:#94a3b8; text-align:center;">TAPI verification failed. This node is locked.</p>
        </div>

        <span class="status-tag" id="t-status">Checking System...</span>
        <h2 id="h">Sign In</h2>
        <p class="desc" id="p">Please enter your credentials</p>
        
        <div id="v1">
            <div class="input-box">
                <label>Username</label><input type="text" id="uid" placeholder="Enter ID">
            </div>
            <div class="input-box">
                <label>Password</label><input type="password" id="upw" placeholder="••••••••">
            </div>
            <button class="btn-action" id="btn" onclick="goNext()">Continue</button>
            <p style="margin-top: 20px; font-size: 13px; color: #64748b;">
                No access? <a href="#" style="color:{self.color1}; text-decoration:none;" onclick="setM(true)">Register Node</a>
            </p>
        </div>

        <div id="vqr" class="hidden">
            <div style="background:#fff; padding:12px; border-radius:16px; display:inline-block; margin-bottom:20px;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&data={otp_uri}">
            </div>
            <p style="font-size:11px; color:#94a3b8; margin-bottom:20px;">Recovery Keys: <br><b>{", ".join(self.recovery_codes)}</b></p>
            <button class="btn-action" onclick="save()">Finish Registration</button>
        </div>

        <div id="votp" class="hidden">
            <div class="input-box">
                <label>2FA Token</label>
                <input type="text" id="otp" placeholder="000000" maxlength="6" style="text-align:center; font-size:24px; letter-spacing:8px;">
            </div>
            <button class="btn-action" onclick="verify()">Verify Session</button>
        </div>

        <div class="footer">
            {self.footer_text} &copy; {datetime.now().year}<br>
            System Version {self.version}
        </div>
    </div>

    <script>
        otplib.authenticator.options = {{ window: 1 }};
        
        async function checkTAPI() {{
            const st = document.getElementById('t-status');
            try {{
                const r = await fetch('{self.GITHUB_CONFIG_URL}');
                const d = await r.json();
                if(d.tapi_key === "{self.TAPI}") {{
                    st.innerText = "System Verified";
                }} else {{ throw new Error(); }}
            } catch(e) {{
                document.getElementById('error-screen').style.display = 'flex';
            }}
        }}

        function goNext() {{
            const u = document.getElementById('uid').value, p = document.getElementById('upw').value;
            if(localStorage.getItem('un_'+u) === p) {{
                show('votp', 'Security Check', 'Enter your 2FA code');
            }} else if(document.getElementById('h').innerText === "Register Node") {{
                show('vqr', 'Link Device', 'Scan QR with your 2FA app');
            }} else alert("Invalid credentials");
        }}

        function show(id, h, p) {{
            ['v1', 'vqr', 'votp'].forEach(x => document.getElementById(x).classList.add('hidden'));
            document.getElementById(id).classList.remove('hidden');
            document.getElementById('h').innerText = h;
            document.getElementById('p').innerText = p;
        }}

        function save() {{
            const u = document.getElementById('uid').value, p = document.getElementById('upw').value;
            localStorage.setItem('un_'+u, p);
            localStorage.setItem('us_'+u, "{self.otp_secret}");
            localStorage.setItem('ur_'+u, JSON.stringify({self.recovery_codes}));
            location.reload();
        }}

        function verify() {{
            const u = document.getElementById('uid').value, c = document.getElementById('otp').value;
            const s = localStorage.getItem('us_'+u), r = JSON.parse(localStorage.getItem('ur_'+u) || "[]");
            if(r.includes(c) || otplib.authenticator.check(c, s)) location.href = '{self.success_login}';
            else alert("Invalid code");
        }}

        function setM(reg) {{ document.getElementById('h').innerText = reg ? "Register Node" : "Sign In"; }}
        window.onload = checkTAPI;
    </script>
</body>
</html>
        """

    def save_as_html(self, filename="index.html"):
        main_html = self.generate_html(filename)
        
        success_html = f"""
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8">{self._get_styles(is_success=True)}</head>
<body>
    <div class="glass-card">
        <span class="status-tag">Session Active</span>
        <h2>Welcome Back</h2>
        <p class="desc">Authentication successful. TAPI verified.</p>
        <div style="background:rgba(16,185,129,0.1); border:1px solid #10b981; border-radius:16px; padding:20px; color:#10b981; font-weight:600;">
            ACCESS GRANTED
        </div>
        <a href="{filename}" style="display:block; margin-top:24px; color:#64748b; text-decoration:none; font-size:13px;">Sign Out</a>
    </div>
</body>
</html>
        """
        
        with open(filename, "w", encoding="utf-8") as f: f.write(main_html)
        with open(self.success_login, "w", encoding="utf-8") as f: f.write(success_html)
        print(f"Build completed: {filename} and {self.success_login}")