.. _readme:

|Logo|

.. |Logo| image:: https://raw.githubusercontent.com/MobileTeleSystems/syncmaster/d14bf1b1272f15d42f441d6e33264bd2f95216c9/docs/_static/logo_wide.svg
    :alt: Data.SyncMaster logo
    :target: https://github.com/MobileTeleSystems/data-syncmaster

|Repo Status| |Docker image| |PyPI| |PyPI License| |PyPI Python Version| |Documentation|
|Build Status| |Coverage| |pre-commit.ci|

.. |Repo Status| image:: https://www.repostatus.org/badges/latest/wip.svg
    :target: https://www.repostatus.org/#wip
.. |Docker image| image:: https://img.shields.io/docker/v/mtsrus/syncmaster-server?sort=semver&label=docker
    :target: https://hub.docker.com/r/mtsrus/syncmaster-server
.. |PyPI| image:: https://img.shields.io/pypi/v/data-syncmaster
    :target: https://pypi.org/project/data-syncmaster/
.. |PyPI License| image:: https://img.shields.io/pypi/l/data-syncmaster.svg
    :target: https://github.com/MobileTeleSystems/syncmaster/blob/develop/LICENSE.txt
.. |PyPI Python Version| image:: https://img.shields.io/pypi/pyversions/data-syncmaster.svg
    :target: https://badge.fury.io/py/data-syncmaster
.. |Documentation| image:: https://readthedocs.org/projects/syncmaster/badge/?version=stable
    :target: https://syncmaster.readthedocs.io
.. |Build Status| image:: https://github.com/MobileTeleSystems/syncmaster/workflows/Run%20All%20Tests/badge.svg
    :target: https://github.com/MobileTeleSystems/syncmaster/actions
.. |Coverage| image:: https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/
    MTSOnGithub/03e73a82ecc4709934540ce8201cc3b4/raw/syncmaster_badge.json
    :target: https://github.com/MobileTeleSystems/syncmaster/actions
.. |pre-commit.ci| image:: https://results.pre-commit.ci/badge/github/MobileTeleSystems/syncmaster/develop.svg
    :target: https://results.pre-commit.ci/latest/github/MobileTeleSystems/syncmaster/develop

What is Data.SyncMaster?
------------------------

Data.SyncMaster is as no-code ETL tool for transferring data between databases and file systems.
List of currently supported connections:

* Apache Hive
* Clickhouse
* Iceberg (REST Catalog + S3)
* MSSQL
* MySQL
* Oracle
* Postgres
* FTP
* FTPS
* HDFS
* S3
* Samba
* SFTP
* WebDAV

Based on `onETL <https://onetl.readthedocs.io/>`_ and `Apache Spark <https://spark.apache.org/>`_.

Goals
-----

* Make transferring data between databases and file systems as simple as possible
* Provide a lot of builtin connectors to transfer data in heterogeneous environment
* RBAC and multitenancy support

Non-goals
---------

* No streaming support for now, only batch operations
* This is not a change data capture (CDC) solution

.. documentation

Documentation
-------------

See https://syncmaster.readthedocs.io
