import argparse
import os
from itertools import chain
from pathlib import Path
from typing import Any

import owlrl
import rdflib
from rdflib import OWL, RDF, RDFS, XSD, Graph, Literal, URIRef

from ..data_source import set_cli_params as data_source_set_cli_params
from ..kgiri import (
    EKG_NS,
    kgiri_replace_iri_in_literal,
    set_kgiri_base,
    set_kgiri_base_replace,
)
from ..kgiri import set_cli_params as kgiri_set_cli_params
from ..log import error, log_error, log_iri, log_item, log_list, warning
from ..main import load_rdf_file_into_graph
from ..namespace import DATAOPS, DATASET, PROV, RAW, RULE

OWL._fail = (
    False  # workaround for this issue: https://github.com/RDFLib/OWL-RL/issues/53
)

ontology_file_names = ['ekgf-dataops-rule.ttl']


def check_ontologies(ontologies_root: Path) -> Path:
    if not ontologies_root.exists():
        error(f'Ontologies root directory not found: {ontologies_root}')
    for ontology_file_name in ontology_file_names:
        if not (ontologies_root / ontology_file_name).exists():
            error(f'Could not find {ontology_file_name} ontology')
    return ontologies_root


def add_dataops_rule_namespaces(rule_graph: Graph) -> None:
    rule_graph.base = EKG_NS['KGIRI']
    rule_graph.bind('kgiri', EKG_NS['KGIRI'])
    rule_graph.bind('kggraph', EKG_NS['KGGRAPH'])
    rule_graph.namespace_manager.bind('owl', OWL)
    rule_graph.namespace_manager.bind('prov', PROV)
    rule_graph.namespace_manager.bind('raw', RAW)
    rule_graph.namespace_manager.bind('dataops', DATAOPS)
    rule_graph.namespace_manager.bind('dataset', DATASET)
    rule_graph.namespace_manager.bind('rule', RULE)


class DataopsRuleParser:
    """Checks each `rule.ttl` file in each subdirectory of `/metadata` to
    see if it refers to `.sparql_endpoint` files that are meant to be used by the relevant calling step.
    This is driven by the presence of the approprate triple e.g rule a rule:TransformationRule
    Each of these `.sparql_endpoint` files is then imported (its contents) into a new version of
    the `rule.ttl` file
    """

    g: rdflib.Graph

    def __init__(
        self,
        args: Any,
        input_file_name: str | None = None,
        rule_file_iri: URIRef | None = None,
    ) -> None:
        self.args = args
        self.verbose = args.verbose
        if input_file_name is None:
            raise ValueError('input_file_name is required')
        self.rule_file = Path(input_file_name)
        if not self.rule_file.exists():
            error(f'{input_file_name} does not exist')
        self.rule_file_iri = rule_file_iri
        if args.data_source_code is None:
            error('No data source code specified')
        self.data_source_code = args.data_source_code
        if self.args.ontologies_root is None:
            error(' Rule Parser requires --ontologies-root to be specified')
        self.ontologies_root = check_ontologies(Path(self.args.ontologies_root))

    def check(self) -> int:
        self.g = self.read_rule_file()
        count = 0
        for rule in self.get_rule_iris():
            if self.check_rule(rule):
                count += 1
        if not count:
            log_error(
                'Could not find any executable rules in {}'.format(self.rule_file)
            )
            return 1
        self.load_ontologies()
        self.rdfs_infer()
        # log_item("# triples", len(self.g))
        self.rdfs_remove_tbox_stuff()
        # log_item("# triples", len(self.g))
        # dump_as_ttl_to_stdout(self.g)
        # exit(1)
        return 0

    def load_ontology(self, ontology_file_name: Path) -> None:
        log_item('Loading Ontology', ontology_file_name)
        load_rdf_file_into_graph(self.g, ontology_file_name)

    def load_ontologies(self) -> None:
        for ontology_file_name in ontology_file_names:
            self.load_ontology(self.ontologies_root / ontology_file_name)

    def rdfs_infer(self) -> None:
        owlrl.RDFSClosure.RDFS_Semantics(self.g, True, True, True)
        closure_class = owlrl.return_closure_class(
            owl_closure=True, rdfs_closure=True, owl_extras=True, trimming=True
        )
        owlrl.DeductiveClosure(
            closure_class,
            improved_datatypes=False,
            rdfs_closure=True,
            axiomatic_triples=False,
            datatype_axioms=False,
        ).expand(self.g)

    def rdfs_remove_tbox_stuff(self) -> None:
        """
        Remove all stuff that the reasoner added that we don't need, only leave
        the rules and other abox stuff in there
        """
        self.g.remove((None, RDF.type, OWL.Ontology))
        self.g.remove((None, RDF.type, OWL.Class))
        self.g.remove((None, RDF.type, OWL.ObjectProperty))
        self.g.remove((None, RDF.type, OWL.DatatypeProperty))
        self.g.remove((None, RDF.type, OWL.FunctionalProperty))
        self.g.remove((None, RDF.type, OWL.AnnotationProperty))
        self.g.remove((None, RDF.type, OWL.DataRange))
        self.g.remove((None, RDF.type, RDFS.Class))
        self.g.remove((None, RDF.type, RDFS.Datatype))
        self.g.remove((None, RDF.type, XSD.dateTime))
        self.g.remove((None, RDF.type, XSD.boolean))
        self.g.remove((None, RDF.type, XSD.string))

        self.g.remove((None, OWL.disjointWith, XSD.dateTime))
        self.g.remove((RULE, None, None))  # type: ignore[arg-type]
        for subject in self.g.subjects(predicate=OWL.equivalentProperty, object=None):
            self.g.remove((subject, None, None))
        for subject in self.g.subjects(predicate=None, object=None):
            if str(subject).startswith(str(RULE)):
                self.g.remove((subject, None, None))

    def get_rule_iris(self) -> Any:
        return chain(
            self.g.subjects(RDF.type, RULE.Rule),
            self.g.subjects(RDF.type, RULE.SPARQLRule),
        )

    def read_rule_file(self) -> Graph:
        """Parse the content of the given turtle file (which should be a Path object) and return an RDF graph"""
        rule_graph = rdflib.Graph()
        add_dataops_rule_namespaces(rule_graph)
        load_rdf_file_into_graph(rule_graph, self.rule_file)
        return rule_graph

    def set_key(self) -> str:
        return self.rule_file.parent.parent.stem

    def set_iri(self) -> URIRef:
        return EKG_NS['KGIRI'].term(f'rule-set-{self.set_key()}')

    def set_sort_key(self) -> str:
        """Produce a sort key allowing for an easy 'ORDER BY' to get all rules to be executed in order.
        This is a temporary implementation, at some point we'll have to switch over to a model where rules
        and rule-sets can specify dependencies to each other and then calculate the execution order based
        on that.
        """
        set_key = self.set_key()
        if set_key == 'generic':
            return '01-generic'
        if set_key == 'generic-last':
            return '98-generic-last'
        if set_key == 'obfuscate':
            return '99-obfuscate'
        return f'10-{set_key}'

    def key(self) -> str:
        return f'{self.set_key()}-{self.rule_file.parent.stem}'

    def sort_key(self) -> str:
        return f'{self.set_sort_key()}-{self.rule_file.parent.stem}'

    def create_rule_set(self) -> URIRef:
        set_iri = self.set_iri()
        self.g.add((set_iri, RDF.type, RULE.term('RuleSet')))
        self.g.add((set_iri, RDFS.label, Literal(self.set_key())))
        return set_iri

    def check_rule(self, rule_iri: URIRef) -> bool:
        log_iri('Rule IRI', rule_iri)
        log_item('Rule Sort-key', self.sort_key())
        set_iri = self.create_rule_set()
        self.g.add((rule_iri, RULE.term('inSet'), set_iri))
        self.g.add((rule_iri, RULE.term('key'), Literal(self.key())))
        self.g.add((rule_iri, RULE.sortKey, Literal(self.sort_key())))
        if self.args.data_source_code:
            self.g.add((
                rule_iri,
                DATASET.dataSourceCode,
                Literal(self.args.data_source_code),
            ))
        if self.rule_file_iri:
            self.g.add((rule_iri, RULE.definedIn, self.rule_file_iri))
        for rdfs_label in self.g.objects(rule_iri, RDFS.label):
            log_item('Rule Title', rdfs_label)
        if self.verbose:
            print('Looking for %s' % RULE.sparqlRuleFileName)
        sparql_rule_file_names = [
            x for x in self.g.objects(rule_iri, RULE.sparqlRuleFileName)
        ]
        if len(sparql_rule_file_names) == 0:
            warning(f'Rule {self.key()} does not have a SPARQL statement')
            return False
        if self.verbose:
            log_list('SPARQL Files', sparql_rule_file_names)
        for sparql_rule_file_name in sparql_rule_file_names:
            self.process_sparql_literal(
                rule_iri, self.check_sparql_file_name(str(sparql_rule_file_name))
            )
        return True

    #
    # Check to see if in the same directory as the rule.ttl file we have a .sparql_endpoint file
    # with the given name. If so, return its contents as a Literal.
    #
    def check_sparql_file_name(self, sparql_file_name: str) -> Literal | None:
        if self.verbose:
            log_item('Checking', self.rule_file.parent / sparql_file_name)
        sparql_file_name_full_path = self.rule_file.parent / sparql_file_name
        if not sparql_file_name_full_path.exists():
            warning(f'Could not find {sparql_file_name_full_path}')
            return None
        log_item(
            'Found SPARQL file', f'{self.rule_file.parent.name}/{sparql_file_name}'
        )
        return rdflib.Literal(sparql_file_name_full_path.read_text())

    def process_sparql_literal(
        self, rule: URIRef, sparql_literal: Literal | None
    ) -> None:
        if not sparql_literal:
            return
        self.replace_literal_triple(
            rule,
            RULE.sparqlRuleFileName,
            RULE.hasSPARQLRule,
            kgiri_replace_iri_in_literal(sparql_literal),
        )
        self.g.add((rule, RDF.type, RULE.Rule))
        self.g.add((rule, RDF.type, RULE.SPARQLRule))
        self.g.namespace_manager.bind('rule', RULE)

    #
    # Add a triple to the graph with the given sparql_endpoint literal.
    #
    def add_literal_triple(self, s: URIRef, p: URIRef, o: Literal) -> None:
        if self.verbose:
            print('Adding triple <{0}> - <{1}> - "{2}"'.format(s, p, o))
        self.g.add((s, p, o))

    def replace_literal_triple(
        self, s: URIRef, p1: URIRef, p2: URIRef, o: Literal
    ) -> None:
        self.g.remove((s, p1, None))
        self.add_literal_triple(s, p2, o)

    def dump(self, output_file: str | Path | None) -> int:
        if not output_file:
            warning('You did not specify an output file, no output file created')
            return 1
        self.g.serialize(destination=output_file, format='ttl')
        log_item('Created', output_file)
        return 0


def runit(args: Any, stream: Any) -> int:
    processor = DataopsRuleParser(args, input_file_name=args.input)
    processor.check()
    processor.check()
    return processor.dump(stream)


def main() -> int:
    parser = argparse.ArgumentParser(
        prog='python3 -m ekg_lib.dataops_rule_parser',
        description='Adds any referenced SPARQL file to the graph as text and writes a new Turtle file',
        epilog='Currently only supports turtle.',
        allow_abbrev=False,
    )
    parser.add_argument(
        '--verbose', '-v', help='verbose output', default=False, action='store_true'
    )
    parser.add_argument('--input', '-i', help='The input rule.ttl file')
    parser.add_argument(
        '--output', '-o', help='The output rule-with-sparql_endpoint.ttl file'
    )
    parser.add_argument(
        '--ontologies-root', help='The root directory where ontologies can be found'
    )
    kgiri_set_cli_params(parser)
    data_source_set_cli_params(parser)
    args = parser.parse_args()
    set_kgiri_base(args.kgiri_base)
    set_kgiri_base_replace(args.kgiri_base_replace)

    if args.output is None:
        log_item('Streaming output to', 'stdout')
        with os.fdopen(1, 'wb', closefd=False) as stdout:
            rc = runit(args, stdout)
            stdout.flush()
    else:
        log_item('Streaming output to', args.output)
        rc = runit(args, args.output)

    return rc


if __name__ == '__main__':
    exit(main())
if __name__ == '__main__':
    exit(main())
