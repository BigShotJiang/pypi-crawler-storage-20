# Rules Capture

> **Warning:** TODO

Captures all rule files from a given directory and uploads
the resulting file to S3 (i.e. "the object store").

```bash
python3 -m ekg_lib.dataops_rules_capture --help
```

```text
usage: python3 -m ekg_lib.dataops_rules_capture [-h] [--verbose]
  --dataops-root              RULE_ROOT
  --ontologies-root           ONTOLOGIES_ROOT
  --data-source-code          DATA_SOURCE_CODE
  --git-branch                GIT_BRANCH
  --kgiri-base                KGIRI_BASE
  --kgiri-base-replace        KGIRI_BASE_REPLACE
  --s3-endpoint               S3_ENDPOINT
  --s3-bucket                 S3_BUCKET
  --s3-create-bucket
  --aws-region                AWS_REGION
  --aws-access-key-id         AWS_ACCESS_KEY_ID
  --aws-secret-access-key     AWS_SECRET_ACCESS_KEY

Captures all rule files from a given directory and uploads the
resulting file to S3

optional arguments:
  -h, --help            show this help message and exit
  --verbose, -v         verbose output (default: False)
  --dataops-root RULE_ROOT
                        The root directory where all rule subdirectories can
                        be found (default: None)
  --ontologies-root ONTOLOGIES_ROOT
                        The root directory where ontologies can be found
                        (default: None)

Data Source:
  --data-source-code DATA_SOURCE_CODE
                        The code of the dataset (can also be set with env var
                        EKG_DATA_SOURCE_CODE) (default: None)
  --git-branch GIT_BRANCH, --branch GIT_BRANCH
                        The git branch name we're working on, default main
                        (default: main)

KGIRI:
  --kgiri-base KGIRI_BASE
                        A root level URL to be used for all KGIRI types
                        (default is EKG_KGIRI_BASE=https://kg.your-
                        company.kom/) (default: https://kg.your-company.kom/)
  --kgiri-base-replace KGIRI_BASE_REPLACE
                        The KGIRI base fragment that is to be replaced with the EKG_KGIRI_BASE
                        (default is EKG_KGIRI_BASE_REPLACE=https://placeholder.kg)

Object Store:
  --s3-endpoint S3_ENDPOINT
                        The S3 endpoint, default can be set via env var
                        S3_ENDPOINT_URL (default: None)
  --s3-bucket S3_BUCKET
                        The S3 bucket name, default can be set via env var
                        S3_BUCKET_NAME (default: None)
  --s3-create-bucket    Create the bucket if it's missing (default: False)
  --aws-region AWS_REGION
                        The AWS region, default can be set via env var
                        AWS_REGION (default: None)
  --aws-access-key-id AWS_ACCESS_KEY_ID
                        The AWS access key id, default can be set via env var
                        AWS_ACCESS_KEY_ID (default: None)
  --aws-secret-access-key AWS_SECRET_ACCESS_KEY
                        The AWS secret access key, default can be set via env
                        var AWS_SECRET_ACCESS_KEY (default: None)

Currently only supports turtle.
```

## Links

- [ekg_lib](../../)
- [EKGF](https://ekgf.org)

