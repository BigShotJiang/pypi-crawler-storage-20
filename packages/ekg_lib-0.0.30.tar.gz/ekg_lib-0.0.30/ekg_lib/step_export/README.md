# Step Export

> **Warning:** TODO

Export the given named graph from the given staging database to the given S3 bucket.

```bash
python3 -m ekg_lib.step_export --help
```

```text
usage: python3 -m ekg_lib.step_export [-h] [--verbose]
  [--dataset-code DATASET_CODE]
  [--branch BRANCH]
  [--sparql-endpoint SPARQL_ENDPOINT]
  [--sparql-database SPARQL_DATABASE]
  [--sparql-userid SPARQL_USERID]
  [--sparql-passwd SPARQL_PASSWD]
  [--s3-endpoint S3_ENDPOINT]
  [--s3-region S3_REGION]
  [--s3-bucket S3_BUCKET]
  [--s3-access-key S3_ACCESS_KEY]
  [--s3-secret-key S3_SECRET_KEY]

Export the given named graph from the given staging database to the given S3
bucket

optional arguments:
  -h, --help            show this help message and exit
  --verbose, -v         verbose output
  --dataset-code DATASET_CODE
                        The code of the dataset that we're going to run the
                        rules against
  --branch BRANCH       The branch name we're working on, default main
  --sparql-endpoint SPARQL_ENDPOINT
                        The SPARQL endpoint
  --sparql-database SPARQL_DATABASE
                        The SPARQL database
  --sparql-userid SPARQL_USERID
                        The SPARQL userid
  --sparql-passwd SPARQL_PASSWD, --sparql-password SPARQL_PASSWD
                        The SPARQL password
  --s3-endpoint S3_ENDPOINT
                        The S3 endpoint
  --s3-region S3_REGION
                        The S3 region (AWS_REGION)
  --s3-bucket S3_BUCKET
                        The S3 bucket name
  --s3-access-key S3_ACCESS_KEY
                        The AWS_ACCESS_KEY_ID
  --s3-secret-key S3_SECRET_KEY
                        The AWS_SECRET_ACCESS_KEY

Currently only supports turtle.
```

## Links

- [ekg_lib](../../)
- [EKGF](https://ekgf.org)

