from .example import main

if __name__ == '__main__':
    main()
    exit(0)
