from __future__ import annotations
import typing
import typing_extensions
import wpilib._wpilib
import wpilib.interfaces._interfaces
import wpimath._controls._controls.plant
import wpimath.units
__all__: list[str] = ['AbsoluteEncoder', 'AbsoluteEncoderConfig', 'AbsoluteEncoderConfigAccessor', 'AlternateEncoderConfig', 'AlternateEncoderConfigAccessor', 'AnalogInput', 'AnalogSensorConfig', 'AnalogSensorConfigAccessor', 'BaseConfig', 'CIEColor', 'ClosedLoopConfig', 'ClosedLoopConfigAccessor', 'ClosedLoopSlot', 'ColorMatch', 'ColorSensorV3', 'DetachedEncoder', 'DetachedEncoderConfig', 'DetachedEncoderConfigAccessor', 'DetachedEncoderLowLevel', 'DetachedEncoderSim', 'DetachedSignalsConfig', 'EncoderConfig', 'EncoderConfigAccessor', 'ExternalEncoderConfig', 'ExternalEncoderConfigAccessor', 'FeedForwardConfig', 'FeedForwardConfigAccessor', 'FeedbackSensor', 'LimitSwitchConfig', 'LimitSwitchConfigAccessor', 'MAXMotionConfig', 'MAXMotionConfigAccessor', 'MovingAverageFilterSim', 'NoiseGenerator', 'PersistMode', 'REVLibError', 'RelativeEncoder', 'ResetMode', 'ServoChannel', 'ServoChannelConfig', 'ServoChannelConfigAccessor', 'ServoHub', 'ServoHubConfig', 'ServoHubConfigAccessor', 'ServoHubLowLevel', 'ServoHubParameter', 'ServoHubSim', 'ServoHubSimFaultManager', 'SignalsConfig', 'SignalsConfigAccessor', 'SoftLimitConfig', 'SoftLimitConfigAccessor', 'SparkAbsoluteEncoder', 'SparkAbsoluteEncoderSim', 'SparkAnalogSensor', 'SparkAnalogSensorSim', 'SparkBase', 'SparkBaseConfig', 'SparkBaseConfigAccessor', 'SparkClosedLoopController', 'SparkExternalEncoderSim', 'SparkFlex', 'SparkFlexConfig', 'SparkFlexConfigAccessor', 'SparkFlexExternalEncoder', 'SparkFlexSim', 'SparkLimitSwitch', 'SparkLimitSwitchSim', 'SparkLowLevel', 'SparkMax', 'SparkMaxAlternateEncoder', 'SparkMaxAlternateEncoderSim', 'SparkMaxConfig', 'SparkMaxConfigAccessor', 'SparkMaxSim', 'SparkParameter', 'SparkRelativeEncoder', 'SparkRelativeEncoderSim', 'SparkSim', 'SparkSimFaultManager', 'SparkSoftLimit', 'SplineEncoder', 'StatusLogger']
class AbsoluteEncoder:
    def __init__(self) -> None:
        ...
    def getPosition(self) -> float:
        """
        Get the position of the motor. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using AbsoluteEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the motor
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the motor. This returns the native units
        of 'rotations per minute' by default, and can be changed by a scale
        factor using AbsoluteEncoderConfig::VelocityConversionFactor().
        
        :returns: Number of rotations per minute of the motor
        """
class AbsoluteEncoderConfig(BaseConfig):
    class Presets:
        @staticmethod
        def REV_SplineEncoder() -> AbsoluteEncoderConfig:
            """
            REV Robotics - MAXSpline Encoder (via 6-pin JST)
            """
        @staticmethod
        def REV_ThroughBoreEncoder() -> AbsoluteEncoderConfig:
            """
            REV Robotics - Through Bore Encoder
            """
        @staticmethod
        def REV_ThroughBoreEncoderV2() -> AbsoluteEncoderConfig:
            """
            REV Robotics - Through Bore Encoder V2
            """
        def __init__(self) -> None:
            ...
    def __init__(self) -> None:
        ...
    def apply(self, config: AbsoluteEncoderConfig) -> AbsoluteEncoderConfig:
        """
        Applies settings from another AbsoluteEncoderConfig to this one.
        
        Settings in the provided config will overwrite existing values in
        this object. Settings not specified in the provided config remain
        unchanged.
        
        :param config: The AbsoluteEncoderConfig to copy settings from
        
        :returns: The updated AbsoluteEncoderConfig for method chaining
        """
    def averageDepth(self, depth: typing.SupportsInt) -> AbsoluteEncoderConfig:
        """
        Set the average sampling depth of the absolute encoder. This is a bit
        size and should be either 1, 2, 4, 8, 16, 32, 64, or 128 (default).
        
        :param depth: The average sampling depth of 1, 2, 4, 8, 16, 32, 64, or
                      128
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def endPulseUs(self, endPulseUs: typing.SupportsFloat) -> AbsoluteEncoderConfig:
        """
        Set the length of the end pulse for this encoder. This pulse will be
        treated as the 1.0 position.
        
        :param endPulseUs: The minimum low pulse in microseconds
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def inverted(self, inverted: bool) -> AbsoluteEncoderConfig:
        """
        Set the phase of the absolute encoder so that it is in phase with the
        motor itself.
        
        :param inverted: The phase of the encoder
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def positionConversionFactor(self, factor: typing.SupportsFloat) -> AbsoluteEncoderConfig:
        """
        Set the conversion factor for the position of the absolute encoder.
        Position is returned in native units of rotations and will be
        multiplied by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def setSparkMaxDataPortConfig(self) -> AbsoluteEncoderConfig:
        """
        Configures the data port to use the absolute encoder, which is
        specifically required for SPARK MAX.
        
        NOTE: This method is only necessary when using an absolute encoder
        with a SPARK MAX without configuring any of its settings
        
        IMPORTANT: SPARK MAX does not support using an absolute encoder in
        conjunction with an alternate encoder.
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def startPulseUs(self, startPulseUs: typing.SupportsFloat) -> AbsoluteEncoderConfig:
        """
        Set the length of the start pulse for this encoder. This pulse will
        be treated as the 0.0 position.
        
        :param startPulseUs: The minimum high pulse in microseconds
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def velocityConversionFactor(self, factor: typing.SupportsFloat) -> AbsoluteEncoderConfig:
        """
        Set the conversion factor for the velocity of the absolute encoder.
        Velocity is returned in native units of rotations per minute and will
        be multiplied by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def zeroCentered(self, zeroCentered: bool) -> AbsoluteEncoderConfig:
        """
        Set whether to enable zero-centering for the absolute encoder. If
        enabled, the position will be reported in the range (-0.5, 0.5], instead
        of the default range [0, 1), assuming the default units of rotations.
        
        :param zeroCentered: Whether to enable zero centering
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
    def zeroOffset(self, offset: typing.SupportsFloat) -> AbsoluteEncoderConfig:
        """
        Set the zero offset of the absolute encoder, the position that is
        reported as zero.
        
        The zero offset is specified as the reported position of the
        encoder in the desired zero position as if the zero offset was set to
        0, the position conversion factor was set to 1, and inverted was set
        to false.
        
        :param offset: The zero offset in the range [0, 1)
        
        :returns: The modified AbsoluteEncoderConfig object for method
                  chaining
        """
class AbsoluteEncoderConfigAccessor:
    def getAverageDepth(self) -> int:
        ...
    def getEndPulseUs(self) -> float:
        ...
    def getInverted(self) -> bool:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getStartPulseUs(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroOffset(self) -> float:
        ...
class AlternateEncoderConfig(BaseConfig):
    class Presets:
        @staticmethod
        def REV_SplineEncoder() -> AlternateEncoderConfig:
            """
            REV Robotics - MAXSpline Encoder (via 6-pin JST)
            """
        @staticmethod
        def REV_ThroughBoreEncoder() -> AlternateEncoderConfig:
            """
            REV Robotics - Through Bore Encoder
            """
        @staticmethod
        def REV_ThroughBoreEncoderV2() -> AlternateEncoderConfig:
            """
            REV Robotics - Through Bore Encoder V2
            """
        def __init__(self) -> None:
            ...
    class Type:
        """
        Members:
        
          kQuadrature
        """
        __members__: typing.ClassVar[dict[str, AlternateEncoderConfig.Type]]  # value = {'kQuadrature': <Type.kQuadrature: 0>}
        kQuadrature: typing.ClassVar[AlternateEncoderConfig.Type]  # value = <Type.kQuadrature: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @staticmethod
    def fromId(id: typing.SupportsInt) -> AlternateEncoderConfig.Type:
        ...
    def __init__(self) -> None:
        ...
    def apply(self, config: AlternateEncoderConfig) -> AlternateEncoderConfig:
        """
        Applies settings from another AlternateEncoderConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The AlternateEncoderConfig to copy settings from
        
        :returns: The updated AlternateEncoderConfig for method chaining
        """
    def averageDepth(self, depth: typing.SupportsInt) -> AlternateEncoderConfig:
        """
        Set the sampling depth of the velocity calculation process of the
        alternate encoder. This value sets the number of samples in the average
        for velocity readings. For a quadrature encoder, this can be any value
        from 1 to 64 (default).
        
        :param depth: The velocity calculation process's sampling depth
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
    def countsPerRevolution(self, cpr: typing.SupportsInt) -> AlternateEncoderConfig:
        """
        Set the counts per revolutions of the alternate encoder.
        
        :param cpr: The counts per rotation
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
    def inverted(self, inverted: bool) -> AlternateEncoderConfig:
        """
        Set the phase of the alternate encoder so that it is in phase with the
        motor itself.
        
        :param inverted: The phase of the encoder
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
    def measurementPeriod(self, periodMs: typing.SupportsInt) -> AlternateEncoderConfig:
        """
        Set the position measurement period used to calculate the velocity of the
        alternate encoder. For a quadrature encoder, this number may be between 1
        and 100 (default).
        
        The basic formula to calculate velocity is change in position / change
        in time. This parameter sets the change in time for measurement.
        
        :param periodMs: Measurement period in milliseconds
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
    def positionConversionFactor(self, factor: typing.SupportsFloat) -> AlternateEncoderConfig:
        """
        Set the conversion factor for the position of the alternate encoder.
        Position is returned in native units of rotations and will be multiplied
        by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
    def setSparkMaxDataPortConfig(self) -> AlternateEncoderConfig:
        """
        Configures the data port to use the alternate encoder, which is
        specifically required for SPARK MAX.
        
        NOTE: This method is only necessary when using an alternate encoder
        with a SPARK MAX without configuring any of its settings
        
        IMPORTANT: SPARK MAX does not support using an alternate encoder in
        conjunction with an absolute encoder and/or limit switches.
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
    def velocityConversionFactor(self, factor: typing.SupportsFloat) -> AlternateEncoderConfig:
        """
        Set the conversion factor for the velocity of the alternate encoder.
        Velocity is returned in native units of rotations per minute and will be
        multiplied by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified AlternateEncoderConfig object for method
                  chaining
        """
class AlternateEncoderConfigAccessor:
    def getCountsPerRevolution(self) -> int:
        ...
    def getInverted(self) -> bool:
        ...
    def getMeasurementPeriod(self) -> int:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
class AnalogInput:
    """
    Get an instance of AnalogInput by using
    SparkBase::GetAnalog(SparkAnalogSensor::Mode)}.
    """
    def getPosition(self) -> float:
        """
        Get the position of the motor. Returns value in the native unit
        of 'volt' by default, and can be changed by a scale factor
        using AnalogSensorConfig::PositionConversionFactor().
        
        :returns: Position of the sensor in volts
        """
    def getVoltage(self) -> float:
        """
        Get the voltage of the analog sensor.
        
        :returns: Voltage of the sensor
        """
class AnalogSensorConfig(BaseConfig):
    def __init__(self) -> None:
        ...
    def apply(self, config: AnalogSensorConfig) -> AnalogSensorConfig:
        """
        Applies settings from another AnalogSensorConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The AnalogSensorConfig to copy settings from
        
        :returns: The updated AnalogSensorConfig for method chaining
        """
    def inverted(self, inverted: bool) -> AnalogSensorConfig:
        """
        Set the phase of the analog sensor so that it is in phase with the motor
        itself.
        
        :param inverted: The phase of the analog sensor
        
        :returns: The modified AnalogSensorConfig object for method
                  chaining
        """
    def positionConversionFactor(self, factor: typing.SupportsFloat) -> AnalogSensorConfig:
        """
        Set the conversion factor for the position of the analog sensor. Position
        is returned in native units of volts and will be multiplied by this
        conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified AnalogSensorConfig object for method
                  chaining
        """
    def velocityConversionFactor(self, factor: typing.SupportsFloat) -> AnalogSensorConfig:
        """
        Set the conversion factor for the velocity of the analog sensor. Velocity
        is returned in native units of volts per second and will be multiplied by
        this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified AnalogSensorConfig object for method
                  chaining
        """
class AnalogSensorConfigAccessor:
    def getInverted(self) -> bool:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
class BaseConfig:
    def flatten(self) -> str:
        ...
class CIEColor:
    def __init__(self, X: typing.SupportsFloat, Y: typing.SupportsFloat, Z: typing.SupportsFloat) -> None:
        ...
    def getX(self) -> float:
        """
        Get the X component of the color
        
        :returns: CIE X
        """
    def getY(self) -> float:
        """
        Get the Y component of the color
        
        :returns: CIE Y
        """
    def getYx(self) -> float:
        """
        Get the x calculated coordinate
        of the CIE 19313 color space
        
        https://en.wikipedia.org/wiki/CIE_1931_color_space
        
        :returns: CIE Yx
        """
    def getYy(self) -> float:
        """
        Get the y calculated coordinate
        of the CIE 19313 color space
        
        https://en.wikipedia.org/wiki/CIE_1931_color_space
        
        :returns: CIE Yy
        """
    def getZ(self) -> float:
        """
        Get the Z component of the color
        
        :returns: CIE Z
        """
class ClosedLoopConfig(BaseConfig):
    def D(self, d: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the derivative gain of the controller for a specific closed loop
        slot.
        
        :param d:    The derivative gain value
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def DFilter(self, dFilter: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the derivative filter of the controller for a specific closed loop
        slot.
        
        :param dFilter: The derivative filter value
        :param slot:    The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def I(self, i: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the integral gain of the controller for a specific closed loop slot.
        
        :param i:    The integral gain value
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def IMaxAccum(self, iMaxAccum: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the maximum I accumulator of the controller for a specific closed
        loop slot. This value is used to constrain the I accumulator to help
        manage integral wind-up.
        
        :param iMaxAccum: The max value to constrain the I accumulator to
        :param slot:      The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def IZone(self, iZone: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the integral zone of the controller for a specific closed loop slot.
        
        :param iZone: The integral zone value
        :param slot:  The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def P(self, p: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the proportional gain of the controller for a specific closed loop
        slot.
        
        :param p:    The proportional gain value
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def __init__(self) -> None:
        ...
    def allowedClosedLoopError(self, allowedError: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the allowed closed loop error for the controller for a specific
        PID slot. This value is how much deviation from the setpoint is
        tolerated and is useful in preventing oscillation around the setpoint.
        Natively, the units are in rotations but will be affected by the
        position conversion factor.
        
        :param allowedError: The allowed error with the position conversion factor
                             applied
        :param slot:         The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    @typing.overload
    def apply(self, config: ClosedLoopConfig) -> ClosedLoopConfig:
        """
        Applies settings from another ClosedLoopConfig to this one,
        including all of its nested configurations.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The ClosedLoopConfig to copy settings from
        
        :returns: The updated ClosedLoopConfig for method chaining
        """
    @typing.overload
    def apply(self, config: MAXMotionConfig) -> ClosedLoopConfig:
        """
        Applies settings from a MAXMotionConfig to this {@link
        ClosedLoopConfig}.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The MAXMotionConfig to copy settings from
        
        :returns: The updated ClosedLoopConfig for method chaining
        """
    @typing.overload
    def apply(self, config: FeedForwardConfig) -> ClosedLoopConfig:
        """
        Applies settings from a FeedForwardConfig to this {@link
        ClosedLoopConfig}.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The FeedForwardConfig to copy settings from
        
        :returns: The updated ClosedLoopConfig for method chaining
        """
    def flatten(self) -> str:
        ...
    def maxOutput(self, maxOutput: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the maximum output of the controller for a specific closed loop slot.
        
        :param maxOutput: The maximum output value in the range [-1, 1]
        :param slot:      The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def minOutput(self, minOutput: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the minimum output of the controller for a specific closed loop slot.
        
        :param minOutput: The minimum output value in the range [-1, 1]
        :param slot:      The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def outputRange(self, minOutput: typing.SupportsFloat, maxOutput: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the output range of the controller for a specific closed loop slot.
        
        :param minOutput: The minimum output value in the range [-1, 1]
        :param maxOutput: The maximum output value in the range [-1, 1]
        :param slot:      The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def pid(self, p: typing.SupportsFloat, i: typing.SupportsFloat, d: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the PID gains of the controller for a specific closed loop slot.
        
        :param p:    The proportional gain value
        :param i:    The integral gain value
        :param d:    The derivative gain value
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def pidf(self, p: typing.SupportsFloat, i: typing.SupportsFloat, d: typing.SupportsFloat, ff: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the PIDF gains of the controller for a specific closed loop slot.
        
        :deprecated: Use FeedForwardConfig::V(double v, ClosedLoopSlot slot) to
                     set a Velocity Feedforward
        
        :param p:    The proportional gain value
        :param i:    The integral gain value
        :param d:    The derivative gain value
        :param ff:   The velocity feedforward value
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def positionWrappingEnabled(self, enabled: bool) -> ClosedLoopConfig:
        """
        Enable or disable PID wrapping for position closed loop control.
        
        :param enabled: True to enable position PID wrapping
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def positionWrappingInputRange(self, minInput: typing.SupportsFloat, maxInput: typing.SupportsFloat) -> ClosedLoopConfig:
        """
        Set the input range for PID wrapping with position closed loop control
        
        :param minInput: The value of min input for the position
        :param maxInput: The value of max input for the position
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def positionWrappingMaxInput(self, maxInput: typing.SupportsFloat) -> ClosedLoopConfig:
        """
        Set the maximum input value for PID wrapping with position closed loop
        control
        
        :param maxInput: The value of max input for the position
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def positionWrappingMinInput(self, minInput: typing.SupportsFloat) -> ClosedLoopConfig:
        """
        Set the minimum input value for PID wrapping with position closed loop
        control.
        
        :param minInput: The value of min input for the position
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    @typing.overload
    def setFeedbackSensor(self, sensor: FeedbackSensor) -> ClosedLoopConfig:
        """
        Set an attached sensor as the feedback sensor of the controller.
        The controller will use this sensor as the source of feedback for its
        closed loop control.
        
        To set a detached encoder, use SetFeedbackSensor(FeedbackSensor, int) or
        SetFeedbackSensor(FeedbackSensor, rev::detached::DetachedEncoder&)
        instead. This method will ignore @c sensor set to a Detached sensor.
        
        The default feedback sensor is assumed to be the primary encoder for
        either brushless or brushed mode. This can be changed to another feedback
        sensor for the controller such as an analog sensor, absolute encoder, or
        alternate/external encoder.
        
        :param sensor: The attached feedback sensor
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    @typing.overload
    def setFeedbackSensor(self, sensor: FeedbackSensor, detachedEncoderDeviceId: typing.SupportsInt) -> ClosedLoopConfig:
        """
        Set an external CAN Detached Encoder as the feedback sensor of the
        controller. The controller will use this sensor as the source of feedback
        for its closed loop control.
        
        To set an attached encoder, use the SetFeedbackSensor(FeedbackSensor)
        method instead. This method will ignore @c sensor set to an attached
        sensor.
        
        :param sensor: The detached feedback sensor
                       @detachedEncoderDeviceId The device ID of the detached CAN encoder to use
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    @typing.overload
    def setFeedbackSensor(self, sensor: FeedbackSensor, detachedEncoder: DetachedEncoder) -> ClosedLoopConfig:
        """
        Set an external CAN Detached Encoder as the feedback sensor of the
        controller. The controller will use this sensor as the source of feedback
        for its closed loop control.
        
        To set an attached encoder, use the SetFeedbackSensor(FeedbackSensor)
        method instead. This method will ignore @c sensor set to an attached
        sensor.
        
        :param sensor: The detached feedback sensor
                       @splineEncoder The detached CAN encoder to use
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    def velocityFF(self, ff: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> ClosedLoopConfig:
        """
        Set the velocity feedforward gain of the controller for a specific closed
        loop slot.
        
        :deprecated: Use FeedForwardConfig::V(double v, ClosedLoopSlot slot) to
                     set this gain
        
        :param ff:   The velocity feedforward gain value
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified ClosedLoopConfig object for method chaining
        """
    @property
    def feedForward(self) -> FeedForwardConfig:
        ...
    @property
    def maxMotion(self) -> MAXMotionConfig:
        ...
class ClosedLoopConfigAccessor:
    def getAllowedClosedLoopError(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getD(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getDFilter(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getFF(self, slot: ClosedLoopSlot = ...) -> float:
        """
        :deprecated: Use FeedForwardConfigAccessor::GetV instead
        """
    def getFeedbackSensor(self) -> FeedbackSensor:
        ...
    def getI(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getIZone(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getMaxIAccumulation(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getMaxOutput(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getMinOutput(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getP(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getPositionWrappingEnabled(self) -> bool:
        ...
    def getPositionWrappingMaxInput(self) -> float:
        ...
    def getPositionWrappingMinInput(self) -> float:
        ...
    @property
    def feedForward(self) -> FeedForwardConfigAccessor:
        ...
    @property
    def maxMotion(self) -> MAXMotionConfigAccessor:
        ...
class ClosedLoopSlot:
    """
    Members:
    
      kSlot0
    
      kSlot1
    
      kSlot2
    
      kSlot3
    """
    __members__: typing.ClassVar[dict[str, ClosedLoopSlot]]  # value = {'kSlot0': <ClosedLoopSlot.kSlot0: 0>, 'kSlot1': <ClosedLoopSlot.kSlot1: 1>, 'kSlot2': <ClosedLoopSlot.kSlot2: 2>, 'kSlot3': <ClosedLoopSlot.kSlot3: 3>}
    kSlot0: typing.ClassVar[ClosedLoopSlot]  # value = <ClosedLoopSlot.kSlot0: 0>
    kSlot1: typing.ClassVar[ClosedLoopSlot]  # value = <ClosedLoopSlot.kSlot1: 1>
    kSlot2: typing.ClassVar[ClosedLoopSlot]  # value = <ClosedLoopSlot.kSlot2: 2>
    kSlot3: typing.ClassVar[ClosedLoopSlot]  # value = <ClosedLoopSlot.kSlot3: 3>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ColorMatch:
    """
    REV Robotics Color Sensor V3.
    
    This class allows access to a REV Robotics color sensor V3 on an I2C bus.
    """
    def __init__(self) -> None:
        ...
    def addColorMatch(self, color: wpilib._wpilib.Color) -> None:
        """
        Add color to match object
        
        :param color: color to add to matching
        """
    def matchClosestColor(self, colorToMatch: wpilib._wpilib.Color) -> tuple[wpilib._wpilib.Color, float]:
        """
        MatchColor uses euclidean distance to compare a given normalized RGB
        vector against stored values
        
        :param colorToMatch: color to compare against stored colors
        :param confidence:   The confidence value for this match, this is
                             simply 1 - euclidean distance of the two color vectors
        
        :returns: Closest matching color
        """
    @typing.overload
    def matchColor(self, colorToMatch: wpilib._wpilib.Color) -> wpilib._wpilib.Color | None:
        """
        MatchColor uses euclidean distance to compare a given normalized RGB
        vector against stored values
        
        :param colorToMatch: color to compare against stored colors
        
        :returns: Matched color if detected
        """
    @typing.overload
    def matchColor(self, colorToMatch: wpilib._wpilib.Color) -> tuple[wpilib._wpilib.Color | None, float]:
        """
        MatchColor uses euclidean distance to compare a given normalized RGB
        vector against stored values
        
        :param colorToMatch: color to compare against stored colors
        :param confidence:   The confidence value for this match, this is
                             simply 1 - euclidean distance of the two color vectors
        
        :returns: Matched color if detected
        """
    def setConfidenceThreshold(self, confidence: typing.SupportsFloat) -> None:
        """
        Set the confidence interval for determining color. Defaults to 0.95
        
        :param confidence: A value between 0 and 1
        """
class ColorSensorV3:
    """
    REV Robotics Color Sensor V3.
    
    This class allows access to a REV Robotics color sensor V3 on an I2C bus.
    """
    class ColorMeasurementRate:
        """
        Members:
        
          k25ms
        
          k50ms
        
          k100ms
        
          k200ms
        
          k500ms
        
          k1000ms
        
          k2000ms
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.ColorMeasurementRate]]  # value = {'k25ms': <ColorMeasurementRate.k25ms: 0>, 'k50ms': <ColorMeasurementRate.k50ms: 1>, 'k100ms': <ColorMeasurementRate.k100ms: 2>, 'k200ms': <ColorMeasurementRate.k200ms: 3>, 'k500ms': <ColorMeasurementRate.k500ms: 4>, 'k1000ms': <ColorMeasurementRate.k1000ms: 5>, 'k2000ms': <ColorMeasurementRate.k2000ms: 7>}
        k1000ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k1000ms: 5>
        k100ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k100ms: 2>
        k2000ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k2000ms: 7>
        k200ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k200ms: 3>
        k25ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k25ms: 0>
        k500ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k500ms: 4>
        k50ms: typing.ClassVar[ColorSensorV3.ColorMeasurementRate]  # value = <ColorMeasurementRate.k50ms: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class ColorResolution:
        """
        Members:
        
          k20bit
        
          k19bit
        
          k18bit
        
          k17bit
        
          k16bit
        
          k13bit
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.ColorResolution]]  # value = {'k20bit': <ColorResolution.k20bit: 0>, 'k19bit': <ColorResolution.k19bit: 16>, 'k18bit': <ColorResolution.k18bit: 32>, 'k17bit': <ColorResolution.k17bit: 48>, 'k16bit': <ColorResolution.k16bit: 64>, 'k13bit': <ColorResolution.k13bit: 80>}
        k13bit: typing.ClassVar[ColorSensorV3.ColorResolution]  # value = <ColorResolution.k13bit: 80>
        k16bit: typing.ClassVar[ColorSensorV3.ColorResolution]  # value = <ColorResolution.k16bit: 64>
        k17bit: typing.ClassVar[ColorSensorV3.ColorResolution]  # value = <ColorResolution.k17bit: 48>
        k18bit: typing.ClassVar[ColorSensorV3.ColorResolution]  # value = <ColorResolution.k18bit: 32>
        k19bit: typing.ClassVar[ColorSensorV3.ColorResolution]  # value = <ColorResolution.k19bit: 16>
        k20bit: typing.ClassVar[ColorSensorV3.ColorResolution]  # value = <ColorResolution.k20bit: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class GainFactor:
        """
        Members:
        
          k1x
        
          k3x
        
          k6x
        
          k9x
        
          k18x
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.GainFactor]]  # value = {'k1x': <GainFactor.k1x: 0>, 'k3x': <GainFactor.k3x: 1>, 'k6x': <GainFactor.k6x: 2>, 'k9x': <GainFactor.k9x: 3>, 'k18x': <GainFactor.k18x: 4>}
        k18x: typing.ClassVar[ColorSensorV3.GainFactor]  # value = <GainFactor.k18x: 4>
        k1x: typing.ClassVar[ColorSensorV3.GainFactor]  # value = <GainFactor.k1x: 0>
        k3x: typing.ClassVar[ColorSensorV3.GainFactor]  # value = <GainFactor.k3x: 1>
        k6x: typing.ClassVar[ColorSensorV3.GainFactor]  # value = <GainFactor.k6x: 2>
        k9x: typing.ClassVar[ColorSensorV3.GainFactor]  # value = <GainFactor.k9x: 3>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class LEDCurrent:
        """
        Members:
        
          kPulse2mA
        
          kPulse5mA
        
          kPulse10mA
        
          kPulse25mA
        
          kPulse50mA
        
          kPulse75mA
        
          kPulse100mA
        
          kPulse125mA
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.LEDCurrent]]  # value = {'kPulse2mA': <LEDCurrent.kPulse2mA: 0>, 'kPulse5mA': <LEDCurrent.kPulse5mA: 1>, 'kPulse10mA': <LEDCurrent.kPulse10mA: 2>, 'kPulse25mA': <LEDCurrent.kPulse25mA: 3>, 'kPulse50mA': <LEDCurrent.kPulse50mA: 4>, 'kPulse75mA': <LEDCurrent.kPulse75mA: 5>, 'kPulse100mA': <LEDCurrent.kPulse100mA: 6>, 'kPulse125mA': <LEDCurrent.kPulse125mA: 7>}
        kPulse100mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse100mA: 6>
        kPulse10mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse10mA: 2>
        kPulse125mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse125mA: 7>
        kPulse25mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse25mA: 3>
        kPulse2mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse2mA: 0>
        kPulse50mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse50mA: 4>
        kPulse5mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse5mA: 1>
        kPulse75mA: typing.ClassVar[ColorSensorV3.LEDCurrent]  # value = <LEDCurrent.kPulse75mA: 5>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class LEDPulseFrequency:
        """
        Members:
        
          k60kHz
        
          k70kHz
        
          k80kHz
        
          k90kHz
        
          k100kHz
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.LEDPulseFrequency]]  # value = {'k60kHz': <LEDPulseFrequency.k60kHz: 24>, 'k70kHz': <LEDPulseFrequency.k70kHz: 64>, 'k80kHz': <LEDPulseFrequency.k80kHz: 40>, 'k90kHz': <LEDPulseFrequency.k90kHz: 48>, 'k100kHz': <LEDPulseFrequency.k100kHz: 56>}
        k100kHz: typing.ClassVar[ColorSensorV3.LEDPulseFrequency]  # value = <LEDPulseFrequency.k100kHz: 56>
        k60kHz: typing.ClassVar[ColorSensorV3.LEDPulseFrequency]  # value = <LEDPulseFrequency.k60kHz: 24>
        k70kHz: typing.ClassVar[ColorSensorV3.LEDPulseFrequency]  # value = <LEDPulseFrequency.k70kHz: 64>
        k80kHz: typing.ClassVar[ColorSensorV3.LEDPulseFrequency]  # value = <LEDPulseFrequency.k80kHz: 40>
        k90kHz: typing.ClassVar[ColorSensorV3.LEDPulseFrequency]  # value = <LEDPulseFrequency.k90kHz: 48>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class ProximityMeasurementRate:
        """
        Members:
        
          k6ms
        
          k12ms
        
          k25ms
        
          k50ms
        
          k100ms
        
          k200ms
        
          k400ms
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.ProximityMeasurementRate]]  # value = {'k6ms': <ProximityMeasurementRate.k6ms: 1>, 'k12ms': <ProximityMeasurementRate.k12ms: 2>, 'k25ms': <ProximityMeasurementRate.k25ms: 3>, 'k50ms': <ProximityMeasurementRate.k50ms: 4>, 'k100ms': <ProximityMeasurementRate.k100ms: 5>, 'k200ms': <ProximityMeasurementRate.k200ms: 6>, 'k400ms': <ProximityMeasurementRate.k400ms: 7>}
        k100ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k100ms: 5>
        k12ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k12ms: 2>
        k200ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k200ms: 6>
        k25ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k25ms: 3>
        k400ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k400ms: 7>
        k50ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k50ms: 4>
        k6ms: typing.ClassVar[ColorSensorV3.ProximityMeasurementRate]  # value = <ProximityMeasurementRate.k6ms: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class ProximityResolution:
        """
        Members:
        
          k8bit
        
          k9bit
        
          k10bit
        
          k11bit
        """
        __members__: typing.ClassVar[dict[str, ColorSensorV3.ProximityResolution]]  # value = {'k8bit': <ProximityResolution.k8bit: 0>, 'k9bit': <ProximityResolution.k9bit: 8>, 'k10bit': <ProximityResolution.k10bit: 16>, 'k11bit': <ProximityResolution.k11bit: 24>}
        k10bit: typing.ClassVar[ColorSensorV3.ProximityResolution]  # value = <ProximityResolution.k10bit: 16>
        k11bit: typing.ClassVar[ColorSensorV3.ProximityResolution]  # value = <ProximityResolution.k11bit: 24>
        k8bit: typing.ClassVar[ColorSensorV3.ProximityResolution]  # value = <ProximityResolution.k8bit: 0>
        k9bit: typing.ClassVar[ColorSensorV3.ProximityResolution]  # value = <ProximityResolution.k9bit: 8>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class RawColor:
        def __init__(self, r: typing.SupportsInt, g: typing.SupportsInt, b: typing.SupportsInt, _ir: typing.SupportsInt) -> None:
            ...
        @property
        def blue(self) -> int:
            ...
        @blue.setter
        def blue(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def green(self) -> int:
            ...
        @green.setter
        def green(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def ir(self) -> int:
            ...
        @ir.setter
        def ir(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def red(self) -> int:
            ...
        @red.setter
        def red(self, arg0: typing.SupportsInt) -> None:
            ...
    def __init__(self, port: wpilib._wpilib.I2C.Port) -> None:
        """
        Constructs a ColorSensorV3.
        
        Note that the REV Color Sensor is really two devices in one package:
        a color sensor providing red, green, blue and IR values, and a proximity
        sensor.
        
        :param port: The I2C port the color sensor is attached to
        """
    def configureColorSensor(self, res: ColorSensorV3.ColorResolution, rate: ColorSensorV3.ColorMeasurementRate) -> None:
        """
        Configure the color sensor.
        
        These settings are only needed for advanced users, the defaults
        will work fine for most teams. Consult the APDS-9151 for more
        information on these configuration settings and how they will affect
        color sensor measurements.
        
        :param res:  Bit resolution output by the respective light sensor ADCs
        :param rate: Measurement rate of the light sensor
        """
    def configureProximitySensor(self, res: ColorSensorV3.ProximityResolution, rate: ColorSensorV3.ProximityMeasurementRate) -> None:
        """
        Configure the proximity sensor.
        
        These settings are only needed for advanced users, the defaults
        will work fine for most teams. Consult the APDS-9151 for more
        information on these configuration settings and how they will affect
        proximity sensor measurements.
        
        :param res:  Bit resolution output by the proximity sensor ADC.
        :param rate: Measurement rate of the proximity sensor
        """
    def configureProximitySensorLED(self, freq: ColorSensorV3.LEDPulseFrequency, current: ColorSensorV3.LEDCurrent, pulses: typing.SupportsInt) -> None:
        """
        Configure the the IR LED used by the proximity sensor.
        
        These settings are only needed for advanced users, the defaults
        will work fine for most teams. Consult the APDS-9151 for more
        information on these configuration settings and how they will affect
        proximity sensor measurements.
        
        :param freq:    The pulse modulation frequency for the proximity
                        sensor LED
        :param current: The pulse current for the proximity sensor LED
        :param pulses:  The number of pulses per measurement of the
                        proximity sensor LED
        """
    def getCIEColor(self) -> CIEColor:
        """
        Get the color converted to CIE XYZ color space using factory
        calibrated constants.
        
        https://en.wikipedia.org/wiki/CIE_1931_color_space
        
        :returns: CIEColor value from sensor
        """
    def getColor(self) -> wpilib._wpilib.Color:
        """
        Get the normalized RGB color from the sensor (normalized based on
        total R + G + B)
        
        :returns: frc::Color class with normalized sRGB values
        """
    def getIR(self) -> float:
        """
        Get the normalzied IR value from the sensor. Works best when within 2
        inches and perpendicular to surface of interest.
        
        :returns: Color class with normalized values
        """
    def getProximity(self) -> int:
        """
        Get the raw proximity value from the sensor ADC. This value is largest
        when an object is close to the sensor and smallest when
        far away.
        
        :returns: Proximity measurement value, ranging from 0 to 2047 in
                  default configuration
        """
    def getRawColor(self) -> ColorSensorV3.RawColor:
        """
        Get the raw color value from the sensor.
        
        :returns: Raw color values from sensopr
        """
    def hasReset(self) -> bool:
        """
        Indicates if the device reset. Based on the power on status flag in the
        status register. Per the datasheet:
        
        Part went through a power-up event, either because the part was turned
        on or because there was power supply voltage disturbance (default at
        first register read).
        
        This flag is self clearing
        
        :returns: true if the device was reset
        """
    def isConnected(self) -> bool:
        """
        Indicates if the device can currently be communicated with.
        
        :returns: true if the device is currently connected and responsive
        """
    def setGain(self, gain: ColorSensorV3.GainFactor) -> None:
        """
        Set the gain factor applied to color ADC measurements.
        
        By default, the gain is set to 3x.
        
        :param gain: Gain factor applied to color ADC measurements
                     measurements
        """
class DetachedEncoder(RelativeEncoder, DetachedEncoderLowLevel):
    class Faults:
        canRx: bool
        canTx: bool
        eeprom: bool
        hasReset: bool
        unexpected: bool
        def __init__(self) -> None:
            ...
        @property
        def rawBits(self) -> int:
            ...
        @rawBits.setter
        def rawBits(self, arg0: typing.SupportsInt) -> None:
            ...
    def __init__(self, deviceID: typing.SupportsInt, model: DetachedEncoderLowLevel.EncoderModel) -> None:
        """
        Create a new object to control a Detached Encoder
        
        :param deviceID: The device ID.
        :param model:    The specific model of detached encoder
        """
    def clearFaults(self) -> REVLibError:
        """
        Clears all sticky faults.
        """
    def configure(self, config: DetachedEncoderConfig, resetMode: ResetMode) -> REVLibError:
        """
        Set the configuration for the Detached encoder.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration.
        
        :param config:    The desired Detached encoder configuration
        :param resetMode: Whether to reset safe parameters before setting the
                          configuration
        
        :returns: REVLibError::kOk if successful
        """
    def getAngle(self) -> float:
        """
        Get the absolute position of the encoder. This returns the native units
        of 'rotations' [0, 1) by default, and can be changed by a scale factor
        using DetachedEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the encoder
        """
    def getFaults(self) -> DetachedEncoder.Faults:
        """
        Get the active faults that are currently present on the detached encoder.
        
        :returns: A struct with each fault and their active value
        """
    def getPosition(self) -> float:
        """
        Get the position of the encoder. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using DetachedEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the encoder
        """
    def getRawAngle(self) -> float:
        """
        Get the absolute position of the encoder. This returns the native units
        of 'rotations' [0, 1) without scaling from conversion factors.
        
        :returns: Number of rotations of the encoder
        """
    def getStickyFaults(self) -> DetachedEncoder.Faults:
        """
        Get the sticky faults that were present on the detached encoder at one
        point since the sticky faults were last cleared.
        
        Sticky faults can be cleared with DetachedEncoder::ClearFaults().
        
        :returns: A struct with each fault and their sticky value
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the encoder. This returns the native units
        of 'RPM' by default, and can be changed by a scale factor
        using DetachedEncoderConfig::VelocityConversionFactor().
        
        :returns: Number the RPM of the encoder
        """
    def setPosition(self, position: typing.SupportsFloat) -> REVLibError:
        """
        Set the position of the encoder.
        
        :param position: Number of rotations of the encoder
        
        :returns: REVLibError::kOk if successful
        """
    @property
    def configAccessor(self) -> DetachedEncoderConfigAccessor:
        """
        Accessor for Detached encoder parameter values. This object contains
        fields and methods to retrieve parameters that have been applied to the
        device. To set parameters, see DetachedEncoderConfig and
        DetachedEncoder::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and should
        be used infrequently.
        """
class DetachedEncoderConfig(BaseConfig):
    def __init__(self) -> None:
        ...
    def angleConversionFactor(self, factor: typing.SupportsFloat) -> DetachedEncoderConfig:
        """
        Set the conversion factor for the angle of the encoder. Angle is
        returned in native units of rotations and will be multiplied by this
        conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified DetachedEncoderConfig object for method chaining
        """
    def apply(self, config: DetachedEncoderConfig) -> DetachedEncoderConfig:
        """
        Applies settings from another DetachedEncoderConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The DetachedEncoderConfig to copy settings from
        
        :returns: The updated DetachedEncoderConfig for method chaining
        """
    def inverted(self, inverted: bool) -> DetachedEncoderConfig:
        """
        Set the phase of the encoder.
        
        :param inverted: The phase of the encoder
        
        :returns: The modified DetachedEncoderConfig object for method chaining
        """
    def positionConversionFactor(self, factor: typing.SupportsFloat) -> DetachedEncoderConfig:
        """
        Set the conversion factor for the position of the encoder. Position is
        returned in native units of rotations and will be multiplied by this
        conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified DetachedEncoderConfig object for method chaining
        """
    def velocityAverageDepth(self, depth: typing.SupportsInt) -> DetachedEncoderConfig:
        """
        Set the sampling depth of the velocity calculation process of the
        encoder. This value sets the number of samples in the average for
        velocity readings. This value must be in the range [1, 64].
        The default value is 64.
        
        :param depth: The velocity calculation process's sampling depth
        
        :returns: The modified DetachedEncoderConfig object for method chaining
        """
    def velocityConversionFactor(self, factor: typing.SupportsFloat) -> DetachedEncoderConfig:
        """
        Set the conversion factor for the velocity of the encoder. Velocity is
        returned in native units of rotations per minute and will be multiplied
        by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified DetachedEncoderConfig object for method chaining
        """
    def zeroCentered(self, zeroCentered: bool) -> DetachedEncoderConfig:
        """
        Set whether to enable zero-centering when using the absolute angle. If
        enabled, the position will be reported in the range (-0.5, 0.5], instead
        of the default range [0, 1), assuming the default units of rotations.
        
        :param zeroCentered: Whether to enable zero centering
        
        :returns: The modified DetachedEncoderConfig object for method
                  chaining
        """
    def zeroOffset(self, offset: typing.SupportsFloat) -> DetachedEncoderConfig:
        """
        Set the zero offset when using the absolute angle, the position that is
        reported as zero.
        
        The zero offset is specified as the reported position of the encoder
        in the desired zero position as if the zero offset was set to 0, the
        position conversion factor was set to 1, and inverted was set to false.
        
        :param offset: The zero offset in the range [0, 1)
        
        :returns: The modified DetachedEncoderConfig object for method
                  chaining
        """
    @property
    def signals(self) -> DetachedSignalsConfig:
        ...
class DetachedEncoderConfigAccessor:
    def getAngleConversionFactor(self) -> float:
        ...
    def getInverted(self) -> bool:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocityAverageDepth(self) -> int:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroCentered(self) -> bool:
        ...
    def getZeroOffset(self) -> float:
        ...
class DetachedEncoderLowLevel:
    class EncoderModel:
        """
        Members:
        
          kUnknown
        
          kMAXSplineEncoder
        """
        __members__: typing.ClassVar[dict[str, DetachedEncoderLowLevel.EncoderModel]]  # value = {'kUnknown': <EncoderModel.kUnknown: 0>, 'kMAXSplineEncoder': <EncoderModel.kMAXSplineEncoder: 1>}
        kMAXSplineEncoder: typing.ClassVar[DetachedEncoderLowLevel.EncoderModel]  # value = <EncoderModel.kMAXSplineEncoder: 1>
        kUnknown: typing.ClassVar[DetachedEncoderLowLevel.EncoderModel]  # value = <EncoderModel.kUnknown: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class FirmwareVersion:
        def __init__(self) -> None:
            ...
        @property
        def fix(self) -> int:
            ...
        @fix.setter
        def fix(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def hardwareMajor(self) -> int:
            ...
        @hardwareMajor.setter
        def hardwareMajor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def hardwareMinor(self) -> int:
            ...
        @hardwareMinor.setter
        def hardwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def minor(self) -> int:
            ...
        @minor.setter
        def minor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def prerelease(self) -> int:
            ...
        @prerelease.setter
        def prerelease(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def year(self) -> int:
            ...
        @year.setter
        def year(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus0:
        model: DetachedEncoderLowLevel.EncoderModel
        def __init__(self) -> None:
            ...
    class PeriodicStatus1:
        canRxFault: bool
        canTxFault: bool
        eepromFault: bool
        hasResetFault: bool
        stickyCanRxFault: bool
        stickyCanTxFault: bool
        stickyEepromFault: bool
        stickyHasResetFault: bool
        stickyUnexpectedFault: bool
        unexpectedFault: bool
        def __init__(self) -> None:
            ...
    class PeriodicStatus2:
        def __init__(self) -> None:
            ...
        @property
        def angle(self) -> float:
            ...
        @angle.setter
        def angle(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def rawAngle(self) -> float:
            ...
        @rawAngle.setter
        def rawAngle(self, arg0: typing.SupportsFloat) -> None:
            ...
    class PeriodicStatus3:
        def __init__(self) -> None:
            ...
        @property
        def position(self) -> float:
            ...
        @position.setter
        def position(self, arg0: typing.SupportsFloat) -> None:
            ...
    class PeriodicStatus4:
        def __init__(self) -> None:
            ...
        @property
        def velocity(self) -> float:
            ...
        @velocity.setter
        def velocity(self, arg0: typing.SupportsFloat) -> None:
            ...
    def __init__(self, deviceID: typing.SupportsInt, model: DetachedEncoderLowLevel.EncoderModel) -> None:
        ...
    def createSimFaultManager(self) -> None:
        """
        Create the sim gui Fault Manager for this Detached Encoder device
        """
    def getDeviceId(self) -> int:
        """
        Get the configured Device ID of the Detached encoder.
        
        :returns: int device ID
        """
    def getEncoderModel(self) -> DetachedEncoderLowLevel.EncoderModel:
        """
        Get the Model of this Detached Encoder Device. Useful for determining
        if this is a MAXSpline, or other device
        
        :returns: the model of this encoder
        """
    def getFirmwareVersion(self) -> DetachedEncoderLowLevel.FirmwareVersion:
        """
        Get the firmware version of the detached encoder.
        
        :returns: Firmware version object
        """
    def getPeriodicStatus0(self) -> DetachedEncoderLowLevel.PeriodicStatus0:
        """
        Get Periodic Status 0 for the Detached Encoder.
        
        :returns: PeriodicStatus0 Periodic status 0
        """
    def getPeriodicStatus1(self) -> DetachedEncoderLowLevel.PeriodicStatus1:
        """
        Get Periodic Status 1 for the Detached Encoder.
        
        :returns: PeriodicStatus1 Periodic status 1
        """
    def getPeriodicStatus2(self) -> DetachedEncoderLowLevel.PeriodicStatus2:
        """
        Get Periodic Status 2 for the Detached Encoder.
        
        :returns: PeriodicStatus2 Periodic status 2
        """
    def getPeriodicStatus3(self) -> DetachedEncoderLowLevel.PeriodicStatus3:
        """
        Get Periodic Status 3 for the Detached Encoder.
        
        :returns: PeriodicStatus3 Periodic status 3
        """
    def getPeriodicStatus4(self) -> DetachedEncoderLowLevel.PeriodicStatus4:
        """
        Get Periodic Status 4 for the Detached Encoder.
        
        :returns: PeriodicStatus4 Periodic status 4
        """
class DetachedEncoderSim:
    def __init__(self, encoder: DetachedEncoder) -> None:
        ...
    def getAngle(self) -> float:
        ...
    def getInverted(self) -> bool:
        ...
    def getPosition(self) -> float:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getRawAngle(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroOffset(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setAngle(self, angle: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setRawAngle(self, rawAngle: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def setZeroOffset(self, zeroOffset: typing.SupportsFloat) -> None:
        ...
class DetachedSignalsConfig(BaseConfig):
    def __init__(self) -> None:
        ...
    def apply(self, config: DetachedSignalsConfig) -> DetachedSignalsConfig:
        """
        Applies settings from another SignalsConfig to this one.
        
        Settings in the provided config will overwrite existing values in
        this object. Settings not specified in the provided config remain
        unchanged.
        
        :param config: The SignalsConfig to copy settings from
        
        :returns: The updated SignalsConfig for method chaining
        """
    def encoderAnglePeriodMs(self, period_ms: typing.SupportsInt) -> DetachedSignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal
        returned by DetachedEncoder::GetAngle(). The default period
        is 50ms.
        
        If multiple periods are set for signals within the same status
        frame, the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def encoderPositionPeriodMs(self, period_ms: typing.SupportsInt) -> DetachedSignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal
        returned by DetachedEncoder::GetPosition(). The default period
        is 50ms.
        
        If multiple periods are set for signals within the same status
        frame, the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def encoderVelocityPeriodMs(self, period_ms: typing.SupportsInt) -> DetachedSignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal
        returned by DetachedEncoder::GetVelocity(). The default period
        is 50ms.
        
        If multiple periods are set for signals within the same status
        frame, the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
class EncoderConfig(BaseConfig):
    class Presets:
        @staticmethod
        def REV_SplineEncoder() -> EncoderConfig:
            """
            REV Robotics - MAXSpline Encoder (via 6-pin JST)
            """
        @staticmethod
        def REV_ThroughBoreEncoder() -> EncoderConfig:
            ...
        @staticmethod
        def REV_ThroughBoreEncoderV2() -> EncoderConfig:
            ...
        def __init__(self) -> None:
            ...
    def __init__(self) -> None:
        ...
    def apply(self, config: EncoderConfig) -> EncoderConfig:
        """
        Applies settings from another EncoderConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The EncoderConfig to copy settings from
        
        :returns: The updated EncoderConfig for method chaining
        """
    def countsPerRevolution(self, cpr: typing.SupportsInt) -> EncoderConfig:
        """
        Set the counts per revolutions of the encoder.
        
        NOTE: This only applies to an encoder used in brushed mode.
        
        :param cpr: The counts per rotation
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def inverted(self, inverted: bool) -> EncoderConfig:
        """
        Set the phase of the encoder so that it is in phase with the motor
        itself.
        
        NOTE: This only applies to an encoder used in brushed mode.
        
        :param inverted: The phase of the encoder
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def positionConversionFactor(self, factor: typing.SupportsFloat) -> EncoderConfig:
        """
        Set the conversion factor for the position of the encoder. Position is
        returned in native units of rotations and will be multiplied by this
        conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def quadratureAverageDepth(self, depth: typing.SupportsInt) -> EncoderConfig:
        """
        Set the sampling depth of the velocity calculation process of the
        encoder. This value sets the number of samples in the average for
        velocity readings. This value must be in the range [1, 64]. The default
        value is 64.
        
        :param depth: The velocity calculation process's sampling depth
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def quadratureMeasurementPeriod(self, periodMs: typing.SupportsInt) -> EncoderConfig:
        """
        Set the position measurement period used to calculate the velocity of the
        encoder. This value is in units of milliseconds and must be in a range
        [1, 100]. The default value is 100ms
        
        The basic formula to calculate velocity is change in position / change
        in time. This parameter sets the change in time for measurement.
        
        :param periodMs: Measurement period in milliseconds
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def uvwAverageDepth(self, depth: typing.SupportsInt) -> EncoderConfig:
        """
        Set the sampling depth of the velocity calculation process of the
        encoder. This value sets the number of samples in the average for
        velocity readings. This value must be either 1, 2, 4, or 8 (default).
        
        :param depth: The velocity calculation process's sampling depth
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def uvwMeasurementPeriod(self, periodMs: typing.SupportsInt) -> EncoderConfig:
        """
        Set the position measurement period used to calculate the velocity of the
        encoder. This value is in units of milliseconds and must be in a range
        [8, 64]. The default value is 32ms.
        
        The basic formula to calculate velocity is change in position / change
        in time. This parameter sets the change in time for measurement.
        
        :param periodMs: Measurement period in milliseconds
        
        :returns: The modified EncoderConfig object for method chaining
        """
    def velocityConversionFactor(self, factor: typing.SupportsFloat) -> EncoderConfig:
        """
        Set the conversion factor for the velocity of the encoder. Velocity is
        returned in native units of rotations per minute and will be multiplied
        by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified EncoderConfig object for method chaining
        """
class EncoderConfigAccessor:
    def getCountsPerRevolution(self) -> int:
        ...
    def getInverted(self) -> bool:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getQuadratureAverageDepth(self) -> int:
        ...
    def getQuadratureMeasurementPeriod(self) -> int:
        ...
    def getUvwAverageDepth(self) -> int:
        ...
    def getUvwMeasurementPeriod(self) -> int:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
class ExternalEncoderConfig(BaseConfig):
    class Presets:
        @staticmethod
        def REV_SplineEncoder() -> ExternalEncoderConfig:
            """
            REV Robotics - MAXSpline Encoder (via 6-pin JST)
            """
        @staticmethod
        def REV_ThroughBoreEncoder() -> ExternalEncoderConfig:
            ...
        @staticmethod
        def REV_ThroughBoreEncoderV2() -> ExternalEncoderConfig:
            ...
        def __init__(self) -> None:
            ...
    class Type:
        """
        Members:
        
          kQuadrature
        """
        __members__: typing.ClassVar[dict[str, ExternalEncoderConfig.Type]]  # value = {'kQuadrature': <Type.kQuadrature: 0>}
        kQuadrature: typing.ClassVar[ExternalEncoderConfig.Type]  # value = <Type.kQuadrature: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    @staticmethod
    def fromId(id: typing.SupportsInt) -> ExternalEncoderConfig.Type:
        ...
    def __init__(self) -> None:
        ...
    def apply(self, config: ExternalEncoderConfig) -> ExternalEncoderConfig:
        """
        Applies settings from another ExternalEncoderConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The ExternalEncoderConfig to copy settings from
        
        :returns: The updated ExternalEncoderConfig for method chaining
        """
    def averageDepth(self, depth: typing.SupportsInt) -> ExternalEncoderConfig:
        """
        Set the sampling depth of the velocity calculation process of the
        External encoder. This value sets the number of samples in the average
        for velocity readings. For a quadrature encoder, this can be any value
        from 1 to 64 (default).
        
        :param depth: The velocity calculation process's sampling depth
        
        :returns: The modified ExternalEncoderConfig object for method
                  chaining
        """
    def countsPerRevolution(self, cpr: typing.SupportsInt) -> ExternalEncoderConfig:
        """
        Set the counts per revolutions of the External encoder.
        
        :param cpr: The counts per rotation
        
        :returns: The modified ExternalEncoderConfig object for method
                  chaining
        """
    def inverted(self, inverted: bool) -> ExternalEncoderConfig:
        """
        Set the phase of the External encoder so that it is in phase with the
        motor itself.
        
        :param inverted: The phase of the encoder
        
        :returns: The modified ExternalEncoderConfig object for method
                  chaining
        """
    def measurementPeriod(self, periodMs: typing.SupportsInt) -> ExternalEncoderConfig:
        """
        Set the position measurement period used to calculate the velocity of the
        External encoder. For a quadrature encoder, this number may be between 1
        and 100 (default).
        
        The basic formula to calculate velocity is change in position / change
        in time. This parameter sets the change in time for measurement.
        
        :param periodMs: Measurement period in milliseconds
        
        :returns: The modified ExternalEncoderConfig object for method
                  chaining
        """
    def positionConversionFactor(self, factor: typing.SupportsFloat) -> ExternalEncoderConfig:
        """
        Set the conversion factor for the position of the External encoder.
        Position is returned in native units of rotations and will be multiplied
        by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified ExternalEncoderConfig object for method
                  chaining
        """
    def velocityConversionFactor(self, factor: typing.SupportsFloat) -> ExternalEncoderConfig:
        """
        Set the conversion factor for the velocity of the External encoder.
        Velocity is returned in native units of rotations per minute and will be
        multiplied by this conversion factor.
        
        :param factor: The conversion factor to multiply the native units by
        
        :returns: The modified ExternalEncoderConfig object for method
                  chaining
        """
class ExternalEncoderConfigAccessor:
    def getAverageDepth(self) -> int:
        ...
    def getCountsPerRevolution(self) -> int:
        ...
    def getInverted(self) -> bool:
        ...
    def getMeasurementPeriod(self) -> int:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
class FeedForwardConfig(BaseConfig):
    def __init__(self) -> None:
        ...
    def apply(self, config: FeedForwardConfig) -> FeedForwardConfig:
        """
        Applies settings from another :class:`.FeedForwardConfig` to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The :class:`.FeedForwardConfig` to copy settings from
        
        :returns: The updated :class:`.FeedForwardConfig` for method chaining
        """
    def kA(self, kA: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kA Acceleration Gain of the controller for a specific closed loop
        slot.
        
        This is only applied in MAXMotion control modes
        
        :param kA:   The kA gain in Volts
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def kCos(self, kCos: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kCos Cosine Gravity Gain of the controller for a specific closed
        loop slot.
        
        This is multiplied by the cosine of the absolute position of the
        mechanism (See {@link FeedForwardConfig#kCosRatio(double kCosRatio,
        ClosedLoopSlot slot)} for info on configuring this) for an arm mechanism.
        Set it to 0 if kG is being used.
        
        This is only applied in Position and MAXMotion Position control modes
        
        :param kCos: The kCos gain in Volts
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def kCosRatio(self, kCosRatio: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kCosRatio of the controller for a specific closed loop slot.
        
        This sets the ratio that is used to calculate the absolute position of
        your arm mechanism for use with kCos. This is applied after the
        conversion factor and should convert from those units to absolute
        rotations of your mechanism. Ensure your selected encoder is zeroed such
        that 0 = horizontal.
        
        :param kCosRatio: The kCosRatio in Volts
        :param slot:      The closed loop slot to set the values for
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def kG(self, kG: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kG Static Gravity Gain of the controller for a specific closed
        loop slot.
        
        This is statically applied, for an elevator or linear mechanism. Set
        it to 0 if kCos is being used.
        
        This is only applied in Position and MAXMotion Position control modes
        
        :param kG:   The kG gain in Volts
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def kS(self, kS: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS Static Gain of the controller for a specific closed loop slot.
        
        :param kS:   The kS gain in Volts
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def kV(self, kV: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kV Velocity Gain of the controller for a specific closed loop
        slot.
        
        This is not applied in Position control mode.
        
        :param kV:   The kV gain in Volts
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def scr(self, kS: typing.SupportsFloat, kCos: typing.SupportsFloat, kCosRatio: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS, kCos, and kCosRatio gains for the provided slot in one call.
        
        For more information on the kS, kCos, and kCosRatio gains, see {@link
        FeedForwardConfig#kS(double)},
        :meth:`.FeedForwardConfig.kCos`, and {@link
        FeedForwardConfig#kCosRatio(double)}.
        
        :param kS:        The kS gain in Volts
        :param kCos:      The kCos gain in Volts
        :param kCosRatio: The ratio used to calculate the absolute position of
                          your arm mechanism for use with kCos
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def sg(self, kS: typing.SupportsFloat, kG: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS and kG gains for the provided slot in one call.
        
        For more information on the kS and kG gains, see {@link
        FeedForwardConfig#kS(double)} and
        :meth:`.FeedForwardConfig.kG`.
        
        :param kS: The kS gain in Volts
        :param kG: The kG gain in Volts
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def sv(self, kS: typing.SupportsFloat, kV: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS and kV gains for the provided slot in one call.
        
        For more information on the kS and kV gains, see {@link
        FeedForwardConfig#kS(double)} and
        :meth:`.FeedForwardConfig.kV`.
        
        :param kS: The kS gain in Volts
        :param kV: The kV gain in Volts per velocity
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def sva(self, kS: typing.SupportsFloat, kV: typing.SupportsFloat, kA: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS, kV, and kA gains for the provided slot in one call.
        
        For more information on the kS, kV, and kA gains, see {@link
        FeedForwardConfig#kS(double)},
        :meth:`.FeedForwardConfig.kV`, and {@link
        FeedForwardConfig#kA(double)}.
        
        :param kS: The kS gain in Volts
        :param kV: The kV gain in Volts per velocity
        :param kA: The kA gain in Volts per velocity per second
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def svacr(self, kS: typing.SupportsFloat, kV: typing.SupportsFloat, kA: typing.SupportsFloat, kCos: typing.SupportsFloat, kCosRatio: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS, kV, kA, kCos, and kCosRatio gains for the provided slot in
        one call.
        
        For more information on the kS, kV, kA, kCos, and kCosRatio gains, see
        :meth:`.FeedForwardConfig.kS`, {@link
        FeedForwardConfig#kV(double)}, :meth:`.FeedForwardConfig.kA`,
        :meth:`.FeedForwardConfig.kCos`, and {@link
        FeedForwardConfig#kCosRatio(double)}.
        
        :param kS:        The kS gain in Volts
        :param kV:        The kV gain in Volts per velocity
        :param kA:        The kA gain in Volts per velocity per second
        :param kCos:      The kCos gain in Volts
        :param kCosRatio: The ratio used to calculate the absolute position of
                          your arm mechanism for use with kCos
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
    def svag(self, kS: typing.SupportsFloat, kV: typing.SupportsFloat, kA: typing.SupportsFloat, kG: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> FeedForwardConfig:
        """
        Set the kS, kV, kA, and kG gains for the provided slot in one call.
        
        For more information on the kS, kV, kA, and kG gains, see {@link
        FeedForwardConfig#kS(double)},
        :meth:`.FeedForwardConfig.kV`, {@link
        FeedForwardConfig#kA(double)}, and
        :meth:`.FeedForwardConfig.kG`.
        
        :param kS: The kS gain in Volts
        :param kV: The kV gain in Volts per velocity
        :param kA: The kA gain in Volts per velocity per second
        :param kG: The kG gain in Volts
        
        :returns: The modified :class:`.FeedForwardConfig` object for method chaining
        """
class FeedForwardConfigAccessor:
    def getkA(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getkCos(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getkCosRatio(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getkG(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getkS(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getkV(self, slot: ClosedLoopSlot = ...) -> float:
        ...
class FeedbackSensor:
    """
    Members:
    
      kNoSensor
    
      kPrimaryEncoder
    
      kAnalogSensor
    
      kAlternateOrExternalEncoder
    
      kAbsoluteEncoder
    
      kDetachedAbsoluteEncoder
    
      kDetachedRelativeEncoder
    """
    __members__: typing.ClassVar[dict[str, FeedbackSensor]]  # value = {'kNoSensor': <FeedbackSensor.kNoSensor: 0>, 'kPrimaryEncoder': <FeedbackSensor.kPrimaryEncoder: 1>, 'kAnalogSensor': <FeedbackSensor.kAnalogSensor: 2>, 'kAlternateOrExternalEncoder': <FeedbackSensor.kAlternateOrExternalEncoder: 3>, 'kAbsoluteEncoder': <FeedbackSensor.kAbsoluteEncoder: 4>, 'kDetachedAbsoluteEncoder': <FeedbackSensor.kDetachedAbsoluteEncoder: 5>, 'kDetachedRelativeEncoder': <FeedbackSensor.kDetachedRelativeEncoder: 6>}
    kAbsoluteEncoder: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kAbsoluteEncoder: 4>
    kAlternateOrExternalEncoder: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kAlternateOrExternalEncoder: 3>
    kAnalogSensor: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kAnalogSensor: 2>
    kDetachedAbsoluteEncoder: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kDetachedAbsoluteEncoder: 5>
    kDetachedRelativeEncoder: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kDetachedRelativeEncoder: 6>
    kNoSensor: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kNoSensor: 0>
    kPrimaryEncoder: typing.ClassVar[FeedbackSensor]  # value = <FeedbackSensor.kPrimaryEncoder: 1>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class LimitSwitchConfig(BaseConfig):
    class Behavior:
        """
        Members:
        
          kKeepMovingMotor
        
          kStopMovingMotor
        
          kKeepMovingMotorAndSetPosition
        
          kStopMovingMotorAndSetPosition
        """
        __members__: typing.ClassVar[dict[str, LimitSwitchConfig.Behavior]]  # value = {'kKeepMovingMotor': <Behavior.kKeepMovingMotor: 0>, 'kStopMovingMotor': <Behavior.kStopMovingMotor: 1>, 'kKeepMovingMotorAndSetPosition': <Behavior.kKeepMovingMotorAndSetPosition: 2>, 'kStopMovingMotorAndSetPosition': <Behavior.kStopMovingMotorAndSetPosition: 3>}
        kKeepMovingMotor: typing.ClassVar[LimitSwitchConfig.Behavior]  # value = <Behavior.kKeepMovingMotor: 0>
        kKeepMovingMotorAndSetPosition: typing.ClassVar[LimitSwitchConfig.Behavior]  # value = <Behavior.kKeepMovingMotorAndSetPosition: 2>
        kStopMovingMotor: typing.ClassVar[LimitSwitchConfig.Behavior]  # value = <Behavior.kStopMovingMotor: 1>
        kStopMovingMotorAndSetPosition: typing.ClassVar[LimitSwitchConfig.Behavior]  # value = <Behavior.kStopMovingMotorAndSetPosition: 3>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Type:
        """
        Members:
        
          kNormallyOpen
        
          kNormallyClosed
        """
        __members__: typing.ClassVar[dict[str, LimitSwitchConfig.Type]]  # value = {'kNormallyOpen': <Type.kNormallyOpen: 0>, 'kNormallyClosed': <Type.kNormallyClosed: 1>}
        kNormallyClosed: typing.ClassVar[LimitSwitchConfig.Type]  # value = <Type.kNormallyClosed: 1>
        kNormallyOpen: typing.ClassVar[LimitSwitchConfig.Type]  # value = <Type.kNormallyOpen: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    def apply(self, config: LimitSwitchConfig) -> LimitSwitchConfig:
        """
        Applies settings from another LimitSwitchConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The LimitSwitchConfig to copy settings from
        
        :returns: The updated LimitSwitchConfig for method chaining
        """
    def forwardLimitSwitchEnabled(self, enabled: bool) -> LimitSwitchConfig:
        """
        Set whether to enable/disable motor shutdown based on the forward
        limit switch state.
        This does not not affect the result of the isPressed() command.
        
        :deprecated: Use
                     LimitSwitchConfig::ForwardLimitSwitchTriggerBehavior(Behavior) instead
        
        :param enabled: True for halting the motor when triggered
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def forwardLimitSwitchPosition(self, position: typing.SupportsFloat) -> LimitSwitchConfig:
        """
        Set the triggered position value of the forward limit switch (used
        when the enable mode is set to kEnabled_SetValueOnTrigger).
        
        :param position: user specified position value
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def forwardLimitSwitchTriggerBehavior(self, behavior: LimitSwitchConfig.Behavior) -> LimitSwitchConfig:
        """
        Set the trigger behavior based on the forward limit switch state.
        This does not not affect the result of the isPressed() command.
        
        :param behavior: The trigger behavior
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def forwardLimitSwitchType(self, type: LimitSwitchConfig.Type) -> LimitSwitchConfig:
        """
        Set the normal state of the forward limit switch.
        
        :param type: kNormallyOpen or kNormallyClosed
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def limitSwitchPositionSensor(self, sensor: FeedbackSensor) -> LimitSwitchConfig:
        """
        Specifies the feedback sensor that the triggered position value is
        set on. This applies for both forward and reverse limit switches.
        
        :param sensor: The feedback sensor to set the position value on
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def reverseLimitSwitchEnabled(self, enabled: bool) -> LimitSwitchConfig:
        """
        Set whether to enable/disable motor shutdown based on the reverse
        limit switch state.
        This does not not affect the result of the isPressed() command.
        
        :deprecated: Use
                     LimitSwitchConfig::ReverseLimitSwitchTriggerBehavior(Behavior) instead
        
        :param enabled: True for halting the motor when triggered
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def reverseLimitSwitchPosition(self, position: typing.SupportsFloat) -> LimitSwitchConfig:
        """
        Set the triggered position value of the reverse limit switch (used
        when the enable mode is set to kEnabled_SetValueOnTrigger).
        
        :param position: user specified position value
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def reverseLimitSwitchTriggerBehavior(self, behavior: LimitSwitchConfig.Behavior) -> LimitSwitchConfig:
        """
        Set the trigger behavior based on the reverse limit switch state.
        This does not not affect the result of the isPressed() command.
        
        :param behavior: The trigger behavior
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def reverseLimitSwitchType(self, type: LimitSwitchConfig.Type) -> LimitSwitchConfig:
        """
        Set the normal state of the reverse limit switch.
        
        :param type: kNormallyOpen or kNormallyClosed
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
    def setSparkMaxDataPortConfig(self) -> LimitSwitchConfig:
        """
        Configures the data port to use limit switches, which is specifically
        required for SPARK MAX.
        
        NOTE: This method is only necessary when using limit switches with a
        SPARK MAX without configuring any of its settings
        
        IMPORTANT: SPARK MAX does not support using limit switches in
        conjunction with an alternate encoder.
        
        :returns: The modified LimitSwitchConfig object for method chaining
        """
class LimitSwitchConfigAccessor:
    def getForwardLimitSwitchEnabled(self) -> bool:
        ...
    def getForwardLimitSwitchPosition(self) -> float:
        ...
    def getForwardLimitSwitchTriggerBehavior(self) -> LimitSwitchConfig.Behavior:
        ...
    def getForwardSwitchType(self) -> LimitSwitchConfig.Type:
        ...
    def getReverseLimitSwitchEnabled(self) -> bool:
        ...
    def getReverseLimitSwitchPosition(self) -> float:
        ...
    def getReverseLimitSwitchTriggerBehavior(self) -> LimitSwitchConfig.Behavior:
        ...
    def getReverseSwitchType(self) -> LimitSwitchConfig.Type:
        ...
class MAXMotionConfig(BaseConfig):
    class MAXMotionPositionMode:
        """
        Members:
        
          kMAXMotionTrapezoidal
        """
        __members__: typing.ClassVar[dict[str, MAXMotionConfig.MAXMotionPositionMode]]  # value = {'kMAXMotionTrapezoidal': <MAXMotionPositionMode.kMAXMotionTrapezoidal: 0>}
        kMAXMotionTrapezoidal: typing.ClassVar[MAXMotionConfig.MAXMotionPositionMode]  # value = <MAXMotionPositionMode.kMAXMotionTrapezoidal: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    def allowedClosedLoopError(self, allowedError: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> MAXMotionConfig:
        """
        Set the allowed profile error for the MAXMotion mode of the controller
        for a specific PID slot. This value is how much deviation from the
        profile is tolerated before the profile is regenerated. Natively, the
        units are in rotations but will be affected by the position conversion
        factor.
        
        :deprecated: Use MAXMotionConfig::AllowedProfileError instead
        
        :param allowedError: The allowed error with the position conversion factor
                             applied
        :param slot:         The closed loop slot to set the values for
        
        :returns: The modified MAXMotionConfig object for method chaining
        """
    def allowedProfileError(self, allowedError: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> MAXMotionConfig:
        """
        Set the allowed profile error for the MAXMotion mode of the controller
        for a specific PID slot. This value is how much deviation from the
        profile is tolerated before the profile is regenerated. Natively, the
        units are in rotations but will be affected by the position conversion
        factor.
        
        :param allowedError: The allowed error with the position conversion factor
                             applied
        :param slot:         The closed loop slot to set the values for
        
        :returns: The modified MAXMotionConfig object for method chaining
        """
    def apply(self, config: MAXMotionConfig) -> MAXMotionConfig:
        """
        Applies settings from another MAXMotionConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The MAXMotionConfig to copy settings from
        
        :returns: The updated MAXMotionConfig for method chaining
        """
    def cruiseVelocity(self, cruiseVelocity: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> MAXMotionConfig:
        """
        Set the cruise velocity for the MAXMotion mode of the controller for a
        specific closed loop slot. Natively, the units are in RPM but will be
        affected by the velocity conversion factor.
        
        :param maxVelocity: The maximum velocity with the velocity conversion
                            factor applied
        :param slot:        The closed loop slot to set the values for
        
        :returns: The modified MAXMotionConfig object for method chaining
        """
    def maxAcceleration(self, maxAcceleration: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> MAXMotionConfig:
        """
        Set the maximum acceleration for the MAXMotion mode of the controller for
        a specific closed loop slot. This is the rate at which the velocity will
        increase until the max velocity is reached. Natively, the units are in
        RPM per second but will be affected by the velocity conversion factor.
        
        :param maxAcceleration: The maximum acceleration with the velocity
                                conversion factor applied
        :param slot:            The closed loop slot to set the values for
        
        :returns: The modified MAXMotionConfig object for method chaining
        """
    def maxVelocity(self, maxVelocity: typing.SupportsFloat, slot: ClosedLoopSlot = ...) -> MAXMotionConfig:
        """
        Set the cruise velocity for the MAXMotion mode of the controller for a
        specific closed loop slot. Natively, the units are in RPM but will be
        affected by the velocity conversion factor.
        
        :deprecated: Use MAXMotionConfig::CruiseVelocity instead
        
        :param maxVelocity: The maximum velocity with the velocity conversion
                            factor applied
        :param slot:        The closed loop slot to set the values for
        
        :returns: The modified MAXMotionConfig object for method chaining
        """
    def positionMode(self, mode: MAXMotionConfig.MAXMotionPositionMode, slot: ClosedLoopSlot = ...) -> MAXMotionConfig:
        """
        Set the MAXMotion position control mode of the controller for a specific
        closed loop slot.
        
        :param mode: The MAXmotion position mode
        :param slot: The closed loop slot to set the values for
        
        :returns: The modified MAXMotionConfig object for method chaining
        """
class MAXMotionConfigAccessor:
    def getAllowedClosedLoopError(self, slot: ClosedLoopSlot = ...) -> float:
        """
        :deprecated: Use GetAllowedProfileError instead
        """
    def getAllowedProfileError(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getCruiseVelocity(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getMaxAcceleration(self, slot: ClosedLoopSlot = ...) -> float:
        ...
    def getMaxVelocity(self, slot: ClosedLoopSlot = ...) -> float:
        """
        :deprecated: Use GetCruiseVelocity instead
        """
    def getPositionMode(self, slot: ClosedLoopSlot = ...) -> MAXMotionConfig.MAXMotionPositionMode:
        ...
class MovingAverageFilterSim:
    def __init__(self, taps: typing.SupportsInt, sampleRate: typing.SupportsFloat) -> None:
        ...
    def get(self) -> float:
        ...
    def put(self, value: typing.SupportsFloat, delta: typing.SupportsFloat) -> None:
        ...
class NoiseGenerator:
    @staticmethod
    def hallSensorVelocity(speedRPM: typing.SupportsFloat) -> float:
        ...
    @staticmethod
    def whiteNoise(input: typing.SupportsFloat, variance: typing.SupportsFloat) -> float:
        ...
    def __init__(self) -> None:
        ...
class PersistMode:
    """
    Members:
    
      kNoPersistParameters
    
      kPersistParameters
    """
    __members__: typing.ClassVar[dict[str, PersistMode]]  # value = {'kNoPersistParameters': <PersistMode.kNoPersistParameters: 0>, 'kPersistParameters': <PersistMode.kPersistParameters: 1>}
    kNoPersistParameters: typing.ClassVar[PersistMode]  # value = <PersistMode.kNoPersistParameters: 0>
    kPersistParameters: typing.ClassVar[PersistMode]  # value = <PersistMode.kPersistParameters: 1>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class REVLibError:
    """
    Members:
    
      kOk
    
      kError
    
      kTimeout
    
      kNotImplemented
    
      kHALError
    
      kCantFindFirmware
    
      kFirmwareTooOld
    
      kFirmwareTooNew
    
      kParamInvalidID
    
      kParamMismatchType
    
      kParamAccessMode
    
      kParamInvalid
    
      kParamNotImplementedDeprecated
    
      kFollowConfigMismatch
    
      kInvalid
    
      kSetpointOutOfRange
    
      kUnknown
    
      kCANDisconnected
    
      kDuplicateCANId
    
      kInvalidCANId
    
      kSparkMaxDataPortAlreadyConfiguredDifferently
    
      kSparkFlexBrushedWithoutDock
    
      kInvalidBrushlessEncoderConfiguration
    
      kFeedbackSensorIncompatibleWithDataPortConfig
    
      kParamInvalidChannel
    
      kParamInvalidValue
    
      kCannotPersistParametersWhileEnabled
    """
    __members__: typing.ClassVar[dict[str, REVLibError]]  # value = {'kOk': <REVLibError.kOk: 0>, 'kError': <REVLibError.kError: 1>, 'kTimeout': <REVLibError.kTimeout: 2>, 'kNotImplemented': <REVLibError.kNotImplemented: 3>, 'kHALError': <REVLibError.kHALError: 4>, 'kCantFindFirmware': <REVLibError.kCantFindFirmware: 5>, 'kFirmwareTooOld': <REVLibError.kFirmwareTooOld: 6>, 'kFirmwareTooNew': <REVLibError.kFirmwareTooNew: 7>, 'kParamInvalidID': <REVLibError.kParamInvalidID: 8>, 'kParamMismatchType': <REVLibError.kParamMismatchType: 9>, 'kParamAccessMode': <REVLibError.kParamAccessMode: 10>, 'kParamInvalid': <REVLibError.kParamInvalid: 11>, 'kParamNotImplementedDeprecated': <REVLibError.kParamNotImplementedDeprecated: 12>, 'kFollowConfigMismatch': <REVLibError.kFollowConfigMismatch: 13>, 'kInvalid': <REVLibError.kInvalid: 14>, 'kSetpointOutOfRange': <REVLibError.kSetpointOutOfRange: 15>, 'kUnknown': <REVLibError.kUnknown: 16>, 'kCANDisconnected': <REVLibError.kCANDisconnected: 17>, 'kDuplicateCANId': <REVLibError.kDuplicateCANId: 18>, 'kInvalidCANId': <REVLibError.kInvalidCANId: 19>, 'kSparkMaxDataPortAlreadyConfiguredDifferently': <REVLibError.kSparkMaxDataPortAlreadyConfiguredDifferently: 20>, 'kSparkFlexBrushedWithoutDock': <REVLibError.kSparkFlexBrushedWithoutDock: 21>, 'kInvalidBrushlessEncoderConfiguration': <REVLibError.kInvalidBrushlessEncoderConfiguration: 22>, 'kFeedbackSensorIncompatibleWithDataPortConfig': <REVLibError.kFeedbackSensorIncompatibleWithDataPortConfig: 23>, 'kParamInvalidChannel': <REVLibError.kParamInvalidChannel: 24>, 'kParamInvalidValue': <REVLibError.kParamInvalidValue: 25>, 'kCannotPersistParametersWhileEnabled': <REVLibError.kCannotPersistParametersWhileEnabled: 26>}
    kCANDisconnected: typing.ClassVar[REVLibError]  # value = <REVLibError.kCANDisconnected: 17>
    kCannotPersistParametersWhileEnabled: typing.ClassVar[REVLibError]  # value = <REVLibError.kCannotPersistParametersWhileEnabled: 26>
    kCantFindFirmware: typing.ClassVar[REVLibError]  # value = <REVLibError.kCantFindFirmware: 5>
    kDuplicateCANId: typing.ClassVar[REVLibError]  # value = <REVLibError.kDuplicateCANId: 18>
    kError: typing.ClassVar[REVLibError]  # value = <REVLibError.kError: 1>
    kFeedbackSensorIncompatibleWithDataPortConfig: typing.ClassVar[REVLibError]  # value = <REVLibError.kFeedbackSensorIncompatibleWithDataPortConfig: 23>
    kFirmwareTooNew: typing.ClassVar[REVLibError]  # value = <REVLibError.kFirmwareTooNew: 7>
    kFirmwareTooOld: typing.ClassVar[REVLibError]  # value = <REVLibError.kFirmwareTooOld: 6>
    kFollowConfigMismatch: typing.ClassVar[REVLibError]  # value = <REVLibError.kFollowConfigMismatch: 13>
    kHALError: typing.ClassVar[REVLibError]  # value = <REVLibError.kHALError: 4>
    kInvalid: typing.ClassVar[REVLibError]  # value = <REVLibError.kInvalid: 14>
    kInvalidBrushlessEncoderConfiguration: typing.ClassVar[REVLibError]  # value = <REVLibError.kInvalidBrushlessEncoderConfiguration: 22>
    kInvalidCANId: typing.ClassVar[REVLibError]  # value = <REVLibError.kInvalidCANId: 19>
    kNotImplemented: typing.ClassVar[REVLibError]  # value = <REVLibError.kNotImplemented: 3>
    kOk: typing.ClassVar[REVLibError]  # value = <REVLibError.kOk: 0>
    kParamAccessMode: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamAccessMode: 10>
    kParamInvalid: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamInvalid: 11>
    kParamInvalidChannel: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamInvalidChannel: 24>
    kParamInvalidID: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamInvalidID: 8>
    kParamInvalidValue: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamInvalidValue: 25>
    kParamMismatchType: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamMismatchType: 9>
    kParamNotImplementedDeprecated: typing.ClassVar[REVLibError]  # value = <REVLibError.kParamNotImplementedDeprecated: 12>
    kSetpointOutOfRange: typing.ClassVar[REVLibError]  # value = <REVLibError.kSetpointOutOfRange: 15>
    kSparkFlexBrushedWithoutDock: typing.ClassVar[REVLibError]  # value = <REVLibError.kSparkFlexBrushedWithoutDock: 21>
    kSparkMaxDataPortAlreadyConfiguredDifferently: typing.ClassVar[REVLibError]  # value = <REVLibError.kSparkMaxDataPortAlreadyConfiguredDifferently: 20>
    kTimeout: typing.ClassVar[REVLibError]  # value = <REVLibError.kTimeout: 2>
    kUnknown: typing.ClassVar[REVLibError]  # value = <REVLibError.kUnknown: 16>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class RelativeEncoder:
    def __init__(self) -> None:
        ...
    def getPosition(self) -> float:
        """
        Get the position of the motor. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using EncoderConfig::PositionConversionFactor(),
        or AlternateEncoderConfig::PositionConversionFactor(), or
        ExternalEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the motor
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the motor. This returns the native units
        of 'RPM' by default, and can be changed by a scale factor
        using EncoderConfig::VelocityConversionFactor(), or
        AlternateEncoderConfig::VelocityConversionFactor(), or
        ExternalEncoderConfig::VelocityConversionFactor().
        
        :returns: The RPM of the motor
        """
    def setPosition(self, position: typing.SupportsFloat) -> REVLibError:
        """
        Set the position of the encoder.
        
        :param position: Number of rotations of the motor
        
        :returns: REVLibError::kOk if successful
        """
class ResetMode:
    """
    Members:
    
      kNoResetSafeParameters
    
      kResetSafeParameters
    """
    __members__: typing.ClassVar[dict[str, ResetMode]]  # value = {'kNoResetSafeParameters': <ResetMode.kNoResetSafeParameters: 0>, 'kResetSafeParameters': <ResetMode.kResetSafeParameters: 1>}
    kNoResetSafeParameters: typing.ClassVar[ResetMode]  # value = <ResetMode.kNoResetSafeParameters: 0>
    kResetSafeParameters: typing.ClassVar[ResetMode]  # value = <ResetMode.kResetSafeParameters: 1>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ServoChannel:
    class ChannelId:
        """
        Members:
        
          kChannelId0
        
          kChannelId1
        
          kChannelId2
        
          kChannelId3
        
          kChannelId4
        
          kChannelId5
        """
        __members__: typing.ClassVar[dict[str, ServoChannel.ChannelId]]  # value = {'kChannelId0': <ChannelId.kChannelId0: 0>, 'kChannelId1': <ChannelId.kChannelId1: 1>, 'kChannelId2': <ChannelId.kChannelId2: 2>, 'kChannelId3': <ChannelId.kChannelId3: 3>, 'kChannelId4': <ChannelId.kChannelId4: 4>, 'kChannelId5': <ChannelId.kChannelId5: 5>}
        kChannelId0: typing.ClassVar[ServoChannel.ChannelId]  # value = <ChannelId.kChannelId0: 0>
        kChannelId1: typing.ClassVar[ServoChannel.ChannelId]  # value = <ChannelId.kChannelId1: 1>
        kChannelId2: typing.ClassVar[ServoChannel.ChannelId]  # value = <ChannelId.kChannelId2: 2>
        kChannelId3: typing.ClassVar[ServoChannel.ChannelId]  # value = <ChannelId.kChannelId3: 3>
        kChannelId4: typing.ClassVar[ServoChannel.ChannelId]  # value = <ChannelId.kChannelId4: 4>
        kChannelId5: typing.ClassVar[ServoChannel.ChannelId]  # value = <ChannelId.kChannelId5: 5>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    kNumServoChannels: typing.ClassVar[int] = 6
    def getChannelId(self) -> ServoChannel.ChannelId:
        """
        Get the channel ID this ServoChannel.
        
        :returns: Channel channel ID
        """
    def getCurrent(self) -> float:
        """
        :returns: The channel's output current in Amps.
        """
    def getPulseWidth(self) -> int:
        """
        :returns: The pulse width applied to this channel in microseconds.
        """
    def isEnabled(self) -> bool:
        """
        :returns: true if the channel is enabled; false, otherwise
        """
    def setEnabled(self, enabled: bool) -> REVLibError:
        """
        Enables/Disables the servo
        
        :param in: enabled true = enabled, false = disabled
        """
    def setPowered(self, powered: bool) -> REVLibError:
        """
        Turns on/off the power to the servo
        
        :param in: powered true = powered on, false = powered off
        """
    def setPulseWidth(self, pulseWidth_us: typing.SupportsInt) -> REVLibError:
        """
        Sets the servo to the desired location based on the pulse width (in
        microseconds)
        
        :param in: pulseWidth_us The desired pulse width in microseconds
        """
class ServoChannelConfig(BaseConfig):
    class BehaviorWhenDisabled:
        """
        Members:
        
          kDoNotSupplyPower
        
          kSupplyPower
        """
        __members__: typing.ClassVar[dict[str, ServoChannelConfig.BehaviorWhenDisabled]]  # value = {'kDoNotSupplyPower': <BehaviorWhenDisabled.kDoNotSupplyPower: 0>, 'kSupplyPower': <BehaviorWhenDisabled.kSupplyPower: 1>}
        kDoNotSupplyPower: typing.ClassVar[ServoChannelConfig.BehaviorWhenDisabled]  # value = <BehaviorWhenDisabled.kDoNotSupplyPower: 0>
        kSupplyPower: typing.ClassVar[ServoChannelConfig.BehaviorWhenDisabled]  # value = <BehaviorWhenDisabled.kSupplyPower: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class PulseRange_t:
        def __init__(self) -> None:
            ...
        @property
        def centerPulse_us(self) -> int:
            ...
        @centerPulse_us.setter
        def centerPulse_us(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def maxPulse_us(self) -> int:
            ...
        @maxPulse_us.setter
        def maxPulse_us(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def minPulse_us(self) -> int:
            ...
        @minPulse_us.setter
        def minPulse_us(self, arg0: typing.SupportsInt) -> None:
            ...
    def __init__(self, channelId: ServoChannel.ChannelId) -> None:
        ...
    def apply(self, config: ServoChannelConfig) -> ServoChannelConfig:
        """
        Applies settings from another ServoChannelConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param in: config The ServoChannelConfig to copy settings from
        
        :returns: The updated ServoChannelConfig for method chaining
        """
    def disableBehavior(self, behavior: ServoChannelConfig.BehaviorWhenDisabled) -> ServoChannelConfig:
        """
        Set the output power behavior when the channel is disabled.
        
        When the channel is enabled [ServoChannel::SetEnabled(true)],
        the output power to the servo follows the channel's power setting
        [ServoChannel::SetPowered()].
        
        When the channel is disabled [ServoChannel::SetEnabled(false)],
        the output power to the servo follows the channel's disableBehavior.
        
        :param in: behavior The disable behavior as described above.
        
        :returns: The modified ServoChannelConfig object for method chaining
        """
    @typing.overload
    def pulseRange(self, minPulse_us: typing.SupportsInt, centerPulse_us: typing.SupportsInt, maxPulse_us: typing.SupportsInt) -> ServoChannelConfig:
        """
        Set the min/center/max pulse widths on this channel.
        
        :param in: minPulse_us The minimum pulse width (in microseconds)
        :param in: centerPulse_us The center pulse width (in microseconds)
        :param in: maxPulse_us The maximum pulse width (in microseconds)
        
        :returns: The modified ServoChannelConfig object for method chaining
        """
    @typing.overload
    def pulseRange(self, pulseRange_us: ServoChannelConfig.PulseRange_t) -> ServoChannelConfig:
        """
        Set the min/center/max pulse widths on this channel.
        
        :param in: pulseRange_us The minimum/center/max pulse widths (in
                   microseconds)
        
        :returns: The modified ServoChannelConfig object for method chaining
        """
class ServoChannelConfigAccessor:
    def getDisableBehavior(self) -> ServoChannelConfig.BehaviorWhenDisabled:
        """
        Get the output power behavior when the channel is disabled.
        
        When the channel is enabled [ServoChannel::SetEnabled(true)],
        the output power to the servo follows the channel's power setting
        [ServoChannel::SetPowered()].
        
        When the channel is disabled [ServoChannel::SetEnabled(false)],
        the output power to the servo follows the channel's disableBehavior.
        
        :returns: The channel's disable behavior
        """
    def getPulseRange(self) -> ServoChannelConfig.PulseRange_t:
        """
        :returns: The channel's pulse range (min, center, max) in microseconds
        """
class ServoHub(ServoHubLowLevel):
    class Bank:
        """
        Members:
        
          kBank0_2
        
          kBank3_5
        """
        __members__: typing.ClassVar[dict[str, ServoHub.Bank]]  # value = {'kBank0_2': <Bank.kBank0_2: 0>, 'kBank3_5': <Bank.kBank3_5: 1>}
        kBank0_2: typing.ClassVar[ServoHub.Bank]  # value = <Bank.kBank0_2: 0>
        kBank3_5: typing.ClassVar[ServoHub.Bank]  # value = <Bank.kBank3_5: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Faults:
        firmware: bool
        hardware: bool
        lowBattery: bool
        regulatorPowerGood: bool
        def __init__(self, faults: typing.SupportsInt) -> None:
            ...
        @property
        def rawBits(self) -> int:
            ...
        @rawBits.setter
        def rawBits(self, arg0: typing.SupportsInt) -> None:
            ...
    class ResetMode:
        """
        Members:
        
          kNoResetSafeParameters
        
          kResetSafeParameters
        """
        __members__: typing.ClassVar[dict[str, ServoHub.ResetMode]]  # value = {'kNoResetSafeParameters': <ResetMode.kNoResetSafeParameters: 0>, 'kResetSafeParameters': <ResetMode.kResetSafeParameters: 1>}
        kNoResetSafeParameters: typing.ClassVar[ServoHub.ResetMode]  # value = <ResetMode.kNoResetSafeParameters: 0>
        kResetSafeParameters: typing.ClassVar[ServoHub.ResetMode]  # value = <ResetMode.kResetSafeParameters: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Warnings:
        brownout: bool
        canBusOff: bool
        canWarning: bool
        channel0Overcurrent: bool
        channel1Overcurrent: bool
        channel2Overcurrent: bool
        channel3Overcurrent: bool
        channel4Overcurrent: bool
        channel5Overcurrent: bool
        hasReset: bool
        def __init__(self, warnings: typing.SupportsInt) -> None:
            ...
        @property
        def rawBits(self) -> int:
            ...
        @rawBits.setter
        def rawBits(self, arg0: typing.SupportsInt) -> None:
            ...
    def __init__(self, deviceID: typing.SupportsInt) -> None:
        """
        Create a new object to control a ServoHub Servo Controller
        
        :param deviceID: The device ID.
        """
    def clearFaults(self) -> REVLibError:
        """
        Clears all non-sticky faults.
        
        Sticky faults must be cleared by resetting the motor controller.
        """
    @typing.overload
    def configure(self, config: ServoHubConfig, resetMode: ServoHub.ResetMode = ...) -> REVLibError:
        """
        Set the configuration for the ServoHub.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration.
        
        :deprecated: Use :meth:`.Configure`
                     instead. This method will be removed in 2027.
        
        :param config:    The desired ServoHub configuration
        :param resetMode: Whether to reset safe parameters before setting the
                          configuration
        
        :returns: REVLibError::kOk if successful
        """
    @typing.overload
    def configure(self, config: ServoHubConfig, resetMode: ResetMode = ...) -> REVLibError:
        """
        Set the configuration for the ServoHub.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration.
        
        :param config:    The desired ServoHub configuration
        :param resetMode: Whether to reset safe parameters before setting the
                          configuration
        
        :returns: REVLibError::kOk if successful
        """
    @typing.overload
    def configureAsync(self, config: ServoHubConfig, resetMode: ServoHub.ResetMode = ...) -> REVLibError:
        """
        Set the configuration for the ServoHub without waiting for a response.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration.
        
        NOTE: This method will immediately return REVLibError::kOk and
        the action will be done in the background. Any errors that occur will be
        reported to the driver station.
        
        :deprecated: Use :meth:`.ConfigureAsync`
                     instead. This method will be removed in 2027.
        
        :param config:    The desired ServoHub configuration
        :param resetMode: Whether to reset safe parameters before setting the
                          configuration
        
        :returns: REVLibError::kOk
                  @see Configure()
        """
    @typing.overload
    def configureAsync(self, config: ServoHubConfig, resetMode: ResetMode = ...) -> REVLibError:
        """
        Set the configuration for the ServoHub without waiting for a response.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration.
        
        NOTE: This method will immediately return REVLibError::kOk and
        the action will be done in the background. Any errors that occur will be
        reported to the driver station.
        
        :param config:    The desired ServoHub configuration
        :param resetMode: Whether to reset safe parameters before setting the
                          configuration
        
        :returns: REVLibError::kOk
                  @see Configure()
        """
    def getDeviceCurrent(self) -> float:
        """
        :returns: The servo controller's output current in Amps.
        """
    def getDeviceVoltage(self) -> float:
        """
        :returns: The voltage fed into the servo controller.
        """
    def getFaults(self) -> ServoHub.Faults:
        """
        Get the active faults that are currently present on the ServoHub. Faults
        are fatal errors that prevent the motor from running.
        
        :returns: A struct with each fault and their active value
        """
    def getServoChannel(self, channelId: ServoChannel.ChannelId) -> ServoChannel:
        """
        Returns an object to control a specific servo channel.
        
        :param channelId: The specific servo channel to get
        
        :returns: The specified ServoChannel
        """
    def getServoVoltage(self) -> float:
        """
        :returns: The voltage fed to the actual servos.
        """
    def getStickyFaults(self) -> ServoHub.Faults:
        """
        Get the sticky faults that were present on the ServoHub at one point
        since the sticky faults were last cleared. Faults are fatal errors
        that prevent the motor from running.
        
        Sticky faults can be cleared with ServoHub::ClearFaults().
        
        :returns: A struct with each fault and their sticky value
        """
    def getStickyWarnings(self) -> ServoHub.Warnings:
        """
        Get the sticky warnings that were present on the ServoHub at one point
        since the sticky warnings were last cleared. Warnings are non-fatal
        errors.
        
        Sticky warnings can be cleared with ServoHub::clearFaults().
        
        :returns: A struct with each warning and their sticky value
        """
    def getWarnings(self) -> ServoHub.Warnings:
        """
        Get the active warnings that are currently present on the ServoHub.
        Warnings are non-fatal errors.
        
        :returns: A struct with each warning and their active value
        """
    def hasActiveFault(self) -> bool:
        """
        Get whether the ServoHub has one or more active faults.
        
        :returns: true if there is an active fault
                  @see GetFaults()
        """
    def hasActiveWarning(self) -> bool:
        """
        Get whether the ServoHub has one or more active warnings.
        
        :returns: true if there is an active warning
                  @see GetWarnings()
        """
    def hasStickyFault(self) -> bool:
        """
        Get whether the ServoHub has one or more sticky faults.
        
        :returns: true if there is a sticky fault
                  @see GetStickyFaults()
        """
    def hasStickyWarning(self) -> bool:
        """
        Get whether the ServoHub has one or more sticky warnings.
        
        :returns: true if there is a sticky warning
                  @see GetStickyWarnings()
        """
    def setBankPulsePeriod(self, bank: ServoHub.Bank, pulsePeriod_us: typing.SupportsInt) -> REVLibError:
        """
        Set the Pulse Period for servo channels 0-2 or servo channels 3-5.
        
        :param bank:           The bank of channels (0-2 or 3-5) to set
        :param pulsePeriod_us: The pulse period in microseconds
        
        :returns: REVLibError::kOk if successful
        """
    @property
    def configAccessor(self) -> ServoHubConfigAccessor:
        """
        Accessor for ServoHub parameter values. This object contains fields and
        methods to retrieve parameters that have been applied to the device. To
        set parameters, see ServoHubConfig and ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and should
        be used infrequently.
        """
class ServoHubConfig(BaseConfig):
    def __init__(self) -> None:
        ...
    @typing.overload
    def apply(self, config: ServoHubConfig) -> ServoHubConfig:
        """
        Applies settings from another ServoHubConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The ServoChannelConfig to apply settings from
        
        :returns: The updated ServoHubConfig for method chaining
        """
    @typing.overload
    def apply(self, channelId: ServoChannel.ChannelId, config: ServoChannelConfig) -> ServoHubConfig:
        """
        Applies settings from a ServoChannelConfig to this ServoHubConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param channelId: The channel to apply the settings to
        :param config:    The ServoChannelConfig to apply settings from
        
        :returns: The updated ServoHubConfig for method chaining
        """
    def flatten(self) -> str:
        ...
    @property
    def channel0(self) -> ServoChannelConfig:
        ...
    @property
    def channel1(self) -> ServoChannelConfig:
        ...
    @property
    def channel2(self) -> ServoChannelConfig:
        ...
    @property
    def channel3(self) -> ServoChannelConfig:
        ...
    @property
    def channel4(self) -> ServoChannelConfig:
        ...
    @property
    def channel5(self) -> ServoChannelConfig:
        ...
class ServoHubConfigAccessor:
    def channel(self, channelId: ServoChannel.ChannelId) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to the specified servo channel. To
        configure these values, use ServoChannelConfig and call
        ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        
        :param channelId: The specific channel to access
        
        :returns: The accessor for the specified servo channel
        """
    @property
    def channel0(self) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to servo channel 0. To configure
        these values, use ServoChannelConfig and call ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def channel1(self) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to servo channel 1. To configure
        these values, use ServoChannelConfig and call ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def channel2(self) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to servo channel 2. To configure
        these values, use ServoChannelConfig and call ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def channel3(self) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to servo channel 3. To configure
        these values, use ServoChannelConfig and call ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def channel4(self) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to servo channel 4. To configure
        these values, use ServoChannelConfig and call ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def channel5(self) -> ServoChannelConfigAccessor:
        """
        Accessor for parameters relating to servo channel 5. To configure
        these values, use ServoChannelConfig and call ServoHub::Configure().
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
class ServoHubLowLevel:
    class CommunicationMode:
        """
        Members:
        
          kNone
        
          kCAN
        
          kRS_485
        """
        __members__: typing.ClassVar[dict[str, ServoHubLowLevel.CommunicationMode]]  # value = {'kNone': <CommunicationMode.kNone: 0>, 'kCAN': <CommunicationMode.kCAN: 1>, 'kRS_485': <CommunicationMode.kRS_485: 2>}
        kCAN: typing.ClassVar[ServoHubLowLevel.CommunicationMode]  # value = <CommunicationMode.kCAN: 1>
        kNone: typing.ClassVar[ServoHubLowLevel.CommunicationMode]  # value = <CommunicationMode.kNone: 0>
        kRS_485: typing.ClassVar[ServoHubLowLevel.CommunicationMode]  # value = <CommunicationMode.kRS_485: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class FirmwareVersion:
        def __init__(self) -> None:
            ...
        @property
        def firmwareFix(self) -> int:
            ...
        @firmwareFix.setter
        def firmwareFix(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def firmwareMinor(self) -> int:
            ...
        @firmwareMinor.setter
        def firmwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def firmwareYear(self) -> int:
            ...
        @firmwareYear.setter
        def firmwareYear(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def hardwareMajor(self) -> int:
            ...
        @hardwareMajor.setter
        def hardwareMajor(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def hardwareMinor(self) -> int:
            ...
        @hardwareMinor.setter
        def hardwareMinor(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus0:
        activelyProgramming: bool
        communicationMode: ServoHubLowLevel.CommunicationMode
        primaryHeartbeatLock: bool
        programmingEnabled: bool
        systemEnabled: bool
        def __init__(self) -> None:
            ...
        @property
        def deviceCurrent(self) -> float:
            ...
        @deviceCurrent.setter
        def deviceCurrent(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def servoVoltage(self) -> float:
            ...
        @servoVoltage.setter
        def servoVoltage(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def voltage(self) -> float:
            ...
        @voltage.setter
        def voltage(self, arg0: typing.SupportsFloat) -> None:
            ...
    class PeriodicStatus1:
        brownout: bool
        canBusOff: bool
        canWarning: bool
        channel0Overcurrent: bool
        channel1Overcurrent: bool
        channel2Overcurrent: bool
        channel3Overcurrent: bool
        channel4Overcurrent: bool
        channel5Overcurrent: bool
        firmwareFault: bool
        hardwareFault: bool
        hasReset: bool
        regulatorPowerGoodFault: bool
        stickyBrownout: bool
        stickyCanBusOff: bool
        stickyCanWarning: bool
        stickyChannel0Overcurrent: bool
        stickyChannel1Overcurrent: bool
        stickyChannel2Overcurrent: bool
        stickyChannel3Overcurrent: bool
        stickyChannel4Overcurrent: bool
        stickyChannel5Overcurrent: bool
        stickyFirmwareFault: bool
        stickyHardwareFault: bool
        stickyHasReset: bool
        stickyRegulatorPowerGoodFault: bool
        def __init__(self) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus2:
        channel0Enabled: bool
        channel0OutOfRange: bool
        channel1Enabled: bool
        channel1OutOfRange: bool
        channel2Enabled: bool
        channel2OutOfRange: bool
        def __init__(self) -> None:
            ...
        @property
        def channel0PulseWidth(self) -> int:
            ...
        @channel0PulseWidth.setter
        def channel0PulseWidth(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def channel1PulseWidth(self) -> int:
            ...
        @channel1PulseWidth.setter
        def channel1PulseWidth(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def channel2PulseWidth(self) -> int:
            ...
        @channel2PulseWidth.setter
        def channel2PulseWidth(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus3:
        channel3Enabled: bool
        channel3OutOfRange: bool
        channel4Enabled: bool
        channel4OutOfRange: bool
        channel5Enabled: bool
        channel5OutOfRange: bool
        def __init__(self) -> None:
            ...
        @property
        def channel3PulseWidth(self) -> int:
            ...
        @channel3PulseWidth.setter
        def channel3PulseWidth(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def channel4PulseWidth(self) -> int:
            ...
        @channel4PulseWidth.setter
        def channel4PulseWidth(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def channel5PulseWidth(self) -> int:
            ...
        @channel5PulseWidth.setter
        def channel5PulseWidth(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus4:
        def __init__(self) -> None:
            ...
        @property
        def channel0Current(self) -> float:
            ...
        @channel0Current.setter
        def channel0Current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def channel1Current(self) -> float:
            ...
        @channel1Current.setter
        def channel1Current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def channel2Current(self) -> float:
            ...
        @channel2Current.setter
        def channel2Current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def channel3Current(self) -> float:
            ...
        @channel3Current.setter
        def channel3Current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def channel4Current(self) -> float:
            ...
        @channel4Current.setter
        def channel4Current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def channel5Current(self) -> float:
            ...
        @channel5Current.setter
        def channel5Current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    _m_servoHubHandle: typing_extensions.CapsuleType
    def __init__(self, deviceID: typing.SupportsInt) -> None:
        ...
    def createSimFaultManager(self) -> None:
        """
        Create the sim gui Fault Manager for this Servo Hub device
        """
    def getControlFramePeriodMs(self) -> int:
        """
        Set the control frame send period for the native CAN Send thread.
        
        :returns: int The send period in milliseconds.
        """
    def getDeviceId(self) -> int:
        """
        Get the configured Device ID of the ServoHub.
        
        :returns: int device ID
        """
    def getFirmwareVersion(self) -> ServoHubLowLevel.FirmwareVersion:
        """
        Get the firmware version of the ServoHub.
        
        :returns: Firmware version represented in the struct
        """
    def getFirmwareVersionString(self) -> str:
        """
        Get the firmware version of the ServoHub as a string.
        
        :returns: std::string Human readable firmware version string
        """
    def getPeriodicStatus0(self) -> ServoHubLowLevel.PeriodicStatus0:
        ...
    def getPeriodicStatus1(self) -> ServoHubLowLevel.PeriodicStatus1:
        ...
    def getPeriodicStatus2(self) -> ServoHubLowLevel.PeriodicStatus2:
        ...
    def getPeriodicStatus3(self) -> ServoHubLowLevel.PeriodicStatus3:
        ...
    def getPeriodicStatus4(self) -> ServoHubLowLevel.PeriodicStatus4:
        ...
    def setCANMaxRetries(self, numRetries: typing.SupportsInt) -> None:
        """
        Set the maximum number of times to retry an RTR CAN frame. This applies
        to calls such as GetFirmwareVersion where a request is made to the
        ServoHub and a response is expected. Anytime sending the request or
        receiving the response fails, it will retry the request a number of
        times, no more than the value set by this method. If an attempt succeeds,
        it will immediately return. The minimum number of retries is 0, where
        only a single attempt will be made and will return regardless of success
        or failure.
        
        The default maximum is 5 retries.
        
        :param numRetries: The maximum number of retries
        """
    def setCANTimeout(self, timeout_ms: typing.SupportsInt) -> REVLibError:
        """
        Sets the timeout duration for waiting for CAN responses from the device.
        
        :param timeout_ms: The timeout in milliseconds.
        
        :returns: REVLibError::kOk if successful
        """
    def setControlFramePeriodMs(self, period_ms: typing.SupportsInt) -> None:
        """
        Set the control frame send period for the native CAN Send thread.
        
        :param period_ms: The send period in milliseconds between 1ms and 100ms or
                          set to 0 to disable periodic sends.
        """
    def setPeriodicFrameTimeout(self, timeout_ms: typing.SupportsInt) -> None:
        """
        Set the amount of time to wait for a periodic status frame before
        returning a timeout error. This timeout will apply to all periodic status
        frames for the ServoHub servo controller.
        
        To prevent invalid timeout errors, the minimum timeout for a given
        periodic status is 2.1 times its period. To use the minimum timeout for
        all status frames, set timeout_ms to 0.
        
        The default timeout is 500ms.
        
        :param timeout_ms: The timeout in milliseconds
        """
class ServoHubParameter:
    """
    Members:
    
      kChannel0_MinPulseWidth
    
      kChannel0_CenterPulseWidth
    
      kChannel0_MaxPulseWidth
    
      kChannel1_MinPulseWidth
    
      kChannel1_CenterPulseWidth
    
      kChannel1_MaxPulseWidth
    
      kChannel2_MinPulseWidth
    
      kChannel2_CenterPulseWidth
    
      kChannel2_MaxPulseWidth
    
      kChannel3_MinPulseWidth
    
      kChannel3_CenterPulseWidth
    
      kChannel3_MaxPulseWidth
    
      kChannel4_MinPulseWidth
    
      kChannel4_CenterPulseWidth
    
      kChannel4_MaxPulseWidth
    
      kChannel5_MinPulseWidth
    
      kChannel5_CenterPulseWidth
    
      kChannel5_MaxPulseWidth
    
      kChannel0_DisableBehavior
    
      kChannel1_DisableBehavior
    
      kChannel2_DisableBehavior
    
      kChannel3_DisableBehavior
    
      kChannel4_DisableBehavior
    
      kChannel5_DisableBehavior
    """
    __members__: typing.ClassVar[dict[str, ServoHubParameter]]  # value = {'kChannel0_MinPulseWidth': <ServoHubParameter.kChannel0_MinPulseWidth: 0>, 'kChannel0_CenterPulseWidth': <ServoHubParameter.kChannel0_CenterPulseWidth: 1>, 'kChannel0_MaxPulseWidth': <ServoHubParameter.kChannel0_MaxPulseWidth: 2>, 'kChannel1_MinPulseWidth': <ServoHubParameter.kChannel1_MinPulseWidth: 3>, 'kChannel1_CenterPulseWidth': <ServoHubParameter.kChannel1_CenterPulseWidth: 4>, 'kChannel1_MaxPulseWidth': <ServoHubParameter.kChannel1_MaxPulseWidth: 5>, 'kChannel2_MinPulseWidth': <ServoHubParameter.kChannel2_MinPulseWidth: 6>, 'kChannel2_CenterPulseWidth': <ServoHubParameter.kChannel2_CenterPulseWidth: 7>, 'kChannel2_MaxPulseWidth': <ServoHubParameter.kChannel2_MaxPulseWidth: 8>, 'kChannel3_MinPulseWidth': <ServoHubParameter.kChannel3_MinPulseWidth: 9>, 'kChannel3_CenterPulseWidth': <ServoHubParameter.kChannel3_CenterPulseWidth: 10>, 'kChannel3_MaxPulseWidth': <ServoHubParameter.kChannel3_MaxPulseWidth: 11>, 'kChannel4_MinPulseWidth': <ServoHubParameter.kChannel4_MinPulseWidth: 12>, 'kChannel4_CenterPulseWidth': <ServoHubParameter.kChannel4_CenterPulseWidth: 13>, 'kChannel4_MaxPulseWidth': <ServoHubParameter.kChannel4_MaxPulseWidth: 14>, 'kChannel5_MinPulseWidth': <ServoHubParameter.kChannel5_MinPulseWidth: 15>, 'kChannel5_CenterPulseWidth': <ServoHubParameter.kChannel5_CenterPulseWidth: 16>, 'kChannel5_MaxPulseWidth': <ServoHubParameter.kChannel5_MaxPulseWidth: 17>, 'kChannel0_DisableBehavior': <ServoHubParameter.kChannel0_DisableBehavior: 18>, 'kChannel1_DisableBehavior': <ServoHubParameter.kChannel1_DisableBehavior: 19>, 'kChannel2_DisableBehavior': <ServoHubParameter.kChannel2_DisableBehavior: 20>, 'kChannel3_DisableBehavior': <ServoHubParameter.kChannel3_DisableBehavior: 21>, 'kChannel4_DisableBehavior': <ServoHubParameter.kChannel4_DisableBehavior: 22>, 'kChannel5_DisableBehavior': <ServoHubParameter.kChannel5_DisableBehavior: 23>}
    kChannel0_CenterPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel0_CenterPulseWidth: 1>
    kChannel0_DisableBehavior: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel0_DisableBehavior: 18>
    kChannel0_MaxPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel0_MaxPulseWidth: 2>
    kChannel0_MinPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel0_MinPulseWidth: 0>
    kChannel1_CenterPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel1_CenterPulseWidth: 4>
    kChannel1_DisableBehavior: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel1_DisableBehavior: 19>
    kChannel1_MaxPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel1_MaxPulseWidth: 5>
    kChannel1_MinPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel1_MinPulseWidth: 3>
    kChannel2_CenterPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel2_CenterPulseWidth: 7>
    kChannel2_DisableBehavior: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel2_DisableBehavior: 20>
    kChannel2_MaxPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel2_MaxPulseWidth: 8>
    kChannel2_MinPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel2_MinPulseWidth: 6>
    kChannel3_CenterPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel3_CenterPulseWidth: 10>
    kChannel3_DisableBehavior: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel3_DisableBehavior: 21>
    kChannel3_MaxPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel3_MaxPulseWidth: 11>
    kChannel3_MinPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel3_MinPulseWidth: 9>
    kChannel4_CenterPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel4_CenterPulseWidth: 13>
    kChannel4_DisableBehavior: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel4_DisableBehavior: 22>
    kChannel4_MaxPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel4_MaxPulseWidth: 14>
    kChannel4_MinPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel4_MinPulseWidth: 12>
    kChannel5_CenterPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel5_CenterPulseWidth: 16>
    kChannel5_DisableBehavior: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel5_DisableBehavior: 23>
    kChannel5_MaxPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel5_MaxPulseWidth: 17>
    kChannel5_MinPulseWidth: typing.ClassVar[ServoHubParameter]  # value = <ServoHubParameter.kChannel5_MinPulseWidth: 15>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ServoHubSim:
    def __init__(self, servoHub: ServoHub) -> None:
        """
        Create a simulated CAN Servo Hub object. This class simulates some of the
        internal behavior of the device. This class is not required to display to
        the sim GUI, but is required to interact with it.
        
        :param servoHub: The Servo Hub to simulate
        """
    def disable(self) -> None:
        """
        Disable the Servo Hub Device
        """
    def enable(self) -> None:
        """
        Enable the Servo Hub Device.
        """
    def getBankPulsePeriod(self, bank: ServoHub.Bank) -> int:
        """
        Get the simulated bank pulse period. This matches the value from
        the ServoHub::GetBankPulsePeriod().
        
        :param bank: the specific bank (0-2, or 3-5)to get
        
        :returns: pulse period (in microseconds)for the specified bank
        """
    def getDeviceCurrent(self) -> float:
        """
        Get the simulated device current output. This matches the value from
        the ServoHub::GetDeviceCurrent().
        
        :returns: device current in amps
        """
    def getDeviceVoltage(self) -> float:
        """
        Get the simulated device voltage output. This matches the value from
        the ServoHub::GetDeviceVoltage().
        
        :returns: device voltage in volts
        """
    def getFaultManager(self) -> ServoHubSimFaultManager:
        """
        Get the ServoHubSimFaultManager object associated with this Servo
        Hub Device. This will allow you to set simulated faults on your simulated
        device and view the Fault Manager in the Sim GUI.
        
        :returns: The ServoHubSimFaultManager object associated with this
                  Servo Hub Device
        """
    def getServoVoltage(self) -> float:
        """
        Get the simulated servo voltage output. This matches the value from
        the ServoHub::GetServoVoltage().
        
        :returns: servo voltage in volts
        """
    def setBankPulsePeriod(self, bank: ServoHub.Bank, pulsePeriod_us: typing.SupportsInt) -> None:
        """
        Set the simulated bank pulse period
        
        :param bank:           the specific bank (0-2, or 3-5)to get
        :param pulsePeriod_us: pulse period (in microseconds)for the specified
                               bank
        """
    def setDeviceCurrent(self, current: typing.SupportsFloat) -> None:
        """
        Set the simulated device current.
        
        :param current: device current in amps
        """
    def setDeviceVoltage(self, voltage: typing.SupportsFloat) -> None:
        """
        Set the simulated device voltage.
        
        :param voltage: device voltage in volts
        """
    def setServoVoltage(self, voltage: typing.SupportsFloat) -> None:
        """
        Set the simulated device voltage.
        
        :param voltage: device voltage in volts
        """
    def useDriverStationEnable(self) -> None:
        """
        Use the driver station enable as the method to enable/disable the Servo
        Hub. This is the default, so you do not need to call this unless you
        previously called enable() or disable().
        """
class ServoHubSimFaultManager:
    def __init__(self, servoHub: ServoHub) -> None:
        """
        Create a Fault Manager object, which allows you to get and set the status
        of simulated faults on your simulated Servo Hub. Constructing this object
        will also cause the Fault Manager to appear in the sim gui. The state of
        faults can be fetched on the original Servo Hub Object.
        
        :param servoHub: The ServoHub associated with the Fault Manager
        """
    def setFaults(self, faults: ServoHub.Faults) -> None:
        """
        Set the state of the simulated faults of the device.
        
        Use device.getFaults() to get the object and modify the parameters.
        
        :param faults: a Faults object indicating the state of the faults
        """
    def setStickyFaults(self, faults: ServoHub.Faults) -> None:
        """
        Set the state of the simulated sticky faults of the device.
        
        Use device.getStickyFaults() to get the object and modify the
        parameters.
        
        :param faults: a Faults object indicating the state of the sticky faults
        """
    def setStickyWarnings(self, warnings: ServoHub.Warnings) -> None:
        """
        Set the state of the simulated sticky warnings of the device.
        
        Use device.getStickyWarnings() to get the object and modify the
        parameters.
        
        :param warnings: a Warnings object indicating the state of the sticky
                         warnings
        """
    def setWarnings(self, warnings: ServoHub.Warnings) -> None:
        """
        Set the state of the simulated warnings of the device.
        
        Use device.getWarnings() to get the object and modify the parameters.
        
        :param warnings: a Warnings object indicating the state of the warnings
        """
class SignalsConfig(BaseConfig):
    def IAccumulationAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkClosedLoopController::GetIAccum().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def IAccumulationPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkClosedLoopController::GetIAccum(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def __init__(self) -> None:
        ...
    def absoluteEncoderPositionAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkAbsoluteEncoder::GetPosition().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def absoluteEncoderPositionPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkAbsoluteEncoder::GetPosition(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def absoluteEncoderVelocityAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkAbsoluteEncoder::GetVelocity().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def absoluteEncoderVelocityPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkAbsoluteEncoder::GetVelocity(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def analogPositionAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkAnalogSensor::GetPosition().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def analogPositionPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkAnalogSensor::GetPosition(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def analogVelocityAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkAnalogSensor::GetVelocity().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def analogVelocityPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkAnalogSensor::GetVelocity(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def analogVoltageAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkAnalogSensor::GetVoltage().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def analogVoltagePeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkAnalogSensor::GetVoltage(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def appliedOutputAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkBase::GetAppliedOutput().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :deprecated: Calling this method will have no effect, as status 0 cannot
                     be disabled.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def appliedOutputPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkBase::GetAppliedOutput(). The default period is 10ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        **NOTE:** Applied output is used by other SPARK devices in follower
        mode. Setting too long of a period should be avoided if this SPARK device
        is the leader, as it can degrade follower mode performance.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def apply(self, config: SignalsConfig) -> SignalsConfig:
        """
        Applies settings from another SignalsConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SignalsConfig to copy settings from
        
        :returns: The updated SignalsConfig for method chaining
        """
    def busVoltageAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkBase::getBusVoltage().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :deprecated: Calling this method will have no effect, as status 0 cannot
                     be disabled.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def busVoltagePeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkBase::getBusVoltage(). The default period is 10ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        **NOTE:** This signal shares a status frame with applied output
        which is used by other SPARK devices in follower mode. Setting too long
        of a period should be avoided if this SPARK device is the leader, as it
        can degrade follower mode performance.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def externalOrAltEncoderPosition(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkFlexExternalEncoder::GetPosition() or
        SparkMaxAlternateEncoder::GetPosition(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def externalOrAltEncoderPositionAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkFlexExternalEncoder::GetPosition() or
        SparkMaxAlternateEncoder::GetPosition().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def externalOrAltEncoderVelocity(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkFlexExternalEncoder::GetVelocity() or
        SparkMaxAlternateEncoder::GetVelocity(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def externalOrAltEncoderVelocityAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkFlexExternalEncoder::GetVelocity() or
        SparkMaxAlternateEncoder::GetVelocity().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def faultsAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkBase::GetFaults() and
        SparkBase::GetStickyFaults().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def faultsPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkBase::GetFaults() and SparkBase::GetStickyFaults().
        The default period is 250ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def isAtSetpointAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkClosedLoopController::IsAtSetpoint().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def isAtSetpointPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkClosedLoopController::IsAtSetpoint(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def limitsAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkLimitSwitch::IsPressed().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :deprecated: Calling this method will have no effect, as status 0 cannot
                     be disabled.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def limitsPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkLimitSwitch::IsPressed(). The default period is 10ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        **NOTE:** This signal shares a status frame with applied output
        which is used by other SPARK devices in follower mode. Setting too long
        of a period should be avoided if this SPARK device is the leader, as it
        can degrade follower mode performance.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def maxMotionSetpointPositionAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by {@link
        com.revrobotics.spark.SparkClosedLoopController#getMAXMotionSetpointPosition()
        SparkClosedLoopController.getMAXMotionSetpointPosition()}
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified :class:`.SignalsConfig` object for method chaining
        """
    def maxMotionSetpointPositionPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by {@link
        com.revrobotics.spark.SparkClosedLoopController#getMAXMotionSetpointPosition()
        SparkClosedLoopController.getMAXMotionSetpointPosition()}. The default
        period is 100ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified :class:`.SignalsConfig` object for method chaining
        """
    def maxMotionSetpointVelocityAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by {@link
        com.revrobotics.spark.SparkClosedLoopController#getMAXMotionSetpointVelocity()
        SparkClosedLoopController.getMAXMotionSetpointVelocity()}
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified :class:`.SignalsConfig` object for method chaining
        """
    def maxMotionSetpointVelocityPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by {@link
        com.revrobotics.spark.SparkClosedLoopController#getMAXMotionSetpointVelocity()
        SparkClosedLoopController.getMAXMotionSetpointVelocity()}. The default
        period is 100ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified :class:`.SignalsConfig` object for method chaining
        """
    def motorTemperatureAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkBase::GetMotorTemperature().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :deprecated: Calling this method will have no effect, as status 0 cannot
                     be disabled.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def motorTemperaturePeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkBase::GetMotorTemperature(). The default period is 10ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        **NOTE:** This signal shares a status frame with applied output
        which is used by other SPARK devices in follower mode. Setting too long
        of a period should be avoided if this SPARK device is the leader, as it
        can degrade follower mode performance.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def outputCurrentAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkBase::GetOutputCurrent().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :deprecated: Calling this method will have no effect, as status 0 cannot
                     be disabled.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def outputCurrentPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkBase::GetOutputCurrent(). The default period is 10ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        **NOTE:** This signal shares a status frame with applied output
        which is used by other SPARK devices in follower mode. Setting too long
        of a period should be avoided if this SPARK device is the leader, as it
        can degrade follower mode performance.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def primaryEncoderPositionAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkRelativeEncoder::GetPosition().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def primaryEncoderPositionPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkRelativeEncoder::GetPosition(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def primaryEncoderVelocityAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkRelativeEncoder::GetVelocity().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def primaryEncoderVelocityPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkRelativeEncoder::GetVelocity(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def selectedSlotAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkClosedLoopController::GetSelectedSlot().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def selectedSlotPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkClosedLoopController::GetSelectedSlot(). The default period is
        20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def setpointAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkClosedLoopController::GetSetpoint().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def setpointPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkClosedLoopController::GetSetpoint(). The default period is 20ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def warningsAlwaysOn(self, enabled: bool) -> SignalsConfig:
        """
        Set whether to always enable the status frame that provides the signal
        returned by SparkBase::GetWarnings() and
        SparkBase::GetStickyWarnings().
        
        Status frames are only enabled when a signal is requested via its
        respective getter method, and there may be a small period of time where
        the signal's data is unavailable due to waiting for the SPARK to receive
        the command to enable the status frame. Use this method to enable the
        status frame at all times.
        
        If multiple alwaysOn values are set for signals within the same status
        frame, the result from OR'ing the values will be used.
        
        :param enabled: True to always enable the status frame
        
        :returns: The modified SignalsConfig object for method chaining
        """
    def warningsPeriodMs(self, periodMs: typing.SupportsInt) -> SignalsConfig:
        """
        Set the period (ms) of the status frame that provides the signal returned
        by SparkBase::GetWarnings() and SparkBase::GetStickyWarnings().
        The default period is 250ms.
        
        If multiple periods are set for signals within the same status frame,
        the minimum given value will be used.
        
        :param periodMs: The period in milliseconds
        
        :returns: The modified SignalsConfig object for method chaining
        """
class SignalsConfigAccessor:
    def getAbsoluteEncoderPositionAlwaysOn(self) -> bool:
        ...
    def getAbsoluteEncoderPositionPeriodMs(self) -> int:
        ...
    def getAbsoluteEncoderVelocityAlwaysOn(self) -> bool:
        ...
    def getAbsoluteEncoderVelocityPeriodMs(self) -> int:
        ...
    def getAnalogPositionAlwaysOn(self) -> bool:
        ...
    def getAnalogPositionPeriodMs(self) -> int:
        ...
    def getAnalogVelocityAlwaysOn(self) -> bool:
        ...
    def getAnalogVelocityPeriodMs(self) -> int:
        ...
    def getAnalogVoltageAlwaysOn(self) -> bool:
        ...
    def getAnalogVoltagePeriodMs(self) -> int:
        ...
    def getAppliedOutputAlwaysOn(self) -> bool:
        ...
    def getAppliedOutputPeriodMs(self) -> int:
        ...
    def getBusVoltageAlwaysOn(self) -> bool:
        ...
    def getBusVoltagePeriodMs(self) -> int:
        ...
    def getExternalOrAltEncoderPositionAlwaysOn(self) -> bool:
        ...
    def getExternalOrAltEncoderPositionPeriodMs(self) -> int:
        ...
    def getExternalOrAltEncoderVelocityAlwaysOn(self) -> bool:
        ...
    def getExternalOrAltEncoderVelocityPeriodMs(self) -> int:
        ...
    def getFaultsAlwaysOn(self) -> bool:
        ...
    def getFaultsPeriodMs(self) -> int:
        ...
    def getIAccumulationAlwaysOn(self) -> bool:
        ...
    def getIAccumulationPeriodMs(self) -> int:
        ...
    def getIsAtSetpointAlwaysOn(self) -> bool:
        ...
    def getIsAtSetpointPeriodMs(self) -> int:
        ...
    def getLimitsAlwaysOn(self) -> bool:
        ...
    def getLimitsPeriodMs(self) -> int:
        ...
    def getMAXMotionSetpointPositionAlwaysOn(self) -> bool:
        ...
    def getMAXMotionSetpointPositionPeriodMs(self) -> int:
        ...
    def getMAXMotionSetpointVelocityAlwaysOn(self) -> bool:
        ...
    def getMAXMotionSetpointVelocityPeriodMs(self) -> int:
        ...
    def getMotorTemperatureAlwaysOn(self) -> bool:
        ...
    def getMotorTemperaturePeriodMs(self) -> int:
        ...
    def getOutputCurrentAlwaysOn(self) -> bool:
        ...
    def getOutputCurrentPeriodMs(self) -> int:
        ...
    def getPrimaryEncoderPositionAlwaysOn(self) -> bool:
        ...
    def getPrimaryEncoderPositionPeriodMs(self) -> int:
        ...
    def getPrimaryEncoderVelocityAlwaysOn(self) -> bool:
        ...
    def getPrimaryEncoderVelocityPeriodMs(self) -> int:
        ...
    def getSelectedSlotAlwaysOn(self) -> bool:
        ...
    def getSelectedSlotPeriodMs(self) -> int:
        ...
    def getSetpointAlwaysOn(self) -> bool:
        ...
    def getSetpointPeriodMs(self) -> int:
        ...
    def getWarningsAlwaysOn(self) -> bool:
        ...
    def getWarningsPeriodMs(self) -> int:
        ...
class SoftLimitConfig(BaseConfig):
    def __init__(self) -> None:
        ...
    def apply(self, config: SoftLimitConfig) -> SoftLimitConfig:
        """
        Applies settings from another SoftLimitConfig to this one.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SoftLimitConfig to copy settings from
        
        :returns: The updated SoftLimitConfig for method chaining
        """
    def forwardSoftLimit(self, limit: typing.SupportsFloat) -> SoftLimitConfig:
        """
        Set the forward soft limit based on the position of the selected feedback
        sensor. This will disable motor actuation in the forward direction past
        this position. This value should have the position conversion factor
        applied to it.
        
        :param limit: The forward soft limit position with the conversion factor
                      applied
        
        :returns: The modified SoftLimitConfig object for method chaining
        """
    def forwardSoftLimitEnabled(self, enabled: bool) -> SoftLimitConfig:
        """
        Set whether to enable or disable the forward soft limit.
        
        :param enabled: True to enable the forward soft limit
        
        :returns: The modified SoftLimitConfig object for method chaining
        """
    def reverseSoftLimit(self, limit: typing.SupportsFloat) -> SoftLimitConfig:
        """
        Set the reverse soft limit based on the position of the selected feedback
        sensor. This will disable motor actuation in the reverse direction past
        this position. This value should have the position conversion factor
        applied to it.
        
        :param limit: The reverse soft limit position with the conversion factor
                      applied
        
        :returns: The modified SoftLimitConfig object for method chaining
        """
    def reverseSoftLimitEnabled(self, enabled: bool) -> SoftLimitConfig:
        """
        Set whether to enable or disable the reverse soft limit.
        
        :param enabled: True to enable the reverse soft limit
        
        :returns: The modified SoftLimitConfig object for method chaining
        """
class SoftLimitConfigAccessor:
    def getForwardSoftLimit(self) -> float:
        ...
    def getForwardSoftLimitEnabled(self) -> bool:
        ...
    def getReverseSoftLimit(self) -> float:
        ...
    def getReverseSoftLimitEnabled(self) -> bool:
        ...
class SparkAbsoluteEncoder(AbsoluteEncoder):
    """
    Get an instance of this class by using SparkBase::GetEncoder() or
    SparkBase::GetEncoder(SparkMaxRelativeEncoder::Type, int).
    """
    def getPosition(self) -> float:
        """
        Get the position of the motor. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using AbsoluteEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the motor
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the motor. This returns the native units
        of 'rotations per second' by default, and can be changed by a scale
        factor using AbsoluteEncoderConfig::VelocityConversionFactor().
        
        :returns: Number of rotations per second of the motor
        """
class SparkAbsoluteEncoderSim:
    @typing.overload
    def __init__(self, motor: SparkMax) -> None:
        ...
    @typing.overload
    def __init__(self, motor: SparkFlex) -> None:
        ...
    def getInverted(self) -> bool:
        ...
    def getPosition(self) -> float:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroOffset(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def setZeroOffset(self, zeroOffset: typing.SupportsFloat) -> None:
        ...
class SparkAnalogSensor(AnalogInput):
    def getPosition(self) -> float:
        """
        Get the position of the sensor. Returns value in the native unit
        of 'volt' by default, and can be changed by a scale factor
        using AnalogSensorConfig::PositionConversionFactor().
        
        :returns: Position of the sensor in volts
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the sensor. Returns value in the native units of
        'volts per second' by default, and can be changed by a
        scale factor using AnalogSensorConfig::VelocityConversionFactor().
        
        :returns: Velocity of the sensor in volts per second
        """
    def getVoltage(self) -> float:
        """
        Get the voltage of the analog sensor.
        
        :returns: Voltage of the sensor
        """
class SparkAnalogSensorSim:
    @typing.overload
    def __init__(self, motor: SparkMax) -> None:
        ...
    @typing.overload
    def __init__(self, motor: SparkFlex) -> None:
        ...
    def getInverted(self) -> bool:
        ...
    def getPosition(self) -> float:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getVoltage(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def setVoltage(self, voltage: typing.SupportsFloat) -> None:
        ...
class SparkBase(SparkLowLevel):
    class Faults:
        can: bool
        escEeprom: bool
        firmware: bool
        gateDriver: bool
        motorType: bool
        other: bool
        sensor: bool
        temperature: bool
        @typing.overload
        def __init__(self) -> None:
            ...
        @typing.overload
        def __init__(self, faults: typing.SupportsInt) -> None:
            ...
        @property
        def rawBits(self) -> int:
            ...
        @rawBits.setter
        def rawBits(self, arg0: typing.SupportsInt) -> None:
            ...
    class IdleMode:
        """
        Members:
        
          kCoast
        
          kBrake
        """
        __members__: typing.ClassVar[dict[str, SparkBase.IdleMode]]  # value = {'kCoast': <IdleMode.kCoast: 0>, 'kBrake': <IdleMode.kBrake: 1>}
        kBrake: typing.ClassVar[SparkBase.IdleMode]  # value = <IdleMode.kBrake: 1>
        kCoast: typing.ClassVar[SparkBase.IdleMode]  # value = <IdleMode.kCoast: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class SoftLimitDirection:
        """
        Members:
        
          kForward
        
          kReverse
        """
        __members__: typing.ClassVar[dict[str, SparkBase.SoftLimitDirection]]  # value = {'kForward': <SoftLimitDirection.kForward: 0>, 'kReverse': <SoftLimitDirection.kReverse: 1>}
        kForward: typing.ClassVar[SparkBase.SoftLimitDirection]  # value = <SoftLimitDirection.kForward: 0>
        kReverse: typing.ClassVar[SparkBase.SoftLimitDirection]  # value = <SoftLimitDirection.kReverse: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Warnings:
        brownout: bool
        escEeprom: bool
        extEeprom: bool
        hasReset: bool
        other: bool
        overcurrent: bool
        sensor: bool
        stall: bool
        @typing.overload
        def __init__(self) -> None:
            ...
        @typing.overload
        def __init__(self, warnings: typing.SupportsInt) -> None:
            ...
        @property
        def rawBits(self) -> int:
            ...
        @rawBits.setter
        def rawBits(self, arg0: typing.SupportsInt) -> None:
            ...
    def __init__(self, deviceID: typing.SupportsInt, type: SparkLowLevel.MotorType, model: SparkLowLevel.SparkModel) -> None:
        """
        Create a new object to control a SPARK motor Controller
        
        :param deviceID: The device ID.
        :param type:     The motor type connected to the controller. Brushless
                         motor wires must be connected to their matching
                         colors, and the hall sensor must be plugged in.
                         Brushed motors must be connected to the Red and Black
                         terminals only.
        :param model:    The model (kSparkMax or kSparkFlex) of the motor.
        """
    def _getEncoderEvenIfAlreadyCreated(self) -> SparkRelativeEncoder:
        ...
    def _getMotorInterface(self) -> int:
        """
        Get the current motor interface for the SPARK.
        
        :returns:
        """
    def _getSparkModel(self) -> SparkLowLevel.SparkModel:
        """
        Get the Model of this SPARK Device. Useful for determining if this
        is a Flex, MAX, or other device
        
        :returns: the model of this device
        """
    def clearFaults(self) -> REVLibError:
        """
        Clears all sticky faults.
        """
    def configure(self, config: SparkBaseConfig, resetMode: ResetMode, persistMode: PersistMode) -> REVLibError:
        """
        Set the configuration for the SPARK.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration. The following parameters will not be
        reset by this action: CAN ID, Motor Type, Idle Mode, PWM Input Deadband,
        and Duty Cycle Offset.
        
        If @c persistMode is PersistMode::kPersistParameters, this
        method will save all parameters to the SPARK's non-volatile memory after
        setting the given configuration. This will allow parameters to persist
        across power cycles.
        
        :param config:      The desired SPARK configuration
        :param resetMode:   Whether to reset safe parameters before setting the
                            configuration
        :param persistMode: Whether to persist the parameters after setting the
                            configuration
        
        :returns: REVLibError::kOk if successful
        """
    def configureAsync(self, config: SparkBaseConfig, resetMode: ResetMode, persistMode: PersistMode) -> REVLibError:
        """
        Set the configuration for the SPARK without waiting for a response.
        
        If @c resetMode is ResetMode::kResetSafeParameters, this
        method will reset safe writable parameters to their default values before
        setting the given configuration. The following parameters will not be
        reset by this action: CAN ID, Motor Type, Idle Mode, PWM Input Deadband,
        and Duty Cycle Offset.
        
        If @c persistMode is PersistMode::kPersistParameters, this
        method will save all parameters to the SPARK's non-volatile memory after
        setting the given configuration. This will allow parameters to persist
        across power cycles.
        
        NOTE: This method will immediately return REVLibError::kOk and the
        action will be done in the background. Any errors that occur will be
        reported to the driver station.
        
        :param config:      The desired SPARK configuration
        :param resetMode:   Whether to reset safe parameters before setting the
                            configuration
        :param persistMode: Whether to persist the parameters after setting the
                            configuration
        
        :returns: REVLibError::kOk
                  @see Configure()
        """
    def disable(self) -> None:
        """
        Common interface for disabling a motor.
        """
    def get(self) -> float:
        """
        Common interface for getting the current set speed of a speed controller.
        
        :returns: The current set speed.  Value is between -1.0 and 1.0.
        """
    def getAbsoluteEncoder(self) -> SparkAbsoluteEncoder:
        """
        Returns an object for interfacing with a connected absolute encoder.
        
        The default encoder type is assumed to be a duty cycle sensor.
        """
    def getAnalog(self) -> SparkAnalogSensor:
        """
        Returns an object for interfacing with a connected analog sensor.
        By default, the mode is set to kAbsolute, thus treating the
        sensor as an absolute sensor.
        """
    def getAppliedOutput(self) -> float:
        """
        Simulation note: this value will not be updated during simulation
        unless
        {@link SparkSim#iterate} is called
        
        Returns motor controller's output duty cycle.
        """
    def getBusVoltage(self) -> float:
        """
        Returns the voltage fed into the motor controller.
        """
    def getClosedLoopController(self) -> SparkClosedLoopController:
        """
        Returns an object for interfacing with the integrated Closed Loop
        Controller.
        """
    def getEncoder(self) -> SparkRelativeEncoder:
        """
        Returns an object for interfacing with the encoder connected to the
        encoder pins or front port of the SPARK MAX or the motor interface of the
        SPARK Flex.
        """
    def getFaults(self) -> SparkBase.Faults:
        """
        Get the active faults that are currently present on the SPARK. Faults
        are fatal errors that prevent the motor from running.
        
        :returns: A struct with each fault and their active value
        """
    def getForwardLimitSwitch(self) -> SparkLimitSwitch:
        """
        Returns an object for interfacing with the forward limit switch connected
        to the appropriate pins on the data port.
        
        This call will disable support for the alternate encoder.
        """
    def getForwardSoftLimit(self) -> SparkSoftLimit:
        """
        Returns an object for interfacing with the forward soft limit switch
        """
    def getInverted(self) -> bool:
        """
        Common interface for returning the inversion state of a speed controller.
        
        This call has no effect if the controller is a follower.
        
        :deprecated: Use SparkBaseConfigAccessor.GetInverted() via
                     SparkMax.configAccessor or SparkFlex.configAccessor instead
        
        :returns: isInverted The state of inversion, true is inverted.
        """
    def getLastError(self) -> REVLibError:
        """
        All device errors are tracked on a per thread basis for all
        devices in that thread. This is meant to be called
        immediately following another call that has the possibility
        of throwing an error to validate if an  error has occurred.
        
        :returns: the last error that was generated.
        """
    def getMotorTemperature(self) -> float:
        """
        Returns the motor temperature in Celsius.
        """
    def getOutputCurrent(self) -> float:
        """
        Returns motor controller's output current in Amps.
        """
    def getReverseLimitSwitch(self) -> SparkLimitSwitch:
        """
        Returns an object for interfacing with the reverse limit switch connected
        to the appropriate pins on the data port.
        
        This call will disable support for the alternate encoder.
        """
    def getReverseSoftLimit(self) -> SparkSoftLimit:
        """
        Returns an object for interfacing with the reverse soft limit switch
        """
    def getStickyFaults(self) -> SparkBase.Faults:
        """
        Get the sticky faults that were present on the SPARK at one point
        since the sticky faults were last cleared. Faults are fatal errors
        that prevent the motor from running.
        
        Sticky faults can be cleared with SparkBase::ClearFaults().
        
        :returns: A struct with each fault and their sticky value
        """
    def getStickyWarnings(self) -> SparkBase.Warnings:
        """
        Get the sticky warnings that were present on the SPARK at one point
        since the sticky warnings were last cleared. Warnings are non-fatal
        errors.
        
        Sticky warnings can be cleared with SparkBase::clearFaults().
        
        :returns: A struct with each warning and their sticky value
        """
    def getWarnings(self) -> SparkBase.Warnings:
        """
        Get the active warnings that are currently present on the SPARK.
        Warnings are non-fatal errors.
        
        :returns: A struct with each warning and their active value
        """
    def hasActiveFault(self) -> bool:
        ...
    def hasActiveWarning(self) -> bool:
        """
        Get whether the SPARK has one or more active warnings.
        
        :returns: true if there is an active warning
                  @see GetWarnings()
        """
    def hasStickyFault(self) -> bool:
        """
        Get whether the SPARK has one or more sticky faults.
        
        :returns: true if there is a sticky fault
                  @see GetStickyFaults()
        """
    def hasStickyWarning(self) -> bool:
        """
        Get whether the SPARK has one or more sticky warnings.
        
        :returns: true if there is a sticky warning
                  @see GetStickyWarnings()
        """
    def isFollower(self) -> bool:
        """
        Returns whether the controller is following another controller
        
        :returns: True if this device is following another controller false
                  otherwise
        """
    def pauseFollowerMode(self) -> REVLibError:
        """
        Pause follower mode.
        
        NOTE: If the SPARK experiences a power cycle and has follower mode
        configured, follower mode will automatically restart.
        
        :returns: REVLibError::kOk if successful
        """
    def pauseFollowerModeAsync(self) -> REVLibError:
        """
        Pause follower mode without waiting for a response.
        
        NOTE: If the SPARK experiences a power cycle and has follower mode
        configured, follower mode will automatically restart.
        
        NOTE: This method will immediately return REVLibError::kOk and the
        action will be done in the background. Any errors that occur will be
        reported to the driver station.
        
        :returns: REVLibError::kOk
                  @see PauseFollowerMode()
        """
    def resumeFollowerMode(self) -> REVLibError:
        """
        Resume follower mode if the SPARK has a valid follower mode config.
        
        NOTE: Follower mode will start automatically upon configuring follower
        mode. If the SPARK experiences a power cycle and has follower mode
        configured, follower mode will automatically restart. This method is only
        useful after PauseFollowerMode() has been called.
        
        :returns: REVLibError::kOk if successful
        """
    def resumeFollowerModeAsync(self) -> REVLibError:
        """
        Resume follower mode if the SPARK has a valid follower
        mode config without waiting for a response.
        
        NOTE: Follower mode will start automatically upon configuring follower
        mode. If the SPARK experiences a power cycle and has follower mode
        configured, follower mode will automatically restart. This method is only
        useful after PauseFollowerMode() has been called.
        
        NOTE: This method will immediately return REVLibError::kOk and the
        action will be done in the background. Any errors that occur will be
        reported to the driver station.
        
        :returns: REVLibError::kOk
                  @see ResumeFollowerMode()
        """
    def set(self, speed: typing.SupportsFloat) -> None:
        """
        Common interface for setting the speed of a speed controller.
        
        :param speed: The speed to set.  Value should be between -1.0 and 1.0.
        """
    def setCANTimeout(self, milliseconds: typing.SupportsInt) -> REVLibError:
        """
        Sets the timeout duration for waiting for CAN responses from the device.
        
        :param milliseconds: The timeout in milliseconds.
        """
    def setInverted(self, isInverted: bool) -> None:
        """
        Common interface for inverting direction of a speed controller.
        
        This call has no effect if the controller is a follower. To invert
        a follower, see the follow() method.
        
        :deprecated: Use SparkBaseConfig.Inverted() with Configure() instead
        
        :param isInverted: The state of inversion, true is inverted.
        """
    def setVoltage(self, output: wpimath.units.volts) -> None:
        """
        Sets the voltage output of the SpeedController.  This is equivalent to
        a call to SetReference(output, SparkBase::ControlType::kVoltage). The
        behavior of this call differs slightly from the WPILib documentation for
        this call since the device internally sets the desired voltage (not a
        compensation value). That means that this *can* be a 'set-and-forget'
        call.
        
        :param output: The voltage to output.
        """
    def stopMotor(self) -> None:
        """
        Common interface to stop the motor until Set is called again.
        """
class SparkBaseConfig(BaseConfig):
    class IdleMode:
        """
        Members:
        
          kCoast
        
          kBrake
        """
        __members__: typing.ClassVar[dict[str, SparkBaseConfig.IdleMode]]  # value = {'kCoast': <IdleMode.kCoast: 0>, 'kBrake': <IdleMode.kBrake: 1>}
        kBrake: typing.ClassVar[SparkBaseConfig.IdleMode]  # value = <IdleMode.kBrake: 1>
        kCoast: typing.ClassVar[SparkBaseConfig.IdleMode]  # value = <IdleMode.kCoast: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Presets:
        @staticmethod
        def CTRE_Minion() -> SparkBaseConfig:
            ...
        @staticmethod
        def REV_NEO() -> SparkBaseConfig:
            """
            REV Robotics - NEO Brushless Motor V1.1
            """
        @staticmethod
        def REV_NEO_2() -> SparkBaseConfig:
            """
            REV Robotics - NEO Brushless Motor 2.0
            """
        @staticmethod
        def REV_NEO_550() -> SparkBaseConfig:
            """
            REV Robotics - NEO 550 Brushless Motor
            """
        @staticmethod
        def REV_Vortex() -> SparkBaseConfig:
            """
            REV Robotics - NEO Vortex Brushless Motor
            """
        def __init__(self) -> None:
            ...
    def __init__(self) -> None:
        ...
    def advanceCommutation(self, byDegrees: typing.SupportsFloat = 0.0) -> SparkBaseConfig:
        """
        Advances the commutation angle of the motor by a specified number of
        degrees.
        
        Warning: This is an advanced feature that should only be used if you
        know what you are doing. Incorrectly setting the commutation angle can
        cause changes to torque, efficiency, and the operating range of the
        motor.
        
        :param byDegrees: The number of degrees to advance the commutation angle
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    @typing.overload
    def apply(self, config: SparkBaseConfig) -> SparkBaseConfig:
        """
        Applies settings from another SparkBaseConfig to this one,
        including all of its nested configurations.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SparkBaseConfig to copy settings from
        
        :returns: The updated SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: AbsoluteEncoderConfig) -> SparkBaseConfig:
        """
        Applies settings from an  AbsoluteEncoderConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  AbsoluteEncoderConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: AnalogSensorConfig) -> SparkBaseConfig:
        """
        Applies settings from an  AnalogSensorConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  AnalogSensorConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: EncoderConfig) -> SparkBaseConfig:
        """
        Applies settings from an  EncoderConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  EncoderConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: LimitSwitchConfig) -> SparkBaseConfig:
        """
        Applies settings from a  LimitSwitchConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  LimitSwitchConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: SoftLimitConfig) -> SparkBaseConfig:
        """
        Applies settings from a  SoftLimitConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  SoftLimitConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: ClosedLoopConfig) -> SparkBaseConfig:
        """
        Applies settings from a  ClosedLoopConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  ClosedLoopConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    @typing.overload
    def apply(self, config: SignalsConfig) -> SparkBaseConfig:
        """
        Applies settings from a  SignalsConfig to this
        SparkBaseConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The  SignalsConfig to copy settings from
        
        :returns: The updated  SparkBaseConfig for method chaining
        """
    def closedLoopRampRate(self, rate: typing.SupportsFloat) -> SparkBaseConfig:
        """
        Sets the ramp rate for closed loop control modes.
        
        This is the maximum rate at which the motor controller's output is
        allowed to change.
        
        :param rate: Time in seconds to go from 0 to full throttle.
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def disableFollowerMode(self) -> SparkBaseConfig:
        """
        Disables follower mode on the controller.
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def disableVoltageCompensation(self) -> SparkBaseConfig:
        """
        Disables the voltage compensation setting for all modes on the SPARK.
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def flatten(self) -> str:
        ...
    @typing.overload
    def follow(self, leaderCanId: typing.SupportsInt, invert: bool = False) -> SparkBaseConfig:
        """
        Causes this controller's output to mirror the provided leader.
        
        Only voltage output is mirrored. Settings changed on the leader do not
        affect the follower.
        
        Following anything other than a CAN-enabled SPARK is not officially
        supported.
        
        :param leaderCanId: The CAN ID of the device to follow.
        :param invert:      Set the follower to output opposite of the leader
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    @typing.overload
    def follow(self, leader: SparkBase, invert: bool = False) -> SparkBaseConfig:
        """
        Causes this controller's output to mirror the provided leader.
        
        Only voltage output is mirrored. Settings changed on the leader do not
        affect the follower.
        
        Following anything other than a CAN-enabled SPARK is not officially
        supported.
        
        :param leader: The motor controller to follow.
        :param invert: Set the follower to output opposite of the leader
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def inverted(self, inverted: bool) -> SparkBaseConfig:
        """
        Common interface for inverting direction of a speed controller.
        
        This call has no effect if the controller is a follower. To invert a
        follower, see the follow() method.
        
        :param inverted: True for inverted
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def openLoopRampRate(self, rate: typing.SupportsFloat) -> SparkBaseConfig:
        """
        Sets the ramp rate for open loop control modes.
        
        This is the maximum rate at which the motor controller's output is
        allowed to change.
        
        :param rate: Time in seconds to go from 0 to full throttle.
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def secondaryCurrentLimit(self, limit: typing.SupportsFloat, chopCycles: typing.SupportsInt = 0) -> SparkBaseConfig:
        """
        Sets the secondary current limit in Amps.
        
        The motor controller will disable the output of the controller briefly
        if the current limit is exceeded to reduce the current. This limit is a
        simplified 'on/off' controller. This limit is enabled by default but is
        set higher than the default Smart Current Limit.
        
        The time the controller is off after the current limit is reached is
        determined by the parameter limitCycles, which is the number of PWM
        cycles (20kHz). The recommended value is the default of 0 which is the
        minimum time and is part of a PWM cycle from when the over current is
        detected. This allows the controller to regulate the current close to the
        limit value.
        
        The total time is set by the equation <code>
        t = (50us - t0) + 50us * limitCycles
        t = total off time after over current
        t0 = time from the start of the PWM cycle until over current is detected
        </code>
        
        :param limit:      The current limit in Amps.
        :param chopCycles: The number of additional PWM cycles to turn the driver
                           off after overcurrent is detected.
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def setIdleMode(self, idleMode: SparkBaseConfig.IdleMode) -> SparkBaseConfig:
        """
        Sets the idle mode setting for the SPARK.
        
        :param idleMode: kCoast or kBrake
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def smartCurrentLimit(self, stallLimit: typing.SupportsInt, freeLimit: typing.SupportsInt = 0, limitRpm: typing.SupportsInt = 20000) -> SparkBaseConfig:
        """
        Sets the current limit in Amps.
        
        The motor controller will reduce the controller voltage output to
        avoid surpassing this limit. This limit is enabled by default and used
        for brushless only. This limit is highly recommended when using the NEO
        brushless motor.
        
        The NEO Brushless Motor has a low internal resistance, which can mean
        large current spikes that could be enough to cause damage to the motor
        and controller. This current limit provides a smarter strategy to deal
        with high current draws and keep the motor and controller operating in a
        safe region.
        
        The controller can also limit the current based on the RPM of the
        motor in a linear fashion to help with controllability in closed loop
        control. For a response that is linear the entire RPM range leave limit
        RPM at 0.
        
        :param stallLimit: The current limit in Amps at 0 RPM.
        :param freeLimit:  The current limit at free speed (5700RPM for NEO).
        :param limitRpm:   RPM less than this value will be set to the stallLimit,
                           RPM values greater than limitRpm will scale linearly to freeLimit
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    def voltageCompensation(self, nominalVoltage: typing.SupportsFloat) -> SparkBaseConfig:
        """
        Sets the voltage compensation setting for all modes on the SPARK and
        enables voltage compensation.
        
        :param nominalVoltage: Nominal voltage to compensate output to
        
        :returns: The modified SparkBaseConfig object for method chaining
        """
    @property
    def absoluteEncoder(self) -> AbsoluteEncoderConfig:
        ...
    @property
    def analogSensor(self) -> AnalogSensorConfig:
        ...
    @property
    def closedLoop(self) -> ClosedLoopConfig:
        ...
    @property
    def encoder(self) -> EncoderConfig:
        ...
    @property
    def limitSwitch(self) -> LimitSwitchConfig:
        ...
    @property
    def signals(self) -> SignalsConfig:
        ...
    @property
    def softLimit(self) -> SoftLimitConfig:
        ...
class SparkBaseConfigAccessor:
    def getAdvanceCommutation(self) -> float:
        ...
    def getClosedLoopRampRate(self) -> float:
        ...
    def getFollowerModeInverted(self) -> bool:
        ...
    def getFollowerModeLeaderId(self) -> int:
        ...
    def getIdleMode(self) -> SparkBaseConfig.IdleMode:
        ...
    def getInverted(self) -> bool:
        ...
    def getOpenLoopRampRate(self) -> float:
        ...
    def getSecondaryCurrentLimit(self) -> float:
        ...
    def getSecondaryCurrentLimitChopCycles(self) -> int:
        ...
    def getSmartCurrentFreeLimit(self) -> int:
        ...
    def getSmartCurrentLimit(self) -> int:
        ...
    def getSmartCurrentRPMLimit(self) -> int:
        ...
    def getVoltageCompensation(self) -> float:
        ...
    def getVoltageCompensationEnabled(self) -> bool:
        ...
    @property
    def absoluteEncoder(self) -> AbsoluteEncoderConfigAccessor:
        """
        Accessor for parameters relating to the absolute encoder. To configure
        these values, use AbsoluteEncoderConfig and call SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def analogSensor(self) -> AnalogSensorConfigAccessor:
        """
        Accessor for parameters relating to the analog sensor. To configure
        these values, use AnalogSensorConfig and call SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def closedLoop(self) -> ClosedLoopConfigAccessor:
        """
        Accessor for parameters relating to the closed loop controller. To
        configure these values, use ClosedLoopConfig and call
        SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def encoder(self) -> EncoderConfigAccessor:
        """
        Accessor for parameters relating to the primary encoder. To configure
        these values, use EncoderConfig and call SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def limitSwitch(self) -> LimitSwitchConfigAccessor:
        """
        Accessor for parameters relating to the hardware limit switches. To
        configure these values, use LimitSwitchConfig and call
        SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def signals(self) -> SignalsConfigAccessor:
        """
        Accessor for parameters relating to status signals. To configure
        these values, use SignalsConfig and call SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
    @property
    def softLimit(self) -> SoftLimitConfigAccessor:
        """
        Accessor for parameters relating to the software limits. To configure
        these values, use SoftLimitConfig and call SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
class SparkClosedLoopController:
    class ArbFFUnits:
        """
        Units for arbitrary feed-forward
        
        Members:
        
          kVoltage
        
          kPercentOut
        """
        __members__: typing.ClassVar[dict[str, SparkClosedLoopController.ArbFFUnits]]  # value = {'kVoltage': <ArbFFUnits.kVoltage: 0>, 'kPercentOut': <ArbFFUnits.kPercentOut: 1>}
        kPercentOut: typing.ClassVar[SparkClosedLoopController.ArbFFUnits]  # value = <ArbFFUnits.kPercentOut: 1>
        kVoltage: typing.ClassVar[SparkClosedLoopController.ArbFFUnits]  # value = <ArbFFUnits.kVoltage: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def getControlType(self) -> SparkLowLevel.ControlType:
        """
        Get the selected control type used when SetReference() was called.
        
        :returns: The selected control type
        """
    def getIAccum(self) -> float:
        """
        Get the I accumulator of the closed loop controller. This is useful when
        wishing to see what the I accumulator value is to help with PID tuning
        
        :returns: The value of the I accumulator
        """
    def getMAXMotionSetpointPosition(self) -> float:
        """
        Get the MAXMotion internal setpoint position.
        
        This will be 0 if the controller is not in a MAXMotion control mode.
        
        :returns: The MAXMotion internal setpoint position in rotations or units
                  specified by the conversion factor.
        """
    def getMAXMotionSetpointVelocity(self) -> float:
        """
        Get the MAXMotion internal setpoint velocity.
        
        This will be 0 if the controller is not in a MAXMotion control mode.
        
        :returns: The MAXMotion internal setpoint velocity in rotations per minute
                  or units specified by the conversion factor.
        """
    def getSelectedSlot(self) -> ClosedLoopSlot:
        """
        Get the selected closed loop PID slot.
        
        :returns: The selected closed loop PID slot
        """
    def getSetpoint(self) -> float:
        """
        Get the internal setpoint of the closed loop controller.
        
        :returns: The internal setpoint
        """
    def isAtSetpoint(self) -> bool:
        """
        Determine if the setpoint has been reached.
        
        :returns: true if the setpoint is reached; false otherwise
        """
    def setIAccum(self, iAccum: typing.SupportsFloat) -> REVLibError:
        """
        Set the I accumulator of the closed loop controller. This is useful when
        wishing to force a reset on the I accumulator of the Closed Loop
        Controller. You can also preset values to see how it will respond to
        certain I characteristics
        
        To use this function, the controller must be in a closed loop control
        mode by calling setReference()
        
        :param iAccum: The value to set the I accumulator to
        
        :returns: REVLibError::kOk if successful
        """
    def setReference(self, setpoint: typing.SupportsFloat, ctrl: SparkLowLevel.ControlType, slot: ClosedLoopSlot = ..., arbFeedforward: typing.SupportsFloat = 0, arbFFUnits: SparkClosedLoopController.ArbFFUnits = ...) -> REVLibError:
        """
        Set the controller setpoint based on the selected control mode.
        
        :deprecated: Use SetSetpoint instead.
        
        :param setpoint:       The setpoint to set depending on the control mode. For:
                               - basic duty cycle control this should be a value between -1 and 1
                               - Voltage Control: Voltage (volts)
                               - Velocity Control: Velocity (RPM)
                               - Position Control: Position (Rotations)
                               - Current Control: Current (Amps).
                               The units can be changed for position and velocity by a scale
                               factor using AlternateEncoderConfig::PositionConversionFactor(), or
                               ExternalEncoderConfig::PositionConversionFactor(), or
                               EncoderConfig::PositionConversionFactor() or
                               AlternateEncoderConfig::VelocityConversionFactor(), or
                               ExternalEncoderConfig::VelocityConversionFactor(), or
                               EncoderConfig::VelocityConversionFactor().
        :param ctrl:           Is the control type
        :param slot:           The ClosedLoopSlot to use
        :param arbFeedforward: A value from -32.0 to 32.0 which is a voltage
                               applied to the motor after the result of the specified control mode. The
                               units for the parameter is Volts. This value is set after the control
                               mode, but before any current limits or ramp rates.
        :param arbFFUnits:     the units for arbitrary feed-forward
        
        :returns: REVLibError::kOk if successful
        """
    def setSetpoint(self, setpoint: typing.SupportsFloat, ctrl: SparkLowLevel.ControlType, slot: ClosedLoopSlot = ..., arbFeedforward: typing.SupportsFloat = 0, arbFFUnits: SparkClosedLoopController.ArbFFUnits = ...) -> REVLibError:
        """
        Set the controller setpoint based on the selected control mode.
        
        :param setpoint:       The setpoint to set depending on the control mode. For:
                               - basic duty cycle control this should be a value between -1 and 1
                               - Voltage Control: Voltage (volts)
                               - Velocity Control: Velocity (RPM)
                               - Position Control: Position (Rotations)
                               - Current Control: Current (Amps).
                               The units can be changed for position and velocity by a scale
                               factor using AlternateEncoderConfig::PositionConversionFactor(), or
                               ExternalEncoderConfig::PositionConversionFactor(), or
                               EncoderConfig::PositionConversionFactor() or
                               AlternateEncoderConfig::VelocityConversionFactor(), or
                               ExternalEncoderConfig::VelocityConversionFactor(), or
                               EncoderConfig::VelocityConversionFactor().
        :param ctrl:           Is the control type
        :param slot:           The ClosedLoopSlot to use
        :param arbFeedforward: A value from -32.0 to 32.0 which is a voltage
                               applied to the motor after the result of the specified control mode. The
                               units for the parameter is Volts. This value is set after the control
                               mode, but before any current limits or ramp rates.
        :param arbFFUnits:     the units for arbitrary feed-forward
        
        :returns: REVLibError::kOk if successful
        """
class SparkExternalEncoderSim:
    def __init__(self, motor: SparkFlex) -> None:
        ...
    def getInverted(self) -> bool:
        ...
    def getPosition(self) -> float:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroOffset(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def setZeroOffset(self, zeroOffset: typing.SupportsFloat) -> None:
        ...
class SparkFlex(SparkBase):
    def __init__(self, deviceID: typing.SupportsInt, type: SparkLowLevel.MotorType) -> None:
        """
        Create a new object to control a SPARK Flex motor Controller
        
        :param deviceID: The device ID.
        :param type:     The motor type connected to the controller. Brushless
                         motor wires must be connected to their matching colors,
                         and the hall sensor must be plugged in. Brushed motors
                         must be connected to the Red and Black terminals only.
        """
    def getExternalEncoder(self) -> SparkFlexExternalEncoder:
        """
        Returns an object for interfacing with an external quadrature encoder
        """
    @property
    def configAccessor(self) -> SparkFlexConfigAccessor:
        """
        Accessor for SPARK parameter values. This object contains fields and
        methods to retrieve parameters that have been applied to the device. To
        set parameters, see SparkBaseConfig and SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and should
        be used infrequently.
        """
class SparkFlexConfig(SparkBaseConfig):
    def __init__(self) -> None:
        ...
    @typing.overload
    def apply(self, config: SparkBaseConfig) -> SparkFlexConfig:
        """
        Applies settings from a SparkBaseConfig to this one; primarily
        used to apply Presets.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SparkBaseConfig to copy settings from
        
        :returns: The updated SparkFlexConfig for method chaining
        """
    @typing.overload
    def apply(self, config: SparkFlexConfig) -> SparkFlexConfig:
        """
        Applies settings from another  SparkFlexConfig to this one,
        including all of its nested configurations.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SparkFlexConfig to copy settings from
        
        :returns: The updated SparkFlexConfig for method chaining
        """
    @typing.overload
    def apply(self, config: ExternalEncoderConfig) -> SparkFlexConfig:
        """
        Applies settings from an ExternalEncoderConfig to this
        SparkFlexConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The ExternalEncoderConfig to copy settings from
        
        :returns: The updated SparkFlexConfig for method chaining
        """
    @typing.overload
    def apply(self, config: SparkBaseConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: AbsoluteEncoderConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: AnalogSensorConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: EncoderConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: LimitSwitchConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: SoftLimitConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: ClosedLoopConfig) -> SparkFlexConfig:
        ...
    @typing.overload
    def apply(self, config: SignalsConfig) -> SparkFlexConfig:
        ...
    def flatten(self) -> str:
        ...
    @property
    def externalEncoder(self) -> ExternalEncoderConfig:
        ...
class SparkFlexConfigAccessor(SparkBaseConfigAccessor):
    @property
    def externalEncoder(self) -> ExternalEncoderConfigAccessor:
        """
        Accessor for parameters relating to the external encoder. To configure
        these values, use ExternalEncoderConfig and call SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
class SparkFlexExternalEncoder(RelativeEncoder):
    def getPosition(self) -> float:
        """
        Get the position of the motor. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using ExternalEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the motor
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the motor. This returns the native units
        of 'RPM' by default, and can be changed by a scale factor
        using ExternalEncoderConfig::VelocityConversionFactor().
        
        :returns: Number the RPM of the motor
        """
    def setPosition(self, position: typing.SupportsFloat) -> REVLibError:
        """
        Set the position of the encoder.
        
        :param position: Number of rotations of the motor
        
        :returns: REVLibError::kOk if successful
        """
class SparkFlexSim(SparkSim):
    def __init__(self, sparkFlex: SparkFlex, motor: wpimath._controls._controls.plant.DCMotor) -> None:
        ...
    def getExternalEncoderSim(self) -> SparkExternalEncoderSim:
        ...
class SparkLimitSwitch:
    def get(self) -> bool:
        """
        Get the state of the limit switch, whether or not it is enabled
        (limiting the rotation of the motor).
        """
class SparkLimitSwitchSim:
    @typing.overload
    def __init__(self, motor: SparkMax, forward: bool) -> None:
        ...
    @typing.overload
    def __init__(self, motor: SparkFlex, forward: bool) -> None:
        ...
    def getEnabled(self) -> bool:
        ...
    def getPressed(self) -> bool:
        ...
    def setPressed(self, state: bool) -> None:
        ...
class SparkLowLevel(wpilib.interfaces._interfaces.MotorController):
    class ControlType:
        """
        Members:
        
          kDutyCycle
        
          kVelocity
        
          kVoltage
        
          kPosition
        
          kCurrent
        
          kMAXMotionPositionControl
        
          kMAXMotionVelocityControl
        """
        __members__: typing.ClassVar[dict[str, SparkLowLevel.ControlType]]  # value = {'kDutyCycle': <ControlType.kDutyCycle: 0>, 'kVelocity': <ControlType.kVelocity: 1>, 'kVoltage': <ControlType.kVoltage: 2>, 'kPosition': <ControlType.kPosition: 3>, 'kCurrent': <ControlType.kCurrent: 4>, 'kMAXMotionPositionControl': <ControlType.kMAXMotionPositionControl: 5>, 'kMAXMotionVelocityControl': <ControlType.kMAXMotionVelocityControl: 6>}
        kCurrent: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kCurrent: 4>
        kDutyCycle: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kDutyCycle: 0>
        kMAXMotionPositionControl: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kMAXMotionPositionControl: 5>
        kMAXMotionVelocityControl: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kMAXMotionVelocityControl: 6>
        kPosition: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kPosition: 3>
        kVelocity: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kVelocity: 1>
        kVoltage: typing.ClassVar[SparkLowLevel.ControlType]  # value = <ControlType.kVoltage: 2>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class MotorType:
        """
        Members:
        
          kBrushed
        
          kBrushless
        """
        __members__: typing.ClassVar[dict[str, SparkLowLevel.MotorType]]  # value = {'kBrushed': <MotorType.kBrushed: 0>, 'kBrushless': <MotorType.kBrushless: 1>}
        kBrushed: typing.ClassVar[SparkLowLevel.MotorType]  # value = <MotorType.kBrushed: 0>
        kBrushless: typing.ClassVar[SparkLowLevel.MotorType]  # value = <MotorType.kBrushless: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class ParameterStatus:
        """
        Members:
        
          kOK
        
          kInvalidID
        
          kMismatchType
        
          kAccessMode
        
          kInvalid
        
          kNotImplementedDeprecated
        """
        __members__: typing.ClassVar[dict[str, SparkLowLevel.ParameterStatus]]  # value = {'kOK': <ParameterStatus.kOK: 0>, 'kInvalidID': <ParameterStatus.kInvalidID: 1>, 'kMismatchType': <ParameterStatus.kMismatchType: 2>, 'kAccessMode': <ParameterStatus.kAccessMode: 3>, 'kInvalid': <ParameterStatus.kInvalid: 4>, 'kNotImplementedDeprecated': <ParameterStatus.kNotImplementedDeprecated: 5>}
        kAccessMode: typing.ClassVar[SparkLowLevel.ParameterStatus]  # value = <ParameterStatus.kAccessMode: 3>
        kInvalid: typing.ClassVar[SparkLowLevel.ParameterStatus]  # value = <ParameterStatus.kInvalid: 4>
        kInvalidID: typing.ClassVar[SparkLowLevel.ParameterStatus]  # value = <ParameterStatus.kInvalidID: 1>
        kMismatchType: typing.ClassVar[SparkLowLevel.ParameterStatus]  # value = <ParameterStatus.kMismatchType: 2>
        kNotImplementedDeprecated: typing.ClassVar[SparkLowLevel.ParameterStatus]  # value = <ParameterStatus.kNotImplementedDeprecated: 5>
        kOK: typing.ClassVar[SparkLowLevel.ParameterStatus]  # value = <ParameterStatus.kOK: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class PeriodicFrame:
        """
        Members:
        
          kStatus0
        
          kStatus1
        
          kStatus2
        
          kStatus3
        
          kStatus4
        
          kStatus5
        
          kStatus6
        
          kStatus7
        
          kStatus8
        
          kStatus9
        """
        __members__: typing.ClassVar[dict[str, SparkLowLevel.PeriodicFrame]]  # value = {'kStatus0': <PeriodicFrame.kStatus0: 0>, 'kStatus1': <PeriodicFrame.kStatus1: 1>, 'kStatus2': <PeriodicFrame.kStatus2: 2>, 'kStatus3': <PeriodicFrame.kStatus3: 3>, 'kStatus4': <PeriodicFrame.kStatus4: 4>, 'kStatus5': <PeriodicFrame.kStatus5: 5>, 'kStatus6': <PeriodicFrame.kStatus6: 6>, 'kStatus7': <PeriodicFrame.kStatus7: 7>, 'kStatus8': <PeriodicFrame.kStatus8: 8>, 'kStatus9': <PeriodicFrame.kStatus9: 9>}
        kStatus0: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus0: 0>
        kStatus1: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus1: 1>
        kStatus2: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus2: 2>
        kStatus3: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus3: 3>
        kStatus4: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus4: 4>
        kStatus5: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus5: 5>
        kStatus6: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus6: 6>
        kStatus7: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus7: 7>
        kStatus8: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus8: 8>
        kStatus9: typing.ClassVar[SparkLowLevel.PeriodicFrame]  # value = <PeriodicFrame.kStatus9: 9>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class PeriodicStatus0:
        hardForwardLimitReached: bool
        hardReverseLimitReached: bool
        inverted: bool
        primaryHeartbeatLock: bool
        softForwardLimitReached: bool
        softReverseLimitReached: bool
        def __init__(self) -> None:
            ...
        @property
        def appliedOutput(self) -> float:
            ...
        @appliedOutput.setter
        def appliedOutput(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def current(self) -> float:
            ...
        @current.setter
        def current(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def motorTemperature(self) -> int:
            ...
        @motorTemperature.setter
        def motorTemperature(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def voltage(self) -> float:
            ...
        @voltage.setter
        def voltage(self, arg0: typing.SupportsFloat) -> None:
            ...
    class PeriodicStatus1:
        brownoutStickyWarning: bool
        brownoutWarning: bool
        canFault: bool
        canStickyFault: bool
        drvFault: bool
        drvStickyFault: bool
        escEepromFault: bool
        escEepromStickyFault: bool
        escEepromStickyWarning: bool
        escEepromWarning: bool
        extEepromStickyWarning: bool
        extEepromWarning: bool
        firmwareFault: bool
        firmwareStickyFault: bool
        hasResetStickyWarning: bool
        hasResetWarning: bool
        isFollower: bool
        motorTypeFault: bool
        motorTypeStickyFault: bool
        otherFault: bool
        otherStickyFault: bool
        otherStickyWarning: bool
        otherWarning: bool
        overcurrentStickyWarning: bool
        overcurrentWarning: bool
        sensorFault: bool
        sensorStickyFault: bool
        sensorStickyWarning: bool
        sensorWarning: bool
        stallStickyWarning: bool
        stallWarning: bool
        temperatureFault: bool
        temperatureStickyFault: bool
        def __init__(self) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus2:
        def __init__(self) -> None:
            ...
        @property
        def primaryEncoderPosition(self) -> float:
            ...
        @primaryEncoderPosition.setter
        def primaryEncoderPosition(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def primaryEncoderVelocity(self) -> float:
            ...
        @primaryEncoderVelocity.setter
        def primaryEncoderVelocity(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus3:
        def __init__(self) -> None:
            ...
        @property
        def analogPosition(self) -> float:
            ...
        @analogPosition.setter
        def analogPosition(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def analogVelocity(self) -> float:
            ...
        @analogVelocity.setter
        def analogVelocity(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def analogVoltage(self) -> float:
            ...
        @analogVoltage.setter
        def analogVoltage(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus4:
        def __init__(self) -> None:
            ...
        @property
        def externalOrAltEncoderPosition(self) -> float:
            ...
        @externalOrAltEncoderPosition.setter
        def externalOrAltEncoderPosition(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def externalOrAltEncoderVelocity(self) -> float:
            ...
        @externalOrAltEncoderVelocity.setter
        def externalOrAltEncoderVelocity(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus5:
        def __init__(self) -> None:
            ...
        @property
        def dutyCycleEncoderPosition(self) -> float:
            ...
        @dutyCycleEncoderPosition.setter
        def dutyCycleEncoderPosition(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def dutyCycleEncoderVelocity(self) -> float:
            ...
        @dutyCycleEncoderVelocity.setter
        def dutyCycleEncoderVelocity(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus6:
        dutyCycleNoSignal: bool
        def __init__(self) -> None:
            ...
        @property
        def dutyCyclePeriod(self) -> float:
            ...
        @dutyCyclePeriod.setter
        def dutyCyclePeriod(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
        @property
        def unadjustedDutyCycle(self) -> float:
            ...
        @unadjustedDutyCycle.setter
        def unadjustedDutyCycle(self, arg0: typing.SupportsFloat) -> None:
            ...
    class PeriodicStatus7:
        def __init__(self) -> None:
            ...
        @property
        def iAccumulation(self) -> float:
            ...
        @iAccumulation.setter
        def iAccumulation(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus8:
        isAtSetpoint: bool
        selectedPidSlot: ClosedLoopSlot
        def __init__(self) -> None:
            ...
        @property
        def setpoint(self) -> float:
            ...
        @setpoint.setter
        def setpoint(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class PeriodicStatus9:
        def __init__(self) -> None:
            ...
        @property
        def maxMotionSetpointPosition(self) -> float:
            ...
        @maxMotionSetpointPosition.setter
        def maxMotionSetpointPosition(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def maxMotionSetpointVelocity(self) -> float:
            ...
        @maxMotionSetpointVelocity.setter
        def maxMotionSetpointVelocity(self, arg0: typing.SupportsFloat) -> None:
            ...
        @property
        def timestamp(self) -> int:
            ...
        @timestamp.setter
        def timestamp(self, arg0: typing.SupportsInt) -> None:
            ...
    class SparkModel:
        """
        Members:
        
          kUnknown
        
          kSparkFlex
        
          kSparkMax
        """
        __members__: typing.ClassVar[dict[str, SparkLowLevel.SparkModel]]  # value = {'kUnknown': <SparkModel.kUnknown: 0>, 'kSparkFlex': <SparkModel.kSparkFlex: 1>, 'kSparkMax': <SparkModel.kSparkMax: 2>}
        kSparkFlex: typing.ClassVar[SparkLowLevel.SparkModel]  # value = <SparkModel.kSparkFlex: 1>
        kSparkMax: typing.ClassVar[SparkLowLevel.SparkModel]  # value = <SparkModel.kSparkMax: 2>
        kUnknown: typing.ClassVar[SparkLowLevel.SparkModel]  # value = <SparkModel.kUnknown: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    kAPIBuildVersion: typing.ClassVar[int] = 1
    kAPIMajorVersion: typing.ClassVar[int] = 2026
    kAPIMinorVersion: typing.ClassVar[int] = 0
    kAPIVersion: typing.ClassVar[int] = 132775937
    def createSimFaultManager(self) -> None:
        """
        Create the sim gui Fault Manager for this Spark Device
        """
    def getDeviceId(self) -> int:
        """
        Get the configured Device ID of the SPARK.
        
        :returns: int device ID
        """
    def getFirmwareString(self) -> str:
        """
        Get the firmware version of the SPARK as a string.
        
        :returns: std::string Human readable firmware version string
        """
    @typing.overload
    def getFirmwareVersion(self) -> int:
        """
        Get the firmware version of the SPARK.
        
        :returns: uint32_t Firmware version integer. Value is represented as 4
                  bytes, Major.Minor.Build H.Build L
        """
    @typing.overload
    def getFirmwareVersion(self) -> tuple[int, bool]:
        ...
    def getMotorType(self) -> SparkLowLevel.MotorType:
        """
        Get the motor type setting for the SPARK.
        
        :returns: MotorType Motor type setting
        """
    def getPeriodicStatus8(self) -> SparkLowLevel.PeriodicStatus8:
        """
        Get Periodic Status 8 for the SPARK.
        
        :returns: PeriodicStatus8 Periodic status 8
        """
    def getPeriodicStatus9(self) -> SparkLowLevel.PeriodicStatus9:
        """
        Get Periodic Status 9 for the SPARK.
        
        :returns: PeriodicStatus9 Periodic status 9
        """
    def getSerialNumber(self) -> list[int]:
        """
        Get the unique serial number of the SPARK. Currently not implemented.
        
        :returns: std::vector<uint8_t> Vector of bytes representig the unique
                  serial number
        """
    def setCANMaxRetries(self, numRetries: typing.SupportsInt) -> None:
        """
        Set the maximum number of times to retry an RTR CAN frame. This applies
        to calls such as SetParameter* and GetParameter* where a request is made
        to the SPARK motor controller and a response is expected. Anytime sending
        the request or receiving the response fails, it will retry the request a
        number of times, no more than the value set by this method. If an attempt
        succeeds, it will immediately return. The minimum number of retries is 0,
        where only a single attempt will be made and will return regardless of
        success or failure.
        
        The default maximum is 5 retries.
        
        :param numRetries: The maximum number of retries
        """
    def setControlFramePeriodMs(self, periodMs: typing.SupportsInt) -> None:
        """
        Set the control frame send period for the native CAN Send thread. To
        disable periodic sends, set periodMs to 0.
        
        :param periodMs: The send period in milliseconds between 1ms and 100ms
                         or set to 0 to disable periodic sends. Note this is not updated until
                         the next call to Set() or SetReference().
        """
    def setPeriodicFrameTimeout(self, timeoutMs: typing.SupportsInt) -> None:
        """
        Set the amount of time to wait for a periodic status frame before
        returning a timeout error. This timeout will apply to all periodic status
        frames for the SPARK motor controller.
        
        To prevent invalid timeout errors, the minimum timeout for a given
        periodic status is 2.1 times its period. To use the minimum timeout for
        all status frames, set timeoutMs to 0.
        
        The default timeout is 500ms.
        
        :param timeoutMs: The timeout in milliseconds
        """
class SparkMax(SparkBase):
    def __init__(self, deviceID: typing.SupportsInt, type: SparkLowLevel.MotorType) -> None:
        """
        Create a new object to control a SPARK MAX motor Controller
        
        :param deviceID: The device ID.
        :param type:     The motor type connected to the controller. Brushless
                         motor wires must be connected to their matching colors,
                         and the hall sensor must be plugged in. Brushed motors must be connected
                         to the Red and Black terminals only.
        """
    def configure(self, config: SparkBaseConfig, resetMode: ResetMode, persistMode: PersistMode) -> REVLibError:
        ...
    def getAbsoluteEncoder(self) -> SparkAbsoluteEncoder:
        ...
    def getAlternateEncoder(self) -> SparkMaxAlternateEncoder:
        """
        Returns an object for interfacing with a quadrature encoder connected to
        the alternate encoder mode data port pins. These are defined as:
        
        Pin 4 (Forward Limit Switch): Index
        Pin 6 (Multi-function): Encoder A
        Pin 8 (Reverse Limit Switch): Encoder B
        
        This call will disable support for the limit switch inputs.
        """
    def getForwardLimitSwitch(self) -> SparkLimitSwitch:
        ...
    def getReverseLimitSwitch(self) -> SparkLimitSwitch:
        ...
    @property
    def configAccessor(self) -> SparkMaxConfigAccessor:
        """
        Accessor for SPARK parameter values. This object contains fields and
        methods to retrieve parameters that have been applied to the device. To
        set parameters, see SparkBaseConfig and SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and should
        be used infrequently.
        """
class SparkMaxAlternateEncoder(RelativeEncoder):
    """
    Get an instance of this class by using SparkMax::GetEncoder() or
    SparkMax::GetEncoder(SparkMax::EncoderType, int).
    """
    def getPosition(self) -> float:
        """
        Get the position of the motor. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using AlternateEncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the motor
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the motor. This returns the native units
        of 'RPM' by default, and can be changed by a scale factor
        using AlternateEncoderConfig::VelocityConversionFactor().
        
        :returns: Number the RPM of the motor
        """
    def setPosition(self, position: typing.SupportsFloat) -> REVLibError:
        """
        Set the position of the encoder.
        
        :param position: Number of rotations of the motor
        
        :returns: REVLibError::kOk if successful
        """
class SparkMaxAlternateEncoderSim:
    def __init__(self, motor: SparkMax) -> None:
        ...
    def getInverted(self) -> bool:
        ...
    def getPosition(self) -> float:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroOffset(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def setZeroOffset(self, zeroOffset: typing.SupportsFloat) -> None:
        ...
class SparkMaxConfig(SparkBaseConfig):
    class DataPortConfig:
        """
        Members:
        
          kInvalid
        
          kLimitSwitchesAndAbsoluteEncoder
        
          kAlternateEncoder
        """
        __members__: typing.ClassVar[dict[str, SparkMaxConfig.DataPortConfig]]  # value = {'kInvalid': <DataPortConfig.kInvalid: -1>, 'kLimitSwitchesAndAbsoluteEncoder': <DataPortConfig.kLimitSwitchesAndAbsoluteEncoder: 0>, 'kAlternateEncoder': <DataPortConfig.kAlternateEncoder: 1>}
        kAlternateEncoder: typing.ClassVar[SparkMaxConfig.DataPortConfig]  # value = <DataPortConfig.kAlternateEncoder: 1>
        kInvalid: typing.ClassVar[SparkMaxConfig.DataPortConfig]  # value = <DataPortConfig.kInvalid: -1>
        kLimitSwitchesAndAbsoluteEncoder: typing.ClassVar[SparkMaxConfig.DataPortConfig]  # value = <DataPortConfig.kLimitSwitchesAndAbsoluteEncoder: 0>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    @typing.overload
    def apply(self, config: SparkBaseConfig) -> SparkMaxConfig:
        """
        Applies settings from a SparkBaseConfig to this one; primarily
        used to apply Presets.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SparkBaseConfig to copy settings from
        
        :returns: The updated SparkMaxConfig for method chaining
        """
    @typing.overload
    def apply(self, config: SparkMaxConfig) -> SparkMaxConfig:
        """
        Applies settings from another SparkMaxConfig to this one,
        including all of its nested configurations.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The SparkMaxConfig to copy settings from
        
        :returns: The updated SparkMaxConfig for method chaining
        """
    @typing.overload
    def apply(self, config: AlternateEncoderConfig) -> SparkMaxConfig:
        """
        Applies settings from an AlternateEncoderConfig to this
        SparkMaxConfig.
        
        Settings in the provided config will overwrite existing values in this
        object. Settings not specified in the provided config remain unchanged.
        
        :param config: The AlternateEncoderConfig to copy settings from
        
        :returns: The updated SparkMaxConfig for method chaining
        """
    @typing.overload
    def apply(self, config: SparkBaseConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: AbsoluteEncoderConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: AnalogSensorConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: EncoderConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: LimitSwitchConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: SoftLimitConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: ClosedLoopConfig) -> SparkMaxConfig:
        ...
    @typing.overload
    def apply(self, config: SignalsConfig) -> SparkMaxConfig:
        ...
    def flatten(self) -> str:
        ...
    @property
    def alternateEncoder(self) -> AlternateEncoderConfig:
        ...
class SparkMaxConfigAccessor(SparkBaseConfigAccessor):
    @property
    def alternateEncoder(self) -> AlternateEncoderConfigAccessor:
        """
        Accessor for parameters relating to the alternate encoder. To configure
        these values, use AlternateEncoderConfig and call
        SparkBase::Configure.
        
        NOTE: This uses calls that are blocking to retrieve parameters and
        should be used infrequently.
        """
class SparkMaxSim(SparkSim):
    def __init__(self, sparkMax: SparkMax, motor: wpimath._controls._controls.plant.DCMotor) -> None:
        ...
    def getAlternateEncoderSim(self) -> SparkMaxAlternateEncoderSim:
        ...
class SparkParameter:
    """
    Members:
    
      kCANID
    
      kInputMode
    
      kMotorType
    
      kCommutationAdvance
    
      kControlType
    
      kIdleMode
    
      kInputDeadband
    
      kClosedLoopControlSensor
    
      kPolePairs
    
      kCurrentChop
    
      kCurrentChopCycles
    
      kP_0
    
      kI_0
    
      kD_0
    
      kV_0
    
      kIZone_0
    
      kDFilter_0
    
      kOutputMin_0
    
      kOutputMax_0
    
      kP_1
    
      kI_1
    
      kD_1
    
      kV_1
    
      kIZone_1
    
      kDFilter_1
    
      kOutputMin_1
    
      kOutputMax_1
    
      kP_2
    
      kI_2
    
      kD_2
    
      kV_2
    
      kIZone_2
    
      kDFilter_2
    
      kOutputMin_2
    
      kOutputMax_2
    
      kP_3
    
      kI_3
    
      kD_3
    
      kV_3
    
      kIZone_3
    
      kDFilter_3
    
      kOutputMin_3
    
      kOutputMax_3
    
      kInverted
    
      kLimitSwitchFwdPolarity
    
      kLimitSwitchRevPolarity
    
      kHardLimitFwdEn
    
      kHardLimitRevEn
    
      kSoftLimitFwdEn
    
      kSoftLimitRevEn
    
      kOpenLoopRampRate
    
      kLegacyFollowerID
    
      kLegacyFollowerConfig
    
      kSmartCurrentStallLimit
    
      kSmartCurrentFreeLimit
    
      kSmartCurrentConfig
    
      kSmartCurrentReserved
    
      kMotorKv
    
      kEncoderCountsPerRev
    
      kEncoderAverageDepth
    
      kEncoderSampleDelta
    
      kEncoderInverted
    
      kVoltageCompensationMode
    
      kCompensatedNominalVoltage
    
      kIMaxAccum_0
    
      kAllowedClosedLoopError_0
    
      kIMaxAccum_1
    
      kAllowedClosedLoopError_1
    
      kIMaxAccum_2
    
      kAllowedClosedLoopError_2
    
      kIMaxAccum_3
    
      kAllowedClosedLoopError_3
    
      kPositionConversionFactor
    
      kVelocityConversionFactor
    
      kClosedLoopRampRate
    
      kSoftLimitForward
    
      kSoftLimitReverse
    
      kAnalogPositionConversion
    
      kAnalogVelocityConversion
    
      kAnalogAverageDepth
    
      kAnalogSensorMode
    
      kAnalogInverted
    
      kAnalogSampleDelta
    
      kCompatibilityPortConfig
    
      kAltEncoderCountsPerRev
    
      kAltEncoderAverageDepth
    
      kAltEncoderSampleDelta
    
      kAltEncoderInverted
    
      kAltEncoderPositionConversion
    
      kAltEncoderVelocityConversion
    
      kUvwSensorSampleRate
    
      kUvwSensorAverageDepth
    
      kNumParameters
    
      kDutyCyclePositionFactor
    
      kDutyCycleVelocityFactor
    
      kDutyCycleInverted
    
      kDutyCycleSensorMode
    
      kDutyCycleAverageDepth
    
      kDutyCycleOffsetLegacy
    
      kPositionPIDWrapEnable
    
      kPositionPIDMinInput
    
      kPositionPIDMaxInput
    
      kDutyCycleZeroCentered
    
      kDutyCycleSensorPrescaler
    
      kDutyCycleOffset
    
      kProductId
    
      kDeviceMajorVersion
    
      kDeviceMinorVersion
    
      kStatus0Period
    
      kStatus1Period
    
      kStatus2Period
    
      kStatus3Period
    
      kStatus4Period
    
      kStatus5Period
    
      kStatus6Period
    
      kStatus7Period
    
      kMAXMotionCruiseVelocity_0
    
      kMAXMotionMaxAccel_0
    
      kMAXMotionMaxJerk_0
    
      kMAXMotionAllowedProfileError_0
    
      kMAXMotionPositionMode_0
    
      kMAXMotionCruiseVelocity_1
    
      kMAXMotionMaxAccel_1
    
      kMAXMotionMaxJerk_1
    
      kMAXMotionAllowedProfileError_1
    
      kMAXMotionPositionMode_1
    
      kMAXMotionCruiseVelocity_2
    
      kMAXMotionMaxAccel_2
    
      kMAXMotionMaxJerk_2
    
      kMAXMotionAllowedProfileError_2
    
      kMAXMotionPositionMode_2
    
      kMAXMotionCruiseVelocity_3
    
      kMAXMotionMaxAccel_3
    
      kMAXMotionMaxJerk_3
    
      kMAXMotionAllowedProfileError_3
    
      kMAXMotionPositionMode_3
    
      kForceEnableStatus_0
    
      kForceEnableStatus_1
    
      kForceEnableStatus_2
    
      kForceEnableStatus_3
    
      kForceEnableStatus_4
    
      kForceEnableStatus_5
    
      kForceEnableStatus_6
    
      kForceEnableStatus_7
    
      kFollowerModeLeaderId
    
      kFollowerModeIsInverted
    
      kDutyCycleEncoderStartPulseUs
    
      kDutyCycleEncoderEndPulseUs
    
      kParamTableVersion
    
      kStatus8Period
    
      kForceEnableStatus_8
    
      kLimitSwitchPositionSensor
    
      kLimitSwitchFwdPosition
    
      kLimitSwitchRevPosition
    
      kS_0
    
      kA_0
    
      kG_0
    
      kCos_0
    
      kCosRatio_0
    
      kS_1
    
      kA_1
    
      kG_1
    
      kCos_1
    
      kCosRatio_1
    
      kS_2
    
      kA_2
    
      kG_2
    
      kCos_2
    
      kCosRatio_2
    
      kS_3
    
      kA_3
    
      kG_3
    
      kCos_3
    
      kCosRatio_3
    
      kStatus9Period
    
      kForceEnableStatus_9
    
      kDetachedEncoderDeviceID
    """
    __members__: typing.ClassVar[dict[str, SparkParameter]]  # value = {'kCANID': <SparkParameter.kCANID: 0>, 'kInputMode': <SparkParameter.kInputMode: 1>, 'kMotorType': <SparkParameter.kMotorType: 2>, 'kCommutationAdvance': <SparkParameter.kCommutationAdvance: 3>, 'kControlType': <SparkParameter.kControlType: 5>, 'kIdleMode': <SparkParameter.kIdleMode: 6>, 'kInputDeadband': <SparkParameter.kInputDeadband: 7>, 'kClosedLoopControlSensor': <SparkParameter.kClosedLoopControlSensor: 9>, 'kPolePairs': <SparkParameter.kPolePairs: 10>, 'kCurrentChop': <SparkParameter.kCurrentChop: 11>, 'kCurrentChopCycles': <SparkParameter.kCurrentChopCycles: 12>, 'kP_0': <SparkParameter.kP_0: 13>, 'kI_0': <SparkParameter.kI_0: 14>, 'kD_0': <SparkParameter.kD_0: 15>, 'kV_0': <SparkParameter.kV_0: 16>, 'kIZone_0': <SparkParameter.kIZone_0: 17>, 'kDFilter_0': <SparkParameter.kDFilter_0: 18>, 'kOutputMin_0': <SparkParameter.kOutputMin_0: 19>, 'kOutputMax_0': <SparkParameter.kOutputMax_0: 20>, 'kP_1': <SparkParameter.kP_1: 21>, 'kI_1': <SparkParameter.kI_1: 22>, 'kD_1': <SparkParameter.kD_1: 23>, 'kV_1': <SparkParameter.kV_1: 24>, 'kIZone_1': <SparkParameter.kIZone_1: 25>, 'kDFilter_1': <SparkParameter.kDFilter_1: 26>, 'kOutputMin_1': <SparkParameter.kOutputMin_1: 27>, 'kOutputMax_1': <SparkParameter.kOutputMax_1: 28>, 'kP_2': <SparkParameter.kP_2: 29>, 'kI_2': <SparkParameter.kI_2: 30>, 'kD_2': <SparkParameter.kD_2: 31>, 'kV_2': <SparkParameter.kV_2: 32>, 'kIZone_2': <SparkParameter.kIZone_2: 33>, 'kDFilter_2': <SparkParameter.kDFilter_2: 34>, 'kOutputMin_2': <SparkParameter.kOutputMin_2: 35>, 'kOutputMax_2': <SparkParameter.kOutputMax_2: 36>, 'kP_3': <SparkParameter.kP_3: 37>, 'kI_3': <SparkParameter.kI_3: 38>, 'kD_3': <SparkParameter.kD_3: 39>, 'kV_3': <SparkParameter.kV_3: 40>, 'kIZone_3': <SparkParameter.kIZone_3: 41>, 'kDFilter_3': <SparkParameter.kDFilter_3: 42>, 'kOutputMin_3': <SparkParameter.kOutputMin_3: 43>, 'kOutputMax_3': <SparkParameter.kOutputMax_3: 44>, 'kInverted': <SparkParameter.kInverted: 45>, 'kLimitSwitchFwdPolarity': <SparkParameter.kLimitSwitchFwdPolarity: 50>, 'kLimitSwitchRevPolarity': <SparkParameter.kLimitSwitchRevPolarity: 51>, 'kHardLimitFwdEn': <SparkParameter.kHardLimitFwdEn: 52>, 'kHardLimitRevEn': <SparkParameter.kHardLimitRevEn: 53>, 'kSoftLimitFwdEn': <SparkParameter.kSoftLimitFwdEn: 54>, 'kSoftLimitRevEn': <SparkParameter.kSoftLimitRevEn: 55>, 'kOpenLoopRampRate': <SparkParameter.kOpenLoopRampRate: 56>, 'kLegacyFollowerID': <SparkParameter.kLegacyFollowerID: 57>, 'kLegacyFollowerConfig': <SparkParameter.kLegacyFollowerConfig: 58>, 'kSmartCurrentStallLimit': <SparkParameter.kSmartCurrentStallLimit: 59>, 'kSmartCurrentFreeLimit': <SparkParameter.kSmartCurrentFreeLimit: 60>, 'kSmartCurrentConfig': <SparkParameter.kSmartCurrentConfig: 61>, 'kSmartCurrentReserved': <SparkParameter.kSmartCurrentReserved: 62>, 'kMotorKv': <SparkParameter.kMotorKv: 63>, 'kEncoderCountsPerRev': <SparkParameter.kEncoderCountsPerRev: 69>, 'kEncoderAverageDepth': <SparkParameter.kEncoderAverageDepth: 70>, 'kEncoderSampleDelta': <SparkParameter.kEncoderSampleDelta: 71>, 'kEncoderInverted': <SparkParameter.kEncoderInverted: 72>, 'kVoltageCompensationMode': <SparkParameter.kVoltageCompensationMode: 74>, 'kCompensatedNominalVoltage': <SparkParameter.kCompensatedNominalVoltage: 75>, 'kIMaxAccum_0': <SparkParameter.kIMaxAccum_0: 96>, 'kAllowedClosedLoopError_0': <SparkParameter.kAllowedClosedLoopError_0: 97>, 'kIMaxAccum_1': <SparkParameter.kIMaxAccum_1: 100>, 'kAllowedClosedLoopError_1': <SparkParameter.kAllowedClosedLoopError_1: 101>, 'kIMaxAccum_2': <SparkParameter.kIMaxAccum_2: 104>, 'kAllowedClosedLoopError_2': <SparkParameter.kAllowedClosedLoopError_2: 105>, 'kIMaxAccum_3': <SparkParameter.kIMaxAccum_3: 108>, 'kAllowedClosedLoopError_3': <SparkParameter.kAllowedClosedLoopError_3: 109>, 'kPositionConversionFactor': <SparkParameter.kPositionConversionFactor: 112>, 'kVelocityConversionFactor': <SparkParameter.kVelocityConversionFactor: 113>, 'kClosedLoopRampRate': <SparkParameter.kClosedLoopRampRate: 114>, 'kSoftLimitForward': <SparkParameter.kSoftLimitForward: 115>, 'kSoftLimitReverse': <SparkParameter.kSoftLimitReverse: 116>, 'kAnalogPositionConversion': <SparkParameter.kAnalogPositionConversion: 119>, 'kAnalogVelocityConversion': <SparkParameter.kAnalogVelocityConversion: 120>, 'kAnalogAverageDepth': <SparkParameter.kAnalogAverageDepth: 121>, 'kAnalogSensorMode': <SparkParameter.kAnalogSensorMode: 122>, 'kAnalogInverted': <SparkParameter.kAnalogInverted: 123>, 'kAnalogSampleDelta': <SparkParameter.kAnalogSampleDelta: 124>, 'kCompatibilityPortConfig': <SparkParameter.kCompatibilityPortConfig: 127>, 'kAltEncoderCountsPerRev': <SparkParameter.kAltEncoderCountsPerRev: 128>, 'kAltEncoderAverageDepth': <SparkParameter.kAltEncoderAverageDepth: 129>, 'kAltEncoderSampleDelta': <SparkParameter.kAltEncoderSampleDelta: 130>, 'kAltEncoderInverted': <SparkParameter.kAltEncoderInverted: 131>, 'kAltEncoderPositionConversion': <SparkParameter.kAltEncoderPositionConversion: 132>, 'kAltEncoderVelocityConversion': <SparkParameter.kAltEncoderVelocityConversion: 133>, 'kUvwSensorSampleRate': <SparkParameter.kUvwSensorSampleRate: 136>, 'kUvwSensorAverageDepth': <SparkParameter.kUvwSensorAverageDepth: 137>, 'kNumParameters': <SparkParameter.kNumParameters: 138>, 'kDutyCyclePositionFactor': <SparkParameter.kDutyCyclePositionFactor: 139>, 'kDutyCycleVelocityFactor': <SparkParameter.kDutyCycleVelocityFactor: 140>, 'kDutyCycleInverted': <SparkParameter.kDutyCycleInverted: 141>, 'kDutyCycleSensorMode': <SparkParameter.kDutyCycleSensorMode: 142>, 'kDutyCycleAverageDepth': <SparkParameter.kDutyCycleAverageDepth: 143>, 'kDutyCycleOffsetLegacy': <SparkParameter.kDutyCycleOffsetLegacy: 145>, 'kPositionPIDWrapEnable': <SparkParameter.kPositionPIDWrapEnable: 149>, 'kPositionPIDMinInput': <SparkParameter.kPositionPIDMinInput: 150>, 'kPositionPIDMaxInput': <SparkParameter.kPositionPIDMaxInput: 151>, 'kDutyCycleZeroCentered': <SparkParameter.kDutyCycleZeroCentered: 152>, 'kDutyCycleSensorPrescaler': <SparkParameter.kDutyCycleSensorPrescaler: 153>, 'kDutyCycleOffset': <SparkParameter.kDutyCycleOffset: 154>, 'kProductId': <SparkParameter.kProductId: 155>, 'kDeviceMajorVersion': <SparkParameter.kDeviceMajorVersion: 156>, 'kDeviceMinorVersion': <SparkParameter.kDeviceMinorVersion: 157>, 'kStatus0Period': <SparkParameter.kStatus0Period: 158>, 'kStatus1Period': <SparkParameter.kStatus1Period: 159>, 'kStatus2Period': <SparkParameter.kStatus2Period: 160>, 'kStatus3Period': <SparkParameter.kStatus3Period: 161>, 'kStatus4Period': <SparkParameter.kStatus4Period: 162>, 'kStatus5Period': <SparkParameter.kStatus5Period: 163>, 'kStatus6Period': <SparkParameter.kStatus6Period: 164>, 'kStatus7Period': <SparkParameter.kStatus7Period: 165>, 'kMAXMotionCruiseVelocity_0': <SparkParameter.kMAXMotionCruiseVelocity_0: 166>, 'kMAXMotionMaxAccel_0': <SparkParameter.kMAXMotionMaxAccel_0: 167>, 'kMAXMotionMaxJerk_0': <SparkParameter.kMAXMotionMaxJerk_0: 168>, 'kMAXMotionAllowedProfileError_0': <SparkParameter.kMAXMotionAllowedProfileError_0: 169>, 'kMAXMotionPositionMode_0': <SparkParameter.kMAXMotionPositionMode_0: 170>, 'kMAXMotionCruiseVelocity_1': <SparkParameter.kMAXMotionCruiseVelocity_1: 171>, 'kMAXMotionMaxAccel_1': <SparkParameter.kMAXMotionMaxAccel_1: 172>, 'kMAXMotionMaxJerk_1': <SparkParameter.kMAXMotionMaxJerk_1: 173>, 'kMAXMotionAllowedProfileError_1': <SparkParameter.kMAXMotionAllowedProfileError_1: 174>, 'kMAXMotionPositionMode_1': <SparkParameter.kMAXMotionPositionMode_1: 175>, 'kMAXMotionCruiseVelocity_2': <SparkParameter.kMAXMotionCruiseVelocity_2: 176>, 'kMAXMotionMaxAccel_2': <SparkParameter.kMAXMotionMaxAccel_2: 177>, 'kMAXMotionMaxJerk_2': <SparkParameter.kMAXMotionMaxJerk_2: 178>, 'kMAXMotionAllowedProfileError_2': <SparkParameter.kMAXMotionAllowedProfileError_2: 179>, 'kMAXMotionPositionMode_2': <SparkParameter.kMAXMotionPositionMode_2: 180>, 'kMAXMotionCruiseVelocity_3': <SparkParameter.kMAXMotionCruiseVelocity_3: 181>, 'kMAXMotionMaxAccel_3': <SparkParameter.kMAXMotionMaxAccel_3: 182>, 'kMAXMotionMaxJerk_3': <SparkParameter.kMAXMotionMaxJerk_3: 183>, 'kMAXMotionAllowedProfileError_3': <SparkParameter.kMAXMotionAllowedProfileError_3: 184>, 'kMAXMotionPositionMode_3': <SparkParameter.kMAXMotionPositionMode_3: 185>, 'kForceEnableStatus_0': <SparkParameter.kForceEnableStatus_0: 186>, 'kForceEnableStatus_1': <SparkParameter.kForceEnableStatus_1: 187>, 'kForceEnableStatus_2': <SparkParameter.kForceEnableStatus_2: 188>, 'kForceEnableStatus_3': <SparkParameter.kForceEnableStatus_3: 189>, 'kForceEnableStatus_4': <SparkParameter.kForceEnableStatus_4: 190>, 'kForceEnableStatus_5': <SparkParameter.kForceEnableStatus_5: 191>, 'kForceEnableStatus_6': <SparkParameter.kForceEnableStatus_6: 192>, 'kForceEnableStatus_7': <SparkParameter.kForceEnableStatus_7: 193>, 'kFollowerModeLeaderId': <SparkParameter.kFollowerModeLeaderId: 194>, 'kFollowerModeIsInverted': <SparkParameter.kFollowerModeIsInverted: 195>, 'kDutyCycleEncoderStartPulseUs': <SparkParameter.kDutyCycleEncoderStartPulseUs: 196>, 'kDutyCycleEncoderEndPulseUs': <SparkParameter.kDutyCycleEncoderEndPulseUs: 197>, 'kParamTableVersion': <SparkParameter.kParamTableVersion: 198>, 'kStatus8Period': <SparkParameter.kStatus8Period: 199>, 'kForceEnableStatus_8': <SparkParameter.kForceEnableStatus_8: 200>, 'kLimitSwitchPositionSensor': <SparkParameter.kLimitSwitchPositionSensor: 201>, 'kLimitSwitchFwdPosition': <SparkParameter.kLimitSwitchFwdPosition: 202>, 'kLimitSwitchRevPosition': <SparkParameter.kLimitSwitchRevPosition: 203>, 'kS_0': <SparkParameter.kS_0: 204>, 'kA_0': <SparkParameter.kA_0: 205>, 'kG_0': <SparkParameter.kG_0: 206>, 'kCos_0': <SparkParameter.kCos_0: 207>, 'kCosRatio_0': <SparkParameter.kCosRatio_0: 208>, 'kS_1': <SparkParameter.kS_1: 209>, 'kA_1': <SparkParameter.kA_1: 210>, 'kG_1': <SparkParameter.kG_1: 211>, 'kCos_1': <SparkParameter.kCos_1: 212>, 'kCosRatio_1': <SparkParameter.kCosRatio_1: 213>, 'kS_2': <SparkParameter.kS_2: 214>, 'kA_2': <SparkParameter.kA_2: 215>, 'kG_2': <SparkParameter.kG_2: 216>, 'kCos_2': <SparkParameter.kCos_2: 217>, 'kCosRatio_2': <SparkParameter.kCosRatio_2: 218>, 'kS_3': <SparkParameter.kS_3: 219>, 'kA_3': <SparkParameter.kA_3: 220>, 'kG_3': <SparkParameter.kG_3: 221>, 'kCos_3': <SparkParameter.kCos_3: 222>, 'kCosRatio_3': <SparkParameter.kCosRatio_3: 223>, 'kStatus9Period': <SparkParameter.kStatus9Period: 224>, 'kForceEnableStatus_9': <SparkParameter.kForceEnableStatus_9: 225>, 'kDetachedEncoderDeviceID': <SparkParameter.kDetachedEncoderDeviceID: 226>}
    kA_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kA_0: 205>
    kA_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kA_1: 210>
    kA_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kA_2: 215>
    kA_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kA_3: 220>
    kAllowedClosedLoopError_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAllowedClosedLoopError_0: 97>
    kAllowedClosedLoopError_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAllowedClosedLoopError_1: 101>
    kAllowedClosedLoopError_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAllowedClosedLoopError_2: 105>
    kAllowedClosedLoopError_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAllowedClosedLoopError_3: 109>
    kAltEncoderAverageDepth: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAltEncoderAverageDepth: 129>
    kAltEncoderCountsPerRev: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAltEncoderCountsPerRev: 128>
    kAltEncoderInverted: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAltEncoderInverted: 131>
    kAltEncoderPositionConversion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAltEncoderPositionConversion: 132>
    kAltEncoderSampleDelta: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAltEncoderSampleDelta: 130>
    kAltEncoderVelocityConversion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAltEncoderVelocityConversion: 133>
    kAnalogAverageDepth: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAnalogAverageDepth: 121>
    kAnalogInverted: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAnalogInverted: 123>
    kAnalogPositionConversion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAnalogPositionConversion: 119>
    kAnalogSampleDelta: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAnalogSampleDelta: 124>
    kAnalogSensorMode: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAnalogSensorMode: 122>
    kAnalogVelocityConversion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kAnalogVelocityConversion: 120>
    kCANID: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCANID: 0>
    kClosedLoopControlSensor: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kClosedLoopControlSensor: 9>
    kClosedLoopRampRate: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kClosedLoopRampRate: 114>
    kCommutationAdvance: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCommutationAdvance: 3>
    kCompatibilityPortConfig: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCompatibilityPortConfig: 127>
    kCompensatedNominalVoltage: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCompensatedNominalVoltage: 75>
    kControlType: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kControlType: 5>
    kCosRatio_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCosRatio_0: 208>
    kCosRatio_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCosRatio_1: 213>
    kCosRatio_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCosRatio_2: 218>
    kCosRatio_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCosRatio_3: 223>
    kCos_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCos_0: 207>
    kCos_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCos_1: 212>
    kCos_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCos_2: 217>
    kCos_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCos_3: 222>
    kCurrentChop: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCurrentChop: 11>
    kCurrentChopCycles: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kCurrentChopCycles: 12>
    kDFilter_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDFilter_0: 18>
    kDFilter_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDFilter_1: 26>
    kDFilter_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDFilter_2: 34>
    kDFilter_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDFilter_3: 42>
    kD_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kD_0: 15>
    kD_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kD_1: 23>
    kD_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kD_2: 31>
    kD_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kD_3: 39>
    kDetachedEncoderDeviceID: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDetachedEncoderDeviceID: 226>
    kDeviceMajorVersion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDeviceMajorVersion: 156>
    kDeviceMinorVersion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDeviceMinorVersion: 157>
    kDutyCycleAverageDepth: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleAverageDepth: 143>
    kDutyCycleEncoderEndPulseUs: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleEncoderEndPulseUs: 197>
    kDutyCycleEncoderStartPulseUs: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleEncoderStartPulseUs: 196>
    kDutyCycleInverted: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleInverted: 141>
    kDutyCycleOffset: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleOffset: 154>
    kDutyCycleOffsetLegacy: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleOffsetLegacy: 145>
    kDutyCyclePositionFactor: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCyclePositionFactor: 139>
    kDutyCycleSensorMode: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleSensorMode: 142>
    kDutyCycleSensorPrescaler: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleSensorPrescaler: 153>
    kDutyCycleVelocityFactor: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleVelocityFactor: 140>
    kDutyCycleZeroCentered: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kDutyCycleZeroCentered: 152>
    kEncoderAverageDepth: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kEncoderAverageDepth: 70>
    kEncoderCountsPerRev: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kEncoderCountsPerRev: 69>
    kEncoderInverted: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kEncoderInverted: 72>
    kEncoderSampleDelta: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kEncoderSampleDelta: 71>
    kFollowerModeIsInverted: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kFollowerModeIsInverted: 195>
    kFollowerModeLeaderId: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kFollowerModeLeaderId: 194>
    kForceEnableStatus_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_0: 186>
    kForceEnableStatus_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_1: 187>
    kForceEnableStatus_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_2: 188>
    kForceEnableStatus_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_3: 189>
    kForceEnableStatus_4: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_4: 190>
    kForceEnableStatus_5: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_5: 191>
    kForceEnableStatus_6: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_6: 192>
    kForceEnableStatus_7: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_7: 193>
    kForceEnableStatus_8: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_8: 200>
    kForceEnableStatus_9: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kForceEnableStatus_9: 225>
    kG_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kG_0: 206>
    kG_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kG_1: 211>
    kG_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kG_2: 216>
    kG_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kG_3: 221>
    kHardLimitFwdEn: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kHardLimitFwdEn: 52>
    kHardLimitRevEn: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kHardLimitRevEn: 53>
    kIMaxAccum_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIMaxAccum_0: 96>
    kIMaxAccum_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIMaxAccum_1: 100>
    kIMaxAccum_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIMaxAccum_2: 104>
    kIMaxAccum_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIMaxAccum_3: 108>
    kIZone_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIZone_0: 17>
    kIZone_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIZone_1: 25>
    kIZone_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIZone_2: 33>
    kIZone_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIZone_3: 41>
    kI_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kI_0: 14>
    kI_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kI_1: 22>
    kI_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kI_2: 30>
    kI_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kI_3: 38>
    kIdleMode: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kIdleMode: 6>
    kInputDeadband: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kInputDeadband: 7>
    kInputMode: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kInputMode: 1>
    kInverted: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kInverted: 45>
    kLegacyFollowerConfig: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLegacyFollowerConfig: 58>
    kLegacyFollowerID: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLegacyFollowerID: 57>
    kLimitSwitchFwdPolarity: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLimitSwitchFwdPolarity: 50>
    kLimitSwitchFwdPosition: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLimitSwitchFwdPosition: 202>
    kLimitSwitchPositionSensor: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLimitSwitchPositionSensor: 201>
    kLimitSwitchRevPolarity: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLimitSwitchRevPolarity: 51>
    kLimitSwitchRevPosition: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kLimitSwitchRevPosition: 203>
    kMAXMotionAllowedProfileError_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionAllowedProfileError_0: 169>
    kMAXMotionAllowedProfileError_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionAllowedProfileError_1: 174>
    kMAXMotionAllowedProfileError_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionAllowedProfileError_2: 179>
    kMAXMotionAllowedProfileError_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionAllowedProfileError_3: 184>
    kMAXMotionCruiseVelocity_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionCruiseVelocity_0: 166>
    kMAXMotionCruiseVelocity_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionCruiseVelocity_1: 171>
    kMAXMotionCruiseVelocity_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionCruiseVelocity_2: 176>
    kMAXMotionCruiseVelocity_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionCruiseVelocity_3: 181>
    kMAXMotionMaxAccel_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxAccel_0: 167>
    kMAXMotionMaxAccel_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxAccel_1: 172>
    kMAXMotionMaxAccel_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxAccel_2: 177>
    kMAXMotionMaxAccel_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxAccel_3: 182>
    kMAXMotionMaxJerk_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxJerk_0: 168>
    kMAXMotionMaxJerk_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxJerk_1: 173>
    kMAXMotionMaxJerk_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxJerk_2: 178>
    kMAXMotionMaxJerk_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionMaxJerk_3: 183>
    kMAXMotionPositionMode_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionPositionMode_0: 170>
    kMAXMotionPositionMode_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionPositionMode_1: 175>
    kMAXMotionPositionMode_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionPositionMode_2: 180>
    kMAXMotionPositionMode_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMAXMotionPositionMode_3: 185>
    kMotorKv: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMotorKv: 63>
    kMotorType: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kMotorType: 2>
    kNumParameters: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kNumParameters: 138>
    kOpenLoopRampRate: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOpenLoopRampRate: 56>
    kOutputMax_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMax_0: 20>
    kOutputMax_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMax_1: 28>
    kOutputMax_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMax_2: 36>
    kOutputMax_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMax_3: 44>
    kOutputMin_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMin_0: 19>
    kOutputMin_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMin_1: 27>
    kOutputMin_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMin_2: 35>
    kOutputMin_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kOutputMin_3: 43>
    kP_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kP_0: 13>
    kP_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kP_1: 21>
    kP_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kP_2: 29>
    kP_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kP_3: 37>
    kParamTableVersion: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kParamTableVersion: 198>
    kPolePairs: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kPolePairs: 10>
    kPositionConversionFactor: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kPositionConversionFactor: 112>
    kPositionPIDMaxInput: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kPositionPIDMaxInput: 151>
    kPositionPIDMinInput: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kPositionPIDMinInput: 150>
    kPositionPIDWrapEnable: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kPositionPIDWrapEnable: 149>
    kProductId: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kProductId: 155>
    kS_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kS_0: 204>
    kS_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kS_1: 209>
    kS_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kS_2: 214>
    kS_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kS_3: 219>
    kSmartCurrentConfig: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSmartCurrentConfig: 61>
    kSmartCurrentFreeLimit: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSmartCurrentFreeLimit: 60>
    kSmartCurrentReserved: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSmartCurrentReserved: 62>
    kSmartCurrentStallLimit: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSmartCurrentStallLimit: 59>
    kSoftLimitForward: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSoftLimitForward: 115>
    kSoftLimitFwdEn: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSoftLimitFwdEn: 54>
    kSoftLimitRevEn: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSoftLimitRevEn: 55>
    kSoftLimitReverse: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kSoftLimitReverse: 116>
    kStatus0Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus0Period: 158>
    kStatus1Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus1Period: 159>
    kStatus2Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus2Period: 160>
    kStatus3Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus3Period: 161>
    kStatus4Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus4Period: 162>
    kStatus5Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus5Period: 163>
    kStatus6Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus6Period: 164>
    kStatus7Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus7Period: 165>
    kStatus8Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus8Period: 199>
    kStatus9Period: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kStatus9Period: 224>
    kUvwSensorAverageDepth: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kUvwSensorAverageDepth: 137>
    kUvwSensorSampleRate: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kUvwSensorSampleRate: 136>
    kV_0: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kV_0: 16>
    kV_1: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kV_1: 24>
    kV_2: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kV_2: 32>
    kV_3: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kV_3: 40>
    kVelocityConversionFactor: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kVelocityConversionFactor: 113>
    kVoltageCompensationMode: typing.ClassVar[SparkParameter]  # value = <SparkParameter.kVoltageCompensationMode: 74>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SparkRelativeEncoder(RelativeEncoder):
    """
    Get an instance of this class by using SparkBase::GetEncoder() or
    SparkBase::GetEncoder(SparkRelativeEncoder::Type, int).
    """
    def getPosition(self) -> float:
        """
        Get the position of the motor. This returns the native units
        of 'rotations' by default, and can be changed by a scale factor
        using EncoderConfig::PositionConversionFactor().
        
        :returns: Number of rotations of the motor
        """
    def getVelocity(self) -> float:
        """
        Get the velocity of the motor. This returns the native units
        of 'RPM' by default, and can be changed by a scale factor
        using EncoderConfig::VelocityConversionFactor().
        
        :returns: Number the RPM of the motor
        """
    def setPosition(self, position: typing.SupportsFloat) -> REVLibError:
        """
        Set the position of the encoder.
        
        :param position: Number of rotations of the motor
        
        :returns: REVLibError::kOk if successful
        """
class SparkRelativeEncoderSim:
    @typing.overload
    def __init__(self, motor: SparkMax) -> None:
        ...
    @typing.overload
    def __init__(self, motor: SparkFlex) -> None:
        ...
    def getInverted(self) -> bool:
        ...
    def getPosition(self) -> float:
        ...
    def getPositionConversionFactor(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def getVelocityConversionFactor(self) -> float:
        ...
    def getZeroOffset(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setInverted(self, inverted: bool) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def setZeroOffset(self, zeroOffset: typing.SupportsFloat) -> None:
        ...
class SparkSim:
    def __init__(self, spark: SparkBase, motor: wpimath._controls._controls.plant.DCMotor) -> None:
        ...
    def disable(self) -> None:
        ...
    def enable(self) -> None:
        ...
    def getAbsoluteEncoderSim(self) -> SparkAbsoluteEncoderSim:
        ...
    def getAnalogSensorSim(self) -> SparkAnalogSensorSim:
        ...
    def getAppliedOutput(self) -> float:
        ...
    def getBusVoltage(self) -> float:
        ...
    def getClosedLoopSlot(self) -> ClosedLoopSlot:
        ...
    def getFaultManager(self) -> SparkSimFaultManager:
        ...
    def getForwardLimitSwitchSim(self) -> SparkLimitSwitchSim:
        ...
    def getMotorCurrent(self) -> float:
        ...
    def getPosition(self) -> float:
        ...
    def getRelativeEncoderSim(self) -> SparkRelativeEncoderSim:
        ...
    def getReverseLimitSwitchSim(self) -> SparkLimitSwitchSim:
        ...
    def getSetpoint(self) -> float:
        ...
    def getVelocity(self) -> float:
        ...
    def iterate(self, velocity: typing.SupportsFloat, vbus: typing.SupportsFloat, dt: typing.SupportsFloat) -> None:
        ...
    def setAppliedOutput(self, appliedOutput: typing.SupportsFloat) -> None:
        ...
    def setBusVoltage(self, voltage: typing.SupportsFloat) -> None:
        ...
    def setMotorCurrent(self, current: typing.SupportsFloat) -> None:
        ...
    def setPosition(self, position: typing.SupportsFloat) -> None:
        ...
    def setVelocity(self, velocity: typing.SupportsFloat) -> None:
        ...
    def useDriverStationEnable(self) -> None:
        ...
class SparkSimFaultManager:
    @typing.overload
    def __init__(self, motor: SparkMax) -> None:
        ...
    @typing.overload
    def __init__(self, motor: SparkFlex) -> None:
        ...
    def setFaults(self, faults: SparkBase.Faults) -> None:
        ...
    def setStickyFaults(self, faults: SparkBase.Faults) -> None:
        ...
    def setStickyWarnings(self, warnings: SparkBase.Warnings) -> None:
        ...
    def setWarnings(self, warnings: SparkBase.Warnings) -> None:
        ...
class SparkSoftLimit:
    def isReached(self) -> bool:
        """
        Get the state of the soft limit (has it been reached)
        """
class SplineEncoder(DetachedEncoder):
    def __init__(self, deviceID: typing.SupportsInt) -> None:
        """
        Create a new object to control a MAXSpline Encoder
        
        :param deviceID: The device ID.
        """
class StatusLogger:
    @staticmethod
    def disableAutoLogging() -> None:
        """
        Prevents the data logger from starting automatically.
        
        **IMPORTANT:** This method must be called before any other REVLib
        function is invoked. The recommended placement is as the first line in
        your
        ``robotInit()`` method.
        
        After calling this, logging will not occur until it is explicitly
        started with :class:`.Start`. This is useful for applications that
        require full manual control over the logging lifecycle.
        
        @see Start()
        @see Stop()
        """
    @staticmethod
    def start() -> None:
        """
        Manually start capturing data from REV devices to a REV binary
        log (.revlog).
        
        **Note:** This method provides an explicit override for the default
        logging behavior. In most cases, this is not required, as logging begins
        automatically on the first call to any REVLib function.
        
        Use this method only for advanced cases where logging must begin at a
        precise moment, such as before the main robot loop or other subsystems
        are initialized.
        
        @see Stop()
        @see DisableAutoLogging()
        """
    @staticmethod
    def stop() -> None:
        """
        Stops the data logging session.
        
        While stopped, no new data from REV devices will be written
        to the REV binary log (.revlog). The logging session is not terminated
        and can be resumed at any time by calling :class:`.Start`.
        
        @see Start()
        @see DisableAutoLogging()
        """
