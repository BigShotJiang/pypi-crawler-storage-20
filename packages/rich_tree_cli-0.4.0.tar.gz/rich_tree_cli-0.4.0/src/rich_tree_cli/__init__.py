"""Rich Tree CLI package."""
