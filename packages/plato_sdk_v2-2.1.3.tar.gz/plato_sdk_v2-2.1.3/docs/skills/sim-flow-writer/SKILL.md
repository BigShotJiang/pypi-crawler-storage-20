---
name: sim-flow-writer
description: Generates flows.yml files for Plato simulators. Uses browser to inspect the RUNNING sandbox app and find correct selectors. Must be called AFTER sandbox services are started but BEFORE worker is started.
allowed-tools: Read, Write, Edit, mcp__playwright__browser_navigate, mcp__playwright__browser_snapshot, mcp__playwright__browser_click, mcp__playwright__browser_type, mcp__playwright__browser_take_screenshot
context: fork
---

# Plato Simulator Flow Writer

**Pipeline Position:** Phase 2, Step 6 (Gate 2 - Login Test)

You create flow YAML files by inspecting the RUNNING application in the Plato sandbox. **You also TEST that login works** - this is the critical gate before starting the worker.

## When to Call This Skill

This skill should be called **AFTER services are started but BEFORE the worker is started**:

1. ✅ Sandbox VM started
2. ✅ Services deployed (`plato sandbox start-services`)
3. ✅ App accessible via browser
4. **→ NOW: Create/test flows with this skill**
5. ⏳ THEN: Start worker (`plato sandbox start-worker`)
6. ⏳ THEN: Run flows and snapshot

**IMPORTANT:** The worker should NOT be started until login is verified working. This skill tests login manually via browser, which confirms the app is ready.

---

## CRITICAL: STOP IF NO PUBLIC_URL

**If you don't have a `public_url`, STOP IMMEDIATELY and return:**

```yaml
flow_result:
  success: false
  error: "Cannot create flow - no public_url provided. Sandbox must be started first."
  action_needed: "Invoke sim-sandbox-operator with action: start-services-only"
```

**DO NOT guess selectors. DO NOT use patterns from documentation. You MUST inspect the actual page.**

---

## Required Input

```yaml
sim_name: "appname"
sim_path: "/path/to/sim"
public_url: "https://job-789.sims.plato.so?_plato_router_target=appname.web.plato.so"  # REQUIRED!
research_report:
  login_url: "/login"
  default_credentials:
    username: "admin@example.com"
    password: "password123"
```

---

## Flow File Format (CRITICAL)

The flow file MUST use this exact format:

```yaml
flows:
  - name: login
    description: Login to AppName
    steps:
      - description: Screenshot of initial page
        type: screenshot
        filename: 01_landing_page.png
      - description: Navigate to login page
        type: navigate
        url: /login
      # ... more steps

  - name: incorrect_login
    description: Verify login fails with incorrect password
    steps:
      # ... steps for incorrect login
```

### Step Types

| Type | Required Fields | Description |
|------|-----------------|-------------|
| `screenshot` | `filename` | Take a screenshot |
| `wait` | `duration` | Wait N milliseconds |
| `navigate` | `url` | Navigate to URL path |
| `wait_for_selector` | `selector`, `timeout` | Wait for element |
| `fill` | `selector`, `value` | Fill input field |
| `click` | `selector` | Click element |
| `verify` | `verify_type`, `selector` | Verify element exists/visible |
| `verify_no_errors` | `error_selectors` | Verify no error messages |

### Important Rules

1. **Use `type:` not `action:`** for step types
2. **Hardcode credentials** - do NOT use `{{username}}` templates
3. **Include screenshots** at key points
4. **Include waits** after navigation and clicks
5. **Always create both `login` and `incorrect_login` flows**

---

## Workflow

### Step 1: Navigate to Public URL and VERIFY APP LOADS

```
mcp__playwright__browser_navigate to {public_url}
mcp__playwright__browser_snapshot
```

**CRITICAL: CHECK FOR ERRORS BEFORE PROCEEDING!**

If the snapshot shows ANY of these, **STOP and return failure**:
- "502 Bad Gateway"
- "503 Service Unavailable"
- "504 Gateway Timeout"
- "Connection refused"
- "Unable to connect"
- nginx error page
- Blank page with no content

**If you see an error page, return:**
```yaml
flow_result:
  success: false
  error: "App not reachable - got error page"
  error_details: "502 Bad Gateway"  # or whatever error you see
  action_needed: "Check app_port routing - see sim-config-writer troubleshooting"
```

**DO NOT proceed to find selectors on an error page!**

### Step 2: Navigate to Login Page

Only after confirming the app loads:
```
mcp__playwright__browser_navigate to {public_url_with_login_path}
```

### Step 3: Take Snapshot & Identify Selectors

```
mcp__playwright__browser_snapshot
```

Look for:
- Username/email input → note the selector (id, name, data-testid)
- Password input → note the selector
- Submit button → note the selector

### Step 4: Test Login Works

```
mcp__playwright__browser_type in username field
mcp__playwright__browser_type in password field
mcp__playwright__browser_click on submit button
mcp__playwright__browser_snapshot  # See result
```

### Step 5: VERIFY LOGIN ACTUALLY SUCCEEDED

**CRITICAL: After clicking submit, check the snapshot carefully!**

Login SUCCEEDED if you see:
- Dashboard/home page content
- User menu, logout button, profile link
- URL changed from /login to /dashboard, /home, etc.
- Welcome message with username

Login FAILED if you see:
- Still on login page
- Error message like "Invalid credentials"
- "502 Bad Gateway" or other error
- Same URL as before (/login)

**If login failed, DO NOT proceed! Return:**
```yaml
flow_result:
  success: false
  error: "Login test failed"
  error_details: "Still on login page after submit"  # or error message shown
  action_needed: "Check credentials or app configuration"
```

### Step 6: Find Verification Element

After successful login, find an element that proves login worked (dashboard header, user menu, etc.)

### Step 7: Write flows.yml

Save to `{sim_path}/base/flows.yml`

---

## Example: Simple Login Flow (WordPress-style)

```yaml
flows:
  - name: login
    description: Login to WordPress admin dashboard
    steps:
      - description: Screenshot of initial landing page
        type: screenshot
        filename: 01_landing_page.png
      - description: Wait for page to finish loading
        type: wait
        duration: 3000
      - description: Navigate to login page
        type: navigate
        url: /wp-login
      - description: Wait for login page to load
        type: wait
        duration: 2000
      - description: Screenshot of login page
        type: screenshot
        filename: 02_login_page.png
      - description: Wait for username field
        type: wait_for_selector
        selector: "input#user_login"
        timeout: 10000
      - description: Fill username field
        type: fill
        selector: "input#user_login"
        value: admin
      - description: Fill password field
        type: fill
        selector: "input#user_pass"
        value: admin
      - description: Screenshot with credentials filled
        type: screenshot
        filename: 03_credentials_filled.png
      - description: Click login submit button
        type: click
        selector: "input#wp-submit"
      - description: Wait for login to complete
        type: wait
        duration: 3000
      - description: Screenshot after successful login
        type: screenshot
        filename: 04_logged_in.png

  - name: incorrect_login
    description: Verify login fails with incorrect password
    steps:
      - description: Screenshot before incorrect login attempt
        type: screenshot
        filename: 01_before_incorrect_login.png
      - description: Navigate to login page
        type: navigate
        url: /wp-login
      - description: Wait for username field
        type: wait_for_selector
        selector: "input#user_login"
        timeout: 10000
      - description: Fill username field
        type: fill
        selector: "input#user_login"
        value: admin
      - description: Fill password field with wrong password
        type: fill
        selector: "input#user_pass"
        value: wrongpassword
      - description: Screenshot with incorrect credentials
        type: screenshot
        filename: 02_incorrect_credentials.png
      - description: Click login submit button
        type: click
        selector: "input#wp-submit"
      - description: Wait for error
        type: wait
        duration: 3000
      - description: Screenshot after failed login
        type: screenshot
        filename: 03_after_failed_login.png
```

---

## Example: Login with Data-TestID Selectors (Chatwoot-style)

```yaml
flows:
  - name: login
    description: Login to Chatwoot
    steps:
      - description: Screenshot of initial landing page
        type: screenshot
        filename: 01_landing_page.png
      - description: Wait for page to finish loading
        type: wait
        duration: 3000
      - description: Navigate to login page
        type: navigate
        url: /app/login
      - description: Wait for login page to load
        type: wait
        duration: 3000
      - description: Screenshot of login page
        type: screenshot
        filename: 02_login_page.png
      - description: Wait for email field
        type: wait_for_selector
        selector: "input[data-testid='email_input']"
        timeout: 10000
      - description: Fill email field
        type: fill
        selector: "input[data-testid='email_input']"
        value: admin@example.com
      - description: Fill password field
        type: fill
        selector: "input[data-testid='password_input']"
        value: Admin@123456
      - description: Screenshot with credentials filled
        type: screenshot
        filename: 03_credentials_filled.png
      - description: Click login button
        type: click
        selector: "button[data-testid='submit_button']"
      - description: Wait for dashboard to load
        type: wait
        duration: 5000
      - description: Screenshot after successful login
        type: screenshot
        filename: 04_logged_in_dashboard.png

  - name: incorrect_login
    description: Verify login fails with incorrect password
    steps:
      - description: Navigate to login page
        type: navigate
        url: /app/login
      - description: Wait for email field
        type: wait_for_selector
        selector: "input[data-testid='email_input']"
        timeout: 10000
      - description: Fill email field
        type: fill
        selector: "input[data-testid='email_input']"
        value: admin@example.com
      - description: Fill password field with wrong password
        type: fill
        selector: "input[data-testid='password_input']"
        value: wrongpassword
      - description: Click login button
        type: click
        selector: "button[data-testid='submit_button']"
      - description: Wait for error
        type: wait
        duration: 3000
      - description: Screenshot after failed login
        type: screenshot
        filename: 03_after_incorrect_login.png
```

---

## Example: Login with Verification Steps (Plausible-style)

```yaml
flows:
  - name: login
    description: Login to Plausible Analytics
    steps:
      - description: Screenshot of initial landing page
        type: screenshot
        filename: 01_landing_page.png
      - description: Wait for page to finish loading
        type: wait
        duration: 3000
      - description: Navigate to login page
        type: navigate
        url: /login
      - description: Wait for login form to appear
        type: wait_for_selector
        selector: 'input#email'
        timeout: 10000
      - description: Screenshot of login form
        type: screenshot
        filename: 02_login_form.png
      - description: Fill email field
        type: fill
        selector: 'input#email'
        value: admin@example.com
      - description: Fill password field
        type: fill
        selector: 'input#current-password'
        value: Admin@123456
      - description: Screenshot with credentials filled
        type: screenshot
        filename: 03_credentials_filled.png
      - description: Click login button
        type: click
        selector: 'button[type="submit"]'
      - description: Wait for login to process
        type: wait
        duration: 3000
      - description: Screenshot after login attempt
        type: screenshot
        filename: 04_after_login.png
      - description: Verify no login errors are displayed
        type: verify_no_errors
        error_selectors:
          - .error
          - .alert-error
          - .alert-danger
          - .error-message
      - description: Verify dashboard element is visible
        type: verify
        verify_type: element_exists
        selector: '.dashboard, .main-content, #app'
      - description: Screenshot of logged in dashboard
        type: screenshot
        filename: 05_dashboard.png

  - name: incorrect_login
    description: Verify login fails with incorrect credentials
    steps:
      - description: Navigate to login page
        type: navigate
        url: /login
      - description: Wait for login form
        type: wait_for_selector
        selector: 'input#email'
        timeout: 10000
      - description: Fill email with valid email
        type: fill
        selector: 'input#email'
        value: admin@example.com
      - description: Fill password with wrong password
        type: fill
        selector: 'input#current-password'
        value: wrongpassword
      - description: Click login button
        type: click
        selector: 'button[type="submit"]'
      - description: Wait for error message
        type: wait
        duration: 2000
      - description: Screenshot after failed login
        type: screenshot
        filename: 04_after_failed_login.png
      - description: Verify still on login page or error shown
        type: verify
        verify_type: element_exists
        selector: 'input#email, .error, .alert'
```

---

## Success Output

```yaml
flow_result:
  success: true
  file: "{sim_path}/base/flows.yml"
  selectors_found:
    username: "input#email"
    password: "input#password"
    submit: "button[type='submit']"
  login_tested: true
  login_result: "Success - redirected to dashboard"
```

---

## Failure Output

```yaml
flow_result:
  success: false
  error: "Could not find password field on login page"
  page_url: "https://xxx.sims.plato.so/login"
  snapshot_summary: "Page shows error: 'Service Unavailable'"
```

---

## DO NOT

- Use `action:` instead of `type:` for steps
- Use template variables like `{{username}}` - hardcode values
- Guess selectors without inspecting the actual page
- Proceed without a public_url
- **Proceed if the page shows 502/503/504 errors - STOP and report failure**
- **Report success if login didn't actually work (still on login page)**
- Write a flow file without testing login works
- Forget to include both `login` and `incorrect_login` flows
- Forget the `flows:` wrapper at the top level
