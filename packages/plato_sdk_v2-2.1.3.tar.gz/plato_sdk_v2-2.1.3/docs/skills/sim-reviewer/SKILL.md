---
name: sim-reviewer
description: Runs the official review workflow using 'plato pm review base' to verify simulator quality. Final quality gate before approval. Use after sandbox creates a snapshot.
allowed-tools: Bash, Read
context: fork
---

# Plato Simulator Reviewer

**Pipeline Position:** Phase 3, Step 9 (Gate 3)

You run the review workflow, **check the output is clean**, and only submit when it passes. If issues found, return to debugger for fixing.

---

## Required Input

You need the simulator name and artifact ID from the snapshot step:

```yaml
sim_name: "appname"
artifact_id: "e9c25ca5-1234-5678-9abc-def012345678"  # From sim-sandbox-operator snapshot output
```

---

## Workflow

### Step 1: Run Review (CHECK FIRST, DON'T SUBMIT YET)

**IMPORTANT:** Pass the artifact ID from the snapshot. The simulator hasn't been submitted yet, so there's no artifact on record server-side.

```bash
cd {sim_path}
plato pm review base -s {sim_name} -a {artifact_id}
```

**Alternative formats (all equivalent):**
```bash
plato pm review base -s appname -a e9c25ca5-1234-5678-9abc-def012345678
plato pm review base -s appname:e9c25ca5-1234-5678-9abc-def012345678   # colon notation
```

### Step 2: Check Output

During review session:

```
Enter command: state
```

**Check for:**
1. **No mutations after login** - State should be empty or only ignored tables
2. **Login worked** - Browser shows dashboard, not login page

### Step 3: Test Real Changes

Make a real change in the browser (create item, edit field, etc.), then:

```
Enter command: state
```

**Mutations MUST appear now.** If no mutations, audit config is wrong.

### Step 4: Decision

**If all checks pass:**
- Choose "pass" (option 1)
- Submit for human approval

**If any check fails:**
- Choose "skip" (option 3)
- Return failure to orchestrator → debugger fixes → loop back to snapshot

---

## Pass Criteria

| Check | Pass If |
|-------|---------|
| No mutations after login | State empty/ignored only |
| Login worked | Dashboard visible |
| Real changes detected | Mutations appear after change |

---

## Review Issues and Fixes

| Issue | Symptom | Fix (via debugger) |
|-------|---------|-------------------|
| Mutations after login | State shows changes | Add `audit_ignore_tables` |
| No mutations detected | State empty after change | Fix audit config |
| Login failed | Still on login page | Fix flow/selectors |

---

## Output

### If Passed

```yaml
review_result:
  passed: true
  submitted: true
  status: "Submitted for human approval"
```

### If Failed

```yaml
review_result:
  passed: false
  issues:
    - "Mutations detected after login: sessions table"
  action: "Invoke debugger to fix"
```

---

## DO NOT

- Submit a failing review
- Skip the state check
- Ignore mutations after login
- Forget to test real changes are detected
- **Add `base_artifact_id` to plato-config.yml** - this field does nothing in the local config file. If the review mentions artifact issues, the problem is server-side (artifact not properly associated), not in the local config. Don't edit plato-config.yml to "fix" artifact issues.
