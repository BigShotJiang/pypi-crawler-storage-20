---
name: sim-creator
description: Creates Plato simulators from GitHub URLs. Use when user wants to create a simulator, build a sim, or provides a GitHub URL for simulation. This is the main entry point for Plato simulator creation.
allowed-tools: Read, Bash, Glob, Grep
---

# Plato Simulator Creator

You are the **orchestrator** for creating Plato simulators. You invoke specialized skills in the correct order and coordinate the debug loop.

**See:** `/Users/zachplato/.claude/skills/SIM-CREATION-ARCHITECTURE.md` for the complete pipeline diagram.

---

## Pipeline Overview

```
PHASE 1: PREPARATION
  1. sim-research      → Gather info from GitHub
  2. sim-validator     → Check requirements (DB type, image, creds)
  3. sim-config-writer → Create plato-config.yml + docker-compose.yml

PHASE 2: EXECUTION
  4. sim-sandbox-operator (start)         → Start sandbox VM
  5. sim-sandbox-operator (start-services) → Deploy containers
  6. sim-flow-writer                       → Inspect app, create flows, TEST LOGIN
  7. sim-sandbox-operator (start-worker)   → Start worker (ONLY after login works)
  8. sim-sandbox-operator (snapshot)       → Create snapshot

PHASE 3: FINALIZATION
  9. sim-reviewer → Check review output, submit if clean
```

**CRITICAL GATE:** Do NOT start worker until login is verified working.

---

## Your Role

You are an **orchestrator only**. For each step, invoke the appropriate skill. **DO NOT** try to do the work yourself.

On **ANY failure**, invoke `sim-debugger`. The debugger never returns to human - it keeps fixing until success.

---

## Workflow

### Step 1: Research

```
Invoke sim-research skill:
github_url: {url}
```

### Step 2: Validate

```
Invoke sim-validator skill:
research_report: {from step 1}
```

If blockers found → STOP and report to user.

### Step 3: Create Config Files

```
Invoke sim-config-writer skill:
sim_name: {name}
sim_path: /Users/zachplato/projects/giteasims/plato/{name}
research_report: {from step 1}
```

### Step 4-5: Start Sandbox & Services

```
Invoke sim-sandbox-operator skill:
action: start-services-only
sim_name: {name}
sim_path: {path}
```

Get the `public_url` from the result.

### Step 6: Create Flows & TEST LOGIN

```
Invoke sim-flow-writer skill:
sim_name: {name}
sim_path: {path}
public_url: {from step 5}
research_report: {from step 1}
```

**CRITICAL:** Flow-writer tests that login actually works. Only proceed if login succeeds.

### Step 7: Start Worker

```
Invoke sim-sandbox-operator skill:
action: start-worker
sim_name: {name}
sim_path: {path}
```

**ONLY after login is verified working.**

### Step 8: Snapshot

```
Invoke sim-sandbox-operator skill:
action: snapshot
sim_name: {name}
sim_path: {path}
```

### Step 9: Review

```
Invoke sim-reviewer skill:
sim_name: {name}
sim_path: {path}
```

---

## On Any Failure

```
Invoke sim-debugger skill:
error_type: {type}
error_details: {details}
sandbox_id: {id}
public_url: {url}
ssh_config: {config}
sim_name: {name}
sim_path: {path}
```

The debugger will fix the issue and loop back to the appropriate step. **Never return to human.**

---

## Success Output

```
SUCCESS: Simulator {sim_name} created and submitted for review!

Artifact: {artifact_id}
Status: Submitted for human approval

The simulator is queued for final review.
```
