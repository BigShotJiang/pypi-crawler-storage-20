---
name: sim-research
description: Researches GitHub repositories for Plato simulator creation. Gathers database type, Docker image, credentials, and environment variables. Use when researching a GitHub repo for simulator creation.
allowed-tools: Read, Grep, Glob, Bash, WebFetch
context: fork
---

# Plato Simulator Research

**Pipeline Position:** Phase 1, Step 1

You research GitHub repositories to gather all information needed to build a Plato simulator.

---

## What You Must Find

| Information | Where to Look | Why It Matters |
|-------------|---------------|----------------|
| **Database type** | docker-compose.yml, README | Must be PostgreSQL/MySQL/MariaDB |
| **Docker image** | Docker Hub, GHCR | Need exact image:tag |
| **Image version tag** | Docker Hub tags | Must be specific, NOT `latest` |
| **Web UI port** | docker-compose.yml, Dockerfile | Need for healthcheck |
| **Login URL path** | docs, screenshots | Usually /login, /admin |
| **Default credentials** | docs, env vars, setup wizard | Need for login flow |
| **Required env vars** | docker-compose.yml, .env.example | App won't start without these |

---

## Research Steps

### 1. Fetch README
```bash
curl -s https://raw.githubusercontent.com/{owner}/{repo}/main/README.md
```

### 2. Find docker-compose.yml
```bash
curl -s https://raw.githubusercontent.com/{owner}/{repo}/main/docker-compose.yml
curl -s https://raw.githubusercontent.com/{owner}/{repo}/main/docker/docker-compose.yml
```

### 3. Check Docker Hub
Look for a specific version tag (NOT `latest`, `stable`, `main`).

### 4. Find Documentation
Look for credentials and setup requirements.

### 5. Identify Database Type
Look for postgres, mysql, mariadb, mongodb, sqlite in docker-compose.

---

## Sim Naming Rules

| App Name | Correct sim_name |
|----------|------------------|
| Invoice Ninja | `invoiceninja` |
| Twenty CRM | `twenty` |
| Cal.com | `calcom` |

**Rules:** lowercase letters only, underscores OK, NO dashes/numbers/special chars

---

## Output Format

Return a YAML research report:

```yaml
research_report:
  app_name: "Human Readable App Name"
  sim_name: "appname"
  github_url: "https://github.com/owner/repo"
  description: "Brief description"

  docker_image: "owner/repo"
  image_tag: "1.2.3"
  app_port: 3000

  database_type: "postgresql"  # or mysql, mariadb, unsupported
  database_notes: "Uses PostgreSQL 15"

  default_credentials:
    username: "admin@example.com"
    password: "password123"
  login_url: "/login"

  env_vars:
    SECRET_KEY: "required"
    DATABASE_URL: "auto-configured"

  requires_initial_setup: false
  has_default_credentials: true

  warnings:
    - "App requires initial setup wizard"

  blockers: []  # e.g., "Uses MongoDB - not supported"

  notes:
    - "Found docker-compose at /docker/docker-compose.yml"
```

---

## Blockers to Flag

- MongoDB, SQLite, Redis (as primary), any NoSQL
- No Docker image available
- Private repository
- No way to get credentials

Always complete the report even if blockers are found - the validator will make the final decision.
