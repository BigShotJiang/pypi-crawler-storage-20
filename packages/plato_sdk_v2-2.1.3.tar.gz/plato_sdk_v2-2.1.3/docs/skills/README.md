# Plato Simulator Skills

Skills for creating Plato simulators from GitHub repositories using Claude Code.

## Installation

Copy the skill folders to `~/.claude/skills/`:

```bash
cp -r skills/* ~/.claude/skills/
```

## Available Skills

| Skill | Description |
|-------|-------------|
| `sim-creator` | Main orchestrator - entry point for creating simulators |
| `sim-research` | Researches GitHub repos for database, Docker image, credentials |
| `sim-validator` | Validates requirements (supported DB, Docker image exists) |
| `sim-config-writer` | Creates docker-compose.yml, plato-config.yml, nginx.conf |
| `sim-flow-writer` | Creates login-flow.yml using browser inspection |
| `sim-sandbox-operator` | Runs plato sandbox commands (start, flow, snapshot) |
| `sim-debugger` | Diagnoses failures and routes to fix skills |
| `sim-reviewer` | Runs `plato pm review base` for final approval |

## Usage

Ask Claude to create a simulator:

```
Create a simulator for https://github.com/docusealco/docuseal
```

Or invoke directly:

```
/sim-creator https://github.com/docusealco/docuseal
```

## Pipeline Flow

```
sim-creator (orchestrator)
    │
    ├──→ sim-research
    │         │
    │         ↓
    ├──→ sim-validator
    │         │
    │         ↓
    ├──→ sim-config-writer ──┐
    │                         ├──→ (parallel)
    ├──→ sim-flow-writer   ──┘
    │         │
    │         ↓
    ├──→ sim-sandbox-operator
    │         │
    │         ├── success ──→ sim-reviewer ──→ APPROVED
    │         │
    │         └── failure ──→ sim-debugger ──→ retry loop
    │
    └──→ Report final result
```

## Requirements

- Claude Code with Plato CLI installed
- Playwright MCP tools (for browser inspection)
- `PLATO_API_KEY` environment variable set
