---
name: sim-config-writer
description: Generates docker-compose.yml and plato-config.yml files for Plato simulators. Use after validation passes to create configuration files.
allowed-tools: Read, Write, Edit, Glob, Bash
context: fork
---

# Plato Simulator Config Writer

**Pipeline Position:** Phase 1, Step 3

You create the configuration files needed for a Plato simulator.

## Files You Create

```
{sim_path}/
├── plato-config.yml          # Simulator metadata and config
└── base/
    ├── docker-compose.yml    # Container orchestration
    ├── flows.yml             # Login flows (created by flow-writer)
    └── nginx.conf            # Reverse proxy (if needed)
```

## Critical Rules

### 1. Database Images - USE PLATO IMAGES

**NEVER use standard database images.** Always use Plato's signal-based images:

| Database | WRONG | CORRECT |
|----------|-------|---------|
| PostgreSQL 15 | `postgres:15` | `public.ecr.aws/i3q4i1d7/app-sim/postgres-15:prod-latest` |
| PostgreSQL 16 | `postgres:16` | `public.ecr.aws/i3q4i1d7/app-sim/postgres-16:prod-latest` |
| MySQL 8.0 | `mysql:8.0` | `public.ecr.aws/i3q4i1d7/app-sim/mysql-8.0:prod-latest` |
| MariaDB 10.6 | `mariadb:10.6` | `public.ecr.aws/i3q4i1d7/app-sim/mariadb-10.6:prod-latest` |

### 2. Network Mode

All containers MUST use `network_mode: host` for production (Plato sandbox).

### 3. Database Connection

Apps must connect to database via `127.0.0.1`, NOT the service name.

### 4. Signal-Based Healthchecks

Databases use file-based healthchecks:
```yaml
healthcheck:
  test: ["CMD-SHELL", "test -f /tmp/mysql-signals/mysql.healthy"]
  interval: 10s
  timeout: 5s
  retries: 3
  start_period: 20s
```

### 5. app_port - CRITICAL for Routing

The `app_port` in `compute` config is **the port the Plato router sends traffic to inside the VM**.

```yaml
compute:
  app_port: 80  # Router sends traffic HERE
```

**How it works:**
1. User visits `https://{job_id}.sims.plato.so`
2. Plato router looks up the job's `app_port`
3. Router forwards traffic to `VM:app_port`
4. Your app (or nginx) must be listening on this port

**Two options:**

| Scenario | app_port | What listens on app_port |
|----------|----------|--------------------------|
| App serves on 80 | 80 | Your app directly |
| App serves on 8001 | 80 | Nginx proxies 80 → 8001 |

**Common pattern:** If your app runs on a non-standard port (e.g., 8001), add nginx listening on `app_port` (80) that proxies to the app.

**Troubleshooting routing issues:**

If you get 502 Bad Gateway or can't reach the app:

1. Check the public URL format: `https://{job_id}--{port}.sims.plato.so`
2. The `--{port}` in the URL tells you what port the router expects
3. Make sure something (your app or nginx) is listening on that port inside the VM
4. If the URL has `--8888` but your app is on port 80, either:
   - Add nginx on port 8888 that proxies to your app
   - Or fix the `app_port` in plato-config.yml and recreate the sandbox

---

## plato-config.yml Template

```yaml
service: "{sim_name}"
datasets:
  base: &base
    compute: &base_compute
      cpus: 1          # Always 1
      memory: 2048     # Always 2048
      disk: 10240      # Always 10240
      app_port: 80
      plato_messaging_port: 7000
    metadata: &base_metadata
      name: "{App Name}"
      description: "{Brief description of the app}"
      source_code_url: "{github_url}"
      start_url: /
      license: "{license}"
      flows_path: base/flows.yml
      variables:
        - name: username
          value: {default_username}
        - name: password
          value: {default_password}
    services: &base_services
      main_app:
        type: docker-compose
        file: base/docker-compose.yml
        healthy_wait_timeout: 600
        required_healthy_containers:
          - {main_container_name}
    listeners: &base_listeners
      db:
        type: db
        db_type: {postgresql|mysql}
        db_host: 127.0.0.1
        db_port: {5432|3306}
        db_user: {db_user}
        db_password: {db_password}
        db_database: {db_name}
        volumes:
          - /home/plato/db_signals:/tmp/{postgres|mysql}-signals
        audit_ignore_tables:
          - sessions
          - schema_migrations
          - table: "*"
            columns: [created_at, updated_at]
```

---

## docker-compose.yml Template (PostgreSQL)

```yaml
services:
  db:
    image: public.ecr.aws/i3q4i1d7/app-sim/postgres-15:prod-latest
    network_mode: host
    environment:
      POSTGRES_USER: {db_user}
      POSTGRES_PASSWORD: {db_password}
      POSTGRES_DB: {db_name}
    volumes:
      - /home/plato/db_signals:/tmp/postgres-signals
    healthcheck:
      test: ["CMD-SHELL", "test -f /tmp/postgres-signals/postgres.healthy"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 20s

  {sim_name}-app:
    image: {docker_image}:{image_tag}
    network_mode: host
    depends_on:
      db:
        condition: service_healthy
    environment:
      DATABASE_URL: postgresql://{db_user}:{db_password}@127.0.0.1:5432/{db_name}
      # Add other required env vars from research
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:{app_port}/ || exit 1"]
      interval: 15s
      timeout: 5s
      retries: 5
      start_period: 45s
```

---

## docker-compose.yml Template (MySQL/MariaDB)

```yaml
services:
  db:
    image: public.ecr.aws/i3q4i1d7/app-sim/mariadb-10.6:prod-latest
    network_mode: host
    environment:
      MYSQL_DATABASE: {db_name}
      MYSQL_USER: {db_user}
      MYSQL_PASSWORD: {db_password}
      MYSQL_ROOT_PASSWORD: {db_password}
    volumes:
      - /home/plato/db_signals:/tmp/mysql-signals
    healthcheck:
      test: ["CMD-SHELL", "test -f /tmp/mysql-signals/mysql.healthy"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 20s

  {sim_name}-app:
    image: {docker_image}:{image_tag}
    network_mode: host
    depends_on:
      db:
        condition: service_healthy
    environment:
      DATABASE_URL: mysql://{db_user}:{db_password}@127.0.0.1:3306/{db_name}
      # Or individual vars:
      DB_HOST: 127.0.0.1
      DB_PORT: 3306
      DB_USER: {db_user}
      DB_PASSWORD: {db_password}
      DB_DATABASE: {db_name}
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:{app_port}/ || exit 1"]
      interval: 15s
      timeout: 5s
      retries: 5
      start_period: 45s
```

---

## nginx.conf Template (if app doesn't serve on app_port)

**When to use:** Your app runs on a different port than `app_port` (e.g., app on 8001, but `app_port: 80`).

Nginx listens on `app_port` and proxies to your app's actual port:

```nginx
events {
    worker_connections 1024;
}

http {
    upstream app {
        server 127.0.0.1:{actual_app_port};  # e.g., 8001
    }

    server {
        listen {app_port};  # Must match compute.app_port (e.g., 80)

        location / {
            proxy_pass http://app;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto https;
        }
    }
}
```

If using nginx, add to docker-compose.yml:
```yaml
  nginx:
    image: nginx:alpine
    network_mode: host
    depends_on:
      {sim_name}-app:
        condition: service_healthy
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:{app_port}/ || exit 1"]  # Must match compute.app_port
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 10s
```

---

## Real Example: WordPress

**plato-config.yml:**
```yaml
service: "wordpress"
datasets:
  base: &base
    compute: &base_compute
      cpus: 1          # Always 1
      memory: 2048     # Always 2048
      disk: 10240      # Always 10240
      app_port: 80
      plato_messaging_port: 7000
    metadata: &base_metadata
      name: "WordPress CMS"
      description: "WordPress CMS running with MariaDB in Docker"
      source_code_url: "https://github.com/WordPress/WordPress"
      start_url: /
      license: "GPL-2.0"
      flows_path: base/flows.yml
      variables:
        - name: username
          value: admin
        - name: password
          value: admin
    services: &base_services
      main_app:
        type: docker-compose
        file: base/docker-compose.yml
        healthy_wait_timeout: 600
        required_healthy_containers:
          - wordpress
    listeners: &base_listeners
      db:
        type: db
        db_type: mysql
        db_host: 127.0.0.1
        db_port: 3306
        db_user: wordpress
        db_password: wordpress
        db_database: wordpress
        volumes:
          - /home/plato/db_signals:/tmp/mysql-signals
        audit_ignore_tables:
          - wp_options
          - table: "*"
            columns: [post_modified, post_modified_gmt]
```

**docker-compose.yml:**
```yaml
services:
  db:
    image: public.ecr.aws/i3q4i1d7/app-sim/mariadb-10.6:prod-latest
    network_mode: host
    environment:
      MYSQL_DATABASE: wordpress
      MYSQL_USER: wordpress
      MYSQL_PASSWORD: wordpress
      MYSQL_ROOT_PASSWORD: wordpress
    volumes:
      - /home/plato/db_signals:/tmp/mysql-signals
    healthcheck:
      test: ["CMD-SHELL", "test -f /tmp/mysql-signals/mysql.healthy"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 20s

  wordpress:
    image: wordpress:php8.4
    network_mode: host
    depends_on:
      db:
        condition: service_healthy
    environment:
      WORDPRESS_DB_HOST: 127.0.0.1:3306
      WORDPRESS_DB_USER: wordpress
      WORDPRESS_DB_PASSWORD: wordpress
      WORDPRESS_DB_NAME: wordpress
      WORDPRESS_CONFIG_EXTRA: |
        define('WP_HOME', 'https://sims.plato.so');
        define('WP_SITEURL', 'https://sims.plato.so');
        define('FORCE_SSL_ADMIN', true);
    healthcheck:
      test: ["CMD-SHELL", "curl -f http://localhost:80/ || exit 1"]
      interval: 15s
      timeout: 5s
      retries: 5
      start_period: 45s
```

---

## Common audit_ignore_tables

Add these to prevent false mutations:

```yaml
audit_ignore_tables:
  # Framework tables
  - sessions
  - schema_migrations
  - ar_internal_metadata
  - django_migrations
  - doctrine_migration_versions

  # Timestamp columns on all tables
  - table: "*"
    columns: [created_at, updated_at, modified_at, last_login]
```

---

## Output

After creating files:
```
Config files created at {sim_path}/:
- plato-config.yml
- base/docker-compose.yml
- base/nginx.conf (if needed)

Next: Use sim-sandbox-operator to start sandbox and services.
```

---

## DO NOT

- Use standard database images (postgres:15, mysql:8.0, etc.)
- Use service names for database connections (use 127.0.0.1)
- Forget `network_mode: host`
- Forget the db_signals volume mount
- Use `latest` tag for app images
