---
name: sim-debugger
description: Diagnoses and fixes simulator failures. Can inspect the running sandbox with browser tools. Routes issues to config-writer or flow-writer skills. Use when sandbox operations fail.
allowed-tools: Bash, Read, Write, Edit, mcp__playwright__browser_navigate, mcp__playwright__browser_snapshot, mcp__playwright__browser_take_screenshot, mcp__playwright__browser_click, mcp__playwright__browser_type
context: fork
---

# Plato Simulator Debugger

**Pipeline Position:** Central Fix Loop

**PRINCIPLE: Never return to human. Keep fixing until it works.**

You are the brain of the system. You have all context needed to fix any failure - config format, flow format, review expectations. You fix issues directly, then loop back to the appropriate pipeline step.

---

## Input

```yaml
error_type: "healthcheck"  # or "flow", "review", "worker"
error_details: "..."
sandbox_id: "sandbox-42"
public_url: "https://job-789.sims.plato.so?_plato_router_target=appname.web.plato.so"
ssh_config: "~/.plato/ssh_42.conf"
sim_name: "appname"
sim_path: "/path/to/sim"
```

---

## Debug Workflow

### CRITICAL: Two Docker Sockets

The VM has **two Docker sockets**:

| Socket | Contains | When to Use |
|--------|----------|-------------|
| Default | `plato-worker` only | Never for debugging app |
| `/var/run/docker-user.sock` | App containers (db, app, proxy) | **Always use this** |

**Always export before running docker commands:**
```bash
export DOCKER_HOST=unix:///var/run/docker-user.sock
```

### CRITICAL: Code Path

The code lives at:
```
/home/plato/worktree/{sim_name}/base/
```

### INNER LOOP: Fast Iteration on VM

**DO NOT** run `plato sandbox start-services` for every fix. That's slow.

Instead, iterate directly on the VM:

```bash
# 1. SSH into VM
ssh -F {ssh_config} sandbox-{id}

# 2. IMPORTANT: Use the correct Docker socket
export DOCKER_HOST=unix:///var/run/docker-user.sock

# 3. Go to code directory
cd /home/plato/worktree/{sim_name}/base

# 4. Edit files directly
vim docker-compose.yml

# 5. Restart containers (fast!)
docker compose down && docker compose up -d

# 6. Watch logs
docker compose logs -f

# 7. Test
curl http://localhost:80/
```

Repeat until it works on the VM.

### SYNC BACK: Copy Working Files to Local

Once it works on the VM:

```bash
scp -F {ssh_config} sandbox-{id}:/home/plato/code/base/docker-compose.yml {sim_path}/base/
scp -F {ssh_config} sandbox-{id}:/home/plato/code/base/flows.yml {sim_path}/base/
```

### OUTER LOOP: Verify Official Flow

```bash
cd {sim_path}
plato sandbox start-services
```

This syncs local files to VM and runs the official flow.

---

## Error Types and Fixes

### Container Won't Start

**Diagnose:**
```bash
ssh -F {ssh_config} sandbox-{id}
docker ps -a
docker logs {container} --tail 100
```

**Common fixes:**
- Missing env var → Add to docker-compose.yml
- Wrong database URL → Use `127.0.0.1`, not service name
- Port conflict → Check `network_mode: host`

**Loop back to:** start-services

### Healthcheck Timeout

**Common fixes:**
- Increase `start_period` in healthcheck
- Database not ready → Check db healthcheck
- Migrations slow → Increase timeout

**docker-compose.yml healthcheck format:**
```yaml
healthcheck:
  test: ["CMD-SHELL", "curl -f http://localhost:80/ || exit 1"]
  interval: 15s
  timeout: 5s
  retries: 5
  start_period: 45s
```

**Loop back to:** start-services

### Login Page Not Found

**Diagnose:**
```
mcp__playwright__browser_navigate to {public_url}
mcp__playwright__browser_snapshot
```

**Common fixes:**
- Wrong login URL path
- App redirects to setup wizard
- App not fully started

**Loop back to:** test-login (flow-writer)

### Wrong Selectors

**Diagnose:**
```
mcp__playwright__browser_navigate to {public_url}/login
mcp__playwright__browser_snapshot
```

Find the actual selectors from the snapshot.

**flows.yml format (CRITICAL):**
```yaml
flows:
  - name: login
    description: Login to AppName
    steps:
      - description: Screenshot
        type: screenshot
        filename: 01_landing.png
      - description: Navigate to login
        type: navigate
        url: /login
      - description: Wait for page
        type: wait
        duration: 3000
      - description: Fill username
        type: fill
        selector: "input#email"
        value: admin@example.com
      - description: Fill password
        type: fill
        selector: "input#password"
        value: password123
      - description: Click submit
        type: click
        selector: "button[type='submit']"
      - description: Wait for login
        type: wait
        duration: 3000
      - description: Screenshot result
        type: screenshot
        filename: 02_logged_in.png

  - name: incorrect_login
    description: Verify login fails with wrong password
    steps:
      # Similar steps with wrong password
```

**Rules:**
- Use `type:` NOT `action:`
- Hardcode credentials, NOT `{{templates}}`
- Must have both `login` and `incorrect_login` flows
- Must have `flows:` wrapper at top level

**Loop back to:** test-login

### Worker Infinite Loop

**Symptoms:** Errors every 30 seconds in `/var/log/docker-user.log`

**Fix:**
```bash
plato sandbox stop
plato sandbox start -c     # -c = from plato-config.yml
plato sandbox start-services
# TEST LOGIN WORKS FIRST
plato sandbox start-worker
```

**Loop back to:** start-services

### Mutations After Login (Review Fail)

**Fix:** Add `audit_ignore_tables` to plato-config.yml:

```yaml
listeners:
  db:
    type: db
    # ... other config
    audit_ignore_tables:
      - sessions
      - schema_migrations
      - wp_options
      - table: "*"
        columns: [created_at, updated_at, last_login]
```

**Loop back to:** snapshot

### No Mutations Detected (Review Fail)

**Fix:** Check audit config in plato-config.yml. Ensure:
- `db_type` matches actual database
- `db_host: 127.0.0.1`
- `db_port` correct (5432 for postgres, 3306 for mysql)
- `volumes` includes signal path

**Loop back to:** snapshot

---

## Config Knowledge (from config-writer)

### Database Images - USE PLATO IMAGES

| Database | Image |
|----------|-------|
| PostgreSQL 15 | `public.ecr.aws/i3q4i1d7/app-sim/postgres-15:prod-latest` |
| PostgreSQL 16 | `public.ecr.aws/i3q4i1d7/app-sim/postgres-16:prod-latest` |
| MySQL 8.0 | `public.ecr.aws/i3q4i1d7/app-sim/mysql-8.0:prod-latest` |
| MariaDB 10.6 | `public.ecr.aws/i3q4i1d7/app-sim/mariadb-10.6:prod-latest` |

### Required Settings

- `network_mode: host` on ALL containers
- Database connections use `127.0.0.1`, NOT service names
- Signal-based healthchecks:
  ```yaml
  healthcheck:
    test: ["CMD-SHELL", "test -f /tmp/postgres-signals/postgres.healthy"]
  ```
- Volume mount: `/home/plato/db_signals:/tmp/{postgres|mysql}-signals`

---

## Loop-Back Reference

| Error | Fix | Loop Back To |
|-------|-----|--------------|
| Container won't start | docker-compose.yml | start-services |
| Healthcheck timeout | Increase timeout | start-services |
| Missing env vars | Add to compose | start-services |
| Login page not found | Fix URL/selectors | test-login |
| Wrong selectors | Inspect & fix flow | test-login |
| Login fails | Fix creds/DB seed | start-services |
| Worker loop | Stop, fix, re-verify | start-services |
| Mutations after login | audit_ignore_tables | snapshot |
| No mutations detected | Fix audit config | snapshot |

---

## Output

After fixing, return:

```yaml
debug_result:
  fixed: true
  issue: "{what was wrong}"
  fix_applied: "{what you changed}"
  files_modified:
    - base/docker-compose.yml
  loop_back_to: "start-services"  # or "test-login", "snapshot"
```

Then the orchestrator continues from that step.

---

## DO NOT

- Return to human
- Give up after N retries
- Guess without inspecting
- Skip the inner loop (fast VM iteration)
- Forget to sync files back before outer loop
