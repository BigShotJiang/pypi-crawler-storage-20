# Plato Worlds - Local Development Guide

Run Plato worlds locally for development and testing.

## Quick Start

```bash
# List available worlds
plato-world-runner --list

# Run a world with a config file
plato-world-runner --world <name> --config config.json
```

## Config File Format

Create a JSON config file with the following structure:

```json
{
  "world_config": {
    "repository_url": "https://github.com/example/repo",
    "prompt": "Fix the bug in main.py"
  },
  "agents": {
    "coder": {
      "image": "my-agent:latest",
      "config": {
        "model": "gpt-4"
      }
    }
  },
  "secrets": {
    "OPENAI_API_KEY": "sk-..."
  },
  "session_id": "local-test-001",
  "callback_url": ""
}
```

### Fields

| Field | Description |
|-------|-------------|
| `world_config` | World-specific configuration (varies by world) |
| `agents` | Map of slot name to agent config (`image` + optional `config`) |
| `secrets` | Secret values (API keys, tokens) |
| `session_id` | Unique identifier for this run |
| `callback_url` | Full Chronos callback URL (e.g., `http://server/api/callback`), leave empty for local runs |

## Creating a World

### 1. Define the World Class

```python
# my_world.py
from plato.worlds import BaseWorld, register_world, AgentSlot, Observation, StepResult
from plato.worlds.config import RunConfig, WorldConfig

class MyWorldConfig(WorldConfig):
    """Typed config for MyWorld."""
    prompt: str
    max_steps: int = 10

@register_world("my-world")
class MyWorld(BaseWorld):
    name = "my-world"
    description = "A simple example world"
    agents = [
        AgentSlot(name="worker", description="The main agent", required=True),
    ]
    secrets = ["API_KEY"]
    config_class = MyWorldConfig

    async def reset(self, config: RunConfig[MyWorldConfig]) -> Observation:
        """Setup the world."""
        self.prompt = config.world_config.prompt
        return Observation(data={"prompt": self.prompt})

    async def step(self) -> StepResult:
        """Execute one step."""
        # Your world logic here
        return StepResult(
            observation=Observation(data={"status": "done"}),
            done=True,
        )

    async def close(self) -> None:
        """Cleanup resources."""
        pass
```

### 2. Register via Entry Point

In your `pyproject.toml`:

```toml
[project.entry-points."plato.worlds"]
my-world = "my_world:MyWorld"
```

### 3. Run It

```bash
# Install your package
pip install -e .

# Verify it's registered
plato-world-runner --list

# Run with config
plato-world-runner --world my-world --config config.json -v
```

## Programmatic Usage

```python
import asyncio
from plato.worlds import run_world
from plato.worlds.config import RunConfig

config = RunConfig(
    world_config={"prompt": "Hello world"},
    agents={"worker": {"image": "agent:latest"}},
    secrets={"API_KEY": "secret"},
)

asyncio.run(run_world("my-world", config))
```

Or load from a file:

```python
from plato.worlds.config import RunConfig

config = RunConfig.from_file("config.json")
```

## CLI Options

```
plato-world-runner [OPTIONS]

Options:
  -w, --world TEXT    World name to run
  -c, --config PATH   Path to config JSON file
  -l, --list          List available worlds
  -v, --verbose       Enable debug logging
```

## World Lifecycle

1. **Discovery**: Worlds are discovered via `plato.worlds` entry points
2. **Instantiation**: World class is instantiated
3. **Reset**: `reset(config)` is called to setup the world
4. **Step Loop**: `step()` is called repeatedly until `done=True`
5. **Cleanup**: `close()` is called to cleanup resources

```
┌─────────────────────────────────────────┐
│  plato-world-runner --world X --config  │
└─────────────────────────────────────────┘
                    │
                    ▼
          ┌─────────────────┐
          │ discover_worlds │
          └─────────────────┘
                    │
                    ▼
          ┌─────────────────┐
          │  world.reset()  │
          └─────────────────┘
                    │
                    ▼
          ┌─────────────────┐
          │  world.step()   │◄──┐
          └─────────────────┘   │
                    │           │
                ┌───┴───┐       │
                │ done? │───No──┘
                └───┬───┘
                   Yes
                    │
                    ▼
          ┌─────────────────┐
          │  world.close()  │
          └─────────────────┘
```

## Debugging

Enable verbose logging:

```bash
plato-world-runner --world my-world --config config.json --verbose
```

Or set log level in code:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```
