"""Upload Logs Zip Endpoint"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import LogsUploadRequest, LogsUploadResponse


def _build_request_args(
    body: LogsUploadRequest,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/callback/logs-zip"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: LogsUploadRequest,
) -> LogsUploadResponse:
    """Upload zipped logs for a session.

    Accepts base64-encoded zip file and uploads to S3."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return LogsUploadResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: LogsUploadRequest,
) -> LogsUploadResponse:
    """Upload zipped logs for a session.

    Accepts base64-encoded zip file and uploads to S3."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return LogsUploadResponse.model_validate(response.json())
