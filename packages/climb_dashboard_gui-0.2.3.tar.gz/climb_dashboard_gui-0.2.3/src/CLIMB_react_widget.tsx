import * as React from 'react';

import App from 'climb-dashboard-gui';

import { ReactWidget } from '@jupyterlab/apputils';
import { requestAPI } from './handler';

export class CLIMBReactWidget extends ReactWidget {
  constructor() {
    super();

    this.node.classList.add('climb-jupyter', 'climb-stats');
  }

  render() {
    const userInfoHandler = async () => {
      return requestAPI<any>('get-env');
    };

    const resourcesHandler = async () => {
      return requestAPI<any>('resources');
    };

    const volumesHandler = async () => {
      return requestAPI<any>('disk-usage');
    };

    const gpuHandler = async () => {
      return requestAPI<any>('gpu-info');
    };

    return (
      <App
        userInfoHandler={userInfoHandler}
        resourcesHandler={resourcesHandler}
        volumesHandler={volumesHandler}
        gpuHandler={gpuHandler}
      />
    );
  }
}
