"""noauth CLI - Command-line interface for token management."""

from noauth.cli.main import app

__all__ = ["app"]
