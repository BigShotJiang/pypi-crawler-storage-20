"""CLI commands for noauth token management."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.json import JSON
from rich.table import Table

from noauth.sdk import NoAuthClient, NoAuthError

app = typer.Typer(
    name="noauth",
    help="Centralized OAuth token management CLI",
    no_args_is_help=True,
)

console = Console()
err_console = Console(stderr=True)

# Default token file paths
DEFAULT_PATHS: dict[str, Path] = {
    "codex": Path.home() / ".codex" / "auth.json",
    "gemini": Path.home() / ".gemini" / "oauth_creds.json",
}


def get_client(url: str | None) -> NoAuthClient:
    """Create SDK client with optional URL override."""
    dotenv_vars = load_dotenv()
    token_id = dotenv_vars.get("NOAUTH_CLIENT_ID") or os.environ.get("NOAUTH_CLIENT_ID")
    token_secret = dotenv_vars.get("NOAUTH_CLIENT_SECRET") or os.environ.get(
        "NOAUTH_CLIENT_SECRET"
    )
    return NoAuthClient(
        base_url=url,
        token_id=token_id,
        token_secret=token_secret,
    )


def load_dotenv(path: Path | None = None) -> dict[str, str]:
    """Load environment variables from a .env file if present.

    Returns parsed variables and does not override existing environment values.
    """
    dotenv_path = path or (Path.cwd() / ".env")
    if not dotenv_path.exists():
        return {}

    parsed: dict[str, str] = {}
    try:
        for raw_line in dotenv_path.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and value:
                parsed[key] = value
                if key not in os.environ:
                    os.environ[key] = value
    except Exception:
        # Best-effort .env loading; ignore parse errors.
        return {}
    return parsed


def print_error(msg: str) -> None:
    """Print error message to stderr."""
    err_console.print(f"[red]Error:[/red] {msg}")


def print_success(msg: str) -> None:
    """Print success message."""
    console.print(f"[green]✓[/green] {msg}")


@app.command()
def get(
    provider: Annotated[str, typer.Argument(help="Provider name (codex, gemini)")],
    no_refresh: Annotated[
        bool, typer.Option("--no-refresh", help="Disable auto-refresh")
    ] = False,
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Get tokens for a provider."""
    try:
        with get_client(url) as client:
            response = client.get_token(provider, auto_refresh=not no_refresh)

        if output_json:
            console.print(JSON(response.model_dump_json()))
        else:
            table = Table(title=f"Tokens for {provider}")
            table.add_column("Key", style="cyan")
            table.add_column("Value", style="green")

            for key, value in response.tokens.items():
                # Truncate long values
                str_value = str(value)
                if len(str_value) > 50:
                    str_value = str_value[:47] + "..."
                table.add_row(key, str_value)

            if response.refreshed:
                table.add_row("[italic]refreshed[/italic]", "[yellow]true[/yellow]")

            console.print(table)
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command()
def store(
    provider: Annotated[str, typer.Argument(help="Provider name (codex, gemini)")],
    file: Annotated[Path, typer.Argument(help="JSON file containing tokens")],
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Store tokens from a JSON file."""
    if not file.exists():
        print_error(f"File not found: {file}")
        raise typer.Exit(1)

    try:
        tokens = json.loads(file.read_text())
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {e}")
        raise typer.Exit(1)

    try:
        with get_client(url) as client:
            response = client.store_token(provider, tokens)
        print_success(response.message)
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command()
def setup(
    provider: Annotated[str, typer.Argument(help="Provider name (codex, gemini)")],
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Store tokens from the default path for a provider.

    Default paths:
    - codex: ~/.codex/auth.json
    - gemini: ~/.gemini/oauth_creds.json
    """
    if provider not in DEFAULT_PATHS:
        print_error(
            f"Unknown provider: {provider}. Supported: {', '.join(DEFAULT_PATHS.keys())}"
        )
        raise typer.Exit(1)

    default_path = DEFAULT_PATHS[provider]
    if not default_path.exists():
        print_error(f"Default token file not found: {default_path}")
        raise typer.Exit(1)

    try:
        tokens = json.loads(default_path.read_text())
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON in {default_path}: {e}")
        raise typer.Exit(1)

    try:
        with get_client(url) as client:
            response = client.store_token(provider, tokens)
        print_success(f"{response.message} (from {default_path})")
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command()
def refresh(
    provider: Annotated[str, typer.Argument(help="Provider name (codex, gemini)")],
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Force refresh tokens for a provider."""
    try:
        with get_client(url) as client:
            response = client.refresh_token(provider)

        if output_json:
            console.print(JSON(response.model_dump_json()))
        else:
            print_success(f"Tokens refreshed for {provider}")
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command("list")
def list_providers(
    output_json: Annotated[bool, typer.Option("--json", help="Output as JSON")] = False,
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """List providers with stored tokens."""
    try:
        with get_client(url) as client:
            providers = client.list_providers()

        if output_json:
            console.print(JSON(json.dumps(providers)))
        else:
            if not providers:
                console.print("[dim]No providers configured[/dim]")
            else:
                table = Table(title="Configured Providers")
                table.add_column("Provider", style="cyan")
                for p in providers:
                    table.add_row(p)
                console.print(table)
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command()
def delete(
    provider: Annotated[str, typer.Argument(help="Provider name (codex, gemini)")],
    force: Annotated[
        bool, typer.Option("--force", "-f", help="Skip confirmation")
    ] = False,
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Delete stored tokens for a provider."""
    if not force:
        confirm = typer.confirm(f"Delete tokens for {provider}?")
        if not confirm:
            raise typer.Abort()

    try:
        with get_client(url) as client:
            response = client.delete_token(provider)
        print_success(response.message)
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command("clear-lock")
def clear_lock(
    provider: Annotated[str, typer.Argument(help="Provider name (codex, gemini)")],
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Clear a stuck refresh lock for a provider."""
    try:
        with get_client(url) as client:
            response = client.clear_lock(provider)
        print_success(response.message)
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command()
def health(
    url: Annotated[
        Optional[str], typer.Option("--url", help="Service URL override")
    ] = None,
) -> None:
    """Check service health."""
    try:
        with get_client(url) as client:
            response = client.health()
        print_success(response.message)
    except NoAuthError as e:
        print_error(str(e))
        raise typer.Exit(1)


def main() -> None:
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
