"""
noauth KMS - Token storage and management with Modal Dict.

Provides encrypted token storage with automatic refresh for OAuth providers.
Uses Modal Dict for persistence and AES-256-GCM for encryption at rest.

Architecture:
- Tokens stored in Modal Dict as encrypted bytes
- Dict keys: "{provider}:tokens" for data, "{provider}:lock" for refresh locking
- Encryption key stored in Modal Secret (MASTER_ENCRYPTION_KEY)
- Locking via Dict.put(skip_if_exists=True) for concurrent refresh protection

Supported providers:
- codex: OpenAI Codex CLI (ChatGPT OAuth)
- gemini: Google Gemini CLI (Google OAuth)
"""

# NOTE: This module name shadows Python's stdlib `secrets` module if imported as
# top-level. Keep imports absolute from `noauth` and avoid direct `import secrets`
# in entrypoints.

from __future__ import annotations

import time
from typing import Any

import modal

from .modal_app import app
from .crypto import CryptoError, decrypt, encrypt, load_key_from_env
from .providers import codex, gemini

# Dict key patterns
TOKEN_KEY = "{provider}:tokens"
LOCK_KEY = "{provider}:lock"

# Lock settings
LOCK_POLL_INTERVAL = 0.1  # seconds
LOCK_TIMEOUT = 30.0  # seconds - max time to wait for lock


class TokenError(Exception):
    """Raised when token operations fail."""


class TokenNotFoundError(TokenError):
    """Raised when requested token doesn't exist."""


class LockTimeoutError(TokenError):
    """Raised when unable to acquire lock within timeout."""


@app.cls()
class KMS:
    """
    Key Management Service for encrypted token storage.

    Manages OAuth tokens with:
    - AES-256-GCM encryption at rest
    - Automatic token refresh before expiry
    - Distributed locking for concurrent access
    """

    @modal.enter()
    def setup(self):
        """Initialize encryption key and Dict connection."""
        self.key = load_key_from_env("MASTER_ENCRYPTION_KEY")
        self.token_dict = modal.Dict.from_name("noauth-tokens", create_if_missing=True)

    def _token_key(self, provider: str) -> str:
        return TOKEN_KEY.format(provider=provider)

    def _lock_key(self, provider: str) -> str:
        return LOCK_KEY.format(provider=provider)

    def _acquire_lock(self, provider: str, timeout: float = LOCK_TIMEOUT) -> bool:
        """
        Attempt to acquire refresh lock for provider.

        Uses Dict.put with skip_if_exists=True for atomic lock acquisition.

        Returns True if lock acquired, False if someone else holds it.
        """
        lock_key = self._lock_key(provider)
        lock_data = {"status": "refreshing", "timestamp": time.time()}

        try:
            acquired = self.token_dict.put(lock_key, lock_data, skip_if_exists=True)
            return acquired
        except Exception:
            return False

    def _release_lock(self, provider: str) -> None:
        """Release refresh lock for provider."""
        lock_key = self._lock_key(provider)
        try:
            self.token_dict.pop(lock_key)
        except KeyError:
            pass  # Already released

    def _wait_for_lock_release(
        self, provider: str, timeout: float = LOCK_TIMEOUT
    ) -> None:
        """
        Wait for another process to release the refresh lock.

        Raises LockTimeoutError if lock isn't released within timeout.
        """
        lock_key = self._lock_key(provider)
        start = time.time()

        while time.time() - start < timeout:
            try:
                lock = self.token_dict.get(lock_key)
                if lock is None:
                    return  # Lock released
            except KeyError:
                return  # Lock doesn't exist

            time.sleep(LOCK_POLL_INTERVAL)

        raise LockTimeoutError(
            f"Lock for {provider} not released within {timeout}s. "
            f"May need manual cleanup: modal dict delete noauth-tokens {lock_key}"
        )

    def _load_tokens(self, provider: str) -> dict[str, Any]:
        """Load and decrypt tokens for provider."""
        token_key = self._token_key(provider)

        try:
            encrypted = self.token_dict[token_key]
        except KeyError:
            raise TokenNotFoundError(f"No tokens stored for provider: {provider}")

        try:
            return decrypt(encrypted, self.key)
        except CryptoError as e:
            raise TokenError(f"Failed to decrypt tokens for {provider}: {e}") from e

    def _save_tokens(self, provider: str, tokens: dict[str, Any]) -> None:
        """Encrypt and save tokens for provider."""
        token_key = self._token_key(provider)

        try:
            encrypted = encrypt(tokens, self.key)
        except CryptoError as e:
            raise TokenError(f"Failed to encrypt tokens for {provider}: {e}") from e

        self.token_dict[token_key] = encrypted

    @modal.method()
    def get_token(
        self,
        provider: str,
        *,
        auto_refresh: bool = True,
        refresh_threshold_seconds: int = 300,
    ) -> dict[str, Any]:
        """
        Get tokens for provider, refreshing if necessary.

        Args:
            provider: Provider name (e.g., "codex", "gemini")
            auto_refresh: Whether to auto-refresh expiring tokens
            refresh_threshold_seconds: Refresh if token expires within this time

        Returns:
            Token data (provider-specific structure)

        Raises:
            TokenNotFoundError: If no tokens stored for provider
            TokenError: If decryption or refresh fails
        """
        tokens = self._load_tokens(provider)

        if not auto_refresh:
            return tokens

        # Check if refresh needed (provider-specific logic)
        needs_refresh = self._check_needs_refresh(
            provider, tokens, refresh_threshold_seconds
        )
        if not needs_refresh:
            return tokens

        # Try to acquire lock for refresh
        if self._acquire_lock(provider):
            try:
                # Re-check after acquiring lock (another process may have refreshed)
                tokens = self._load_tokens(provider)
                if not self._check_needs_refresh(
                    provider, tokens, refresh_threshold_seconds
                ):
                    return tokens

                # Perform refresh
                refreshed_tokens = self._refresh_tokens(provider, tokens)
                self._save_tokens(provider, refreshed_tokens)
                return refreshed_tokens
            finally:
                self._release_lock(provider)
        else:
            # Wait for other process to finish refresh
            self._wait_for_lock_release(provider)
            return self._load_tokens(provider)

    def _check_needs_refresh(
        self, provider: str, tokens: dict[str, Any], threshold_seconds: int
    ) -> bool:
        """Check if tokens need refresh (provider-specific)."""
        if provider == "codex":
            return self._check_codex_needs_refresh(tokens, threshold_seconds)
        elif provider == "gemini":
            return self._check_gemini_needs_refresh(tokens, threshold_seconds)
        else:
            # Unknown provider - don't auto-refresh
            return False

    def _refresh_tokens(self, provider: str, tokens: dict[str, Any]) -> dict[str, Any]:
        """Refresh tokens (provider-specific)."""
        if provider == "codex":
            return self._refresh_codex_tokens(tokens)
        elif provider == "gemini":
            return self._refresh_gemini_tokens(tokens)
        else:
            raise TokenError(f"Unknown provider: {provider}")

    # -------------------------------------------------------------------------
    # Codex-specific implementation
    # -------------------------------------------------------------------------

    def _check_codex_needs_refresh(
        self, tokens: dict[str, Any], threshold_seconds: int
    ) -> bool:
        """Check if Codex tokens need refresh."""
        try:
            codex.validate_auth_structure(tokens)
            access_token = tokens["tokens"]["access_token"]
            return codex.is_token_expiring(
                access_token, threshold_seconds=threshold_seconds
            )
        except codex.CodexAuthError:
            return False  # Invalid structure, can't refresh

    def _refresh_codex_tokens(self, tokens: dict[str, Any]) -> dict[str, Any]:
        """Refresh Codex OAuth tokens."""
        try:
            updated, _ = codex.ensure_fresh_tokens(tokens, force_refresh=True)
            return updated
        except codex.CodexAuthError as e:
            raise TokenError(f"Codex token refresh failed: {e}") from e

    # -------------------------------------------------------------------------
    # Gemini-specific implementation
    # -------------------------------------------------------------------------

    def _check_gemini_needs_refresh(
        self, tokens: dict[str, Any], threshold_seconds: int
    ) -> bool:
        """Check if Gemini tokens need refresh."""
        try:
            gemini.validate_token_structure(tokens)
            return gemini.is_token_expiring(tokens, threshold_seconds=threshold_seconds)
        except gemini.GeminiAuthError:
            return False  # Invalid structure, can't refresh

    def _refresh_gemini_tokens(self, tokens: dict[str, Any]) -> dict[str, Any]:
        """Refresh Gemini OAuth tokens."""
        try:
            updated, _ = gemini.ensure_fresh_tokens(tokens, force_refresh=True)
            return updated
        except gemini.GeminiAuthError as e:
            raise TokenError(f"Gemini token refresh failed: {e}") from e

    # -------------------------------------------------------------------------
    # Token management endpoints
    # -------------------------------------------------------------------------

    @modal.method()
    def store_token(self, provider: str, tokens: dict[str, Any]) -> None:
        """
        Store tokens for a provider (encrypted).

        Args:
            provider: Provider name
            tokens: Token data to store

        Raises:
            TokenError: If encryption or storage fails
        """
        # Validate structure for known providers
        if provider == "codex":
            try:
                codex.validate_auth_structure(tokens)
            except codex.CodexAuthError as e:
                raise TokenError(f"Invalid Codex token structure: {e}") from e
        elif provider == "gemini":
            try:
                gemini.validate_token_structure(tokens)
            except gemini.GeminiAuthError as e:
                raise TokenError(f"Invalid Gemini token structure: {e}") from e

        self._save_tokens(provider, tokens)

    @modal.method()
    def delete_token(self, provider: str) -> bool:
        """
        Delete stored tokens for a provider.

        Returns True if tokens existed and were deleted.
        """
        token_key = self._token_key(provider)
        try:
            self.token_dict.pop(token_key)
            return True
        except KeyError:
            return False

    @modal.method()
    def list_providers(self) -> list[str]:
        """
        List providers with stored tokens.

        Note: This iterates Dict keys, which may be slow for many entries.
        """
        providers = set()
        # Dict doesn't have a keys() method, so we track what we've stored
        # In practice, you'd maintain a separate index or use known providers
        for provider in ["codex", "gemini"]:
            try:
                _ = self.token_dict[self._token_key(provider)]
                providers.add(provider)
            except KeyError:
                pass
        return sorted(providers)

    @modal.method()
    def force_refresh(self, provider: str) -> dict[str, Any]:
        """
        Force token refresh regardless of expiry status.

        Useful for testing or when tokens are known to be invalid.
        """
        tokens = self._load_tokens(provider)

        if self._acquire_lock(provider):
            try:
                refreshed_tokens = self._refresh_tokens(provider, tokens)
                self._save_tokens(provider, refreshed_tokens)
                return refreshed_tokens
            finally:
                self._release_lock(provider)
        else:
            self._wait_for_lock_release(provider)
            return self._load_tokens(provider)

    @modal.method()
    def clear_lock(self, provider: str) -> bool:
        """
        Manually clear a stuck lock.

        Use only when a refresh process crashed and left a lock behind.
        Returns True if lock existed and was cleared.
        """
        lock_key = self._lock_key(provider)
        try:
            self.token_dict.pop(lock_key)
            return True
        except KeyError:
            return False
