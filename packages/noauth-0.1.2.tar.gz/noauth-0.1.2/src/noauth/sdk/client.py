"""NoAuth SDK client for token management."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Self

import httpx

from noauth.sdk.exceptions import (
    AuthenticationError,
    ConnectionError,
    NoAuthError,
    TokenError,
    TokenNotFoundError,
)
from noauth.sdk.models import StatusResponse, StoreTokenRequest, TokenResponse

DEFAULT_URL = "https://tomas-5909--noauth-web.modal.run"
DEFAULT_TIMEOUT = 30.0


class NoAuthClient:
    """Client for interacting with the noauth token service.

    Authentication sources (in priority order):
    1. Explicit constructor parameters
    2. Environment variables (NOAUTH_CLIENT_ID, NOAUTH_CLIENT_SECRET)
    3. ~/.modal.toml file
    """

    def __init__(
        self,
        base_url: str | None = None,
        token_id: str | None = None,
        token_secret: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.base_url = (
            base_url or os.environ.get("NOAUTH_URL") or DEFAULT_URL
        ).rstrip("/")
        self.timeout = timeout

        # Resolve credentials
        self._token_id, self._token_secret = self._resolve_credentials(
            token_id, token_secret
        )

        self._client: httpx.Client | None = None

    def _resolve_credentials(
        self, token_id: str | None, token_secret: str | None
    ) -> tuple[str, str]:
        """Resolve Modal credentials from params, env vars, or config file."""
        # Priority 1: Explicit params
        if token_id and token_secret:
            return token_id, token_secret

        # Priority 2: Environment variables
        env_id = os.environ.get("NOAUTH_CLIENT_ID")
        env_secret = os.environ.get("NOAUTH_CLIENT_SECRET")
        if env_id and env_secret:
            return env_id, env_secret

        # Priority 3: ~/.modal.toml
        modal_toml = Path.home() / ".modal.toml"
        if modal_toml.exists():
            creds = self._parse_modal_toml(modal_toml)
            if creds:
                return creds

        raise AuthenticationError(
            "No Modal credentials found. Provide token_id/token_secret, "
            "set NOAUTH_CLIENT_ID/NOAUTH_CLIENT_SECRET env vars, "
            "or configure ~/.modal.toml"
        )

    def _parse_modal_toml(self, path: Path) -> tuple[str, str] | None:
        """Parse token_id and token_secret from Modal TOML config."""
        try:
            content = path.read_text()
            token_id = None
            token_secret = None

            for line in content.splitlines():
                line = line.strip()
                if line.startswith("token_id"):
                    _, _, value = line.partition("=")
                    token_id = value.strip().strip('"').strip("'")
                elif line.startswith("token_secret"):
                    _, _, value = line.partition("=")
                    token_secret = value.strip().strip('"').strip("'")

            if token_id and token_secret:
                return token_id, token_secret
        except Exception:
            pass
        return None

    @property
    def client(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url,
                headers={
                    "Modal-Key": self._token_id,
                    "Modal-Secret": self._token_secret,
                },
                timeout=self.timeout,
            )
        return self._client

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def _handle_response(self, response: httpx.Response) -> dict[str, Any]:
        """Handle HTTP response and raise appropriate exceptions."""
        try:
            data = response.json()
        except Exception:
            data = {"detail": response.text}

        if response.status_code == 401:
            raise AuthenticationError(data.get("detail", "Authentication failed"))
        if response.status_code == 404:
            raise TokenNotFoundError(data.get("detail", "Token not found"))
        if response.status_code >= 400:
            raise TokenError(
                data.get("detail", f"Request failed: {response.status_code}")
            )

        return data

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request with error handling."""
        try:
            response = self.client.request(method, path, params=params, json=json)
            return self._handle_response(response)
        except httpx.ConnectError as e:
            raise ConnectionError(f"Failed to connect to {self.base_url}: {e}") from e
        except httpx.TimeoutException as e:
            raise ConnectionError(f"Request timed out: {e}") from e
        except NoAuthError:
            raise
        except Exception as e:
            raise TokenError(f"Request failed: {e}") from e

    def get_token(self, provider: str, auto_refresh: bool = True) -> TokenResponse:
        """Get tokens for a provider.

        Args:
            provider: Provider name (codex, gemini)
            auto_refresh: Whether to auto-refresh expiring tokens (default: True)

        Returns:
            TokenResponse with provider tokens
        """
        data = self._request(
            "GET",
            "/get-token",
            params={"provider": provider, "auto_refresh": str(auto_refresh).lower()},
        )
        return TokenResponse.model_validate(data)

    def store_token(self, provider: str, tokens: dict[str, Any]) -> StatusResponse:
        """Store tokens for a provider.

        Args:
            provider: Provider name (codex, gemini)
            tokens: Token data dict

        Returns:
            StatusResponse indicating success
        """
        request = StoreTokenRequest(tokens=tokens)
        data = self._request(
            "POST",
            "/store-token",
            params={"provider": provider},
            json=request.model_dump(),
        )
        return StatusResponse.model_validate(data)

    def delete_token(self, provider: str) -> StatusResponse:
        """Delete stored tokens for a provider.

        Args:
            provider: Provider name (codex, gemini)

        Returns:
            StatusResponse indicating success
        """
        data = self._request("DELETE", "/delete-token", params={"provider": provider})
        return StatusResponse.model_validate(data)

    def refresh_token(self, provider: str) -> TokenResponse:
        """Force refresh tokens for a provider.

        Args:
            provider: Provider name (codex, gemini)

        Returns:
            TokenResponse with refreshed tokens
        """
        data = self._request("POST", "/refresh-token", params={"provider": provider})
        return TokenResponse.model_validate(data)

    def list_providers(self) -> list[str]:
        """List providers with stored tokens.

        Returns:
            List of provider names
        """
        return self._request("GET", "/list-providers")

    def clear_lock(self, provider: str) -> StatusResponse:
        """Manually clear a stuck refresh lock.

        Args:
            provider: Provider name (codex, gemini)

        Returns:
            StatusResponse indicating success
        """
        data = self._request("POST", "/clear-lock", params={"provider": provider})
        return StatusResponse.model_validate(data)

    def health(self) -> StatusResponse:
        """Health check endpoint.

        Returns:
            StatusResponse indicating service status
        """
        try:
            data = self._request("GET", "/health")
            return StatusResponse.model_validate(data)
        except httpx.ConnectError as e:
            raise ConnectionError(f"Failed to connect to {self.base_url}: {e}") from e
        except httpx.TimeoutException as e:
            raise ConnectionError(f"Request timed out: {e}") from e
        except Exception as e:
            raise TokenError(f"Health check failed: {e}") from e
