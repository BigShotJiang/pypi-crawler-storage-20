"""Pydantic models for SDK request/response types."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class StoreTokenRequest(BaseModel):
    """Request body for storing tokens."""

    tokens: dict[str, Any]


class TokenResponse(BaseModel):
    """Response containing token data."""

    provider: str
    tokens: dict[str, Any]
    refreshed: bool = False


class StatusResponse(BaseModel):
    """Generic status response."""

    success: bool
    message: str


class CodexTokens(BaseModel):
    """Codex OAuth tokens structure."""

    access_token: str
    refresh_token: str
    id_token: str | None = None
    last_refresh: str | None = None


class GeminiTokens(BaseModel):
    """Gemini OAuth tokens structure (Google Credentials format)."""

    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expiry_date: int | None = None
