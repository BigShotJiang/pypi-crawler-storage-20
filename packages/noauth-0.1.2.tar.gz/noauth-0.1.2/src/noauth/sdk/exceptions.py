"""SDK exception hierarchy."""

from __future__ import annotations


class NoAuthError(Exception):
    """Base exception for noauth SDK."""

    pass


class AuthenticationError(NoAuthError):
    """Missing or invalid Modal credentials."""

    pass


class TokenNotFoundError(NoAuthError):
    """Provider token not found (404)."""

    pass


class TokenError(NoAuthError):
    """Token operation failed (400/500)."""

    pass


class ConnectionError(NoAuthError):
    """Network failure."""

    pass
