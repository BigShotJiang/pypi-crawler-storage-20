"""noauth - Centralized OAuth token service on Modal."""

from importlib.metadata import PackageNotFoundError, version

__all__ = ["__version__"]


try:
    __version__ = version("noauth")
except PackageNotFoundError:  # pragma: no cover - local editable/dev installs
    __version__ = "0.0.0"
