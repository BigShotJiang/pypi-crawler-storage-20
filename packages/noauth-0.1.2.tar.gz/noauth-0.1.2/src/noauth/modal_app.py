"""Modal app configuration for noauth service."""

from __future__ import annotations

import modal

image = modal.Image.debian_slim(python_version="3.12").pip_install(
    "cryptography>=46.0.3",
    "fastapi[standard]",
    "pydantic>=2.12.5",
)
master_encryption_key_secret = modal.Secret.from_name(
    "kms", required_keys=["MASTER_ENCRYPTION_KEY"]
)
app = modal.App("noauth", image=image, secrets=[master_encryption_key_secret])
