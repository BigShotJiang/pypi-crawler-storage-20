"""
AES-256-GCM encryption utilities for noauth token storage.

Uses the cryptography library with OpenSSL backend for hardware-accelerated
encryption. Tokens are encrypted at rest in Modal Dict.

See docs/encryption-flow.md for detailed documentation.
"""

from __future__ import annotations

import json
import os
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

NONCE_SIZE = 12  # 96 bits, recommended for GCM
MIN_CIPHERTEXT_SIZE = NONCE_SIZE + 16  # nonce + minimum auth tag


class CryptoError(Exception):
    """Raised when encryption or decryption fails."""


def encrypt(data: dict[str, Any], key: bytes) -> bytes:
    """Encrypt a dictionary with AES-256-GCM.

    Args:
        data: Dictionary to encrypt (will be JSON serialized)
        key: 32-byte AES key

    Returns:
        Encrypted bytes: nonce (12) + ciphertext + tag (16)

    Raises:
        CryptoError: If key is invalid or encryption fails
    """
    if len(key) != 32:
        raise CryptoError(f"Key must be 32 bytes, got {len(key)}")

    try:
        plaintext = json.dumps(data, separators=(",", ":")).encode("utf-8")
        nonce = os.urandom(NONCE_SIZE)
        aesgcm = AESGCM(key)
        ciphertext = aesgcm.encrypt(nonce, plaintext, associated_data=None)
        return nonce + ciphertext
    except Exception as e:
        raise CryptoError(f"Encryption failed: {e}") from e


def decrypt(encrypted: bytes, key: bytes) -> dict[str, Any]:
    """Decrypt data encrypted with encrypt().

    Args:
        encrypted: Output from encrypt()
        key: 32-byte AES key (same as used for encryption)

    Returns:
        Decrypted dictionary

    Raises:
        CryptoError: If key is invalid, data is tampered, or decryption fails
    """
    if len(key) != 32:
        raise CryptoError(f"Key must be 32 bytes, got {len(key)}")

    if len(encrypted) < MIN_CIPHERTEXT_SIZE:
        raise CryptoError(
            f"Encrypted data too short: {len(encrypted)} bytes, "
            f"minimum {MIN_CIPHERTEXT_SIZE}"
        )

    try:
        nonce = encrypted[:NONCE_SIZE]
        ciphertext = encrypted[NONCE_SIZE:]
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, associated_data=None)
        return json.loads(plaintext.decode("utf-8"))
    except json.JSONDecodeError as e:
        raise CryptoError(f"Decrypted data is not valid JSON: {e}") from e
    except Exception as e:
        # cryptography.exceptions.InvalidTag or other errors
        raise CryptoError(f"Decryption failed (wrong key or tampered data): {e}") from e


def load_key_from_env(env_var: str = "MASTER_ENCRYPTION_KEY") -> bytes:
    """Load AES key from environment variable.

    Args:
        env_var: Name of environment variable containing hex-encoded key

    Returns:
        32-byte key

    Raises:
        CryptoError: If key missing or invalid
    """
    hex_key = os.environ.get(env_var, "").strip()
    if not hex_key:
        raise CryptoError(f"{env_var} environment variable not set")

    try:
        key = bytes.fromhex(hex_key)
    except ValueError as e:
        raise CryptoError(f"{env_var} is not valid hex: {e}") from e

    if len(key) != 32:
        raise CryptoError(f"Key must be 32 bytes (64 hex chars), got {len(key)} bytes")

    return key
