"""
noauth API endpoints.

Protected FastAPI endpoints for token management.
All endpoints require Modal Proxy Auth.
"""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

import modal

from .modal_app import app
from .kms import KMS, LockTimeoutError, TokenError, TokenNotFoundError


class StoreTokenRequest(BaseModel):
    """Request body for storing tokens."""

    tokens: dict[str, Any]


class TokenResponse(BaseModel):
    """Response containing token data."""

    provider: str
    tokens: dict[str, Any]
    refreshed: bool = False


class StatusResponse(BaseModel):
    """Generic status response."""

    success: bool
    message: str


def build_app() -> FastAPI:
    """Create the FastAPI app with noauth endpoints."""
    web_app = FastAPI(title="noauth", description="Centralized OAuth token service")

    # Create KMS instance for endpoint handlers
    kms = KMS()

    @web_app.get("/health")
    def health() -> StatusResponse:
        """Health check endpoint."""
        return StatusResponse(success=True, message="noauth is running")

    @web_app.get("/get-token")
    def get_token(provider: str, auto_refresh: bool = True) -> TokenResponse:
        """
        Get tokens for a provider.

        Query params:
        - provider: Provider name (codex, gemini)
        - auto_refresh: Whether to auto-refresh expiring tokens (default: true)

        Returns token data. If auto_refresh is enabled and tokens were refreshed,
        the response includes refreshed=true.
        """
        try:
            tokens = kms.get_token.remote(provider, auto_refresh=auto_refresh)
            return TokenResponse(provider=provider, tokens=tokens)
        except TokenNotFoundError:
            raise HTTPException(
                status_code=404, detail=f"No tokens stored for provider: {provider}"
            )
        except LockTimeoutError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except TokenError as e:
            raise HTTPException(status_code=500, detail=str(e))

    @web_app.post("/store-token")
    def store_token(provider: str, request: StoreTokenRequest) -> StatusResponse:
        """
        Store tokens for a provider.

        Body:
        - tokens: Token data object (structure depends on provider)

        For Codex, expects:
        {
        "tokens": {
            "access_token": "...",
            "refresh_token": "...",
            "id_token": "..." (optional)
        },
        "last_refresh": "..." (optional)
        }

        For Gemini, expects (Google Credentials format from ~/.gemini/oauth_creds.json):
        {
        "access_token": "ya29.a0AfH6SMBx...",
        "refresh_token": "1//0eXxXxXx...",
        "token_type": "Bearer",
        "expiry_date": 1737234567890  (optional, Unix ms)
        }
        """
        try:
            kms.store_token.remote(provider, request.tokens)
            return StatusResponse(success=True, message=f"Tokens stored for {provider}")
        except TokenError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @web_app.delete("/delete-token")
    def delete_token(provider: str) -> StatusResponse:
        """Delete stored tokens for a provider."""
        deleted = kms.delete_token.remote(provider)
        if deleted:
            return StatusResponse(
                success=True, message=f"Tokens deleted for {provider}"
            )
        else:
            raise HTTPException(
                status_code=404, detail=f"No tokens stored for provider: {provider}"
            )

    @web_app.post("/refresh-token")
    def refresh_token(provider: str) -> TokenResponse:
        """
        Force refresh tokens for a provider.

        Useful when tokens are known to be invalid or for testing.
        """
        try:
            tokens = kms.force_refresh.remote(provider)
            return TokenResponse(provider=provider, tokens=tokens, refreshed=True)
        except TokenNotFoundError:
            raise HTTPException(
                status_code=404, detail=f"No tokens stored for provider: {provider}"
            )
        except LockTimeoutError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except TokenError as e:
            raise HTTPException(status_code=500, detail=str(e))

    @web_app.get("/list-providers")
    def list_providers() -> list[str]:
        """List providers with stored tokens."""
        return kms.list_providers.remote()

    @web_app.post("/clear-lock")
    def clear_lock(provider: str) -> StatusResponse:
        """
        Manually clear a stuck refresh lock.

        Use only when a refresh process crashed and left a lock behind.
        """
        cleared = kms.clear_lock.remote(provider)
        if cleared:
            return StatusResponse(success=True, message=f"Lock cleared for {provider}")
        else:
            return StatusResponse(
                success=True, message=f"No lock existed for {provider}"
            )

    return web_app


@app.function()
@modal.asgi_app(requires_proxy_auth=True)
def web() -> FastAPI:
    """ASGI app serving all noauth endpoints."""
    return build_app()
