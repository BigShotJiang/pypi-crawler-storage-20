"""
Codex/ChatGPT OAuth token refresh handler.

Handles the OAuth refresh flow for OpenAI Codex CLI tokens stored in auth.json format.

Token structure (OAuth portion):
{
  "OPENAI_API_KEY": null,          # optional, for API key auth mode
  "tokens": {
    "id_token": "...",             # JWT with user info, may rotate
    "access_token": "...",         # JWT for API calls
    "refresh_token": "...",        # used to get new access tokens
    "account_id": "..."            # optional
  },
  "last_refresh": "2025-01-15T10:30:00Z"
}

Refresh behavior:
- Access tokens are JWTs with an 'exp' claim (typically ~1 hour)
- We refresh when token expires within threshold (default 5 minutes)
- Codex CLI uses 8-day interval as fallback; we use actual JWT expiry

This module intentionally avoids logging any tokens.
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

# Codex OAuth constants (from codex-rs/core/src/auth.rs)
DEFAULT_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
DEFAULT_TOKEN_ENDPOINT = "https://auth.openai.com/oauth/token"

# Refresh when token expires within this many seconds
DEFAULT_REFRESH_THRESHOLD_SECONDS = 300  # 5 minutes


class CodexAuthError(Exception):
    """Raised when Codex auth operations fail."""


@dataclass(frozen=True)
class RefreshedTokens:
    """Result of a successful token refresh."""

    access_token: str
    refresh_token: str | None = None
    id_token: str | None = None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _isoformat_z(dt: datetime) -> str:
    """Format datetime as ISO string with Z suffix (like JS toISOString)."""
    return (
        dt.astimezone(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def _b64url_decode(data: str) -> bytes:
    """Decode base64url without requiring padding."""
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def _jwt_payload(token: str) -> dict[str, Any] | None:
    """
    Best-effort decode of JWT payload (no signature verification).
    Returns None if token doesn't look like a JWT or decoding fails.
    """
    parts = token.split(".")
    if len(parts) < 2:
        return None
    try:
        payload_raw = _b64url_decode(parts[1])
        payload = json.loads(payload_raw.decode("utf-8"))
        if isinstance(payload, dict):
            return payload
        return None
    except Exception:
        return None


def get_token_expiry(access_token: str) -> datetime | None:
    """
    Returns the expiry time from the access token's JWT 'exp' claim.
    None if not available / not parseable.
    """
    payload = _jwt_payload(access_token)
    if not payload:
        return None
    exp = payload.get("exp")
    if isinstance(exp, (int, float)) and exp > 0:
        return datetime.fromtimestamp(int(exp), tz=timezone.utc)
    return None


def is_token_expiring(
    access_token: str,
    *,
    threshold_seconds: int = DEFAULT_REFRESH_THRESHOLD_SECONDS,
    now: datetime | None = None,
) -> bool:
    """
    Returns True if:
      - access_token has an 'exp' claim AND
      - exp - now <= threshold_seconds

    If the token has no parseable 'exp', returns False (unknown).
    """
    now_dt = now or _utc_now()
    exp_dt = get_token_expiry(access_token)
    if exp_dt is None:
        return False
    remaining = (exp_dt - now_dt).total_seconds()
    return remaining <= threshold_seconds


def is_token_expired(access_token: str, *, now: datetime | None = None) -> bool:
    """Returns True if token is already expired."""
    return is_token_expiring(access_token, threshold_seconds=0, now=now)


def refresh_tokens(
    refresh_token: str,
    *,
    client_id: str | None = None,
    token_endpoint: str | None = None,
    timeout_seconds: float = 15.0,
) -> RefreshedTokens:
    """
    Refresh tokens using the OAuth refresh_token grant.

    POST to token_endpoint with:
      grant_type=refresh_token
      refresh_token=...
      client_id=...

    Returns new access_token, plus optional rotated refresh_token and id_token.

    Raises:
        CodexAuthError: If refresh fails (network error, invalid token, etc.)
    """
    client_id_final = (client_id or DEFAULT_CLIENT_ID).strip()
    endpoint_final = (token_endpoint or DEFAULT_TOKEN_ENDPOINT).strip()

    if not client_id_final:
        raise CodexAuthError("client_id is empty")
    if not endpoint_final:
        raise CodexAuthError("token_endpoint is empty")
    if not refresh_token.strip():
        raise CodexAuthError("refresh_token is empty")

    form = urlencode(
        {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token.strip(),
            "client_id": client_id_final,
        }
    ).encode("utf-8")

    req = Request(
        endpoint_final,
        data=form,
        method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    try:
        with urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read()
    except HTTPError as e:
        # Avoid leaking tokens in error messages
        body = b""
        try:
            body = e.read() or b""
        except Exception:
            pass

        # Parse error code if available
        error_code = _extract_error_code(body)
        error_msg = _error_code_to_message(error_code)

        raise CodexAuthError(f"Token refresh failed: HTTP {e.code}. {error_msg}") from e
    except URLError as e:
        raise CodexAuthError(f"Token refresh failed: network error: {e.reason}") from e
    except TimeoutError as e:
        raise CodexAuthError(
            f"Token refresh failed: timeout after {timeout_seconds}s"
        ) from e

    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise CodexAuthError("Token refresh failed: response was not valid JSON") from e

    access = (data.get("access_token") or "").strip()
    if not access:
        raise CodexAuthError("Token refresh response missing access_token")

    new_refresh = data.get("refresh_token")
    if isinstance(new_refresh, str):
        new_refresh = new_refresh.strip() or None
    else:
        new_refresh = None

    new_id = data.get("id_token")
    if isinstance(new_id, str):
        new_id = new_id.strip() or None
    else:
        new_id = None

    return RefreshedTokens(
        access_token=access,
        refresh_token=new_refresh,
        id_token=new_id,
    )


def _extract_error_code(body: bytes) -> str | None:
    """Extract error code from OAuth error response."""
    if not body:
        return None
    try:
        data = json.loads(body.decode("utf-8"))
        if isinstance(data, dict):
            error = data.get("error")
            if isinstance(error, dict):
                return error.get("code")
            elif isinstance(error, str):
                return error
            return data.get("code")
    except Exception:
        pass
    return None


def _error_code_to_message(code: str | None) -> str:
    """Convert OAuth error code to user-friendly message."""
    if not code:
        return "Please log out and sign in again."

    code_lower = code.lower()
    if code_lower == "refresh_token_expired":
        return "Refresh token has expired. Please log out and sign in again."
    elif code_lower == "refresh_token_reused":
        return "Refresh token was already used. Please log out and sign in again."
    elif code_lower == "refresh_token_invalidated":
        return "Refresh token was revoked. Please log out and sign in again."
    else:
        return f"Error: {code}. Please log out and sign in again."


def validate_auth_structure(auth: dict[str, Any]) -> None:
    """
    Validate that auth dict has the expected Codex auth.json structure.

    Raises:
        CodexAuthError: If structure is invalid
    """
    tokens = auth.get("tokens")
    if not isinstance(tokens, dict):
        raise CodexAuthError("auth data missing 'tokens' object (OAuth login required)")

    access_token = tokens.get("access_token")
    if not isinstance(access_token, str) or not access_token.strip():
        raise CodexAuthError("auth data missing tokens.access_token")

    refresh_token = tokens.get("refresh_token")
    if not isinstance(refresh_token, str) or not refresh_token.strip():
        raise CodexAuthError("auth data missing tokens.refresh_token")


def apply_refreshed_tokens(
    auth: dict[str, Any], refreshed: RefreshedTokens
) -> dict[str, Any]:
    """
    Apply refreshed tokens to auth dict, updating last_refresh timestamp.

    Returns a new dict (does not mutate input).
    """
    auth = auth.copy()
    tokens = auth.get("tokens", {}).copy()

    tokens["access_token"] = refreshed.access_token
    if refreshed.refresh_token:
        tokens["refresh_token"] = refreshed.refresh_token
    if refreshed.id_token:
        tokens["id_token"] = refreshed.id_token

    auth["tokens"] = tokens
    auth["last_refresh"] = _isoformat_z(_utc_now())

    return auth


def ensure_fresh_tokens(
    auth: dict[str, Any],
    *,
    threshold_seconds: int = DEFAULT_REFRESH_THRESHOLD_SECONDS,
    force_refresh: bool = False,
    client_id: str | None = None,
    token_endpoint: str | None = None,
    timeout_seconds: float = 15.0,
) -> tuple[dict[str, Any], bool]:
    """
    Ensure tokens in auth dict are fresh, refreshing if necessary.

    Args:
        auth: Codex auth.json structure
        threshold_seconds: Refresh if token expires within this many seconds
        force_refresh: Force refresh even if token isn't expiring
        client_id: OAuth client ID (defaults to Codex CLI client)
        token_endpoint: OAuth token endpoint
        timeout_seconds: HTTP timeout for refresh request

    Returns:
        Tuple of (updated_auth_dict, was_refreshed)

    Raises:
        CodexAuthError: If auth structure is invalid or refresh fails
    """
    validate_auth_structure(auth)

    tokens = auth["tokens"]
    access_token = tokens["access_token"].strip()
    refresh_token = tokens["refresh_token"].strip()

    needs_refresh = force_refresh or is_token_expiring(
        access_token, threshold_seconds=threshold_seconds
    )

    if not needs_refresh:
        return auth, False

    refreshed = refresh_tokens(
        refresh_token,
        client_id=client_id,
        token_endpoint=token_endpoint,
        timeout_seconds=timeout_seconds,
    )

    updated_auth = apply_refreshed_tokens(auth, refreshed)
    return updated_auth, True
