"""
Gemini CLI OAuth token refresh handler.

Handles the OAuth refresh flow for Google Gemini CLI tokens stored in oauth_creds.json format.

Token structure (Google Credentials format):
{
  "access_token": "ya29.a0AfH6SMBx...",
  "refresh_token": "1//0eXxXxXx...",
  "token_type": "Bearer",
  "expiry_date": 1737234567890,  # Unix timestamp in milliseconds
  "scope": "..."
}

Refresh behavior:
- Access tokens typically last ~1 hour
- We refresh when token expires within threshold (default 5 minutes)
- Google may return a new refresh_token on each refresh (must be stored)

This module intentionally avoids logging any tokens.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

# Gemini CLI OAuth constants (from google-gemini/gemini-cli oauth2.ts)
# These are public credentials for an "installed application" - safe to embed
# See: https://developers.google.com/identity/protocols/oauth2#installed
DEFAULT_CLIENT_ID = (
    "681255809395-oo8ft2oprdrnp9e3aqf6av3hmdib135j.apps.googleusercontent.com"
)
DEFAULT_CLIENT_SECRET = "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"
DEFAULT_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"

# Refresh when token expires within this many seconds
DEFAULT_REFRESH_THRESHOLD_SECONDS = 300  # 5 minutes


class GeminiAuthError(Exception):
    """Raised when Gemini auth operations fail."""


@dataclass(frozen=True)
class RefreshedTokens:
    """Result of a successful token refresh."""

    access_token: str
    expires_in: int  # seconds until expiry
    token_type: str = "Bearer"
    refresh_token: str | None = None  # May be rotated
    scope: str | None = None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _isoformat_z(dt: datetime) -> str:
    """Format datetime as ISO string with Z suffix (like JS toISOString)."""
    return (
        dt.astimezone(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def get_token_expiry(tokens: dict[str, Any]) -> datetime | None:
    """
    Returns the expiry time from the tokens' expiry_date field.

    Note: Google Credentials use expiry_date in MILLISECONDS.
    We also support expires_at in SECONDS for compatibility.

    Returns None if not available.
    """
    # Try expiry_date (milliseconds) - Google Credentials format
    expiry_date = tokens.get("expiry_date")
    if isinstance(expiry_date, (int, float)) and expiry_date > 0:
        # Convert milliseconds to datetime
        return datetime.fromtimestamp(expiry_date / 1000, tz=timezone.utc)

    # Try expires_at (seconds) - alternative format
    expires_at = tokens.get("expires_at")
    if isinstance(expires_at, (int, float)) and expires_at > 0:
        return datetime.fromtimestamp(expires_at, tz=timezone.utc)

    return None


def is_token_expiring(
    tokens: dict[str, Any],
    *,
    threshold_seconds: int = DEFAULT_REFRESH_THRESHOLD_SECONDS,
    now: datetime | None = None,
) -> bool:
    """
    Returns True if:
      - tokens have an expiry time AND
      - expiry - now <= threshold_seconds

    If the token has no parseable expiry, returns False (unknown).
    """
    now_dt = now or _utc_now()
    exp_dt = get_token_expiry(tokens)
    if exp_dt is None:
        return False
    remaining = (exp_dt - now_dt).total_seconds()
    return remaining <= threshold_seconds


def is_token_expired(tokens: dict[str, Any], *, now: datetime | None = None) -> bool:
    """Returns True if token is already expired."""
    return is_token_expiring(tokens, threshold_seconds=0, now=now)


def refresh_tokens(
    refresh_token: str,
    *,
    client_id: str | None = None,
    client_secret: str | None = None,
    token_endpoint: str | None = None,
    timeout_seconds: float = 15.0,
) -> RefreshedTokens:
    """
    Refresh tokens using the OAuth refresh_token grant.

    POST to token_endpoint with:
      grant_type=refresh_token
      refresh_token=...
      client_id=...
      client_secret=...

    Returns new access_token, plus optional rotated refresh_token.

    Raises:
        GeminiAuthError: If refresh fails (network error, invalid token, etc.)
    """
    client_id_final = (client_id or DEFAULT_CLIENT_ID).strip()
    client_secret_final = (client_secret or DEFAULT_CLIENT_SECRET).strip()
    endpoint_final = (token_endpoint or DEFAULT_TOKEN_ENDPOINT).strip()

    if not client_id_final:
        raise GeminiAuthError("client_id is empty")
    if not client_secret_final:
        raise GeminiAuthError("client_secret is empty")
    if not endpoint_final:
        raise GeminiAuthError("token_endpoint is empty")
    if not refresh_token.strip():
        raise GeminiAuthError("refresh_token is empty")

    form = urlencode(
        {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token.strip(),
            "client_id": client_id_final,
            "client_secret": client_secret_final,
        }
    ).encode("utf-8")

    req = Request(
        endpoint_final,
        data=form,
        method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )

    try:
        with urlopen(req, timeout=timeout_seconds) as resp:
            raw = resp.read()
    except HTTPError as e:
        # Avoid leaking tokens in error messages
        body = b""
        try:
            body = e.read() or b""
        except Exception:
            pass

        # Parse error code if available
        error_code = _extract_error_code(body)
        error_msg = _error_code_to_message(error_code)

        raise GeminiAuthError(
            f"Token refresh failed: HTTP {e.code}. {error_msg}"
        ) from e
    except URLError as e:
        raise GeminiAuthError(f"Token refresh failed: network error: {e.reason}") from e
    except TimeoutError as e:
        raise GeminiAuthError(
            f"Token refresh failed: timeout after {timeout_seconds}s"
        ) from e

    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as e:
        raise GeminiAuthError(
            "Token refresh failed: response was not valid JSON"
        ) from e

    access = (data.get("access_token") or "").strip()
    if not access:
        raise GeminiAuthError("Token refresh response missing access_token")

    expires_in = data.get("expires_in")
    if not isinstance(expires_in, int) or expires_in <= 0:
        # Default to 1 hour if not provided
        expires_in = 3600

    token_type = data.get("token_type", "Bearer")
    scope = data.get("scope")

    # Google may rotate refresh tokens
    new_refresh = data.get("refresh_token")
    if isinstance(new_refresh, str):
        new_refresh = new_refresh.strip() or None
    else:
        new_refresh = None

    return RefreshedTokens(
        access_token=access,
        expires_in=expires_in,
        token_type=token_type,
        refresh_token=new_refresh,
        scope=scope if isinstance(scope, str) else None,
    )


def _extract_error_code(body: bytes) -> str | None:
    """Extract error code from Google OAuth error response."""
    if not body:
        return None
    try:
        data = json.loads(body.decode("utf-8"))
        if isinstance(data, dict):
            # Google returns: {"error": "invalid_grant", "error_description": "..."}
            error = data.get("error")
            if isinstance(error, str):
                return error
            return data.get("code")
    except Exception:
        pass
    return None


def _error_code_to_message(code: str | None) -> str:
    """Convert Google OAuth error code to user-friendly message."""
    if not code:
        return "Please re-authenticate with Gemini CLI."

    code_lower = code.lower()
    if code_lower == "invalid_grant":
        return (
            "Refresh token expired or revoked. Please re-authenticate with Gemini CLI."
        )
    elif code_lower == "invalid_client":
        return "Invalid client credentials. This may be a configuration error."
    elif code_lower == "unauthorized_client":
        return "Client not authorized for this grant type."
    else:
        return f"Error: {code}. Please re-authenticate with Gemini CLI."


def validate_token_structure(tokens: dict[str, Any]) -> None:
    """
    Validate that tokens dict has the expected Google Credentials structure.

    Raises:
        GeminiAuthError: If structure is invalid
    """
    access_token = tokens.get("access_token")
    if not isinstance(access_token, str) or not access_token.strip():
        raise GeminiAuthError("tokens missing 'access_token'")

    refresh_token = tokens.get("refresh_token")
    if not isinstance(refresh_token, str) or not refresh_token.strip():
        raise GeminiAuthError("tokens missing 'refresh_token'")

    # Warn if no expiry info (but don't fail)
    if not tokens.get("expiry_date") and not tokens.get("expires_at"):
        # This is a soft warning - token may still work
        pass


def apply_refreshed_tokens(
    tokens: dict[str, Any], refreshed: RefreshedTokens
) -> dict[str, Any]:
    """
    Apply refreshed tokens to tokens dict, updating expiry timestamp.

    Returns a new dict (does not mutate input).
    """
    tokens = tokens.copy()

    tokens["access_token"] = refreshed.access_token
    tokens["token_type"] = refreshed.token_type

    # Google may rotate refresh tokens - must update if new one provided
    if refreshed.refresh_token:
        tokens["refresh_token"] = refreshed.refresh_token

    if refreshed.scope:
        tokens["scope"] = refreshed.scope

    # Update expiry - use milliseconds for Google Credentials format
    now_ms = int(time.time() * 1000)
    tokens["expiry_date"] = now_ms + (refreshed.expires_in * 1000)

    # Also store expires_at in seconds for compatibility
    tokens["expires_at"] = int(time.time()) + refreshed.expires_in

    # Track when we last refreshed
    tokens["last_refresh"] = _isoformat_z(_utc_now())

    return tokens


def ensure_fresh_tokens(
    tokens: dict[str, Any],
    *,
    threshold_seconds: int = DEFAULT_REFRESH_THRESHOLD_SECONDS,
    force_refresh: bool = False,
    client_id: str | None = None,
    client_secret: str | None = None,
    token_endpoint: str | None = None,
    timeout_seconds: float = 15.0,
) -> tuple[dict[str, Any], bool]:
    """
    Ensure tokens are fresh, refreshing if necessary.

    Args:
        tokens: Google Credentials structure
        threshold_seconds: Refresh if token expires within this many seconds
        force_refresh: Force refresh even if token isn't expiring
        client_id: OAuth client ID (defaults to Gemini CLI client)
        client_secret: OAuth client secret (defaults to Gemini CLI secret)
        token_endpoint: OAuth token endpoint
        timeout_seconds: HTTP timeout for refresh request

    Returns:
        Tuple of (updated_tokens_dict, was_refreshed)

    Raises:
        GeminiAuthError: If token structure is invalid or refresh fails
    """
    validate_token_structure(tokens)

    refresh_token = tokens["refresh_token"].strip()

    needs_refresh = force_refresh or is_token_expiring(
        tokens, threshold_seconds=threshold_seconds
    )

    if not needs_refresh:
        return tokens, False

    refreshed = refresh_tokens(
        refresh_token,
        client_id=client_id,
        client_secret=client_secret,
        token_endpoint=token_endpoint,
        timeout_seconds=timeout_seconds,
    )

    updated_tokens = apply_refreshed_tokens(tokens, refreshed)
    return updated_tokens, True
