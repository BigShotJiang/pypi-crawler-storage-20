"""Tests for FastAPI app wiring."""

from noauth.app import build_app


def test_build_app_health_openapi_response_model() -> None:
    """Health route response model should be fully defined."""
    app = build_app()

    health_route = next(
        route
        for route in app.routes
        if getattr(route, "path", None) == "/health"
        and "GET" in getattr(route, "methods", set())
    )

    response_field = getattr(health_route, "response_field", None)
    assert response_field is not None
    assert response_field.type_ is not None
