"""Tests for noauth.crypto module."""

import pytest

from noauth.crypto import (
    MIN_CIPHERTEXT_SIZE,
    NONCE_SIZE,
    CryptoError,
    decrypt,
    encrypt,
    load_key_from_env,
)


class TestEncrypt:
    """Tests for encrypt()."""

    def test_encrypt_returns_bytes(self, test_encryption_key: bytes):
        data = {"access_token": "test123"}
        result = encrypt(data, test_encryption_key)
        assert isinstance(result, bytes)

    def test_encrypt_output_contains_nonce(self, test_encryption_key: bytes):
        data = {"key": "value"}
        result = encrypt(data, test_encryption_key)
        assert len(result) >= MIN_CIPHERTEXT_SIZE

    def test_encrypt_different_nonce_each_time(self, test_encryption_key: bytes):
        data = {"key": "value"}
        result1 = encrypt(data, test_encryption_key)
        result2 = encrypt(data, test_encryption_key)
        # Nonces should be different (first 12 bytes)
        assert result1[:NONCE_SIZE] != result2[:NONCE_SIZE]

    def test_encrypt_rejects_short_key(self):
        data = {"key": "value"}
        short_key = b"short"
        with pytest.raises(CryptoError, match="Key must be 32 bytes"):
            encrypt(data, short_key)

    def test_encrypt_rejects_long_key(self):
        data = {"key": "value"}
        long_key = b"x" * 64
        with pytest.raises(CryptoError, match="Key must be 32 bytes"):
            encrypt(data, long_key)


class TestDecrypt:
    """Tests for decrypt()."""

    def test_decrypt_roundtrip(self, test_encryption_key: bytes):
        original = {"access_token": "abc123", "refresh_token": "xyz789"}
        encrypted = encrypt(original, test_encryption_key)
        decrypted = decrypt(encrypted, test_encryption_key)
        assert decrypted == original

    def test_decrypt_unicode_data(self, test_encryption_key: bytes):
        original = {"message": "Hello 世界 🌍"}
        encrypted = encrypt(original, test_encryption_key)
        decrypted = decrypt(encrypted, test_encryption_key)
        assert decrypted == original

    def test_decrypt_nested_dict(self, test_encryption_key: bytes):
        original = {
            "tokens": {"access_token": "abc", "refresh_token": "xyz"},
            "metadata": {"created": 123456},
        }
        encrypted = encrypt(original, test_encryption_key)
        decrypted = decrypt(encrypted, test_encryption_key)
        assert decrypted == original

    def test_decrypt_rejects_short_data(self, test_encryption_key: bytes):
        short_data = b"short"
        with pytest.raises(CryptoError, match="Encrypted data too short"):
            decrypt(short_data, test_encryption_key)

    def test_decrypt_rejects_wrong_key(self, test_encryption_key: bytes):
        original = {"key": "value"}
        encrypted = encrypt(original, test_encryption_key)
        wrong_key = bytes.fromhex("1" * 64)
        with pytest.raises(CryptoError, match="Decryption failed"):
            decrypt(encrypted, wrong_key)

    def test_decrypt_rejects_tampered_data(self, test_encryption_key: bytes):
        original = {"key": "value"}
        encrypted = encrypt(original, test_encryption_key)
        tampered = bytearray(encrypted)
        tampered[-1] ^= 0xFF  # Flip bits in auth tag
        with pytest.raises(CryptoError, match="Decryption failed"):
            decrypt(bytes(tampered), test_encryption_key)


class TestLoadKeyFromEnv:
    """Tests for load_key_from_env()."""

    def test_load_key_success(
        self, monkeypatch: pytest.MonkeyPatch, test_encryption_key_hex: str
    ):
        monkeypatch.setenv("MASTER_ENCRYPTION_KEY", test_encryption_key_hex)
        key = load_key_from_env()
        assert key == bytes.fromhex(test_encryption_key_hex)

    def test_load_key_custom_env_var(self, monkeypatch: pytest.MonkeyPatch):
        hex_key = "ab" * 32
        monkeypatch.setenv("CUSTOM_KEY", hex_key)
        key = load_key_from_env("CUSTOM_KEY")
        assert key == bytes.fromhex(hex_key)

    def test_load_key_missing_env_var(self):
        with pytest.raises(CryptoError, match="environment variable not set"):
            load_key_from_env("NONEXISTENT_KEY")

    def test_load_key_empty_env_var(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("MASTER_ENCRYPTION_KEY", "")
        with pytest.raises(CryptoError, match="environment variable not set"):
            load_key_from_env()

    def test_load_key_invalid_hex(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("MASTER_ENCRYPTION_KEY", "not-valid-hex")
        with pytest.raises(CryptoError, match="not valid hex"):
            load_key_from_env()

    def test_load_key_wrong_length(self, monkeypatch: pytest.MonkeyPatch):
        # 16 bytes (32 hex chars) instead of 32 bytes
        monkeypatch.setenv("MASTER_ENCRYPTION_KEY", "00" * 16)
        with pytest.raises(CryptoError, match="Key must be 32 bytes"):
            load_key_from_env()

    def test_load_key_strips_whitespace(self, monkeypatch: pytest.MonkeyPatch):
        hex_key = "00" * 32
        monkeypatch.setenv("MASTER_ENCRYPTION_KEY", f"  {hex_key}  \n")
        key = load_key_from_env()
        assert key == bytes.fromhex(hex_key)
