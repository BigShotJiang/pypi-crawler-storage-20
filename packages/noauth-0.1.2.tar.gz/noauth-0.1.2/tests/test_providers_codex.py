"""Tests for noauth.providers.codex module."""

import base64
import json
import time
from unittest.mock import MagicMock, patch

import pytest

from noauth.providers.codex import (
    CodexAuthError,
    RefreshedTokens,
    apply_refreshed_tokens,
    ensure_fresh_tokens,
    get_token_expiry,
    is_token_expired,
    is_token_expiring,
    validate_auth_structure,
)


def _make_jwt(payload: dict, header: dict | None = None) -> str:
    """Create a JWT token for testing (no signature verification)."""
    header = header or {"alg": "none", "typ": "JWT"}
    header_b64 = base64.urlsafe_b64encode(json.dumps(header).encode()).rstrip(b"=")
    payload_b64 = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=")
    sig_b64 = base64.urlsafe_b64encode(b"fake-signature").rstrip(b"=")
    return f"{header_b64.decode()}.{payload_b64.decode()}.{sig_b64.decode()}"


def _make_expired_jwt(seconds_ago: int = 60) -> str:
    """Create a JWT that expired N seconds ago."""
    exp = int(time.time()) - seconds_ago
    return _make_jwt({"exp": exp, "sub": "test"})


def _make_valid_jwt(expires_in: int = 3600) -> str:
    """Create a JWT that expires in N seconds."""
    exp = int(time.time()) + expires_in
    return _make_jwt({"exp": exp, "sub": "test"})


def _make_auth_dict(access_token: str, refresh_token: str = "refresh123") -> dict:
    """Create a valid auth structure for testing."""
    return {
        "tokens": {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "id_token": "id123",
        },
        "last_refresh": "2025-01-15T10:30:00Z",
    }


class TestGetTokenExpiry:
    """Tests for get_token_expiry()."""

    def test_valid_jwt_with_exp(self):
        exp_time = int(time.time()) + 3600
        token = _make_jwt({"exp": exp_time})
        result = get_token_expiry(token)
        assert result is not None
        assert int(result.timestamp()) == exp_time

    def test_jwt_without_exp(self):
        token = _make_jwt({"sub": "user123"})
        result = get_token_expiry(token)
        assert result is None

    def test_invalid_jwt_format(self):
        assert get_token_expiry("not-a-jwt") is None
        assert get_token_expiry("only.two") is None
        assert get_token_expiry("") is None

    def test_invalid_base64(self):
        # Invalid base64 in payload
        assert get_token_expiry("header.!!!invalid!!!.sig") is None


class TestIsTokenExpiring:
    """Tests for is_token_expiring()."""

    def test_expiring_soon(self):
        # Token expires in 60 seconds, threshold is 300
        token = _make_valid_jwt(expires_in=60)
        assert is_token_expiring(token, threshold_seconds=300) is True

    def test_not_expiring(self):
        # Token expires in 3600 seconds, threshold is 300
        token = _make_valid_jwt(expires_in=3600)
        assert is_token_expiring(token, threshold_seconds=300) is False

    def test_already_expired(self):
        token = _make_expired_jwt(seconds_ago=60)
        assert is_token_expiring(token, threshold_seconds=300) is True

    def test_no_exp_claim(self):
        token = _make_jwt({"sub": "user"})
        # Unknown expiry returns False
        assert is_token_expiring(token, threshold_seconds=300) is False

    def test_exactly_at_threshold(self):
        # Token expires exactly at threshold - should be considered expiring
        token = _make_valid_jwt(expires_in=300)
        assert is_token_expiring(token, threshold_seconds=300) is True


class TestIsTokenExpired:
    """Tests for is_token_expired()."""

    def test_expired(self):
        token = _make_expired_jwt(seconds_ago=60)
        assert is_token_expired(token) is True

    def test_not_expired(self):
        token = _make_valid_jwt(expires_in=3600)
        assert is_token_expired(token) is False


class TestValidateAuthStructure:
    """Tests for validate_auth_structure()."""

    def test_valid_structure(self):
        auth = _make_auth_dict(_make_valid_jwt())
        # Should not raise
        validate_auth_structure(auth)

    def test_missing_tokens(self):
        auth = {"last_refresh": "2025-01-15T10:30:00Z"}
        with pytest.raises(CodexAuthError, match="missing 'tokens' object"):
            validate_auth_structure(auth)

    def test_tokens_not_dict(self):
        auth = {"tokens": "not-a-dict"}
        with pytest.raises(CodexAuthError, match="missing 'tokens' object"):
            validate_auth_structure(auth)

    def test_missing_access_token(self):
        auth = {"tokens": {"refresh_token": "refresh123"}}
        with pytest.raises(CodexAuthError, match="missing tokens.access_token"):
            validate_auth_structure(auth)

    def test_empty_access_token(self):
        auth = {"tokens": {"access_token": "  ", "refresh_token": "refresh123"}}
        with pytest.raises(CodexAuthError, match="missing tokens.access_token"):
            validate_auth_structure(auth)

    def test_missing_refresh_token(self):
        auth = {"tokens": {"access_token": _make_valid_jwt()}}
        with pytest.raises(CodexAuthError, match="missing tokens.refresh_token"):
            validate_auth_structure(auth)


class TestApplyRefreshedTokens:
    """Tests for apply_refreshed_tokens()."""

    def test_applies_new_tokens(self):
        original = _make_auth_dict(_make_expired_jwt())
        refreshed = RefreshedTokens(
            access_token="new_access",
            refresh_token="new_refresh",
            id_token="new_id",
        )

        result = apply_refreshed_tokens(original, refreshed)

        assert result["tokens"]["access_token"] == "new_access"
        assert result["tokens"]["refresh_token"] == "new_refresh"
        assert result["tokens"]["id_token"] == "new_id"
        assert "last_refresh" in result

    def test_does_not_mutate_original(self):
        original = _make_auth_dict(_make_expired_jwt())
        original_access = original["tokens"]["access_token"]
        refreshed = RefreshedTokens(access_token="new_access")

        apply_refreshed_tokens(original, refreshed)

        assert original["tokens"]["access_token"] == original_access

    def test_keeps_old_refresh_if_not_rotated(self):
        original = _make_auth_dict(_make_expired_jwt())
        refreshed = RefreshedTokens(access_token="new_access")

        result = apply_refreshed_tokens(original, refreshed)

        assert result["tokens"]["refresh_token"] == "refresh123"


class TestEnsureFreshTokens:
    """Tests for ensure_fresh_tokens()."""

    def test_returns_unchanged_if_fresh(self):
        auth = _make_auth_dict(_make_valid_jwt(expires_in=3600))

        result, was_refreshed = ensure_fresh_tokens(auth, threshold_seconds=300)

        assert was_refreshed is False
        assert result == auth

    @patch("noauth.providers.codex.refresh_tokens")
    def test_refreshes_if_expiring(self, mock_refresh: MagicMock):
        mock_refresh.return_value = RefreshedTokens(
            access_token="new_access",
            refresh_token="new_refresh",
        )
        auth = _make_auth_dict(_make_valid_jwt(expires_in=60))

        result, was_refreshed = ensure_fresh_tokens(auth, threshold_seconds=300)

        assert was_refreshed is True
        assert result["tokens"]["access_token"] == "new_access"
        mock_refresh.assert_called_once()

    @patch("noauth.providers.codex.refresh_tokens")
    def test_force_refresh(self, mock_refresh: MagicMock):
        mock_refresh.return_value = RefreshedTokens(access_token="forced_access")
        auth = _make_auth_dict(_make_valid_jwt(expires_in=3600))

        result, was_refreshed = ensure_fresh_tokens(auth, force_refresh=True)

        assert was_refreshed is True
        mock_refresh.assert_called_once()

    def test_raises_on_invalid_structure(self):
        invalid_auth = {"not": "valid"}

        with pytest.raises(CodexAuthError):
            ensure_fresh_tokens(invalid_auth)
