"""Tests for Gemini provider token handling."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from noauth.providers import gemini


class TestGetTokenExpiry:
    """Tests for get_token_expiry()."""

    def test_expiry_date_milliseconds(self):
        """Should parse expiry_date in milliseconds."""
        # 1 hour from now in milliseconds
        future_ms = int((time.time() + 3600) * 1000)
        tokens = {"expiry_date": future_ms, "access_token": "a", "refresh_token": "r"}

        result = gemini.get_token_expiry(tokens)

        assert result is not None
        assert isinstance(result, datetime)
        # Should be close to 1 hour from now
        remaining = (result - datetime.now(timezone.utc)).total_seconds()
        assert 3590 < remaining < 3610

    def test_expires_at_seconds(self):
        """Should parse expires_at in seconds as fallback."""
        future_sec = int(time.time() + 3600)
        tokens = {"expires_at": future_sec, "access_token": "a", "refresh_token": "r"}

        result = gemini.get_token_expiry(tokens)

        assert result is not None
        remaining = (result - datetime.now(timezone.utc)).total_seconds()
        assert 3590 < remaining < 3610

    def test_prefers_expiry_date_over_expires_at(self):
        """Should prefer expiry_date (ms) over expires_at (s)."""
        now = time.time()
        tokens = {
            "expiry_date": int((now + 3600) * 1000),  # 1 hour
            "expires_at": int(now + 7200),  # 2 hours
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.get_token_expiry(tokens)

        # Should use expiry_date (1 hour), not expires_at (2 hours)
        remaining = (result - datetime.now(timezone.utc)).total_seconds()
        assert 3590 < remaining < 3610

    def test_no_expiry_info(self):
        """Should return None if no expiry info present."""
        tokens = {"access_token": "a", "refresh_token": "r"}

        result = gemini.get_token_expiry(tokens)

        assert result is None

    def test_invalid_expiry_value(self):
        """Should return None for invalid expiry values."""
        tokens = {
            "expiry_date": "not-a-number",
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.get_token_expiry(tokens)

        assert result is None


class TestIsTokenExpiring:
    """Tests for is_token_expiring()."""

    def test_expiring_soon(self):
        """Should return True if token expires within threshold."""
        # Expires in 2 minutes
        tokens = {
            "expiry_date": int((time.time() + 120) * 1000),
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.is_token_expiring(tokens, threshold_seconds=300)

        assert result is True

    def test_not_expiring(self):
        """Should return False if token has time remaining."""
        # Expires in 1 hour
        tokens = {
            "expiry_date": int((time.time() + 3600) * 1000),
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.is_token_expiring(tokens, threshold_seconds=300)

        assert result is False

    def test_already_expired(self):
        """Should return True if token is already expired."""
        # Expired 10 minutes ago
        tokens = {
            "expiry_date": int((time.time() - 600) * 1000),
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.is_token_expiring(tokens, threshold_seconds=300)

        assert result is True

    def test_no_expiry_info(self):
        """Should return False if no expiry info (unknown)."""
        tokens = {"access_token": "a", "refresh_token": "r"}

        result = gemini.is_token_expiring(tokens, threshold_seconds=300)

        assert result is False

    def test_custom_threshold(self):
        """Should respect custom threshold."""
        # Expires in 10 minutes
        tokens = {
            "expiry_date": int((time.time() + 600) * 1000),
            "access_token": "a",
            "refresh_token": "r",
        }

        # Not expiring with 5-minute threshold
        assert gemini.is_token_expiring(tokens, threshold_seconds=300) is False

        # Expiring with 15-minute threshold
        assert gemini.is_token_expiring(tokens, threshold_seconds=900) is True


class TestIsTokenExpired:
    """Tests for is_token_expired()."""

    def test_expired(self):
        """Should return True if token is expired."""
        tokens = {
            "expiry_date": int((time.time() - 100) * 1000),
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.is_token_expired(tokens)

        assert result is True

    def test_not_expired(self):
        """Should return False if token is still valid."""
        tokens = {
            "expiry_date": int((time.time() + 3600) * 1000),
            "access_token": "a",
            "refresh_token": "r",
        }

        result = gemini.is_token_expired(tokens)

        assert result is False


class TestValidateTokenStructure:
    """Tests for validate_token_structure()."""

    def test_valid_structure(self):
        """Should accept valid token structure."""
        tokens = {
            "access_token": "ya29.test_access",
            "refresh_token": "1//test_refresh",
            "token_type": "Bearer",
            "expiry_date": int(time.time() * 1000),
        }

        # Should not raise
        gemini.validate_token_structure(tokens)

    def test_missing_access_token(self):
        """Should reject tokens without access_token."""
        tokens = {"refresh_token": "1//test_refresh"}

        with pytest.raises(gemini.GeminiAuthError, match="access_token"):
            gemini.validate_token_structure(tokens)

    def test_empty_access_token(self):
        """Should reject empty access_token."""
        tokens = {"access_token": "", "refresh_token": "1//test_refresh"}

        with pytest.raises(gemini.GeminiAuthError, match="access_token"):
            gemini.validate_token_structure(tokens)

    def test_missing_refresh_token(self):
        """Should reject tokens without refresh_token."""
        tokens = {"access_token": "ya29.test_access"}

        with pytest.raises(gemini.GeminiAuthError, match="refresh_token"):
            gemini.validate_token_structure(tokens)

    def test_whitespace_only_access_token(self):
        """Should reject whitespace-only access_token."""
        tokens = {"access_token": "   ", "refresh_token": "1//test_refresh"}

        with pytest.raises(gemini.GeminiAuthError, match="access_token"):
            gemini.validate_token_structure(tokens)


class TestApplyRefreshedTokens:
    """Tests for apply_refreshed_tokens()."""

    def test_applies_new_tokens(self):
        """Should apply refreshed token values."""
        original = {
            "access_token": "old_access",
            "refresh_token": "old_refresh",
            "token_type": "Bearer",
            "expiry_date": 1000,
        }
        refreshed = gemini.RefreshedTokens(
            access_token="new_access",
            expires_in=3600,
            token_type="Bearer",
            refresh_token="new_refresh",
            scope="scope1 scope2",
        )

        result = gemini.apply_refreshed_tokens(original, refreshed)

        assert result["access_token"] == "new_access"
        assert result["refresh_token"] == "new_refresh"
        assert result["token_type"] == "Bearer"
        assert result["scope"] == "scope1 scope2"
        # Expiry should be ~1 hour from now
        assert result["expiry_date"] > int(time.time() * 1000)
        assert result["expires_at"] > int(time.time())
        assert "last_refresh" in result

    def test_does_not_mutate_original(self):
        """Should not modify the original dict."""
        original = {
            "access_token": "old_access",
            "refresh_token": "old_refresh",
            "expiry_date": 1000,
        }
        refreshed = gemini.RefreshedTokens(
            access_token="new_access",
            expires_in=3600,
        )

        gemini.apply_refreshed_tokens(original, refreshed)

        assert original["access_token"] == "old_access"
        assert original["refresh_token"] == "old_refresh"

    def test_keeps_old_refresh_if_not_rotated(self):
        """Should keep old refresh_token if not rotated."""
        original = {
            "access_token": "old_access",
            "refresh_token": "old_refresh",
            "expiry_date": 1000,
        }
        refreshed = gemini.RefreshedTokens(
            access_token="new_access",
            expires_in=3600,
            refresh_token=None,  # Not rotated
        )

        result = gemini.apply_refreshed_tokens(original, refreshed)

        assert result["refresh_token"] == "old_refresh"


class TestEnsureFreshTokens:
    """Tests for ensure_fresh_tokens()."""

    def test_returns_unchanged_if_fresh(self):
        """Should return original tokens if not expiring."""
        tokens = {
            "access_token": "valid_access",
            "refresh_token": "valid_refresh",
            "expiry_date": int((time.time() + 3600) * 1000),  # 1 hour from now
        }

        result, refreshed = gemini.ensure_fresh_tokens(tokens, threshold_seconds=300)

        assert refreshed is False
        assert result["access_token"] == "valid_access"

    @patch("noauth.providers.gemini.refresh_tokens")
    def test_refreshes_if_expiring(self, mock_refresh: MagicMock):
        """Should refresh tokens if expiring soon."""
        mock_refresh.return_value = gemini.RefreshedTokens(
            access_token="new_access",
            expires_in=3600,
            refresh_token="new_refresh",
        )

        tokens = {
            "access_token": "expiring_access",
            "refresh_token": "valid_refresh",
            "expiry_date": int((time.time() + 60) * 1000),  # 1 minute from now
        }

        result, refreshed = gemini.ensure_fresh_tokens(tokens, threshold_seconds=300)

        assert refreshed is True
        assert result["access_token"] == "new_access"
        mock_refresh.assert_called_once()

    @patch("noauth.providers.gemini.refresh_tokens")
    def test_force_refresh(self, mock_refresh: MagicMock):
        """Should refresh when force_refresh=True even if not expiring."""
        mock_refresh.return_value = gemini.RefreshedTokens(
            access_token="forced_new_access",
            expires_in=3600,
        )

        tokens = {
            "access_token": "valid_access",
            "refresh_token": "valid_refresh",
            "expiry_date": int((time.time() + 3600) * 1000),  # Not expiring
        }

        result, refreshed = gemini.ensure_fresh_tokens(tokens, force_refresh=True)

        assert refreshed is True
        assert result["access_token"] == "forced_new_access"
        mock_refresh.assert_called_once()

    def test_raises_on_invalid_structure(self):
        """Should raise GeminiAuthError for invalid token structure."""
        tokens = {"access_token": "valid"}  # Missing refresh_token

        with pytest.raises(gemini.GeminiAuthError):
            gemini.ensure_fresh_tokens(tokens)


class TestRefreshTokens:
    """Tests for refresh_tokens()."""

    def test_raises_on_empty_refresh_token(self):
        """Should raise error for empty refresh token."""
        with pytest.raises(gemini.GeminiAuthError, match="refresh_token is empty"):
            gemini.refresh_tokens("")

    def test_raises_on_whitespace_refresh_token(self):
        """Should raise error for whitespace-only refresh token."""
        with pytest.raises(gemini.GeminiAuthError, match="refresh_token is empty"):
            gemini.refresh_tokens("   ")

    def test_uses_default_client_credentials(self):
        """Should use default Gemini CLI client credentials."""
        # Verify the constants are defined
        assert gemini.DEFAULT_CLIENT_ID
        assert "apps.googleusercontent.com" in gemini.DEFAULT_CLIENT_ID
        assert gemini.DEFAULT_CLIENT_SECRET
        assert gemini.DEFAULT_TOKEN_ENDPOINT == "https://oauth2.googleapis.com/token"


class TestErrorCodeMessages:
    """Tests for error code handling."""

    def test_invalid_grant_message(self):
        """Should provide helpful message for invalid_grant."""
        msg = gemini._error_code_to_message("invalid_grant")
        assert "re-authenticate" in msg.lower()

    def test_invalid_client_message(self):
        """Should provide helpful message for invalid_client."""
        msg = gemini._error_code_to_message("invalid_client")
        assert "client" in msg.lower()

    def test_unknown_code_message(self):
        """Should include the code in the message."""
        msg = gemini._error_code_to_message("some_unknown_error")
        assert "some_unknown_error" in msg

    def test_none_code_message(self):
        """Should provide generic message for None code."""
        msg = gemini._error_code_to_message(None)
        assert "re-authenticate" in msg.lower()
