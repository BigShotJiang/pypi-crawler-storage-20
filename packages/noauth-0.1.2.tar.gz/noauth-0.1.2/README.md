# noauth

Centralized OAuth token service on Modal with encrypted storage and automatic refresh.

## SDK install (GitHub)

Use this when you only want the client library (no Modal server deps). This install does not pull Modal.

```bash
uv pip install "git+https://github.com/thehumanworks/noauth.git"
```

Minimal usage:

```python
from noauth.sdk import NoAuthClient

# Credentials can be provided via:
# 1. Explicit parameters (shown below)
# 2. Environment variables (NOAUTH_CLIENT_ID, NOAUTH_CLIENT_SECRET)
# 3. ~/.modal.toml file

client = NoAuthClient(
    base_url="https://<your-app>.modal.run",
    token_id="wk-...",
    token_secret="ws-...",
)
print(client.health().message)
```

## Server install (Modal app)

Use this when you want to deploy the service:

```bash
uv pip install "git+https://github.com/thehumanworks/noauth.git#egg=noauth[server]"
```

Deploy:

```bash
uv run modal deploy -m noauth.app
```

Notes:
- All endpoints require Modal Proxy Auth. Use a Proxy Auth token (`wk-...`/`ws-...`).
- API/CLI tokens (`ak-`/`as-`) are not valid for proxy auth.
