### dropbucket
Robust SNP-based demultiplexing tool designed to accurately assign cells to donors in pooled scRNA-seq datasets, even under extremely unbalanced pooling condition and samples with genetically similar genotypes.

### Usage
```bash
   python dropbucket_pipeline.py \
     --mtx_path dir/mtx_path \
     --cellbarcode_path dir/barcodes.tsv \
     --k 8 \
     --output_dir results
```

### Requirements (Python)

- Python >= 3.9
- numpy
- pandas
- scipy
- scikit-learn

### Requirements (External tools)

- freebayes
- vartrix
