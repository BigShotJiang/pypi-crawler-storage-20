from setuptools import setup, Extension
import os
import sys

from setuptools import setup, Extension, find_packages
from setuptools.command.build_ext import build_ext


# from Cython.Build import cythonize


def main():

    # 创建扩展模块，简化配置
    extensions = [
        Extension(
            "torch.extensions.extension",  # 模块名称与初始化函数匹配
            sources=["torch/extensions/extension.c"],
            # extra_compile_args=["-g", "-O2"],
            language="c",  # 使用C编译
        ),
        # Extension(
        #     "torch.extensions.extension",  # 模块名称与初始化函数匹配
        #     sources=["torch/extensions/extension.pyx"],
        #     py_limited_api=True,  # 关键：启用 Python 稳定 ABI（abi3）
        #     define_macros=[("Py_LIMITED_API", "0x03080000")],  # 3.8 及以上兼容
        #     extra_compile_args=(
        #         ["-O3"] if sys.platform != "win32" else ["/O2"]
        #     ),  # 优化编译
        #     language="c",  # 使用C编译
        # ),
    ]

    setup(
        name="torch-extensions",
        version="0.0.6",
        description="pytorch通用模型导出",
        author="zhumingwu",
        author_email="zhumingwu@126.com",
        packages=["torch.extensions"],
        ext_modules=extensions,
        install_requires=[
            "torch>=2.8.0",
            "numpy>=1.20",
        ],
        python_requires=">=3.8",
        # Windows 下避免路径问题
        zip_safe=False,
    )


if __name__ == "__main__":
    main()
