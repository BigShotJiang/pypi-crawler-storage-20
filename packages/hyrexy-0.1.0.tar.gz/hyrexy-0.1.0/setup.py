from setuptools import setup

setup(
    name='HyRexy',
    version='0.1.0',    
    description='A fast, differentiable, and extensible recombination code',
    url='https://github.com/TonyZhou729/HyRex',
    author='Zilu Zhou, Cara Giovanetti, Hongwan Liu',
    author_email='cgiovanetti@lbl.gov',
    license='MIT',
    packages=['hyrex'],
    install_requires=['numpy',
                        'scipy',
                        'matplotlib',
                        'jax',
                        'jaxlib',
                        'diffrax',
                        'equinox'
                      ],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'Operating System :: POSIX :: Linux',        
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
        'Programming Language :: Python :: 3.14'
    ],
)