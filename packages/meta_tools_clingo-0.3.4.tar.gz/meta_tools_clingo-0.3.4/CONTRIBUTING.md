# Contributing

Thanks for considering a contribution to meta_tools. ❤️

## How to get help or discuss possible contributions

To avoid duplicating issues, please search our [issue tracker][issues] and our
[mailing list][mailing_list] before filing a new issue.

- Open an [issue][new_issue] describing your problem.
- [Subscribe] to our mailing list on SourceForge.

## How to make a contribution

- Fork the [meta_tools][project_url] repository and create a branch for your
  changes.
- Submit a pull request to the master branch with your changes.
- Respond to feedback on your pull request.
- If everything is fine your pull request is merged. 🥳

## License

When contributing to this project, you agree that you have authored 100% of the
content, that you have the necessary rights to the content and that the content
you contribute may be provided under the project license.

[issues]: https://github.com/krr-up/meta-tools.git/issues/
[mailing_list]: https://sourceforge.net/p/potassco/mailman/potassco-users/
[new_issue]: https://github.com/krr-up/meta-tools.git/issues/new/
[project_url]: https://github.com/krr-up/meta-tools.git/
[subscribe]: https://sourceforge.net/projects/potassco/lists/potassco-users/
