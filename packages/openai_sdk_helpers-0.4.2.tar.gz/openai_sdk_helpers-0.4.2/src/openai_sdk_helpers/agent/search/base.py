"""Generic base classes for search agent workflows.

This module provides abstract base classes that extract common patterns from
web search and vector search implementations, eliminating code duplication
and providing a consistent interface for new search types.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Generic, List, Optional, TypeVar, Union

from ..base import AgentBase
from ..config import AgentConfiguration
from ...structure.base import StructureBase

# Type variables for search workflow components
ItemType = TypeVar(
    "ItemType", bound=StructureBase
)  # Search item structure (e.g., WebSearchItemStructure)
ResultType = TypeVar("ResultType")  # Individual search result
PlanType = TypeVar("PlanType", bound=StructureBase)  # Complete search plan structure
ReportType = TypeVar("ReportType", bound=StructureBase)  # Final report structure


class SearchPlanner(AgentBase, Generic[PlanType]):
    """Generic planner agent for search workflows.

    Subclasses implement specific planner logic by overriding the
    `_configure_agent` method and specifying the output type.

    Parameters
    ----------
    prompt_dir : Path, optional
        Directory containing prompt templates.
    default_model : str, optional
        Default model identifier to use when not defined in config.

    Methods
    -------
    run_agent(query)
        Generate a search plan for the provided query.
    _configure_agent()
        Return AgentConfiguration for this planner instance.

    Raises
    ------
    ValueError
        If the default model is not provided.

    Examples
    --------
    >>> class MyPlanner(SearchPlanner):
    ...     def _configure_agent(self):
    ...         return AgentConfiguration(
    ...             name="my_planner",
    ...             description="Plans searches",
    ...             output_structure=WebSearchPlanStructure,
    ...         )
    >>> planner = MyPlanner(default_model="gpt-4o-mini")
    """

    def __init__(
        self,
        prompt_dir: Optional[Path] = None,
        default_model: Optional[str] = None,
    ) -> None:
        """Initialize the planner agent."""
        config = self._configure_agent()
        super().__init__(
            config=config,
            prompt_dir=prompt_dir,
            default_model=default_model,
        )

    @abstractmethod
    def _configure_agent(self) -> AgentConfiguration:
        """Return configuration for this planner.

        Returns
        -------
        AgentConfiguration
            Configuration with name, description, and output_structure set.

        Examples
        --------
        >>> config = AgentConfiguration(
        ...     name="web_planner",
        ...     description="Plan web searches",
        ...     output_structure=WebSearchPlanStructure,
        ... )
        >>> return config
        """
        pass

    async def run_agent(self, query: str) -> PlanType:
        """Generate a search plan for the query.

        Parameters
        ----------
        query : str
            User search query.

        Returns
        -------
        PlanType
            Generated search plan of the configured output type.
        """
        result: PlanType = await self.run_async(
            input=query,
            output_structure=self._output_structure,
        )
        return result


class SearchToolAgent(AgentBase, Generic[ItemType, ResultType, PlanType]):
    """Generic tool agent for executing search workflows.

    Executes individual searches in a plan with concurrency control.
    Subclasses implement search execution logic by overriding the
    `_configure_agent` and `run_search` methods.

    Parameters
    ----------
    prompt_dir : Path, optional
        Directory containing prompt templates.
    default_model : str, optional
        Default model identifier to use when not defined in config.
    max_concurrent_searches : int, default=10
        Maximum number of concurrent search operations.

    Methods
    -------
    run_agent(search_plan)
        Execute all searches in the plan.
    run_search(item)
        Execute a single search item.
    _configure_agent()
        Return AgentConfiguration for this tool agent.

    Raises
    ------
    ValueError
        If the default model is not provided.

    Examples
    --------
    >>> class MyTool(SearchToolAgent):
    ...     def _configure_agent(self):
    ...         return AgentConfiguration(
    ...             name="my_tool",
    ...             description="Executes searches",
    ...             input_structure=WebSearchPlanStructure,
    ...         )
    ...     async def run_search(self, item):
    ...         return "result"
    >>> tool = MyTool(default_model="gpt-4o-mini")
    """

    def __init__(
        self,
        *,
        prompt_dir: Optional[Path] = None,
        default_model: Optional[str] = None,
        max_concurrent_searches: int = 10,
    ) -> None:
        """Initialize the search tool agent."""
        self._max_concurrent_searches = max_concurrent_searches
        config = self._configure_agent()
        super().__init__(
            config=config,
            prompt_dir=prompt_dir,
            default_model=default_model,
        )

    @abstractmethod
    def _configure_agent(self) -> AgentConfiguration:
        """Return configuration for this tool agent.

        Returns
        -------
        AgentConfiguration
            Configuration with name, description, input_structure, and tools set.

        Examples
        --------
        >>> config = AgentConfiguration(
        ...     name="web_search",
        ...     description="Perform web searches",
        ...     input_structure=WebSearchPlanStructure,
        ...     tools=[WebSearchTool()],
        ... )
        >>> return config
        """
        pass

    @abstractmethod
    async def run_search(self, item: ItemType) -> ResultType:
        """Execute a single search item.

        Parameters
        ----------
        item : ItemType
            Individual search item from the plan.

        Returns
        -------
        ResultType
            Result of executing the search item.
        """
        pass

    async def run_agent(self, search_plan: PlanType) -> List[ResultType]:
        """Execute all searches in the plan with concurrency control.

        Parameters
        ----------
        search_plan : PlanType
            Plan structure containing search items.

        Returns
        -------
        list[ResultType]
            Completed search results from executing the plan.
        """
        semaphore = asyncio.Semaphore(self._max_concurrent_searches)

        async def _bounded_search(item: ItemType) -> Optional[ResultType]:
            """Execute search within concurrency limit."""
            async with semaphore:
                return await self.run_search(item)

        items = getattr(search_plan, "searches", [])
        tasks = [asyncio.create_task(_bounded_search(item)) for item in items]
        results = await asyncio.gather(*tasks)

        return [result for result in results if result is not None]


class SearchWriter(AgentBase, Generic[ReportType]):
    """Generic writer agent for search workflow reports.

    Synthesizes search results into a final report. Subclasses implement
    specific report generation logic by overriding the `_configure_agent` method.

    Parameters
    ----------
    prompt_dir : Path, optional
        Directory containing prompt templates.
    default_model : str, optional
        Default model identifier to use when not defined in config.

    Methods
    -------
    run_agent(query, search_results)
        Generate a report from search results.
    _configure_agent()
        Return AgentConfiguration for this writer instance.

    Raises
    ------
    ValueError
        If the default model is not provided.

    Examples
    --------
    >>> class MyWriter(SearchWriter):
    ...     def _configure_agent(self):
    ...         return AgentConfiguration(
    ...             name="my_writer",
    ...             description="Writes reports",
    ...             output_structure=WebSearchReportStructure,
    ...         )
    >>> writer = MyWriter(default_model="gpt-4o-mini")
    """

    def __init__(
        self,
        prompt_dir: Optional[Path] = None,
        default_model: Optional[str] = None,
    ) -> None:
        """Initialize the writer agent."""
        config = self._configure_agent()
        super().__init__(
            config=config,
            prompt_dir=prompt_dir,
            default_model=default_model,
        )

    @abstractmethod
    def _configure_agent(self) -> AgentConfiguration:
        """Return configuration for this writer.

        Returns
        -------
        AgentConfiguration
            Configuration with name, description, and output_structure set.

        Examples
        --------
        >>> config = AgentConfiguration(
        ...     name="web_writer",
        ...     description="Write web search report",
        ...     output_structure=WebSearchReportStructure,
        ... )
        >>> return config
        """
        pass

    async def run_agent(
        self,
        query: str,
        search_results: List[ResultType],
    ) -> ReportType:
        """Generate a report from search results.

        Parameters
        ----------
        query : str
            Original search query.
        search_results : list[ResultType]
            Results from the search execution phase.

        Returns
        -------
        ReportType
            Final report structure of the configured output type.
        """
        template_context = {
            "original_query": query,
            "search_results": search_results,
        }
        result: ReportType = await self.run_async(
            input=query,
            context=template_context,
            output_structure=self._output_structure,
        )
        return result


__all__ = [
    "SearchPlanner",
    "SearchToolAgent",
    "SearchWriter",
]
