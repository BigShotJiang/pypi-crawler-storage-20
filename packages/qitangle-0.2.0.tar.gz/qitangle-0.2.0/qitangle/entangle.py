# This file is generated - do not edit
"""Entangle - entangles code from ipython notebook cells to python .py files"""

import typing
import sys
import os
import argparse
import autopep8
import subprocess

from IPython.core.magic import Magics, magics_class, cell_magic
from qitangle.cantrips import extract_filepath

def split_line_args(line_args):

    if isinstance(line_args, str):
        args = line_args.split(' ')
    else:
        args = line_args.copy()

    return filter(lambda x: bool(x), args)

def create_writer_arg_parser():

    parser = argparse.ArgumentParser(
        prog='entangle file writer',
        description='Cantrips - set export to a file specifed by libfolder and a python module-path',
        exit_on_error=False,
        add_help=True
    )

    parser.add_argument(
        '-f', '--fix', help='Fix/reformat with Black', action='store_true')
    parser.add_argument('libfolder', nargs='?',
                        help='the root folder for the code', default='')
    parser.add_argument('modulepath',  help='the module path')

    return parser

def create_writer(line_args, docstring):

    parser = create_writer_arg_parser()

    parsed_args = parser.parse_args(list(split_line_args(line_args)))
    filepath = extract_filepath(parsed_args.libfolder, parsed_args.modulepath)

    print(f"Output will be written to {filepath}")

    pre_amble = [
        f'"""\n{"\n\t".join(docstring.split('\n'))}\n"""\n'
    ]

    def write_cells(code_cells: typing.Iterator, fix=False):
        print(f"Writing {code_cells} to {filepath}")

        with open(filepath, 'w') as f:
            f.writelines(pre_amble)
            for cell in code_cells:
                f.write(cell)

        if parsed_args.fix or fix:
            print(f"Reformatting {filepath} with Black")
            rr = subprocess.run([
                str(sys.executable), '-m',
                'black', filepath
            ],
                cwd=os.path.dirname(filepath),
                check=True, capture_output=True
            )
            print(rr.stdout.decode('utf-8'))
            print(rr.stderr.decode('utf-8'))

    return write_cells

class CodeCell(typing.NamedTuple):
    """Passive object with code, label and dependencies attributes"""

    code: str
    label: str
    dependencies: list

def entangle_cells(cells: dict[str, CodeCell]):
    """
    Entangles a collection of code cells

    params:
        cells: dict[str, CodeCell] a collection of code cells

    returns:
        typing.Iterator[CodeCell]
    """

    collection = cells.copy()

    def _entangle_cell(current_label):
        current_cell = collection.pop(current_label)

        for dependency in current_cell.dependencies:
            if dependency in collection:
                yield from _entangle_cell(dependency)

        yield current_cell

    while collection:
        yield from _entangle_cell(next(iter(collection)))

def create_entangler_parser():
    parser = argparse.ArgumentParser(
        'Entangler', exit_on_error=False, add_help=True)
    parser.add_argument(
        '-e', '--export',  help='entangle (write) all cells in the collection', action='store_true')
    parser.add_argument(
        '-f', '--fix', help='Fix/reFormat code', action='store_true')
    parser.add_argument('label', nargs='?', help='the label for the code cell')
    parser.add_argument('dependencies', nargs='*',
                        help='the dependencies for the code cell')

    return parser

def create_entangler(line_args, cell):

    parser = create_entangler_parser()
    write_cells = create_writer(line_args, str(cell))
    cell_collection = {}

    def entangle(line_args, cell):
        args = parser.parse_args(list(split_line_args(line_args)))

        if args.label:
            if args.fix:
                cell_collection[args.label] = CodeCell(
                    autopep8.fix_code(cell), args.label, args.dependencies)
            else:
                cell_collection[args.label] = CodeCell(
                    cell, args.label, args.dependencies)

        if args.export:
            write_cells((c.code for c in entangle_cells(
                cell_collection)), fix=args.fix)

    return entangle

@magics_class
class EntangleMagic(Magics):

    @cell_magic
    def entanglefile(self, line, cell):
        """Creates the entangler from the file specification provided"""
        self.entangler = create_entangler(line, cell)

    @cell_magic
    def entangle(self, line, cell):
        "Entangles a code cell"
        self.shell.run_cell(cell)
        self.entangler(line, cell)

def load_ipython_extension(ipython):
    ipython.register_magics(EntangleMagic)
