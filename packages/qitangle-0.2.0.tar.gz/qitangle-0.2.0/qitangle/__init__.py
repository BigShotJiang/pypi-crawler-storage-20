"""QiTangle - IPython magic to tangle (quarto) specified code cells into python source files"""
__version__ = "0.2.0"

from .entangle import load_ipython_extension