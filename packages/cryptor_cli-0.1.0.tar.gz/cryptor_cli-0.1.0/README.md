# Cryptor CLI Tool

`cryptor-cli` is a secure command-line interface (CLI) tool for encrypting and decrypting files using robust cryptographic primitives. It employs **envelope encryption** with **AES-256-GCM** for data, and a password-derived **Argon2id** key for master key protection, ensuring high levels of confidentiality, integrity, and authenticity.

## Features

*   **Strong Encryption**: Utilizes AES-256-GCM for authenticated encryption.
*   **Secure Key Derivation**: Employs Argon2id (the current industry standard) to derive cryptographic keys from your password, protecting against brute-force attacks.
*   **Envelope Encryption**: Each file is encrypted with a unique Data Encryption Key (DEK), which is then encrypted by a Master Key (KEK). This isolates the risk: compromise of one DEK does not affect other files.
*   **Key Wrapping**: Uses AES Key Wrap for secure management of encryption keys.
*   **Data Integrity**: Guarantees that any tampering with encrypted files will be detected during decryption.
*   **Simple CLI**: Easy-to-use commands for key management, encryption, and decryption.

## Installation

1.  **Clone the repository** (if you haven't already):
    ```bash
    # Assuming you are in the parent directory of your project
    git clone https://github.com/yourusername/cryptor-cli.git # Replace with your repo URL
    cd cryptor-cli
    ```

2.  **Create and activate a Python virtual environment**:
    It's highly recommended to use a virtual environment to manage dependencies:
    ```bash
    python3 -m venv venv
    source venv/bin/activate
    ```

3.  **Install the package**:
    Navigate to the directory containing `setup.py` and install in editable mode:
    ```bash
    pip install .
    ```

## Usage

Once installed, the `cryptor` command will be available in your activated virtual environment.

### 1. Generate a Master Key

Before you can encrypt or decrypt any files, you need to generate a master key. This key will be encrypted by a password you provide and stored in `master.key`.

```bash
cryptor manage-keys generate
```
You will be prompted to enter and confirm a strong password.

### 2. Encrypt a File

To encrypt a file, specify the input (plaintext) file and the desired output (encrypted) file.

```bash
cryptor encrypt my_secret_document.txt my_secret_document.crpt
```
You will be prompted for your master key password.

### 3. Decrypt a File

To decrypt an encrypted file, specify the input (encrypted) file and the desired output (plaintext) file.

```bash
cryptor decrypt my_secret_document.crpt my_secret_document_decrypted.txt
```
You will be prompted for your master key password. The decrypted content will be written to `my_secret_document_decrypted.txt`.

### 4. Change Master Key Password

If you need to change the password protecting your master key:

```bash
cryptor manage-keys change-password
```
You will be prompted for your current password, and then for your new password (twice for confirmation).

## Security Notes

*   **Strong Passwords are Crucial**: The security of your encrypted files ultimately depends on the strength of your master key password. Use a long, complex, and unique password.
*   **Protect `master.key`**: The `master.key` file contains your encrypted master key. While it's protected by your password, it should be treated as highly sensitive. Back it up securely, and ensure it's not accidentally deleted or exposed.
*   **Nonce Reuse (Prevented)**: This tool uses a unique, randomly generated nonce for every encryption operation, which is critical for the security of AES-GCM. Never manually encrypt data with a reused nonce and the same key.
*   **No Tampering (Detected)**: Due to the use of Authenticated Encryption (AES-GCM), any attempt to tamper with the encrypted data will result in a decryption failure (an `InvalidTag` error), protecting you from malicious modifications.
*   **Key Storage**: The master key is stored on your local filesystem, encrypted by your password. For scenarios requiring extreme security or multi-user access, consider integrating with Hardware Security Modules (HSMs) or cloud Key Management Services (KMS).

## Contributing

Contributions are welcome! Please feel free to open issues or submit pull requests.

## License

This project is licensed under the MIT License. See the `LICENSE` file for details.
