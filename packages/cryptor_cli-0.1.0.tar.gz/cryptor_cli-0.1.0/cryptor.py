# cryptor.py
import os
import click
import sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id
from cryptography.hazmat.primitives.keywrap import aes_key_wrap, aes_key_unwrap
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidTag, InvalidKey

# --- Constants ---
MKEK_SALT_SIZE = 16
ARGON2_ITERATIONS = 3
ARGON2_MEMORY_COST = 65536
ARGON2_LANES = 4
MKEK_SIZE = 32
MASTER_KEY_SIZE = 32
DEK_SIZE = 32
GCM_NONCE_SIZE = 12
GCM_TAG_SIZE = 16
MASTER_KEY_FILE = 'master.key'

# --- Helper Functions ---

def derive_key_from_password(password: bytes, salt: bytes) -> bytes:
    """Derives a key from a password and salt using Argon2id."""
    kdf = Argon2id(
        salt=salt,
        length=MKEK_SIZE,
        iterations=ARGON2_ITERATIONS,
        lanes=ARGON2_LANES,
        memory_cost=ARGON2_MEMORY_COST
    )
    key = kdf.derive(password)
    return key

def load_master_key(password: str) -> bytes:
    """Loads, decrypts, and returns the master key from the master.key file."""
    try:
        with open(MASTER_KEY_FILE, 'rb') as f:
            salt = f.read(MKEK_SALT_SIZE)
            wrapped_master_key = f.read()

        mKEK = derive_key_from_password(password.encode(), salt)
        master_key = aes_key_unwrap(mKEK, wrapped_master_key)
        return master_key
    except FileNotFoundError:
        raise click.ClickException(f"Master key file '{MASTER_KEY_FILE}' not found. Please generate it first using 'manage-keys generate'.")
    except InvalidKey:
        raise click.ClickException("Invalid password or corrupted master key file.")
    except Exception as e:
        raise click.ClickException(f"An error occurred while loading the master key: {e}")

# --- Click CLI Group Setup ---
@click.group()
def cli():
    """A CLI tool for secure file encryption using AES-256-GCM and Argon2."""
    pass

# --- Key Management Commands ---
@cli.group('manage-keys')
def manage_keys():
    """Commands for managing the master key."""
    pass

@manage_keys.command('generate')
def generate_master_key():
    """Generates a new master key and encrypts it with your password."""
    if os.path.exists(MASTER_KEY_FILE):
        click.confirm(f"⚠️  '{MASTER_KEY_FILE}' already exists. Overwrite it?", abort=True)

    password = click.prompt("Enter a new password for the master key", hide_input=True, confirmation_prompt=True)
    
    master_key = os.urandom(MASTER_KEY_SIZE)
    salt = os.urandom(MKEK_SALT_SIZE)
    mKEK = derive_key_from_password(password.encode(), salt)
    wrapped_master_key = aes_key_wrap(mKEK, master_key)
    
    with open(MASTER_KEY_FILE, 'wb') as f:
        f.write(salt)
        f.write(wrapped_master_key)
        
    click.secho(f"✅ Master key generated and saved to '{MASTER_KEY_FILE}'.", fg='green')

@manage_keys.command('change-password')
def change_master_key_password():
    """Changes the password for an existing master key."""
    if not os.path.exists(MASTER_KEY_FILE):
        raise click.ClickException(f"Master key file '{MASTER_KEY_FILE}' not found. Cannot change password.")

    old_password = click.prompt("Enter your current password", hide_input=True)
    
    try:
        master_key = load_master_key(old_password)
        
        new_password = click.prompt("Enter your new password", hide_input=True, confirmation_prompt=True)
        
        new_salt = os.urandom(MKEK_SALT_SIZE)
        new_mKEK = derive_key_from_password(new_password.encode(), new_salt)
        new_wrapped_master_key = aes_key_wrap(new_mKEK, master_key)
        
        with open(MASTER_KEY_FILE, 'wb') as f:
            f.write(new_salt)
            f.write(new_wrapped_master_key)
            
        click.secho("✅ Master key password changed successfully.", fg='green')
        
    except click.ClickException as e:
        click.secho(f"❌ Error: {e}", fg='red', err=True)

@cli.command('encrypt')
@click.argument('input_file', type=click.Path(exists=True, dir_okay=False))
@click.argument('output_file', type=click.Path(dir_okay=False))
def encrypt(input_file, output_file):
    """Encrypts a file using envelope encryption."""
    password = click.prompt("Enter your master key password", hide_input=True)
    
    try:
        master_key = load_master_key(password)
        dek = os.urandom(DEK_SIZE)
        wrapped_dek = aes_key_wrap(master_key, dek)
        
        with open(input_file, 'rb') as f:
            plaintext = f.read()
        
        aesgcm = AESGCM(dek)
        gcm_nonce = os.urandom(GCM_NONCE_SIZE)
        ciphertext = aesgcm.encrypt(gcm_nonce, plaintext, None)
        gcm_tag = ciphertext[-GCM_TAG_SIZE:]
        encrypted_data = ciphertext[:-GCM_TAG_SIZE]
        
        with open(output_file, 'wb') as f:
            f.write(gcm_nonce)
            f.write(wrapped_dek)
            f.write(gcm_tag)
            f.write(encrypted_data)
            
        click.secho(f"✅ File '{input_file}' encrypted successfully to '{output_file}'.", fg='green')
        
    except click.ClickException as e:
        click.secho(f"❌ Error: {e}", fg='red', err=True)
    except Exception as e:
        click.secho(f"❌ An unexpected error occurred during encryption: {e}", fg='red', err=True)

@cli.command('decrypt')
@click.argument('input_file', type=click.Path(exists=True, dir_okay=False))
@click.argument('output_file', type=click.Path(dir_okay=False))
def decrypt(input_file, output_file):
    """Decrypts a file."""
    password = click.prompt("Enter your master key password", hide_input=True)
    
    try:
        master_key = load_master_key(password)
        
        with open(input_file, 'rb') as f:
            gcm_nonce = f.read(GCM_NONCE_SIZE)
            wrapped_dek_size = DEK_SIZE + 8
            wrapped_dek = f.read(wrapped_dek_size)
            gcm_tag = f.read(GCM_TAG_SIZE)
            ciphertext = f.read()
            
        dek = aes_key_unwrap(master_key, wrapped_dek)
        
        aesgcm = AESGCM(dek)
        ciphertext_with_tag = ciphertext + gcm_tag
        plaintext = aesgcm.decrypt(gcm_nonce, ciphertext_with_tag, None)
        
        with open(output_file, 'wb') as f:
            f.write(plaintext)
            
        click.secho(f"✅ File '{input_file}' decrypted successfully to '{output_file}'.", fg='green')
        
    except (click.ClickException, InvalidTag, InvalidKey) as e:
        click.secho(f"❌ Decryption failed. Check your password or file integrity. Error: {e}", fg='red', err=True)
    except Exception as e:
        click.secho(f"❌ An unexpected error occurred during decryption: {e}", fg='red', err=True)

if __name__ == '__main__':
    cli()