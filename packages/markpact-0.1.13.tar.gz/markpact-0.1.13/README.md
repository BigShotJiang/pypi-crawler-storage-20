# Task Manager API

## Uruchomienie

```bash
markpact README.md
```

---

```markpact:deps python
fastapi
pydantic
uvicorn
```

```markpact:file python path=app.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class Task(BaseModel):
    id: int
    title: str
    description: str = ""
    done: bool = False
    created_at: str = ""

class TaskCreate(BaseModel):
    title: str
    description: str = ""

app = FastAPI(title="Task Manager API")

tasks: dict[int, Task] = {}
next_id = 1

@app.get("/")
def root():
    return {"service": "Task Manager", "version": "1.0"}

@app.get("/tasks")
def list_tasks():
    return list(tasks.values())

@app.get("/tasks/{task_id}")
def get_task(task_id: int):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    return tasks[task_id]

@app.post("/tasks")
def create_task(task_data: TaskCreate):
    global next_id
    task = Task(
        id=next_id,
        title=task_data.title,
        description=task_data.description,
        created_at=datetime.now().isoformat()
    )
    tasks[next_id] = task
    next_id += 1
    return task

@app.patch("/tasks/{task_id}/done")
def mark_done(task_id: int):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    tasks[task_id].done = True
    return tasks[task_id]

@app.delete("/tasks/{task_id}")
def delete_task(task_id: int):
    if task_id not in tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    deleted = tasks.pop(task_id)
    return {"deleted": deleted}

@app.get("/health")
def health():
    return {"status": "healthy", "tasks_count": len(tasks)}
```

```markpact:run python
uvicorn app:app --host 0.0.0.0 --port ${MARKPACT_PORT:-8000}
```
