from __future__ import annotations

import argparse
import asyncio
import time
import traceback
from pathlib import Path
from typing import Any, Optional

from aiel_sdk import SDK_VERSION

from ._version import RUNTIME_VERSION
from .describe import describe as describe_fn
from .invoke import invoke as invoke_fn, InvokeTimeout
from .loader import load_snapshot
from .protocol import RunnerRequest, RunnerResponse, ErrorInfo, ResponseMeta, Context, InvokeMeta
from .security import ImportPolicy


def _read_stdin_json() -> str:
    import sys
    data = sys.stdin.read()
    if not data.strip():
        raise ValueError("Empty input. Expected JSON on stdin.")
    return data


def _mk_policy(meta: Optional[InvokeMeta]) -> ImportPolicy:
    caps = (meta.capabilities if meta else None)
    return ImportPolicy(
        allow_network=bool(caps.network) if caps else False,
        allow_subprocess=bool(caps.subprocess) if caps else False,
        allow_ctypes=bool(caps.ctypes) if caps else False,
        allow_signal=bool(caps.signal) if caps else False,
        allow_resource=bool(caps.resource) if caps else False,
    )


def _error_response(
    *,
    request_id: str,
    trace_id: Optional[str],
    start_ms: int,
    cold_start: bool,
    snapshot_id: Optional[str],
    code: str,
    message: str,
    details: Optional[dict] = None,
    logs: Optional[list] = None,
) -> RunnerResponse:
    duration = int(time.time() * 1000) - start_ms
    return RunnerResponse(
        ok=False,
        result=None,
        error=ErrorInfo(code=code, message=message, details=details),
        meta=ResponseMeta(
            request_id=request_id,
            trace_id=trace_id,
            duration_ms=duration,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            sdk_version=SDK_VERSION,
            runtime_version=RUNTIME_VERSION,
            logs=logs or [],
        ),
    )


def _ok_response(
    *,
    request_id: str,
    trace_id: Optional[str],
    start_ms: int,
    cold_start: bool,
    snapshot_id: Optional[str],
    result: Any,
    logs: list,
) -> RunnerResponse:
    duration = int(time.time() * 1000) - start_ms
    return RunnerResponse(
        ok=True,
        result=result,
        error=None,
        meta=ResponseMeta(
            request_id=request_id,
            trace_id=trace_id,
            duration_ms=duration,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            sdk_version=SDK_VERSION,
            runtime_version=RUNTIME_VERSION,
            logs=logs,
        ),
    )


async def main_async() -> int:
    ap = argparse.ArgumentParser(prog="aiel_runtime.runner")
    ap.add_argument("--files-root", required=True, help="Path to user snapshot root (contains entry_point.py)")
    ap.add_argument("--no-traceback", action="store_true", help="Do not include traceback in errors")
    ap.add_argument("--keep-warm", action="store_true", help="Keep snapshot loaded (less safe; not recommended)")
    args = ap.parse_args()

    start_ms = int(time.time() * 1000)

    # Parse request
    try:
        req = RunnerRequest.model_validate_json(_read_stdin_json())
    except Exception as e:
        resp = _error_response(
            request_id="unknown",
            trace_id=None,
            start_ms=start_ms,
            cold_start=True,
            snapshot_id=None,
            code="BAD_REQUEST",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
        )
        print(resp.model_dump_json())
        return 2

    meta = req.meta or InvokeMeta()
    request_id = meta.request_id
    trace_id = meta.trace_id

    files_root = Path(args.files_root)

    # Load snapshot first (describe and invoke depend on registry)
    snapshot_id = None
    cold_start = True
    try:
        policy = _mk_policy(meta)
        snap = load_snapshot(files_root, policy=policy, keep_warm=args.keep_warm)
        snapshot_id = snap.snapshot_id
        cold_start = snap.cold_start
    except PermissionError as e:
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="SECURITY_VIOLATION",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
        )
        print(resp.model_dump_json())
        return 3
    except FileNotFoundError as e:
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="ENTRYPOINT_NOT_FOUND",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
        )
        print(resp.model_dump_json())
        return 3
    except Exception as e:
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="SNAPSHOT_LOAD_ERROR",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
        )
        print(resp.model_dump_json())
        return 3

    # Build context + deadline
    now_ms = int(time.time() * 1000)
    deadline_ms = now_ms + meta.timeout_ms if meta.timeout_ms else None
    ctx = Context(
        request_id=request_id,
        trace_id=trace_id,
        deadline_ms=deadline_ms,
        snapshot_id=snapshot_id,
    )
    ctx.log("runner.start", action=req.action, snapshot_id=snapshot_id)

    try:
        if req.action == "describe":
            out = describe_fn(snapshot_id=snapshot_id)
            ctx.log("runner.describe.ok")
            resp = _ok_response(
                request_id=request_id,
                trace_id=trace_id,
                start_ms=start_ms,
                cold_start=cold_start,
                snapshot_id=snapshot_id,
                result=out,
                logs=ctx.logs,  # ✅ fixed
            )
            print(resp.model_dump_json())
            return 0

        if req.action == "invoke":
            # For invoke, requirements depend on kind
            if not req.kind:
                raise ValueError("invoke requires 'kind'")

            ctx.log("runner.invoke", kind=req.kind, handler=req.handler)

            result = await invoke_fn(
                kind=req.kind,
                handler=req.handler,
                event=req.event,
                http=req.http,
                mcp=req.mcp,
                ctx=ctx,
                timeout_ms=meta.timeout_ms,
            )

            ctx.log("runner.invoke.ok")
            resp = _ok_response(
                request_id=request_id,
                trace_id=trace_id,
                start_ms=start_ms,
                cold_start=cold_start,
                snapshot_id=snapshot_id,
                result=result,
                logs=ctx.logs,  # ✅ fixed
            )
            print(resp.model_dump_json())
            return 0

        raise ValueError(f"Invalid action: {req.action}")

    except InvokeTimeout as e:
        ctx.log("runner.invoke.timeout", message=str(e))
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="TIMEOUT",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
            logs=ctx.logs,  # ✅ fixed
        )
        print(resp.model_dump_json())
        return 4

    except KeyError as e:
        msg = str(e).strip("'")
        ctx.log("runner.invoke.not_found", message=msg)
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="HANDLER_NOT_FOUND",
            message=msg,
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
            logs=ctx.logs,  # ✅ fixed
        )
        print(resp.model_dump_json())
        return 5

    except (TypeError, ValueError) as e:
        ctx.log("runner.invoke.validation_error", message=str(e))
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="VALIDATION_ERROR",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
            logs=ctx.logs,  # ✅ fixed
        )
        print(resp.model_dump_json())
        return 6

    except Exception as e:
        ctx.log("runner.invoke.user_code_error", message=str(e))
        resp = _error_response(
            request_id=request_id,
            trace_id=trace_id,
            start_ms=start_ms,
            cold_start=cold_start,
            snapshot_id=snapshot_id,
            code="USER_CODE_ERROR",
            message=str(e),
            details=None if args.no_traceback else {"traceback": traceback.format_exc()},
            logs=ctx.logs,  # ✅ fixed
        )
        print(resp.model_dump_json())
        return 7


def main() -> None:
    rc = asyncio.run(main_async())
    raise SystemExit(rc)


def cli() -> None:
    main()


if __name__ == "__main__":
    main()
