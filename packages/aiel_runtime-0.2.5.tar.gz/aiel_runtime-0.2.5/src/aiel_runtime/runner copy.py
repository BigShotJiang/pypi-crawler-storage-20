from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import traceback
from pathlib import Path
from typing import Any

from .protocol import RunnerRequest, RunnerResponse
from .loader import load_snapshot
from .describe import describe
from .invoke import invoke


def _error(code: str, message: str, *, tb: str | None = None, details: dict[str, Any] | None = None) -> RunnerResponse:
    err: dict[str, Any] = {"code": code, "message": message}
    if details:
        err["details"] = details
    if tb:
        err["traceback"] = tb
    return RunnerResponse(ok=False, error=err)


def _resolve_files_root(cli_files_root: str | None) -> Path:
    """
    Resolve the snapshot root directory.

    Precedence:
      1) --files-root
      2) EP_FILES_ROOT env var
    """
    v = cli_files_root or os.getenv("EP_FILES_ROOT")
    if not v:
        raise RuntimeError(
            "Missing files root. Provide --files-root or set EP_FILES_ROOT to a snapshot folder containing entry_point.py."
        )

    p = Path(v).expanduser().resolve()
    if not p.exists():
        raise RuntimeError(f"files root does not exist: {p}")

    entry = p / "entry_point.py"
    if not entry.exists():
        raise RuntimeError(f"entry_point.py not found under files root: {p}")

    return p


def _read_request() -> RunnerRequest:
    raw = sys.stdin.read()
    if not raw.strip():
        raise RuntimeError("Empty stdin. Expected JSON request (e.g. {'action':'describe'}).")
    return RunnerRequest.model_validate_json(raw)


async def _run(files_root: Path) -> RunnerResponse:
    load_snapshot(files_root)
    req = _read_request()

    if req.action == "describe":
        return RunnerResponse(ok=True, result=describe())

    if req.action == "invoke":
        out = await invoke(req.kind or "", req.name or "", req.payload or {})
        return RunnerResponse(ok=True, result=out)

    return RunnerResponse(
        ok=False,
        error={
            "code": "INVALID_ACTION",
            "message": f"invalid action: {req.action!r}",
            "details": {"allowed": ["describe", "invoke"]},
        },
    )


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="aiel-runtime", add_help=True)
    parser.add_argument(
        "--files-root",
        help="Absolute path to the snapshot folder containing entry_point.py. "
             "If omitted, EP_FILES_ROOT env var is used.",
        default=None,
    )
    parser.add_argument(
        "--no-traceback",
        help="Do not include traceback in error output (cleaner for production).",
        action="store_true",
    )

    args = parser.parse_args(argv)

    try:
        files_root = _resolve_files_root(args.files_root)
        resp = asyncio.run(_run(files_root))
        print(resp.model_dump_json())
        raise SystemExit(0 if resp.ok else 1)

    except Exception as e:
        tb = None if args.no_traceback else traceback.format_exc()
        # classify common errors into stable codes
        msg = str(e)

        code = "RUNTIME_ERROR"
        if "Missing files root" in msg or "EP_FILES_ROOT" in msg or "entry_point.py" in msg:
            code = "MISSING_FILES_ROOT"
        elif "Empty stdin" in msg:
            code = "EMPTY_REQUEST"
        elif isinstance(e, json.JSONDecodeError):
            code = "INVALID_JSON"
        elif isinstance(e, ValueError) and "invalid action" in msg:
            code = "INVALID_ACTION"

        print(_error(code, msg, tb=tb).model_dump_json())
        raise SystemExit(2)


def cli() -> None:
    # Convenience wrapper: `aiel-runtime < req.json`
    main()


if __name__ == "__main__":
    main()
