from __future__ import annotations
from pydantic import BaseModel
from typing import Any, Literal
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

class RunnerRequest(BaseModel):
    action: Literal["describe", "invoke"]
    kind: str | None = None     # tool|agent|flow|http|mcp
    name: str | None = None
    payload: dict[str, Any] | None = None

class RunnerResponse(BaseModel):
    ok: bool
    result: Any | None = None
    error: dict[str, Any] | None = None

@dataclass
class Context:
    request_id: str = "req_unknown"
    tenant_id: Optional[str] = None
    workspace_id: Optional[str] = None
    project_id: Optional[str] = None
    user_id: Optional[str] = None
    logs: list[dict] = field(default_factory=list)

    def log(self, event: str, **fields: Any) -> None:
        self.logs.append({"event": event, **fields})

    @classmethod
    def from_dict(cls, d: Optional[Dict[str, Any]]) -> "Context":
        if not d:
            return cls()
        return cls(
            request_id=d.get("request_id", "req_unknown"),
            tenant_id=d.get("tenant_id"),
            workspace_id=d.get("workspace_id"),
            project_id=d.get("project_id"),
            user_id=d.get("user_id"),
        )