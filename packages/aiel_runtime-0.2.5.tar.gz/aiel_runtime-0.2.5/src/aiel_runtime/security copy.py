from __future__ import annotations

DEFAULT_DENY_IMPORTS = {
    "subprocess",
    "socket",
    "ctypes",
    "resource",
    "signal",
}

def ensure_allowed_import_roots(import_roots: set[str]) -> None:
    bad = sorted([m for m in import_roots if m in DEFAULT_DENY_IMPORTS])
    if bad:
        raise RuntimeError(f"Disallowed imports detected: {bad}")
