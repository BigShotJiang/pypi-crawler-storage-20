from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple
import contextlib
import hashlib
import importlib.util
import os
import sys
import time
from uuid import uuid4

from aiel_sdk import reset_registry, validate_contracts

from .security import enforce_import_policy, ImportPolicy


@dataclass
class SnapshotInfo:
    snapshot_id: str
    cold_start: bool
    module_name: str


_COLD_START = True

# Optional warm cache: snapshot_id -> module_name
# Disabled by default because it increases cross-run state risk.
_WARM_CACHE: Dict[str, str] = {}


def _hash_snapshot(files_root: Path) -> str:
    """
    Content-addressed snapshot id (stable for identical snapshot contents).
    """
    h = hashlib.sha256()
    for p in sorted(files_root.rglob("*")):
        if not p.is_file():
            continue
        # Ignore typical junk directories
        rel = p.relative_to(files_root).as_posix()
        if rel.startswith(".git/") or rel.startswith(".venv/") or rel.startswith("__pycache__/"):
            continue
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(p.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


@contextlib.contextmanager
def _temporary_sys_path(path: str):
    sys.path.insert(0, path)
    try:
        yield
    finally:
        # Remove only one instance (the one we inserted)
        try:
            sys.path.remove(path)
        except ValueError:
            pass


def _import_entrypoint(files_root: Path, module_name: str) -> None:
    entry = files_root / "entry_point.py"
    if not entry.exists():
        raise FileNotFoundError(f"entry_point.py not found at: {entry}")

    spec = importlib.util.spec_from_file_location(module_name, str(entry))
    if spec is None or spec.loader is None:
        raise RuntimeError("Failed to create import spec for entry_point.py")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)  # type: ignore[attr-defined]


def _cleanup_snapshot_modules(files_root: Path, before_modules: set[str]) -> None:
    """
    Remove any modules that were imported during snapshot load whose __file__ sits under files_root.
    Also remove the unique entrypoint module we created.
    """
    root = str(files_root.resolve())

    after = set(sys.modules.keys())
    new_modules = after - before_modules

    to_delete = []
    for name in new_modules:
        mod = sys.modules.get(name)
        f = getattr(mod, "__file__", None)
        if not f:
            continue
        try:
            f_abs = str(Path(f).resolve())
        except Exception:
            continue
        if f_abs.startswith(root + os.sep) or f_abs == root:
            to_delete.append(name)

    for name in to_delete:
        sys.modules.pop(name, None)


def load_snapshot(
    files_root: Path,
    *,
    policy: ImportPolicy,
    keep_warm: bool = False,
) -> SnapshotInfo:
    global _COLD_START

    files_root = files_root.resolve()
    snapshot_id = _hash_snapshot(files_root)
    cold_start = _COLD_START
    _COLD_START = False

    # Safety: reset registry each load (prevents stale registrations)
    reset_registry()

    # Enforce security *before* import
    enforce_import_policy(files_root, policy)

    # Warm-cache logic (optional and OFF by default)
    if keep_warm and snapshot_id in _WARM_CACHE:
        module_name = _WARM_CACHE[snapshot_id]
        # Registry must still be reloaded to ensure it's populated for this process run
        # (If you want true warm reuse, you'd also keep registry, but that increases risk.)
        # We'll simply re-import the entrypoint under a new module name to re-register.
        keep_warm = False

    module_name = f"aiel_snapshot_{snapshot_id[:8]}_{uuid4().hex[:8]}"

    before_modules = set(sys.modules.keys())

    with _temporary_sys_path(str(files_root)):
        _import_entrypoint(files_root, module_name)

    # Enforce contracts early (clear errors)
    validate_contracts()

    if keep_warm:
        _WARM_CACHE[snapshot_id] = module_name
    else:
        _cleanup_snapshot_modules(files_root, before_modules)

    return SnapshotInfo(snapshot_id=snapshot_id, cold_start=cold_start, module_name=module_name)
