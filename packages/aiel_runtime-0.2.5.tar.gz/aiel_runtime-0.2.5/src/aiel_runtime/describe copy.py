from __future__ import annotations
from aiel_sdk import get_registry, SDK_VERSION
from ._version import RUNTIME_VERSION

def describe() -> dict:
    reg = get_registry()
    return {
        "sdk_version": SDK_VERSION,
        "runtime_version": RUNTIME_VERSION,
        "tools": sorted(reg.tools.keys()),
        "agents": sorted(reg.agents.keys()),
        "flows": sorted(reg.flows.keys()),
        "http_handlers": [{"method": h.method, "path": h.path} for h in reg.http_handlers],
        "mcp_servers": [{"name": s.name, "tools": s.tools} for s in reg.mcp_servers.values()],
    }
