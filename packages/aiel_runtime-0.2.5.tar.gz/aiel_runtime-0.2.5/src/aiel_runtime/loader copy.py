from __future__ import annotations
import sys
from pathlib import Path

from aiel_sdk import reset_registry, validate_contracts

def load_snapshot(files_root: Path) -> None:
    # Make warm runtimes safe: reset registry each load
    reset_registry()

    # Put user snapshot first on sys.path
    sys.path.insert(0, str(files_root))

    # Import user entrypoint (registers tools/agents/flows/http/mcp)
    __import__("entry_point")

    # Enforce contracts early (clear errors)
    validate_contracts()
