from __future__ import annotations
import asyncio
import inspect
from typing import Any
from .protocol import Context

from aiel_sdk import get_registry
_RESERVED_KEYS = {"ctx", "_ctx", "state", "timeout_ms", "headers", "meta"}

async def _maybe_await(x: Any) -> Any:
    if asyncio.iscoroutine(x):
        return await x
    return x

def _ctx(payload: dict):
    ctx_data = None
    if isinstance(payload, dict):
        ctx_data = payload.get("ctx") or payload.get("_ctx")

    return Context.from_dict(ctx_data) 

def _clean_kwargs(payload: dict) -> dict:
    if not isinstance(payload, dict):
        return {}
    return {k: v for k, v in payload.items() if k not in _RESERVED_KEYS}

def _call_style(fn) -> str:
    """
    Decide how to call fn:
      - "payload": (ctx, payload_dict)
      - "kwargs":  (ctx, **payload_dict)
    """
    sig = inspect.signature(fn)
    params = list(sig.parameters.values())

    # Need at least ctx
    if len(params) < 1:
        return "payload"

    # If exactly 2 params, very likely (ctx, payload)
    if len(params) == 2:
        return "payload"

    # If second param is **kwargs, call kwargs
    if len(params) >= 2 and params[1].kind == inspect.Parameter.VAR_KEYWORD:
        return "kwargs"

    # If function declares named args beyond ctx, call kwargs
    # Example: (ctx, email: str, name: str)
    if len(params) > 2:
        return "kwargs"

    # Fallback to payload
    return "payload"

def _validate_kwargs(fn, kwargs: dict) -> None:
    """
    Validate kwargs against signature to raise a clean error message.
    """
    sig = inspect.signature(fn)
    params = list(sig.parameters.values())

    # Remove ctx param
    if params:
        params = params[1:]

    required = []
    accepts_kwargs = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params)
    accepted_names = {p.name for p in params if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)}

    for p in params:
        if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
            if p.default is inspect._empty:
                required.append(p.name)

    missing = [k for k in required if k not in kwargs]
    if missing:
        raise TypeError(f"Missing required arguments: {missing}")

    if not accepts_kwargs:
        unknown = [k for k in kwargs.keys() if k not in accepted_names]
        if unknown:
            raise TypeError(f"Unknown arguments: {unknown}")


async def invoke(kind: str, name: str, payload: dict) -> Any:
    reg = get_registry()
    payload = payload or {}
    ctx = _ctx(payload)

    if kind == "tool":
        exp = reg.tools.get(name)
        if not exp:
            raise KeyError(f"Tool not found: {name}")

        fn = exp.fn
        style = _call_style(fn)

        if style == "payload":
            # Canonical: tool(ctx, payload)
            return await _maybe_await(fn(ctx, payload))

        # Compatibility: tool(ctx, **payload)
        kwargs = _clean_kwargs(payload)
        _validate_kwargs(fn, kwargs)
        return await _maybe_await(fn(ctx, **kwargs))

    if kind == "agent":
        exp = reg.agents.get(name)
        if not exp:
            raise KeyError(f"Agent not found: {name}")

        state = payload.get("state", payload)
        fn = exp.fn
        style = _call_style(fn)

        if style == "payload":
            # Canonical: agent(ctx, state)
            return await _maybe_await(fn(ctx, state))

        # Some people write agent(ctx, **state) — allow it (optional)
        if not isinstance(state, dict):
            raise TypeError("Agent state must be an object for kwargs-style agents.")
        kwargs = _clean_kwargs(state)
        _validate_kwargs(fn, kwargs)
        return await _maybe_await(fn(ctx, **kwargs))

    raise KeyError(f"Unsupported kind: {kind}")