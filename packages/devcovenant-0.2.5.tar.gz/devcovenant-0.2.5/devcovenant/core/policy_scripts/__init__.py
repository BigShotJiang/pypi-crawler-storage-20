"""Policy check scripts."""
