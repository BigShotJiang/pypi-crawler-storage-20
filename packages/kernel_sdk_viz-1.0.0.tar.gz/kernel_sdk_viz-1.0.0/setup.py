from setuptools import setup, find_namespace_packages


setup(
    name="kernel_sdk_viz",
    version=open("VERSION").read(),
    author="Kernel",
    author_email="software@kernel.com",
    packages=find_namespace_packages(include=["kernel.sdk.viz", "kernel.sdk.viz.*"]),
    package_data={"kernel.sdk.viz.docs": ["*"]},
    long_description=open("kernel/sdk/viz/docs/README.md").read(),
    long_description_content_type="text/markdown",
    entry_points={
        "console_scripts": [
            "kernel-sdk-viz=kernel.sdk.viz.scripts.cli:cli",
        ],
    },
    install_requires=[
        "kernel_sdk",
        "click",
        "numpy",
        "pyqtgraph",
    ],  # PyQt5 or PySide2 is also required
    include_package_data=True,
    description="Example visualization tools for kernel.sdk",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    zip_safe=False,
)
