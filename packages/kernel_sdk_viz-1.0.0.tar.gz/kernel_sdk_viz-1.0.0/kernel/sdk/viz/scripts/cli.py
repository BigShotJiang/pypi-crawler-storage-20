import threading
import click
from kernel.sdk import SdkClient, Wavelength, MomentNumber
import numpy as np
import pyqtgraph as pg
from pyqtgraph.Qt import QtCore


@click.group()
@click.pass_context
def cli(ctx):
    ctx.ensure_object(dict)


class _DataSignal(QtCore.QObject):
    # singals have to be inside a QObject, can't just make them within the graph_moment function
    signal = QtCore.Signal()

    def __init__(self):
        super().__init__()


@cli.command(name="graph-moment")
@click.option("--wavelength", "-w", type=click.Choice(["Red", "IR"]), default="red")
@click.option("--module", "-m", type=int, default=0)
def graph_moment(wavelength, module):
    """Graph the zeroth moment for a given wavelength, for each detector on a given module"""
    client = SdkClient()

    NUM_SAMPLES = 4 * 19  # 12 samples per second for 20 seconds
    data = {i: [] for i in range(6)}
    timestamps = []

    win = pg.GraphicsLayoutWidget(show=True)

    plotWidget = win.addPlot(
        title=f"Flow Moment 0 Graph - {wavelength} - Module {module}"
    )
    curves = {i: plotWidget.plot(pen=(i, 6), name=f"detector {i}") for i in range(6)}
    legend = pg.LegendItem((80, 60), offset=(70, 20), colCount=2)
    legend.setParentItem(plotWidget.graphicsItem())
    for i in range(6):
        legend.addItem(curves[i], f"detector {i}")

    def render_data():
        nonlocal data, timestamps
        offest_timestamps = np.array(timestamps) - timestamps[0]
        for i in range(6):
            curves[i].setData(offest_timestamps, data[i])

    signal = _DataSignal()
    signal.signal.connect(render_data)

    def pipe_to_app(ts, d):
        nonlocal data, timestamps
        for i in range(len(ts)):
            scaled_ts = ts[i] / 1e9
            if len(timestamps) > 0 and scaled_ts - timestamps[-1] > 1:
                # if there's a gap in the timestamps, clear the data and wait for next callback
                timestamps = []
                data = {i: [] for i in range(6)}
                return
            timestamps.append(scaled_ts)

            if len(timestamps) > NUM_SAMPLES:
                while len(timestamps) > NUM_SAMPLES:
                    timestamps.pop(0)
        for i in range(6):
            # and push each row as a separate element into data
            for t in range(len(ts)):
                data[i].append(d[t, i])
                if len(data[i]) > NUM_SAMPLES:
                    while len(data[i]) > NUM_SAMPLES:
                        data[i].pop(0)

        # emit signal to update the plot
        signal.signal.emit()

    client.on_moments_by_module(
        MomentNumber.Zeroth, Wavelength(wavelength), module, pipe_to_app
    )

    pg.exec()


class WarningTimer(QtCore.QObject):
    def __init__(self, warning_time_seconds: float):
        super().__init__()
        self.warning_time = warning_time_seconds
        self.timer = QtCore.QTimer()
        self.timer.start(warning_time_seconds * 1000)  # convert to milliseconds
        self._reset_signal = _DataSignal()

        self._reset_signal.signal.connect(self._reset)

    def reset(self):
        """
        thread-safe method to reset the timer
        """
        self._reset_signal.signal.emit()

    def _reset(self):
        self.timer.start(self.warning_time * 1000)


@cli.command(name="graph")
def graph():
    """Graph a moment"""
    client = SdkClient()

    # check available modules to populate the combobox
    modules = client.get_available_modules()

    _app = pg.mkQApp()

    win = pg.QtWidgets.QMainWindow()
    layout = pg.QtWidgets.QGridLayout()

    # add buttons for module selection and wavelength selection
    module_spinbox = pg.ComboBox(win, items={str(i): i for i in modules})
    wavelength_combobox = pg.ComboBox(win)
    wavelength_combobox.addItem("Red")
    wavelength_combobox.addItem("IR")

    # add a button to update the selected module and wavelength by unsubscribing the current future (if any) and subscribing to the new one
    button = pg.QtWidgets.QPushButton("Update", win)

    # add widgets to the layout
    layout.addWidget(module_spinbox, 0, 0)
    layout.addWidget(wavelength_combobox, 0, 1)
    layout.addWidget(button, 0, 2)

    graphicslayout = pg.GraphicsLayoutWidget(show=True)
    plotWidget = graphicslayout.addPlot(title=f"Flow Moment 0 Graph")
    layout.addWidget(graphicslayout, 1, 0, 1, 3)
    warning_label = pg.QtWidgets.QLabel(
        "Warning: No data received recently, check that lasers are on", win
    )
    layout.addWidget(warning_label, 2, 0, 1, 3)
    warning_label.hide()

    warning_timer = WarningTimer(3)

    is_hidden = True

    def show_warning():
        nonlocal is_hidden
        if not is_hidden:
            return
        is_hidden = False
        warning_label.show()

    def hide_warning():
        nonlocal is_hidden
        if is_hidden:
            return
        is_hidden = True
        warning_label.hide()

    warning_timer.timer.timeout.connect(show_warning)

    cw = pg.QtWidgets.QWidget()
    cw.setLayout(layout)
    win.setCentralWidget(cw)

    NUM_SAMPLES = 4 * 19
    data = {i: [] for i in range(6)}
    timestamps = []

    def pipe_to_app(ts, d):
        nonlocal data, timestamps, warning_timer
        warning_timer.reset()
        hide_warning()
        for i in range(len(ts)):
            scaled_ts = ts[i] / 1e9
            if len(timestamps) > 0 and scaled_ts - timestamps[-1] > 1:
                # if there's a gap in the timestamps, clear the data and wait for next callback
                timestamps = []
                data = {i: [] for i in range(6)}
                return
            timestamps.append(scaled_ts)

            while len(timestamps) > NUM_SAMPLES:
                timestamps.pop(0)
        for i in range(6):
            # and push each row as a separate element into data
            for t in range(len(ts)):
                data[i].append(d[t, i])
                if len(data[i]) > NUM_SAMPLES:
                    while len(data[i]) > NUM_SAMPLES:
                        data[i].pop(0)

        # emit signal to update the plot
        signal.signal.emit()

    current_future = None

    def update():
        nonlocal current_future, data, timestamps, client

        if current_future is not None:
            # cancelling the future will unsubscribe from kortex
            current_future.cancel()

        # clear the data and rerender an empty plot
        data = {i: [] for i in range(6)}
        timestamps = []
        render_data()
        current_future = client.on_moments_by_module(
            MomentNumber.Zeroth,
            Wavelength(wavelength_combobox.value()),
            int(module_spinbox.value()),
            pipe_to_app,
        )
        # clear the data
        data = {i: [] for i in range(6)}
        timestamps = []
        # update plot title
        plotWidget.setTitle(
            f"Flow Moment 0 Graph - {wavelength_combobox.value()} - Module {int(module_spinbox.value())}"
        )

    button.clicked.connect(update)

    curves = {i: plotWidget.plot(pen=(i, 6), name=f"detector {i}") for i in range(6)}
    legend = pg.LegendItem((80, 60), offset=(70, 20), colCount=2)
    legend.setParentItem(plotWidget.graphicsItem())
    for i in range(6):
        legend.addItem(curves[i], f"detector {i}")

    def render_data():
        nonlocal data, timestamps

        offest_timestamps = []
        if len(timestamps) > 0:
            offest_timestamps = np.array(timestamps) - timestamps[0]
        for i in range(6):
            curves[i].setData(offest_timestamps, data[i])

    signal = _DataSignal()
    signal.signal.connect(render_data)
    win.show()
    pg.exec()
