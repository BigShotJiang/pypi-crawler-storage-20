__version__ = "0.7.0"

__dev_version__ = "0.7.0.dev2"
