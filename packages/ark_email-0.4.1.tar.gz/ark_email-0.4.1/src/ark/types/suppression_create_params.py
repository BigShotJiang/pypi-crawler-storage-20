# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["SuppressionCreateParams"]


class SuppressionCreateParams(TypedDict, total=False):
    address: Required[str]
    """Email address to suppress"""

    reason: str
    """Reason for suppression"""
