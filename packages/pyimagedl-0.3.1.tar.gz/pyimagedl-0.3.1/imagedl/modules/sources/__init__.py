'''initialize'''
from .base import BaseImageClient
from .bing import BingImageClient
from .i360 import I360ImageClient
from .baidu import BaiduImageClient
from .sogou import SogouImageClient
from .yahoo import YahooImageClient
from .pexels import PexelsImageClient
from .google import GoogleImageClient
from ..utils import BaseModuleBuilder
from .yandex import YandexImageClient
from .pixabay import PixabayImageClient
from .danbooru import DanbooruImageClient
from .unsplash import UnsplashImageClient
from .gelbooru import GelbooruImageClient
from .safebooru import SafebooruImageClient
from .duckduckgo import DuckduckgoImageClient


'''ImageClientBuilder'''
class ImageClientBuilder(BaseModuleBuilder):
    REGISTERED_MODULES = {
        'BingImageClient': BingImageClient, 'BaiduImageClient': BaiduImageClient, 'GoogleImageClient': GoogleImageClient, 'I360ImageClient': I360ImageClient, 
        'PixabayImageClient': PixabayImageClient, 'YandexImageClient': YandexImageClient, 'DuckduckgoImageClient': DuckduckgoImageClient, 'SogouImageClient': SogouImageClient, 
        'YahooImageClient': YahooImageClient, 'UnsplashImageClient': UnsplashImageClient, 'SafebooruImageClient': SafebooruImageClient, 'DanbooruImageClient': DanbooruImageClient,
        'GelbooruImageClient': GelbooruImageClient, 'PexelsImageClient': PexelsImageClient,
    }


'''BuildImageClient'''
BuildImageClient = ImageClientBuilder().build