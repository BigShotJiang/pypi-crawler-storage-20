"""Tests for appscript-mcp"""
