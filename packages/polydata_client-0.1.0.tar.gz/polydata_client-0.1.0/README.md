# Polydata Python Client

Official Python client for the [Polydata](https://polydata.co) API.

## Installation

```bash
pip install polydata-client
```

## Quick Start

```python
from polydata import PolydataClient

# Initialize client with your API key
client = PolydataClient(api_key="pd_sk_your_api_key_here")

# Test connection
client.test_connection()

# Get data from a view
df = client.get_data_view(
    hub_schema="my_hub",
    view_name="my_view"
)
```

## Authentication

Get your API key from your Polydata dashboard. You can pass it directly or set it as an environment variable:

```bash
export POLYDATA_API_KEY="pd_sk_your_api_key_here"
```

```python
import os
from polydata import PolydataClient

client = PolydataClient(api_key=os.getenv("POLYDATA_API_KEY"))
```

## Core Features

### Get Data

Retrieve data from a view as a pandas DataFrame:

```python
df = client.get_data_view(
    hub_schema="my_hub",
    view_name="my_view"
)
```

### Upload Data

Upload CSV data to create or update tables:

```python
client.upload_data_source(
    file_path="data.csv",
    hub_schema="my_hub",
    table_name="my_table",
    schema_path="schema.json",
    type="create"  # or "replace" or "append"
)
```

### Manage Views

```python
# List all views
views = client.list_data_views(hub_schema="my_hub")
```

## Additional Features

The client also supports:

- Data apps, pages, components, and widgets
- Tickers for real-time displays
- Custom API endpoints
- Batch uploads for large files

## Requirements

- Python >= 3.8
- requests >= 2.31.0
- pandas >= 1.5.0

## Links

- [Homepage](https://polydata.co)
- [Documentation](https://docs.polydata.co)

## License

Apache License 2.0
