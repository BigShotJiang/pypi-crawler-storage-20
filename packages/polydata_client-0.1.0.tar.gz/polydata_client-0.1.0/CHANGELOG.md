# Changelog

All notable changes to the Polydata Python client will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-01-16

### Added

- Initial release of Polydata Python client
- Support for data source uploads (create, replace, append)
- Data view management (create, update, get, list)
- Data app creation and page updates
- Component and widget management
- Ticker creation and updates
- Custom endpoint creation and management
- Helper utilities for create-or-update patterns
- Batch upload support for large CSV files
- Comprehensive error handling
- API connection testing
