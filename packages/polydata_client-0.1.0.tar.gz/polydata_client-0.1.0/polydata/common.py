"""
Common utility functions for Polydata client usage.
"""

import os
import tempfile
import time
from typing import Dict

import pandas as pd


def hub_view_exists(view_name: str, hub_views_df: pd.DataFrame) -> bool:
    """
    Check if a view exists in the hub.

    Args:
        view_name: Full view name (schema.view_name format)
        hub_views_df: DataFrame from client.list_data_views()

    Returns:
        True if the view exists, False otherwise
    """
    return view_name in hub_views_df["view_name"].values


def create_or_update_view(
    client,
    hub_schema: str,
    view_name: str,
    view_query: str,
    hub_views_df: pd.DataFrame,
):
    """
    Create or update a data view based on whether it exists.

    This function checks if a view already exists and calls either
    client.create_data_view() or client.update_data_view() accordingly.

    Args:
        client: PolydataClient instance
        hub_schema: Schema name
        view_name: View name (without schema prefix)
        view_query: SQL query for the view
        hub_views_df: DataFrame from client.list_data_views(hub_schema=hub_schema)

    Example:
        ```python
        from polydata import PolydataClient
        from polydata.common import create_or_update_view

        client = PolydataClient(api_key="...", base_url="...")
        hub_views_df = client.list_data_views(hub_schema="my_schema")

        create_or_update_view(
            client=client,
            hub_schema="my_schema",
            view_name="my_view",
            view_query="SELECT * FROM my_table",
            hub_views_df=hub_views_df,
        )
        ```
    """
    full_view_name = f"{hub_schema}.{view_name}"

    if hub_view_exists(full_view_name, hub_views_df):
        client.update_data_view(
            hub_schema=hub_schema,
            view_name=view_name,
            view_query=view_query,
        )
    else:
        client.create_data_view(
            hub_schema=hub_schema,
            view_name=view_name,
            view_query=view_query,
        )


def ticker_exists(ticker_name: str, hub_tickers_df: pd.DataFrame) -> bool:
    """
    Check if a ticker exists in the hub.

    Args:
        ticker_name: Ticker name to check
        hub_tickers_df: DataFrame from client.list_tickers()

    Returns:
        True if the ticker exists, False otherwise
    """
    if hub_tickers_df.empty:
        return False
    return ticker_name in hub_tickers_df["ticker_name"].values


def create_or_update_ticker(
    client,
    hub_schema: str,
    ticker_name: str,
    ticker_config: dict,
    hub_tickers_df: pd.DataFrame,
    is_ticker_on_homepage: bool = False,
    is_ticker_on_hub_homepage: bool = False,
    data_app_name: str = None,
    last_updated_table_name: str = None,
):
    """
    Create or update a ticker based on whether it exists.

    This function checks if a ticker already exists and calls either
    client.create_ticker() or client.update_ticker() accordingly.

    Args:
        client: PolydataClient instance
        hub_schema: Schema name
        ticker_name: Ticker name
        ticker_config: Ticker configuration dict
        hub_tickers_df: DataFrame from client.list_tickers()
        is_ticker_on_homepage: Whether to show ticker on homepage
        is_ticker_on_hub_homepage: Whether to show ticker on hub homepage
        data_app_name: Name of the associated data app (optional)
        last_updated_table_name: Name of the table to check for last update

    Example:
        ```python
        from polydata import PolydataClient, create_or_update_ticker

        client = PolydataClient(api_key="...", base_url="...")
        hub_tickers_df = client.list_tickers(hub_schema="my_schema")

        create_or_update_ticker(
            client=client,
            hub_schema="my_schema",
            ticker_name="my_ticker",
            ticker_config={...},
            hub_tickers_df=hub_tickers_df,
            is_ticker_on_homepage=True,
            data_app_name="My App",
        )
        ```
    """
    if ticker_exists(ticker_name, hub_tickers_df):
        client.update_ticker(
            hub_schema=hub_schema,
            ticker_name=ticker_name,
            ticker_config=ticker_config,
            is_ticker_on_homepage=is_ticker_on_homepage,
            is_ticker_on_hub_homepage=is_ticker_on_hub_homepage,
            data_app_name=data_app_name,
            last_updated_table_name=last_updated_table_name,
        )
    else:
        client.create_ticker(
            hub_schema=hub_schema,
            ticker_name=ticker_name,
            ticker_config=ticker_config,
            is_ticker_on_homepage=is_ticker_on_homepage,
            is_ticker_on_hub_homepage=is_ticker_on_hub_homepage,
            data_app_name=data_app_name,
            last_updated_table_name=last_updated_table_name,
        )


def upload_large_csv_in_batches(
    client,
    file_path: str,
    hub_schema: str,
    table_name: str,
    schema_path: str,
    chunk_size: int = 10000,
    delay_between_chunks: int = 5,
    ignore_superset_validation: bool = False,
    explicitly_delete_view: bool = False,
    force_cascade: bool = False,
) -> Dict:
    """
    Upload a large CSV file in batches to avoid memory issues.

    This function splits a large CSV into smaller chunks and uploads them
    sequentially. The first chunk uses type="replace" to clear/create the
    table, and subsequent chunks use type="append" to add more rows.

    This is useful when uploading files that would exceed API memory limits
    (typically > 50-100MB depending on server configuration).

    Args:
        client: PolydataClient instance
        file_path: Path to the large CSV file
        hub_schema: The hub schema name (e.g. fight_matrix)
        table_name: Name for the table
        schema_path: Path to the JSON schema file
        chunk_size: Number of rows per chunk (default: 10,000)
        delay_between_chunks: Seconds to wait between chunk uploads to allow
          server garbage collection (default: 5). Increase for memory-constrained
          servers. Set to 0 to disable delays.
        ignore_superset_validation: If True, skip superset validation
          (only applies to first/replace operation)
        explicitly_delete_view: If True, delete view before replacing
          (only applies to first/replace operation)
        force_cascade: If True, use CASCADE when dropping columns
          (only applies to first/replace operation)

    Returns:
        Dict: Summary of upload results

    Example:
        ```python
        from polydata import PolydataClient
        from polydata.common import upload_large_csv_in_batches

        client = PolydataClient(api_key="...", base_url="...")

        upload_large_csv_in_batches(
            client=client,
            file_path="/path/to/large_file.csv",
            hub_schema="my_schema",
            table_name="my_table",
            schema_path="/path/to/schema.json",
            chunk_size=10000
        )
        ```
    """
    print(f"\n📦 Starting batched upload of: {file_path}")
    print(f"   Chunk size: {chunk_size:,} rows")

    # Read CSV as raw lines to preserve exact formatting
    with open(file_path, "r") as f:
        lines = f.readlines()

    header = lines[0]
    data_lines = lines[1:]
    total_rows = len(data_lines)
    num_chunks = (total_rows + chunk_size - 1) // chunk_size

    print(f"   Total rows: {total_rows:,}")
    print(f"   Number of chunks: {num_chunks}")

    # Create temporary directory for chunk files
    temp_dir = tempfile.mkdtemp(prefix="polydata_chunks_")
    print(f"   Temporary directory: {temp_dir}")

    try:
        for chunk_num in range(num_chunks):
            start_row = chunk_num * chunk_size
            end_row = min(start_row + chunk_size, total_rows)
            chunk_lines = data_lines[start_row:end_row]

            # Create temporary chunk file
            chunk_filename = f"chunk_{chunk_num:04d}.csv"
            chunk_path = os.path.join(temp_dir, chunk_filename)

            # Write chunk preserving exact CSV format
            with open(chunk_path, "w") as f:
                f.write(header)
                f.writelines(chunk_lines)

            chunk_size_mb = os.path.getsize(chunk_path) / (1024 * 1024)
            chunk_row_count = len(chunk_lines)

            print(
                f"\n   📤 Uploading chunk {chunk_num + 1}/{num_chunks} "
                f"(rows {start_row:,}-{end_row:,}, "
                f"{chunk_row_count:,} rows, {chunk_size_mb:.2f} MB)"
            )

            # First chunk: replace, rest: append
            if chunk_num == 0:
                client.upload_data_source(
                    file_path=chunk_path,
                    hub_schema=hub_schema,
                    table_name=table_name,
                    schema_path=schema_path,
                    type="replace",
                    ignore_superset_validation=ignore_superset_validation,
                    explicitly_delete_view=explicitly_delete_view,
                    force_cascade=force_cascade,
                )
            else:
                client.upload_data_source(
                    file_path=chunk_path,
                    hub_schema=hub_schema,
                    table_name=table_name,
                    schema_path=schema_path,
                    type="append",
                )

            print(f"      ✓ Chunk {chunk_num + 1} uploaded successfully")

            # Clean up chunk file after upload
            os.remove(chunk_path)

            # Add delay between chunks to allow server garbage collection
            # (skip delay after last chunk)
            if delay_between_chunks > 0 and chunk_num < num_chunks - 1:
                print(
                    f"      ⏳ Waiting {delay_between_chunks}s for server "
                    f"garbage collection..."
                )
                time.sleep(delay_between_chunks)

    finally:
        # Clean up temporary directory
        try:
            os.rmdir(temp_dir)
            print("\n   🧹 Cleaned up temporary directory")
        except OSError:
            print(
                f"\n   ⚠️  Could not remove temp directory: {temp_dir} "
                f"(may contain files)"
            )

    print(
        f"\n   ✅ Batched upload complete: {total_rows:,} total rows uploaded"
    )

    return {
        "total_rows": total_rows,
        "num_chunks": num_chunks,
        "chunk_size": chunk_size,
    }
