from pathlib import Path
from typing import Dict

import pandas as pd
import requests


class PolydataClient:
    """Client for interacting with the Polydata API."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.polydata.co/v1",
        timeout: int = 3600,
    ):
        self.api_key = api_key
        self.base_url = base_url
        self.timeout = timeout  # Default 60 minutes (3600 seconds)
        self.session = requests.Session()
        self.session.headers.update(
            {"Authorization": "Bearer {}".format(api_key)}
        )

    def _handle_response(
        self,
        response: requests.Response,
        success_message: str = None,
        error_context: str = "Request",
    ) -> Dict:
        """
        Handle API response with standardized error handling.

        Args:
            response: The response object from requests
            success_message: Optional message to print on success
            error_context: Context for error message (e.g., "Create ticker")

        Returns:
            Dict: Response JSON if successful

        Raises:
            Exception: If request fails (status != 200)
        """
        if response.status_code == 200:
            if success_message:
                print(success_message)
            return response.json() if response.text else {}
        else:
            raise Exception(
                f"{error_context} failed with status "
                f"{response.status_code}: {response.text}"
            )

    def test_connection(self) -> Dict:
        """
        Test the API connection and authentication.

        Returns:
          Dict: Response from the API with user info.

        Raises:
          Exception: If connection fails or API key is invalid
        """
        response = self.session.get(f"{self.base_url}/auth/test-auth")
        self._handle_response(
            response,
            success_message="✅ API key connection works.",
            error_context="Connection test",
        )
        return True

    def upload_data_source(
        self,
        file_path: str,
        hub_schema: str,
        table_name: str,
        schema_path: str,
        type: str,
        ignore_superset_validation: bool = False,
        explicitly_delete_view: bool = False,
        force_cascade: bool = False,
    ) -> Dict:
        """
        Upload, replace, or append data to a data source.

        Args:
          file_path: Path to the CSV file
          hub_schema: The hub schema name (e.g. fight_matrix)
          table_name: Name for the table
          schema_path: Path to the JSON schema file
          type: Operation type - "create", "replace", or "append"
          ignore_superset_validation: If True, skip superset validation
            (only applies to replace operations)
          explicitly_delete_view: If True, delete view before replacing
            (only applies to replace operations)
          force_cascade: If True, use CASCADE when dropping columns
            (only applies to replace operations)

        Returns:
          Dict: Response from the API

        Raises:
          Exception: If upload fails or invalid type specified
        """

        # Validate type parameter
        valid_types = ["create", "replace", "append"]
        if type not in valid_types:
            raise ValueError(
                f"Invalid type '{type}'. Must be one of: {valid_types}"
            )

        with open(schema_path, "r") as f:
            table_schema = f.read()

        form_data = {
            "hub_schema": hub_schema,
            "table_name": table_name,
            "table_schema": table_schema,
        }

        # Only add these params for replace operations
        if type == "replace":
            form_data.update(
                {
                    "ignore_superset_validation": str(
                        ignore_superset_validation
                    ).lower(),
                    "explicitly_delete_view": str(
                        explicitly_delete_view
                    ).lower(),
                    "force_cascade": str(force_cascade).lower(),
                }
            )

        # Map type to endpoint
        endpoint_map = {
            "create": "/data/workflows/create-data-source-from-file",
            "replace": "/data/workflows/replace-data-source-from-file",
            "append": "/data/workflows/append-data-source-from-file",
        }

        endpoint = endpoint_map[type]
        action = type.capitalize()

        file_path = Path(file_path)
        with open(file_path, "rb") as f:
            files = {"file": (file_path.name, f, "text/csv")}
            response = self.session.post(
                f"{self.base_url}{endpoint}",
                data=form_data,
                files=files,
                timeout=self.timeout,
            )

        return self._handle_response(response, error_context=action)

    def create_data_app(
        self,
        hub_schema: str,
        data_app_name: str,
        data_app_title: str,
        data_app_description: str,
    ) -> bool:
        """
        Create a data app using the API endpoint.

        Args:
          hub_schema: The hub schema name
          data_app_name: Name for the data app
          data_app_title: Title for the data app
          data_app_description: Description of the data app
        Returns:
          bool: True if successful, False otherwise
        """
        payload = {
            "hub_schema": hub_schema,
            "data_app_name": data_app_name,
            "data_app_title": data_app_title,
            "data_app_description": data_app_description,
        }

        response = self.session.post(
            f"{self.base_url}/apps/workflows/initialize-data-app",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Created data app: {data_app_name}",
            error_context=f"Create data app {data_app_name}",
        )
        return True

    def update_data_app_page(self, app_config: dict) -> bool:
        """
        Update data app page configuration using the API endpoint.

        Args:
          app_config: Dictionary containing the app configuration

        Returns:
          bool: True if successful, False otherwise
        """
        response = self.session.patch(
            f"{self.base_url}/apps/pages/update-data-app-page",
            json=app_config,
        )
        app_name = app_config.get("data_app_name", "unknown")
        self._handle_response(
            response,
            success_message=f"✓ Updated page config for: {app_name}",
            error_context="Update page config",
        )
        return True

    def create_data_view(
        self, hub_schema: str, view_name: str, view_query: str
    ) -> bool:
        """
        Create a data view using the API endpoint.

        Args:
          hub_schema: The hub schema name
          view_name: Name for the view
          view_query: SQL query for the view

        Returns:
          bool: True if successful, False otherwise
        """
        payload = {"view_query": view_query}
        response = self.session.post(
            f"{self.base_url}/data/views/{hub_schema}/{view_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Created data view: {view_name}",
            error_context=f"Create view {view_name}",
        )
        return True

    def update_data_view(
        self, hub_schema: str, view_name: str, view_query: str
    ) -> bool:
        """
        Update an existing data view using the API endpoint.

        Args:
          hub_schema: The hub schema name
          view_name: Name of the view to update
          view_query: New SQL query for the view

        Returns:
          bool: True if successful, False otherwise
        """
        payload = {"view_query": view_query}
        response = self.session.patch(
            f"{self.base_url}/data/views/{hub_schema}/{view_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Updated data view: {view_name}",
            error_context=f"Update view {view_name}",
        )
        return True

    def get_data_view(
        self, hub_schema: str, view_name: str, include_data: bool = True
    ) -> pd.DataFrame:
        """
        Get data from an existing data view and return as a pandas DataFrame.

        Args:
          hub_schema: The hub schema name
          view_name: Name of the view to retrieve
          include_data: Whether to include the actual data (default: True)

        Returns:
          pd.DataFrame: DataFrame containing the view data

        Raises:
          Exception: If retrieval fails
        """
        response = self.session.get(
            f"{self.base_url}/data/views/{hub_schema}/{view_name}",
            params={"include_data": include_data},
        )
        response_data = self._handle_response(
            response, error_context=f"Get view {view_name}"
        )
        view_data = response_data.get("data", {}).get("data", [])
        df = pd.DataFrame(view_data)
        print(f"✓ Retrieved data view: {view_name} ({len(df)} rows)")
        return df

    def list_data_views(self, hub_schema: str) -> pd.DataFrame:
        """
        List all data views for a specific hub and return as a pandas DataFrame.

        Args:
          hub_schema: The hub schema name

        Returns:
          pd.DataFrame: DataFrame containing view metadata (hub_view_id, hub_id, created_by, view_name, view_query)

        Raises:
          Exception: If retrieval fails
        """  # noqa: E501
        response = self.session.get(f"{self.base_url}/data/views/{hub_schema}")
        response_data = self._handle_response(
            response, error_context=f"List views for hub {hub_schema}"
        )
        views_list = response_data.get("data", [])
        df = pd.DataFrame(views_list)
        print(f"✓ Retrieved {len(df)} data views for hub: {hub_schema}")
        return df

    def list_data_apps(self, hub_schema: str) -> pd.DataFrame:
        """
        List all data apps for a specific hub and return as a pandas DataFrame.

        Args:
          hub_schema: The hub schema name

        Returns:
          pd.DataFrame: DataFrame containing data app metadata

        Raises:
          Exception: If retrieval fails
        """
        response = self.session.get(
            f"{self.base_url}/apps/dataapps/{hub_schema}"
        )
        response_data = self._handle_response(
            response, error_context=f"List apps for hub {hub_schema}"
        )
        apps_list = response_data.get("data", [])
        df = pd.DataFrame(apps_list)
        print(f"✓ Retrieved {len(df)} data apps for hub: {hub_schema}")
        return df

    def update_component(
        self, hub_schema: str, component_name: str, component_config: dict
    ) -> bool:
        """
        Update an existing component using the API endpoint.

        Args:
          hub_schema: The hub schema name
          component_name: Name of the component to update
          component_config: Component configuration dict

        Returns:
          bool: True if successful, False otherwise
        """
        import json

        payload = {"component_config": json.dumps(component_config)}

        response = self.session.patch(
            f"{self.base_url}/apps/components/{hub_schema}/{component_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Updated component: {component_name}",
            error_context=f"Update component {component_name}",
        )
        return True

    def create_widget(
        self, hub_schema: str, widget_name: str, widget_config: dict
    ) -> bool:
        """
        Create a new widget using the API endpoint.

        Args:
          hub_schema: The hub schema name
          widget_name: Name for the widget
          widget_config: Widget configuration dict

        Returns:
          bool: True if successful, False otherwise
        """
        import json

        payload = {"widget_config": json.dumps(widget_config)}

        response = self.session.post(
            f"{self.base_url}/apps/widgets/{hub_schema}/{widget_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Created widget: {widget_name}",
            error_context=f"Create widget {widget_name}",
        )
        return True

    def update_widget(
        self, hub_schema: str, widget_name: str, widget_config: dict
    ) -> bool:
        """
        Update an existing widget using the API endpoint.

        Args:
          hub_schema: The hub schema name
          widget_name: Name of the widget to update
          widget_config: Widget configuration dict

        Returns:
          bool: True if successful, False otherwise
        """
        import json

        payload = {"widget_config": json.dumps(widget_config)}

        response = self.session.patch(
            f"{self.base_url}/apps/widgets/{hub_schema}/{widget_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Updated widget: {widget_name}",
            error_context=f"Update widget {widget_name}",
        )
        return True

    def create_ticker(
        self,
        hub_schema: str,
        ticker_name: str,
        ticker_config: dict,
        is_ticker_on_homepage: bool = False,
        is_ticker_on_hub_homepage: bool = False,
        data_app_name: str = None,
        last_updated_table_name: str = None,
    ) -> bool:
        """
        Create a new ticker using the API endpoint.

        Args:
          hub_schema: The hub schema name
          ticker_name: Name for the ticker
          ticker_config: Ticker configuration dict (required)
          is_ticker_on_homepage: Whether to show ticker on homepage
            (default: False)
          is_ticker_on_hub_homepage: Whether to show ticker on hub homepage
            (default: False)
          data_app_name: Name of the associated data app (optional)
          last_updated_table_name: Name of the table to check for last
            update (optional)

        Returns:
          bool: True if successful, False otherwise
        """
        payload = {
            "ticker_config": ticker_config,
            "is_ticker_on_homepage": is_ticker_on_homepage,
            "is_ticker_on_hub_homepage": is_ticker_on_hub_homepage,
        }

        if data_app_name is not None:
            payload["data_app_name"] = data_app_name
        if last_updated_table_name is not None:
            payload["last_updated_table_name"] = last_updated_table_name

        response = self.session.post(
            f"{self.base_url}/apps/tickers/{hub_schema}/{ticker_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Created ticker: {ticker_name}",
            error_context=f"Create ticker {ticker_name}",
        )
        return True

    def update_ticker(
        self,
        hub_schema: str,
        ticker_name: str,
        ticker_config: dict = None,
        is_ticker_on_homepage: bool = None,
        is_ticker_on_hub_homepage: bool = None,
        data_app_name: str = None,
        last_updated_table_name: str = None,
    ) -> bool:
        """
        Update an existing ticker using the API endpoint.

        Args:
          hub_schema: The hub schema name
          ticker_name: Name of the ticker to update
          ticker_config: Ticker configuration dict (optional)
          is_ticker_on_homepage: Whether to show ticker on homepage
            (optional)
          is_ticker_on_hub_homepage: Whether to show ticker on hub homepage
            (optional)
          data_app_name: Name of the associated data app (optional)
          last_updated_table_name: Name of the table to check for last
            update (optional)

        Returns:
          bool: True if successful, False otherwise
        """
        payload = {}

        if ticker_config is not None:
            payload["ticker_config"] = ticker_config
        if is_ticker_on_homepage is not None:
            payload["is_ticker_on_homepage"] = is_ticker_on_homepage
        if is_ticker_on_hub_homepage is not None:
            payload["is_ticker_on_hub_homepage"] = is_ticker_on_hub_homepage
        if data_app_name is not None:
            payload["data_app_name"] = data_app_name
        if last_updated_table_name is not None:
            payload["last_updated_table_name"] = last_updated_table_name

        response = self.session.patch(
            f"{self.base_url}/apps/tickers/{hub_schema}/{ticker_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Updated ticker: {ticker_name}",
            error_context=f"Update ticker {ticker_name}",
        )
        return True

    def list_tickers(self, hub_schema: str) -> pd.DataFrame:
        """
        List all tickers for a specific hub and return as a pandas DataFrame.

        Args:
          hub_schema: The hub schema name

        Returns:
          pd.DataFrame: DataFrame containing ticker metadata

        Raises:
          Exception: If retrieval fails
        """
        response = self.session.get(
            f"{self.base_url}/apps/tickers/{hub_schema}"
        )
        response_data = self._handle_response(
            response, error_context=f"List tickers for hub {hub_schema}"
        )
        tickers_list = response_data.get("data", [])
        df = pd.DataFrame(tickers_list)
        print(f"✓ Retrieved {len(df)} tickers for hub: {hub_schema}")
        return df

    def create_endpoint(
        self,
        hub_schema: str,
        hub_view_id: int,
        hub_endpoint_name: str,
        subscription_plan_type_name: str = "enterprise",
        params_config: dict = None,
    ) -> bool:
        """
        Create a new hub endpoint using the API.

        Args:
          hub_schema: The hub schema name
          hub_view_id: ID of the hub view to expose as an endpoint
          hub_endpoint_name: Name for the endpoint
          subscription_plan_type_name: Subscription plan type required
            (default: "enterprise")
          params_config: Optional configuration for query parameters and
            allowed columns

        Returns:
          bool: True if successful, False otherwise
        """
        payload = {
            "hub_view_id": hub_view_id,
            "hub_endpoint_name": hub_endpoint_name,
            "subscription_plan_type_name": subscription_plan_type_name,
        }

        if params_config is not None:
            payload["params_config"] = params_config

        response = self.session.post(
            f"{self.base_url}/endpoints/{hub_schema}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Created endpoint: {hub_endpoint_name}",
            error_context=f"Create endpoint {hub_endpoint_name}",
        )
        return True

    def update_endpoint(
        self,
        hub_schema: str,
        hub_endpoint_name: str,
        hub_view_id: int = None,
        subscription_plan_type_name: str = None,
        params_config: dict = None,
        is_active: bool = None,
    ) -> bool:
        """
        Update an existing hub endpoint using the API.

        Args:
          hub_schema: The hub schema name
          hub_endpoint_name: Name of the endpoint to update
          hub_view_id: New hub view ID (optional)
          subscription_plan_type_name: New subscription plan type (optional)
          params_config: New configuration for query parameters (optional)
          is_active: Whether the endpoint is active (optional)

        Returns:
          bool: True if successful, False otherwise
        """
        payload = {}

        if hub_view_id is not None:
            payload["hub_view_id"] = hub_view_id
        if subscription_plan_type_name is not None:
            payload["subscription_plan_type_name"] = subscription_plan_type_name
        if params_config is not None:
            payload["params_config"] = params_config
        if is_active is not None:
            payload["is_active"] = is_active

        response = self.session.patch(
            f"{self.base_url}/endpoints/{hub_schema}/{hub_endpoint_name}",
            json=payload,
        )
        self._handle_response(
            response,
            success_message=f"✓ Updated endpoint: {hub_endpoint_name}",
            error_context=f"Update endpoint {hub_endpoint_name}",
        )
        return True

    def list_endpoints(self, hub_schema: str) -> pd.DataFrame:
        """
        List all endpoints for a specific hub and return as a pandas DataFrame.

        Args:
          hub_schema: The hub schema name

        Returns:
          pd.DataFrame: DataFrame containing endpoint metadata including
            params_config

        Raises:
          Exception: If retrieval fails
        """
        response = self.session.get(f"{self.base_url}/endpoints/{hub_schema}")
        response_data = self._handle_response(
            response, error_context=f"List endpoints for hub {hub_schema}"
        )
        endpoints_list = response_data.get("data", [])
        df = pd.DataFrame(endpoints_list)
        print(f"✓ Retrieved {len(df)} endpoints for hub: {hub_schema}")
        return df
