"""Library version."""

VERSION = "2026.1.2"
