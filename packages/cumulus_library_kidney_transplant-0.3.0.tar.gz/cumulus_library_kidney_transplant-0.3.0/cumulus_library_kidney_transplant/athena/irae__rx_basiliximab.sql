create or replace view irae__rx_basiliximab as select * from (values

('http://www.nlm.nih.gov/research/umls/rxnorm','1159396','basiliximab Injectable Product'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1182652','Simulect Injectable Product'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656641','basiliximab 10 MG'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656642','basiliximab Injection'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656643','basiliximab 10 MG Injection'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656644','basiliximab 10 MG [Simulect]'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656645','basiliximab Injection [Simulect]'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656646','Simulect 10 MG Injection'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656647','basiliximab 20 MG'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656648','basiliximab 20 MG Injection'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656649','basiliximab 20 MG [Simulect]'),
('http://www.nlm.nih.gov/research/umls/rxnorm','1656650','Simulect 20 MG Injection'),
('http://www.nlm.nih.gov/research/umls/rxnorm','196102','basiliximab'),
('http://www.nlm.nih.gov/research/umls/rxnorm','219912','Simulect')
) AS t (system,code,display) ;