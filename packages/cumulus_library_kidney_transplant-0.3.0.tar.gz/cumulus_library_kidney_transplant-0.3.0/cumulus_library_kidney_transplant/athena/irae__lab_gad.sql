create or replace view irae__lab_gad as select * from (values

('http://loinc.org','101232-7','Glutamate decarboxylase 65 antibody, Spinal fluid'),
('http://loinc.org','101233-5','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','13926-1','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','30347-9','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','42501-7','Glutamate decarboxylase 65 antibody, Spinal fluid'),
('http://loinc.org','53708-4','Glutamate decarboxylase 65 antibody, Spinal fluid'),
('http://loinc.org','56540-8','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','58451-6','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','72523-4','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','81725-4','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','82658-6','Glutamate decarboxylase antibody, Spinal fluid'),
('http://loinc.org','82660-2','Glutamate decarboxylase antibody, Blood'),
('http://loinc.org','83004-2','Glutamate decarboxylase 65 IgG antibody, Blood'),
('http://loinc.org','90829-3','Glutamate decarboxylase 65 antibody, Spinal fluid'),
('http://loinc.org','94345-6','Glutamate decarboxylase 65 IgG+IgM, Blood'),
('http://loinc.org','94359-7','Glutamate decarboxylase 65 IgG+IgM, Spinal fluid'),
('http://loinc.org','94699-6','Glutamate decarboxylase 65 antibody, Blood'),
('http://loinc.org','94711-9','Glutamate decarboxylase 65 antibody, Spinal fluid')
) AS t (system,code,display) ;