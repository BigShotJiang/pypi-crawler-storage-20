
Changelog
=========

All notable changes to this project will be documented in this file.

The format is based on
`Keep a Changelog`_.

Starting with version 0.0.1, this project implements a version of
`Semantic Versioning`_ described
`here <https://iscinumpy.dev/post/bound-version-constraints/#semver>`_ called
"Realistic" Semantic Versioning.

`0.0.2`_ (2026-01-12)
----------------------

Added
~~~~~

Tasks
+++++

* ``MolecularDynamics`` task

* ``BondScan`` task

* ``ScheduledMixin``: a mixin class for scheduler-enabled tasks

* ``den_fit`` and ``fitting_basis`` parameters for :class:`.GaussianJob`

Harvest
+++++++

* ``GPAW`` harvester

Task/Study (Group)
++++++++++++++++++

* Support for creating study/task group/task directories using name templates
  in ``StudyGroup.to_directory``, ``Study.to_directory``, ``autojob advance``,
  and ``autojob next``

* ``autojob new``: creating unstructured task directories with metadata

Other
+++++

* ``autojob clean`` CLI: clean up the directory of a completed task

* ``autojob config-gen`` CLI: automatic configuration file generation from
  ``autojob`` defaults

* ``autojob new`` CLI: tool for creating unstructured task, task group,
  study, and study group directories.

* ``autojob.utils.parsing.parse_time_from_slurm_script`` function

* ``SchedulerInputs.ntasks_per_node`` and ``SchedulerInputs.cpus_per_task``

* :func:`autojob.utils.files.create_templated_dir_name`

Changed
~~~~~~~

Tasks
+++++

* ``Calculation`` tasks obtain their scheduler properties from ``ScheduledMixin``

* Task/Calculation script writing methods (e.g. :meth:`.Task.write_task_script` and
  :meth:`.Calculation.write_task_script`) no longer accept variadic
  keyword arguments

* :attr:`.CalculationInputs.opt_params` defaults to an empty dictionary

* :meth:`Calculation.write_calculation_script`:

  * The ``template`` and ``structure_name`` arguments have been removed
  * The ``additional_data`` argument has been added
  * Templates are rendered with the output of ``Calculation.model_dump`` plus
    any additional data (the structure name and calculator name/parameters
    must be accessed accordingly)

* :meth:`Task.write_task_script`:

  * Templates are rendered with the output of ``Task.model_dump`` plus
    any additional data

* :meth:`.Calculation.write_inputs_json` no longer accepts variadic keyword
  arguments

* :meth:`.Task.write_inputs_json` no longer accepts variadic keyword
  arguments

Settings
++++++++

* Default settings:

  * ``ARCHIVE_FILE="archive.json"``
  * ``TASK_METADATA_FILE="task.json"``
  * ``TASK_GROUP_METADATA_FILE="task_group.json"``

HPC
+++++

* Renamed ``scheduler_script_template`` argument of ``template_script`` to
  ``script_template``

* ``SchedulerOutputs.state`` is set to ``JobState.UNK`` if None.

* ``autojob.hpc.convert`` was moved to :mod:`autojob.utils.parsing`

* ``SchedulerInputs.cores_per_node`` renamed to ``SchedulerInputs.ntasks_per_node``
  to match SLURM parameter name


Other
+++++

* configuration for ``autojob`` is expected under the ``[tool.autojob]`` table
  in `.toml` configuration files

* ``autojob.cli`` renamed to ``autojob._cli``

* CLI commands are all defined in ``autojob._cli``

* ``submit_new_task`` requires a ``task_script`` argument

* ``Study.to_directory`` and ``StudyGroup.to_directory`` return the newly
  created directory's path

* ``autojob run`` now accepts a command instead of a script

Fixed
~~~~~

* The correct command name is now shown for ``autojob clean -h``

* Study directories created with ``StudyGroup.to_directory`` are now correctly
  created as immediate children of the parent study group directory.

* The input atoms object is no longer written to the inputs JSON

* The SLURM time limit is correctly parsed from the option value to
  ``autojob run --time-source``

* The CLI will not fail if ``tkinter`` is not available

* The value of ``strict_mode`` passed to ``MolecularDynamics.from_directory``
  is now passed to ``MDOutputs.from_directory``

* ``autojob.harvest.harvest.harvest`` no longer raises a KeyError when
  harvesting from an archive file in a task directory not named according
  to its task ID

* archiving tasks as CSV files with :func:`.archive`

* Input atoms for a task are now always written to the value of
  ``Task.task_inputs.atoms_filename``

* various bugs with using ``autojob coordinator``

* serialization of ``numpy`` arrays in :attr:`CalculationOutputs.calculator_results`

* the ``autojob`` CLI no longer fails when ``tkinter`` is missing for commands other
  than ``autojob coordinator``

Removed
~~~~~~~

* Settings:

  * ``TASK_SCRIPT``: use ``CalculationInputs.calculation_script``
  * ``SLURM_SCRIPT``: use ``TaskInputs.task_script``

* ``SchedulerInputs.cores_per_node``

`0.0.1`_ (2025-12-02)
---------------------

Added
~~~~~

Task/Study (Group)
++++++++++++++++++

* :class:`autojob.bases.task_base`: An abstract base class for tasks;
  :class:`Task` and :class:`Calculation` have been re-written as subclasses
  with necessary `write_inputs` and `from_directory` methods

* :mod:`autojob.tasks`: a namespace package for pre-defined concrete
  ``TaskBase`` implementations

* :meth:`.tasks.Task.write_task_script`: write the task script

* :meth:`.tasks.Calculation.write_task_script`: write the task script; this
  replaces ``Calculation.write_slurm_script``

* :meth:`.tasks.Calculation.write_calculation_script`: write the
  calculation script

* Removed ``use_cache`` argument from `Task.from_directory` and
  `Calculation.from_directory`

* :attr:`.TaskOutcome.UNKNOWN` and comprehensive description of
  :class:`.task_Base.TaskOutcome`

* :meth:`autojob.study.Study.to_directory` and
  :meth:`autojob.study.Study.from_directory`: utility functions for study
  directories

* :meth:`.study_group.StudyGroup.to_directory` and
  :meth:`.study_group.StudyGroup.from_directory`

* Custom serialization for writing :class:`autojob.study.Study` metadata files

* Re-added the cpu2021-bf05 partition (see the commit message from
  :gitref:`85c4092980e01963586702c2f4ee443f0313244a` for details)

* :class:`autojob.hpc.JobState`: SLURM-specific job states

Coordinator
+++++++++++

* :attr:`autojob.coordinator.coordinator.Coordinator.ase_calculator`: a
  property for getting the ASE calculator corresponding to the CalculatorType

* :func:`autojob.coordinator.coordinator.submission_parameters_to_scheduler_inputs`:
  convert the submission parameters as represented in the GUI to
  :class:`autojob.hpc.SchedulerInputs`

* :mod:`autojob.coordinator.filters`: Utilities for filtering parameter
  dictionaries by their values

* :class:`autojob.coordinator.gui.gui.CoordinatorTabs`: a
  :class:`TypedDict` representing the GUI notebook tabs

* :class:`autojob.coordinator.gui.job_submission.JobSubmissionParameters`: a
  :class:`TypedDict` representing the GUI defined scheduler inputs

* :meth:`autojob.coordinator.gui.groups.CalculationParameterGroup.get_sets`:
  get all permutations of the parameter values specified in a
  :class:`autojob.coordinator.gui.groups.CalculationParameterGroup`

* ``--dest`` CLI option for ``autojob coordinator``

Harvest
++++++++

* ``--dest`` CLI option for ``autojob harvest``,
  :func:`autojob.harvest.harvest.harvest`,
  and :func:`autojob.harvest.archive.archive`

* support for Quantum Espresso

* progress bar for harvesting calculations with
  :func:`autojob.harvest.harvest.harvest`

* :mod:`autojob.harvest.harvesters`: a namespace package with pre-defined
  harvesters (VASP, gaussian, espresso, DDEC6, bader, default)

next
++++

* ``autojob restart`` CLI

* ``autojob.next.advance`` and ``autojob.next.restart``

* ``autojob.parametrizations.create_parametrization``

Other
++++++

* The plugin interface for tasks, harvesters, and analyses

* :mod:`autojob.legacy`: legacy mode classes/functions

* :func:`autojob.parametrizations.getattrpath`

* Several settings: see :class:`AutojobSettings`

* :func:`autojob.utils.get_loader`: replacement for
  :meth:`autojob.coordinator.scripter.Scripter.get_loader`

* ``autojob.utils.get_last_updated``

* ``autojob.utils.copy_file_permissions_and_ownership``

* ``autojob.utils.schemas.id_factory``

Changed
~~~~~~~

Task/Study (Group)
++++++++++++++++++

* major refactor of ``Task`` and subclasses to adhere to the :class:`TaskBase`
  abstract base class

* ``magmoms`` are retrieved from the calculator ``results`` dictionary instead
  of with :meth:`ase.atoms.Atoms.get_magnetic_moments` in
  :meth:`.Task.prepare_input_atoms`

* ``.TaskMetadata._build_class`` changed to
  ``autojob.bases.task_base.TaskMetadataBase.task_class``

* Moved ``.patch_task`` to :class:`autojob.calculation.calculation.Calculation`

* Job stats files are created newly every time and are now JSON files

* :attr:`autojob.task.TaskOutputs.outcome` is set in calculation according to
  convergence and :attr:`autojob.hpc.SchedulerOutputs.state`

* :class:`autojob.study.Study` and :class:`autojob.study_group.StudyGroup`
  implemented as Pydantic ``BaseModel``

* :class:`autojob.study.StudyType` moved to :class:`autojob.legacy` module

* Task metadata is now **only** read from the job file (set by
  ``SETTINGS.TASK_METADATA_FILE``)

* copy metadata from input atoms in ``Calculation.patch_task``

* ``autojob.task`` re-implemented in ``autojob.tasks.task``

Coordinator
+++++++++++

* Job directories are created using :meth:`autojob.study_group.StudyGroup.to_directory`

* :attr:`.SchedulerOutputs.partition` is typed and validated as a string

* ``autojob.calculation.parameters`` moved to ``autojob.coordinator``

Harvest
+++++++

* :func:`autojob.harvest.patch.build_metadata_patches` implements a "Strategy"
  design pattern to enable applicability for all types of metadata

* ``autojob.harvest.charge`` implemented as ddec6 and bader harvesters

* the ``whitelist`` and ``blacklist`` arguments to ``autojob harvest`` and
  :func:`~autojob.harvest.harvest.harvest` are renamed to ``whitelists`` and
  ``blacklists`` in better agreement with their implementations

* ``ElementaryStep`` renamed to
  :class:`autojob.harvest.mechanism.ElectrochemicalStep`; stoichiometric
  coefficient added as attribute

* all new calculation outputs returned in ``flatten_calculations``

* DOS can be optionally retained when harvesting VASP calculations

next
++++

* :meth:`autojob.parametrizations.VariableReference.set_input_value` accepts
  both an object in addition to a mapping for ``shell``

Other
+++++

* :func:`autojob.utils.parsing.parse_job_stats_file` raises a ``DeprecationWarning``
  if an old ``job_stats.txt`` file is parsed

* the names of several ``autojob`` settings have been changed

* ``reorder_vasp_sequence`` moved to utils

* ``autojob run`` CLI

* all templates but for new, simplified templates ``run.py.j2`` and
  ``run.sh.j2``

* directory finders (e.g., ``find_study_dirs``) identify directories by the
  presence of metadata files

* ``find_job_dirs`` renamed to ``find_task_dirs``

* ``find_calculation_dirs`` renamed to ``find_task_group_dirs``

* ``substitute_placeholders`` accepts regular Python format strings

* add defaults for fields for ``autojob.workflow.Step``

Fixed
~~~~~

Task/Study (Group)
++++++++++++++++++

* Pydantic warnings emitted when calling :meth:`.SchedulerInputs.model_dump`
  (see :gitref:`fda0e7eb7c3af3f3e9f7772fc9f04b15e9ccc851`)

* :attr:`.task.TaskMetadata.calculation_type`,
  :attr:`.task.TaskMetadata.calculator_type`,
  and :attr:`.task.TaskMetadata.study_type` are serialized as None when None

* :class:`~autojob.hpc.SchedulerOutputs` now correctly recognizes `"Partition"`
  as an alias for :attr:`.SchedulerOutputs.partition`

* :class:`~autojob.hpc.SchedulerInputs` are now included in the result of
  :func:`~autojob.harvest.archive.flatten_calculations`

Harvest
+++++++

* All DDEC6 charge data is loaded instead of a subset, if present

* :meth:`autojob.parametrizations.VariableReference.set_input_value` previously
  (and incorrectly) checked the type of ``shell`` to decide how to set and
  delete attributes/keys, resulting in attempting to set nonexistent attributes
  on a dictionary

* :func:`~autojob.next.relaxation.restart_relaxation` properly handles calc
  and slurm mods

* :class:`autojob.calculation.charge.BaderAnalysis` schema now matches that of
  :attr:`pymatgen.command_line.bader_caller.BaderAnalysis.summary`

Other
+++++

* ``Atoms`` objects that are serialized with ``BaseModel.model_dump`` are
  serialized as ``Atoms`` objects if ``mode="python"`` and as dictionaries
  otherwise

Removed
~~~~~~~

Task/Study (Group)
++++++++++++++++++

* :class:`autojob.study.StudyType`: ``study_type`` will only be a field name
  for legacy mode

* ``Calculation.write_input_atoms``: use :meth:`autojob.task.Task.write_inputs`

* ``Calculation.to_directory``: use :meth:`autojob.task.Task.to_directory`

* ``autojob.study.TASK_FILES``

* ``StudyGroup.as_dict``, ``StudyGroup.from_dict``, ``StudyGroup.from_path``,
  ``StudyGroup.create_directory``, ``StudyGroup.addstudies``,
  ``StudyGroup.removestudies`` and ``StudyGroup.studies`` property

* ``SchedulerOutputs.error``: all scheduler information is recorded in
  :attr:`autojob.hpc.SchedulerOutputs.state`

* :meth:`.task.TaskInputs.extract_files_to_copy`

* :meth:`.calculation.Calculation.write_python_script`

* ``autojob.hpc.Cluster`` and all instances

* ``autojob.hpc.SchedulerError``

* ``autojob.next.update_metadata_file``

* ``legacy_mode`` arguments from most functions/methods

Coordinator
+++++++++++

* :mod:`autojob.coordinator.scripter`: script writing handled by
  :meth:`autojob.task.Task.write_inputs`

Harvest
+++++++

* :func:`autojob.harvest.patch.build_calculation_patches`: use
  :func:`autojob.harvest.patch.build_metadata_patches` with
  ``metadata_type="calculation"``

* :func:`autojob.harvest.patch.build_study_patches`: use
  :func:`autojob.harvest.patch.build_metadata_patches` with
  ``metadata_type="study"``

* ``autojob.harvest.structure``

next
++++

* ``autojob.advance`` and ``autojob.cli.advance`` (CLI logic is contained
  in ``autojob.next.advance``)

* ``restart-relaxation`` and ``run-vibration`` CLIs and related modules
  ``autojob.next.restart_relaxation`` and ``autojob.next.run_vibration``

Other
++++++

* `autojob.advance.advance.write_calculation_metadata`

* ``autojob.schemas``: charge data consolidated in
  :mod:`autojob.calculation.charge`

* ``autojob.calculation`` sub-package

* ``autojob.utils.extract_structure_name``

* ``autojob.utils.parsing.import_class``

`0.0.1a37`_ (2024-08-21)
------------------------

Added
~~~~~

* ``LORBIT`` Vasp INCAR tag to :mod:`autojob.coordinator.vasp`

* support for Gaussian-powered calculations

* support for custom Python script templates

* default template for infrared calculations

* New modules:

  * :mod:`autojob.utils`

  * :mod:`autojob.advance`: incremental job control

  * :mod:`autojob.harvest`: data assimilation convenience functions & CLI

    * :mod:`autojob.harvest.harvest`: utilities for harvesting task data

    * :mod:`autojob.harvest.patch`: utilities for patching task data

  * :mod:`autojob.cli.restart_relaxation`,
    :mod:`autojob.next.relaxation` and corresponding CLI command
    `restart-relaxation`

  * :mod:`autojob.cli.run_vibration`,
    :mod:`autojob.next.vibration` and corresponding CLI command
    `run-vibration`: create metadata preserving thermodynamic calculation
    directories

  * :mod:`autojob.cli.init`: enable shell completion for ``autojob``

  * :mod:`autojob.task`

  * :mod:`autojob.workflow`

  * :mod:`autojob.study`, :mod:`autojob.study_group`, :mod:`autojob.hpc`,
    :mod:`autojob.settings`, :mod:`autojob.schemas`,
    :mod:`autojob.parametrizations`

  * :mod:`autojob.calculation`: representations/manipulation of calculation
    data

  * :mod:`autojob.coordinator.gaussian`

* New dependencies:

  * `Pydantic`_ & `pydantic-settings`: for data validation/data model

  * `cclib`: for calculation output parsing

Changed
~~~~~~~

* Deprecated modules:

  * :mod:`autojob.coordinator.calculation`: use :mod:`autojob.calculation`

  * :mod:`autojob.coordinator.classification`: use :mod:`autojob.calculation`

  * :mod:`autojob.coordinator.job`: use :mod:`autojob.calculation`

  * :mod:`autojob.coordinator.study`: use :mod:`autojob.study`

  * :mod:`autojob.coordinator.validation`: use :mod:`autojob.utils`

  * :mod:`autojob.coordinator.vasp`: use :mod:`autojob.calculation.vasp`

* ``vasp.sh`` template no longer removes wildcard files upon cleaning up the
  scratch directory

* Switched to Hatch for build backend and testing (no more Poetry/tox)

* :mod:`autojob.cli.restart`: move to :mod:`autojob.next`

* Dropped support for Python <3.10

* Python and SLURM script templates

* Minimum ``ccu`` dependency is v0.0.5

Removed
~~~~~~~

* :mod:`autojob.accountant` and :mod:`autojob.auditor` have been removed in
  favour of using Pydantic for validation and deserialization

* :mod:`autojob.coordinator.arc` has been removed; use :mod:`autojob.hpc`
  instead

* :mod:`autojob.coordinator.calculation` has been removed; use
  :mod:`autojob.calculation` and :mod:`autojob.task` instead

* :mod:`autojob.coordinator.study` has been removed; use :mod:`autojob.study`
  instead

* :class:`autojob.coordinator.submission_configuration.ParameterSelectionCombobox`
  has been removed

* :mod:`autojob.utils.validate_id` has been removed

`0.0.1a36`_ (2022-12-02)
------------------------

Added
~~~~~

* :mod:`autojob.details`

Removed
~~~~~~~

* :func:`.findfile.find_details`

* :func:`.findfile.infer_details`

* :func:`.findfile.determine_entry_type`

* :func:`.findfile.find_studies`

`0.0.1a35`_ (2022-12-01)
------------------------

Added
~~~~~

* ``AMIX``, ``AMIX_MAG``, ``BMIX``, ``BMIX_MAG``, ``IMIX`` Vasp INCAR tags to
  :mod:`autojob.coordinator.vasp`

* :class:`~autojob.coordinator.vasp.VaspError`

* :func:`.findfile.get_slurm_job_id`

* :func:`.findfile.find_last_submitted_jobs`

Changed
~~~~~~~

* :class:`~xml.etree.ElementTree.ParseError`s are caught by
  :meth:`.Restarter.characterize_jobs`

* Default buffer time (i.e., time that a Vasp calculation is stopped prior to
  the actual end time) is increased from 5% to 10%

* :func:`.findfile.find_template_dir` renamed to
  :func:`.findfile._find_template_dir`
  (i.e., made private to module)

Fixed
~~~~~

* Parsing of structure name in
  :meth:`.Restarter.create_restart_jobs`

* New job names returned by
  :meth:`.Restarter.create_restart_jobs` instead of old job names

`0.0.1a34`_ (2022-11-28)
------------------------

Added
~~~~~

* docstrings for :mod:`autojob.accountant.parsing` functions

* Optional keyword argument parameter (``with_wavecar``) to
  :meth:`autojob.cli.restart.Restarter.create_restart_jobs`

* Optional inclusion of ``WAVECAR`` in restarted jobs from
  ``autojob restart``

* :meth:`autojob.cli.restart.Restarter.characterize_jobs`

Changed
~~~~~~~

* study group ID, study ID, calculation ID, and job ID included in
  :class:`.accountant.AccountingError` raised by
  :func:`.parsing.parse_job_results`

* ``gamma`` key added to first dictionary returned by
  :func:`.parsing.parse_job_results`

* Different printing of not added study groups in
  :meth:`.Accountant.create_study_group`, :meth:`.Accountant.create_study`,
  :meth:`.Accountant.create_calculation` depending on verbosity

* :meth:`.Accountant.create_study_group`, :meth:`.Accountant.create_study`,
  :meth:`.Accountant.create_calculation` print unknown errors to console

Fixed
~~~~~

* values argument to :class:`.job.CalculationParameter` for ``LDAUTYPE`` and
  ``NSW``

`0.0.1a33`_ (2022-11-22)
------------------------

Changed
~~~~~~~

* Memory limit specified per core instead of per node

Fixed
~~~~~

* rendering of k-pts in ``run.py``


`0.0.1a32`_ (2022-11-15)
------------------------

Added
~~~~~

* Option to format the ``vasp.sh`` for running on ComputeCanada clusters

Removed
~~~~~~~

* removed support for dictionaries in
  :func:`.validation.iter_to_native`

`0.0.1a31`_ (2022-11-14)
------------------------

Added
~~~~~

* :func:`.validation.iter_to_native` supports dictionaries

Changed
~~~~~~~

* :class:`autojob.coordinator.gui.groups.CalculationParameterGroup` stores
  values as native Python values instead of strings

Fixed
~~~~~

* Fixed issue with distinguishing calculation parameters in submission
  parameter tab


`0.0.1a30`_ (2022-11-12)
------------------------

Added
~~~~~

* Add docstrings for :func:`.findfile.find_study_group_dirs`,
  :func:`.findfile.find_study_dirs`,
  :func:`.findfile.find_calculation_dirs`, and
  :func:`.findfile.find_job_dirs`

* docstrings for :class:`~autojob.auditor.auditor.Auditor`

* :meth:`.Auditor.audit`

* :meth:`.Auditor.format`

* :meth:`.Auditor.prune`

* :meth:`.Auditor.prune_calculation_directories`

* ``autojob auditor`` CLI subcommands (`add`, `format`, `prune`)

* `Jinja2`_ dependency

Changed
~~~~~~~

* render `run.py` and `vasp.sh` using Jinja2 templates

`0.0.1a29`_ (2022-11-12)
------------------------

Changed
~~~~~~~

* The structure name for a restart job is determined from the `run.py` file

`0.0.1a28`_ (2022-11-06)
------------------------

Added
~~~~~

* outline of :mod:`autojob.auditor` subpackage

Changed
~~~~~~~

* :meth:`.JobStats.parse_max_rss` parses memory
  appropriately according to units

* `dest` variable not passed to
  :meth:`.Accountant.export`

Fixed
~~~~~

* :meth:`.Accountant.add` now correctly calls :meth:`.Accountant.create_study`
  instead of :meth:`.Accountant.create_study_group`

* :meth:`.Accountant.export` no longer passes `dest` as positional argument to
  :meth:`.Accountant._export_jobs`, :meth:`.Accountant._export_calculations`,
  :meth:`.Accountant._export_studies`, and
  :meth:`.Accountant._export_study_groups`

* :func:`.parsing.parse_job_results` handles :class:`IndexError` from
  parsing `vasprun.xml`

`0.0.1a27`_ (2022-10-18)
------------------------

Removed
~~~~~~~

* `pymongo` dependency

`0.0.1a26`_ (2022-10-18)
------------------------

Changed
~~~~~~~

* `--memory-scale` CLI option for `autojob restart` was renamed to
  `--memory-multiplier`

Fixed
~~~~~

* `autojob restart` now prints the new job ID instead of the old ID when
  listing newly created jobs

`0.0.1a25`_ (2022-10-17)
------------------------

Changed
~~~~~~~

* `autojob restart` prints all newly created jobs

* New memory requirements are printed with the 'GB' suffix

Fixed
~~~~~

* the correct directories were not found due to the regex used in
  :func:`.findfile.find_study_group_dirs`, :func:`.findfile.find_study_dirs`,
  :func:`.findfile.find_calculation_dirs`, and :func:`.findfile.find_job_dirs`

* the `vasp.sh` file is now correctly opened instead of attempting to open
  the old job directory

`0.0.1a24`_ (2022-10-17)
------------------------

Added
~~~~~

* docstring added for :meth:`.TreeviewFrame.clear_treeview`

* docstrings added for :mod:`autojob.coordinator.gui.submission_configuration`

Changed
~~~~~~~

* :meth:`.Coordinator.calc_params_for` and
  :meth:`.Coordinator.calc_param_values_for` accept a list of
  :class:`~pathlib.Path`s for the `structures` parameters instead of a list of
  strings

* :meth:`.Coordinator.structure_groups_with` accepts an iterable of
  :class:`pathlib.Path`s for the `structures` parameters instead of an
  iterable of strings

Removed
~~~~~~~

* :class:`~autojob.coordinator.gui.submission_configuration.ParameterSelectionPanel`

`0.0.1a23`_ (2022-10-17)
------------------------

Changed
~~~~~~~

* Restart jobs are printed as `calculationID/newjobID`

`0.0.1a22`_ (2022-10-17)
------------------------

Changed
~~~~~~~

* Logic of `autojob restart` moved into
  :class:`autojob.cli.restart.Restarter` class

`0.0.1a21`_ (2022-10-17)
------------------------

Added
~~~~~

* :func:`autojob.accountant.findfile.find_study_group_dirs`

* :func:`autojob.accountant.findfile.find_study_dirs`

* :func:`autojob.accountant.findfile.find_calculation_dirs`

* :func:`autojob.accountant.findfile.find_job_dirs`

* :func:`autojob.accountant.findfile.find_template_dir`

`0.0.1a20`_ (2022-10-16)
------------------------

Changed
~~~~~~~

* `autojob restart` (and related API functions) support scaling the memory
  limit in the restart job and changing the verbosity


`0.0.1a19`_ (2022-10-13)
------------------------

Added
~~~~~

* User can elect to update database entries instead of overwrite when using
  `autojob accountant add`, using the `-u`CLI option, or
  :meth:`autojob.accountant.accountant.Accountant.add` by setting the
  `update` attribute to `True`

Changed
~~~~~~~

* Formatting of filename returned by
  :func:`autojob.accountant.findfile.get_filename`

* `autojob accountant add` prints added entries by default

* Long CLI options for specifying export files with `autojob accountant add`
  have double hyphen prefixes

`0.0.1a18`_ (2022-10-13)
------------------------

Added
~~~~~

* :func:`autojob.accountant.findfile.get_filename`

* CLI option `--dest` for `autojob accountant export` subcommand

* User can specify filenames to output `.csv` files for jobs, calculations,
  studies, and study groups with `-jf`, `-cf`, `-sf`, and `-gf` CLI options,
  respectively

* verbose option (`-v`) added for `autojob accountant export` subcommand

Changed
~~~~~~~

* :func:`autojob.accountant.parsing.parse_job_results` raises
  :class:`~autojob.accountant.AccountingError` if no valid `vasprun.xml` found

* :func:`autojob.accountant.accountant.export` has new positional arguments
  `dest` and `filenames`

`0.0.1a17`_ (2022-10-13)
------------------------

Changed
~~~~~~~

* The job ID of the source job is recorded in the `job.json` file of the
  restart job by :mod:`autojob.cli.restart`

`0.0.1a16`_ (2022-10-13)
------------------------

Changed
~~~~~~~

* :meth:`.ParameterSelectionTab.calc_params` values are
  :class:`~autojob.coordinator.gui.groups.CalculationParameterGroup`'s

* values in dictionary return by
  :meth:`.ParameterSelectionTab.load_calc_params` are
  :class:`~autojob.coordinator.gui.groups.CalculationParameterGroup`'s

Fixed
~~~~~

* `bool` values are cast correctly in
  :class:`~autojob.coordinator.gui.parameter_selection.ParameterSelectionTab`


`0.0.1a15`_ (2022-10-12)
------------------------

Fixed
~~~~~

* :class:`AttributeError` due to calling `extend` method of values parameter
  passed to :meth:`.CalculationParameterGroup.add_values` by
  :meth:`.ParameterPanel.add_parameter_values`

`0.0.1a14`_ (2022-10-12)
------------------------

Changed
~~~~~~~

* Jobs that are not added to database by
  :func:`autojob.accountant.accountant.add` are printed out

* :class:`.accountant.AccountingError` raised if
  :func:`.parsing.parse_job_results` unable to parse `vasprun.xml`
  file twice


`0.0.1a13`_ (2022-10-12)
------------------------

Added
~~~~~

* DFT+U and magnetization :class:`CalculationParameter`s in
  :mod:`autojob.coordinator.vasp`

Changed
~~~~~~~

* :class:`FileNotFoundError` is handled by
  :func:`autojob.cli.restart.create_restart_calculation`

`0.0.1a12`_ (2022-10-11)
------------------------

Added
~~~~~

* :meth:`autojob.coordinator.groups.CalculationParameterGroup.defined_values`

* :meth:`.CalculationParameterGroup.defined_calculation_parameters`

* :class:`~autojob.coordinator.groups.SubmissionParameterGroup`

* :mod:`autojob.cli.restart` and correspondind CLI subcommand

Fixed
~~~~~

* Duplicate :class:`CalculationParameter`s in
  :class:`CalculationParameterGroup`

* Extra argument supplied to `load` methods of tabs

* Return value from :meth:`.SelectionFrame.structures`
  is now a list of strings instead of a list of :class:`pathlib.Path`'s

Removed
~~~~~~~

* :meth:`.Coordinator.next_calc_params`

`0.0.1a11`_ (2022-10-09)
------------------------

Added
~~~~~

* Version option for CLI

`0.0.1a10`_ (2022-10-09)
------------------------

Added
~~~~~

* :mod:`autojob.coordinator.gui.groups`

Changed
~~~~~~~

* :class:`~autojob.coordinator.gui.job_submission.JobSubmissionTab`,
  :class:`~autojob.coordinator.gui.parameter_selection.ParameterSelectionTab`,
  :class:`~autojob.coordinator.gui.structure_selection.StructureSelectionTab`,
  :class:`~autojob.coordinator.gui.study_configuration.StudyConfigurationTab`,
  :class:`~autojob.coordinator.gui.submission_configuration.SubmissionConfigurationTab`, and
  :class:`~autojob.coordinator.gui.summary.SummaryTab`
  constructors no longer require `notebook` parameter

* :class:`autojob.coordinator.job.InputParameter` renamed to
  :class:`~autojob.coordinator.job.CalculationParameter`


`0.0.1a9`_ (2022-09-30)
-----------------------

Added
~~~~~

* docstrings for :meth:`.Accountant.add` call stack


`0.0.1a8`_ (2022-09-28)
-----------------------

Added
~~~~~

* :func:`autojob.accountant.accountant.export` is implemented in API and CLI

Changed
~~~~~~~

* `as_dict`, `as_flat_dict`, and `from_dict` moved from must be
  implemented by subclasses (e.g., :class:`autojob.coordinator.vasp.VaspJob`)

* structure-related keys in `input_parameters` return value from
  `autojob.accountant.parsing`

* the dictionary return from :meth:`.Calculation.as_dict` includes the keys
  `@module` and `@class`

`0.0.1a7`_ (2022-09-28)
-----------------------

Added
~~~~~

* `Inputs`, `Outputs`, `@module`, `@class` keys in return value dictionary in
  :meth:`.Job.as_dict`

Removed
~~~~~~~

* `k-pts`, and `Results` keys in return value dictionary in
  :class:`.Job.as_dict`

`0.0.1a6`_ (2022-09-26)
-----------------------

Added
~~~~~

* CLI with `coordinator` and `accountant` subcommands

* :class:`~autojob.accountant.findfile.DetailEncoder`

* :class:`~autojob.coordinator.job.JobStats`

* :meth:`.Partition.from_name`

* :func:`.parsing.match_xml_tags`

* :func:`.parsing.parse_job_results`

* :meth:`.Job.as_dict`

* :meth:`.Calculation.as_dict`

* :meth:`Study.as_dict <autojob.coordinator.study.Study.as_dict>`

* :meth:`StudyGroup.as_dict <autojob.coordinator.study_group.StudyGroup.as_dict>`

* :meth:`.Accountant.create_study_group`

* :meth:`.Accountant.create_study`

* :meth:`.Accountant.create_calculation`

* :meth:`.Accountant.create_job`

* :meth:`.Accountant.load_db`

* :meth:`.Accountant.add_to_database`

* :class:`~autojob.coordinator.job.Job` accepts `None` for `results`
  and `job_stats` parameters

Changed
~~~~~~~

* :class:`~autojob.coordinator.main.MainApplication` renamed to
  :class:`~autojob.coordinator.gui.GUI`

* `strict` parameter renamed to `update` in
  :mod:`autojob.accountant.accountant`

* :mod:`autojob.accountant.accountant` CLI methods moved to
  :mod:`autojob.accountant.cli`

* :class:`~autojob.coordinator.calculation.Calculation` accepts a list of
  strings instead of a list of :class:`~autojob.coordinator.job.Job`'s

* :class:`~.autojob.coordinator.study.Study` accepts a list of strings instead
  of a list of :class:`~autojob.coordinator.calculation.Calculation`'s

* :class:`~autojob.coordinator.study.StudyGroup` accepts a list of strings
  instead of a list of :class:`~autojob.coordinator.study.Study`'s

* :class:`~autojob.coordinator.classification.CalculationType`,
  :class:`~autojob.coordinator.classification.CalculatorType`,
  :class:`~autojob.coordinator.classification.StudyType` do not capitalize
  `__str__` return value

* :class:`~autojob.accountant.accountant.Accountant` constructor requires three
  positional arguments (`exclusive`, `update`, `verbose`)

* `exclusive`, `update`, `verbose` are stored as instance attributes of
  :class:`~autojob.accountant.accountant.Accountant` objects and are no longer
  passed as arguments to :meth:`.Accountant.add`

* :func:`autojob.accountant.parsing.parse_job_stats_file` raises
  :class:`~autojob.accountant.AccountingError` is unable to parse job stats
  file

* :func:`.parsing.parse_job_stats_file` raises `ValueError` is headers missing
  in job stats file

* :class:`~autojob.coordinator.job.Job` properties changed to attributes

* :attr:`.Study.study_type` property changed to attribute

* :attr:`.StudyGroup.date_created` property changed to attribute

* :class:`~autojob.coordinator.calculation.Calculation` properties
  (except `job`) changed to attributes

`0.0.1a5`_ (2022-09-13)
-----------------------

Added
~~~~~

* `isym` as a vasp parameter

Changed
~~~~~~~

* Properties of :class:`~autojob.coordinator.coordinator.Coordinator` are no
  longer cached


`0.0.1a4`_ (2022-09-12)
-----------------------

Added
~~~~~

* :mod:`autojob.accountant`

* :mod:`autojob.coordinator.scripter`

* :class:`monty.json.MSONable` methods to
  :class:`~autojob.coordinator.calculation.Calculation`,
  :class:`~autojob.coordinator.job.Job`,
  :class:`~autojob.coordinator.study.Study`, and
  :class:`~autojob.coordinator.study.StudyGroup`

Changed
~~~~~~~

* Refactored tests

* Moved package to `src/` directory

* scripting capabilities located in :mod:`autojob.coordinator.scripter`

`0.0.1a3`_ (2022-09-08)
-----------------------

Removed
~~~~~~~

* `pymatgen-db`, `acat`, `wulffpack`, `scipy`, `pandas`
  dependencies

Changed
~~~~~~~

* The list containing GUI pages has been re-implemented as a dictionary

`0.0.1a2`_ (2022-09-07)
-----------------------

Added
~~~~~

* The Job Submission tab allows for different submission parameters
  for each :class:`~autojob.coordinator.gui.groups.ParameterGroup`

* :class:`~autojob.coordinator.gui.job_submission.JobSubmissionTab`

* :mod:`autojob.coordinator.gui.submission_configuration`

* Structure groups

* :class:`~autojob.coordinator.gui.widgets.TreeviewFrame`

* :func:`.validation.val_to_native`

* :func:`.validation.iter_to_native`

* Summary Tab in GUI

* :mod:`autojob.coordinator.coordinator`

Changed
~~~~~~~

* Refactor :mod:`autojob.coordinator.gui.parameter_selection`

`0.0.1a1`_ (2022-09-02)
------------------------

* First version.

.. _0.0.2: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1...v0.0.2?from_project_id=39386367&straight=true
.. _0.0.1: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a37...v0.0.1?from_project_id=39386367&straight=true
.. _0.0.1a37: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a36...v0.0.1a37?from_project_id=39386367&straight=true
.. _0.0.1a36: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a35...v0.0.1a36?from_project_id=39386367&straight=true
.. _0.0.1a35: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a34...v0.0.1a35?from_project_id=39386367&straight=true
.. _0.0.1a34: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a33...v0.0.1a34?from_project_id=39386367&straight=true
.. _0.0.1a33: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a32...v0.0.1a33?from_project_id=39386367&straight=true
.. _0.0.1a32: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a31...v0.0.1a32?from_project_id=39386367&straight=true
.. _0.0.1a31: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a30...v0.0.1a31?from_project_id=39386367&straight=true
.. _0.0.1a30: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a29...v0.0.1a30?from_project_id=39386367&straight=true
.. _0.0.1a29: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a28...v0.0.1a29?from_project_id=39386367&straight=true
.. _0.0.1a28: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a27...v0.0.1a28?from_project_id=39386367&straight=true
.. _0.0.1a27: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a26...v0.0.1a27?from_project_id=39386367&straight=true
.. _0.0.1a26: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a25...v0.0.1a26?from_project_id=39386367&straight=true
.. _0.0.1a25: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a24...v0.0.1a25?from_project_id=39386367&straight=true
.. _0.0.1a24: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a23...v0.0.1a24?from_project_id=39386367&straight=true
.. _0.0.1a23: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a22...v0.0.1a23?from_project_id=39386367&straight=true
.. _0.0.1a22: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a21...v0.0.1a22?from_project_id=39386367&straight=true
.. _0.0.1a21: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a20...v0.0.1a21?from_project_id=39386367&straight=true
.. _0.0.1a20: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a19...v0.0.1a20?from_project_id=39386367&straight=true
.. _0.0.1a19: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a18...v0.0.1a19?from_project_id=39386367&straight=true
.. _0.0.1a18: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a17...v0.0.1a18?from_project_id=39386367&straight=true
.. _0.0.1a17: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a16...v0.0.1a17?from_project_id=39386367&straight=true
.. _0.0.1a16: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a15...v0.0.1a16?from_project_id=39386367&straight=true
.. _0.0.1a15: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a14...v0.0.1a15?from_project_id=39386367&straight=true
.. _0.0.1a14: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a13...v0.0.1a14?from_project_id=39386367&straight=true
.. _0.0.1a13: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a12...v0.0.1a13?from_project_id=39386367&straight=true
.. _0.0.1a12: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a11...v0.0.1a12?from_project_id=39386367&straight=true
.. _0.0.1a11: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a10...v0.0.1a11?from_project_id=39386367&straight=true
.. _0.0.1a10: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a9...v0.0.1a10?from_project_id=39386367&straight=true
.. _0.0.1a9: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a8...v0.0.1a9?from_project_id=39386367&straight=true
.. _0.0.1a8: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a7...v0.0.1a8?from_project_id=39386367&straight=true
.. _0.0.1a7: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a6...v0.0.1a7?from_project_id=39386367&straight=true
.. _0.0.1a6: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a5...v0.0.1a6?from_project_id=39386367&straight=true
.. _0.0.1a5: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a4...v0.0.1a5?from_project_id=39386367&straight=true
.. _0.0.1a4: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a3...v0.0.1a4?from_project_id=39386367&straight=true
.. _0.0.1a3: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a2...v0.0.1a3?from_project_id=39386367&straight=true
.. _0.0.1a2: https://gitlab.com/ugognw/python-autojob/-/compare/v0.0.1a1...v0.0.1a2?from_project_id=39386367&straight=true
.. _0.0.1a1: https://gitlab.com/ugognw/python-autojob/-/tree/v0.0.1a1?ref_type=tags

.. _Pydantic: https://docs.pydantic.dev/latest/
.. _Keep a Changelog: https://keepachangelog.com/en/1.0.0/
.. _Semantic Versioning: https://semver.org/spec/v2.0.0.html
.. _Jinja2: https://jinja.palletsprojects.com/en/stable/
