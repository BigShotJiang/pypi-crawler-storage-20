Features
==============

``autojob`` has three main functionalities:

1. :doc:`coordinator <coordinator>` - Codeless workflow design

3. :doc:`harvest <harvest>` - Data aggregation

2. :doc:`next <next>` - Semi-automatic workflow management

``coordinator``
---------------

:mod:`autojob.coordinator` subpackage contains a codeless interface for computational chemistry
workflow design, management, and parallelization. With ``coordinator``, you can design
workflows, parametrize tasks, use custom templates, and dump task inputs to dedicated
directories.

``harvest``
-----------

The :mod:`autojob.harvest` subpackage provides utilities for collecting the
results of completed tasks into structured data model that is suitable
for database storage. All harvested results are collected in
:class:`.task.Task` objects which can be dumped into JSON-able dictionaries
with :meth:`.Task.to_directory`.

``next``
---------

The :mod:`autojob.next` subpackage can be used for semi-automatic
workflow management. The :mod:`autojob.next.advance` and :mod:`autojob.next.restart` modules can be
used to step forward in a workflow from the command-line or restart a calculation
after modifying inputs.

.. toctree::
   :maxdepth: 1
   :hidden:

   coordinator
   harvest
   next
