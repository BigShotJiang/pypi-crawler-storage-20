Harvesting your results 🌽
==========================

The :mod:`autojob.harvest` subpackage provides functions to harvest the results from
task directories.

.. code-block:: python

    from pathlib import Path
    from autojob.harvest.harvest import harvest

    data = harvest(Path(...))

This will load the inputs, outputs, and metadata for each task in the directory
provided. Users have the ability to customize the harvesting process by registering
harvesters as plugins. ``autojob`` defines the :class:`~autojob.bases.harvester_base.HarvesterBase`
interface for callables that can harvest results from directories.

.. seealso::
    :doc:`/concepts/task/index`

    :func:`~autojob.harvest.archive.archive`: serialize tasks as CSV or JSON files
