(Semi-)Automatic Workflow Management
=====================================

Because failures on remote systems run such a large risk of losing state,
``autojob`` is designed with failure in mind. That means that wherever possible,
state is stored in files and progress can be restarted from command line. The
former functionality is achieved through the use of :doc:`Tasks /concepts/task/index`
and adherents of the :class:`~autojob.bases.task_base.InputWriter` interface. The latter
is provided by the :class:`autojob.next` subpackage and ``autojob advance`` and
``autojob restart`` CLI commands. For example, to restart a failed task with a new task,
use :func:`~autojob.next.restart.restart`.

.. code-block:: python

  from pathlib import Path

  from autojob.next.restart import restart

  old_task_dir = Path("path/to/task")
  new_task = restart(
    src=old_task_dir,
    submit=True,
    auto_restart=True,
    name_template="calc_{i}",
    file_size_limit=1e9
  )

Or

.. code-block:: shell

  autojob restart --path path/to/task --submit --auto-restart --name-template 'calc_{i}' --file-size-limit 1GB
