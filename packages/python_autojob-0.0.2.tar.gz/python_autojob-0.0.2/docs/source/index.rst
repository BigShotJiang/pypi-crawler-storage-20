.. autojob documentation master file, created by
   sphinx-quickstart on Tue Jan 23 10:25:50 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. image:: _static/autojob_dark.png
   :align: center

Welcome to autojob's documentation!
===================================

.. include:: ../../README.rst
    :start-after: .. start elevator-pitch
    :end-before: .. end elevator-pitch

* :doc:`Getting Started <quickstart>`: what you need and how to install ``autojob``
* :doc:`Features <features/index>`: an overview of ``autojob``'s features
* :doc:`How-Tos </howtos/index>`: a library of instructions for common ``autojob`` use-cases
* :doc:`API Documentation <reference/modules>`: API for all of ``autojob``'s packages, modules, and
  CLI functions

.. toctree::
   :caption: Quickstart 🚀
   :maxdepth: 1
   :hidden:

   quickstart

.. toctree::
   :maxdepth: 2
   :caption: User Guide
   :hidden:

   features/index
   concepts/index
   Configuration 🎨 <usage/configuration>
   howtos/index
   tutorials/index

.. toctree::
   :maxdepth: 2
   :caption: API Documentation
   :glob:
   :hidden:

   reference/modules
   Command-Line Interface <reference/commandline>


.. toctree::
   :maxdepth: 2
   :caption: Developer Guide
   :hidden:

   devguide/contributing
   devguide/docs
   devguide/extending

.. toctree::
   :maxdepth: 2
   :caption: About
   :hidden:

   Changelog 🔮 <about/changelog>
   License <about/license>
