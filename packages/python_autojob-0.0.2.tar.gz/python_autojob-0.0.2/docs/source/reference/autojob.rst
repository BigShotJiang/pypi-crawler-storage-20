autojob package
===============

.. automodule:: autojob
   :members:
   :show-inheritance:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   autojob.bases
   autojob.coordinator
   autojob.harvest
   autojob.next
   autojob.utils

Submodules
----------

autojob.hpc module
------------------

.. automodule:: autojob.hpc
   :members:
   :show-inheritance:
   :undoc-members:

autojob.legacy module
---------------------

.. automodule:: autojob.legacy
   :members:
   :show-inheritance:
   :undoc-members:

autojob.parametrizations module
-------------------------------

.. automodule:: autojob.parametrizations
   :members:
   :show-inheritance:
   :undoc-members:

autojob.plugins module
----------------------

.. automodule:: autojob.plugins
   :members:
   :show-inheritance:
   :undoc-members:

autojob.settings module
-----------------------

.. automodule:: autojob.settings
   :members:
   :show-inheritance:
   :undoc-members:

autojob.study module
--------------------

.. automodule:: autojob.study
   :members:
   :show-inheritance:
   :undoc-members:

autojob.study\_group module
---------------------------

.. automodule:: autojob.study_group
   :members:
   :show-inheritance:
   :undoc-members:

autojob.workflow module
-----------------------

.. automodule:: autojob.workflow
   :members:
   :show-inheritance:
   :undoc-members:
