autojob.coordinator.gui package
===============================

.. automodule:: autojob.coordinator.gui
   :members:
   :show-inheritance:
   :undoc-members:

Submodules
----------

autojob.coordinator.gui.groups module
-------------------------------------

.. automodule:: autojob.coordinator.gui.groups
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.gui module
----------------------------------

.. automodule:: autojob.coordinator.gui.gui
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.job\_submission module
----------------------------------------------

.. automodule:: autojob.coordinator.gui.job_submission
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.parameter\_selection module
---------------------------------------------------

.. automodule:: autojob.coordinator.gui.parameter_selection
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.structure\_selection module
---------------------------------------------------

.. automodule:: autojob.coordinator.gui.structure_selection
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.study\_configuration module
---------------------------------------------------

.. automodule:: autojob.coordinator.gui.study_configuration
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.submission\_configuration module
--------------------------------------------------------

.. automodule:: autojob.coordinator.gui.submission_configuration
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.summary module
--------------------------------------

.. automodule:: autojob.coordinator.gui.summary
   :members:
   :show-inheritance:
   :undoc-members:

autojob.coordinator.gui.widgets module
--------------------------------------

.. automodule:: autojob.coordinator.gui.widgets
   :members:
   :show-inheritance:
   :undoc-members:
