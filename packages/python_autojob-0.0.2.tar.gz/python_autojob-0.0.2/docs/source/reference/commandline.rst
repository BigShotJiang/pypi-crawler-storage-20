Usage
=====

Enable Shell Completion
-----------------------

Shell completion is supported for the bash, zsh, and fish shells. Shell
completion can be enabled by running ``autojob init`` and then restarting
your shell.

CLI Commands
------------

.. click:: autojob._cli.advance:main
    :prog: advance
    :nested: full

.. click:: autojob._cli.config_gen:main
    :prog: config-gen
    :nested: full

.. click:: autojob._cli.coordinator:main
    :prog: coordinator
    :nested: full

.. click:: autojob._cli.harvest:main
    :prog: harvest
    :nested: full

.. click:: autojob._cli.init:main
    :prog: init
    :nested: full

.. click:: autojob._cli.new:main
    :prog: new
    :nested: full

.. click:: autojob._cli.restart:main
    :prog: restart
    :nested: full

.. click:: autojob._cli.run:main
    :prog: run
    :nested: full
