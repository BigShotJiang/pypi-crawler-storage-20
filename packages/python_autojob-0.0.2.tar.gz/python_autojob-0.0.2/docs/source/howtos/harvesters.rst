How to Write a Harvester Plugin
===============================

Users can modify how ``autojob`` :class:`Calculation` tasks are harvested by
writing a custom harvester and either explicitly registering the harvester as a
plugin or exposing your plugin as an entry point. Of the two, options the second
is preferred.
