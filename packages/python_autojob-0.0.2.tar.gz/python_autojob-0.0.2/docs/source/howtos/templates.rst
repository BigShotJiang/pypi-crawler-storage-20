How To Write a Template
=======================

``autojob`` uses Jinja2_ to template scripts. For details on syntax, please
see the Jinja2_ documentation.

Python script templates will be passed the following
variables which may be accessed when rendering the template:

- ``calculator``: the name of the ASE calculator used for the calculation
- ``structure``: the filename of the structure used in the calculation
- ``parameters``: a dictionary mapping strings to values that can be used to
  configure an ASE calculator; the keys correspond to ASE calculator keyword
  arguments
- ``run_bader``: whether or to run Bader charge analysis after the calculation
- ``run_chargemol``: whether or to run Chargemol charge analysis after the calculation

SLURM script templates will be passed the following variables which may be accessed
when rendering the template:

- ``parameters``: a dictionary mapping strings to SLURM option values; the scheduler
  inputs for the calculation in SLURM format
- ``atoms``: the input atoms for the task
- ``files_to_copy``: files to copy from the submission directory to the scratch
  directory
- ``files_to_delete``: files to delete from the scratch directory after the calculation
- ``files_to_carry_over``: files to carry over from the previous calculation
- ``auto_restart``: whether or not to enable auto-restart
- ``calculator``: the name of the ASE calculator used for the calculation
- ``python_script``: the name of the Python script
- ``slurm_script``: the name of the SLURM submission script

Generally, the user is free to structure their templates as they please. However,
in order for task inputs to be retrieved from a completed task, the following
environment variables must be set in the template:

- ``AUTOJOB_COPY_TO_SCRATCH``
- ``AUTOJOB_FILES_TO_DELETE``
- files to carryover are not implemented correctly as of yet
- WIP (add instructions for ``auto_restart``)

To indicate to ``autojob`` that custom templates should be used, the user
should set the ``AUTOJOB_TEMPLATE_DIR``, ``AUTOJOB_SLURM_TEMPLATE``, and
``AUTOJOB_PYTHON_TEMPLATE`` environment variables.

.. _Jinja2: https://jinja.palletsprojects.com/en/stable/
