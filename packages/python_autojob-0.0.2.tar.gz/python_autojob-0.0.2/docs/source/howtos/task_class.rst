How To Write a New Task
========================

This page will explain how to write a simple, concrete implementation of
:class:`~autojob.bases.task_base.TaskBase` and how to register it with the
``autojob`` plug-in system.
