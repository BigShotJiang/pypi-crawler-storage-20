Working with Tasks
===================

The following How-Tos will illustrate how to perform common procedures while
working with tasks.

How to Create Tasks
-------------------

An empty task can always be instantiated by an empty call to the constructor:

.. code-block:: python

    from autojob.tasks.task import Task
    from autojob.tasks.calculation import Calculation
    from autojob.tasks.scan import BondScan

    task = Task()
    calc = Calculation()
    scan = BondScan()

The new task will have default values set for task inputs, task metadata,
and any other inputs defined by the :class:`.TaskBase` implementation.

Creating multiple tasks is as simple as iterating through a for loop.

.. code-block:: python

    from ase.data.g2 import data
    from ase.build import molecule

    from autojob.tasks.task import TaskInputs
    from autojob.tasks.calculation import Calculation

    calcs = []

    for name in data.molecule_names:
        atoms = molecule(name)
        tinputs = TaskInputs(atoms=atoms)
        calcs.append(Calculation(task_inputs=tinputs))

.. seealso::
    :class:`~autojob.tasks.task.Task`,
    :class:`~autojob.tasks.calculation.Calculation`,
    :class:`~autojob.tasks.scan.BondScan`

How to Dump Tasks to a Directory
--------------------------------

Multiple tasks can either be dumped to a structured directory
by collecting them into a :class:`.StudyGroup` or individually
dumped into unstructured directories.

To write the inputs of a single task to a directory
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    from pathlib import Path

    from autojob.tasks.task import Task

    task = Task()
    task.task_inputs.atoms = molecule("CO")
    task.write_inputs(".")

.. seealso::
    :meth:`.Task.write_inputs`

To dump tasks into a structured directory
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    from pathlib import Path

    from ase.data.g2 import data
    from ase.build import molecule

    from autojob.study import Study
    from autojob.study_group import StudyGroup
    from autojob.tasks.task import TaskInputs, TaskMetadata, Task

    sg = StudyGroup()
    study = Study(study_group_id=sg.study_group_id)
    tasks = []

    for name in data.molecule_names:
        atoms = molecule(name)
        tinputs = TaskInputs(atoms=atoms)
        metadata = TaskMetadata(
            study_group_id=sg.study_group_id,
            study_id=study.study_id,
        )
        task = Task(
            task_inputs=tinputs,
            task_metadata=metadata,
        )
        tasks.append(task)

    dest = Path()
    sg.to_directory(dest)

.. seealso::
    :meth:`.StudyGroup.to_directory`

To dump tasks into unstructured directories
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    from pathlib import Path

    from ase.data.g2 import data
    from ase.build import molecule

    from autojob.study import Study
    from autojob.study_group import StudyGroup
    from autojob.tasks.task import TaskInputs, TaskMetadata, Task

    sg = StudyGroup()
    study = Study(study_group_id=sg.study_group_id)
    name_template = "task_{i}"
    dest = Path()
    tasks = []

    for i, name in enumerate(data.molecule_names):
        atoms = molecule(name)
        tinputs = TaskInputs(atoms=atoms)
        metadata = TaskMetadata(
            study_group_id=sg.study_group_id,
            study_id=study.study_id,
        )
        task = Task(
            task_inputs=tinputs,
            task_metadata=metadata,
        )
        new_task_dir = create_task_tree(task, dest, name_template.format(i))

.. seealso::
    :doc:`/concepts/directory`

    :func:`.create_task_tree`

How to Harvest Tasks
--------------------

Tasks can be harvested from directories either directly using
:meth:`.Task.from_directory` or indirectly using
:func:`~autojob.harvest.harvest.harvest`. If the specific type of task to
load is known, then it is recommended to directly use that classes
:meth:`.Task.from_directory` method:

.. code-block:: python

    from pathlib import Path

    from autojob.tasks.task import Task
    from autojob.tasks.calculation import Calculation
    from autojob.tasks.scan import BondScan

    task = Task.from_directory(Path("task_directory"))
    calc = Calculation.from_directory(Path("calc_directory"))
    scan = BondScan.from_directory(Path("bond_scan_directory"))

A more robust interface is to call :meth:`.Task.from_directory` with
``magic_mode=True``. This parameter will use the value of the ``"task_class"``
key in the task's metadata to load to correct implementation of
:class:`.TaskBase`.

.. code-block:: python

    from pathlib import Path

    from autojob.tasks.task import Task

    task = Task.from_directory(Path("task_directory", magic_mode=True))

.. note::
    This feature requires ``"task_class"`` to be a
    :doc:`registered task </howtos/task_class>`.

Finally, several tasks can be harvested from all task directories in a
given using :func:`~autojob.harvest.harvest.harvest`.

.. code-block:: python

    from pathlib import Path

    from autojob.harvest.harvest import harvest

    tasks = harvest(Path())

This function searches for all subdirectories of the path provided that
contain a task metadata file. The name of task metadata files is
controlled by :attr:`SETTINGS.TASK_METADATA_FILE` setting.

How to Archive Tasks
---------------------

``autojob`` defines a convenience method for serializing collections
of tasks into JSON and CSV files, :func:`~autojob.harvest.archive.archive`.

.. code-block:: python

    from pathlib import Path

    from autojob.harvest.archive import archive
    from autojob.harvest.harvest import harvest

    harvested = harvest(Path())
    archive(
        filename="archive.json",
        archive_mode="both",
        harvested=harvested,
        time_stamp=True,
    )


Of course, because tasks are `Pydantic models`_, they can easily converted into
dictionaries using their :meth:`BaseModel.model_dump` methods. One can then
use libraries like Pandas_ to process the data further or h5py_ to prepare
more complicated formats.

.. _Pydantic models: https://docs.pydantic.dev/latest/concepts/models/
.. _h5py: https://docs.h5py.org/en/stable/
.. _Pandas: http://pandas.pydata.org
