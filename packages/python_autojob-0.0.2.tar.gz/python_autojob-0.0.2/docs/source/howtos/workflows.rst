How To Create Automatic Workflows
==================================

To convert your semi-automatic workflows into automatic ones, you must include
calls to :func:`~autojob.next.advance.advance` and :func:`~autojob.next.restart.restart`
(or ``autojob advance`` and ``autojob restart``) in your task script.

(show examples of task scripts with appropriate logic)
