Configuration (WIP)
===================

This page will describe how to configure ``autojob`` using environment variables,
a configuration file, and at runtime using the global instance of
:class:`AutojobSettings`.
