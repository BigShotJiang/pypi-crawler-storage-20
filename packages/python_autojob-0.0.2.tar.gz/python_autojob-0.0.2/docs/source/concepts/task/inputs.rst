Writing the Inputs of Tasks to a Directory
-------------------------------------------------

An instance of a concrete implementation of :class:`TaskBase` can be "dumped to a directory".
This process serializes a task by writing its inputs and metadata to files.
The behaviour is defined in the :class:`InputWriter` interface, which implementations of
:class:`TaskBase` must adhere to by defining a ``write_inputs()`` method. Good implementations
of this method must enable identical data to be loaded from the files written with ``write_inputs()``.
For example, :meth:`Task.write_inputs` writes a JSON file (named by ``SETTINGS.INPUTS_FILE``)
containing the task inputs, a trajectory containing the input :class:`~ase.Atoms` object(s),
a metadata JSON, and a templated task script that is meant to be used to execute the task.

If one has already created a directory in which they would like to dump a task, dumping
to a directory should be done like so:

.. code-block:: python

    from pathlib import Path

    from ase.build import molecule

    from autojob.tasks.task import Task, TaskInputs, TaskMetadata

    atoms = molecule("CO")
    metadata = TaskMetadata()
    tinputs = TaskInputs(atoms=atoms, atoms_filename="in.traj")
    task = Task(task_metadata=metadata, task_inputs=tinputs)
    task_dir = Path("my_task_dir")
    task_dir.mkdir()
    task.write_inputs(task_dir)

Otherwise, it is recommended to create new task directories with
:func:`autojob.next.create_task_tree`. This function can be used to create templated
directories and copy files from the directory of a previous task.

.. code-block:: python

    from pathlib import Path

    from ase.build import molecule

    from autojob.next import create_task_tree
    from autojob.tasks.task import Task, TaskInputs, TaskMetadata

    atoms = molecule("CO")
    metadata = TaskMetadata()
    tinputs = TaskInputs(atoms=atoms, atoms_filename="in.traj")
    task = Task(task_metadata=metadata, task_inputs=tinputs)
    task_dir = Path()
    src = Path("../calc_1")
    to_copy = ["CHGCAR", "WAVECAR"]
    template = "calc_{i}"
    create_task_tree(
        task,
        task_dir,
        src=src,
        files_to_carryover=to_copy,
        name_template=template
    )

.. seealso::
    For creating tasks within the workflow infrastructure, opt for the
    :func:`autojob.next.initialize_task` function.

    :meth:`autojob.tasks.calculation.Calculation.write_inputs`
