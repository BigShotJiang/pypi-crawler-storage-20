Deserializing Tasks
===========================

An instance of a concrete implementation of :class:`.TaskBase` can be loaded from a directory.
This process deserializes a task by reading its inputs, outputs, and metadata from files.
The behaviour is defined in the :class:`.PathLoadable` interface, which implementations of
:class:`.TaskBase` must adhere to by defining a ``from_directory()`` method. Implementations of
this function can assume that the source directory argument will point to a directory
containing an inputs JSON and a metadata file.

.. code-block:: python

    from pathlib import Path
    from autojob.tasks.task import Task

    task = Task.from_directory(Path(...))

An important function for :class:`~autojob.tasks.task.Task` instances is
:meth:`.Task.load_magic` which can change the type of task returned depending
on the ``task_class`` (set in :attr:`.Task.task_metadata`). This function can be
called directly or it can be activated using the ``magic_mode=True`` to
:meth:`.Task.from_directory`. Note that in order for this feature to work with custom :class:`~autojob.bases.task_base.TaskBase`
implementations, you must :doc:`register your task </howtos/tasks>`.

.. code-block:: python

    from pathlib import Path

    from ase.build import molecule

    from autojob.next import create_task_tree
    from autojob.tasks.task import Task, TaskInputs, TaskMetadata

    atoms = molecule("CO")
    metadata = TaskMetadata()
    tinputs = TaskInputs(atoms=atoms, atoms_filename="in.traj")
    task = Task(task_metadata=metadata, task_inputs=tinputs)
    task_dir = Path()
    src = Path("../calc_1")
    to_copy = ["CHGCAR", "WAVECAR"]
    template = "calc_{i}"
    create_task_tree(
        task,
        task_dir,
        src=src,
        files_to_carryover=to_copy,
        name_template=template
    )

.. seealso::
    For creating tasks within the workflow infrastructure, opt for the
    :func:`~autojob.next.initialize_task` function.

    :func:`~autojob.harvest.harvest.harvest`: harvest multiple tasks from
    directories

    :mod:`~autojob.harvest.harvesters`: ``autojob`` implementations of
    :class:`.HarvesterBase`
