Tasks
=====

One of the primary goals of ``autojob`` is to enable the recovery of failed
jobs from the directory in which they were run. As such, the "task" concept
associates with each job an object that contains its state. In addition to
being able to instantiate a task programmatically, a central tenet of
``autojob`` is that tasks should:

1. be instantiable from the directory in which the related job was run, and
2. be straightforwardly written to a directory in which they can be run.

The first goal is accomplished by the :class:`~autojob.bases.task_base.PathLoadable`
protocol, which requires adherents to implement the ``from_directory`` method.
The latter goal is accomplished by the :class:`~autojob.bases.task_base.InputWriter`
protocol, which requires adherents to implement a ``write_inputs`` method.

The typical life-cycle of an ``autojob`` task is: creation > serialization > execution
> deserialization. The following sections describe each of these concepts in
context of ``autojob`` tasks.

.. toctree::
   :maxdepth: 1
   :hidden:

   creation
   inputs
   execution
   harvesting
