
Execution
---------

Although ``autojob`` does not directly handle task execution, it does facilitate
execution by the user. The files written by ``autojob`` contain the specifications
required to run execute the task. Note, however, that the user is still responsible
for setup of the environment to run the task. This function is often achieved using
the task script written by :meth:`.TaskBase.write_inputs()`. The
:class:`~autojobs.tasks.task.Task` class writes:

- a JSON file containing all task inputs to the file named according to
  :attr:`SETTINGS.INPUTS_FILE`
- a JSON file containing all task metadata to the file named according to
  :attr:`SETTINGS.TASK_METADATA_FILE`
- the task script, a templated file (whose template is specified by
  :attr:`Task.task_inputs.task_script_template`) written to
  :attr:`SETTINGS.TASK_SCRIPT`

A recommended pattern is to use the task script to setup the environment for
the task and then call a separate script to execute the task. A simple implementation
is shown below:

.. code-block:: shell

  #!/usr/bin/env bash

  python -m venv .venv
  source .venv/bin/activate
  pip install ase autojob
  python run.py
  rm -rf .venv

If the task script is to be used with a scheduler, then the task script should also specify
scheduler resources.

.. code-block:: shell

  #!/usr/bin/env bash
  #SBATCH --time=1:00:00
  #SBATCH --ntasks-per-node=4
  #SBATCH --mem-per-cpu=100MB

  python -m venv .venv
  source .venv/bin/activate
  pip install ase autojob
  python run.py
  rm -rf .venv

.. seealso::
  :class:`~autojob.hpc.ScheduledMixin`: a mixin class that enables interfacing with
  job schedulers

  :doc:`/howtos/templates`
