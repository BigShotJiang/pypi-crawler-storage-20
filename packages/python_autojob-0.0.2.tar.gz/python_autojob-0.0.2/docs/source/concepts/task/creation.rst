Task Creation
==============

The abstract base class, :class:`~autojob.bases.task_base.TaskBase`, defines
these methods as abstract methods that must be implemented by its concrete
implementations. :class:`~autojob.base.task_base.TaskBase` objects **cannot
be directly instantiated.** The class merely specifies an interface for concrete
implementations. Each concrete implementation of
:class:`~autojob.bases.task_base.TaskBase` represents a type of task, and each
instance represents an atomic compute job.

:mod:`autojob.tasks` is a namespace
package that contains several concrete implementations of
:class:`~autojob.base.task_base.TaskBase` that can be used as is or subclasses
and modified further. In the following example,
:class:`~autojob.tasks.calculation.Calculation` is a concrete implementation
of :class:`~autojob.base.task_base.TaskBase` made for storing the results of a
calculation and ``calc`` represents an individual calculation.

.. code-block:: python

    from autojob.tasks.calculation import Calculation, CalculationInputs

    calc = Calculation()

Note that :class:`~autojob.tasks.calculation.Calculation` is a subclass of the
:class:`~autojob.tasks.task.Task` class. *It is recommended that users
implementing custom tasks subclass one of these two classes (or their
subclasses).*

Instances of either class can be customized at creation or afterwards. The simplest
task (e.g., an instance of :class:`~autojob.tasks.task.Task`) has attributes
representing task inputs, outputs, and metadata. This information is defined in
the :class:`~class.bases.task_base.TaskMetadataBase`,
the :class:`~class.bases.task_base.TaskInputsBase`,
and the :class:`~class.bases.task_base.TaskOutputsBase` classes, respectively.

The state of a task is represented by Pydantic_ model fields. This means that upon
creation, all fields will be validated and
converted to an expected type; missing fields will be instantiated
with default values. For example, the ``task_metadata`` field of tasks expects
an instance of :class:`~autojob.bases.task_base.TaskMetadataBase` (which is actually an
abstract base class with corresponding concrete implementation
:class:`~autojob.tasks.task.TaskMetadata`). If you pass
an incompatible type, instantiation of the task will fail.

.. code-block:: python

    from autojob.tasks.task import Task

    task = Task(task_metadata=1)

However, if you pass a dictionary that can be *converted into* a valid
:class:`~autojob.bases.task_base.TaskMetadataBase` object, then validation will pass.

.. code-block:: python

    from autojob.tasks.task import Task

    task = Task(
        task_metadata={
            "label": "my task",
            "study_group_id": "g123456789",
            "study_id": "s123456789",
            "task_group_id": "c123456789",
            "task_id": "j123456789",
        },
    )

Of course, you can always pass an instance of the expected type.

.. code-block:: python

    from autojob.tasks.task import Task, TaskMetadata

    task = Task(
        task_metadata=TaskMetadata(
        label="my task",
        study_group_id="g123456789",
        study_id="s123456789",
        task_group_id="c123456789",
        task_id="j123456789",
        ),
    )

**Note that validation is only done upon instantiation.** Task fields are
not validated during assignment operations. Therefore, the recommended
way to modify tasks and their fields is to instantiate the desired object
*prior* to assignment.

.. code-block:: python

    from autojob.tasks.task import Task, TaskMetadata

    task = Task()
    task.task_metadata = TaskMetadata(
        label="my task",
        study_group_id="g123456789",
        study_id="s123456789",
        task_group_id="c123456789",
        task_id="j123456789",
    )

Users are encouraged to consult the :class:`~class.bases.task_base.TaskBase`
documentation for a description of the remaining fields of all tasks
and the the :class:`~class.tasks.calculation.Calculation` for a description
of the additional fields of :class:`~class.tasks.calculation.Calculation`
objects.

.. seealso::
    :class:`~autojob.tasks`,
    :class:`~autojob.tasks.task.Task`,
    :class:`~autojob.tasks.calculation.Calculation`,
    :class:`~autojob.tasks.vibration.Vibration`,
    :class:`~autojob.tasks.scan.BondScan`,
    :class:`~autojob.tasks.md.MolecularDynamics`,
    :class:`~autojob.tasks.infrared.Infrared`

Note that the latter four implementations inherit from subclasses of
:class:`~autojob.tasks.calculation.Calculation`.

Further, users can define their own implementations of
:class:`~autojob.bases.task_base.TaskBase` by inheriting from one of the
abstract base classes or from one of the concrete implementations defined
herein. Although passing custom implementations of tasks will work for all
methods which accept :class:`~autojob.bases.task_base.TaskBase` instances,
in order for some of the magic of :class:`~autojob.harvest.harvest` to
function correctly (automatic instantiating of task subclasses) without
explicitly passing the custom class, users should register their tasks
using the plug-in system (TODO: write how-to).

.. _Pydantic: https://docs.pydantic.dev/latest/
