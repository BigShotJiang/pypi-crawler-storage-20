Key Concepts
============

``autojob`` is designed with the following workflow in mind:

1. **Task creation**: initializing the task data model and writing inputs to directory
2. **Execution**: Task runs on HPC
3. **Harvesting/Analysis**: loads results using calculator-specific and custom "harvesters"
4. **Workflow**: progress through DAG-based `Workflow`\ s

The following sections describe key concepts required for implementation of the
above workflow.

.. toctree::
   :maxdepth: 1

   data_hierarchy
   task/index
   directory
   workflows
