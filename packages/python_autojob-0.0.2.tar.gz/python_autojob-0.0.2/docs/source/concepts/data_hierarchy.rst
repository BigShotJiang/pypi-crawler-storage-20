Data Hierarchy
===============

.. image:: images/data_hierarchy.svg

The figure above describes the relationship between :class:`.StudyGroup`\ s,
:class:`.Study`\ s, task groups and :class:`.Task`\ s. The concept of a ``Task`` is
described :doc:`here </concepts/task/index>`. A group of tasks form a task group.
Usually, these should be closely related tasks with only minor changes between
them. When tasks are restarted using :mod:`autojob.next`, each restarted task
is added to the task group of its precedent. A collection of task groups forms
a :class:`.Study`, and a collection of studies form a :class:`.StudyGroup`\.

The typical use case for this data hierarchy is that every task group will
correspond to a single desired output (e.g., relaxed structure, density of states)
with its constituent tasks being any repeated attempts to obtain that output.
The task groups which comprise a study will typically all be slight variations of
the same task (e.g., changed calculation parameters) often linked by a common
question. The studies which comprise a study group will typically represent
variations of the same question: how does
convergence change for given calculation parameters and structures?
