Running Your First Task
========================

This tutorial will instruct you through creating your first task to
harvesting its results and archive the data.

We will be creating a calculation task in order to optimize the
structure of an H2O molecule using GPAW.

Creating the Structure for the Task
------------------------------------

We start by creating the structure:

.. code-block:: python

    from pathlib import Path
    from ase.build import molecule

    # We will create the task directory in the current working directory
    dest = Path()
    atoms = molecule("H2O")

You can inspect and modify the structure using :meth:`Atoms.edit`. Try
to tag the oxygen atom with a 1 and center the :class:`.Atoms` object
in a 10 Å vacuum cell.

.. code-block:: python

    >>> atoms.edit()
    >>> atoms.get_tags()
    array([1, 0, 0])
    >>> atoms.get_cell()
    Cell([20.0, 21.526478, 20.596309])

Customizing the Inputs
-----------------------

The first set of inputs that we will create will be task inputs. The
:class:`.TaskInputsBase` abstract base class describes the data model for task
inputs. All :class:`.Task`\ s have task inputs. The most important field to
set for task inputs is usually :attr:`.TaskInputsBase.atoms`. We will set the
task inputs atoms to be our H2O molecule.

.. code-block:: python

    from autojob.tasks.task import TaskInputs

    tinputs = TaskInputs(
        atoms=atoms,
        atoms_filename="H2O.traj",
        task_script="run.sh",
        task_script_template="run.sh.j2",
    )

This will create a :class:`.TaskInputs` object that specifies the task inputs
for our calculation. The task inputs structure will be our H2O structure, and
the filename used to save the input atoms will be ``"H2O.traj"``. The task
script that is written to the task directory will be ``run.sh``, and the
``"run.sh.j2"`` template will be used. For example, we also could have
specified the names of ``files_to_copy`` and ``files_to_delete``.

.. seealso::
    :class:`.TaskInputsBase`

The second set of inputs that we will create are specific to calculation tasks
and subclasses. :class:`.Calculation` tasks differ from the basic :class:`.Task`
tasks in that they have additional inputs and outputs. In addition
to task inputs, calculations have calculation inputs (:class:`.CalculationInputs`)
and scheduler inputs (:class:`.SchedulerInputs`). To prepare a calculation,
you can specify the calculator, an optimizer (if desired), and specify calculator and
optimizer parameters. One can also optionally specify analyses to execute
post-calculation and specify a calculation script template and the name of the
script to write as the calculation script.

.. code-block:: python

    from autojob.tasks.calculation import CalculationInputs

    cinputs = CalculationInputs(
        calculator="gpaw",
        optimizer="LBFGS",
        calc_params={
            "mode": "pw",
        },
        opt_params={
            "init": {
                "trajectory": "opt.traj",
                "logfile": "opt.log",
            },
            "run": {
                "fmax": 0.05,
                "steps": 10,
            },
        },
        calculation_script="my_calc.py",
        calculation_script_template="run.py.j2",
    )

This creates a :class:`.CalculationInputs` object in which the calculator is
specified to be a GPAW calculator and the optimizer is set to LBFGS. We have
specified a dictionary that will be used to set the GPAW calculator parameters
to set the calculation mode to plane-wave mode. We specify initialization
and optimization parameters for the LBFGS optimizer in a dictionary as well.
``calculation_script`` controls the name of the calculation script that will
be written when calculation inputs are dumped to a directory.
``calculation_script_template`` specifies the template that will be used to
write the calculation script. Calculation script templates are read from the
template directory, which is controlled by the setting, ``SETTINGS.TEMPLATE_DIR``
or ``AUTOJOB_TEMPLATE_DIR`` environment variable. By default, the ``autojob``
templates will be used (``autojob.templates``).

Finally, we will create the object to host the task metadata.

.. code-block:: python

    from autojob.tasks.task import TaskMetadata

    metadata = TaskMetadata(
        label="My custom H2O task",
        tags=[
            "H2O",
            "GPAW",
        ]
    )

When not set, metadata fields will be populated with default values.
What is the task ID?

.. code-block:: python

    >>> metadata.task_id

The names of all fields in task metadata are attributes of
:class:`.TaskMetadataBase`.

Creating the Task
-----------------

Putting it all together, we can now create the task:

.. code-block:: python

    from autojob.tasks.calculation import Calculation

    calc = Calculation(
        task_inputs=tinputs,
        task_metadata=metadata,
        calculation_inputs=cinputs,
    )

Writing the Task Inputs
-----------------------

To create a task directory and write its inputs to a directory,
use the :func:`.create_task_tree` function.

.. code-block:: python

    from pathlib import Path
    from autojob.next import create_task_tree

    dest = Path()
    create_task_tree(calc, dest)

You should notice that a new directory has been created in the current
working directory. What is the directory named? If you would like to
use a different naming scheme, you can use the ``name_template`` argument:

.. code-block:: python

    from pathlib import Path
    from autojob.next import create_task_tree

    dest = Path()
    task_dir = create_task_tree(calc, dest, name_template="calc_{i}")

The ``name_template`` argument controls the naming scheme used to create
new task directories. By using the pattern ``"{i}"``, we tell
:func:`.create_task_tree` to number task directories to avoid naming
conflicts. You can also use different placeholders such as ``"{task_id}"``
to template task directories.

You should also notice a number of files in the directory. What are they
called? For a brief explanation of the purpose of each of these files,
see the :doc:`/concepts/directory` page. You should notice a file named
``run.sh``. Running this script in the shell should execute our task:

.. code-block:: shell

    bash run.sh

Retrieving Task Outputs
------------------------

We can retrieve the task outputs using the :class:`.PathLoadable` interface.

.. code-block:: python

    from autojob.tasks.calculation import Calculation

    completed = Calculation.from_directory(task_dir)

:class:`.Calculation` tasks have both task outputs and calculation outputs.
Task outputs are relatively simple; their interface is described by the
:class:`.TaskOutputsBase` class, and they typically only include the output
:class:`.Atoms` object. You can visualize the output atoms like so:

.. code-block:: python

    completed.task_outputs.atoms.edit()

How does this structure compare with the input atoms?

The calculation outputs are generally more complex as they can contain
any of the output from a calculation. The data model of calculation outputs
is described in the :class:`.CalculationOutputs` class. Most basically, the
calculation outputs include whether the calculation converged, the system
``energy``, atomic ``forces``, and results for the calculator, optimizer,
and any analyses that were run.

Storing Task Results
---------------------

We can archive the results of our calculation task using the
:func:`.archive` function.

.. code-block:: python

    from autojob.archive.archive import archive

    archive("archive", archive_mode="json", harvested=completed)

You can time stamp the archive using the ``time_stamp`` argument and select
multiple archive modes by setting ``archive_mode="both"``.

.. code-block:: python

    from autojob.archive.archive import archive

    archive(
        "archive",
        harvested=completed,
        archive_mode="both",
        time_stamp=True,
    )
