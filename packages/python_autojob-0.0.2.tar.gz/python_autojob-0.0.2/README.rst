========
Overview
========

.. start elevator-pitch

``autojob`` is a (semi-)automatic framework for DFT job automation on massively parallel
computing resources. With ``autojob``, you can manage complex, automated workflows while
still retaining the flexibility to stop, make job-level changes, and resume the workflow.
Additionally, ``autojob`` provides a codeless workflow design suite and
high-fidelity data aggregation utilities.

.. end elevator-pitch

.. image:: docs/source/_static/autojob_light.png
   :align: center

.. start quickstart

Installation 🛠️
===============

``autojob`` can be installed via ``pip``:

.. code-block:: console

    pip install python-autojob

You can also install the in-development version with ssh:

.. code-block:: console

    pip install git+ssh://git@gitlab.com/ugognw/python-autojob.git@development"

or https

.. code-block:: console

    pip install git+https://gitlab.com/ugognw/python-autojob.git

Usage
=====

To use ``autojob``, do

.. code-block:: python

    import autojob

.. end quickstart

Documentation
=============

https://python-autojob.readthedocs.io/
