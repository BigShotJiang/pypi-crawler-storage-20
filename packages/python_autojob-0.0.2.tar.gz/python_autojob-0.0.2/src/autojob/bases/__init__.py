"""This subpackage defines core base classes for autojob."""
