"""Plato agent runner utilities.

This module provides utilities for running coding agents in Docker containers.
Each agent image has its own entrypoint that handles execution internally.

Runner:
    - AgentRunner: Utility for running agents in Docker containers
    - AgentRunResult: Async iterator for agent output

Schemas:
    - AGENT_SCHEMAS: JSON schemas for agent configuration
    - get_agent_schema: Get schema for a specific agent

Example:
    from plato.agents import AgentRunner

    async for line in AgentRunner.run(
        image="us-docker.pkg.dev/plato-prod/agents/openhands:latest",
        config={"model_name": "anthropic/claude-sonnet-4"},
        secrets={"anthropic_api_key": "sk-..."},
        instruction="Fix the bug in main.py",
        workspace="/path/to/repo",
    ):
        print(line)
"""

from __future__ import annotations

__all__ = [
    # Schemas
    "get_agent_schema",
    "AGENT_SCHEMAS",
    # Runner
    "AgentRunner",
    "AgentRunResult",
]


# JSON Schemas for agent configuration
AGENT_SCHEMAS: dict[str, dict] = {
    "claude-code": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "claude-code",
        "title": "ClaudeCodeConfig",
        "description": "Configuration for Claude Code agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use (e.g., 'anthropic/claude-sonnet-4')",
            },
            "max_thinking_tokens": {
                "type": ["integer", "null"],
                "default": None,
                "description": "Maximum tokens for extended thinking mode",
            },
        },
        "required": [],
    },
    "openhands": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "openhands",
        "title": "OpenHandsConfig",
        "description": "Configuration for OpenHands agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use (e.g., 'anthropic/claude-sonnet-4')",
            },
            "disable_tool_calls": {
                "type": "boolean",
                "default": False,
                "description": "Whether to disable native function calling",
            },
            "reasoning_effort": {
                "type": ["string", "null"],
                "enum": ["low", "medium", "high", None],
                "default": "medium",
                "description": "Reasoning effort level for the model",
            },
        },
        "required": [],
    },
    "codex": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "codex",
        "title": "CodexConfig",
        "description": "Configuration for Codex CLI agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use (e.g., 'openai/gpt-4o')",
            },
        },
        "required": [],
    },
    "aider": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "aider",
        "title": "AiderConfig",
        "description": "Configuration for Aider agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use",
            },
        },
        "required": [],
    },
    "gemini-cli": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "gemini-cli",
        "title": "GeminiCliConfig",
        "description": "Configuration for Gemini CLI agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use (e.g., 'google/gemini-2.5-pro')",
            },
        },
        "required": [],
    },
    "goose": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "goose",
        "title": "GooseConfig",
        "description": "Configuration for Block Goose agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use",
            },
        },
        "required": [],
    },
    "swe-agent": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "swe-agent",
        "title": "SweAgentConfig",
        "description": "Configuration for SWE-agent.",
        "type": "object",
        "properties": {
            "model_name": {
                "type": "string",
                "description": "LLM model to use",
            },
        },
        "required": [],
    },
}


def get_agent_schema(agent_name: str) -> dict | None:
    """Get the JSON schema for an agent.

    Args:
        agent_name: The agent name (e.g., 'claude-code', 'openhands')

    Returns:
        JSON schema dict or None if agent not found
    """
    return AGENT_SCHEMAS.get(agent_name)


class AgentRunResult:
    """Result of running an agent.

    This class is an async iterator that yields output lines from the agent.
    It also provides access to the logs directory where agent logs are stored.

    Example:
        result = AgentRunner.run(...)
        async for line in result:
            print(line)
        print(f"Logs at: {result.logs_dir}")
    """

    def __init__(
        self,
        image: str,
        config: dict,
        secrets: dict[str, str],
        instruction: str,
        workspace: str,
        logs_dir: str | None,
        pull: bool,
    ):
        self._image = image
        self._config = config
        self._secrets = secrets
        self._instruction = instruction
        self._workspace = workspace
        self._pull = pull

        # Create logs dir if not provided
        if logs_dir is None:
            import tempfile

            self._logs_dir = tempfile.mkdtemp(prefix="agent_logs_")
        else:
            self._logs_dir = logs_dir

    @property
    def logs_dir(self) -> str:
        """Host path where agent logs are stored."""
        return self._logs_dir

    def __aiter__(self):
        return self._stream()

    async def _stream(self):
        """Stream output from the agent."""
        import asyncio
        import json
        import os
        import tempfile

        # Pull the image if requested
        if self._pull:
            pull_proc = await asyncio.create_subprocess_exec(
                "docker",
                "pull",
                self._image,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            assert pull_proc.stdout is not None  # stdout is set via PIPE
            while True:
                line = await pull_proc.stdout.readline()
                if not line:
                    break
                yield f"[pull] {line.decode().rstrip()}"
            await pull_proc.wait()

        # Create agent subdirectory for logs (Harbor writes to /logs/agent/)
        agent_logs_subdir = os.path.join(self._logs_dir, "agent")
        os.makedirs(agent_logs_subdir, exist_ok=True)

        # Write config to a temp file
        config_file = tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False)
        json.dump(self._config, config_file)
        config_file.close()

        try:
            # Build docker command
            docker_cmd = [
                "docker",
                "run",
                "--rm",
                "-v",
                f"{self._workspace}:/workspace",
                "-v",
                f"{self._logs_dir}:/logs",
                "-v",
                f"{config_file.name}:/config.json:ro",
                "-w",
                "/workspace",
            ]

            # Add secrets as environment variables
            for key, value in self._secrets.items():
                docker_cmd.extend(["-e", f"{key.upper()}={value}"])

            # Add the image and instruction argument
            docker_cmd.append(self._image)
            docker_cmd.extend(["--instruction", self._instruction])

            # Run the container
            process = await asyncio.create_subprocess_exec(
                *docker_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            assert process.stdout is not None  # stdout is set via PIPE

            # Stream output
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                yield line.decode().rstrip()

            await process.wait()

            if process.returncode != 0:
                raise RuntimeError(f"Agent failed with exit code {process.returncode}")
        finally:
            # Clean up config file
            os.unlink(config_file.name)


class AgentRunner:
    """Utility for running agents in Docker containers.

    Each agent image has its own entrypoint that:
    - Reads config from /config.json
    - Reads secrets from environment variables
    - Takes instruction via --instruction argument

    Example:
        import asyncio
        from plato.agents import AgentRunner

        async def main():
            async for line in AgentRunner.run(
                image="us-docker.pkg.dev/plato-prod/agents/openhands:latest",
                config={"model_name": "anthropic/claude-sonnet-4"},
                secrets={"anthropic_api_key": "sk-..."},
                instruction="Fix the bug in main.py",
                workspace="/path/to/repo",
            ):
                print(line)

        asyncio.run(main())
    """

    @staticmethod
    def run(
        image: str,
        config: dict,
        secrets: dict[str, str],
        instruction: str,
        workspace: str,
        logs_dir: str | None = None,
        pull: bool = True,
    ) -> AgentRunResult:
        """Run an agent in a Docker container.

        Pulls the image if needed, then runs the agent with proper
        configuration. Returns a result object that can be iterated
        to stream output lines.

        Args:
            image: Docker image URI
            config: Agent-specific configuration dict (matches agent schema)
            secrets: Secret values (API keys, tokens, etc.)
            instruction: The task instruction/prompt for the agent
            workspace: Host directory to mount as /workspace
            logs_dir: Host directory for agent logs. If None, creates a temp dir.
            pull: Whether to pull the image before running

        Returns:
            AgentRunResult that can be async-iterated for output lines.
            Access result.logs_dir to get the host path where logs are stored.

        Raises:
            RuntimeError: If agent fails with non-zero exit code

        Example:
            result = AgentRunner.run(...)
            async for line in result:
                print(line)
            print(f"Logs at: {result.logs_dir}")
        """
        return AgentRunResult(
            image=image,
            config=config,
            secrets=secrets,
            instruction=instruction,
            workspace=workspace,
            logs_dir=logs_dir,
            pull=pull,
        )
