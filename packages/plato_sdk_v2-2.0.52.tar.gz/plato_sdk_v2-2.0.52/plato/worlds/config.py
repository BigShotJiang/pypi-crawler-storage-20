"""Configuration models for Plato worlds."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field


class AgentConfig(BaseModel):
    """Configuration for a single agent slot.

    Attributes:
        image: Docker image URI for the agent
        config: Agent-specific configuration (passed to the agent)
    """

    image: str
    config: dict[str, Any] = Field(default_factory=dict)


class WorldConfig(BaseModel):
    """World-specific configuration base class.

    Subclass this to create typed configurations for your world:

        class CodeWorldConfig(WorldConfig):
            repository_url: str
            checkout: str = "main"
            prompt: str

    The schema will be auto-generated from the Pydantic model.
    """

    model_config = {"extra": "allow"}

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by key (for backwards compatibility)."""
        return getattr(self, key, default)

    @classmethod
    def get_json_schema(cls) -> dict:
        """Get JSON schema for this config class."""
        schema = cls.model_json_schema()
        # Remove Pydantic-specific keys
        schema.pop("title", None)
        return schema


# Type variable for typed config classes
WorldConfigT = TypeVar("WorldConfigT", bound=WorldConfig)


class RunConfig(BaseModel, Generic[WorldConfigT]):
    """Full configuration for running a world.

    This is passed to the world runner and contains everything
    needed to execute a world. Use with a type parameter for typed config access:

        config: RunConfig[CodeWorldConfig] = ...
        config.world_config.repository_url  # type-safe access

    Attributes:
        world_config: World-specific configuration (typed via generic)
        agents: Mapping of slot name to agent configuration
        secrets: Secret values (API keys, tokens, etc.)
        session_id: Unique session identifier
    """

    world_config: WorldConfigT = Field(default_factory=WorldConfig)  # type: ignore[assignment]
    agents: dict[str, AgentConfig] = Field(default_factory=dict)
    secrets: dict[str, str] = Field(default_factory=dict)
    session_id: str = ""
    callback_url: str = ""  # URL for agent to push logs back to Chronos

    def get_agent(self, slot_name: str) -> AgentConfig | None:
        """Get agent config for a slot."""
        return self.agents.get(slot_name)

    def get_secret(self, key: str, default: str | None = None) -> str | None:
        """Get a secret value."""
        return self.secrets.get(key, default)

    @classmethod
    def from_file(
        cls,
        path: str | Path,
        config_class: type[WorldConfig] | None = None,
    ) -> RunConfig:
        """Load run config from a JSON file.

        Args:
            path: Path to JSON config file
            config_class: Optional WorldConfig subclass to parse world_config into.
                         Defaults to WorldConfig if not provided.
        """
        import json

        path = Path(path)
        with open(path) as f:
            data = json.load(f)

        # Parse agents into AgentConfig objects
        agents = {}
        for slot_name, agent_data in data.get("agents", {}).items():
            if isinstance(agent_data, dict):
                agents[slot_name] = AgentConfig(**agent_data)
            else:
                agents[slot_name] = AgentConfig(image=str(agent_data))

        # Use provided config class or default to WorldConfig
        config_cls = config_class or WorldConfig
        world_config = config_cls(**data.get("world_config", {}))

        return cls(
            world_config=world_config,  # type: ignore[arg-type]
            agents=agents,
            secrets=data.get("secrets", {}),
            session_id=data.get("session_id", ""),
            callback_url=data.get("callback_url", ""),
        )
