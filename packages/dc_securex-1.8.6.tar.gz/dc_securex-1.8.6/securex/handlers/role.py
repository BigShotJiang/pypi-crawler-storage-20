"""
Role protection handler for SecureX SDK.
"""
import discord
import asyncio
from datetime import datetime, timedelta
from ..models import ThreatEvent


class RoleHandler:
    """Handles role protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_role_create(self, role: discord.Role):
        """Detect unauthorized role creation - uses lock to prevent duplicate processing"""
        try:
            guild = role.guild
            
            # Get or create lock for this guild
            if guild.id not in self.sdk._spam_locks:
                self.sdk._spam_locks[guild.id] = asyncio.Lock()
            
            # Only ONE handler processes spam at a time
            async with self.sdk._spam_locks[guild.id]:
                # Wait briefly for spam to finish
                await asyncio.sleep(0.5)
                
                # Get audit logs for last 30 seconds (timezone-aware)
                from datetime import timezone
                cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
                
                unauthorized_roles = []
                violator = None
                
                async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.role_create):
                    # Stop if older than 30 seconds
                    if entry.created_at < cutoff_time:
                        break
                    
                    # Check if unauthorized
                    if not await self._is_authorized(guild, entry.user.id):
                        # Find the role if it still exists
                        created_role = guild.get_role(entry.target.id)
                        if created_role:
                            unauthorized_roles.append(created_role)
                        if violator is None:
                            violator = entry.user
                
                # Process spam if detected (only first handler does this)
                if unauthorized_roles and violator:
                    print(f"🚨 Detected {len(unauthorized_roles)} spam roles from {violator.name}")
                    
                    # STEP 1: PUNISH IMMEDIATELY to stop the attack
                    print(f"⚡ Punishing {violator.name} to stop attack...")
                    punishment_action = await self.sdk.punisher.punish(
                        guild=guild,
                        user=violator,
                        violation_type="role_create",
                        details=f"Spam created {len(unauthorized_roles)} roles",
                        sdk=self.sdk
                    )
                    print(f"✅ Punishment applied: {punishment_action}")
                    
                    # STEP 2: Now safely batch delete all spam roles
                    print(f"🧹 Cleaning up {len(unauthorized_roles)} spam roles...")
                    deleted_count = 0
                    
                    for spam_role in unauthorized_roles:
                        try:
                            await spam_role.delete(reason="SecureX: Spam role creation")
                            deleted_count += 1
                        except discord.errors.NotFound:
                            # Role already deleted - that's fine
                            pass
                        except Exception as e:
                            print(f"Error deleting role {spam_role.name}: {e}")
                    
                    print(f"✅ Deleted {deleted_count}/{len(unauthorized_roles)} spam roles")
                    
                    # Create threat event
                    threat = ThreatEvent(
                        type="role_create",
                        guild_id=guild.id,
                        actor_id=violator.id,
                        target_id=role.id,
                        target_name=f"{len(unauthorized_roles)} spam roles",
                        prevented=True,
                        restored=False,
                        punishment_action=punishment_action,
                        details={
                            "spam_count": len(unauthorized_roles),
                            "deleted_count": deleted_count
                        }
                    )
                    
                    await self.sdk._trigger_callbacks('threat_detected', threat)
                # If no spam found, this handler came late - first one already handled it
                
        except Exception as e:
            print(f"Error in role_create handler: {e}")
    
    async def on_role_delete(self, role: discord.Role):
        """Detect and restore unauthorized role deletion"""
        try:
            guild = role.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
                if entry.target.id == role.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Restore role from backup
                        restored = await self.backup_manager.restore_role(guild, role.id)
                        
                        threat = ThreatEvent(
                            type="role_delete",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=role.id,
                            target_name=role.name,
                            prevented=True,
                            restored=restored
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in role_delete handler: {e}")
    
    async def on_role_update(self, before: discord.Role, after: discord.Role):
        """Detect unauthorized role permission/position changes"""
        try:
            # Only check if position or permissions changed
            if before.position == after.position and before.permissions == after.permissions:
                return
            
            guild = after.guild
            await asyncio.sleep(0.3)
            
            async for entry in guild.audit_logs(limit=3, oldest_first=False):
                if entry.action == discord.AuditLogAction.role_update:
                    if entry.target.id == after.id:
                        if not await self._is_authorized(guild, entry.user.id):
                            # Restore role to backup state
                            restored = await self.backup_manager.restore_role_permissions(guild, after.id)
                            
                            threat = ThreatEvent(
                                type="role_update",
                                guild_id=guild.id,
                                actor_id=entry.user.id,
                                target_id=after.id,
                                target_name=after.name,
                                prevented=True,
                                restored=restored,
                                details={"changed": "permissions/position"}
                            )
                            
                            await self.sdk._trigger_callbacks('threat_detected', threat)
                        break
        except Exception as e:
            print(f"Error in role_update handler: {e}")
