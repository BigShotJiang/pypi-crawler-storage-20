"""
Channel protection handler for SecureX SDK.
"""
import discord
import asyncio
from datetime import datetime, timedelta
from ..models import ThreatEvent


class ChannelHandler:
    """Handles channel protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized (owner or whitelisted)"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True  # Bot is always authorized
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_channel_create(self, channel: discord.abc.GuildChannel):
        """Detect unauthorized channel creation - uses lock to prevent duplicate processing"""
        try:
            guild = channel.guild
            
            # Get or create lock for this guild
            if guild.id not in self.sdk._spam_locks:
                self.sdk._spam_locks[guild.id] = asyncio.Lock()
            
            # Only ONE handler processes spam at a time
            async with self.sdk._spam_locks[guild.id]:
                # Wait briefly for spam to finish
                await asyncio.sleep(0.5)
                
                # Get audit logs for last 30 seconds (timezone-aware)
                from datetime import timezone
                cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
                
                unauthorized_channels = []
                violator = None
                
                async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.channel_create):
                    # Stop if older than 30 seconds
                    if entry.created_at < cutoff_time:
                        break
                    
                    # Check if unauthorized
                    if not await self._is_authorized(guild, entry.user.id):
                        # Find the channel if it still exists
                        created_channel = guild.get_channel(entry.target.id)
                        if created_channel:
                            unauthorized_channels.append(created_channel)
                        if violator is None:
                            violator = entry.user
                
                # Process spam if detected (only first handler does this)
                if unauthorized_channels and violator:
                    print(f"🚨 Detected {len(unauthorized_channels)} spam channels from {violator.name}")
                    
                    # STEP 1: PUNISH IMMEDIATELY to stop the attack
                    print(f"⚡ Punishing {violator.name} to stop attack...")
                    punishment_action = await self.sdk.punisher.punish(
                        guild=guild,
                        user=violator,
                        violation_type="channel_create",
                        details=f"Spam created {len(unauthorized_channels)} channels",
                        sdk=self.sdk
                    )
                    print(f"✅ Punishment applied: {punishment_action}")
                    
                    # STEP 2: Now safely batch delete all spam channels
                    print(f"🧹 Cleaning up {len(unauthorized_channels)} spam channels...")
                    deleted_count = 0
                    
                    for spam_channel in unauthorized_channels:
                        try:
                            await spam_channel.delete(reason="SecureX: Spam channel creation")
                            deleted_count += 1
                        except discord.errors.NotFound:
                            # Channel already deleted - that's fine
                            pass
                        except Exception as e:
                            print(f"Error deleting channel {spam_channel.name}: {e}")
                    
                    print(f"✅ Deleted {deleted_count}/{len(unauthorized_channels)} spam channels")
                    
                    # Create threat event
                    threat = ThreatEvent(
                        type="channel_create",
                        guild_id=guild.id,
                        actor_id=violator.id,
                        target_id=channel.id,
                        target_name=f"{len(unauthorized_channels)} spam channels",
                        prevented=True,
                        restored=False,
                        punishment_action=punishment_action,
                        details={
                            "spam_count": len(unauthorized_channels),
                            "deleted_count": deleted_count
                        }
                    )
                    
                    await self.sdk._trigger_callbacks('threat_detected', threat)
                # If no spam found, this handler came late - first one already handled it
                
        except Exception as e:
            print(f"Error in channel_create handler: {e}")
    
    async def on_channel_delete(self, channel: discord.abc.GuildChannel):
        """Detect and restore unauthorized channel deletion"""
        try:
            guild = channel.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                if entry.target.id == channel.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        print(f"🔄 Unauthorized channel deletion by {entry.user.name}")
                        print(f"   Channel: {channel.name} (ID: {channel.id})")
                        
                        # Restore the channel
                        new_channel = await self.backup_manager.restore_channel(guild, channel)
                        
                        if new_channel:
                            print(f"✅ Restored channel: {new_channel.name}")
                            
                            # If this was a category, restore its children too
                            if isinstance(channel, discord.CategoryChannel):
                                print(f"📁 This was a category - restoring children...")
                                await self.backup_manager.restore_category_children(
                                    guild, 
                                    channel.id,  # old_category_id
                                    new_channel.id  # new_category_id
                                )
                        
                        # Punish violator
                        punishment_action = await self.sdk.punisher.punish(
                            guild=guild,
                            user=entry.user,
                            violation_type="channel_delete",
                            details=f"Deleted #{channel.name}",
                            sdk=self.sdk
                        )
                        
                        # Create threat event
                        threat = ThreatEvent(
                            type="channel_delete",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=channel.id,
                            target_name=channel.name,
                            prevented=True,
                            restored=new_channel is not None,
                            punishment_action=punishment_action
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in channel_delete handler: {e}")
    
    async def on_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        """Detect unauthorized channel updates"""
        try:
            # Only check permission or position changes
            if (before.overwrites == after.overwrites and 
                before.position == after.position):
                return
            
            guild = after.guild
            await asyncio.sleep(0.5)
            
            async for entry in guild.audit_logs(limit=3, oldest_first=False):
                if entry.action == discord.AuditLogAction.channel_update:
                    if entry.target and entry.target.id == after.id:
                        # Check if changes were unauthorized 
                        if not await self._is_authorized(guild, entry.user.id):
                            # Restore channel permissions
                            restored = await self.backup_manager.restore_channel_permissions(guild, after.id)
                            
                            # Create threat event
                            threat = ThreatEvent(
                                type="channel_update",
                                guild_id=guild.id,
                                actor_id=entry.user.id,
                                target_id=after.id,
                                target_name=after.name,
                                prevented=True,
                                restored=restored,
                                details={"changed": "permissions/position"}
                            )
                            
                            # Trigger callback
                            await self.sdk._trigger_callbacks('threat_detected', threat)
                        break
        except Exception as e:
            print(f"Error in channel_update handler: {e}")
