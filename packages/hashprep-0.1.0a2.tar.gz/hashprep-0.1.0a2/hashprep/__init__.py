from .core.analyzer import DatasetAnalyzer

__version__ = "0.1.0a2"
