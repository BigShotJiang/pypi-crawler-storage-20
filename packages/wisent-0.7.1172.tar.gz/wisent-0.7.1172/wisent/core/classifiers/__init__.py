"""Classifier modules for wisent."""
