class MrokError(Exception):
    pass
