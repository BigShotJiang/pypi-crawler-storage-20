"""
Basic tests for DSLighting simplified API.

Run with:
    python tests/test_dslighting_api.py
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import dslighting
import pandas as pd


def test_imports():
    """Test that all public API can be imported."""
    print("Testing imports...")

    assert hasattr(dslighting, 'Agent')
    assert hasattr(dslighting, 'AgentResult')
    assert hasattr(dslighting, 'DataLoader')
    assert hasattr(dslighting, 'LoadedData')
    assert hasattr(dslighting, 'load_data')
    assert hasattr(dslighting, 'run_agent')

    print("✓ All imports successful")


def test_agent_creation():
    """Test Agent initialization."""
    print("\nTesting Agent creation...")

    # Default agent
    agent = dslighting.Agent()
    assert agent.config is not None
    assert agent.config.workflow.name == "aide"

    # Custom agent
    agent = dslighting.Agent(
        workflow="autokaggle",
        model="gpt-4o",
        temperature=0.5
    )
    assert agent.config.workflow.name == "autokaggle"
    assert agent.config.llm.model == "gpt-4o"
    assert agent.config.llm.temperature == 0.5

    print("✓ Agent creation successful")


def test_data_loader():
    """Test DataLoader."""
    print("\nTesting DataLoader...")

    loader = dslighting.DataLoader()

    # Test question loading
    data = loader.load_question("What is 2+2?")
    assert data.task_detection is not None
    assert data.task_detection.task_type == "qa"

    # Test DataFrame loading
    df = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    data = loader.load_dataframe(df)
    assert data.task_detection is not None
    assert data.task_detection.task_type == "datasci"

    print("✓ DataLoader successful")


def test_task_detector():
    """Test TaskDetector."""
    print("\nTesting TaskDetector...")

    from dslighting.core.task_detector import TaskDetector

    detector = TaskDetector()

    # Test QA detection
    detection = detector.detect("What is the capital of France?")
    assert detection.task_type == "qa"
    assert detection.recommended_workflow == "aide"

    # Test DataFrame detection
    df = pd.DataFrame({'X': [1, 2, 3], 'y': [4, 5, 6]})
    detection = detector.detect(df)
    assert detection.task_type == "datasci"

    print("✓ TaskDetector successful")


def test_config_builder():
    """Test ConfigBuilder."""
    print("\nTesting ConfigBuilder...")

    from dslighting.core.config_builder import ConfigBuilder

    builder = ConfigBuilder()
    config = builder.build_config(
        workflow="aide",
        model="gpt-4o-mini",
        temperature=0.7
    )

    assert config.workflow.name == "aide"
    assert config.llm.model == "gpt-4o-mini"
    assert config.llm.temperature == 0.7

    print("✓ ConfigBuilder successful")


def test_convenience_functions():
    """Test convenience functions."""
    print("\nTesting convenience functions...")

    # Test load_data
    data = dslighting.load_data("What is 3+3?")
    assert data.task_detection is not None

    print("✓ Convenience functions successful")


def main():
    """Run all tests."""
    print("=" * 60)
    print("DSLighting API Tests")
    print("=" * 60)

    try:
        test_imports()
        test_agent_creation()
        test_data_loader()
        test_task_detector()
        test_config_builder()
        test_convenience_functions()

        print("\n" + "=" * 60)
        print("✓ All tests passed!")
        print("=" * 60)

    except AssertionError as e:
        print(f"\n✗ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
