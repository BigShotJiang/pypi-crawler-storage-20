__version__ = "0.24.0"


def get_version() -> str:
    return __version__
