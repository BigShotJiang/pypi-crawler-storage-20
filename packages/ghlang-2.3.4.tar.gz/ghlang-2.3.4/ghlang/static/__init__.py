"""Static assets for ghlang"""
