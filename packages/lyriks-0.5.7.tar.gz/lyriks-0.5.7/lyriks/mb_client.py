import time
from json.decoder import JSONDecodeError
from re import Pattern
from typing import NewType

import trio
from httpx import AsyncClient as HttpClient
from httpx import RequestError
from rich.markup import escape
from stamina import retry
from trio import Lock

from .cli.console import console
from .const import VERSION

Mbid = NewType('Mbid', str)

DEFAULT_MUSICBRAINZ_SERVER_URL = 'https://musicbrainz.org'
API_PATH = 'ws/2'
USER_AGENT = f'lyriks/{VERSION} ( max@maxr1998.de )'
_ARTIST_INC = 'url-rels'
_RELEASE_INC = 'artist-credits+release-groups+recordings+media+url-rels'

_DEFAULT_RATE_LIMIT_DELAY = 1.0  # seconds


class Artist:
    def __init__(self, data: dict):
        self.data = data
        self.id: Mbid = data['id']
        self.name: str = data['name']
        self.urls: set = {
            relation['url']['resource']
            for relation in data.get('relations', [])
            if relation.get('target-type') == 'url'
        }

    @property
    def url(self):
        return f'{DEFAULT_MUSICBRAINZ_SERVER_URL}/artist/{self.id}'

    @property
    def rich_string(self) -> str:
        return f'[underline][link={self.url}]{escape(self.name)}[/link][/underline]'


class Release:
    def __init__(self, data: dict):
        self.data = data
        self.id: Mbid = data['id']
        self.title: str = data['title']
        self.artist_credit: dict = data['artist-credit']
        self.rg_mbid: Mbid = data['release-group']['id']
        self.media: list = self.data['media']

    def get_track_count(self) -> int:
        return sum(medium['track-count'] for medium in self.media)

    def get_track_map(self) -> list[dict[Mbid, dict]]:
        return [{track['id']: track for track in medium['tracks']} for medium in self.media]

    @property
    def url(self):
        return f'{DEFAULT_MUSICBRAINZ_SERVER_URL}/release/{self.id}'

    @property
    def rich_string(self) -> str:
        return f'[underline][link={self.url}]{escape(self.title)}[/link][/underline]'

    def extract_url_str(self, pattern: Pattern) -> str | None:
        """
        Extracts an ID from the release's URL relations using the provided RegEx pattern.
        The pattern must contain exactly one capturing group for the ID.
        """
        if pattern.groups != 1:
            raise ValueError("Pattern must contain exactly one capturing group: %r" % pattern)

        relations = self.data['relations']
        for relation in relations:
            if relation.get('target-type') != 'url' or relation.get('ended'):
                continue
            url = relation['url']['resource']
            match = pattern.fullmatch(url)
            if match:
                return match.group(1)
        return None

    def extract_url_id(self, pattern: Pattern) -> int | None:
        """
        Extracts an integer ID from the release's URL relations using the provided RegEx pattern.
        The pattern must contain exactly one capturing group for the ID.
        """
        id_str = self.extract_url_str(pattern)
        if id_str is None:
            return None

        try:
            return int(id_str)
        except ValueError:
            return None


class RequestRateLimiter:
    def __init__(self, delay: float):
        self.delay: float = delay
        self.lock: Lock = Lock()
        self.last_request_time: float = 0

    async def __aenter__(self):
        await self.lock.acquire()
        time_since = time.time() - self.last_request_time
        if time_since <= self.delay:
            await trio.sleep(self.delay - time_since)

    def notify_request(self):
        """
        Notify the rate limiter that a request has been made.
        Must be called in the context of this rate limiter.
        """
        self.last_request_time = time.time()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.lock.release()


mb_api_url = f'{DEFAULT_MUSICBRAINZ_SERVER_URL}/{API_PATH}'
rate_limiter = RequestRateLimiter(delay=_DEFAULT_RATE_LIMIT_DELAY)
has_custom_server = False


def set_server_url(server_url: str):
    global mb_api_url, rate_limiter, has_custom_server
    mb_api_url = f'{server_url}/{API_PATH}'
    rate_limiter = RequestRateLimiter(delay=_DEFAULT_RATE_LIMIT_DELAY)  # reset delay to default
    has_custom_server = server_url != DEFAULT_MUSICBRAINZ_SERVER_URL
    if has_custom_server:
        console.print(f'Using custom MusicBrainz server URL: {server_url}', style='warning')


def set_rate_limit(delay: float) -> bool:
    """
    Set the minimum delay between requests to the MusicBrainz API.
    Can only be set when using a custom MusicBrainz server URL.

    :return: True if the rate limit was set, False otherwise.
    """
    if not has_custom_server:
        return False

    global rate_limiter
    rate_limiter = RequestRateLimiter(delay=delay)

    return True


artist_cache: dict[Mbid, Artist | None] = {}
release_group_cache: dict[Mbid, list[Release]] = {}
track_release_cache: dict[Mbid, Release | None] = {}


@retry(on=RequestError, attempts=3)
async def get_artist(http_client: HttpClient, artist_mbid: Mbid) -> Artist | None:
    # Initial cache check
    if artist_mbid in artist_cache:
        return artist_cache[artist_mbid]

    async with rate_limiter:
        # Check cache again inside rate limiter lock
        if artist_mbid in artist_cache:
            return artist_cache[artist_mbid]

        artist_url = f'{mb_api_url}/artist/{artist_mbid}?inc={_ARTIST_INC}'
        try:
            response = (
                await http_client.get(
                    artist_url,
                    headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'},
                )
            ).json()
        except JSONDecodeError:
            return None
        finally:
            rate_limiter.notify_request()

        if 'error' in response:
            console.print(f'[bold red]Error: {escape(repr(response["error"]))}')
            return None

        artist = Artist(response)

        # Cache result
        artist_cache[artist_mbid] = artist

    return artist


@retry(on=RequestError, attempts=3)
async def _get_releases(http_client: HttpClient, browse_url: str) -> list[Release]:
    try:
        response = (
            await http_client.get(
                browse_url,
                headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'},
            )
        ).json()
    except JSONDecodeError:
        return []

    return [Release(release) for release in response.get("releases", [])]


async def get_release_by_track(http_client: HttpClient, track_mbid: Mbid) -> Release | None:
    # Initial cache check
    if track_mbid in track_release_cache:
        return track_release_cache[track_mbid]

    async with rate_limiter:
        # Check cache again inside rate limiter lock
        if track_mbid in track_release_cache:
            return track_release_cache[track_mbid]

        try:
            releases = await _get_releases(
                http_client, f'{mb_api_url}/release?track={track_mbid}&status=official&inc={_RELEASE_INC}'
            )
        finally:
            rate_limiter.notify_request()

        release = next(iter(releases), None)

        # Cache release for each contained track
        if release is not None:
            for media in release.media:
                for track in media['tracks']:
                    track_mbid: Mbid = track['id']
                    track_release_cache[track_mbid] = release

    return release


async def get_releases_by_release_group(http_client: HttpClient, rg_mbid: Mbid) -> list[Release]:
    # Initial cache check
    if rg_mbid in release_group_cache:
        return release_group_cache[rg_mbid]

    async with rate_limiter:
        # Check cache again inside rate limiter lock
        if rg_mbid in release_group_cache:
            return release_group_cache[rg_mbid]

        try:
            releases = await _get_releases(
                http_client, f'{mb_api_url}/release?release-group={rg_mbid}&status=official&inc={_RELEASE_INC}'
            )
        finally:
            rate_limiter.notify_request()

        # Cache result
        release_group_cache[rg_mbid] = releases

    return releases
