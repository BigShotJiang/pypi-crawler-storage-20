"""
DeepAudioX: A deep learning framework for end-to-end audio classification.

This package provides modules for:
- Dataset management and preprocessing
- Model architectures
- Training, evaluation, and inference utilities
"""

__version__ = "0.1.1"
