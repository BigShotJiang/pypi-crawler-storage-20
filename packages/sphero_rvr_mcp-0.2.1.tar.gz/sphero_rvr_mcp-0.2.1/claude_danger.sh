claude --dangerously-skip-permissions
