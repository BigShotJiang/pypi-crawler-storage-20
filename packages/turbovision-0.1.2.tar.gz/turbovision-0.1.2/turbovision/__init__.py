"""
TurboVision Package
"""

from .main import Turbo

__version__ = "0.1.2"
__all__ = ["Turbo"]

