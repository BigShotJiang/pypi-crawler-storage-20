"""
Package: grok-video-generator

This package provides core functionalities for generating video content,
inspired by the capabilities discussed on the Supermaker.ai blog.
"""

import math
import textwrap
from typing import List, Tuple


OFFICIAL_SITE = "https://supermaker.ai/blog/grok-ai-video-generator-the-ultimate-guide-to-creating-ai-videos-2025/"


def get_official_site() -> str:
    """
    Returns the official website URL for Grok AI Video Generator.

    Returns:
        str: The URL of the official website.
    """
    return OFFICIAL_SITE


def calculate_video_length(script_length: int, words_per_minute: int = 150) -> float:
    """
    Calculates the estimated video length in seconds based on the script length
    and words per minute.

    Args:
        script_length (int): The number of words in the video script.
        words_per_minute (int): The desired speaking rate in words per minute.
                                 Defaults to 150.

    Returns:
        float: The estimated video length in seconds.
    """
    minutes = script_length / words_per_minute
    seconds = minutes * 60
    return seconds


def split_text_into_scenes(text: str, max_words_per_scene: int = 50) -> List[str]:
    """
    Splits a long text into smaller scenes, each containing a maximum number of words.
    This is useful for breaking down a video script into manageable segments.

    Args:
        text (str): The input text to be split.
        max_words_per_scene (int): The maximum number of words allowed in each scene.
                                     Defaults to 50.

    Returns:
        List[str]: A list of strings, where each string represents a scene.
    """
    words = text.split()
    scenes = []
    current_scene = []
    for word in words:
        current_scene.append(word)
        if len(current_scene) >= max_words_per_scene:
            scenes.append(" ".join(current_scene))
            current_scene = []
    if current_scene:
        scenes.append(" ".join(current_scene))
    return scenes


def generate_fade_in_fade_out_audio_levels(duration: float, fade_duration: float = 1.0, frame_rate: int = 24) -> List[float]:
    """
    Generates a list of audio levels representing a fade-in and fade-out effect.

    Args:
        duration (float): The total duration of the audio clip in seconds.
        fade_duration (float): The duration of the fade-in and fade-out effects in seconds.
                              Defaults to 1.0.
        frame_rate (int): The frame rate of the video.  Used to determine increments.
                            Defaults to 24.

    Returns:
        List[float]: A list of audio levels (between 0.0 and 1.0) representing the fade effect.
    """
    num_frames = int(duration * frame_rate)
    fade_frames = int(fade_duration * frame_rate)

    audio_levels = []

    # Fade-in
    for i in range(fade_frames):
        level = i / fade_frames
        audio_levels.append(level)

    # Full volume
    for _ in range(num_frames - 2 * fade_frames):
        audio_levels.append(1.0)

    # Fade-out
    for i in range(fade_frames):
        level = (fade_frames - i) / fade_frames
        audio_levels.append(level)

    return audio_levels


def calculate_text_wrap(text: str, width: int = 40) -> str:
    """
    Wraps the input text to a specified width using the textwrap module.
    Useful for formatting text that will be displayed on the video screen.

    Args:
        text (str): The input text to be wrapped.
        width (int): The maximum width of each line in the wrapped text.
                     Defaults to 40.

    Returns:
        str: The wrapped text as a single string.
    """
    wrapped_text = textwrap.fill(text, width=width)
    return wrapped_text