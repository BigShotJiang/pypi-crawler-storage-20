from setuptools import setup, find_packages

setup(
    name="grok-video-generator",
    version="1768377.239.270",
    description="High-quality integration for https://supermaker.ai/blog/grok-ai-video-generator-the-ultimate-guide-to-creating-ai-videos-2025/",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="SuperMaker",
    url="https://supermaker.ai/blog/grok-ai-video-generator-the-ultimate-guide-to-creating-ai-videos-2025/",
    packages=find_packages(),
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
