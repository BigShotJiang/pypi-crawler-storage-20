# grok-video-generator

A streamlined Python library designed to simplify the creation of videos leveraging the capabilities described in the SuperMaker.ai guide. This package provides a convenient interface for generating video content based on predefined templates and data inputs.

## Installation

Install the `grok-video-generator` package using pip:
bash
pip install grok-video-generator

## Basic Usage

Here are a few examples demonstrating how to use the `grok-video-generator` library:

**1. Creating a Product Demo Video:**
python
from grok_video_generator import VideoGenerator

# Initialize the video generator with a product demo template
generator = VideoGenerator(template_type="product_demo")

# Define product details
product_data = {
    "product_name": "SuperWidget X",
    "features": ["Enhanced Performance", "User-Friendly Interface", "Advanced Security"],
    "price": 99.99
}

# Generate the video
video_path = generator.generate_video(data=product_data, output_filename="superwidget_demo.mp4")

print(f"Product demo video generated at: {video_path}")

**2. Generating a Social Media Ad:**
python
from grok_video_generator import VideoGenerator

# Initialize the video generator with a social media ad template
generator = VideoGenerator(template_type="social_media_ad")

# Define ad content
ad_data = {
    "headline": "Unlock Your Potential with Grok!",
    "description": "Learn cutting-edge video creation techniques.",
    "call_to_action": "Sign Up Today!",
    "website_url": "https://supermaker.ai"
}

# Generate the video
video_path = generator.generate_video(data=ad_data, output_filename="grok_ad.mp4")

print(f"Social media ad video generated at: {video_path}")

**3. Creating an Explainer Video:**
python
from grok_video_generator import VideoGenerator

# Initialize the video generator with an explainer video template
generator = VideoGenerator(template_type="explainer_video")

# Define the explanation content
explainer_data = {
    "topic": "Artificial Intelligence",
    "steps": [
        "Collect Data",
        "Train Model",
        "Evaluate Performance",
        "Deploy Solution"
    ]
}

# Generate the video
video_path = generator.generate_video(data=explainer_data, output_filename="ai_explainer.mp4")

print(f"Explainer video generated at: {video_path}")

**4. Generating a Personalized Birthday Greeting Video:**
python
from grok_video_generator import VideoGenerator

# Initialize the video generator with a birthday greeting template
generator = VideoGenerator(template_type="birthday_greeting")

# Define the recipient details
greeting_data = {
    "recipient_name": "Alice",
    "sender_name": "Bob",
    "message": "Happy Birthday, Alice! Wishing you a fantastic year ahead."
}

# Generate the video
video_path = generator.generate_video(data=greeting_data, output_filename="alice_birthday.mp4")

print(f"Birthday greeting video generated at: {video_path}")

## Feature List

*   **Template-Based Video Generation:** Easily create videos using predefined templates for various purposes.
*   **Data-Driven Content:** Populate video content dynamically with data inputs.
*   **Simplified API:** A straightforward and intuitive API for seamless integration.
*   **Customizable Output:** Control the output filename and video format.
*   **Pre-configured Templates:** Includes templates for product demos, social media ads, explainer videos, and personalized greetings.

## License

MIT License

This project is a gateway to the grok-video-generator ecosystem. For advanced features and full capabilities, please visit: https://supermaker.ai/blog/grok-ai-video-generator-the-ultimate-guide-to-creating-ai-videos-2025/