__version__ = "0.66.0"

API_VERSION = "v0.1.507"
SDK_VERSION = __version__
