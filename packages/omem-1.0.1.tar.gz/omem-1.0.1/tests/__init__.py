"""Tests for omem SDK."""

