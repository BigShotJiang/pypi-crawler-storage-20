"""Tursu domain model."""
