# SPDX-License-Identifier: Apache-2.0.
# Copyright (c) 2024 - 2026 Waldiez and contributors.
"""Version information for waldiez_runner."""

__version__ = "0.7.1"
