# SPDX-License-Identifier: Apache-2.0.
# Copyright (c) 2024 - 2026 Waldiez and contributors.
"""Waldiez runner package."""

from ._version import __version__  # noqa

__all__ = ["__version__"]
