# -*- code: utf-8 -*-
# SPDX-License-Identifier: EPL-1.0
##############################################################################
# Copyright (c) 2018 The Linux Foundation and others.
#
# All rights reserved. This program and the accompanying materials
# are made available under the terms of the Eclipse Public License v1.0
# which accompanies this distribution, and is available at
# http://www.eclipse.org/legal/epl-v10.html
##############################################################################
"""stack related sub-commands for openstack command."""

__author__ = "Thanh Ha"

import json
import logging
import sys
import time
import urllib.request
from datetime import datetime

import openstack
import openstack.config
from openstack.cloud.exc import OpenStackCloudHTTPError

from lftools.jenkins import Jenkins

log = logging.getLogger(__name__)


def create(os_cloud, name, template_file, parameter_file, timeout=900, tries=2):
    """Create a heat stack from a template_file and a parameter_file."""
    cloud = openstack.connection.from_config(cloud=os_cloud)
    stack_success = False

    print("Creating stack {}".format(name))
    for i in range(tries):
        try:
            stack = cloud.create_stack(
                name, template_file=template_file, environment_files=[parameter_file], timeout=timeout, rollback=False
            )
        except OpenStackCloudHTTPError as e:
            if cloud.search_stacks(name):
                print("Stack with name {} already exists.".format(name))
            else:
                print(e)
            sys.exit(1)

        stack_id = stack.id
        t_end = time.time() + timeout
        while time.time() < t_end:
            time.sleep(10)
            stack = cloud.get_stack(stack_id)

            if stack.status == "CREATE_IN_PROGRESS":
                print("Waiting to initialize infrastructure...")
            elif stack.status == "CREATE_COMPLETE":
                print("Stack initialization successful.")
                stack_success = True
                break
            elif stack.status == "CREATE_FAILED":
                print("WARN: Failed to initialize stack. Reason: {}".format(stack.status_reason))
                if delete(os_cloud, stack_id):
                    break
            else:
                print("Unexpected status: {}".format(stack.status))

        if stack_success:
            break

    print("------------------------------------")
    print("Stack Details")
    print("------------------------------------")
    cloud.pprint(stack)
    print("------------------------------------")


def cost(os_cloud, stack_name, timeout=60):
    """Get current cost info for the stack.

    Return the cost in dollars & cents (x.xx).

    Args:
        os_cloud: OpenStack cloud name from clouds.yaml
        stack_name: Name of the stack to calculate cost for
        timeout: Timeout in seconds for network operations (default: 60)
    """
    import socket

    def get_server_cost(server_id):
        try:
            flavor, seconds = get_server_info(server_id)
            url = "https://pricing.vexxhost.net/v1/pricing/%s/cost?seconds=%d"
            with urllib.request.urlopen(url % (flavor, seconds), timeout=timeout) as response:  # nosec
                data = json.loads(response.read())
            return data["cost"]
        except (urllib.error.URLError, socket.timeout) as e:
            log.warning("Failed to get cost for server %s: %s", server_id, e)
            log.warning("Returning 0 cost for this server")
            return 0.0
        except Exception as e:
            log.error("Unexpected error getting cost for server %s: %s", server_id, e)
            return 0.0

    def parse_iso8601_time(time):
        return datetime.strptime(time, "%Y-%m-%dT%H:%M:%S.%f")

    def get_server_info(server_id):
        server = cloud.compute.find_server(server_id)
        diff = datetime.utcnow() - parse_iso8601_time(server.launched_at)
        return server.flavor["original_name"], diff.total_seconds()

    def get_server_ids(stack_name):
        servers = get_resources_by_type(stack_name, "OS::Nova::Server")
        return [s["physical_resource_id"] for s in servers]

    def get_resources_by_type(stack_name, resource_type):
        resources = get_stack_resources(stack_name)
        return [r for r in resources if r.resource_type == resource_type]

    def get_stack_resources(stack_name):
        resources = []

        def _is_nested(resource):
            link_types = [link["rel"] for link in resource.links]
            if "nested" in link_types:
                return True
            return False

        for r in cloud.orchestration.resources(stack_name):
            if _is_nested(r):
                resources += get_stack_resources(r.physical_resource_id)
                continue
            resources.append(r)
        return resources

    cloud = openstack.connect(os_cloud)

    try:
        total_cost = 0.0
        server_ids = get_server_ids(stack_name)

        if not server_ids:
            log.info("No servers found in stack %s", stack_name)
            print("total: 0.0")
            return

        for server in server_ids:
            total_cost += get_server_cost(server)
        print("total: " + str(total_cost))
    except Exception as e:
        log.error("Error calculating stack cost: %s", e)
        log.warning("Returning 0 total cost due to error")
        print("total: 0.0")


def delete(os_cloud, name_or_id, force, timeout=900):
    """Delete a stack.

    Return True if delete was successful.
    """
    cloud = openstack.connection.from_config(cloud=os_cloud)
    print("Deleting stack {}".format(name_or_id))
    cloud.delete_stack(name_or_id)

    t_end = time.time() + timeout
    while time.time() < t_end:
        time.sleep(10)
        stack = cloud.get_stack(name_or_id)

        if not stack or stack.status == "DELETE_COMPLETE":
            print("Successfully deleted stack {}".format(name_or_id))
            return True
        elif stack.status == "DELETE_IN_PROGRESS":
            print("Waiting for stack to delete...")
        elif stack.status == "DELETE_FAILED":
            print("WARN: Failed to delete $STACK_NAME. Reason: {}".format(stack.status_reason))
            print("Retrying delete...")
            cloud.delete_stack(name_or_id)
        else:
            print("WARN: Unexpected delete status: {}".format(stack.status))
            print("Retrying delete...")
            cloud.delete_stack(name_or_id)

    print("Failed to delete stack {}".format(name_or_id))
    if not force:
        return False


def delete_stale(os_cloud, jenkins_servers):
    """Search Jenkins and OpenStack for orphaned stacks and remove them.

    An orphaned stack is a stack that is not known in any of the Jenkins
    servers passed into this function.
    """
    cloud = openstack.connection.from_config(cloud=os_cloud)
    stacks = cloud.search_stacks()
    if not stacks:
        log.debug("No stacks to delete.")
        sys.exit(0)

    builds = []
    for server in jenkins_servers:
        jenkins = Jenkins(server)
        jenkins_url = jenkins.url.rstrip("/")
        silo = jenkins_url.split("/")

        if len(silo) == 4:  # https://jenkins.opendaylight.org/releng
            silo = silo[3]
        elif len(silo) == 3:  # https://jenkins.onap.org
            silo = "production"
        else:
            log.error("Unexpected URL pattern, could not detect silo.")
            sys.exit(1)

        log.debug("Fetching running builds from {}".format(jenkins_url))
        running_builds = jenkins.server.get_running_builds()
        for build in running_builds:
            build_name = "{}-{}-{}".format(silo, build.get("name"), build.get("number"))
            log.debug("    {}".format(build_name))
            builds.append(build_name)

    log.debug("Active stacks")
    for stack in stacks:
        if stack.status == "CREATE_COMPLETE" or stack.status == "CREATE_FAILED" or stack.status == "DELETE_FAILED":
            log.debug("    {}".format(stack.stack_name))

            if stack.status == "DELETE_FAILED":
                cloud.pprint(stack)

            if stack.stack_name not in builds:
                log.debug("        >>>> Marked for deletion <<<<")
                delete(os_cloud, stack.stack_name)

        else:
            continue
