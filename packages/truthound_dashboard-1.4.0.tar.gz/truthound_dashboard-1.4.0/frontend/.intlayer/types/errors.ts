/* eslint-disable */
export default {
  "key": "errors",
  "content": {
    "nodeType": "translation",
    "translation": {
      "en": {
        "generic": "An error occurred. Please try again.",
        "notFound": "The requested resource was not found.",
        "unauthorized": "You are not authorized to perform this action.",
        "validation": "Please check your input and try again.",
        "network": "Network error. Please check your connection.",
        "serverError": "Server error. Please try again later.",
        "loadFailed": "Failed to load data"
      },
      "ko": {
        "generic": "오류가 발생했습니다. 다시 시도해 주세요.",
        "notFound": "요청한 리소스를 찾을 수 없습니다.",
        "unauthorized": "이 작업을 수행할 권한이 없습니다.",
        "validation": "입력을 확인하고 다시 시도해 주세요.",
        "network": "네트워크 오류입니다. 연결을 확인해 주세요.",
        "serverError": "서버 오류입니다. 나중에 다시 시도해 주세요.",
        "loadFailed": "데이터를 불러오지 못했습니다"
      }
    }
  },
  "localIds": [
    "errors::local::src/content/errors.content.ts"
  ]
} as const;
