/* eslint-disable */
export default {
  "key": "collaboration",
  "content": {
    "nodeType": "translation",
    "translation": {
      "en": {
        "comments": "Comments",
        "addComment": "Add Comment",
        "editComment": "Edit",
        "deleteComment": "Delete",
        "noComments": "No comments yet",
        "writeComment": "Write a comment...",
        "reply": "Reply",
        "replyTo": "Reply to comment",
        "cancelReply": "Cancel",
        "postComment": "Post",
        "commentPosted": "Comment posted",
        "commentUpdated": "Comment updated",
        "commentDeleted": "Comment deleted",
        "commentError": "Failed to post comment",
        "confirmDeleteComment": "Are you sure you want to delete this comment?",
        "activity": "Activity",
        "recentActivity": "Recent Activity",
        "allActivity": "All Activity",
        "noActivity": "No activity recorded",
        "loadMore": "Load more",
        "actions": {
          "created": "created",
          "updated": "updated",
          "deleted": "deleted",
          "commented": "commented on"
        },
        "resourceTypes": {
          "term": "term",
          "asset": "asset",
          "column": "column"
        },
        "timeAgo": {
          "justNow": "Just now",
          "minutesAgo": "{count} minutes ago",
          "hoursAgo": "{count} hours ago",
          "daysAgo": "{count} days ago",
          "weeksAgo": "{count} weeks ago",
          "monthsAgo": "{count} months ago"
        },
        "filterByResource": "Filter by resource",
        "allResources": "All resources"
      },
      "ko": {
        "comments": "댓글",
        "addComment": "댓글 추가",
        "editComment": "수정",
        "deleteComment": "삭제",
        "noComments": "댓글이 없습니다",
        "writeComment": "댓글을 작성하세요...",
        "reply": "답글",
        "replyTo": "답글 작성",
        "cancelReply": "취소",
        "postComment": "등록",
        "commentPosted": "댓글이 등록되었습니다",
        "commentUpdated": "댓글이 수정되었습니다",
        "commentDeleted": "댓글이 삭제되었습니다",
        "commentError": "댓글 등록에 실패했습니다",
        "confirmDeleteComment": "이 댓글을 삭제하시겠습니까?",
        "activity": "활동",
        "recentActivity": "최근 활동",
        "allActivity": "모든 활동",
        "noActivity": "기록된 활동이 없습니다",
        "loadMore": "더 보기",
        "actions": {
          "created": "생성됨",
          "updated": "수정됨",
          "deleted": "삭제됨",
          "commented": "댓글 작성"
        },
        "resourceTypes": {
          "term": "용어",
          "asset": "자산",
          "column": "컬럼"
        },
        "timeAgo": {
          "justNow": "방금 전",
          "minutesAgo": "{count}분 전",
          "hoursAgo": "{count}시간 전",
          "daysAgo": "{count}일 전",
          "weeksAgo": "{count}주 전",
          "monthsAgo": "{count}개월 전"
        },
        "filterByResource": "리소스 필터",
        "allResources": "모든 리소스"
      }
    }
  },
  "localIds": [
    "collaboration::local::src/content/collaboration.content.ts"
  ]
} as const;
