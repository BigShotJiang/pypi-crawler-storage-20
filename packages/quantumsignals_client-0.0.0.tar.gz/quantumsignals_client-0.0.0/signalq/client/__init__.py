"""Quantum Signals Python client library."""

from signalq.client.client import Client
from signalq.client.exceptions import (
    APIError,
    APIKeyError,
    QSClientError,
)
from signalq.client.models import (
    BacktestAccuracyMetrics,
    BacktestMetadata,
    BacktestResultRow,
    KongUserInfoResponse,
    ModelDescription,
    Signal,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "Client",
    # Models
    "Signal",
    "ModelDescription",
    "KongUserInfoResponse",
    "BacktestMetadata",
    "BacktestResultRow",
    "BacktestAccuracyMetrics",
    # Exceptions
    "QSClientError",
    "APIKeyError",
    "APIError",
]
