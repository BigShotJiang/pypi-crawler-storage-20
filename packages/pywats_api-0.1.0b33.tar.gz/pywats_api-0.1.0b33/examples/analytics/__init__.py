"""Analytics domain examples package."""
