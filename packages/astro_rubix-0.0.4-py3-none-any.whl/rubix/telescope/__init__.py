from .factory import TelescopeFactory
