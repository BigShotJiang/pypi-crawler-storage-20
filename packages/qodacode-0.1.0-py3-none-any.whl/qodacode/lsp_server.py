"""
Qodacode Language Server Protocol (LSP) Server.

Provides real-time code analysis for VSCode/Cursor with:
- Diagnostics (squiggly lines)
- Code actions (quick fixes)
- Hover information
- Incremental document sync

Run with: python -m qodacode.lsp_server
"""

import json
import sys
import threading
from typing import Any, Dict, List, Optional
from pathlib import Path
from dataclasses import dataclass, asdict

from qodacode.scanner import Scanner
from qodacode.rules.base import Severity

# LSP message types
CONTENT_LENGTH = "Content-Length: "


@dataclass
class Position:
    line: int
    character: int


@dataclass
class Range:
    start: Position
    end: Position


@dataclass
class Diagnostic:
    range: Range
    message: str
    severity: int  # 1=Error, 2=Warning, 3=Info, 4=Hint
    source: str = "qodacode"
    code: Optional[str] = None
    data: Optional[Dict] = None


class QodacodeLSPServer:
    """Language Server Protocol server for Qodacode."""

    def __init__(self):
        self.scanner = Scanner()
        self.documents: Dict[str, str] = {}  # uri -> content
        self.diagnostics_cache: Dict[str, List[Diagnostic]] = {}
        self.running = True
        self.capabilities = {
            "textDocumentSync": {
                "openClose": True,
                "change": 2,  # Incremental
                "save": {"includeText": True},
            },
            "diagnosticProvider": {
                "interFileDependencies": False,
                "workspaceDiagnostics": False,
            },
            "codeActionProvider": {
                "codeActionKinds": ["quickfix"],
            },
            "hoverProvider": True,
        }

    def run(self):
        """Main server loop - reads JSON-RPC messages from stdin."""
        while self.running:
            try:
                message = self._read_message()
                if message:
                    response = self._handle_message(message)
                    if response:
                        self._send_message(response)
            except Exception as e:
                self._log(f"Error: {e}")

    def _read_message(self) -> Optional[Dict]:
        """Read a JSON-RPC message from stdin."""
        headers = {}

        # Read headers
        while True:
            line = sys.stdin.readline()
            if not line or line == "\r\n":
                break
            if line.startswith(CONTENT_LENGTH):
                headers["content-length"] = int(line[len(CONTENT_LENGTH):].strip())

        if "content-length" not in headers:
            return None

        # Read content
        content = sys.stdin.read(headers["content-length"])
        return json.loads(content)

    def _send_message(self, message: Dict):
        """Send a JSON-RPC message to stdout."""
        content = json.dumps(message)
        header = f"Content-Length: {len(content)}\r\n\r\n"
        sys.stdout.write(header + content)
        sys.stdout.flush()

    def _send_notification(self, method: str, params: Dict):
        """Send a notification (no response expected)."""
        self._send_message({
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        })

    def _log(self, message: str):
        """Log a message to the client."""
        self._send_notification("window/logMessage", {
            "type": 3,  # Info
            "message": f"[Qodacode] {message}",
        })

    def _handle_message(self, message: Dict) -> Optional[Dict]:
        """Handle incoming JSON-RPC message."""
        method = message.get("method", "")
        params = message.get("params", {})
        msg_id = message.get("id")

        # Requests (need response)
        if method == "initialize":
            return self._handle_initialize(msg_id, params)
        elif method == "shutdown":
            return self._handle_shutdown(msg_id)
        elif method == "textDocument/codeAction":
            return self._handle_code_action(msg_id, params)
        elif method == "textDocument/hover":
            return self._handle_hover(msg_id, params)

        # Notifications (no response)
        elif method == "initialized":
            self._log("Server initialized")
        elif method == "exit":
            self.running = False
        elif method == "textDocument/didOpen":
            self._handle_did_open(params)
        elif method == "textDocument/didChange":
            self._handle_did_change(params)
        elif method == "textDocument/didSave":
            self._handle_did_save(params)
        elif method == "textDocument/didClose":
            self._handle_did_close(params)

        return None

    def _handle_initialize(self, msg_id: int, params: Dict) -> Dict:
        """Handle initialize request."""
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                "capabilities": self.capabilities,
                "serverInfo": {
                    "name": "qodacode-lsp",
                    "version": "0.1.0",
                },
            },
        }

    def _handle_shutdown(self, msg_id: int) -> Dict:
        """Handle shutdown request."""
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": None,
        }

    def _handle_did_open(self, params: Dict):
        """Handle document open."""
        uri = params["textDocument"]["uri"]
        text = params["textDocument"]["text"]
        self.documents[uri] = text
        self._analyze_document(uri)

    def _handle_did_change(self, params: Dict):
        """Handle document change (incremental)."""
        uri = params["textDocument"]["uri"]
        changes = params.get("contentChanges", [])

        if uri in self.documents:
            # Apply incremental changes
            content = self.documents[uri]
            for change in changes:
                if "range" in change:
                    # Incremental update
                    start = change["range"]["start"]
                    end = change["range"]["end"]
                    lines = content.split("\n")

                    # Calculate offset
                    start_offset = sum(len(lines[i]) + 1 for i in range(start["line"])) + start["character"]
                    end_offset = sum(len(lines[i]) + 1 for i in range(end["line"])) + end["character"]

                    content = content[:start_offset] + change["text"] + content[end_offset:]
                else:
                    # Full content replacement
                    content = change["text"]

            self.documents[uri] = content

        # Debounced analysis (300ms) - run in thread
        self._schedule_analysis(uri)

    def _handle_did_save(self, params: Dict):
        """Handle document save."""
        uri = params["textDocument"]["uri"]
        if "text" in params:
            self.documents[uri] = params["text"]
        self._analyze_document(uri)

    def _handle_did_close(self, params: Dict):
        """Handle document close."""
        uri = params["textDocument"]["uri"]
        if uri in self.documents:
            del self.documents[uri]
        if uri in self.diagnostics_cache:
            del self.diagnostics_cache[uri]
        # Clear diagnostics
        self._send_notification("textDocument/publishDiagnostics", {
            "uri": uri,
            "diagnostics": [],
        })

    def _schedule_analysis(self, uri: str):
        """Schedule analysis with debounce."""
        # Simple debounce using timer
        timer = threading.Timer(0.3, lambda: self._analyze_document(uri))
        timer.start()

    def _analyze_document(self, uri: str):
        """Analyze document and publish diagnostics."""
        if uri not in self.documents:
            return

        # Convert URI to file path
        filepath = uri.replace("file://", "")

        try:
            # Scan the document content
            content = self.documents[uri]

            # Write to temp file for scanning (or modify scanner to accept content)
            import tempfile
            import os

            # Get file extension from URI
            ext = Path(filepath).suffix

            with tempfile.NamedTemporaryFile(mode='w', suffix=ext, delete=False) as f:
                f.write(content)
                temp_path = f.name

            try:
                result = self.scanner.scan_file(temp_path)
                diagnostics = self._convert_to_diagnostics(result.issues)
                self.diagnostics_cache[uri] = diagnostics

                # Publish diagnostics
                self._send_notification("textDocument/publishDiagnostics", {
                    "uri": uri,
                    "diagnostics": [self._diagnostic_to_dict(d) for d in diagnostics],
                })
            finally:
                os.unlink(temp_path)

        except Exception as e:
            self._log(f"Analysis error: {e}")

    def _convert_to_diagnostics(self, issues: List) -> List[Diagnostic]:
        """Convert scanner issues to LSP diagnostics."""
        diagnostics = []

        severity_map = {
            Severity.CRITICAL: 1,  # Error
            Severity.HIGH: 1,      # Error
            Severity.MEDIUM: 2,    # Warning
            Severity.LOW: 3,       # Info
        }

        for issue in issues:
            diag = Diagnostic(
                range=Range(
                    start=Position(line=max(0, issue.location.line - 1), character=0),
                    end=Position(line=max(0, issue.location.line - 1), character=1000),
                ),
                message=f"[{issue.rule_id}] {issue.message}",
                severity=severity_map.get(issue.severity, 2),
                code=issue.rule_id,
                data={
                    "rule_id": issue.rule_id,
                    "fix_suggestion": issue.fix_suggestion,
                },
            )
            diagnostics.append(diag)

        return diagnostics

    def _diagnostic_to_dict(self, diag: Diagnostic) -> Dict:
        """Convert Diagnostic to dict for JSON serialization."""
        return {
            "range": {
                "start": {"line": diag.range.start.line, "character": diag.range.start.character},
                "end": {"line": diag.range.end.line, "character": diag.range.end.character},
            },
            "message": diag.message,
            "severity": diag.severity,
            "source": diag.source,
            "code": diag.code,
            "data": diag.data,
        }

    def _handle_code_action(self, msg_id: int, params: Dict) -> Dict:
        """Handle code action request (quick fixes)."""
        uri = params["textDocument"]["uri"]
        range_params = params["range"]

        actions = []

        # Get diagnostics at this location
        if uri in self.diagnostics_cache:
            for diag in self.diagnostics_cache[uri]:
                if self._range_overlaps(diag.range, range_params):
                    rule_id = diag.code

                    # Only "Learn more" action - opens documentation
                    # NOTE: "Fix" and "Ignore" actions removed because they had no
                    # actual implementation (no TextEdit). Better to show nothing
                    # than broken UI that frustrates users.
                    actions.append({
                        "title": f"Learn about {rule_id}",
                        "kind": "quickfix",
                        "command": {
                            "title": "Learn More",
                            "command": "vscode.open",
                            "arguments": [f"https://qodacode.dev/rules/{rule_id.lower()}"],
                        },
                    })

        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": actions,
        }

    def _handle_hover(self, msg_id: int, params: Dict) -> Dict:
        """Handle hover request."""
        uri = params["textDocument"]["uri"]
        position = params["position"]

        hover_content = None

        # Check if there's a diagnostic at this position
        if uri in self.diagnostics_cache:
            for diag in self.diagnostics_cache[uri]:
                if self._position_in_range(position, diag.range):
                    rule_id = diag.code
                    fix = diag.data.get("fix_suggestion") if diag.data else None

                    content = f"**{rule_id}**: {diag.message}"
                    if fix:
                        content += f"\n\n**Fix:** {fix}"

                    hover_content = {
                        "contents": {
                            "kind": "markdown",
                            "value": content,
                        },
                    }
                    break

        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": hover_content,
        }

    def _range_overlaps(self, diag_range: Range, lsp_range: Dict) -> bool:
        """Check if two ranges overlap."""
        diag_start = diag_range.start.line
        diag_end = diag_range.end.line
        lsp_start = lsp_range["start"]["line"]
        lsp_end = lsp_range["end"]["line"]

        return not (diag_end < lsp_start or diag_start > lsp_end)

    def _position_in_range(self, position: Dict, range_obj: Range) -> bool:
        """Check if position is within range."""
        line = position["line"]
        return range_obj.start.line <= line <= range_obj.end.line


def main():
    """Entry point for LSP server."""
    server = QodacodeLSPServer()
    server.run()


if __name__ == "__main__":
    main()
