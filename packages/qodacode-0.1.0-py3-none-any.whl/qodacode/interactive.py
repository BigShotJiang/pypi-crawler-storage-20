"""
Qodacode Interactive CLI.

REPL with slash commands and autocomplete like Claude Code / Gemini CLI.
Type / to see available commands.
"""

import json
import os
import getpass
from pathlib import Path
from typing import Optional, List

from prompt_toolkit import prompt
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from textual.app import App, ComposeResult
from textual.widgets import Input, Static, OptionList
from textual.widgets.option_list import Option
from textual.containers import Vertical, Horizontal
from textual.binding import Binding
from textual import events

from qodacode import __version__
from qodacode.scanner import Scanner
from qodacode.reporter import Reporter
from qodacode.rules.base import Severity

console = Console()
reporter = Reporter()
scanner = Scanner()

# Config paths
CONFIG_DIR = Path.home() / ".qodacode"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Slash commands definition
# Main commands (shown in welcome screen)
COMMANDS = {
    "/check": "Smart Scan (default)",
    "/audit": "Full Compliance Audit",
    "/watch": "Real-time Monitor",
    "/mode": "Toggle Junior/Senior",
    "/api": "Configure API Keys",
    "/status": "System Health",
    "/help": "Show all commands",
    "/exit": "Exit Qodacode",
}

# Advanced commands (hidden from welcome, but functional)
ADVANCED_COMMANDS = {
    "/fast": "Fast scan (Tree-sitter only)",
    "/deep": "Deep SAST scan (Semgrep)",
    "/secrets": "Secret detection (Gitleaks)",
    "/deps": "Dependency vulnerabilities (OSV)",
    "/ready": "Check if production ready",
    "/rules": "List available rules",
    "/language": "Change language (en/es)",
}

# All commands for autocomplete
ALL_COMMANDS = {**COMMANDS, **ADVANCED_COMMANDS}


def load_global_config() -> dict:
    """Load global Qodacode config."""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return {}


def save_global_config(config: dict):
    """Save global Qodacode config."""
    CONFIG_DIR.mkdir(exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)


def is_trusted(path: str) -> bool:
    """Check if path is already trusted."""
    config = load_global_config()
    trusted = config.get("trusted_paths", [])
    return os.path.abspath(path) in trusted


def add_trusted_path(path: str):
    """Add path to trusted list."""
    config = load_global_config()
    trusted = config.get("trusted_paths", [])
    abs_path = os.path.abspath(path)
    if abs_path not in trusted:
        trusted.append(abs_path)
    config["trusted_paths"] = trusted
    save_global_config(config)


def get_project_config(path: str) -> dict:
    """Get project-specific config, create default if not exists."""
    project_config = Path(path) / ".qodacode" / "config.json"
    if project_config.exists():
        with open(project_config) as f:
            return json.load(f)
    # Create default config
    default_config = {
        "language": "en",
        "mode": "senior",
        "ai": {},
        "exclude": [".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"],
    }
    save_project_config(path, default_config)
    return default_config


def save_project_config(path: str, config: dict):
    """Save project-specific config."""
    project_dir = Path(path) / ".qodacode"
    project_dir.mkdir(exist_ok=True)
    with open(project_dir / "config.json", "w") as f:
        json.dump(config, f, indent=2)


def get_username() -> str:
    """Get current username."""
    return getpass.getuser().capitalize()


def show_banner():
    """Display the Qodacode banner - BIG with gradient colors."""
    banner = """
[bold #FF8C42]   ██████╗ [/][bold #F97316] ██████╗ [/][bold #EA580C]██████╗ [/][bold #DC2626] █████╗ [/][bold #B91C1C] ██████╗[/][bold #991B1B]██████╗ [/][bold #7F1D1D]██████╗ [/][bold #7F1D1D]███████╗[/]
[bold #FF8C42]  ██╔═══██╗[/][bold #F97316]██╔═══██╗[/][bold #EA580C]██╔══██╗[/][bold #DC2626]██╔══██╗[/][bold #B91C1C]██╔════╝[/][bold #991B1B]██╔═══██╗[/][bold #7F1D1D]██╔══██╗[/][bold #7F1D1D]██╔════╝[/]
[bold #FF8C42]  ██║   ██║[/][bold #F97316]██║   ██║[/][bold #EA580C]██║  ██║[/][bold #DC2626]███████║[/][bold #B91C1C]██║     [/][bold #991B1B]██║   ██║[/][bold #7F1D1D]██║  ██║[/][bold #7F1D1D]█████╗  [/]
[bold #FF8C42]  ██║▄▄ ██║[/][bold #F97316]██║   ██║[/][bold #EA580C]██║  ██║[/][bold #DC2626]██╔══██║[/][bold #B91C1C]██║     [/][bold #991B1B]██║   ██║[/][bold #7F1D1D]██║  ██║[/][bold #7F1D1D]██╔══╝  [/]
[bold #FF8C42]  ╚██████╔╝[/][bold #F97316]╚██████╔╝[/][bold #EA580C]██████╔╝[/][bold #DC2626]██║  ██║[/][bold #B91C1C]╚██████╗[/][bold #991B1B]╚██████╔╝[/][bold #7F1D1D]██████╔╝[/][bold #7F1D1D]███████╗[/]
[bold #FF8C42]   ╚══▀▀═╝ [/][bold #F97316] ╚═════╝ [/][bold #EA580C]╚═════╝ [/][bold #DC2626]╚═╝  ╚═╝[/][bold #B91C1C] ╚═════╝[/][bold #991B1B] ╚═════╝ [/][bold #7F1D1D]╚═════╝ [/][bold #7F1D1D]╚══════╝[/]

                    [dim]v{version}[/]  [#DA7028]│[/]  [dim]Type[/] [#DA7028]/[/] [dim]for commands[/]
"""
    console.print(banner.format(version=__version__))


def show_welcome(path: str):
    """Display welcome screen with commands."""
    abs_path = os.path.abspath(path)
    project_name = os.path.basename(abs_path)
    username = get_username()

    # Truncar path si es muy largo
    display_path = abs_path
    if len(display_path) > 25:
        display_path = "..." + abs_path[-22:]

    # Build welcome panel content
    table = Table(show_header=False, box=None, padding=(0, 2), expand=True)
    table.add_column("Left", ratio=1)
    table.add_column("Right", ratio=1)

    # Row 1: Welcome + Commands header
    table.add_row(
        f"[bold white]Welcome {username}![/bold white]",
        "[#FF6B35]Commands[/#FF6B35]"
    )
    # Row 2: empty + /check
    table.add_row("", "[#DA7028]/check[/#DA7028]   Scan code")
    # Row 3: Project + /watch
    table.add_row(
        f"[dim]Project:[/dim] [#DA7028]{project_name}[/#DA7028]",
        "[#DA7028]/watch[/#DA7028]   Real-time monitor"
    )
    # Row 4: Path + /status
    table.add_row(
        f"[dim]Path:[/dim] [dim]{display_path}[/dim]",
        "[#DA7028]/status[/#DA7028]  Project health"
    )
    # Row 5: empty + /ready
    table.add_row("", "[#DA7028]/ready[/#DA7028]   Production check")
    # Row 6: empty + /config
    table.add_row("", "[#DA7028]/config[/#DA7028]  Settings")

    console.print(Panel(
        table,
        border_style="orange1",
        box=box.SQUARE,
        padding=(1, 2),
    ))


def prompt_trust(path: str) -> bool:
    """Show trust prompt."""
    abs_path = os.path.abspath(path)

    console.print()
    console.print(Panel(
        f"[bold orange1]Do you trust the files in this folder?[/bold orange1]\n\n"
        f"[white]{abs_path}[/white]\n\n"
        f"[dim]Qodacode will analyze files in this directory.[/dim]",
        border_style="orange1",
        box=box.ROUNDED,
    ))

    response = prompt("Trust this folder? (y/n): ").strip().lower()

    if response in ["y", "yes"]:
        add_trusted_path(path)
        return True
    return False


# Command handlers

def cmd_init(path: str, config: dict):
    """Initialize project."""
    qodacode_dir = Path(path) / ".qodacode"

    if qodacode_dir.exists():
        console.print("[yellow]Project already initialized.[/yellow]")
        return

    console.print("[#DA7028]Initializing...[/#DA7028]")
    qodacode_dir.mkdir(exist_ok=True)
    (qodacode_dir / "cache").mkdir(exist_ok=True)

    # Run initial scan
    result = scanner.scan(path)

    # Save index
    index_data = {
        "version": __version__,
        "files_scanned": result.files_scanned,
        "issues_found": len(result.issues),
    }
    with open(qodacode_dir / "index.json", "w") as f:
        json.dump(index_data, f, indent=2)

    console.print(f"[green]✓ Initialized[/green] - {result.files_scanned} files, {len(result.issues)} issues\n")


def cmd_check(path: str, config: dict, scan_mode: str = "default"):
    """Scan code for issues.

    Args:
        path: Project path to scan
        config: Project config
        scan_mode: One of 'default', 'fast', 'deep', 'secrets', 'deps', 'audit'
    """
    mode = config.get("mode", "senior")

    # Display scan mode
    mode_labels = {
        "default": "[#DA7028]Smart Scan[/]",
        "fast": "[blue]Fast (Tree-sitter)[/]",
        "deep": "[magenta]Deep SAST (Semgrep)[/]",
        "secrets": "[red]Secret Detection (Gitleaks)[/]",
        "deps": "[yellow]Dependencies (OSV)[/]",
        "audit": "[green]Full Compliance Audit[/]",
    }

    console.print(f"\n[#DA7028]Scanning...[/] {mode_labels.get(scan_mode, '')}\n")

    # Run the appropriate scan
    if scan_mode == "fast":
        # Tree-sitter only
        result = scanner.scan(path)
    elif scan_mode == "deep":
        # Semgrep (import here to avoid circular imports)
        from qodacode.engines.semgrep_runner import SemgrepRunner
        semgrep = SemgrepRunner()
        if semgrep.is_available():
            issues = semgrep.run(path)
            # Create minimal result for reporting
            from qodacode.scanner import ScanResult
            result = ScanResult(
                issues=issues,
                files_scanned=0,
                scan_time=0.0,
            )
        else:
            console.print("[yellow]Semgrep not installed.[/]")
            console.print(f"[dim]{semgrep.get_install_instructions()}[/]")
            return
    elif scan_mode == "secrets":
        # Gitleaks
        from qodacode.engines.gitleaks_runner import GitleaksRunner
        gitleaks = GitleaksRunner()
        if gitleaks.is_available():
            issues = gitleaks.run(path)
            from qodacode.scanner import ScanResult
            result = ScanResult(
                issues=issues,
                files_scanned=0,
                scan_time=0.0,
            )
        else:
            console.print("[yellow]Gitleaks not available.[/]")
            console.print("[dim]Will auto-download on next run.[/]")
            return
    elif scan_mode == "deps":
        # OSV Scanner
        from qodacode.osv import check_requirements
        vulnerabilities = check_requirements(path)
        if vulnerabilities:
            console.print(f"[red]Found {len(vulnerabilities)} vulnerable dependencies[/]\n")
            for vuln in vulnerabilities[:5]:  # Show top 5
                console.print(f"  [red]●[/] {vuln.get('package', 'unknown')} - {vuln.get('id', 'CVE')}")
            if len(vulnerabilities) > 5:
                console.print(f"  [dim]...and {len(vulnerabilities) - 5} more[/]")
        else:
            console.print("[green]✓ No vulnerable dependencies found![/]")
        return
    elif scan_mode == "audit":
        # Full Compliance Audit - run all engines
        all_issues = []

        console.print("[bold]🔍 FULL COMPLIANCE AUDIT[/bold]\n")

        # 1. Tree-sitter (fast)
        console.print("  [dim]● Running Tree-sitter...[/]")
        ts_result = scanner.scan(path)
        all_issues.extend(ts_result.issues)
        console.print(f"    [green]✓[/] {len(ts_result.issues)} issues")

        # 2. Gitleaks (secrets)
        try:
            from qodacode.engines.gitleaks_runner import GitleaksRunner
            console.print("  [dim]● Running Gitleaks...[/]")
            gitleaks = GitleaksRunner()
            if gitleaks.is_available():
                gl_issues = gitleaks.run(path)
                all_issues.extend(gl_issues)
                console.print(f"    [green]✓[/] {len(gl_issues)} secrets")
        except Exception:
            console.print("    [yellow]○[/] skipped")

        # 3. Semgrep (deep)
        try:
            from qodacode.engines.semgrep_runner import SemgrepRunner
            console.print("  [dim]● Running Semgrep...[/]")
            semgrep = SemgrepRunner()
            if semgrep.is_available():
                sg_issues = semgrep.run(path)
                all_issues.extend(sg_issues)
                console.print(f"    [green]✓[/] {len(sg_issues)} vulnerabilities")
            else:
                console.print("    [yellow]○[/] not installed")
        except Exception:
            console.print("    [yellow]○[/] skipped")

        console.print()
        from qodacode.scanner import ScanResult
        result = ScanResult(
            issues=all_issues,
            files_scanned=ts_result.files_scanned,
            scan_time=0.0,
        )
    else:
        # Default: fast + secrets
        all_issues = []

        # Tree-sitter
        ts_result = scanner.scan(path)
        all_issues.extend(ts_result.issues)

        # Gitleaks
        try:
            from qodacode.engines.gitleaks_runner import GitleaksRunner
            gitleaks = GitleaksRunner()
            if gitleaks.is_available():
                gl_issues = gitleaks.run(path)
                all_issues.extend(gl_issues)
        except Exception:
            pass

        from qodacode.scanner import ScanResult
        result = ScanResult(
            issues=all_issues,
            files_scanned=ts_result.files_scanned,
            scan_time=0.0,
        )

    if not result.issues:
        console.print(Panel(
            "[bold green]✓ No issues found![/bold green]",
            border_style="green",
        ))
    else:
        # Summary
        console.print(f"[bold]Found {len(result.issues)} issue(s)[/bold]\n")

        if result.critical_count:
            console.print(f"  [red]● {result.critical_count} critical[/red]")
        if result.high_count:
            console.print(f"  [yellow]● {result.high_count} high[/yellow]")
        if result.medium_count:
            console.print(f"  [blue]● {result.medium_count} medium[/blue]")
        if result.low_count:
            console.print(f"  [dim]● {result.low_count} low[/dim]")

        console.print()
        reporter.report_scan_result(result, show_fixes=True, mode=mode)

    console.print()


def cmd_rules(path: str, config: dict):
    """List available detection rules."""
    from qodacode.rules.security import SECURITY_RULES
    from qodacode.rules.robustness import ROBUSTNESS_RULES
    from qodacode.rules.maintainability import MAINTAINABILITY_RULES
    from qodacode.rules.operability import OPERABILITY_RULES
    from qodacode.rules.dependencies import DEPENDENCY_RULES

    console.print("\n[bold]Available Detection Rules[/bold]\n")

    # Security rules
    console.print("[red]Security[/]")
    for rule in SECURITY_RULES:
        console.print(f"  [dim]●[/] {rule.id}: {rule.name}")

    # Robustness rules
    console.print("\n[yellow]Robustness[/]")
    for rule in ROBUSTNESS_RULES:
        console.print(f"  [dim]●[/] {rule.id}: {rule.name}")

    # Maintainability rules
    console.print("\n[blue]Maintainability[/]")
    for rule in MAINTAINABILITY_RULES:
        console.print(f"  [dim]●[/] {rule.id}: {rule.name}")

    # Operability rules
    console.print("\n[cyan]Operability[/]")
    for rule in OPERABILITY_RULES:
        console.print(f"  [dim]●[/] {rule.id}: {rule.name}")

    # Dependency rules
    console.print("\n[magenta]Dependencies[/]")
    for rule in DEPENDENCY_RULES:
        console.print(f"  [dim]●[/] {rule.id}: {rule.name}")

    total = (len(SECURITY_RULES) + len(ROBUSTNESS_RULES) +
             len(MAINTAINABILITY_RULES) + len(OPERABILITY_RULES) +
             len(DEPENDENCY_RULES))
    console.print(f"\n[dim]Total: {total} rules[/]\n")


def cmd_watch(path: str, config: dict):
    """Start file watching."""
    console.print("\n[#DA7028]Starting watch mode...[/#DA7028]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")

    from qodacode.cli import watch
    import click

    try:
        ctx = click.Context(watch)
        ctx.invoke(watch, path=path, severity="high", mode=config.get("mode", "senior"))
    except KeyboardInterrupt:
        console.print("\n[dim]Watch stopped.[/dim]\n")


def cmd_status(path: str, config: dict):
    """Show project status."""
    qodacode_dir = Path(path) / ".qodacode"

    if not qodacode_dir.exists():
        console.print("[yellow]Not initialized. Run /init first.[/yellow]\n")
        return

    result = scanner.scan(path)

    # Calculate grade
    if result.critical_count > 0:
        grade, color = "F", "red"
    elif result.high_count > 0:
        grade, color = "C", "yellow"
    elif len(result.issues) > 10:
        grade, color = "B", "blue"
    elif len(result.issues) > 0:
        grade, color = "A", "green"
    else:
        grade, color = "A+", "green"

    console.print(Panel(
        f"[bold {color}]Grade: {grade}[/bold {color}]\n\n"
        f"Files: {result.files_scanned}\n"
        f"Issues: {len(result.issues)}\n"
        f"[red]Critical: {result.critical_count}[/red]\n"
        f"[yellow]High: {result.high_count}[/yellow]",
        title="[bold]Project Status[/bold]",
        border_style=color,
    ))
    console.print()


def cmd_ready(path: str, config: dict):
    """Check if production ready."""
    console.print("\n[#DA7028]Checking production readiness...[/#DA7028]\n")

    result = scanner.scan(path)

    blockers = result.critical_count + result.high_count

    if blockers == 0:
        console.print(Panel(
            "[bold green]✓ READY FOR PRODUCTION[/bold green]\n\n"
            "[dim]No critical or high severity issues found.[/dim]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[bold red]✗ NOT READY[/bold red]\n\n"
            f"[red]{result.critical_count} critical[/red] + "
            f"[yellow]{result.high_count} high[/yellow] = "
            f"[bold]{blockers} blockers[/bold]\n\n"
            "[dim]Fix these issues before deploying.[/dim]",
            border_style="red",
        ))
    console.print()


def cmd_help():
    """Show all commands."""
    console.print("\n[bold]Available Commands[/bold]\n")
    for cmd, desc in COMMANDS.items():
        console.print(f"  [#DA7028]{cmd:12}[/#DA7028] {desc}")
    console.print()


def detect_api_provider(api_key: str) -> str:
    """Auto-detect API provider from key prefix."""
    if api_key.startswith("sk-ant-"):
        return "anthropic"
    elif api_key.startswith("xai-"):
        return "grok"
    elif api_key.startswith("AIza"):
        return "gemini"
    elif api_key.startswith("sk-"):
        return "openai"
    elif api_key.startswith("ollama") or api_key.startswith("http://localhost"):
        return "ollama"
    return "unknown"


def cmd_api(path: str, config: dict, api_key: str = None) -> str:
    """Set API key with auto-detection."""
    if not api_key:
        # Show current status
        current = config.get("ai", {})
        if current.get("api_key"):
            provider = current.get("provider", "unknown")
            masked = current["api_key"][:8] + "..." + current["api_key"][-4:]
            return f"[#DA7028]API:[/] {provider} ({masked})\n[dim]Use /api <key> to change[/]"
        else:
            return "[dim]No API key configured[/]\n[#DA7028]Usage:[/] /api <key>\n[dim]sk-ant-* → Anthropic | sk-* → OpenAI | xai-* → Grok | AIza* → Gemini | ollama → Ollama[/]"

    # Detect provider
    provider = detect_api_provider(api_key)
    if provider == "unknown":
        return "[yellow]Warning: Unknown API key format[/]\n[dim]Expected: sk-ant-* (Anthropic), sk-* (OpenAI), xai-* (Grok), AIza* (Gemini), ollama (Ollama)[/]"

    # Save
    config["ai"] = {"provider": provider, "api_key": api_key}
    save_project_config(path, config)

    return f"[green]✓ API configured:[/] {provider}"


def cmd_language(path: str, config: dict, lang: str = None) -> str:
    """Change language."""
    if not lang:
        current = config.get("language", "en")
        return f"[#DA7028]Language:[/] {current}\n[dim]Use /language en or /language es[/]"

    lang = lang.lower()
    if lang not in ["en", "es"]:
        return "[red]Invalid language.[/] Use: en, es"

    config["language"] = lang
    save_project_config(path, config)
    return f"[green]✓ Language:[/] {lang}"


class CommandInput(Input):
    """Custom input with slash command suggestions."""

    BINDINGS = [
        Binding("escape", "clear_input", "Clear"),
    ]

    def __init__(self, commands: dict, **kwargs):
        super().__init__(**kwargs)
        self.commands = commands
        self.suggestions_visible = False

    def action_clear_input(self):
        self.value = ""

    def on_input_changed(self, event: Input.Changed) -> None:
        """Show suggestions when typing /"""
        app = self.app
        if hasattr(app, 'suggestions'):
            if event.value.startswith("/"):
                # Filter commands
                filtered = [
                    (cmd, desc) for cmd, desc in self.commands.items()
                    if cmd.startswith(event.value.lower())
                ]
                app.update_suggestions(filtered)
                app.suggestions.display = True
            else:
                app.suggestions.display = False


class QodacodeApp(App):
    """Qodacode Interactive TUI."""

    CSS = """
    Screen {
        background: #1a1a1a;
    }

    #banner {
        text-align: center;
        padding: 1 0 0 0;
    }

    #welcome-box {
        border: solid #DA7028;
        padding: 1 2;
        margin: 0 2;
        background: #2d2d2d;
    }

    #input-container {
        height: auto;
        margin: 0 2;
        padding: 0;
    }

    #top-line, #bottom-line {
        color: #DA7028;
        height: 1;
        margin: 0;
        padding: 0;
    }

    #command-input {
        border: none;
        background: #1a1a1a;
        padding: 0;
        margin: 0;
        height: 1;
        color: #e0e0e0;
    }

    #command-input:focus {
        border: none;
    }

    #command-input > .input--placeholder {
        color: #707070;
    }

    #hint {
        color: #707070;
        padding: 0 2;
        height: 1;
        margin: 0;
    }

    #suggestions {
        background: #2d2d2d;
        border: solid #DA7028;
        margin: 0 2;
        max-height: 12;
        padding: 0;
    }

    OptionList > .option-list--option {
        padding: 0 2;
        color: #e0e0e0;
    }

    OptionList > .option-list--option-highlighted {
        background: #DA7028;
        color: #ffffff;
    }

    #output {
        margin: 1 2;
        height: auto;
        color: #e0e0e0;
    }
    """

    BINDINGS = [
        Binding("ctrl+c", "quit", "Exit"),
    ]

    def __init__(self, path: str, config: dict):
        super().__init__()
        self.path = path
        self.config = config
        self.command_result = None

    def compose(self) -> ComposeResult:
        """Create the UI layout."""
        # Banner - QODACODE with gradient colors
        banner = """
[bold #FF8C42]   ██████╗ [/][bold #F97316] ██████╗ [/][bold #EA580C]██████╗ [/][bold #DC2626] █████╗ [/][bold #B91C1C] ██████╗[/][bold #991B1B]██████╗ [/][bold #7F1D1D]██████╗ [/][bold #7F1D1D]███████╗[/]
[bold #FF8C42]  ██╔═══██╗[/][bold #F97316]██╔═══██╗[/][bold #EA580C]██╔══██╗[/][bold #DC2626]██╔══██╗[/][bold #B91C1C]██╔════╝[/][bold #991B1B]██╔═══██╗[/][bold #7F1D1D]██╔══██╗[/][bold #7F1D1D]██╔════╝[/]
[bold #FF8C42]  ██║   ██║[/][bold #F97316]██║   ██║[/][bold #EA580C]██║  ██║[/][bold #DC2626]███████║[/][bold #B91C1C]██║     [/][bold #991B1B]██║   ██║[/][bold #7F1D1D]██║  ██║[/][bold #7F1D1D]█████╗  [/]
[bold #FF8C42]  ██║▄▄ ██║[/][bold #F97316]██║   ██║[/][bold #EA580C]██║  ██║[/][bold #DC2626]██╔══██║[/][bold #B91C1C]██║     [/][bold #991B1B]██║   ██║[/][bold #7F1D1D]██║  ██║[/][bold #7F1D1D]██╔══╝  [/]
[bold #FF8C42]  ╚██████╔╝[/][bold #F97316]╚██████╔╝[/][bold #EA580C]██████╔╝[/][bold #DC2626]██║  ██║[/][bold #B91C1C]╚██████╗[/][bold #991B1B]╚██████╔╝[/][bold #7F1D1D]██████╔╝[/][bold #7F1D1D]███████╗[/]
[bold #FF8C42]   ╚══▀▀═╝ [/][bold #F97316] ╚═════╝ [/][bold #EA580C]╚═════╝ [/][bold #DC2626]╚═╝  ╚═╝[/][bold #B91C1C] ╚═════╝[/][bold #991B1B] ╚═════╝ [/][bold #7F1D1D]╚═════╝ [/][bold #7F1D1D]╚══════╝[/]

                    [dim]v{version}[/]  [#DA7028]│[/]  [dim]Type[/] [#DA7028]/[/] [dim]for commands[/]
"""
        yield Static(banner.format(version=__version__), id="banner")

        username = get_username()
        project_name = os.path.basename(os.path.abspath(self.path))
        mode = self.config.get("mode", "senior")
        ai_config = self.config.get("ai", {})
        has_api = bool(ai_config.get("api_key"))

        if has_api:
            provider = ai_config.get("provider", "unknown")
            # Capitalize provider names for display
            provider_display = {
                "anthropic": "Anthropic",
                "openai": "OpenAI",
                "grok": "Grok",
                "gemini": "Gemini",
                "ollama": "Ollama",
            }.get(provider, provider.capitalize())
            api_line = f"[dim]AI:[/] [green]●[/] [#DA7028]{provider_display}[/]"
        else:
            api_line = "[dim]AI:[/] None"

        # Welcome content with current status
        welcome_content = f"""[bold white]Welcome {username}![/]

[dim]Project:[/] [#DA7028]{project_name}[/]
[dim]Mode:[/] [#DA7028]{mode}[/]
{api_line}"""

        # Commands - clean and minimal
        commands_content = """[#FF6B35]Scan[/]                    [#FF6B35]Config[/]
[#DA7028]/check[/]  Smart Scan        [#DA7028]/mode[/]   Junior/Senior
[#DA7028]/audit[/]  Full Audit        [#DA7028]/api[/]    API Keys
[#DA7028]/watch[/]  Real-time         [#DA7028]/status[/] Health"""

        yield Static(f"{welcome_content}\n\n{commands_content}", id="welcome-box")

        # Input area with lines
        with Vertical(id="input-container"):
            yield Static("─" * 70, id="top-line")
            yield CommandInput(ALL_COMMANDS, placeholder="Type / for commands", id="command-input")
            yield Static("─" * 70, id="bottom-line")
            yield Static("  /api <key> to start  │  / for commands", id="hint")

        # Suggestions list (hidden by default)
        self.suggestions = OptionList(id="suggestions")
        self.suggestions.display = False
        yield self.suggestions

        # Output area
        yield Static("", id="output")

    def update_suggestions(self, items: list):
        """Update the suggestions list."""
        self.suggestions.clear_options()
        for cmd, desc in items:
            self.suggestions.add_option(Option(f"[#DA7028]{cmd:12}[/] [dim]{desc}[/]", id=cmd))

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle command submission."""
        value = event.value.strip()

        if not value:
            return

        # Hide suggestions
        self.suggestions.display = False

        # Clear input
        event.input.value = ""

        # Parse command and args
        parts = value.split(maxsplit=1)
        cmd = parts[0].lower()
        args = parts[1] if len(parts) > 1 else None

        # Process command
        if cmd == "/exit":
            self.exit()
        elif cmd == "/help":
            self.show_output(self.get_help_text())
        elif cmd == "/mode":
            # Toggle between junior and senior
            current = self.config.get("mode", "senior")
            new_mode = "junior" if current == "senior" else "senior"
            self.config["mode"] = new_mode
            save_project_config(self.path, self.config)
            if new_mode == "junior":
                self.show_output("[#DA7028]Mode: junior[/] [dim]- Detailed explanations for learning[/]")
            else:
                self.show_output("[#DA7028]Mode: senior[/] [dim]- Concise enterprise comments[/]")
            self.refresh_welcome_box()
        elif cmd == "/junior":
            self.config["mode"] = "junior"
            save_project_config(self.path, self.config)
            self.show_output("[#DA7028]Mode: junior[/] [dim]- Detailed AI explanations for learning[/]")
            self.refresh_welcome_box()
        elif cmd == "/senior":
            self.config["mode"] = "senior"
            save_project_config(self.path, self.config)
            self.show_output("[#DA7028]Mode: senior[/] [dim]- Concise enterprise comments[/]")
            self.refresh_welcome_box()
        elif cmd == "/api":
            result = cmd_api(self.path, self.config, args)
            self.show_output(result)
            self.refresh_welcome_box()
        elif cmd == "/language":
            result = cmd_language(self.path, self.config, args)
            self.show_output(result)
        elif cmd in ["/check", "/audit", "/fast", "/deep", "/secrets", "/deps",
                     "/init", "/status", "/ready", "/watch", "/rules"]:
            # Exit app to run command in console mode
            self.command_result = cmd
            self.exit()
        elif cmd.startswith("/"):
            self.show_output(f"[red]Unknown command: {cmd}[/]\n[dim]Type /help for available commands[/]")
        else:
            self.show_output("[dim]Type / to see commands[/]")

    def refresh_welcome_box(self):
        """Refresh the welcome box to show updated status."""
        welcome_box = self.query_one("#welcome-box", Static)
        username = get_username()
        project_name = os.path.basename(os.path.abspath(self.path))
        mode = self.config.get("mode", "senior")
        ai_config = self.config.get("ai", {})
        has_api = bool(ai_config.get("api_key"))

        if has_api:
            provider = ai_config.get("provider", "unknown")
            # Capitalize provider names for display
            provider_display = {
                "anthropic": "Anthropic",
                "openai": "OpenAI",
                "grok": "Grok",
                "gemini": "Gemini",
                "ollama": "Ollama",
            }.get(provider, provider.capitalize())
            api_line = f"[dim]AI:[/] [green]●[/] [#DA7028]{provider_display}[/]"
        else:
            api_line = "[dim]AI:[/] None"

        welcome_content = f"""[bold white]Welcome {username}![/]

[dim]Project:[/] [#DA7028]{project_name}[/]
[dim]Mode:[/] [#DA7028]{mode}[/]
{api_line}"""

        commands_content = """[#FF6B35]Scan[/]                    [#FF6B35]Config[/]
[#DA7028]/check[/]  Smart Scan        [#DA7028]/mode[/]   Junior/Senior
[#DA7028]/audit[/]  Full Audit        [#DA7028]/api[/]    API Keys
[#DA7028]/watch[/]  Real-time         [#DA7028]/status[/] Health"""

        welcome_box.update(f"{welcome_content}\n\n{commands_content}")

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        """Handle suggestion selection."""
        cmd_input = self.query_one("#command-input", Input)
        cmd_input.value = event.option.id
        cmd_input.focus()
        self.suggestions.display = False

    def get_help_text(self) -> str:
        """Generate help text."""
        lines = ["[bold]Available Commands[/]\n"]
        for cmd, desc in COMMANDS.items():
            lines.append(f"  [#DA7028]{cmd:12}[/] {desc}")
        return "\n".join(lines)

    def show_output(self, text: str):
        """Show output in the output area."""
        output = self.query_one("#output", Static)
        output.update(text)


def run_interactive(path: str = "."):
    """Main REPL entry point.

    Flow:
    1. $ qodacode
    2. Trust this folder? [Yes/No]
    3. UI with banner and /commands (defaults: en, senior, no AI)
    4. User configures via /api, /language, /junior, /senior
    """

    # 1. Trust prompt (first time in this folder)
    if not is_trusted(path):
        if not prompt_trust(path):
            console.print("\n[dim]Cancelled.[/dim]\n")
            return

    # 2. Get config (creates default if not exists)
    config = get_project_config(path)

    # 3. Run Textual app loop
    while True:
        app = QodacodeApp(path, config)
        app.run()

        # Check if there's a command to execute outside Textual
        if app.command_result:
            cmd = app.command_result

            if cmd == "/init":
                cmd_init(path, config)
            elif cmd == "/check":
                cmd_check(path, config, scan_mode="default")
            elif cmd == "/fast":
                cmd_check(path, config, scan_mode="fast")
            elif cmd == "/deep":
                cmd_check(path, config, scan_mode="deep")
            elif cmd == "/secrets":
                cmd_check(path, config, scan_mode="secrets")
            elif cmd == "/deps":
                cmd_check(path, config, scan_mode="deps")
            elif cmd == "/audit":
                cmd_check(path, config, scan_mode="audit")
            elif cmd == "/rules":
                cmd_rules(path, config)
            elif cmd == "/watch":
                cmd_watch(path, config)
            elif cmd == "/status":
                cmd_status(path, config)
            elif cmd == "/ready":
                cmd_ready(path, config)

            # Wait for user to press Enter before returning to app
            input("\nPress Enter to continue...")

            # Reload config in case it changed
            config = get_project_config(path)
        else:
            # User exited
            console.print("\n[dim]Goodbye![/dim]\n")
            break
