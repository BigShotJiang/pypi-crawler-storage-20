"""
Qodacode CLI - Command line interface.

Commands:
- init: Index repository and create .qodacode/
- check: Scan code for issues
- status: Show project status
- git-history: Scan git history for secrets
- watch: Real-time file monitoring
"""

import json
import os
import signal
import sys
import time
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from qodacode import __version__
from qodacode.scanner import Scanner, ScanResult
from qodacode.rules.base import Severity, Category, RuleRegistry
from qodacode.reporter import Reporter


# ─────────────────────────────────────────────────────────────────────────────
# GRACEFUL SHUTDOWN HANDLER (Phase 5.2)
# ─────────────────────────────────────────────────────────────────────────────
_shutdown_requested = False


def _signal_handler(signum: int, frame) -> None:
    """
    Handle Ctrl+C (SIGINT) gracefully.

    First press: Request graceful shutdown, show message
    Second press: Force exit immediately
    """
    global _shutdown_requested

    if _shutdown_requested:
        # Second Ctrl+C - force exit
        console.print("\n[bold red]Force quit.[/bold red]")
        sys.exit(130)  # Standard exit code for SIGINT

    _shutdown_requested = True
    console.print("\n[yellow]⚠ Interrupt received. Finishing current task...[/yellow]")
    console.print("[dim]Press Ctrl+C again to force quit.[/dim]")


def is_shutdown_requested() -> bool:
    """Check if graceful shutdown was requested."""
    return _shutdown_requested


# Register signal handler
signal.signal(signal.SIGINT, _signal_handler)


# ─────────────────────────────────────────────────────────────────────────────
# GLOBAL EXCEPTION HANDLER (Phase 5.3)
# ─────────────────────────────────────────────────────────────────────────────
def _write_crash_log(exc_type, exc_value, exc_tb) -> Optional[str]:
    """
    Write crash details to .qodacode/crash.log

    Returns the path to the crash log if written, None otherwise.
    """
    import traceback
    from datetime import datetime

    try:
        crash_dir = Path(".qodacode")
        crash_dir.mkdir(exist_ok=True)
        crash_file = crash_dir / "crash.log"

        crash_info = [
            f"═══ QODACODE CRASH REPORT ═══",
            f"Timestamp: {datetime.now().isoformat()}",
            f"Version: {__version__}",
            f"Python: {sys.version}",
            f"Platform: {sys.platform}",
            f"",
            f"Exception: {exc_type.__name__}: {exc_value}",
            f"",
            f"Traceback:",
            "".join(traceback.format_exception(exc_type, exc_value, exc_tb)),
        ]

        with open(crash_file, "a") as f:
            f.write("\n".join(crash_info))
            f.write("\n\n")

        return str(crash_file)
    except Exception:
        return None


def _global_exception_handler(exc_type, exc_value, exc_tb):
    """
    Global exception handler for unhandled exceptions.

    - Writes crash log
    - Shows user-friendly error message
    - Exits with error code
    """
    # Don't handle KeyboardInterrupt here (signal handler does that)
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        return

    # Write crash log
    crash_path = _write_crash_log(exc_type, exc_value, exc_tb)

    # Show user-friendly message
    console.print("\n[bold red]╔═══════════════════════════════════════╗[/bold red]")
    console.print("[bold red]║        UNEXPECTED ERROR               ║[/bold red]")
    console.print("[bold red]╚═══════════════════════════════════════╝[/bold red]")
    console.print(f"\n[red]{exc_type.__name__}:[/red] {exc_value}")

    if crash_path:
        console.print(f"\n[dim]Crash details saved to: {crash_path}[/dim]")
        console.print("[dim]Please include this file when reporting bugs.[/dim]")

    console.print("\n[yellow]Report issues at:[/yellow] https://github.com/qodacode/qodacode/issues")

    sys.exit(1)


# Register global exception handler
sys.excepthook = _global_exception_handler


# ─────────────────────────────────────────────────────────────────────────────


# Initialize scanner globally for reuse
scanner = Scanner()
reporter = Reporter()
console = Console()


# ASCII Banner - static, compatible with all terminals
BANNER = r"""
   ___   ___  ____    _    ____ ___  ____  _____
  / _ \ / _ \|  _ \  / \  / ___/ _ \|  _ \| ____|
 | | | | | | | | | |/ _ \| |  | | | | | | |  _|
 | |_| | |_| | |_| / ___ \ |__| |_| | |_| | |___
  \__\_\\___/|____/_/   \_\____\___/|____/|_____|
"""


def show_banner():
    """Display the Qodacode banner - static, compatible with all terminals."""
    console.print(f"[bold cyan]{BANNER}[/bold cyan]")
    console.print(
        f"  [bold green]v{__version__}[/bold green]  "
        "[yellow]|[/yellow]  "
        "[bold white]Functional code[/bold white] [dim]to[/dim] "
        "[bold green]enterprise production[/bold green]\n"
    )


def show_welcome():
    """Display welcome message with quick start guide."""
    console.print("[bold white]Quick Start:[/bold white]\n")

    console.print("  [cyan]1.[/cyan] Initialize your project:")
    console.print("     [dim]$[/dim] [green]qodacode init[/green]\n")

    console.print("  [cyan]2.[/cyan] Scan for issues:")
    console.print("     [dim]$[/dim] [green]qodacode check[/green]\n")

    console.print("  [cyan]3.[/cyan] View available rules:")
    console.print("     [dim]$[/dim] [green]qodacode rules[/green]\n")

    console.print("[bold white]Scan Modes:[/bold white]\n")
    console.print("  [yellow]--mode senior[/yellow]  [dim](default)[/dim]  Quick, concise output")
    console.print("  [yellow]--mode junior[/yellow]            Learn why issues matter + how to fix\n")

    console.print("[bold white]Other Commands:[/bold white]\n")
    console.print("  [green]qodacode status[/green]       [dim]Show project health[/dim]")
    console.print("  [green]qodacode git-history[/green]  [dim]Scan git history for secrets[/dim]")
    console.print("  [green]qodacode watch[/green]        [dim]Real-time file monitoring[/dim]")
    console.print("  [green]qodacode config[/green]       [dim]Configure AI explanations[/dim]")
    console.print("  [green]qodacode serve[/green]        [dim]Start MCP server for AI tools[/dim]")
    console.print()
    console.print("[dim]Run 'qodacode --help' for all options.[/dim]\n")


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="qodacode")
@click.option("--no-banner", is_flag=True, hidden=True, help="Hide banner")
@click.option("--classic", is_flag=True, help="Use classic CLI mode instead of interactive")
@click.pass_context
def main(ctx, no_banner, classic):
    """Qodacode - Take your code from functional to enterprise production.

    Detects exactly what line, variable, or configuration will break your deploy.
    """
    ctx.ensure_object(dict)

    # If no subcommand provided, launch interactive mode
    if ctx.invoked_subcommand is None:
        if classic:
            # Classic mode: show banner and help
            if not no_banner:
                show_banner()
            show_welcome()
        else:
            # Interactive mode
            from qodacode.interactive import run_interactive
            run_interactive(".")


@main.command()
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Path to repository (default: current directory)"
)
@click.option(
    "--force", "-f",
    is_flag=True,
    help="Force re-indexing even if .qodacode exists"
)
def init(path: str, force: bool):
    """Initialize Qodacode for a repository.

    Creates .qodacode/ directory with indexes and configuration.
    """
    qodacode_dir = Path(path) / ".qodacode"

    if qodacode_dir.exists() and not force:
        reporter.warning(f".qodacode/ already exists. Use --force to re-index.")
        return

    reporter.info("Initializing Qodacode...")

    # Create directory structure
    qodacode_dir.mkdir(exist_ok=True)
    (qodacode_dir / "cache").mkdir(exist_ok=True)

    # Run initial scan to warm up cache
    reporter.info("Scanning repository...")
    result = scanner.scan(path)

    # Save index metadata
    index_data = {
        "version": __version__,
        "files_scanned": result.files_scanned,
        "issues_found": len(result.issues),
        "path": os.path.abspath(path),
    }

    with open(qodacode_dir / "index.json", "w") as f:
        json.dump(index_data, f, indent=2)

    # Create default config
    config_data = {
        "exclude": [
            ".git",
            "node_modules",
            "__pycache__",
            ".venv",
            "venv",
            "dist",
            "build",
        ],
        "severity_threshold": "medium",
        "categories": ["security", "robustness", "maintainability", "operability", "dependencies"],
    }

    with open(qodacode_dir / "config.json", "w") as f:
        json.dump(config_data, f, indent=2)

    reporter.success(f"Initialized Qodacode")
    reporter.info(f"  Files scanned: {result.files_scanned}")
    reporter.info(f"  Issues found: {len(result.issues)}")
    reporter.info(f"  Config: .qodacode/config.json")


@main.command()
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Path to scan (default: current directory)"
)
@click.option(
    "--severity", "-s",
    type=click.Choice(["critical", "high", "medium", "low", "all"]),
    default="all",
    help="Minimum severity to report"
)
@click.option(
    "--category", "-c",
    type=click.Choice(["security", "robustness", "maintainability", "operability", "dependencies", "all"]),
    default="all",
    help="Category to check"
)
@click.option(
    "--format", "-f",
    "output_format",
    type=click.Choice(["terminal", "json", "sarif", "markdown"]),
    default="terminal",
    help="Output format: terminal (rich), json (machine-readable), sarif (GitHub Security), markdown (PR comments)"
)
@click.option(
    "--fix",
    is_flag=True,
    help="Show fix suggestions"
)
@click.option(
    "--mode", "-m",
    type=click.Choice(["junior", "senior"]),
    default="senior",
    help="Output mode: junior (learn while fixing) or senior (just facts)"
)
@click.option(
    "--deep",
    is_flag=True,
    help="Run deep SAST analysis with Semgrep (requires semgrep installed)"
)
@click.option(
    "--secrets",
    is_flag=True,
    help="Scan for hardcoded secrets with Gitleaks (requires gitleaks installed)"
)
@click.option(
    "--deps",
    is_flag=True,
    help="Scan dependencies for vulnerabilities with OSV (requires internet)"
)
@click.option(
    "--all", "scan_all",
    is_flag=True,
    help="Run ALL engines: Tree-sitter + Semgrep + Gitleaks + OSV (the nuclear option)"
)
@click.option(
    "--skip-missing",
    is_flag=True,
    help="Skip missing engines silently (for CI/CD, no interactive prompts)"
)
def check(path: str, severity: str, category: str, output_format: str, fix: bool, mode: str, deep: bool, secrets: bool, deps: bool, scan_all: bool, skip_missing: bool):
    """Enterprise Code Intelligence Scanner.

    Multi-engine security orchestration: SAST, Secrets, and Supply Chain
    analysis in a single command. OWASP Top 10 and ISO 27001 compliant.

    Engines:
      Native (always):  Instant structural analysis (<50ms, real-time capable)
      --deep:           Industry-standard SAST (Semgrep integration)
      --secrets:        Credential scanning (Gitleaks integration)
      --deps:           Supply Chain Security / SCA (OSV database)
      --all:            Full security suite (all engines)

    Output modes:
      --mode junior:    Full explanations with enterprise examples
      --mode senior:    Terse output, facts only

    CI/CD:
      --skip-missing:   Silent skip for missing engines (no prompts)
      --json:           Machine-readable output
      --sarif:          GitHub Security Tab compatible

    Examples:
      qodacode check                    # Instant scan
      qodacode check --all              # Full security suite
      qodacode check --all --skip-missing  # CI/CD mode
    """
    # --all activates everything
    if scan_all:
        deep = True
        secrets = True
        deps = True
    # Map severity filter
    severity_filter = None
    if severity != "all":
        severity_map = {
            "critical": [Severity.CRITICAL],
            "high": [Severity.CRITICAL, Severity.HIGH],
            "medium": [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM],
            "low": [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW],
        }
        severity_filter = severity_map.get(severity)

    # Map category filter
    category_filter = None
    if category != "all":
        category_map = {
            "security": [Category.SECURITY],
            "robustness": [Category.ROBUSTNESS],
            "maintainability": [Category.MAINTAINABILITY],
            "operability": [Category.OPERABILITY],
            "dependencies": [Category.DEPENDENCIES],
        }
        category_filter = category_map.get(category)

    # Run Tree-sitter scan (always runs - fast, local)
    result = scanner.scan(
        path=path,
        categories=category_filter,
        severities=severity_filter,
    )

    # Deep mode: Run Semgrep for additional SAST analysis
    if deep:
        from qodacode.engines import SemgrepRunner

        semgrep = SemgrepRunner()

        if not semgrep.is_available():
            if skip_missing:
                # CI mode: log to stderr and continue
                import sys as _sys
                print("SKIPPED: Semgrep not installed (--skip-missing)", file=_sys.stderr)
            else:
                # Interactive mode: offer to help install
                console.print()
                console.print("[yellow]⚠ Semgrep not found.[/yellow]")
                console.print(f"  Install with: [cyan]{semgrep.get_install_instructions()}[/cyan]")
                console.print()
                if sys.stdin.isatty():
                    # Only prompt if interactive terminal
                    from rich.prompt import Confirm
                    if Confirm.ask("Continue without Semgrep?", default=True):
                        reporter.info("Continuing with Tree-sitter results only...")
                    else:
                        reporter.info("Aborting. Install Semgrep and try again.")
                        sys.exit(0)
                else:
                    reporter.info("Continuing with Tree-sitter results only...")
        else:
            reporter.info("[Source: Semgrep] Running deep SAST analysis...")
            try:
                semgrep_issues = semgrep.run(path)

                # Merge Semgrep issues with Tree-sitter issues (unified Pydantic Issue)
                result.issues.extend(semgrep_issues)

                # Update files_with_issues count
                files_with_semgrep = set(issue.location.filepath for issue in semgrep_issues)
                files_with_treesitter = set(issue.location.filepath for issue in result.issues if issue not in semgrep_issues)
                result.files_with_issues = len(files_with_semgrep | files_with_treesitter)

                reporter.success(f"[Source: Semgrep] Found {len(semgrep_issues)} additional issues")
            except Exception as e:
                reporter.warning(f"Semgrep scan failed: {e}")
                reporter.info("Continuing with Tree-sitter results only...")

    # Secrets mode: Run Gitleaks for secret detection
    if secrets:
        from qodacode.engines import GitleaksRunner

        gitleaks = GitleaksRunner()

        if not gitleaks.is_available():
            if skip_missing:
                # CI mode: log to stderr and continue
                import sys as _sys
                print("SKIPPED: Gitleaks not installed (--skip-missing)", file=_sys.stderr)
            else:
                # Interactive mode: offer to help install
                console.print()
                console.print("[yellow]⚠ Gitleaks not found.[/yellow]")
                console.print(f"  Install with: [cyan]{gitleaks.get_install_instructions()}[/cyan]")
                console.print()
                if sys.stdin.isatty():
                    from rich.prompt import Confirm
                    if Confirm.ask("Continue without Gitleaks?", default=True):
                        reporter.info("Continuing without secret scanning...")
                    else:
                        reporter.info("Aborting. Install Gitleaks and try again.")
                        sys.exit(0)
                else:
                    reporter.info("Continuing without secret scanning...")
        else:
            reporter.info("[Source: Gitleaks] Scanning for hardcoded secrets...")
            try:
                gitleaks_issues = gitleaks.run(path)

                # Merge Gitleaks issues with existing issues (unified Pydantic Issue)
                result.issues.extend(gitleaks_issues)

                # Update files_with_issues count
                all_files = set(issue.location.filepath for issue in result.issues)
                result.files_with_issues = len(all_files)

                reporter.success(f"[Source: Gitleaks] Found {len(gitleaks_issues)} secret(s)")
            except Exception as e:
                reporter.warning(f"Gitleaks scan failed: {e}")
                reporter.info("Continuing without secret scanning...")

    # Deps mode: Run OSV for dependency vulnerability scanning
    if deps:
        from qodacode.engines import OSVRunner

        osv = OSVRunner()
        reporter.info("[Source: OSV] Scanning dependencies for vulnerabilities...")

        try:
            osv_issues = osv.run(path)

            # Merge OSV issues with existing issues (unified Pydantic Issue)
            result.issues.extend(osv_issues)

            # Update files_with_issues count
            all_files = set(issue.location.filepath for issue in result.issues)
            result.files_with_issues = len(all_files)

            if osv_issues:
                reporter.success(f"[Source: OSV] Found {len(osv_issues)} vulnerable dependency(ies)")
            else:
                reporter.success("[Source: OSV] No vulnerable dependencies found")
        except Exception as e:
            reporter.warning(f"OSV scan failed (offline?): {e}")
            reporter.info("Continuing without dependency scanning...")

    # Deduplicate and filter suppressed issues
    from qodacode.context import Deduplicator

    dedup = Deduplicator(project_root=path)
    original_count = len(result.issues)

    # Deduplicate: same file+line+category = 1 alert
    # Priority: Gitleaks > Semgrep > OSV > Tree-sitter
    result.issues = dedup.deduplicate(result.issues)
    duplicates_removed = original_count - len(result.issues)
    if duplicates_removed > 0:
        reporter.info(f"[Dedup] Removed {duplicates_removed} duplicate(s)")

    # Filter suppressed issues
    before_filter = len(result.issues)
    result.issues = dedup.filter_suppressed(result.issues)
    suppressed_count = before_filter - len(result.issues)
    if suppressed_count > 0:
        reporter.info(f"[Suppress] Filtered {suppressed_count} suppressed issue(s)")

    # Add fingerprints to issues for suppress command
    for issue in result.issues:
        issue.context["fingerprint"] = dedup.get_fingerprint(issue)

    # Output results
    # Output based on format
    if output_format == "json":
        from qodacode.github import calculate_health_score
        health = calculate_health_score(result)
        output = {
            "version": "1.0",
            "files_scanned": result.files_scanned,
            "files_with_issues": result.files_with_issues,
            "summary": {
                "total": len(result.issues),
                "critical": result.critical_count,
                "high": result.high_count,
                "medium": result.medium_count,
                "low": result.low_count,
            },
            "health": health,
            "issues": [issue.model_dump(mode="json") for issue in result.issues],
        }
        click.echo(json.dumps(output, indent=2))
    elif output_format == "sarif":
        from qodacode.github import generate_sarif
        sarif = generate_sarif(result)
        click.echo(json.dumps(sarif, indent=2))
    elif output_format == "markdown":
        from qodacode.github import generate_pr_comment
        markdown = generate_pr_comment(result, show_suggestions=fix, mode=mode)
        click.echo(markdown)
    else:
        reporter.report_scan_result(result, show_fixes=fix, mode=mode)

    # Exit with error code if critical issues found
    if result.critical_count > 0:
        sys.exit(1)


@main.command()
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Path to check (default: current directory)"
)
def status(path: str):
    """Show project status.

    Displays summary of indexed files and current issues.
    """
    qodacode_dir = Path(path) / ".qodacode"

    if not qodacode_dir.exists():
        reporter.warning("Qodacode not initialized. Run 'qodacode init' first.")
        return

    # Load index
    try:
        with open(qodacode_dir / "index.json") as f:
            index_data = json.load(f)
    except FileNotFoundError:
        reporter.error("Index file not found. Run 'qodacode init' to re-index.")
        return

    # Run quick scan for current status
    result = scanner.scan(path)

    reporter.report_status(
        path=path,
        files_scanned=result.files_scanned,
        result=result,
        index_data=index_data,
    )


@main.command()
@click.argument("fingerprint")
@click.option(
    "--reason", "-r",
    default="",
    help="Reason for suppressing (e.g., 'false positive', 'accepted risk')"
)
@click.option(
    "--expires", "-e",
    type=int,
    default=None,
    help="Auto-expire after N days (default: permanent)"
)
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Project root (default: current directory)"
)
def suppress(fingerprint: str, reason: str, expires: int, path: str):
    """Suppress an issue by fingerprint.

    The fingerprint is shown in scan output (e.g., 'abc123def456').
    Suppressed issues won't appear in future scans.

    Example:
        qodacode suppress abc123def456 --reason "false positive"
        qodacode suppress abc123def456 --expires 30  # Expires in 30 days
    """
    from qodacode.context import Deduplicator

    dedup = Deduplicator(project_root=path)

    if dedup.suppress(fingerprint, reason=reason, expires_in_days=expires):
        reporter.success(f"Issue {fingerprint} suppressed")
        if reason:
            reporter.info(f"Reason: {reason}")
        if expires:
            reporter.info(f"Expires in {expires} days")
    else:
        reporter.warning(f"Issue {fingerprint} was already suppressed")


@main.command()
@click.argument("fingerprint")
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Project root (default: current directory)"
)
def unsuppress(fingerprint: str, path: str):
    """Remove a suppression.

    Example:
        qodacode unsuppress abc123def456
    """
    from qodacode.context import Deduplicator

    dedup = Deduplicator(project_root=path)

    if dedup.unsuppress(fingerprint):
        reporter.success(f"Suppression removed for {fingerprint}")
    else:
        reporter.warning(f"Issue {fingerprint} was not suppressed")


@main.command()
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Project root (default: current directory)"
)
def suppressions(path: str):
    """List all active suppressions.

    Example:
        qodacode suppressions
    """
    from qodacode.context import Deduplicator

    dedup = Deduplicator(project_root=path)
    supps = dedup.list_suppressions()

    if not supps:
        reporter.info("No active suppressions")
        return

    reporter.info(f"Active suppressions: {len(supps)}")
    for s in supps:
        expires = f" (expires: {s.expires_at})" if s.expires_at else ""
        reason = f" - {s.reason}" if s.reason else ""
        click.echo(f"  {s.fingerprint}{reason}{expires}")


@main.command()
def doctor():
    """Check engine dependencies and system health.

    Shows status of all analysis engines:
    - Tree-sitter (built-in, always available)
    - Semgrep (optional, for deep SAST)
    - Gitleaks (optional, for secret detection)
    - OSV (uses API, requires internet)

    Example:
        qodacode doctor
    """
    import shutil
    import subprocess

    console.print()
    console.print("[bold]QODACODE Doctor[/bold] - Checking system health...")
    console.print()

    # Create table
    table = Table(title="Engine Status", show_header=True, header_style="bold cyan")
    table.add_column("Engine", style="bold")
    table.add_column("Status")
    table.add_column("Version")
    table.add_column("Path / Info")

    # Tree-sitter (always available - it's a Python package)
    try:
        import tree_sitter
        ts_version = getattr(tree_sitter, '__version__', 'installed')
        table.add_row(
            "Tree-sitter",
            "[green]✓ Installed[/green]",
            ts_version,
            "[dim]Built-in (pip package)[/dim]"
        )
    except ImportError:
        table.add_row(
            "Tree-sitter",
            "[red]✗ Missing[/red]",
            "-",
            "[yellow]pip install tree-sitter[/yellow]"
        )

    # Semgrep
    semgrep_path = shutil.which("semgrep")
    if semgrep_path:
        try:
            result = subprocess.run(
                ["semgrep", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            version = result.stdout.strip().split('\n')[0] if result.stdout else "unknown"
            table.add_row(
                "Semgrep",
                "[green]✓ Installed[/green]",
                version,
                semgrep_path
            )
        except Exception:
            table.add_row(
                "Semgrep",
                "[yellow]? Error[/yellow]",
                "-",
                semgrep_path
            )
    else:
        table.add_row(
            "Semgrep",
            "[red]✗ Missing[/red]",
            "-",
            "[yellow]pip install semgrep[/yellow]"
        )

    # Gitleaks
    gitleaks_path = shutil.which("gitleaks")
    if gitleaks_path:
        try:
            result = subprocess.run(
                ["gitleaks", "version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            version = result.stdout.strip() if result.stdout else "unknown"
            table.add_row(
                "Gitleaks",
                "[green]✓ Installed[/green]",
                version,
                gitleaks_path
            )
        except Exception:
            table.add_row(
                "Gitleaks",
                "[yellow]? Error[/yellow]",
                "-",
                gitleaks_path
            )
    else:
        table.add_row(
            "Gitleaks",
            "[red]✗ Missing[/red]",
            "-",
            "[yellow]brew install gitleaks[/yellow]"
        )

    # OSV (API-based, check internet)
    try:
        import urllib.request
        urllib.request.urlopen("https://api.osv.dev", timeout=3)
        table.add_row(
            "OSV",
            "[green]✓ Available[/green]",
            "API",
            "[dim]https://api.osv.dev[/dim]"
        )
    except Exception:
        table.add_row(
            "OSV",
            "[yellow]⚠ Offline[/yellow]",
            "API",
            "[dim]Requires internet connection[/dim]"
        )

    console.print(table)
    console.print()

    # Summary
    all_installed = semgrep_path and gitleaks_path
    if all_installed:
        console.print("[green]✓ All engines ready![/green] Use [bold]--all[/bold] for full analysis.")
    else:
        console.print("[yellow]Some optional engines missing.[/yellow]")
        console.print("Install them for deeper analysis, or use [bold]--skip-missing[/bold] in CI.")
    console.print()


@main.command()
@click.option(
    "--ai-provider", "-p",
    type=click.Choice(["anthropic", "openai", "ollama", "none"]),
    help="AI provider for explanations"
)
@click.option(
    "--ai-key", "-k",
    help="API key for AI provider (not needed for Ollama)"
)
@click.option(
    "--ai-model", "-m",
    help="Model to use (e.g., claude-3-haiku-20240307, gpt-4o-mini, llama3.2)"
)
@click.option(
    "--show", "-s",
    is_flag=True,
    help="Show current configuration"
)
def config(ai_provider: Optional[str], ai_key: Optional[str], ai_model: Optional[str], show: bool):
    """Configure Qodacode settings.

    Set up AI provider for contextual explanations in junior mode.

    Examples:
        qodacode config --show
        qodacode config --ai-provider anthropic --ai-key sk-ant-xxx
        qodacode config --ai-provider openai --ai-key sk-xxx
        qodacode config --ai-provider ollama --ai-model llama3.2
        qodacode config --ai-provider none

    Environment variables (alternative):
        ANTHROPIC_API_KEY=sk-ant-xxx
        OPENAI_API_KEY=sk-xxx
        OLLAMA_HOST=http://localhost:11434
    """
    from qodacode.ai_explainer import load_config, save_config, get_provider_info

    if show or (not ai_provider and not ai_key and not ai_model):
        # Show current config
        info = get_provider_info()
        reporter.info("Current AI Configuration:")
        if info["available"]:
            console.print(f"  Provider: [green]{info['provider']}[/green]")
            console.print(f"  Model: [cyan]{info['model']}[/cyan]")
            console.print(f"  Status: [green]✓ AI explanations enabled[/green]")
        else:
            console.print(f"  Provider: [dim]none[/dim]")
            console.print(f"  Status: [yellow]Static explanations only[/yellow]")
            console.print()
            console.print("[dim]To enable AI explanations:[/dim]")
            console.print("  qodacode config --ai-provider anthropic --ai-key YOUR_KEY")
            console.print("  qodacode config --ai-provider ollama  [dim](free, local)[/dim]")
        return

    if ai_provider:
        config_path = save_config(
            provider=ai_provider,
            api_key=ai_key,
            model=ai_model,
        )
        reporter.success(f"Configuration saved to {config_path}")

        if ai_provider == "none":
            reporter.info("AI explanations disabled. Using static explanations.")
        elif ai_provider == "ollama":
            reporter.info(f"Using Ollama (local). Model: {ai_model or 'llama3.2'}")
            reporter.info("Make sure Ollama is running: ollama serve")
        else:
            reporter.info(f"Using {ai_provider}. Model: {ai_model or 'default'}")


@main.command()
def rules():
    """List all available rules."""
    all_rules = RuleRegistry.get_all()

    reporter.info(f"Available rules ({len(all_rules)}):\n")

    # Group by category
    by_category = {}
    for rule in all_rules:
        cat = rule.category.value
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(rule)

    for category, rules_list in sorted(by_category.items()):
        reporter.section(category.upper())
        for rule in sorted(rules_list, key=lambda r: r.id):
            severity_color = {
                Severity.CRITICAL: "red",
                Severity.HIGH: "yellow",
                Severity.MEDIUM: "blue",
                Severity.LOW: "dim",
            }.get(rule.severity, "white")

            reporter.rule_info(
                rule_id=rule.id,
                name=rule.name,
                severity=rule.severity.value,
                description=rule.description,
                severity_color=severity_color,
            )
        reporter.newline()


@main.command("git-history")
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Path to git repository (default: current directory)"
)
@click.option(
    "--max-commits", "-n",
    default=50,
    help="Maximum number of commits to scan"
)
@click.option(
    "--since", "-s",
    default=None,
    help="Only scan commits since this date (YYYY-MM-DD)"
)
@click.option(
    "--format", "-f",
    "output_format",
    type=click.Choice(["terminal", "json"]),
    default="terminal",
    help="Output format"
)
def git_history(path: str, max_commits: int, since: Optional[str], output_format: str):
    """Scan git history for secrets.

    Detects secrets that may have been committed and later removed,
    but still exist in git history.

    Examples:
        qodacode git-history
        qodacode git-history --max-commits 100
        qodacode git-history --since 2024-01-01
    """
    from qodacode.git_scanner import scan_git_history, is_git_repo, format_git_findings

    if not is_git_repo(path):
        reporter.error("Not a git repository. Run from inside a git repo.")
        sys.exit(1)

    reporter.info(f"Scanning git history (last {max_commits} commits)...")

    findings = scan_git_history(path, max_commits=max_commits, since=since)

    if output_format == "json":
        output = {
            "findings": [
                {
                    "commit_hash": f.commit_hash,
                    "commit_author": f.commit_author,
                    "commit_date": f.commit_date,
                    "commit_message": f.commit_message,
                    "file_path": f.file_path,
                    "secret_type": f.secret_type,
                    "match": f.match,
                }
                for f in findings
            ],
            "total": len(findings),
        }
        click.echo(json.dumps(output, indent=2))
    else:
        if not findings:
            reporter.success("No secrets found in git history!")
        else:
            console.print(f"\n[red bold]⚠ Found {len(findings)} secret(s) in git history![/red bold]\n")

            table = Table(show_header=True, header_style="bold")
            table.add_column("Commit", style="cyan")
            table.add_column("Date")
            table.add_column("File")
            table.add_column("Type", style="yellow")
            table.add_column("Match", style="red")

            for finding in findings:
                table.add_row(
                    finding.commit_hash,
                    finding.commit_date,
                    finding.file_path[:30],
                    finding.secret_type,
                    finding.match[:20] + "..." if len(finding.match) > 20 else finding.match,
                )

            console.print(table)
            console.print()
            console.print("[yellow]WARNING:[/yellow] Secrets in git history remain accessible even after removal.")
            console.print("[dim]Consider: git filter-branch or BFG Repo-Cleaner to purge history.[/dim]")

            sys.exit(1)


@main.command("serve")
def serve():
    """Start the MCP server for AI integration.

    Exposes Qodacode as an MCP (Model Context Protocol) server that
    can be used by Claude, Cursor, and other MCP-compatible AI tools.

    The server provides tools for:
    - Code scanning and analysis
    - Secret detection
    - Dependency vulnerability checking
    - Rule explanations

    Configure in Claude Code:
        Add to ~/.claude/claude_desktop_config.json:
        {
          "mcpServers": {
            "qodacode": {
              "command": "qodacode",
              "args": ["serve"]
            }
          }
        }
    """
    reporter.info("Starting Qodacode MCP server...")
    reporter.info("Server is ready. Waiting for MCP connections.\n")

    try:
        from qodacode.mcp_server import main as mcp_main
        mcp_main()
    except ImportError as e:
        reporter.error(f"MCP dependencies not installed: {e}")
        reporter.info("Install with: pip install mcp")
        sys.exit(1)


@main.command()
def lsp():
    """Start the Language Server Protocol (LSP) server.

    Used by VSCode/Cursor extension for real-time code analysis.
    Communicates via stdin/stdout using JSON-RPC.

    This command is typically invoked automatically by the VSCode extension.
    """
    try:
        from qodacode.lsp_server import main as lsp_main
        lsp_main()
    except ImportError as e:
        reporter.error(f"LSP dependencies not available: {e}")
        sys.exit(1)
    except Exception as e:
        reporter.error(f"LSP server error: {e}")
        sys.exit(1)


@main.command()
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Path to watch (default: current directory)"
)
@click.option(
    "--severity", "-s",
    type=click.Choice(["critical", "high", "medium", "low", "all"]),
    default="high",
    help="Minimum severity to report (default: high)"
)
@click.option(
    "--mode", "-m",
    type=click.Choice(["junior", "senior"]),
    default="senior",
    help="Output mode"
)
def watch(path: str, severity: str, mode: str):
    """Watch files for changes and scan in real-time.

    Monitors the directory for file changes and automatically
    scans modified files for issues.

    Press Ctrl+C to stop watching.

    Examples:
        qodacode watch
        qodacode watch --path ./src
        qodacode watch --severity critical
    """
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler, FileModifiedEvent, FileCreatedEvent
    except ImportError:
        reporter.error("watchdog package required. Install with: pip install watchdog")
        sys.exit(1)

    # Map severity filter
    severity_filter = None
    if severity != "all":
        severity_map = {
            "critical": [Severity.CRITICAL],
            "high": [Severity.CRITICAL, Severity.HIGH],
            "medium": [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM],
            "low": [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW],
        }
        severity_filter = severity_map.get(severity)

    # Extensions to watch
    WATCH_EXTENSIONS = {".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml", ".yml", ".env"}
    IGNORE_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

    class QodacodeHandler(FileSystemEventHandler):
        """Handler for file system events."""

        def __init__(self):
            self.scanner = Scanner()
            self.last_scan = {}

        def should_scan(self, path: str) -> bool:
            """Check if file should be scanned."""
            p = Path(path)

            # Skip directories in ignore list
            for part in p.parts:
                if part in IGNORE_DIRS:
                    return False

            # Only scan supported extensions
            if p.suffix not in WATCH_EXTENSIONS:
                return False

            # Debounce: skip if scanned in last 2 seconds
            now = time.time()
            if path in self.last_scan and now - self.last_scan[path] < 2:
                return False

            self.last_scan[path] = now
            return True

        def on_modified(self, event):
            if event.is_directory:
                return
            if self.should_scan(event.src_path):
                self.scan_file(event.src_path)

        def on_created(self, event):
            if event.is_directory:
                return
            if self.should_scan(event.src_path):
                self.scan_file(event.src_path)

        def scan_file(self, filepath: str):
            """Scan a single file and report issues."""
            try:
                result = self.scanner.scan_file(
                    filepath,
                    severities=severity_filter,
                )

                if result.issues:
                    console.print(f"\n[yellow]─── File changed: {filepath} ───[/yellow]")
                    reporter.report_scan_result(result, show_fixes=True, mode=mode)
            except Exception as e:
                pass  # Silently ignore scan errors during watch

    # Start watching
    abs_path = os.path.abspath(path)
    console.print(f"\n[bold cyan]👁 Watching for changes...[/bold cyan]")
    console.print(f"[dim]Path: {abs_path}[/dim]")
    console.print(f"[dim]Severity filter: {severity}[/dim]")
    console.print(f"[dim]Press Ctrl+C to stop[/dim]\n")

    event_handler = QodacodeHandler()
    observer = Observer()
    observer.schedule(event_handler, abs_path, recursive=True)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        console.print("\n[dim]Stopped watching.[/dim]")

    observer.join()


@main.command()
@click.option(
    "--path", "-p",
    default=".",
    type=click.Path(exists=True),
    help="Path to scan (default: current directory)"
)
@click.option(
    "--fail-on",
    type=click.Choice(["critical", "high", "medium", "low", "none"]),
    default="critical",
    help="Fail if issues of this severity or higher are found"
)
@click.option(
    "--mode", "-m",
    type=click.Choice(["junior", "senior"]),
    default="senior",
    help="Output mode: junior (educational) or senior (concise)"
)
@click.option(
    "--categories",
    default="all",
    help="Categories to scan (comma-separated)"
)
@click.option(
    "--comment",
    is_flag=True,
    help="Generate PR comment file"
)
@click.option(
    "--output-file",
    help="File to write GitHub Actions outputs"
)
@click.option(
    "--json-output",
    is_flag=True,
    help="Output results as JSON"
)
@click.option(
    "--sarif",
    is_flag=True,
    help="Generate SARIF output for GitHub Security tab"
)
@click.option(
    "--sarif-file",
    default="qodacode-results.sarif",
    help="Path for SARIF output file"
)
def ci(
    path: str,
    fail_on: str,
    mode: str,
    categories: str,
    comment: bool,
    output_file: Optional[str],
    json_output: bool,
    sarif: bool,
    sarif_file: str,
):
    """Run Qodacode in CI/CD mode (GitHub Actions, GitLab CI, etc.).

    Designed for automated pipelines:
    - Outputs to GITHUB_OUTPUT for Actions
    - Generates PR comment markdown
    - Returns exit code based on fail-on threshold
    - Supports JSON and SARIF output

    Examples:
        qodacode ci --fail-on critical --comment
        qodacode ci --fail-on high --json-output
        qodacode ci --sarif  # For GitHub Security tab
        qodacode ci --mode junior --comment
    """
    from qodacode.github import (
        GitHubContext,
        generate_pr_comment,
        generate_status_check_output,
        write_github_output,
        get_exit_code,
        write_sarif,
    )

    # Parse categories
    category_filter = None
    if categories != "all":
        category_list = [c.strip().upper() for c in categories.split(",")]
        category_filter = [
            cat for cat in Category
            if cat.name in category_list
        ]

    # Run scan
    result = scanner.scan(
        path=path,
        categories=category_filter,
    )

    # Get GitHub context
    ctx = GitHubContext.from_env()

    if json_output:
        # JSON output for programmatic use
        output = generate_status_check_output(result, fail_on)
        output["issues"] = [
            {
                "rule_id": issue.rule_id,
                "rule_name": issue.rule_name,
                "severity": issue.severity.name,
                "filepath": issue.location.filepath,
                "line": issue.location.line,
                "message": issue.message,
                "fix_suggestion": issue.fix_suggestion,
            }
            for issue in result.issues
        ]
        click.echo(json.dumps(output, indent=2))
    else:
        # Human-readable output
        status = generate_status_check_output(result, fail_on)

        if result.issues:
            console.print(f"\n[bold red]QODACODE CI: {len(result.issues)} issue(s) found[/bold red]")
        else:
            console.print(f"\n[bold green]QODACODE CI: No issues found![/bold green]")

        console.print(f"[dim]Health Score: {status['health_score']}/100 (Grade {status['grade']})[/dim]")
        console.print(f"[dim]Files scanned: {result.files_scanned}[/dim]")

        if result.critical_count:
            console.print(f"[red]  Critical: {result.critical_count}[/red]")
        if result.high_count:
            console.print(f"[yellow]  High: {result.high_count}[/yellow]")
        if result.medium_count:
            console.print(f"[blue]  Medium: {result.medium_count}[/blue]")
        if result.low_count:
            console.print(f"[dim]  Low: {result.low_count}[/dim]")

    # Write GitHub outputs
    if ctx.is_ci or output_file:
        write_github_output(result, fail_on, output_file)
        if comment:
            console.print(f"\n[dim]PR comment written to .qodacode/pr-comment.md[/dim]")

    # Generate PR comment file if requested
    if comment:
        from pathlib import Path
        comment_dir = Path(".qodacode")
        comment_dir.mkdir(exist_ok=True)
        comment_content = generate_pr_comment(result, fail_on, mode=mode)
        (comment_dir / "pr-comment.md").write_text(comment_content)

    # Generate SARIF output for GitHub Security tab
    if sarif:
        sarif_path = write_sarif(result, sarif_file)
        console.print(f"\n[green]SARIF output written to {sarif_path}[/green]")
        console.print(f"[dim]Upload to GitHub: gh code-scanning upload --sarif-file={sarif_path}[/dim]")

    # Exit with appropriate code
    exit_code = get_exit_code(result, fail_on)
    if exit_code != 0:
        console.print(f"\n[red bold]Merge blocked: {fail_on} issues found[/red bold]")

    sys.exit(exit_code)


@main.command()
def login():
    """Authenticate with GitHub for MCP integration.

    Opens browser for GitHub OAuth authentication.
    Required for using Qodacode with Claude Code via MCP.

    The token is stored securely in ~/.qodacode/auth.json
    """
    import webbrowser
    import secrets
    import http.server
    import urllib.parse

    AUTH_DIR = Path.home() / ".qodacode"
    AUTH_FILE = AUTH_DIR / "auth.json"

    # For now, we'll use a simple approach without OAuth
    # Just verify GitHub CLI is available and user is logged in
    console.print("\n[bold #DA7028]Qodacode Login[/bold #DA7028]\n")

    # Check if gh CLI is installed
    import subprocess

    try:
        result = subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            # Extract username from output
            output = result.stdout + result.stderr
            username = "user"
            for line in output.split("\n"):
                if "Logged in to github.com account" in line:
                    # Extract username
                    parts = line.split("account")
                    if len(parts) > 1:
                        username = parts[1].strip().split()[0].strip("()")
                    break
                elif "Logged in to github.com as" in line:
                    parts = line.split("as")
                    if len(parts) > 1:
                        username = parts[1].strip().split()[0]
                    break

            # Save auth info
            AUTH_DIR.mkdir(exist_ok=True)
            auth_data = {
                "method": "gh_cli",
                "username": username,
                "authenticated": True,
            }
            with open(AUTH_FILE, "w") as f:
                json.dump(auth_data, f, indent=2)

            console.print(f"[green]✓ Logged in as[/green] [bold]@{username}[/bold]")
            console.print(f"\n[dim]Auth saved to {AUTH_FILE}[/dim]")
            console.print("\n[#DA7028]Next step:[/#DA7028] Run [bold]qodacode setup-mcp[/bold] to configure Claude Code")

        else:
            console.print("[yellow]GitHub CLI not authenticated.[/yellow]")
            console.print("\n[#DA7028]To authenticate:[/#DA7028]")
            console.print("  1. Install GitHub CLI: [dim]brew install gh[/dim]")
            console.print("  2. Login: [dim]gh auth login[/dim]")
            console.print("  3. Run: [dim]qodacode login[/dim]")
            sys.exit(1)

    except FileNotFoundError:
        console.print("[yellow]GitHub CLI (gh) not found.[/yellow]")
        console.print("\n[#DA7028]Install GitHub CLI:[/#DA7028]")
        console.print("  macOS:   [dim]brew install gh[/dim]")
        console.print("  Linux:   [dim]sudo apt install gh[/dim]")
        console.print("  Windows: [dim]winget install GitHub.cli[/dim]")
        console.print("\nThen run: [dim]gh auth login[/dim]")
        sys.exit(1)


@main.command("setup-mcp")
def setup_mcp():
    """Configure MCP server for Claude Code.

    Automatically adds Qodacode to Claude Code's MCP configuration.
    After running this, restart Claude Code to use Qodacode.

    Usage in Claude Code:
        "scan this project with Qodacode"
        "check for security issues"
    """
    CLAUDE_CONFIG_DIR = Path.home() / ".claude"
    CLAUDE_CONFIG_FILE = CLAUDE_CONFIG_DIR / "claude_desktop_config.json"
    AUTH_FILE = Path.home() / ".qodacode" / "auth.json"

    console.print("\n[bold #DA7028]Qodacode MCP Setup[/bold #DA7028]\n")

    # Check if logged in
    if not AUTH_FILE.exists():
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("Run [bold]qodacode login[/bold] first.")
        sys.exit(1)

    # Create Claude config directory if needed
    CLAUDE_CONFIG_DIR.mkdir(exist_ok=True)

    # Load existing config or create new
    if CLAUDE_CONFIG_FILE.exists():
        with open(CLAUDE_CONFIG_FILE) as f:
            config = json.load(f)
    else:
        config = {}

    # Add/update mcpServers
    if "mcpServers" not in config:
        config["mcpServers"] = {}

    config["mcpServers"]["qodacode"] = {
        "command": "qodacode",
        "args": ["serve"]
    }

    # Write config
    with open(CLAUDE_CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)

    console.print(f"[green]✓ Added qodacode to[/green] {CLAUDE_CONFIG_FILE}")
    console.print("\n[bold #DA7028]Next steps:[/bold #DA7028]")
    console.print("  1. [bold]Restart Claude Code[/bold]")
    console.print("  2. Say: [dim]\"scan this project with Qodacode\"[/dim]")
    console.print("\n[dim]MCP server will start automatically when Claude Code needs it.[/dim]")


if __name__ == "__main__":
    main()
