"""
Qodacode VectorStore - Chroma-based embedding storage.

Stores code embeddings for semantic search and cross-file context.
"""

import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

import numpy as np

try:
    import chromadb
    from chromadb.config import Settings
    CHROMA_AVAILABLE = True
except ImportError:
    CHROMA_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False


@dataclass
class SearchResult:
    """Result from vector search."""
    id: str
    content: str
    metadata: Dict[str, Any]
    distance: float


class VectorStore:
    """
    Chroma-based vector store for code embeddings.

    Features:
    - Persistent local storage in .qodacode/chroma/
    - Semantic search for similar code
    - Metadata filtering (file type, entity type, etc.)
    """

    def __init__(
        self,
        path: str = ".qodacode/chroma",
        collection_name: str = "code_entities",
        embedding_model: str = "nomic-ai/nomic-embed-text-v1.5",
        embedding_dim: int = 256,
    ):
        """
        Initialize the vector store.

        Args:
            path: Path to store Chroma database
            collection_name: Name of the collection
            embedding_model: Sentence transformer model to use
            embedding_dim: Dimension for Matryoshka truncation
        """
        self.path = path
        self.collection_name = collection_name
        self.embedding_dim = embedding_dim
        self._model = None
        self._client = None
        self._collection = None

        if not CHROMA_AVAILABLE:
            raise ImportError("chromadb is required. Install with: pip install chromadb")

    @property
    def model(self) -> "SentenceTransformer":
        """Lazy load embedding model."""
        if self._model is None:
            if not EMBEDDINGS_AVAILABLE:
                raise ImportError(
                    "sentence-transformers is required. "
                    "Install with: pip install sentence-transformers"
                )
            self._model = SentenceTransformer(
                "nomic-ai/nomic-embed-text-v1.5",
                trust_remote_code=True,
            )
        return self._model

    @property
    def client(self) -> "chromadb.Client":
        """Lazy load Chroma client."""
        if self._client is None:
            # Create directory if needed
            os.makedirs(self.path, exist_ok=True)

            self._client = chromadb.PersistentClient(
                path=self.path,
                settings=Settings(anonymized_telemetry=False),
            )
        return self._client

    @property
    def collection(self) -> "chromadb.Collection":
        """Get or create the collection."""
        if self._collection is None:
            self._collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection

    def embed(self, text: str, is_query: bool = False) -> np.ndarray:
        """
        Generate embedding for text.

        Args:
            text: Text to embed
            is_query: If True, use query prefix; else use document prefix

        Returns:
            Embedding vector truncated to embedding_dim
        """
        # nomic-embed requires task prefixes
        prefix = "search_query: " if is_query else "search_document: "
        full_text = prefix + text

        embedding = self.model.encode(full_text)

        # Matryoshka truncation to save space
        return embedding[:self.embedding_dim]

    def add(
        self,
        id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Add a single item to the store.

        Args:
            id: Unique identifier
            content: Text content to embed
            metadata: Optional metadata dict
        """
        embedding = self.embed(content, is_query=False)

        self.collection.add(
            ids=[id],
            embeddings=[embedding.tolist()],
            documents=[content],
            metadatas=[metadata or {}],
        )

    def add_batch(
        self,
        ids: List[str],
        contents: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """
        Add multiple items to the store.

        Args:
            ids: List of unique identifiers
            contents: List of text contents
            metadatas: Optional list of metadata dicts
        """
        embeddings = [self.embed(c, is_query=False).tolist() for c in contents]

        self.collection.add(
            ids=ids,
            embeddings=embeddings,
            documents=contents,
            metadatas=metadatas or [{} for _ in ids],
        )

    def search(
        self,
        query: str,
        limit: int = 5,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[SearchResult]:
        """
        Search for similar items.

        Args:
            query: Search query text
            limit: Maximum results to return
            where: Optional metadata filter

        Returns:
            List of SearchResult objects
        """
        query_embedding = self.embed(query, is_query=True)

        results = self.collection.query(
            query_embeddings=[query_embedding.tolist()],
            n_results=limit,
            where=where,
            include=["documents", "metadatas", "distances"],
        )

        search_results = []
        if results["ids"] and results["ids"][0]:
            for i, id in enumerate(results["ids"][0]):
                search_results.append(SearchResult(
                    id=id,
                    content=results["documents"][0][i] if results["documents"] else "",
                    metadata=results["metadatas"][0][i] if results["metadatas"] else {},
                    distance=results["distances"][0][i] if results["distances"] else 0.0,
                ))

        return search_results

    def get(self, id: str) -> Optional[SearchResult]:
        """Get a specific item by ID."""
        result = self.collection.get(
            ids=[id],
            include=["documents", "metadatas"],
        )

        if result["ids"]:
            return SearchResult(
                id=result["ids"][0],
                content=result["documents"][0] if result["documents"] else "",
                metadata=result["metadatas"][0] if result["metadatas"] else {},
                distance=0.0,
            )
        return None

    def delete(self, id: str) -> None:
        """Delete an item by ID."""
        self.collection.delete(ids=[id])

    def delete_by_metadata(self, where: Dict[str, Any]) -> None:
        """Delete items matching metadata filter."""
        self.collection.delete(where=where)

    def count(self) -> int:
        """Get total number of items in store."""
        return self.collection.count()

    def clear(self) -> None:
        """Clear all items from the store."""
        self.client.delete_collection(self.collection_name)
        self._collection = None
