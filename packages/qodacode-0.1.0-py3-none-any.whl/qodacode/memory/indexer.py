"""
Qodacode Indexer - Repository indexing with Tree-sitter.

Extracts code entities (functions, classes, imports) and their
relationships for cross-file context.
"""

import os
import hashlib
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import tree_sitter

from qodacode.scanner import LANGUAGE_CONFIG
from qodacode.memory.store import VectorStore


class EntityType(Enum):
    """Types of code entities."""
    FUNCTION = "function"
    CLASS = "class"
    METHOD = "method"
    MODULE = "module"
    VARIABLE = "variable"
    IMPORT = "import"


class RelationType(Enum):
    """Types of relationships between entities."""
    CALLS = "calls"
    IMPORTS = "imports"
    CONTAINS = "contains"
    INHERITS = "inherits"
    DEFINES = "defines"
    USES = "uses"


@dataclass
class CodeEntity:
    """Represents a code entity (function, class, etc.)."""
    id: str
    type: EntityType
    name: str
    filepath: str
    start_line: int
    end_line: int
    content: str
    signature: str = ""
    docstring: str = ""
    metadata: Dict = field(default_factory=dict)


@dataclass
class Relationship:
    """Represents a relationship between entities."""
    source_id: str
    target_id: str
    type: RelationType
    metadata: Dict = field(default_factory=dict)


class Indexer:
    """
    Repository indexer using Tree-sitter.

    Extracts code entities and relationships for:
    - Cross-file context (what calls what)
    - Semantic search (find similar code)
    - Impact analysis (what does this change affect)
    """

    def __init__(
        self,
        store: Optional[VectorStore] = None,
        qodacode_path: str = ".qodacode",
    ):
        """
        Initialize the indexer.

        Args:
            store: VectorStore for embeddings (created if None)
            qodacode_path: Path to .qodacode directory
        """
        self.qodacode_path = qodacode_path
        self.store = store or VectorStore(path=f"{qodacode_path}/chroma")

        self._parsers: Dict[str, tree_sitter.Parser] = {}
        self._entities: Dict[str, CodeEntity] = {}
        self._relationships: List[Relationship] = []

        # Initialize parsers
        for ext, config in LANGUAGE_CONFIG.items():
            lang_name = config["name"]
            if lang_name not in self._parsers:
                parser = tree_sitter.Parser(config["language"])
                self._parsers[lang_name] = parser

    def _get_language(self, filepath: str) -> Optional[str]:
        """Get language from file extension."""
        ext = Path(filepath).suffix.lower()
        if ext in LANGUAGE_CONFIG:
            return LANGUAGE_CONFIG[ext]["name"]
        return None

    def _generate_id(self, filepath: str, name: str, line: int) -> str:
        """Generate unique ID for an entity."""
        content = f"{filepath}:{name}:{line}"
        return hashlib.md5(content.encode()).hexdigest()[:12]

    def index_file(self, filepath: str) -> List[CodeEntity]:
        """
        Index a single file, extracting entities.

        Args:
            filepath: Path to file to index

        Returns:
            List of extracted CodeEntity objects
        """
        language = self._get_language(filepath)
        if not language or language not in self._parsers:
            return []

        try:
            with open(filepath, "rb") as f:
                source = f.read()
        except (IOError, OSError):
            return []

        parser = self._parsers[language]
        tree = parser.parse(source)

        entities = []

        if language == "python":
            entities = self._extract_python_entities(tree, source, filepath)
        elif language in ("javascript", "typescript"):
            entities = self._extract_js_entities(tree, source, filepath)

        # Store entities
        for entity in entities:
            self._entities[entity.id] = entity

        return entities

    def _extract_python_entities(
        self,
        tree: tree_sitter.Tree,
        source: bytes,
        filepath: str,
    ) -> List[CodeEntity]:
        """Extract entities from Python code."""
        entities = []

        def visit(node: tree_sitter.Node, parent_class: Optional[str] = None):
            # Function definition
            if node.type == "function_definition":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte].decode()
                    entity_type = EntityType.METHOD if parent_class else EntityType.FUNCTION

                    # Get signature
                    params_node = node.child_by_field_name("parameters")
                    params = ""
                    if params_node:
                        params = source[params_node.start_byte:params_node.end_byte].decode()

                    # Get docstring
                    docstring = self._extract_docstring(node, source)

                    entity = CodeEntity(
                        id=self._generate_id(filepath, name, node.start_point[0]),
                        type=entity_type,
                        name=name,
                        filepath=filepath,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        content=source[node.start_byte:node.end_byte].decode(),
                        signature=f"def {name}{params}",
                        docstring=docstring,
                        metadata={"class": parent_class} if parent_class else {},
                    )
                    entities.append(entity)

            # Class definition
            elif node.type == "class_definition":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte].decode()
                    docstring = self._extract_docstring(node, source)

                    entity = CodeEntity(
                        id=self._generate_id(filepath, name, node.start_point[0]),
                        type=EntityType.CLASS,
                        name=name,
                        filepath=filepath,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        content=source[node.start_byte:node.end_byte].decode(),
                        signature=f"class {name}",
                        docstring=docstring,
                    )
                    entities.append(entity)

                    # Visit children with class context
                    for child in node.children:
                        visit(child, parent_class=name)
                    return  # Don't double-visit children

            # Import statement
            elif node.type in ("import_statement", "import_from_statement"):
                import_text = source[node.start_byte:node.end_byte].decode()
                entity = CodeEntity(
                    id=self._generate_id(filepath, import_text, node.start_point[0]),
                    type=EntityType.IMPORT,
                    name=import_text,
                    filepath=filepath,
                    start_line=node.start_point[0] + 1,
                    end_line=node.end_point[0] + 1,
                    content=import_text,
                )
                entities.append(entity)

            # Recurse into children
            for child in node.children:
                visit(child, parent_class)

        visit(tree.root_node)
        return entities

    def _extract_js_entities(
        self,
        tree: tree_sitter.Tree,
        source: bytes,
        filepath: str,
    ) -> List[CodeEntity]:
        """Extract entities from JavaScript/TypeScript code."""
        entities = []

        def visit(node: tree_sitter.Node):
            # Function declaration
            if node.type == "function_declaration":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte].decode()
                    params_node = node.child_by_field_name("parameters")
                    params = ""
                    if params_node:
                        params = source[params_node.start_byte:params_node.end_byte].decode()

                    entity = CodeEntity(
                        id=self._generate_id(filepath, name, node.start_point[0]),
                        type=EntityType.FUNCTION,
                        name=name,
                        filepath=filepath,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        content=source[node.start_byte:node.end_byte].decode(),
                        signature=f"function {name}{params}",
                    )
                    entities.append(entity)

            # Arrow function in variable declaration
            elif node.type == "lexical_declaration":
                for child in node.children:
                    if child.type == "variable_declarator":
                        name_node = child.child_by_field_name("name")
                        value_node = child.child_by_field_name("value")
                        if name_node and value_node and value_node.type == "arrow_function":
                            name = source[name_node.start_byte:name_node.end_byte].decode()
                            entity = CodeEntity(
                                id=self._generate_id(filepath, name, node.start_point[0]),
                                type=EntityType.FUNCTION,
                                name=name,
                                filepath=filepath,
                                start_line=node.start_point[0] + 1,
                                end_line=node.end_point[0] + 1,
                                content=source[node.start_byte:node.end_byte].decode(),
                                signature=f"const {name} = () =>",
                            )
                            entities.append(entity)

            # Class declaration
            elif node.type == "class_declaration":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte].decode()
                    entity = CodeEntity(
                        id=self._generate_id(filepath, name, node.start_point[0]),
                        type=EntityType.CLASS,
                        name=name,
                        filepath=filepath,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        content=source[node.start_byte:node.end_byte].decode(),
                        signature=f"class {name}",
                    )
                    entities.append(entity)

            # Import statement
            elif node.type == "import_statement":
                import_text = source[node.start_byte:node.end_byte].decode()
                entity = CodeEntity(
                    id=self._generate_id(filepath, import_text, node.start_point[0]),
                    type=EntityType.IMPORT,
                    name=import_text,
                    filepath=filepath,
                    start_line=node.start_point[0] + 1,
                    end_line=node.end_point[0] + 1,
                    content=import_text,
                )
                entities.append(entity)

            for child in node.children:
                visit(child)

        visit(tree.root_node)
        return entities

    def _extract_docstring(self, node: tree_sitter.Node, source: bytes) -> str:
        """Extract docstring from function/class node."""
        # Look for string as first statement in body
        body = node.child_by_field_name("body")
        if body and body.children:
            first_stmt = body.children[0]
            if first_stmt.type == "expression_statement":
                expr = first_stmt.children[0] if first_stmt.children else None
                if expr and expr.type == "string":
                    docstring = source[expr.start_byte:expr.end_byte].decode()
                    # Remove quotes
                    return docstring.strip('"""').strip("'''").strip()
        return ""

    def index_directory(
        self,
        path: str,
        exclude: Optional[Set[str]] = None,
    ) -> Tuple[int, int]:
        """
        Index all files in a directory.

        Args:
            path: Directory path to index
            exclude: Patterns to exclude

        Returns:
            Tuple of (files_indexed, entities_found)
        """
        exclude = exclude or {
            ".git", "node_modules", "__pycache__", ".venv", "venv",
            "dist", "build", ".qodacode",
        }

        files_indexed = 0
        total_entities = 0

        for root, dirs, files in os.walk(path):
            # Filter excluded directories
            dirs[:] = [d for d in dirs if d not in exclude]

            for filename in files:
                filepath = os.path.join(root, filename)
                if self._get_language(filepath):
                    entities = self.index_file(filepath)
                    if entities:
                        files_indexed += 1
                        total_entities += len(entities)

                        # Add to vector store
                        for entity in entities:
                            # Create searchable content
                            search_content = f"{entity.name} {entity.signature} {entity.docstring}"
                            self.store.add(
                                id=entity.id,
                                content=search_content,
                                metadata={
                                    "type": entity.type.value,
                                    "name": entity.name,
                                    "filepath": entity.filepath,
                                    "start_line": entity.start_line,
                                    "end_line": entity.end_line,
                                },
                            )

        return files_indexed, total_entities

    def search(self, query: str, limit: int = 5) -> List[CodeEntity]:
        """
        Search for entities matching a query.

        Args:
            query: Search query
            limit: Maximum results

        Returns:
            List of matching CodeEntity objects
        """
        results = self.store.search(query, limit=limit)
        entities = []

        for result in results:
            if result.id in self._entities:
                entities.append(self._entities[result.id])

        return entities

    def get_entity(self, entity_id: str) -> Optional[CodeEntity]:
        """Get entity by ID."""
        return self._entities.get(entity_id)

    def get_entities_in_file(self, filepath: str) -> List[CodeEntity]:
        """Get all entities in a file."""
        return [e for e in self._entities.values() if e.filepath == filepath]

    def get_stats(self) -> Dict[str, int]:
        """Get indexing statistics."""
        stats = {
            "total_entities": len(self._entities),
            "functions": 0,
            "classes": 0,
            "methods": 0,
            "imports": 0,
        }

        for entity in self._entities.values():
            if entity.type == EntityType.FUNCTION:
                stats["functions"] += 1
            elif entity.type == EntityType.CLASS:
                stats["classes"] += 1
            elif entity.type == EntityType.METHOD:
                stats["methods"] += 1
            elif entity.type == EntityType.IMPORT:
                stats["imports"] += 1

        return stats
