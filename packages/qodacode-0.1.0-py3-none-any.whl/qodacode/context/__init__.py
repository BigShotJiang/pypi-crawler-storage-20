"""
Context management for Qodacode.

Handles deduplication, suppression, and memory of issues.
"""

from .deduplicator import Deduplicator, IssueFingerprint

__all__ = ["Deduplicator", "IssueFingerprint"]
