"""
Qodacode MCP Server - Enterprise Edition.

Exposes Qodacode analysis capabilities as MCP tools for AI assistants.
Allows Claude, Cursor, and other MCP-compatible tools to use Qodacode
for code analysis, security scanning, and quality checks.

Features:
- Multi-engine orchestration (Gitleaks, Tree-sitter, Semgrep, OSV)
- Rich output with fix suggestions and CWE references
- Adaptive output modes (junior/senior)
- AI-enriched explanations when API key is available
"""

import json
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any, Literal

from mcp.server.fastmcp import FastMCP

# Configure logging to stderr (CRITICAL: never use stdout with STDIO transport)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("qodacode-mcp")

# Initialize MCP server
mcp = FastMCP("qodacode")


# CWE Mapping for common vulnerability types
CWE_MAP = {
    # Secrets
    "GL-": "CWE-798",  # Hardcoded Credentials
    # SQL Injection
    "SEC-002": "CWE-89",
    "sql-injection": "CWE-89",
    # Command Injection
    "SEC-003": "CWE-78",
    "command-injection": "CWE-78",
    # XSS
    "SEC-004": "CWE-79",
    "xss": "CWE-79",
    # Path Traversal
    "SEC-007": "CWE-22",
    "path-traversal": "CWE-22",
    # Deserialization
    "SEC-006": "CWE-502",
    # Missing Auth
    "SEC-005": "CWE-306",
}


def _get_cwe_id(rule_id: str, rule_name: str = "") -> Optional[str]:
    """Get CWE ID for a rule if available."""
    # Check direct rule_id match
    if rule_id in CWE_MAP:
        return CWE_MAP[rule_id]
    # Check prefix match (for Gitleaks GL-*)
    for prefix, cwe in CWE_MAP.items():
        if rule_id.startswith(prefix):
            return cwe
    # Check rule_name keywords
    for keyword, cwe in CWE_MAP.items():
        if keyword in rule_name.lower():
            return cwe
    return None


def _format_issue(issue, mode: str = "senior") -> dict:
    """Format an issue for JSON output with rich context."""
    base = {
        "rule_id": issue.rule_id,
        "rule_name": issue.rule_name,
        "category": issue.category.value,
        "severity": issue.severity.value,
        "file": issue.location.filepath,
        "line": issue.location.line,
        "column": issue.location.column,
        "message": issue.message,
        "fix_suggestion": issue.fix_suggestion,
    }

    # Add CWE if available
    cwe = _get_cwe_id(issue.rule_id, issue.rule_name)
    if cwe:
        base["cwe_id"] = cwe
        base["cwe_url"] = f"https://cwe.mitre.org/data/definitions/{cwe.split('-')[1]}.html"

    # Add snippet if available
    if hasattr(issue, "snippet") and issue.snippet:
        base["snippet"] = issue.snippet

    # Add engine source if available
    if hasattr(issue, "engine") and issue.engine:
        base["engine"] = issue.engine.value

    # Junior mode: add detailed explanations
    if mode == "junior":
        base["why_it_matters"] = _get_why_it_matters(issue.rule_id)
        base["how_to_fix"] = _get_how_to_fix(issue.rule_id)

    return base


def _format_issue_rich(issue, mode: str = "senior") -> dict:
    """Format an issue with maximum context for LLM consumption."""
    base = _format_issue(issue, mode)

    # Add fix code snippet if we can infer it
    fix_snippet = _get_fix_snippet(issue.rule_id, getattr(issue, "snippet", None))
    if fix_snippet:
        base["suggested_fix_snippet"] = fix_snippet

    # Add context for cross-file analysis
    if hasattr(issue, "context") and issue.context:
        base["context"] = issue.context

    return base


def _get_fix_snippet(rule_id: str, original_snippet: Optional[str] = None) -> Optional[str]:
    """Generate a code fix snippet for common patterns."""
    fix_snippets = {
        "SEC-001": "# Use environment variable\nimport os\napi_key = os.getenv('API_KEY')",
        "SEC-002": "# Use parameterized query\ncursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
        "SEC-003": "# Use subprocess with shell=False\nimport subprocess\nsubprocess.run(['ls', '-la'], shell=False)",
        "ROB-001": "# Add try-except block\ntry:\n    risky_operation()\nexcept Exception as e:\n    logger.error(f'Error: {e}')",
        "ROB-002": "# Add timeout\nrequests.get(url, timeout=30)",
    }
    # Check Gitleaks prefix
    if rule_id.startswith("GL-"):
        return fix_snippets.get("SEC-001")
    return fix_snippets.get(rule_id)


@mcp.tool()
def full_audit(
    path: str = ".",
    include_memory: bool = False,
) -> str:
    """Run a comprehensive security audit using all available engines.

    This is the most thorough scan, combining:
    1. Gitleaks - Secret detection (API keys, tokens, credentials)
    2. Tree-sitter - Fast pattern matching (code quality, security patterns)
    3. Semgrep - Deep SAST analysis (complex vulnerabilities, taint tracking)
    4. OSV - Dependency vulnerabilities (CVEs from Open Source Vulnerabilities DB)

    Use this for:
    - Pre-commit security checks
    - CI/CD pipeline gates
    - Security audits before production deployments
    - Compliance verification

    Args:
        path: Directory to audit. Defaults to current directory.
        include_memory: If True, search for similar vulnerable patterns across codebase.

    Returns:
        JSON with issues from all engines, sorted by severity.
    """
    from qodacode.scanner import Scanner

    logger.info(f"Full audit on: {path}")

    all_issues: List[Dict[str, Any]] = []
    engines_run: Dict[str, Any] = {}

    # 1. Gitleaks (secrets) - PRIORITY
    try:
        from qodacode.engines.gitleaks_runner import GitleaksRunner

        gitleaks = GitleaksRunner()
        if gitleaks.is_available():
            gl_issues = gitleaks.run(path)
            engines_run["gitleaks"] = {"status": "success", "count": len(gl_issues)}
            for issue in gl_issues:
                all_issues.append(_format_issue_rich(issue))
        else:
            engines_run["gitleaks"] = {"status": "not_available"}
    except Exception as e:
        engines_run["gitleaks"] = {"status": "error", "message": str(e)}

    # 2. Tree-sitter (fast patterns)
    try:
        import qodacode.rules.security  # noqa: F401
        import qodacode.rules.robustness  # noqa: F401
        import qodacode.rules.maintainability  # noqa: F401
        import qodacode.rules.operability  # noqa: F401

        scanner = Scanner()
        ts_result = scanner.scan(path)
        engines_run["tree_sitter"] = {
            "status": "success",
            "count": len(ts_result.issues),
            "files_scanned": ts_result.files_scanned,
        }
        for issue in ts_result.issues:
            all_issues.append(_format_issue_rich(issue))
    except Exception as e:
        engines_run["tree_sitter"] = {"status": "error", "message": str(e)}

    # 3. Semgrep (deep SAST)
    try:
        from qodacode.engines.semgrep_runner import SemgrepRunner

        semgrep = SemgrepRunner()
        if semgrep.is_available():
            sg_issues = semgrep.run(path)
            engines_run["semgrep"] = {"status": "success", "count": len(sg_issues)}
            for issue in sg_issues:
                all_issues.append(_format_issue_rich(issue))
        else:
            engines_run["semgrep"] = {
                "status": "not_installed",
                "install": "pip install semgrep",
            }
    except Exception as e:
        engines_run["semgrep"] = {"status": "error", "message": str(e)}

    # 4. OSV (dependency vulnerabilities)
    try:
        from qodacode.osv import (
            find_dependency_files,
            parse_dependency_file,
            query_osv_batch,
        )

        dep_files = find_dependency_files(path)
        if dep_files:
            vuln_count = 0
            for dep_file in dep_files:
                ecosystem, packages = parse_dependency_file(dep_file)
                if packages:
                    vulns = query_osv_batch(packages, ecosystem)
                    for pkg_name, pkg_vulns in vulns.items():
                        for vuln in pkg_vulns:
                            vuln_count += 1
                            all_issues.append({
                                "rule_id": vuln.get("id", "OSV-UNKNOWN"),
                                "rule_name": "vulnerable-dependency",
                                "category": "dependencies",
                                "severity": vuln.get("severity", "high"),
                                "file": str(dep_file),
                                "line": 0,
                                "message": f"{pkg_name}: {vuln.get('summary', 'Known vulnerability')}",
                                "fix_suggestion": "Update to a patched version",
                                "engine": "osv",
                            })
            engines_run["osv"] = {"status": "success", "count": vuln_count}
        else:
            engines_run["osv"] = {"status": "no_dependency_files"}
    except Exception as e:
        engines_run["osv"] = {"status": "error", "message": str(e)}

    # 5. Memory search (optional) - find similar patterns
    similar_patterns = []
    if include_memory:
        try:
            indexer = _get_indexer()
            if indexer.store.count() > 0:
                # Search for files with critical issues
                critical_files = set(
                    i["file"] for i in all_issues
                    if i.get("severity") in ["critical", "high"]
                )
                for filepath in list(critical_files)[:3]:  # Limit to top 3
                    results = indexer.store.search(
                        f"security vulnerability in {filepath}",
                        limit=3,
                    )
                    for r in results:
                        if r.metadata.get("filepath") != filepath:
                            similar_patterns.append({
                                "source_file": filepath,
                                "similar_file": r.metadata.get("filepath"),
                                "entity": r.metadata.get("name"),
                                "relevance": round(1 - r.distance, 3),
                            })
        except Exception:
            pass  # Memory search is optional

    # Sort issues by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    all_issues.sort(key=lambda x: severity_order.get(x.get("severity", "info"), 4))

    # Count by severity
    severity_counts = {
        "critical": sum(1 for i in all_issues if i.get("severity") == "critical"),
        "high": sum(1 for i in all_issues if i.get("severity") == "high"),
        "medium": sum(1 for i in all_issues if i.get("severity") == "medium"),
        "low": sum(1 for i in all_issues if i.get("severity") == "low"),
    }

    output = {
        "summary": {
            "total_issues": len(all_issues),
            "by_severity": severity_counts,
            "engines": engines_run,
        },
        "issues": all_issues,
    }

    if similar_patterns:
        output["similar_patterns"] = similar_patterns

    return json.dumps(output, indent=2)


@mcp.tool()
def scan_code(
    path: str = ".",
    mode: str = "fast",
    categories: Optional[str] = None,
    severity_filter: Optional[str] = None,
) -> str:
    """Scan code for security vulnerabilities, quality issues, and best practices.

    This tool analyzes source code using static analysis to find:
    - Security vulnerabilities (SQL injection, XSS, hardcoded secrets, etc.)
    - Robustness issues (missing error handling, no timeouts, etc.)
    - Maintainability problems (long functions, too many parameters)
    - Operability concerns (no logging, hardcoded config)

    Args:
        path: File or directory path to scan. Defaults to current directory.
        mode: Scan mode - "fast" (Tree-sitter only, quick) or "deep" (includes Semgrep SAST).
        categories: Comma-separated list of categories to check.
                   Options: security, robustness, maintainability, operability, dependencies
        severity_filter: Minimum severity to report. Options: critical, high, medium, low
    """
    from qodacode.scanner import Scanner
    from qodacode.rules.base import Category, Severity

    logger.info(f"Scanning path: {path}")

    # Import rules to register them
    import qodacode.rules.security  # noqa: F401
    import qodacode.rules.robustness  # noqa: F401
    import qodacode.rules.maintainability  # noqa: F401
    import qodacode.rules.operability  # noqa: F401
    import qodacode.rules.dependencies  # noqa: F401

    scanner = Scanner()

    # Parse categories filter
    category_list = None
    if categories:
        category_map = {
            "security": Category.SECURITY,
            "robustness": Category.ROBUSTNESS,
            "maintainability": Category.MAINTAINABILITY,
            "operability": Category.OPERABILITY,
            "dependencies": Category.DEPENDENCIES,
        }
        category_list = [
            category_map[c.strip().lower()]
            for c in categories.split(",")
            if c.strip().lower() in category_map
        ]

    # Parse severity filter
    severity_list = None
    if severity_filter:
        severity_order = ["critical", "high", "medium", "low", "info"]
        min_index = severity_order.index(severity_filter.lower())
        severity_map = {
            "critical": Severity.CRITICAL,
            "high": Severity.HIGH,
            "medium": Severity.MEDIUM,
            "low": Severity.LOW,
            "info": Severity.INFO,
        }
        severity_list = [
            severity_map[s] for s in severity_order[:min_index + 1]
        ]

    # Run Tree-sitter scan (always)
    result = scanner.scan(
        path=path,
        categories=category_list,
        severities=severity_list,
    )

    all_issues = list(result.issues)
    engines_used = ["tree_sitter"]

    # Deep mode: also run Semgrep
    if mode == "deep":
        try:
            from qodacode.engines.semgrep_runner import SemgrepRunner

            semgrep = SemgrepRunner()
            if semgrep.is_available():
                sg_issues = semgrep.run(path)
                all_issues.extend(sg_issues)
                engines_used.append("semgrep")
        except Exception as e:
            logger.warning(f"Semgrep scan failed: {e}")

    # Format output
    output = {
        "mode": mode,
        "engines": engines_used,
        "summary": {
            "files_scanned": result.files_scanned,
            "files_with_issues": result.files_with_issues,
            "total_issues": len(all_issues),
            "critical": sum(1 for i in all_issues if i.severity.value == "critical"),
            "high": sum(1 for i in all_issues if i.severity.value == "high"),
            "medium": sum(1 for i in all_issues if i.severity.value == "medium"),
            "low": sum(1 for i in all_issues if i.severity.value == "low"),
        },
        "issues": [_format_issue(i) for i in all_issues],
    }

    if result.parse_errors:
        output["parse_errors"] = result.parse_errors

    return json.dumps(output, indent=2)


@mcp.tool()
def scan_single_file(filepath: str) -> str:
    """Scan a single file for issues.

    Faster than full scan when you only need to check one file.
    Useful for real-time analysis as code is being written.

    Args:
        filepath: Path to the file to scan.
    """
    from qodacode.scanner import Scanner

    # Import rules
    import qodacode.rules.security  # noqa: F401
    import qodacode.rules.robustness  # noqa: F401
    import qodacode.rules.maintainability  # noqa: F401
    import qodacode.rules.operability  # noqa: F401
    import qodacode.rules.dependencies  # noqa: F401

    logger.info(f"Scanning file: {filepath}")

    scanner = Scanner()
    result = scanner.scan_file(filepath)

    output = {
        "file": filepath,
        "issues_found": len(result.issues),
        "issues": [_format_issue(i) for i in result.issues],
    }

    return json.dumps(output, indent=2)


@mcp.tool()
def check_secrets(path: str = ".", include_git_history: bool = False) -> str:
    """Scan for hardcoded secrets and credentials using Gitleaks.

    Uses the Gitleaks engine (auto-downloaded if needed) for industry-standard
    secret detection with 700+ patterns and entropy validation.

    Detects: AWS, GCP, Azure, Stripe, GitHub, GitLab, JWT, private keys,
    database credentials, and many more secret types.

    Args:
        path: File or directory to scan for secrets.
        include_git_history: If True, also scan git commit history for secrets
                            that may have been committed and later removed.
    """
    logger.info(f"Checking secrets in: {path}")

    try:
        from qodacode.engines.gitleaks_runner import GitleaksRunner

        gitleaks = GitleaksRunner(scan_git=include_git_history)

        if not gitleaks.is_available():
            return json.dumps({
                "status": "gitleaks_not_available",
                "message": "Gitleaks could not be downloaded or found.",
                "fallback": "You can install manually: brew install gitleaks (macOS)",
            })

        issues = gitleaks.run(path)

        # Format issues with rich output
        findings = []
        for issue in issues:
            finding = {
                "file": issue.location.filepath,
                "line": issue.location.line,
                "type": issue.rule_id,
                "severity": issue.severity.value,
                "message": issue.message,
                "fix_suggestion": issue.fix_suggestion,
            }
            # Add CWE reference for secrets
            finding["cwe_id"] = "CWE-798"
            finding["cwe_url"] = "https://cwe.mitre.org/data/definitions/798.html"

            # Add snippet (already redacted by GitleaksRunner)
            if issue.snippet:
                finding["snippet"] = issue.snippet

            # Add git context if available
            if issue.context:
                if issue.context.get("commit"):
                    finding["commit"] = issue.context["commit"]
                if issue.context.get("author"):
                    finding["author"] = issue.context["author"]
                if issue.context.get("date"):
                    finding["date"] = issue.context["date"]

            findings.append(finding)

        output = {
            "engine": "gitleaks",
            "total_secrets_found": len(findings),
            "secrets": findings,
            "recommendation": (
                "CRITICAL: Rotate all exposed secrets immediately. "
                "Remove from code and git history using git-filter-repo or BFG."
            ) if findings else "No secrets detected. Good job!",
        }

        return json.dumps(output, indent=2)

    except Exception as e:
        logger.error(f"Error in check_secrets: {e}")
        return json.dumps({
            "status": "error",
            "message": str(e),
        })


@mcp.tool()
def check_dependencies(path: str = ".") -> str:
    """Check dependencies for known vulnerabilities (CVEs).

    Queries the OSV (Open Source Vulnerabilities) database for real-time
    vulnerability information about your project dependencies.

    Supports: requirements.txt, package.json, Pipfile.lock, package-lock.json

    Args:
        path: Directory containing dependency files.
    """
    from qodacode.osv import (
        find_dependency_files,
        parse_dependency_file,
        query_osv_batch,
    )

    logger.info(f"Checking dependencies in: {path}")

    dep_files = find_dependency_files(path)

    if not dep_files:
        return json.dumps({
            "status": "no_dependency_files",
            "message": "No dependency files found (requirements.txt, package.json, etc.)",
        })

    all_vulnerabilities = []

    for dep_file in dep_files:
        ecosystem, packages = parse_dependency_file(dep_file)
        if not packages:
            continue

        vulns = query_osv_batch(packages, ecosystem)

        for pkg_name, pkg_vulns in vulns.items():
            for vuln in pkg_vulns:
                all_vulnerabilities.append({
                    "package": pkg_name,
                    "ecosystem": ecosystem,
                    "vulnerability_id": vuln.get("id", "unknown"),
                    "summary": vuln.get("summary", "No summary"),
                    "severity": vuln.get("severity", "unknown"),
                    "source_file": str(dep_file),
                })

    output = {
        "files_checked": [str(f) for f in dep_files],
        "total_vulnerabilities": len(all_vulnerabilities),
        "vulnerabilities": all_vulnerabilities,
        "recommendation": "Update vulnerable packages to patched versions."
        if all_vulnerabilities else "No known vulnerabilities found.",
    }

    return json.dumps(output, indent=2)


@mcp.tool()
def list_rules() -> str:
    """List all available analysis rules.

    Returns information about all rules Qodacode can check for,
    organized by category and severity.
    """
    from qodacode.rules.base import RuleRegistry

    # Import rules to register them
    import qodacode.rules.security  # noqa: F401
    import qodacode.rules.robustness  # noqa: F401
    import qodacode.rules.maintainability  # noqa: F401
    import qodacode.rules.operability  # noqa: F401
    import qodacode.rules.dependencies  # noqa: F401

    rules = RuleRegistry.get_all()

    rules_by_category = {}
    for rule in rules:
        cat = rule.category.value
        if cat not in rules_by_category:
            rules_by_category[cat] = []
        rules_by_category[cat].append({
            "id": rule.id,
            "name": rule.name,
            "severity": rule.severity.value,
            "description": rule.description,
            "languages": rule.languages,
        })

    output = {
        "total_rules": len(rules),
        "rules_by_category": rules_by_category,
    }

    return json.dumps(output, indent=2)


@mcp.tool()
def explain_issue(rule_id: str, context: Optional[str] = None) -> str:
    """Get detailed explanation for a specific rule or issue.

    Provides educational information about why an issue matters,
    how to fix it, and examples of correct code.

    Args:
        rule_id: The rule ID (e.g., SEC-001, ROB-002)
        context: Optional code context for more specific advice
    """
    from qodacode.rules.base import RuleRegistry

    # Import rules
    import qodacode.rules.security  # noqa: F401
    import qodacode.rules.robustness  # noqa: F401
    import qodacode.rules.maintainability  # noqa: F401
    import qodacode.rules.operability  # noqa: F401
    import qodacode.rules.dependencies  # noqa: F401

    rule = RuleRegistry.get_by_id(rule_id)

    if not rule:
        return json.dumps({
            "error": f"Rule '{rule_id}' not found",
            "available_rules": [r.id for r in RuleRegistry.get_all()],
        })

    explanation = {
        "rule_id": rule.id,
        "name": rule.name,
        "category": rule.category.value,
        "severity": rule.severity.value,
        "description": rule.description,
        "why_it_matters": _get_why_it_matters(rule.id),
        "how_to_fix": _get_how_to_fix(rule.id),
        "languages": rule.languages,
    }

    return json.dumps(explanation, indent=2)


def _get_why_it_matters(rule_id: str) -> str:
    """Get explanation of why a rule matters."""
    explanations = {
        "SEC-001": "Hardcoded secrets in source code can be exposed through version control, logs, or decompilation. Attackers who gain access to your repository or binaries can use these credentials to access your systems.",
        "SEC-002": "SQL injection allows attackers to execute arbitrary SQL commands, potentially reading, modifying, or deleting data, bypassing authentication, or even executing system commands.",
        "SEC-003": "Command injection allows attackers to execute arbitrary system commands, potentially taking complete control of your server.",
        "SEC-004": "Cross-site scripting (XSS) allows attackers to inject malicious scripts that run in users' browsers, stealing sessions, credentials, or personal data.",
        "SEC-005": "Endpoints without authentication can be accessed by anyone, potentially exposing sensitive data or functionality to unauthorized users.",
        "SEC-006": "Insecure deserialization can allow attackers to execute arbitrary code by crafting malicious serialized objects.",
        "SEC-007": "Path traversal allows attackers to access files outside the intended directory, potentially reading sensitive configuration files or source code.",
        "ROB-001": "Missing error handling causes applications to crash unexpectedly, leading to poor user experience and potential data loss.",
        "ROB-002": "Operations without timeouts can hang indefinitely, consuming resources and making your application unresponsive.",
        "ROB-003": "Unvalidated input can lead to crashes, security vulnerabilities, or incorrect behavior when unexpected data is received.",
        "ROB-004": "Without retry logic, transient failures in external services cause immediate failures instead of graceful recovery.",
        "ROB-005": "Without graceful degradation, a single failing dependency can bring down your entire application.",
        "MNT-001": "Long functions are harder to understand, test, and maintain. They often indicate that a function is doing too many things.",
        "MNT-002": "Functions with many parameters are hard to call correctly and often indicate poor abstraction.",
        "OPS-001": "Without logging, it's nearly impossible to debug production issues or understand application behavior.",
        "OPS-002": "Hardcoded configuration makes it difficult to change settings across environments and may expose sensitive values.",
        "DEP-001": "Vulnerable packages contain known security flaws that attackers can exploit to compromise your application.",
        "DEP-002": "Outdated dependencies may lack security patches and bug fixes, and can become incompatible with other packages.",
        "DEP-003": "Unused dependencies increase attack surface, slow down installation, and add maintenance burden.",
        "DEP-004": "Some licenses (GPL, AGPL) have requirements that may be incompatible with proprietary software.",
    }
    return explanations.get(rule_id, "This rule helps maintain code quality and security.")


def _get_how_to_fix(rule_id: str) -> str:
    """Get fix suggestions for a rule."""
    fixes = {
        "SEC-001": "Use environment variables or a secrets manager (AWS Secrets Manager, HashiCorp Vault, etc.) to store sensitive values. Never commit secrets to version control.",
        "SEC-002": "Use parameterized queries or ORM methods instead of string concatenation. Example: cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
        "SEC-003": "Avoid shell commands when possible. If necessary, use subprocess with shell=False and validate/sanitize all inputs. Never pass user input directly to system commands.",
        "SEC-004": "Always escape or sanitize user input before rendering in HTML. Use templating engines with auto-escaping enabled. Set Content-Security-Policy headers.",
        "SEC-005": "Add authentication middleware or decorators to protect sensitive endpoints. Use established auth libraries (OAuth, JWT) rather than rolling your own.",
        "SEC-006": "Avoid deserializing untrusted data. If necessary, use safe serialization formats (JSON) or validate data integrity with signatures before deserialization.",
        "SEC-007": "Validate and sanitize file paths. Use os.path.basename() to extract filenames. Resolve paths and verify they're within allowed directories.",
        "ROB-001": "Wrap risky operations in try/except blocks. Handle specific exceptions appropriately. Always have a fallback for unexpected errors.",
        "ROB-002": "Set explicit timeouts on all network operations, database queries, and external API calls. Use timeout parameters provided by libraries.",
        "ROB-003": "Validate all inputs at system boundaries. Check types, ranges, formats, and lengths. Reject or sanitize invalid input early.",
        "ROB-004": "Implement retry logic with exponential backoff for transient failures. Use libraries like tenacity (Python) or async-retry (Node.js).",
        "ROB-005": "Design systems with fallbacks: cached data, default values, or degraded functionality when dependencies fail.",
        "MNT-001": "Extract logical sections into separate functions. Aim for functions that do one thing well. Use descriptive names for extracted functions.",
        "MNT-002": "Group related parameters into objects or data classes. Consider using builder pattern or configuration objects for complex initialization.",
        "OPS-001": "Add structured logging at appropriate levels (debug, info, warning, error). Include context like request IDs, user IDs, and timestamps.",
        "OPS-002": "Move configuration to environment variables, config files, or a configuration service. Use different configs per environment.",
        "DEP-001": "Update to a patched version of the package. If no patch exists, consider alternatives or implement mitigations.",
        "DEP-002": "Regularly update dependencies. Use tools like dependabot or renovate for automated updates.",
        "DEP-003": "Remove unused dependencies from your package manifest. Use tools to detect unused imports and packages.",
        "DEP-004": "Review license compatibility with your project. Consider alternatives with more permissive licenses if needed.",
    }
    return fixes.get(rule_id, "Review the code and apply best practices for this type of issue.")


@mcp.tool()
def get_project_health(path: str = ".") -> str:
    """Get overall health assessment of a project.

    Provides a summary of code quality, security posture, and
    actionable recommendations prioritized by impact.

    Args:
        path: Project directory to analyze.
    """
    import json as json_module
    from qodacode.scanner import Scanner
    from qodacode.rules.base import Category, Severity

    # Import rules
    import qodacode.rules.security  # noqa: F401
    import qodacode.rules.robustness  # noqa: F401
    import qodacode.rules.maintainability  # noqa: F401
    import qodacode.rules.operability  # noqa: F401
    import qodacode.rules.dependencies  # noqa: F401

    logger.info(f"Analyzing project health: {path}")

    scanner = Scanner()
    result = scanner.scan(path=path)

    # Calculate health score (0-100)
    # Deduct points based on issues
    score = 100
    score -= result.critical_count * 15
    score -= result.high_count * 8
    score -= result.medium_count * 3
    score -= result.low_count * 1
    score = max(0, score)

    # Determine grade
    if score >= 90:
        grade = "A"
        status = "Excellent"
    elif score >= 80:
        grade = "B"
        status = "Good"
    elif score >= 70:
        grade = "C"
        status = "Needs Improvement"
    elif score >= 60:
        grade = "D"
        status = "Poor"
    else:
        grade = "F"
        status = "Critical"

    # Get top issues to fix
    critical_issues = [i for i in result.issues if i.severity == Severity.CRITICAL][:5]
    high_issues = [i for i in result.issues if i.severity == Severity.HIGH][:5]

    # Count by category
    by_category = result.by_category()

    output = {
        "health_score": score,
        "grade": grade,
        "status": status,
        "summary": {
            "files_analyzed": result.files_scanned,
            "total_issues": len(result.issues),
            "critical": result.critical_count,
            "high": result.high_count,
            "medium": result.medium_count,
            "low": result.low_count,
        },
        "by_category": {
            cat.value: len(issues)
            for cat, issues in by_category.items()
            if issues
        },
        "priority_fixes": [
            {
                "rule": i.rule_id,
                "file": i.filepath,
                "line": i.line,
                "message": i.message,
            }
            for i in (critical_issues + high_issues)
        ],
        "recommendations": _get_recommendations(result),
    }

    return json_module.dumps(output, indent=2)


def _get_recommendations(result) -> list:
    """Generate prioritized recommendations based on scan results."""
    recommendations = []

    if result.critical_count > 0:
        recommendations.append(
            "URGENT: Address critical security issues immediately. "
            "These could allow attackers to compromise your system."
        )

    by_category = result.by_category()
    from qodacode.rules.base import Category

    if len(by_category.get(Category.SECURITY, [])) > 3:
        recommendations.append(
            "Security: Multiple security issues detected. "
            "Consider a security audit and implementing security best practices."
        )

    if len(by_category.get(Category.ROBUSTNESS, [])) > 5:
        recommendations.append(
            "Reliability: Add error handling and timeouts to improve "
            "application stability and resilience."
        )

    if len(by_category.get(Category.DEPENDENCIES, [])) > 0:
        recommendations.append(
            "Dependencies: Update vulnerable packages and set up automated "
            "dependency updates (Dependabot, Renovate)."
        )

    if not recommendations:
        recommendations.append(
            "Good job! Continue maintaining code quality with regular scans."
        )

    return recommendations


# ============================================================================
# Memory & Context Tools
# ============================================================================

# Global indexer instance for memory features
_indexer_instance = None


def _get_indexer():
    """Get or create the global indexer instance."""
    global _indexer_instance
    if _indexer_instance is None:
        from qodacode.memory.indexer import Indexer
        _indexer_instance = Indexer()
    return _indexer_instance


@mcp.tool()
def index_project(path: str = ".") -> str:
    """Index a project to enable semantic code search and cross-file context.

    This tool uses Tree-sitter to extract code entities (functions, classes,
    methods, imports) and stores them in a vector database for semantic search.

    Run this once when starting work on a project, or after major changes.
    The index is stored in .qodacode/chroma/ for persistence.

    Args:
        path: Project directory to index. Defaults to current directory.

    Returns:
        Summary of indexed entities.
    """
    logger.info(f"Indexing project: {path}")

    try:
        indexer = _get_indexer()
        files_indexed, entities_found = indexer.index_directory(path)

        stats = indexer.get_stats()

        output = {
            "status": "success",
            "files_indexed": files_indexed,
            "total_entities": entities_found,
            "breakdown": {
                "functions": stats.get("functions", 0),
                "classes": stats.get("classes", 0),
                "methods": stats.get("methods", 0),
                "imports": stats.get("imports", 0),
            },
            "message": f"Indexed {entities_found} code entities from {files_indexed} files. "
                      "You can now use search_code_context to find similar code.",
        }

        return json.dumps(output, indent=2)

    except ImportError as e:
        return json.dumps({
            "status": "error",
            "error": f"Missing dependencies for indexing: {e}",
            "solution": "Install with: pip install chromadb sentence-transformers",
        })
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
        })


@mcp.tool()
def search_code_context(query: str, limit: int = 5) -> str:
    """Search for code entities semantically similar to a query.

    Uses vector embeddings to find functions, classes, and methods that
    match the intent of your query, not just keyword matching.

    Requires index_project to have been run first.

    Examples:
    - "function that handles user authentication"
    - "class for database connection"
    - "error handling for API calls"

    Args:
        query: Natural language description of what you're looking for.
        limit: Maximum number of results to return (default: 5).

    Returns:
        List of matching code entities with file locations.
    """
    logger.info(f"Searching code context: {query}")

    try:
        indexer = _get_indexer()

        # Check if index exists
        if indexer.store.count() == 0:
            return json.dumps({
                "status": "no_index",
                "message": "No index found. Run index_project first to enable semantic search.",
                "suggestion": "Use index_project tool to index the codebase.",
            })

        results = indexer.store.search(query, limit=limit)

        if not results:
            return json.dumps({
                "status": "no_results",
                "message": f"No code matching '{query}' found.",
                "suggestion": "Try different keywords or run index_project to refresh the index.",
            })

        output = {
            "status": "success",
            "query": query,
            "results_count": len(results),
            "results": [
                {
                    "name": r.metadata.get("name", "unknown"),
                    "type": r.metadata.get("type", "unknown"),
                    "file": r.metadata.get("filepath", "unknown"),
                    "line": r.metadata.get("start_line", 0),
                    "end_line": r.metadata.get("end_line", 0),
                    "relevance": round(1 - r.distance, 3),  # Convert distance to similarity
                    "preview": r.content[:200] + "..." if len(r.content) > 200 else r.content,
                }
                for r in results
            ],
        }

        return json.dumps(output, indent=2)

    except ImportError as e:
        return json.dumps({
            "status": "error",
            "error": f"Missing dependencies: {e}",
            "solution": "Install with: pip install chromadb sentence-transformers",
        })
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
        })


@mcp.tool()
def get_file_entities(filepath: str) -> str:
    """Get all code entities (functions, classes, methods) in a specific file.

    Useful for understanding the structure of a file before making changes.
    Shows all defined functions, classes, and their relationships.

    Args:
        filepath: Path to the file to analyze.

    Returns:
        List of entities with their signatures and line numbers.
    """
    logger.info(f"Getting entities in file: {filepath}")

    try:
        indexer = _get_indexer()

        # Index just this file if not already indexed
        entities = indexer.index_file(filepath)

        if not entities:
            return json.dumps({
                "status": "no_entities",
                "file": filepath,
                "message": "No functions, classes, or methods found in this file.",
                "note": "File might be empty, unsupported language, or only contain imports.",
            })

        output = {
            "status": "success",
            "file": filepath,
            "entity_count": len(entities),
            "entities": [
                {
                    "id": e.id,
                    "type": e.type.value,
                    "name": e.name,
                    "signature": e.signature,
                    "lines": f"{e.start_line}-{e.end_line}",
                    "docstring": e.docstring[:100] + "..." if len(e.docstring) > 100 else e.docstring,
                    "class": e.metadata.get("class") if e.metadata else None,
                }
                for e in entities
            ],
        }

        return json.dumps(output, indent=2)

    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
        })


@mcp.tool()
def find_similar_code(filepath: str, line: int, limit: int = 5) -> str:
    """Find code similar to a specific function or class.

    Given a file and line number, finds semantically similar code elsewhere
    in the codebase. Useful for:
    - Finding duplicate or near-duplicate code
    - Discovering patterns used elsewhere
    - Understanding how similar problems were solved

    Args:
        filepath: Path to the file containing the code.
        line: Line number within the function/class of interest.
        limit: Maximum similar results to return.

    Returns:
        List of similar code entities in other files.
    """
    logger.info(f"Finding similar code to {filepath}:{line}")

    try:
        indexer = _get_indexer()

        # Check if index exists
        if indexer.store.count() == 0:
            return json.dumps({
                "status": "no_index",
                "message": "No index found. Run index_project first.",
            })

        # Find the entity at this location
        entities = indexer.index_file(filepath)
        target_entity = None

        for entity in entities:
            if entity.start_line <= line <= entity.end_line:
                target_entity = entity
                break

        if not target_entity:
            return json.dumps({
                "status": "not_found",
                "message": f"No function or class found at line {line} in {filepath}",
                "available_entities": [
                    {"name": e.name, "lines": f"{e.start_line}-{e.end_line}"}
                    for e in entities
                ],
            })

        # Search for similar code using the entity's content as query
        search_query = f"{target_entity.name} {target_entity.signature} {target_entity.docstring}"
        results = indexer.store.search(search_query, limit=limit + 1)  # +1 to exclude self

        # Filter out the source entity itself
        similar = [
            r for r in results
            if r.metadata.get("filepath") != filepath or r.metadata.get("start_line") != target_entity.start_line
        ][:limit]

        if not similar:
            return json.dumps({
                "status": "no_similar",
                "source": {
                    "name": target_entity.name,
                    "type": target_entity.type.value,
                    "file": filepath,
                },
                "message": "No similar code found in the codebase.",
            })

        output = {
            "status": "success",
            "source": {
                "name": target_entity.name,
                "type": target_entity.type.value,
                "signature": target_entity.signature,
                "file": filepath,
                "lines": f"{target_entity.start_line}-{target_entity.end_line}",
            },
            "similar_code": [
                {
                    "name": r.metadata.get("name", "unknown"),
                    "type": r.metadata.get("type", "unknown"),
                    "file": r.metadata.get("filepath", "unknown"),
                    "line": r.metadata.get("start_line", 0),
                    "similarity": round(1 - r.distance, 3),
                    "preview": r.content[:150] + "..." if len(r.content) > 150 else r.content,
                }
                for r in similar
            ],
        }

        return json.dumps(output, indent=2)

    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
        })


@mcp.tool()
def get_memory_stats() -> str:
    """Get statistics about the indexed codebase.

    Shows how many files and entities are indexed, broken down by type.
    Useful to verify the index is up to date.

    Returns:
        Statistics about indexed code entities.
    """
    logger.info("Getting memory stats")

    try:
        indexer = _get_indexer()
        count = indexer.store.count()

        if count == 0:
            return json.dumps({
                "status": "empty",
                "message": "No code indexed yet. Run index_project to build the index.",
            })

        stats = indexer.get_stats()

        output = {
            "status": "success",
            "indexed_entities": count,
            "breakdown": stats,
            "storage_path": indexer.qodacode_path + "/chroma",
        }

        return json.dumps(output, indent=2)

    except Exception as e:
        return json.dumps({
            "status": "error",
            "error": str(e),
        })


def main():
    """Run the MCP server."""
    logger.info("Starting Qodacode MCP server...")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
