# Printer Logging

Libreria Python per **logging/stampa formattata** con prefissi coerenti, filtro di visibilità, log strutturati JSON opzionali e gestione session/remote id.

## Caratteristiche

- **Prefissi coerenti**: custom logs, session id, log_code
- **Filtro di visibilità**: controllo tramite `DebuggingMode` (NORMAL, VERBOSE, DEBUG)
- **Output flessibile**: stdout/stderr o `logging.Logger` integrato
- **Log strutturati JSON**: opzionali quando `use_structured_logging=True`
- **Gestione log_code**: risoluzione automatica con fallback e mapping configurabile

## Installazione

```bash
pip install printer-logging
```

## Quickstart

### Uso diretto (classe Printer)

```python
from printer import Printer, DebuggingMode, set_session_id

set_session_id("abc-123")

p = Printer(
    debugging_mode=DebuggingMode.DEBUG,
    name="MyApp",
    use_structured_logging=False,
)

p.info("Hello")                      # default: print
p.warning("Bad request", log_code=400)
p.error("Boom", log_code=500)
```

### Uso con API funzionale (singleton)

```python
import printer
from printer import DebuggingMode

printer.configure_printer(
    debugging_mode=DebuggingMode.DEBUG,
    name="MyApp",
    use_structured_logging=True,
    default_output_type="log",
)

printer.info("Hello", log_code=200, category="REQUEST_RECEIVED")
printer.warning("Bad request", log_code=400)
printer.error("Error occurred", log_code=500)
```

## DebuggingMode

Controlla la visibilità dei log:

- `NORMAL`: mostra solo `WARNING`/`ERROR`/`CRITICAL`
- `VERBOSE`: mostra `INFO+` (esclude `DEBUG`)
- `PRODUCTION`: equivalente a `VERBOSE`
- `DEBUG`: mostra tutto

## Log strutturati JSON

Quando `use_structured_logging=True` e `output_type="log"`, viene emesso anche un JSON per ogni evento con:

- `timestamp`, `level`, `logger`, `message`, `log_code`
- `custom_logs_prefix`, `session_id`
- `context` (`state/phase/category`) se presenti
- `exception` quando applicabile

## Session ID

Gestito via `contextvars`, funziona anche in async:

```python
from printer import set_session_id, get_session_id

set_session_id("abc-123")
assert get_session_id() == "abc-123"
```

## Requisiti

- Python >= 3.9

## Documentazione completa

Per dettagli completi, esempi avanzati e configurazione, consulta il [README completo](https://github.com/tuo-repo/printer) nel repository.
