"""API pubblica del package ``printer``.

Questo package fornisce:

- ``PrinterBase``: logging/stampa formattata con controllo visibilità via
  ``DebuggingMode``
- ``Printer``: estensione con supporto a log strutturati JSON (opzionali)
- gestione ``session_id`` tramite context variables
- risoluzione di ``log_code`` (fallback 200/400/500 + configurazione via JSON)
- API funzionale (facade) per usare un singleton condiviso

Note:
    I simboli vengono re-esportati per offrire un’API stabile.
"""

from .core.base import PrinterBase
from .core.printer import Printer
from .utils import DebuggingMode, set_session_id, get_session_id, LogCode, get_log_code
from .config import PrinterConfig, PropertiesPolicy
from .api import (
    get_printer,
    set_printer,
    is_configured,
    reset_printer,
    configure_printer,
    configure_printer_config,
    set_logger_name,
    set_debugging_mode,
    debug,
    info,
    warning,
    error,
    critical,
    success,
    header,
    section,
    custom,
    plain,
)

__all__ = [
    "PrinterBase",
    "Printer",
    "DebuggingMode",
    "set_session_id",
    "get_session_id",
    "LogCode",
    "get_log_code",
    "get_printer",
    "set_printer",
    "is_configured",
    "reset_printer",
    "configure_printer",
    "configure_printer_config",
    "set_logger_name",
    "set_debugging_mode",
    "debug",
    "info",
    "warning",
    "error",
    "critical",
    "success",
    "header",
    "section",
    "custom",
    "plain",
    "PrinterConfig",
    "PropertiesPolicy",
]

__version__ = "1.0.3"
