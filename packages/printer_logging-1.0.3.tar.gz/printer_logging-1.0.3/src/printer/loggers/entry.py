"""Utilità per costruire log strutturati (JSON).

Questo modulo costruisce un payload JSON con uno schema stabile e “pulito”,
separando:

- campi top-level (timestamp, level, logger, message, log_code, …)
- metadati semantici (context, exception, …) quando presenti
- properties applicative (solo chiavi non riservate), con policy opzionale di
  allowlist/redaction/transform

Nota:
    L’obiettivo è evitare JSON “rumorosi” e prevenire collisioni tra chiavi
    riservate (es. `log_code`, `stack_trace`) e proprietà applicative.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Callable, FrozenSet


@dataclass(frozen=True)
class PrefixInfo:
    """Informazioni di prefisso elevate a campi dedicati dell’entry JSON.

    Attributes:
        custom_logs (str | None): Prefisso custom logs normalizzato
            (es. `"[CUSTOM_LOGS]"`) oppure None.
        session_id (str | None): Session id del contesto corrente (se abilitato)
            oppure None.

    Note:
        Questi valori **non** vengono concatenati dentro `message`: vivono in
        campi strutturati per facilitare query/filtri nei sistemi di logging.
    """

    custom_logs: Optional[str]
    session_id: Optional[str]


@dataclass(frozen=True)
class PropertiesPolicy:
    """Policy di normalizzazione/protezione per le properties strutturate.

    La policy si applica **solo** alle proprietà “extra” (cioè non riservate),
    dopo lo split tra chiavi riservate e non riservate.

    Attributes:
        allowlist_keys (frozenset[str] | None): Se impostata, include solo queste
            chiavi (match case-insensitive).
        redact_keys (frozenset[str]): Chiavi da mascherare (match case-insensitive).
        redaction_value (str): Valore sostitutivo per le chiavi redatte.
        transformer (Callable[[dict[str, Any]], dict[str, Any]] | None): Funzione
            opzionale che riceve e ritorna un dict di properties (post-split).
            Se il transformer solleva eccezioni, vengono ignorate per non rompere
            il logging.
    """

    allowlist_keys: Optional[FrozenSet[str]] = None
    redact_keys: FrozenSet[str] = frozenset()
    redaction_value: str = "***"
    transformer: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None


RESERVED_PROPERTY_KEYS = {
    "output_type",
    "raw_message",
    "level_name",
    "emoji",
    # `status_code` è mantenuto come alias retro-compatibile (deprecato).
    "log_code",
    "status_code",
    "code_name",
    "state",
    "phase",
    "category",
    "stack_trace",
    "exception_type",
    "exception_message",
}


def utc_now_iso() -> str:
    """Ritorna il timestamp UTC in formato ISO-8601 con suffisso `Z`.

    Returns:
        str: Timestamp in ISO-8601 (UTC) con suffisso `Z`.
    """
    # Python recenti deprecano `datetime.utcnow()`; usiamo un datetime timezone-aware.
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def split_properties(properties: Dict[str, Any]) -> tuple[Dict[str, Any], Dict[str, Any]]:
    """Separa properties tra riservate (top-level) ed extra.

    Args:
        properties: Dizionario di properties in input.

    Returns:
        tuple[dict[str, Any], dict[str, Any]]: Tupla `(reserved, extra)` dove:
        - `reserved` contiene solo le chiavi in `RESERVED_PROPERTY_KEYS`
        - `extra` contiene tutte le altre chiavi
    """
    reserved: Dict[str, Any] = {}
    extra: Dict[str, Any] = {}
    for k, v in (properties or {}).items():
        if k in RESERVED_PROPERTY_KEYS:
            reserved[k] = v
        else:
            extra[k] = v
    return reserved, extra


def apply_properties_policy(
    extra: Dict[str, Any],
    policy: Optional[PropertiesPolicy],
) -> Dict[str, Any]:
    """Applica allowlist/redaction/transformer alle properties extra.

    Args:
        extra: Properties non riservate.
        policy: Policy opzionale.

    Returns:
        dict[str, Any]: Nuovo dict sanitizzato. Se `extra` è vuoto ritorna `{}`.

    Note:
        La policy è case-insensitive sulle chiavi e viene applicata nell’ordine:
        transformer → allowlist → redaction.
    """
    if not extra:
        return {}
    if policy is None:
        return extra

    current = dict(extra)

    if policy.transformer is not None:
        try:
            transformed = policy.transformer(dict(current))
            if isinstance(transformed, dict):
                current = transformed
        except Exception:
            pass

    allow = {k.lower() for k in policy.allowlist_keys} if policy.allowlist_keys else None
    redact = {k.lower() for k in policy.redact_keys} if policy.redact_keys else set()

    sanitized: Dict[str, Any] = {}
    for k, v in current.items():
        if not isinstance(k, str):
            continue
        kl = k.lower()
        if allow is not None and kl not in allow:
            continue
        if kl in redact:
            sanitized[k] = policy.redaction_value
        else:
            sanitized[k] = v

    return sanitized


def build_structured_log_entry(
    *,
    logger_name: str,
    level: str,
    message: str,
    emoji: str,
    log_code: int,
    prefix: PrefixInfo,
    properties: Dict[str, Any],
    properties_policy: Optional[PropertiesPolicy] = None,
) -> Dict[str, Any]:
    """Costruisce un’entry di log strutturata (JSON) con schema stabile.

    Args:
        logger_name: Nome del logger.
        level: Livello log normalizzato (es. `"INFO"`, `"ERROR"`).
        message: Messaggio “pulito” (senza prefissi).
        emoji: Emoji opzionale (campo separato, non concatenato in `message`).
        log_code: Codice numerico associato al log.
        prefix: Prefissi da elevare a campi strutturati (custom/session_id).
        properties: Dizionario di properties (riservate + extra).
        properties_policy: Policy opzionale applicata solo alle properties extra.

    Returns:
        dict[str, Any]: Dizionario serializzabile in JSON.

    Note:
        Le chiavi riservate (es. `log_code`, `state`, `stack_trace`) vengono
        estratte da `properties` ed elevate a campi top-level (o sottostrutture
        come `context`/`exception`). Le rimanenti finiscono in `properties`.
    """
    reserved, extra = split_properties(properties)
    extra = apply_properties_policy(extra, properties_policy)

    entry: Dict[str, Any] = {
        "timestamp": utc_now_iso(),
        "level": level,
        "logger": logger_name,
        "message": message,
        "log_code": int(log_code),
    }

    if emoji:
        entry["emoji"] = emoji

    if isinstance(reserved.get("code_name"), str) and reserved["code_name"]:
        entry["code_name"] = reserved["code_name"]

    if isinstance(prefix.custom_logs, str) and prefix.custom_logs:
        entry["custom_logs_prefix"] = prefix.custom_logs

    if isinstance(prefix.session_id, str) and prefix.session_id:
        entry["session_id"] = prefix.session_id

    context: Dict[str, Any] = {}
    for k in ("state", "phase", "category"):
        v = reserved.get(k)
        if v is not None:
            context[k] = v
    if context:
        entry["context"] = context

    exc: Dict[str, Any] = {}
    for k in ("exception_type", "exception_message", "stack_trace"):
        v = reserved.get(k)
        if v:
            exc[k] = v
    if exc:
        entry["exception"] = exc

    if extra:
        entry["properties"] = extra

    return entry


