"""Logger per log strutturati in formato JSON.

Questo modulo fornisce un wrapper minimale sopra ``logging.Logger`` che emette
una singola stringa JSON per ogni evento, usando lo schema prodotto da
``loggers.entry.build_structured_log_entry``.
"""

import json
import logging
from typing import Dict, Any, Optional, Callable, Union

from ..utils.session import get_session_id
from ..utils.log_codes import get_log_code
from .entry import PrefixInfo, PropertiesPolicy, build_structured_log_entry


class StructuredLogger:
    """Costruttore/emettitore di log strutturati (JSON).

    Responsabilità principali:
    - risoluzione del ``log_code`` (via resolver custom o fallback)
    - acquisizione del ``session_id`` dal contesto
    - costruzione dell’entry JSON “pulita”
    - emissione tramite ``logging.Logger.log(...)`` come stringa JSON

    Note:
        Il messaggio (``message``) è atteso “pulito”: prefissi e metadati vivono
        in campi dedicati dell’entry, non concatenati nella stringa.
    """

    def __init__(
        self,
        logger_name: str,
        log_code_resolver: Optional[
            Callable[
                [
                    str,
                    str,
                    Optional[int],
                    Optional[str],
                    Optional[str],
                    Optional[Dict[str, Any]],
                ],
                int,
            ]
        ] = None,
        custom_logs_prefix: Union[str, bool] = True,
        session_id_prefix: Union[str, bool] = True,
        properties_policy: Optional[PropertiesPolicy] = None,
    ):
        """Inizializza l’helper per logging strutturato.

        Args:
            logger_name: Nome del logger (campo `logger` nell’entry).
            log_code_resolver: Callable opzionale per risolvere il `log_code`.
                Se assente viene usato `utils.log_codes.get_log_code`.
            custom_logs_prefix: Policy prefisso custom (bool/str). Viene
                normalizzata con la stessa logica di `PrinterBase`.
            session_id_prefix: Policy per includere il session id (bool/str).
                Viene normalizzata con la stessa logica di `PrinterBase`.
            properties_policy: Policy per filtrare/mascherare/trasformare le
                properties extra (solo structured logging).
        """
        self.logger_name = logger_name
        self.log_code_resolver = log_code_resolver
        from ..core.base import (
            PrinterBase,
        )  # import locale per evitare cicli a import-time

        self.custom_logs_prefix = PrinterBase._normalize_custom_logs_prefix(
            custom_logs_prefix
        )
        self.session_id_prefix = PrinterBase._normalize_session_id_prefix(
            session_id_prefix
        )
        self.properties_policy = properties_policy

    def log(
        self,
        level: str,
        emoji: str,
        message: str,
        log_level: int,
        logger: logging.Logger,
        **properties: Any,
    ) -> None:
        """Emette un log strutturato come JSON.

        Args:
            level: Livello log come stringa (es. `"INFO"`, `"ERROR"`).
            emoji: Emoji opzionale; viene salvata in un campo dedicato.
            message: Messaggio di log “pulito”.
            log_level: Livello numerico (`logging.INFO`, `logging.ERROR`, …).
            logger: Logger Python da utilizzare per l’emissione.
            **properties: Metadati aggiuntivi da includere nell’entry. Le chiavi
                riservate vengono elevate a top-level; il resto finisce in
                `properties` (eventualmente filtrate dalla policy).
        """
        session_id = get_session_id()

        message_for_code = message

        log_code = properties.get("log_code")
        if not isinstance(log_code, int) or not (100 <= log_code <= 999):
            # Alias retro-compatibile (deprecato)
            log_code = properties.get("status_code")
        phase = properties.get("phase")
        state = properties.get("state")
        if self.log_code_resolver is not None:
            log_code = self.log_code_resolver(
                level, message_for_code, log_code, phase, state, properties
            )
        else:
            log_code = get_log_code(
                level, message_for_code, log_code, phase, state, properties
            )

        prefix = PrefixInfo(
            custom_logs=self.custom_logs_prefix
            if isinstance(self.custom_logs_prefix, str)
            else None,
            session_id=session_id if (session_id and self.session_id_prefix) else None,
        )

        log_entry: Dict[str, Any] = build_structured_log_entry(
            logger_name=self.logger_name,
            level=level,
            message=message_for_code,
            emoji=emoji or "",
            log_code=int(log_code),
            prefix=prefix,
            properties=dict(properties) if properties else {},
            properties_policy=self.properties_policy,
        )

        logger.log(log_level, json.dumps(log_entry))
