"""Componenti per logging strutturato (JSON)."""

from .structured import StructuredLogger

__all__ = ["StructuredLogger"]

