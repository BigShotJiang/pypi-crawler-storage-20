"""API funzionale (facade) sopra ``Printer``.

Questo modulo espone funzioni “comode” (es. `printer.info(...)`) che inoltrano
le chiamate a una singola istanza condivisa di `Printer`.

Il singleton **non** viene auto-configurato: va creato esplicitamente con
`configure_printer(...)` oppure impostato con `set_printer(...)`.
"""

from __future__ import annotations

from typing import Any, Optional, Literal

from .core.printer import Printer
from .config import PrinterConfig
from .loggers.entry import PropertiesPolicy
from .utils.enums import DebuggingMode
from .utils.log_codes import load_log_code_config_json, make_log_code_resolver

_default_printer: Optional[Printer] = None


def get_printer() -> Printer:
    """Ritorna l’istanza singleton di ``Printer``.

    Returns:
        Printer: L’istanza condivisa.

    Raises:
        RuntimeError: Se il singleton non è stato configurato.
    """
    global _default_printer
    if _default_printer is None:
        raise RuntimeError(
            "Printer non configurato. Chiama `printer.configure_printer(...)` "
            "oppure `printer.set_printer(Printer(...))` prima di usare `printer.info(...)`."
        )
    return _default_printer


def set_printer(printer: Printer) -> None:
    """Imposta/sostituisce il singleton usato dall’API funzionale.

    Args:
        printer: Istanza da usare come target per tutte le funzioni facade.
    """
    global _default_printer
    _default_printer = printer


def is_configured() -> bool:
    """Ritorna True se il singleton è configurato.

    Returns:
        bool
    """
    return _default_printer is not None


def reset_printer() -> None:
    """Reset del singleton (tipicamente utile nei test).

    Returns:
        None
    """
    global _default_printer
    _default_printer = None


def configure_printer(
    debugging_mode: DebuggingMode,
    custom_logs_prefix: str | bool,
    session_id_prefix: str | bool,
    name: str = "Printer",
    use_structured_logging: bool = False,
    log_codes_path: Optional[str] = None,
    stacktrace_mode: Literal["exception_only", "off"] = "exception_only",
    default_output_type: Literal["print", "log"] = "print",
    structured_properties_policy: Optional[PropertiesPolicy] = None,
) -> Printer:
    """Crea/(ri)configura il singleton e lo ritorna.

    Args:
        debugging_mode: Modalità di visibilità dei log.
        custom_logs_prefix: Gestione prefisso “custom logs” (bool/str).
        session_id_prefix: Gestione prefisso session id (bool/str).
        name: Nome del logger.
        use_structured_logging: Se True abilita emissione JSON structured quando
            `output_type="log"`.
        log_codes_path: Path opzionale a JSON di configurazione per log_code e
            metadati (emoji/nome per codice).
        stacktrace_mode: Policy per aggiungere stack trace automaticamente.
        default_output_type: Output predefinito per i metodi (`"print"` o `"log"`).
        structured_properties_policy: Policy per filtrare/mascherare/trasformare
            le properties extra nei log strutturati.

    Returns:
        Printer: L’istanza `Printer` configurata (singleton).

    Raises:
        ValueError: Se `stacktrace_mode` o `default_output_type` non sono validi.
    """
    global _default_printer
    if stacktrace_mode not in ("exception_only", "off"):
        raise ValueError("stacktrace_mode non valido. Valori ammessi: 'exception_only', 'off'.")
    if default_output_type not in ("print", "log"):
        raise ValueError("default_output_type non valido. Valori ammessi: 'print', 'log'.")

    log_code_resolver = None
    emoji_by_code = None
    name_by_code = None
    if log_codes_path:
        cfg = load_log_code_config_json(log_codes_path)
        log_code_resolver = make_log_code_resolver(cfg)
        emoji_by_code = cfg.emoji_by_code or None
        name_by_code = cfg.name_by_code or None
    _default_printer = Printer(
        debugging_mode=debugging_mode,
        name=name,
        use_structured_logging=use_structured_logging,
        log_code_resolver=log_code_resolver,
        emoji_by_code=emoji_by_code,
        name_by_code=name_by_code,
        custom_logs_prefix=custom_logs_prefix,
        session_id_prefix=session_id_prefix,
        stacktrace_mode=stacktrace_mode,
        default_output_type=default_output_type,
        structured_properties_policy=structured_properties_policy,
    )
    return _default_printer


def configure_printer_config(config: PrinterConfig) -> Printer:
    """Configura il singleton a partire da una ``PrinterConfig``.

    Args:
        config: Oggetto di configurazione.

    Returns:
        Printer: Istanza configurata (singleton).
    """
    return configure_printer(
        debugging_mode=config.debugging_mode,
        custom_logs_prefix=config.custom_logs_prefix,
        session_id_prefix=config.session_id_prefix,
        name=config.name,
        use_structured_logging=config.use_structured_logging,
        log_codes_path=config.log_codes_path,
        stacktrace_mode=config.stacktrace_mode,
        default_output_type=config.default_output_type,
        structured_properties_policy=config.structured_properties_policy,
    )


def set_logger_name(name: str) -> None:
    """Imposta il nome del logger del singleton.

    Args:
        name: Nome del logger.
    """
    get_printer().set_logger_name(name)


def set_debugging_mode(debugging_mode: DebuggingMode) -> None:
    """Imposta la modalità di debugging del singleton.

    Args:
        debugging_mode: Modalità di debug.
    """
    get_printer().set_debugging_mode(debugging_mode)


def debug(
    message: str,
    output_type: Any = None,
    log_code: Optional[int] = None,
    state: Optional[str] = None,
    force: bool = False,
    use_emoji: bool = True,
    *,
    # Alias retro-compatibile (deprecato). Preferire `log_code`.
    status_code: Optional[int] = None,
    **properties: Any,
) -> None:
    """Logga un messaggio di livello DEBUG tramite il singleton.

    Args:
        message: Messaggio.
        output_type: Output ("print" | "log") o None per default.
        log_code: Codice log (opzionale).
        state: Stato (opzionale).
        force: Se True bypassa il filtro.
        use_emoji: Se True abilita emoji (se configurata per code).
        **properties: Metadati aggiuntivi.
    """
    if log_code is None and status_code is not None:
        log_code = status_code
    get_printer().debug(
        message,
        output_type=output_type,
        log_code=log_code,
        state=state,
        force=force,
        use_emoji=use_emoji,
        **properties,
    )


def info(
    message: str,
    output_type: Any = None,
    log_code: Optional[int] = None,
    state: Optional[str] = None,
    force: bool = False,
    use_emoji: bool = True,
    *,
    # Alias retro-compatibile (deprecato). Preferire `log_code`.
    status_code: Optional[int] = None,
    **properties: Any,
) -> None:
    """Logga un messaggio di livello INFO tramite il singleton.

    Args:
        message: Messaggio.
        output_type: Output ("print" | "log") o None per default.
        log_code: Codice log (opzionale).
        state: Stato (opzionale).
        force: Se True bypassa il filtro.
        use_emoji: Se True abilita emoji (se configurata per code).
        **properties: Metadati aggiuntivi.
    """
    if log_code is None and status_code is not None:
        log_code = status_code
    get_printer().info(
        message,
        output_type=output_type,
        log_code=log_code,
        state=state,
        force=force,
        use_emoji=use_emoji,
        **properties,
    )


def warning(
    message: str,
    output_type: Any = None,
    log_code: Optional[int] = None,
    state: Optional[str] = None,
    force: bool = False,
    use_emoji: bool = True,
    *,
    # Alias retro-compatibile (deprecato). Preferire `log_code`.
    status_code: Optional[int] = None,
    **properties: Any,
) -> None:
    """Logga un messaggio di livello WARNING tramite il singleton.

    Args:
        message: Messaggio.
        output_type: Output ("print" | "log") o None per default.
        log_code: Codice log (opzionale).
        state: Stato (opzionale).
        force: Se True bypassa il filtro.
        use_emoji: Se True abilita emoji (se configurata per code).
        **properties: Metadati aggiuntivi.
    """
    if log_code is None and status_code is not None:
        log_code = status_code
    get_printer().warning(
        message,
        output_type=output_type,
        log_code=log_code,
        state=state,
        force=force,
        use_emoji=use_emoji,
        **properties,
    )


def error(
    message: str,
    output_type: Any = None,
    log_code: Optional[int] = None,
    state: Optional[str] = None,
    force: bool = False,
    use_emoji: bool = True,
    *,
    # Alias retro-compatibile (deprecato). Preferire `log_code`.
    status_code: Optional[int] = None,
    **properties: Any,
) -> None:
    """Logga un messaggio di livello ERROR tramite il singleton.

    Args:
        message: Messaggio.
        output_type: Output ("print" | "log") o None per default.
        log_code: Codice log (opzionale).
        state: Stato (opzionale).
        force: Se True bypassa il filtro.
        use_emoji: Se True abilita emoji (se configurata per code).
        **properties: Metadati aggiuntivi.
    """
    if log_code is None and status_code is not None:
        log_code = status_code
    get_printer().error(
        message,
        output_type=output_type,
        log_code=log_code,
        state=state,
        force=force,
        use_emoji=use_emoji,
        **properties,
    )


def critical(
    message: str,
    output_type: Any = None,
    log_code: Optional[int] = None,
    state: Optional[str] = None,
    force: bool = False,
    use_emoji: bool = True,
    *,
    # Alias retro-compatibile (deprecato). Preferire `log_code`.
    status_code: Optional[int] = None,
    **properties: Any,
) -> None:
    """Logga un messaggio di livello CRITICAL tramite il singleton.

    Args:
        message: Messaggio.
        output_type: Output ("print" | "log") o None per default.
        log_code: Codice log (opzionale).
        state: Stato (opzionale).
        force: Se True bypassa il filtro.
        use_emoji: Se True abilita emoji (se configurata per code).
        **properties: Metadati aggiuntivi.
    """
    if log_code is None and status_code is not None:
        log_code = status_code
    get_printer().critical(
        message,
        output_type=output_type,
        log_code=log_code,
        state=state,
        force=force,
        use_emoji=use_emoji,
        **properties,
    )


def success(
    message: str,
    output_type: Any = None,
    log_code: Optional[int] = None,
    state: Optional[str] = None,
    force: bool = False,
    use_emoji: bool = True,
    *,
    # Alias retro-compatibile (deprecato). Preferire `log_code`.
    status_code: Optional[int] = None,
    **properties: Any,
) -> None:
    """Logga un messaggio di livello SUCCESS tramite il singleton.

    Args:
        message: Messaggio.
        output_type: Output ("print" | "log") o None per default.
        log_code: Codice log (opzionale).
        state: Stato (opzionale).
        force: Se True bypassa il filtro.
        use_emoji: Se True abilita emoji (se configurata per code).
        **properties: Metadati aggiuntivi.
    """
    if log_code is None and status_code is not None:
        log_code = status_code
    get_printer().success(
        message,
        output_type=output_type,
        log_code=log_code,
        state=state,
        force=force,
        use_emoji=use_emoji,
        **properties,
    )


def header(
    message: str,
    char: str = "=",
    length: int = 80,
    force: bool = False,
    **properties: Any,
) -> None:
    """Stampa/logga un’intestazione (header) tramite il singleton.

    Args:
        message: Messaggio.
        char: Carattere da usare per le linee.
        length: Lunghezza linee.
        force: Se True bypassa il filtro.
        **properties: Metadati aggiuntivi.
    """
    get_printer().header(message, char=char, length=length, force=force, **properties)


def section(title: str, content: str, force: bool = False) -> None:
    """Stampa/logga una sezione con titolo e contenuto tramite il singleton.

    Args:
        title: Titolo della sezione.
        content: Contenuto.
        force: Se True bypassa il filtro.
    """
    get_printer().section(title, content, force=force)


def custom(message: str, prefix: str = "➡️", force: bool = False) -> None:
    """Stampa/logga un messaggio custom con un prefisso tramite il singleton.

    Args:
        message: Messaggio.
        prefix: Prefisso da anteporre.
        force: Se True bypassa il filtro.
    """
    get_printer().custom(message, prefix=prefix, force=force)


def plain(message: str, force: bool = False) -> None:
    """Stampa/logga un messaggio senza formattazione tramite il singleton.

    Args:
        message: Messaggio.
        force: Se True bypassa il filtro.
    """
    get_printer().plain(message, force=force)


__all__ = [
    "get_printer",
    "set_printer",
    "configure_printer",
    "set_logger_name",
    "set_debugging_mode",
    "debug",
    "info",
    "warning",
    "error",
    "critical",
    "success",
    "header",
    "section",
    "custom",
    "plain",
]
