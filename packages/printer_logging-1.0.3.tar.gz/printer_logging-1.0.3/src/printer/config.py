"""Modelli di configurazione per la libreria `printer`.

Questo modulo fornisce una dataclass (`PrinterConfig`) per raccogliere in modo
tipizzato i parametri necessari a costruire/configurare un `Printer`, evitando
firme troppo lunghe e mantenendo l’approccio di **config esplicita** (nessun
auto-loading da variabili d’ambiente).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Literal

from .utils.enums import DebuggingMode
from .loggers.entry import PropertiesPolicy


@dataclass(frozen=True)
class PrinterConfig:
    """Configurazione completa per inizializzare/configurare un ``Printer``.

    I campi senza default sono intenzionalmente “obbligatori”, per rendere
    esplicite le scelte di configurazione.

    Note:
        I campi senza default sono intenzionalmente “obbligatori”, per rendere
        esplicite le scelte di configurazione.

    Attributes:
        debugging_mode (DebuggingMode): Modalità di visibilità dei log.
        custom_logs_prefix (str | bool): Policy prefisso “custom logs”.
        session_id_prefix (str | bool): Policy per includere il session id.
        name (str): Nome del logger.
        use_structured_logging (bool): Se True abilita emissione JSON structured
            quando `output_type="log"`.
        log_codes_path (str | None): Path opzionale a JSON per configurare log_code
            e metadati associati.
        stacktrace_mode (Literal["exception_only", "off"]): Policy per aggiungere
            stack trace automaticamente.
        default_output_type (Literal["print", "log"]): Output predefinito.
        structured_properties_policy (PropertiesPolicy | None): Policy per
            filtrare/mascherare/trasformare le properties extra nei log strutturati.
    """

    debugging_mode: DebuggingMode
    custom_logs_prefix: str | bool
    session_id_prefix: str | bool

    name: str = "Printer"
    use_structured_logging: bool = False
    log_codes_path: Optional[str] = None
    stacktrace_mode: Literal["exception_only", "off"] = "exception_only"
    default_output_type: Literal["print", "log"] = "print"
    structured_properties_policy: Optional[PropertiesPolicy] = None


__all__ = ["PrinterConfig", "PropertiesPolicy"]


