"""Enum e costanti per la configurazione del package.

In particolare, `DebuggingMode` definisce profili di visibilità dei log usati da
`PrinterBase`/`Printer`.
"""

import logging
from enum import Enum


class DebuggingMode(Enum):
    """Modalità di debugging per controllare la visibilità dei log.

    Notes
    -----
    Profili:
    - NORMAL: mostra solo WARNING, ERROR, CRITICAL
    - VERBOSE: mostra INFO, WARNING, ERROR, CRITICAL (esclude DEBUG)
    - PRODUCTION: mostra INFO, WARNING, ERROR, CRITICAL, SUCCESS (esclude DEBUG)
    - DEBUG: mostra tutti i log inclusi DEBUG
    """

    NORMAL = logging.WARNING
    VERBOSE = logging.INFO
    PRODUCTION = logging.INFO
    DEBUG = logging.DEBUG

