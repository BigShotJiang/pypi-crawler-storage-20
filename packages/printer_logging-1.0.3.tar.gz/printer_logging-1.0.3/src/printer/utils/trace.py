"""Utilità per l'estrazione e il filtraggio dello stack trace.

Questo modulo fornisce funzioni per estrarre stack trace filtrati,
escludendo frame non rilevanti (es. site-packages, worker.py, ecc.).
"""

import traceback
from typing import Optional


def get_filtered_stack_trace(project_name: str, limit: int = 5) -> str:
    """Estrae uno stack trace filtrato, escludendo frame non rilevanti.

    Filtra i frame dello stack trace per escludere:
    - frame da `site-packages` (librerie esterne)
    - frame da `worker.py` (comune in ambienti serverless)
    - frame interni del modulo `printer` stesso (se non in modalità debug)

    Args:
        project_name: Nome del progetto (usato per filtrare frame rilevanti).
        limit: Numero massimo di frame da includere (default: 5).

    Returns:
        Stringa formattata dello stack trace filtrato.
    """
    stack = traceback.extract_stack()

    # Filtra i frame escludendo quelli non rilevanti
    filtered_frames = []
    for frame in stack[:-1]:  # Escludi l'ultimo frame (questa funzione stessa)
        filename = frame.filename

        # Escludi frame da site-packages
        if "site-packages" in filename:
            continue

        # Escludi frame da worker.py (comune in Azure Functions, AWS Lambda, ecc.)
        if "worker.py" in filename:
            continue

        # Escludi frame interni del modulo printer (opzionale, per pulizia)
        # Mantieni solo se il project_name è nel path
        if project_name and project_name != "unknown_project":
            if project_name.lower() not in filename.lower():
                # Se il project_name è specificato e non è nel path,
                # includi comunque frame che non sono da printer stesso
                if "printer" in filename.lower() and "printer/core" in filename.lower():
                    continue

        filtered_frames.append(frame)

    # Limita il numero di frame
    if limit > 0:
        filtered_frames = filtered_frames[-limit:]

    # Formatta lo stack trace
    if not filtered_frames:
        return ""

    lines = []
    for frame in filtered_frames:
        lines.append(f'  File "{frame.filename}", line {frame.lineno}, in {frame.name}')
        if frame.line:
            lines.append(f"    {frame.line.strip()}")

    return "\n".join(lines)
