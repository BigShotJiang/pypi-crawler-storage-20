"""Gestione del `session_id` tramite `contextvars`.

Il `session_id` è mantenuto in una `ContextVar`, quindi è “locale al contesto”
(thread/task) e adatto anche ad ambienti async.
"""

from contextvars import ContextVar
from typing import Optional

session_id_var: ContextVar[Optional[str]] = ContextVar("session_id", default=None)


def set_session_id(session_id: str) -> None:
    """Imposta il `session_id` per il contesto corrente.

    Args:
        session_id: Identificatore della sessione.
    """
    session_id_var.set(session_id)


def get_session_id() -> Optional[str]:
    """Ritorna il `session_id` del contesto corrente.

    Returns:
        str | None: Il `session_id` corrente oppure None se non impostato.
    """
    return session_id_var.get()
