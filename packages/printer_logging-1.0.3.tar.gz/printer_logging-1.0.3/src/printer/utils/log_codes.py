"""Risoluzione dei codici di log (`log_code`) in modo generico e configurabile.

Obiettivi:
- evitare pattern hardcoded sul testo del messaggio (fragili e domain-specific)
- fornire un fallback standard (200/400/500) in base al livello
- permettere mapping custom (state/phase/category) e metadati (emoji/nome) via JSON
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional

logger = logging.getLogger(__name__)


class LogCode:
    """Codici standard minimi (fallback).

    I progetti possono definire codici più specifici via JSON e/o tramite un
    resolver custom.
    """

    OK = 200
    CLIENT_ERROR = 400
    SERVER_ERROR = 500


DEFAULT_BY_LEVEL: Dict[str, int] = {
    "DEBUG": LogCode.OK,
    "INFO": LogCode.OK,
    "SUCCESS": LogCode.OK,
    "WARNING": LogCode.CLIENT_ERROR,
    "ERROR": LogCode.SERVER_ERROR,
    "CRITICAL": LogCode.SERVER_ERROR,
}


def _normalize_level(level: str) -> str:
    return (level or "INFO").upper()


def _is_valid_code(code: Any) -> bool:
    return isinstance(code, int) and 100 <= code <= 999


def _normalize_key(key: str) -> str:
    return (key or "").strip().lower()


@dataclass(frozen=True)
class LogCodeConfig:
    """Configurazione per la risoluzione del `log_code`.

    Attributi:
        default_by_level: Mapping livello -> codice (fallback).
        state_codes: Mapping state -> codice.
        phase_codes: Mapping phase -> codice.
        category_codes: Mapping category -> codice.
        emoji_by_code: Mapping codice -> emoji (opzionale).
        name_by_code: Mapping codice -> nome (opzionale).
    """

    default_by_level: Dict[str, int] = field(default_factory=lambda: dict(DEFAULT_BY_LEVEL))
    state_codes: Dict[str, int] = field(default_factory=dict)
    phase_codes: Dict[str, int] = field(default_factory=dict)
    category_codes: Dict[str, int] = field(default_factory=dict)
    emoji_by_code: Dict[int, str] = field(default_factory=dict)
    name_by_code: Dict[int, str] = field(default_factory=dict)


LogCodeResolver = Callable[
    [str, str, Optional[int], Optional[str], Optional[str], Optional[Dict[str, Any]]],
    int,
]


def log_code_config_from_dict(data: Mapping[str, Any]) -> LogCodeConfig:
    """Costruisce una `LogCodeConfig` da un dizionario (tipicamente da JSON).

    Args:
        data: Dati già deserializzati (tipicamente da JSON).

    Schema supportato (tutti i campi sono opzionali):
    - `default_by_level`: `{ "INFO": 200, "WARNING": 400, ... }`
    - `state_codes` / alias `states`: `{ "search": 104, ... }`
    - `phase_codes` / alias `phases`: `{ "init": 100, ... }`
    - `category_codes` / alias `categories`: `{ "REQUEST_RECEIVED": 100, ... }`

    Metadati per codice (opzionali):
    - `emoji_by_code` (alias: `code_emojis`, `emojis_by_code`): `{ "200": "🟦", 500: "🟥" }`
    - `name_by_code` (alias: `code_names`, `names_by_code`): `{ "200": "OK", 500: "SERVER_ERROR" }`
    - `codes` (alias: `code_definitions`): forma “ricca” per definire name/emoji:
      `{ "200": {"name": "OK", "emoji": "🟦"}, "500": {"name": "SERVER_ERROR", "emoji": "🟥"} }`

    Returns:
        LogCodeConfig
    """
    default_by_level_raw = data.get("default_by_level") or {}
    if not isinstance(default_by_level_raw, dict):
        default_by_level_raw = {}

    default_by_level: Dict[str, int] = dict(DEFAULT_BY_LEVEL)
    for k, v in default_by_level_raw.items():
        if not isinstance(k, str):
            logger.warning(
                f"Log code config: chiave non valida in 'default_by_level': "
                f"atteso str, trovato {type(k).__name__} (valore: {repr(k)})"
            )
            continue
        if not _is_valid_code(v):
            logger.warning(
                f"Log code config: valore non valido in 'default_by_level' per chiave '{k}': "
                f"atteso intero tra 100-999, trovato {type(v).__name__} (valore: {repr(v)})"
            )
            continue
        default_by_level[_normalize_level(k)] = v

    def _read_code_map(*keys: str) -> Dict[str, int]:
        raw = None
        key_used = None
        for key in keys:
            raw = data.get(key)
            if raw is not None:
                key_used = key
                break
        if raw is None:
            return {}
        if not isinstance(raw, dict):
            logger.warning(
                f"Log code config: '{key_used}' deve essere un dizionario, "
                f"trovato {type(raw).__name__}"
            )
            return {}
        out: Dict[str, int] = {}
        for k, v in raw.items():
            if not isinstance(k, str):
                logger.warning(
                    f"Log code config: chiave non valida in '{key_used}': "
                    f"atteso str, trovato {type(k).__name__} (valore: {repr(k)})"
                )
                continue
            if not _is_valid_code(v):
                logger.warning(
                    f"Log code config: valore non valido in '{key_used}' per chiave '{k}': "
                    f"atteso intero tra 100-999, trovato {type(v).__name__} (valore: {repr(v)})"
                )
                continue
            out[_normalize_key(k)] = v
        return out

    state_codes = _read_code_map("state_codes", "states")
    phase_codes = _read_code_map("phase_codes", "phases")
    category_codes = _read_code_map("category_codes", "categories")

    codes_raw = data.get("codes") or data.get("code_definitions") or {}

    emoji_raw = data.get("emoji_by_code") or data.get("code_emojis") or data.get("emojis_by_code") or {}
    emoji_by_code: Dict[int, str] = {}
    if not isinstance(emoji_raw, dict):
        if emoji_raw:  # Solo se non è None/empty
            logger.warning(
                f"Log code config: 'emoji_by_code' (o alias) deve essere un dizionario, "
                f"trovato {type(emoji_raw).__name__}"
            )
    else:
        for k, v in emoji_raw.items():
            try:
                code = int(k) if not isinstance(k, int) else k
            except (ValueError, TypeError) as e:
                logger.warning(
                    f"Log code config: non è possibile convertire la chiave '{k}' in intero "
                    f"per 'emoji_by_code': {e}"
                )
                continue
            if not _is_valid_code(code):
                logger.warning(
                    f"Log code config: codice non valido in 'emoji_by_code' per chiave '{k}': "
                    f"atteso intero tra 100-999, trovato {code}"
                )
                continue
            if not isinstance(v, str):
                logger.warning(
                    f"Log code config: valore non valido in 'emoji_by_code' per codice {code}: "
                    f"atteso str, trovato {type(v).__name__} (valore: {repr(v)})"
                )
                continue
            emoji_by_code[int(code)] = v

    name_raw = data.get("name_by_code") or data.get("code_names") or data.get("names_by_code") or {}
    name_by_code: Dict[int, str] = {}
    if not isinstance(name_raw, dict):
        if name_raw:  # Solo se non è None/empty
            logger.warning(
                f"Log code config: 'name_by_code' (o alias) deve essere un dizionario, "
                f"trovato {type(name_raw).__name__}"
            )
    else:
        for k, v in name_raw.items():
            try:
                code = int(k) if not isinstance(k, int) else k
            except (ValueError, TypeError) as e:
                logger.warning(
                    f"Log code config: non è possibile convertire la chiave '{k}' in intero "
                    f"per 'name_by_code': {e}"
                )
                continue
            if not _is_valid_code(code):
                logger.warning(
                    f"Log code config: codice non valido in 'name_by_code' per chiave '{k}': "
                    f"atteso intero tra 100-999, trovato {code}"
                )
                continue
            if not isinstance(v, str):
                logger.warning(
                    f"Log code config: valore non valido in 'name_by_code' per codice {code}: "
                    f"atteso str, trovato {type(v).__name__} (valore: {repr(v)})"
                )
                continue
            if not v.strip():
                logger.warning(
                    f"Log code config: valore vuoto in 'name_by_code' per codice {code}"
                )
                continue
            name_by_code[int(code)] = v.strip()

    if not isinstance(codes_raw, dict):
        if codes_raw:  # Solo se non è None/empty
            logger.warning(
                f"Log code config: 'codes' (o alias 'code_definitions') deve essere un dizionario, "
                f"trovato {type(codes_raw).__name__}"
            )
    else:
        for k, meta in codes_raw.items():
            try:
                code = int(k) if not isinstance(k, int) else k
            except (ValueError, TypeError) as e:
                logger.warning(
                    f"Log code config: non è possibile convertire la chiave '{k}' in intero "
                    f"per 'codes': {e}"
                )
                continue
            if not _is_valid_code(code):
                logger.warning(
                    f"Log code config: codice non valido in 'codes' per chiave '{k}': "
                    f"atteso intero tra 100-999, trovato {code}"
                )
                continue
            if not isinstance(meta, dict):
                logger.warning(
                    f"Log code config: valore non valido in 'codes' per codice {code}: "
                    f"atteso dict, trovato {type(meta).__name__} (valore: {repr(meta)})"
                )
                continue
            emoji_val = meta.get("emoji")
            if emoji_val is not None:
                if isinstance(emoji_val, str):
                    emoji_by_code[int(code)] = emoji_val
                else:
                    logger.warning(
                        f"Log code config: campo 'emoji' non valido in 'codes' per codice {code}: "
                        f"atteso str, trovato {type(emoji_val).__name__} (valore: {repr(emoji_val)})"
                    )
            name_val = meta.get("name")
            if name_val is not None:
                if isinstance(name_val, str) and name_val.strip():
                    name_by_code[int(code)] = name_val.strip()
                else:
                    logger.warning(
                        f"Log code config: campo 'name' non valido in 'codes' per codice {code}: "
                        f"atteso str non vuoto, trovato {type(name_val).__name__} (valore: {repr(name_val)})"
                    )

    return LogCodeConfig(
        default_by_level=default_by_level,
        state_codes=state_codes,
        phase_codes=phase_codes,
        category_codes=category_codes,
        emoji_by_code=emoji_by_code,
        name_by_code=name_by_code,
    )


def load_log_code_config_json(path: str) -> LogCodeConfig:
    """Carica una `LogCodeConfig` da un file JSON.

    Args:
        path: Path del file JSON.

    Returns:
        LogCodeConfig
    """
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Il file JSON dei log codes deve contenere un oggetto (dict).")
    return log_code_config_from_dict(data)


def make_log_code_resolver(config: Optional[LogCodeConfig] = None) -> LogCodeResolver:
    """Crea un resolver (callable) in base alla configurazione.

    Args:
        config: Configurazione opzionale.

    Ordine di priorità (dal più forte al fallback):
    1) `log_code` esplicito (argomento o dentro `properties`)
    2) `category` (solo da `properties`)
    3) `state` (argomento o dentro `properties`, con fallback su `category_codes`)
    4) `phase` (argomento o dentro `properties`)
    5) `default_by_level` (fallback standard 200/400/500)

    Returns:
        LogCodeResolver
    """
    cfg = config or LogCodeConfig()

    def resolve(
        level: str,
        message: str,
        log_code: Optional[int] = None,
        phase: Optional[str] = None,
        state: Optional[str] = None,
        properties: Optional[Dict[str, Any]] = None,
        *,
        status_code: Optional[int] = None,
    ) -> int:
        if _is_valid_code(log_code):
            return int(log_code)

        if properties and _is_valid_code(properties.get("log_code")):
            return int(properties["log_code"])

        # `status_code` è mantenuto come alias retro-compatibile (deprecato).
        if _is_valid_code(status_code):
            return int(status_code)

        if properties and _is_valid_code(properties.get("status_code")):
            return int(properties["status_code"])

        category = None
        if properties and isinstance(properties.get("category"), str):
            category = properties.get("category")
        if isinstance(category, str):
            ck = _normalize_key(category)
            if ck and ck in cfg.category_codes:
                return cfg.category_codes[ck]

        st = None
        if isinstance(state, str):
            st = state
        elif properties and isinstance(properties.get("state"), str):
            st = properties.get("state")
        if isinstance(st, str):
            sk = _normalize_key(st)
            if sk:
                if sk in cfg.state_codes:
                    return cfg.state_codes[sk]
                if sk in cfg.category_codes:
                    return cfg.category_codes[sk]

        ph = None
        if isinstance(phase, str):
            ph = phase
        elif properties and isinstance(properties.get("phase"), str):
            ph = properties.get("phase")
        if isinstance(ph, str):
            pk = _normalize_key(ph)
            if pk and pk in cfg.phase_codes:
                return cfg.phase_codes[pk]

        return cfg.default_by_level.get(_normalize_level(level), LogCode.OK)

    return resolve


def get_log_code(
    level: str,
    message: str,
    log_code: Optional[int] = None,
    phase: Optional[str] = None,
    state: Optional[str] = None,
    properties: Optional[Dict[str, Any]] = None,
    *,
    status_code: Optional[int] = None,
) -> int:
    """Resolver di default (fallback standard 200/400/500).

    Args:
        level: Livello log (es. "INFO", "ERROR").
        message: Attualmente non usato per la risoluzione, ma mantenuto per compatibilità
            e possibili estensioni future.
        log_code: Codice esplicito (opzionale).
        phase: Phase (opzionale).
        state: State (opzionale).
        properties: Properties aggiuntive (opzionale).

    Per usare mapping custom (state/phase/category), crea un resolver con
    `make_log_code_resolver(...)` e passalo al `Printer`.

    Returns:
        int
    """
    resolver = make_log_code_resolver()
    return resolver(level, message, log_code, phase, state, properties, status_code=status_code)


__all__ = [
    "LogCode",
    "LogCodeConfig",
    "LogCodeResolver",
    "DEFAULT_BY_LEVEL",
    "log_code_config_from_dict",
    "load_log_code_config_json",
    "make_log_code_resolver",
    "get_log_code",
]


