"""Metodi “di livello” (API) del printer.

Questo mixin espone i metodi pubblici (debug/info/warning/error/critical/success)
e delega tutta la logica a `_log(...)` implementato dalla classe concreta
(tipicamente `Printer`).
"""

from abc import ABC, abstractmethod
import logging
from typing import Any, Optional


class PrinterLevelMethodsMixin(ABC):
    """Mixin che richiede l’implementazione di `_log(...)`.

    Il contratto esplicito evita dipendenze “implicite” (AttributeError a runtime)
    e separa l’API pubblica dall’orchestrazione interna.
    """

    @abstractmethod
    def _log(self, **kwargs: Any) -> None:
        """Implementazione concreta del logging (orchestrazione).

        Note:
            Questo metodo è astratto: la classe concreta (es. ``Printer``) deve
            implementarlo.
        """
        raise NotImplementedError

    @staticmethod
    def _sanitize_properties(properties: dict[str, Any]) -> dict[str, Any]:
        """Rimuove chiavi che collidono con argomenti interni di `_log(...)`.

        Nota:
            È comune voler passare campi come `level_name` in structured logging,
            ma qui `level_name` è un argomento interno dell’orchestratore.
            Se l’utente lo passa in `**properties`, Python alzerebbe TypeError
            ("multiple values for keyword argument").
        """
        if not properties:
            return {}
        if any(k in properties for k in ("level_name", "log_level", "error_stream")):
            out = dict(properties)
            out.pop("level_name", None)
            out.pop("log_level", None)
            out.pop("error_stream", None)
            return out
        return properties

    def debug(
        self,
        message: str,
        output_type: Any = None,
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        *,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ):
        """Emette un messaggio di livello DEBUG.

        Args:
            message: Messaggio.
            output_type: Output ("print" | "log") o None per default.
            log_code: Codice log (opzionale).
            state: Stato (opzionale).
            force: Se True bypassa il filtro.
            use_emoji: Se True abilita emoji (se configurata per code).
            **properties: Metadati aggiuntivi.
        """
        if log_code is None and status_code is not None:
            log_code = status_code
        properties = self._sanitize_properties(properties)
        self._log(
            level_name="DEBUG",
            log_level=logging.DEBUG,
            message=message,
            output_type=output_type,
            log_code=log_code,
            state=state,
            force=force,
            use_emoji=use_emoji,
            **properties,
        )

    def info(
        self,
        message: str,
        output_type: Any = None,
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        *,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ):
        """Emette un messaggio di livello INFO.

        Args:
            message: Messaggio.
            output_type: Output ("print" | "log") o None per default.
            log_code: Codice log (opzionale).
            state: Stato (opzionale).
            force: Se True bypassa il filtro.
            use_emoji: Se True abilita emoji (se configurata per code).
            **properties: Metadati aggiuntivi.
        """
        if log_code is None and status_code is not None:
            log_code = status_code
        properties = self._sanitize_properties(properties)
        self._log(
            level_name="INFO",
            log_level=logging.INFO,
            message=message,
            output_type=output_type,
            log_code=log_code,
            state=state,
            force=force,
            use_emoji=use_emoji,
            **properties,
        )

    def warning(
        self,
        message: str,
        output_type: Any = None,
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        *,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ):
        """Emette un messaggio di livello WARNING.

        Args:
            message: Messaggio.
            output_type: Output ("print" | "log") o None per default.
            log_code: Codice log (opzionale).
            state: Stato (opzionale).
            force: Se True bypassa il filtro.
            use_emoji: Se True abilita emoji (se configurata per code).
            **properties: Metadati aggiuntivi.
        """
        if log_code is None and status_code is not None:
            log_code = status_code
        properties = self._sanitize_properties(properties)
        self._log(
            level_name="WARNING",
            log_level=logging.WARNING,
            message=message,
            output_type=output_type,
            log_code=log_code,
            state=state,
            force=force,
            use_emoji=use_emoji,
            **properties,
        )

    def error(
        self,
        message: str,
        output_type: Any = None,
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        *,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ):
        """Emette un messaggio di livello ERROR.

        Args:
            message: Messaggio.
            output_type: Output ("print" | "log") o None per default.
            log_code: Codice log (opzionale).
            state: Stato (opzionale).
            force: Se True bypassa il filtro.
            use_emoji: Se True abilita emoji (se configurata per code).
            **properties: Metadati aggiuntivi.
        """
        if log_code is None and status_code is not None:
            log_code = status_code
        properties = self._sanitize_properties(properties)
        self._log(
            level_name="ERROR",
            log_level=logging.ERROR,
            message=message,
            output_type=output_type,
            log_code=log_code,
            state=state,
            force=force,
            use_emoji=use_emoji,
            error_stream=True,
            **properties,
        )

    def critical(
        self,
        message: str,
        output_type: Any = None,
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        *,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ):
        """Emette un messaggio di livello CRITICAL.

        Args:
            message: Messaggio.
            output_type: Output ("print" | "log") o None per default.
            log_code: Codice log (opzionale).
            state: Stato (opzionale).
            force: Se True bypassa il filtro.
            use_emoji: Se True abilita emoji (se configurata per code).
            **properties: Metadati aggiuntivi.
        """
        if log_code is None and status_code is not None:
            log_code = status_code
        properties = self._sanitize_properties(properties)
        self._log(
            level_name="CRITICAL",
            log_level=logging.CRITICAL,
            message=message,
            output_type=output_type,
            log_code=log_code,
            state=state,
            force=force,
            use_emoji=use_emoji,
            error_stream=True,
            **properties,
        )

    def success(
        self,
        message: str,
        output_type: Any = None,
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        *,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ):
        """Emette un messaggio di livello SUCCESS (livello numerico: INFO).

        Args:
            message: Messaggio.
            output_type: Output ("print" | "log") o None per default.
            log_code: Codice log (opzionale).
            state: Stato (opzionale).
            force: Se True bypassa il filtro.
            use_emoji: Se True abilita emoji (se configurata per code).
            **properties: Metadati aggiuntivi.
        """
        if log_code is None and status_code is not None:
            log_code = status_code
        properties = self._sanitize_properties(properties)
        self._log(
            level_name="SUCCESS",
            log_level=logging.INFO,
            message=message,
            output_type=output_type,
            log_code=log_code,
            state=state,
            force=force,
            use_emoji=use_emoji,
            **properties,
        )


