"""Implementazione completa del printer.

`Printer` estende `PrinterBase` aggiungendo:
- emissione opzionale di log strutturati JSON (quando `use_structured_logging=True`)
- mapping opzionale `log_code -> emoji` e `log_code -> name`
- gestione automatica dello stack trace (configurabile)
"""

import sys
import os
import logging
import traceback
from typing import Optional, Any, Dict, Callable, Mapping, Union, Literal

from .base import PrinterBase
from .level_methods import PrinterLevelMethodsMixin
from ..utils.enums import DebuggingMode
from ..utils.trace import get_filtered_stack_trace
from ..loggers.structured import StructuredLogger
from ..loggers.entry import PropertiesPolicy


class Printer(PrinterLevelMethodsMixin, PrinterBase):
    """Classe completa per logging e stampa formattata.

    La logica “base” (filtri, prefissi, print/log) vive in `PrinterBase`.
    Questa classe aggiunge un canale structured (JSON) e metadati opzionali
    legati al `log_code`.
    """

    def __init__(
        self,
        debugging_mode: DebuggingMode = DebuggingMode.NORMAL,
        name: str = "Printer",
        use_structured_logging: bool = False,
        log_code_resolver: Optional[
            Callable[
                [
                    str,
                    str,
                    Optional[int],
                    Optional[str],
                    Optional[str],
                    Optional[Dict[str, Any]],
                ],
                int,
            ]
        ] = None,
        emoji_by_code: Optional[Mapping[int, str]] = None,
        name_by_code: Optional[Mapping[int, str]] = None,
        custom_logs_prefix: Union[str, bool] = True,
        session_id_prefix: Union[str, bool] = True,
        stacktrace_mode: Literal["off", "exception_only"] = "exception_only",
        default_output_type: Literal["print", "log"] = "print",
        structured_properties_policy: Optional[PropertiesPolicy] = None,
        project_name: Optional[str] = None,
    ):
        """Inizializza il ``Printer`` con configurazione personalizzata.

        Args:
            debugging_mode: Modalità di debugging per controllare la visibilità dei log.
            name: Nome del logger che apparirà nei messaggi di log.
            use_structured_logging: Se True abilita emissione di log strutturati JSON
                quando `output_type="log"`.
            log_code_resolver: Resolver opzionale per i log code (per-istanza).
            emoji_by_code: Mapping opzionale code -> emoji.
            name_by_code: Mapping opzionale code -> nome.
            custom_logs_prefix: Prefisso custom logs (True=default, False=disabilita, str=valore).
            session_id_prefix: Prefisso session id (True=default "SES-ID-", False=disabilita, str=valore).
            stacktrace_mode: Policy stack trace per ERROR/CRITICAL.
            default_output_type: Output predefinito quando `output_type=None`.
            structured_properties_policy: Policy allowlist/redaction/transformer delle properties
                (solo structured).
            project_name: Nome del progetto. Se non fornito, viene letto da variabili d'ambiente
                `PROJECT_NAME` o `AZURE_FUNCTION_NAME`. Se ancora assente, usa "unknown_project".
        """
        super().__init__(
            debugging_mode,
            name,
            log_code_resolver=log_code_resolver,
            custom_logs_prefix=custom_logs_prefix,
            session_id_prefix=session_id_prefix,
            default_output_type=default_output_type,
        )

        self.use_structured_logging = use_structured_logging

        self.structured_logger = StructuredLogger(
            self.logger.name,
            log_code_resolver=self._resolve_log_code,
            custom_logs_prefix=custom_logs_prefix,
            session_id_prefix=session_id_prefix,
            properties_policy=structured_properties_policy,
        )

        self.emoji_by_code = dict(emoji_by_code) if emoji_by_code else {}
        self.name_by_code = dict(name_by_code) if name_by_code else {}
        self.stacktrace_mode = stacktrace_mode
        
        # Risolvi project_name: parametro > variabili d'ambiente > default
        if project_name is None:
            project_name = os.getenv("PROJECT_NAME") or os.getenv("AZURE_FUNCTION_NAME")
        self.project_name = project_name if project_name else "unknown_project"

    def _emoji_for_code(self, code: int) -> str:
        return self.emoji_by_code.get(int(code), "")

    def _name_for_code(self, code: int) -> str:
        return self.name_by_code.get(int(code), "")

    def _build_formatted_message(
        self, emoji: str, level_name: str, message: str
    ) -> str:
        """Costruisce la stringa di log “testuale”.

        Note:
            Mantiene lo spacing storico: per INFO/WARNING vengono inseriti due spazi
            dopo l’emoji.
        """
        if emoji:
            if level_name in ("INFO", "WARNING"):
                return f"{emoji}  {level_name}: {message}"
            return f"{emoji} {level_name}: {message}"
        return f"{level_name}: {message}"

    def _choose_emoji(self, *, resolved_code: int, use_emoji: bool) -> str:
        """Seleziona l’emoji da associare al codice risolto (se abilitato)."""
        if not use_emoji:
            return ""
        code_emoji = self._emoji_for_code(resolved_code)
        if code_emoji:
            return code_emoji
        return ""

    _RESERVED_PROPERTY_KEYS = (
        # `status_code` è mantenuto come alias retro-compatibile (deprecato).
        "log_code",
        "status_code",
        # chiavi interne che non devono finire nelle properties
        "log_level",
        "error_stream",
        "state",
        "level_name",
        "emoji",
        "raw_message",
        "code_name",
    )

    def _log(
        self,
        *,
        level_name: str,
        log_level: int,
        message: str,
        output_type: Any = "print",
        log_code: Optional[int] = None,
        state: Optional[str] = None,
        force: bool = False,
        use_emoji: bool = True,
        error_stream: bool = False,
        # Alias retro-compatibile (deprecato). Preferire `log_code`.
        status_code: Optional[int] = None,
        **properties: Any,
    ) -> None:
        """Implementazione unica per debug/info/warning/error/critical/success.

        Note:
            Centralizza:
            - risoluzione del `log_code` (fallback o mapping JSON/resolver custom)
            - scelta emoji e `code_name` (se configurati)
            - sanitizzazione delle properties (rimuove chiavi riservate)
            - delega finale a `_output(...)`
        """
        if output_type is None:
            output_type = self.default_output_type

        phase = properties.get("phase")
        effective_log_code = log_code if log_code is not None else status_code
        resolved_code = self._resolve_log_code(
            level_name, message, effective_log_code, phase, state, properties
        )
        emoji = self._choose_emoji(resolved_code=resolved_code, use_emoji=use_emoji)
        formatted_message = self._build_formatted_message(emoji, level_name, message)
        code_name = self._name_for_code(resolved_code)

        properties_clean = {
            k: v for k, v in properties.items() if k not in self._RESERVED_PROPERTY_KEYS
        }

        self._output(
            formatted_message,
            log_level,
            error=error_stream,
            force=force,
            log_code=resolved_code,
            output_type=output_type,
            state=state,
            level_name=level_name,
            emoji=emoji,
            raw_message=message,
            code_name=code_name,
            **properties_clean,
        )

    def _output(
        self,
        message: str,
        log_level: int,
        error: bool = False,
        force: bool = False,
        **properties: Any,
    ):
        """Override del metodo base per aggiungere log strutturati (opzionali).

        Args:
            message: Messaggio da visualizzare.
            log_level: Livello numerico (controllo visibilità + emissione structured).
            error: Se True, stampa su stderr invece che su stdout.
            force: Se True, bypassa il filtro DebuggingMode.
            **properties: Metadati aggiuntivi; alcuni vengono usati per:
                - aggiungere stack trace (se configurato e c’è eccezione attiva)
                - produrre l’entry JSON structured (se abilitata)
        """
        level_map = {
            logging.DEBUG: "DEBUG",
            logging.INFO: "INFO",
            logging.WARNING: "WARNING",
            logging.ERROR: "ERROR",
            logging.CRITICAL: "CRITICAL",
        }
        level = level_map.get(log_level, "INFO")

        if (
            self.stacktrace_mode != "off"
            and level in ["ERROR", "CRITICAL"]
            and "stack_trace" not in properties
        ):
            properties = properties.copy() if properties else {}

            exc_type, exc_value, exc_traceback = sys.exc_info()
            if exc_type is not None:
                # Usa traceback.format_exc() per le eccezioni (include il traceback completo)
                properties["stack_trace"] = traceback.format_exc()
                properties["exception_type"] = exc_type.__name__
                if exc_value:
                    properties["exception_message"] = str(exc_value)
            else:
                # Se non c'è eccezione attiva ma vogliamo comunque lo stack trace,
                # usa la funzione filtrata
                filtered_trace = get_filtered_stack_trace(self.project_name, limit=5)
                if filtered_trace:
                    properties["stack_trace"] = filtered_trace

        super()._output(message, log_level, error, force, **properties)

        output_type = properties.get("output_type")
        ot = output_type.lower() if isinstance(output_type, str) else None
        if self.use_structured_logging and properties and ot == "log":
            # Usa level_name se disponibile (es. SUCCESS), altrimenti mappa dal livello numerico.
            explicit_level = properties.get("level_name")
            if isinstance(explicit_level, str) and explicit_level:
                level = explicit_level.upper()
            else:
                level_map = {
                    logging.DEBUG: "DEBUG",
                    logging.INFO: "INFO",
                    logging.WARNING: "WARNING",
                    logging.ERROR: "ERROR",
                    logging.CRITICAL: "CRITICAL",
                }
                level = level_map.get(log_level, "INFO")

            emoji = (
                properties.get("emoji")
                if isinstance(properties.get("emoji"), str)
                else ""
            )

            raw_message = properties.get("raw_message")
            clean_message = (
                raw_message if isinstance(raw_message, str) and raw_message else message
            )

            structured_properties = {
                k: v
                for k, v in properties.items()
                if k
                not in (
                    "output_type",
                    "emoji",
                    "level_name",
                    "raw_message",
                )
            }
            self.structured_logger.log(
                level,
                emoji,
                clean_message,
                log_level,
                self.logger,
                **structured_properties,
            )

    def set_logger_name(self, name: str):
        """Imposta un nuovo nome per il logger (testuale + structured).

        Note:
            `StructuredLogger` mantiene una copia del nome logger da inserire nel JSON.
            Se non lo aggiorniamo, i log strutturati continuano a riportare il vecchio nome.
        """
        super().set_logger_name(name)
        # Mantieni coerente anche il canale structured.
        if getattr(self, "structured_logger", None) is not None:
            self.structured_logger.logger_name = name


__all__ = ["Printer"]
