"""Implementazione base per logging/stampa formattata.

`PrinterBase` fornisce:
- controllo della verbosità tramite `DebuggingMode`
- output su stdout/stderr oppure via `logging.Logger` (selezionabile con `output_type`)
- prefissi coerenti (custom/session id/log_code)

Le funzionalità avanzate (es. emissione JSON strutturata) sono implementate da
`Printer` che estende questa classe.
"""

import sys
import logging
import traceback
from typing import Optional, Any, Callable, Dict, Union, Literal

from ..utils.enums import DebuggingMode
from ..utils.session import get_session_id
from ..utils.log_codes import get_log_code


class LogMessageFormatter:
    """Helper per formattare i messaggi di log con prefissi standard.
    
    Si occupa esclusivamente di assemblare la stringa del messaggio,
    gestendo prefissi [CUSTOM], [SES-ID], [CODE] e concatenazione con il messaggio utente.
    """
    
    def __init__(
        self,
        custom_logs_prefix: Optional[str],
        session_id_prefix: Optional[str],
    ):
        """Inizializza il formatter.
        
        Args:
            custom_logs_prefix: Prefisso custom logs (es. "[CUSTOM_LOGS]").
            session_id_prefix: Prefisso session id (es. "SES-ID-").
        """
        self.custom_logs_prefix = custom_logs_prefix
        self.session_id_prefix = session_id_prefix
    
    def format(
        self,
        message: str,
        log_code: int,
        session_id: Optional[str] = None,
        stack_trace: Optional[str] = None,
    ) -> str:
        """Formatta un messaggio di log con tutti i prefissi.
        
        Args:
            message: Messaggio già formattato (es. "INFO: ...").
            log_code: Codice log da includere.
            session_id: Session ID opzionale.
            stack_trace: Stack trace opzionale da appendere.
        
        Returns:
            Messaggio formattato completo.
        """
        message_for_code = message
        level_prefix = ""
        for prefix in ("DEBUG: ", "INFO: ", "WARNING: ", "ERROR: ", "CRITICAL: ", "SUCCESS: "):
            if message_for_code.startswith(prefix):
                level_prefix = prefix
                message_for_code = message_for_code[len(prefix) :]
                break
        
        message_content = message
        # Se il messaggio "pulito" (senza "INFO: ") inizia già con il prefisso custom,
        # lo strippo per evitare duplicazioni (es. riloggare una riga già prefissata).
        if self.custom_logs_prefix and message_for_code.startswith(self.custom_logs_prefix):
            parts = message_for_code.split(" - ", 1)
            if len(parts) > 1:
                inner = parts[1]
            else:
                inner = message_for_code.replace(self.custom_logs_prefix, "").strip()
            
            # Se l'inner contiene già un prefisso di livello (es. "INFO: "),
            # non aggiungo un secondo "INFO: ".
            if inner.startswith(("DEBUG: ", "INFO: ", "WARNING: ", "ERROR: ", "CRITICAL: ", "SUCCESS: ")):
                message_content = inner
            else:
                message_content = f"{level_prefix}{inner}" if level_prefix else inner
        
        prefix_parts = []
        if self.custom_logs_prefix:
            prefix_parts.append(self.custom_logs_prefix)
        if session_id and self.session_id_prefix:
            prefix_parts.append(f"[{self.session_id_prefix}{session_id}]")
        prefix_parts.append(f"[{int(log_code):03d}]")
        
        if prefix_parts:
            prefixed_message = " - ".join(prefix_parts) + f" - {message_content}"
        else:
            prefixed_message = message_content
        
        if stack_trace:
            prefixed_message += f"\n{stack_trace}"
        
        return prefixed_message


class PrinterBase:
    """Classe base per logging e stampa formattata.

    La classe espone metodi “di livello” (debug/info/...) e utilità di
    formattazione (header/section/custom/plain) che producono un output coerente
    e filtrabile tramite `DebuggingMode`.

    Note:
        Se il logger non ha handler, ``PrinterBase`` ne crea due:
        - stdout per livelli < ERROR
        - stderr per livelli >= ERROR
    """

    def __init__(
        self,
        debugging_mode: DebuggingMode = DebuggingMode.NORMAL,
        name: str = "Printer",
        *,
        log_code_resolver: Optional[
            Callable[[str, str, Optional[int], Optional[str], Optional[str], Optional[Dict[str, Any]]], int]
        ] = None,
        custom_logs_prefix: Union[str, bool] = True,
        session_id_prefix: Union[str, bool] = True,
        default_output_type: Literal["print", "log"] = "print",
    ):
        """Inizializza un ``PrinterBase``.

        Args:
            debugging_mode: Modalità che controlla la visibilità dei log.
            name: Nome del ``logging.Logger`` usato internamente.
            log_code_resolver: Callable opzionale per risolvere il ``log_code``.
                Se assente viene usato ``utils.log_codes.get_log_code``.
            custom_logs_prefix: Prefisso “custom logs”.
            session_id_prefix: Prefisso per session id.
            default_output_type: Output predefinito quando ``output_type`` non viene
                passato.
        """
        self.debugging_mode = debugging_mode
        self.logger = logging.getLogger(name)
        self.logger.name = name
        self.log_code_resolver = log_code_resolver
        self.custom_logs_prefix = self._normalize_custom_logs_prefix(custom_logs_prefix)
        self.session_id_prefix = self._normalize_session_id_prefix(session_id_prefix)
        self.default_output_type: Literal["print", "log"] = default_output_type
        
        # Inizializza il formatter per la formattazione dei messaggi
        self._formatter = LogMessageFormatter(
            custom_logs_prefix=self.custom_logs_prefix,
            session_id_prefix=self.session_id_prefix,
        )

        if not self.logger.handlers:
            formatter = logging.Formatter("%(message)s")

            class _LessThanErrorFilter(logging.Filter):
                def filter(self, record: logging.LogRecord) -> bool:  # type: ignore[override]
                    return record.levelno < logging.ERROR

            class _AtLeastErrorFilter(logging.Filter):
                def filter(self, record: logging.LogRecord) -> bool:  # type: ignore[override]
                    return record.levelno >= logging.ERROR

            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setFormatter(formatter)
            stdout_handler.addFilter(_LessThanErrorFilter())

            stderr_handler = logging.StreamHandler(sys.stderr)
            stderr_handler.setFormatter(formatter)
            stderr_handler.addFilter(_AtLeastErrorFilter())

            self.logger.addHandler(stdout_handler)
            self.logger.addHandler(stderr_handler)

        self.logger.setLevel(debugging_mode.value)

        # Evita propagazione verso il root logger (es. Azure Functions) e quindi duplicazioni.
        self.logger.propagate = False

    @staticmethod
    def _normalize_custom_logs_prefix(value: Union[str, bool]) -> Optional[str]:
        """Normalizza il prefisso “custom logs”.

        - `False`: disabilita
        - `True`: usa il default `"[CUSTOM_LOGS]"`
        - `str`: usa il valore; se non è già tra parentesi quadre, viene wrappato
        """
        if value is False:
            return None
        if value is True:
            return "[CUSTOM_LOGS]"
        if isinstance(value, str):
            v = value.strip()
            if not v:
                return None
            if v.startswith("[") and v.endswith("]"):
                return v
            return f"[{v}]"
        return "[CUSTOM_LOGS]"

    @staticmethod
    def _normalize_session_id_prefix(value: Union[str, bool]) -> Optional[str]:
        """Normalizza il prefisso usato per stampare il session id.

        - `False`: disabilita
        - `True`: usa il default `"SES-ID-"`
        - `str`: usa il valore così com’è (es. `"SESSION-"`, `"SES-ID-"`)

        Se viene passato un valore già racchiuso tra parentesi quadre (es.
        `"[SES-ID-]"`), queste vengono rimosse per evitare doppie parentesi.
        """
        if value is False:
            return None
        if value is True:
            return "SES-ID-"
        if isinstance(value, str):
            v = value.strip()
            if not v:
                return None
            if v.startswith("[") and v.endswith("]"):
                v = v[1:-1].strip()
            return v if v else None
        return "SES-ID-"

    def _resolve_log_code(
        self,
        level: str,
        message_for_code: str,
        log_code: Optional[int] = None,
        phase: Optional[str] = None,
        state: Optional[str] = None,
        properties: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Risolvi il ``log_code`` usando il resolver per-istanza (se presente).

        Returns:
            int
        """
        if self.log_code_resolver is not None:
            return self.log_code_resolver(level, message_for_code, log_code, phase, state, properties)
        # `status_code` è mantenuto come alias retro-compatibile (deprecato) via properties.
        return get_log_code(level, message_for_code, log_code, phase, state, properties)

    def _should_log(self, log_level: int) -> bool:
        """Ritorna True se il messaggio è visibile dato il ``DebuggingMode``.

        Args:
            log_level: Livello numerico di logging (es. ``logging.INFO``).

        Returns:
            bool
        """
        if self.debugging_mode == DebuggingMode.NORMAL:
            return log_level >= logging.WARNING
        elif self.debugging_mode == DebuggingMode.VERBOSE:
            return log_level > logging.DEBUG
        elif self.debugging_mode == DebuggingMode.PRODUCTION:
            return log_level > logging.DEBUG
        elif self.debugging_mode == DebuggingMode.DEBUG:
            return True
        return False

    def _dispatch_log(
        self,
        formatted_message: str,
        log_level: int,
        output_type: str,
        error: bool = False,
        force: bool = False,
    ) -> None:
        """Esegue il dispatch del log (print o logging.Logger).
        
        Si occupa esclusivamente di decidere se stampare su stdout/stderr
        o usare self.logger.log.
        
        Args:
            formatted_message: Messaggio già formattato con tutti i prefissi.
            log_level: Livello numerico (logging.INFO, logging.ERROR, ...).
            output_type: Tipo di output ("print" o "log").
            error: Se True stampa su stderr (solo per output_type="print").
            force: Se True bypassa il filtro del logger (solo per output_type="log").
        """
        if output_type == "log":
            if force:
                # `Logger.log(...)` applica anche il livello del logger; `force=True`
                # deve bypassare la visibilità end-to-end.
                record = self.logger.makeRecord(
                    self.logger.name,
                    log_level,
                    fn="",
                    lno=0,
                    msg=formatted_message,
                    args=(),
                    exc_info=None,
                )
                self.logger.handle(record)
            else:
                self.logger.log(log_level, formatted_message)
        else:
            if error:
                print(formatted_message, file=sys.stderr)
            else:
                print(formatted_message)

    def _output(
        self,
        message: str,
        log_level: int,
        error: bool = False,
        force: bool = False,
        **properties: dict,
    ):
        """Esegue l'output finale (print o logging) con prefissi standard.

        Il formato del messaggio include (se abilitati):
        - prefisso custom logs
        - session id (da contesto)
        - log_code (sempre presente, in forma `[XYZ]`)

        Args:
            message: Messaggio già formattato (es. ``"INFO: ..."``).
            log_level: Livello numerico (``logging.INFO``, ``logging.ERROR``, …).
            error: Se True stampa su stderr (solo per ``output_type="print"``).
            force: Se True bypassa il filtro di ``DebuggingMode``.
            **properties: Metadati usati per risolvere il ``log_code`` e per aggiungere
                opzionalmente ``stack_trace``.
        """
        output_type = properties.pop("output_type", self.default_output_type)
        if output_type is None:
            output_type = self.default_output_type
        if isinstance(output_type, str):
            output_type = output_type.lower()
        else:
            output_type = self.default_output_type

        if not force and not self._should_log(log_level):
            return

        # Recupera session_id e log_code
        session_id = get_session_id()

        level_map = {
            logging.DEBUG: "DEBUG",
            logging.INFO: "INFO",
            logging.WARNING: "WARNING",
            logging.ERROR: "ERROR",
            logging.CRITICAL: "CRITICAL",
        }
        level = level_map.get(log_level, "INFO")

        message_for_code = message
        for prefix in ("DEBUG: ", "INFO: ", "WARNING: ", "ERROR: ", "CRITICAL: ", "SUCCESS: "):
            if message_for_code.startswith(prefix):
                message_for_code = message_for_code[len(prefix) :]
                break

        explicit_log_code = properties.get("log_code")
        if not isinstance(explicit_log_code, int) or not (100 <= explicit_log_code <= 999):
            # Alias retro-compatibile (deprecato)
            explicit_log_code = properties.get("status_code")
        phase = properties.get("phase")
        state = properties.get("state")

        log_code = self._resolve_log_code(level, message_for_code, explicit_log_code, phase, state, properties)

        # Estrai stack_trace se presente
        stack_trace = None
        if level in ["ERROR", "CRITICAL"] and properties:
            stack_trace = properties.get("stack_trace")

        # Delega la formattazione al formatter
        formatted_message = self._formatter.format(
            message=message,
            log_code=log_code,
            session_id=session_id,
            stack_trace=stack_trace,
        )

        # Delega il dispatch al dispatcher
        self._dispatch_log(
            formatted_message=formatted_message,
            log_level=log_level,
            output_type=output_type,
            error=error,
            force=force,
        )

    def set_logger_name(self, name: str):
        """Imposta un nuovo nome per il logger.

        Args:
            name: Nome del logger.
        """
        self.logger.name = name

    def set_debugging_mode(self, debugging_mode: DebuggingMode):
        """Imposta una nuova modalità di debugging.

        Args:
            debugging_mode: Modalità di debug.
        """
        self.debugging_mode = debugging_mode
        self.logger.setLevel(debugging_mode.value)

    def debug(self, message: str, force: bool = False, **properties):
        """Stampa un messaggio di debug."""
        formatted_message = f"DEBUG: {message}"
        self._output(formatted_message, logging.DEBUG, force=force, **properties)

    def info(self, message: str, force: bool = False, **properties):
        """Stampa un messaggio informativo."""
        formatted_message = f"INFO: {message}"
        self._output(formatted_message, logging.INFO, force=force, **properties)

    def warning(self, message: str, force: bool = False, **properties):
        """Stampa un messaggio di avviso."""
        formatted_message = f"WARNING: {message}"
        self._output(formatted_message, logging.WARNING, force=force, **properties)

    def error(self, message: str, force: bool = False, **properties):
        """Stampa un messaggio di errore."""
        formatted_message = f"ERROR: {message}"
        self._output(formatted_message, logging.ERROR, error=True, force=force, **properties)

    def critical(self, message: str, force: bool = False, **properties):
        """Stampa un messaggio critico."""
        formatted_message = f"CRITICAL: {message}"
        self._output(formatted_message, logging.CRITICAL, error=True, force=force, **properties)

    def success(self, message: str, force: bool = False, **properties):
        """Stampa un messaggio di successo."""
        formatted_message = f"SUCCESS: {message}"
        self._output(formatted_message, logging.INFO, force=force, **properties)

    def header(
        self,
        message: str,
        char: str = "=",
        length: int = 80,
        force: bool = False,
        **properties,
    ):
        """Stampa un'intestazione circondata da linee di un carattere."""
        header_line = char * length
        formatted_message = f"\n{header_line}\n{message}\n{header_line}"
        self._output(formatted_message, logging.INFO, force=force, **properties)

    def section(self, title: str, content: str, force: bool = False):
        """Stampa una sezione formattata con un titolo e un contenuto."""
        formatted_message = f"\n📑 {title}\n{'-' * 40}\n{content}\n{'-' * 40}"
        self._output(formatted_message, logging.INFO, force=force)

    def custom(self, message: str, prefix: str = "➡️", force: bool = False):
        """Stampa un messaggio personalizzato con un prefisso a scelta."""
        formatted_message = f"{prefix} {message}"
        self._output(formatted_message, logging.INFO, force=force)

    def plain(self, message: str, force: bool = False):
        """Stampa un messaggio senza alcuna formattazione aggiuntiva."""
        self._output(message, logging.INFO, force=force)


__all__ = ["PrinterBase"]


