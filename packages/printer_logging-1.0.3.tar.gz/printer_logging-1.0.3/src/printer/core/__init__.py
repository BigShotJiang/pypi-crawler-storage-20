"""Implementazioni principali del package.

Note:
    Il package root (``printer.__init__``) re-esporta i simboli qui definiti per
    offrire un’API pubblica stabile.
"""

from .base import PrinterBase
from .printer import Printer

__all__ = ["PrinterBase", "Printer"]


