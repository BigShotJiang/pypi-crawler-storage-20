from __future__ import annotations

import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams


ensure_src_on_path()

from printer import PrinterBase, DebuggingMode  # noqa: E402
from printer.utils.session import session_id_var  # noqa: E402


class TestPrefixNormalization(unittest.TestCase):
    def tearDown(self) -> None:
        session_id_var.set(None)

    def test_normalize_custom_logs_prefix(self):
        self.assertIsNone(PrinterBase._normalize_custom_logs_prefix(False))
        self.assertEqual(PrinterBase._normalize_custom_logs_prefix(True), "[CUSTOM_LOGS]")
        self.assertEqual(PrinterBase._normalize_custom_logs_prefix("X"), "[X]")
        self.assertEqual(PrinterBase._normalize_custom_logs_prefix("[X]"), "[X]")
        self.assertIsNone(PrinterBase._normalize_custom_logs_prefix("   "))

    def test_normalize_session_id_prefix(self):
        self.assertIsNone(PrinterBase._normalize_session_id_prefix(False))
        self.assertEqual(PrinterBase._normalize_session_id_prefix(True), "SES-ID-")
        self.assertEqual(PrinterBase._normalize_session_id_prefix("SESSION-"), "SESSION-")
        self.assertEqual(PrinterBase._normalize_session_id_prefix("[SES-ID-]"), "SES-ID-")
        self.assertIsNone(PrinterBase._normalize_session_id_prefix("   "))

    def test_message_content_strips_custom_prefix(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="PFX", custom_logs_prefix=True, default_output_type="log")
        streams = attach_logger_streams(p.logger)

        # messaggio già con prefisso custom e " - "
        p.info("[CUSTOM_LOGS] - INFO: hello", output_type="log", force=True)
        out = streams.stdout.getvalue()
        # deve stampare un solo [CUSTOM_LOGS] (quello “ufficiale”)
        self.assertIn("[CUSTOM_LOGS] - [200] - INFO: hello", out)

    def test_session_prefix_only_when_session_id_present(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="PFX2", session_id_prefix=True, default_output_type="log")
        streams = attach_logger_streams(p.logger)

        session_id_var.set(None)
        p.info("no-session", output_type="log", force=True)
        self.assertNotIn("SES-ID-", streams.stdout.getvalue())

        session_id_var.set("abc")
        p.info("with-session", output_type="log", force=True)
        self.assertIn("[SES-ID-abc]", streams.stdout.getvalue())


