from __future__ import annotations

import logging
import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams, capture_print_streams, reset_logger


ensure_src_on_path()

from printer import PrinterBase, DebuggingMode  # noqa: E402


class TestMatrixCore(unittest.TestCase):
    def test_handlers_created_only_when_missing(self):
        name = "MATRIX_HANDLERS"
        lg = reset_logger(name)
        lg.addHandler(logging.NullHandler())

        p = PrinterBase(DebuggingMode.DEBUG, name=name)
        # aveva già handler -> non deve aggiungere i due stream handler standard
        self.assertEqual(len(p.logger.handlers), 1)

        # reset: senza handler -> deve aggiungerne 2
        reset_logger(name)
        p2 = PrinterBase(DebuggingMode.DEBUG, name=name)
        self.assertEqual(len(p2.logger.handlers), 2)

    def test_output_type_normalization(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="MATRIX_OT")
        streams = attach_logger_streams(p.logger)

        # case-insensitive
        p.info("a", output_type="LOG", force=True)
        self.assertIn("INFO: a", streams.stdout.getvalue())

        # output_type non stringa -> fallback a default_output_type (print)
        with capture_print_streams() as s:
            p.info("b", output_type=object(), force=True)
            out, err = s.getvalue()
        self.assertIn("INFO: b", out)
        self.assertEqual(err.strip(), "")

    def test_force_bypasses_debugging_mode(self):
        p = PrinterBase(DebuggingMode.NORMAL, name="MATRIX_FORCE")
        streams = attach_logger_streams(p.logger)

        p.info("hidden", output_type="log", force=False)
        self.assertEqual(streams.stdout.getvalue().strip(), "")

        p.info("forced", output_type="log", force=True)
        self.assertIn("INFO: forced", streams.stdout.getvalue())

    def test_routing_stdout_stderr_in_log_mode(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="MATRIX_ROUTE", default_output_type="log")
        streams = attach_logger_streams(p.logger)

        p.warning("w")  # stdout handler (< ERROR)
        p.error("e")    # stderr handler (>= ERROR)

        out, err = streams.getvalue()
        self.assertIn("WARNING: w", out)
        self.assertNotIn("ERROR: e", out)
        self.assertIn("ERROR: e", err)


