from __future__ import annotations

import unittest

from tests.helpers import ensure_src_on_path


ensure_src_on_path()

from printer.utils.log_codes import log_code_config_from_dict, make_log_code_resolver  # noqa: E402


class TestLogCodeConfigParsing(unittest.TestCase):
    def test_alias_keys_and_code_definitions(self):
        cfg = log_code_config_from_dict(
            {
                "default_by_level": {"info": 210},  # case-insensitive key
                "states": {"Init": 111},
                "phases": {"BOOT": 121},
                "categories": {"REQ": 101},
                "code_definitions": {  # alias di `codes`
                    "210": {"name": "OK", "emoji": "🟦"},
                    500: {"name": "SERVER_ERROR", "emoji": "🟥"},
                },
            }
        )

        self.assertEqual(cfg.default_by_level["INFO"], 210)
        self.assertEqual(cfg.state_codes["init"], 111)
        self.assertEqual(cfg.phase_codes["boot"], 121)
        self.assertEqual(cfg.category_codes["req"], 101)
        self.assertEqual(cfg.name_by_code[210], "OK")
        self.assertEqual(cfg.emoji_by_code[210], "🟦")
        self.assertEqual(cfg.name_by_code[500], "SERVER_ERROR")
        self.assertEqual(cfg.emoji_by_code[500], "🟥")

        resolver = make_log_code_resolver(cfg)
        self.assertEqual(resolver("INFO", "x"), 210)
        self.assertEqual(resolver("INFO", "x", None, None, "init", {}), 111)
        self.assertEqual(resolver("INFO", "x", None, "boot", None, {}), 121)
        self.assertEqual(resolver("INFO", "x", None, None, None, {"category": "REQ"}), 101)

    def test_invalid_maps_are_ignored_gracefully(self):
        cfg = log_code_config_from_dict(
            {
                "default_by_level": ["bad"],
                "states": "bad",
                "phases": {"ok": 99},  # code non valido (range)
                "emoji_by_code": {"x": "🟦", "200": 123},  # invalid
                "name_by_code": {"200": ""},  # empty string ignored
            }
        )
        self.assertIn("INFO", cfg.default_by_level)
        self.assertEqual(cfg.state_codes, {})
        self.assertEqual(cfg.phase_codes, {})
        self.assertEqual(cfg.emoji_by_code, {})
        self.assertEqual(cfg.name_by_code, {})


