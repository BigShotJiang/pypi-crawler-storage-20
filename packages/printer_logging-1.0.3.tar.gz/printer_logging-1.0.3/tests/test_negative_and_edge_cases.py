from __future__ import annotations

import json
import tempfile
import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams


ensure_src_on_path()

import printer  # noqa: E402
from printer import Printer, DebuggingMode  # noqa: E402
from printer.utils.log_codes import get_log_code, load_log_code_config_json  # noqa: E402


class TestNegativeAndEdgeCases(unittest.TestCase):
    def tearDown(self) -> None:
        printer.reset_printer()

    def _last_json_any_stream(self, streams) -> dict:
        out = streams.stdout.getvalue()
        err = streams.stderr.getvalue()
        blob = "\n".join([out, err])
        lines = [ln.strip() for ln in blob.splitlines() if ln.strip()]
        json_lines = [ln for ln in lines if ln.startswith("{") and ln.endswith("}")]
        self.assertTrue(json_lines, f"Nessuna riga JSON trovata:\n{blob}")
        return json.loads(json_lines[-1])

    def test_configure_printer_rejects_invalid_enums(self):
        with self.assertRaises(ValueError):
            printer.configure_printer(
                debugging_mode=DebuggingMode.DEBUG,
                custom_logs_prefix=True,
                session_id_prefix=True,
                stacktrace_mode="nope",  # type: ignore[arg-type]
            )
        with self.assertRaises(ValueError):
            printer.configure_printer(
                debugging_mode=DebuggingMode.DEBUG,
                custom_logs_prefix=True,
                session_id_prefix=True,
                default_output_type="nope",  # type: ignore[arg-type]
            )

    def test_log_code_invalid_values_fallback(self):
        # fuori range / tipo errato -> fallback per level
        self.assertEqual(get_log_code("INFO", "x", log_code=99), 200)
        self.assertEqual(get_log_code("ERROR", "x", log_code=1000), 500)
        self.assertEqual(get_log_code("INFO", "x", properties={"log_code": "x"}), 200)
        self.assertEqual(get_log_code("WARNING", "x", properties={"log_code": 50}), 400)
        # alias status_code fuori range -> ignorato e fallback
        self.assertEqual(get_log_code("ERROR", "x", properties={"status_code": 12}), 500)

    def test_load_log_code_config_json_invalid_payload(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=True) as f:
            f.write("[1,2,3]")
            f.flush()
            with self.assertRaises(ValueError):
                load_log_code_config_json(f.name)

    def test_load_log_code_config_json_missing_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            load_log_code_config_json("/path/that/does/not/exist/log_codes.json")

    def test_stacktrace_in_structured_when_exception_active(self):
        p = Printer(DebuggingMode.DEBUG, name="E", use_structured_logging=True)
        streams = attach_logger_streams(p.logger)

        try:
            raise RuntimeError("boom")
        except RuntimeError:
            p.error("failed", output_type="log", log_code=500)

        entry = self._last_json_any_stream(streams)
        self.assertEqual(entry["log_code"], 500)
        self.assertIn("exception", entry)
        self.assertIn("stack_trace", entry["exception"])
        self.assertIn("exception_type", entry["exception"])

    def test_stacktrace_off_does_not_add_exception(self):
        p = Printer(
            DebuggingMode.DEBUG,
            name="E2",
            use_structured_logging=True,
            stacktrace_mode="off",
        )
        streams = attach_logger_streams(p.logger)

        try:
            raise RuntimeError("boom")
        except RuntimeError:
            p.error("failed", output_type="log", log_code=500)

        entry = self._last_json_any_stream(streams)
        self.assertEqual(entry["log_code"], 500)
        self.assertNotIn("exception", entry)


