from __future__ import annotations

import json
import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams


ensure_src_on_path()

from printer import Printer, DebuggingMode  # noqa: E402


class TestEmojiAndCodeName(unittest.TestCase):
    def _last_json(self, out: str) -> dict:
        lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
        json_lines = [ln for ln in lines if ln.startswith("{") and ln.endswith("}")]
        self.assertTrue(json_lines, f"Nessuna riga JSON trovata:\n{out}")
        return json.loads(json_lines[-1])

    def test_emoji_and_code_name_used_in_text_and_structured(self):
        p = Printer(
            DebuggingMode.DEBUG,
            name="ECN",
            use_structured_logging=True,
            emoji_by_code={201: "🟦"},
            name_by_code={201: "OKISH"},
        )
        streams = attach_logger_streams(p.logger)

        p.info("hello", output_type="log", log_code=201)
        out = streams.stdout.getvalue()

        # INFO ha due spazi dopo emoji per compatibilità storica
        self.assertIn("🟦  INFO: hello", out)

        entry = self._last_json(out)
        self.assertEqual(entry["log_code"], 201)
        self.assertEqual(entry.get("emoji"), "🟦")
        self.assertEqual(entry.get("code_name"), "OKISH")

    def test_use_emoji_false_disables_emoji_in_text_and_structured(self):
        p = Printer(
            DebuggingMode.DEBUG,
            name="ECN2",
            use_structured_logging=True,
            emoji_by_code={201: "🟦"},
        )
        streams = attach_logger_streams(p.logger)

        p.info("hello", output_type="log", log_code=201, use_emoji=False)
        out = streams.stdout.getvalue()
        self.assertIn("INFO: hello", out)
        self.assertNotIn("🟦", out)

        entry = self._last_json(out)
        self.assertNotIn("emoji", entry)


