from __future__ import annotations

import unittest

from tests.helpers import ensure_src_on_path


ensure_src_on_path()

from printer.utils.log_codes import (  # noqa: E402
    LogCode,
    log_code_config_from_dict,
    make_log_code_resolver,
    get_log_code,
)


class TestLogCodes(unittest.TestCase):
    def test_default_fallback_by_level(self):
        self.assertEqual(get_log_code("INFO", "x"), LogCode.OK)
        self.assertEqual(get_log_code("WARNING", "x"), LogCode.CLIENT_ERROR)
        self.assertEqual(get_log_code("ERROR", "x"), LogCode.SERVER_ERROR)
        self.assertEqual(get_log_code("CRITICAL", "x"), LogCode.SERVER_ERROR)
        self.assertEqual(get_log_code("SUCCESS", "x"), LogCode.OK)

    def test_explicit_log_code_wins(self):
        resolver = make_log_code_resolver()
        self.assertEqual(resolver("INFO", "x", 201, None, None, {}), 201)
        # anche via properties
        self.assertEqual(resolver("INFO", "x", None, None, None, {"log_code": 202}), 202)

    def test_status_code_alias_still_works(self):
        resolver = make_log_code_resolver()
        self.assertEqual(resolver("INFO", "x", None, None, None, {"status_code": 203}), 203)
        self.assertEqual(resolver("INFO", "x", None, None, None, {}, status_code=204), 204)
        self.assertEqual(get_log_code("INFO", "x", status_code=205), 205)

    def test_category_state_phase_mapping(self):
        cfg = log_code_config_from_dict(
            {
                "categories": {"request_received": 101},
                "states": {"init": 111},
                "phases": {"boot": 121},
            }
        )
        resolver = make_log_code_resolver(cfg)

        # category (solo da properties) vince su state/phase
        self.assertEqual(
            resolver("INFO", "x", None, None, None, {"category": "REQUEST_RECEIVED"}), 101
        )
        # state (arg o properties)
        self.assertEqual(resolver("INFO", "x", None, None, "init", {}), 111)
        self.assertEqual(resolver("INFO", "x", None, None, None, {"state": "init"}), 111)
        # phase
        self.assertEqual(resolver("INFO", "x", None, "boot", None, {}), 121)
        self.assertEqual(resolver("INFO", "x", None, None, None, {"phase": "boot"}), 121)


