from __future__ import annotations

import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams, capture_print_streams


ensure_src_on_path()

from printer import PrinterBase, DebuggingMode  # noqa: E402
from printer.utils.session import session_id_var  # noqa: E402


class TestPrinterBase(unittest.TestCase):
    def tearDown(self) -> None:
        # evita contaminazioni tra test
        session_id_var.set(None)

    def test_prefixes_include_custom_session_and_log_code(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="T")
        streams = attach_logger_streams(p.logger)

        session_id_var.set("abc")
        p.info("hello", output_type="log", force=True)

        out, err = streams.getvalue()
        self.assertEqual(err.strip(), "")
        self.assertIn("[CUSTOM_LOGS]", out)
        self.assertIn("[SES-ID-abc]", out)
        self.assertIn("[200]", out)
        self.assertIn("INFO: hello", out)

    def test_can_disable_prefixes(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="T2", custom_logs_prefix=False, session_id_prefix=False)
        streams = attach_logger_streams(p.logger)

        session_id_var.set("abc")
        p.info("hello", output_type="log", force=True)
        out, _ = streams.getvalue()

        self.assertNotIn("[CUSTOM_LOGS]", out)
        self.assertNotIn("SES-ID-", out)
        self.assertIn("[200]", out)

    def test_debugging_mode_filters_by_default(self):
        # NORMAL: mostra solo WARNING+
        p = PrinterBase(DebuggingMode.NORMAL, name="T3")
        streams = attach_logger_streams(p.logger)

        p.info("hidden", output_type="log")  # no force
        out, err = streams.getvalue()
        self.assertEqual(out.strip(), "")
        self.assertEqual(err.strip(), "")

        p.warning("visible", output_type="log")
        out, _ = streams.getvalue()
        self.assertIn("WARNING: visible", out)

    def test_output_type_log_emits_via_logger(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="T4", default_output_type="log")
        streams = attach_logger_streams(p.logger)

        p.info("hello")  # default_output_type=log
        out, _ = streams.getvalue()
        self.assertIn("INFO: hello", out)

    def test_error_goes_to_stderr_when_printing(self):
        p = PrinterBase(DebuggingMode.DEBUG, name="T5")

        with capture_print_streams() as streams:
            p.error("boom", force=True)  # path print -> stderr
            out, err = streams.getvalue()
        self.assertEqual(out.strip(), "")
        self.assertIn("ERROR: boom", err)


