from __future__ import annotations

import json
import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams


ensure_src_on_path()

import printer  # noqa: E402
from printer import DebuggingMode  # noqa: E402


class TestApiFacade(unittest.TestCase):
    def tearDown(self) -> None:
        printer.reset_printer()

    def _last_json(self, stdout: str) -> dict:
        lines = [ln.strip() for ln in stdout.splitlines() if ln.strip()]
        json_lines = [ln for ln in lines if ln.startswith("{") and ln.endswith("}")]
        self.assertTrue(json_lines, f"Nessuna riga JSON trovata:\n{stdout}")
        return json.loads(json_lines[-1])

    def test_singleton_lifecycle(self):
        self.assertFalse(printer.is_configured())
        with self.assertRaises(RuntimeError):
            printer.get_printer()

        p = printer.configure_printer(
            debugging_mode=DebuggingMode.DEBUG,
            custom_logs_prefix=True,
            session_id_prefix=True,
            name="Facade",
            use_structured_logging=True,
        )
        self.assertTrue(printer.is_configured())
        self.assertIs(printer.get_printer(), p)

        printer.reset_printer()
        self.assertFalse(printer.is_configured())

    def test_facade_forwards_log_code_and_alias(self):
        p = printer.configure_printer(
            debugging_mode=DebuggingMode.DEBUG,
            custom_logs_prefix=True,
            session_id_prefix=True,
            name="Facade",
            use_structured_logging=True,
            default_output_type="log",
        )
        streams = attach_logger_streams(p.logger)

        printer.info("hello", output_type="log", log_code=301)
        entry = self._last_json(streams.stdout.getvalue())
        self.assertEqual(entry["log_code"], 301)

        printer.info("alias", output_type="log", status_code=302)
        entry2 = self._last_json(streams.stdout.getvalue())
        self.assertEqual(entry2["log_code"], 302)


