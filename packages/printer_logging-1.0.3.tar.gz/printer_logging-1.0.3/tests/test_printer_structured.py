from __future__ import annotations

import json
import unittest

from tests.helpers import ensure_src_on_path, attach_logger_streams


ensure_src_on_path()

from printer import Printer, DebuggingMode  # noqa: E402
from printer.loggers.entry import PropertiesPolicy  # noqa: E402
from printer.utils.session import session_id_var  # noqa: E402


class TestPrinterStructured(unittest.TestCase):
    def tearDown(self) -> None:
        session_id_var.set(None)

    def _last_json_line(self, stdout: str) -> dict:
        lines = [ln.strip() for ln in stdout.splitlines() if ln.strip()]
        # ci aspettiamo una linea "testuale" + una JSON
        json_lines = [ln for ln in lines if ln.startswith("{") and ln.endswith("}")]
        self.assertTrue(json_lines, f"Nessuna riga JSON trovata in output:\n{stdout}")
        return json.loads(json_lines[-1])

    def test_structured_schema_and_logger_name_update(self):
        p = Printer(DebuggingMode.DEBUG, name="A", use_structured_logging=True)
        streams = attach_logger_streams(p.logger)

        session_id_var.set("s1")
        p.info("hello", output_type="log", log_code=201, state="init", phase="boot", category="X")
        entry1 = self._last_json_line(streams.stdout.getvalue())
        self.assertEqual(entry1["logger"], "A")
        self.assertEqual(entry1["level"], "INFO")
        self.assertEqual(entry1["message"], "hello")
        self.assertEqual(entry1["log_code"], 201)
        self.assertEqual(entry1.get("session_id"), "s1")
        self.assertIn("custom_logs_prefix", entry1)
        self.assertEqual(entry1["context"]["state"], "init")
        self.assertEqual(entry1["context"]["phase"], "boot")
        self.assertEqual(entry1["context"]["category"], "X")

        p.set_logger_name("B")
        p.info("after", output_type="log", log_code=202)
        entry2 = self._last_json_line(streams.stdout.getvalue())
        self.assertEqual(entry2["logger"], "B")
        self.assertEqual(entry2["log_code"], 202)

    def test_properties_policy_allowlist_and_redaction(self):
        policy = PropertiesPolicy(
            allowlist_keys=frozenset({"user", "token", "misc"}),
            redact_keys=frozenset({"token"}),
            redaction_value="***",
        )
        p = Printer(
            DebuggingMode.DEBUG,
            name="P",
            use_structured_logging=True,
            structured_properties_policy=policy,
        )
        streams = attach_logger_streams(p.logger)

        p.info(
            "hello",
            output_type="log",
            log_code=210,
            user="u1",
            token="secret",
            misc={"a": 1},
            dropped="nope",
        )
        entry = self._last_json_line(streams.stdout.getvalue())
        props = entry.get("properties") or {}
        self.assertEqual(props.get("user"), "u1")
        self.assertEqual(props.get("token"), "***")
        self.assertEqual(props.get("misc"), {"a": 1})
        self.assertNotIn("dropped", props)

    def test_reserved_keys_do_not_end_up_in_properties(self):
        p = Printer(DebuggingMode.DEBUG, name="R", use_structured_logging=True)
        streams = attach_logger_streams(p.logger)

        p.info(
            "hello",
            output_type="log",
            log_code=220,
            phase="p1",
            state="s1",
            raw_message="should_not_override",
            emoji="X",
            # non deve esplodere (collisione sanitizzata) e non deve finire in properties
            level_name="HACK",
            log_level=999,
            error_stream=True,
            code_name="HACK",
            stack_trace="trace",
        )
        entry = self._last_json_line(streams.stdout.getvalue())
        props = entry.get("properties") or {}
        # le chiavi riservate vengono elevate/ignorate, non devono finire in properties extra
        for k in (
            "log_code",
            "status_code",
            "phase",
            "state",
            "raw_message",
            "level_name",
            "emoji",
            "output_type",
            "code_name",
            "stack_trace",
            "log_level",
            "error_stream",
        ):
            self.assertNotIn(k, props)


