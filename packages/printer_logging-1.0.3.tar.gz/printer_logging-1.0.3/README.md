## Printer

Libreria Python per **logging/stampa formattata** con:

- **prefissi coerenti** (custom logs, session id, log_code)
- **filtro di visibilità** tramite `DebuggingMode`
- output su **stdout/stderr** oppure via `logging.Logger` (`output_type="print" | "log"`)
- **log strutturati JSON** opzionali (structured logging) quando `use_structured_logging=True`
- risoluzione **generalizzata** di `log_code` (fallback 200/400/500 + mapping via JSON su `category/state/phase`)

Requisiti: **Python >= 3.9**

---

### Installazione

#### Sviluppo (editable)

```bash
cd /path/to/printer
python -m venv .venv
.venv/bin/python -m pip install -U pip
.venv/bin/python -m pip install -e . --no-deps
```

#### Comandi rapidi (Makefile)

Se hai `make` disponibile:

```bash
make test
make coverage
make clean
make wheel
make release-local
```

#### Build wheel

```bash
.venv/bin/python -m pip wheel . -w dist --no-deps
```

#### Installazione da wheel (consumo)

```bash
python -m pip install dist/printer-*.whl
```

---

### Quickstart (uso diretto)

```python
from printer import Printer, DebuggingMode, set_session_id

set_session_id("abc-123")

p = Printer(
    debugging_mode=DebuggingMode.DEBUG,
    name="MyApp",
    use_structured_logging=False,
)

p.info("Hello")                      # default: print
p.warning("Bad request", log_code=400)
p.error("Boom", log_code=500)
```

---

### Quickstart (API funzionale / singleton)

Se preferisci usare funzioni tipo `printer.info(...)`, devi prima configurare il singleton.

```python
import printer
from printer import DebuggingMode

printer.configure_printer(
    debugging_mode=DebuggingMode.DEBUG,
    custom_logs_prefix=True,
    session_id_prefix=True,
    name="MyApp",
    use_structured_logging=True,
    default_output_type="log",
)

printer.info("Hello", log_code=200, category="REQUEST_RECEIVED")
```

Note:
- se chiami `printer.info(...)` senza configurare, viene sollevato `RuntimeError`.
- `reset_printer()` è utile nei test.

---

### Concetti chiave

#### `DebuggingMode`

Controlla la visibilità dei log:
- `NORMAL`: mostra `WARNING`/`ERROR`/`CRITICAL`
- `VERBOSE`: mostra `INFO+` (esclude `DEBUG`)
- `PRODUCTION`: equivalente a `VERBOSE` (esclude `DEBUG`)
- `DEBUG`: mostra tutto

Puoi bypassare la visibilità con `force=True`.

#### `output_type`: `"print"` vs `"log"`

- `output_type="print"`: usa `print(...)` (stdout/stderr)
- `output_type="log"`: usa `logging.Logger` interno (con due handler: stdout < ERROR, stderr >= ERROR)
- se `output_type=None`, viene usato `default_output_type`

#### `session_id`

È gestito via `contextvars`, quindi funziona bene anche in async:

```python
from printer import set_session_id, get_session_id

set_session_id("abc-123")
assert get_session_id() == "abc-123"
```

#### `log_code` (ex `status_code`)

`log_code` è il codice numerico (100–999) usato nei prefissi e nel JSON structured.

- se non lo passi, c’è un fallback standard:
  - `INFO/DEBUG/SUCCESS` → 200
  - `WARNING` → 400
  - `ERROR/CRITICAL` → 500

Compatibilità:
- `status_code` è mantenuto come **alias deprecato** di `log_code`.

---

### Configurazione `log_code` via JSON

Puoi definire mapping e metadati (emoji/nome) in un JSON e passarne il path a `configure_printer(..., log_codes_path=...)`.

Esempio:

```json
{
  "default_by_level": { "INFO": 200, "WARNING": 400, "ERROR": 500 },
  "categories": { "request_received": 101 },
  "states": { "init": 111 },
  "phases": { "boot": 121 },
  "codes": {
    "200": { "name": "OK", "emoji": "🟦" },
    "500": { "name": "SERVER_ERROR", "emoji": "🟥" }
  }
}
```

Regole di priorità (dal più forte al fallback):
1. `log_code` esplicito (argomento o dentro `properties`)
2. `category` (solo da `properties`)
3. `state` (argomento o dentro `properties`, con fallback su `category_codes`)
4. `phase` (argomento o dentro `properties`)
5. fallback per livello (200/400/500)

---

### Structured logging (JSON)

Se `use_structured_logging=True`, **solo quando `output_type="log"`** viene emesso anche un JSON (una riga per evento) con campi tipo:

- `timestamp`, `level`, `logger`, `message`, `log_code`
- `custom_logs_prefix`, `session_id`
- `context` (`state/phase/category`) se presenti
- `exception` (`exception_type`, `exception_message`, `stack_trace`) quando applicabile

Puoi controllare le `properties` extra con `PropertiesPolicy` (allowlist/redaction/transformer).

#### Stack trace automatico

Per `ERROR/CRITICAL`, se c’è un’eccezione attiva e `stacktrace_mode="exception_only"` (default), vengono aggiunti campi in `exception` (structured) e/o una sezione `stack_trace` (testuale).
Imposta `stacktrace_mode="off"` per disabilitare.

---

### Test

Esecuzione suite:

```bash
python -m unittest -q
```

Line coverage (stdlib `trace`):

```bash
rm -rf .trace_cov && mkdir -p .trace_cov
python -m trace --count --missing --coverdir .trace_cov --module unittest -q
```

---

### API Reference (principali)

#### Import consigliati

```python
from printer import (
    Printer,
    PrinterBase,
    DebuggingMode,
    PrinterConfig,
    PropertiesPolicy,
    set_session_id,
    get_session_id,
)
import printer  # facade/singleton
```

#### `Printer` (classe completa)

Costruttore (parametri principali):
- `debugging_mode: DebuggingMode`
- `name: str = "Printer"`
- `use_structured_logging: bool = False`
- `log_code_resolver: callable | None`
- `emoji_by_code: Mapping[int, str] | None`
- `name_by_code: Mapping[int, str] | None`
- `custom_logs_prefix: str | bool = True`
- `session_id_prefix: str | bool = True`
- `stacktrace_mode: Literal["off", "exception_only"] = "exception_only"`
- `default_output_type: Literal["print", "log"] = "print"`
- `structured_properties_policy: PropertiesPolicy | None`

Metodi di livello:
- `debug/info/warning/error/critical/success(message, output_type=None, log_code=None, state=None, force=False, use_emoji=True, **properties)`
  - **alias**: `status_code` (deprecato) al posto di `log_code`
  - `category/phase/state` possono stare in `**properties` e influenzano la risoluzione del `log_code`

Metodi utility:
- `header(message, char="=", length=80, force=False, **properties)`
- `section(title, content, force=False)`
- `custom(message, prefix="➡️", force=False)`
- `plain(message, force=False)`

Note:
- alcune chiavi riservate non vengono propagate dentro `properties` (es. `log_code`, `status_code`, `raw_message`, `emoji`, ecc.)
- se passi chiavi “interne” in `**properties` (es. `level_name/log_level/error_stream`), vengono ignorate per evitare errori

#### `PrinterBase` (core)

È la base che gestisce:
- filtro `DebuggingMode`
- prefissi (`custom_logs_prefix`, `session_id_prefix`, `[XYZ]`)
- output `print`/`log` e handler stdout/stderr

È utile se vuoi solo output testuale senza structured.

#### Facade / singleton (`import printer`)

Funzioni principali:
- `configure_printer(...) -> Printer`
- `configure_printer_config(config: PrinterConfig) -> Printer`
- `get_printer() -> Printer` (alza `RuntimeError` se non configurato)
- `set_printer(p: Printer) -> None`
- `is_configured() -> bool`
- `reset_printer() -> None`
- `set_logger_name(name: str) -> None`
- `set_debugging_mode(mode: DebuggingMode) -> None`
- `debug/info/warning/error/critical/success/header/section/custom/plain(...)`

---

### FAQ / Troubleshooting

#### “Non vedo nulla in output”
- controlla `DebuggingMode`: in `NORMAL` non stampa `INFO/DEBUG` (usa `VERBOSE/DEBUG` o `force=True`)
- se stai usando `output_type="log"`, verifica che il logger non venga filtrato da handler/level esterni

#### “I log structured JSON non escono”
- devi avere **entrambi**:
  - `use_structured_logging=True`
  - `output_type="log"` (o `default_output_type="log"`)

#### “Vedo righe duplicate”
- evita di aggiungere handler esterni allo stesso `logging.Logger` usato da `Printer`
- `PrinterBase` imposta `logger.propagate = False` per evitare duplicazioni via root logger

#### “Voglio cambiare/disabilitare i prefissi”
- `custom_logs_prefix=False` disabilita `[CUSTOM_LOGS]` (oppure una stringa per usare un prefisso custom)
- `session_id_prefix=False` disabilita `[SES-ID-...]` (oppure stringa per cambiare prefisso)

#### “Perché non vedo `session_id`?”
- `session_id` è per-contesto (`contextvars`): devi chiamare `set_session_id(...)` nel contesto corretto (thread/task)
- assicurati che `session_id_prefix` non sia `False`

#### “Non voglio stack trace automatici”
- usa `stacktrace_mode="off"`

---

### License

Questo progetto è **proprietario**. Vedi il file `LICENSE`.

---

### Changelog

Vedi `CHANGELOG.md`.

---

### Contributing

Vedi `CONTRIBUTING.md` (uso interno).


