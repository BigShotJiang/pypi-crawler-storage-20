"""Pipeline package for Bijux Agent.

The preferred entrypoint is the AuditableDocPipeline; the Pipeline remains
available for internal experiments.
"""

from __future__ import annotations

from .canonical import AuditableDocPipeline
from .definition import PipelineDefinition
from .pipeline import Pipeline

__all__ = [
    "AuditableDocPipeline",
    "Pipeline",
    "PipelineDefinition",
]
