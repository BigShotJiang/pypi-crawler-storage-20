# Advaita

> Philosophy expressed as code. Minimal. Sharp. Clear.

`advaita` is a minimalist Python library that brings the clarity of Advaita Vedanta and the teachings of Acharya Prashant into your terminal.

## Installation

```bash
pip install advaita
```

## Usage

### In Python

```python
import advaita

# Experience the silence
quote = advaita.silence()
print(quote)

# Seek clarity
print(advaita.clarity())
```

### CLI

```bash
advaita
```

## Philosophy

Advaita (non-duality) suggests that the observer and the observed are one. This library is a reminder of that simplicity. No dependencies. No complexity. Just truth.
