from advaita import silence, clarity

def test_silence():
    quote = silence()
    assert isinstance(quote, str)
    assert len(quote) > 0

def test_clarity():
    quote = clarity()
    assert isinstance(quote, str)
    assert len(quote) > 0

if __name__ == "__main__":
    print("Testing silence...")
    test_silence()
    print("Testing clarity...")
    test_clarity()
    print("All tests passed with clarity.")
