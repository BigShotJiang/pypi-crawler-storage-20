import random

QUOTES = [
    "Neti, neti. (Not this, not that.)",
    "The observer is the observed.",
    "Clarity is the absence of the 'me'.",
    "Truth is not something to be achieved; it is what remains when the false is dropped.",
    "Silence is the most powerful speech.",
    "You are not the mind; you are the one aware of the mind.",
    "The world is as you are.",
    "Freedom is the ability to see things as they are, without the interference of the past.",
    "Action born out of clarity is non-binding.",
    "The ego is a bundle of memories and identification.",
    "Understanding is the only transformation.",
    "Don't seek the truth. Just drop the lies.",
    "Realization is not a new acquisition; it is a discovery of the eternal.",
    "The root of all suffering is the belief in a separate self.",
    "Awareness is the fire that burns through the conditioning."
]

def silence():
    """Returns a random quote from the void."""
    return random.choice(QUOTES)

def clarity():
    """An alias for silence, focusing on the result of seeing."""
    return silence()
