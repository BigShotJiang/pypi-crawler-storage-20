import sys
from .quotes import silence

def main():
    """Entry point for the CLI."""
    print(f"\n  ✨ {silence()}\n")

if __name__ == "__main__":
    main()
