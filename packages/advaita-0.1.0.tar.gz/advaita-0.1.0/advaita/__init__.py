from .quotes import silence, clarity

__all__ = ["silence", "clarity"]

__version__ = "0.1.0"
