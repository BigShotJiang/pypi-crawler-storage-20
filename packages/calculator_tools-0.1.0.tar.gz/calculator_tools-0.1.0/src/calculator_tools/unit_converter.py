# src/calculator_tools/unit_converter.py
"""单位转换工具"""


def celsius_to_fahrenheit(celsius: float) -> float:
    """
    摄氏度转华氏度

    Formula: °F = (°C × 9/5) + 32

    Args:
        celsius: 摄氏度温度

    Returns:
        华氏度温度
    """
    return (celsius * 9 / 5) + 32


def meter_to_feet(meters: float) -> float:
    """
    米转英尺

    Formula: feet = meters × 3.28084

    Args:
        meters: 米

    Returns:
        英尺
    """
    return meters * 3.28084


def kg_to_pound(kg: float) -> float:
    """千克转磅（1 kg = 2.20462 pounds）"""
    return kg * 2.20462
