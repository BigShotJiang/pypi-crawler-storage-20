# src/calculator_tools/__init__.py
"""
calculator_tools - 一个实用的计算器工具包

提供基本的数学计算、单位转换等功能。
"""

__version__ = "0.1.0"
__author__ = "李朋飞"
__email__ = "mainapbind@163.com"

# 公开的 API（用户可以直接导入的函数/类）
from .basic_calculator import add, subtract, multiply, divide
from .unit_converter import celsius_to_fahrenheit, meter_to_feet

# 使用 __all__ 明确导出内容
__all__ = [
    "add",
    "subtract",
    "multiply",
    "divide",
    "celsius_to_fahrenheit",
    "meter_to_feet",
]
