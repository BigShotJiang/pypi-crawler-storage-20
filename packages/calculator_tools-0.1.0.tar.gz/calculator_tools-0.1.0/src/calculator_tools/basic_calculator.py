# src/calculator_tools/basic_calculator.py
"""基础数学计算模块"""


def add(a: float, b: float) -> float:
    """
    两数相加

    Args:
        a: 第一个数
        b: 第二个数

    Returns:
        两数之和

    Example:
        >>> add(2, 3)
        5.0
    """
    return float(a + b)


def subtract(a: float, b: float) -> float:
    """两数相减"""
    return float(a - b)


def multiply(a: float, b: float) -> float:
    """两数相乘"""
    return float(a * b)


def divide(a: float, b: float) -> float:
    """
    两数相除

    Raises:
        ZeroDivisionError: 除数为零时抛出
    """
    if b == 0:
        raise ZeroDivisionError("除数不能为零")
    return float(a / b)
