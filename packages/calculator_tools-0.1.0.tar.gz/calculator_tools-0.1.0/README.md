# Calculator Tools

一个实用的 Python 计算器工具包，提供基础数学计算和单位转换功能。

## ✨ 特性

- 🧮 基础数学运算（加减乘除）
- 🌡️ 温度单位转换（摄氏度↔华氏度）
- 📏 长度单位转换（米↔英尺）
- ⚖️ 重量单位转换（千克↔磅）
- 🐍 纯 Python 实现，无额外依赖

## 📦 安装

```bash
pip install calculator-tools