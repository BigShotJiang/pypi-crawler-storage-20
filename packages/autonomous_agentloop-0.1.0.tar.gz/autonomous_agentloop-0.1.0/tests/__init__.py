"""Tests for AgentLoop."""

