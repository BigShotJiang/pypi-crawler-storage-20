"""
Channel position and permission monitoring - background task.
"""
import discord
import asyncio
import json
from pathlib import Path
from typing import List, Tuple, Dict, Any, Union

class ChannelPositionMonitor:
    """
    Utility to check and restore channel positions and permissions.
    Triggered by events instead of a background loop.
    """
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_dir = sdk.backup_dir
        self.enabled = True
    
    def start(self):
        """Start method (kept for backward compatibility, but does nothing now)"""
        print("🔍 Channel Monitor: Ready (Event-driven)")
    
    def stop(self):
        """Stop method (kept for backward compatibility)"""
        pass
    
    async def fix_guild_channels(self, guild: discord.Guild):
        """Check and restore channel positions/permissions for a guild"""
        try:
            # Get backup from manager's cache (source of truth)
            backup = await self.sdk.backup_manager._get_cached_backup(guild.id, "channels")
            if not backup:
                return
            
            # Build current snapshot {channel_id: channel_obj}
            current_channels = {c.id: c for c in guild.channels}
            
            # Iterate through BACKUP channels (the source of truth)
            for ch_data in backup["channels"]:
                channel_id = ch_data["id"]
                channel = current_channels.get(channel_id)
                
                # 1. Missing Channel Detection
                if not channel:
                    # In event-driven mode, missing channels are handled by on_channel_delete handler
                    continue
                
                # 2. Check Position
                if channel.position != ch_data["position"]:
                    try:
                        await channel.edit(position=ch_data["position"], reason="SecureX: Auto-restoring position")
                    except Exception:
                        pass
                
                # 3. Check Category
                expected_cat_id = ch_data.get("category_id")
                current_cat_id = channel.category.id if channel.category else None
                
                if expected_cat_id != current_cat_id:
                    try:
                        if expected_cat_id:
                            category = guild.get_channel(expected_cat_id)
                            if category and isinstance(category, discord.CategoryChannel):
                                await channel.edit(category=category, reason="SecureX: Auto-restoring category")
                        else:
                            await channel.edit(category=None, reason="SecureX: Auto-restoring category")
                    except Exception:
                        pass

                # 4. Check Permissions (Simplified)
                backup_perms = ch_data.get("permissions", {})
                if len(channel.overwrites) != len(backup_perms):
                    try:
                         await self.sdk.backup_manager.restore_channel_permissions(guild, channel.id)
                    except Exception:
                        pass
                
        except Exception as e:
            # print(f"Error checking guild {guild.id}: {e}")
            pass
