"""
Role position monitoring - background task that checks every 5 seconds.
"""
import discord
import asyncio
import json
from pathlib import Path
from typing import List, Tuple


class RolePositionMonitor:
    """
    Utility to check and restore role positions.
    Triggered by events instead of a background loop.
    """
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_dir = sdk.backup_dir
        self.enabled = True
    
    def start(self):
        """Start method (kept for backward compatibility)"""
        print("🔍 Role Position Monitor: Ready (Event-driven)")
    
    def stop(self):
        """Stop method (kept for backward compatibility)"""
        pass
    
    async def fix_guild_roles(self, guild: discord.Guild):
        """Check and restore role positions for a specific guild"""
        try:
            # Get backup from manager's cache
            backup = await self.sdk.backup_manager._get_cached_backup(guild.id, "roles")
            if not backup:
                return
            
            # Use guild.roles snapshot for efficient lookup
            current_roles = {role.id: role for role in guild.roles}
            
            # Collect all mismatched roles
            role_position_pairs: List[Tuple[discord.Role, int]] = []
            
            for role_data in backup["roles"]:
                role = current_roles.get(role_data["id"])
                if not role:
                    continue  # Role was deleted
                
                # Check if position matches
                if role.position != role_data["position"]:
                    role_position_pairs.append((role, role_data["position"]))
            
            # If we found mismatches, restore using bulk endpoint
            if role_position_pairs:
                try:
                    positions_dict = {
                        role: expected_pos
                        for role, expected_pos in role_position_pairs
                    }
                    
                    await guild.edit_role_positions(
                        positions=positions_dict,
                        reason="SecureX: Bulk position restore"
                    )
                except Exception as e:
                    # Fallback to individual updates
                    await self._fallback_individual_updates(guild, role_position_pairs)
        
        except Exception as e:
            pass
    
    async def _fallback_individual_updates(self, guild: discord.Guild, role_position_pairs: List[Tuple[discord.Role, int]]):
        """Fallback to individual role updates if bulk fails"""
        for role, expected_pos in role_position_pairs:
            try:
                await role.edit(position=expected_pos, reason="SecureX: Position restore")
                await asyncio.sleep(0.3)
            except Exception:
                pass

    async def _load_guild_cache(self, guild_id: int):
        """Load role positions from backup into cache"""
        pass  # Handled by BackupManager now
    
    async def preload_all(self):
        """Preload all role positions into cache on startup"""
        pass # Handled by BackupManager.preload_all()
    
    def update_cache(self, guild_id: int):
        """Update cache after role backup"""
        pass # Handled by BackupManager
