"""Internal core utilities."""
