"""Synchronous Codacle Graph SDK client."""

from __future__ import annotations

from typing import Any

from .._core._http import HttpClient
from .._core._validation import detect_write_operation
from ..exceptions import ForbiddenError, NotFoundError
from ..models.nodes import (
    ApplicationNode,
    AttributeNode,
    BaseNode,
    ClassNode,
    ClientNode,
    ModuleNode,
    ObjectNode,
    SubroutineNode,
)
from ..models.relationships import (
    BaseRelationship,
    ContainsImports,
    DefinesAttribute,
    DefinesMethod,
    HasApplication,
    HasClass,
    HasModule,
    HasSubroutine,
    InheritsFrom,
    Triggers,
    parse_relationship,
)
from ..models.requests import (
    ApiKeyCreateRequest,
    ApiKeyUpdateRequest,
    BulkInsertRequest,
    CypherQueryRequest,
    Neo4jCredentialsRequest,
    NodeData,
    RelationshipData,
)
from ..models.responses import (
    ApiKeyCreateResponse,
    ApiKeyListResponse,
    ApiKeyUpdateResponse,
    BulkInsertResponse,
    CredentialSaveResponse,
    CypherQueryResponse,
    DeleteResponse,
    DriverPoolStats,
    HealthResponse,
    Neo4jCredentialsResponse,
)


def _escape_cypher_string(value: str) -> str:
    """Escape special characters for Cypher string literals."""
    return value.replace("\\", "\\\\").replace("'", "\\'")


def _build_property_map(props: dict[str, Any]) -> str:
    """Build Cypher property map string from dict."""
    if not props:
        return ""
    parts = []
    for key, value in props.items():
        if value is None:
            continue
        escaped_key = _escape_cypher_string(key)
        if isinstance(value, str):
            parts.append(f"`{escaped_key}`: '{_escape_cypher_string(value)}'")
        elif isinstance(value, bool):
            parts.append(f"`{escaped_key}`: {str(value).lower()}")
        elif isinstance(value, int | float):
            parts.append(f"`{escaped_key}`: {value}")
        elif isinstance(value, list):
            items = [f"'{_escape_cypher_string(str(v))}'" for v in value]
            parts.append(f"`{escaped_key}`: [{', '.join(items)}]")
        else:
            escaped_val = _escape_cypher_string(str(value))
            parts.append(f"`{escaped_key}`: '{escaped_val}'")
    return "{" + ", ".join(parts) + "}" if parts else ""


class Client:
    """
    Synchronous client for Codacle Graph Service.

    Args:
        url: Base URL of the Codacle Graph Service.
        api_key: API key for authentication.
        alias: Default Neo4j instance alias (optional).
        timeout: Request timeout in seconds (default: 30).
        read_only: If True (default), blocks write operations (CREATE, DELETE,
            MERGE, SET, REMOVE, etc.) client-side before sending to server.
            Set to False to enable write operations.

    Raises:
        AuthenticationError: If API key is missing, empty, or contains
            invalid characters (null bytes, non-latin1 unicode).

    Example:
        >>> # Read-only by default (safe)
        >>> client = Client(
        ...     url="https://api.codacle.com",
        ...     api_key="your-api-key",
        ...     alias="production-db",
        ... )
        >>> result = client.cypher_query("MATCH (c:Class) RETURN c")
        >>> for node in result.get_nodes():
        ...     print(node.name)

        >>> # Enable writes explicitly
        >>> client = Client(api_key="your-key", read_only=False)
        >>> client.cypher_query("CREATE (n:Test) RETURN n")
    """

    def __init__(
        self,
        url: str,
        api_key: str,
        alias: str | None = None,
        timeout: float = 30.0,
        read_only: bool = True,
    ):
        self._http = HttpClient(url, api_key, timeout)
        self._default_alias = alias
        self._read_only = read_only

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the HTTP client."""
        self._http.close()

    def _resolve_alias(self, alias: str | None) -> str | None:
        """Use provided alias or fall back to default."""
        return alias if alias is not None else self._default_alias

    # -------------------------------------------------------------------------
    # Query Operations
    # -------------------------------------------------------------------------

    def cypher_query(
        self,
        query: str,
        alias: str | None = None,
        neo4j_uri: str | None = None,
    ) -> CypherQueryResponse:
        """
        Execute Cypher query, stored query (by name/ID), or natural language.

        Args:
            query: Cypher query, stored query name/ID, or natural language.
            alias: Neo4j instance alias.
            neo4j_uri: Direct Neo4j URI.

        Returns:
            Query response with results.

        Raises:
            ForbiddenError: If read_only=True and query contains write ops.
            ValidationError: If query is empty or contains invalid characters.
            Neo4jQueryError: If query execution fails.
        """
        # Check read-only mode (enabled by default)
        if self._read_only and detect_write_operation(query):
            raise ForbiddenError(
                "Write operations are not allowed in read-only mode. "
                f"Detected write operation in query: {query[:50]}... "
                "Set read_only=False to enable write operations.",
                status_code=403,
            )

        data = self._http.post(
            "/api/v1/cypher-query",
            json=CypherQueryRequest(
                query=query,
                alias=self._resolve_alias(alias),
                neo4j_uri=neo4j_uri,
            ).model_dump(exclude_none=True),
        )
        return CypherQueryResponse.model_validate(data)

    # -------------------------------------------------------------------------
    # Bulk Operations
    # -------------------------------------------------------------------------

    def bulk_insert(
        self,
        nodes: list[NodeData] | None = None,
        relationships: list[RelationshipData] | None = None,
        alias: str | None = None,
        neo4j_uri: str | None = None,
    ) -> BulkInsertResponse:
        """
        Bulk insert nodes and/or relationships.

        Args:
            nodes: List of nodes to create.
            relationships: List of relationships to create.
            alias: Neo4j instance alias.
            neo4j_uri: Direct Neo4j URI.
        """
        data = self._http.post(
            "/api/v1/bulk-insert",
            json=BulkInsertRequest(
                alias=self._resolve_alias(alias),
                neo4j_uri=neo4j_uri,
                nodes=nodes or [],
                relationships=relationships or [],
            ).model_dump(exclude_none=True),
        )
        return BulkInsertResponse.model_validate(data)

    # -------------------------------------------------------------------------
    # Admin: Neo4j Credentials (requires admin API key)
    # -------------------------------------------------------------------------

    def list_credentials(self) -> Neo4jCredentialsResponse:
        """List all Neo4j credentials (admin only)."""
        data = self._http.get("/api/v1/neo4j-credentials")
        return Neo4jCredentialsResponse.model_validate(data)

    def add_credentials(
        self,
        uri: str,
        username: str,
        password: str,
        database: str | None = None,
        alias: str | None = None,
    ) -> CredentialSaveResponse:
        """Store Neo4j credentials (admin only)."""
        data = self._http.post(
            "/api/v1/neo4j-credentials",
            json=Neo4jCredentialsRequest(
                uri=uri,
                username=username,
                password=password,
                database=database,
                alias=alias,
            ).model_dump(exclude_none=True),
        )
        return CredentialSaveResponse.model_validate(data)

    # -------------------------------------------------------------------------
    # Admin: API Keys (requires admin API key)
    # -------------------------------------------------------------------------

    def create_api_key(
        self,
        name: str,
        allowed_aliases: list[str],
    ) -> ApiKeyCreateResponse:
        """Create scoped API key (admin only)."""
        data = self._http.post(
            "/api/v1/permissions",
            json=ApiKeyCreateRequest(
                name=name,
                allowed_aliases=allowed_aliases,
            ).model_dump(),
        )
        return ApiKeyCreateResponse.model_validate(data)

    def list_api_keys(self) -> ApiKeyListResponse:
        """List all API keys (admin only)."""
        data = self._http.get("/api/v1/permissions")
        return ApiKeyListResponse.model_validate(data)

    def update_api_key(
        self,
        identifier: str,
        allowed_aliases: list[str],
    ) -> ApiKeyUpdateResponse:
        """Update API key permissions (admin only)."""
        data = self._http.put(
            f"/api/v1/permissions/{identifier}",
            json=ApiKeyUpdateRequest(
                allowed_aliases=allowed_aliases
            ).model_dump(),
        )
        return ApiKeyUpdateResponse.model_validate(data)

    def delete_api_key(self, identifier: str) -> DeleteResponse:
        """Revoke API key (admin only)."""
        data = self._http.delete(f"/api/v1/permissions/{identifier}")
        return DeleteResponse.model_validate(data)

    # -------------------------------------------------------------------------
    # Monitoring
    # -------------------------------------------------------------------------

    def health(self) -> HealthResponse:
        """Check service health (no auth required)."""
        data = self._http.get("/health")
        return HealthResponse.model_validate(data)

    def driver_pool_stats(self) -> DriverPoolStats:
        """Get Neo4j driver pool statistics (admin only)."""
        data = self._http.get("/api/v1/driver-pool-stats")
        return DriverPoolStats.model_validate(data)

    # -------------------------------------------------------------------------
    # Convenience Methods - Graph Traversals
    # -------------------------------------------------------------------------

    def get_clients(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClientNode]:
        """Get all Client nodes."""
        limit_clause = f" LIMIT {limit}" if limit else ""
        result = self.cypher_query(
            f"MATCH (c:Client) RETURN c{limit_clause}", alias=alias
        )
        return [n for n in result.get_nodes() if isinstance(n, ClientNode)]

    def get_applications(
        self,
        client_name: str | None = None,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ApplicationNode]:
        """Get Application nodes, optionally filtered by client."""
        limit_clause = f" LIMIT {limit}" if limit else ""
        if client_name:
            escaped = _escape_cypher_string(client_name)
            query = (
                f"MATCH (c:Client {{name: '{escaped}'}})"
                f"-[:has_application]->(a:Application) RETURN a{limit_clause}"
            )
        else:
            query = f"MATCH (a:Application) RETURN a{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [
            n for n in result.get_nodes() if isinstance(n, ApplicationNode)
        ]

    def get_modules(
        self,
        application_name: str | None = None,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Get Module nodes, optionally filtered by application."""
        limit_clause = f" LIMIT {limit}" if limit else ""
        if application_name:
            escaped = _escape_cypher_string(application_name)
            query = (
                f"MATCH (app:Application {{name: '{escaped}'}})"
                f"-[:has_module]->(m:Module) RETURN m{limit_clause}"
            )
        else:
            query = f"MATCH (m:Module) RETURN m{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def get_classes_in_module(
        self,
        module_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """Get all classes defined in a module."""
        escaped = _escape_cypher_string(module_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (m:Module {{name: '{escaped}'}})"
            f"-[:has_class]->(c:Class) RETURN c{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_methods_of_class(
        self,
        class_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Get all methods defined in a class."""
        escaped = _escape_cypher_string(class_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class {{name: '{escaped}'}})"
            f"-[:defines_method]->(s:Subroutine) RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        nodes = result.get_nodes()
        return [n for n in nodes if isinstance(n, SubroutineNode)]

    def get_attributes_of_class(
        self,
        class_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[AttributeNode]:
        """Get all attributes defined in a class."""
        escaped = _escape_cypher_string(class_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class {{name: '{escaped}'}})"
            f"-[:defines_attribute]->(a:Attribute) RETURN a{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, AttributeNode)]

    def get_class_hierarchy(
        self,
        class_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """Get inheritance chain (parents) of a class."""
        escaped = _escape_cypher_string(class_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class {{name: '{escaped}'}})"
            f"-[:inherits_from*]->(parent:Class) RETURN parent{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_subroutines_in_module(
        self,
        module_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Get all functions/subroutines in a module."""
        escaped = _escape_cypher_string(module_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (m:Module {{name: '{escaped}'}})"
            f"-[:has_subroutine]->(s:Subroutine) RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        nodes = result.get_nodes()
        return [n for n in nodes if isinstance(n, SubroutineNode)]

    def get_module_imports(
        self,
        module_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Get modules imported by a module."""
        escaped = _escape_cypher_string(module_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (m:Module {{name: '{escaped}'}})"
            f"-[:contains_imports]->(imported:Module) "
            f"RETURN imported{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def get_callers_of_subroutine(
        self,
        subroutine_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Get subroutines that trigger/call this subroutine."""
        escaped = _escape_cypher_string(subroutine_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (caller:Subroutine)-[:triggers]->"
            f"(s:Subroutine {{name: '{escaped}'}}) RETURN caller{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        nodes = result.get_nodes()
        return [n for n in nodes if isinstance(n, SubroutineNode)]

    def get_objects_used_by_subroutine(
        self,
        subroutine_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ObjectNode]:
        """Get objects used by a subroutine."""
        escaped = _escape_cypher_string(subroutine_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine {{name: '{escaped}'}})"
            f"-[:uses]->(o:Object) RETURN o{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ObjectNode)]

    def get_instances_of_class(
        self,
        class_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ObjectNode]:
        """Get all object instances of a class."""
        escaped = _escape_cypher_string(class_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class {{name: '{escaped}'}})"
            f"-[:has_instance]->(o:Object) RETURN o{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ObjectNode)]

    def get_subclasses(
        self,
        class_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """Get classes that inherit from this class."""
        escaped = _escape_cypher_string(class_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (child:Class)-[:inherits_from]->"
            f"(c:Class {{name: '{escaped}'}}) RETURN child{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_full_module_structure(
        self,
        module_name: str,
        alias: str | None = None,
    ) -> dict[str, Any]:
        """
        Get complete module structure with classes, functions, imports.

        Returns dict with keys: 'classes', 'subroutines', 'imports'.
        """
        return {
            "classes": self.get_classes_in_module(module_name, alias=alias),
            "subroutines": self.get_subroutines_in_module(
                module_name, alias=alias
            ),
            "imports": self.get_module_imports(module_name, alias=alias),
        }

    def get_full_class_structure(
        self,
        class_name: str,
        alias: str | None = None,
    ) -> dict[str, Any]:
        """
        Get complete class structure with methods, attributes, hierarchy.

        Returns dict with keys: 'methods', 'attributes', 'parents',
        'children', 'instances'.
        """
        methods = self.get_methods_of_class(class_name, alias=alias)
        attributes = self.get_attributes_of_class(class_name, alias=alias)
        parents = self.get_class_hierarchy(class_name, alias=alias)
        children = self.get_subclasses(class_name, alias=alias)
        instances = self.get_instances_of_class(class_name, alias=alias)
        return {
            "methods": methods,
            "attributes": attributes,
            "parents": parents,
            "children": children,
            "instances": instances,
        }

    # -------------------------------------------------------------------------
    # Convenience Methods - Class Operations
    # -------------------------------------------------------------------------

    def get_all_classes(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Get all Class nodes in the graph.

        Args:
            limit: Maximum number of results (None for unlimited).
            alias: Neo4j instance alias.

        Returns:
            List of ClassNode instances.

        Example:
            >>> classes = client.get_all_classes(limit=100)
            >>> for cls in classes:
            ...     print(f"{cls.name}: abstract={cls.is_abstract}")
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (c:Class) RETURN c{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def find_class_by_name(
        self,
        name: str,
        alias: str | None = None,
    ) -> ClassNode | None:
        """
        Find a class by exact name match.

        Args:
            name: Exact class name to find.
            alias: Neo4j instance alias.

        Returns:
            ClassNode if found, None otherwise.

        Example:
            >>> cls = client.find_class_by_name("UserService")
            >>> if cls:
            ...     print(cls.docstring)
        """
        escaped = _escape_cypher_string(name)
        query = f"MATCH (c:Class {{name: '{escaped}'}}) RETURN c LIMIT 1"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ClassNode)]
        return nodes[0] if nodes else None

    def find_classes_by_name_pattern(
        self,
        pattern: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Find classes matching a regex pattern on name.

        Args:
            pattern: Regex pattern (Neo4j =~ operator syntax).
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of matching ClassNode instances.
        """
        escaped = _escape_cypher_string(pattern)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class) WHERE c.name =~ '{escaped}' "
            f"RETURN c{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def find_classes_by_metadata(
        self,
        filters: dict[str, Any],
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Find classes matching metadata field filters.

        Args:
            filters: Dictionary of field-value pairs to match.
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of ClassNode instances matching all filters.
        """
        if not filters:
            return self.get_all_classes(limit=limit, alias=alias)

        conditions = []
        for key, value in filters.items():
            escaped_key = _escape_cypher_string(key)
            if isinstance(value, str):
                escaped_val = _escape_cypher_string(value)
                conditions.append(f"c.`{escaped_key}` = '{escaped_val}'")
            elif isinstance(value, bool):
                conditions.append(f"c.`{escaped_key}` = {str(value).lower()}")
            elif isinstance(value, int | float):
                conditions.append(f"c.`{escaped_key}` = {value}")
            else:
                escaped_val = _escape_cypher_string(str(value))
                conditions.append(f"c.`{escaped_key}` = '{escaped_val}'")

        where_clause = " AND ".join(conditions)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (c:Class) WHERE {where_clause} RETURN c{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def count_classes(self, alias: str | None = None) -> int:
        """
        Count total number of Class nodes.

        Args:
            alias: Neo4j instance alias.

        Returns:
            Number of Class nodes in the graph.

        Example:
            >>> total = client.count_classes()
            >>> print(f"Total classes: {total}")
        """
        query = "MATCH (c:Class) RETURN count(c) AS count"
        result = self.cypher_query(query, alias=alias)
        if result.results and "count" in result.results[0]:
            return int(result.results[0]["count"])
        return 0

    def class_exists(self, name: str, alias: str | None = None) -> bool:
        """
        Check if a class with the given name exists.

        Args:
            name: Class name to check.
            alias: Neo4j instance alias.

        Returns:
            True if class exists, False otherwise.

        Example:
            >>> if client.class_exists("UserService"):
            ...     print("Class found")
        """
        escaped = _escape_cypher_string(name)
        query = (
            f"MATCH (c:Class {{name: '{escaped}'}}) "
            "RETURN count(c) > 0 AS exists"
        )
        result = self.cypher_query(query, alias=alias)
        if result.results and "exists" in result.results[0]:
            return bool(result.results[0]["exists"])
        return False

    # -------------------------------------------------------------------------
    # Convenience Methods - Module Operations
    # -------------------------------------------------------------------------

    def get_all_modules(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """
        Get all Module nodes in the graph.

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of ModuleNode instances.

        Example:
            >>> modules = client.get_all_modules(limit=50)
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (m:Module) RETURN m{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def find_module_by_name(
        self,
        name: str,
        alias: str | None = None,
    ) -> ModuleNode | None:
        """
        Find a module by exact name match.

        Args:
            name: Exact module name to find.
            alias: Neo4j instance alias.

        Returns:
            ModuleNode if found, None otherwise.

        Example:
            >>> mod = client.find_module_by_name("utils")
        """
        escaped = _escape_cypher_string(name)
        query = f"MATCH (m:Module {{name: '{escaped}'}}) RETURN m LIMIT 1"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ModuleNode)]
        return nodes[0] if nodes else None

    def find_modules_by_name_pattern(
        self,
        pattern: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Find modules matching a regex pattern on name."""
        escaped = _escape_cypher_string(pattern)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (m:Module) WHERE m.name =~ '{escaped}' "
            f"RETURN m{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def find_modules_by_path_pattern(
        self,
        pattern: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Find modules matching a regex pattern on path."""
        escaped = _escape_cypher_string(pattern)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (m:Module) WHERE m.path =~ '{escaped}' "
            f"RETURN m{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def find_modules_by_metadata(
        self,
        filters: dict[str, Any],
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Find modules matching metadata field filters."""
        if not filters:
            return self.get_all_modules(limit=limit, alias=alias)

        conditions = []
        for key, value in filters.items():
            escaped_key = _escape_cypher_string(key)
            if isinstance(value, str):
                escaped_val = _escape_cypher_string(value)
                conditions.append(f"m.`{escaped_key}` = '{escaped_val}'")
            elif isinstance(value, bool):
                conditions.append(f"m.`{escaped_key}` = {str(value).lower()}")
            elif isinstance(value, int | float):
                conditions.append(f"m.`{escaped_key}` = {value}")
            else:
                escaped_val = _escape_cypher_string(str(value))
                conditions.append(f"m.`{escaped_key}` = '{escaped_val}'")

        where_clause = " AND ".join(conditions)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (m:Module) WHERE {where_clause} RETURN m{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def count_modules(self, alias: str | None = None) -> int:
        """
        Count total number of Module nodes.

        Args:
            alias: Neo4j instance alias.

        Returns:
            Number of Module nodes in the graph.
        """
        query = "MATCH (m:Module) RETURN count(m) AS count"
        result = self.cypher_query(query, alias=alias)
        if result.results and "count" in result.results[0]:
            return int(result.results[0]["count"])
        return 0

    def module_exists(self, name: str, alias: str | None = None) -> bool:
        """
        Check if a module with the given name exists.

        Args:
            name: Module name to check.
            alias: Neo4j instance alias.

        Returns:
            True if module exists, False otherwise.
        """
        escaped = _escape_cypher_string(name)
        query = (
            f"MATCH (m:Module {{name: '{escaped}'}}) "
            "RETURN count(m) > 0 AS exists"
        )
        result = self.cypher_query(query, alias=alias)
        if result.results and "exists" in result.results[0]:
            return bool(result.results[0]["exists"])
        return False

    # -------------------------------------------------------------------------
    # Convenience Methods - Subroutine Operations
    # -------------------------------------------------------------------------

    def get_all_subroutines(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """
        Get all Subroutine nodes in the graph.

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of SubroutineNode instances.
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (s:Subroutine) RETURN s{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def find_subroutine_by_name(
        self,
        name: str,
        alias: str | None = None,
    ) -> SubroutineNode | None:
        """
        Find a subroutine by exact name match.

        Args:
            name: Exact subroutine name to find.
            alias: Neo4j instance alias.

        Returns:
            SubroutineNode if found, None otherwise.
        """
        escaped = _escape_cypher_string(name)
        query = f"MATCH (s:Subroutine {{name: '{escaped}'}}) RETURN s LIMIT 1"
        result = self.cypher_query(query, alias=alias)
        nodes = [
            n for n in result.get_nodes() if isinstance(n, SubroutineNode)
        ]
        return nodes[0] if nodes else None

    def find_subroutines_by_name_pattern(
        self,
        pattern: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Find subroutines matching a regex pattern on name."""
        escaped = _escape_cypher_string(pattern)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine) WHERE s.name =~ '{escaped}' "
            f"RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def find_subroutines_by_return_type(
        self,
        return_type: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Find subroutines with a specific return type."""
        escaped = _escape_cypher_string(return_type)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine {{return_type: '{escaped}'}}) "
            f"RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def find_subroutines_by_metadata(
        self,
        filters: dict[str, Any],
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Find subroutines matching metadata field filters."""
        if not filters:
            return self.get_all_subroutines(limit=limit, alias=alias)

        conditions = []
        for key, value in filters.items():
            escaped_key = _escape_cypher_string(key)
            if isinstance(value, str):
                escaped_val = _escape_cypher_string(value)
                conditions.append(f"s.`{escaped_key}` = '{escaped_val}'")
            elif isinstance(value, bool):
                conditions.append(f"s.`{escaped_key}` = {str(value).lower()}")
            elif isinstance(value, int | float):
                conditions.append(f"s.`{escaped_key}` = {value}")
            else:
                escaped_val = _escape_cypher_string(str(value))
                conditions.append(f"s.`{escaped_key}` = '{escaped_val}'")

        where_clause = " AND ".join(conditions)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine) WHERE {where_clause} "
            f"RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def count_subroutines(self, alias: str | None = None) -> int:
        """
        Count total number of Subroutine nodes.

        Args:
            alias: Neo4j instance alias.

        Returns:
            Number of Subroutine nodes in the graph.
        """
        query = "MATCH (s:Subroutine) RETURN count(s) AS count"
        result = self.cypher_query(query, alias=alias)
        if result.results and "count" in result.results[0]:
            return int(result.results[0]["count"])
        return 0

    def subroutine_exists(self, name: str, alias: str | None = None) -> bool:
        """
        Check if a subroutine with the given name exists.

        Args:
            name: Subroutine name to check.
            alias: Neo4j instance alias.

        Returns:
            True if subroutine exists, False otherwise.
        """
        escaped = _escape_cypher_string(name)
        query = (
            f"MATCH (s:Subroutine {{name: '{escaped}'}}) "
            "RETURN count(s) > 0 AS exists"
        )
        result = self.cypher_query(query, alias=alias)
        if result.results and "exists" in result.results[0]:
            return bool(result.results[0]["exists"])
        return False

    # -------------------------------------------------------------------------
    # Convenience Methods - Attribute Operations
    # -------------------------------------------------------------------------

    def get_all_attributes(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[AttributeNode]:
        """
        Get all Attribute nodes in the graph.

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of AttributeNode instances.
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (a:Attribute) RETURN a{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, AttributeNode)]

    def find_attribute_by_name(
        self,
        name: str,
        alias: str | None = None,
    ) -> AttributeNode | None:
        """
        Find an attribute by exact name match.

        Args:
            name: Exact attribute name to find.
            alias: Neo4j instance alias.

        Returns:
            AttributeNode if found, None otherwise.
        """
        escaped = _escape_cypher_string(name)
        query = f"MATCH (a:Attribute {{name: '{escaped}'}}) RETURN a LIMIT 1"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, AttributeNode)]
        return nodes[0] if nodes else None

    def find_attributes_by_name_pattern(
        self,
        pattern: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[AttributeNode]:
        """Find attributes matching a regex pattern on name."""
        escaped = _escape_cypher_string(pattern)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (a:Attribute) WHERE a.name =~ '{escaped}' "
            f"RETURN a{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, AttributeNode)]

    def find_attributes_by_type(
        self,
        type_annotation: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[AttributeNode]:
        """Find attributes with a specific type annotation."""
        escaped = _escape_cypher_string(type_annotation)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (a:Attribute {{type_annotation: '{escaped}'}}) "
            f"RETURN a{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, AttributeNode)]

    def count_attributes(self, alias: str | None = None) -> int:
        """
        Count total number of Attribute nodes.

        Args:
            alias: Neo4j instance alias.

        Returns:
            Number of Attribute nodes in the graph.
        """
        query = "MATCH (a:Attribute) RETURN count(a) AS count"
        result = self.cypher_query(query, alias=alias)
        if result.results and "count" in result.results[0]:
            return int(result.results[0]["count"])
        return 0

    def attribute_exists(self, name: str, alias: str | None = None) -> bool:
        """
        Check if an attribute with the given name exists.

        Args:
            name: Attribute name to check.
            alias: Neo4j instance alias.

        Returns:
            True if attribute exists, False otherwise.
        """
        escaped = _escape_cypher_string(name)
        query = (
            f"MATCH (a:Attribute {{name: '{escaped}'}}) "
            "RETURN count(a) > 0 AS exists"
        )
        result = self.cypher_query(query, alias=alias)
        if result.results and "exists" in result.results[0]:
            return bool(result.results[0]["exists"])
        return False

    # -------------------------------------------------------------------------
    # Convenience Methods - Relationship Traversals
    # -------------------------------------------------------------------------

    def get_classes_inheriting_from(
        self,
        base_class_name: str,
        recursive: bool = False,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """Get all classes that inherit from a given base class."""
        escaped = _escape_cypher_string(base_class_name)
        depth = "*1.." if recursive else ""
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (child:Class)-[:inherits_from{depth}]->"
            f"(base:Class {{name: '{escaped}'}}) "
            f"RETURN DISTINCT child{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_base_classes(
        self,
        class_name: str,
        recursive: bool = False,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """Get base classes of a given class."""
        escaped = _escape_cypher_string(class_name)
        depth = "*1.." if recursive else ""
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class {{name: '{escaped}'}})"
            f"-[:inherits_from{depth}]->(base:Class) "
            f"RETURN DISTINCT base{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_subroutines_calling(
        self,
        subroutine_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Get all subroutines that call/trigger the given subroutine."""
        escaped = _escape_cypher_string(subroutine_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (caller:Subroutine)-[:triggers]->"
            f"(s:Subroutine {{name: '{escaped}'}}) RETURN caller{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def get_subroutines_called_by(
        self,
        subroutine_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Get all subroutines called/triggered by the given subroutine."""
        escaped = _escape_cypher_string(subroutine_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine {{name: '{escaped}'}})"
            f"-[:triggers]->(callee:Subroutine) RETURN callee{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def get_modules_importing(
        self,
        module_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Get all modules that import the given module (dependents)."""
        escaped = _escape_cypher_string(module_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (importer:Module)-[:contains_imports]->"
            f"(m:Module {{name: '{escaped}'}}) RETURN importer{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def get_modules_imported_by(
        self,
        module_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """Get all modules imported by the given module (dependencies)."""
        escaped = _escape_cypher_string(module_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (m:Module {{name: '{escaped}'}})"
            f"-[:contains_imports]->(imported:Module) "
            f"RETURN imported{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def get_classes_used_by_subroutine(
        self,
        subroutine_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """Get all classes instantiated or used by a subroutine."""
        escaped = _escape_cypher_string(subroutine_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine {{name: '{escaped}'}})"
            f"-[:instantiates_class]->(c:Class) RETURN c{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_subroutines_using_class(
        self,
        class_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """Get all subroutines that instantiate or use a given class."""
        escaped = _escape_cypher_string(class_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine)-[:instantiates_class]->"
            f"(c:Class {{name: '{escaped}'}}) RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    # -------------------------------------------------------------------------
    # Convenience Methods - Advanced Queries
    # -------------------------------------------------------------------------

    def find_async_subroutines(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """
        Find all asynchronous subroutines (async def).

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of async SubroutineNode instances.

        Example:
            >>> async_funcs = client.find_async_subroutines(limit=10)
            >>> for func in async_funcs:
            ...     print(f"async {func.name}")
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (s:Subroutine {{is_async: true}}) RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def find_abstract_classes(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Find all abstract classes.

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of abstract ClassNode instances.

        Example:
            >>> abstract = client.find_abstract_classes(limit=10)
            >>> for cls in abstract:
            ...     print(f"ABC: {cls.name}")
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = f"MATCH (c:Class {{is_abstract: true}}) RETURN c{limit_clause}"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def find_classes_with_base(
        self,
        base_name: str,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Find classes that have a specific base in their bases list.

        Note: This checks the 'bases' property array, not the relationship.
        Use get_classes_inheriting_from() for relationship-based traversal.

        Args:
            base_name: Base class name to search for in bases array.
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of ClassNode instances with the base in their bases list.

        Example:
            >>> models = client.find_classes_with_base("BaseModel", limit=10)
        """
        escaped = _escape_cypher_string(base_name)
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            f"MATCH (c:Class) WHERE '{escaped}' IN c.bases RETURN c"
            f"{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def find_orphan_classes(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Find classes not contained by any module.

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of ClassNode instances with no parent module.

        Example:
            >>> orphans = client.find_orphan_classes(limit=10)
            >>> print(f"Found {len(orphans)} orphan classes")
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            "MATCH (c:Class) "
            "WHERE NOT ((:Module)-[:has_class]->(c)) "
            f"RETURN c{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def find_orphan_subroutines(
        self,
        limit: int | None = None,
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """
        Find subroutines not defined in any module or class.

        Args:
            limit: Maximum number of results.
            alias: Neo4j instance alias.

        Returns:
            List of orphan SubroutineNode instances.
        """
        limit_clause = f" LIMIT {limit}" if limit else ""
        query = (
            "MATCH (s:Subroutine) "
            "WHERE NOT (()-[:has_subroutine|defines_method]->(s)) "
            f"RETURN s{limit_clause}"
        )
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    def get_classes_with_method_count(
        self,
        min_methods: int = 0,
        max_methods: int | None = None,
        alias: str | None = None,
    ) -> list[tuple[ClassNode, int]]:
        """
        Get classes with their method count, filtered by range.

        Args:
            min_methods: Minimum method count (inclusive).
            max_methods: Maximum method count (inclusive), None for unlimited.
            alias: Neo4j instance alias.

        Returns:
            List of (ClassNode, method_count) tuples.

        Example:
            >>> # Find large classes (potential code smell)
            >>> large = client.get_classes_with_method_count(min_methods=20)
            >>> for cls, count in large:
            ...     print(f"{cls.name}: {count} methods")
        """
        from ..models.nodes import parse_node

        max_clause = f" AND cnt <= {max_methods}" if max_methods else ""
        query = (
            "MATCH (c:Class) "
            "OPTIONAL MATCH (c)-[:defines_method]->(m:Subroutine) "
            f"WITH c, count(m) AS cnt WHERE cnt >= {min_methods}{max_clause} "
            "RETURN c, cnt ORDER BY cnt DESC"
        )
        result = self.cypher_query(query, alias=alias)
        output: list[tuple[ClassNode, int]] = []
        for row in result.results:
            if "c" in row and "cnt" in row:
                node = parse_node(row["c"])
                if isinstance(node, ClassNode):
                    output.append((node, row["cnt"]))
        return output

    # -------------------------------------------------------------------------
    # Convenience Methods - Batch Operations
    # -------------------------------------------------------------------------

    def get_classes_by_names(
        self,
        names: list[str],
        alias: str | None = None,
    ) -> list[ClassNode]:
        """
        Get multiple classes by their names in a single query.

        Args:
            names: List of class names to retrieve.
            alias: Neo4j instance alias.

        Returns:
            List of ClassNode instances found (may be fewer than requested).

        Example:
            >>> classes = client.get_classes_by_names(
            ...     ["UserService", "OrderService"]
            ... )
        """
        if not names:
            return []
        escaped_names = [f"'{_escape_cypher_string(n)}'" for n in names]
        names_list = ", ".join(escaped_names)
        query = f"MATCH (c:Class) WHERE c.name IN [{names_list}] RETURN c"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ClassNode)]

    def get_modules_by_names(
        self,
        names: list[str],
        alias: str | None = None,
    ) -> list[ModuleNode]:
        """
        Get multiple modules by their names in a single query.

        Args:
            names: List of module names to retrieve.
            alias: Neo4j instance alias.

        Returns:
            List of ModuleNode instances found.
        """
        if not names:
            return []
        escaped_names = [f"'{_escape_cypher_string(n)}'" for n in names]
        names_list = ", ".join(escaped_names)
        query = f"MATCH (m:Module) WHERE m.name IN [{names_list}] RETURN m"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, ModuleNode)]

    def get_subroutines_by_names(
        self,
        names: list[str],
        alias: str | None = None,
    ) -> list[SubroutineNode]:
        """
        Get multiple subroutines by their names in a single query.

        Args:
            names: List of subroutine names to retrieve.
            alias: Neo4j instance alias.

        Returns:
            List of SubroutineNode instances found.
        """
        if not names:
            return []
        escaped_names = [f"'{_escape_cypher_string(n)}'" for n in names]
        names_list = ", ".join(escaped_names)
        query = f"MATCH (s:Subroutine) WHERE s.name IN [{names_list}] RETURN s"
        result = self.cypher_query(query, alias=alias)
        return [n for n in result.get_nodes() if isinstance(n, SubroutineNode)]

    # =========================================================================
    # Write Operations - Node Creation
    # =========================================================================

    def create_client(
        self,
        name: str,
        description: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> ClientNode:
        """
        Create a Client node.

        Args:
            name: Unique client name.
            description: Optional description.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created ClientNode.
        """
        props: dict[str, Any] = {"name": name}
        if description is not None:
            props["description"] = description
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Client {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ClientNode)]
        if not nodes:
            raise RuntimeError("Failed to create Client node")
        return nodes[0]

    def create_application(
        self,
        name: str,
        version: str | None = None,
        language: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> ApplicationNode:
        """
        Create an Application node.

        Args:
            name: Unique application name.
            version: Optional version string.
            language: Optional programming language.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created ApplicationNode.
        """
        props: dict[str, Any] = {"name": name}
        if version is not None:
            props["version"] = version
        if language is not None:
            props["language"] = language
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Application {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [
            n for n in result.get_nodes() if isinstance(n, ApplicationNode)
        ]
        if not nodes:
            raise RuntimeError("Failed to create Application node")
        return nodes[0]

    def create_module(
        self,
        name: str,
        path: str | None = None,
        docstring: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> ModuleNode:
        """
        Create a Module node.

        Args:
            name: Unique module name.
            path: Optional file path.
            docstring: Optional docstring.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created ModuleNode.
        """
        props: dict[str, Any] = {"name": name}
        if path is not None:
            props["path"] = path
        if docstring is not None:
            props["docstring"] = docstring
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Module {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ModuleNode)]
        if not nodes:
            raise RuntimeError("Failed to create Module node")
        return nodes[0]

    def create_class(
        self,
        name: str,
        docstring: str | None = None,
        is_abstract: bool = False,
        bases: list[str] | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> ClassNode:
        """
        Create a Class node.

        Args:
            name: Unique class name.
            docstring: Optional docstring.
            is_abstract: Whether the class is abstract.
            bases: List of base class names.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created ClassNode.
        """
        props: dict[str, Any] = {"name": name, "is_abstract": is_abstract}
        if docstring is not None:
            props["docstring"] = docstring
        if bases:
            props["bases"] = bases
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Class {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ClassNode)]
        if not nodes:
            raise RuntimeError("Failed to create Class node")
        return nodes[0]

    def create_subroutine(
        self,
        name: str,
        signature: str | None = None,
        docstring: str | None = None,
        is_async: bool = False,
        return_type: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> SubroutineNode:
        """
        Create a Subroutine node.

        Args:
            name: Unique subroutine name.
            signature: Optional function signature.
            docstring: Optional docstring.
            is_async: Whether the subroutine is async.
            return_type: Optional return type annotation.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created SubroutineNode.
        """
        props: dict[str, Any] = {"name": name, "is_async": is_async}
        if signature is not None:
            props["signature"] = signature
        if docstring is not None:
            props["docstring"] = docstring
        if return_type is not None:
            props["return_type"] = return_type
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Subroutine {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [
            n for n in result.get_nodes() if isinstance(n, SubroutineNode)
        ]
        if not nodes:
            raise RuntimeError("Failed to create Subroutine node")
        return nodes[0]

    def create_attribute(
        self,
        name: str,
        type_annotation: str | None = None,
        default_value: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> AttributeNode:
        """
        Create an Attribute node.

        Args:
            name: Unique attribute name.
            type_annotation: Optional type annotation.
            default_value: Optional default value.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created AttributeNode.
        """
        props: dict[str, Any] = {"name": name}
        if type_annotation is not None:
            props["type_annotation"] = type_annotation
        if default_value is not None:
            props["default_value"] = default_value
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Attribute {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, AttributeNode)]
        if not nodes:
            raise RuntimeError("Failed to create Attribute node")
        return nodes[0]

    def create_object(
        self,
        name: str,
        class_name: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> ObjectNode:
        """
        Create an Object node.

        Args:
            name: Unique object name.
            class_name: Optional class name this object is an instance of.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created ObjectNode.
        """
        props: dict[str, Any] = {"name": name}
        if class_name is not None:
            props["class_name"] = class_name
        props.update(metadata)

        prop_map = _build_property_map(props)
        query = f"CREATE (n:Object {prop_map}) RETURN n"
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ObjectNode)]
        if not nodes:
            raise RuntimeError("Failed to create Object node")
        return nodes[0]

    # =========================================================================
    # Write Operations - Generic Node Operations
    # =========================================================================

    def update_node(
        self,
        node_id: int,
        properties: dict[str, Any],
        alias: str | None = None,
    ) -> BaseNode:
        """
        Update properties on a node by ID.

        Args:
            node_id: Neo4j internal node ID.
            properties: Dict of properties to SET (merges, not replaces).
            alias: Neo4j instance alias.

        Returns:
            The updated node.

        Raises:
            NotFoundError: If node doesn't exist.
        """
        set_clauses = []
        for key, value in properties.items():
            if value is None:
                continue
            escaped_key = _escape_cypher_string(key)
            if isinstance(value, str):
                escaped_val = _escape_cypher_string(value)
                set_clauses.append(f"n.`{escaped_key}` = '{escaped_val}'")
            elif isinstance(value, bool):
                set_clauses.append(f"n.`{escaped_key}` = {str(value).lower()}")
            elif isinstance(value, int | float):
                set_clauses.append(f"n.`{escaped_key}` = {value}")
            elif isinstance(value, list):
                items = [f"'{_escape_cypher_string(str(v))}'" for v in value]
                set_clauses.append(f"n.`{escaped_key}` = [{', '.join(items)}]")
            else:
                escaped_val = _escape_cypher_string(str(value))
                set_clauses.append(f"n.`{escaped_key}` = '{escaped_val}'")

        if not set_clauses:
            query = f"MATCH (n) WHERE id(n) = {node_id} RETURN n"
        else:
            set_clause = ", ".join(set_clauses)
            query = (
                f"MATCH (n) WHERE id(n) = {node_id} "
                f"SET {set_clause} RETURN n"
            )

        result = self.cypher_query(query, alias=alias)
        nodes = result.get_nodes()
        if not nodes:
            raise NotFoundError(
                f"Node with ID {node_id} not found", status_code=404
            )
        return nodes[0]

    def delete_node(
        self,
        node_id: int,
        detach: bool = True,
        alias: str | None = None,
    ) -> bool:
        """
        Delete a node by ID.

        Args:
            node_id: Neo4j internal node ID.
            detach: If True, delete all relationships first (DETACH DELETE).
            alias: Neo4j instance alias.

        Returns:
            True if deleted successfully.
        """
        delete_cmd = "DETACH DELETE n" if detach else "DELETE n"
        query = f"MATCH (n) WHERE id(n) = {node_id} {delete_cmd}"
        self.cypher_query(query, alias=alias)
        return True

    def delete_node_by_name(
        self,
        label: str,
        name: str,
        detach: bool = True,
        alias: str | None = None,
    ) -> bool:
        """
        Delete a node by label and name.

        Args:
            label: Node label (e.g., "Class", "Module").
            name: Node name property.
            detach: If True, delete all relationships first.
            alias: Neo4j instance alias.

        Returns:
            True if deleted successfully.
        """
        escaped_label = _escape_cypher_string(label)
        escaped_name = _escape_cypher_string(name)
        delete_cmd = "DETACH DELETE n" if detach else "DELETE n"
        query = (
            f"MATCH (n:`{escaped_label}` {{name: '{escaped_name}'}}) "
            f"{delete_cmd}"
        )
        self.cypher_query(query, alias=alias)
        return True

    def add_metadata_to_node(
        self,
        node_id: int,
        metadata: dict[str, Any],
        alias: str | None = None,
    ) -> BaseNode:
        """
        Add metadata properties to a node.

        This is an alias for update_node() for semantic clarity.

        Args:
            node_id: Neo4j internal node ID.
            metadata: Dict of metadata properties to add/update.
            alias: Neo4j instance alias.

        Returns:
            The updated node.
        """
        return self.update_node(node_id, metadata, alias=alias)

    def remove_metadata_from_node(
        self,
        node_id: int,
        keys: list[str],
        alias: str | None = None,
    ) -> BaseNode:
        """
        Remove specific metadata keys from a node.

        Args:
            node_id: Neo4j internal node ID.
            keys: List of property keys to remove.
            alias: Neo4j instance alias.

        Returns:
            The updated node.

        Raises:
            NotFoundError: If node doesn't exist.
        """
        if not keys:
            query = f"MATCH (n) WHERE id(n) = {node_id} RETURN n"
        else:
            remove_parts = [f"n.`{_escape_cypher_string(k)}`" for k in keys]
            remove_clause = ", ".join(remove_parts)
            query = (
                f"MATCH (n) WHERE id(n) = {node_id} "
                f"REMOVE {remove_clause} RETURN n"
            )

        result = self.cypher_query(query, alias=alias)
        nodes = result.get_nodes()
        if not nodes:
            raise NotFoundError(
                f"Node with ID {node_id} not found", status_code=404
            )
        return nodes[0]

    # =========================================================================
    # Write Operations - Relationship Builders
    # =========================================================================

    def link_application_to_client(
        self,
        app_name: str,
        client_name: str,
        alias: str | None = None,
    ) -> HasApplication:
        """
        Create has_application relationship between Client and Application.

        Args:
            app_name: Application node name.
            client_name: Client node name.
            alias: Neo4j instance alias.

        Returns:
            The created HasApplication relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_app = _escape_cypher_string(app_name)
        escaped_client = _escape_cypher_string(client_name)
        query = (
            f"MATCH (c:Client {{name: '{escaped_client}'}}), "
            f"(a:Application {{name: '{escaped_app}'}}) "
            f"CREATE (c)-[r:has_application]->(a) "
            f"RETURN r, id(c) AS start_id, id(a) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Client '{client_name}' or Application '{app_name}' "
                "not found",
                status_code=404,
            )
        row = result.results[0]
        return HasApplication(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_module_to_application(
        self,
        module_name: str,
        app_name: str,
        alias: str | None = None,
    ) -> HasModule:
        """
        Create has_module relationship between Application and Module.

        Args:
            module_name: Module node name.
            app_name: Application node name.
            alias: Neo4j instance alias.

        Returns:
            The created HasModule relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_module = _escape_cypher_string(module_name)
        escaped_app = _escape_cypher_string(app_name)
        query = (
            f"MATCH (a:Application {{name: '{escaped_app}'}}), "
            f"(m:Module {{name: '{escaped_module}'}}) "
            f"CREATE (a)-[r:has_module]->(m) "
            f"RETURN r, id(a) AS start_id, id(m) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Application '{app_name}' or Module '{module_name}' "
                "not found",
                status_code=404,
            )
        row = result.results[0]
        return HasModule(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_class_to_module(
        self,
        class_name: str,
        module_name: str,
        alias: str | None = None,
    ) -> HasClass:
        """
        Create has_class relationship between Module and Class.

        Args:
            class_name: Class node name.
            module_name: Module node name.
            alias: Neo4j instance alias.

        Returns:
            The created HasClass relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_class = _escape_cypher_string(class_name)
        escaped_module = _escape_cypher_string(module_name)
        query = (
            f"MATCH (m:Module {{name: '{escaped_module}'}}), "
            f"(c:Class {{name: '{escaped_class}'}}) "
            f"CREATE (m)-[r:has_class]->(c) "
            f"RETURN r, id(m) AS start_id, id(c) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Module '{module_name}' or Class '{class_name}' not found",
                status_code=404,
            )
        row = result.results[0]
        return HasClass(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_subroutine_to_module(
        self,
        subroutine_name: str,
        module_name: str,
        alias: str | None = None,
    ) -> HasSubroutine:
        """
        Create has_subroutine relationship between Module and Subroutine.

        Args:
            subroutine_name: Subroutine node name.
            module_name: Module node name.
            alias: Neo4j instance alias.

        Returns:
            The created HasSubroutine relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_sub = _escape_cypher_string(subroutine_name)
        escaped_module = _escape_cypher_string(module_name)
        query = (
            f"MATCH (m:Module {{name: '{escaped_module}'}}), "
            f"(s:Subroutine {{name: '{escaped_sub}'}}) "
            f"CREATE (m)-[r:has_subroutine]->(s) "
            f"RETURN r, id(m) AS start_id, id(s) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Module '{module_name}' or Subroutine '{subroutine_name}' "
                "not found",
                status_code=404,
            )
        row = result.results[0]
        return HasSubroutine(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_method_to_class(
        self,
        method_name: str,
        class_name: str,
        alias: str | None = None,
    ) -> DefinesMethod:
        """
        Create defines_method relationship between Class and Subroutine.

        Args:
            method_name: Subroutine node name (the method).
            class_name: Class node name.
            alias: Neo4j instance alias.

        Returns:
            The created DefinesMethod relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_method = _escape_cypher_string(method_name)
        escaped_class = _escape_cypher_string(class_name)
        query = (
            f"MATCH (c:Class {{name: '{escaped_class}'}}), "
            f"(s:Subroutine {{name: '{escaped_method}'}}) "
            f"CREATE (c)-[r:defines_method]->(s) "
            f"RETURN r, id(c) AS start_id, id(s) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Class '{class_name}' or Subroutine '{method_name}' "
                "not found",
                status_code=404,
            )
        row = result.results[0]
        return DefinesMethod(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_attribute_to_class(
        self,
        attribute_name: str,
        class_name: str,
        alias: str | None = None,
    ) -> DefinesAttribute:
        """
        Create defines_attribute relationship between Class and Attribute.

        Args:
            attribute_name: Attribute node name.
            class_name: Class node name.
            alias: Neo4j instance alias.

        Returns:
            The created DefinesAttribute relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_attr = _escape_cypher_string(attribute_name)
        escaped_class = _escape_cypher_string(class_name)
        query = (
            f"MATCH (c:Class {{name: '{escaped_class}'}}), "
            f"(a:Attribute {{name: '{escaped_attr}'}}) "
            f"CREATE (c)-[r:defines_attribute]->(a) "
            f"RETURN r, id(c) AS start_id, id(a) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Class '{class_name}' or Attribute '{attribute_name}' "
                "not found",
                status_code=404,
            )
        row = result.results[0]
        return DefinesAttribute(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_inheritance(
        self,
        child_class: str,
        parent_class: str,
        alias: str | None = None,
    ) -> InheritsFrom:
        """
        Create inherits_from relationship between two Classes.

        Args:
            child_class: Child class name (the one that inherits).
            parent_class: Parent class name (the base class).
            alias: Neo4j instance alias.

        Returns:
            The created InheritsFrom relationship.

        Raises:
            NotFoundError: If either class doesn't exist.
        """
        escaped_child = _escape_cypher_string(child_class)
        escaped_parent = _escape_cypher_string(parent_class)
        query = (
            f"MATCH (child:Class {{name: '{escaped_child}'}}), "
            f"(parent:Class {{name: '{escaped_parent}'}}) "
            f"CREATE (child)-[r:inherits_from]->(parent) "
            f"RETURN r, id(child) AS start_id, id(parent) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Class '{child_class}' or '{parent_class}' not found",
                status_code=404,
            )
        row = result.results[0]
        return InheritsFrom(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_module_import(
        self,
        importer_name: str,
        imported_name: str,
        alias: str | None = None,
    ) -> ContainsImports:
        """
        Create contains_imports relationship between two Modules.

        Args:
            importer_name: Module that imports (source).
            imported_name: Module being imported (target).
            alias: Neo4j instance alias.

        Returns:
            The created ContainsImports relationship.

        Raises:
            NotFoundError: If either module doesn't exist.
        """
        escaped_importer = _escape_cypher_string(importer_name)
        escaped_imported = _escape_cypher_string(imported_name)
        query = (
            f"MATCH (importer:Module {{name: '{escaped_importer}'}}), "
            f"(imported:Module {{name: '{escaped_imported}'}}) "
            f"CREATE (importer)-[r:contains_imports]->(imported) "
            f"RETURN r, id(importer) AS start_id, id(imported) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Module '{importer_name}' or '{imported_name}' not found",
                status_code=404,
            )
        row = result.results[0]
        return ContainsImports(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    def link_subroutine_call(
        self,
        caller_name: str,
        callee_name: str,
        alias: str | None = None,
    ) -> Triggers:
        """
        Create triggers relationship between two Subroutines.

        Args:
            caller_name: Subroutine that calls (source).
            callee_name: Subroutine being called (target).
            alias: Neo4j instance alias.

        Returns:
            The created Triggers relationship.

        Raises:
            NotFoundError: If either subroutine doesn't exist.
        """
        escaped_caller = _escape_cypher_string(caller_name)
        escaped_callee = _escape_cypher_string(callee_name)
        query = (
            f"MATCH (caller:Subroutine {{name: '{escaped_caller}'}}), "
            f"(callee:Subroutine {{name: '{escaped_callee}'}}) "
            f"CREATE (caller)-[r:triggers]->(callee) "
            f"RETURN r, id(caller) AS start_id, id(callee) AS end_id"
        )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Subroutine '{caller_name}' or '{callee_name}' not found",
                status_code=404,
            )
        row = result.results[0]
        return Triggers(
            id=row["r"].get("identity"),
            start_node_id=row["start_id"],
            end_node_id=row["end_id"],
            properties=row["r"].get("properties", {}),
        )

    # =========================================================================
    # Write Operations - Generic Relationship Operations
    # =========================================================================

    def create_relationship(
        self,
        start_id: int,
        end_id: int,
        rel_type: str,
        properties: dict[str, Any] | None = None,
        alias: str | None = None,
    ) -> BaseRelationship:
        """
        Create a relationship between two nodes by ID.

        Args:
            start_id: Source node ID.
            end_id: Target node ID.
            rel_type: Relationship type (e.g., "has_class", "triggers").
            properties: Optional relationship properties.
            alias: Neo4j instance alias.

        Returns:
            The created relationship.

        Raises:
            NotFoundError: If either node doesn't exist.
        """
        escaped_type = _escape_cypher_string(rel_type)
        prop_map = _build_property_map(properties or {})
        if prop_map:
            query = (
                f"MATCH (a), (b) "
                f"WHERE id(a) = {start_id} AND id(b) = {end_id} "
                f"CREATE (a)-[r:`{escaped_type}` {prop_map}]->(b) "
                f"RETURN r"
            )
        else:
            query = (
                f"MATCH (a), (b) "
                f"WHERE id(a) = {start_id} AND id(b) = {end_id} "
                f"CREATE (a)-[r:`{escaped_type}`]->(b) "
                f"RETURN r"
            )
        result = self.cypher_query(query, alias=alias)
        if not result.results:
            raise NotFoundError(
                f"Node {start_id} or {end_id} not found",
                status_code=404,
            )
        rel_data = result.results[0]["r"]
        rel_data["type"] = rel_type
        rel_data["start"] = start_id
        rel_data["end"] = end_id
        return parse_relationship(rel_data)

    def delete_relationship(
        self,
        relationship_id: int,
        alias: str | None = None,
    ) -> bool:
        """
        Delete a relationship by ID.

        Args:
            relationship_id: Neo4j internal relationship ID.
            alias: Neo4j instance alias.

        Returns:
            True if deleted successfully.
        """
        query = f"MATCH ()-[r]-() WHERE id(r) = {relationship_id} DELETE r"
        self.cypher_query(query, alias=alias)
        return True

    # =========================================================================
    # Write Operations - Composite Operations
    # =========================================================================

    def create_class_in_module(
        self,
        class_name: str,
        module_name: str,
        docstring: str | None = None,
        is_abstract: bool = False,
        bases: list[str] | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> ClassNode:
        """
        Create a Class node and link it to an existing Module atomically.

        Args:
            class_name: Name for the new class.
            module_name: Existing module to link to.
            docstring: Optional class docstring.
            is_abstract: Whether the class is abstract.
            bases: List of base class names.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created ClassNode.

        Raises:
            NotFoundError: If module doesn't exist.
        """
        props: dict[str, Any] = {
            "name": class_name, "is_abstract": is_abstract
        }
        if docstring is not None:
            props["docstring"] = docstring
        if bases:
            props["bases"] = bases
        props.update(metadata)

        prop_map = _build_property_map(props)
        escaped_module = _escape_cypher_string(module_name)
        query = (
            f"MATCH (m:Module {{name: '{escaped_module}'}}) "
            f"CREATE (m)-[:has_class]->(c:Class {prop_map}) "
            f"RETURN c"
        )
        result = self.cypher_query(query, alias=alias)
        nodes = [n for n in result.get_nodes() if isinstance(n, ClassNode)]
        if not nodes:
            raise NotFoundError(
                f"Module '{module_name}' not found", status_code=404
            )
        return nodes[0]

    def create_method_in_class(
        self,
        method_name: str,
        class_name: str,
        signature: str | None = None,
        docstring: str | None = None,
        is_async: bool = False,
        return_type: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> SubroutineNode:
        """
        Create a Subroutine node and link it to a Class atomically.

        Args:
            method_name: Name for the new method.
            class_name: Existing class to link to.
            signature: Optional function signature.
            docstring: Optional docstring.
            is_async: Whether the method is async.
            return_type: Optional return type annotation.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created SubroutineNode.

        Raises:
            NotFoundError: If class doesn't exist.
        """
        props: dict[str, Any] = {"name": method_name, "is_async": is_async}
        if signature is not None:
            props["signature"] = signature
        if docstring is not None:
            props["docstring"] = docstring
        if return_type is not None:
            props["return_type"] = return_type
        props.update(metadata)

        prop_map = _build_property_map(props)
        escaped_class = _escape_cypher_string(class_name)
        query = (
            f"MATCH (c:Class {{name: '{escaped_class}'}}) "
            f"CREATE (c)-[:defines_method]->(s:Subroutine {prop_map}) "
            f"RETURN s"
        )
        result = self.cypher_query(query, alias=alias)
        nodes = [
            n for n in result.get_nodes() if isinstance(n, SubroutineNode)
        ]
        if not nodes:
            raise NotFoundError(
                f"Class '{class_name}' not found", status_code=404
            )
        return nodes[0]

    def create_subroutine_in_module(
        self,
        subroutine_name: str,
        module_name: str,
        signature: str | None = None,
        docstring: str | None = None,
        is_async: bool = False,
        return_type: str | None = None,
        alias: str | None = None,
        **metadata: Any,
    ) -> SubroutineNode:
        """
        Create a Subroutine node and link it to a Module atomically.

        Args:
            subroutine_name: Name for the new subroutine.
            module_name: Existing module to link to.
            signature: Optional function signature.
            docstring: Optional docstring.
            is_async: Whether the subroutine is async.
            return_type: Optional return type annotation.
            alias: Neo4j instance alias.
            **metadata: Additional properties.

        Returns:
            The created SubroutineNode.

        Raises:
            NotFoundError: If module doesn't exist.
        """
        props: dict[str, Any] = {"name": subroutine_name, "is_async": is_async}
        if signature is not None:
            props["signature"] = signature
        if docstring is not None:
            props["docstring"] = docstring
        if return_type is not None:
            props["return_type"] = return_type
        props.update(metadata)

        prop_map = _build_property_map(props)
        escaped_module = _escape_cypher_string(module_name)
        query = (
            f"MATCH (m:Module {{name: '{escaped_module}'}}) "
            f"CREATE (m)-[:has_subroutine]->(s:Subroutine {prop_map}) "
            f"RETURN s"
        )
        result = self.cypher_query(query, alias=alias)
        nodes = [
            n for n in result.get_nodes() if isinstance(n, SubroutineNode)
        ]
        if not nodes:
            raise NotFoundError(
                f"Module '{module_name}' not found", status_code=404
            )
        return nodes[0]
