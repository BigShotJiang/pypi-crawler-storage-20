"""Claude Code session search tool."""
__version__ = "0.1.0"
