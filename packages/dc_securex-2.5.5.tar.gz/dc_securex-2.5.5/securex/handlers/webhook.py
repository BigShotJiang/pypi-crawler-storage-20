"""
Webhook spam protection handler.
"""
import discord
import asyncio
from datetime import datetime, timezone, timedelta
from ..models import ThreatEvent


class WebhookHandler:
    """Handles webhook spam detection"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_webhooks_update(self, channel: discord.TextChannel):
        """Detect and delete spam webhooks"""
        try:
            guild = channel.guild
            await asyncio.sleep(0.3)
            
            webhooks = await channel.webhooks()
            if not webhooks:
                return
            
            # Get recent webhook creations (last 30 seconds)
            now = datetime.now(timezone.utc)
            recent_creates = []
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.webhook_create):
                if entry.target and hasattr(entry.target, 'id'):
                    entry_age = (now - entry.created_at).total_seconds()
                    if entry_age <= 30:
                        recent_creates.append({
                            'webhook_id': entry.target.id,
                            'creator_id': entry.user.id,
                            'name': getattr(entry.target, 'name', 'unknown')
                        })
            
            if not recent_creates:
                return
            
            # Delete unauthorized webhooks
            deleted_count = 0
            for webhook_info in recent_creates:
                is_allowed = await self._is_authorized(guild, webhook_info['creator_id'])
                
                if not is_allowed:
                    for webhook in webhooks:
                        if webhook.id == webhook_info['webhook_id']:
                            try:
                                await webhook.delete(reason="SecureX: Spam webhook")
                                deleted_count += 1
                            except discord.NotFound:
                                pass
                            except Exception as e:
                                print(f"Error deleting webhook: {e}")
                            break
            
            if deleted_count > 0:
                threat = ThreatEvent(
                    type="webhook_spam",
                    guild_id=guild.id,
                    actor_id=recent_creates[0]['creator_id'],
                    target_id=channel.id,
                    target_name=channel.name,
                    prevented=True,
                    restored=False,
                    details={"deleted_count": deleted_count}
                )
                
                await self.sdk._trigger_callbacks('threat_detected', threat)
                
        except Exception as e:
            print(f"Error in webhooks_update handler: {e}")
