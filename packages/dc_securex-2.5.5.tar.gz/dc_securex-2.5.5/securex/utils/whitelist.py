"""
Whitelist management for SecureX SDK.
Strictly per-guild - no cross-server whitelisting.
"""
import json
import aiofiles
from pathlib import Path
from typing import List, Set
from ..models import WhitelistChange


class WhitelistManager:
    """Manages whitelisted users per guild (guild-specific only)"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.data_dir = Path("./data/whitelists")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory cache (per-guild only) - loaded on startup
        self._whitelists: dict[int, Set[int]] = {}
        self._cache_loaded = False
    
    def _get_file_path(self, guild_id: int) -> Path:
        """Get whitelist file path for guild"""
        return self.data_dir / f"{guild_id}.json"
    
    async def preload_all(self):
        """
        Preload ALL whitelists into memory on startup.
        Call this in enable() to warm the cache.
        """
        if self._cache_loaded:
            return
        
        print("🔄 Preloading whitelists into cache...")
        count = 0
        
        # Load all whitelist files (async)
        for file_path in self.data_dir.glob("*.json"):
            try:
                guild_id = int(file_path.stem)
                async with aiofiles.open(file_path, 'r') as f:
                    content = await f.read()
                    data = json.loads(content)
                    self._whitelists[guild_id] = set(data.get('users', []))
                count += 1
            except Exception as e:
                print(f"Error loading whitelist {file_path}: {e}")
        
        self._cache_loaded = True
        print(f"✅ Cached {count} whitelists in memory")
    
    async def _load_whitelist(self, guild_id: int):
        """Load whitelist from file (fallback if not preloaded)"""
        file_path = self._get_file_path(guild_id)
        if file_path.exists():
            async with aiofiles.open(file_path, 'r') as f:
                content = await f.read()
                data = json.loads(content)
                self._whitelists[guild_id] = set(data.get('users', []))
    
    async def _save_whitelist(self, guild_id: int):
        """Save whitelist to file (async)"""
        file_path = self._get_file_path(guild_id)
        async with aiofiles.open(file_path, 'w') as f:
            content = json.dumps({
                'users': list(self._whitelists.get(guild_id, set()))
            }, indent=2)
            await f.write(content)
    
    async def add(self, guild_id: int, user_id: int, moderator_id: int = None):
        """Add user to guild whitelist"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
            if guild_id not in self._whitelists:
                self._whitelists[guild_id] = set()
        
        self._whitelists[guild_id].add(user_id)
        await self._save_whitelist(guild_id)
        
        # Trigger callback
        change = WhitelistChange(
            guild_id=guild_id,
            user_id=user_id,
            action="added",
            moderator_id=moderator_id
        )
        await self.sdk._trigger_callbacks('whitelist_changed', change)
    
    async def remove(self, guild_id: int, user_id: int, moderator_id: int = None):
        """Remove user from guild whitelist"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
        
        if guild_id in self._whitelists:
            self._whitelists[guild_id].discard(user_id)
            await self._save_whitelist(guild_id)
            
            # Trigger callback
            change = WhitelistChange(
                guild_id=guild_id,
                user_id=user_id,
                action="removed",
                moderator_id=moderator_id
            )
            await self.sdk._trigger_callbacks('whitelist_changed', change)
    
    async def get_all(self, guild_id: int) -> List[int]:
        """Get all whitelisted users for guild"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
        return list(self._whitelists.get(guild_id, set()))
    
    async def is_whitelisted(self, guild_id: int, user_id: int) -> bool:
        """
        Check if user is whitelisted in specific guild.
        Uses cached data - instant response (no file I/O).
        """
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
        
        return user_id in self._whitelists.get(guild_id, set())
    
    async def clear(self, guild_id: int):
        """Clear all whitelisted users for a guild"""
        self._whitelists[guild_id] = set()
        await self._save_whitelist(guild_id)

