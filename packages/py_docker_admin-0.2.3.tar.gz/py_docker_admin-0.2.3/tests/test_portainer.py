# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for Portainer functionality."""

from unittest.mock import MagicMock, mock_open, patch

import pytest
import requests

from py_docker_admin.exceptions import PortainerAPIError, PortainerInstallationError
from py_docker_admin.models import PortainerConfig
from py_docker_admin.portainer import PortainerClient, PortainerInstaller


class TestPortainerClient:
    """Test PortainerClient class."""

    def test_portainer_client_initialization(self):
        """Test PortainerClient initialization."""
        client = PortainerClient("http://localhost:9000")
        assert client.base_url == "http://localhost:9000"
        assert client.session is not None
        assert client._auth_token is None

    def test_portainer_client_url_normalization(self):
        """Test URL normalization in PortainerClient."""
        client = PortainerClient("http://localhost:9000/")
        assert client.base_url == "http://localhost:9000"

    @patch("requests.Session.request")
    def test_request_success(self, mock_request):
        """Test successful API request."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_request.return_value = mock_response

        client = PortainerClient()
        result = client._request("GET", "test/endpoint")

        mock_request.assert_called_once()
        assert result == {"status": "success"}

    @patch("requests.Session.request")
    def test_request_with_auth_token(self, mock_request):
        """Test API request with authentication token."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "success"}
        mock_request.return_value = mock_response

        client = PortainerClient()
        client._auth_token = "test-token"

        client._request("GET", "test/endpoint")

        args, kwargs = mock_request.call_args
        assert kwargs["headers"]["Authorization"] == "Bearer test-token"

    @patch("requests.Session.request")
    def test_request_api_error(self, mock_request):
        """Test API request with error response."""
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = "Not found"
        mock_request.return_value = mock_response

        client = PortainerClient()

        with pytest.raises(
            PortainerAPIError, match="Portainer API error: 404 - Not found"
        ):
            client._request("GET", "test/endpoint")

    @patch("requests.Session.request")
    def test_request_connection_error(self, mock_request):
        """Test API request with connection error."""
        mock_request.side_effect = requests.exceptions.RequestException(
            "Connection failed"
        )

        client = PortainerClient()

        with pytest.raises(
            PortainerAPIError, match="Portainer API request failed: Connection failed"
        ):
            client._request("GET", "test/endpoint")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_admin_user_success(self, mock_request):
        """Test successful admin user creation."""
        mock_request.return_value = {"success": True}

        client = PortainerClient()
        result = client.create_admin_user("admin", "password123")

        mock_request.assert_called_once_with(
            "POST",
            "users/admin/init",
            json_data={"username": "admin", "password": "password123"},
        )
        assert result == {"success": True}

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_admin_user_failure(self, mock_request):
        """Test failed admin user creation."""
        mock_request.side_effect = PortainerAPIError("Creation failed")

        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Creation failed"):
            client.create_admin_user("admin", "password123")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_authenticate_success(self, mock_request):
        """Test successful authentication."""
        mock_request.return_value = {"jwt": "test-token"}

        client = PortainerClient()
        result = client.authenticate("admin", "password123")

        mock_request.assert_called_once_with(
            "POST", "auth", json_data={"username": "admin", "password": "password123"}
        )
        assert result == {"jwt": "test-token"}
        assert client._auth_token == "test-token"

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_authenticate_failure(self, mock_request):
        """Test failed authentication."""
        mock_request.side_effect = PortainerAPIError("Authentication failed")

        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Authentication failed"):
            client.authenticate("admin", "password123")

    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_get_endpoints(self, mock_request):
        """Test get_endpoints method."""
        mock_request.return_value = [{"id": 1, "name": "local"}]

        client = PortainerClient()
        result = client.get_endpoints()

        mock_request.assert_called_once_with("GET", "endpoints")
        assert result == [{"id": 1, "name": "local"}]

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_success(self, mock_request, mock_file):
        """Test successful stack creation."""
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        client = PortainerClient()
        result = client.create_stack(
            name="test-stack", compose_file="docker-compose.yml"
        )

        mock_file.assert_called_once_with("docker-compose.yml")
        mock_request.assert_called_once()
        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", new_callable=mock_open, read_data="version: '3.8'")
    @patch("py_docker_admin.portainer.PortainerClient._request")
    def test_create_stack_with_env_file(self, mock_request, mock_file):
        """Test stack creation with environment file."""
        mock_env_file = mock_open(
            read_data="VAR1=value1\nVAR2=value2\n# Comment\nVAR3=value3"
        )
        mock_request.return_value = {"id": 1, "name": "test-stack"}

        with patch("builtins.open", mock_env_file):
            client = PortainerClient()
            result = client.create_stack(
                name="test-stack", compose_file="docker-compose.yml", env_file="env.env"
            )

        mock_request.assert_called_once()
        args, kwargs = mock_request.call_args
        assert kwargs["json_data"]["env"] == {
            "VAR1": "value1",
            "VAR2": "value2",
            "VAR3": "value3",
        }
        assert result == {"id": 1, "name": "test-stack"}

    @patch("builtins.open", side_effect=OSError("File not found"))
    def test_create_stack_file_not_found(self, mock_file):
        """Test stack creation with missing compose file."""
        client = PortainerClient()

        with pytest.raises(PortainerAPIError, match="Failed to read compose file"):
            client.create_stack(name="test-stack", compose_file="missing.yml")


class TestPortainerInstaller:
    """Test PortainerInstaller class."""

    def test_portainer_installer_initialization(self):
        """Test PortainerInstaller initialization."""
        config = PortainerConfig()
        installer = PortainerInstaller(config)
        assert installer.config == config
        assert installer.logger is not None

    @patch("py_docker_admin.portainer.run_command")
    def test_is_portainer_running_true(self, mock_run_command):
        """Test is_portainer_running when Portainer is running."""
        mock_result = MagicMock()
        mock_result.stdout = "portainer\n"
        mock_run_command.return_value = mock_result

        config = PortainerConfig()
        installer = PortainerInstaller(config)
        result = installer.is_portainer_running()

        assert result is True
        mock_run_command.assert_called_once()

    @patch("py_docker_admin.portainer.run_command")
    def test_is_portainer_running_false(self, mock_run_command):
        """Test is_portainer_running when Portainer is not running."""
        mock_result = MagicMock()
        mock_result.stdout = ""
        mock_run_command.return_value = mock_result

        config = PortainerConfig()
        installer = PortainerInstaller(config)
        result = installer.is_portainer_running()

        assert result is False

    @patch("py_docker_admin.portainer.run_command")
    def test_remove_existing_container_success(self, mock_run_command):
        """Test remove_existing_container success."""
        config = PortainerConfig(remove_existing=True)
        installer = PortainerInstaller(config)

        installer.remove_existing_container()

        mock_run_command.assert_called_once_with(
            "docker rm -f portainer", log_level="info"
        )

    @patch("py_docker_admin.portainer.run_command")
    def test_remove_existing_container_disabled(self, mock_run_command):
        """Test remove_existing_container when disabled."""
        config = PortainerConfig(remove_existing=False)
        installer = PortainerInstaller(config)

        installer.remove_existing_container()

        mock_run_command.assert_not_called()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_success(self, mock_run_command, mock_wait):
        """Test install_portainer success."""
        config = PortainerConfig()
        installer = PortainerInstaller(config)

        installer.install_portainer()

        # Should be called twice: once for is_portainer_running, once for actual install
        assert mock_run_command.call_count == 2
        args, kwargs = mock_run_command.call_args
        assert "docker run -d --name portainer" in args[0]
        assert "-p 9000:9000" in args[0]
        assert "portainer/portainer-ce:latest" in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.wait_for_portainer")
    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_custom_config(self, mock_run_command, mock_wait):
        """Test install_portainer with custom configuration."""
        config = PortainerConfig(
            container_name="my-portainer",
            port=9443,
            volume="/custom/socket:/var/run/docker.sock",
        )
        installer = PortainerInstaller(config)

        installer.install_portainer()

        args, kwargs = mock_run_command.call_args
        assert "--name my-portainer" in args[0]
        assert "-p 9443:9000" in args[0]
        assert "/custom/socket:/var/run/docker.sock" in args[0]
        mock_wait.assert_called_once()

    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_already_running(self, mock_run_command):
        """Test install_portainer when already running."""
        config = PortainerConfig()
        installer = PortainerInstaller(config)

        with patch.object(installer, "is_portainer_running", return_value=True):
            installer.install_portainer()

        mock_run_command.assert_not_called()

    @patch("py_docker_admin.portainer.run_command")
    def test_install_portainer_failure(self, mock_run_command):
        """Test install_portainer failure."""
        mock_run_command.side_effect = Exception("Installation failed")

        config = PortainerConfig()
        installer = PortainerInstaller(config)

        with pytest.raises(
            PortainerInstallationError, match="Failed to install Portainer"
        ):
            installer.install_portainer()

    @patch("py_docker_admin.portainer.PortainerClient.create_admin_user")
    @patch("py_docker_admin.portainer.PortainerClient.authenticate")
    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_success(self, mock_install, mock_auth, mock_create_admin):
        """Test setup_portainer success."""
        config = PortainerConfig(admin_username="admin", admin_password="password123")
        installer = PortainerInstaller(config)

        client = installer.setup_portainer()

        mock_install.assert_called_once()
        mock_create_admin.assert_called_once_with("admin", "password123")
        mock_auth.assert_called_once_with("admin", "password123")
        assert isinstance(client, PortainerClient)

    @patch("py_docker_admin.portainer.PortainerInstaller.install_portainer")
    def test_setup_portainer_failure(self, mock_install):
        """Test setup_portainer failure."""
        mock_install.side_effect = Exception("Setup failed")

        config = PortainerConfig()
        installer = PortainerInstaller(config)

        with pytest.raises(PortainerInstallationError, match="Portainer setup failed"):
            installer.setup_portainer()
