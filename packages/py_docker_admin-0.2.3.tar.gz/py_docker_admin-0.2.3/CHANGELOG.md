# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.3] - 2026-01-18

### Added
- Added `uninstall` command to CLI for complete Docker removal
- Implemented container, volume, network, and image cleanup functionality
- Added Docker package uninstallation with data removal options
- Added `--remove-data/--keep-data` flag to control data cleanup

### Changed
- Updated version to 0.2.3
- Enhanced DockerInstaller class with comprehensive uninstall methods

## [0.2.2] - 2026-01-18

### Added
- Created `publish_wheel.sh` script for automated PyPI publication
- Added comprehensive error handling and user confirmation in publication script
- Added cleanup step to remove dist folder after successful upload

### Changed
- Improved logging and code guidelines using ruff
- Enhanced project documentation with publication guide

## [0.2.1] - 2026-01-17

### Added
- Basic project structure with core functionality
- Initial Docker and Portainer automation features
- Core CLI commands and utilities
- Basic testing framework with pytest
- Initial documentation

### Changed
- Refactored code structure for better maintainability
- Improved error handling in core modules
- Enhanced type annotations and code quality

## [0.2.0] - 2026-01-15

### Added
- Initial project setup
- Basic Docker automation capabilities
- Core models and utilities
- First version of CLI interface
- Initial test suite

### Changed
- Project structure organization
- Documentation improvements
- Code quality enhancements
