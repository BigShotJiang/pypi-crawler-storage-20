"""Package manager UI components."""
