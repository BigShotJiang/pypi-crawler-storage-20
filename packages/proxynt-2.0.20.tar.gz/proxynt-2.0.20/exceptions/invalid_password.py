class InvalidPassword(Exception):
    pass