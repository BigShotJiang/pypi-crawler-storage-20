import{J as i}from"./index.DiwhD0Ic.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
