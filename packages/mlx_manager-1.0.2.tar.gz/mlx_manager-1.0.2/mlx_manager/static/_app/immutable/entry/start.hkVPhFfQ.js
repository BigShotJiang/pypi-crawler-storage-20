import{l as o,a as r}from"../chunks/COzvXrpK.js";export{o as load_css,r as start};
