# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from typing_extensions import Literal, Required, TypedDict

from .context_param import ContextParam

__all__ = ["AgentInvokeParamsBase", "AgentInvokeParamsNonStreaming", "AgentInvokeParamsStreaming"]


class AgentInvokeParamsBase(TypedDict, total=False):
    input: Required[Dict[str, Optional[object]]]
    """Input data for the agent. Structure depends on agent implementation."""

    context: ContextParam
    """Optional request context passed to the agent handler."""


class AgentInvokeParamsNonStreaming(AgentInvokeParamsBase, total=False):
    stream: Literal[False]
    """Whether to stream the response as SSE."""


class AgentInvokeParamsStreaming(AgentInvokeParamsBase):
    stream: Required[Literal[True]]
    """Whether to stream the response as SSE."""


AgentInvokeParams = Union[AgentInvokeParamsNonStreaming, AgentInvokeParamsStreaming]
