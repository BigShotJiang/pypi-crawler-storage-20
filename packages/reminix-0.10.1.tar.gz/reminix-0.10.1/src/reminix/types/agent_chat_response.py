# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from .._models import BaseModel
from .chat_message import ChatMessage

__all__ = ["AgentChatResponse"]


class AgentChatResponse(BaseModel):
    messages: List[ChatMessage]
    """Full conversation history including the assistant response"""

    output: str
    """Final assistant response text"""
