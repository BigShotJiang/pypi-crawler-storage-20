# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["StreamChunk"]


class StreamChunk(BaseModel):
    chunk: str
    """Text chunk from the stream"""
