# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable
from typing_extensions import Literal, Required, TypedDict

from .context_param import ContextParam
from .chat_message_param import ChatMessageParam

__all__ = ["AgentChatParamsBase", "AgentChatParamsNonStreaming", "AgentChatParamsStreaming"]


class AgentChatParamsBase(TypedDict, total=False):
    messages: Required[Iterable[ChatMessageParam]]
    """Conversation history. Must include at least one message."""

    context: ContextParam
    """Optional request context passed to the agent handler."""


class AgentChatParamsNonStreaming(AgentChatParamsBase, total=False):
    stream: Literal[False]
    """Whether to stream the response as SSE."""


class AgentChatParamsStreaming(AgentChatParamsBase):
    stream: Required[Literal[True]]
    """Whether to stream the response as SSE."""


AgentChatParams = Union[AgentChatParamsNonStreaming, AgentChatParamsStreaming]
