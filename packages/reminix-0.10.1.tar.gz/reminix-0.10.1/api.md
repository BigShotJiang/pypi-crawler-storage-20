# Projects

Types:

```python
from reminix.types import PaginationCursor, Project
```

Methods:

- <code title="get /projects/current">client.projects.<a href="./src/reminix/resources/projects.py">retrieve_current</a>() -> <a href="./src/reminix/types/project.py">Project</a></code>

# Agents

Types:

```python
from reminix.types import ChatMessage, Context, StreamChunk, AgentChatResponse, AgentInvokeResponse
```

Methods:

- <code title="post /agents/{name}/chat">client.agents.<a href="./src/reminix/resources/agents.py">chat</a>(name, \*\*<a href="src/reminix/types/agent_chat_params.py">params</a>) -> <a href="./src/reminix/types/agent_chat_response.py">AgentChatResponse</a></code>
- <code title="post /agents/{name}/invoke">client.agents.<a href="./src/reminix/resources/agents.py">invoke</a>(name, \*\*<a href="src/reminix/types/agent_invoke_params.py">params</a>) -> <a href="./src/reminix/types/agent_invoke_response.py">AgentInvokeResponse</a></code>

# ClientTokens

Types:

```python
from reminix.types import ClientTokenCreateResponse
```

Methods:

- <code title="post /client-tokens">client.client_tokens.<a href="./src/reminix/resources/client_tokens.py">create</a>(\*\*<a href="src/reminix/types/client_token_create_params.py">params</a>) -> <a href="./src/reminix/types/client_token_create_response.py">ClientTokenCreateResponse</a></code>
- <code title="delete /client-tokens/{id}">client.client_tokens.<a href="./src/reminix/resources/client_tokens.py">revoke</a>(id) -> None</code>
