"""AskUser tool for LLM to request human input.

This tool allows the LLM to pause execution and ask the user
for clarification or additional information.
"""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

from ..tool import BaseTool, ToolResult
from ..core.types.session import generate_id
from ..core.types.block import BlockEvent
from .exceptions import HITLSuspendError, HITLRequest

if TYPE_CHECKING:
    from ..core.context import InvocationContext


class AskUserTool(BaseTool):
    """Tool for LLM to ask user questions.
    
    When executed, this tool:
    1. Checkpoints current state
    2. Updates invocation status to SUSPENDED
    3. Emits a hitl_request block to frontend
    4. Raises HITLSuspendError to pause execution
    
    The user's response comes via:
    - agent.respond(request_id, response)
    - agent.run(response) (auto-detects suspended state)
    """
    
    _name = "ask_user"
    _description = "Ask the user for clarification or additional information. Use this when you need more details to complete a task."
    _parameters = {
        "type": "object",
        "properties": {
            "question": {
                "type": "string",
                "description": "The question to ask the user",
            },
            "options": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Optional list of suggested answers",
            },
            "context": {
                "type": "string",
                "description": "Additional context about why you're asking",
            },
        },
        "required": ["question"],
    }
    
    async def execute(
        self,
        question: str,
        options: list[str] | None = None,
        context: str | None = None,
        *,
        ctx: "InvocationContext | None" = None,
    ) -> ToolResult:
        """Execute ask_user tool.
        
        This method does NOT return normally - it raises HITLSuspendError
        to pause the agent execution.
        
        Args:
            question: Question to ask the user
            options: Optional predefined answer options
            context: Additional context
            ctx: Invocation context (injected by agent)
            
        Returns:
            Never returns normally
            
        Raises:
            HITLSuspendError: Always raised to suspend execution
        """
        if ctx is None:
            # If no context, return error (should not happen in normal use)
            return ToolResult.error("Cannot ask user without execution context")
        
        # Generate request ID
        request_id = generate_id("req")
        
        # Create HITL request data
        request = HITLRequest(
            request_id=request_id,
            request_type="ask_user",
            message=question,
            options=options,
            tool_name=self._name,
            metadata={"context": context} if context else {},
        )
        
        # Checkpoint current state
        if hasattr(ctx, "state") and ctx.state is not None:
            await ctx.state.checkpoint()
        
        # Update invocation status to SUSPENDED
        if ctx.storage:
            await ctx.storage.set("invocations", ctx.invocation_id, {
                "status": "suspended",
                "pending_request_id": request_id,
                "pending_request_type": "ask_user",
                "pending_request_data": request.to_dict(),
            })
        
        # Emit HITL request block to frontend
        await ctx.emit(BlockEvent(
            kind="hitl_request",
            data={
                "request_id": request_id,
                "type": "ask_user",
                "question": question,
                "options": options,
                "context": context,
            },
        ))
        
        # Raise exception to suspend execution
        raise HITLSuspendError(
            request_id=request_id,
            request_type="ask_user",
            message=question,
            options=options,
            metadata={"context": context} if context else {},
        )


class ConfirmTool(BaseTool):
    """Tool for LLM to request confirmation before proceeding.
    
    Similar to ask_user but specifically for yes/no confirmations.
    """
    
    _name = "confirm"
    _description = "Ask the user to confirm an action before proceeding."
    _parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "description": "The action you want to perform",
            },
            "details": {
                "type": "string",
                "description": "Details about the action",
            },
            "risk_level": {
                "type": "string",
                "enum": ["low", "medium", "high"],
                "description": "Risk level of the action",
            },
        },
        "required": ["action"],
    }
    
    async def execute(
        self,
        action: str,
        details: str | None = None,
        risk_level: str = "medium",
        *,
        ctx: "InvocationContext | None" = None,
    ) -> ToolResult:
        """Execute confirm tool.
        
        Args:
            action: Action to confirm
            details: Additional details
            risk_level: Risk level (low, medium, high)
            ctx: Invocation context
            
        Raises:
            HITLSuspendError: Always raised to suspend execution
        """
        if ctx is None:
            return ToolResult.error("Cannot confirm without execution context")
        
        request_id = generate_id("req")
        
        message = f"Confirm: {action}"
        if details:
            message += f"\n\nDetails: {details}"
        
        request = HITLRequest(
            request_id=request_id,
            request_type="confirm",
            message=message,
            options=["Yes, proceed", "No, cancel"],
            tool_name=self._name,
            metadata={
                "action": action,
                "details": details,
                "risk_level": risk_level,
            },
        )
        
        # Checkpoint
        if hasattr(ctx, "state") and ctx.state is not None:
            await ctx.state.checkpoint()
        
        # Update invocation
        if ctx.storage:
            await ctx.storage.set("invocations", ctx.invocation_id, {
                "status": "suspended",
                "pending_request_id": request_id,
                "pending_request_type": "confirm",
                "pending_request_data": request.to_dict(),
            })
        
        # Emit block
        await ctx.emit(BlockEvent(
            kind="hitl_request",
            data={
                "request_id": request_id,
                "type": "confirm",
                "action": action,
                "details": details,
                "risk_level": risk_level,
                "options": ["Yes, proceed", "No, cancel"],
            },
        ))
        
        raise HITLSuspendError(
            request_id=request_id,
            request_type="confirm",
            message=message,
            options=["Yes, proceed", "No, cancel"],
            metadata=request.metadata,
        )


__all__ = ["AskUserTool", "ConfirmTool"]
