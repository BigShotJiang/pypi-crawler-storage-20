from yta_math_easings.animated.abstract import EasingAnimatedFunction
from yta_math_easings.enums import EasingFunctionName
from yta_math_easings.slow_into import SlowIntoEasing


class SlowIntoAnimatedEasing(EasingAnimatedFunction):
    """
    A slow into function but animated, including a
    range of values and a duration.

    The formula:
    - `np.sqrt(1 - (1 - t_normalized) * (1 - t_normalized))`
    """
    name: str = EasingFunctionName.SLOW_INTO.value

    def __init__(
        self,
        start_value: float,
        end_value: float,
        duration: float
    ):
        super().__init__(
            start_value = start_value,
            end_value = end_value,
            duration = duration,
            easing_function = SlowIntoEasing()
        )