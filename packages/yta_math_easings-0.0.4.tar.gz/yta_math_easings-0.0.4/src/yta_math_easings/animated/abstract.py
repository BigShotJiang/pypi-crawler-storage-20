"""
Some explanations to let you understand it better:
Entrada (t): tiempo normalizado en [0, 1].
Salida (a): progreso no lineal en [0, 1].

En animación siempre hay dos espacios independientes:

A. Espacio temporal (time domain)
Tiempo real:
    t ∈ [0, duration]
Tiempo normalizado (también llamado normalized time, alpha):
    u ∈ [0, 1]
    u = t / duration

B. Espacio de valores (value domain)
Valor real:
    v ∈ [start_value, end_value]
Valor normalizado:
    p ∈ [0, 1]


When we talk about easing, we receive a normalized
time moment (u ∈ [0, 1]) and we obtain the normalized
value (p ∈ [0, 1]) associated to that normalized time
moment.

"""
from yta_math_easings.abstract import EasingFunction
from yta_math_easings.enums import EasingFunctionName
from yta_validation.parameter import ParameterValidator
from abc import ABC


class EasingAnimatedFunction(ABC):
    """
    *Abstract class*

    Abstract class to be inherited by the specific
    easing implementations.

    An easing function that is able to calculate a
    value according to the `n` parameter provided,
    but within a range of possible values and
    according to the duration set.

    The `t_normalized` value is representing the
    time elapsed for the easing function, as a
    normalized value in the `[0.0, 1.0]` range.

    The `value_normalized` (also known as alpha)
    value is representing the progress for the
    easing function, as a normalized value in
    the `[0.0, 1.0]` range.
    """
    _limit = (0.0, 1.0)
    """
    *For internal use only*

    The limit of the alpha value we can use.
    """
    _REGISTRY: dict[str, type['EasingFunction']] = {}
    """
    A register to simplify the way we instantiate
    new classes from strings.
    """
    name: str
    """
    The string name of the specific easing implementation
    class.
    """

    def __init_subclass__(
        cls,
        **kwargs
    ):
        """
        Init the subclass and register it.
        """
        super().__init_subclass__(**kwargs)

        if hasattr(cls, 'name'):
            EasingAnimatedFunction._REGISTRY[cls.name] = cls

    @classmethod
    def get(
        cls,
        name: EasingFunctionName
    ) -> type['EasingAnimatedFunction']:
        """
        Get the specific class associated to the given
        easing animated function `name`.
        """
        name = EasingFunctionName.to_enum(name)

        return cls._REGISTRY[name.value]

    def __init__(
        self,
        start_value: float,
        end_value: float,
        duration: float,
        easing_function: EasingFunction
    ):
        ParameterValidator.validate_mandatory_number('start_value', start_value, do_include_zero = True)
        ParameterValidator.validate_mandatory_number('end_value', end_value, do_include_zero = True)
        ParameterValidator.validate_mandatory_positive_number('duration', duration, do_include_zero = False)
        ParameterValidator.validate_mandatory_instance_of('easing_function', easing_function, EasingFunction)

        self.start_value: float = start_value
        """
        The start value of the valid range of the animated
        easing function.
        """
        self.end_value: float = end_value
        """
        The end value of the valid range of the animated
        easing function.
        """
        self.duration: float = duration
        """
        The total duration (in seconds) that the animated
        easing will take to go from the `start_value`
        to the `end_value`, that can be used to calculate
        the different values at the different time moments
        requested by the user.
        """
        self._easing_function: EasingFunction = easing_function
        """
        The easing function associated to this animated
        easing function, that will be the one used to
        calculate the values according to the definition.
        """

    def ease(
        self,
        t_normalized: float,
        **kwargs
    ) -> float:
        """
        Apply the easing to the `t_normalized` value provided,
        that must be a value in the `[0.0, 1.0]` range, to
        obtain the normalized value associated to it.

        It will transform the `t_normalized` into the real t
        time moment, and use it to calculate the value 
        associated to it, but returning it normalized.

        What do you get:
        - The `value` but normalized (in `[0.0, 1.0]` range).
        """
        return self._easing_function.ease(
            t_normalized = t_normalized,
            **kwargs
        )

    def get_value_from_t_normalized(
        self,
        t_normalized: float,
        **kwargs
    ) -> float:
        """
        Get the real value (in between the `start_value` and
        the `end_value`) according to the normalized `t` time
        moment provided (must be a value in the `[0.0, 1.0]`
        range).

        What do you get:
        - The real `value` (in `[start_value, end_value]`
        range).
        """
        ParameterValidator.validate_mandatory_number_between(
            name = 't_normalized',
            value = t_normalized,
            lower_limit = 0.0,
            upper_limit = 1.0,
            do_include_lower_limit = True,
            do_include_upper_limit = True
        )

        value_normalized = self.ease(
            t_normalized = t_normalized,
            **kwargs
        )

        return self.start_value * (1 - value_normalized) + self.end_value * value_normalized
    
    def get_value_from_t(
        self,
        t: float,
        **kwargs
    ) -> float:
        """
        Get the real value (in between the `start_value` and
        the `end_value`) for the real `t` time moment provided
        (that must be in the range `[0.0, self.duration]`).

        What do you get:
        - The real `value` (in `[start_value, end_value]`
        range).
        """
        ParameterValidator.validate_mandatory_number_between(
            name = 't',
            value = t,
            lower_limit = 0.0,
            upper_limit = self.duration,
            do_include_lower_limit = True,
            # TODO: Do we include the upper limit (?)
            do_include_upper_limit = True
        )

        return self.get_value_from_t_normalized(
            progress_normalized = self.get_t_normalized_from_t(
                t = t
            ),
            **kwargs
        )
    
    # Utils below
    def get_t_from_t_normalized(
        self,
        t_normalized: float
    ) -> float:
        """
        Get the real time moment associated to the 
        `t_normalized` provided (that must be a value
        in the range `[0.0, 1.0]`).
        """
        ParameterValidator.validate_mandatory_number_between(
            name = 't_normalized',
            value = t_normalized,
            lower_limit = self._limit[0],
            upper_limit = self._limit[1],
            do_include_lower_limit = True,
            do_include_upper_limit = True
        )

        return t_normalized * self.duration
    
    def get_t_normalized_from_t(
        self,
        t: float
    ) -> float:
        """
        Get the normalized t according to the real
        `t` time moment provided.
        """
        ParameterValidator.validate_mandatory_number_between(
            name = 't',
            value = t,
            lower_limit = 0.0,
            upper_limit = self.duration,
            do_include_lower_limit = True,
            # TODO: Do we include the upper limit (?)
            do_include_upper_limit = True
        )

        return t / self.duration
    
    def get_value_from_value_normalized(
        self,
        value_normalized: float
    ) -> float:
        """
        Get the real valule associated to the `value_normalized`
        given as parameter.
        """
        # TODO: We should not do this because in some easing
        # functions we have values out of the 0.0 and 1.0
        # limits...
        ParameterValidator.validate_mandatory_number_between(
            name = 'value_normalized',
            value = value_normalized,
            lower_limit = self._limit[0],
            upper_limit = self._limit[1],
            do_include_lower_limit = True,
            do_include_upper_limit = True
        )

        return self.start_value + value_normalized * (self.end_value - self.start_value)
    
    def get_value_normalized_from_value(
        self,
        value: float
    ) -> float:
        """
        Get the value normalized associated to the `value`
        given as parameter.
        """
        # TODO: We should not do this because in some easing
        # functions we have values out of the 0.0 and 1.0
        # limits...
        ParameterValidator.validate_mandatory_number_between(
            name = 'value',
            value = value,
            lower_limit = self.start_value,
            upper_limit = self.end_value,
            do_include_lower_limit = True,
            do_include_upper_limit = True
        )
        
        return (value - self.start_value) / (self.end_value - self.start_value)

    def __call__(
        self,
        t_normalized: float,
        **kwargs
    ) -> float:
        """
        Special method to allow us doing
        `AnimatedEasingFunction.ease(alpha)` directly.
        """

        """
        This `.__call__` allows us to do this:
        ```
        linear_animated_easing = LinearAnimatedEasing(2.0, 6.0, 1.0)
        linear_animated_easing(0.5)
        ```
        """
        return self.ease(
            t_normalized = t_normalized,
            **kwargs
        )