from __future__ import annotations
import collections.abc
import typing
from . import actions
from . import chunk_store
from . import data
from . import nodes
from . import redis
from . import service
from . import webrtc
from . import websockets
__all__: list[str] = ['AbslStringMap', 'GlobalSettings', 'actions', 'chunk_store', 'data', 'get_global_settings', 'nodes', 'redis', 'run_threadsafe_if_coroutine', 'save_first_encountered_event_loop', 'service', 'webrtc', 'websockets']
class AbslStringMap:
    def __bool__(self) -> bool:
        """
        Check whether the map is nonempty
        """
    @typing.overload
    def __contains__(self, arg0: str) -> bool:
        ...
    @typing.overload
    def __contains__(self, arg0: typing.Any) -> bool:
        ...
    def __delitem__(self, arg0: str) -> None:
        ...
    def __getitem__(self, arg0: str) -> str:
        ...
    def __init__(self) -> None:
        ...
    def __iter__(self) -> collections.abc.Iterator[str]:
        ...
    def __len__(self) -> int:
        ...
    def __repr__(self) -> str:
        """
        Return the canonical string representation of this map.
        """
    def __setitem__(self, arg0: str, arg1: str) -> None:
        ...
    def items(self) -> typing.ItemsView:
        ...
    def keys(self) -> typing.KeysView:
        ...
    def values(self) -> typing.ValuesView:
        ...
class GlobalSettings:
    readers_deserialise_automatically: bool
    readers_read_in_order: bool
    readers_remove_read_chunks: bool
    @property
    def readers_buffer_size(self) -> int:
        ...
    @readers_buffer_size.setter
    def readers_buffer_size(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def readers_timeout(self) -> float:
        ...
    @readers_timeout.setter
    def readers_timeout(self, arg1: typing.SupportsFloat) -> None:
        ...
def get_global_settings() -> GlobalSettings:
    ...
def run_threadsafe_if_coroutine(function_call_result: typing.Any, loop: typing.Any = None, return_future: bool = False) -> typing.Any:
    ...
def save_first_encountered_event_loop() -> None:
    """
    Saves the first encountered event loop globally for later use.
    """
