"""
Goblin Core Generator - Advanced Image Generation with Full Parameter Support
"""
import asyncio
import random
import base64
import re
import os
import threading
import time
from typing import Optional, Literal, Any
from dataclasses import dataclass, field

import cloudscraper

from .models import MODELS, get_model, get_model_defaults, get_model_styles, list_models
from .parameters import (
    build_prompt, get_resolution, get_style, get_quality, get_lighting,
    get_camera, get_composition, get_expression,
    STYLES, QUALITY_PRESETS, LIGHTING_PRESETS, CAMERA_PRESETS,
    COMPOSITION_PRESETS, EXPRESSION_PRESETS, RESOLUTIONS, AVAILABLE_OPTIONS
)

# Key cache file
_KEY_FILE = os.path.join(os.path.dirname(__file__), ".gkey")


@dataclass
class GenerateRequest:
    """Image generation request with all parameters"""
    prompt: str
    negative_prompt: str = ""
    model: str = "goblin-sd"

    # Basic parameters
    shape: str = "square"
    seed: int = -1
    guidance_scale: Optional[float] = None  # None = use model default

    # Style parameters
    style: str = "default"
    quality: str = "standard"

    # Advanced parameters
    lighting: str = "auto"
    camera: str = "auto"
    composition: str = "auto"
    expression: str = "auto"

    # Extra options
    style_strength: float = 1.0
    remove_background: bool = False

    # Model-specific extras (passed through)
    extras: dict = field(default_factory=dict)


class Goblin:
    """
    Goblin Image Generator

    Free AI image generation with 34 models and comprehensive parameter support.

    Usage:
        async with Goblin() as goblin:
            # Simple generation
            image = await goblin.generate("a beautiful sunset")

            # With style and quality
            image = await goblin.generate(
                "a warrior princess",
                model="goblin-anime",
                style="ghibli",
                quality="ultra",
                lighting="golden-hour"
            )

            # With photography parameters
            image = await goblin.generate(
                "professional headshot",
                model="goblin-portrait",
                camera="portrait-85mm",
                lighting="studio",
                expression="confident"
            )

            # Get all available options
            options = goblin.available_options
    """

    _E = "aW1hZ2UtZ2VuZXJhdGlvbi5wZXJjaGFuY2Uub3Jn"
    _P = "L2FwaS8="
    _G = "cGVyY2hhbmNlLm9yZy9haS10ZXh0LXRvLWltYWdlLWdlbmVyYXRvcg=="

    def __init__(self):
        self._s = None
        self._k = None
        self._keep_alive_task = None
        self._running = False

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, *args):
        await self.close()

    @property
    def _b(self):
        return f"https://{base64.b64decode(self._E).decode()}{base64.b64decode(self._P).decode()}"

    @property
    def _gen_url(self):
        return f"https://{base64.b64decode(self._G).decode()}"

    async def start(self):
        """Initialize the generator"""
        self._s = cloudscraper.create_scraper()
        self._running = True

        # Try to load cached key
        self._k = self._load_cached_key()

        # If no valid key, get one
        if not self._k:
            await self._gk()

        # Start keep-alive background task
        self._keep_alive_task = asyncio.create_task(self._keep_alive_loop())

    async def close(self):
        """Cleanup resources"""
        self._running = False
        if self._keep_alive_task:
            self._keep_alive_task.cancel()
            try:
                await self._keep_alive_task
            except asyncio.CancelledError:
                pass
        self._s = None

    def _load_cached_key(self) -> Optional[str]:
        """Load key from cache file if valid"""
        try:
            if os.path.exists(_KEY_FILE):
                with open(_KEY_FILE, 'r') as f:
                    key = f.read().strip()
                if key and self._verify_key(key):
                    return key
        except:
            pass
        return None

    def _save_cached_key(self, key: str):
        """Save key to cache file"""
        try:
            with open(_KEY_FILE, 'w') as f:
                f.write(key)
        except:
            pass

    def _verify_key(self, key: str) -> bool:
        """Check if key is still valid"""
        try:
            url = f"{self._b}checkVerificationStatus?userKey={key}&__cacheBust={random.random()}"
            r = self._s.get(url, timeout=10)
            return "not_verified" not in r.text and "invalid" not in r.text.lower()
        except:
            return False

    async def _keep_alive_loop(self):
        """Background task to keep the key alive"""
        while self._running:
            try:
                await asyncio.sleep(120)  # Check every 2 minutes

                if not self._running:
                    break

                # Verify key is still valid
                if self._k and not self._verify_key(self._k):
                    print("[Goblin] Key expired, refreshing...")
                    self._k = None
                    await self._gk()

            except asyncio.CancelledError:
                break
            except Exception as e:
                pass

    async def _capture_key_from_browser(self) -> str:
        """Launch browser with xvfb on Linux, click buttons, capture userKey"""
        from patchright.async_api import async_playwright
        import subprocess
        import sys
        import platform

        # Auto-install browser if needed
        try:
            subprocess.run(
                [sys.executable, "-m", "patchright", "install", "chromium"],
                capture_output=True, timeout=120
            )
        except:
            pass

        captured_key = None
        is_linux = platform.system() == "Linux"

        async with async_playwright() as p:
            # On Linux servers: use xvfb virtual display with headed browser
            # On Windows/Mac: use headed browser off-screen
            if is_linux:
                browser = await p.chromium.launch(
                    headless=False,
                    args=[
                        '--no-sandbox',
                        '--disable-setuid-sandbox',
                        '--disable-dev-shm-usage',
                        '--disable-gpu'
                    ]
                )
            else:
                browser = await p.chromium.launch(
                    headless=False,
                    args=[
                        '--window-position=-32000,-32000',
                        '--window-size=1,1'
                    ]
                )
            page = await browser.new_page()

            def handle_request(request):
                nonlocal captured_key
                if "userKey=" in request.url and not captured_key:
                    match = re.search(r'userKey=([a-f\d]{64})', request.url)
                    if match:
                        captured_key = match.group(1)

            page.on("request", handle_request)

            await page.goto(self._gen_url, timeout=60000)
            await asyncio.sleep(5)

            # Find generator iframe and click buttons
            for frame in page.frames:
                if '.perchance.org/ai-text-to-image-generator' in frame.url:
                    await frame.click('.random-input-btn', timeout=5000)
                    await asyncio.sleep(0.5)
                    await frame.click('#generateButtonEl', timeout=5000)
                    break

            # Wait for key
            for _ in range(20):
                if captured_key:
                    break
                await asyncio.sleep(1)

            await browser.close()

        if not captured_key:
            raise Exception("Failed to capture key from browser")

        return captured_key

    async def _gk(self):
        """Get authentication key"""
        # First check if cached key is valid
        if self._k and self._verify_key(self._k):
            return self._k

        # Try verifyUser endpoint directly (sometimes works without token)
        try:
            r = self._s.get(f"{self._b}verifyUser?thread=0&__cacheBust={random.random()}", timeout=10)
            d = r.json()
            if d.get("userKey"):
                self._k = d["userKey"]
                self._save_cached_key(self._k)
                return self._k
        except:
            pass

        # Fall back to browser capture
        self._k = await self._capture_key_from_browser()
        self._save_cached_key(self._k)
        return self._k

    @property
    def models(self) -> dict:
        """Get available models with their parameters"""
        return list_models()

    @property
    def available_options(self) -> dict:
        """Get all available parameter options"""
        return AVAILABLE_OPTIONS

    def get_model(self, model_id: str) -> dict:
        """Get detailed model info including supported parameters"""
        return get_model(model_id)

    def get_model_styles(self, model_id: str) -> list:
        """Get styles supported by a specific model"""
        return get_model_styles(model_id)

    def _build_final_prompt(
        self,
        base_prompt: str,
        base_negative: str,
        style: str,
        quality: str,
        lighting: str,
        camera: str,
        composition: str,
        expression: str,
    ) -> tuple[str, str]:
        """Build the final prompt with all modifiers"""
        enhanced_prompt, enhanced_negative = build_prompt(
            base_prompt,
            style=style,
            quality=quality,
            lighting=lighting,
            camera=camera,
            composition=composition,
            expression=expression
        )

        # Merge user's negative prompt
        if base_negative:
            enhanced_negative = f"{base_negative}, {enhanced_negative}" if enhanced_negative else base_negative

        return enhanced_prompt, enhanced_negative

    async def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        model: str = "goblin-sd",
        shape: str = "square",
        seed: int = -1,
        guidance_scale: Optional[float] = None,
        style: str = "default",
        quality: str = "standard",
        lighting: str = "auto",
        camera: str = "auto",
        composition: str = "auto",
        expression: str = "auto",
        style_strength: float = 1.0,
        remove_background: bool = False,
        return_bytes: bool = True,
        **extras
    ) -> bytes | dict:
        """
        Generate an image with full parameter support.

        Args:
            prompt: Text description of the image
            negative_prompt: Things to avoid in the image
            model: Model ID (use .models to see all 34 models)
            shape: Image shape (square, portrait, landscape, square-lg, etc.)
            seed: Seed for reproducibility (-1 for random)
            guidance_scale: How closely to follow prompt (None = use model default)
            style: Art style preset (cinematic, anime, photo, etc.)
            quality: Quality preset (standard, high, ultra, maximum)
            lighting: Lighting preset (natural, studio, golden-hour, neon, etc.)
            camera: Camera preset for realistic models (portrait-85mm, wide-35mm, etc.)
            composition: Shot composition (closeup, medium, full-body, wide, etc.)
            expression: Character expression (happy, serious, mysterious, etc.)
            style_strength: How strongly to apply the style (0.0-1.0)
            remove_background: Attempt to generate transparent PNG
            return_bytes: If True returns image bytes, else returns metadata dict
            **extras: Additional model-specific parameters

        Returns:
            Image bytes (JPEG) or dict with image_id and metadata
        """
        if not self._s:
            await self.start()

        # Get model config
        m = get_model(model)
        if not m:
            raise ValueError(f"Unknown model: {model}. Use .models to see available models.")

        # Get model defaults
        defaults = get_model_defaults(model)

        # Apply model defaults if not specified
        if guidance_scale is None:
            guidance_scale = defaults.get("guidance_scale", 7.0)
        if style == "default" and "style" in defaults:
            style = defaults["style"]
        if quality == "standard" and "quality" in defaults:
            quality = defaults["quality"]

        # Build enhanced prompt with all modifiers
        final_prompt, final_negative = self._build_final_prompt(
            prompt, negative_prompt,
            style, quality, lighting, camera, composition, expression
        )

        # Get resolution
        res = get_resolution(shape)

        # Channel from model
        ch = m["channel"]

        for attempt in range(3):
            try:
                # Ensure we have a valid key
                if not self._k or not self._verify_key(self._k):
                    await self._gk()

                url = f"{self._b}generate?userKey={self._k}&requestId=gen{random.randint(0,2**30)}&__cacheBust={random.random()}"

                body = {
                    "generatorName": "ai-image-generator",
                    "channel": ch,
                    "subChannel": "public",
                    "prompt": final_prompt,
                    "negativePrompt": final_negative,
                    "seed": seed,
                    "resolution": res,
                    "guidanceScale": guidance_scale
                }

                # Add remove background if requested
                if remove_background:
                    body["removeBackground"] = True

                r = self._s.post(url, json=body, timeout=30)
                d = r.json()

                if d.get("imageId"):
                    if not return_bytes:
                        return {
                            "image_id": d["imageId"],
                            "seed": d.get("seed"),
                            "model": model,
                            "prompt": final_prompt,
                            "negative_prompt": final_negative,
                            "resolution": res,
                            "guidance_scale": guidance_scale,
                            "style": style,
                            "quality": quality,
                        }

                    # Download image
                    img_url = f"{self._b}downloadTemporaryImage?imageId={d['imageId']}"
                    img_r = self._s.get(img_url, timeout=30)
                    if img_r.status_code == 200:
                        return img_r.content
                    raise Exception("Failed to download image")

                status = d.get("status", "")
                if status == "waiting_for_prev_request_to_finish":
                    await asyncio.sleep(2)
                    continue
                elif "invalid" in status.lower() or "failed" in status.lower():
                    self._k = None
                    continue
                else:
                    raise Exception(f"Generation failed: {d}")

            except Exception as e:
                self._k = None
                if attempt < 2:
                    await asyncio.sleep(1)
                    continue
                raise

        raise Exception("Generation failed after retries")

    async def generate_base64(self, prompt: str, **kwargs) -> str:
        """Generate image and return as base64 string"""
        img_bytes = await self.generate(prompt, **kwargs)
        return base64.b64encode(img_bytes).decode()

    async def generate_from_request(self, request: GenerateRequest) -> bytes | dict:
        """Generate from a GenerateRequest dataclass"""
        return await self.generate(
            prompt=request.prompt,
            negative_prompt=request.negative_prompt,
            model=request.model,
            shape=request.shape,
            seed=request.seed,
            guidance_scale=request.guidance_scale,
            style=request.style,
            quality=request.quality,
            lighting=request.lighting,
            camera=request.camera,
            composition=request.composition,
            expression=request.expression,
            style_strength=request.style_strength,
            remove_background=request.remove_background,
            **request.extras
        )

    # === Convenience methods for specific use cases ===

    async def generate_photo(
        self,
        prompt: str,
        camera: str = "portrait-85mm",
        lighting: str = "natural",
        **kwargs
    ) -> bytes:
        """Generate a realistic photo with photography presets"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-photo"),
            camera=camera,
            lighting=lighting,
            quality="ultra",
            **kwargs
        )

    async def generate_anime(
        self,
        prompt: str,
        style: str = "anime",
        expression: str = "auto",
        **kwargs
    ) -> bytes:
        """Generate anime-style art"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-anime"),
            style=style,
            expression=expression,
            **kwargs
        )

    async def generate_portrait(
        self,
        prompt: str,
        expression: str = "neutral",
        **kwargs
    ) -> bytes:
        """Generate a portrait"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-portrait"),
            composition="closeup",
            expression=expression,
            quality="ultra",
            **kwargs
        )

    async def generate_concept_art(
        self,
        prompt: str,
        **kwargs
    ) -> bytes:
        """Generate professional concept art"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-concept"),
            style="concept-art",
            quality="ultra",
            **kwargs
        )

    async def generate_cinematic(
        self,
        prompt: str,
        **kwargs
    ) -> bytes:
        """Generate cinematic-style image"""
        return await self.generate(
            prompt,
            style="cinematic",
            lighting="cinematic",
            quality="ultra",
            **kwargs
        )
