"""cmemc custom parameter types."""
