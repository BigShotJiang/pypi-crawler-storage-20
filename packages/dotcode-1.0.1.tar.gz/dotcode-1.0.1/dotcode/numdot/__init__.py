"""
NumDot language module
"""