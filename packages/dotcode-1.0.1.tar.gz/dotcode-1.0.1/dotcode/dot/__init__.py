"""
Dot language module
"""