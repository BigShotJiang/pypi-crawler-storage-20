import numpy as np
import networkx as nx
import pandas as pd
from sklearn.decomposition import PCA
from scipy.spatial.distance import cdist
from scipy import sparse
import matplotlib.pyplot as plt
from collections import defaultdict, Counter

from sklearn.neighbors import NearestNeighbors, KDTree
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
import heapq
from typing import Tuple, List, Dict, Optional
import warnings

class ClusterNetworkBuilder:
    """
    基于KNN的聚类中心网络构建器
    
    算法步骤：
    1. 建立聚类中心c到数据点x的knn网络H
    2. 基于H建立聚类中心c的网络G
       - 如果两个聚类中心c1可以经过某个数据点到达c2，则c1和c2建立边
       - 边的权重由中介数据点的数量决定
       - 中介数据点的比重越大，边的权重越大
    """
    
    def __init__(self, 
                 k_data_to_centers=5,      # 每个数据点连接到多少个聚类中心
                 k_centers_to_data=10,     # 每个聚类中心连接到多少个数据点
                 weight_method='count',     # 权重计算方法: 'count', 'proportion', 'weighted'
                 min_edge_weight=0.01,     # 最小边权重
                 normalize_weights=True,   # 是否归一化权重
                 symmetric=True,           # 是否创建对称边
                 use_jaccard=False):       # 是否使用Jaccard相似度
        """
        参数:
        k_data_to_centers: 每个数据点连接到k个最近的聚类中心
        k_centers_to_data: 每个聚类中心连接到k个最近的数据点
        weight_method: 权重计算方法
            - 'count': 使用中介数据点的数量
            - 'proportion': 使用中介数据点的比例
            - 'weighted': 使用加权计数
        """
        self.k_data_to_centers = k_data_to_centers
        self.k_centers_to_data = k_centers_to_data
        self.weight_method = weight_method
        self.min_edge_weight = min_edge_weight
        self.normalize_weights = normalize_weights
        self.symmetric = symmetric
        self.use_jaccard = use_jaccard
        
    def build_network(self, x, c, metric='euclidean', return_details=False):
        """
        构建聚类中心网络
        
        参数:
        x: 数据点 (n_samples, n_features)
        c: 聚类中心 (n_clusters, n_features)
        metric: 距离度量
        return_details: 是否返回详细中间结果
        
        返回:
        G: 聚类中心网络
        如果return_details=True，还返回(H, edge_weights_dict, data_assignments)
        """
        n_samples = x.shape[0]
        n_clusters = c.shape[0]
        
        # 步骤1: 构建KNN网络H（二部图）
        H, data_assignments = self._build_knn_bipartite(x, c, metric)
        
        # 步骤2: 基于H构建聚类中心网络G
        G, edge_weights_dict = self._build_cluster_network_from_bipartite(
            H, n_clusters, n_samples
        )
        
        # 为节点添加属性
        self._add_node_attributes(G, c, data_assignments, n_samples)
        
        if return_details:
            return G, H, edge_weights_dict, data_assignments
        return G
    
    def _build_knn_bipartite(self, x, c, metric):
        """构建数据点和聚类中心的KNN二部图H"""
        n_samples = x.shape[0]
        n_clusters = c.shape[0]
        
        # 创建二部图
        H = nx.Graph()
        
        # 添加节点
        # 数据点节点: 前缀'd_'，如'd_0', 'd_1', ...
        for i in range(n_samples):
            H.add_node(f'd_{i}', type='data', index=i, features=x[i])
        
        # 聚类中心节点: 前缀'c_'，如'c_0', 'c_1', ...
        for j in range(n_clusters):
            H.add_node(f'c_{j}', type='cluster', index=j, center=c[j])
        
        # 1. 数据点到聚类中心的连接
        if self.k_data_to_centers > 0:
            # 计算每个数据点到所有聚类中心的距离
            data_to_center_dists = cdist(x, c, metric=metric)
            
            # 为每个数据点找到k个最近的聚类中心
            k1 = min(self.k_data_to_centers, n_clusters)
            for i in range(n_samples):
                # 找到最近的k1个聚类中心
                if k1 < n_clusters:
                    # 使用argpartition提高效率
                    nearest = np.argpartition(data_to_center_dists[i], k1)[:k1]
                else:
                    nearest = np.arange(n_clusters)
                
                for j in nearest:
                    distance = data_to_center_dists[i, j]
                    H.add_edge(f'd_{i}', f'c_{j}', 
                              weight=1.0/(1.0 + distance),
                              distance=distance,
                              type='data_to_center')
        
        # 2. 聚类中心到数据点的连接
        if self.k_centers_to_data > 0:
            # 计算每个聚类中心到所有数据点的距离
            center_to_data_dists = cdist(c, x, metric=metric)
            
            # 为每个聚类中心找到k个最近的数据点
            k2 = min(self.k_centers_to_data, n_samples)
            for j in range(n_clusters):
                if k2 < n_samples:
                    nearest = np.argpartition(center_to_data_dists[j], k2)[:k2]
                else:
                    nearest = np.arange(n_samples)
                
                for i in nearest:
                    distance = center_to_data_dists[j, i]
                    H.add_edge(f'c_{j}', f'd_{i}',
                              weight=1.0/(1.0 + distance),
                              distance=distance,
                              type='center_to_data')
        
        # 创建数据点分配矩阵
        data_assignments = self._create_data_assignments(H, n_samples, n_clusters)
        
        return H, data_assignments
    
    def _create_data_assignments(self, H, n_samples, n_clusters):
        """从二部图创建数据点分配矩阵"""
        assignments = np.zeros((n_samples, n_clusters))
        
        for i in range(n_samples):
            data_node = f'd_{i}'
            if data_node in H:
                # 获取连接到这个数据点的所有聚类中心
                cluster_neighbors = [n for n in H.neighbors(data_node) 
                                   if n.startswith('c_')]
                
                for cluster_node in cluster_neighbors:
                    j = int(cluster_node.split('_')[1])
                    # 使用边的权重作为分配权重
                    weight = H[data_node][cluster_node].get('weight', 1.0)
                    assignments[i, j] = weight
        
        # 归一化每行的分配（使每行和为1）
        row_sums = assignments.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1  # 避免除零
        assignments = assignments / row_sums
        
        return assignments
    
    def _build_cluster_network_from_bipartite(self, H, n_clusters, n_samples):
        """从二部图构建聚类中心网络"""
        G = nx.Graph()
        
        # 添加聚类中心节点
        for j in range(n_clusters):
            G.add_node(j, index=j)
        
        # 计算边权重
        edge_weights = defaultdict(float)
        
        # 方法1: 通过数据点连接聚类中心
        for i in range(n_samples):
            data_node = f'd_{i}'
            if data_node in H:
                # 获取连接到这个数据点的所有聚类中心
                cluster_neighbors = [n for n in H.neighbors(data_node) 
                                   if n.startswith('c_')]
                cluster_indices = [int(n.split('_')[1]) for n in cluster_neighbors]
                
                # 为每对聚类中心添加权重
                for idx1, c1 in enumerate(cluster_indices):
                    for c2 in cluster_indices[idx1+1:]:
                        # 这个数据点同时连接到c1和c2
                        edge_key = tuple(sorted((c1, c2)))
                        
                        # 计算这个数据点对这条边的贡献
                        weight_c1 = H[data_node][f'c_{c1}'].get('weight', 1.0)
                        weight_c2 = H[data_node][f'c_{c2}'].get('weight', 1.0)
                        
                        if self.weight_method == 'count':
                            # 计数：每个中介数据点贡献1
                            contribution = 1.0
                        elif self.weight_method == 'weighted':
                            # 加权：使用连接权重的乘积
                            contribution = weight_c1 * weight_c2
                        else:  # 'proportion'
                            # 比例：平均权重
                            contribution = (weight_c1 + weight_c2) / 2.0
                        
                        edge_weights[edge_key] += contribution
        
        # 如果使用Jaccard相似度
        if self.use_jaccard:
            edge_weights = self._compute_jaccard_weights(H, n_clusters, edge_weights)
        
        # 归一化权重
        if self.normalize_weights and edge_weights:
            max_weight = max(edge_weights.values())
            if max_weight > 0:
                for key in edge_weights:
                    edge_weights[key] /= max_weight
        
        # 添加边到网络G
        for (c1, c2), weight in edge_weights.items():
            if weight >= self.min_edge_weight:
                G.add_edge(c1, c2, weight=weight, 
                          n_mediators=int(weight * 10))  # 估计的中介点数
        
        return G, dict(edge_weights)
    
    def _compute_jaccard_weights(self, H, n_clusters, edge_weights):
        """计算Jaccard相似度作为边权重"""
        # 计算每个聚类中心连接的数据点集合
        cluster_data_sets = {}
        for j in range(n_clusters):
            cluster_node = f'c_{j}'
            if cluster_node in H:
                data_neighbors = {n for n in H.neighbors(cluster_node) 
                                if n.startswith('d_')}
                cluster_data_sets[j] = data_neighbors
        
        # 重新计算边权重为Jaccard相似度
        jaccard_weights = {}
        clusters = list(cluster_data_sets.keys())
        
        for i in range(len(clusters)):
            for j in range(i+1, len(clusters)):
                c1, c2 = clusters[i], clusters[j]
                set1 = cluster_data_sets.get(c1, set())
                set2 = cluster_data_sets.get(c2, set())
                
                if set1 and set2:
                    intersection = len(set1.intersection(set2))
                    union = len(set1.union(set2))
                    jaccard = intersection / union if union > 0 else 0
                    
                    if jaccard > 0:
                        jaccard_weights[(c1, c2)] = jaccard
        
        return jaccard_weights
    
    def _add_node_attributes(self, G, c, data_assignments, n_samples):
        """为节点添加属性"""
        n_clusters = c.shape[0]
        
        for j in range(n_clusters):
            if j in G:
                # 计算分配给这个聚类的数据点
                cluster_assignments = data_assignments[:, j]
                
                # 硬分配计数（分配权重大于0.5）
                hard_count = np.sum(cluster_assignments > 0.5)
                
                # 软分配权重和
                soft_weight = np.sum(cluster_assignments)
                
                # 更新节点属性
                G.nodes[j].update({
                    'center': c[j],
                    'hard_assigned_count': hard_count,
                    'soft_assigned_weight': soft_weight,
                    'proportion': soft_weight / n_samples,
                    'avg_assignment': np.mean(cluster_assignments[cluster_assignments > 0])
                })
    
    


def visualize_network(G, c=None, node_size_scale=5000, edge_size_scale=30, figsize=(12, 10)):
    """可视化聚类中心网络"""
    fig, ax1 = plt.subplots(1, 1, figsize=figsize)
    
    # 位置布局（如果提供了聚类中心坐标，使用它们；否则使用力导向布局）
    if c is not None and c.shape[1] >= 2:
        # 使用前两个维度作为位置
        pos = {i: (c[i, 0], c[i, 1]) for i in G.nodes()}
        
        # 如果只有1D，添加一个虚拟维度
        if c.shape[1] == 1:
            pos = {i: (c[i, 0], i) for i in G.nodes()}
    else:
        pos = nx.spring_layout(G, seed=42, weight='weight')
    
    # 节点大小基于权重
    node_weights = [G.nodes[node]['proportion'] for node in G.nodes()]
    node_sizes = [node_size_scale * w for w in node_weights]
    
    # 节点颜色基于权重
    node_colors = node_weights
    
    # 边宽度基于权重
    edge_weights = [G[u][v]['weight'] for u, v in G.edges()]
    edge_widths = [edge_size_scale * w for w in edge_weights]
    
    # 绘制网络
    nodes = nx.draw_networkx_nodes(G, pos, 
                                  node_size=node_sizes,
                                  node_color=node_colors,
                                  cmap='viridis',
                                  alpha=0.8,
                                  edgecolors='black',
                                  linewidths=1,
                                  ax=ax1)
    
    nx.draw_networkx_edges(G, pos,
                          width=edge_widths,
                          alpha=0.6,
                          edge_color='gray',
                          ax=ax1)
    
    nx.draw_networkx_labels(G, pos,
                           font_size=10,
                           font_weight='bold',
                           ax=ax1)
    
    # 添加颜色条
    sm = plt.cm.ScalarMappable(cmap='viridis', 
                               norm=plt.Normalize(vmin=min(node_colors), 
                                                  vmax=max(node_colors)))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax1, shrink=0.8)
    cbar.set_label('Node Weight')
    
    ax1.axis('off')
    
    plt.tight_layout()
    plt.show()