"""Tests for TimeSmith."""
