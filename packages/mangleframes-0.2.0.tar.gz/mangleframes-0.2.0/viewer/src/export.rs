//! Export DataFrame to various formats.

use arrow::record_batch::RecordBatch;
use arrow_csv::WriterBuilder as CsvWriterBuilder;
use arrow_json::LineDelimitedWriter;
use parquet::arrow::ArrowWriter;
use parquet::basic::Compression;
use parquet::file::properties::WriterProperties;
use rust_xlsxwriter::{Format, Workbook};
use thiserror::Error;

use crate::reconcile::ReconcileResult;

#[derive(Error, Debug)]
pub enum ExportError {
    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),
    #[error("Parquet error: {0}")]
    Parquet(#[from] parquet::errors::ParquetError),
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Excel error: {0}")]
    Xlsx(#[from] rust_xlsxwriter::XlsxError),
    #[error("No data to export")]
    NoData,
}

pub fn to_csv(batches: &[RecordBatch]) -> Result<Vec<u8>, ExportError> {
    if batches.is_empty() {
        return Err(ExportError::NoData);
    }

    let mut buffer = Vec::new();
    let mut writer = CsvWriterBuilder::new()
        .with_header(true)
        .build(&mut buffer);

    for batch in batches {
        writer.write(batch)?;
    }

    drop(writer);
    Ok(buffer)
}

pub fn to_json(batches: &[RecordBatch]) -> Result<Vec<u8>, ExportError> {
    if batches.is_empty() {
        return Err(ExportError::NoData);
    }

    let mut buffer = Vec::new();
    let mut writer = LineDelimitedWriter::new(&mut buffer);

    for batch in batches {
        writer.write(batch)?;
    }

    writer.finish()?;
    Ok(buffer)
}

pub fn to_parquet(batches: &[RecordBatch]) -> Result<Vec<u8>, ExportError> {
    if batches.is_empty() {
        return Err(ExportError::NoData);
    }

    let schema = batches[0].schema();
    let mut buffer = Vec::new();

    let props = WriterProperties::builder()
        .set_compression(Compression::SNAPPY)
        .build();

    let mut writer = ArrowWriter::try_new(&mut buffer, schema, Some(props))?;

    for batch in batches {
        writer.write(batch)?;
    }

    writer.close()?;
    Ok(buffer)
}

pub fn to_xlsx_reconcile(result: &ReconcileResult) -> Result<Vec<u8>, ExportError> {
    let mut workbook = Workbook::new();

    let header_fmt = Format::new().set_bold();
    let match_fmt = Format::new().set_background_color(rust_xlsxwriter::Color::RGB(0xD4EDDA));
    let mismatch_fmt = Format::new().set_background_color(rust_xlsxwriter::Color::RGB(0xF8D7DA));

    // Summary sheet
    let summary = workbook.add_worksheet();
    summary.set_name("Summary")?;
    summary.write_string_with_format(0, 0, "Reconciliation Summary", &header_fmt)?;
    summary.write_string(2, 0, "Metric")?;
    summary.write_string(2, 1, "Value")?;
    summary.write_string(3, 0, "Source Total")?;
    summary.write_number(3, 1, result.statistics.source_total as f64)?;
    summary.write_string(4, 0, "Target Total")?;
    summary.write_number(4, 1, result.statistics.target_total as f64)?;
    summary.write_string(5, 0, "Matched")?;
    summary.write_number(5, 1, result.statistics.matched_count as f64)?;
    summary.write_string(6, 0, "Source Only")?;
    summary.write_number(6, 1, result.statistics.source_only_count as f64)?;
    summary.write_string(7, 0, "Target Only")?;
    summary.write_number(7, 1, result.statistics.target_only_count as f64)?;
    summary.write_string(8, 0, "Match Rate")?;
    summary.write_string(8, 1, &format!("{:.2}%", result.statistics.match_rate * 100.0))?;

    // Aggregates sheet
    if !result.aggregate_comparisons.is_empty() {
        let agg_sheet = workbook.add_worksheet();
        agg_sheet.set_name("Aggregates")?;
        agg_sheet.write_string_with_format(0, 0, "Column", &header_fmt)?;
        agg_sheet.write_string_with_format(0, 1, "Aggregation", &header_fmt)?;
        agg_sheet.write_string_with_format(0, 2, "Source", &header_fmt)?;
        agg_sheet.write_string_with_format(0, 3, "Target", &header_fmt)?;
        agg_sheet.write_string_with_format(0, 4, "Difference", &header_fmt)?;
        agg_sheet.write_string_with_format(0, 5, "Status", &header_fmt)?;

        for (i, agg) in result.aggregate_comparisons.iter().enumerate() {
            let row = (i + 1) as u32;
            let fmt = if agg.match_status == "match" { &match_fmt } else { &mismatch_fmt };
            agg_sheet.write_string_with_format(row, 0, &agg.column, fmt)?;
            agg_sheet.write_string_with_format(row, 1, &agg.aggregation, fmt)?;
            if let Some(v) = agg.source_value {
                agg_sheet.write_number_with_format(row, 2, v, fmt)?;
            }
            if let Some(v) = agg.target_value {
                agg_sheet.write_number_with_format(row, 3, v, fmt)?;
            }
            if let Some(v) = agg.difference {
                agg_sheet.write_number_with_format(row, 4, v, fmt)?;
            }
            agg_sheet.write_string_with_format(row, 5, &agg.match_status, fmt)?;
        }
    }

    // Source Only sheet
    if !result.source_only.rows.is_empty() {
        write_json_rows_to_sheet(&mut workbook, "Source Only", &result.source_only.rows)?;
    }

    // Target Only sheet
    if !result.target_only.rows.is_empty() {
        write_json_rows_to_sheet(&mut workbook, "Target Only", &result.target_only.rows)?;
    }

    workbook.save_to_buffer().map_err(ExportError::Xlsx)
}

fn write_json_rows_to_sheet(
    workbook: &mut Workbook,
    name: &str,
    rows: &[serde_json::Value],
) -> Result<(), ExportError> {
    let sheet = workbook.add_worksheet();
    sheet.set_name(name)?;

    if rows.is_empty() {
        return Ok(());
    }

    let header_fmt = Format::new().set_bold();

    // Get column names from first row
    let columns: Vec<String> = if let Some(obj) = rows[0].as_object() {
        obj.keys().cloned().collect()
    } else {
        return Ok(());
    };

    // Write headers
    for (col, name) in columns.iter().enumerate() {
        sheet.write_string_with_format(0, col as u16, name, &header_fmt)?;
    }

    // Write data rows
    for (row_idx, row) in rows.iter().enumerate() {
        if let Some(obj) = row.as_object() {
            for (col_idx, col_name) in columns.iter().enumerate() {
                if let Some(val) = obj.get(col_name) {
                    write_json_value(sheet, (row_idx + 1) as u32, col_idx as u16, val)?;
                }
            }
        }
    }

    Ok(())
}

fn write_json_value(
    sheet: &mut rust_xlsxwriter::Worksheet,
    row: u32,
    col: u16,
    val: &serde_json::Value,
) -> Result<(), ExportError> {
    match val {
        serde_json::Value::Null => {}
        serde_json::Value::Bool(b) => { sheet.write_boolean(row, col, *b)?; }
        serde_json::Value::Number(n) => {
            if let Some(f) = n.as_f64() {
                sheet.write_number(row, col, f)?;
            } else if let Some(i) = n.as_i64() {
                sheet.write_number(row, col, i as f64)?;
            }
        }
        serde_json::Value::String(s) => { sheet.write_string(row, col, s)?; }
        _ => { sheet.write_string(row, col, &val.to_string())?; }
    }
    Ok(())
}
