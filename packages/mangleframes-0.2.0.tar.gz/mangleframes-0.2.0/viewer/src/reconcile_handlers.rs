//! HTTP handlers for CSV reconciliation endpoints.

use std::sync::Arc;
use std::time::Instant;

use arrow::record_batch::RecordBatch;
use axum::body::Body;
use axum::extract::{Multipart, State};
use axum::http::{header, Response, StatusCode};
use axum::response::IntoResponse;
use axum::Json;
use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64};
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::arrow_reader;
use crate::export;
use crate::reconcile::{ReconcileEngine, JoinType, AggregationConfig};
use crate::web_server::{AppState, CachedFrame};

const CSV_FRAME_PREFIX: &str = "__csv__";
/// Limit of 0 means fetch all rows (no limit)
const RECONCILE_FETCH_LIMIT: usize = 0;

#[derive(Deserialize)]
pub struct UploadCsvJsonRequest {
    pub csv_data: String,
    pub frame_name: String,
}

#[derive(Serialize)]
pub struct UploadCsvResponse {
    pub frame_name: String,
    pub columns: Vec<ColumnInfo>,
    pub row_count: usize,
}

#[derive(Serialize)]
pub struct ColumnInfo {
    pub name: String,
    pub data_type: String,
    pub nullable: bool,
}

#[derive(Deserialize)]
pub struct ReconcileRequest {
    pub source_frame: String,
    pub target_frame: String,
    #[serde(default = "default_source_type")]
    pub source_type: String,
    pub source_keys: Vec<String>,
    pub target_keys: Vec<String>,
    pub join_type: JoinType,
    #[serde(default)]
    pub aggregations: Vec<AggregationConfig>,
    pub sample_limit: Option<usize>,
}

fn default_source_type() -> String {
    "csv".to_string()
}

#[derive(Deserialize)]
pub struct ExportReconcileRequest {
    pub source_frame: String,
    pub target_frame: String,
    #[serde(default = "default_source_type")]
    pub source_type: String,
    pub source_keys: Vec<String>,
    pub target_keys: Vec<String>,
    pub join_type: JoinType,
    #[serde(default)]
    pub aggregations: Vec<AggregationConfig>,
    pub format: String,
}

pub async fn upload_csv_multipart(
    State(state): State<Arc<AppState>>,
    mut multipart: Multipart,
) -> impl IntoResponse {
    let mut csv_data: Option<Vec<u8>> = None;
    let mut frame_name: Option<String> = None;

    while let Ok(Some(field)) = multipart.next_field().await {
        let name = field.name().unwrap_or("").to_string();
        match name.as_str() {
            "file" => {
                csv_data = match field.bytes().await {
                    Ok(b) => Some(b.to_vec()),
                    Err(e) => return error_response(StatusCode::BAD_REQUEST, &e.to_string()),
                };
            }
            "frame_name" => {
                frame_name = match field.text().await {
                    Ok(t) => Some(t),
                    Err(e) => return error_response(StatusCode::BAD_REQUEST, &e.to_string()),
                };
            }
            _ => {}
        }
    }

    let csv_data = match csv_data {
        Some(d) => d,
        None => return error_response(StatusCode::BAD_REQUEST, "No CSV file provided"),
    };

    let frame_name = frame_name.unwrap_or_else(|| {
        format!("csv_upload_{}", chrono::Utc::now().timestamp_millis())
    });

    process_csv_upload(&state, &csv_data, &frame_name).await
}

pub async fn upload_csv_json(
    State(state): State<Arc<AppState>>,
    Json(req): Json<UploadCsvJsonRequest>,
) -> impl IntoResponse {
    let csv_data = match BASE64.decode(&req.csv_data) {
        Ok(d) => d,
        Err(e) => return error_response(StatusCode::BAD_REQUEST, &format!("Invalid base64: {}", e)),
    };

    process_csv_upload(&state, &csv_data, &req.frame_name).await
}

async fn process_csv_upload(
    state: &AppState,
    csv_data: &[u8],
    frame_name: &str,
) -> axum::response::Response {
    let batches = match ReconcileEngine::parse_csv(csv_data) {
        Ok(b) => b,
        Err(e) => return error_response(StatusCode::BAD_REQUEST, &e.to_string()),
    };

    if batches.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "CSV has no data");
    }

    let schema = batches[0].schema();
    let columns: Vec<ColumnInfo> = schema.fields().iter().map(|f| ColumnInfo {
        name: f.name().clone(),
        data_type: format!("{:?}", f.data_type()),
        nullable: f.is_nullable(),
    }).collect();

    let row_count: usize = batches.iter().map(|b| b.num_rows()).sum();

    state.evict_frame_if_needed().await;
    let mut cache = state.cache.write().await;
    cache.insert(
        format!("{}{}", CSV_FRAME_PREFIX, frame_name),
        CachedFrame { batches, stats: None, last_access: Instant::now() },
    );

    Json(UploadCsvResponse { frame_name: frame_name.to_string(), columns, row_count }).into_response()
}

pub async fn list_csv_frames(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let cache = state.cache.read().await;
    let frames: Vec<String> = cache.keys()
        .filter(|k| k.starts_with(CSV_FRAME_PREFIX))
        .map(|k| k.strip_prefix(CSV_FRAME_PREFIX).unwrap_or(k).to_string())
        .collect();
    Json(json!({ "frames": frames }))
}

pub async fn reconcile(
    State(state): State<Arc<AppState>>,
    Json(req): Json<ReconcileRequest>,
) -> impl IntoResponse {
    if req.source_keys.len() != req.target_keys.len() {
        return error_response(StatusCode::BAD_REQUEST, "Key count mismatch");
    }
    if req.source_keys.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "At least one join key required");
    }

    let source_batches = match get_source_batches(&state, &req.source_frame, &req.source_type).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let target_batches = match get_or_fetch_frame(&state, &req.target_frame).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let engine = ReconcileEngine::new();
    let sample_limit = req.sample_limit.unwrap_or(100);

    match engine.reconcile(
        source_batches,
        target_batches,
        &req.source_keys,
        &req.target_keys,
        req.join_type,
        &req.aggregations,
        sample_limit,
    ).await {
        Ok(result) => Json(result).into_response(),
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

async fn get_source_batches(
    state: &AppState,
    frame_name: &str,
    source_type: &str,
) -> Result<Vec<RecordBatch>, axum::response::Response> {
    if source_type == "dataframe" {
        return get_or_fetch_frame(state, frame_name).await;
    }

    let cache = state.cache.read().await;
    let key = format!("{}{}", CSV_FRAME_PREFIX, frame_name);
    match cache.get(&key) {
        Some(cached) => Ok(cached.batches.clone()),
        None => Err(error_response(
            StatusCode::NOT_FOUND,
            &format!("CSV frame '{}' not found. Upload first.", frame_name)
        )),
    }
}

pub async fn export_reconciliation(
    State(state): State<Arc<AppState>>,
    Json(req): Json<ExportReconcileRequest>,
) -> impl IntoResponse {
    let source_batches = match get_source_batches(&state, &req.source_frame, &req.source_type).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let target_batches = match get_or_fetch_frame(&state, &req.target_frame).await {
        Ok(b) => b,
        Err(resp) => return resp,
    };

    let engine = ReconcileEngine::new();
    let result = match engine.reconcile(
        source_batches,
        target_batches,
        &req.source_keys,
        &req.target_keys,
        req.join_type,
        &req.aggregations,
        RECONCILE_FETCH_LIMIT,
    ).await {
        Ok(r) => r,
        Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    };

    let (content_type, data, ext) = match req.format.as_str() {
        "json" => {
            let json = serde_json::to_vec_pretty(&result).unwrap_or_default();
            ("application/json", json, "json")
        }
        "csv" => {
            let csv = reconcile_result_to_csv(&result);
            ("text/csv", csv, "csv")
        }
        "xlsx" => {
            match export::to_xlsx_reconcile(&result) {
                Ok(d) => ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", d, "xlsx"),
                Err(e) => return error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
            }
        }
        _ => return error_response(StatusCode::BAD_REQUEST, "Invalid format. Use: json, csv, xlsx"),
    };

    let filename = format!("reconciliation_{}_{}.{}", req.source_frame, req.target_frame, ext);
    Response::builder()
        .header(header::CONTENT_TYPE, content_type)
        .header(header::CONTENT_DISPOSITION, format!("attachment; filename=\"{}\"", filename))
        .body(Body::from(data))
        .unwrap()
        .into_response()
}

async fn get_or_fetch_frame(
    state: &AppState,
    frame_name: &str,
) -> Result<Vec<RecordBatch>, axum::response::Response> {
    // Always fetch fresh for reconciliation to ensure we get all rows
    // (UI cache may have truncated data from paginated viewing)
    let response = state.client.get_frame(frame_name, RECONCILE_FETCH_LIMIT).map_err(|e| {
        error_response(StatusCode::NOT_FOUND, &format!("Failed to fetch {}: {}", frame_name, e))
    })?;

    let batches = arrow_reader::parse_arrow_stream(&response.data)
        .map_err(|e| error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()))?;

    Ok(batches)
}

fn error_response(status: StatusCode, msg: &str) -> axum::response::Response {
    (status, Json(json!({"error": msg}))).into_response()
}

fn reconcile_result_to_csv(result: &crate::reconcile::ReconcileResult) -> Vec<u8> {
    let mut csv = String::new();
    csv.push_str("Reconciliation Summary\n");
    csv.push_str(&format!("Source Total,{}\n", result.statistics.source_total));
    csv.push_str(&format!("Target Total,{}\n", result.statistics.target_total));
    csv.push_str(&format!("Matched,{}\n", result.statistics.matched_count));
    csv.push_str(&format!("Source Only,{}\n", result.statistics.source_only_count));
    csv.push_str(&format!("Target Only,{}\n", result.statistics.target_only_count));
    csv.push_str(&format!("Match Rate,{:.2}%\n", result.statistics.match_rate * 100.0));
    csv.push_str("\nAggregate Comparisons\n");
    csv.push_str("Column,Aggregation,Source,Target,Difference,Status\n");
    for agg in &result.aggregate_comparisons {
        csv.push_str(&format!(
            "{},{},{},{},{},{}\n",
            agg.column,
            agg.aggregation,
            agg.source_value.map(|v| v.to_string()).unwrap_or_default(),
            agg.target_value.map(|v| v.to_string()).unwrap_or_default(),
            agg.difference.map(|v| v.to_string()).unwrap_or_default(),
            agg.match_status
        ));
    }
    csv.into_bytes()
}
