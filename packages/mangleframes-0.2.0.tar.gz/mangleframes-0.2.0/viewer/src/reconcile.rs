//! CSV reconciliation engine using DataFusion SQL execution.

use std::io::Cursor;
use std::sync::Arc;

use arrow::array::{Array, ArrayRef};
use arrow::record_batch::RecordBatch;
use arrow_csv::ReaderBuilder;
use datafusion::datasource::MemTable;
use datafusion::prelude::*;
use serde::{Deserialize, Serialize};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ReconcileError {
    #[error("CSV parse error: {0}")]
    CsvParse(String),
    #[error("DataFusion error: {0}")]
    DataFusion(#[from] datafusion::error::DataFusionError),
    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),
    #[error("No data provided")]
    NoData,
    #[error("Key count mismatch: source={0}, target={1}")]
    KeyMismatch(usize, usize),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum JoinType {
    Inner,
    Left,
    Right,
    Full,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AggregationType {
    Sum,
    Count,
    Min,
    Max,
    Avg,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AggregationConfig {
    pub column: String,
    pub aggregations: Vec<AggregationType>,
}

#[derive(Debug, Serialize)]
pub struct ReconcileStatistics {
    pub source_total: usize,
    pub target_total: usize,
    pub matched_count: usize,
    pub source_only_count: usize,
    pub target_only_count: usize,
    pub match_rate: f64,
}

#[derive(Debug, Serialize)]
pub struct AggregateComparison {
    pub column: String,
    pub aggregation: String,
    pub source_value: Option<f64>,
    pub target_value: Option<f64>,
    pub difference: Option<f64>,
    pub match_status: String,
}

#[derive(Debug, Serialize)]
pub struct UnmatchedRows {
    pub total: usize,
    pub rows: Vec<serde_json::Value>,
}

#[derive(Debug, Serialize)]
pub struct ReconcileResult {
    pub statistics: ReconcileStatistics,
    pub source_only: UnmatchedRows,
    pub target_only: UnmatchedRows,
    pub aggregate_comparisons: Vec<AggregateComparison>,
    pub matched_sample: Vec<serde_json::Value>,
}

pub struct ReconcileEngine {
    ctx: SessionContext,
}

impl ReconcileEngine {
    pub fn new() -> Self {
        Self { ctx: SessionContext::new() }
    }

    pub fn parse_csv(data: &[u8]) -> Result<Vec<RecordBatch>, ReconcileError> {
        let cursor = Cursor::new(data);
        let format = arrow_csv::reader::Format::default().with_header(true);
        let (schema, _) = format
            .infer_schema(cursor, Some(100))
            .map_err(|e| ReconcileError::CsvParse(e.to_string()))?;

        let cursor = Cursor::new(data);
        let reader = ReaderBuilder::new(Arc::new(schema))
            .with_header(true)
            .build(cursor)
            .map_err(|e| ReconcileError::CsvParse(e.to_string()))?;

        reader.collect::<Result<Vec<_>, _>>().map_err(ReconcileError::Arrow)
    }

    pub async fn reconcile(
        &self,
        source: Vec<RecordBatch>,
        target: Vec<RecordBatch>,
        source_keys: &[String],
        target_keys: &[String],
        _join_type: JoinType,
        aggregations: &[AggregationConfig],
        sample_limit: usize,
    ) -> Result<ReconcileResult, ReconcileError> {
        if source_keys.len() != target_keys.len() {
            return Err(ReconcileError::KeyMismatch(source_keys.len(), target_keys.len()));
        }

        self.register_table("source_tbl", source).await?;
        self.register_table("target_tbl", target).await?;

        let statistics = self.compute_statistics(source_keys, target_keys).await?;
        let source_only = self.get_unmatched(
            "source_tbl", "target_tbl", source_keys, target_keys, sample_limit
        ).await?;
        let target_only = self.get_unmatched(
            "target_tbl", "source_tbl", target_keys, source_keys, sample_limit
        ).await?;
        let aggregate_comparisons = self.compute_aggregates(aggregations).await?;
        let matched_sample = self.get_matched_sample(
            source_keys, target_keys, sample_limit
        ).await?;

        Ok(ReconcileResult {
            statistics,
            source_only,
            target_only,
            aggregate_comparisons,
            matched_sample,
        })
    }

    async fn register_table(&self, name: &str, batches: Vec<RecordBatch>) -> Result<(), ReconcileError> {
        if batches.is_empty() {
            return Err(ReconcileError::NoData);
        }
        let schema = batches[0].schema();
        let table = MemTable::try_new(schema, vec![batches])?;
        self.ctx.register_table(name, Arc::new(table))?;
        Ok(())
    }

    async fn compute_statistics(
        &self,
        source_keys: &[String],
        target_keys: &[String],
    ) -> Result<ReconcileStatistics, ReconcileError> {
        let source_total = self.count_rows("source_tbl").await?;
        let target_total = self.count_rows("target_tbl").await?;

        let join_cond = build_join_condition("s", "t", source_keys, target_keys);
        let matched_sql = format!(
            "SELECT COUNT(DISTINCT {}) as cnt FROM source_tbl s \
             INNER JOIN target_tbl t ON {}",
            keys_to_concat("s", source_keys),
            join_cond
        );
        let matched_count = self.execute_count(&matched_sql).await?;

        let source_only_sql = format!(
            "SELECT COUNT(*) as cnt FROM source_tbl s \
             WHERE NOT EXISTS (SELECT 1 FROM target_tbl t WHERE {})",
            join_cond
        );
        let source_only_count = self.execute_count(&source_only_sql).await?;

        let target_only_sql = format!(
            "SELECT COUNT(*) as cnt FROM target_tbl t \
             WHERE NOT EXISTS (SELECT 1 FROM source_tbl s WHERE {})",
            join_cond
        );
        let target_only_count = self.execute_count(&target_only_sql).await?;

        let match_rate = if source_total > 0 {
            (source_total - source_only_count) as f64 / source_total as f64
        } else {
            0.0
        };

        Ok(ReconcileStatistics {
            source_total,
            target_total,
            matched_count,
            source_only_count,
            target_only_count,
            match_rate,
        })
    }

    async fn count_rows(&self, table: &str) -> Result<usize, ReconcileError> {
        let sql = format!("SELECT COUNT(*) as cnt FROM {}", table);
        self.execute_count(&sql).await
    }

    async fn execute_count(&self, sql: &str) -> Result<usize, ReconcileError> {
        let batches = self.ctx.sql(sql).await?.collect().await?;
        Ok(extract_count(&batches))
    }

    async fn compute_aggregates(
        &self,
        configs: &[AggregationConfig],
    ) -> Result<Vec<AggregateComparison>, ReconcileError> {
        let mut results = Vec::new();

        for config in configs {
            for agg in &config.aggregations {
                let agg_func = match agg {
                    AggregationType::Sum => "SUM",
                    AggregationType::Count => "COUNT",
                    AggregationType::Min => "MIN",
                    AggregationType::Max => "MAX",
                    AggregationType::Avg => "AVG",
                };

                let source_val = self.compute_single_aggregate("source_tbl", &config.column, agg_func).await?;
                let target_val = self.compute_single_aggregate("target_tbl", &config.column, agg_func).await?;

                let (difference, match_status) = compute_comparison(source_val, target_val);

                results.push(AggregateComparison {
                    column: config.column.clone(),
                    aggregation: agg_func.to_string(),
                    source_value: source_val,
                    target_value: target_val,
                    difference,
                    match_status,
                });
            }
        }

        Ok(results)
    }

    async fn compute_single_aggregate(
        &self,
        table: &str,
        column: &str,
        func: &str,
    ) -> Result<Option<f64>, ReconcileError> {
        let sql = format!("SELECT {}(\"{}\") as val FROM {}", func, column, table);
        let batches = self.ctx.sql(&sql).await?.collect().await?;
        Ok(extract_f64(&batches))
    }

    async fn get_unmatched(
        &self,
        main_table: &str,
        other_table: &str,
        main_keys: &[String],
        other_keys: &[String],
        limit: usize,
    ) -> Result<UnmatchedRows, ReconcileError> {
        let join_cond = build_join_condition("m", "o", main_keys, other_keys);

        let count_sql = format!(
            "SELECT COUNT(*) as cnt FROM {} m \
             WHERE NOT EXISTS (SELECT 1 FROM {} o WHERE {})",
            main_table, other_table, join_cond
        );
        let total = self.execute_count(&count_sql).await?;

        let data_sql = format!(
            "SELECT m.* FROM {} m \
             WHERE NOT EXISTS (SELECT 1 FROM {} o WHERE {}) \
             LIMIT {}",
            main_table, other_table, join_cond, limit
        );
        let batches = self.ctx.sql(&data_sql).await?.collect().await?;
        let rows = batches_to_json(&batches);

        Ok(UnmatchedRows { total, rows })
    }

    async fn get_matched_sample(
        &self,
        source_keys: &[String],
        target_keys: &[String],
        limit: usize,
    ) -> Result<Vec<serde_json::Value>, ReconcileError> {
        let join_cond = build_join_condition("s", "t", source_keys, target_keys);
        let sql = format!(
            "SELECT s.* FROM source_tbl s \
             INNER JOIN target_tbl t ON {} \
             LIMIT {}",
            join_cond, limit
        );
        let batches = self.ctx.sql(&sql).await?.collect().await?;
        Ok(batches_to_json(&batches))
    }
}

fn build_join_condition(left_alias: &str, right_alias: &str, left_keys: &[String], right_keys: &[String]) -> String {
    left_keys.iter().zip(right_keys.iter())
        .map(|(lk, rk)| format!("{}.\"{}\" = {}.\"{}\"", left_alias, lk, right_alias, rk))
        .collect::<Vec<_>>()
        .join(" AND ")
}

fn keys_to_concat(alias: &str, keys: &[String]) -> String {
    if keys.len() == 1 {
        format!("{}.\"{}\"", alias, keys[0])
    } else {
        let parts: Vec<String> = keys.iter()
            .map(|k| format!("CAST({}.\"{}\" AS VARCHAR)", alias, k))
            .collect();
        format!("CONCAT({})", parts.join(", "))
    }
}

fn extract_count(batches: &[RecordBatch]) -> usize {
    if batches.is_empty() || batches[0].num_rows() == 0 {
        return 0;
    }
    let col = batches[0].column(0);
    extract_int_col(col)
}

fn extract_int_col(col: &ArrayRef) -> usize {
    if let Some(arr) = col.as_any().downcast_ref::<arrow::array::Int64Array>() {
        arr.value(0) as usize
    } else if let Some(arr) = col.as_any().downcast_ref::<arrow::array::UInt64Array>() {
        arr.value(0) as usize
    } else {
        0
    }
}

fn extract_f64(batches: &[RecordBatch]) -> Option<f64> {
    if batches.is_empty() || batches[0].num_rows() == 0 {
        return None;
    }
    let col = batches[0].column(0);
    if let Some(arr) = col.as_any().downcast_ref::<arrow::array::Float64Array>() {
        if arr.is_null(0) { None } else { Some(arr.value(0)) }
    } else if let Some(arr) = col.as_any().downcast_ref::<arrow::array::Int64Array>() {
        if arr.is_null(0) { None } else { Some(arr.value(0) as f64) }
    } else if let Some(arr) = col.as_any().downcast_ref::<arrow::array::UInt64Array>() {
        if arr.is_null(0) { None } else { Some(arr.value(0) as f64) }
    } else if let Some(arr) = col.as_any().downcast_ref::<arrow::array::Decimal128Array>() {
        if arr.is_null(0) {
            None
        } else {
            let scale = arr.scale() as i32;
            let raw = arr.value(0);
            Some(raw as f64 / 10_f64.powi(scale))
        }
    } else {
        None
    }
}

fn compute_comparison(source: Option<f64>, target: Option<f64>) -> (Option<f64>, String) {
    match (source, target) {
        (Some(s), Some(t)) => {
            let diff = s - t;
            let status = if (diff.abs()) < f64::EPSILON { "match" } else { "mismatch" };
            (Some(diff), status.to_string())
        }
        (Some(_), None) => (None, "source_only".to_string()),
        (None, Some(_)) => (None, "target_only".to_string()),
        (None, None) => (None, "match".to_string()),
    }
}

fn batches_to_json(batches: &[RecordBatch]) -> Vec<serde_json::Value> {
    use arrow::json::ArrayWriter;
    use std::io::Cursor;

    if batches.is_empty() {
        return vec![];
    }

    let mut buf = Vec::new();
    {
        let cursor = Cursor::new(&mut buf);
        let mut writer = ArrayWriter::new(cursor);
        for batch in batches {
            if batch.num_rows() > 0 {
                let _ = writer.write(batch);
            }
        }
        let _ = writer.finish();
    }

    serde_json::from_slice(&buf).unwrap_or_default()
}
