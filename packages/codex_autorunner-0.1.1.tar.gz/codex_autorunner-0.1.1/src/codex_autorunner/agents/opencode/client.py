from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterator, Optional

import httpx

from ...core.logging_utils import log_event
from .events import SSEEvent, parse_sse_lines

_MAX_INVALID_JSON_PREVIEW_BYTES = 512


class OpenCodeProtocolError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        content_type: Optional[str] = None,
        body_preview: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.content_type = content_type
        self.body_preview = body_preview


class OpenCodeClient:
    def __init__(
        self,
        base_url: str,
        *,
        auth: Optional[tuple[str, str]] = None,
        timeout: Optional[float] = None,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self._client = httpx.AsyncClient(
            base_url=base_url,
            auth=auth,
            timeout=timeout,
        )
        self._logger = logger or logging.getLogger(__name__)

    async def close(self) -> None:
        await self._client.aclose()

    def _dir_params(self, directory: Optional[str]) -> dict[str, str]:
        return {"directory": directory} if directory else {}

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        json_body: Optional[dict[str, Any]] = None,
        expect_json: bool = True,
    ) -> Any:
        response = await self._client.request(
            method, path, params=params, json=json_body
        )
        response.raise_for_status()
        raw = response.content
        if not raw or not raw.strip():
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            self._log_invalid_json(
                method,
                path,
                response,
                raw,
                expect_json=expect_json,
            )
            if expect_json:
                preview = (
                    raw[:_MAX_INVALID_JSON_PREVIEW_BYTES]
                    .decode("utf-8", errors="replace")
                    .strip()
                )
                content_type = response.headers.get("content-type")
                hint = ""
                if content_type and "text/html" in content_type.lower():
                    hint = (
                        " Response looks like HTML; the OpenCode server may have "
                        "proxied the request instead of handling an API route."
                    )
                elif preview.startswith("<"):
                    hint = (
                        " Response looks like HTML; check that the OpenCode API "
                        "endpoint is correct."
                    )
                raise OpenCodeProtocolError(
                    f"OpenCode returned invalid JSON.{hint}",
                    status_code=response.status_code,
                    content_type=content_type,
                    body_preview=preview or None,
                ) from exc
        return None

    def _log_invalid_json(
        self,
        method: str,
        path: str,
        response: httpx.Response,
        raw: bytes,
        *,
        expect_json: bool,
    ) -> None:
        preview = raw[:_MAX_INVALID_JSON_PREVIEW_BYTES].decode(
            "utf-8", errors="replace"
        )
        log_event(
            self._logger,
            logging.WARNING,
            "opencode.response.invalid_json",
            method=method,
            path=path,
            status_code=response.status_code,
            content_length=len(raw),
            content_type=response.headers.get("content-type"),
            expect_json=expect_json,
            preview=preview,
        )

    async def providers(self, directory: Optional[str] = None) -> Any:
        return await self._request(
            "GET",
            "/config/providers",
            params=self._dir_params(directory),
            expect_json=True,
        )

    async def create_session(
        self,
        *,
        title: Optional[str] = None,
        directory: Optional[str] = None,
    ) -> Any:
        payload: dict[str, Any] = {}
        if title:
            payload["title"] = title
        if directory:
            payload["directory"] = directory
        return await self._request(
            "POST", "/session", json_body=payload, expect_json=True
        )

    async def list_sessions(self, directory: Optional[str] = None) -> Any:
        return await self._request(
            "GET", "/session", params=self._dir_params(directory), expect_json=True
        )

    async def get_session(self, session_id: str) -> Any:
        return await self._request("GET", f"/session/{session_id}", expect_json=True)

    async def send_message(
        self,
        session_id: str,
        *,
        message: str,
        agent: Optional[str] = None,
        model: Optional[dict[str, str]] = None,
        variant: Optional[str] = None,
    ) -> Any:
        payload: dict[str, Any] = {
            "parts": [{"type": "text", "text": message}],
        }
        if agent:
            payload["agent"] = agent
        if model:
            payload["model"] = model
        if variant:
            payload["variant"] = variant
        return await self._request(
            "POST",
            f"/session/{session_id}/message",
            json_body=payload,
            expect_json=False,
        )

    async def prompt(
        self,
        session_id: str,
        *,
        message: str,
        agent: Optional[str] = None,
        model: Optional[dict[str, str]] = None,
        variant: Optional[str] = None,
    ) -> Any:
        payload: dict[str, Any] = {
            "parts": [{"type": "text", "text": message}],
        }
        if agent:
            payload["agent"] = agent
        if model:
            payload["model"] = model
        if variant:
            payload["variant"] = variant
        try:
            return await self._request(
                "POST",
                f"/session/{session_id}/message",
                json_body=payload,
                expect_json=True,
            )
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in (404, 405):
                return await self._request(
                    "POST",
                    f"/session/{session_id}/prompt_async",
                    json_body=payload,
                    expect_json=False,
                )
            raise

    async def send_command(
        self,
        session_id: str,
        *,
        command: str,
        arguments: Optional[str] = None,
        model: Optional[str] = None,
        agent: Optional[str] = None,
    ) -> Any:
        payload: dict[str, Any] = {
            "command": command,
            "arguments": arguments or "",
        }
        if model:
            payload["model"] = model
        if agent:
            payload["agent"] = agent
        return await self._request(
            "POST",
            f"/session/{session_id}/command",
            json_body=payload,
            expect_json=False,
        )

    async def summarize(
        self,
        session_id: str,
        *,
        provider_id: str,
        model_id: str,
        auto: Optional[bool] = None,
    ) -> Any:
        payload: dict[str, Any] = {
            "providerID": provider_id,
            "modelID": model_id,
        }
        if auto is not None:
            payload["auto"] = auto
        return await self._request(
            "POST",
            f"/session/{session_id}/summarize",
            json_body=payload,
            expect_json=True,
        )

    async def respond_permission(
        self,
        *,
        request_id: str,
        reply: str,
        message: Optional[str] = None,
    ) -> Any:
        payload: dict[str, Any] = {"reply": reply}
        if message:
            payload["message"] = message
        return await self._request(
            "POST",
            f"/permission/{request_id}/reply",
            json_body=payload,
            expect_json=False,
        )

    async def abort(self, session_id: str) -> Any:
        return await self._request(
            "POST", f"/session/{session_id}/abort", expect_json=False
        )

    async def stream_events(
        self, *, directory: Optional[str] = None
    ) -> AsyncIterator[SSEEvent]:
        params = self._dir_params(directory)
        async with self._client.stream("GET", "/event", params=params) as response:
            response.raise_for_status()
            async for sse in parse_sse_lines(response.aiter_lines()):
                event_type = sse.event
                try:
                    payload = json.loads(sse.data) if sse.data else None
                    if isinstance(payload, dict) and "type" in payload:
                        event_type = str(payload["type"])
                except (json.JSONDecodeError, TypeError):
                    pass
                yield SSEEvent(
                    event=event_type,
                    data=sse.data,
                    id=sse.id,
                    retry=sse.retry,
                )


__all__ = ["OpenCodeClient", "OpenCodeProtocolError"]
