"""Agent harness abstractions."""
