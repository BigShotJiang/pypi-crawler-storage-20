"""
DSLighting 2.0 - Operators Layer

This layer provides atomic, reusable capability units.

Operators are organized into categories:
- LLM Operators: Language model operations (generate, plan, review, summarize)
- Code Operators: Code execution operations
- Data Operators: Data science operations (analysis, features, modeling, evaluation)
- Orchestration Operators: Composition patterns (Pipeline, Parallel, Conditional)
"""

# Base operator class
try:
    from dsat.operators.base import Operator
except ImportError:
    Operator = None

# LLM Operators
try:
    from dsat.operators.llm.generate import GenerateCodeAndPlanOperator
    from dsat.operators.llm.plan import PlanOperator
    from dsat.operators.llm.review import ReviewOperator
    from dsat.operators.llm.summarize import SummarizeOperator
except ImportError:
    GenerateCodeAndPlanOperator = None
    PlanOperator = None
    ReviewOperator = None
    SummarizeOperator = None

# Code Operators
try:
    from dsat.operators.code.execute import ExecuteAndTestOperator
except ImportError:
    ExecuteAndTestOperator = None

# Re-export orchestration operators
from .orchestration import Pipeline, Parallel, Conditional

# Custom Operators (用户自定义)
try:
    from .custom import *  # 导入所有自定义 operators
except ImportError:
    # 如果没有自定义 operators，忽略
    pass

__all__ = [
    # Base
    "Operator",
    # LLM Operators
    "GenerateCodeAndPlanOperator",
    "PlanOperator",
    "ReviewOperator",
    "SummarizeOperator",
    # Code Operators
    "ExecuteAndTestOperator",
    # Orchestration
    "Pipeline",
    "Parallel",
    "Conditional",
]


# ============================================================================
# Discovery Functions - Help users discover available operators
# ============================================================================

def list_available_operators(category: str = "all") -> dict[str, list[str]]:
    """
    List all available operators by category.

    Args:
        category: Filter by category ('all', 'llm', 'code', 'data', 'orchestration', 'custom')
                  Default: 'all'

    Returns:
        Dictionary mapping category names to lists of operator names

    Example:
        >>> from dslighting.operators import list_available_operators
        >>> ops = list_available_operators()
        >>> for category, names in ops.items():
        ...     print(f"{category}: {len(names)} operators")
    """
    categories = {
        "base": ["Operator"],
        "llm": [
            "GenerateCodeAndPlanOperator",
            "PlanOperator",
            "ReviewOperator",
            "SummarizeOperator",
        ],
        "code": [
            "ExecuteAndTestOperator",
        ],
        "orchestration": [
            "Pipeline",
            "Parallel",
            "Conditional",
        ],
    }

    # Add custom operators if any
    try:
        from .custom import __all__ as custom_all
        if custom_all:
            categories["custom"] = custom_all
    except (ImportError, AttributeError):
        pass

    if category == "all":
        return categories
    elif category in categories:
        return {category: categories[category]}
    else:
        return {}


def get_operator_info(operator_name: str) -> dict[str, str]:
    """
    Get information about a specific operator.

    Args:
        operator_name: Name of the operator class

    Returns:
        Dictionary with 'name', 'category', 'description', 'usage' keys

    Example:
        >>> from dslighting.operators import get_operator_info
        >>> info = get_operator_info("PlanOperator")
        >>> print(f"{info['name']}: {info['description']}")
    """
    operators_info = {
        # Base
        "Operator": {
            "category": "base",
            "description": "Base class for all operators. Inherit from this to create custom operators.",
            "usage": "class MyOperator(Operator): ...",
        },
        # LLM Operators
        "PlanOperator": {
            "category": "llm",
            "description": "Generate execution plans using LLM",
            "usage": "PlanOperator(llm_service=llm_service)",
        },
        "GenerateCodeAndPlanOperator": {
            "category": "llm",
            "description": "Generate code and execution plan together",
            "usage": "GenerateCodeAndPlanOperator(llm_service=llm_service)",
        },
        "ReviewOperator": {
            "category": "llm",
            "description": "Review and critique code or results using LLM",
            "usage": "ReviewOperator(llm_service=llm_service)",
        },
        "SummarizeOperator": {
            "category": "llm",
            "description": "Summarize execution history or results",
            "usage": "SummarizeOperator(llm_service=llm_service)",
        },
        # Code Operators
        "ExecuteAndTestOperator": {
            "category": "code",
            "description": "Execute code and run tests",
            "usage": "ExecuteAndTestOperator(sandbox_service=sandbox)",
        },
        # Orchestration Operators
        "Pipeline": {
            "category": "orchestration",
            "description": "Execute operators sequentially",
            "usage": "Pipeline([op1, op2, op3])",
        },
        "Parallel": {
            "category": "orchestration",
            "description": "Execute operators in parallel",
            "usage": "Parallel([op1, op2, op3])",
        },
        "Conditional": {
            "category": "orchestration",
            "description": "Execute operators based on condition",
            "usage": "Conditional(condition_func, if_op=[op1], else_op=[op2])",
        },
    }

    if operator_name in operators_info:
        info = operators_info[operator_name].copy()
        info["name"] = operator_name
        return info
    else:
        return {
            "name": operator_name,
            "error": f"Operator '{operator_name}' not found. Use list_available_operators() to see all available operators.",
        }


# Add discovery functions to __all__
__all__.extend([
    "list_available_operators",
    "get_operator_info",
])
