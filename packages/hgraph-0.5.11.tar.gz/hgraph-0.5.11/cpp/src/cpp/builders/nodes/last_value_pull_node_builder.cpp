#include <hgraph/builders/nodes/last_value_pull_node_builder.h>
#include <hgraph/builders/input_builder.h>
#include <hgraph/builders/output_builder.h>
#include <hgraph/types/node.h>
#include <hgraph/types/tsb.h>
#include <hgraph/nodes/last_value_pull_node.h>
#include <hgraph/util/arena_enable_shared_from_this.h>

namespace hgraph {

    size_t LastValuePullNodeBuilder::node_type_size() const {
        return sizeof(LastValuePullNode);
    }

    node_s_ptr LastValuePullNodeBuilder::make_instance(const std::vector<int64_t> &owning_graph_id,
                                                     int64_t node_ndx) const {
        auto node = arena_make_shared_as<LastValuePullNode, Node>(node_ndx, owning_graph_id, signature, scalars);
        _build_inputs_and_outputs(node.get());
        return node;
    }

    void last_value_pull_node_builder_register_with_nanobind(nb::module_ &m) {
        nb::class_<LastValuePullNodeBuilder, BaseNodeBuilder>(m, "LastValuePullNodeBuilder")
                .def("__init__",
                     [](LastValuePullNodeBuilder *self, const nb::kwargs &kwargs) {
                         auto signature_ = nb::cast<node_signature_s_ptr>(kwargs["signature"]);
                         auto scalars_ = nb::cast<nb::dict>(kwargs["scalars"]);

                         std::optional<input_builder_s_ptr> input_builder_ =
                                 kwargs.contains("input_builder")
                                     ? nb::cast<std::optional<input_builder_s_ptr> >(kwargs["input_builder"])
                                     : std::nullopt;
                         std::optional<output_builder_s_ptr> output_builder_ =
                                 kwargs.contains("output_builder")
                                     ? nb::cast<std::optional<output_builder_s_ptr> >(kwargs["output_builder"])
                                     : std::nullopt;
                         std::optional<output_builder_s_ptr> error_builder_ =
                                 kwargs.contains("error_builder")
                                     ? nb::cast<std::optional<output_builder_s_ptr> >(kwargs["error_builder"])
                                     : std::nullopt;
                         std::optional<output_builder_s_ptr> recordable_state_builder_ =
                                 kwargs.contains("recordable_state_builder")
                                     ? nb::cast<std::optional<output_builder_s_ptr> >(kwargs["recordable_state_builder"])
                                     : std::nullopt;

                         new(self) LastValuePullNodeBuilder(std::move(signature_), std::move(scalars_),
                                                            std::move(input_builder_),
                                                            std::move(output_builder_), std::move(error_builder_),
                                                            std::move(recordable_state_builder_));
                     });
    }
} // namespace hgraph