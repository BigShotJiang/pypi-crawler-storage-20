"""
Service layer for reward management operations.
"""

from datetime import datetime
from typing import List, Optional, Tuple, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func

from ..models.base import RewardTransaction, Contribution, FederatedSession, Node
from ..models.schemas import RewardTransactionResponse
from ..core.exceptions import RewardTransactionNotFoundError, ValidationError
# from ..rewards.dracma_calculator import dracmaCalculator, NodeContribution  # Commented out - module not found
from ...core.config import Config


from ...rewards.dracma_calculator import dracmaCalculator, NodeContribution # Add this import

class RewardService:
    """Service for managing DracmaS rewards and transactions."""

    def __init__(self, config: Config = None):
        self.config = config or Config()
        self.dracma_calculator = dracmaCalculator(self.config)

    @staticmethod
    async def list_reward_transactions(
        db: Session,
        skip: int = 0,
        limit: int = 100,
        session_id: Optional[str] = None,
        node_id: Optional[str] = None,
        transaction_type: Optional[str] = None,
        status: Optional[str] = None
    ) -> Tuple[List[RewardTransactionResponse], int]:
        """List reward transactions with optional filtering."""
        query = db.query(RewardTransaction)

        # Apply filters
        if session_id:
            query = query.filter(RewardTransaction.session_id == session_id)
        if node_id:
            query = query.filter(RewardTransaction.node_id == node_id)
        if transaction_type:
            query = query.filter(RewardTransaction.transaction_type == transaction_type)
        if status:
            query = query.filter(RewardTransaction.status == status)

        # Get total count
        total = query.count()

        # Apply pagination
        transactions = query.offset(skip).limit(limit).all()

        # Convert to response models
        transaction_responses = []
        for transaction in transactions:
            transaction_responses.append(RewardTransactionResponse(
                id=transaction.id,
                session_id=transaction.session_id,
                node_id=transaction.node_id,
                transaction_type=transaction.transaction_type,
                dracma_amount=transaction.dracma_amount,
                contribution_id=transaction.contribution_id,
                status=transaction.status,
                blockchain_tx_hash=transaction.blockchain_tx_hash,
                blockchain_tx_status=transaction.blockchain_tx_status,
                processed_at=transaction.processed_at,
                distribution_proof=transaction.distribution_proof,
                created_at=transaction.created_at,
                updated_at=transaction.updated_at
            ))

        return transaction_responses, total

    @staticmethod
    async def get_reward_transaction_by_id(db: Session, transaction_id: int) -> RewardTransactionResponse:
        """Get a reward transaction by ID."""
        transaction = db.query(RewardTransaction).filter(RewardTransaction.id == transaction_id).first()
        if not transaction:
            raise RewardTransactionNotFoundError(transaction_id)

        return RewardTransactionResponse(
            id=transaction.id,
            session_id=transaction.session_id,
            node_id=transaction.node_id,
            transaction_type=transaction.transaction_type,
            dracma_amount=transaction.dracma_amount,
            contribution_id=transaction.contribution_id,
            status=transaction.status,
            blockchain_tx_hash=transaction.blockchain_tx_hash,
            blockchain_tx_status=transaction.blockchain_tx_status,
            processed_at=transaction.processed_at,
            distribution_proof=transaction.distribution_proof,
            created_at=transaction.created_at,
            updated_at=transaction.updated_at
        )

    @staticmethod
    async def create_reward_transaction(
        db: Session,
        session_id: str,
        node_id: str,
        transaction_type: str,
        dracma_amount: float,
        contribution_id: Optional[int] = None
    ) -> RewardTransactionResponse:
        """Create a new reward transaction."""
        # Validate session
        session = db.query(FederatedSession).filter(FederatedSession.id == session_id).first()
        if not session:
            from ..core.exceptions import SessionNotFoundError
            raise SessionNotFoundError(session_id)

        # Validate node
        node = db.query(Node).filter(Node.id == node_id).first()
        if not node:
            from ..core.exceptions import NodeNotFoundError
            raise NodeNotFoundError(node_id)

        # Validate contribution if provided
        if contribution_id:
            contribution = db.query(Contribution).filter(Contribution.id == contribution_id).first()
            if not contribution:
                from ..core.exceptions import ContributionNotFoundError
                raise ContributionNotFoundError(contribution_id)

        # Validate amount
        if dracma_amount <= 0:
            raise ValidationError("DracmaS amount must be positive")

        # Create transaction
        transaction = RewardTransaction(
            session_id=session_id,
            node_id=node_id,
            transaction_type=transaction_type,
            dracma_amount=dracma_amount,
            contribution_id=contribution_id
        )

        db.add(transaction)
        db.commit()
        db.refresh(transaction)

        return await RewardService.get_reward_transaction_by_id(db, transaction.id)

    async def calculate_session_rewards(
        self,
        db: Session,
        session_id: str
    ) -> List[RewardTransactionResponse]:
        """Calculate rewards for all contributions in a session."""
        # Get all validated contributions for the session
        contributions = db.query(Contribution).filter(
            and_(
                Contribution.session_id == session_id,
                Contribution.status == 'validated'
            )
        ).all()

        if not contributions:
            return []

        # Convert to NodeContribution objects for the calculator
        node_contributions_for_calculator = []
        from ...verification.zk_proofs import ContributionProof # Import here to avoid circular dependency
        for contrib in contributions:
            # The proof_of_work from the DB is now a JSON object, which SQLAlchemy
            # automatically deserializes into a Python dict. We need to convert it
            # back to a ContributionProof dataclass if it's not None.
            proof_of_work_obj = None
            if contrib.proof_of_work:
                # Assuming the JSON stored is a dict representation of ContributionProof
                proof_of_work_obj = ContributionProof(**contrib.proof_of_work)

            node_contrib = NodeContribution(
                node_id=contrib.node_id,
                session_id=contrib.session_id,
                round_number=contrib.round_number,
                parameters_trained=contrib.parameters_trained,
                data_samples=contrib.data_samples_used,
                training_time_seconds=contrib.training_time_seconds,
                model_accuracy=contrib.model_accuracy or 0.0,
                hardware_specs=contrib.hardware_specs or {},
                timestamp=contrib.created_at,
                proof_of_work=proof_of_work_obj
            )
            node_contributions_for_calculator.append(node_contrib)

        # Add contributions to calculator
        for contrib in node_contributions_for_calculator:
            await self.dracma_calculator.add_contribution(contrib)

        # Calculate rewards
        reward_calculations = await self.dracma_calculator.calculate_session_rewards(session_id)

        # Create transactions for each reward
        transactions = []
        for calc in reward_calculations:
            # Find corresponding contribution
            contribution = next(
                (c for c in contributions if c.node_id == calc.node_id and c.round_number == calc.round_number),
                None
            )

            if contribution:
                # Update contribution with calculated rewards
                contribution.rewards_calculated = calc.dracma_amount

                # Create reward transaction
                transaction = await self.create_reward_transaction(
                    db=db,
                    session_id=session_id,
                    node_id=calc.node_id,
                    transaction_type='contribution_reward',
                    dracma_amount=calc.dracma_amount,
                    contribution_id=contribution.id
                )
                transactions.append(transaction)

        # Commit contribution updates
        db.commit()

        # Broadcast reward distribution event
        from ..websocket.event_broadcaster import event_broadcaster
        from ..websocket.notification_service import notification_service

        reward_data = [
            {
                "node_id": calc.node_id,
                "amount": calc.dracma_amount,
                "reason": "training_contribution",
                "round_number": calc.round_number
            }
            for calc in reward_calculations
        ]
        await event_broadcaster.notify_rewards_distributed(session_id, reward_data)

        # Send individual notifications
        await notification_service.notify_on_rewards_distributed(session_id, reward_data)

        return transactions

    @staticmethod
    async def process_reward_transaction(
        db: Session,
        transaction_id: int,
        blockchain_tx_hash: str
    ) -> RewardTransactionResponse:
        """Process a reward transaction on the blockchain."""
        transaction = db.query(RewardTransaction).filter(RewardTransaction.id == transaction_id).first()
        if not transaction:
            raise RewardTransactionNotFoundError(transaction_id)

        if transaction.status != 'pending':
            raise ValidationError(f"Transaction is already {transaction.status}")

        # Update transaction with blockchain info
        transaction.blockchain_tx_hash = blockchain_tx_hash
        transaction.status = 'processing'
        transaction.processed_at = datetime.utcnow()

        db.commit()
        db.refresh(transaction)

        return await RewardService.get_reward_transaction_by_id(db, transaction_id)

    @staticmethod
    async def confirm_reward_transaction(
        db: Session,
        transaction_id: int,
        blockchain_tx_status: str = 'confirmed'
    ) -> RewardTransactionResponse:
        """Confirm a processed reward transaction."""
        transaction = db.query(RewardTransaction).filter(RewardTransaction.id == transaction_id).first()
        if not transaction:
            raise RewardTransactionNotFoundError(transaction_id)

        if transaction.status not in ['processing', 'pending']:
            raise ValidationError(f"Transaction is already {transaction.status}")

        # Update transaction status
        transaction.blockchain_tx_status = blockchain_tx_status
        transaction.status = 'completed' if blockchain_tx_status == 'confirmed' else 'failed'

        # Update node total rewards if completed
        if transaction.status == 'completed':
            node = db.query(Node).filter(Node.id == transaction.node_id).first()
            if node:
                node.total_rewards_earned += transaction.dracma_amount
                db.commit()

        db.commit()
        db.refresh(transaction)

        return await RewardService.get_reward_transaction_by_id(db, transaction_id)

    @staticmethod
    async def get_node_rewards(
        db: Session,
        node_id: str,
        session_id: Optional[str] = None,
        limit: Optional[int] = None
    ) -> List[RewardTransactionResponse]:
        """Get reward transactions for a specific node."""
        query = db.query(RewardTransaction).filter(RewardTransaction.node_id == node_id)

        if session_id:
            query = query.filter(RewardTransaction.session_id == session_id)

        query = query.order_by(RewardTransaction.created_at.desc())

        if limit:
            query = query.limit(limit)

        transactions = query.all()

        return [
            RewardTransactionResponse(
                id=t.id,
                session_id=t.session_id,
                node_id=t.node_id,
                transaction_type=t.transaction_type,
                dracma_amount=t.dracma_amount,
                contribution_id=t.contribution_id,
                status=t.status,
                blockchain_tx_hash=t.blockchain_tx_hash,
                blockchain_tx_status=t.blockchain_tx_status,
                processed_at=t.processed_at,
                distribution_proof=t.distribution_proof,
                created_at=t.created_at,
                updated_at=t.updated_at
            )
            for t in transactions
        ]

    @staticmethod
    async def get_session_rewards(db: Session, session_id: str) -> List[RewardTransactionResponse]:
        """Get all reward transactions for a session."""
        transactions = db.query(RewardTransaction).filter(RewardTransaction.session_id == session_id).all()

        return [
            RewardTransactionResponse(
                id=t.id,
                session_id=t.session_id,
                node_id=t.node_id,
                transaction_type=t.transaction_type,
                dracma_amount=t.dracma_amount,
                contribution_id=t.contribution_id,
                status=t.status,
                blockchain_tx_hash=t.blockchain_tx_hash,
                blockchain_tx_status=t.blockchain_tx_status,
                processed_at=t.processed_at,
                distribution_proof=t.distribution_proof,
                created_at=t.created_at,
                updated_at=t.updated_at
            )
            for t in transactions
        ]

    @staticmethod
    async def get_reward_stats(db: Session, session_id: Optional[str] = None) -> dict:
        """Get reward statistics."""
        query = db.query(RewardTransaction)

        if session_id:
            query = query.filter(RewardTransaction.session_id == session_id)

        total_transactions = query.count()
        completed_transactions = query.filter(RewardTransaction.status == 'completed').count()
        pending_transactions = query.filter(RewardTransaction.status == 'pending').count()
        failed_transactions = query.filter(RewardTransaction.status == 'failed').count()

        # Calculate totals
        total_dracma = db.query(func.sum(RewardTransaction.dracma_amount)).filter(
            RewardTransaction.status == 'completed'
        ).scalar() or 0

        avg_reward = db.query(func.avg(RewardTransaction.dracma_amount)).filter(
            RewardTransaction.status == 'completed'
        ).scalar() or 0

        return {
            'total_transactions': total_transactions,
            'completed_transactions': completed_transactions,
            'pending_transactions': pending_transactions,
            'failed_transactions': failed_transactions,
            'completion_rate': completed_transactions / max(total_transactions, 1),
            'total_dracma_distributed': float(total_dracma),
            'average_reward_amount': float(avg_reward)
        }

    def get_reward_pool_status(self, session_id: str) -> Optional[dict]:
        """Get reward pool status for a session."""
        if not self.dracma_calculator:
            return None # Or raise an error if calculator is mandatory

        reward_pool = self.dracma_calculator.get_reward_pool_status(session_id)
        if reward_pool:
            return {
                'session_id': reward_pool.session_id,
                'total_pool_dracma': reward_pool.total_pool_dracma,
                'allocated_dracma': reward_pool.allocated_dracma,
                'remaining_dracma': reward_pool.remaining_dracma,
                'distribution_start': reward_pool.distribution_start.isoformat(),
                'distribution_end': reward_pool.distribution_end.isoformat() if reward_pool.distribution_end else None,
                'min_contribution_threshold': reward_pool.min_contribution_threshold,
                'reward_curve': reward_pool.reward_curve
            }
        return None

    # ===== MEMORY HOSTING REWARDS INTEGRATION =====

    async def calculate_memory_hosting_rewards(self, db: Session, node_id: str,
                                             verification_data: Dict[str, Any]) -> List[RewardTransactionResponse]:
        """
        Calculate and distribute rewards for memory hosting (Proof of Memory).

        Args:
            db: Database session
            node_id: ID of the memory hosting node
            verification_data: Verification metrics from memory hosting

        Returns:
            List of created reward transactions
        """
        try:
            # Import DRACMA manager for memory hosting functionality
            from ...rewards.dracma_manager import DRACMA_Manager
            from ...core.config import get_config

            dracma_manager = DRACMA_Manager(get_config())

            # Get memory hosting stats for the node
            hosting_stats = dracma_manager.get_memory_hosting_stats(node_id)
            if hosting_stats.get('error') or not hosting_stats.get('node_memory_slots', 0) > 0:
                # Node is not registered for memory hosting
                return []

            # Calculate rewards for each hosting record
            reward_transactions = []

            # In a real implementation, we would iterate through active hosting records
            # For now, simulate based on hosting stats
            total_slots = hosting_stats.get('node_memory_slots', 0)
            if total_slots > 0:
                # Calculate base reward (simplified)
                base_reward = total_slots * 0.1 * 24  # 0.1 DRACMA per slot per hour * 24 hours

                # Apply verification bonuses
                uptime_bonus = verification_data.get('uptime_percentage', 1.0)
                integrity_bonus = verification_data.get('storage_integrity', 1.0)

                total_reward = base_reward * uptime_bonus * integrity_bonus

                # Create reward transaction
                transaction = await self.create_reward_transaction(
                    db=db,
                    session_id=f"memory_hosting_{node_id}",  # Special session for memory hosting
                    node_id=node_id,
                    transaction_type='memory_hosting_reward',
                    drachma_amount=total_reward
                )

                reward_transactions.append(transaction)

                # Log the memory hosting reward
                self.logger.info(f"💾 Distributed {total_reward:.4f} DRACMA memory hosting rewards to {node_id} "
                               f"({total_slots} slots, uptime: {uptime_bonus:.2f})")

            return reward_transactions

        except Exception as e:
            self.logger.error(f"Error calculating memory hosting rewards for {node_id}: {e}")
            return []

    async def get_memory_hosting_rewards_history(self, db: Session, node_id: str,
                                                limit: Optional[int] = None) -> List[RewardTransactionResponse]:
        """
        Get memory hosting rewards history for a node.

        Args:
            db: Database session
            node_id: Node ID
            limit: Maximum number of transactions to return

        Returns:
            List of memory hosting reward transactions
        """
        try:
            query = db.query(RewardTransaction).filter(
                RewardTransaction.node_id == node_id,
                RewardTransaction.transaction_type == 'memory_hosting_reward'
            ).order_by(RewardTransaction.created_at.desc())

            if limit:
                query = query.limit(limit)

            transactions = query.all()

            return [
                RewardTransactionResponse(
                    id=t.id,
                    session_id=t.session_id,
                    node_id=t.node_id,
                    transaction_type=t.transaction_type,
                    drachma_amount=t.drachma_amount,
                    contribution_id=t.contribution_id,
                    status=t.status,
                    blockchain_tx_hash=t.blockchain_tx_hash,
                    blockchain_tx_status=t.blockchain_tx_status,
                    processed_at=t.processed_at,
                    distribution_proof=t.distribution_proof,
                    created_at=t.created_at,
                    updated_at=t.updated_at
                )
                for t in transactions
            ]

        except Exception as e:
            self.logger.error(f"Error getting memory hosting rewards history for {node_id}: {e}")
            return []

    async def register_memory_hosting_node(self, db: Session, node_id: str,
                                         hosting_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Register a node for memory hosting rewards.

        Args:
            db: Database session
            node_id: Node ID
            hosting_config: Memory hosting configuration

        Returns:
            Registration result
        """
        try:
            # Import DRACMA manager
            from ...rewards.dracma_manager import DRACMA_Manager
            from ...core.config import get_config

            dracma_manager = DRACMA_Manager(get_config())

            # Register with DRACMA manager
            registration_result = dracma_manager.register_memory_hosting(
                node_id=node_id,
                memory_slots=hosting_config.get('memory_slots', 1),
                storage_capacity_gb=hosting_config.get('storage_capacity_gb', 10.0),
                uptime_commitment=hosting_config.get('uptime_commitment', 0.99)
            )

            if registration_result['success']:
                # Create a special transaction to record the registration
                await self.create_reward_transaction(
                    db=db,
                    session_id=f"memory_registration_{node_id}",
                    node_id=node_id,
                    transaction_type='memory_hosting_registration',
                    drachma_amount=0.0  # Registration is free
                )

                self.logger.info(f"📚 Registered node {node_id} for memory hosting rewards")

            return registration_result

        except Exception as e:
            self.logger.error(f"Error registering memory hosting for {node_id}: {e}")
            return {'success': False, 'error': str(e)}

    async def verify_memory_hosting_performance(self, db: Session, node_id: str,
                                              verification_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Verify memory hosting performance and update rewards accordingly.

        Args:
            db: Database session
            node_id: Node ID
            verification_data: Performance verification data

        Returns:
            Verification result
        """
        try:
            # Import DRACMA manager
            from ...rewards.dracma_manager import DRACMA_Manager
            from ...core.config import get_config

            dracma_manager = DRACMA_Manager(get_config())

            # Get hosting records for the node
            hosting_stats = dracma_manager.get_memory_hosting_stats(node_id)

            if not hosting_stats.get('node_memory_slots', 0) > 0:
                return {'success': False, 'error': 'Node not registered for memory hosting'}

            # Perform verification (simplified - in production would involve cryptographic proofs)
            hosting_id = f"memory_host_{node_id}_verification"  # Simplified

            verification_result = dracma_manager.verify_memory_hosting_integrity(
                hosting_id=hosting_id,
                challenge_data=verification_data
            )

            if verification_result['success']:
                # Calculate and distribute rewards based on verification
                reward_transactions = await self.calculate_memory_hosting_rewards(
                    db=db,
                    node_id=node_id,
                    verification_data=verification_data
                )

                verification_result['rewards_distributed'] = len(reward_transactions)
                verification_result['total_rewards'] = sum(tx.drachma_amount for tx in reward_transactions)

            return verification_result

        except Exception as e:
            self.logger.error(f"Error verifying memory hosting performance for {node_id}: {e}")
            return {'success': False, 'error': str(e)}

    def get_memory_hosting_reward_stats(self, db: Session) -> Dict[str, Any]:
        """
        Get statistics about memory hosting rewards.

        Args:
            db: Database session

        Returns:
            Memory hosting reward statistics
        """
        try:
            # Get total memory hosting rewards distributed
            total_rewards = db.query(RewardTransaction).filter(
                RewardTransaction.transaction_type == 'memory_hosting_reward'
            ).count()

            total_amount = db.query(func.sum(RewardTransaction.drachma_amount)).filter(
                RewardTransaction.transaction_type == 'memory_hosting_reward'
            ).scalar() or 0.0

            # Get active memory hosting nodes
            active_registrations = db.query(RewardTransaction).filter(
                RewardTransaction.transaction_type == 'memory_hosting_registration'
            ).count()

            # Get recent activity (last 24 hours)
            from datetime import datetime, timedelta
            yesterday = datetime.utcnow() - timedelta(days=1)

            recent_rewards = db.query(func.sum(RewardTransaction.drachma_amount)).filter(
                RewardTransaction.transaction_type == 'memory_hosting_reward',
                RewardTransaction.created_at >= yesterday
            ).scalar() or 0.0

            return {
                'total_memory_hosting_rewards': float(total_amount),
                'total_reward_transactions': total_rewards,
                'active_memory_hosting_nodes': active_registrations,
                'rewards_last_24h': float(recent_rewards),
                'avg_reward_per_transaction': float(total_amount) / max(total_rewards, 1)
            }

        except Exception as e:
            self.logger.error(f"Error getting memory hosting reward stats: {e}")
            return {'error': str(e)}
