"""
Servicio para gestionar tracking de versiones de modelos por nodo.

Permite:
- Registrar distribuci\u00f3n de modelos a nodos
- Confirmar descarga exitosa de nodos
- Consultar qu\u00e9 versiones tiene cada nodo
- Estad\u00edsticas de distribuci\u00f3n
"""

import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging

from ...core.logging import get_logger

logger = get_logger(__name__)


class NodeModelVersionService:
    """
    Servicio para tracking de versiones de modelos distribuidas a nodos.
    
    En ausencia de base de datos, usa storage en memoria.
    Para producci\u00f3n, conectar a PostgreSQL/SQLite v\u00eda SQLAlchemy.
    """
    
    def __init__(self):
        # Storage en memoria (para demo sin DB)
        # En producci\u00f3n: self.db_session = get_db_session()
        self.node_versions: Dict[str, Dict[str, Dict[str, Any]]] = {}  # {node_id: {version_id: data}}
        self.distribution_history: List[Dict[str, Any]] = []
        
        logger.info("\ud83d\udcbe NodeModelVersionService initialized (in-memory mode)")
    
    async def register_distribution(self, node_id: str, version_id: str, 
                                   model_cid: str, metadata_cid: str,
                                   expected_hash: str) -> bool:
        """
        Registrar que una versi\u00f3n fue distribuida a un nodo.
        
        Args:
            node_id: ID del nodo
            version_id: ID de la versi\u00f3n
            model_cid: CID del modelo en IPFS
            metadata_cid: CID de metadata en IPFS
            expected_hash: Hash esperado del modelo
            
        Returns:
            True si se registr\u00f3 exitosamente
        """
        try:
            if node_id not in self.node_versions:
                self.node_versions[node_id] = {}
            
            # Registrar distribuci\u00f3n
            self.node_versions[node_id][version_id] = {
                'version_id': version_id,
                'model_cid': model_cid,
                'metadata_cid': metadata_cid,
                'expected_hash': expected_hash,
                'distributed_at': datetime.utcnow().isoformat(),
                'downloaded_at': None,
                'hash_verified': False,
                'verified_hash': None,
                'download_success': False,
                'error_message': None,
                'metadata': {}
            }
            
            # A\u00f1adir a historial
            self.distribution_history.append({
                'node_id': node_id,
                'version_id': version_id,
                'action': 'distributed',
                'timestamp': datetime.utcnow().isoformat()
            })
            
            logger.info(f"\ud83d\udcdd Registered distribution: {version_id} -> {node_id}")
            return True
            
        except Exception as e:
            logger.error(f"\u274c Error registering distribution: {e}")
            return False
    
    async def confirm_download(self, node_id: str, version_id: str,
                              verified_hash: str, success: bool,
                              error_message: str = "") -> bool:
        """
        Confirmar que un nodo descarg\u00f3 una versi\u00f3n.
        
        Args:
            node_id: ID del nodo
            version_id: ID de la versi\u00f3n
            verified_hash: Hash verificado por el nodo
            success: Si la descarga fue exitosa
            error_message: Mensaje de error si fallo
            
        Returns:
            True si se confirm\u00f3 exitosamente
        """
        try:
            if node_id not in self.node_versions or version_id not in self.node_versions[node_id]:
                logger.warning(f"\u26a0\ufe0f No distribution found for {node_id}/{version_id}")
                return False
            
            version_data = self.node_versions[node_id][version_id]
            expected_hash = version_data['expected_hash']
            
            # Actualizar datos
            version_data.update({
                'downloaded_at': datetime.utcnow().isoformat(),
                'verified_hash': verified_hash,
                'hash_verified': verified_hash == expected_hash,
                'download_success': success,
                'error_message': error_message if not success else None
            })
            
            # A\u00f1adir a historial
            self.distribution_history.append({
                'node_id': node_id,
                'version_id': version_id,
                'action': 'downloaded' if success else 'failed',
                'timestamp': datetime.utcnow().isoformat(),
                'hash_verified': version_data['hash_verified']
            })
            
            status = "\u2705" if success else "\u274c"
            logger.info(f"{status} Confirmed download: {version_id} on {node_id} (success={success})")
            return True
            
        except Exception as e:
            logger.error(f"\u274c Error confirming download: {e}")
            return False
    
    async def get_node_versions(self, node_id: str) -> List[Dict[str, Any]]:
        """
        Obtener todas las versiones de un nodo.
        
        Args:
            node_id: ID del nodo
            
        Returns:
            Lista de versiones con su estado
        """
        try:
            if node_id not in self.node_versions:
                return []
            
            versions = list(self.node_versions[node_id].values())
            logger.debug(f"\ud83d\udcca Node {node_id} has {len(versions)} versions")
            return versions
            
        except Exception as e:
            logger.error(f"\u274c Error getting node versions: {e}")
            return []
    
    async def node_has_version(self, node_id: str, version_id: str) -> bool:
        """
        Verificar si un nodo tiene una versi\u00f3n espec\u00edfica.
        
        Args:
            node_id: ID del nodo
            version_id: ID de la versi\u00f3n
            
        Returns:
            True si el nodo tiene la versi\u00f3n y fue verificada
        """
        try:
            if node_id not in self.node_versions or version_id not in self.node_versions[node_id]:
                return False
            
            version_data = self.node_versions[node_id][version_id]
            return version_data.get('download_success', False) and version_data.get('hash_verified', False)
            
        except Exception as e:
            logger.error(f"\u274c Error checking node version: {e}")
            return False
    
    async def get_version_nodes(self, version_id: str) -> List[str]:
        """
        Obtener qu\u00e9 nodos tienen una versi\u00f3n espec\u00edfica.
        
        Args:
            version_id: ID de la versi\u00f3n
            
        Returns:
            Lista de node_ids que tienen la versi\u00f3n
        """
        try:
            nodes_with_version = []
            
            for node_id, versions in self.node_versions.items():
                if version_id in versions:
                    version_data = versions[version_id]
                    if version_data.get('download_success', False):
                        nodes_with_version.append(node_id)
            
            logger.debug(f"\ud83d\udcca Version {version_id} is on {len(nodes_with_version)} nodes")
            return nodes_with_version
            
        except Exception as e:
            logger.error(f"\u274c Error getting version nodes: {e}")
            return []
    
    async def get_distribution_stats(self) -> Dict[str, Any]:
        """
        Obtener estad\u00edsticas de distribuci\u00f3n.
        
        Returns:
            Diccionario con estad\u00edsticas
        """
        try:
            total_distributions = sum(len(versions) for versions in self.node_versions.values())
            successful = 0
            failed = 0
            pending = 0
            
            for versions in self.node_versions.values():
                for version_data in versions.values():
                    if version_data.get('download_success'):
                        successful += 1
                    elif version_data.get('downloaded_at'):
                        failed += 1
                    else:
                        pending += 1
            
            return {
                'total_distributions': total_distributions,
                'successful': successful,
                'failed': failed,
                'pending': pending,
                'success_rate': successful / total_distributions if total_distributions > 0 else 0,
                'total_nodes': len(self.node_versions),
                'distribution_history_size': len(self.distribution_history)
            }
            
        except Exception as e:
            logger.error(f"\u274c Error getting stats: {e}")
            return {}
    
    async def cleanup_old_distributions(self, days_old: int = 30) -> int:
        """
        Limpiar distribuciones antiguas.
        
        Args:
            days_old: D\u00edas de antig\u00fcedad
            
        Returns:
            N\u00famero de distribuciones eliminadas
        """
        # Implementaci\u00f3n simplificada - en producci\u00f3n usar timestamps
        logger.info(f"\ud83e\uddf9 Cleanup would remove distributions older than {days_old} days")
        return 0


# Singleton instance
_service_instance = None

def get_node_version_service() -> NodeModelVersionService:
    """Obtener instancia singleton del servicio."""
    global _service_instance
    if _service_instance is None:
        _service_instance = NodeModelVersionService()
    return _service_instance
