"""
Personalization training queue with persistent storage.
"""

import logging
import threading
import uuid
from datetime import datetime
from typing import Optional, Dict, Any

from sqlalchemy.orm import Session

from ..database.connection import SessionLocal
from ..models.base import PersonalizationTrainingSession, PersonalizationTrainingJob
from ...ai.personalization import PersonalizationService, FineTuningConfig

logger = logging.getLogger(__name__)

_PRIORITY_MAP = {"low": 1, "normal": 2, "high": 3}
_ACTIVE_STATUSES = {"queued", "initialized", "preparing", "training", "evaluating"}
_DONE_STATUSES = {"completed", "failed", "cancelled"}


def _calculate_progress(status: str, session_data: Optional[Dict[str, Any]], total_epochs: int) -> float:
    if status == "completed":
        return 1.0
    if status in ("failed", "cancelled"):
        return 0.0
    if not session_data:
        return 0.0
    total_steps = session_data.get("total_steps") or 0
    if total_steps:
        current_step = session_data.get("current_step") or 0
        return min(1.0, max(0.0, current_step / total_steps))
    if total_epochs:
        current_epoch = session_data.get("current_epoch") or 0
        return min(1.0, max(0.0, current_epoch / total_epochs))
    return 0.0


class PersonalizationTrainingWorker:
    """Background worker that executes queued personalization jobs."""

    def __init__(
        self,
        session_factory=SessionLocal,
        personalization_service: Optional[PersonalizationService] = None,
        poll_interval: float = 5.0
    ):
        self.session_factory = session_factory
        self.personalization_service = personalization_service or PersonalizationService()
        self.poll_interval = poll_interval
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        logger.info("Personalization training worker started")

    def stop(self) -> None:
        self._stop_event.set()

    def _run_loop(self) -> None:
        while not self._stop_event.is_set():
            session_id = self._claim_next_job()
            if not session_id:
                self._stop_event.wait(self.poll_interval)
                continue
            self._run_job(session_id)

    def _claim_next_job(self) -> Optional[str]:
        db = self.session_factory()
        try:
            query = db.query(PersonalizationTrainingJob).filter(
                PersonalizationTrainingJob.status == "queued"
            ).order_by(
                PersonalizationTrainingJob.priority.desc(),
                PersonalizationTrainingJob.created_at.asc()
            )
            try:
                job = query.with_for_update(skip_locked=True).first()
            except Exception:
                job = query.first()

            if not job:
                return None

            if job.attempts >= job.max_attempts:
                job.status = "failed"
                job.last_error = "Max attempts exceeded"
                job.completed_at = datetime.utcnow()
                db.commit()
                return None

            now = datetime.utcnow()
            job.status = "running"
            job.started_at = now
            job.attempts = (job.attempts or 0) + 1
            job.updated_at = now

            session = db.query(PersonalizationTrainingSession).filter(
                PersonalizationTrainingSession.id == job.session_id
            ).first()
            if session:
                session.status = "preparing"
                session.started_at = session.started_at or now
                session.updated_at = now

            db.commit()
            return job.session_id
        finally:
            db.close()

    def _run_job(self, session_id: str) -> None:
        db = self.session_factory()
        try:
            session = db.query(PersonalizationTrainingSession).filter(
                PersonalizationTrainingSession.id == session_id
            ).first()
            if not session:
                self._mark_job_failed(session_id, "Session not found")
                return

            user_numeric_id = session.user_numeric_id
            config_data = session.config or {}
        finally:
            db.close()

        if user_numeric_id is None:
            self._mark_job_failed(session_id, "Missing numeric user id")
            return

        config = FineTuningConfig(**config_data)

        self.personalization_service.create_training_session(
            user_id=user_numeric_id,
            config=config,
            session_id=session_id
        )
        self.personalization_service.add_progress_callback(session_id, self._progress_callback)

        started = self.personalization_service.start_fine_tuning(session_id, run_async=False)
        if not started:
            self._mark_job_failed(session_id, "Failed to start fine-tuning")
            return

        self._finalize_job(session_id)

    def _progress_callback(self, session_id: str, status: str, message: str, session_data: Dict[str, Any]) -> None:
        db = self.session_factory()
        try:
            session = db.query(PersonalizationTrainingSession).filter(
                PersonalizationTrainingSession.id == session_id
            ).first()
            if not session:
                return

            session.status = status
            session.current_epoch = session_data.get("current_epoch", session.current_epoch)
            session.total_epochs = session_data.get("config", {}).get(
                "max_epochs", session.total_epochs
            )
            session.training_loss = session_data.get("training_loss")
            session.validation_loss = session_data.get("validation_loss")
            session.progress = _calculate_progress(status, session_data, session.total_epochs)
            session.model_path = session_data.get("model_path") or session.model_path
            session.base_model_path = session_data.get("base_model_path") or session.base_model_path
            session.metadata_json = session_data.get("metadata") or session.metadata_json
            session.updated_at = datetime.utcnow()

            if status in _DONE_STATUSES:
                session.completed_at = session.completed_at or datetime.utcnow()
                if status == "failed":
                    session.error_message = session_data.get("metadata", {}).get("error")

                job = db.query(PersonalizationTrainingJob).filter(
                    PersonalizationTrainingJob.session_id == session_id
                ).first()
                if job:
                    job.status = status
                    job.completed_at = job.completed_at or datetime.utcnow()
                    job.updated_at = datetime.utcnow()
                    if status == "failed":
                        job.last_error = session.error_message or "Training failed"
                    if status == "cancelled":
                        job.last_error = "Cancelled by user"

            db.commit()
        finally:
            db.close()

    def _finalize_job(self, session_id: str) -> None:
        db = self.session_factory()
        try:
            session = db.query(PersonalizationTrainingSession).filter(
                PersonalizationTrainingSession.id == session_id
            ).first()
            job = db.query(PersonalizationTrainingJob).filter(
                PersonalizationTrainingJob.session_id == session_id
            ).first()
            if not session or not job:
                return

            if session.status in _DONE_STATUSES and job.status not in _DONE_STATUSES:
                job.status = session.status
                job.completed_at = job.completed_at or datetime.utcnow()
                job.updated_at = datetime.utcnow()
                if session.status == "failed":
                    job.last_error = session.error_message or "Training failed"
                if session.status == "cancelled":
                    job.last_error = "Cancelled by user"
                db.commit()
        finally:
            db.close()

    def _mark_job_failed(self, session_id: str, error_message: str) -> None:
        db = self.session_factory()
        try:
            now = datetime.utcnow()
            job = db.query(PersonalizationTrainingJob).filter(
                PersonalizationTrainingJob.session_id == session_id
            ).first()
            session = db.query(PersonalizationTrainingSession).filter(
                PersonalizationTrainingSession.id == session_id
            ).first()
            if session:
                session.status = "failed"
                session.error_message = error_message
                session.completed_at = now
                session.updated_at = now
            if job:
                job.status = "failed"
                job.last_error = error_message
                job.completed_at = now
                job.updated_at = now
            db.commit()
        finally:
            db.close()


class PersonalizationTrainingQueue:
    """Queue interface used by API endpoints."""

    def __init__(self, session_factory=SessionLocal):
        self.session_factory = session_factory
        self.personalization_service = PersonalizationService()
        self.worker = PersonalizationTrainingWorker(
            session_factory=session_factory,
            personalization_service=self.personalization_service
        )

    def start_worker(self) -> None:
        self.worker.start()

    def get_active_session(self, db: Session, user_id: str) -> Optional[PersonalizationTrainingSession]:
        return db.query(PersonalizationTrainingSession).filter(
            PersonalizationTrainingSession.user_id == user_id,
            PersonalizationTrainingSession.status.in_(_ACTIVE_STATUSES)
        ).order_by(PersonalizationTrainingSession.created_at.desc()).first()

    def list_sessions(self, db: Session, user_id: str) -> list[PersonalizationTrainingSession]:
        return db.query(PersonalizationTrainingSession).filter(
            PersonalizationTrainingSession.user_id == user_id
        ).order_by(PersonalizationTrainingSession.created_at.desc()).all()

    def enqueue_session(
        self,
        db: Session,
        user_id: str,
        user_numeric_id: Optional[int],
        dataset_size: str,
        training_hours: int,
        priority: str,
        config: FineTuningConfig
    ) -> PersonalizationTrainingSession:
        session_id = str(uuid.uuid4())
        session = PersonalizationTrainingSession(
            id=session_id,
            user_id=user_id,
            user_numeric_id=user_numeric_id,
            status="queued",
            dataset_size=dataset_size,
            training_hours=training_hours,
            priority=priority,
            config=config.__dict__,
            total_epochs=config.max_epochs,
            progress=0.0
        )
        job = PersonalizationTrainingJob(
            session_id=session_id,
            user_id=user_id,
            status="queued",
            priority=_PRIORITY_MAP.get(priority, 2),
            attempts=0,
            max_attempts=3
        )
        db.add(session)
        db.add(job)
        db.commit()
        db.refresh(session)
        return session

    def cancel_session(self, db: Session, session_id: str) -> bool:
        session = db.query(PersonalizationTrainingSession).filter(
            PersonalizationTrainingSession.id == session_id
        ).first()
        job = db.query(PersonalizationTrainingJob).filter(
            PersonalizationTrainingJob.session_id == session_id
        ).first()
        if not session:
            return False

        session.status = "cancelled"
        session.completed_at = session.completed_at or datetime.utcnow()
        session.updated_at = datetime.utcnow()
        if job and job.status not in _DONE_STATUSES:
            job.status = "cancelled"
            job.completed_at = job.completed_at or datetime.utcnow()
            job.last_error = "Cancelled by user"
            job.updated_at = datetime.utcnow()
        db.commit()
        self.personalization_service.cancel_training_session(session_id)
        return True


_queue_instance: Optional[PersonalizationTrainingQueue] = None


def get_personalization_training_queue() -> PersonalizationTrainingQueue:
    global _queue_instance
    if _queue_instance is None:
        _queue_instance = PersonalizationTrainingQueue()
        _queue_instance.start_worker()
    return _queue_instance
