"""
Backward-compatible config module for coordinator services.
"""

from .coordinator_config import CoordinatorConfig, Config, config, get_config, load_config_from_env

__all__ = [
    "CoordinatorConfig",
    "Config",
    "config",
    "get_config",
    "load_config_from_env",
]
