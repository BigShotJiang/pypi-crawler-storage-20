"""
API endpoints for federated learning statistics and overview.
"""

import os
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from ...database.connection import get_db
from ...models.schemas import APIResponse
from ...models.base import Node, FederatedSession
from ...services.session_service import SessionService
from ...services.round_service import RoundService
from ...services.node_service import NodeService
from ...auth.dependencies import conditional_user_auth, conditional_node_auth
from ...config.settings import settings

router = APIRouter()
node_service = NodeService()


def _normalize_dt(timestamp: Optional[datetime]) -> Optional[datetime]:
    if not timestamp:
        return None
    tzinfo = timestamp.tzinfo
    if tzinfo is None:
        return timestamp
    try:
        if tzinfo.utcoffset(timestamp) is None:
            return timestamp
    except Exception:
        return timestamp
    return timestamp.astimezone(timezone.utc).replace(tzinfo=None)


def _seconds_since(timestamp: Optional[datetime]) -> Optional[float]:
    normalized = _normalize_dt(timestamp)
    if not normalized:
        return None
    return (datetime.utcnow() - normalized).total_seconds()


class FederatedNodeRegisterRequest(BaseModel):
    """Request model for federated node registration."""
    node_id: str = Field(..., description="Node identifier")
    public_key: Optional[str] = Field(None, description="Node public key")
    capabilities: Optional[Dict[str, Any]] = Field(None, description="Hardware capabilities")
    hardware_info: Optional[Dict[str, Any]] = Field(None, description="Hardware details")
    hardware_specs: Optional[Dict[str, Any]] = Field(None, description="Explicit hardware specs payload")
    location: Optional[Dict[str, Any]] = Field(None, description="Location metadata")
    ip_address: Optional[str] = Field(None, description="Node IP address")
    p2p_host: Optional[str] = Field(None, description="P2P host")
    p2p_port: Optional[int] = Field(None, description="P2P port")
    status: Optional[str] = Field(None, description="Initial status override")


class FederatedNodeHeartbeatRequest(BaseModel):
    """Request model for federated node heartbeat."""
    node_id: str = Field(..., description="Node identifier")
    status: Optional[Any] = Field(None, description="Node status payload")
    capabilities: Optional[Dict[str, Any]] = Field(None, description="Hardware capabilities")
    hardware_info: Optional[Dict[str, Any]] = Field(None, description="Hardware details")
    hardware_specs: Optional[Dict[str, Any]] = Field(None, description="Explicit hardware specs payload")
    location: Optional[Dict[str, Any]] = Field(None, description="Location metadata")
    ip_address: Optional[str] = Field(None, description="Node IP address")
    metrics: Optional[Dict[str, Any]] = Field(None, description="Performance metrics")


@router.get("/stats")
async def get_federated_stats(
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Get federated learning network statistics."""
    try:
        total_nodes = db.query(Node).count()
        active_nodes = await node_service.get_active_nodes_count(db)
        total_sessions = db.query(FederatedSession).count()
        active_sessions = await SessionService.get_active_sessions_count(db)

        stats = {
            "total_nodes": total_nodes,
            "active_nodes": active_nodes,
            "total_sessions": total_sessions,
            "active_sessions": active_sessions,
            "total_rounds_completed": 0,
            "active_rounds": 0,
            "total_dracma_distributed": 0.0,
            "network_accuracy": 0.0,
            "network_health": "healthy" if active_nodes > 0 else "idle",
            "last_updated": datetime.utcnow().isoformat()
        }

        return stats
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving federated stats: {str(e)}")


@router.get("/health")
async def get_federated_health(
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Get federated learning network health status."""
    try:
        total_nodes = db.query(Node).count()
        active_nodes = await node_service.get_active_nodes_count(db)
        active_sessions = await SessionService.get_active_sessions_count(db)

        status = "healthy" if active_nodes > 0 else "idle"
        if total_nodes > 0 and active_nodes == 0:
            status = "degraded"

        health_data = {
            "status": status,
            "database_connection": "connected",
            "active_nodes": active_nodes,
            "active_sessions": active_sessions,
            "registered_nodes": total_nodes,
            "network_latency_ms": 0,
            "last_health_check": datetime.utcnow().isoformat()
        }

        return health_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving federated health: {str(e)}")


@router.get("/nodes/")
async def get_nodes_overview(
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Get node list and summary stats for the federated nodes page."""
    try:
        nodes = db.query(Node).all()
        timeout_seconds = settings.node_timeout_seconds

        def _extract(specs: Dict[str, Any], key: str, default: Any = 0) -> Any:
            if not isinstance(specs, dict):
                return default
            if key in specs:
                return specs.get(key, default)
            caps = specs.get("capabilities") if isinstance(specs.get("capabilities"), dict) else {}
            if key in caps:
                return caps.get(key, default)
            return default

        node_payloads: List[Dict[str, Any]] = []
        active_nodes = 0
        for node in nodes:
            last_seen = node.last_heartbeat
            seconds_since = _seconds_since(last_seen)
            is_active = seconds_since is not None and seconds_since <= timeout_seconds
            status = "active" if is_active else "offline"
            active_nodes += 1 if is_active else 0

            specs = node.hardware_specs or {}
            location = node.location or {}

            node_payloads.append({
                "id": node.id,
                "name": node.id,
                "location": location.get("region") or location.get("country") or "unknown",
                "status": status,
                "uptime": 0,
                "lastSeen": last_seen.isoformat() if last_seen else None,
                "version": specs.get("version", "unknown") if isinstance(specs, dict) else "unknown",
                "resources": {
                    "cpu": _extract(specs, "cpu_cores", 0),
                    "memory": _extract(specs, "memory_gb", 0),
                    "storage": _extract(specs, "storage_gb", 0),
                    "gpu": _extract(specs, "gpu_count", 0)
                },
                "health": {
                    "score": 100 if is_active else 0,
                    "issues": [] if is_active else ["stale_heartbeat"]
                },
                "metrics": specs.get("metrics", {}) if isinstance(specs, dict) else {},
                "region": location.get("region", "unknown"),
                "ip": location.get("ip_address"),
                "port": (specs.get("p2p", {}) or {}).get("port") if isinstance(specs, dict) else None
            })

        stats = {
            "totalNodes": len(nodes),
            "activeNodes": active_nodes,
            "inactiveNodes": len(nodes) - active_nodes,
            "maintenanceNodes": 0,
            "avgUptime": 0,
            "avgResponseTime": 0,
            "networkHealth": 100 if active_nodes > 0 else 0,
            "totalCapacity": {
                "cpu": sum(n["resources"]["cpu"] for n in node_payloads),
                "memory": sum(n["resources"]["memory"] for n in node_payloads),
                "storage": sum(n["resources"]["storage"] for n in node_payloads)
            },
            "geographicDistribution": []
        }

        return {"nodes": node_payloads, "stats": stats}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving node status: {str(e)}")


@router.get("/nodes/status")
async def get_nodes_status(
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Get node status summary for dashboards."""
    try:
        nodes = db.query(Node).all()
        timeout_seconds = settings.node_timeout_seconds

        def _extract(specs: Dict[str, Any], key: str, default: Any = 0) -> Any:
            if not isinstance(specs, dict):
                return default
            if key in specs:
                return specs.get(key, default)
            caps = specs.get("capabilities") if isinstance(specs.get("capabilities"), dict) else {}
            if key in caps:
                return caps.get(key, default)
            return default

        node_payloads: List[Dict[str, Any]] = []
        active_nodes = 0
        for node in nodes:
            last_seen = node.last_heartbeat
            seconds_since = _seconds_since(last_seen)
            is_active = seconds_since is not None and seconds_since <= timeout_seconds
            status = "active" if is_active else "offline"
            active_nodes += 1 if is_active else 0

            specs = node.hardware_specs or {}
            location = node.location or {}

            node_payloads.append({
                "id": node.id,
                "name": node.id,
                "location": location.get("region") or location.get("country") or "unknown",
                "status": status,
                "uptime": 0,
                "lastSeen": last_seen.isoformat() if last_seen else None,
                "version": specs.get("version", "unknown") if isinstance(specs, dict) else "unknown",
                "resources": {
                    "cpu": _extract(specs, "cpu_cores", 0),
                    "memory": _extract(specs, "memory_gb", 0),
                    "storage": _extract(specs, "storage_gb", 0),
                    "gpu": _extract(specs, "gpu_count", 0)
                },
                "health": {
                    "score": 100 if is_active else 0,
                    "issues": [] if is_active else ["stale_heartbeat"]
                },
                "metrics": specs.get("metrics", {}) if isinstance(specs, dict) else {},
                "region": location.get("region", "unknown"),
                "ip": location.get("ip_address"),
                "port": (specs.get("p2p", {}) or {}).get("port") if isinstance(specs, dict) else None
            })

        stats = {
            "totalNodes": len(nodes),
            "activeNodes": active_nodes,
            "inactiveNodes": len(nodes) - active_nodes,
            "maintenanceNodes": 0,
            "avgUptime": 0,
            "avgResponseTime": 0,
            "networkHealth": 100 if active_nodes > 0 else 0,
            "totalCapacity": {
                "cpu": sum(n["resources"]["cpu"] for n in node_payloads),
                "memory": sum(n["resources"]["memory"] for n in node_payloads),
                "storage": sum(n["resources"]["storage"] for n in node_payloads)
            },
            "geographicDistribution": []
        }

        return {"nodes": node_payloads, "stats": stats}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving nodes status: {str(e)}")


@router.get("/nodes/status/{node_id}")
async def get_node_status_by_id(
    node_id: str,
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Get health status for a specific node."""
    try:
        node = db.query(Node).filter(Node.id == node_id).first()
        if not node:
            raise HTTPException(status_code=404, detail="Node not found")

        timeout_seconds = settings.node_timeout_seconds
        last_seen = node.last_heartbeat
        seconds_since = _seconds_since(last_seen)
        health_status = "healthy" if seconds_since is not None and seconds_since <= timeout_seconds else "unhealthy"

        return {
            "node_id": node.id,
            "status": node.status,
            "health_status": health_status,
            "last_heartbeat": last_seen.isoformat() if last_seen else None,
            "seconds_since_heartbeat": seconds_since,
            "timeout_seconds": timeout_seconds
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving node status: {str(e)}")


@router.get("/sessions")
async def get_sessions_api_v1(db: Session = Depends(get_db), current_user: Optional[dict] = Depends(conditional_user_auth)):
    """Get sessions for API v1 compatibility."""
    try:
        # Mock data for now - in real implementation, query database
        sessions = [
            {
                "id": "session_001",
                "name": "Test Session 1",
                "description": "Federated learning session for testing",
                "model_type": "transformer",
                "status": "active",
                "current_round": 3,
                "total_rounds": 10,
                "min_nodes": 5,
                "max_nodes": 20,
                "active_participants": 8,
                "created_at": "2024-01-15T10:00:00Z",
                "started_at": "2024-01-15T10:30:00Z"
            },
            {
                "id": "session_002",
                "name": "Production Session",
                "description": "Production federated learning session",
                "model_type": "cnn",
                "status": "completed",
                "current_round": 10,
                "total_rounds": 10,
                "min_nodes": 10,
                "max_nodes": 50,
                "active_participants": 25,
                "created_at": "2024-01-10T09:00:00Z",
                "started_at": "2024-01-10T09:15:00Z",
                "completed_at": "2024-01-12T14:30:00Z"
            }
        ]

        return {"sessions": sessions}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving sessions: {str(e)}")


@router.get("/rounds/active")
async def get_active_rounds_api_v1(db: Session = Depends(get_db), current_user: Optional[dict] = Depends(conditional_user_auth)):
    """Get active rounds for API v1 compatibility."""
    try:
        # Mock data for now - in real implementation, query database
        rounds = [
            {
                "id": "round_001",
                "session_id": "session_001",
                "round_number": 3,
                "status": "active",
                "progress_percentage": 65,
                "active_participants": 8,
                "total_participants": 10,
                "estimated_completion": "2024-01-15T12:00:00Z",
                "started_at": "2024-01-15T11:00:00Z",
                "metrics": {
                    "loss": 0.234,
                    "accuracy": 0.89,
                    "f1_score": 0.87,
                    "throughput": 150.5
                },
                "participants": [
                    {
                        "id": "part_001",
                        "node_id": "node_001",
                        "status": "active",
                        "contributions_count": 45,
                        "rewards_earned": 12.5,
                        "last_activity": "2024-01-15T11:30:00Z",
                        "performance_metrics": {
                            "local_loss": 0.198,
                            "local_accuracy": 0.91,
                            "computation_time": 45.2
                        }
                    }
                ]
            }
        ]

        return {"rounds": rounds}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving active rounds: {str(e)}")


@router.get("/metrics/realtime/snapshot")
async def get_metrics_realtime_snapshot_api_v1(db: Session = Depends(get_db), current_user: Optional[dict] = Depends(conditional_user_auth)):
    """Get real-time metrics snapshot for API v1 compatibility."""
    try:
        # Mock data for now - in real implementation, query database
        metrics = {
            "timestamp": "2024-01-15T11:45:00Z",
            "active_sessions": 3,
            "total_nodes": 42,
            "active_nodes": 28,
            "network_latency_ms": 45,
            "federation_efficiency": 0.87,
            "total_dracma_distributed": 12500.50,
            "system_load": 0.65
        }

        return metrics
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving metrics snapshot: {str(e)}")


@router.post("/nodes/register", response_model=APIResponse, status_code=201)
async def register_node(
    request: FederatedNodeRegisterRequest,
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Register a new federated node."""
    try:
        hardware_specs = request.hardware_specs or request.hardware_info or request.capabilities
        if request.p2p_host or request.p2p_port:
            hardware_specs = hardware_specs or {}
            hardware_specs = {**hardware_specs, "p2p": {"host": request.p2p_host, "port": request.p2p_port}}

        location = request.location or {}
        if request.ip_address:
            location = {**location, "ip_address": request.ip_address}

        auto_verify = os.getenv(
            "AUTO_VERIFY_NODES",
            "1" if settings.environment != "production" else "0"
        ) == "1"

        node = await node_service.register_node(
            db=db,
            node_data={
                "id": request.node_id,
                "public_key": request.public_key,
                "status": request.status,
                "hardware_specs": hardware_specs,
                "location": location or None
            },
            auto_verify=auto_verify
        )

        return APIResponse(
            data=node,
            message="Node registered successfully"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error registering node: {str(e)}")


@router.post("/nodes/heartbeat", response_model=APIResponse)
async def node_heartbeat(
    request: FederatedNodeHeartbeatRequest,
    db: Session = Depends(get_db),
    current_node: Optional[dict] = Depends(conditional_node_auth),
    current_user: Optional[dict] = Depends(conditional_user_auth)
):
    """Update heartbeat for a federated node."""
    try:
        if current_node and current_node.get("node_id") != request.node_id:
            raise HTTPException(status_code=403, detail="Can only update own heartbeat")

        status_value = None
        if isinstance(request.status, str):
            status_value = request.status
        elif isinstance(request.status, dict):
            if request.status.get("is_training"):
                status_value = "training"
            elif request.status.get("is_online") is False:
                status_value = "offline"
            else:
                status_value = "active"

        hardware_specs = request.hardware_specs or request.hardware_info or request.capabilities
        if request.metrics:
            hardware_specs = hardware_specs or {}
            hardware_specs = {**hardware_specs, "metrics": request.metrics}

        location = request.location or {}
        if request.ip_address:
            location = {**location, "ip_address": request.ip_address}

        await node_service.update_heartbeat(
            db=db,
            node_id=request.node_id,
            status=status_value,
            hardware_specs=hardware_specs,
            location=location or None
        )

        return APIResponse(message="Heartbeat updated successfully")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating heartbeat: {str(e)}")


@router.post("/nodes/{node_id}/disconnect")
async def disconnect_node(node_id: str, db: Session = Depends(get_db), current_user: Optional[dict] = Depends(conditional_user_auth)):
    """Disconnect a federated node."""
    try:
        # Mock implementation - in real implementation, update database
        result = {
            "node_id": node_id,
            "status": "disconnected",
            "disconnected_at": "2024-01-15T10:30:00Z",
            "message": "Node disconnected successfully"
        }

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error disconnecting node: {str(e)}")


@router.post("/privacy/settings")
async def save_privacy_settings(settings: Dict[str, Any], db: Session = Depends(get_db), current_user: Optional[dict] = Depends(conditional_user_auth)):
    """Save federated privacy settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "settings_saved": True,
            "timestamp": "2024-01-15T10:30:00Z",
            "message": "Privacy settings saved successfully"
        }

        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving privacy settings: {str(e)}")
