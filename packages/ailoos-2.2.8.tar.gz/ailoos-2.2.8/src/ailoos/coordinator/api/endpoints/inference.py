"""
EmpoorioLM Inference API endpoints.
Provides text generation endpoints with JWT authentication.
"""

import time
import os
import asyncio
import json
import base64
import hashlib
import hmac
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, AsyncGenerator
from concurrent.futures import ThreadPoolExecutor
import logging

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization

from transformers import AutoTokenizer
import torch
import torch.nn.functional as F

from ....models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
from ....models.empoorio_lm.tokenizer import EmpoorioBPETokenizer, EmpoorioTokenizerConfig
from ...models.schemas import InferenceRequest, InferenceResponse, ModelInfo, StatusResponse
from ...auth.jwt import get_current_token_data, require_permissions
from ...database.connection import get_db
from ...config.settings import settings
from ...empoorio_lm.service import EmpoorioLMService, create_empoorio_lm_service
from .models import (
    FederatedQueryRequest, FederatedBatchQueryRequest, FederatedQueryResponse,
    FederatedBatchQueryResponse, InferenceStatusResponse, ModelDeploymentRequest,
    ModelUndeploymentRequest, ModelDeploymentStatus, WalletAuthRequest,
    EncryptedRequest, EncryptedResponse
)
from ....marketplace.registry.model_registry import get_model_registry
from ....inference.api import EmpoorioLMInferenceAPI, InferenceConfig
from ....inference.model_registry import ModelRegistry
from ....inference.sentencepiece_tokenizer import SentencePieceTokenizerWrapper

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()

# Global inference service instance
inference_service = None

# EmpoorioLM service instance
empoorio_lm_service: EmpoorioLMService = None

# Federated Inference Coordinator (using EmpoorioLM Inference API)
federated_inference_coordinator: EmpoorioLMInferenceAPI = None

# Model Registry instance
model_registry = None

# Encryption key for basic encryption (in production, use proper key management)
ENCRYPTION_KEY = Fernet.generate_key()
cipher = Fernet(ENCRYPTION_KEY)


def _env_enabled(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.lower() in ("1", "true", "yes", "on")


async def _authenticate_wallet(signature: str, model_id: str) -> bool:
    """
    Authenticate wallet signature for model access.

    Args:
        signature: Wallet signature
        model_id: Model being accessed

    Returns:
        True if authenticated
    """
    try:
        if not signature:
            raise HTTPException(status_code=401, detail="Invalid wallet signature")

        shared_secret = os.getenv("AILOOS_WALLET_HMAC_SECRET")
        if not shared_secret:
            raise HTTPException(status_code=500, detail="Wallet auth secret not configured")

        expected = hmac.new(
            shared_secret.encode("utf-8"),
            model_id.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(signature, expected):
            raise HTTPException(status_code=401, detail="Invalid wallet signature")

        return True
    except Exception as e:
        logger.error(f"Wallet authentication error: {e}")
        raise HTTPException(status_code=401, detail="Wallet authentication failed")


async def _encrypt_response(data: str) -> str:
    """
    Encrypt response data.

    Args:
        data: Data to encrypt

    Returns:
        Base64 encoded encrypted data
    """
    try:
        encrypted = cipher.encrypt(data.encode())
        return base64.b64encode(encrypted).decode()
    except Exception as e:
        logger.error(f"Encryption error: {e}")
        raise HTTPException(status_code=500, detail="Encryption failed")


async def _decrypt_request(data: str) -> str:
    """
    Decrypt request data.

    Args:
        data: Base64 encoded encrypted data

    Returns:
        Decrypted data
    """
    try:
        encrypted = base64.b64decode(data)
        decrypted = cipher.decrypt(encrypted)
        return decrypted.decode()
    except Exception as e:
        logger.error(f"Decryption error: {e}")
        raise HTTPException(status_code=400, detail="Decryption failed")


class EmpoorioLMInferenceService:
    """
    Inference service for EmpoorioLM with JWT authentication.
    """

    def __init__(self):
        self.model: EmpoorioLM = None
        self.tokenizer = None
        self.is_loaded = False
        self.device = self._get_device()
        self.executor = ThreadPoolExecutor(max_workers=4)
        self.metrics = {
            "total_requests": 0,
            "total_tokens_generated": 0,
            "avg_response_time": 0.0,
            "error_rate": 0.0
        }

        logger.info(f"🚀 EmpoorioLM Inference Service initialized - Device: {self.device}")

    def _get_device(self) -> torch.device:
        """Determine the optimal device."""
        force_cpu = os.getenv("AILOOS_FORCE_CPU", "false").lower() in ("1", "true", "yes")
        if force_cpu:
            return torch.device("cpu")

        requested = os.getenv("AILOOS_DEVICE") or os.getenv("INFERENCE_DEVICE")
        if requested:
            requested = requested.lower()
            if requested == "cpu":
                return torch.device("cpu")
            if requested == "cuda":
                if torch.cuda.is_available():
                    return torch.device("cuda")
                logger.warning("Requested CUDA but it's not available, falling back to auto.")
            if requested == "mps":
                if torch.backends.mps.is_available():
                    try:
                        torch.zeros(1, device="mps")
                        return torch.device("mps")
                    except Exception as exc:
                        logger.warning(f"MPS unavailable, falling back to CPU: {exc}")
                        return torch.device("cpu")
                logger.warning("Requested MPS but it's not available, falling back to auto.")

        if torch.cuda.is_available():
            return torch.device("cuda")
        elif torch.backends.mps.is_available():
            try:
                torch.zeros(1, device="mps")
                return torch.device("mps")
            except Exception as exc:
                logger.warning(f"MPS unavailable, falling back to CPU: {exc}")
                return torch.device("cpu")
        else:
            return torch.device("cpu")

    async def _resolve_model_path(self) -> Path:
        """Resolve model path from config or registry."""
        configured = settings.inference.model_path or "./models/empoorio_lm/v1.0.0"
        candidate = Path(configured)
        if candidate.exists():
            return candidate

        registry_path = os.getenv("AILOOS_MODEL_REGISTRY_PATH", "data/model_registry")
        registry = ModelRegistry(registry_path)
        await registry.load_registry()

        model = None
        model_id = os.getenv("AILOOS_ACTIVE_MODEL_ID")
        model_name = os.getenv("AILOOS_ACTIVE_MODEL_NAME")
        if model_id:
            model = await registry.get_model(model_id)
        if not model and model_name:
            model = await registry.get_model_by_name(model_name)
        if not model:
            models = await registry.list_models()
            if models:
                model = models[0]

        if not model:
            raise FileNotFoundError("No model available in registry")

        version = await registry.get_active_version(model.model_id)
        if not version:
            versions = await registry.get_model_versions(model.model_id)
            if versions:
                version = versions[-1]

        if not version:
            raise FileNotFoundError("No model version available in registry")

        file_path = Path(version.file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Model file not found at {file_path}")

        return file_path.parent

    def _load_tokenizer(self, model_path: Path):
        """Load tokenizer from local resources only."""
        require_tokenizer = _env_enabled("AILOOS_REQUIRE_TOKENIZER", default=False)

        tokenizer_dir = os.getenv("EMPOORIO_TOKENIZER_PATH") or os.getenv("AILOOS_TOKENIZER_PATH")
        if tokenizer_dir:
            return EmpoorioBPETokenizer.load(tokenizer_dir)

        tokenizer_model_path = os.getenv("INFERENCE_TOKENIZER_PATH") or os.getenv("AILOOS_TOKENIZER_MODEL_PATH")
        if tokenizer_model_path:
            model_path_obj = Path(tokenizer_model_path)
            if not model_path_obj.exists():
                raise FileNotFoundError(f"Tokenizer not found at {model_path_obj}")
            if model_path_obj.suffix == ".model":
                return SentencePieceTokenizerWrapper(str(model_path_obj))
            return AutoTokenizer.from_pretrained(str(model_path_obj), local_files_only=True, use_fast=False)

        if (model_path / "tokenizer_config.json").exists():
            return EmpoorioBPETokenizer.load(model_path)

        default_path = Path("data/tokenizer/empoorio_bpe")
        if default_path.exists():
            return EmpoorioBPETokenizer.load(default_path)

        tokenizer_name = settings.inference.tokenizer_name
        if tokenizer_name:
            name_path = Path(tokenizer_name)
            if name_path.exists():
                return AutoTokenizer.from_pretrained(str(name_path), local_files_only=True, use_fast=False)
            logger.warning(
                f"Tokenizer {tokenizer_name} not available locally; falling back to byte-level tokenizer"
            )

        if require_tokenizer:
            raise FileNotFoundError("Tokenizer required but not found. Set EMPOORIO_TOKENIZER_PATH.")

        logger.warning("No tokenizer configured; using minimal byte-level tokenizer")
        return EmpoorioBPETokenizer(EmpoorioTokenizerConfig())

    async def load_model(self) -> bool:
        """Load the EmpoorioLM model and tokenizer."""
        try:
            logger.info("📥 Loading EmpoorioLM model...")

            # Load model
            model_path = await self._resolve_model_path()
            config_path = model_path / "config.json"
            config = EmpoorioLMConfig.load_config(str(config_path)) if config_path.exists() else EmpoorioLMConfig()
            config.device = self.device
            self.model = EmpoorioLM.from_pretrained(model_path, config=config)

            # Load tokenizer
            self.tokenizer = self._load_tokenizer(model_path)

            # Configure pad token
            if getattr(self.tokenizer, "pad_token", None) is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            if getattr(self.tokenizer, "pad_token_id", None) is None and getattr(self.tokenizer, "eos_token_id", None) is not None:
                self.tokenizer.pad_token_id = self.tokenizer.eos_token_id

            model_vocab = getattr(self.model.config, "vocab_size", None)
            tokenizer_vocab = None
            if hasattr(self.tokenizer, "get_vocab_size"):
                tokenizer_vocab = self.tokenizer.get_vocab_size()
            elif hasattr(self.tokenizer, "vocab_size"):
                tokenizer_vocab = self.tokenizer.vocab_size
            if model_vocab and tokenizer_vocab and tokenizer_vocab != model_vocab:
                if _env_enabled("AILOOS_STRICT_TOKENIZER_MATCH", default=False):
                    raise ValueError(
                        f"Tokenizer vocab size {tokenizer_vocab} does not match model vocab size {model_vocab}"
                    )
                logger.warning(
                    f"Tokenizer vocab size {tokenizer_vocab} != model vocab size {model_vocab}"
                )

            # Move model to device
            try:
                self.model.to(self.device)
            except Exception as exc:
                if self.device.type == "mps":
                    logger.warning(f"MPS failed, falling back to CPU: {exc}")
                    self.device = torch.device("cpu")
                    self.model.to(self.device)
                else:
                    raise
            self.model.eval()

            # Disable gradients
            for param in self.model.parameters():
                param.requires_grad = False

            self.is_loaded = True
            logger.info("✅ EmpoorioLM model loaded successfully")
            return True

        except Exception as e:
            logger.error(f"❌ Error loading model: {e}")
            return False

    async def generate(
        self,
        request: InferenceRequest
    ) -> InferenceResponse:
        """Generate text with EmpoorioLM."""
        if not self.is_loaded:
            raise HTTPException(status_code=503, detail="Model not loaded")

        start_time = time.time()

        try:
            # Prepare generation parameters
            max_new_tokens = request.max_tokens or 512
            gen_kwargs = {
                "temperature": request.temperature or 0.7,
                "top_p": request.top_p or 0.9,
                "top_k": request.top_k or 50,
                "do_sample": True,
                "pad_token_id": self.tokenizer.pad_token_id,
                "eos_token_id": self.tokenizer.eos_token_id,
            }

            # Generate in thread pool
            loop = asyncio.get_event_loop()
            generated_tokens = await loop.run_in_executor(
                self.executor,
                self._generate_sync,
                request.prompt,
                gen_kwargs,
                max_new_tokens
            )

            # Decode tokens
            generated_text = self._decode_tokens(generated_tokens)

            # Calculate usage
            response_time = time.time() - start_time
            prompt_tokens = len(self.tokenizer.encode(request.prompt, add_special_tokens=True))
            completion_tokens = len(self.tokenizer.encode(generated_text, add_special_tokens=False))

            usage = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens,
                "response_time_seconds": response_time
            }

            # Update metrics
            self._update_metrics(usage, response_time)

            response = InferenceResponse(
                text=generated_text,
                usage=usage,
                model_version=getattr(self.model.config, "version", "unknown"),
                generated_at=time.time()
            )

            return response

        except Exception as e:
            logger.error(f"❌ Generation error: {e}")
            self.metrics["error_rate"] = (self.metrics["error_rate"] * self.metrics["total_requests"] + 1) / (self.metrics["total_requests"] + 1)
            raise HTTPException(status_code=500, detail=f"Inference error: {str(e)}")

    def _generate_sync(self, prompt: str, gen_kwargs: Dict[str, Any], max_new_tokens: int) -> torch.Tensor:
        """Synchronous generation."""
        inputs = self.tokenizer(prompt, return_tensors="pt", padding=True, truncation=True)
        input_ids = inputs["input_ids"].to(self.device)

        with torch.no_grad():
            local_kwargs = dict(gen_kwargs)
            local_kwargs["max_length"] = input_ids.shape[-1] + max_new_tokens
            output = self.model.generate(input_ids, **local_kwargs)

        return output

    def _decode_tokens(self, tokens: torch.Tensor) -> str:
        """Decode tokens to text."""
        return self.tokenizer.decode(tokens[0], skip_special_tokens=True)

    def _update_metrics(self, usage: Dict[str, Any], response_time: float):
        """Update service metrics."""
        self.metrics["total_requests"] += 1
        self.metrics["total_tokens_generated"] += usage["completion_tokens"]

        # Update average response time
        prev_avg = self.metrics["avg_response_time"]
        self.metrics["avg_response_time"] = (prev_avg * (self.metrics["total_requests"] - 1) + response_time) / self.metrics["total_requests"]

    async def generate_stream(
        self,
        request: InferenceRequest
    ) -> AsyncGenerator[str, None]:
        """Generate text in streaming mode."""
        if not self.is_loaded:
            yield f"data: {json.dumps({'error': 'Model not loaded'})}\n\n"
            return

        try:
            # Tokenize prompt
            inputs = self.tokenizer(request.prompt, return_tensors="pt", padding=True, truncation=True)
            input_ids = inputs["input_ids"].to(self.device)

            # Prepare generation parameters
            gen_kwargs = {
                "max_new_tokens": request.max_tokens or 512,
                "temperature": request.temperature or 0.7,
                "top_p": request.top_p or 0.9,
                "top_k": request.top_k or 50,
                "do_sample": True,
                "pad_token_id": self.tokenizer.pad_token_id,
                "eos_token_id": self.tokenizer.eos_token_id,
            }

            generated_tokens = input_ids.clone()
            generated_text = ""

            with torch.no_grad():
                for _ in range(gen_kwargs["max_new_tokens"]):
                    # Get logits for last token
                    outputs = self.model(generated_tokens)
                    next_token_logits = outputs["logits"][:, -1, :]

                    # Apply temperature
                    if gen_kwargs["temperature"] != 1.0:
                        next_token_logits = next_token_logits / gen_kwargs["temperature"]

                    # Apply top-k
                    if gen_kwargs["top_k"] > 0:
                        top_k_logits, _ = torch.topk(next_token_logits, gen_kwargs["top_k"], dim=-1)
                        next_token_logits = torch.where(
                            next_token_logits < top_k_logits[:, -1:].expand_as(next_token_logits),
                            torch.full_like(next_token_logits, float('-inf')),
                            next_token_logits
                        )

                    # Apply top-p
                    if gen_kwargs["top_p"] < 1.0:
                        sorted_logits, sorted_indices = torch.sort(next_token_logits, descending=True)
                        cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)

                        sorted_logits = torch.where(
                            cumulative_probs > gen_kwargs["top_p"],
                            torch.full_like(sorted_logits, float('-inf')),
                            sorted_logits
                        )

                        next_token_logits = torch.gather(
                            sorted_logits,
                            dim=-1,
                            index=torch.argsort(sorted_indices, dim=-1)
                        )

                    # Sample next token
                    next_token = torch.multinomial(F.softmax(next_token_logits, dim=-1), num_samples=1)

                    # Append to sequence
                    generated_tokens = torch.cat([generated_tokens, next_token], dim=-1)

                    # Decode new token
                    new_token_text = self.tokenizer.decode(next_token[0], skip_special_tokens=True)
                    generated_text += new_token_text

                    # Yield chunk
                    chunk_data = {
                        "token": new_token_text,
                        "text_so_far": generated_text,
                        "finished": False
                    }
                    yield f"data: {json.dumps(chunk_data)}\n\n"

                    # Check for EOS
                    if next_token.item() == gen_kwargs["eos_token_id"]:
                        break

            # Final chunk
            final_data = {
                "token": "",
                "text_so_far": generated_text,
                "finished": True
            }
            yield f"data: {json.dumps(final_data)}\n\n"

        except Exception as e:
            error_data = {
                "error": f"Streaming error: {str(e)}",
                "finished": True
            }
            yield f"data: {json.dumps(error_data)}\n\n"

    def get_status(self) -> Dict[str, Any]:
        """Get service status."""
        return {
            "status": "healthy" if self.is_loaded else "unhealthy",
            "model_loaded": self.is_loaded,
            "device": str(self.device),
            "model_info": self.model.get_model_info() if self.is_loaded else None,
            "metrics": self.metrics,
            "config": {
                "model_path": settings.inference.model_path,
                "tokenizer_name": settings.inference.tokenizer_name,
                "max_batch_size": settings.inference.max_batch_size,
                "max_concurrent_requests": settings.inference.max_concurrent_requests,
                "timeout": settings.inference.request_timeout_seconds
            }
        }


# Initialize global service
inference_service = EmpoorioLMInferenceService()


@router.on_event("startup")
async def startup_event():
    """Load model on startup."""
    global inference_service, empoorio_lm_service, federated_inference_coordinator, model_registry

    # Initialize legacy inference service
    inference_service = EmpoorioLMInferenceService()

    # Initialize new EmpoorioLM service
    if _env_enabled("AILOOS_ENABLE_EMPOORIO_SERVICE", default=False):
        empoorio_lm_service = create_empoorio_lm_service()
        await empoorio_lm_service.initialize()
        await empoorio_lm_service.start()
    else:
        empoorio_lm_service = None
        logger.info("EmpoorioLM service disabled (set AILOOS_ENABLE_EMPOORIO_SERVICE=true to enable)")

    # Initialize Federated Inference Coordinator
    if _env_enabled("AILOOS_ENABLE_FEDERATED_INFERENCE", default=False):
        inference_config = InferenceConfig()
        federated_inference_coordinator = EmpoorioLMInferenceAPI(inference_config)
    else:
        federated_inference_coordinator = None
        logger.info("Federated inference disabled (set AILOOS_ENABLE_FEDERATED_INFERENCE=true to enable)")

    # Initialize Model Registry
    model_registry = get_model_registry()
    await model_registry.initialize()

    # Load legacy model
    success = await inference_service.load_model()
    if not success:
        logger.error("❌ Failed to load EmpoorioLM model on startup")

    # Load federated coordinator model
    if federated_inference_coordinator:
        federated_success = await federated_inference_coordinator.load_model()
        if not federated_success:
            logger.warning("⚠️ Failed to load federated inference coordinator model")


@router.post("/generate", response_model=InferenceResponse)
async def generate_text(
    request: InferenceRequest,
    background_tasks: BackgroundTasks,
    # token_data = Depends(require_permissions(["inference:generate"]))  # Temporarily disabled for chat
):
    """
    Generate text using EmpoorioLM.

    Requires inference:generate permission.
    """
    try:
        if request.stream:
            # For streaming, redirect to stream endpoint
            raise HTTPException(
                status_code=400,
                detail="Use POST /inference/generate/stream for streaming responses"
            )

        response = await inference_service.generate(request)
        return response

    except Exception as e:
        logger.error(f"Generate endpoint error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/stream")
async def generate_text_stream(
    request: InferenceRequest,
    # token_data = Depends(require_permissions(["inference:generate"]))  # Temporarily disabled for chat
):
    """
    Generate text using EmpoorioLM with streaming response.

    Requires inference:generate permission.
    """
    try:
        return StreamingResponse(
            inference_service.generate_stream(request),
            media_type="text/plain",
            headers={"Cache-Control": "no-cache"}
        )

    except Exception as e:
        logger.error(f"Stream endpoint error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/models", response_model=List[ModelInfo])
async def list_models(
    # token_data = Depends(require_permissions(["inference:read"]))  # Temporarily disabled for chat
):
    """
    List available models.

    Requires inference:read permission.
    """
    try:
        models = [{
            "id": "empoorio_lm_v1.0",
            "object": "model",
            "created": int(time.time()),
            "owned_by": "ailoos"
        }]
        return models

    except Exception as e:
        logger.error(f"Models endpoint error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status", response_model=StatusResponse)
async def get_status(
    # token_data = Depends(require_permissions(["inference:read"]))  # Temporarily disabled for chat
):
    """
    Get inference service status.

    Requires inference:read permission.
    """
    try:
        # Get legacy status
        legacy_status = inference_service.get_status()

        # Get new EmpoorioLM service status
        if empoorio_lm_service:
            empoorio_status = empoorio_lm_service.get_service_status()
        else:
            empoorio_status = {"enabled": False, "status": "disabled"}

        # Combine statuses
        empoorio_running = bool(empoorio_status.get("is_running")) if empoorio_lm_service else True
        combined_status = {
            "status": "healthy" if legacy_status["status"] == "healthy" and empoorio_running else "degraded",
            "legacy_service": legacy_status,
            "empoorio_lm_service": empoorio_status,
            "integrated": True
        }

        return combined_status

    except Exception as e:
        logger.error(f"Status endpoint error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Federated Inference Endpoints

@router.post("/federated/query", response_model=FederatedQueryResponse)
async def federated_query(
    request: FederatedQueryRequest,
    token_data = Depends(require_permissions(["inference:generate"]))
):
    """
    Perform federated inference query.

    Requires inference:generate permission.
    """
    try:
        start_time = time.time()

        # Validate model exists in registry
        if model_registry:
            model_info = await model_registry._get_model(request.model_id)
            if not model_info:
                raise HTTPException(status_code=404, detail=f"Model {request.model_id} not found")

        # Authenticate wallet if signature provided
        if request.wallet_signature:
            await _authenticate_wallet(request.wallet_signature, request.model_id)

        # Process encrypted request if needed
        if request.encrypted:
            request.prompt = await _decrypt_request(request.prompt)

        # Perform inference using federated coordinator
        if federated_inference_coordinator and federated_inference_coordinator.is_loaded:
            inference_request = InferenceRequest(
                prompt=request.prompt,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                top_p=request.top_p,
                top_k=request.top_k,
                stream=False
            )
            response = await federated_inference_coordinator.generate(inference_request)
            generated_text = response.text
        else:
            # Fallback to legacy service
            inference_request = InferenceRequest(
                prompt=request.prompt,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                top_p=request.top_p,
                top_k=request.top_k,
                stream=False
            )
            response = await inference_service.generate(inference_request)
            generated_text = response.text

        # Encrypt response if requested
        if request.encrypted:
            generated_text = await _encrypt_response(generated_text)

        processing_time = time.time() - start_time

        return FederatedQueryResponse(
            text=generated_text,
            usage=response.usage if hasattr(response, 'usage') else {},
            model_version=request.model_id,
            federated_nodes=["coordinator-node"],  # Placeholder for actual federated nodes
            processing_time=processing_time,
            encrypted=request.encrypted
        )

    except Exception as e:
        logger.error(f"Federated query error: {e}")
        raise HTTPException(status_code=500, detail=f"Federated inference error: {str(e)}")


@router.post("/federated/batch_query", response_model=FederatedBatchQueryResponse)
async def federated_batch_query(
    request: FederatedBatchQueryRequest,
    token_data = Depends(require_permissions(["inference:generate"]))
):
    """
    Perform batch federated inference queries.

    Requires inference:generate permission.
    """
    try:
        start_time = time.time()

        # Validate model exists
        if model_registry:
            model_info = await model_registry._get_model(request.model_id)
            if not model_info:
                raise HTTPException(status_code=404, detail=f"Model {request.model_id} not found")

        # Authenticate wallet if signature provided
        if request.wallet_signature:
            await _authenticate_wallet(request.wallet_signature, request.model_id)

        # Process batch
        results = []
        total_usage = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

        for prompt in request.prompts:
            # Decrypt if needed
            processed_prompt = await _decrypt_request(prompt) if request.encrypted else prompt

            # Perform inference
            if federated_inference_coordinator and federated_inference_coordinator.is_loaded:
                inference_request = InferenceRequest(
                    prompt=processed_prompt,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    stream=False
                )
                response = await federated_inference_coordinator.generate(inference_request)
            else:
                inference_request = InferenceRequest(
                    prompt=processed_prompt,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    stream=False
                )
                response = await inference_service.generate(inference_request)

            # Encrypt response if needed
            generated_text = response.text
            if request.encrypted:
                generated_text = await _encrypt_response(generated_text)

            # Accumulate usage
            if hasattr(response, 'usage'):
                total_usage["prompt_tokens"] += response.usage.get("prompt_tokens", 0)
                total_usage["completion_tokens"] += response.usage.get("completion_tokens", 0)
                total_usage["total_tokens"] += response.usage.get("total_tokens", 0)

            results.append(FederatedQueryResponse(
                text=generated_text,
                usage=response.usage if hasattr(response, 'usage') else {},
                model_version=request.model_id,
                federated_nodes=["coordinator-node"],
                processing_time=time.time() - start_time,
                encrypted=request.encrypted
            ))

        batch_processing_time = time.time() - start_time

        return FederatedBatchQueryResponse(
            results=results,
            total_usage=total_usage,
            batch_processing_time=batch_processing_time,
            encrypted=request.encrypted
        )

    except Exception as e:
        logger.error(f"Federated batch query error: {e}")
        raise HTTPException(status_code=500, detail=f"Federated batch inference error: {str(e)}")


@router.get("/federated/status", response_model=InferenceStatusResponse)
async def get_federated_status(
    token_data = Depends(require_permissions(["inference:read"]))
):
    """
    Get federated inference service status.

    Requires inference:read permission.
    """
    try:
        # Get coordinator status
        coordinator_status = "healthy" if federated_inference_coordinator and federated_inference_coordinator.is_loaded else "unhealthy"

        # Get model registry status
        registry_status = "healthy" if model_registry else "unhealthy"

        # Get active models from registry
        active_models = []
        if model_registry:
            try:
                models = await model_registry.query_models({})
                active_models = [m['model_id'] for m in models if m.get('status') == 'published']
            except Exception:
                active_models = []

        # Placeholder for federated nodes status
        federated_nodes = [
            {"node_id": "coordinator-node", "status": "active", "models": active_models}
        ]

        # Metrics placeholder
        metrics = {
            "total_federated_requests": 0,
            "active_federated_sessions": 0,
            "federated_throughput": 0.0
        }

        return InferenceStatusResponse(
            status="healthy" if coordinator_status == "healthy" and registry_status == "healthy" else "degraded",
            federated_coordinator_status=coordinator_status,
            model_registry_status=registry_status,
            active_models=active_models,
            federated_nodes=federated_nodes,
            metrics=metrics
        )

    except Exception as e:
        logger.error(f"Federated status error: {e}")
        raise HTTPException(status_code=500, detail=f"Status error: {str(e)}")


# Model Management Endpoints

@router.get("/models/list", response_model=List[Dict[str, Any]])
async def list_federated_models(
    skip: int = 0,
    limit: int = 100,
    token_data = Depends(require_permissions(["models:read"]))
):
    """
    List available federated models.

    Requires models:read permission.
    """
    try:
        if not model_registry:
            raise HTTPException(status_code=503, detail="Model registry not available")

        # Query models from registry
        filters = {"status": "published"}  # Only show published models
        models = await model_registry.query_models(filters, limit=limit)

        # Format response
        formatted_models = []
        for model in models[skip:skip+limit]:
            formatted_models.append({
                "id": model["model_id"],
                "name": model["name"],
                "version": model["version"],
                "description": model["description"],
                "architecture": model["architecture"],
                "framework": model["framework"],
                "performance_metrics": model["performance_metrics"],
                "tags": model["tags"],
                "publisher_address": model["publisher_address"],
                "created_at": model["created_at"],
                "ipfs_cid": model.get("ipfs_cid")
            })

        return formatted_models

    except Exception as e:
        logger.error(f"List models error: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing models: {str(e)}")


@router.get("/models/{model_id}", response_model=Dict[str, Any])
async def get_federated_model(
    model_id: str,
    token_data = Depends(require_permissions(["models:read"]))
):
    """
    Get details of a specific federated model.

    Requires models:read permission.
    """
    try:
        if not model_registry:
            raise HTTPException(status_code=503, detail="Model registry not available")

        model = await model_registry._get_model(model_id)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {model_id} not found")

        # Get lineage information
        lineage = await model_registry.get_model_lineage(model_id)

        response = {
            "id": model["model_id"],
            "name": model["name"],
            "version": model["version"],
            "description": model["description"],
            "architecture": model["architecture"],
            "framework": model["framework"],
            "dataset_info": model["dataset_info"],
            "performance_metrics": model["performance_metrics"],
            "tags": model["tags"],
            "license": model["license"],
            "publisher_address": model["publisher_address"],
            "status": model["status"],
            "created_at": model["created_at"],
            "updated_at": model["updated_at"],
            "ipfs_cid": model.get("ipfs_cid"),
            "model_hash": model.get("model_hash"),
            "federated_lineage": None
        }

        if lineage:
            response["federated_lineage"] = {
                "contributors": lineage.contributors,
                "datasets": lineage.datasets,
                "training_rounds": lineage.training_rounds,
                "privacy_measures": lineage.privacy_measures,
                "federated_metrics": lineage.federated_metrics
            }

        return response

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get model error: {e}")
        raise HTTPException(status_code=500, detail=f"Error retrieving model: {str(e)}")


@router.post("/models/deploy", response_model=ModelDeploymentStatus)
async def deploy_federated_model(
    request: ModelDeploymentRequest,
    token_data = Depends(require_permissions(["models:deploy"]))
):
    """
    Deploy a model to federated nodes.

    Requires models:deploy permission.
    """
    try:
        if not model_registry:
            raise HTTPException(status_code=503, detail="Model registry not available")

        # Authenticate wallet if signature provided
        if request.wallet_signature:
            await _authenticate_wallet(request.wallet_signature, request.model_id)

        # Verify model exists
        model = await model_registry._get_model(request.model_id)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {request.model_id} not found")

        # Placeholder deployment logic
        # In production, this would:
        # 1. Select target nodes based on request.target_nodes or auto-scaling
        # 2. Distribute model to selected nodes
        # 3. Update deployment status
        # 4. Handle encryption if requested

        deployed_nodes = request.target_nodes or ["node-1", "node-2", "node-3"]  # Placeholder

        return ModelDeploymentStatus(
            model_id=request.model_id,
            status="deployed",
            deployed_nodes=deployed_nodes,
            deployment_time=datetime.utcnow()
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Deploy model error: {e}")
        raise HTTPException(status_code=500, detail=f"Error deploying model: {str(e)}")


@router.post("/models/undeploy", response_model=ModelDeploymentStatus)
async def undeploy_federated_model(
    request: ModelUndeploymentRequest,
    token_data = Depends(require_permissions(["models:deploy"]))
):
    """
    Undeploy a model from federated nodes.

    Requires models:deploy permission.
    """
    try:
        if not model_registry:
            raise HTTPException(status_code=503, detail="Model registry not available")

        # Authenticate wallet if signature provided
        if request.wallet_signature:
            await _authenticate_wallet(request.wallet_signature, request.model_id)

        # Verify model exists
        model = await model_registry._get_model(request.model_id)
        if not model:
            raise HTTPException(status_code=404, detail=f"Model {request.model_id} not found")

        # Placeholder undeployment logic
        # In production, this would:
        # 1. Identify nodes where model is deployed
        # 2. Remove model from selected nodes
        # 3. Update deployment status

        target_nodes = request.target_nodes or ["node-1", "node-2", "node-3"]  # Placeholder

        return ModelDeploymentStatus(
            model_id=request.model_id,
            status="undeployed",
            deployed_nodes=[],  # No longer deployed
            deployment_time=datetime.utcnow()
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Undeploy model error: {e}")
        raise HTTPException(status_code=500, detail=f"Error undeploying model: {str(e)}")
