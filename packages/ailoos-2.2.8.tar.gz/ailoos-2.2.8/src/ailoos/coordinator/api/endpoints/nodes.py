"""
API endpoints for node management.
"""

import os
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from ...database.connection import get_db
from ...auth.jwt import require_permissions, ADMIN_PERMISSIONS
from ...auth.dependencies import conditional_node_auth
from ...models.schemas import (
    NodeResponse,
    NodeUpdate,
    APIResponse,
    PaginatedResponse
)
from ...services.node_service import NodeService
from ...core.exceptions import NodeNotFoundError
from ...config.settings import settings


router = APIRouter()
node_service = NodeService()


def _normalize_dt(timestamp: Optional[datetime]) -> Optional[datetime]:
    if not timestamp:
        return None
    tzinfo = timestamp.tzinfo
    if tzinfo is None:
        return timestamp
    try:
        if tzinfo.utcoffset(timestamp) is None:
            return timestamp
    except Exception:
        return timestamp
    return timestamp.astimezone(timezone.utc).replace(tzinfo=None)


def _seconds_since(timestamp: Optional[datetime]) -> Optional[float]:
    normalized = _normalize_dt(timestamp)
    if not normalized:
        return None
    return (datetime.utcnow() - normalized).total_seconds()

class NodeRegisterRequest(BaseModel):
    """Request schema for node registration."""
    node_id: str = Field(..., description="Node identifier")
    public_key: Optional[str] = Field(None, description="Node public key")
    capabilities: Optional[Dict[str, Any]] = Field(None, description="Hardware capabilities")
    hardware_specs: Optional[Dict[str, Any]] = Field(None, description="Detailed hardware specs")
    location: Optional[Dict[str, Any]] = Field(None, description="Location metadata")
    ip_address: Optional[str] = Field(None, description="Node IP address")
    status: Optional[str] = Field(None, description="Initial node status")


class NodeHeartbeatRequest(BaseModel):
    """Request schema for node heartbeat."""
    status: Optional[Any] = Field(None, description="Node status")
    capabilities: Optional[Dict[str, Any]] = Field(None, description="Hardware capabilities")
    hardware_specs: Optional[Dict[str, Any]] = Field(None, description="Detailed hardware specs")
    location: Optional[Dict[str, Any]] = Field(None, description="Location metadata")
    ip_address: Optional[str] = Field(None, description="Node IP address")


@router.get("/", response_model=PaginatedResponse)
async def list_nodes(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of records to return"),
    status: Optional[str] = Query(None, description="Filter by node status"),
    trust_level: Optional[str] = Query(None, description="Filter by trust level"),
    db: Session = Depends(get_db),
    # Temporarily remove admin permission requirement for federated-nodes page
    # current_user: str = Depends(require_permissions(ADMIN_PERMISSIONS["full"]))
):
    """List all nodes with optional filtering."""
    try:
        nodes, total = await node_service.list_nodes(
            db=db,
            skip=skip,
            limit=limit,
            status=status,
            trust_level=trust_level
        )

        return PaginatedResponse(
            data=nodes,
            total=total,
            page=(skip // limit) + 1,
            page_size=limit,
            total_pages=(total + limit - 1) // limit
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/register", response_model=APIResponse, status_code=201)
async def register_node(
    request: NodeRegisterRequest,
    db: Session = Depends(get_db)
):
    """Register or refresh a node entry."""
    hardware_specs = request.hardware_specs or request.capabilities
    location = request.location or {}
    if request.ip_address:
        location = {**location, "ip_address": request.ip_address}

    auto_verify = os.getenv(
        "AUTO_VERIFY_NODES",
        "1" if settings.environment != "production" else "0"
    ) == "1"

    node = await node_service.register_node(
        db=db,
        node_data={
            "id": request.node_id,
            "public_key": request.public_key,
            "status": request.status,
            "hardware_specs": hardware_specs,
            "location": location or None
        },
        auto_verify=auto_verify
    )

    return APIResponse(
        data=node,
        message="Node registered successfully"
    )


@router.get("/{node_id}", response_model=APIResponse)
async def get_node(
    node_id: str,
    db: Session = Depends(get_db),
    # Temporarily remove admin permission requirement for federated-nodes page
    # current_user: str = Depends(require_permissions(ADMIN_PERMISSIONS["full"]))
):
    """Get a specific node by ID."""
    try:
        node = await node_service.get_node_by_id(db=db, node_id=node_id)
        return APIResponse(data=node)
    except NodeNotFoundError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{node_id}/status", response_model=APIResponse)
async def get_node_status(
    node_id: str,
    db: Session = Depends(get_db),
    current_node: Optional[dict] = Depends(conditional_node_auth)
):
    """Get node status with health metadata."""
    if current_node and current_node.get("node_id") != node_id:
        raise HTTPException(status_code=403, detail="Can only access own node status")

    node = await node_service.get_node_by_id(db=db, node_id=node_id)

    last_heartbeat = node.last_heartbeat
    timeout_seconds = settings.node_timeout_seconds
    seconds_since = _seconds_since(last_heartbeat)
    if seconds_since is not None:
        health_status = "healthy" if seconds_since <= timeout_seconds else "unhealthy"
    else:
        health_status = "unknown"

    return APIResponse(
        data={
            "node": node,
            "health_status": health_status,
            "seconds_since_heartbeat": seconds_since,
            "timeout_seconds": timeout_seconds
        }
    )


@router.put("/{node_id}", response_model=APIResponse)
async def update_node(
    node_id: str,
    node_update: NodeUpdate,
    db: Session = Depends(get_db),
    # Temporarily remove admin permission requirement for federated-nodes page
    # current_user: str = Depends(require_permissions(ADMIN_PERMISSIONS["full"]))
):
    """Update node information."""
    try:
        node = await node_service.update_node(
            db=db,
            node_id=node_id,
            node_update=node_update
        )
        return APIResponse(data=node, message="Node updated successfully")
    except NodeNotFoundError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{node_id}", response_model=APIResponse)
async def delete_node(
    node_id: str,
    db: Session = Depends(get_db),
    # Temporarily remove admin permission requirement for federated-nodes page
    # current_user: str = Depends(require_permissions(ADMIN_PERMISSIONS["full"]))
):
    """Delete a node."""
    try:
        await node_service.delete_node(db=db, node_id=node_id)
        return APIResponse(message="Node deleted successfully")
    except NodeNotFoundError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/me/status", response_model=APIResponse)
async def get_my_status(
    current_node: dict = Depends(conditional_node_auth),
    db: Session = Depends(get_db)
):
    """Get current node's own status."""
    if not current_node or not current_node.get("node_id"):
        raise HTTPException(status_code=403, detail="Authentication required")

    try:
        node = await node_service.get_node_by_id(db=db, node_id=current_node["node_id"])
        return APIResponse(data=node)
    except NodeNotFoundError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{node_id}/heartbeat", response_model=APIResponse)
@router.put("/{node_id}/heartbeat", response_model=APIResponse)
async def node_heartbeat(
    node_id: str,
    db: Session = Depends(get_db),
    current_node: Optional[dict] = Depends(conditional_node_auth),
    request: Optional[NodeHeartbeatRequest] = None
):
    """Update node heartbeat timestamp."""
    if current_node and current_node.get("node_id") != node_id:
        raise HTTPException(status_code=403, detail="Can only update own heartbeat")

    try:
        hardware_specs = None
        location = None
        status = None

        if request:
            if isinstance(request.status, dict):
                if request.status.get("is_training"):
                    status = "training"
                elif request.status.get("is_online") is False:
                    status = "offline"
                else:
                    status = "active"
            else:
                status = request.status
            hardware_specs = request.hardware_specs or request.capabilities
            location = request.location or {}
            if request.ip_address:
                location = {**location, "ip_address": request.ip_address}

        await node_service.update_heartbeat(
            db=db,
            node_id=node_id,
            status=status,
            hardware_specs=hardware_specs,
            location=location
        )
        return APIResponse(message="Heartbeat updated successfully")
    except NodeNotFoundError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ========== Model Distribution Endpoints ==========

class DistributionACKRequest(BaseModel):
    """Request schema for distribution ACK."""
    node_id: str = Field(..., description="Node identifier")
    version_id: str = Field(..., description="Model version identifier")
    verified_hash: str = Field(..., description="SHA256 hash verified by node")
    success: bool = Field(..., description="Whether download was successful")
    error: Optional[str] = Field(None, description="Error message if failed")
    timestamp: float = Field(..., description="Timestamp of verification")


@router.post("/distribution-ack", response_model=APIResponse, status_code=200)
async def receive_distribution_ack(
    request: DistributionACKRequest,
    db: Session = Depends(get_db)
):
    """
    Receive acknowledgment from node that model was downloaded and verified.
    
    This endpoint is called by physical nodes after they successfully download
    a model from IPFS and verify its hash.
    """
    try:
        # Import los servicios necesarios
        from ...services.node_version_service import get_node_version_service
        from ....federated.ipfs_version_distributor import IPFSVersionDistributor
        
        version_service = get_node_version_service()
        
        # Confirmar descarga en el servicio
        confirmed = await version_service.confirm_download(
            node_id=request.node_id,
            version_id=request.version_id,
            verified_hash=request.verified_hash,
            success=request.success,
            error_message=request.error or ""
        )
        
        if not confirmed:
            raise HTTPException(
                status_code=404, 
                detail=f"No pending distribution found for {request.node_id}/{request.version_id}"
            )
        
        # Log el resultado
        from ....core.logging import get_logger
        logger = get_logger(__name__)
        
        if request.success:
            logger.info(f"✅ Node {request.node_id} confirmed download of {request.version_id}")
        else:
            logger.warning(f"❌ Node {request.node_id} failed to download {request.version_id}: {request.error}")
        
        return APIResponse(
            data={
                "node_id": request.node_id,
                "version_id": request.version_id,
                "confirmed": True,
                "hash_verified": request.success
            },
            message="Distribution ACK received"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        from ....core.logging import get_logger
        logger = get_logger(__name__)
        logger.error(f"Error processing distribution ACK: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/peers", response_model=APIResponse)
async def list_active_peers(
    db: Session = Depends(get_db),
    region: Optional[str] = Query(None, description="Filter by region"),
    min_trust_level: Optional[float] = Query(None, description="Minimum trust level")
):
    """
    Get list of active peer nodes for P2P connections.
    
    Returns nodes that are currently active and available for P2P communication,
    including their host/port information for direct connections.
    """
    try:
        # Obtener nodos activos
        nodes, total = await node_service.list_nodes(
            db=db,
            skip=0,
            limit=1000,
            status="active"
        )
        
        # Filtrar y formatear para P2P
        peers = []
        for node in nodes:
            # Extraer información de conexión
            location = node.get("location", {}) if isinstance(node, dict) else {}
            hardware_specs = node.get("hardware_specs", {}) if isinstance(node, dict) else {}
            
            # Filtrar por región si se especifica
            if region and location.get("region") != region:
                continue
            
            # Filtrar por trust level si se especifica
            if min_trust_level is not None:
                node_trust = node.get("trust_level", 0.0) if isinstance(node, dict) else 0.0
                if node_trust < min_trust_level:
                    continue
            
            # Construir info de peer
            peer_info = {
                "node_id": node.get("id") if isinstance(node, dict) else node.id,
                "host": location.get("ip_address", "unknown"),
                "port": hardware_specs.get("p2p_port", 8443),  # Puerto por defecto
                "region": location.get("region", "unknown"),
                "last_seen": node.get("last_heartbeat") if isinstance(node, dict) else None,
                "trust_level": node.get("trust_level", 0.0) if isinstance(node, dict) else 0.0,
                "capabilities": hardware_specs
            }
            
            peers.append(peer_info)
        
        return APIResponse(
            data={
                "peers": peers,
                "total": len(peers),
                "filtered_by_region": region,
                "min_trust_level": min_trust_level
            },
            message=f"Found {len(peers)} active peers"
        )
        
    except Exception as e:
        from ....core.logging import get_logger
        logger = get_logger(__name__)
        logger.error(f"Error listing peers: {e}")
        raise HTTPException(status_code=500, detail=str(e))
