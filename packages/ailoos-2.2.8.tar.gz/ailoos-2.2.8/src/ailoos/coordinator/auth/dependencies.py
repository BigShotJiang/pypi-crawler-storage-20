"""
Authentication and authorization dependencies for FastAPI.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional
import os
import jwt
from datetime import datetime, timedelta

from ...core.config import Config


security = HTTPBearer(auto_error=False)
config = Config()
_DEFAULT_JWT_SECRET = "change-this-in-production-to-a-secure-random-key"


def _get_jwt_secret() -> str:
    secret = getattr(config.api, "jwt_secret", None)
    if secret:
        return secret
    env_secret = os.getenv("JWT_SECRET_KEY") or os.getenv("JWT_SECRET")
    if env_secret:
        return env_secret
    return _DEFAULT_JWT_SECRET


def _get_jwt_expiration_hours() -> int:
    return getattr(config.api, "jwt_expiration_hours", 24)


def get_current_node(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """Get current authenticated node."""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, _get_jwt_secret(), algorithms=["HS256"])

        # Check token expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload.get("exp", 0)):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )

        return {
            "node_id": payload.get("node_id"),
            "public_key": payload.get("public_key"),
            "trust_level": payload.get("trust_level", "basic"),
            "roles": payload.get("roles", [])
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """Get current authenticated user (allows both admin and regular users)."""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, _get_jwt_secret(), algorithms=["HS256"])

        # Check token expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload.get("exp", 0)):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )

        # Return user info - allow both admin and regular users
        return {
            "user_id": payload.get("user_id"),
            "username": payload.get("username"),
            "roles": payload.get("roles", []),
            "permissions": payload.get("permissions", [])
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )


def get_current_admin(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """Get current authenticated admin user."""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, _get_jwt_secret(), algorithms=["HS256"])

        # Check token expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload.get("exp", 0)):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )

        # Check if user has admin role
        roles = payload.get("roles", [])
        if "admin" not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin access required"
            )

        return {
            "user_id": payload.get("user_id"),
            "username": payload.get("username"),
            "roles": roles,
            "permissions": payload.get("permissions", [])
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )


def create_node_token(node_id: str, public_key: str, trust_level: str = "basic") -> str:
    """Create JWT token for a node."""
    expiration = datetime.utcnow() + timedelta(hours=_get_jwt_expiration_hours())

    payload = {
        "node_id": node_id,
        "public_key": public_key,
        "trust_level": trust_level,
        "roles": ["node"],
        "exp": expiration.timestamp(),
        "iat": datetime.utcnow().timestamp(),
        "iss": "ailoos-coordinator"
    }

    return jwt.encode(payload, _get_jwt_secret(), algorithm="HS256")


def create_admin_token(user_id: str, username: str, roles: list, permissions: list) -> str:
    """Create JWT token for an admin user."""
    expiration = datetime.utcnow() + timedelta(hours=_get_jwt_expiration_hours())

    payload = {
        "user_id": user_id,
        "username": username,
        "roles": roles,
        "permissions": permissions,
        "exp": expiration.timestamp(),
        "iat": datetime.utcnow().timestamp(),
        "iss": "ailoos-coordinator"
    }

    return jwt.encode(payload, _get_jwt_secret(), algorithm="HS256")


def require_admin(user: dict = Depends(get_current_admin)) -> dict:
    """Require admin role dependency."""
    return user


def conditional_user_auth(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> Optional[dict]:
    """Conditional user authentication based on environment.
    Skips authentication unless in production."""
    import os

    environment = os.getenv("ENVIRONMENT", "development")

    if environment != "production":
        # Skip authentication unless in production
        return None

    # Require authentication in production
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Authentication required in production environment"
        )

    try:
        token = credentials.credentials
        payload = jwt.decode(token, config.jwt_secret_key, algorithms=["HS256"])

        # Check token expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload.get("exp", 0)):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )

        # Return user info
        return {
            "user_id": payload.get("user_id"),
            "username": payload.get("username"),
            "roles": payload.get("roles", []),
            "permissions": payload.get("permissions", [])
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Authentication required in production environment"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Authentication required in production environment"
        )


def conditional_node_auth(credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)) -> Optional[dict]:
    """Conditional node authentication based on environment.
    Skips authentication unless in production."""
    import os

    environment = os.getenv("ENVIRONMENT", "development")

    if environment != "production":
        # Skip authentication unless in production
        return None

    # Require authentication in production
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Authentication required in production environment"
        )

    try:
        token = credentials.credentials
        payload = jwt.decode(token, config.jwt_secret_key, algorithms=["HS256"])

        # Check token expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload.get("exp", 0)):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )

        # Return node info
        return {
            "node_id": payload.get("node_id"),
            "public_key": payload.get("public_key"),
            "trust_level": payload.get("trust_level", "basic"),
            "roles": payload.get("roles", [])
        }
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Authentication required in production environment"
        )
    except jwt.InvalidTokenError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Authentication required in production environment"
        )


def verify_token(token: str) -> Optional[dict]:
    """Verify JWT token and return payload."""
    try:
        payload = jwt.decode(token, config.jwt_secret_key, algorithms=["HS256"])

        # Check expiration
        if datetime.utcnow() > datetime.fromtimestamp(payload.get("exp", 0)):
            return None

        return payload
    except:
        return None
