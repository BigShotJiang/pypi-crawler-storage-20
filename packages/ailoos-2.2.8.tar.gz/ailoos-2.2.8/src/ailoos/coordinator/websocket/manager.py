"""
Backward-compatible WebSocket manager module.
"""

from .websocket_manager import ConnectionManager, manager, websocket_router

__all__ = ["ConnectionManager", "manager", "websocket_router"]
