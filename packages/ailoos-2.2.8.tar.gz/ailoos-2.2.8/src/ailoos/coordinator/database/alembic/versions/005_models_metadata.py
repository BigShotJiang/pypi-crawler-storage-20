"""Add missing model metadata columns

Revision ID: 005_models_metadata
Revises: 004_revoked_tokens
Create Date: 2026-01-12 23:01:30.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = "005_models_metadata"
down_revision: Union[str, None] = "004_revoked_tokens"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("models", sa.Column("description", sa.Text(), nullable=True))
    op.add_column("models", sa.Column("tags", postgresql.JSON(astext_type=sa.Text()), nullable=True))
    op.add_column("models", sa.Column("ipfs_cid", sa.String(length=128), nullable=True))
    op.add_column("models", sa.Column("file_hash", sa.String(length=128), nullable=True))
    op.add_column("models", sa.Column("file_size", sa.Integer(), nullable=True))
    op.add_column("models", sa.Column("published_at", sa.DateTime(), nullable=True))
    op.add_column("models", sa.Column("published_by", sa.String(length=64), nullable=True))

    op.create_index("ix_models_ipfs_cid", "models", ["ipfs_cid"])
    op.create_index("ix_models_file_hash", "models", ["file_hash"])


def downgrade() -> None:
    op.drop_index("ix_models_file_hash", table_name="models")
    op.drop_index("ix_models_ipfs_cid", table_name="models")

    op.drop_column("models", "published_by")
    op.drop_column("models", "published_at")
    op.drop_column("models", "file_size")
    op.drop_column("models", "file_hash")
    op.drop_column("models", "ipfs_cid")
    op.drop_column("models", "tags")
    op.drop_column("models", "description")
