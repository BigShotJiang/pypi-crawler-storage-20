"""Add revoked_tokens table for JWT revocation

Revision ID: 004_revoked_tokens
Revises: 003_personalization_training
Create Date: 2026-01-12 21:38:30.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "004_revoked_tokens"
down_revision: Union[str, None] = "003_personalization_training"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "revoked_tokens",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("token_jti", sa.String(length=64), nullable=False, unique=True),
        sa.Column("token_type", sa.String(length=20), nullable=False),
        sa.Column("revoked_by", sa.String(length=64), nullable=True),
        sa.Column("revocation_reason", sa.String(length=100), nullable=True),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("created_at", sa.DateTime(), server_default=sa.text("now()"), nullable=False),
    )
    op.create_index("idx_revoked_tokens_jti_type", "revoked_tokens", ["token_jti", "token_type"])
    op.create_index("idx_revoked_tokens_expires", "revoked_tokens", ["expires_at"])
    op.create_index("ix_revoked_tokens_token_type", "revoked_tokens", ["token_type"])


def downgrade() -> None:
    op.drop_index("ix_revoked_tokens_token_type", table_name="revoked_tokens")
    op.drop_index("idx_revoked_tokens_expires", table_name="revoked_tokens")
    op.drop_index("idx_revoked_tokens_jti_type", table_name="revoked_tokens")
    op.drop_table("revoked_tokens")
