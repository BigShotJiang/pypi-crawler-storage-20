"""Add personalization training sessions and jobs

Revision ID: 003_personalization_training
Revises: add_discord_webhook_integrations
Create Date: 2026-01-12 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = '003_personalization_training'
down_revision: Union[str, None] = 'add_discord_webhook_integrations'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'personalization_training_sessions',
        sa.Column('id', sa.String(length=64), nullable=False),
        sa.Column('user_id', sa.String(length=64), nullable=False),
        sa.Column('user_numeric_id', sa.Integer(), nullable=True),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='queued'),
        sa.Column('dataset_size', sa.String(length=10), nullable=False),
        sa.Column('training_hours', sa.Integer(), nullable=False),
        sa.Column('priority', sa.String(length=10), nullable=False, server_default='normal'),
        sa.Column('config', postgresql.JSON(astext_type=sa.Text()), nullable=True),
        sa.Column('progress', sa.Float(), nullable=False, server_default='0.0'),
        sa.Column('current_epoch', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('total_epochs', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('training_loss', sa.Float(), nullable=True),
        sa.Column('validation_loss', sa.Float(), nullable=True),
        sa.Column('model_path', sa.String(length=500), nullable=True),
        sa.Column('base_model_path', sa.String(length=500), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('metadata_json', postgresql.JSON(astext_type=sa.Text()), nullable=True),
        sa.Column('started_at', postgresql.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('completed_at', postgresql.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('created_at', postgresql.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', postgresql.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )

    op.create_table(
        'personalization_training_jobs',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('session_id', sa.String(length=64), nullable=False),
        sa.Column('user_id', sa.String(length=64), nullable=False),
        sa.Column('status', sa.String(length=20), nullable=False, server_default='queued'),
        sa.Column('priority', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('attempts', sa.Integer(), nullable=False, server_default='0'),
        sa.Column('max_attempts', sa.Integer(), nullable=False, server_default='3'),
        sa.Column('last_error', sa.Text(), nullable=True),
        sa.Column('started_at', postgresql.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('completed_at', postgresql.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('locked_at', postgresql.TIMESTAMP(timezone=True), nullable=True),
        sa.Column('locked_by', sa.String(length=64), nullable=True),
        sa.Column('created_at', postgresql.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', postgresql.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('session_id')
    )

    op.create_index(
        'ix_personalization_training_sessions_user_id',
        'personalization_training_sessions',
        ['user_id']
    )
    op.create_index(
        'ix_personalization_training_sessions_status',
        'personalization_training_sessions',
        ['status']
    )
    op.create_index(
        'idx_personalization_sessions_user_status',
        'personalization_training_sessions',
        ['user_id', 'status']
    )

    op.create_index(
        'ix_personalization_training_jobs_session_id',
        'personalization_training_jobs',
        ['session_id']
    )
    op.create_index(
        'ix_personalization_training_jobs_status',
        'personalization_training_jobs',
        ['status']
    )
    op.create_index(
        'idx_personalization_jobs_status_priority',
        'personalization_training_jobs',
        ['status', 'priority']
    )

    op.create_foreign_key(
        'fk_personalization_jobs_session_id',
        'personalization_training_jobs',
        'personalization_training_sessions',
        ['session_id'],
        ['id']
    )


def downgrade() -> None:
    op.drop_constraint('fk_personalization_jobs_session_id', 'personalization_training_jobs', type_='foreignkey')

    op.drop_index('idx_personalization_jobs_status_priority', table_name='personalization_training_jobs')
    op.drop_index('ix_personalization_training_jobs_status', table_name='personalization_training_jobs')
    op.drop_index('ix_personalization_training_jobs_session_id', table_name='personalization_training_jobs')
    op.drop_table('personalization_training_jobs')

    op.drop_index('idx_personalization_sessions_user_status', table_name='personalization_training_sessions')
    op.drop_index('ix_personalization_training_sessions_status', table_name='personalization_training_sessions')
    op.drop_index('ix_personalization_training_sessions_user_id', table_name='personalization_training_sessions')
    op.drop_table('personalization_training_sessions')
