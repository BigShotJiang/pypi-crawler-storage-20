"""Add Discord and webhook integrations to apps_connectors_settings

Revision ID: add_discord_webhook_integrations
Revises: 002
Create Date: 2025-11-11 10:03:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'add_discord_webhook_integrations'
down_revision = '002'
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if not inspector.has_table('apps_connectors_settings'):
        return

    existing_columns = {col['name'] for col in inspector.get_columns('apps_connectors_settings')}
    if 'discord_bot_token' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('discord_bot_token', sa.String(255), nullable=True))
    if 'discord_server_id' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('discord_server_id', sa.String(50), nullable=True))
    if 'discord_channel_id' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('discord_channel_id', sa.String(50), nullable=True))
    if 'discord_webhook_url' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('discord_webhook_url', sa.String(500), nullable=True))
    if 'webhook_headers' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('webhook_headers', sa.Text(), nullable=True))
    if 'webhook_method' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('webhook_method', sa.String(10), nullable=False, server_default='POST'))
    if 'webhook_enabled' not in existing_columns:
        op.add_column('apps_connectors_settings', sa.Column('webhook_enabled', sa.Boolean(), nullable=False, server_default='false'))

    constraint_exists = bind.execute(
        sa.text(
            "SELECT 1 FROM pg_constraint WHERE conname = :name AND conrelid = :table::regclass"
        ),
        {"name": "check_webhook_method", "table": "apps_connectors_settings"}
    ).first()
    if not constraint_exists:
        op.create_check_constraint(
            'check_webhook_method',
            'apps_connectors_settings',
            "webhook_method IN ('GET', 'POST', 'PUT', 'PATCH', 'DELETE')"
        )


def downgrade():
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    if not inspector.has_table('apps_connectors_settings'):
        return

    constraint_exists = bind.execute(
        sa.text(
            "SELECT 1 FROM pg_constraint WHERE conname = :name AND conrelid = :table::regclass"
        ),
        {"name": "check_webhook_method", "table": "apps_connectors_settings"}
    ).first()
    if constraint_exists:
        op.drop_constraint('check_webhook_method', 'apps_connectors_settings', type_='check')

    existing_columns = {col['name'] for col in inspector.get_columns('apps_connectors_settings')}
    if 'webhook_enabled' in existing_columns:
        op.drop_column('apps_connectors_settings', 'webhook_enabled')
    if 'webhook_method' in existing_columns:
        op.drop_column('apps_connectors_settings', 'webhook_method')
    if 'webhook_headers' in existing_columns:
        op.drop_column('apps_connectors_settings', 'webhook_headers')
    if 'discord_webhook_url' in existing_columns:
        op.drop_column('apps_connectors_settings', 'discord_webhook_url')
    if 'discord_channel_id' in existing_columns:
        op.drop_column('apps_connectors_settings', 'discord_channel_id')
    if 'discord_server_id' in existing_columns:
        op.drop_column('apps_connectors_settings', 'discord_server_id')
    if 'discord_bot_token' in existing_columns:
        op.drop_column('apps_connectors_settings', 'discord_bot_token')
