import os
import sys
from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

# Add the parent directory to the path so we can import our models
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

# Import our models and settings
import sys
import os

# Add the project root to the path so we can import our models
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
sys.path.insert(0, project_root)

try:
    from src.ailoos.coordinator.config.settings import settings
    from src.ailoos.coordinator.models.base import Base
except ImportError:
    # Fallback for relative imports
    from ..config.settings import settings
    from ..models.base import Base

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = settings.database_url
    context.configure(
        url=url,
        target_metadata=target_metadata,
        render_as_batch=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    # Get database configuration from settings
    db_config = {
        "sqlalchemy.url": settings.database_url,
        "sqlalchemy.poolclass": "sqlalchemy.pool.QueuePool",
        "sqlalchemy.pool_size": 10,  # Default pool size
        "sqlalchemy.max_overflow": 20,  # Default max overflow
        "sqlalchemy.pool_pre_ping": True,
        "sqlalchemy.pool_recycle": 3600,  # 1 hour
        "sqlalchemy.echo": settings.debug,
    }

    try:
        connectable = engine_from_config(
            db_config,
            prefix="sqlalchemy.",
            poolclass=pool.QueuePool,
        )

        with connectable.connect() as connection:
            context.configure(
                connection=connection, target_metadata=target_metadata
            )

            with context.begin_transaction():
                context.run_migrations()
    except Exception as e:
        # If database connection fails, skip online migration and use offline mode
        print(f"Database connection failed, using offline mode: {e}")
        run_migrations_offline()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()