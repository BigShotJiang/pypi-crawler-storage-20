"""
Minimal AILOOS Coordinator API - Basic endpoints only.
This is a simplified version that avoids complex dependencies.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .api.routes import api_router
from .services.model_service import model_service
from ..core.logging import get_logger

logger = get_logger(__name__)

# Create FastAPI app
app = FastAPI(
    title="AILOOS Coordinator API",
    description="Minimal AILOOS API with basic endpoints",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all API routers
app.include_router(api_router, prefix="/api")

# Startup hooks
@app.on_event("startup")
async def startup_services():
    """Initialize coordinator services that require async setup."""
    try:
        await model_service.initialize()
        logger.info("✅ Model service initialized")
    except Exception as e:
        logger.warning(f"⚠️ Model service initialization failed: {e}")

# Health check endpoint
@app.get("/health")
async def health_check():
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "service": "ailoos-coordinator",
        "version": "1.0.0"
    }

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "message": "Welcome to AILOOS Coordinator API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

def create_application() -> FastAPI:
    """Create and return the FastAPI application."""
    return app


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
