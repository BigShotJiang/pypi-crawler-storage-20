# Gesttalt Python Bindings

Snippets CRUD bindings for Gesttalt, powered by Zig.

## Install

```bash
pip install gesttalt
```

## Usage

```python
from gesttalt import create_snippet, read_snippet, update_snippet, delete_snippet

project_dir = "."
timestamp = 1735148400

path = create_snippet(project_dir, timestamp, "Example snippet", "const x = 1;", "example.zig")
print(path)

snippet = read_snippet(project_dir, timestamp)
print(snippet)

update_snippet(project_dir, timestamp, description="Updated description")

delete_snippet(project_dir, timestamp)
```

## Development

```bash
# From project root
zig build -Doptimize=ReleaseFast

cd bindings/python
pip install -e .
pytest
```

## License

MIT
