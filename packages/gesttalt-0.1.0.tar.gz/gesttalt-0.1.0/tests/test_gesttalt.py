import os
import tempfile

from gesttalt import create_snippet, read_snippet, update_snippet, delete_snippet


def test_snippet_crud():
    with tempfile.TemporaryDirectory() as tmpdir:
        timestamp = 1735148400
        path = create_snippet(
            tmpdir,
            timestamp,
            "Test snippet",
            "const x = 1;",
            "hello.zig",
        )

        assert os.path.exists(path)

        snippet = read_snippet(tmpdir, timestamp)
        assert snippet["description"] == "Test snippet"

        update_snippet(tmpdir, timestamp, description="Updated snippet")
        updated = read_snippet(tmpdir, timestamp)
        assert updated["description"] == "Updated snippet"

        delete_snippet(tmpdir, timestamp)
        assert not os.path.exists(path)
