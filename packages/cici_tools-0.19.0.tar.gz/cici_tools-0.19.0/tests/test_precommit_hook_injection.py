# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

import pytest

from cici.config.project.serializers import loads

CONFIG_YAML = """
name: test-pipeline
targets:
  - name: A
  - name: B
  - name: C
  - name: D
"""
# Only some targets have hooks
PRECOMMIT_HOOKS = {"A": {}, "C": {}}  # type: ignore[var-annotated]


def _target_by_name(file_obj, name: str):
    for t in file_obj.targets:
        if t.name == name:
            return t
    raise AssertionError(f"Target not found: {name}")


@pytest.mark.parametrize(
    "target_name, expected_has_hook",
    [
        ("A", True),
        ("B", False),
        ("C", True),
        ("D", False),
    ],
)
def test_precommit_hook_injection_is_name_based(
    target_name: str,
    expected_has_hook: bool,
):
    file_obj = loads(
        CONFIG_YAML,
        gitlab_ci_jobs={},  # irrelevant for this test
        precommit_hooks=PRECOMMIT_HOOKS,
    )
    target = _target_by_name(file_obj, target_name)
    # dict-or-None version
    assert (target.precommit_hook is not None) == expected_has_hook
