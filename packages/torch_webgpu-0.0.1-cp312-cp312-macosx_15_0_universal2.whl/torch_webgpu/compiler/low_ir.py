from typing import Any, List
import torch
from enum import StrEnum, auto

from .compiler_pass import CompilerPass
from .ir import IRNode
from .high_ir import HighIRCreateTensor, HighIRNode, HighIROp, HighIRArange, HighIRFull, HighIRZeros, HighIROnes
from .logger import debug


class LowIROp(StrEnum):
    CREATE_BUFFER = auto()
    WRITE_BUFFER = auto()
    RUN_SHADER = auto()
    MOVE_TO = auto()
    OUTPUT = auto()


class LowIRNode(IRNode):
    ir_op: LowIROp

    def __init__(
        self,
        high_ir_node: HighIRNode,
        value_id: Any = None,
        inputs: List[Any] = [],
    ):
        super().__init__(value_id, inputs)
        self.high_ir_node = high_ir_node

    def __str__(self):
        return self.ir_op


class LowIRCreateBuffer(LowIRNode):
    ir_op = LowIROp.CREATE_BUFFER
    shape = None
    stride = None
    dtype = None
    device = None
    numel = None
    size = None
    # TODO adjust the list, for now I copied it from High IR

    def __init__(
        self,
        high_ir_node: HighIRCreateTensor,
        value_id: Any = None,
        inputs: List[Any] = [],
    ):
        super().__init__(high_ir_node, value_id, inputs)
        self.shape = high_ir_node.shape
        self.dtype = high_ir_node.dtype
        self.device = high_ir_node.device
        self.numel = high_ir_node.numel
        self.stride = high_ir_node.stride
        self.size = high_ir_node.size
        # I don't put data here, because it should go to LowIRWriteBuffer


class LowIRWriteBuffer(LowIRNode):
    ir_op = LowIROp.WRITE_BUFFER
    shape = None
    stride = None
    dtype = None
    device = None
    numel = None
    size = None
    data = None
    constant_data = None

    def __init__(
        self,
        high_ir_node: HighIRCreateTensor,
        value_id: Any = None,
        inputs: List[Any] = [],
    ):
        super().__init__(high_ir_node, value_id, inputs)
        self.shape = high_ir_node.shape
        self.dtype = high_ir_node.dtype
        self.device = high_ir_node.device
        self.numel = high_ir_node.numel
        self.stride = high_ir_node.stride
        self.size = high_ir_node.size
        self.constant_data = high_ir_node.constant_data


class LowIRRunShader(LowIRNode):
    ir_op = LowIROp.RUN_SHADER
    # TODO: not sure if I want to have a generic shader runner or define IR per shader
    # TODO: possibly more properties will be needed here to run a shader [efficiently]

    def __init__(
        self, high_ir_node: HighIRNode, value_id: Any = None, inputs: List[Any] = []
    ):
        super().__init__(high_ir_node, value_id=value_id, inputs=inputs)
        # For CAST ops, use cast_method (float, half, int, etc.) as shader name
        if hasattr(high_ir_node, 'cast_method') and high_ir_node.cast_method:
            self.shader_name = high_ir_node.cast_method
        else:
            self.shader_name = high_ir_node.ir_op


class LowIRMoveTo(LowIRNode):
    ir_op = LowIROp.MOVE_TO
    to_device = None

    def __init__(
        self, high_ir_node: HighIRNode, value_id: Any = None, inputs: List[Any] = []
    ):
        super().__init__(high_ir_node, value_id=value_id, inputs=inputs)
        # Extract device from args or kwargs
        fx_args = high_ir_node.fx_node.args
        fx_kwargs = high_ir_node.fx_node.kwargs

        # Try to extract device from args[1] or kwargs['device']
        device_arg = None
        if len(fx_args) >= 2:
            device_arg = fx_args[1]
        elif 'device' in fx_kwargs:
            device_arg = fx_kwargs['device']

        if device_arg is not None:
            if isinstance(device_arg, str):
                self.to_device = device_arg
            elif isinstance(device_arg, torch.device):
                self.to_device = str(device_arg)
            elif hasattr(device_arg, 'type'):  # torch.device-like
                self.to_device = device_arg.type

        # If still no device, try to infer from example_value metadata
        if self.to_device is None and "example_value" in high_ir_node.fx_node.meta:
            example = high_ir_node.fx_node.meta["example_value"]
            if hasattr(example, 'device'):
                self.to_device = str(example.device)

        if self.to_device is None:
            raise Exception(
                "Can't build LowIRMoveTo, because I don't know where the tensor should be moved to.",
                f"Debug context: high_ir_node={high_ir_node}, ",
                f"value_id={value_id}, inputs={inputs}, args={fx_args}, kwargs={fx_kwargs}",
            )


class LowIROutput(LowIRNode):
    ir_op = LowIROp.OUTPUT

    def __init__(
        self, high_ir_node: HighIRNode, value_id: Any = None, inputs: List[Any] = []
    ):
        super().__init__(high_ir_node, value_id=value_id, inputs=inputs)


high_ir_op_to_low_ir_op: dict[HighIROp, list[LowIROp]] = {
    # Existing ops
    HighIROp.CREATE_TENSOR: [LowIROp.CREATE_BUFFER, LowIROp.WRITE_BUFFER],
    HighIROp.PLACEHOLDER: [],  # Placeholders are just references to input tensors
    HighIROp.GETATTR: [],  # Getattr is just reference to module attributes
    HighIROp.MUL: [LowIROp.RUN_SHADER],
    HighIROp.FUSED_ADD_RELU: [LowIROp.RUN_SHADER],
    HighIROp.RELU: [LowIROp.RUN_SHADER],
    HighIROp.ADD: [LowIROp.RUN_SHADER],
    HighIROp.MM: [LowIROp.RUN_SHADER],
    HighIROp.MOVE_TO: [LowIROp.MOVE_TO],
    HighIROp.OUTPUT: [LowIROp.OUTPUT],
    # Basic arithmetic
    HighIROp.SUB: [LowIROp.RUN_SHADER],
    HighIROp.DIV: [LowIROp.RUN_SHADER],
    HighIROp.NEG: [LowIROp.RUN_SHADER],
    # Matrix ops
    HighIROp.MATMUL: [LowIROp.RUN_SHADER],
    # Activation functions
    HighIROp.SILU: [LowIROp.RUN_SHADER],
    HighIROp.GELU: [LowIROp.RUN_SHADER],
    HighIROp.TANH: [LowIROp.RUN_SHADER],
    # Unary math
    HighIROp.COS: [LowIROp.RUN_SHADER],
    HighIROp.SIN: [LowIROp.RUN_SHADER],
    HighIROp.EXP: [LowIROp.RUN_SHADER],
    HighIROp.SQRT: [LowIROp.RUN_SHADER],
    HighIROp.RSQRT: [LowIROp.RUN_SHADER],
    HighIROp.POW: [LowIROp.RUN_SHADER],
    # Reductions
    HighIROp.SUM: [LowIROp.RUN_SHADER],
    HighIROp.MEAN: [LowIROp.RUN_SHADER],
    HighIROp.MAX: [LowIROp.RUN_SHADER],
    HighIROp.MIN: [LowIROp.RUN_SHADER],
    HighIROp.ARGMAX: [LowIROp.RUN_SHADER],
    HighIROp.CUMSUM: [LowIROp.RUN_SHADER],
    HighIROp.REPEAT_INTERLEAVE: [LowIROp.RUN_SHADER],
    HighIROp.SET_GRAD_ENABLED: [],  # No-op for inference (returns None)
    # vmap batch operations
    HighIROp.ADD_BATCH_DIM: [LowIROp.RUN_SHADER],
    HighIROp.REMOVE_BATCH_DIM: [LowIROp.RUN_SHADER],
    HighIROp.VMAP_INCREMENT_NESTING: [LowIROp.RUN_SHADER],
    HighIROp.VMAP_DECREMENT_NESTING: [LowIROp.RUN_SHADER],
    # Internal PyTorch ops (return None)
    HighIROp.LAZY_LOAD_DECOMPOSITIONS: [LowIROp.RUN_SHADER],
    HighIROp.ENTER_AUTOCAST: [LowIROp.RUN_SHADER],
    HighIROp.EXIT_AUTOCAST: [LowIROp.RUN_SHADER],
    HighIROp.LOG_API_USAGE: [LowIROp.RUN_SHADER],
    # Scalar extraction
    HighIROp.ITEM: [LowIROp.RUN_SHADER],  # Extract scalar from tensor
    # Softmax
    HighIROp.SOFTMAX: [LowIROp.RUN_SHADER],
    # Normalization
    HighIROp.LAYER_NORM: [LowIROp.RUN_SHADER],
    # Linear and embedding
    HighIROp.LINEAR: [LowIROp.RUN_SHADER],
    HighIROp.EMBEDDING: [LowIROp.RUN_SHADER],
    # Shape ops
    HighIROp.VIEW: [LowIROp.RUN_SHADER],
    HighIROp.RESHAPE: [LowIROp.RUN_SHADER],
    HighIROp.UNSQUEEZE: [LowIROp.RUN_SHADER],
    HighIROp.SQUEEZE: [LowIROp.RUN_SHADER],
    HighIROp.TRANSPOSE: [LowIROp.RUN_SHADER],
    HighIROp.PERMUTE: [LowIROp.RUN_SHADER],
    HighIROp.CONTIGUOUS: [LowIROp.RUN_SHADER],
    HighIROp.CLONE: [LowIROp.RUN_SHADER],
    HighIROp.EXPAND: [LowIROp.RUN_SHADER],
    HighIROp.CAT: [LowIROp.RUN_SHADER],
    # Tensor creation
    HighIROp.ARANGE: [LowIROp.CREATE_BUFFER, LowIROp.RUN_SHADER],
    HighIROp.FULL: [LowIROp.CREATE_BUFFER, LowIROp.RUN_SHADER],
    HighIROp.ZEROS: [LowIROp.CREATE_BUFFER, LowIROp.RUN_SHADER],
    HighIROp.ONES: [LowIROp.CREATE_BUFFER, LowIROp.RUN_SHADER],
    # Indexing
    HighIROp.GETITEM: [LowIROp.RUN_SHADER],
    HighIROp.SELECT: [LowIROp.RUN_SHADER],
    HighIROp.SLICE: [LowIROp.RUN_SHADER],
    HighIROp.INDEX: [LowIROp.RUN_SHADER],
    # Comparisons
    HighIROp.EQ: [LowIROp.RUN_SHADER],
    HighIROp.NE: [LowIROp.RUN_SHADER],
    HighIROp.LT: [LowIROp.RUN_SHADER],
    HighIROp.LE: [LowIROp.RUN_SHADER],
    HighIROp.GT: [LowIROp.RUN_SHADER],
    HighIROp.GE: [LowIROp.RUN_SHADER],
    # Masking
    HighIROp.WHERE: [LowIROp.RUN_SHADER],
    HighIROp.MASKED_FILL: [LowIROp.RUN_SHADER],
    HighIROp.TRIU: [LowIROp.RUN_SHADER],
    # Dropout
    HighIROp.DROPOUT: [LowIROp.RUN_SHADER],
    # Attention
    HighIROp.SCALED_DOT_PRODUCT_ATTENTION: [LowIROp.RUN_SHADER],
    # Casting
    HighIROp.CAST: [LowIROp.RUN_SHADER],
    # MoE ops
    HighIROp.TOPK: [LowIROp.RUN_SHADER],
    HighIROp.SCATTER: [LowIROp.RUN_SHADER],
    HighIROp.SCATTER_ADD: [LowIROp.RUN_SHADER],
    HighIROp.GATHER: [LowIROp.RUN_SHADER],
    HighIROp.ANY: [LowIROp.RUN_SHADER],
}

low_ir_op_to_low_ir_node: dict[LowIROp, type[LowIRNode]] = {
    LowIROp.CREATE_BUFFER: LowIRCreateBuffer,
    LowIROp.WRITE_BUFFER: LowIRWriteBuffer,
    LowIROp.RUN_SHADER: LowIRRunShader,
    LowIROp.MOVE_TO: LowIRMoveTo,
    LowIROp.OUTPUT: LowIROutput,
}

low_ir_compiler_passes: list[CompilerPass[LowIRNode]] = []  # TODO


def get_low_ir_node(high_ir_op: HighIROp, high_ir_node: HighIRNode):
    low_ir_ops = high_ir_op_to_low_ir_op.get(high_ir_op)
    if low_ir_ops is None:
        debug(f"Didn't find a Low IR Op mapping for High IR Op: {high_ir_op}")
        return None
    # Empty list is valid - means this op produces no low ir nodes (e.g., placeholder)
    if len(low_ir_ops) == 0:
        return []
    low_ir_nodes = []
    for op in low_ir_ops:
        ir_node_type = low_ir_op_to_low_ir_node.get(op)
        if ir_node_type:
            ir_node = ir_node_type(
                high_ir_node, value_id=high_ir_node.value_id, inputs=high_ir_node.inputs
            )
            low_ir_nodes.append(ir_node)
        else:
            debug(f"Didn't find a Low IR Node for Low IR Op: {op}")
    return low_ir_nodes


def high_ir_to_low_ir(high_ir_graph: List[HighIRNode]) -> List[LowIRNode]:
    ir_graph: list[LowIRNode] = []
    for i, node in enumerate(high_ir_graph):
        ir_nodes = get_low_ir_node(high_ir_op=node.ir_op, high_ir_node=node)
        if ir_nodes is None:
            debug(
                f"Unsupported High IR op: {node.ir_op} (node: {node}). ir_graph: {ir_graph}"
            )
            raise Exception(f"Unsupported High IR op: {node.ir_op} for node: {node}")
        # ir_nodes can be empty list for ops like PLACEHOLDER that don't produce low ir nodes
        for n in ir_nodes:
            ir_graph.append(n)
    return ir_graph


def low_ir_print_tabular(nodes: List[LowIRNode]) -> None:
    if nodes is None or len(nodes) == 0:
        debug("IR Nodes list is empty")
        return None

    # took most of the code from PyTorch torch/fx/graph.py
    try:
        from tabulate import tabulate
    except ImportError:
        debug(
            "`print_tabular` relies on the library `tabulate`, "
            "which could not be found on this machine. Run `pip "
            "install tabulate` to install the library."
        )
        raise

    node_specs = [[n.ir_op, n.high_ir_node, n.value_id, n.inputs] for n in nodes]
    debug(
        tabulate(
            node_specs,
            headers=[
                "opcode",
                "high ir node",
                "value_id",
                "inputs",
            ],
        )
        + "\n"
    )
