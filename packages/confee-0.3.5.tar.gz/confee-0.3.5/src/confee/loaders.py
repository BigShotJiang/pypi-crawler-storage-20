"""Configuration loaders for YAML, JSON, TOML and other formats."""

import json
from pathlib import Path
from typing import Any, Dict, Type, TypeVar

import yaml  # type: ignore[import-untyped]

from .config import ConfigBase

T = TypeVar("T", bound=ConfigBase)

# TOML support (Python 3.11+ built-in, or tomli for older versions)
_toml_available = False
tomllib: Any | None = None

# Python 3.12+ has built-in tomllib
try:
    import tomllib

    _toml_available = True
except ImportError:
    # tomllib should be built-in for Python 3.12+, but in rare edge cases
    # (e.g., custom Python builds), it may be unavailable. Gracefully disable
    # TOML support so the rest of the library remains functional.
    pass


class ConfigLoader:
    """Flexible configuration file loader with automatic format detection.

    Supports YAML, JSON, and TOML formats. Automatically detects format based on file extension.
    Integrates with the plugin system for custom format support.

    Examples:
        >>> # Load YAML config
        >>> data = ConfigLoader.load("config.yaml")

        >>> # Load TOML config (Python 3.11+ or with tomli)
        >>> data = ConfigLoader.load("config.toml")

        >>> # Load from pyproject.toml [tool.confee] section
        >>> data = ConfigLoader.load_pyproject("pyproject.toml")
    """

    SUPPORTED_FORMATS = {".yaml", ".yml", ".json", ".toml"}

    @staticmethod
    def detect_format(file_path: str | Path) -> str:
        """Detect configuration file format from extension."""
        path = Path(file_path)
        suffix = path.suffix.lower()

        # Check plugin registry for additional formats
        try:
            from .plugins import PluginRegistry

            plugin_extensions = set(PluginRegistry.list_extensions())
            all_formats = ConfigLoader.SUPPORTED_FORMATS | plugin_extensions
        except ImportError:
            all_formats = ConfigLoader.SUPPORTED_FORMATS

        if suffix not in all_formats:
            raise ValueError(f"Unsupported file format: {suffix}. Supported formats: {all_formats}")
        return suffix

    @staticmethod
    def load_yaml(file_path: str | Path) -> Dict[str, Any]:
        """Load YAML configuration file."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {file_path}")

        with open(path, encoding="utf-8") as f:
            try:
                data = yaml.safe_load(f)
                # YAML can return None for empty files
                return data if isinstance(data, dict) else ({} if data is None else {})
            except yaml.YAMLError as e:
                raise ValueError(f"Invalid YAML file: {file_path}\nError: {e}")

    @staticmethod
    def load_json(file_path: str | Path) -> Dict[str, Any]:
        """Load JSON configuration file."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {file_path}")

        with open(path, encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON file: {file_path}\nError: {e}")

    @staticmethod
    def load_toml(file_path: str | Path) -> Dict[str, Any]:
        """Load TOML configuration file.

        Requires Python 3.11+ or the 'tomli' package for older versions.

        Args:
            file_path: Path to TOML configuration file

        Returns:
            Configuration dictionary

        Raises:
            ImportError: If TOML support is not available
            FileNotFoundError: If file doesn't exist
            ValueError: If TOML is invalid
        """
        if not _toml_available or tomllib is None:
            raise ImportError(
                "TOML support requires Python 3.11+ or the 'tomli' package. "
                "Install it with: pip install confee[toml] or pip install tomli"
            )

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {file_path}")

        with open(path, "rb") as f:
            try:
                return tomllib.load(f)
            except ValueError as e:
                # tomllib/tomli raise TOMLDecodeError (inherits from ValueError) for invalid TOML.
                raise ValueError(f"Invalid TOML file: {file_path}\nError: {e}")

    @staticmethod
    def load_pyproject(
        file_path: str | Path = "pyproject.toml",
        tool_name: str = "confee",
    ) -> Dict[str, Any]:
        """Load configuration from pyproject.toml [tool.<name>] section.

        Args:
            file_path: Path to pyproject.toml file
            tool_name: Tool section name (default: "confee")

        Returns:
            Configuration dictionary from [tool.<name>] section

        Examples:
            >>> # pyproject.toml:
            >>> # [tool.confee]
            >>> # debug = true
            >>> # workers = 4
            >>> config = ConfigLoader.load_pyproject()
        """
        data = ConfigLoader.load_toml(file_path)
        tool_config = data.get("tool", {}).get(tool_name, {})
        return tool_config

    @staticmethod
    def load_remote(
        url: str,
        timeout: float = 30.0,
        headers: Dict[str, str] | None = None,
    ) -> Dict[str, Any]:
        """Load configuration from a remote URL (synchronous).

        Supports HTTP/HTTPS URLs. Automatically detects format from
        Content-Type header or URL extension.

        Args:
            url: Remote configuration URL
            timeout: Request timeout in seconds
            headers: Optional HTTP headers

        Returns:
            Configuration dictionary

        Examples:
            >>> config = ConfigLoader.load_remote("https://example.com/config.yaml")
        """
        import urllib.request

        req = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(req, timeout=timeout) as response:  # nosec B310
            content = response.read().decode("utf-8")
            content_type = response.headers.get("Content-Type", "")

            # Detect format from content type or URL
            if "json" in content_type or url.endswith(".json"):
                return json.loads(content)
            elif "yaml" in content_type or url.endswith((".yaml", ".yml")):
                return yaml.safe_load(content)
            elif "toml" in content_type or url.endswith(".toml"):
                if not _toml_available or tomllib is None:
                    raise ImportError("TOML support requires Python 3.11+ or 'tomli' package")
                return tomllib.loads(content)
            else:
                # Try YAML first (superset of JSON)
                try:
                    return yaml.safe_load(content)
                except Exception:
                    return json.loads(content)

    @staticmethod
    def load(file_path: str | Path, strict: bool = True) -> Dict[str, Any]:
        """Load configuration file with automatic format detection.

        Supports YAML, JSON, TOML and plugin-registered formats.

        Args:
            file_path: Path to configuration file
            strict: If True, raise error on invalid format. If False, return empty dict.

        Returns:
            Configuration dictionary
        """
        try:
            file_format = ConfigLoader.detect_format(file_path)
            path = Path(file_path)

            # Try built-in loaders first
            if file_format in {".yaml", ".yml"}:
                data = ConfigLoader.load_yaml(file_path)
            elif file_format == ".json":
                data = ConfigLoader.load_json(file_path)
            elif file_format == ".toml":
                data = ConfigLoader.load_toml(file_path)
            else:
                # Try plugin registry
                try:
                    from .plugins import PluginRegistry

                    loader = PluginRegistry.get_loader(path)
                    if loader:
                        data = loader(path) if callable(loader) else loader.load(path)
                    else:
                        return {}
                except ImportError:
                    return {}

            # Run plugin hooks if available
            try:
                from .plugins import PluginRegistry

                data = PluginRegistry.run_post_hooks(data)
            except ImportError:
                # Plugins module may not be available in minimal installations;
                # continue without running post-processing hooks.
                pass

            # Resolve file references in the loaded data
            base_dir = Path(file_path).parent
            data = ConfigLoader.resolve_file_references(data, base_dir)
            return data

        except (FileNotFoundError, ValueError) as e:
            if strict:
                raise
            print(f"Warning: Failed to load config file: {e}")
            return {}

    @staticmethod
    def resolve_file_references(
        data: Dict[str, Any],
        base_dir: Path,
        file_prefix: str = "@file:",
        _visited: frozenset[Path] | None = None,
    ) -> Dict[str, Any]:
        """Resolve file references in configuration values.

        File references use multiple formats:
        - "@file:path/to/file" - 파일 내용을 문자열로 로드
        - "@config:path/to/file.yaml" - YAML 파일을 딕셔너리로 로드

        Paths are resolved relative to base_dir.

        Args:
            data: Configuration dictionary
            base_dir: Base directory for relative path resolution
            file_prefix: Prefix for file references (default: "@file:")
            _visited: Internal parameter to track visited files for cycle detection

        Returns:
            Configuration dictionary with file references resolved

        Raises:
            RecursionError: If circular reference is detected

        Examples:
            # 텍스트 파일 로드
            # secret_key: "@file:secrets/api_key.txt"
            >>> data = {"key": "@file:values.txt"}
            >>> resolved = ConfigLoader.resolve_file_references(data, Path("."))
            >>> resolved["key"]  # Contents of values.txt

            # YAML 파일 로드
            # database: "@config:config/db.yaml"
            >>> data = {"db": "@config:config/db.yaml"}
            >>> resolved = ConfigLoader.resolve_file_references(data, Path("."))
            >>> resolved["db"]  # {'host': 'localhost', 'port': 5432, ...}
        """
        if _visited is None:
            _visited = frozenset()

        resolved: Dict[str, Any] = {}

        for key, value in data.items():
            if isinstance(value, str) and ("@" in value and ":" in value):
                # 접두사 추출
                prefix_match = None
                file_path_value = None

                if value.startswith("@file:"):
                    prefix_match = "@file:"
                    file_path_value = value[len("@file:") :]
                elif value.startswith("@config:"):
                    prefix_match = "@config:"
                    file_path_value = value[len("@config:") :]

                if prefix_match and file_path_value:
                    file_full_path = (base_dir / file_path_value).resolve()

                    try:
                        if not file_full_path.exists():
                            raise FileNotFoundError(f"Referenced file not found: {file_full_path}")

                        if prefix_match == "@file:":
                            with open(file_full_path, encoding="utf-8") as f:
                                resolved[key] = f.read().strip()

                        elif prefix_match == "@config:":
                            if file_full_path in _visited:
                                cycle_path = (
                                    " -> ".join(str(p) for p in _visited) + f" -> {file_full_path}"
                                )
                                raise RecursionError(
                                    f"Circular config reference detected: {cycle_path}"
                                )

                            new_visited = _visited | {file_full_path}
                            yaml_data = ConfigLoader.load_yaml(file_full_path)
                            resolved[key] = ConfigLoader.resolve_file_references(
                                yaml_data, file_full_path.parent, file_prefix, new_visited
                            )

                    except Exception as e:
                        if isinstance(e, RecursionError):
                            raise
                        print(f"Warning: Failed to resolve file reference {value}: {e}")
                        resolved[key] = value
                else:
                    resolved[key] = value

            elif isinstance(value, dict):
                resolved[key] = ConfigLoader.resolve_file_references(
                    value, base_dir, file_prefix, _visited
                )
            else:
                resolved[key] = value

        return resolved


def load_from_file[T: ConfigBase](
    file_path: str | Path,
    config_class: Type[T],
    strict: bool = True,
) -> T:
    """Load configuration from file into specified config class.

    Args:
        file_path: Path to configuration file (YAML or JSON)
        config_class: Pydantic config class to load into
        strict: If True, raise error on validation failure. If False, use defaults or partial config.

    Returns:
        Instance of config_class

    Examples:
        >>> class AppConfig(ConfigBase):
        ...     name: str
        ...     debug: bool = False

        >>> config = load_from_file("config.yaml", AppConfig)
    """
    data = ConfigLoader.load(file_path, strict=strict)

    try:
        return config_class(**data)
    except Exception as e:
        if strict:
            raise
        print(f"Warning: Failed to validate config: {e}")
        # In non-strict mode (strict=False), try to create with partial data if possible
        # If that fails, raise error (can't instantiate with missing required fields)
        try:
            # Try with empty dict if all fields have defaults
            return config_class()
        except Exception:
            # If that fails too, re-raise the original error since non-strict mode
            # cannot create instance without required fields
            raise e


def load_config[T: ConfigBase](
    *file_paths: str | Path,
    config_class: Type[T],
    strict: bool = True,
) -> T:
    """Load and merge multiple configuration files.

    Later files override earlier files. All files must be compatible with config_class.

    Args:
        *file_paths: Paths to configuration files
        config_class: Pydantic config class to load into
        strict: If True, raise error on validation failure

    Returns:
        Merged configuration instance

    Examples:
        >>> config = load_config(
        ...     "defaults.yaml",
        ...     "config.yaml",
        ...     config_class=AppConfig
        ... )
    """
    merged_data: Dict[str, Any] = {}

    for file_path in file_paths:
        data = ConfigLoader.load(file_path, strict=strict)
        merged_data.update(data)

    try:
        return config_class(**merged_data)
    except Exception as e:
        if strict:
            raise
        print(f"Warning: Failed to validate merged config: {e}")
        return config_class()
