"""支持断言逻辑的推理引擎"""
from kele.config import (
    Config,
    ExecutorConfig,
    GrounderConfig,
    InferenceStrategyConfig,
    KBConfig,
    PathConfig,
    RunControlConfig,
)
from kele.control import register
from kele.main import EngineRunResult, InferenceEngine, QueryStructure
from kele.syntax.base_classes import Assertion, CompoundTerm, Concept, Constant, Formula, Operator, Rule, Variable

try:
    from ._version import version as __version__
except ImportError:
    __version__ = '0.0.0'

__all__ = [
    'Assertion',
    'CompoundTerm',
    'Concept',
    'Config',
    'Constant',
    'EngineRunResult',
    'ExecutorConfig',
    'Formula',
    'GrounderConfig',
    'InferenceEngine',
    'InferenceStrategyConfig',
    'KBConfig',
    'Operator',
    'PathConfig',
    'QueryStructure',
    'Rule',
    'RunControlConfig',
    'Variable',
    'register',
]
