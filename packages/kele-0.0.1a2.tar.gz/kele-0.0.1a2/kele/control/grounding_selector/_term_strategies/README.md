## 默认strategy

### Exhausted
穷尽所有可用term的策略实现。

## 创建自己的strategy
1. 创建一个py文件，命名要求为`_<name>_strategy.py`；
2. 继承TermSelectionStrategy类，并至少声明此Protocol要求的函数；
3. 从`kele.control`导入并使用`@register.term_selector('<name>')`注册你的策略类，后续即可通过`grounding_term_strategy`使用策略；
4. 注意调整`grounding_term_strategy`的类型标注（增加Literal的候选值）。

示例：
```python
from kele.control import register
from kele.control.grounding_selector._term_strategies.strategy_protocol import TermSelectionStrategy


@register.term_selector("MyTermStrategy")
class MyTermStrategy:
    def __init__(self) -> None:
        self._terms = []

    def add_terms(self, terms):
        self._terms.extend(terms)

    def reset(self) -> None:
        self._terms = []

    def select_next(self, rule):
        return list(self._terms)

    def on_feedback(self, feedback):
        return None
```
