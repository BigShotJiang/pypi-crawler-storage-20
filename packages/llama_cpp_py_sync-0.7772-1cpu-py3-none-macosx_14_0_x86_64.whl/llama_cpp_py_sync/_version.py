"""Version information for llama-cpp-py-sync."""

__version__ = "0.7772"
__llama_cpp_commit__ = "287a33017"
__llama_cpp_tag__ = "b7772"
