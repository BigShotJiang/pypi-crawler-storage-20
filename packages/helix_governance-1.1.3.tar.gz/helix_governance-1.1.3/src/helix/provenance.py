from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

from helix.support.subprocess import no_console_kwargs

_GIT_SHA_RE = re.compile(r"^[0-9a-f]{7,64}$")
_GIT_SHA_UNSET = object()
_CACHED_GIT_SHA: str | None | object = _GIT_SHA_UNSET


def current_git_sha() -> str | None:
    """Return the current git SHA (best-effort).

    Resolution order:
    1) `HELIX_GIT_SHA` (recommended for CI/release builds)
    2) `GITHUB_SHA` (GitHub Actions)
    3) `git rev-parse HEAD` when a .git directory is present
    """

    for env_name in ("HELIX_GIT_SHA", "GITHUB_SHA"):
        raw = os.getenv(env_name)
        if not raw:
            continue
        candidate = raw.strip().lower()
        if _GIT_SHA_RE.fullmatch(candidate):
            return candidate

    global _CACHED_GIT_SHA
    cached = _CACHED_GIT_SHA
    if cached is not _GIT_SHA_UNSET:
        return cached if isinstance(cached, str) else None

    try:
        repo_root = Path(__file__).resolve().parents[2]
        if not (repo_root / ".git").exists():
            _CACHED_GIT_SHA = None
            return None
        sha = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            stderr=subprocess.DEVNULL,
            text=True,
            **no_console_kwargs(),
        ).strip().lower()
        if _GIT_SHA_RE.fullmatch(sha):
            _CACHED_GIT_SHA = sha
            return sha
    except Exception:
        _CACHED_GIT_SHA = None
        return None
    _CACHED_GIT_SHA = None
    return None


__all__ = ["current_git_sha"]
