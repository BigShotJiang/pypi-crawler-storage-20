from __future__ import annotations

import os
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Iterator

from .blob_store import BlobPutResult
from .digest import Sha256Digest, sha256_bytes


def _normalize_prefix(prefix: str | None) -> str:
    p = str(prefix or "").strip()
    p = p.strip("/")
    return p


def _s3_key(prefix: str, digest: Sha256Digest) -> str:
    base = f"blobs/sha256/{digest.hex}"
    if prefix:
        return f"{prefix}/{base}"
    return base


@dataclass(frozen=True)
class S3BlobStoreConfig:
    bucket: str
    prefix: str
    endpoint_url: str | None
    region: str | None
    addressing_style: str = "auto"
    connect_timeout_s: int = 5
    read_timeout_s: int = 60
    retry_max_attempts: int = 10
    retry_mode: str = "standard"
    strict_no_overwrite: bool = False


class S3BlobStore:
    def __init__(self, cfg: S3BlobStoreConfig) -> None:
        self._cfg = cfg

        try:
            import boto3
            from botocore.config import Config
        except Exception as exc:  # pragma: no cover
            raise RuntimeError(
                "S3 blob backend requires boto3. Install with 'pip install -e \".[s3]\"' "
                "(or include boto3 in your environment)."
            ) from exc

        region = cfg.region or os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "us-east-1"

        endpoint_url = cfg.endpoint_url or None
        addressing_style = str(cfg.addressing_style or "auto").strip().lower()
        if endpoint_url and addressing_style == "auto":
            # MinIO is typically most reliable with path-style addressing.
            addressing_style = "path"

        connect_timeout = int(cfg.connect_timeout_s)
        read_timeout = int(cfg.read_timeout_s)
        max_attempts = int(cfg.retry_max_attempts)
        retry_mode = str(cfg.retry_mode or "standard").strip()

        s3_cfg: dict[str, str] = {}
        if addressing_style in {"path", "virtual"}:
            s3_cfg["addressing_style"] = addressing_style

        client_cfg = Config(
            connect_timeout=connect_timeout,
            read_timeout=read_timeout,
            retries={"max_attempts": max_attempts, "mode": retry_mode},
            s3=s3_cfg,
        )

        self._client = boto3.client(
            "s3",
            endpoint_url=endpoint_url,
            region_name=region,
            config=client_cfg,
        )

    @classmethod
    def from_env(cls) -> "S3BlobStore":
        from helix.user_config import resolve_setting_bool, resolve_setting_int, resolve_setting_str

        bucket = str(resolve_setting_str(env_var="HELIX_S3_BUCKET", config_key="s3_bucket", default="") or "").strip()
        if not bucket:
            raise ValueError("HELIX_S3_BUCKET is required when HELIX_BLOB_BACKEND=s3")
        prefix = _normalize_prefix(resolve_setting_str(env_var="HELIX_S3_PREFIX", config_key="s3_prefix", default=""))
        endpoint_url = str(resolve_setting_str(env_var="HELIX_S3_ENDPOINT_URL", config_key="s3_endpoint_url", default="") or "").strip() or None
        region = str(os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION") or "").strip() or None

        addressing_style = str(
            resolve_setting_str(
                env_var="HELIX_S3_ADDRESSING_STYLE",
                config_key="s3_addressing_style",
                default="auto",
            )
            or "auto"
        ).strip()
        connect_timeout_s = int(
            resolve_setting_int(
                env_var="HELIX_S3_CONNECT_TIMEOUT",
                config_key="s3_connect_timeout_s",
                default=5,
            )
            or 5
        )
        read_timeout_s = int(
            resolve_setting_int(
                env_var="HELIX_S3_READ_TIMEOUT",
                config_key="s3_read_timeout_s",
                default=60,
            )
            or 60
        )
        retry_max_attempts = int(
            resolve_setting_int(
                env_var="HELIX_S3_RETRY_MAX_ATTEMPTS",
                config_key="s3_retry_max_attempts",
                default=10,
            )
            or 10
        )
        retry_mode = str(
            resolve_setting_str(
                env_var="HELIX_S3_RETRY_MODE",
                config_key="s3_retry_mode",
                default="standard",
            )
            or "standard"
        ).strip()
        strict_no_overwrite = bool(
            resolve_setting_bool(
                env_var="HELIX_S3_STRICT_NO_OVERWRITE",
                config_key="s3_strict_no_overwrite",
                default=False,
            )
            or False
        )

        return cls(
            S3BlobStoreConfig(
                bucket=bucket,
                prefix=prefix,
                endpoint_url=endpoint_url,
                region=region,
                addressing_style=addressing_style,
                connect_timeout_s=connect_timeout_s,
                read_timeout_s=read_timeout_s,
                retry_max_attempts=retry_max_attempts,
                retry_mode=retry_mode,
                strict_no_overwrite=strict_no_overwrite,
            )
        )

    def _key_for(self, digest: Sha256Digest) -> str:
        return _s3_key(self._cfg.prefix, digest)

    def _raise_for_client_error(self, exc: Exception, *, digest: Sha256Digest) -> None:
        try:
            from botocore.exceptions import ClientError
        except Exception:  # pragma: no cover
            raise

        if not isinstance(exc, ClientError):
            raise exc
        code = str((exc.response or {}).get("Error", {}).get("Code") or "")
        if code in {"404", "NoSuchKey", "NotFound"}:
            raise FileNotFoundError(digest.prefixed) from exc
        if code in {"AccessDenied", "InvalidAccessKeyId", "SignatureDoesNotMatch"}:
            raise PermissionError(f"s3 access error: {code}") from exc
        raise RuntimeError(f"s3 error: {code}") from exc

    def exists(self, digest: Sha256Digest) -> bool:
        try:
            self._client.head_object(Bucket=self._cfg.bucket, Key=self._key_for(digest))
            return True
        except Exception as exc:
            try:
                self._raise_for_client_error(exc, digest=digest)
            except FileNotFoundError:
                return False
            raise

    def put_bytes(self, data: bytes, *, expected: Sha256Digest | None = None) -> BlobPutResult:
        digest = sha256_bytes(data)
        if expected is not None and expected.hex != digest.hex:
            raise ValueError(f"sha256 mismatch (expected {expected.prefixed} computed {digest.prefixed})")

        raw_strict = os.environ.get("HELIX_S3_STRICT_NO_OVERWRITE")
        if raw_strict is not None:
            token = str(raw_strict).strip().lower()
            strict_no_overwrite = token in {"1", "true", "yes", "on"}
        else:
            strict_no_overwrite = bool(self._cfg.strict_no_overwrite)
        if strict_no_overwrite:
            # Prefer a single-call conditional write (no race window).
            try:
                self._client.put_object(Bucket=self._cfg.bucket, Key=self._key_for(digest), Body=data, IfNoneMatch="*")
                return BlobPutResult(sha256=digest, bytes=len(data))
            except Exception as exc:
                try:
                    from botocore.exceptions import ClientError
                except Exception:  # pragma: no cover
                    raise
                if isinstance(exc, ClientError):
                    code = str((exc.response or {}).get("Error", {}).get("Code") or "")
                    status = int((exc.response or {}).get("ResponseMetadata", {}).get("HTTPStatusCode") or 0)
                    if code == "PreconditionFailed" or status == 412:
                        return BlobPutResult(sha256=digest, bytes=len(data))
                self._raise_for_client_error(exc, digest=digest)
                raise  # pragma: no cover

        if self.exists(digest):
            # Content-addressed immutability: if it exists, it's already the right bytes.
            return BlobPutResult(sha256=digest, bytes=len(data))

        try:
            self._client.put_object(Bucket=self._cfg.bucket, Key=self._key_for(digest), Body=data)
        except Exception as exc:
            self._raise_for_client_error(exc, digest=digest)
        return BlobPutResult(sha256=digest, bytes=len(data))

    def get_bytes(self, digest: Sha256Digest) -> bytes:
        try:
            obj = self._client.get_object(Bucket=self._cfg.bucket, Key=self._key_for(digest))
            body = obj["Body"]
            try:
                return body.read()
            finally:
                body.close()
        except Exception as exc:
            self._raise_for_client_error(exc, digest=digest)
            raise

    def size_bytes(self, digest: Sha256Digest) -> int:
        try:
            meta = self._client.head_object(Bucket=self._cfg.bucket, Key=self._key_for(digest))
            return int(meta.get("ContentLength") or 0)
        except Exception as exc:
            self._raise_for_client_error(exc, digest=digest)
            raise

    def download_to_path(self, digest: Sha256Digest, path: Path) -> int:
        path.parent.mkdir(parents=True, exist_ok=True)
        bytes_written = 0
        try:
            obj = self._client.get_object(Bucket=self._cfg.bucket, Key=self._key_for(digest))
            body = obj["Body"]
            try:
                with path.open("wb") as handle:
                    while True:
                        chunk = body.read(1024 * 1024)
                        if not chunk:
                            break
                        handle.write(chunk)
                        bytes_written += len(chunk)
            finally:
                body.close()
        except Exception as exc:
            self._raise_for_client_error(exc, digest=digest)
            raise
        return bytes_written

    @contextmanager
    def open_reader(self, digest: Sha256Digest) -> Iterator[BinaryIO]:
        try:
            obj = self._client.get_object(Bucket=self._cfg.bucket, Key=self._key_for(digest))
            body = obj["Body"]
            try:
                yield body
            finally:
                body.close()
        except Exception as exc:
            self._raise_for_client_error(exc, digest=digest)
            raise
