from __future__ import annotations

import os
import shutil
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, ContextManager, Iterator, Protocol

from helix import temp
from .digest import Sha256Digest, sha256_bytes


@dataclass(frozen=True)
class BlobPutResult:
    sha256: Sha256Digest
    bytes: int


class BlobStore(Protocol):
    def exists(self, digest: Sha256Digest) -> bool: ...

    def put_bytes(self, data: bytes, *, expected: Sha256Digest | None = None) -> BlobPutResult: ...

    def get_bytes(self, digest: Sha256Digest) -> bytes: ...

    def size_bytes(self, digest: Sha256Digest) -> int: ...

    def download_to_path(self, digest: Sha256Digest, path: Path) -> int: ...

    def open_reader(self, digest: Sha256Digest) -> ContextManager[BinaryIO]: ...


class ContentAddressedBlobStore:
    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    def _path_for(self, digest: Sha256Digest) -> Path:
        return self._root / digest.hex[:2] / digest.hex[2:]

    def exists(self, digest: Sha256Digest) -> bool:
        return self._path_for(digest).exists()

    def put_bytes(self, data: bytes, *, expected: Sha256Digest | None = None) -> BlobPutResult:
        digest = sha256_bytes(data)
        if expected is not None and expected.hex != digest.hex:
            raise ValueError(f"sha256 mismatch (expected {expected.prefixed} computed {digest.prefixed})")

        path = self._path_for(digest)
        if path.exists():
            # Content-addressed immutability: if it exists, it's already the right bytes.
            return BlobPutResult(sha256=digest, bytes=len(data))

        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = temp.mkstemp(prefix="blob_", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(data)
            os.replace(tmp_path, path)
        finally:
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass

        return BlobPutResult(sha256=digest, bytes=len(data))

    def get_bytes(self, digest: Sha256Digest) -> bytes:
        return self._path_for(digest).read_bytes()

    def size_bytes(self, digest: Sha256Digest) -> int:
        return self._path_for(digest).stat().st_size

    def download_to_path(self, digest: Sha256Digest, path: Path) -> int:
        src = self._path_for(digest)
        if not src.exists():
            raise FileNotFoundError(src)
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, path)
        return src.stat().st_size

    @contextmanager
    def open_reader(self, digest: Sha256Digest) -> Iterator[BinaryIO]:
        with self._path_for(digest).open("rb") as handle:
            yield handle


def get_blob_store(*, blob_root: Path) -> BlobStore:
    from helix.user_config import resolve_setting_str

    backend = str(
        resolve_setting_str(
            env_var="HELIX_BLOB_BACKEND",
            config_key="blob_backend",
            default="fs",
        )
        or "fs"
    ).strip().lower()
    if backend in {"fs", "filesystem"}:
        return ContentAddressedBlobStore(blob_root)
    if backend == "s3":
        from .blob_store_s3 import S3BlobStore

        return S3BlobStore.from_env()
    raise ValueError(f"unknown HELIX_BLOB_BACKEND: {backend!r}")
