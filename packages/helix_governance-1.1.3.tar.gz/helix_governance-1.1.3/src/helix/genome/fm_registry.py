"""Lightweight FM-index registry keyed by genome_id.

Persists a tiny JSON file under ~/.helix (or HELIX_REGISTRY_DIR) that records
the 2bit path plus any built FM index for that genome. This keeps CRISPR/Prime
tools and Helix Studio aligned on genome identity without manual file picking.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Optional, Callable
import subprocess
import shlex
import re
import sys

from helix import clock
from helix.determinism import allow_nondeterminism
from helix.support.subprocess import no_console_kwargs

from .ingest import GenomeIngestResult


def _registry_dir() -> Path:
    env = os.environ.get("HELIX_REGISTRY_DIR")
    return Path(env).expanduser() if env else Path.home() / ".helix"


def _registry_path() -> Path:
    return _registry_dir() / "genomes_registry.json"


@dataclass
class GenomeIndexEntry:
    genome_id: str
    two_bit_path: Path
    fm_index: Optional[Path] = None
    mode: str | None = None
    params: Dict[str, str] | None = None

    def to_json(self) -> Dict[str, str]:
        data = asdict(self)
        data["two_bit_path"] = str(self.two_bit_path)
        data["fm_index"] = str(self.fm_index) if self.fm_index else ""
        if data.get("params") is None:
            data["params"] = {}
        return data

    @staticmethod
    def from_json(genome_id: str, payload: Dict[str, str]) -> "GenomeIndexEntry":
        return GenomeIndexEntry(
            genome_id=genome_id,
            two_bit_path=Path(payload.get("two_bit_path") or payload.get("two_bit") or ""),
            fm_index=Path(payload.get("fm_index")) if payload.get("fm_index") else None,
            mode=payload.get("mode"),
            params=payload.get("params"),
        )


def load_registry() -> Dict[str, GenomeIndexEntry]:
    path = _registry_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text())
    except Exception:
        return {}
    genomes = data.get("genomes", {}) if isinstance(data, dict) else {}
    out: Dict[str, GenomeIndexEntry] = {}
    for gid, payload in genomes.items():
        if not isinstance(payload, dict):
            continue
        out[gid] = GenomeIndexEntry.from_json(gid, payload)
    return out


def save_registry(entries: Dict[str, GenomeIndexEntry]) -> None:
    path = _registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {gid: entry.to_json() for gid, entry in entries.items()}
    wrapped = {"genomes": payload}
    path.write_text(json.dumps(wrapped, indent=2))


def register_ingest_result(result: GenomeIngestResult) -> GenomeIndexEntry:
    entries = load_registry()
    entry = entries.get(result.genome_id) or GenomeIndexEntry(genome_id=result.genome_id, two_bit_path=result.two_bit_path)
    entry.two_bit_path = result.two_bit_path
    entries[result.genome_id] = entry
    save_registry(entries)
    return entry


def set_fm_index(genome_id: str, fm_index_path: Path, mode: str | None = None, params: Dict[str, str] | None = None) -> None:
    entries = load_registry()
    entry = entries.get(genome_id)
    if entry is None:
        entry = GenomeIndexEntry(genome_id=genome_id, two_bit_path=fm_index_path)
    entry.fm_index = fm_index_path
    if mode:
        entry.mode = mode
    if params:
        merged = dict(entry.params or {})
        merged.update(params)
        entry.params = merged
    entries[genome_id] = entry
    save_registry(entries)


def _parse_percent(line: str, last: int) -> int:
    match = re.search(r"(\d{1,3})\s*%", line)
    if not match:
        match = re.search(r"(\d{1,3})\s*percent", line, flags=re.IGNORECASE)
    if match:
        pct = int(match.group(1))
        return max(last, min(100, pct))
    return last


def build_fm_index_with_progress(
    genome_id: str,
    two_bit_path: Path,
    *,
    progress_cb: Callable[[int], None] | None = None,
    cancel_cb: Callable[[], bool] | None = None,
    quiet: bool = False,
    idle_timeout_s: float = 120.0,
) -> Path:
    """Invoke the real FM index builder CLI and stream progress.

    The builder command is configurable via HELIX_FM_BUILD_CMD, defaulting to
    `ogn_fm_build --input <twoBit> --output <out>`.
    """

    out_path = _registry_dir() / "fm" / f"{genome_id}.fmidx"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    cmd_template = os.environ.get("HELIX_FM_BUILD_CMD", "ogn_fm_build --input {input} --output {output}")
    cmd = cmd_template.format(input=shlex.quote(str(two_bit_path)), output=shlex.quote(str(out_path)))
    builder_label = Path(shlex.split(cmd)[0]).name if cmd else "fm_builder"

    proc = subprocess.Popen(
        shlex.split(cmd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        **no_console_kwargs(),
    )

    last_pct = 0
    with allow_nondeterminism(reason="genome:fm_build"):
        last_output_ts = clock.unix_time_s()
    recent_lines: list[str] = []
    try:
        if progress_cb:
            progress_cb(0)
        assert proc.stdout is not None
        for line in proc.stdout:
            recent_lines.append(line.rstrip())
            if len(recent_lines) > 8:
                recent_lines.pop(0)
            with allow_nondeterminism(reason="genome:fm_build"):
                last_output_ts = clock.unix_time_s()
            if cancel_cb and cancel_cb():
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                raise RuntimeError("fm build cancelled")
            last_pct = _parse_percent(line, last_pct)
            if progress_cb:
                progress_cb(last_pct)
            if idle_timeout_s:
                with allow_nondeterminism(reason="genome:fm_build"):
                    now = clock.unix_time_s()
                if (now - last_output_ts) > idle_timeout_s:
                    proc.kill()
                    raise RuntimeError("fm build stalled (idle timeout)")
        code = proc.wait()
        if code != 0:
            trailer = " | ".join(recent_lines[-4:]) if recent_lines else ""
            raise RuntimeError(f"fm build failed (exit {code}) {trailer}")
    except Exception:
        if proc.poll() is None:
            proc.kill()
        raise

    if progress_cb:
        progress_cb(100)
    # record builder metadata
    try:
        set_fm_index(
            genome_id,
            out_path,
            mode="whole_genome",
            params={"builder": builder_label, "cmd": cmd_template},
        )
    except Exception:
        pass
    return out_path


def resolve_fm_index(genome_id: str) -> Optional[Path]:
    entry = load_registry().get(genome_id)
    if entry and entry.fm_index and entry.fm_index.exists():
        return entry.fm_index
    return None


def resolve_two_bit(genome_id: str) -> Optional[Path]:
    entry = load_registry().get(genome_id)
    if entry and entry.two_bit_path.exists():
        return entry.two_bit_path
    return None
