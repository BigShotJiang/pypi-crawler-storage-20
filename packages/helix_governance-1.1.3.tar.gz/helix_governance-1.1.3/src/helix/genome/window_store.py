"""Memory-map 2bit genomes and provide windowed access."""

from __future__ import annotations

import mmap
import struct
from pathlib import Path
from typing import Dict, Iterator, NamedTuple


class GenomeWindow(NamedTuple):
    chrom: str
    start: int  # zero-based, inclusive
    end: int    # exclusive
    sequence: bytes  # decoded ASCII bases or packed bytes
    packed: bool


class GenomeWindowStore:
    def __init__(self, two_bit_path: Path, genome_id: str | None = None):
        self.path = Path(two_bit_path).resolve()
        self.genome_id = genome_id or self.path.stem
        self._fh = self.path.open("rb")
        self._map = mmap.mmap(self._fh.fileno(), 0, access=mmap.ACCESS_READ)
        self._index = self._parse_index()

    def close(self) -> None:
        try:
            self._map.close()
            self._fh.close()
        except Exception:
            pass

    def chrom_sizes(self) -> Dict[str, int]:
        return {name: meta["dna_size"] for name, meta in self._index.items()}

    def _parse_index(self) -> Dict[str, Dict[str, int]]:
        data = self._map
        sig, ver, count, _ = struct.unpack(">IIII", data[:16])
        if sig != 0x1A412743:
            raise ValueError("Invalid 2bit signature")
        if ver != 0:
            raise ValueError("Unsupported 2bit version")
        offset = 16
        entries = []
        for _ in range(count):
            name_len = data[offset]
            offset += 1
            name = data[offset : offset + name_len].decode("ascii")
            offset += name_len
            seq_offset = struct.unpack(">I", data[offset : offset + 4])[0]
            offset += 4
            entries.append((name, seq_offset))

        index: Dict[str, Dict[str, int]] = {}
        for name, seq_offset in entries:
            dna_size = struct.unpack(">I", data[seq_offset : seq_offset + 4])[0]
            n_count = struct.unpack(">I", data[seq_offset + 4 : seq_offset + 8])[0]
            idx = seq_offset + 8
            n_starts = struct.unpack(">" + "I" * n_count, data[idx : idx + 4 * n_count]) if n_count else ()
            idx += 4 * n_count
            n_sizes = struct.unpack(">" + "I" * n_count, data[idx : idx + 4 * n_count]) if n_count else ()
            idx += 4 * n_count
            mask_count = struct.unpack(">I", data[idx : idx + 4])[0]
            idx += 4 + 4 * mask_count * 2  # skip mask blocks
            idx += 4  # reserved
            packed_offset = idx
            packed_len = ((dna_size + 3) // 4)
            index[name] = {
                "offset": packed_offset,
                "dna_size": dna_size,
                "packed_len": packed_len,
                "seq_offset": seq_offset,
                "n_starts": n_starts,
                "n_sizes": n_sizes,
            }
        return index

    def get_window(self, chrom: str, start: int, length: int, *, packed: bool = False) -> GenomeWindow:
        meta = self._index.get(chrom)
        if meta is None:
            raise KeyError(f"chromosome not found: {chrom}")
        start = max(0, start)
        end = min(meta["dna_size"], start + max(0, length))
        if end <= start:
            return GenomeWindow(chrom, start, start, b"", packed)

        byte_start = meta["offset"] + (start // 4)
        byte_end = meta["offset"] + ((end + 3) // 4)
        packed_view = memoryview(self._map)[byte_start:byte_end]

        if packed:
            return GenomeWindow(chrom, start, end, packed_view.tobytes(), True)

        # decode only the needed bases
        base_map = b"TCAG"
        rel_start = start % 4
        needed = end - start
        out = bytearray(needed)
        out_idx = 0
        for byte in packed_view:
            for shift in (6, 4, 2, 0):
                if rel_start > 0:
                    rel_start -= 1
                    continue
                out[out_idx] = base_map[(byte >> shift) & 0b11]
                out_idx += 1
                if out_idx >= needed:
                    break
            if out_idx >= needed:
                break
        return GenomeWindow(chrom, start, end, bytes(out), False)

    def iter_windows(self, chrom: str, window_size: int, stride: int, *, packed: bool = False) -> Iterator[GenomeWindow]:
        meta = self._index.get(chrom)
        if meta is None:
            raise KeyError(f"chromosome not found: {chrom}")
        pos = 0
        while pos < meta["dna_size"]:
            yield self.get_window(chrom, pos, window_size, packed=packed)
            pos += stride
