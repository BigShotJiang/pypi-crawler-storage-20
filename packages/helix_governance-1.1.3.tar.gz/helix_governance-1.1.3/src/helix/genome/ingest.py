"""Stream FASTA to 2bit with caching and metadata.

This is a lightweight, dependency-free 2bit writer that handles Ns
via nBlocks and produces a UCSC-compatible 2bit file. It avoids
buffering entire genomes in RAM by packing each contig to a temp file
and then emitting the final 2bit with proper offsets.
"""

from __future__ import annotations

import hashlib
import io
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Tuple

from helix import temp
_TWOBIT_SIG = 0x1A412743
_TWOBIT_VER = 0


@dataclass
class GenomeIngestResult:
    genome_id: str
    two_bit_path: Path
    chrom_sizes: Dict[str, int]
    total_bp: int
    source_fasta: Path


def _pack_sequence(
    seq_iter,
    *,
    tmp_dir: Path | None = None,
    cancel_cb: Callable[[], bool] | None = None,
) -> Tuple[Path, int, List[int], List[int]]:
    """Pack bases into a temp file (2 bits/base). Returns (tmp_path, bp_len, n_starts, n_sizes)."""
    fd, tmp_path = temp.mkstemp(prefix="helix_ingest_", dir=(tmp_dir or temp.gettempdir()))
    tmp = os.fdopen(fd, "wb")

    n_starts: List[int] = []
    n_sizes: List[int] = []
    in_n = False
    n_run_start = 0
    n_run_len = 0

    bp_len = 0
    buf = 0
    count = 0
    base_map = {"T": 0, "t": 0, "C": 1, "c": 1, "A": 2, "a": 2, "G": 3, "g": 3}

    def _flush_byte(bcount, bbuf):
        if bcount:
            tmp.write(bytes([bbuf << (8 - bcount * 2)]))

    for chunk in seq_iter:
        for ch in chunk:
            if cancel_cb is not None and cancel_cb():
                raise RuntimeError("ingest cancelled")

            is_n = ch not in base_map
            if is_n:
                if not in_n:
                    n_run_start = bp_len
                    n_run_len = 1
                    in_n = True
                else:
                    n_run_len += 1
            else:
                if in_n:
                    n_starts.append(n_run_start)
                    n_sizes.append(n_run_len)
                    in_n = False
                code = base_map[ch]
                buf = (buf << 2) | code
                count += 1
                if count == 4:
                    tmp.write(bytes([buf]))
                    buf = 0
                    count = 0
            bp_len += 1

    if in_n:
        n_starts.append(n_run_start)
        n_sizes.append(n_run_len)

    _flush_byte(count, buf)
    tmp.flush()
    tmp.close()
    return tmp_path, bp_len, n_starts, n_sizes


def _iter_fasta_sequences(path: Path):
    name = None
    buf: List[str] = []
    with path.open("r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith(">"):
                if name is not None:
                    yield name, buf
                name = line[1:].strip().split()[0]
                buf = []
            else:
                buf.append(line.strip())
        if name is not None:
            yield name, buf


def ingest_fasta_to_2bit(
    path: Path,
    dest_dir: Path | None = None,
    progress_cb: Callable[[int], None] | None = None,
    cancel_cb: Callable[[], bool] | None = None,
) -> GenomeIngestResult:
    """Stream FASTA to 2bit. Optionally emit percent progress via callback."""

    path = path.resolve()
    if dest_dir is None:
        dest_dir = Path.home() / ".helix" / "genomes"
    dest_dir.mkdir(parents=True, exist_ok=True)

    total_bp_est = None
    if progress_cb is not None:
        # Light-weight pre-pass to estimate total bases for progress
        try:
            total_bp_est = 0
            with path.open("r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if not line or line.startswith(">"):  # headers are skipped
                        continue
                    total_bp_est += len(line.strip())
        except Exception:
            total_bp_est = None

    sha = hashlib.sha256()
    chrom_meta = []  # list of (name, tmp_path, bp_len, n_starts, n_sizes)
    total_bp = 0
    processed_bp = 0

    for name, lines in _iter_fasta_sequences(path):
        def line_iter():
            nonlocal processed_bp
            for ln in lines:
                sha.update(ln.encode("utf-8"))
                processed_bp += len(ln)
                if progress_cb is not None and total_bp_est:
                    if processed_bp % 500_000 == 0:  # throttle updates
                        progress_cb(min(99, int(processed_bp * 100 / total_bp_est)))
                yield ln

        tmp_root = dest_dir / ".tmp_ingest"
        tmp_root.mkdir(parents=True, exist_ok=True)
        tmp_path, bp_len, n_starts, n_sizes = _pack_sequence(line_iter(), tmp_dir=tmp_root, cancel_cb=cancel_cb)
        chrom_meta.append((name, tmp_path, bp_len, n_starts, n_sizes))
        total_bp += bp_len

    genome_id = sha.hexdigest()
    two_bit_path = dest_dir / f"{path.stem}-{genome_id[:12]}.2bit"

    # Build offsets
    header_size = 16
    index_size = 0
    for name, _, _, _, _ in chrom_meta:
        index_size += 1 + len(name) + 4  # nameLen byte + name + offset uint32

    offsets = []
    current_offset = header_size + index_size

    for name, tmp_path, bp_len, n_starts, n_sizes in chrom_meta:
        n_count = len(n_starts)
        seq_record_size = (
            4  # dnaSize
            + 4  # nBlockCount
            + n_count * 4  # nStarts
            + n_count * 4  # nSizes
            + 4  # maskBlockCount
            + 4  # reserved
        )
        packed_bytes = tmp_path.stat().st_size
        seq_record_size += packed_bytes
        offsets.append(current_offset)
        current_offset += seq_record_size

    with two_bit_path.open("wb") as out:
        out.write(_TWOBIT_SIG.to_bytes(4, "big"))
        out.write(_TWOBIT_VER.to_bytes(4, "big"))
        out.write(len(chrom_meta).to_bytes(4, "big"))
        out.write((0).to_bytes(4, "big"))

        # index
        for (name, _, _, _, _), offset in zip(chrom_meta, offsets):
            out.write(len(name).to_bytes(1, "big"))
            out.write(name.encode("ascii", "ignore"))
            out.write(offset.to_bytes(4, "big"))

        # sequences
        for (name, tmp_path, bp_len, n_starts, n_sizes), offset in zip(chrom_meta, offsets):
            n_count = len(n_starts)
            out.write(bp_len.to_bytes(4, "big"))
            out.write(n_count.to_bytes(4, "big"))
            for v in n_starts:
                out.write(v.to_bytes(4, "big"))
            for v in n_sizes:
                out.write(v.to_bytes(4, "big"))
            out.write((0).to_bytes(4, "big"))  # maskBlockCount
            out.write((0).to_bytes(4, "big"))  # reserved
            with tmp_path.open("rb") as temp_in:
                out.write(temp_in.read())

    # cleanup temp files
    for _, tmp_path, _, _, _ in chrom_meta:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
    try:
        tmp_root = dest_dir / ".tmp_ingest"
        tmp_root.rmdir()
    except Exception:
        pass

    if progress_cb is not None:
        progress_cb(100)

    chrom_sizes = {name: bp_len for name, _, bp_len, _, _ in chrom_meta}
    return GenomeIngestResult(
        genome_id=genome_id,
        two_bit_path=two_bit_path,
        chrom_sizes=chrom_sizes,
        total_bp=total_bp,
        source_fasta=path,
    )
