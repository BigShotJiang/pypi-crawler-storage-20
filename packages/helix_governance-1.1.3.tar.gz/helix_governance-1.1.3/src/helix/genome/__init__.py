"""Genome ingest and window access helpers."""

from .ingest import ingest_fasta_to_2bit, GenomeIngestResult
from .window_store import GenomeWindowStore, GenomeWindow
from .fm_registry import (
    GenomeIndexEntry,
    load_registry,
    save_registry,
    register_ingest_result,
    set_fm_index,
    resolve_fm_index,
    resolve_two_bit,
    build_fm_index_with_progress,
)

__all__ = [
    "ingest_fasta_to_2bit",
    "GenomeIngestResult",
    "GenomeWindowStore",
    "GenomeWindow",
    "GenomeIndexEntry",
    "load_registry",
    "save_registry",
    "register_ingest_result",
    "set_fm_index",
    "resolve_fm_index",
    "resolve_two_bit",
    "build_fm_index_with_progress",
]
