from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Mapping

from helix import __version__
from helix.provenance import current_git_sha


def build_meta_path() -> Path | None:
    """Return the on-disk build metadata file path when present."""

    override = os.getenv("HELIX_BUILD_META_PATH")
    if override:
        path = Path(override).expanduser()
        if path.exists():
            return path

    if getattr(sys, "frozen", False):  # PyInstaller / frozen apps
        base = Path(sys.executable).resolve().parent
        candidate = base / "helix_build_meta.json"
        if candidate.exists():
            return candidate

    return None


def load_build_meta() -> Mapping[str, Any] | None:
    path = build_meta_path()
    if path is None:
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if isinstance(data, Mapping):
        return data
    return None


def build_info() -> dict[str, str]:
    meta = dict(load_build_meta() or {})
    build_date = str(meta.get("build_date_utc") or "")
    sha = str(meta.get("git_sha") or "") or (current_git_sha() or "")
    return {
        "helix_version": __version__,
        "git_sha": sha,
        "build_date_utc": build_date,
    }

def is_enterprise_build() -> bool:
    """
    Return True when this build should enforce enterprise-only safety defaults.

    This is intentionally conservative: it only returns True when explicitly configured
    via environment variable or build metadata.
    """

    env = str(os.getenv("HELIX_ENTERPRISE_BUILD") or "").strip().lower()
    if env in {"1", "true", "yes", "on"}:
        return True

    meta = load_build_meta()
    if not isinstance(meta, Mapping):
        return False
    edition = str(meta.get("edition") or meta.get("channel") or "").strip().lower()
    if edition in {"enterprise", "ent"}:
        return True
    return bool(meta.get("enterprise", False))


__all__ = ["build_meta_path", "load_build_meta", "build_info", "is_enterprise_build"]
