from __future__ import annotations

import json
import os
import platform
import re
import sys
import traceback
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any

from helix import __version__
from helix import fs
from helix import clock
from helix.determinism import allow_nondeterminism
from helix.provenance import current_git_sha

_TOKEN_RE = re.compile(r"(gh[a-z]_[A-Za-z0-9_]{16,}|github_pat_[A-Za-z0-9_]{16,}|sk-[A-Za-z0-9_-]{16,})")
_DNA_RE = re.compile(r"([ACGTNacgtn]{50,})")


@dataclass(frozen=True)
class CrashRecordRef:
    path: Path
    created_at_utc: str


def crash_dir() -> Path:
    override = os.getenv("HELIX_CRASH_DIR")
    if override:
        root = Path(override).expanduser()
    else:
        root = Path.home() / ".helix" / "crashes"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _redact_text(value: str) -> str:
    def _token_repl(match: re.Match[str]) -> str:
        _ = match.group(0)
        return "<redacted:token>"

    def _dna_repl(match: re.Match[str]) -> str:
        seq = match.group(0)
        digest = sha256(seq.encode("utf-8")).hexdigest()[:12]
        return f"<redacted:dna len={len(seq)} sha256={digest}>"

    value = _TOKEN_RE.sub(_token_repl, value)
    value = _DNA_RE.sub(_dna_repl, value)
    return value


def write_crash_record(
    exc_type: type[BaseException],
    exc_value: BaseException,
    exc_tb,
    *,
    context: dict[str, Any] | None = None,
) -> CrashRecordRef:
    """Persist a crash record to disk and return its reference."""

    with allow_nondeterminism(reason="support:crash_record"):
        created_at = _utc_now_iso()
    sha = current_git_sha()
    tb_str = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))

    record: dict[str, Any] = {
        "schema": {"kind": "helix.crash.v1", "version": 1},
        "created_at_utc": created_at,
        "helix_version": __version__,
        "git_sha": sha,
        "platform": platform.platform(),
        "python": {
            "executable": sys.executable,
            "version": platform.python_version(),
            "prefix": sys.prefix,
            "base_prefix": getattr(sys, "base_prefix", ""),
        },
        "argv": list(sys.argv),
        "exception": {
            "type": getattr(exc_type, "__name__", str(exc_type)),
            "message": str(exc_value),
        },
        "traceback": tb_str,
        "context": dict(context or {}),
    }

    # Redact obvious secrets from strings before writing to disk.
    record["exception"]["message"] = _redact_text(str(record["exception"]["message"]))
    record["traceback"] = _redact_text(str(record["traceback"]))

    crash_root = crash_dir()
    with allow_nondeterminism(reason="support:crash_record"):
        filename = f"crash_{clock.local_now_stamp()}_{os.getpid()}.json"
    out = crash_root / filename
    tmp = out.with_suffix(".tmp")
    payload = json.dumps(record, indent=2, sort_keys=True) + "\n"
    with open(tmp, "w", encoding="utf-8") as handle:
        handle.write(payload)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except Exception:
            pass
    tmp.replace(out)
    _prune_old_crashes(crash_root)
    return CrashRecordRef(path=out, created_at_utc=created_at)


def _prune_old_crashes(root: Path, *, keep: int = 25) -> None:
    try:
        files = [p for p in fs.iterdir_sorted(root) if p.is_file() and p.name.startswith("crash_") and p.suffix == ".json"]
    except Exception:
        return
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0.0, reverse=True)
    for extra in files[keep:]:
        try:
            extra.unlink()
        except Exception:
            continue


def latest_crash() -> CrashRecordRef | None:
    root = crash_dir()
    try:
        files = [p for p in fs.iterdir_sorted(root) if p.is_file() and p.name.startswith("crash_") and p.suffix == ".json"]
    except Exception:
        return None
    if not files:
        return None
    files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0.0, reverse=True)
    newest = files[0]
    try:
        data = json.loads(newest.read_text(encoding="utf-8"))
        created_at = str(data.get("created_at_utc") or "")
    except Exception:
        created_at = ""
    return CrashRecordRef(path=newest, created_at_utc=created_at)


def format_crash_text(path: Path) -> str:
    """Return a human-readable crash report suitable for clipboard/support."""
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return f"Crash report unreadable: {path}"

    created = raw.get("created_at_utc", "")
    exc = raw.get("exception", {}) if isinstance(raw, dict) else {}
    exc_type = exc.get("type", "")
    exc_msg = exc.get("message", "")
    tb = raw.get("traceback", "")
    header = [
        "Helix Studio crash report",
        f"created_at_utc: {created}",
        f"exception: {exc_type}: {exc_msg}",
        f"path: {path}",
        "",
    ]
    return "\n".join(header) + str(tb)


__all__ = [
    "CrashRecordRef",
    "crash_dir",
    "write_crash_record",
    "latest_crash",
    "format_crash_text",
]
