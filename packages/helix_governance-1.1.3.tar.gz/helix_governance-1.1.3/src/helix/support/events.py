from __future__ import annotations

import json
import os
import re
import threading
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping

from helix import __version__
from helix import clock

_TOKEN_RE = re.compile(r"(gh[a-z]_[A-Za-z0-9_]{16,}|github_pat_[A-Za-z0-9_]{16,}|sk-[A-Za-z0-9_-]{16,})")
_DNA_RE = re.compile(r"([ACGTNacgtn]{50,})")
_SENSITIVE_KEY_MARKERS = (
    "token",
    "secret",
    "password",
    "passwd",
    "api_key",
    "apikey",
    "access_key",
    "private_key",
    "bearer",
)
_PAYLOAD_KEY_MARKERS = (
    "sequence",
    "seq",
)
_DEFAULT_MAX_BYTES = 512_000
_DEFAULT_KEEP_FILES = 5
_WRITE_LOCK = threading.Lock()


@dataclass(frozen=True)
class EventRecord:
    ts_utc: str
    name: str
    props: Mapping[str, Any]


def events_dir() -> Path:
    override = os.getenv("HELIX_EVENTS_DIR")
    if override:
        root = Path(override).expanduser()
    else:
        root = Path.home() / ".helix" / "events"
    root.mkdir(parents=True, exist_ok=True)
    return root


def events_path() -> Path:
    return events_dir() / "events.jsonl"


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _truncate_digest(value: str) -> str:
    return sha256(value.encode("utf-8")).hexdigest()[:12]


def _sanitize_string(value: str) -> str:
    """Return a metadata-only placeholder for any string payload."""

    if _TOKEN_RE.search(value):
        return "<redacted:token>"

    dna_matches = list(_DNA_RE.finditer(value))
    if dna_matches:
        seq = max(dna_matches, key=lambda m: len(m.group(0))).group(0)
        digest = _truncate_digest(seq)
        return f"<redacted:sequence len={len(seq)} sha256={digest}>"

    digest = _truncate_digest(value)
    return f"<redacted:str len={len(value)} sha256={digest}>"


def _sanitize_payload_value(value: Any) -> str:
    if isinstance(value, str):
        return _sanitize_string(value)
    if isinstance(value, (int, float, bool)) or value is None:
        return f"<redacted:payload type={type(value).__name__} value={value}>"
    digest = _truncate_digest(str(value))
    return f"<redacted:payload type={type(value).__name__} sha256={digest}>"


def _sanitize_value(value: Any) -> Any:
    if isinstance(value, str):
        return _sanitize_string(value)
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    digest = _truncate_digest(str(value))
    return f"<redacted:{type(value).__name__} sha256={digest}>"


def _sanitize_props(props: Mapping[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in props.items():
        key_str = str(key)
        key_lower = key_str.lower()
        if any(marker in key_lower for marker in _SENSITIVE_KEY_MARKERS):
            out[key_str] = "<redacted>"
        elif any(marker in key_lower for marker in _PAYLOAD_KEY_MARKERS):
            out[key_str] = _sanitize_payload_value(value)
        else:
            out[key_str] = _sanitize_value(value)
    return out


def _rotated_path(path: Path, idx: int) -> Path:
    return path.with_name(f"{path.stem}.{idx}{path.suffix}")


def _rotate_if_needed(path: Path) -> None:
    try:
        max_bytes = int(os.getenv("HELIX_EVENTS_MAX_BYTES", str(_DEFAULT_MAX_BYTES)))
    except Exception:
        max_bytes = _DEFAULT_MAX_BYTES
    try:
        keep = int(os.getenv("HELIX_EVENTS_KEEP", str(_DEFAULT_KEEP_FILES)))
    except Exception:
        keep = _DEFAULT_KEEP_FILES

    max_bytes = max(0, max_bytes)
    keep = max(0, keep)

    if max_bytes <= 0 or not path.exists():
        return

    try:
        size = path.stat().st_size
    except Exception:
        return
    if size < max_bytes:
        return

    if keep <= 0:
        try:
            path.unlink()
        except Exception:
            pass
        return

    for idx in range(keep, 0, -1):
        candidate = _rotated_path(path, idx)
        if idx == keep and candidate.exists():
            try:
                candidate.unlink()
            except Exception:
                pass

        if idx > 1:
            src = _rotated_path(path, idx - 1)
            dst = candidate
            if src.exists():
                try:
                    src.replace(dst)
                except Exception:
                    pass

    try:
        path.replace(_rotated_path(path, 1))
    except Exception:
        pass


def log_event(name: str, **props: Any) -> None:
    """Append a minimal, local-first event record to ~/.helix/events/events.jsonl."""

    if os.getenv("HELIX_EVENT_LOG", "1") != "1":
        return

    record = {
        "schema": {"kind": "helix.event.v1", "version": 1},
        "ts_utc": _utc_now_iso(),
        "helix_version": __version__,
        "name": str(name),
        "props": _sanitize_props(props),
    }
    path = events_path()
    line = json.dumps(record, sort_keys=True)

    with _WRITE_LOCK:
        _rotate_if_needed(path)
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(line + "\n")


__all__ = ["EventRecord", "events_dir", "events_path", "log_event"]
