from __future__ import annotations

import json
import os
import platform
import re
import sys
import zipfile
from dataclasses import dataclass
from hashlib import sha256
from importlib import metadata
from pathlib import Path
from typing import Any, Mapping

from helix import __version__
from helix import fs
from helix import clock
from helix.determinism import allow_nondeterminism
from helix.support.doctor import render_doctor_report
from helix.studio.session_io import _ensure_contract_identity
from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_artifact,
    extract_decision_grade_proof_from_summary,
    governance_stamp_lines,
    interpretation_for_mode,
    normalize_decision_mode,
)

_FIXED_ZIP_DT = (2020, 1, 1, 0, 0, 0)


@dataclass(frozen=True)
class BundleEntry:
    path: str
    sha256: str
    bytes: int
    redacted: bool = False
    source: str | None = None


_DNA_RE = re.compile(r"([ACGTNacgtn]{50,})")
_TOKEN_RE = re.compile(r"(gh[a-z]_[A-Za-z0-9_]{16,}|github_pat_[A-Za-z0-9_]{16,}|sk-[A-Za-z0-9_-]{16,})")
_SENSITIVE_KEY_MARKERS = (
    "token",
    "secret",
    "password",
    "passwd",
    "api_key",
    "apikey",
    "access_key",
    "private_key",
    "bearer",
)


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _sha256_bytes(data: bytes) -> str:
    return sha256(data).hexdigest()


def _zip_write_bytes(zf: zipfile.ZipFile, arcname: str, data: bytes) -> None:
    name = arcname.replace(os.sep, "/")
    info = zipfile.ZipInfo(name, date_time=_FIXED_ZIP_DT)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    zf.writestr(info, data)


def _package_list_text() -> str:
    rows: list[str] = []
    for dist in metadata.distributions():
        name = dist.metadata.get("Name")
        if not name:
            continue
        rows.append(f"{name}=={dist.version}")
    rows.sort(key=str.lower)
    return "\n".join(rows) + "\n"


def _tail_text(path: Path, *, max_lines: int) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        try:
            text = path.read_text(errors="replace")
        except Exception:
            return ""
    lines = text.splitlines()
    if max_lines <= 0:
        return ""
    tail = lines[-max_lines:]
    return "\n".join(tail) + ("\n" if tail else "")


def _discover_log_files(*, max_files: int) -> list[Path]:
    roots = [
        Path.home() / ".helix",
        Path.home() / ".helix" / "logs",
        Path.home() / ".helix" / "studio",
        Path.home() / ".helix" / "studio" / "logs",
    ]
    candidates: list[Path] = []
    for root in roots:
        try:
            if not root.exists():
                continue
            for child in fs.iterdir_sorted(root):
                if child.is_file() and child.suffix.lower() in {".log", ".txt"}:
                    candidates.append(child)
        except Exception:
            continue
    candidates.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0.0, reverse=True)
    return candidates[: max(0, max_files)]


def _redact_string(value: str) -> str:
    def _token_repl(match: re.Match[str]) -> str:
        _ = match.group(0)
        return "<redacted:token>"

    def _dna_repl(match: re.Match[str]) -> str:
        seq = match.group(0)
        digest = sha256(seq.encode("utf-8")).hexdigest()[:12]
        return f"<redacted:dna len={len(seq)} sha256={digest}>"

    value = _TOKEN_RE.sub(_token_repl, value)
    value = _DNA_RE.sub(_dna_repl, value)
    return value


def _redact_payload(obj: Any) -> Any:
    if isinstance(obj, str):
        return _redact_string(obj)
    if isinstance(obj, list):
        return [_redact_payload(v) for v in obj]
    if isinstance(obj, dict):
        redacted: dict[str, Any] = {}
        for key, value in obj.items():
            key_str = str(key)
            key_lower = key_str.lower()
            if any(marker in key_lower for marker in _SENSITIVE_KEY_MARKERS):
                redacted[key_str] = "<redacted>"
                continue
            redacted[key_str] = _redact_payload(value)
        return redacted
    return obj


def _governance_summary_for_session(session_obj: Mapping[str, Any] | None) -> dict[str, Any]:
    runs = session_obj.get("runs") if isinstance(session_obj, Mapping) and isinstance(session_obj.get("runs"), list) else []
    rows: list[dict[str, Any]] = []

    for run in runs:
        if not isinstance(run, Mapping):
            continue
        run_id = str(run.get("run_id") or "").strip() or None
        meta = run.get("metadata") if isinstance(run.get("metadata"), Mapping) else {}
        artifact = meta.get("run_artifact") if isinstance(meta.get("run_artifact"), Mapping) else None
        summary = meta.get("run_summary") if isinstance(meta.get("run_summary"), Mapping) else None

        requested = None
        eligible = False
        effective = "filter_only"
        proof = None
        if isinstance(artifact, Mapping):
            requested = normalize_decision_mode(artifact.get("decision_mode"))
            eligible = bool(artifact.get("decision_mode_eligible"))
            effective = "decision_grade" if (requested == "decision_grade" and eligible) else "filter_only"
            proof = extract_decision_grade_proof_from_artifact(artifact)
        elif isinstance(summary, Mapping):
            requested = normalize_decision_mode(summary.get("decision_mode_requested"))
            effective = normalize_decision_mode(summary.get("decision_mode"))
            eligible = bool(effective == "decision_grade")
            proof = extract_decision_grade_proof_from_summary(summary)
        else:
            requested = "filter_only"
            effective = "filter_only"
            eligible = False
            proof = None

        interpretation = interpretation_for_mode(effective)
        stamp_lines = governance_stamp_lines(
            decision_mode=effective,
            interpretation=interpretation,
            decision_grade_proof=proof if isinstance(proof, Mapping) else None,
        )
        rows.append(
            {
                "run_id": run_id,
                "decision_mode_requested": requested,
                "decision_mode": effective,
                "decision_mode_eligible": bool(eligible),
                "interpretation": interpretation,
                "decision_grade_proof": (dict(proof) if isinstance(proof, Mapping) else None),
                "stamp_lines": list(stamp_lines),
            }
        )

    if not rows:
        interpretation = interpretation_for_mode("filter_only")
        stamp_lines = governance_stamp_lines(
            decision_mode="filter_only",
            interpretation=interpretation,
            decision_grade_proof=None,
        )
        rows.append(
            {
                "run_id": None,
                "decision_mode_requested": "filter_only",
                "decision_mode": "filter_only",
                "decision_mode_eligible": False,
                "interpretation": interpretation,
                "decision_grade_proof": None,
                "stamp_lines": list(stamp_lines),
            }
        )

    max_mode = "filter_only"
    if any(str(r.get("decision_mode") or "") == "decision_grade" for r in rows):
        max_mode = "decision_grade"

    return {
        "schema": "helix.governance.support_bundle/v1",
        "decision_mode_max": max_mode,
        "runs": rows,
    }


def write_support_bundle(
    out_path: str | Path | None = None,
    *,
    session_path: str | Path | None = None,
    session_payload: Mapping[str, Any] | None = None,
    extra_logs: str | None = None,
    redact: bool = True,
    max_log_lines: int = 2000,
    max_log_files: int = 6,
) -> Path:
    """Write a zip support bundle and return its path."""

    with allow_nondeterminism(reason="support:bundle"):
        stamp = clock.local_now_stamp()
    out = Path(out_path) if out_path is not None else Path.cwd() / f"helix_support_bundle_{stamp}.zip"
    if out.exists() and out.is_dir():
        out = out / f"helix_support_bundle_{stamp}.zip"
    out.parent.mkdir(parents=True, exist_ok=True)

    with allow_nondeterminism(reason="support:bundle"):
        created_at = _utc_now_iso()
    entries: list[BundleEntry] = []

    def add_bytes(arcname: str, data: bytes, *, redacted_entry: bool = False, source: str | None = None) -> None:
        entries.append(
            BundleEntry(
                path=arcname.replace(os.sep, "/"),
                sha256=_sha256_bytes(data),
                bytes=len(data),
                redacted=redacted_entry,
                source=source,
            )
        )
        _zip_write_bytes(zf, arcname, data)

    with zipfile.ZipFile(out, mode="w") as zf:
        doctor_text = render_doctor_report()
        add_bytes("doctor.txt", doctor_text.encode("utf-8"), redacted_entry=False, source="doctor")

        packages_text = _package_list_text()
        add_bytes("packages.txt", packages_text.encode("utf-8"), redacted_entry=False, source="importlib.metadata")

        try:
            from helix.support.events import events_path
        except Exception:  # pragma: no cover - events module unavailable
            events_path = None  # type: ignore[assignment]

        if events_path is not None:
            try:
                evt_path = events_path()
                if evt_path.exists():
                    tail = _tail_text(evt_path, max_lines=max_log_lines)
                    if redact:
                        tail = _redact_string(tail)
                    add_bytes(
                        "events/events.jsonl.tail.txt",
                        tail.encode("utf-8", errors="replace"),
                        redacted_entry=bool(redact),
                        source=str(evt_path),
                    )
            except Exception:
                pass

        try:
            from helix.support.crash import latest_crash
        except Exception:  # pragma: no cover - crash module unavailable
            latest_crash = None  # type: ignore[assignment]

        if latest_crash is not None:
            try:
                crash = latest_crash()
            except Exception:
                crash = None
            if crash is not None:
                try:
                    crash_payload = json.loads(crash.path.read_text(encoding="utf-8"))
                except Exception:
                    crash_payload = None
                if isinstance(crash_payload, dict):
                    if redact:
                        crash_payload = _redact_payload(crash_payload)
                    crash_data = (json.dumps(crash_payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
                    add_bytes(
                        "crash/latest_crash.json",
                        crash_data,
                        redacted_entry=bool(redact),
                        source=str(crash.path),
                    )

        logs_readme = (
            "Log tails included on a best-effort basis.\n"
            "If you exported from Studio, this may also include a tail of the in-app log panel.\n"
        )
        add_bytes("logs/README.txt", logs_readme.encode("utf-8"), source="bundle")

        if extra_logs:
            data = _redact_string(extra_logs) if redact else extra_logs
            add_bytes("logs/studio_log_tail.txt", data.encode("utf-8", errors="replace"), redacted_entry=bool(redact), source="studio")

        for log_path in _discover_log_files(max_files=max_log_files):
            tail = _tail_text(log_path, max_lines=max_log_lines)
            if not tail:
                continue
            if redact:
                tail = _redact_string(tail)
            safe_name = re.sub(r"[^a-zA-Z0-9_.-]+", "_", log_path.name)
            add_bytes(
                f"logs/{safe_name}.tail.txt",
                tail.encode("utf-8", errors="replace"),
                redacted_entry=bool(redact),
                source=str(log_path),
            )

        session_obj: Mapping[str, Any] | None = session_payload
        session_source: str | None = None
        if session_obj is None and session_path is not None:
            session_source = str(session_path)
            try:
                raw = Path(session_path).read_text(encoding="utf-8")
                parsed = json.loads(raw)
                if isinstance(parsed, Mapping):
                    session_obj = parsed
            except Exception:
                session_obj = None

        if session_obj is not None:
            try:
                gov = _governance_summary_for_session(session_obj)
                gov_bytes = (json.dumps(gov, indent=2, sort_keys=True) + "\n").encode("utf-8")
                add_bytes("governance/governance.json", gov_bytes, redacted_entry=False, source="bundle")

                lines: list[str] = []
                lines.append("Helix support bundle governance stamp")
                lines.append(f"created_at_utc: {created_at}")
                lines.append("")
                for row in gov.get("runs", []) if isinstance(gov.get("runs"), list) else []:
                    if not isinstance(row, Mapping):
                        continue
                    rid = str(row.get("run_id") or "run")
                    lines.append(f"run_id: {rid}")
                    for ln in row.get("stamp_lines", []) if isinstance(row.get("stamp_lines"), list) else []:
                        lines.append(str(ln))
                    lines.append("")
                add_bytes("governance/governance.txt", ("\n".join(lines).rstrip() + "\n").encode("utf-8"), source="bundle")
            except Exception:
                pass

            payload: Any = dict(session_obj)
            if isinstance(payload, Mapping):
                payload = _ensure_contract_identity(dict(payload))
            if redact:
                payload = _redact_payload(payload)
            encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
            add_bytes(
                "session/session_redacted.helix.json" if redact else "session/session.helix.json",
                encoded,
                redacted_entry=bool(redact),
                    source=session_source or "payload",
                )
        else:
            try:
                lines = governance_stamp_lines(decision_mode="filter_only", interpretation="exploratory_uncalibrated")
                text = "Helix support bundle governance stamp\n" + "\n".join(lines) + "\n"
                add_bytes("governance/governance.txt", text.encode("utf-8"), source="bundle")
            except Exception:
                pass

        manifest = {
            "bundle_version": 1,
            "created_at_utc": created_at,
            "helix_version": __version__,
            "platform": platform.platform(),
            "python": {
                "executable": sys.executable,
                "version": platform.python_version(),
                "prefix": sys.prefix,
                "base_prefix": getattr(sys, "base_prefix", ""),
            },
            "entries": [e.__dict__ for e in sorted(entries, key=lambda e: e.path)],
        }
        add_bytes("manifest.json", (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode("utf-8"), source="bundle")

    return out


__all__ = ["write_support_bundle"]
