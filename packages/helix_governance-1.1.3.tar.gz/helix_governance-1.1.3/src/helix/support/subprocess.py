from __future__ import annotations

import os
import subprocess
from typing import Any


def no_console_kwargs() -> dict[str, Any]:
    """Return subprocess kwargs that suppress console windows on Windows.

    Windows GUI applications spawning console subprocesses (git, python, etc.) can
    pop up transient console windows. Use these kwargs with subprocess.run/Popen/
    check_output to avoid that behavior.
    """

    if os.name != "nt":
        return {}

    kwargs: dict[str, Any] = {}
    try:
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        startup = subprocess.STARTUPINFO()  # type: ignore[attr-defined]
        startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW  # type: ignore[attr-defined]
        kwargs["startupinfo"] = startup
    except Exception:
        pass
    return kwargs


__all__ = ["no_console_kwargs"]

