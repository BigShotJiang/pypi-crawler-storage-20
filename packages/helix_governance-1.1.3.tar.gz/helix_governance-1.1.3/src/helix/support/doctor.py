from __future__ import annotations

import os
import platform
import site
import sys
from pathlib import Path

from helix import __version__
from helix.provenance import current_git_sha


def _is_windows() -> bool:
    return os.name == "nt"


def _is_venv() -> bool:
    return sys.prefix != getattr(sys, "base_prefix", sys.prefix)


def _find_repo_root(start: Path | None = None) -> Path | None:
    candidate = (start or Path.cwd()).resolve()
    for root in (candidate, *candidate.parents):
        if (root / "pyproject.toml").exists() or (root / ".git").exists():
            return root
    return None


def _venv_python_candidates(root: Path) -> list[Path]:
    if _is_windows():
        return [
            root / "venv" / "Scripts" / "python.exe",
            root / ".venv" / "Scripts" / "python.exe",
        ]
    return [
        root / "venv" / "bin" / "python",
        root / ".venv" / "bin" / "python",
    ]


def _resolve_repo_python(root: Path | None) -> Path | None:
    override = os.getenv("HELIX_PYTHON")
    if override:
        return Path(override)
    if root is None:
        return None
    for candidate in _venv_python_candidates(root):
        if candidate.exists():
            return candidate
    return None


def _site_packages_paths() -> list[str]:
    out: list[str] = []
    for path in sys.path:
        if "site-packages" in path or "dist-packages" in path:
            out.append(path)
    return out


def render_doctor_report(*, repo_root: Path | None = None) -> str:
    """Return a human-readable environment report for support and debugging."""

    root = repo_root or _find_repo_root()
    sha = current_git_sha()

    lines: list[str] = []

    def section(title: str) -> None:
        if lines:
            lines.append("")
        lines.append(f"== {title} ==")

    section("Helix Doctor")
    lines.append(f"helix_version={__version__}")
    if sha:
        lines.append(f"git_sha={sha}")
    if root is not None:
        lines.append(f"repo_root={root}")
    lines.append(f"platform={platform.platform()}")
    lines.append(f"python={sys.executable}")
    lines.append(f"python_version={platform.python_version()}")
    lines.append(f"sys.prefix={sys.prefix}")
    lines.append(f"sys.base_prefix={getattr(sys, 'base_prefix', '')}")
    lines.append(f"venv_detected={_is_venv()}")
    lines.append(f"VIRTUAL_ENV={os.getenv('VIRTUAL_ENV', '')}")
    for key in (
        "PYTHONPATH",
        "QT_QPA_PLATFORM",
        "QT_SCALE_FACTOR",
        "WAYLAND_DISPLAY",
        "DISPLAY",
        "XDG_SESSION_TYPE",
        "WSL_DISTRO_NAME",
        "WSL_INTEROP",
        "HELIX_WSL_QT_PLATFORM",
        "HELIX_QT_SCALE_FACTOR",
        "HELIX_FORCE_96DPI",
        "HELIX_STUDIO_NO_GL",
        "HELIX_STUDIO_SOFTGL",
        "HELIX_STUDIO_HEADLESS",
    ):
        val = os.getenv(key)
        if val:
            lines.append(f"env:{key}={val}")

    section("Site Packages")
    lines.append(f"site.getsitepackages={getattr(site, 'getsitepackages', lambda: 'n/a')()}")
    lines.append(f"site.getusersitepackages={getattr(site, 'getusersitepackages', lambda: 'n/a')()}")
    for path in _site_packages_paths():
        lines.append(f"sys.path_site={path}")

    section("Env Guard")
    try:
        from tools.test_env_guard import describe_test_env_issues  # type: ignore[import-not-found]
    except Exception as exc:
        lines.append(f"tools.test_env_guard unavailable: {exc!r}")
    else:
        issues = describe_test_env_issues()
        if not issues:
            lines.append("status=OK (no system site-packages detected)")
        else:
            lines.append("status=WARNING (system site-packages detected)")
            for issue in issues:
                lines.append(f"issue={issue.message}")
                for detail in issue.details:
                    lines.append(f"  path={detail}")
            lines.append("hint=Run tests via tools/test.* to avoid system package leakage.")

    section("Recommended Commands")
    repo_python = _resolve_repo_python(root)
    if repo_python is not None:
        lines.append(f"repo_python={repo_python}")
    else:
        lines.append("repo_python=(not found; expected ./venv or ./.venv)")

    repo_python_str = str(repo_python) if repo_python is not None else "python"
    repo_python_ps1 = f"& '{repo_python}'" if repo_python is not None else "python"
    if _is_windows():
        lines.append("tests=powershell -ExecutionPolicy Bypass -File tools/test.ps1")
        lines.append("tests_example=powershell -ExecutionPolicy Bypass -File tools/test.ps1 -q tests/test_config_features.py")
        lines.append(
            "studio_offscreen_smoke="
            f"$env:QT_QPA_PLATFORM='offscreen'; $env:HELIX_STUDIO_NO_GL='1'; {repo_python_ps1} -c \"import helix.studio.app\""
        )
        lines.append("welcome_smoke=$env:QT_QPA_PLATFORM='offscreen'; powershell -ExecutionPolicy Bypass -File tools/test.ps1 -q tests/test_welcome_dialog_smoke.py")
    else:
        lines.append("tests=tools/test.sh")
        lines.append("tests_example=tools/test.sh -q tests/test_config_features.py")
        lines.append(f"studio_offscreen_smoke=QT_QPA_PLATFORM=offscreen HELIX_STUDIO_NO_GL=1 {repo_python_str} -c \"import helix.studio.app\"")
        lines.append("welcome_smoke=QT_QPA_PLATFORM=offscreen tools/test.sh -q tests/test_welcome_dialog_smoke.py")

    lines.append("")
    return "\n".join(lines)


__all__ = ["render_doctor_report"]
