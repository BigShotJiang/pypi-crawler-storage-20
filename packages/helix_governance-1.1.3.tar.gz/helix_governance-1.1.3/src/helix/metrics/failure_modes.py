from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


Interpretability = Literal["impossible", "risky", "unknown"]


@dataclass(frozen=True)
class FailureModeSpec:
    code: str
    failure_mode: str
    consequence: str
    interpretability: Interpretability


FAILURE_MODE_REGISTRY: dict[str, FailureModeSpec] = {
    "WLP001": FailureModeSpec(
        code="WLP001",
        failure_mode="missing_controls",
        consequence="Cannot attribute observed effects without explicit controls.",
        interpretability="impossible",
    ),
    "WLP002": FailureModeSpec(
        code="WLP002",
        failure_mode="missing_validation_readout",
        consequence="Cannot measure the edit or validate the intended perturbation.",
        interpretability="impossible",
    ),
    "WLP003": FailureModeSpec(
        code="WLP003",
        failure_mode="isoform_ambiguity_knockout",
        consequence="Genotype-to-phenotype linkage is ambiguous without transcript/isoform resolution.",
        interpretability="impossible",
    ),
    "WLP004": FailureModeSpec(
        code="WLP004",
        failure_mode="single_guide_knockout_no_justification",
        consequence="Increased risk of escape/partial KO without independent perturbation or justification.",
        interpretability="risky",
    ),
    "WLP005": FailureModeSpec(
        code="WLP005",
        failure_mode="missing_decision_framing",
        consequence="Cannot interpret outcomes against an explicit decision question and success criteria.",
        interpretability="impossible",
    ),
    "WLP101": FailureModeSpec(
        code="WLP101",
        failure_mode="copy_number_or_ploidy_confound",
        consequence="Potential locus confounds; interpret outcomes as exploratory until locally validated.",
        interpretability="risky",
    ),
    "WLP102": FailureModeSpec(
        code="WLP102",
        failure_mode="readout_timing_mismatch",
        consequence="Readout timing may not match expected dynamics under policy constraints.",
        interpretability="risky",
    ),
    "WLP103": FailureModeSpec(
        code="WLP103",
        failure_mode="delivery_modality_mismatch",
        consequence="Delivery modality mismatch can introduce confounds under the declared policy.",
        interpretability="risky",
    ),
}


def interpretability_of(code: str) -> Interpretability:
    spec = FAILURE_MODE_REGISTRY.get(str(code))
    if spec is None:
        return "unknown"
    return spec.interpretability


def is_interpretability_impossible(code: str) -> bool:
    return interpretability_of(code) == "impossible"


__all__ = [
    "FailureModeSpec",
    "FAILURE_MODE_REGISTRY",
    "Interpretability",
    "interpretability_of",
    "is_interpretability_impossible",
]

