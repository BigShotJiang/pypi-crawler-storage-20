from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import fs

from helix.scientific_contract import canonical_json_bytes

from .failure_modes import interpretability_of


RUN_METRICS_SCHEMA_V1 = "helix.metrics.run/v1"
SUMMARY_METRICS_SCHEMA_V1 = "helix.metrics.summary/v1"

RUN_METRICS_FILENAME_V1 = "helix.metrics.run.v1.json"
SUMMARY_METRICS_FILENAME_V1 = "helix.metrics.summary.v1.json"


def _utc_from_iso8601(value: str) -> datetime:
    txt = str(value or "").strip()
    if not txt:
        raise ValueError("timestamp is required")
    # Accept Z and naive timestamps (assume UTC for naive).
    dt = datetime.fromisoformat(txt.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _as_mapping(value: Any) -> Mapping[str, Any] | None:
    return value if isinstance(value, Mapping) else None


def _as_sequence(value: Any) -> Sequence[Any] | None:
    if isinstance(value, (list, tuple)):
        return value
    return None


def _text(value: Any) -> str:
    return str(value or "").strip()


def _coerce_code_list(value: Any) -> list[str]:
    seq = _as_sequence(value)
    if seq is None:
        return []
    out: list[str] = []
    for item in seq:
        txt = _text(item)
        if txt:
            out.append(txt)
    return sorted(set(out))


@dataclass(frozen=True)
class PolicyRoiEstimates:
    cost_usd_min: int
    cost_usd_max: int
    duration_days_min: int
    duration_days_max: int
    basis: str | None = None


def extract_policy_roi_estimates(policy: Mapping[str, Any]) -> PolicyRoiEstimates | None:
    roi = _as_mapping(policy.get("roi"))
    if roi is None:
        return None
    cost = _as_mapping(roi.get("typical_cost_usd"))
    dur = _as_mapping(roi.get("typical_duration_days"))
    if cost is None or dur is None:
        return None

    def _as_int(value: Any) -> int | None:
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return int(value)
        if isinstance(value, float):
            return int(value)
        txt = _text(value)
        if not txt:
            return None
        try:
            return int(float(txt))
        except Exception:
            return None

    cmin = _as_int(cost.get("min"))
    cmax = _as_int(cost.get("max"))
    dmin = _as_int(dur.get("min"))
    dmax = _as_int(dur.get("max"))
    if None in (cmin, cmax, dmin, dmax):
        return None
    if cmin < 0 or cmax < 0 or dmin < 0 or dmax < 0:
        return None
    if cmin > cmax or dmin > dmax:
        return None
    basis = _text(roi.get("basis")) or None
    return PolicyRoiEstimates(
        cost_usd_min=cmin,
        cost_usd_max=cmax,
        duration_days_min=dmin,
        duration_days_max=dmax,
        basis=basis,
    )


@dataclass(frozen=True)
class MetricsRunV1:
    schema: str
    run_id: str
    timestamp: datetime
    policy_id: str | None
    policy_hash: str
    verdict: str
    error_codes: tuple[str, ...]
    warning_codes: tuple[str, ...]


def load_metrics_run_v1(path: str | Path) -> MetricsRunV1:
    p = Path(path)
    payload = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError(f"{p}: expected JSON object")

    schema = _text(payload.get("schema"))
    if schema != RUN_METRICS_SCHEMA_V1:
        raise ValueError(f"{p}: unsupported schema {schema!r}")

    run_id = _text(payload.get("run_id"))
    if not run_id:
        raise ValueError(f"{p}: run_id is required")

    timestamp = _utc_from_iso8601(_text(payload.get("timestamp")))
    policy_id_raw = payload.get("policy_id")
    policy_id = _text(policy_id_raw) or None
    policy_hash = _text(payload.get("policy_hash"))
    if not policy_hash:
        raise ValueError(f"{p}: policy_hash is required")

    verdict = _text(payload.get("verdict")).upper()
    if verdict not in {"PASS", "FAIL"}:
        raise ValueError(f"{p}: verdict must be PASS|FAIL")

    error_codes = tuple(_coerce_code_list(payload.get("error_codes")))
    warning_codes = tuple(_coerce_code_list(payload.get("warning_codes")))

    return MetricsRunV1(
        schema=schema,
        run_id=run_id,
        timestamp=timestamp,
        policy_id=policy_id,
        policy_hash=policy_hash,
        verdict=verdict,
        error_codes=error_codes,
        warning_codes=warning_codes,
    )


def _find_metrics_runs(root_dir: Path) -> list[Path]:
    if root_dir.is_file():
        return [root_dir]
    if not root_dir.exists():
        return []
    return fs.rglob_sorted(root_dir, RUN_METRICS_FILENAME_V1)


def _parse_date(value: str) -> date:
    txt = str(value or "").strip()
    if not txt:
        raise ValueError("date is required")
    return date.fromisoformat(txt)


def _window_label(start: date, end: date) -> str:
    return f"{start.isoformat()} to {end.isoformat()}"


def summarize_metrics_runs_v1(
    metrics_root: str | Path,
    *,
    policy_id: str,
    start: date,
    end: date,
    require_policy_roi_estimates: bool = True,
    require_registry_coverage: bool = True,
) -> dict[str, Any]:
    """
    Summarize helix.metrics.run/v1 artifacts into helix.metrics.summary/v1.

    - Counts are derived from the per-run metrics artifacts.
    - Cost/time ranges are derived from the per-run bundle manifest policy payload (policy-declared estimates).
    """

    root = Path(metrics_root)
    runs: list[tuple[Path, MetricsRunV1]] = []
    for p in _find_metrics_runs(root):
        run = load_metrics_run_v1(p)
        if run.policy_id != policy_id:
            continue
        if not (start <= run.timestamp.date() < end):
            continue
        runs.append((p, run))

    total_linted = len(runs)
    blocked_runs: list[tuple[Path, MetricsRunV1]] = [(p, r) for (p, r) in runs if r.verdict == "FAIL"]
    blocked = len(blocked_runs)

    failure_counts: dict[str, int] = {}
    structurally_non_interpretable = 0

    avoided_cost_min = 0
    avoided_cost_max = 0
    avoided_days_min = 0
    avoided_days_max = 0

    missing_estimates: list[str] = []
    unknown_codes: set[str] = set()

    for p, run in blocked_runs:
        # Failure mode stats
        for code in run.error_codes:
            failure_counts[code] = failure_counts.get(code, 0) + 1
            impact = interpretability_of(code)
            if impact == "unknown":
                unknown_codes.add(code)
        if any(interpretability_of(c) == "impossible" for c in run.error_codes):
            structurally_non_interpretable += 1

        # ROI: policy-declared cost/time ranges live in the bundle manifest policy payload.
        manifest_path = p.parent / "manifest.json"
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception:
            manifest = None
        policy = _as_mapping((manifest or {}).get("policy") if isinstance(manifest, Mapping) else None) or {}
        estimates = extract_policy_roi_estimates(policy)
        if estimates is None:
            missing_estimates.append(str(manifest_path))
            continue
        avoided_cost_min += estimates.cost_usd_min
        avoided_cost_max += estimates.cost_usd_max
        avoided_days_min += estimates.duration_days_min
        avoided_days_max += estimates.duration_days_max

    if require_registry_coverage and unknown_codes:
        raise ValueError(
            "Missing Failure Mode Registry entries for codes: " + ", ".join(sorted(unknown_codes))
        )

    if require_policy_roi_estimates and missing_estimates:
        raise ValueError(
            "Missing policy.roi.typical_* estimates in bundle manifests:\n"
            + "\n".join(sorted(missing_estimates))
        )

    top_failure_modes = [
        {"code": code, "count": int(count)}
        for code, count in sorted(failure_counts.items(), key=lambda kv: (-kv[1], kv[0]))
        if count > 0
    ]

    return {
        "schema": SUMMARY_METRICS_SCHEMA_V1,
        "window": _window_label(start, end),
        "policy_id": policy_id,
        "total_linted": int(total_linted),
        "blocked": int(blocked),
        "structurally_non_interpretable": int(structurally_non_interpretable),
        "top_failure_modes": top_failure_modes,
        "estimated_avoided_cost_usd": {"min": int(avoided_cost_min), "max": int(avoided_cost_max)},
        "estimated_time_saved_days": {"min": int(avoided_days_min), "max": int(avoided_days_max)},
    }


def write_summary_v1(path: str | Path, payload: Mapping[str, Any], *, pretty: bool = False) -> None:
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if pretty:
        out_path.write_text(json.dumps(dict(payload), indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return
    out_path.write_bytes(canonical_json_bytes(dict(payload)))


def parse_date(value: str) -> date:
    return _parse_date(value)


__all__ = [
    "RUN_METRICS_SCHEMA_V1",
    "SUMMARY_METRICS_SCHEMA_V1",
    "RUN_METRICS_FILENAME_V1",
    "SUMMARY_METRICS_FILENAME_V1",
    "PolicyRoiEstimates",
    "extract_policy_roi_estimates",
    "MetricsRunV1",
    "load_metrics_run_v1",
    "parse_date",
    "summarize_metrics_runs_v1",
    "write_summary_v1",
]
