from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from helix import clock
from helix import __version__ as helix_version
from helix.scientific_contract import sha256_prefixed

from .errors import (
    LICENSE_EXPIRED,
    LICENSE_INVALID,
    LICENSE_NOT_YET_VALID,
    LICENSE_REQUIRED,
    LICENSE_SCOPE_MISMATCH,
    SIGNING_KEY_REQUIRED,
    GovernanceIssue,
)


_ENV_POLICY_PATH = "HELIX_POLICY_PATH"


def _utc_now() -> datetime:
    return datetime.fromisoformat(clock.utc_now_iso_offset()).astimezone(timezone.utc)


def _safe_text(value: Any) -> str:
    return str(value or "").strip()


def _short_sha256(value: str, *, chars: int = 10) -> str:
    token = _safe_text(value).lower()
    if token.startswith("sha256:"):
        token = token[len("sha256:") :]
    if not token:
        return ""
    return f"sha256:{token[: int(chars)]}"


def _select_policy_label(*, policy_id: str, policy_profile: str, policy_hash: str) -> str:
    if policy_id:
        return policy_id
    if policy_profile:
        return policy_profile
    if policy_hash:
        return _short_sha256(policy_hash)
    return "unknown"


def _parse_utc(ts: str) -> datetime:
    text = str(ts or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _load_policy_best_effort(path: str | None) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    resolved = str(path or os.getenv(_ENV_POLICY_PATH) or "").strip()
    if not resolved:
        return None, {"path": None, "policy_id": None, "policy_profile": None, "policy_hash": None, "determinism_class": None}
    try:
        payload = json.loads(Path(resolved).read_text(encoding="utf-8"))
    except Exception:
        payload = None
    if not isinstance(payload, Mapping):
        return None, {"path": resolved, "policy_id": None, "policy_profile": Path(resolved).name, "policy_hash": None, "determinism_class": None}

    policy_id = _safe_text(payload.get("policyId") or payload.get("policy_id") or payload.get("policyName"))
    determinism = _safe_text(payload.get("determinismClass") or payload.get("determinism_class"))
    policy_hash = sha256_prefixed(payload)
    return dict(payload), {
        "path": resolved,
        "policy_id": (policy_id or None),
        "policy_profile": Path(resolved).name if resolved else None,
        "policy_hash": policy_hash,
        "determinism_class": (determinism or None),
    }


@dataclass(frozen=True, slots=True)
class GovernanceSelfCheckResult:
    ok: bool
    decision_mode: str
    policy: dict[str, Any]
    pinned_issuer_key_ids: tuple[str, ...]
    license: dict[str, Any] | None
    signing_key: dict[str, Any]
    blockers: tuple[GovernanceIssue, ...]
    warnings: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "helix.governance.self_check/v1",
            "ok": bool(self.ok),
            "tool": {"dist": "helix-governance", "version": str(helix_version)},
            "decision_mode": self.decision_mode,
            "policy": dict(self.policy),
            "pinned_issuer_key_ids": list(self.pinned_issuer_key_ids),
            "license": dict(self.license) if isinstance(self.license, dict) else None,
            "signing_key": dict(self.signing_key),
            "blockers": [b.to_dict() for b in self.blockers],
            "warnings": list(self.warnings),
        }


def governance_self_check(
    *,
    decision_mode: str,
    policy_path: str | None = None,
    license_path: str | Path | None = None,
    edit_program_id: str | None = None,
    signing_key: str | Path | None = None,
    now_utc: datetime | None = None,
) -> GovernanceSelfCheckResult:
    """
    Offline governance “status” primitive for support + enterprise onboarding.

    It never phones home and it never emits secrets. It reports what would be required for
    decision-grade outputs under the current local configuration.
    """

    from helix.licensing.license import load_license
    from helix.licensing.verify import issuer_key_ids, read_private_key_raw, sign_ed25519

    now = now_utc or _utc_now()

    mode = "decision_grade" if str(decision_mode or "").strip().lower() == "decision_grade" else "filter_only"
    policy_payload, policy_meta = _load_policy_best_effort(str(policy_path) if policy_path is not None else None)
    policy_label = _select_policy_label(
        policy_id=_safe_text(policy_meta.get("policy_id")),
        policy_profile=_safe_text(policy_meta.get("policy_profile")),
        policy_hash=_safe_text(policy_meta.get("policy_hash")),
    )
    policy_meta["policy_label"] = policy_label

    pinned_keys = tuple(issuer_key_ids())

    blockers: list[GovernanceIssue] = []
    warnings: list[str] = []

    lic_obj = None
    lic_payload = None
    lic_err: Exception | None = None
    try:
        lic_obj = load_license(path=license_path)
        lic_payload = {
            "path": (str(license_path) if license_path is not None else None),
            "license_id": str(lic_obj.license_id),
            "issuer_key_id": str(lic_obj.issuer_key_id),
            "org": str(lic_obj.org),
            "edit_program_id": str(lic_obj.edit_program_id),
            "capabilities": sorted(lic_obj.capabilities),
            "not_before_utc": str(lic_obj.not_before_utc),
            "not_after_utc": str(lic_obj.not_after_utc),
            "license_sha256": str(lic_obj.license_sha256),
            "active": bool(lic_obj.is_active(now_utc=now)),
        }
    except Exception as exc:
        lic_err = exc
        lic_obj = None
        lic_payload = None

    # Signing key check (never prints raw keys).
    signing_payload: dict[str, Any] = {
        "path": (str(signing_key) if signing_key is not None else None),
        "present": bool(signing_key),
        "authorized_by_license": None,
        "public_key_authorized": None,
    }
    signer_pub_raw: bytes | None = None
    if signing_key is not None:
        try:
            sk_raw = read_private_key_raw(signing_key)
            _sig, pk_raw = sign_ed25519(b"helix-self-check", private_key_raw=sk_raw)
            signer_pub_raw = pk_raw
        except Exception as exc:
            blockers.append(
                GovernanceIssue(
                    code=SIGNING_KEY_REQUIRED,
                    details={"reason": "SIGNING_KEY_INVALID", "error": str(exc)},
                )
            )
            signer_pub_raw = None

    if lic_obj is not None and signer_pub_raw is not None:
        if not lic_obj.signing_keys:
            blockers.append(GovernanceIssue(code=LICENSE_INVALID, details={"reason": "LICENSE_SIGNING_KEYS_MISSING"}))
        else:
            allowed = {k.public_key_raw for k in lic_obj.signing_keys}
            ok = signer_pub_raw in allowed
            signing_payload["authorized_by_license"] = bool(ok)
            signing_payload["public_key_authorized"] = bool(ok)
            if not ok:
                blockers.append(
                    GovernanceIssue(
                        code=SIGNING_KEY_REQUIRED,
                        details={"reason": "SIGNING_KEY_NOT_AUTHORIZED"},
                    )
                )

    # Decision-grade readiness: license + scope + capabilities + signing context.
    if mode == "decision_grade":
        if lic_obj is None:
            # Distinguish missing vs invalid when possible.
            details: dict[str, Any] = {"reason": "LICENSE_MISSING"}
            code = LICENSE_REQUIRED
            if lic_err is not None:
                raw_code = getattr(lic_err, "code", None)
                if isinstance(raw_code, str) and raw_code.startswith("LICENSE_"):
                    if raw_code in {"LICENSE_NOT_CONFIGURED", "LICENSE_NOT_FOUND"}:
                        code = LICENSE_REQUIRED
                    else:
                        code = LICENSE_INVALID
                        details["cause"] = {"code": raw_code}
                else:
                    code = LICENSE_INVALID
                    details["cause"] = {"error": str(lic_err)}
            blockers.append(GovernanceIssue(code=code, details=details))
        else:
            requested_edit_program_id = _safe_text(edit_program_id) or _safe_text(os.getenv("HELIX_EDIT_PROGRAM_ID"))
            if not requested_edit_program_id:
                blockers.append(
                    GovernanceIssue(
                        code=LICENSE_SCOPE_MISMATCH,
                        details={"reason": "EDIT_PROGRAM_ID_REQUIRED"},
                    )
                )
            elif str(lic_obj.edit_program_id) != requested_edit_program_id:
                blockers.append(
                    GovernanceIssue(
                        code=LICENSE_SCOPE_MISMATCH,
                        details={
                            "reason": "EDIT_PROGRAM_ID_MISMATCH",
                            "license_edit_program_id": str(lic_obj.edit_program_id),
                            "requested_edit_program_id": requested_edit_program_id,
                        },
                    )
                )

            try:
                nb = _parse_utc(str(lic_obj.not_before_utc))
                na = _parse_utc(str(lic_obj.not_after_utc))
                if now < nb:
                    blockers.append(
                        GovernanceIssue(
                            code=LICENSE_NOT_YET_VALID,
                            details={"reason": "LICENSE_WINDOW_NOT_STARTED", "not_before_utc": str(lic_obj.not_before_utc)},
                        )
                    )
                elif now > na:
                    blockers.append(
                        GovernanceIssue(
                            code=LICENSE_EXPIRED,
                            details={"reason": "LICENSE_WINDOW_ENDED", "not_after_utc": str(lic_obj.not_after_utc)},
                        )
                    )
            except Exception:
                blockers.append(GovernanceIssue(code=LICENSE_INVALID, details={"reason": "LICENSE_WINDOW_INVALID"}))

            if "governance" not in lic_obj.capabilities:
                blockers.append(
                    GovernanceIssue(
                        code=LICENSE_SCOPE_MISMATCH,
                        details={"reason": "CAPABILITY_NOT_GRANTED", "capability": "governance"},
                    )
                )
            if "sign" not in lic_obj.capabilities:
                blockers.append(
                    GovernanceIssue(
                        code=LICENSE_SCOPE_MISMATCH,
                        details={"reason": "CAPABILITY_NOT_GRANTED", "capability": "sign"},
                    )
                )
            if signing_key is None:
                blockers.append(GovernanceIssue(code=SIGNING_KEY_REQUIRED, details={"reason": "SIGNING_KEY_MISSING"}))

    ok = not blockers
    return GovernanceSelfCheckResult(
        ok=bool(ok),
        decision_mode=mode,
        policy=dict(policy_meta),
        pinned_issuer_key_ids=pinned_keys,
        license=lic_payload,
        signing_key=signing_payload,
        blockers=tuple(blockers),
        warnings=tuple(warnings),
    )


__all__ = ["GovernanceSelfCheckResult", "governance_self_check"]
