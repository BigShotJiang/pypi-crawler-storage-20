from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


LICENSE_REQUIRED = "LICENSE_REQUIRED"
LICENSE_INVALID = "LICENSE_INVALID"
LICENSE_EXPIRED = "LICENSE_EXPIRED"
LICENSE_NOT_YET_VALID = "LICENSE_NOT_YET_VALID"
LICENSE_SCOPE_MISMATCH = "LICENSE_SCOPE_MISMATCH"
SIGNING_KEY_REQUIRED = "SIGNING_KEY_REQUIRED"
POLICY_LOCK_VIOLATION = "POLICY_LOCK_VIOLATION"
SIDE_CHANNEL_OUTPUT_BLOCKED = "SIDE_CHANNEL_OUTPUT_BLOCKED"
ATTESTATION_INVALID = "ATTESTATION_INVALID"
MANIFEST_MISMATCH = "MANIFEST_MISMATCH"


_CANONICAL_MESSAGES = {
    LICENSE_REQUIRED: "A Helix Governance License is required for this action.",
    LICENSE_INVALID: "The Helix Governance License is invalid.",
    LICENSE_EXPIRED: "The Helix Governance License is expired.",
    LICENSE_NOT_YET_VALID: "The Helix Governance License is not yet valid.",
    LICENSE_SCOPE_MISMATCH: "The Helix Governance License does not cover this action.",
    SIGNING_KEY_REQUIRED: "A signing key is required for decision-grade outputs.",
    POLICY_LOCK_VIOLATION: "Policy lock violation.",
    SIDE_CHANNEL_OUTPUT_BLOCKED: "Side-channel output is blocked by governance policy.",
    ATTESTATION_INVALID: "Attestation verification failed.",
    MANIFEST_MISMATCH: "Bundle manifest does not match its contents.",
}


def canonical_message(code: str) -> str:
    return _CANONICAL_MESSAGES.get(str(code), "Governance error.")


class GovernanceError(RuntimeError):
    def __init__(
        self,
        *,
        code: str,
        message: str | None = None,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        token = str(code)
        msg = canonical_message(token) if token in _CANONICAL_MESSAGES else str(message or "Governance error.")
        super().__init__(msg)
        self.code = token
        self.details = dict(details or {})

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": str(self.code),
            "message": str(self),
            "details": dict(self.details),
        }


@dataclass(frozen=True, slots=True)
class GovernanceIssue:
    code: str
    details: dict[str, Any]

    @property
    def message(self) -> str:
        return canonical_message(self.code)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": str(self.code),
            "message": self.message,
            "details": dict(self.details),
        }


__all__ = [
    "ATTESTATION_INVALID",
    "LICENSE_EXPIRED",
    "LICENSE_INVALID",
    "LICENSE_NOT_YET_VALID",
    "LICENSE_REQUIRED",
    "LICENSE_SCOPE_MISMATCH",
    "MANIFEST_MISMATCH",
    "POLICY_LOCK_VIOLATION",
    "SIDE_CHANNEL_OUTPUT_BLOCKED",
    "SIGNING_KEY_REQUIRED",
    "GovernanceError",
    "GovernanceIssue",
    "canonical_message",
]
