from __future__ import annotations

import sys
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from helix.governance.errors import GovernanceError, POLICY_LOCK_VIOLATION, SIDE_CHANNEL_OUTPUT_BLOCKED
from helix.governance.ledger import compute_governance_state, governance_mode, load_governance_events_from_bundle


_REGISTRY_ALLOW_UNREGISTERED_EXPORT_ENV = "HELIX_REGISTRY_ALLOW_UNREGISTERED_EXPORT"


@dataclass(frozen=True, slots=True)
class GovernanceExportDecision:
    ok: bool
    mode: str
    reason: str
    waiver_used: bool
    details: dict[str, Any]


def _warn(message: str) -> None:
    print(message, file=sys.stderr)


def _env_bool(name: str, *, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    raw = raw.strip().lower()
    if raw in {"", "0", "false", "no"}:
        return False
    if raw in {"1", "true", "yes"}:
        return True
    return default


def _short_sha(token: str | None) -> str:
    t = str(token or "").strip()
    if t.startswith("sha256:"):
        t = t[len("sha256:") :]
    return f"sha256:{t[:12]}" if t else "none"


def _try_record_export_blocked(*, export_kind: str, reason: str, details: Mapping[str, Any] | None) -> None:
    """
    Best-effort telemetry hook for "unavoidable" posture dashboards.

    This never blocks or changes governance decisions; failures are ignored.
    """

    import json
    from urllib.request import Request, urlopen

    from helix.user_config import resolve_setting_str

    registry_url = str(resolve_setting_str(env_var="HELIX_REGISTRY_URL", config_key="registry_url", default="") or "").strip().rstrip("/")
    registry_token = str(os.environ.get("HELIX_REGISTRY_TOKEN") or "").strip()
    if not registry_url or not registry_token:
        return

    url = f"{registry_url}/api/v0/telemetry/export-blocked"
    payload: dict[str, Any] = {"exportKind": str(export_kind), "reason": str(reason)}
    if details:
        payload["details"] = dict(details)

    data = (json.dumps(payload, sort_keys=True) + "\n").encode("utf-8")
    req = Request(url, method="POST", data=data)
    req.add_header("Authorization", f"Bearer {registry_token}")
    req.add_header("Content-Type", "application/json")
    try:
        with urlopen(req, timeout=2) as _resp:  # nosec B310 - internal service URL
            _ = _resp.read(16)
    except Exception:
        return


def _waiver_roles_satisfied(waiver_events: list[Mapping[str, Any]], required: Mapping[str, int]) -> bool:
    if not required:
        return False
    counts: dict[str, int] = {k: 0 for k in required.keys()}
    seen: set[tuple[str, str, str]] = set()
    for w in waiver_events:
        role = str(w.get("signer_role") or "").strip()
        identity = str(w.get("signer_identity") or "").strip()
        key_id = str(w.get("signer_key_id") or "").strip()
        if not role or not identity or not key_id:
            continue
        triplet = (role, identity, key_id)
        if triplet in seen:
            continue
        seen.add(triplet)
        if role in counts:
            counts[role] += 1
    for role, need in required.items():
        if counts.get(role, 0) < int(need):
            return False
    return True


def _load_registry_ref(bundle_path: str | Path) -> dict[str, Any] | None:
    """
    Load governance/registry_ref.json from a bundle directory or zip.

    This is append-only metadata (not part of the manifest content-addressed set).
    """

    import json
    import zipfile

    path = Path(bundle_path)
    if path.is_file() and path.name == "manifest.json":
        path = path.parent

    rel = "governance/registry_ref.json"
    if path.is_dir():
        ref = path / rel
        if not ref.exists() or not ref.is_file():
            return None
        try:
            payload = json.loads(ref.read_text(encoding="utf-8"))
        except Exception:
            return None
        return payload if isinstance(payload, dict) else None

    if path.is_file() and path.suffix.lower() in {".zip", ".hxs"}:
        try:
            with zipfile.ZipFile(path, "r") as zf:
                raw = zf.read(rel)
        except Exception:
            return None
        try:
            payload = json.loads(raw.decode("utf-8"))
        except Exception:
            return None
        return payload if isinstance(payload, dict) else None

    return None


def _registry_status(
    *,
    registry_url: str,
    registry_token: str,
    program_id: str,
    version: str,
) -> tuple[dict[str, Any] | None, str | None, int | None]:
    """
    Query the registry server for ProgramVersion status.

    Returns (payload, error, http_status_code).
    """

    import json
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    base = str(registry_url or "").strip().rstrip("/")
    if not base:
        return None, "missing registry_url (HELIX_REGISTRY_URL or profile.registry_url)", None
    token = str(registry_token or "").strip()
    if not token:
        return None, "missing HELIX_REGISTRY_TOKEN", None

    url = f"{base}/api/v0/registry/programs/{program_id}/versions/{version}/status"
    req = Request(url, method="GET")
    req.add_header("Authorization", f"Bearer {token}")
    try:
        with urlopen(req, timeout=10) as resp:  # nosec B310 - internal service URL
            raw = resp.read()
    except HTTPError as exc:
        return None, f"http {exc.code}", int(exc.code)
    except URLError as exc:
        return None, f"network error: {exc}", None
    except Exception as exc:
        return None, f"error: {exc}", None

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        return None, f"invalid json: {exc}", None
    if not isinstance(payload, dict):
        return None, "invalid response (not an object)", None
    return payload, None, 200


def _registry_export_gate(
    bundle_path: str | Path,
    *,
    export_kind: str,
    mode: str,
) -> tuple[bool, str, dict[str, Any]]:
    from helix.user_config import resolve_setting_str

    registry_url = str(resolve_setting_str(env_var="HELIX_REGISTRY_URL", config_key="registry_url", default="") or "").strip()
    registry_token = str(os.environ.get("HELIX_REGISTRY_TOKEN") or "").strip()
    allow_unregistered = _env_bool(_REGISTRY_ALLOW_UNREGISTERED_EXPORT_ENV, default=False)

    registry_required = bool(registry_url and mode in {"warn", "enforce"} and not allow_unregistered)

    ref = _load_registry_ref(bundle_path)
    if not isinstance(ref, Mapping):
        if registry_required:
            return (
                False,
                "registry_ref_required",
                {
                    "export_kind": export_kind,
                    "registry_reason": "registry_ref_required",
                    "registryUrl": registry_url,
                },
            )
        return True, "no_registry_ref", {}

    program_id = str(ref.get("programId") or "").strip()
    version = str(ref.get("version") or "").strip()
    if not program_id or not version:
        return False, "registry_ref_invalid", {"export_kind": export_kind, "registry_reason": "registry_ref_invalid", "registryRef": dict(ref)}

    if not registry_url or not registry_token:
        if allow_unregistered:
            return True, "registry_config_missing_allowed", {"export_kind": export_kind, "registry_reason": "registry_config_missing_allowed", "registryRef": dict(ref)}
        return False, "registry_config_missing", {"export_kind": export_kind, "registry_reason": "registry_config_missing", "registryRef": dict(ref)}

    status, err, http_code = _registry_status(
        registry_url=registry_url,
        registry_token=registry_token,
        program_id=program_id,
        version=version,
    )
    if err or not isinstance(status, Mapping):
        if http_code == 404:
            if export_kind == "registry_publish_bundle_zip":
                return True, "registry_not_registered_yet", {"export_kind": export_kind, "registry_reason": "registry_not_registered_yet", "registryRef": dict(ref)}
            if allow_unregistered:
                return True, "registry_not_registered_allowed", {"export_kind": export_kind, "registry_reason": "registry_not_registered_allowed", "registryRef": dict(ref)}
            return False, "registry_not_registered", {"export_kind": export_kind, "registry_reason": "registry_not_registered", "error": err, "registryRef": dict(ref)}
        if allow_unregistered:
            return True, "registry_unreachable_allowed", {"export_kind": export_kind, "registry_reason": "registry_unreachable_allowed", "error": err, "registryRef": dict(ref)}
        return False, "registry_unreachable", {"export_kind": export_kind, "registry_reason": "registry_unreachable", "error": err, "registryRef": dict(ref)}

    deprecated = bool(status.get("deprecated"))
    needs_review = bool(status.get("needsReview"))
    if deprecated:
        return False, "registry_deprecated", {
            "export_kind": export_kind,
            "registry_reason": "registry_deprecated",
            "status": dict(status),
            "registryRef": dict(ref),
        }
    if needs_review:
        return False, "registry_needs_review", {
            "export_kind": export_kind,
            "registry_reason": "registry_needs_review",
            "status": dict(status),
            "registryRef": dict(ref),
        }

    return True, "registry_ok", {"export_kind": export_kind, "registry_reason": "registry_ok", "status": dict(status), "registryRef": dict(ref)}


def _verified_waivers_for_scope(
    *,
    bundle_path: str | Path,
    waived_transition_id: str,
    waiver_scope: str,
) -> list[Mapping[str, Any]]:
    """
    Return verified waiver payloads for a given (scope, transition_id).

    We verify signatures against the bundle's embedded governance/license.json keys.
    """

    from helix.artifacts.verify import verify_artifact_bundle
    from helix.licensing.license import parse_license_v1
    from helix.licensing.verify import verify_ed25519_signature

    verification = verify_artifact_bundle(bundle_path, require_signed=True)
    lic_payload = verification.license if isinstance(verification.license, Mapping) else None
    if not isinstance(lic_payload, Mapping):
        return []
    try:
        lic = parse_license_v1(lic_payload)
    except Exception:
        return []
    if not lic.signing_keys:
        return []

    transitions, _signoffs, waivers, issues = load_governance_events_from_bundle(bundle_path)
    if issues:
        return []
    _ = transitions  # transitions not used directly; kept for future checks

    allowed = [k.public_key_raw for k in lic.signing_keys]
    key_id_by_pub = {k.public_key_raw: k.key_id for k in lic.signing_keys}

    out: list[Mapping[str, Any]] = []
    for w in waivers:
        if w.waived_transition_id != waived_transition_id:
            continue
        if w.waiver_scope != waiver_scope:
            continue
        try:
            _signed_sha, pub_raw = verify_ed25519_signature(w.raw, allowed_public_keys_raw=allowed, require_allowed_key=True)
        except Exception:
            continue
        expected_key_id = key_id_by_pub.get(pub_raw)
        if expected_key_id is None or expected_key_id != w.signer_key_id:
            continue
        out.append(w.raw)
    return out


def evaluate_official_export(
    bundle_path: str | Path,
    *,
    export_kind: str,
    policy_path: str | Path | None = None,
) -> GovernanceExportDecision:
    mode = governance_mode()
    if mode == "off":
        return GovernanceExportDecision(ok=True, mode=mode, reason="mode=off", waiver_used=False, details={})

    # Core requirements: bundle must be intact and governance state must be Approved.
    from helix.artifacts.verify import verify_artifact_bundle

    integrity = verify_artifact_bundle(bundle_path, require_signed=True)
    state = compute_governance_state(bundle_path, policy_path=policy_path)

    approved = bool(state.state == "Approved" and state.effective_transition_id)
    chain_ok = approved and not state.issues
    if integrity.ok and chain_ok:
        reg_ok, reg_reason, reg_details = _registry_export_gate(bundle_path, export_kind=export_kind, mode=mode)
        if not reg_ok:
            return GovernanceExportDecision(
                ok=False,
                mode=mode,
                reason=reg_reason,
                waiver_used=False,
                details={
                    "bundle_id": state.bundle_id,
                    "state": state.state,
                    "effective_transition_id": state.effective_transition_id,
                    "approval_surface_hash": state.current_approval_surface_hash,
                    **dict(reg_details),
                },
            )
        return GovernanceExportDecision(
            ok=True,
            mode=mode,
            reason="approved",
            waiver_used=False,
            details={
                "bundle_id": state.bundle_id,
                "state": state.state,
                "effective_transition_id": state.effective_transition_id,
                "approval_surface_hash": state.current_approval_surface_hash,
            },
        )

    # Waiver path: allow export even if not Approved, but only when integrity is OK and
    # a valid export_unapproved waiver exists for the latest Approved transition request.
    transitions, _signoffs, _waivers, issues = load_governance_events_from_bundle(bundle_path)
    if issues:
        return GovernanceExportDecision(
            ok=False,
            mode=mode,
            reason="ledger invalid",
            waiver_used=False,
            details={"issues": [i.details for i in issues]},
        )
    approved_requests = [t for t in transitions if t.to_state == "Approved"]
    target = approved_requests[-1].event_id if approved_requests else None
    if integrity.ok and target:
        required = state.policy.waiver_required_signoffs(waiver_scope="export_unapproved")
        verified = _verified_waivers_for_scope(bundle_path=bundle_path, waived_transition_id=target, waiver_scope="export_unapproved")
        if _waiver_roles_satisfied(verified, required):
            reg_ok, reg_reason, reg_details = _registry_export_gate(bundle_path, export_kind=export_kind, mode=mode)
            if not reg_ok:
                return GovernanceExportDecision(
                    ok=False,
                    mode=mode,
                    reason=reg_reason,
                    waiver_used=True,
                    details={
                        "bundle_id": state.bundle_id,
                        "state": state.state,
                        "target_transition_id": target,
                        "export_kind": export_kind,
                        "waiver_scope": "export_unapproved",
                        **dict(reg_details),
                    },
                )
            return GovernanceExportDecision(
                ok=True,
                mode=mode,
                reason="waived",
                waiver_used=True,
                details={
                    "bundle_id": state.bundle_id,
                    "state": state.state,
                    "target_transition_id": target,
                    "export_kind": export_kind,
                    "waiver_scope": "export_unapproved",
                },
            )

    reason = "not approved"
    details = {
        "export_kind": export_kind,
        "bundle_id": state.bundle_id,
        "state": state.state,
        "integrity_ok": bool(integrity.ok),
        "approved": bool(approved),
        "chain_ok": bool(chain_ok),
        "effective_transition_id": state.effective_transition_id,
        "approval_surface_hash": state.current_approval_surface_hash,
        "issue_count": len(state.issues),
    }
    return GovernanceExportDecision(ok=False, mode=mode, reason=reason, waiver_used=False, details=details)


def require_official_export_allowed(
    bundle_path: str | Path,
    *,
    export_kind: str,
    policy_path: str | Path | None = None,
) -> None:
    decision = evaluate_official_export(bundle_path, export_kind=export_kind, policy_path=policy_path)
    if decision.ok:
        return
    if decision.mode == "enforce":
        _try_record_export_blocked(export_kind=export_kind, reason=decision.reason, details=decision.details)
    msg = (
        f"Governance blocks export '{export_kind}': {decision.reason}. "
        f"bundle={decision.details.get('bundle_id') or '<unknown>'} state={decision.details.get('state')}. "
        f"Set HELIX_GOVERNANCE_MODE=off to bypass (not recommended)."
    )
    if decision.mode == "warn":
        _warn("WARN\t" + msg)
        return
    raise GovernanceError(
        code=POLICY_LOCK_VIOLATION,
        details={"reason": "GOVERNANCE_EXPORT_BLOCKED", "export_kind": export_kind, **dict(decision.details)},
    )


def require_side_channel_output_allowed(*, output_kind: str, guidance: str | None = None) -> None:
    """
    Block "side-channel" outputs (reports/exports written outside governed bundles) in enforce mode.

    This is the primary lever for checklist item 38 ("no side channel artifacts") in
    HELIX_GOVERNANCE_MODE=enforce.
    """

    mode = governance_mode()
    if mode == "off":
        return

    msg = f"Governance blocks side-channel output '{output_kind}'."
    if guidance:
        msg = msg + " " + str(guidance).strip()
    msg = msg + " Set HELIX_GOVERNANCE_MODE=off to bypass (not recommended)."

    if mode == "warn":
        _warn("WARN\t" + msg)
        return

    _try_record_export_blocked(
        export_kind=str(output_kind),
        reason="side_channel_output_blocked",
        details={"guidance": str(guidance).strip()} if guidance else None,
    )
    raise GovernanceError(
        code=SIDE_CHANNEL_OUTPUT_BLOCKED,
        details={"reason": "SIDE_CHANNEL_OUTPUT_BLOCKED", "output_kind": str(output_kind)},
    )


__all__ = [
    "GovernanceExportDecision",
    "evaluate_official_export",
    "require_official_export_allowed",
    "require_side_channel_output_allowed",
]
