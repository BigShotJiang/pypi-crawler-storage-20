from __future__ import annotations

from typing import Any, Mapping

from .errors import GovernanceError, SIGNING_KEY_REQUIRED


def normalize_decision_mode(value: Any) -> str:
    mode = str(value or "").strip().lower()
    return "decision_grade" if mode == "decision_grade" else "filter_only"


def require_decision_grade_signing(
    *,
    decision_mode: Any,
    governance_signing: bool,
    run_id: str | None = None,
    surface: str | None = None,
    extra_details: Mapping[str, Any] | None = None,
) -> None:
    """
    Enforce that decision-grade outputs are only emitted when a signing context exists.

    This is a trust boundary: decision-grade artifacts must be verifiable as part of a signed bundle.
    """

    if normalize_decision_mode(decision_mode) != "decision_grade":
        return
    if bool(governance_signing):
        return

    details: dict[str, Any] = {"reason": "DECISION_GRADE_REQUIRES_SIGNING"}
    if isinstance(run_id, str) and run_id.strip():
        details["run_id"] = run_id.strip()
    if isinstance(surface, str) and surface.strip():
        details["surface"] = surface.strip()
    if isinstance(extra_details, Mapping):
        details.update({str(k): v for k, v in extra_details.items()})

    raise GovernanceError(code=SIGNING_KEY_REQUIRED, details=details)


__all__ = ["normalize_decision_mode", "require_decision_grade_signing"]

