from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any, Mapping


_ENV_SLACK_WEBHOOK_URL = "SLACK_WEBHOOK_URL"


def slack_webhook_url() -> str | None:
    from helix.user_config import resolve_setting_str

    return (
        resolve_setting_str(
            env_var=_ENV_SLACK_WEBHOOK_URL,
            config_key="slack_webhook_url",
            default=None,
        )
        or None
    )


def try_notify_slack(*, text: str, webhook_url: str | None = None, timeout_s: float = 2.0) -> tuple[bool, str | None]:
    """
    Best-effort Slack notification.

    - Disabled unless SLACK_WEBHOOK_URL is set (or webhook_url is provided).
    - Never raises; returns (ok, error).
    """

    url = (str(webhook_url or "").strip() or slack_webhook_url())
    if not url:
        return True, None

    payload: Mapping[str, Any] = {"text": str(text)}
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=float(timeout_s)) as resp:
            resp.read()
        return True, None
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        return False, f"http {exc.code}: {body or exc.reason}"
    except Exception as exc:
        return False, str(exc)


__all__ = ["slack_webhook_url", "try_notify_slack"]
