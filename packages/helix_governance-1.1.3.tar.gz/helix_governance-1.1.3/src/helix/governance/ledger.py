from __future__ import annotations

import base64
import hashlib
import json
import os
import time
import zipfile
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib import resources
from pathlib import Path
from typing import Any, Iterable, Literal, Mapping, Sequence

from helix import clock
from helix.licensing.license import HelixLicenseV1, parse_license_v1
from helix.licensing.verify import CANONICALIZATION_ID, verify_ed25519_signature
from helix.scientific_contract import canonical_json_bytes, sha256_prefixed


LifecycleState = Literal["Draft", "Review", "Approved", "Deprecated"]
GovernanceRole = Literal["scientific_owner", "safety_reviewer", "compliance_reviewer"]
GovernanceEventType = Literal["transition_request_v1", "transition_request_v2", "signoff_v1", "signoff_v2", "waiver_v1"]


_DEFAULT_POLICY_RESOURCE = "governance/governance_policy_v1.json"

_TRANSITION_REQUEST_V1_SCHEMA_RESOURCE = "governance/ledger/transition_request_v1.schema.json"
_SIGNOFF_V1_SCHEMA_RESOURCE = "governance/ledger/signoff_v1.schema.json"
_WAIVER_V1_SCHEMA_RESOURCE = "governance/ledger/waiver_v1.schema.json"
_TRANSITION_REQUEST_V2_SCHEMA_RESOURCE = "governance/ledger/transition_request_v2.schema.json"
_SIGNOFF_V2_SCHEMA_RESOURCE = "governance/ledger/signoff_v2.schema.json"

# These hashes are checked at runtime; update them intentionally when the schema changes.
_TRANSITION_REQUEST_V1_SCHEMA_HASH = "sha256:4cc895279673215e5d4c422dd8e563017a1f5b54eb1c296b8fb34f04dd9331d0"
_SIGNOFF_V1_SCHEMA_HASH = "sha256:95860ddc61cfc2502bad39be48d1ddc13fb94a4da204918c9a0aebff20a699b4"
_WAIVER_V1_SCHEMA_HASH = "sha256:9bd36fbc67d8fd67a3cb31cfacb9be8a61a2eedfd5a9648cada1ea3f3358471c"
_TRANSITION_REQUEST_V2_SCHEMA_HASH = "sha256:0a62515178448b0de3095608a09ba15d02362badecde900ae60325a6aecc8e65"
_SIGNOFF_V2_SCHEMA_HASH = "sha256:79f468138dea91347637d43a5ef56faa1e10275342948952207c59b014c7479b"


class GovernanceLedgerError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class LedgerIssue:
    code: str
    details: dict[str, Any]


@dataclass(frozen=True, slots=True)
class GovernancePolicyV1:
    policy_id: str
    policy_hash: str
    raw: dict[str, Any]

    def required_checks(self, *, to_state: LifecycleState) -> tuple[str, ...]:
        required = self.raw.get("required") if isinstance(self.raw.get("required"), Mapping) else {}
        block = required.get(to_state) if isinstance(required, Mapping) else None
        checks = block.get("checks") if isinstance(block, Mapping) else None
        if not isinstance(checks, list) or not all(isinstance(x, str) for x in checks):
            return ()
        return tuple(str(x) for x in checks)

    def required_signoffs(self, *, to_state: LifecycleState) -> dict[GovernanceRole, int]:
        required = self.raw.get("required") if isinstance(self.raw.get("required"), Mapping) else {}
        block = required.get(to_state) if isinstance(required, Mapping) else None
        signoffs = block.get("signoffs") if isinstance(block, Mapping) else None
        out: dict[GovernanceRole, int] = {}
        if not isinstance(signoffs, Mapping):
            return out
        for role, count in signoffs.items():
            if not isinstance(role, str):
                continue
            if role not in {"scientific_owner", "safety_reviewer", "compliance_reviewer"}:
                continue
            try:
                out[role] = int(count)  # type: ignore[assignment]
            except Exception:
                continue
        return out

    def waiver_required_signoffs(self, *, waiver_scope: str) -> dict[GovernanceRole, int]:
        waivers = self.raw.get("waivers") if isinstance(self.raw.get("waivers"), Mapping) else {}
        block = waivers.get(waiver_scope) if isinstance(waivers, Mapping) else None
        required = block.get("required_signoffs") if isinstance(block, Mapping) else None
        out: dict[GovernanceRole, int] = {}
        if not isinstance(required, Mapping):
            return out
        for role, count in required.items():
            if not isinstance(role, str):
                continue
            if role not in {"scientific_owner", "safety_reviewer", "compliance_reviewer"}:
                continue
            try:
                out[role] = int(count)  # type: ignore[assignment]
            except Exception:
                continue
        return out


@dataclass(frozen=True, slots=True)
class TransitionRequestV1:
    event_type: Literal["transition_request_v1"]
    ledger_seq: int | None
    event_id: str
    created_at: str
    bundle_id: str
    from_state: LifecycleState
    to_state: LifecycleState
    policy_id: str
    policy_hash: str
    checks_digest: str
    checks_report_relpath: str
    rationale_ref: str
    approval_surface_hash: str
    supersedes: str | None
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class GovernanceToolchainV1:
    helix_version: str
    git_sha: str
    schema_version: str
    contract_id: str
    contract_hash: str
    governance_policy_id: str
    governance_policy_hash: str
    runner_image_digest: str | None
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class TransitionRequestV2:
    event_type: Literal["transition_request_v2"]
    ledger_seq: int | None
    event_id: str
    created_at: str
    bundle_id: str
    from_state: LifecycleState
    to_state: LifecycleState
    policy_id: str
    policy_hash: str
    checks_digest: str
    checks_report_relpath: str
    rationale_ref: str
    approval_surface_hash: str
    supersedes: str | None
    toolchain: GovernanceToolchainV1
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class SignoffV1:
    event_type: Literal["signoff_v1"]
    ledger_seq: int | None
    event_id: str
    created_at: str
    transition_event_id: str
    signer_identity: str
    signer_role: GovernanceRole
    signer_key_id: str
    signature: dict[str, Any]
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class SignoffV2:
    event_type: Literal["signoff_v2"]
    ledger_seq: int | None
    event_id: str
    created_at: str
    transition_event_id: str
    signer_identity: str
    signer_role: GovernanceRole
    signer_key_id: str
    toolchain: GovernanceToolchainV1
    signature: dict[str, Any]
    raw: dict[str, Any]


@dataclass(frozen=True, slots=True)
class WaiverV1:
    event_type: Literal["waiver_v1"]
    ledger_seq: int | None
    event_id: str
    created_at: str
    bundle_id: str
    waived_transition_id: str
    waived_check_id: str | None
    waiver_scope: str
    justification: str
    signer_identity: str
    signer_role: GovernanceRole
    signer_key_id: str
    signature: dict[str, Any]
    raw: dict[str, Any]


TransitionRequest = TransitionRequestV1 | TransitionRequestV2
Signoff = SignoffV1 | SignoffV2


@dataclass(frozen=True, slots=True)
class GovernanceState:
    bundle_id: str | None
    state: LifecycleState
    effective_transition_id: str | None
    effective_transition: TransitionRequest | None
    effective_signoffs: tuple[Signoff, ...]
    effective_waivers: tuple[WaiverV1, ...]
    current_approval_surface_hash: str | None
    issues: tuple[LedgerIssue, ...]
    policy: GovernancePolicyV1

    def ok(self) -> bool:
        return not self.issues


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _schema_hash_from_resource(resource_path: str) -> str:
    schema = json.loads(resources.files("helix.schema").joinpath(resource_path).read_text(encoding="utf-8"))
    if not isinstance(schema, dict):
        raise GovernanceLedgerError(f"schema resource is not a JSON object: {resource_path}")
    msg = json.dumps(schema, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return f"sha256:{_sha256_hex(msg)}"


def _verify_schema_hashes() -> None:
    expected = {
        _TRANSITION_REQUEST_V1_SCHEMA_RESOURCE: _TRANSITION_REQUEST_V1_SCHEMA_HASH,
        _SIGNOFF_V1_SCHEMA_RESOURCE: _SIGNOFF_V1_SCHEMA_HASH,
        _WAIVER_V1_SCHEMA_RESOURCE: _WAIVER_V1_SCHEMA_HASH,
        _TRANSITION_REQUEST_V2_SCHEMA_RESOURCE: _TRANSITION_REQUEST_V2_SCHEMA_HASH,
        _SIGNOFF_V2_SCHEMA_RESOURCE: _SIGNOFF_V2_SCHEMA_HASH,
    }
    for resource_path, expected_hash in expected.items():
        computed = _schema_hash_from_resource(resource_path)
        if computed != expected_hash:
            raise GovernanceLedgerError(
                "Internal error: governance schema hash mismatch "
                f"for {resource_path} (expected {expected_hash}, got {computed})."
            )


def _safe_text(value: Any) -> str:
    return str(value or "").strip()


def _is_sha256_prefixed(token: object) -> bool:
    if not isinstance(token, str):
        return False
    t = token.strip()
    if not t.startswith("sha256:"):
        return False
    hex_part = t[len("sha256:") :]
    return len(hex_part) == 64 and all(ch in "0123456789abcdef" for ch in hex_part.lower())


def _is_hex(token: object, *, chars: int) -> bool:
    if not isinstance(token, str):
        return False
    t = token.strip()
    return len(t) == int(chars) and all(ch in "0123456789abcdef" for ch in t.lower())


def _parse_utc(ts: str) -> datetime:
    text = str(ts or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _validate_relpath(rel: str) -> None:
    token = str(rel or "")
    if not token:
        raise ValueError("path is empty")
    if token.startswith(("/", "\\")):
        raise ValueError("path is absolute")
    parts = token.replace("\\", "/").split("/")
    if any(p in {"", ".", ".."} for p in parts):
        raise ValueError("path is not normalized")


def _bundle_root_and_mode(bundle_path: str | Path) -> tuple[Path, str]:
    path = Path(bundle_path)
    if path.is_file() and path.name == "manifest.json":
        path = path.parent
    if path.is_dir():
        return path.resolve(), "dir"
    if path.is_file() and path.suffix.lower() in {".zip", ".hxs"}:
        return path.resolve(), "zip"
    raise GovernanceLedgerError(f"unsupported bundle path: {path}")


def _read_bundle_file_bytes(bundle_path: str | Path, rel: str) -> bytes:
    _validate_relpath(rel)
    root, mode = _bundle_root_and_mode(bundle_path)
    if mode == "dir":
        abs_path = (root / rel).resolve()
        if not abs_path.is_relative_to(root):
            raise GovernanceLedgerError(f"entry path escapes bundle root: {rel!r}")
        if not abs_path.exists() or not abs_path.is_file():
            raise FileNotFoundError(rel)
        return abs_path.read_bytes()
    if mode == "zip":
        with zipfile.ZipFile(root, "r") as zf:
            return zf.read(rel)
    raise GovernanceLedgerError(f"unsupported bundle mode: {mode}")


def _iter_bundle_files(bundle_path: str | Path, *, prefix: str) -> Iterable[str]:
    _validate_relpath(prefix)
    root, mode = _bundle_root_and_mode(bundle_path)
    if mode == "dir":
        base = root
        for p in sorted((base / prefix).rglob("*"), key=lambda q: q.as_posix()):
            if not p.is_file():
                continue
            rel = p.relative_to(base).as_posix()
            yield rel
        return
    if mode == "zip":
        with zipfile.ZipFile(root, "r") as zf:
            for name in sorted(zf.namelist()):
                if not name.startswith(prefix.rstrip("/") + "/"):
                    continue
                if name.endswith("/"):
                    continue
                yield name
        return
    raise GovernanceLedgerError(f"unsupported bundle mode: {mode}")


def _load_bundle_manifest(bundle_path: str | Path) -> dict[str, Any]:
    root, mode = _bundle_root_and_mode(bundle_path)
    if mode == "dir":
        manifest_path = root / "manifest.json"
        if not manifest_path.exists():
            raise GovernanceLedgerError(f"manifest.json not found in bundle dir: {root}")
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise GovernanceLedgerError("manifest.json must be a JSON object")
        return payload
    if mode == "zip":
        with zipfile.ZipFile(root, "r") as zf:
            try:
                raw = zf.read("manifest.json")
            except KeyError as exc:
                raise GovernanceLedgerError(f"manifest.json not found in bundle: {root}") from exc
        payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, dict):
            raise GovernanceLedgerError("manifest.json must be a JSON object")
        return payload
    raise GovernanceLedgerError(f"unsupported bundle mode: {mode}")


def _load_license_from_bundle(bundle_path: str | Path) -> HelixLicenseV1 | None:
    try:
        raw = _read_bundle_file_bytes(bundle_path, "governance/license.json")
    except Exception:
        return None
    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(payload, Mapping):
        return None
    try:
        return parse_license_v1(payload)
    except Exception:
        return None


def load_governance_policy_v1(*, policy_path: str | Path | None = None) -> GovernancePolicyV1:
    if policy_path is None:
        raw = resources.files("helix.schema").joinpath(_DEFAULT_POLICY_RESOURCE).read_text(encoding="utf-8")
        payload = json.loads(raw)
    else:
        payload = json.loads(Path(policy_path).read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise GovernanceLedgerError("governance policy must be a JSON object")
    policy_id = _safe_text(payload.get("policy_id") or payload.get("policyId") or payload.get("id")) or "unknown"
    policy_hash = sha256_prefixed(dict(payload))
    return GovernancePolicyV1(policy_id=policy_id, policy_hash=policy_hash, raw=dict(payload))


def compute_approval_surface_hash_from_manifest(manifest: Mapping[str, Any]) -> str:
    """
    Compute a deterministic approval surface hash from a subset of manifest fields.

    V1 rule: include toolchain anchors + risk-relevant entry hashes, excluding presentation-only reports.
    """

    helix_version = _safe_text(manifest.get("helix_version"))
    git_sha = _safe_text(manifest.get("git_sha"))
    schema_version = _safe_text(manifest.get("schema_version"))

    entries_raw = manifest.get("entries")
    entries: list[dict[str, Any]] = []
    if isinstance(entries_raw, list):
        for item in entries_raw:
            if not isinstance(item, Mapping):
                continue
            kind = _safe_text(item.get("kind"))
            # Exclude pure presentation surfaces by default.
            if kind in {"report.html"}:
                continue
            if kind in {"support_bundle.zip", "license"}:
                continue
            entries.append(
                {
                    "path": _safe_text(item.get("path")),
                    "sha256": _safe_text(item.get("sha256")),
                    "size": item.get("size"),
                    "kind": kind,
                    "role": (_safe_text(item.get("role")) or None),
                }
            )

    surface = {
        "schema": "helix.governance.approval_surface.v1",
        "toolchain": {
            "helix_version": helix_version or None,
            "git_sha": git_sha or None,
            "schema_version": schema_version or None,
        },
        "entries": sorted(entries, key=lambda e: e.get("path") or ""),
    }
    return sha256_prefixed(surface)


def _compute_event_id(payload: Mapping[str, Any]) -> str:
    unsigned = dict(payload)
    unsigned.pop("signature", None)
    unsigned.pop("event_id", None)
    return sha256_prefixed(unsigned)


def compute_governance_event_id(payload: Mapping[str, Any]) -> str:
    """Compute sha256:<hex> stable id for a governance event payload."""

    return _compute_event_id(payload)


def _validate_toolchain_v1(payload: Mapping[str, Any]) -> GovernanceToolchainV1:
    allowed = {
        "helix_version",
        "git_sha",
        "schema_version",
        "contract_id",
        "contract_hash",
        "governance_policy_id",
        "governance_policy_hash",
        "runner_image_digest",
    }
    extras = sorted(k for k in payload.keys() if k not in allowed)
    if extras:
        raise ValueError(f"unexpected toolchain keys: {', '.join(extras)}")

    helix_version = _safe_text(payload.get("helix_version"))
    if not helix_version:
        raise ValueError("toolchain.helix_version is required")
    git_sha = _safe_text(payload.get("git_sha")).lower()
    if not git_sha:
        raise ValueError("toolchain.git_sha is required")
    schema_version = _safe_text(payload.get("schema_version"))
    if not schema_version:
        raise ValueError("toolchain.schema_version is required")

    contract_id = _safe_text(payload.get("contract_id"))
    if not contract_id:
        raise ValueError("toolchain.contract_id is required")
    contract_hash = _safe_text(payload.get("contract_hash")).lower()
    if not _is_hex(contract_hash, chars=64):
        raise ValueError("toolchain.contract_hash must be 64 hex")

    governance_policy_id = _safe_text(payload.get("governance_policy_id"))
    if not governance_policy_id:
        raise ValueError("toolchain.governance_policy_id is required")
    governance_policy_hash = _safe_text(payload.get("governance_policy_hash"))
    if not _is_sha256_prefixed(governance_policy_hash):
        raise ValueError("toolchain.governance_policy_hash must be sha256:<hex>")

    runner_image_digest_raw = payload.get("runner_image_digest")
    runner_image_digest = _safe_text(runner_image_digest_raw) if runner_image_digest_raw is not None else ""
    if runner_image_digest:
        if not _is_sha256_prefixed(runner_image_digest):
            raise ValueError("toolchain.runner_image_digest must be sha256:<hex> when present")
        runner_value: str | None = runner_image_digest
    else:
        runner_value = None

    return GovernanceToolchainV1(
        helix_version=helix_version,
        git_sha=git_sha,
        schema_version=schema_version,
        contract_id=contract_id,
        contract_hash=contract_hash,
        governance_policy_id=governance_policy_id,
        governance_policy_hash=governance_policy_hash,
        runner_image_digest=runner_value,
        raw=dict(payload),
    )


def _validate_transition_request_v1(payload: Mapping[str, Any]) -> TransitionRequestV1:
    allowed = {
        "event_type",
        "ledger_seq",
        "event_id",
        "created_at",
        "bundle_id",
        "from_state",
        "to_state",
        "policy_id",
        "policy_hash",
        "checks_digest",
        "checks_report_relpath",
        "rationale_ref",
        "approval_surface_hash",
        "supersedes",
    }
    extras = sorted(k for k in payload.keys() if k not in allowed)
    if extras:
        raise ValueError(f"unexpected keys: {', '.join(extras)}")

    if payload.get("event_type") != "transition_request_v1":
        raise ValueError("event_type const mismatch")

    ledger_seq_raw = payload.get("ledger_seq")
    ledger_seq: int | None = None
    if ledger_seq_raw is not None:
        if not isinstance(ledger_seq_raw, int):
            raise ValueError("ledger_seq must be an integer")
        if ledger_seq_raw < 0:
            raise ValueError("ledger_seq must be >= 0")
        ledger_seq = int(ledger_seq_raw)

    event_id = _safe_text(payload.get("event_id"))
    if not _is_sha256_prefixed(event_id):
        raise ValueError("event_id must be sha256:<hex>")
    computed = _compute_event_id(payload)
    if event_id != computed:
        raise ValueError(f"event_id mismatch (declared {event_id} computed {computed})")

    created_at = _safe_text(payload.get("created_at"))
    _parse_utc(created_at)
    bundle_id = _safe_text(payload.get("bundle_id"))
    if not bundle_id:
        raise ValueError("bundle_id is required")

    from_state = _safe_text(payload.get("from_state"))
    to_state = _safe_text(payload.get("to_state"))
    if from_state not in {"Draft", "Review", "Approved", "Deprecated"}:
        raise ValueError("from_state invalid")
    if to_state not in {"Draft", "Review", "Approved", "Deprecated"}:
        raise ValueError("to_state invalid")

    policy_id = _safe_text(payload.get("policy_id"))
    if not policy_id:
        raise ValueError("policy_id is required")
    policy_hash = _safe_text(payload.get("policy_hash"))
    if not _is_sha256_prefixed(policy_hash):
        raise ValueError("policy_hash must be sha256:<hex>")

    checks_digest = _safe_text(payload.get("checks_digest"))
    if not _is_sha256_prefixed(checks_digest):
        raise ValueError("checks_digest must be sha256:<hex>")
    checks_report_relpath = _safe_text(payload.get("checks_report_relpath"))
    _validate_relpath(checks_report_relpath)
    rationale_ref = _safe_text(payload.get("rationale_ref"))
    _validate_relpath(rationale_ref)

    approval_surface_hash = _safe_text(payload.get("approval_surface_hash"))
    if not _is_sha256_prefixed(approval_surface_hash):
        raise ValueError("approval_surface_hash must be sha256:<hex>")

    supersedes_raw = payload.get("supersedes")
    supersedes = _safe_text(supersedes_raw) if supersedes_raw is not None else ""
    if supersedes:
        if not _is_sha256_prefixed(supersedes):
            raise ValueError("supersedes must be sha256:<hex> when present")
        supersedes_value: str | None = supersedes
    else:
        supersedes_value = None

    return TransitionRequestV1(
        event_type="transition_request_v1",
        ledger_seq=ledger_seq,
        event_id=event_id,
        created_at=created_at,
        bundle_id=bundle_id,
        from_state=from_state,  # type: ignore[assignment]
        to_state=to_state,  # type: ignore[assignment]
        policy_id=policy_id,
        policy_hash=policy_hash,
        checks_digest=checks_digest,
        checks_report_relpath=checks_report_relpath,
        rationale_ref=rationale_ref,
        approval_surface_hash=approval_surface_hash,
        supersedes=supersedes_value,
        raw=dict(payload),
    )


def _validate_transition_request_v2(payload: Mapping[str, Any]) -> TransitionRequestV2:
    allowed = {
        "event_type",
        "ledger_seq",
        "event_id",
        "created_at",
        "bundle_id",
        "from_state",
        "to_state",
        "policy_id",
        "policy_hash",
        "checks_digest",
        "checks_report_relpath",
        "rationale_ref",
        "approval_surface_hash",
        "supersedes",
        "toolchain",
    }
    extras = sorted(k for k in payload.keys() if k not in allowed)
    if extras:
        raise ValueError(f"unexpected keys: {', '.join(extras)}")

    if payload.get("event_type") != "transition_request_v2":
        raise ValueError("event_type const mismatch")

    ledger_seq_raw = payload.get("ledger_seq")
    ledger_seq: int | None = None
    if ledger_seq_raw is not None:
        if not isinstance(ledger_seq_raw, int):
            raise ValueError("ledger_seq must be an integer")
        if ledger_seq_raw < 0:
            raise ValueError("ledger_seq must be >= 0")
        ledger_seq = int(ledger_seq_raw)

    event_id = _safe_text(payload.get("event_id"))
    if not _is_sha256_prefixed(event_id):
        raise ValueError("event_id must be sha256:<hex>")
    computed = _compute_event_id(payload)
    if event_id != computed:
        raise ValueError(f"event_id mismatch (declared {event_id} computed {computed})")

    created_at = _safe_text(payload.get("created_at"))
    _parse_utc(created_at)
    bundle_id = _safe_text(payload.get("bundle_id"))
    if not bundle_id:
        raise ValueError("bundle_id is required")

    from_state = _safe_text(payload.get("from_state"))
    to_state = _safe_text(payload.get("to_state"))
    if from_state not in {"Draft", "Review", "Approved", "Deprecated"}:
        raise ValueError("from_state invalid")
    if to_state not in {"Draft", "Review", "Approved", "Deprecated"}:
        raise ValueError("to_state invalid")

    policy_id = _safe_text(payload.get("policy_id"))
    if not policy_id:
        raise ValueError("policy_id is required")
    policy_hash = _safe_text(payload.get("policy_hash"))
    if not _is_sha256_prefixed(policy_hash):
        raise ValueError("policy_hash must be sha256:<hex>")

    checks_digest = _safe_text(payload.get("checks_digest"))
    if not _is_sha256_prefixed(checks_digest):
        raise ValueError("checks_digest must be sha256:<hex>")
    checks_report_relpath = _safe_text(payload.get("checks_report_relpath"))
    _validate_relpath(checks_report_relpath)
    rationale_ref = _safe_text(payload.get("rationale_ref"))
    _validate_relpath(rationale_ref)

    approval_surface_hash = _safe_text(payload.get("approval_surface_hash"))
    if not _is_sha256_prefixed(approval_surface_hash):
        raise ValueError("approval_surface_hash must be sha256:<hex>")

    supersedes_raw = payload.get("supersedes")
    supersedes = _safe_text(supersedes_raw) if supersedes_raw is not None else ""
    if supersedes:
        if not _is_sha256_prefixed(supersedes):
            raise ValueError("supersedes must be sha256:<hex> when present")
        supersedes_value: str | None = supersedes
    else:
        supersedes_value = None

    tc_raw = payload.get("toolchain")
    if not isinstance(tc_raw, Mapping):
        raise ValueError("toolchain must be an object")
    toolchain = _validate_toolchain_v1(tc_raw)

    if toolchain.governance_policy_id != policy_id or toolchain.governance_policy_hash != policy_hash:
        raise ValueError("toolchain governance_policy_* must match policy_*")

    return TransitionRequestV2(
        event_type="transition_request_v2",
        ledger_seq=ledger_seq,
        event_id=event_id,
        created_at=created_at,
        bundle_id=bundle_id,
        from_state=from_state,  # type: ignore[assignment]
        to_state=to_state,  # type: ignore[assignment]
        policy_id=policy_id,
        policy_hash=policy_hash,
        checks_digest=checks_digest,
        checks_report_relpath=checks_report_relpath,
        rationale_ref=rationale_ref,
        approval_surface_hash=approval_surface_hash,
        supersedes=supersedes_value,
        toolchain=toolchain,
        raw=dict(payload),
    )


def _validate_signature_block(sig: Mapping[str, Any]) -> None:
    if sig.get("algorithm") != "ed25519":
        raise ValueError("signature.algorithm must be ed25519")
    canon = sig.get("canonicalization")
    if canon != CANONICALIZATION_ID:
        raise ValueError(f"signature.canonicalization must be {CANONICALIZATION_ID}")
    if not isinstance(sig.get("publicKeyB64"), str) or not _safe_text(sig.get("publicKeyB64")):
        raise ValueError("signature.publicKeyB64 is required")
    if not isinstance(sig.get("signatureB64"), str) or not _safe_text(sig.get("signatureB64")):
        raise ValueError("signature.signatureB64 is required")
    if not _is_sha256_prefixed(sig.get("signedPayloadSha256")):
        raise ValueError("signature.signedPayloadSha256 must be sha256:<hex>")


def _validate_signoff_v1(payload: Mapping[str, Any]) -> SignoffV1:
    allowed = {
        "event_type",
        "ledger_seq",
        "event_id",
        "created_at",
        "transition_event_id",
        "signer_identity",
        "signer_role",
        "signer_key_id",
        "signature",
    }
    extras = sorted(k for k in payload.keys() if k not in allowed)
    if extras:
        raise ValueError(f"unexpected keys: {', '.join(extras)}")
    if payload.get("event_type") != "signoff_v1":
        raise ValueError("event_type const mismatch")

    ledger_seq_raw = payload.get("ledger_seq")
    ledger_seq: int | None = None
    if ledger_seq_raw is not None:
        if not isinstance(ledger_seq_raw, int):
            raise ValueError("ledger_seq must be an integer")
        if ledger_seq_raw < 0:
            raise ValueError("ledger_seq must be >= 0")
        ledger_seq = int(ledger_seq_raw)

    event_id = _safe_text(payload.get("event_id"))
    if not _is_sha256_prefixed(event_id):
        raise ValueError("event_id must be sha256:<hex>")
    computed = _compute_event_id(payload)
    if event_id != computed:
        raise ValueError(f"event_id mismatch (declared {event_id} computed {computed})")

    created_at = _safe_text(payload.get("created_at"))
    _parse_utc(created_at)

    transition_event_id = _safe_text(payload.get("transition_event_id"))
    if not _is_sha256_prefixed(transition_event_id):
        raise ValueError("transition_event_id must be sha256:<hex>")

    signer_identity = _safe_text(payload.get("signer_identity"))
    if not signer_identity:
        raise ValueError("signer_identity is required")
    signer_role = _safe_text(payload.get("signer_role"))
    if signer_role not in {"scientific_owner", "safety_reviewer", "compliance_reviewer"}:
        raise ValueError("signer_role invalid")
    signer_key_id = _safe_text(payload.get("signer_key_id"))
    if not signer_key_id:
        raise ValueError("signer_key_id is required")

    sig = payload.get("signature")
    if not isinstance(sig, Mapping):
        raise ValueError("signature must be an object")
    _validate_signature_block(sig)

    return SignoffV1(
        event_type="signoff_v1",
        ledger_seq=ledger_seq,
        event_id=event_id,
        created_at=created_at,
        transition_event_id=transition_event_id,
        signer_identity=signer_identity,
        signer_role=signer_role,  # type: ignore[assignment]
        signer_key_id=signer_key_id,
        signature=dict(sig),
        raw=dict(payload),
    )


def _validate_signoff_v2(payload: Mapping[str, Any]) -> SignoffV2:
    allowed = {
        "event_type",
        "ledger_seq",
        "event_id",
        "created_at",
        "transition_event_id",
        "signer_identity",
        "signer_role",
        "signer_key_id",
        "toolchain",
        "signature",
    }
    extras = sorted(k for k in payload.keys() if k not in allowed)
    if extras:
        raise ValueError(f"unexpected keys: {', '.join(extras)}")
    if payload.get("event_type") != "signoff_v2":
        raise ValueError("event_type const mismatch")

    ledger_seq_raw = payload.get("ledger_seq")
    ledger_seq: int | None = None
    if ledger_seq_raw is not None:
        if not isinstance(ledger_seq_raw, int):
            raise ValueError("ledger_seq must be an integer")
        if ledger_seq_raw < 0:
            raise ValueError("ledger_seq must be >= 0")
        ledger_seq = int(ledger_seq_raw)

    event_id = _safe_text(payload.get("event_id"))
    if not _is_sha256_prefixed(event_id):
        raise ValueError("event_id must be sha256:<hex>")
    computed = _compute_event_id(payload)
    if event_id != computed:
        raise ValueError(f"event_id mismatch (declared {event_id} computed {computed})")

    created_at = _safe_text(payload.get("created_at"))
    _parse_utc(created_at)

    transition_event_id = _safe_text(payload.get("transition_event_id"))
    if not _is_sha256_prefixed(transition_event_id):
        raise ValueError("transition_event_id must be sha256:<hex>")

    signer_identity = _safe_text(payload.get("signer_identity"))
    if not signer_identity:
        raise ValueError("signer_identity is required")
    signer_role = _safe_text(payload.get("signer_role"))
    if signer_role not in {"scientific_owner", "safety_reviewer", "compliance_reviewer"}:
        raise ValueError("signer_role invalid")
    signer_key_id = _safe_text(payload.get("signer_key_id"))
    if not signer_key_id:
        raise ValueError("signer_key_id is required")

    tc_raw = payload.get("toolchain")
    if not isinstance(tc_raw, Mapping):
        raise ValueError("toolchain must be an object")
    toolchain = _validate_toolchain_v1(tc_raw)

    sig = payload.get("signature")
    if not isinstance(sig, Mapping):
        raise ValueError("signature must be an object")
    _validate_signature_block(sig)

    return SignoffV2(
        event_type="signoff_v2",
        ledger_seq=ledger_seq,
        event_id=event_id,
        created_at=created_at,
        transition_event_id=transition_event_id,
        signer_identity=signer_identity,
        signer_role=signer_role,  # type: ignore[assignment]
        signer_key_id=signer_key_id,
        toolchain=toolchain,
        signature=dict(sig),
        raw=dict(payload),
    )


def _validate_waiver_v1(payload: Mapping[str, Any]) -> WaiverV1:
    allowed = {
        "event_type",
        "ledger_seq",
        "event_id",
        "created_at",
        "bundle_id",
        "waived_transition_id",
        "waived_check_id",
        "waiver_scope",
        "justification",
        "signer_identity",
        "signer_role",
        "signer_key_id",
        "signature",
    }
    extras = sorted(k for k in payload.keys() if k not in allowed)
    if extras:
        raise ValueError(f"unexpected keys: {', '.join(extras)}")
    if payload.get("event_type") != "waiver_v1":
        raise ValueError("event_type const mismatch")

    ledger_seq_raw = payload.get("ledger_seq")
    ledger_seq: int | None = None
    if ledger_seq_raw is not None:
        if not isinstance(ledger_seq_raw, int):
            raise ValueError("ledger_seq must be an integer")
        if ledger_seq_raw < 0:
            raise ValueError("ledger_seq must be >= 0")
        ledger_seq = int(ledger_seq_raw)

    event_id = _safe_text(payload.get("event_id"))
    if not _is_sha256_prefixed(event_id):
        raise ValueError("event_id must be sha256:<hex>")
    computed = _compute_event_id(payload)
    if event_id != computed:
        raise ValueError(f"event_id mismatch (declared {event_id} computed {computed})")

    created_at = _safe_text(payload.get("created_at"))
    _parse_utc(created_at)

    bundle_id = _safe_text(payload.get("bundle_id"))
    if not bundle_id:
        raise ValueError("bundle_id is required")

    waived_transition_id = _safe_text(payload.get("waived_transition_id"))
    if not _is_sha256_prefixed(waived_transition_id):
        raise ValueError("waived_transition_id must be sha256:<hex>")
    waived_check_id_raw = payload.get("waived_check_id")
    waived_check_id = _safe_text(waived_check_id_raw) if isinstance(waived_check_id_raw, str) else None

    waiver_scope = _safe_text(payload.get("waiver_scope"))
    if not waiver_scope:
        raise ValueError("waiver_scope is required")
    justification = _safe_text(payload.get("justification"))
    if not justification:
        raise ValueError("justification is required")

    signer_identity = _safe_text(payload.get("signer_identity"))
    if not signer_identity:
        raise ValueError("signer_identity is required")
    signer_role = _safe_text(payload.get("signer_role"))
    if signer_role not in {"scientific_owner", "safety_reviewer", "compliance_reviewer"}:
        raise ValueError("signer_role invalid")
    signer_key_id = _safe_text(payload.get("signer_key_id"))
    if not signer_key_id:
        raise ValueError("signer_key_id is required")

    sig = payload.get("signature")
    if not isinstance(sig, Mapping):
        raise ValueError("signature must be an object")
    _validate_signature_block(sig)

    return WaiverV1(
        event_type="waiver_v1",
        ledger_seq=ledger_seq,
        event_id=event_id,
        created_at=created_at,
        bundle_id=bundle_id,
        waived_transition_id=waived_transition_id,
        waived_check_id=waived_check_id,
        waiver_scope=waiver_scope,
        justification=justification,
        signer_identity=signer_identity,
        signer_role=signer_role,  # type: ignore[assignment]
        signer_key_id=signer_key_id,
        signature=dict(sig),
        raw=dict(payload),
    )


def load_governance_events_from_bundle(
    bundle_path: str | Path,
) -> tuple[tuple[TransitionRequest, ...], tuple[Signoff, ...], tuple[WaiverV1, ...], tuple[LedgerIssue, ...]]:
    _verify_schema_hashes()

    issues: list[LedgerIssue] = []
    transitions: list[TransitionRequest] = []
    signoffs: list[Signoff] = []
    waivers: list[WaiverV1] = []

    for rel in _iter_bundle_files(bundle_path, prefix="governance/ledger"):
        if not rel.endswith(".json"):
            continue
        try:
            raw = _read_bundle_file_bytes(bundle_path, rel)
            payload = json.loads(raw.decode("utf-8"))
            if not isinstance(payload, Mapping):
                raise ValueError("event must be a JSON object")
            event_type = payload.get("event_type")
            if event_type == "transition_request_v1":
                transitions.append(_validate_transition_request_v1(payload))
            elif event_type == "transition_request_v2":
                transitions.append(_validate_transition_request_v2(payload))
            elif event_type == "signoff_v1":
                signoffs.append(_validate_signoff_v1(payload))
            elif event_type == "signoff_v2":
                signoffs.append(_validate_signoff_v2(payload))
            elif event_type == "waiver_v1":
                waivers.append(_validate_waiver_v1(payload))
            else:
                raise ValueError(f"unknown event_type: {event_type!r}")
        except Exception as exc:
            issues.append(LedgerIssue(code="LEDGER_EVENT_INVALID", details={"path": rel, "error": str(exc)}))

    def _order_key(seq: int | None, event_id: str) -> tuple[int, int, str]:
        if seq is None:
            return (0, 0, event_id)
        return (1, int(seq), event_id)

    transitions_sorted = sorted(transitions, key=lambda e: _order_key(e.ledger_seq, e.event_id))
    signoffs_sorted = sorted(signoffs, key=lambda e: _order_key(e.ledger_seq, e.event_id))
    waivers_sorted = sorted(waivers, key=lambda e: _order_key(e.ledger_seq, e.event_id))
    return (
        tuple(transitions_sorted),
        tuple(signoffs_sorted),
        tuple(waivers_sorted),
        tuple(issues),
    )


def next_ledger_seq(bundle_path: str | Path) -> int:
    """
    Compute the next append-order sequence number for governance/ledger events.

    Notes:
      - This is best-effort and deterministic for a given on-disk ledger.
      - If existing events already carry ledger_seq, we use max+1.
      - Otherwise we fall back to the count of existing ledger *.json files.
    """

    max_seq = -1
    count = 0
    for rel in _iter_bundle_files(bundle_path, prefix="governance/ledger"):
        if not rel.endswith(".json"):
            continue
        count += 1
        try:
            raw = _read_bundle_file_bytes(bundle_path, rel)
            payload = json.loads(raw.decode("utf-8"))
        except Exception:
            continue
        if not isinstance(payload, Mapping):
            continue
        seq = payload.get("ledger_seq")
        if isinstance(seq, int) and seq >= 0:
            max_seq = max(max_seq, int(seq))

    if max_seq >= 0:
        return int(max_seq) + 1
    return int(count)


@contextmanager
def ledger_write_lock(bundle_path: str | Path, *, timeout_s: float = 10.0, poll_s: float = 0.05) -> Any:
    """
    Best-effort filesystem lock for governance/ledger writes.

    This prevents trivial concurrent-writer races (two processes choosing the same ledger_seq).
    """

    root, mode = _bundle_root_and_mode(bundle_path)
    if mode != "dir":
        raise GovernanceLedgerError("governance ledger write lock requires a bundle directory")

    ledger_dir = root / "governance" / "ledger"
    ledger_dir.mkdir(parents=True, exist_ok=True)
    lock_path = ledger_dir / ".lock"

    from helix.determinism.nondet import allow_nondeterminism

    with allow_nondeterminism("ledger_write_lock"):
        start = clock.monotonic()
        fd: int | None = None
        while True:
            try:
                fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                break
            except FileExistsError:
                if clock.monotonic() - start >= float(timeout_s):
                    raise GovernanceLedgerError(f"timed out waiting for ledger lock: {lock_path}")
                time.sleep(float(poll_s))

    try:
        try:
            os.write(fd, f"pid={os.getpid()}\n".encode("utf-8"))
        except Exception:
            pass
        yield
    finally:
        try:
            if fd is not None:
                os.close(fd)
        except Exception:
            pass
        try:
            lock_path.unlink()
        except FileNotFoundError:
            pass


def _verify_signer_key_id_matches_license(
    *,
    signer_key_id: str,
    signer_public_key_raw: bytes,
    license_obj: HelixLicenseV1,
) -> bool:
    for k in license_obj.signing_keys:
        if k.key_id != signer_key_id:
            continue
        return k.public_key_raw == signer_public_key_raw
    return False


def _verify_signed_event(
    payload: Mapping[str, Any],
    *,
    license_obj: HelixLicenseV1 | None,
    signer_key_id: str,
) -> tuple[bool, str | None]:
    if license_obj is None or not license_obj.signing_keys:
        return False, "license missing signing_keys"
    allowed = [k.public_key_raw for k in license_obj.signing_keys]
    try:
        _signed_sha, signer_pub_raw = verify_ed25519_signature(
            payload,
            allowed_public_keys_raw=allowed,
            require_allowed_key=True,
        )
    except Exception as exc:
        return False, f"signature invalid: {exc}"
    if not _verify_signer_key_id_matches_license(
        signer_key_id=signer_key_id,
        signer_public_key_raw=signer_pub_raw,
        license_obj=license_obj,
    ):
        return False, "signer_key_id does not match license key"
    return True, None


def _load_check_report(bundle_path: str | Path, relpath: str) -> dict[str, Any] | None:
    try:
        raw = _read_bundle_file_bytes(bundle_path, relpath)
    except Exception:
        return None
    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(payload, Mapping):
        return None
    return dict(payload)


def _check_report_digest(payload: Mapping[str, Any]) -> str:
    return sha256_prefixed(dict(payload))


def _required_checks_satisfied(
    *,
    report: Mapping[str, Any] | None,
    required_checks: Sequence[str],
) -> tuple[bool, str | None]:
    if not required_checks:
        return True, None
    if report is None:
        return False, "checks report missing"
    results = report.get("results")
    if not isinstance(results, list):
        return False, "checks report missing results"
    statuses: dict[str, str] = {}
    for item in results:
        if not isinstance(item, Mapping):
            continue
        check_id = _safe_text(item.get("check_id"))
        status = _safe_text(item.get("status"))
        if check_id:
            statuses[check_id] = status
    missing = [c for c in required_checks if c not in statuses]
    if missing:
        return False, f"checks report missing required checks: {', '.join(missing)}"
    failing = [c for c in required_checks if statuses.get(c) != "pass"]
    if failing:
        return False, f"required checks not passing: {', '.join(failing)}"
    return True, None


def _count_signoffs(
    signoffs: Sequence[Signoff],
    *,
    required: Mapping[GovernanceRole, int],
) -> dict[GovernanceRole, int]:
    counts: dict[GovernanceRole, int] = {k: 0 for k in required.keys()}
    seen: set[tuple[str, str, str]] = set()
    for s in signoffs:
        key = (s.signer_role, s.signer_identity, s.signer_key_id)
        if key in seen:
            continue
        seen.add(key)
        if s.signer_role in counts:
            counts[s.signer_role] += 1
    return counts


def _signoffs_satisfy_policy(
    signoffs: Sequence[Signoff],
    *,
    required: Mapping[GovernanceRole, int],
) -> bool:
    if not required:
        return True
    counts = _count_signoffs(signoffs, required=required)
    for role, needed in required.items():
        if counts.get(role, 0) < int(needed):
            return False
    return True


def _waivers_satisfy_policy(
    waivers: Sequence[WaiverV1],
    *,
    waiver_scope: str,
    waived_transition_id: str,
    required: Mapping[GovernanceRole, int],
) -> bool:
    if not required:
        return False
    relevant = [w for w in waivers if w.waiver_scope == waiver_scope and w.waived_transition_id == waived_transition_id]
    counts: dict[GovernanceRole, int] = {k: 0 for k in required.keys()}
    seen: set[tuple[str, str, str]] = set()
    for w in relevant:
        key = (w.signer_role, w.signer_identity, w.signer_key_id)
        if key in seen:
            continue
        seen.add(key)
        if w.signer_role in counts:
            counts[w.signer_role] += 1
    for role, needed in required.items():
        if counts.get(role, 0) < int(needed):
            return False
    return True


def _allowed_transition(from_state: LifecycleState, to_state: LifecycleState) -> bool:
    allowed = {
        ("Draft", "Review"),
        ("Review", "Approved"),
        ("Approved", "Deprecated"),
        ("Review", "Draft"),
    }
    return (from_state, to_state) in allowed


def compute_governance_state(bundle_path: str | Path, *, policy_path: str | Path | None = None) -> GovernanceState:
    policy = load_governance_policy_v1(policy_path=policy_path)

    manifest: dict[str, Any] | None = None
    bundle_id: str | None = None
    try:
        manifest = _load_bundle_manifest(bundle_path)
        bundle_id = _safe_text(manifest.get("bundle_id")) or None
    except Exception:
        manifest = None
        bundle_id = None

    current_surface_hash: str | None = None
    if manifest is not None:
        try:
            current_surface_hash = compute_approval_surface_hash_from_manifest(manifest)
        except Exception:
            current_surface_hash = None

    transitions, signoffs, waivers, issues = load_governance_events_from_bundle(bundle_path)
    license_obj = _load_license_from_bundle(bundle_path)

    # Signature verification is strict: invalid signed events are ignored for effectiveness but reported.
    signoff_by_id: dict[str, Signoff] = {s.event_id: s for s in signoffs}
    waiver_by_id: dict[str, WaiverV1] = {w.event_id: w for w in waivers}
    verified_signoff_ids: set[str] = set()
    verified_waiver_ids: set[str] = set()
    issues_out: list[LedgerIssue] = list(issues)

    # Guardrail: transition_request events must not have conflicting ledger_seq values.
    # If collisions exist, we treat those transition requests as ineligible to avoid silently
    # selecting a winner by hash tie-break.
    blocked_transition_ids: set[str] = set()
    seq_to_ids: dict[int, list[str]] = {}
    for t in transitions:
        if t.ledger_seq is None:
            continue
        seq_to_ids.setdefault(int(t.ledger_seq), []).append(t.event_id)
    collisions: list[dict[str, Any]] = []
    for seq, ids in sorted(seq_to_ids.items(), key=lambda it: it[0]):
        uniq = sorted(set(ids))
        if len(uniq) <= 1:
            continue
        blocked_transition_ids.update(uniq)
        collisions.append({"ledger_seq": int(seq), "event_ids": uniq})
    if collisions:
        issues_out.append(
            LedgerIssue(
                code="LEDGER_SEQ_COLLISION",
                details={
                    "event_type": "transition_request",
                    "collisions": collisions,
                    "remediation": "Resolve by deleting or superseding conflicting transition_request events; do not edit existing event_ids in place.",
                },
            )
        )

    for s in signoffs:
        ok, err = _verify_signed_event(s.raw, license_obj=license_obj, signer_key_id=s.signer_key_id)
        if not ok:
            issues_out.append(
                LedgerIssue(
                    code="LEDGER_SIGNOFF_INVALID",
                    details={"event_id": s.event_id, "transition_event_id": s.transition_event_id, "error": err},
                )
            )
            continue
        verified_signoff_ids.add(s.event_id)

    for w in waivers:
        ok, err = _verify_signed_event(w.raw, license_obj=license_obj, signer_key_id=w.signer_key_id)
        if not ok:
            issues_out.append(
                LedgerIssue(
                    code="LEDGER_WAIVER_INVALID",
                    details={"event_id": w.event_id, "waived_transition_id": w.waived_transition_id, "error": err},
                )
            )
            continue
        verified_waiver_ids.add(w.event_id)

    # Replay transition requests in deterministic, "latest wins" order.
    #
    # We treat governance state as computed over the *entire* ledger snapshot (not incremental time),
    # so a newer transition_request can supersede older competing requests regardless of timestamp.
    state: LifecycleState = "Draft"
    effective_transition: TransitionRequest | None = None

    state_rank: dict[LifecycleState, int] = {"Draft": 0, "Review": 1, "Approved": 2, "Deprecated": 3}

    def _order_key(seq: int | None, event_id: str) -> tuple[int, int, str]:
        if seq is None:
            return (0, 0, event_id)
        return (1, int(seq), event_id)

    def _is_regressive(from_state: LifecycleState, to_state: LifecycleState) -> bool:
        return state_rank[to_state] < state_rank[from_state]

    def _seq_value(seq: int | None) -> int:
        return int(seq) if isinstance(seq, int) else 0

    applied_transition_ids: set[str] = set()
    verified_signoffs_by_transition: dict[str, list[Signoff]] = {}
    verified_waivers: list[WaiverV1] = []
    for s in signoffs:
        if s.event_id in verified_signoff_ids:
            verified_signoffs_by_transition.setdefault(s.transition_event_id, []).append(s)
    for w in waivers:
        if w.event_id in verified_waiver_ids:
            verified_waivers.append(w)

    while True:
        candidates = [
            t
            for t in transitions
            if t.event_id not in applied_transition_ids and t.event_id not in blocked_transition_ids and t.from_state == state
        ]
        candidates.sort(key=lambda t: _order_key(t.ledger_seq, t.event_id), reverse=True)

        advanced = False
        for t in candidates:
            # Guardrail for "revision loops": do not allow an old regressive transition (e.g. Review->Draft)
            # to apply after a newer entry into the current state (e.g. Draft->Review). Without this, a
            # typical Review->Draft->Review workflow can end up reporting the *oldest* Review entry as
            # effective due to cycle exhaustion.
            if _is_regressive(t.from_state, t.to_state) and effective_transition is not None:
                entered_seq = _seq_value(effective_transition.ledger_seq)
                if _seq_value(t.ledger_seq) < entered_seq:
                    continue
            if not _allowed_transition(t.from_state, t.to_state):
                continue
            if bundle_id is not None and t.bundle_id != bundle_id:
                continue
            if t.policy_id != policy.policy_id or t.policy_hash != policy.policy_hash:
                continue

            # Check report digest must match.
            report = _load_check_report(bundle_path, t.checks_report_relpath)
            if report is None:
                continue
            computed_digest = _check_report_digest(report)
            if computed_digest != t.checks_digest:
                continue

            # Required checks must be satisfied.
            required_checks = policy.required_checks(to_state=t.to_state)
            ok_checks, _err = _required_checks_satisfied(report=report, required_checks=required_checks)
            if not ok_checks:
                continue

            # Required signoffs must be present.
            required_roles = policy.required_signoffs(to_state=t.to_state)
            s_for_t = verified_signoffs_by_transition.get(t.event_id, [])
            if not _signoffs_satisfy_policy(s_for_t, required=required_roles):
                continue

            # Change control: surface hash must match, unless waived.
            if current_surface_hash is not None and t.approval_surface_hash != current_surface_hash:
                waiver_required = policy.waiver_required_signoffs(waiver_scope="approval_surface_mismatch")
                if not _waivers_satisfy_policy(
                    verified_waivers,
                    waiver_scope="approval_surface_mismatch",
                    waived_transition_id=t.event_id,
                    required=waiver_required,
                ):
                    continue

            state = t.to_state
            effective_transition = t
            applied_transition_ids.add(t.event_id)
            advanced = True
            break

        if not advanced:
            break

    # Record high-signal issues that impact the final effective transition.
    if effective_transition is not None:
        t = effective_transition
        if manifest is None:
            issues_out.append(LedgerIssue(code="LEDGER_MANIFEST_MISSING", details={"reason": "manifest not readable"}))
        if bundle_id is not None and t.bundle_id != bundle_id:
            issues_out.append(
                LedgerIssue(
                    code="LEDGER_BUNDLE_ID_MISMATCH",
                    details={"transition_bundle_id": t.bundle_id, "manifest_bundle_id": bundle_id},
                )
            )
        if t.policy_id != policy.policy_id or t.policy_hash != policy.policy_hash:
            issues_out.append(
                LedgerIssue(
                    code="LEDGER_POLICY_MISMATCH",
                    details={"transition_policy_id": t.policy_id, "transition_policy_hash": t.policy_hash, "policy_id": policy.policy_id, "policy_hash": policy.policy_hash},
                )
            )
        report = _load_check_report(bundle_path, t.checks_report_relpath)
        if report is None:
            issues_out.append(LedgerIssue(code="LEDGER_CHECK_REPORT_MISSING", details={"path": t.checks_report_relpath}))
        else:
            computed_digest = _check_report_digest(report)
            if computed_digest != t.checks_digest:
                issues_out.append(
                    LedgerIssue(
                        code="LEDGER_CHECK_DIGEST_MISMATCH",
                        details={"expected": t.checks_digest, "computed": computed_digest, "path": t.checks_report_relpath},
                    )
                )

    effective_signoffs: tuple[Signoff, ...] = ()
    effective_waivers: tuple[WaiverV1, ...] = ()
    if effective_transition is not None:
        effective_signoffs = tuple(verified_signoffs_by_transition.get(effective_transition.event_id, []))
        effective_waivers = tuple(w for w in verified_waivers if w.waived_transition_id == effective_transition.event_id)

    return GovernanceState(
        bundle_id=bundle_id,
        state=state,
        effective_transition_id=(effective_transition.event_id if effective_transition else None),
        effective_transition=effective_transition,
        effective_signoffs=effective_signoffs,
        effective_waivers=effective_waivers,
        current_approval_surface_hash=current_surface_hash,
        issues=tuple(issues_out),
        policy=policy,
    )


def build_check_report_v1(
    *,
    bundle_id: str,
    to_state: LifecycleState,
    policy: GovernancePolicyV1,
    bundle_integrity_ok: bool,
    decision_log_present: bool,
    approval_surface_hash_present: bool,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    results: list[dict[str, Any]] = []

    def add(check_id: str, ok: bool, details: Mapping[str, Any] | None = None) -> None:
        results.append(
            {
                "check_id": str(check_id),
                "status": "pass" if ok else "fail",
                "details": dict(details or {}),
            }
        )

    add("bundle_integrity", bool(bundle_integrity_ok))
    add("decision_log_present", bool(decision_log_present))
    add("approval_surface_hash_present", bool(approval_surface_hash_present))

    report: dict[str, Any] = {
        "schema": "helix.governance.check_report.v1",
        "created_at": clock.utc_now_iso(),
        "bundle_id": bundle_id,
        "policy_id": policy.policy_id,
        "policy_hash": policy.policy_hash,
        "to_state": to_state,
        "required_checks": list(policy.required_checks(to_state=to_state)),
        "results": sorted(results, key=lambda r: str(r.get("check_id") or "")),
    }
    if isinstance(extra, Mapping):
        report["extra"] = dict(extra)
    return report


def sign_payload_ed25519(
    unsigned_payload: Mapping[str, Any],
    *,
    private_key_raw: bytes,
) -> dict[str, Any]:
    from helix.licensing.verify import sign_ed25519

    msg = canonical_json_bytes(dict(unsigned_payload))
    signed_sha = f"sha256:{_sha256_hex(msg)}"
    sig_raw, pk_raw = sign_ed25519(msg, private_key_raw=private_key_raw)
    return {
        "algorithm": "ed25519",
        "canonicalization": CANONICALIZATION_ID,
        "publicKeyB64": base64.b64encode(pk_raw).decode("ascii"),
        "signatureB64": base64.b64encode(sig_raw).decode("ascii"),
        "signedPayloadSha256": signed_sha,
    }


def governance_mode() -> str:
    from helix.user_config import resolve_setting_str

    mode = str(
        resolve_setting_str(
            env_var="HELIX_GOVERNANCE_MODE",
            config_key="governance_mode",
            default="warn",
        )
        or "warn"
    ).strip().lower()
    if mode in {"off", "warn", "enforce"}:
        return mode
    return "warn"
