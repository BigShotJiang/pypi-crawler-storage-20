from __future__ import annotations

import os
from dataclasses import dataclass

from helix import __version__
from helix.governance.ledger import governance_mode
from helix.user_config import load_user_profile


def _env_bool(name: str, *, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    token = raw.strip().lower()
    if token in {"", "0", "false", "no", "off"}:
        return False
    if token in {"1", "true", "yes", "on"}:
        return True
    return default


def _fmt_bool(value: bool) -> str:
    return "yes" if value else "no"


def _fmt_present(value: str | None) -> str:
    return "present" if str(value or "").strip() else "missing"


@dataclass(frozen=True, slots=True)
class EnforcementPosture:
    helix_version: str
    governance_mode: str
    registry_url: str | None
    registry_token_present: bool
    registry_allow_unregistered_export: bool
    registry_required: bool
    blob_backend: str
    s3_bucket: str | None
    s3_prefix: str | None
    s3_endpoint_url: str | None
    s3_addressing_style: str | None
    s3_connect_timeout_s: int | None
    s3_read_timeout_s: int | None
    s3_retry_max_attempts: int | None
    s3_retry_mode: str | None
    s3_strict_no_overwrite: bool | None


def load_enforcement_posture() -> EnforcementPosture:
    mode = governance_mode()
    cfg = load_user_profile().values

    registry_url = str(os.environ.get("HELIX_REGISTRY_URL") or "").strip() or None
    if registry_url is None:
        registry_url = str(cfg.get("registry_url") or "").strip() or None
    registry_token = str(os.environ.get("HELIX_REGISTRY_TOKEN") or "").strip() or None
    registry_allow_unregistered = _env_bool("HELIX_REGISTRY_ALLOW_UNREGISTERED_EXPORT", default=False)
    registry_required = bool(registry_url and mode == "enforce" and not registry_allow_unregistered)

    blob_backend = str(os.environ.get("HELIX_BLOB_BACKEND") or "").strip().lower()
    if not blob_backend:
        blob_backend = str(cfg.get("blob_backend") or "fs").strip().lower()
    blob_backend = blob_backend or "fs"

    s3_bucket = None
    s3_prefix = None
    s3_endpoint_url = None
    s3_addressing_style = None
    s3_connect_timeout_s = None
    s3_read_timeout_s = None
    s3_retry_max_attempts = None
    s3_retry_mode = None
    s3_strict_no_overwrite = None
    if blob_backend == "s3":
        s3_bucket = str(os.environ.get("HELIX_S3_BUCKET") or "").strip() or None
        if s3_bucket is None:
            s3_bucket = str(cfg.get("s3_bucket") or "").strip() or None
        s3_prefix = str(os.environ.get("HELIX_S3_PREFIX") or "").strip() or None
        if s3_prefix is None:
            s3_prefix = str(cfg.get("s3_prefix") or "").strip() or None
        s3_endpoint_url = str(os.environ.get("HELIX_S3_ENDPOINT_URL") or "").strip() or None
        if s3_endpoint_url is None:
            s3_endpoint_url = str(cfg.get("s3_endpoint_url") or "").strip() or None
        s3_addressing_style = str(os.environ.get("HELIX_S3_ADDRESSING_STYLE") or "").strip() or None
        if not s3_addressing_style:
            s3_addressing_style = str(cfg.get("s3_addressing_style") or "auto").strip() or None
        connect_timeout_raw = str(os.environ.get("HELIX_S3_CONNECT_TIMEOUT") or "").strip()
        if connect_timeout_raw:
            s3_connect_timeout_s = int(connect_timeout_raw)
        else:
            s3_connect_timeout_s = int(str(cfg.get("s3_connect_timeout_s") or "5").strip())
        read_timeout_raw = str(os.environ.get("HELIX_S3_READ_TIMEOUT") or "").strip()
        if read_timeout_raw:
            s3_read_timeout_s = int(read_timeout_raw)
        else:
            s3_read_timeout_s = int(str(cfg.get("s3_read_timeout_s") or "60").strip())
        retry_max_raw = str(os.environ.get("HELIX_S3_RETRY_MAX_ATTEMPTS") or "").strip()
        if retry_max_raw:
            s3_retry_max_attempts = int(retry_max_raw)
        else:
            s3_retry_max_attempts = int(str(cfg.get("s3_retry_max_attempts") or "10").strip())
        s3_retry_mode = str(os.environ.get("HELIX_S3_RETRY_MODE") or "").strip() or None
        if s3_retry_mode is None:
            s3_retry_mode = str(cfg.get("s3_retry_mode") or "standard").strip() or None
        if "HELIX_S3_STRICT_NO_OVERWRITE" in os.environ:
            s3_strict_no_overwrite = _env_bool("HELIX_S3_STRICT_NO_OVERWRITE", default=False)
        else:
            raw = cfg.get("s3_strict_no_overwrite")
            if isinstance(raw, bool):
                s3_strict_no_overwrite = bool(raw)
            elif isinstance(raw, str):
                token = raw.strip().lower()
                if token in {"1", "true", "yes", "on"}:
                    s3_strict_no_overwrite = True
                elif token in {"0", "false", "no", "off"}:
                    s3_strict_no_overwrite = False
                else:
                    s3_strict_no_overwrite = _env_bool("HELIX_S3_STRICT_NO_OVERWRITE", default=False)
            else:
                s3_strict_no_overwrite = _env_bool("HELIX_S3_STRICT_NO_OVERWRITE", default=False)

    return EnforcementPosture(
        helix_version=__version__,
        governance_mode=mode,
        registry_url=registry_url,
        registry_token_present=bool(registry_token),
        registry_allow_unregistered_export=registry_allow_unregistered,
        registry_required=registry_required,
        blob_backend=blob_backend,
        s3_bucket=s3_bucket,
        s3_prefix=s3_prefix,
        s3_endpoint_url=s3_endpoint_url,
        s3_addressing_style=s3_addressing_style,
        s3_connect_timeout_s=s3_connect_timeout_s,
        s3_read_timeout_s=s3_read_timeout_s,
        s3_retry_max_attempts=s3_retry_max_attempts,
        s3_retry_mode=s3_retry_mode,
        s3_strict_no_overwrite=s3_strict_no_overwrite,
    )


def format_enforcement_posture(*, include_version: bool = True) -> str:
    p = load_enforcement_posture()
    lines: list[str] = []
    if include_version:
        lines.append(f"helix_version: {p.helix_version}")
    lines.append(f"governance_mode: {p.governance_mode}")
    lines.append(f"registry_url: {p.registry_url or 'none'}")
    lines.append(f"registry_token: {_fmt_present('x' if p.registry_token_present else '')}")
    lines.append(f"registry_allow_unregistered_export: {_fmt_bool(p.registry_allow_unregistered_export)}")
    lines.append(f"registry_required: {_fmt_bool(p.registry_required)}")
    lines.append(f"blob_backend: {p.blob_backend}")
    if p.blob_backend == "s3":
        lines.append(f"s3_bucket: {p.s3_bucket or 'missing'}")
        lines.append(f"s3_prefix: {p.s3_prefix or 'none'}")
        lines.append(f"s3_endpoint_url: {p.s3_endpoint_url or 'none'}")
        lines.append(f"s3_addressing_style: {p.s3_addressing_style or 'auto'}")
        lines.append(f"s3_connect_timeout_s: {p.s3_connect_timeout_s}")
        lines.append(f"s3_read_timeout_s: {p.s3_read_timeout_s}")
        lines.append(f"s3_retry_max_attempts: {p.s3_retry_max_attempts}")
        lines.append(f"s3_retry_mode: {p.s3_retry_mode or 'standard'}")
        lines.append(f"s3_strict_no_overwrite: {_fmt_bool(bool(p.s3_strict_no_overwrite))}")
    return "\n".join(lines) + "\n"
