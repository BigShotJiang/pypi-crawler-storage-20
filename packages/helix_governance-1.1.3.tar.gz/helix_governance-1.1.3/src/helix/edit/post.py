"""Post-processing helpers for edit DAGs."""
from __future__ import annotations

import hashlib
import math
from collections import defaultdict

from .dag import EditDAG, EditNode


def _seq_hash(sequence: str) -> str:
    return hashlib.sha256(sequence.encode("utf-8")).hexdigest()[:16]


def _log_sum_exp(values):
    if not values:
        return float("-inf")
    m = max(values)
    return m + math.log(sum(math.exp(v - m) for v in values))


def dedupe_terminal_nodes(dag: EditDAG) -> EditDAG:
    """
    Merge terminal nodes with identical sequences.

    The log_prob of the canonical node is updated via log-sum-exp; duplicates are removed.
    """
    if not dag.nodes:
        return dag
    root_view = dag.nodes[dag.root_id].genome_view
    chroms = list(root_view.base.sequences.keys())
    groups = defaultdict(list)
    for node in dag.terminal_nodes():
        key = []
        for chrom in chroms:
            seq = node.genome_view.materialize_chrom(chrom)
            key.append(_seq_hash(seq))
        groups[tuple(key)].append(node.id)

    drop_ids = set()
    redirect: dict[str, str] = {}
    for ids in groups.values():
        if len(ids) < 2:
            continue
        kept = ids[0]
        values = [dag.nodes[node_id].log_prob for node_id in ids]
        combined_log_prob = _log_sum_exp(values)
        for dup in ids[1:]:
            redirect[dup] = kept
            drop_ids.add(dup)
        # Replace the kept node so frame snapshots that reference the pre-dedupe node
        # object remain stable (dedupe is applied after frames are emitted).
        kept_node = dag.nodes.get(kept)
        if isinstance(kept_node, EditNode):
            parents = set(kept_node.parents or ())
            for dup in ids[1:]:
                parents.update(dag.nodes.get(dup).parents or ())
            dag.nodes[kept] = EditNode(
                id=kept_node.id,
                genome_view=kept_node.genome_view,
                log_prob=combined_log_prob,
                metadata=dict(kept_node.metadata),
                parents=tuple(sorted(parents)),
                seq_hashes=dict(kept_node.seq_hashes),
                diffs=kept_node.diffs,
            )
        else:  # pragma: no cover - defensive fallback
            try:
                dag.nodes[kept].log_prob = combined_log_prob
            except Exception:
                pass

    if not drop_ids:
        return dag

    if redirect:
        rewired = []
        for edge in dag.edges:
            if edge.source in drop_ids:
                continue
            target = redirect.get(edge.target, edge.target)
            if target != edge.target:
                rewired.append(
                    type(edge)(
                        source=edge.source,
                        target=target,
                        rule_name=edge.rule_name,
                        event=edge.event,
                        metadata=edge.metadata,
                    )
                )
            else:
                rewired.append(edge)
        dag.edges = rewired

    dag.nodes = {node_id: node for node_id, node in dag.nodes.items() if node_id not in drop_ids}
    return dag
