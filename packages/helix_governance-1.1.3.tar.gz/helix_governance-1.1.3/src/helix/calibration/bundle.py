from __future__ import annotations

import hashlib
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from helix import __version__ as HELIX_VERSION
from helix import fs
from helix import clock
from helix.provenance import current_git_sha


class CalibrationBundleError(ValueError):
    pass


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _sha256_prefixed_hex(hex_digest: str) -> str:
    if str(hex_digest).startswith("sha256:"):
        return str(hex_digest)
    return f"sha256:{hex_digest}"


def sha256_prefixed_bytes(data: bytes) -> str:
    return _sha256_prefixed_hex(hashlib.sha256(data).hexdigest())


def canonical_json_bytes(obj: Any) -> bytes:
    text = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
    return text.encode("utf-8")


def _bundle_hash(payload: Mapping[str, Any]) -> str:
    material = dict(payload)
    material.pop("bundle_hash", None)
    return sha256_prefixed_bytes(canonical_json_bytes(material))


def _evaluation_code_hash() -> str:
    try:
        data = Path(__file__).read_bytes()
    except Exception:
        return "sha256:unavailable"
    return sha256_prefixed_bytes(data)


@dataclass(frozen=True)
class CalibrationRecord:
    pred: float
    obs: float
    locus_set: str
    weight: float = 1.0


def _safe_float(value: Any, *, default: float | None = None) -> float | None:
    try:
        x = float(value)
    except Exception:
        return default
    if not (x == x):  # NaN
        return default
    return x


def _load_records(path: Path) -> list[CalibrationRecord]:
    raw = path.read_text(encoding="utf-8").strip()
    if not raw:
        raise CalibrationBundleError("calibration input is empty")

    records_raw: list[Mapping[str, Any]] = []
    if path.suffix.lower() == ".jsonl":
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if isinstance(obj, Mapping):
                records_raw.append(obj)
        return _coerce_records(records_raw)

    parsed = json.loads(raw)
    if isinstance(parsed, list):
        records_raw = [r for r in parsed if isinstance(r, Mapping)]
    elif isinstance(parsed, Mapping):
        items = parsed.get("records")
        if isinstance(items, list):
            records_raw = [r for r in items if isinstance(r, Mapping)]
        else:
            raise CalibrationBundleError("input JSON must be an array or {records:[...]}")
    else:
        raise CalibrationBundleError("input JSON must be an array or object")
    return _coerce_records(records_raw)


def _coerce_records(records: Sequence[Mapping[str, Any]]) -> list[CalibrationRecord]:
    out: list[CalibrationRecord] = []
    for idx, r in enumerate(records):
        pred = _safe_float(r.get("pred"), default=None)
        if pred is None:
            pred = _safe_float(r.get("predicted"), default=None)
        if pred is None:
            pred = _safe_float(r.get("predicted_p"), default=None)
        obs = _safe_float(r.get("obs"), default=None)
        if obs is None:
            obs = _safe_float(r.get("observed"), default=None)
        if obs is None:
            obs = _safe_float(r.get("observed_p"), default=None)
        if pred is None or obs is None:
            raise CalibrationBundleError(f"record[{idx}] missing pred/obs")
        pred_f = max(0.0, min(1.0, float(pred)))
        obs_f = max(0.0, min(1.0, float(obs)))
        locus_set = str(r.get("locus_set") or r.get("locusSet") or r.get("set") or "overall")
        w = _safe_float(r.get("weight"), default=1.0)
        w_f = float(w) if w is not None and float(w) > 0 else 1.0
        out.append(CalibrationRecord(pred=pred_f, obs=obs_f, locus_set=locus_set, weight=w_f))
    if not out:
        raise CalibrationBundleError("no usable calibration records")
    return out


def _pearson_r(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    if len(xs) != len(ys) or len(xs) < 2:
        return None
    mean_x = sum(xs) / float(len(xs))
    mean_y = sum(ys) / float(len(ys))
    num = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))
    den_x = sum((x - mean_x) ** 2 for x in xs)
    den_y = sum((y - mean_y) ** 2 for y in ys)
    den = (den_x * den_y) ** 0.5
    if den <= 0.0:
        return None
    return float(num / den)


def _rmse(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    if len(xs) != len(ys) or not xs:
        return None
    mse = sum((x - y) ** 2 for x, y in zip(xs, ys)) / float(len(xs))
    return float(mse**0.5)


def _mae(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    if len(xs) != len(ys) or not xs:
        return None
    return float(sum(abs(x - y) for x, y in zip(xs, ys)) / float(len(xs)))


def _bias(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    if len(xs) != len(ys) or not xs:
        return None
    return float(sum((x - y) for x, y in zip(xs, ys)) / float(len(xs)))


def _curve(records: Sequence[CalibrationRecord], *, bins: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    b = max(2, int(bins))
    edges = [i / float(b) for i in range(b + 1)]
    buckets: list[list[CalibrationRecord]] = [[] for _ in range(b)]
    for r in records:
        idx = int(min(b - 1, max(0, int(r.pred * b))))
        buckets[idx].append(r)

    curve: list[dict[str, Any]] = []
    pred_all: list[float] = []
    obs_all: list[float] = []
    bucket_weights: list[float] = []
    for i in range(b):
        bucket = buckets[i]
        if not bucket:
            curve.append({"bin_lo": edges[i], "bin_hi": edges[i + 1], "n": 0, "pred_mean": None, "obs_mean": None})
            bucket_weights.append(0.0)
            continue
        wsum = sum(float(r.weight) for r in bucket) or 1.0
        pred_mean = sum(float(r.pred) * float(r.weight) for r in bucket) / wsum
        obs_mean = sum(float(r.obs) * float(r.weight) for r in bucket) / wsum
        curve.append(
            {
                "bin_lo": edges[i],
                "bin_hi": edges[i + 1],
                "n": len(bucket),
                "pred_mean": float(pred_mean),
                "obs_mean": float(obs_mean),
            }
        )
        bucket_weights.append(float(wsum))
        pred_all.extend([float(r.pred) for r in bucket])
        obs_all.extend([float(r.obs) for r in bucket])

    # Calibration error: expected calibration error (ECE) and max calibration error (MCE).
    total_w = sum(float(r.weight) for r in records) or 1.0
    ece = 0.0
    mce = 0.0
    for bin_row, w in zip(curve, bucket_weights):
        if not w:
            continue
        pm = bin_row.get("pred_mean")
        om = bin_row.get("obs_mean")
        if not isinstance(pm, (int, float)) or not isinstance(om, (int, float)):
            continue
        diff = abs(float(pm) - float(om))
        ece += (float(w) / float(total_w)) * diff
        mce = max(mce, diff)

    # Proper scoring rules (treat obs as Bernoulli mean when obs is fractional).
    brier = 0.0
    log_loss = 0.0
    eps = 1e-12
    for r in records:
        w = float(r.weight) if float(r.weight) > 0 else 1.0
        pred = float(r.pred)
        obs = float(r.obs)
        brier += w * float((pred - obs) ** 2)
        p = min(1.0 - eps, max(eps, pred))
        log_loss += w * float(-(obs * math.log(p) + (1.0 - obs) * math.log(1.0 - p)))
    brier = float(brier / float(total_w))
    log_loss = float(log_loss / float(total_w))

    metrics = {
        "n": int(len(records)),
        "pearson_r": _pearson_r(pred_all, obs_all),
        "rmse": _rmse(pred_all, obs_all),
        "mae": _mae(pred_all, obs_all),
        "bias": _bias(pred_all, obs_all),
        "ece": float(ece),
        "mce": float(mce),
        "brier": float(brier),
        "log_loss": float(log_loss),
    }
    return curve, metrics


def build_calibration_bundle(
    *,
    input_path: str | Path,
    model_id: str,
    model_version: str,
    model_hash: str | None,
    calibration_dataset_id: str,
    calibration_dataset_checksum: str,
    heldout_dataset_id: str,
    heldout_dataset_checksum: str,
    bins: int = 10,
    coverage: Mapping[str, Any] | None = None,
    target: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    records = _load_records(Path(input_path))
    by_set: dict[str, list[CalibrationRecord]] = {}
    for r in records:
        by_set.setdefault(r.locus_set or "overall", []).append(r)

    curves: dict[str, Any] = {}
    metrics: dict[str, Any] = {}
    overall_curve, overall_metrics = _curve(records, bins=bins)
    curves["overall"] = overall_curve
    metrics["overall"] = overall_metrics
    for key in sorted(k for k in by_set.keys() if k != "overall"):
        c, m = _curve(by_set[key], bins=bins)
        curves[key] = c
        metrics[key] = m

    if not model_hash:
        model_hash = _sha256_prefixed_hex(
            hashlib.sha256(canonical_json_bytes({"model_id": model_id, "model_version": model_version})).hexdigest()
        )
    else:
        model_hash = str(model_hash)
        if not model_hash.startswith("sha256:"):
            raise CalibrationBundleError("model_hash must be sha256:<hex> if provided")

    payload: dict[str, Any] = {
        "schema": "helix.calibration.bundle/v1",
        "bundle_id": f"calibration_bundle_{clock.utc_now_stamp().replace('_', 'T')}Z",
        "created_at_utc": _utc_now_iso(),
        "provenance": {
            "helix_version": str(HELIX_VERSION),
            "git_commit": str(current_git_sha() or "unavailable"),
            "evaluation_code_hash": _evaluation_code_hash(),
        },
        "model": {
            "model_id": str(model_id),
            "model_version": str(model_version),
            "model_hash": str(model_hash),
        },
        "datasets": {
            "calibration_dataset": {
                "id": str(calibration_dataset_id),
                "checksum": _sha256_prefixed_hex(str(calibration_dataset_checksum)),
            },
            "heldout_dataset": {
                "id": str(heldout_dataset_id),
                "checksum": _sha256_prefixed_hex(str(heldout_dataset_checksum)),
            },
        },
        "evaluation": {
            "bins": {"count": int(max(2, int(bins)))},
            "curves": curves,
            "metrics": metrics,
        },
        "heldout_summary": {
            "metrics": {
                "grade_correlation": metrics.get("overall", {}).get("pearson_r"),
                "rmse": metrics.get("overall", {}).get("rmse"),
                "mae": metrics.get("overall", {}).get("mae"),
                "ece": metrics.get("overall", {}).get("ece"),
                "mce": metrics.get("overall", {}).get("mce"),
                "brier": metrics.get("overall", {}).get("brier"),
                "log_loss": metrics.get("overall", {}).get("log_loss"),
            }
        },
        "bundle_hash": "",
    }
    if isinstance(coverage, Mapping) and coverage:
        payload["coverage"] = dict(coverage)
    if isinstance(target, Mapping) and target:
        payload["target"] = dict(target)
    payload["bundle_hash"] = _bundle_hash(payload)
    return payload


def write_calibration_bundle(bundle: Mapping[str, Any], path: str | Path, *, pretty: bool = True) -> Path:
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    data = dict(bundle)
    if pretty:
        out.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    else:
        out.write_bytes(canonical_json_bytes(data))
    return out


def load_calibration_bundle(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    obj = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(obj, Mapping):
        raise CalibrationBundleError("calibration bundle must be a JSON object")
    bundle = dict(obj)
    if str(bundle.get("schema") or "") != "helix.calibration.bundle/v1":
        raise CalibrationBundleError("unsupported calibration bundle schema")
    expected = str(bundle.get("bundle_hash") or "")
    computed = _bundle_hash(bundle)
    if expected and expected != computed:
        raise CalibrationBundleError("calibration bundle_hash mismatch")
    if not expected:
        bundle["bundle_hash"] = computed
    return bundle


def _matches(
    bundle: Mapping[str, Any],
    *,
    model_id: str,
    model_version: str,
    model_hash: str | None,
    calibration_dataset_id: str | None,
) -> bool:
    model = bundle.get("model") if isinstance(bundle.get("model"), Mapping) else {}
    if str(model.get("model_id") or "") != str(model_id):
        return False
    if str(model.get("model_version") or "") != str(model_version):
        return False
    if model_hash is not None and str(model.get("model_hash") or "") != str(model_hash):
        return False
    if calibration_dataset_id is not None:
        datasets = bundle.get("datasets") if isinstance(bundle.get("datasets"), Mapping) else {}
        cal = datasets.get("calibration_dataset") if isinstance(datasets.get("calibration_dataset"), Mapping) else {}
        if str(cal.get("id") or "") != str(calibration_dataset_id):
            return False
    return True


def find_calibration_bundle(
    *,
    model_id: str,
    model_version: str,
    model_hash: str | None = None,
    calibration_dataset_id: str | None = None,
) -> dict[str, Any] | None:
    """Return the first matching calibration bundle from HELIX_CALIBRATION_BUNDLE_PATH/DIR."""

    bundle_path = os.getenv("HELIX_CALIBRATION_BUNDLE_PATH")
    if bundle_path:
        try:
            bundle = load_calibration_bundle(bundle_path)
            if _matches(
                bundle,
                model_id=model_id,
                model_version=model_version,
                model_hash=model_hash,
                calibration_dataset_id=calibration_dataset_id,
            ):
                return bundle
        except Exception:
            return None

    bundle_dir = os.getenv("HELIX_CALIBRATION_BUNDLE_DIR")
    if not bundle_dir:
        return None
    root = Path(bundle_dir)
    if not root.exists() or not root.is_dir():
        return None

    candidates: list[dict[str, Any]] = []
    for path in fs.glob_sorted(root, "*.json"):
        try:
            bundle = load_calibration_bundle(path)
        except Exception:
            continue
        if _matches(
            bundle,
            model_id=model_id,
            model_version=model_version,
            model_hash=model_hash,
            calibration_dataset_id=calibration_dataset_id,
        ):
            candidates.append(bundle)

    if not candidates:
        return None
    if model_hash is not None:
        for b in candidates:
            model = b.get("model") if isinstance(b.get("model"), Mapping) else {}
            if str(model.get("model_hash") or "") == str(model_hash):
                return dict(b)
    return dict(candidates[0])


__all__ = [
    "CalibrationBundleError",
    "CalibrationRecord",
    "canonical_json_bytes",
    "sha256_prefixed_bytes",
    "build_calibration_bundle",
    "write_calibration_bundle",
    "load_calibration_bundle",
    "find_calibration_bundle",
]
