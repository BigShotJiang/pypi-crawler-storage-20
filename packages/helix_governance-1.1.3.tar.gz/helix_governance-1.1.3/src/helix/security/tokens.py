from __future__ import annotations

from helix.entropy import token_bytes as _token_bytes
from helix.entropy import token_hex as _token_hex
from helix.entropy import token_urlsafe as _token_urlsafe


def token_bytes(nbytes: int) -> bytes:
    return _token_bytes(int(nbytes))


def token_hex(nbytes: int) -> str:
    return _token_hex(int(nbytes))


def token_urlsafe(nbytes: int) -> str:
    return _token_urlsafe(int(nbytes))


__all__ = ["token_bytes", "token_hex", "token_urlsafe"]
