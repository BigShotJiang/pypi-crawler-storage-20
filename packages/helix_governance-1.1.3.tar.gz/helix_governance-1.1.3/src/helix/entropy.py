from __future__ import annotations

import base64
import contextvars
import hashlib
import os
import secrets
import uuid
from typing import Final

from helix.determinism.nondet import nondeterminism_allowed


_SEED: contextvars.ContextVar[int] = contextvars.ContextVar("helix_deterministic_entropy_seed", default=0)
_COUNTER: contextvars.ContextVar[int] = contextvars.ContextVar("helix_deterministic_entropy_counter", default=0)

_BLAKE_PERSON: Final[bytes] = b"helix.entropy.v1"


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _deterministic_mode() -> bool:
    return _truthy(os.getenv("HELIX_DETERMINISTIC")) or _truthy(os.getenv("HELIX_FORBID_RANDOM"))


def set_deterministic_entropy_seed(seed: int) -> None:
    _SEED.set(int(seed))
    _COUNTER.set(0)


def set_deterministic_entropy_seed_from_run_id(run_id: str) -> None:
    token = str(run_id or "").strip()
    if not token:
        set_deterministic_entropy_seed(0)
        return
    digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
    set_deterministic_entropy_seed(int.from_bytes(digest, "big"))


def deterministic_token_bytes(nbytes: int) -> bytes:
    """
    Deterministic pseudo-entropy for deterministic artifacts.

    This is intentionally *not* cryptographically secure. It is stable across
    replays given the same seed and call order.
    """

    size = int(nbytes)
    if size < 0:
        raise ValueError("nbytes must be >= 0")
    seed = int(_SEED.get() or 0)
    counter = int(_COUNTER.get() or 0)
    _COUNTER.set(counter + 1)
    payload = f"{seed}:{counter}".encode("utf-8")
    digest = hashlib.blake2b(payload, digest_size=32, person=_BLAKE_PERSON).digest()
    out = bytearray()
    while len(out) < size:
        counter += 1
        block = hashlib.blake2b(
            digest + counter.to_bytes(8, "big", signed=False),
            digest_size=32,
            person=_BLAKE_PERSON,
        ).digest()
        out.extend(block)
    return bytes(out[:size])


def token_bytes(nbytes: int) -> bytes:
    """
    Entropy bytes.

    In deterministic mode, returns deterministic bytes unless nondeterminism is explicitly allowed.
    """

    if _deterministic_mode() and not nondeterminism_allowed():
        return deterministic_token_bytes(nbytes)
    return secrets.token_bytes(int(nbytes))


def token_hex(nbytes: int) -> str:
    if _deterministic_mode() and not nondeterminism_allowed():
        return deterministic_token_bytes(nbytes).hex()
    return secrets.token_hex(int(nbytes))


def token_urlsafe(nbytes: int) -> str:
    if _deterministic_mode() and not nondeterminism_allowed():
        raw = deterministic_token_bytes(nbytes)
        return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    return secrets.token_urlsafe(int(nbytes))


def uuid4() -> uuid.UUID:
    """
    UUID for correlation/UX identifiers.

    In deterministic mode, returns a deterministic UUID unless nondeterminism is explicitly allowed.
    """

    if _deterministic_mode() and not nondeterminism_allowed():
        raw = bytearray(deterministic_token_bytes(16))
        raw[6] = (raw[6] & 0x0F) | 0x40  # version 4
        raw[8] = (raw[8] & 0x3F) | 0x80  # variant 10xx
        return uuid.UUID(bytes=bytes(raw))
    return uuid.uuid4()


__all__ = [
    "deterministic_token_bytes",
    "set_deterministic_entropy_seed",
    "set_deterministic_entropy_seed_from_run_id",
    "token_bytes",
    "token_hex",
    "token_urlsafe",
    "uuid4",
]

