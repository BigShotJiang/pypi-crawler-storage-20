from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence
import json


@dataclass(frozen=True, slots=True)
class Locus:
    contig: str
    position: int
    strand: str
    window_start: int
    window_end: int

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Locus":
        return cls(
            contig=str(payload["contig"]),
            position=int(payload["position"]),
            strand=str(payload["strand"]),
            window_start=int(payload["windowStart"]),
            window_end=int(payload["windowEnd"]),
        )


@dataclass(frozen=True, slots=True)
class ReferenceWindow:
    start: int
    end: int
    sequence: str | None = None
    checksum: str | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "ReferenceWindow":
        seq = payload.get("sequence")
        checksum = payload.get("checksum")
        return cls(
            start=int(payload["start"]),
            end=int(payload["end"]),
            sequence=(str(seq) if seq is not None else None),
            checksum=(str(checksum) if checksum is not None else None),
        )


@dataclass(frozen=True, slots=True)
class PhaseStage:
    name: str
    start: float
    end: float

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "PhaseStage":
        return cls(
            name=str(payload["name"]),
            start=float(payload["start"]),
            end=float(payload["end"]),
        )


@dataclass(frozen=True, slots=True)
class StyleRule:
    """A deterministic, ordered rule for mapping mechanism tags to visual style."""

    match_any: tuple[str, ...]
    color_rgb: tuple[int, int, int] | None = None
    thickness_mul: float | None = None
    braid: bool | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "StyleRule":
        match_any_raw = payload.get("matchAny") or []
        if not isinstance(match_any_raw, Sequence) or isinstance(match_any_raw, (str, bytes, bytearray)):
            raise TypeError("style.tagRules[].matchAny must be an array of strings")
        color_raw = payload.get("colorRgb")
        color_rgb: tuple[int, int, int] | None = None
        if color_raw is not None:
            if not isinstance(color_raw, Sequence) or isinstance(color_raw, (str, bytes, bytearray)):
                raise TypeError("style.tagRules[].colorRgb must be a 3-item array")
            if len(color_raw) != 3:
                raise ValueError("style.tagRules[].colorRgb must have 3 items")
            color_rgb = (int(color_raw[0]), int(color_raw[1]), int(color_raw[2]))
        braid_raw = payload.get("braid")
        braid = bool(braid_raw) if braid_raw is not None else None
        thickness_mul_raw = payload.get("thicknessMul")
        thickness_mul = float(thickness_mul_raw) if thickness_mul_raw is not None else None
        return cls(
            match_any=tuple(str(t).lower() for t in match_any_raw),
            color_rgb=color_rgb,
            thickness_mul=thickness_mul,
            braid=braid,
        )


@dataclass(frozen=True, slots=True)
class RenderStyle:
    """Frozen style map for deterministic renders.

    This is part of the fixture contract: if the style mapping drifts, goldens become meaningless
    (you changed the visual language, not the data).
    """

    version: str
    layout_mode: str
    margins: tuple[int, int, int, int]  # left, right, top, bottom
    trunk_color: tuple[int, int, int, int]
    trunk_radius_px: int
    branch_radius_px: int
    tip_radius_px: int
    tip_alpha_boost: int
    alpha_base: int
    alpha_scale: int
    alpha_min: int
    alpha_max: int
    lane_spread_px: float
    lane_spread_frac: float
    base_edit_lane_spread_px: float
    base_edit_lane_spread_frac: float
    delta_bp_scale_px: float
    delta_bp_clamp_px: float
    tree_max_spread_px: float
    tree_leaf_jitter_px: float
    bundling: Mapping[str, Any]
    ghosts: Mapping[str, Any]
    base_sheen: Mapping[str, Any]
    default_color_rgb: tuple[int, int, int]
    tag_rules: tuple[StyleRule, ...]

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "RenderStyle":
        version = str(payload.get("version") or "")
        layout_mode = str(payload.get("layoutMode") or "")
        margins_raw = payload.get("margins") or {}
        if not isinstance(margins_raw, Mapping):
            raise TypeError("style.margins must be an object")
        margins = (
            int(margins_raw.get("left") or 0),
            int(margins_raw.get("right") or 0),
            int(margins_raw.get("top") or 0),
            int(margins_raw.get("bottom") or 0),
        )
        trunk_color = _rgba8_from_payload(payload.get("trunkColor"))
        default_rgb_raw = payload.get("defaultColorRgb")
        if not isinstance(default_rgb_raw, Sequence) or isinstance(default_rgb_raw, (str, bytes, bytearray)):
            raise TypeError("style.defaultColorRgb must be a 3-item array")
        if len(default_rgb_raw) != 3:
            raise ValueError("style.defaultColorRgb must have 3 items")
        default_color_rgb = (int(default_rgb_raw[0]), int(default_rgb_raw[1]), int(default_rgb_raw[2]))

        rules_raw = payload.get("tagRules") or []
        if not isinstance(rules_raw, Sequence) or isinstance(rules_raw, (str, bytes, bytearray)):
            raise TypeError("style.tagRules must be an array")
        rules = tuple(StyleRule.from_payload(r) for r in rules_raw if isinstance(r, Mapping))

        bundling = payload.get("bundling") or {}
        if not isinstance(bundling, Mapping):
            raise TypeError("style.bundling must be an object")
        ghosts = payload.get("ghosts") or {}
        if not isinstance(ghosts, Mapping):
            raise TypeError("style.ghosts must be an object")
        base_sheen = payload.get("baseSheen") or {}
        if not isinstance(base_sheen, Mapping):
            raise TypeError("style.baseSheen must be an object")

        return cls(
            version=version,
            layout_mode=layout_mode,
            margins=margins,
            trunk_color=trunk_color,
            trunk_radius_px=int(payload.get("trunkRadiusPx") or 0),
            branch_radius_px=int(payload.get("branchRadiusPx") or 0),
            tip_radius_px=int(payload.get("tipRadiusPx") or 0),
            tip_alpha_boost=int(payload.get("tipAlphaBoost") or 0),
            alpha_base=int(payload.get("alphaBase") or 0),
            alpha_scale=int(payload.get("alphaScale") or 0),
            alpha_min=int(payload.get("alphaMin") or 0),
            alpha_max=int(payload.get("alphaMax") or 255),
            lane_spread_px=float(payload.get("laneSpreadPx") or 0.0),
            lane_spread_frac=float(payload.get("laneSpreadFrac") or 0.0),
            base_edit_lane_spread_px=float(payload.get("baseEditLaneSpreadPx") or 0.0),
            base_edit_lane_spread_frac=float(payload.get("baseEditLaneSpreadFrac") or 0.0),
            delta_bp_scale_px=float(payload.get("deltaBpScalePx") or 0.0),
            delta_bp_clamp_px=float(payload.get("deltaBpClampPx") or 0.0),
            tree_max_spread_px=float(payload.get("treeMaxSpreadPx") or 0.0),
            tree_leaf_jitter_px=float(payload.get("treeLeafJitterPx") or 0.0),
            bundling=dict(bundling),
            ghosts=dict(ghosts),
            base_sheen=dict(base_sheen),
            default_color_rgb=default_color_rgb,
            tag_rules=rules,
        )


@dataclass(frozen=True, slots=True)
class RenderGolden:
    renderer: "Renderer"
    width: int
    height: int
    phase: float
    seed: int
    background: tuple[int, int, int, int]
    camera: "Camera2D"
    projection: "Projection2D"
    color_space: str
    alpha_mode: str
    composite_space: str
    style: RenderStyle
    settings_sha256: str
    rgba_sha256: str
    geometry_sha256: str | None = None
    tolerance: "RenderTolerance | None" = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "RenderGolden":
        tol_raw = payload.get("tolerance")
        tolerance: RenderTolerance | None = None
        if isinstance(tol_raw, Mapping):
            tolerance = RenderTolerance.from_payload(tol_raw)
        style_raw = payload.get("style")
        if not isinstance(style_raw, Mapping):
            raise TypeError("renderGolden.style must be an object")
        return cls(
            renderer=Renderer.from_payload(payload.get("renderer") or {}),
            width=int(payload["width"]),
            height=int(payload["height"]),
            phase=float(payload["phase"]),
            seed=int(payload["seed"]),
            background=_rgba8_from_payload(payload.get("background")),
            camera=Camera2D.from_payload(payload.get("camera") or {}),
            projection=Projection2D.from_payload(payload.get("projection") or {}),
            color_space=str(payload.get("colorSpace") or ""),
            alpha_mode=str(payload.get("alphaMode") or ""),
            composite_space=str(payload.get("compositeSpace") or ""),
            style=RenderStyle.from_payload(style_raw),
            settings_sha256=str(payload.get("settingsSha256") or ""),
            rgba_sha256=str(payload["rgbaSha256"]),
            geometry_sha256=(str(payload.get("geometrySha256")) if payload.get("geometrySha256") is not None else None),
            tolerance=tolerance,
        )


@dataclass(frozen=True, slots=True)
class Renderer:
    id: str
    version: str
    shader_sha256: str | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Renderer":
        shader_sha256 = payload.get("shaderSha256")
        return cls(
            id=str(payload.get("id") or ""),
            version=str(payload.get("version") or ""),
            shader_sha256=(str(shader_sha256) if shader_sha256 is not None else None),
        )


@dataclass(frozen=True, slots=True)
class Camera2D:
    kind: str
    pan_px: tuple[float, float]
    zoom: float

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Camera2D":
        pan_raw = payload.get("panPx") or (0.0, 0.0)
        if isinstance(pan_raw, Sequence) and not isinstance(pan_raw, (str, bytes, bytearray)):
            pan = (float(pan_raw[0]), float(pan_raw[1]))
        else:
            pan = (0.0, 0.0)
        return cls(
            kind=str(payload.get("kind") or ""),
            pan_px=pan,
            zoom=float(payload.get("zoom") or 1.0),
        )


@dataclass(frozen=True, slots=True)
class Projection2D:
    kind: str
    phase_direction: str

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Projection2D":
        return cls(
            kind=str(payload.get("kind") or ""),
            phase_direction=str(payload.get("phaseDirection") or ""),
        )


@dataclass(frozen=True, slots=True)
class RenderTolerance:
    max_abs_diff: int = 0
    mean_abs_diff: float = 0.0

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "RenderTolerance":
        return cls(
            max_abs_diff=int(payload.get("maxAbsDiff") or 0),
            mean_abs_diff=float(payload.get("meanAbsDiff") or 0.0),
        )


def _rgba8_from_payload(payload: object) -> tuple[int, int, int, int]:
    if not isinstance(payload, Sequence) or isinstance(payload, (str, bytes, bytearray)):
        raise TypeError("renderGolden.background must be a 4-item array")
    if len(payload) != 4:
        raise ValueError("renderGolden.background must have 4 items")
    rgba = tuple(int(v) for v in payload[:4])
    r, g, b, a = rgba
    for v in (r, g, b, a):
        if v < 0 or v > 255:
            raise ValueError("renderGolden.background values must be in [0,255]")
    return r, g, b, a


@dataclass(frozen=True, slots=True)
class Outcome:
    id: str
    probability: float
    divergence_phase: float
    allele_ops: Sequence[Mapping[str, Any]]
    mechanism_tags: tuple[str, ...] = ()
    notes: str | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "Outcome":
        tags_raw = payload.get("mechanismTags") or []
        tags: tuple[str, ...]
        if isinstance(tags_raw, Sequence) and not isinstance(tags_raw, (str, bytes, bytearray)):
            tags = tuple(str(t) for t in tags_raw)
        else:
            tags = ()
        ops_raw = payload.get("alleleOps") or []
        if not isinstance(ops_raw, Sequence) or isinstance(ops_raw, (str, bytes, bytearray)):
            raise TypeError("outcome.alleleOps must be a sequence")
        return cls(
            id=str(payload["id"]),
            probability=float(payload["probability"]),
            divergence_phase=float(payload["divergencePhase"]),
            allele_ops=tuple(dict(op) for op in ops_raw),
            mechanism_tags=tags,
            notes=(str(payload["notes"]) if payload.get("notes") is not None else None),
        )


@dataclass(frozen=True, slots=True)
class OffTarget:
    id: str
    locus: Locus
    probability_mass: float
    mismatch_signature: Mapping[str, Any]

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "OffTarget":
        return cls(
            id=str(payload["id"]),
            locus=Locus.from_payload(payload["locus"]),
            probability_mass=float(payload["probabilityMass"]),
            mismatch_signature=dict(payload.get("mismatchSignature") or {}),
        )


@dataclass(frozen=True, slots=True)
class BuilderProvenance:
    builder_id: str
    builder_version: str | None
    seed: int
    params: Mapping[str, Any]
    reference_window_sha256: str
    notes: str | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "BuilderProvenance":
        params_raw = payload.get("params") or {}
        if not isinstance(params_raw, Mapping):
            raise TypeError("builderProvenance.params must be an object")
        builder_version_raw = payload.get("builderVersion")
        return cls(
            builder_id=str(payload.get("builderId") or ""),
            builder_version=(str(builder_version_raw) if builder_version_raw is not None else None),
            seed=int(payload.get("seed") or 0),
            params=dict(params_raw),
            reference_window_sha256=str(payload.get("referenceWindowSha256") or ""),
            notes=(str(payload["notes"]) if payload.get("notes") is not None else None),
        )


@dataclass(frozen=True, slots=True)
class LightconeDocument:
    spec_version: str
    id: str
    locus: Locus
    edit_type: str
    reference_window: ReferenceWindow | None
    outcomes: tuple[Outcome, ...]
    builder_provenance: BuilderProvenance | None = None
    phase_stages: tuple[PhaseStage, ...] = ()
    off_targets: tuple[OffTarget, ...] = ()
    render_golden: RenderGolden | None = None
    notes: str | None = None

    @classmethod
    def from_payload(cls, payload: Mapping[str, Any]) -> "LightconeDocument":
        spec_version = str(payload.get("specVersion") or "")
        if not spec_version:
            raise ValueError("Missing required field: specVersion")
        locus_raw = payload.get("locus")
        if not isinstance(locus_raw, Mapping):
            raise TypeError("locus must be an object")
        builder_provenance: BuilderProvenance | None = None
        bp_raw = payload.get("builderProvenance")
        if isinstance(bp_raw, Mapping):
            builder_provenance = BuilderProvenance.from_payload(bp_raw)
        outcomes_raw = payload.get("outcomes") or []
        if not isinstance(outcomes_raw, Sequence) or isinstance(outcomes_raw, (str, bytes, bytearray)):
            raise TypeError("outcomes must be an array")
        outcomes = tuple(Outcome.from_payload(o) for o in outcomes_raw)

        ref_win: ReferenceWindow | None = None
        ref_raw = payload.get("referenceWindow")
        if isinstance(ref_raw, Mapping):
            ref_win = ReferenceWindow.from_payload(ref_raw)

        phase_model_raw = payload.get("phaseModel") or {}
        phase_stages: tuple[PhaseStage, ...] = ()
        if isinstance(phase_model_raw, Mapping):
            stages_raw = phase_model_raw.get("stages") or []
            if isinstance(stages_raw, Sequence) and not isinstance(stages_raw, (str, bytes, bytearray)):
                phase_stages = tuple(PhaseStage.from_payload(s) for s in stages_raw)

        off_targets_raw = payload.get("offTargets") or []
        off_targets: tuple[OffTarget, ...] = ()
        if isinstance(off_targets_raw, Sequence) and not isinstance(off_targets_raw, (str, bytes, bytearray)):
            off_targets = tuple(OffTarget.from_payload(ot) for ot in off_targets_raw)

        render_golden: RenderGolden | None = None
        rg_raw = payload.get("renderGolden")
        if isinstance(rg_raw, Mapping):
            render_golden = RenderGolden.from_payload(rg_raw)

        notes = payload.get("notes")
        return cls(
            spec_version=spec_version,
            id=str(payload.get("id") or ""),
            locus=Locus.from_payload(locus_raw),
            edit_type=str(payload.get("editType") or ""),
            reference_window=ref_win,
            outcomes=outcomes,
            builder_provenance=builder_provenance,
            phase_stages=phase_stages,
            off_targets=off_targets,
            render_golden=render_golden,
            notes=(str(notes) if notes is not None else None),
        )


def load_lightcone_document(path: str | Path) -> LightconeDocument:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise TypeError("Lightcone document must be a JSON object")
    return LightconeDocument.from_payload(payload)
