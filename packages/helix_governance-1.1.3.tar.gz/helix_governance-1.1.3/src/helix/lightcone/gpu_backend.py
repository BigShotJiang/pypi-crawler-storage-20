from __future__ import annotations

import hashlib
import math
import os
import struct
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence, Tuple

from .contract import LightconeDocument, Outcome, PhaseStage
from .geometry import CompiledEdge, CompiledGeometry, compile_lightcone_geometry
from .outcomes import stable_sort_outcomes
from .picking import build_selection_index

try:  # Optional dependency; GPU backend is gated in tests and never used for CPU goldens.
    import moderngl  # type: ignore
except Exception:  # pragma: no cover
    moderngl = None  # type: ignore[assignment]


LIGHTCONE_GPU_RENDERER_ID = "helix.lightcone.moderngl"
LIGHTCONE_GPU_RENDERER_VERSION = "v0.1"


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _flip_rows(data: bytes, *, row_bytes: int, height: int) -> bytes:
    """Flip packed rows from bottom-origin (OpenGL) to top-origin (CPU/canvas)."""

    if height <= 1:
        return data
    if row_bytes <= 0:
        raise ValueError("row_bytes must be positive")
    if len(data) != row_bytes * height:
        raise ValueError(f"unexpected buffer size {len(data)} != {row_bytes}*{height}")

    mv = memoryview(data)
    out = bytearray(len(data))
    for y in range(height):
        src0 = y * row_bytes
        dst0 = (height - 1 - y) * row_bytes
        out[dst0 : dst0 + row_bytes] = mv[src0 : src0 + row_bytes]
    return bytes(out)


def _default_phase_stages() -> tuple[PhaseStage, ...]:
    return (
        PhaseStage("bind", 0.0, 0.15),
        PhaseStage("cut_or_nick", 0.15, 0.3),
        PhaseStage("processing", 0.3, 0.55),
        PhaseStage("synthesis", 0.55, 0.85),
        PhaseStage("ligation", 0.85, 1.0),
    )


def _stage_color_rgba8(name: str) -> tuple[int, int, int, int]:
    return {
        "bind": (28, 38, 64, 90),
        "cut_or_nick": (42, 32, 72, 90),
        "processing": (30, 52, 62, 90),
        "synthesis": (52, 46, 26, 90),
        "ligation": (44, 44, 50, 90),
    }.get(name, (32, 32, 40, 80))


def _clamp_float(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


def _clamp_int(x: int, lo: int, hi: int) -> int:
    return lo if x < lo else hi if x > hi else x


def _scale_radius(r: int, zoom: float) -> int:
    """Mirror helix.lightcone.render._scale_radius (Qt-style rounding via Python round)."""

    if int(r) <= 0:
        return 0
    return max(0, int(round(float(r) * float(zoom))))


def _radius_draw_px(r: int) -> float:
    """Convert a canvas-style integer radius to a GPU radius in pixel units.

    Canvas radius 0 draws a single pixel; represent that as a disc radius of 0.5 so the quad rasterizes.
    """

    r_i = int(r)
    if r_i <= 0:
        return 0.5
    return float(r_i)


def _gpu_raster_mode() -> str:
    """Select GPU rasterization strategy.

    We default to "stamps" because the canonical CPU renderer uses DDA disc stamping.
    Capsules are faster and look smoother, but they diverge slightly across drivers.
    """

    mode = os.environ.get("HELIX_LIGHTCONE_GPU_RASTER", "").strip().lower()
    if not mode:
        return "capsules"
    if mode in {"capsule", "capsules", "segment", "segments", "analytic"}:
        return "capsules"
    if mode in {"stamp", "stamps", "dda", "disc", "discs"}:
        return "stamps"
    return "stamps"


_GPU_SCISSOR_MODE = "full_viewport"
_GPU_QUAD_PAD_PX = 0.5


def lightcone_gpu_backend_receipts() -> dict[str, object]:
    """Return stable, low-entropy GPU backend knobs for receipts/baselines."""

    return {
        "rasterMode": _gpu_raster_mode(),
        "scissorMode": _GPU_SCISSOR_MODE,
        "quadPadPx": float(_GPU_QUAD_PAD_PX),
        "shaderSha256_3d": sha256_hex(_SEG_VERT_3D.encode("utf-8") + _SEG_FRAG_3D.encode("utf-8")),
    }


@dataclass(frozen=True, slots=True)
class GpuSegment:
    p0: tuple[float, float]
    p1: tuple[float, float]
    radius: float
    color_rgba8: tuple[int, int, int, int]
    selection_id: int = 0


# 3D ribbon segments reuse p0/p1 as layout-space positions (pre camera/wrap).
@dataclass(frozen=True, slots=True)
class GpuSegment3D:
    p0: tuple[float, float]
    p1: tuple[float, float]
    radius: float
    color_rgba8: tuple[int, int, int, int]
    selection_id: int = 0

# Minimal 3D ribbon shaders (placeholder: behaves like 2D passthrough for now).
_SEG_VERT_3D = """
#version 330
#define PI 3.14159265359
layout(std140) uniform Camera {
    vec3 u_eye;
    vec3 u_center;
    vec3 u_up;
    mat4 u_view;
    mat4 u_proj;
};
in vec2 in_corner;        // (t, side)
in vec4 in_seg_p0p1;      // layout space x/y (post-2D layout, pre-wrap)
in vec4 in_seg_color;
in float in_seg_radius;
in uint in_seg_id;

uniform float u_theta_scale;
uniform float u_phase_clip_lo;
uniform float u_phase_clip_hi;
uniform vec2 u_resolution;

out vec4 v_color;
flat out uint v_id;
flat out float v_radius_px;

// SplitMix32 for deterministic hash -> theta.
uint hash32(uint x) {
    x += 0x9e3779b9u;
    x = (x ^ (x >> 16u)) * 0x85ebca6bu;
    x = (x ^ (x >> 13u)) * 0xc2b2ae35u;
    x = x ^ (x >> 16u);
    return x;
}

void main() {
    float t = in_corner.x;
    float side = in_corner.y;

    vec2 p0 = in_seg_p0p1.xy;
    vec2 p1 = in_seg_p0p1.zw;

    // Phase clip in layout Y (pixel space already).
    float y0 = p0.y;
    float y1 = p1.y;
    float y_clip_lo = u_resolution.y - u_phase_clip_hi * u_resolution.y;
    float y_clip_hi = u_resolution.y - u_phase_clip_lo * u_resolution.y;
    if ((y0 < y_clip_lo && y1 < y_clip_lo) || (y0 > y_clip_hi && y1 > y_clip_hi)) {
        gl_Position = vec4(2.0, 2.0, 1.0, 1.0);
        v_color = vec4(0.0);
        v_id = 0u;
        v_radius_px = 0.0;
        return;
    }

    // Theta from selection id.
    uint h = hash32(in_seg_id);
    float theta = (float(h) / 4294967296.0) * 2.0 * PI;

    // Cylindrical wrap: treat layout x as radial magnitude.
    float r0 = abs(p0.x - u_resolution.x * 0.5) * u_theta_scale;
    float r1 = abs(p1.x - u_resolution.x * 0.5) * u_theta_scale;
    vec3 p0w = vec3(r0 * cos(theta), p0.y, r0 * sin(theta));
    vec3 p1w = vec3(r1 * cos(theta), p1.y, r1 * sin(theta));

    vec3 dw = p1w - p0w;
    float len2 = dot(dw, dw);
    vec3 dir = (len2 > 1e-6) ? (dw / sqrt(len2)) : vec3(0.0, -1.0, 0.0);
    vec3 up = normalize(u_up);
    vec3 n = normalize(cross(dir, up));
    if (length(n) < 1e-6) {
        n = vec3(1.0, 0.0, 0.0);
    }

    vec3 pos = mix(p0w, p1w, t) + n * side * in_seg_radius;
    vec4 view_pos = u_view * vec4(pos, 1.0);
    gl_Position = u_proj * view_pos;

    v_color = in_seg_color;
    v_id = in_seg_id;
    v_radius_px = in_seg_radius;
}
"""

_SEG_FRAG_3D = """
#version 330
flat in uint v_id;
flat in float v_radius_px;
in vec4 v_color;
out vec4 out_color;
void main() {
    out_color = v_color;
}
"""


_GPU_PREFLIGHT_CACHE: dict[bool, tuple[dict[str, str], str | None]] = {}


def gpu_preflight(*, allow_software: bool = False) -> tuple[dict[str, str], str | None]:
    """Best-effort OpenGL preflight for the GPU backend.

    Returns (info, skip_reason). `info` is stable JSON-able strings.
    """

    cached = _GPU_PREFLIGHT_CACHE.get(bool(allow_software))
    if cached is not None:
        info, reason = cached
        return dict(info), reason

    if moderngl is None:
        info = {"ERROR": "moderngl not installed"}
        reason = "moderngl not installed"
        _GPU_PREFLIGHT_CACHE[bool(allow_software)] = (dict(info), reason)
        return dict(info), reason
    try:
        ctx = moderngl.create_standalone_context()
        info = {
            "GL_VENDOR": str(ctx.info.get("GL_VENDOR", "")),
            "GL_RENDERER": str(ctx.info.get("GL_RENDERER", "")),
            "GL_VERSION": str(ctx.info.get("GL_VERSION", "")),
        }
        renderer_l = info["GL_RENDERER"].lower()
        software_tokens = ("llvmpipe", "softpipe", "swrast", "swiftshader", "software")
        if not allow_software and any(tok in renderer_l for tok in software_tokens):
            reason = f"Software OpenGL renderer detected ({info['GL_RENDERER']!r})"
            _GPU_PREFLIGHT_CACHE[bool(allow_software)] = (dict(info), reason)
            return dict(info), reason
        _GPU_PREFLIGHT_CACHE[bool(allow_software)] = (dict(info), None)
        return dict(info), None
    except Exception as exc:
        info = {"ERROR": repr(exc)}
        reason = f"Failed to init standalone OpenGL context ({exc!r})"
        _GPU_PREFLIGHT_CACHE[bool(allow_software)] = (dict(info), reason)
        return dict(info), reason


_FSQ_VERT = """
#version 330
in vec2 in_pos;
out vec2 v_uv;
void main() {
    // in_pos is already NDC.
    gl_Position = vec4(in_pos, 0.0, 1.0);
    v_uv = in_pos * 0.5 + 0.5;
}
"""


_FSQ_FRAG = """
#version 330
in vec2 v_uv;
out vec4 out_color;

uniform vec2 u_resolution;
uniform vec4 u_bg;               // straight alpha in [0,1]
uniform int u_stage_count;
uniform vec2 u_stage_y01[8];     // y0,y1 in pixel-index coords (top-origin)
uniform vec4 u_stage_color[8];   // straight alpha in [0,1]

vec4 over_premult(vec4 src_premult, vec4 dst_premult) {
    return src_premult + dst_premult * (1.0 - src_premult.a);
}

void main() {
    // Pixel index coords (0..w-1, 0..h-1) with top-origin.
    vec2 frag = vec2(gl_FragCoord.x - 0.5, u_resolution.y - gl_FragCoord.y - 0.5);

    // Start from bg (premult).
    vec4 bg = vec4(u_bg.rgb * u_bg.a, u_bg.a);
    vec4 acc = bg;

    float y = frag.y;
    for (int i = 0; i < u_stage_count; i++) {
        vec2 y01 = u_stage_y01[i];
        if (y >= y01.x && y < y01.y) {
            vec4 s = u_stage_color[i];
            vec4 sp = vec4(s.rgb * s.a, s.a);
            acc = over_premult(sp, acc);
            break;
        }
    }

    // Output straight-ish (acc is premult; bg is opaque in our fixtures).
    if (acc.a <= 1e-6) {
        out_color = vec4(0.0);
        return;
    }
    vec3 rgb = acc.rgb / acc.a;
    out_color = vec4(rgb, acc.a);
}
"""


_SEG_VERT = """
#version 330
in vec2 in_corner;        // (t, side) where t in {0,1}, side in {-1,+1}
in vec4 in_seg_p0p1;      // p0x,p0y,p1x,p1y in pixel-index coords
in vec4 in_seg_color;     // rgba in [0,1]
in float in_seg_radius;   // pixels
in uint in_seg_id;        // selection id (for pick pass)

out vec2 v_p0;
out vec2 v_p1;
out float v_radius;
out vec4 v_color;
flat out uint v_id;

uniform vec2 u_resolution;

void main() {
    float t = in_corner.x;
    float side = in_corner.y;

    vec2 p0 = in_seg_p0p1.xy;
    vec2 p1 = in_seg_p0p1.zw;
    vec2 d = p1 - p0;
    float len2 = dot(d, d);
    vec2 dir = (len2 > 1e-6) ? (d / sqrt(len2)) : vec2(0.0, -1.0);
    vec2 n = vec2(-dir.y, dir.x);

    float r = in_seg_radius;
    float r_box = r + 0.5;
    // Expand beyond endpoints by radius so the fragment shader can produce round caps.
    vec2 along = dir * (2.0 * t - 1.0) * r_box;
    vec2 pos = mix(p0, p1, t) + along + n * side * r_box;

    // Convert pixel index coords to pixel center coords, then to NDC.
    vec2 pos_px = pos + vec2(0.5, 0.5);
    vec2 ndc = vec2((pos_px.x / u_resolution.x) * 2.0 - 1.0, 1.0 - (pos_px.y / u_resolution.y) * 2.0);
    gl_Position = vec4(ndc, 0.0, 1.0);

    v_p0 = p0;
    v_p1 = p1;
    v_radius = r;
    v_color = in_seg_color;
    v_id = in_seg_id;
}
"""


_SEG_FRAG_COLOR = """
#version 330
in vec2 v_p0;
in vec2 v_p1;
in float v_radius;
in vec4 v_color;   // straight alpha
out vec4 out_color;

uniform vec2 u_resolution;
uniform float u_y_clip;   // pixel-index coords (top-origin)

float capsule_distance2(vec2 p, vec2 a, vec2 b) {
    vec2 ba = b - a;
    float denom = dot(ba, ba);
    float h = 0.0;
    if (denom > 1e-6) {
        h = clamp(dot(p - a, ba) / denom, 0.0, 1.0);
    }
    vec2 d = (p - a) - ba * h;
    return dot(d, d);
}

void main() {
    vec2 frag = vec2(gl_FragCoord.x - 0.5, u_resolution.y - gl_FragCoord.y - 0.5);
    // Match CPU phase clipping: segments are sampled at y>=clip, but discs/line thickness can extend above by radius.
    if (frag.y < (u_y_clip - v_radius)) {
        discard;
    }
    float r = v_radius;
    float d2 = capsule_distance2(frag, v_p0, v_p1);
    if (d2 > r * r + 1e-4) {
        discard;
    }
    // Output premultiplied; compositor uses (ONE, ONE_MINUS_SRC_ALPHA).
    vec3 rgb = v_color.rgb * v_color.a;
    out_color = vec4(rgb, v_color.a);
}
"""


_SEG_FRAG_ID = """
#version 330
in vec2 v_p0;
in vec2 v_p1;
in float v_radius;
flat in uint v_id;
out uint out_id;

uniform vec2 u_resolution;
uniform float u_y_clip;   // pixel-index coords (top-origin)

float capsule_distance2(vec2 p, vec2 a, vec2 b) {
    vec2 ba = b - a;
    float denom = dot(ba, ba);
    float h = 0.0;
    if (denom > 1e-6) {
        h = clamp(dot(p - a, ba) / denom, 0.0, 1.0);
    }
    vec2 d = (p - a) - ba * h;
    return dot(d, d);
}

void main() {
    vec2 frag = vec2(gl_FragCoord.x - 0.5, u_resolution.y - gl_FragCoord.y - 0.5);
    if (frag.y < (u_y_clip - v_radius)) {
        discard;
    }
    float r = v_radius;
    float d2 = capsule_distance2(frag, v_p0, v_p1);
    if (d2 > r * r + 1e-4) {
        discard;
    }
    out_id = v_id;
}
"""


def lightcone_gpu_shader_sha256() -> str:
    blob = ("\n".join([_FSQ_VERT, _FSQ_FRAG, _SEG_VERT, _SEG_FRAG_COLOR, _SEG_FRAG_ID])).encode("utf-8")
    return sha256_hex(blob)


class LightconeGpuRenderer:
    _live_contexts = 0
    _live_programs = 0
    _live_buffers = 0
    _live_vaos = 0
    _live_framebuffers = 0
    _live_textures = 0

    @classmethod
    def live_resource_counts(cls) -> dict[str, int]:
        return {
            "contexts": int(cls._live_contexts),
            "programs": int(cls._live_programs),
            "buffers": int(cls._live_buffers),
            "vaos": int(cls._live_vaos),
            "framebuffers": int(cls._live_framebuffers),
            "textures": int(cls._live_textures),
        }

    @classmethod
    def _inc(cls, field: str, n: int = 1) -> None:
        setattr(cls, field, int(getattr(cls, field)) + int(n))

    @classmethod
    def _dec(cls, field: str, n: int = 1) -> None:
        setattr(cls, field, max(0, int(getattr(cls, field)) - int(n)))

    @staticmethod
    def _safe_release(obj: Any) -> None:
        try:
            if obj is not None:
                obj.release()
        except Exception:
            pass

    def __init__(self) -> None:
        if moderngl is None:
            raise RuntimeError("GPU lightcone backend requires 'moderngl' (install the 'realtime' extra).")
        self._closed = False
        self._ctx = moderngl.create_standalone_context()
        self._inc("_live_contexts", 1)
        self._prog_bg = self._ctx.program(vertex_shader=_FSQ_VERT, fragment_shader=_FSQ_FRAG)
        self._prog_seg_color = self._ctx.program(vertex_shader=_SEG_VERT, fragment_shader=_SEG_FRAG_COLOR)
        self._prog_seg_id = self._ctx.program(vertex_shader=_SEG_VERT, fragment_shader=_SEG_FRAG_ID)
        self._prog_seg_color_3d = self._ctx.program(vertex_shader=_SEG_VERT_3D, fragment_shader=_SEG_FRAG_3D)
        self._prog_seg_id_3d = self._ctx.program(vertex_shader=_SEG_VERT_3D, fragment_shader=_SEG_FRAG_ID)
        self._inc("_live_programs", 5)

        # Fullscreen triangle (3 vertices in NDC).
        self._fsq_vbo = self._ctx.buffer(
            data=struct.pack(
                "6f",
                -1.0,
                -1.0,
                3.0,
                -1.0,
                -1.0,
                3.0,
            )
        )
        self._fsq_vao = self._ctx.vertex_array(self._prog_bg, [(self._fsq_vbo, "2f", "in_pos")])
        self._inc("_live_buffers", 1)
        self._inc("_live_vaos", 1)

        # Base quad for capsule rendering: 6 vertices with (t, side).
        corners = [
            (0.0, -1.0),
            (0.0, 1.0),
            (1.0, 1.0),
            (0.0, -1.0),
            (1.0, 1.0),
            (1.0, -1.0),
        ]
        self._corner_vbo = self._ctx.buffer(data=struct.pack("12f", *(v for xy in corners for v in xy)))
        self._inc("_live_buffers", 1)

        self._seg_vbo = None
        self._seg_count = 0
        self._seg_vao_color = None
        self._seg_vao_id = None
        self._seg_vao_color_3d = None
        self._seg_vao_id_3d = None

        self._fbo_color = None
        self._fbo_id = None
        self._tex_id = None
        self._size = (0, 0)
        # 3D camera UBO
        self._ubo_camera = self._ctx.buffer(reserve=16 * 4 * 2 + 4 * 3 * 3)  # rough reserve
        self._inc("_live_buffers", 1)

    @property
    def ctx(self):
        return self._ctx

    def ensure_framebuffers(self, width: int, height: int) -> None:
        size = (int(width), int(height))
        if self._size == size and self._fbo_color is not None and self._fbo_id is not None:
            return

        # Tear down old targets first (avoid GL object accumulation in long-lived sessions).
        if self._fbo_color is not None:
            self._safe_release(self._fbo_color)
            self._dec("_live_framebuffers", 1)
            self._fbo_color = None
        if self._fbo_id is not None:
            self._safe_release(self._fbo_id)
            self._dec("_live_framebuffers", 1)
            self._fbo_id = None
        if self._tex_id is not None:
            self._safe_release(self._tex_id)
            self._dec("_live_textures", 1)
            self._tex_id = None

        self._size = size
        self._fbo_color = self._ctx.framebuffer(
            color_attachments=[self._ctx.texture(size, components=4, dtype="f1")],
            depth_attachment=self._ctx.depth_renderbuffer(size),
        )
        self._inc("_live_framebuffers", 1)

        self._tex_id = self._ctx.texture(size, components=1, dtype="u4")
        self._inc("_live_textures", 1)
        self._fbo_id = self._ctx.framebuffer(color_attachments=[self._tex_id], depth_attachment=self._ctx.depth_renderbuffer(size))
        self._inc("_live_framebuffers", 1)

    def upload_segments(self, segments: Sequence[GpuSegment]) -> None:
        # Release previous instance buffers/vaos (they can otherwise pile up when swapping scenes).
        if self._seg_vao_color is not None:
            self._safe_release(self._seg_vao_color)
            self._dec("_live_vaos", 1)
            self._seg_vao_color = None
        if self._seg_vao_id is not None:
            self._safe_release(self._seg_vao_id)
            self._dec("_live_vaos", 1)
            self._seg_vao_id = None
        if self._seg_vao_color_3d is not None:
            self._safe_release(self._seg_vao_color_3d)
            self._dec("_live_vaos", 1)
            self._seg_vao_color_3d = None
        if self._seg_vao_id_3d is not None:
            self._safe_release(self._seg_vao_id_3d)
            self._dec("_live_vaos", 1)
            self._seg_vao_id_3d = None
        if self._seg_vbo is not None:
            self._safe_release(self._seg_vbo)
            self._dec("_live_buffers", 1)
            self._seg_vbo = None

        # Instance struct: p0p1 (4f), color (4f), radius (1f), id (1u)
        data = bytearray()
        for s in segments:
            r, g, b, a = s.color_rgba8
            data.extend(struct.pack("4f", float(s.p0[0]), float(s.p0[1]), float(s.p1[0]), float(s.p1[1])))
            data.extend(struct.pack("4f", r / 255.0, g / 255.0, b / 255.0, a / 255.0))
            data.extend(struct.pack("f", float(s.radius)))
            data.extend(struct.pack("I", int(s.selection_id) & 0xFFFFFFFF))
        self._seg_vbo = self._ctx.buffer(data=bytes(data))
        self._seg_count = len(segments)
        self._inc("_live_buffers", 1)

        # Note: some GL drivers optimize away unused vertex inputs (e.g. `in_seg_id`
        # in the color pass, or `in_seg_color` in the ID pass). Bind only what the
        # shaders actually consume, but preserve the packed instance stride via
        # explicit padding in the format string.
        self._seg_vao_color = self._ctx.vertex_array(
            self._prog_seg_color,
            [
                (self._corner_vbo, "2f", "in_corner"),
                # Instance struct: p0p1 (4f), color (4f), radius (1f), id (1u) -> skip id (4x)
                (self._seg_vbo, "4f 4f 1f 4x /i", "in_seg_p0p1", "in_seg_color", "in_seg_radius"),
            ],
        )
        self._seg_vao_id = self._ctx.vertex_array(
            self._prog_seg_id,
            [
                (self._corner_vbo, "2f", "in_corner"),
                # Bind only the attributes needed to compute the quad + the selection id.
                # Skip color (16x) to avoid depending on optimizer decisions.
                (self._seg_vbo, "4f 16x 1f 1u /i", "in_seg_p0p1", "in_seg_radius", "in_seg_id"),
            ],
        )
        self._seg_vao_color_3d = self._ctx.vertex_array(
            self._prog_seg_color_3d,
            [
                (self._corner_vbo, "2f", "in_corner"),
                (self._seg_vbo, "4f 4f 1f 4x /i", "in_seg_p0p1", "in_seg_color", "in_seg_radius"),
                (self._seg_vbo, "4f 4f 1f 1u /i", "in_seg_p0p1", "in_seg_color", "in_seg_radius", "in_seg_id"),
            ],
        )
        self._seg_vao_id_3d = self._ctx.vertex_array(
            self._prog_seg_id_3d,
            [
                (self._corner_vbo, "2f", "in_corner"),
                (self._seg_vbo, "4f 16x 1f 1u /i", "in_seg_p0p1", "in_seg_radius", "in_seg_id"),
            ],
        )
        self._inc("_live_vaos", 4)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        # Release draw resources first, then the context.
        if self._seg_vao_color is not None:
            self._safe_release(self._seg_vao_color)
            self._dec("_live_vaos", 1)
            self._seg_vao_color = None
        if self._seg_vao_id is not None:
            self._safe_release(self._seg_vao_id)
            self._dec("_live_vaos", 1)
            self._seg_vao_id = None
        if self._seg_vbo is not None:
            self._safe_release(self._seg_vbo)
            self._dec("_live_buffers", 1)
            self._seg_vbo = None

        if self._fbo_color is not None:
            self._safe_release(self._fbo_color)
            self._dec("_live_framebuffers", 1)
            self._fbo_color = None
        if self._fbo_id is not None:
            self._safe_release(self._fbo_id)
            self._dec("_live_framebuffers", 1)
            self._fbo_id = None
        if self._tex_id is not None:
            self._safe_release(self._tex_id)
            self._dec("_live_textures", 1)
            self._tex_id = None

        if getattr(self, "_fsq_vao", None) is not None:
            self._safe_release(self._fsq_vao)
            self._dec("_live_vaos", 1)
            self._fsq_vao = None
        if getattr(self, "_fsq_vbo", None) is not None:
            self._safe_release(self._fsq_vbo)
            self._dec("_live_buffers", 1)
            self._fsq_vbo = None
        if getattr(self, "_corner_vbo", None) is not None:
            self._safe_release(self._corner_vbo)
            self._dec("_live_buffers", 1)
            self._corner_vbo = None

        if getattr(self, "_prog_bg", None) is not None:
            self._safe_release(self._prog_bg)
            self._dec("_live_programs", 1)
            self._prog_bg = None
        if getattr(self, "_prog_seg_color", None) is not None:
            self._safe_release(self._prog_seg_color)
            self._dec("_live_programs", 1)
            self._prog_seg_color = None
        if getattr(self, "_prog_seg_id", None) is not None:
            self._safe_release(self._prog_seg_id)
            self._dec("_live_programs", 1)
            self._prog_seg_id = None
        if getattr(self, "_prog_seg_color_3d", None) is not None:
            self._safe_release(self._prog_seg_color_3d)
            self._dec("_live_programs", 1)
            self._prog_seg_color_3d = None
        if getattr(self, "_prog_seg_id_3d", None) is not None:
            self._safe_release(self._prog_seg_id_3d)
            self._dec("_live_programs", 1)
            self._prog_seg_id_3d = None
        if getattr(self, "_prog_seg_color_3d", None) is not None:
            self._safe_release(self._prog_seg_color_3d)
            self._dec("_live_programs", 1)
            self._prog_seg_color_3d = None
        if getattr(self, "_prog_seg_id_3d", None) is not None:
            self._safe_release(self._prog_seg_id_3d)
            self._dec("_live_programs", 1)
            self._prog_seg_id_3d = None

        if getattr(self, "_ctx", None) is not None:
            self._safe_release(self._ctx)
            self._dec("_live_contexts", 1)
            self._ctx = None

    def __del__(self) -> None:  # pragma: no cover
        try:
            self.close()
        except Exception:
            pass

    def render_color(
        self,
        doc: LightconeDocument,
        *,
        width: int,
        height: int,
        phase: float,
        background_rgba8: tuple[int, int, int, int],
        y_clip: float,
        stage_bands: Sequence[tuple[float, float, tuple[int, int, int, int]]],
        readback: bool = True,
    ) -> bytes:
        self.ensure_framebuffers(width, height)
        assert self._fbo_color is not None

        self._fbo_color.use()
        self._ctx.disable(moderngl.DEPTH_TEST)
        self._ctx.disable(moderngl.CULL_FACE)
        # Be robust to callers leaving a scissor box enabled (e.g. embedded contexts).
        self._ctx.scissor = (0, 0, int(width), int(height))

        # Pass 0: background + stage bands in one fullscreen draw.
        self._ctx.disable(moderngl.BLEND)
        bg = tuple(int(x) for x in background_rgba8)
        self._prog_bg["u_resolution"].value = (float(width), float(height))
        self._prog_bg["u_bg"].value = (bg[0] / 255.0, bg[1] / 255.0, bg[2] / 255.0, bg[3] / 255.0)
        n = min(len(stage_bands), 8)
        self._prog_bg["u_stage_count"].value = int(n)
        y01 = [(0.0, 0.0)] * 8
        c01 = [(0.0, 0.0, 0.0, 0.0)] * 8
        for i in range(n):
            y0, y1, c = stage_bands[i]
            y01[i] = (float(y0), float(y1))
            c01[i] = (c[0] / 255.0, c[1] / 255.0, c[2] / 255.0, c[3] / 255.0)
        self._prog_bg["u_stage_y01"].value = y01
        self._prog_bg["u_stage_color"].value = c01
        self._fsq_vao.render(mode=moderngl.TRIANGLES, vertices=3)

        # Pass 1: segments (capsules) with premultiplied blending.
        if self._seg_vao_color is not None and self._seg_count:
            self._ctx.enable(moderngl.BLEND)
            self._ctx.blend_func = moderngl.ONE, moderngl.ONE_MINUS_SRC_ALPHA
            self._prog_seg_color["u_resolution"].value = (float(width), float(height))
            self._prog_seg_color["u_y_clip"].value = float(y_clip)
            self._seg_vao_color.render(mode=moderngl.TRIANGLES, vertices=6, instances=int(self._seg_count))

        if not readback:
            return b""

        data = self._fbo_color.read(components=4, dtype="f1")
        return _flip_rows(bytes(data), row_bytes=int(width) * 4, height=int(height))

    def render_id_u32(
        self,
        *,
        width: int,
        height: int,
        y_clip: float,
        readback: bool = True,
    ) -> bytes:
        self.ensure_framebuffers(width, height)
        assert self._fbo_id is not None

        self._fbo_id.use()
        self._ctx.disable(moderngl.DEPTH_TEST)
        self._ctx.disable(moderngl.CULL_FACE)
        self._ctx.disable(moderngl.BLEND)
        self._ctx.scissor = (0, 0, int(width), int(height))
        self._ctx.clear(0.0, 0.0, 0.0, 0.0)

        if self._seg_vao_id is not None and self._seg_count:
            self._prog_seg_id["u_resolution"].value = (float(width), float(height))
            self._prog_seg_id["u_y_clip"].value = float(y_clip)
            self._seg_vao_id.render(mode=moderngl.TRIANGLES, vertices=6, instances=int(self._seg_count))

        if not readback:
            return b""

        data = self._fbo_id.read(components=1, dtype="u4")
        return _flip_rows(bytes(data), row_bytes=int(width) * 4, height=int(height))

    # Placeholder 3D pipelines: reuse 2D paths to keep compatibility until full 3D shaders land.
    def render_color_3d(
        self,
        doc: LightconeDocument,
        *,
        width: int,
        height: int,
        phase: float,
        background_rgba8: tuple[int, int, int, int],
        y_clip: float,
        stage_bands: Sequence[tuple[float, float, tuple[int, int, int, int]]],
        geometry: CompiledGeometry,
        camera_pose: tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]],
        phase_clip: tuple[float, float] = (0.0, 1.0),
        theta_scale: float = 1.0,
        readback: bool = True,
    ) -> bytes:
        if self._seg_vao_color_3d is None or self._seg_count == 0:
            return b""
        self.ensure_framebuffers(width, height)
        assert self._fbo_color is not None

        self._fbo_color.use()
        self._ctx.enable(moderngl.DEPTH_TEST)
        self._ctx.enable(moderngl.CULL_FACE)
        self._ctx.front_face = "ccw"
        self._ctx.cull_face = "back"
        self._ctx.enable(moderngl.BLEND)
        self._ctx.blend_func = moderngl.ONE, moderngl.ONE_MINUS_SRC_ALPHA
        self._ctx.scissor = (0, 0, int(width), int(height))
        bg = background_rgba8
        self._ctx.clear(bg[0] / 255.0, bg[1] / 255.0, bg[2] / 255.0, bg[3] / 255.0, 1.0)

        eye, center, up = camera_pose
        view = _look_at(eye, center, up)
        proj = _perspective(35.0, float(width) / float(max(1, height)), 1.0, 5000.0)

        u = self._prog_seg_color_3d
        u["u_resolution"].value = (float(width), float(height))
        u["u_theta_scale"].value = float(theta_scale)
        u["u_phase_clip_lo"].value = float(phase_clip[0])
        u["u_phase_clip_hi"].value = float(phase_clip[1])
        u["u_eye"].value = tuple(float(x) for x in eye)
        u["u_center"].value = tuple(float(x) for x in center)
        u["u_up"].value = tuple(float(x) for x in up)
        u["u_view"].write(_mat4_to_bytes(view))
        u["u_proj"].write(_mat4_to_bytes(proj))

        self._seg_vao_color_3d.render(mode=moderngl.TRIANGLES, vertices=6, instances=int(self._seg_count))

        if not readback:
            return b""
        data = self._fbo_color.read(components=4, dtype="f1")
        return _flip_rows(bytes(data), row_bytes=int(width) * 4, height=int(height))

    def render_id_u32_3d(
        self,
        doc: LightconeDocument,
        *,
        width: int,
        height: int,
        phase: float,
        geometry: CompiledGeometry,
        camera_pose: tuple[tuple[float, float, float], tuple[float, float, float], tuple[float, float, float]],
        phase_clip: tuple[float, float] = (0.0, 1.0),
        theta_scale: float = 1.0,
        readback: bool = True,
    ) -> bytes:
        if self._seg_vao_id_3d is None or self._seg_count == 0:
            return b""
        self.ensure_framebuffers(width, height)
        assert self._fbo_id is not None

        self._fbo_id.use()
        self._ctx.enable(moderngl.DEPTH_TEST)
        self._ctx.enable(moderngl.CULL_FACE)
        self._ctx.front_face = "ccw"
        self._ctx.cull_face = "back"
        self._ctx.disable(moderngl.BLEND)
        self._ctx.scissor = (0, 0, int(width), int(height))
        self._ctx.clear(0.0, 0.0, 0.0, 0.0, 1.0)

        eye, center, up = camera_pose
        view = _look_at(eye, center, up)
        proj = _perspective(35.0, float(width) / float(max(1, height)), 1.0, 5000.0)

        u = self._prog_seg_id_3d
        u["u_resolution"].value = (float(width), float(height))
        u["u_theta_scale"].value = float(theta_scale)
        u["u_phase_clip_lo"].value = float(phase_clip[0])
        u["u_phase_clip_hi"].value = float(phase_clip[1])
        u["u_eye"].value = tuple(float(x) for x in eye)
        u["u_center"].value = tuple(float(x) for x in center)
        u["u_up"].value = tuple(float(x) for x in up)
        u["u_view"].write(_mat4_to_bytes(view))
        u["u_proj"].write(_mat4_to_bytes(proj))

        self._seg_vao_id_3d.render(mode=moderngl.TRIANGLES, vertices=6, instances=int(self._seg_count))

        if not readback:
            return b""
        data = self._fbo_id.read(components=1, dtype="u4")
        return _flip_rows(bytes(data), row_bytes=int(width) * 4, height=int(height))


def _y_of_phase(phase: float, *, y_bottom: float, axis_h: float) -> float:
    return y_bottom - _clamp_float(float(phase), 0.0, 1.0) * axis_h


def _camera_transform_px(
    x: float,
    y: float,
    *,
    width: int,
    height: int,
    pan_px: tuple[float, float],
    zoom: float,
) -> tuple[float, float]:
    cx = width * 0.5
    cy = height * 0.5
    x2 = (x - cx) * zoom + cx + pan_px[0]
    y2 = (y - cy) * zoom + cy + pan_px[1]
    return x2, y2


def _bezier_points(p0: tuple[float, float], p1: tuple[float, float], p2: tuple[float, float], p3: tuple[float, float], *, steps: int) -> list[tuple[float, float]]:
    out: list[tuple[float, float]] = []
    for i in range(steps + 1):
        t = i / steps
        u = 1.0 - t
        x = (
            u * u * u * p0[0]
            + 3.0 * u * u * t * p1[0]
            + 3.0 * u * t * t * p2[0]
            + t * t * t * p3[0]
        )
        y = (
            u * u * u * p0[1]
            + 3.0 * u * u * t * p1[1]
            + 3.0 * u * t * t * p2[1]
            + t * t * t * p3[1]
        )
        out.append((x, y))
    return out


def _perspective(fov_deg: float, aspect: float, z_near: float, z_far: float) -> tuple[tuple[float, float, float, float], ...]:
    f = 1.0 / math.tan(math.radians(fov_deg) * 0.5)
    a = (z_far + z_near) / (z_near - z_far)
    b = (2.0 * z_far * z_near) / (z_near - z_far)
    return (
        (f / aspect, 0.0, 0.0, 0.0),
        (0.0, f, 0.0, 0.0),
        (0.0, 0.0, a, -1.0),
        (0.0, 0.0, b, 0.0),
    )


def _normalize(v: tuple[float, float, float]) -> tuple[float, float, float]:
    l = math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])
    if l <= 1e-9:
        return (0.0, 0.0, 1.0)
    return (v[0] / l, v[1] / l, v[2] / l)


def _cross(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _dot(a: tuple[float, float, float], b: tuple[float, float, float]) -> float:
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _subtract(a: tuple[float, float, float], b: tuple[float, float, float]) -> tuple[float, float, float]:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _look_at(eye: tuple[float, float, float], center: tuple[float, float, float], up: tuple[float, float, float]) -> tuple[tuple[float, float, float, float], ...]:
    f = _normalize(_subtract(center, eye))
    u = _normalize(up)
    s = _normalize(_cross(f, u))
    u = _cross(s, f)

    m = (
        (s[0], u[0], -f[0], 0.0),
        (s[1], u[1], -f[1], 0.0),
        (s[2], u[2], -f[2], 0.0),
        (-_dot(s, eye), -_dot(u, eye), _dot(f, eye), 1.0),
    )
    return m


def _mat4_to_bytes(m: tuple[tuple[float, float, float, float], ...]) -> bytes:
    # Column-major for GL.
    cols = [
        (m[0][0], m[1][0], m[2][0], m[3][0]),
        (m[0][1], m[1][1], m[2][1], m[3][1]),
        (m[0][2], m[1][2], m[2][2], m[3][2]),
        (m[0][3], m[1][3], m[2][3], m[3][3]),
    ]
    out = []
    for c in cols:
        out.extend(c)
    return struct.pack("16f", *out)


def _polyline_segments(
    pts: Sequence[tuple[int, int]],
    *,
    radius: float,
    color: tuple[int, int, int, int],
    selection_id: int = 0,
) -> list[GpuSegment]:
    out: list[GpuSegment] = []
    if len(pts) < 2:
        return out
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        out.append(
            GpuSegment(
                p0=(float(x0), float(y0)),
                p1=(float(x1), float(y1)),
                radius=float(radius),
                color_rgba8=color,
                selection_id=int(selection_id),
            )
        )
    return out


def _disc_segment(
    *,
    x: int,
    y: int,
    radius: float,
    color: tuple[int, int, int, int],
    selection_id: int = 0,
) -> GpuSegment:
    return GpuSegment(
        p0=(float(x), float(y)),
        p1=(float(x), float(y)),
        radius=float(radius),
        color_rgba8=color,
        selection_id=int(selection_id),
    )


def _segments_to_dda_disc_stamps(segments: Sequence[GpuSegment]) -> list[GpuSegment]:
    """Expand segments into deterministic DDA disc stamps.

    The canonical CPU renderer draws lines/polylines by stamping discs at DDA-rounded points.
    Using the same sampling reduces GPU/CPU parity drift across GL drivers.
    """

    out: list[GpuSegment] = []
    for s in segments:
        x0 = int(round(float(s.p0[0])))
        y0 = int(round(float(s.p0[1])))
        x1 = int(round(float(s.p1[0])))
        y1 = int(round(float(s.p1[1])))
        dx = x1 - x0
        dy = y1 - y0
        steps = max(abs(dx), abs(dy))
        if steps <= 0:
            out.append(
                GpuSegment(
                    p0=(float(x0), float(y0)),
                    p1=(float(x0), float(y0)),
                    radius=float(s.radius),
                    color_rgba8=tuple(int(c) for c in s.color_rgba8),
                    selection_id=int(s.selection_id),
                )
            )
            continue
        for i in range(steps + 1):
            t = i / steps
            x = int(round(x0 + dx * t))
            y = int(round(y0 + dy * t))
            out.append(
                GpuSegment(
                    p0=(float(x), float(y)),
                    p1=(float(x), float(y)),
                    radius=float(s.radius),
                    color_rgba8=tuple(int(c) for c in s.color_rgba8),
                    selection_id=int(s.selection_id),
                )
            )
    return out


def _delta_bp(allele_ops: Sequence[Mapping[str, Any]]) -> int:
    ins = 0
    dele = 0
    for op in allele_ops:
        kind = str(op.get("op") or "").lower()
        if kind == "ins":
            ins += len(str(op.get("seq") or ""))
        elif kind == "del":
            dele += int(op.get("n") or 0)
    return ins - dele


def _assign_lane_offsets(n: int) -> list[int]:
    out: list[int] = []
    k = 0
    while len(out) < n:
        if k == 0:
            out.append(0)
        else:
            out.append(k)
            if len(out) < n:
                out.append(-k)
        k += 1
    return out[:n]


def _build_segments_lanes_v0(doc: LightconeDocument, *, width: int, height: int, phase: float) -> tuple[list[GpuSegment], float, list[tuple[float, float, tuple[int, int, int, int]]]]:
    """Build GPU segments for the legacy lane layout (matches CPU renderer order/knobs)."""

    rg = doc.render_golden
    if rg is None:
        raise ValueError("GPU render requires renderGolden (explicit invariants)")
    style = rg.style

    margin_l, margin_r, margin_t, margin_b = style.margins
    x_center = width // 2
    y_top = margin_t
    y_bottom = height - margin_b
    axis_h = max(1, y_bottom - y_top)

    def y_of_p(p: float) -> float:
        return _y_of_phase(p, y_bottom=float(y_bottom), axis_h=float(axis_h))

    y_clip = y_of_p(float(phase))

    stage_bands: list[tuple[float, float, tuple[int, int, int, int]]] = []
    stages = doc.phase_stages or _default_phase_stages()
    for st in stages:
        y0 = y_of_p(float(st.end))
        y1 = y_of_p(float(st.start))
        if y1 <= y0:
            continue
        stage_bands.append((float(y0), float(y1), _stage_color_rgba8(st.name)))

    segs: list[GpuSegment] = []

    # Trunk up to current phase.
    x0_t, y0_t = _camera_transform_px(float(x_center), float(y_bottom), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
    x1_t, y1_t = _camera_transform_px(float(x_center), float(y_clip), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
    trunk_r = _radius_draw_px(_scale_radius(int(style.trunk_radius_px), float(rg.camera.zoom)))
    segs.append(
        GpuSegment(
            p0=(float(round(x0_t)), float(round(y0_t))),
            p1=(float(round(x1_t)), float(round(y1_t))),
            radius=float(trunk_r),
            color_rgba8=tuple(int(c) for c in style.trunk_color),
            selection_id=0,
        )
    )

    outcomes = list(stable_sort_outcomes(doc.outcomes))
    lane_offsets = _assign_lane_offsets(len(outcomes))
    max_lane = max(1, max(abs(i) for i in lane_offsets))
    usable_w = max(1, width - margin_l - margin_r)
    if doc.edit_type == "base_edit":
        total_spread = min(float(style.base_edit_lane_spread_px), usable_w * float(style.base_edit_lane_spread_frac))
        lane_dx = total_spread / max_lane
    else:
        lane_dx = min(float(style.lane_spread_px), (usable_w * float(style.lane_spread_frac)) / max_lane)

    max_prob = max(1e-9, max(float(o.probability) for o in outcomes))

    for oc, lane in zip(outcomes, lane_offsets):
        div = _clamp_float(float(oc.divergence_phase), 0.0, 1.0)
        if phase <= div:
            continue
        y_div = y_of_p(div)
        delta = _delta_bp(oc.allele_ops)
        x_tip = float(x_center) + lane_dx * lane + _clamp_float(delta * float(style.delta_bp_scale_px), -float(style.delta_bp_clamp_px), float(style.delta_bp_clamp_px))
        x_tip = _clamp_float(x_tip, float(margin_l), float(width - margin_r))

        mid_y = (y_div + y_clip) * 0.5
        p0 = (float(x_center), float(y_div))
        p3 = (float(x_tip), float(y_clip))
        p1 = (float(x_center), float(mid_y))
        p2 = (float(x_tip), float(mid_y))
        pts_f = _bezier_points(p0, p1, p2, p3, steps=36)
        pts: list[tuple[int, int]] = []
        for x, y in pts_f:
            x_t, y_t = _camera_transform_px(x, y, width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
            pts.append((int(round(x_t)), int(round(y_t))))

        tags_l = {t.lower() for t in oc.mechanism_tags}
        rgb, thickness_mul, braid = style.default_color_rgb, 1.0, False
        for rule in style.tag_rules:
            if any(t in tags_l for t in rule.match_any):
                if rule.color_rgb is not None:
                    rgb = rule.color_rgb
                if rule.thickness_mul is not None:
                    thickness_mul *= float(rule.thickness_mul)
                if rule.braid is not None:
                    braid = braid or bool(rule.braid)
                break

        intensity = math.sqrt(max(0.0, float(oc.probability)) / max_prob)
        alpha = int(round(int(style.alpha_base) + int(style.alpha_scale) * intensity))
        alpha = _clamp_int(alpha, int(style.alpha_min), int(style.alpha_max))
        color = (int(rgb[0]), int(rgb[1]), int(rgb[2]), alpha)
        base_r = max(0, int(round(float(style.branch_radius_px) * float(thickness_mul))))
        r_scaled = _scale_radius(base_r, float(rg.camera.zoom))
        radius = _radius_draw_px(r_scaled)

        if doc.edit_type == "prime_edit" and braid:
            # Same braided signature as CPU: two strands with alternating lateral offset.
            offset = max(1, int(r_scaled) + 1)
            a: list[tuple[int, int]] = []
            b: list[tuple[int, int]] = []
            for i, (x, y) in enumerate(pts):
                sign = 1 if (i // 4) % 2 == 0 else -1
                a.append((x + sign * offset, y))
                b.append((x - sign * offset, y))
            segs.extend(_polyline_segments(a, radius=radius, color=color))
            segs.extend(_polyline_segments(b, radius=radius, color=color))
        else:
            segs.extend(_polyline_segments(pts, radius=radius, color=color))

        # Tip dot.
        x_tip_t, y_tip_t = _camera_transform_px(float(x_tip), float(y_clip), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
        tip_alpha = _clamp_int(alpha + int(style.tip_alpha_boost), 0, 255)
        tip_r = _radius_draw_px(_scale_radius(int(style.tip_radius_px), float(rg.camera.zoom)))
        segs.append(
            _disc_segment(
                x=int(round(x_tip_t)),
                y=int(round(y_tip_t)),
                radius=float(tip_r),
                color=(int(rgb[0]), int(rgb[1]), int(rgb[2]), int(tip_alpha)),
            )
        )

    # Ghosts and threads.
    ghosts_cfg = dict(style.ghosts)
    if doc.off_targets and bool(ghosts_cfg.get("enabled", True)):
        ghosts = list(doc.off_targets)
        ghosts.sort(key=lambda g: (-float(g.probability_mass), str(g.id)))
        total_mass = sum(float(g.probability_mass) for g in ghosts) or 1.0
        gx0 = margin_l
        gx1 = width - margin_r
        for idx, ghost in enumerate(ghosts):
            t = 0.5 if len(ghosts) == 1 else idx / (len(ghosts) - 1)
            gx = int(round(gx0 + t * (gx1 - gx0)))
            gy = int(round(y_of_p(0.05)))
            mass = float(ghost.probability_mass) / total_mass
            alpha_scale = int(ghosts_cfg.get("alphaScalePrime" if doc.edit_type == "prime_edit" else "alphaScale", 140))
            alpha_base = int(ghosts_cfg.get("alphaBase", 35))
            alpha_min = int(ghosts_cfg.get("alphaMin", 18))
            alpha_max = int(ghosts_cfg.get("alphaMax", 200))
            alpha = _clamp_int(int(round(alpha_base + alpha_scale * math.sqrt(mass))), alpha_min, alpha_max)
            c = (int(ghosts_cfg.get("colorR", 160)), int(ghosts_cfg.get("colorG", 120)), int(ghosts_cfg.get("colorB", 255)), alpha)

            gx_t, gy_t = _camera_transform_px(float(gx), float(gy), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
            radius = int(ghosts_cfg.get("radiusPrime" if doc.edit_type == "prime_edit" else "radius", 5))
            ghost_r = _radius_draw_px(_scale_radius(int(radius), float(rg.camera.zoom)))
            segs.append(_disc_segment(x=int(round(gx_t)), y=int(round(gy_t)), radius=float(ghost_r), color=c))

            tx_t, ty_t = _camera_transform_px(float(x_center), float(y_of_p(0.12)), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
            segs.append(
                GpuSegment(
                    p0=(float(round(gx_t)), float(round(gy_t))),
                    p1=(float(round(tx_t)), float(round(ty_t))),
                    radius=0.5,
                    color_rgba8=(c[0], c[1], c[2], alpha // int(ghosts_cfg.get("threadAlphaDiv", 2))),
                    selection_id=0,
                )
            )

            if bool(ghosts_cfg.get("mismatchThreadsEnabled", False)):
                mismatches = ghost.mismatch_signature.get("mismatches") or []
                idxs: list[int] = []
                if isinstance(mismatches, Sequence) and not isinstance(mismatches, (str, bytes, bytearray)):
                    for m in mismatches:
                        if not isinstance(m, Mapping):
                            continue
                        try:
                            idxs.append(int(m.get("index") or 0))
                        except Exception:
                            continue
                if idxs:
                    idxs.sort()
                    max_idx = max(idxs) or 1
                    pulse_r = _radius_draw_px(_scale_radius(int(ghosts_cfg.get("mismatchPulseRadius", 2)), float(rg.camera.zoom)))
                    for i in idxs:
                        tt = 0.15 + 0.7 * (i / max_idx)
                        x = int(round(tx_t + (gx_t - tx_t) * tt))
                        y = int(round(ty_t + (gy_t - ty_t) * tt))
                        segs.append(_disc_segment(x=x, y=y, radius=pulse_r, color=(c[0], c[1], c[2], _clamp_int(alpha // 2 + 10, 0, 255))))

    # Base-edit sheen discs (late so it sits on top).
    base_sheen_cfg = dict(style.base_sheen)
    if doc.edit_type == "base_edit" and doc.reference_window and doc.reference_window.sequence and bool(base_sheen_cfg.get("enabled", True)):
        ref_len = len(doc.reference_window.sequence)
        if ref_len > 0:
            mass_by_pos = [0.0 for _ in range(ref_len)]
            for oc in outcomes:
                ref_pos = 0
                for op in oc.allele_ops:
                    kind = str(op.get("op") or "").lower()
                    if kind == "match":
                        ref_pos += int(op.get("n") or 0)
                    elif kind == "del":
                        ref_pos += int(op.get("n") or 0)
                    elif kind == "ins":
                        continue
                    elif kind == "sub":
                        ref = str(op.get("ref") or "")
                        ln = len(ref)
                        for j in range(ln):
                            pos = ref_pos + j
                            if 0 <= pos < ref_len:
                                mass_by_pos[pos] += float(oc.probability)
                        ref_pos += ln
            peak = max(mass_by_pos) if mass_by_pos else 0.0
            if peak > 1e-9:
                tags = {t.lower() for o in outcomes for t in o.mechanism_tags}
                if "cbe" in tags:
                    rgb = tuple(int(x) for x in (base_sheen_cfg.get("cbeRgb") or (110, 180, 255)))
                elif "abe" in tags:
                    rgb = tuple(int(x) for x in (base_sheen_cfg.get("abeRgb") or (170, 255, 150)))
                else:
                    rgb = tuple(int(x) for x in (base_sheen_cfg.get("defaultRgb") or (120, 220, 210)))

                y_center = y_of_p(float(base_sheen_cfg.get("phaseCenter", 0.72)))
                sheen_h = min(float(base_sheen_cfg.get("spanPx", 80.0)), axis_h * float(base_sheen_cfg.get("phaseSpan", 0.28)))
                radius = _radius_draw_px(_scale_radius(int(base_sheen_cfg.get("radiusPx", 3)), float(rg.camera.zoom)))
                a_base = int(base_sheen_cfg.get("alphaBase", 18))
                a_scale = int(base_sheen_cfg.get("alphaScale", 210))
                for pos, mass in enumerate(mass_by_pos):
                    if mass <= 0.0:
                        continue
                    tt = 0.0 if ref_len <= 1 else (pos / (ref_len - 1) - 0.5)
                    y = y_center + tt * sheen_h
                    alpha = _clamp_int(int(round(a_base + a_scale * (mass / peak) ** 0.5)), 0, 255)
                    x_t, y_t = _camera_transform_px(float(x_center), float(y), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
                    segs.append(_disc_segment(x=int(round(x_t)), y=int(round(y_t)), radius=radius, color=(int(rgb[0]), int(rgb[1]), int(rgb[2]), alpha)))

    return segs, float(y_clip), stage_bands


def _build_segments_tree_v1(
    doc: LightconeDocument,
    *,
    width: int,
    height: int,
    phase: float,
    pick_mode: bool,
) -> tuple[list[GpuSegment], float, list[tuple[float, float, tuple[int, int, int, int]]], CompiledGeometry]:
    rg = doc.render_golden
    assert rg is not None
    style = rg.style
    margin_l, margin_r, margin_t, margin_b = style.margins
    x_center = width // 2
    y_top = margin_t
    y_bottom = height - margin_b
    axis_h = max(1, y_bottom - y_top)

    def y_of_p(p: float) -> float:
        return _y_of_phase(p, y_bottom=float(y_bottom), axis_h=float(axis_h))

    y_clip = y_of_p(float(phase))

    stage_bands: list[tuple[float, float, tuple[int, int, int, int]]] = []
    stages = doc.phase_stages or _default_phase_stages()
    for st in stages:
        y0 = y_of_p(float(st.end))
        y1 = y_of_p(float(st.start))
        if y1 <= y0:
            continue
        stage_bands.append((float(y0), float(y1), _stage_color_rgba8(st.name)))

    geom = compile_lightcone_geometry(doc, width=width, height=height, phase=phase, camera_pan_px=rg.camera.pan_px, camera_zoom=rg.camera.zoom)

    steps_per_edge = 32
    bp = getattr(doc, "builder_provenance", None)
    if bp is not None:
        try:
            from .stress import STRESS_TREE_BUILDER_ID, StressTreeParams

            if str(getattr(bp, "builder_id", "")) == STRESS_TREE_BUILDER_ID:
                sp = StressTreeParams.from_builder_params(seed=int(getattr(bp, "seed", 0)), params=getattr(bp, "params", {}) or {})
                steps_per_edge = int(sp.segments_per_edge)
        except Exception:
            pass
    steps_per_edge = _clamp_int(int(steps_per_edge), 4, 256)

    segs: list[GpuSegment] = []
    # Trunk up to current phase.
    x0_t, y0_t = _camera_transform_px(float(x_center), float(y_bottom), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
    x1_t, y1_t = _camera_transform_px(float(x_center), float(y_clip), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
    trunk_r = _radius_draw_px(_scale_radius(int(style.trunk_radius_px), float(rg.camera.zoom)))
    segs.append(
        GpuSegment(
            p0=(float(round(x0_t)), float(round(y0_t))),
            p1=(float(round(x1_t)), float(round(y1_t))),
            radius=float(trunk_r),
            color_rgba8=tuple(int(c) for c in style.trunk_color),
            selection_id=0,
        )
    )

    # Deterministic ordering for pick: low mass first, intended last (similar to CPU picker).
    edges = list(geom.edges)
    sel_index = None
    if pick_mode:
        sel_index = build_selection_index(doc, geom)

        def is_intended(edge: CompiledEdge) -> bool:
            info = sel_index.get(int(edge.selection_id))
            if info is None:
                return False
            return "intended" in {t.lower() for t in info.mechanism_tags}

        edges.sort(key=lambda e: (is_intended(e), float(e.probability_mass), int(e.selection_id)))
    # For the color/parity path, preserve the compiler edge order to keep blending stable.

    # Dynamic pruning: skip very low-mass branches to keep interactive perf.
    base_thresh = float(os.environ.get("HELIX_LIGHTCONE_GPU_THRESH", "0.0005"))
    zoom = float(rg.camera.zoom)
    dyn_thresh = base_thresh * max(0.3, min(3.0, 1.0 / zoom))

    for e in edges:
        if float(e.probability_mass) < dyn_thresh:
            continue
        pts = _bezier_points(tuple(e.p0), tuple(e.p1), tuple(e.p2), tuple(e.p3), steps=steps_per_edge)
        # Already in post-camera integer-ish pixel coords.
        pts_i = [(int(round(x)), int(round(y))) for (x, y) in pts]
        color = tuple(int(c) for c in e.color)
        sel_id = int(e.selection_id) if pick_mode else 0
        r_canvas = max(0, int(e.radius_px))
        r = _radius_draw_px(r_canvas)

        if e.braid and r_canvas > 0:
            offset = max(1, int(r_canvas) + 1)
            a: list[tuple[int, int]] = []
            b: list[tuple[int, int]] = []
            for i, (x, y) in enumerate(pts_i):
                sign = 1 if (i // 4) % 2 == 0 else -1
                a.append((x + sign * offset, y))
                b.append((x - sign * offset, y))
            segs.extend(_polyline_segments(a, radius=float(r), color=color, selection_id=sel_id))
            segs.extend(_polyline_segments(b, radius=float(r), color=color, selection_id=sel_id))
        else:
            segs.extend(_polyline_segments(pts_i, radius=float(r), color=color, selection_id=sel_id))

        # Tip dot at end.
        tip_alpha = _clamp_int(int(e.color[3]) + int(style.tip_alpha_boost), 0, 255)
        tip_r = _radius_draw_px(max(1, int(style.tip_radius_px)))
        segs.append(
            _disc_segment(
                x=int(e.p3[0]),
                y=int(e.p3[1]),
                radius=float(tip_r),
                color=(int(color[0]), int(color[1]), int(color[2]), int(tip_alpha)),
                selection_id=sel_id,
            )
        )

    # Ghosts and threads (visual only; discs are pickable when pick_mode is enabled).
    ghosts_cfg = dict(style.ghosts)
    if doc.off_targets and bool(ghosts_cfg.get("enabled", True)):
        ghost_sid_by_id: dict[str, int] = {}
        if pick_mode and sel_index is not None:
            ghost_sid_by_id = {
                str(info.ghost_id): int(sid)
                for sid, info in sel_index.items()
                if info.kind == "ghost" and info.ghost_id is not None
            }

        ghosts = list(doc.off_targets)
        ghosts.sort(key=lambda g: (-float(g.probability_mass), str(g.id)))
        total_mass = sum(float(g.probability_mass) for g in ghosts) or 1.0
        gx0 = margin_l
        gx1 = width - margin_r
        for idx, ghost in enumerate(ghosts):
            t = 0.5 if len(ghosts) == 1 else idx / (len(ghosts) - 1)
            gx = int(round(gx0 + t * (gx1 - gx0)))
            gy = int(round(y_of_p(0.05)))
            mass = float(ghost.probability_mass) / total_mass
            alpha_scale = int(ghosts_cfg.get("alphaScalePrime" if doc.edit_type == "prime_edit" else "alphaScale", 140))
            alpha_base = int(ghosts_cfg.get("alphaBase", 35))
            alpha_min = int(ghosts_cfg.get("alphaMin", 18))
            alpha_max = int(ghosts_cfg.get("alphaMax", 200))
            alpha = _clamp_int(int(round(alpha_base + alpha_scale * math.sqrt(mass))), alpha_min, alpha_max)
            c = (int(ghosts_cfg.get("colorR", 160)), int(ghosts_cfg.get("colorG", 120)), int(ghosts_cfg.get("colorB", 255)), alpha)

            gx_t, gy_t = _camera_transform_px(float(gx), float(gy), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
            radius = int(ghosts_cfg.get("radiusPrime" if doc.edit_type == "prime_edit" else "radius", 5))
            sid = int(ghost_sid_by_id.get(str(ghost.id), 0)) if pick_mode else 0
            ghost_r = _radius_draw_px(_scale_radius(int(radius), float(rg.camera.zoom)))
            segs.append(_disc_segment(x=int(round(gx_t)), y=int(round(gy_t)), radius=float(ghost_r), color=c, selection_id=sid))

            # Thread line back to trunk (not pickable).
            tx_t, ty_t = _camera_transform_px(float(x_center), float(y_of_p(0.12)), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
            segs.append(
                GpuSegment(
                    p0=(float(round(gx_t)), float(round(gy_t))),
                    p1=(float(round(tx_t)), float(round(ty_t))),
                    radius=_radius_draw_px(0),
                    color_rgba8=(c[0], c[1], c[2], alpha // int(ghosts_cfg.get("threadAlphaDiv", 2))),
                    selection_id=0,
                )
            )
            if bool(ghosts_cfg.get("mismatchThreadsEnabled", False)):
                mismatches = ghost.mismatch_signature.get("mismatches") or []
                idxs: list[int] = []
                if isinstance(mismatches, Sequence) and not isinstance(mismatches, (str, bytes, bytearray)):
                    for m in mismatches:
                        if not isinstance(m, Mapping):
                            continue
                        try:
                            idxs.append(int(m.get("index") or 0))
                        except Exception:
                            continue
                if idxs:
                    idxs.sort()
                    max_idx = max(idxs) or 1
                    pulse_r = _radius_draw_px(_scale_radius(int(ghosts_cfg.get("mismatchPulseRadius", 2)), float(rg.camera.zoom)))
                    for i in idxs:
                        tt = 0.15 + 0.7 * (i / max_idx)
                        x = int(round(tx_t + (gx_t - tx_t) * tt))
                        y = int(round(ty_t + (gy_t - ty_t) * tt))
                        segs.append(_disc_segment(x=x, y=y, radius=pulse_r, color=(c[0], c[1], c[2], _clamp_int(alpha // 2 + 10, 0, 255)), selection_id=0))

    # Base-edit sheen discs (late so it sits on top).
    outcomes = list(stable_sort_outcomes(doc.outcomes))
    base_sheen_cfg = dict(style.base_sheen)
    if doc.edit_type == "base_edit" and doc.reference_window and doc.reference_window.sequence and bool(base_sheen_cfg.get("enabled", True)):
        ref_len = len(doc.reference_window.sequence)
        if ref_len > 0:
            mass_by_pos = [0.0 for _ in range(ref_len)]
            for oc in outcomes:
                ref_pos = 0
                for op in oc.allele_ops:
                    kind = str(op.get("op") or "").lower()
                    if kind == "match":
                        ref_pos += int(op.get("n") or 0)
                    elif kind == "del":
                        ref_pos += int(op.get("n") or 0)
                    elif kind == "ins":
                        continue
                    elif kind == "sub":
                        ref = str(op.get("ref") or "")
                        ln = len(ref)
                        for j in range(ln):
                            pos = ref_pos + j
                            if 0 <= pos < ref_len:
                                mass_by_pos[pos] += float(oc.probability)
                        ref_pos += ln
            peak = max(mass_by_pos) if mass_by_pos else 0.0
            if peak > 1e-9:
                tags = {t.lower() for o in outcomes for t in o.mechanism_tags}
                if "cbe" in tags:
                    rgb = tuple(int(x) for x in (base_sheen_cfg.get("cbeRgb") or (110, 180, 255)))
                elif "abe" in tags:
                    rgb = tuple(int(x) for x in (base_sheen_cfg.get("abeRgb") or (170, 255, 150)))
                else:
                    rgb = tuple(int(x) for x in (base_sheen_cfg.get("defaultRgb") or (120, 220, 210)))

                y_center = y_of_p(float(base_sheen_cfg.get("phaseCenter", 0.72)))
                sheen_h = min(float(base_sheen_cfg.get("spanPx", 80.0)), axis_h * float(base_sheen_cfg.get("phaseSpan", 0.28)))
                radius = _radius_draw_px(_scale_radius(int(base_sheen_cfg.get("radiusPx", 3)), float(rg.camera.zoom)))
                a_base = int(base_sheen_cfg.get("alphaBase", 18))
                a_scale = int(base_sheen_cfg.get("alphaScale", 210))
                for pos, mass in enumerate(mass_by_pos):
                    if mass <= 0.0:
                        continue
                    tt = 0.0 if ref_len <= 1 else (pos / (ref_len - 1) - 0.5)
                    y = y_center + tt * sheen_h
                    alpha = _clamp_int(int(round(a_base + a_scale * (mass / peak) ** 0.5)), 0, 255)
                    x_t, y_t = _camera_transform_px(float(x_center), float(y), width=width, height=height, pan_px=rg.camera.pan_px, zoom=rg.camera.zoom)
                    segs.append(_disc_segment(x=int(round(x_t)), y=int(round(y_t)), radius=radius, color=(int(rgb[0]), int(rgb[1]), int(rgb[2]), alpha), selection_id=0))

    return segs, float(y_clip), stage_bands, geom


def render_lightcone_rgba_gpu_from_golden(doc: LightconeDocument) -> bytes:
    rg = doc.render_golden
    if rg is None:
        raise ValueError("Lightcone document missing renderGolden")
    return render_lightcone_rgba_gpu(
        doc,
        width=rg.width,
        height=rg.height,
        phase=rg.phase,
    )


def render_lightcone_rgba_gpu(doc: LightconeDocument, *, width: int, height: int, phase: float) -> bytes:
    if moderngl is None:
        raise RuntimeError("GPU lightcone backend requires 'moderngl' (install the 'realtime' extra).")
    rg = doc.render_golden
    if rg is None:
        raise ValueError("GPU render requires renderGolden (explicit invariants)")
    style = rg.style

    if style.layout_mode == "lanes_v0":
        segs, y_clip, stage_bands = _build_segments_lanes_v0(doc, width=width, height=height, phase=phase)
        geom = None
    elif style.layout_mode == "tree_v1":
        segs, y_clip, stage_bands, geom = _build_segments_tree_v1(doc, width=width, height=height, phase=phase, pick_mode=False)
    else:
        raise ValueError(f"Unsupported style.layoutMode for GPU backend: {style.layout_mode!r}")

    if _gpu_raster_mode() == "stamps":
        segs = _segments_to_dda_disc_stamps(segs)

    renderer = LightconeGpuRenderer()
    renderer.upload_segments(segs)
    rgba = renderer.render_color(
        doc,
        width=width,
        height=height,
        phase=phase,
        background_rgba8=tuple(int(x) for x in rg.background),
        y_clip=float(y_clip),
        stage_bands=stage_bands,
    )
    return rgba


def render_lightcone_id_u32_gpu_from_golden(doc: LightconeDocument) -> tuple[bytes, CompiledGeometry]:
    rg = doc.render_golden
    if rg is None:
        raise ValueError("Lightcone document missing renderGolden")
    return render_lightcone_id_u32_gpu(
        doc,
        width=rg.width,
        height=rg.height,
        phase=rg.phase,
    )


def render_lightcone_id_u32_gpu(doc: LightconeDocument, *, width: int, height: int, phase: float) -> tuple[bytes, CompiledGeometry]:
    if moderngl is None:
        raise RuntimeError("GPU lightcone backend requires 'moderngl' (install the 'realtime' extra).")
    rg = doc.render_golden
    if rg is None:
        raise ValueError("GPU pick render requires renderGolden (explicit invariants)")
    style = rg.style
    if style.layout_mode != "tree_v1":
        raise ValueError("GPU picking currently requires style.layoutMode='tree_v1'")

    segs, y_clip, stage_bands, geom = _build_segments_tree_v1(doc, width=width, height=height, phase=phase, pick_mode=True)
    _ = stage_bands  # not used in pick path

    if _gpu_raster_mode() == "stamps":
        segs = _segments_to_dda_disc_stamps(segs)

    renderer = LightconeGpuRenderer()
    renderer.upload_segments(segs)
    u32 = renderer.render_id_u32(width=width, height=height, y_clip=float(y_clip))
    return u32, geom


def decode_id_u32_le(buffer: bytes, *, x: int, y: int, width: int, height: int) -> int:
    if x < 0 or y < 0 or x >= width or y >= height:
        return 0
    i = (y * width + x) * 4
    if i + 4 > len(buffer):
        return 0
    return struct.unpack_from("<I", buffer, i)[0]
