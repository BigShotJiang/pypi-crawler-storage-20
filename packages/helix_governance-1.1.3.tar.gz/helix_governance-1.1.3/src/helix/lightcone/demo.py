from __future__ import annotations

import argparse
import json
from pathlib import Path

from .contract import load_lightcone_document
from .png import write_png_rgba8
from .metadata import build_lightcone_png_text
from .render import render_lightcone_rgba, render_settings_payload, render_settings_sha256, sha256_hex
from .geometry import compile_lightcone_geometry, compiled_geometry_sha256


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="helix-lightcone-demo")
    p.add_argument("--fixture", required=True, help="Path to a v0.1 lightcone JSON fixture")
    p.add_argument("--out", required=True, help="Output PNG path")
    p.add_argument("--backend", choices=["cpu", "gpu"], default="cpu", help="Render backend (cpu is canonical for goldens)")
    p.add_argument("--width", type=int, default=None)
    p.add_argument("--height", type=int, default=None)
    p.add_argument("--phase", type=float, default=None, help="Phase in [0,1] (default: fixture renderGolden.phase or 1.0)")
    args = p.parse_args(argv)

    doc = load_lightcone_document(args.fixture)
    rg = doc.render_golden
    width = int(args.width if args.width is not None else (rg.width if rg else 800))
    height = int(args.height if args.height is not None else (rg.height if rg else 450))
    phase = float(args.phase if args.phase is not None else (rg.phase if rg else 1.0))

    if rg is not None:
        settings_payload = render_settings_payload(rg)
        if args.width is not None:
            settings_payload["width"] = width
        if args.height is not None:
            settings_payload["height"] = height
        if args.phase is not None:
            settings_payload["phase"] = phase
        settings_sha = sha256_hex(
            json.dumps(settings_payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        )
    else:
        settings_payload = None
        settings_sha = ""

    extra: dict[str, object] | None = None
    if args.width is not None or args.height is not None or args.phase is not None:
        extra = {"overrides": {"width": args.width, "height": args.height, "phase": args.phase}}

    if args.backend == "gpu":
        from .gpu_backend import gpu_preflight, lightcone_gpu_shader_sha256, render_lightcone_rgba_gpu

        rgba = render_lightcone_rgba_gpu(doc, width=width, height=height, phase=phase)
        info, skip_reason = gpu_preflight(allow_software=True)
        extra2 = {
            "backend": "gpu",
            "gpuShaderSha256": lightcone_gpu_shader_sha256(),
            "gpuPreflight": info,
        }
        if skip_reason:
            extra2["gpuPreflightWarning"] = skip_reason
        extra = {**(extra or {}), **extra2}
    else:
        rgba = render_lightcone_rgba(
            doc,
            width=width,
            height=height,
            phase=phase,
            background=(rg.background if rg is not None else (8, 10, 18, 255)),
            camera_pan_px=(rg.camera.pan_px if rg is not None else (0.0, 0.0)),
            camera_zoom=(rg.camera.zoom if rg is not None else 1.0),
        )
    rgba_sha = sha256_hex(rgba)

    text = None
    if rg is not None:
        geometry_sha = None
        try:
            if rg.style.layout_mode == "tree_v1":
                geom = compile_lightcone_geometry(
                    doc,
                    width=width,
                    height=height,
                    phase=phase,
                    camera_pan_px=rg.camera.pan_px,
                    camera_zoom=rg.camera.zoom,
                )
                geometry_sha = compiled_geometry_sha256(geom)
        except Exception:
            geometry_sha = None
        text = build_lightcone_png_text(
            doc,
            rg,
            rgba_sha256=rgba_sha,
            settings_sha256=settings_sha,
            geometry_sha256=geometry_sha,
            settings=(settings_payload or None),
            extra=extra,
        )

    write_png_rgba8(Path(args.out), width=width, height=height, rgba=rgba, text=text)
    print(f"Wrote {args.out} ({width}x{height}), rgbaSha256={rgba_sha}")
    if rg is not None:
        if settings_sha and settings_sha != rg.settings_sha256:
            print(f"Note: settingsSha256 mismatch fixture={rg.settings_sha256} computed={settings_sha}")
        if rgba_sha != rg.rgba_sha256:
            print(f"Note: rgbaSha256 mismatch fixture={rg.rgba_sha256} computed={rgba_sha}")
        if rg.geometry_sha256 and geometry_sha and geometry_sha != rg.geometry_sha256:
            print(f"Note: geometrySha256 mismatch fixture={rg.geometry_sha256} computed={geometry_sha}")


if __name__ == "__main__":  # pragma: no cover
    main()
