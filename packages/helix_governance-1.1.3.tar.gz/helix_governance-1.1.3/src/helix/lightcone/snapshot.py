from __future__ import annotations

from typing import Any, Mapping

from .contract import (
    BuilderProvenance,
    Camera2D,
    LightconeDocument,
    Locus,
    OffTarget,
    Outcome,
    PhaseStage,
    Projection2D,
    ReferenceWindow,
    RenderGolden,
    RenderStyle,
    RenderTolerance,
    Renderer,
    StyleRule,
)


def _locus_to_payload(locus: Locus) -> dict[str, Any]:
    return {
        "contig": str(locus.contig),
        "position": int(locus.position),
        "strand": str(locus.strand),
        "windowStart": int(locus.window_start),
        "windowEnd": int(locus.window_end),
    }


def _reference_window_to_payload(ref: ReferenceWindow) -> dict[str, Any]:
    out: dict[str, Any] = {"start": int(ref.start), "end": int(ref.end)}
    if ref.sequence is not None:
        out["sequence"] = str(ref.sequence)
    if ref.checksum is not None:
        out["checksum"] = str(ref.checksum)
    return out


def _phase_stage_to_payload(st: PhaseStage) -> dict[str, Any]:
    return {"name": str(st.name), "start": float(st.start), "end": float(st.end)}


def _style_rule_to_payload(rule: StyleRule) -> dict[str, Any]:
    out: dict[str, Any] = {"matchAny": [str(t) for t in rule.match_any]}
    if rule.color_rgb is not None:
        out["colorRgb"] = [int(rule.color_rgb[0]), int(rule.color_rgb[1]), int(rule.color_rgb[2])]
    if rule.thickness_mul is not None:
        out["thicknessMul"] = float(rule.thickness_mul)
    if rule.braid is not None:
        out["braid"] = bool(rule.braid)
    return out


def _render_style_to_payload(style: RenderStyle) -> dict[str, Any]:
    return {
        "version": str(style.version),
        "layoutMode": str(style.layout_mode),
        "margins": {
            "left": int(style.margins[0]),
            "right": int(style.margins[1]),
            "top": int(style.margins[2]),
            "bottom": int(style.margins[3]),
        },
        "trunkColor": [int(x) for x in style.trunk_color],
        "trunkRadiusPx": int(style.trunk_radius_px),
        "branchRadiusPx": int(style.branch_radius_px),
        "tipRadiusPx": int(style.tip_radius_px),
        "tipAlphaBoost": int(style.tip_alpha_boost),
        "alphaBase": int(style.alpha_base),
        "alphaScale": int(style.alpha_scale),
        "alphaMin": int(style.alpha_min),
        "alphaMax": int(style.alpha_max),
        "laneSpreadPx": float(style.lane_spread_px),
        "laneSpreadFrac": float(style.lane_spread_frac),
        "baseEditLaneSpreadPx": float(style.base_edit_lane_spread_px),
        "baseEditLaneSpreadFrac": float(style.base_edit_lane_spread_frac),
        "deltaBpScalePx": float(style.delta_bp_scale_px),
        "deltaBpClampPx": float(style.delta_bp_clamp_px),
        "treeMaxSpreadPx": float(style.tree_max_spread_px),
        "treeLeafJitterPx": float(style.tree_leaf_jitter_px),
        "bundling": dict(style.bundling),
        "ghosts": dict(style.ghosts),
        "baseSheen": dict(style.base_sheen),
        "defaultColorRgb": [int(x) for x in style.default_color_rgb],
        "tagRules": [_style_rule_to_payload(r) for r in style.tag_rules],
    }


def _renderer_to_payload(renderer: Renderer) -> dict[str, Any]:
    out = {"id": str(renderer.id), "version": str(renderer.version)}
    if renderer.shader_sha256 is not None:
        out["shaderSha256"] = str(renderer.shader_sha256)
    return out


def _camera_to_payload(camera: Camera2D) -> dict[str, Any]:
    return {"kind": str(camera.kind), "panPx": [float(camera.pan_px[0]), float(camera.pan_px[1])], "zoom": float(camera.zoom)}


def _projection_to_payload(proj: Projection2D) -> dict[str, Any]:
    return {"kind": str(proj.kind), "phaseDirection": str(proj.phase_direction)}


def _tolerance_to_payload(tol: RenderTolerance) -> dict[str, Any]:
    return {"maxAbsDiff": int(tol.max_abs_diff), "meanAbsDiff": float(tol.mean_abs_diff)}


def _render_golden_to_payload(rg: RenderGolden) -> dict[str, Any]:
    out: dict[str, Any] = {
        "renderer": _renderer_to_payload(rg.renderer),
        "width": int(rg.width),
        "height": int(rg.height),
        "phase": float(rg.phase),
        "seed": int(rg.seed),
        "background": [int(x) for x in rg.background],
        "camera": _camera_to_payload(rg.camera),
        "projection": _projection_to_payload(rg.projection),
        "colorSpace": str(rg.color_space),
        "alphaMode": str(rg.alpha_mode),
        "compositeSpace": str(rg.composite_space),
        "style": _render_style_to_payload(rg.style),
        "settingsSha256": str(rg.settings_sha256),
        "rgbaSha256": str(rg.rgba_sha256),
    }
    if rg.geometry_sha256 is not None:
        out["geometrySha256"] = str(rg.geometry_sha256)
    if rg.tolerance is not None:
        out["tolerance"] = _tolerance_to_payload(rg.tolerance)
    return out


def _outcome_to_payload(oc: Outcome) -> dict[str, Any]:
    out: dict[str, Any] = {
        "id": str(oc.id),
        "probability": float(oc.probability),
        "divergencePhase": float(oc.divergence_phase),
        "alleleOps": [dict(op) for op in oc.allele_ops],
        "mechanismTags": [str(t) for t in oc.mechanism_tags],
    }
    if oc.notes is not None:
        out["notes"] = str(oc.notes)
    return out


def _off_target_to_payload(ot: OffTarget) -> dict[str, Any]:
    return {
        "id": str(ot.id),
        "locus": _locus_to_payload(ot.locus),
        "probabilityMass": float(ot.probability_mass),
        "mismatchSignature": dict(ot.mismatch_signature),
    }


def _builder_provenance_to_payload(bp: BuilderProvenance) -> dict[str, Any]:
    out: dict[str, Any] = {
        "builderId": str(bp.builder_id),
        "seed": int(bp.seed),
        "params": dict(bp.params),
        "referenceWindowSha256": str(bp.reference_window_sha256),
    }
    if bp.builder_version is not None:
        out["builderVersion"] = str(bp.builder_version)
    if bp.notes is not None:
        out["notes"] = str(bp.notes)
    return out


def lightcone_document_to_payload(
    doc: LightconeDocument,
    *,
    render_golden_override: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "specVersion": str(doc.spec_version),
        "id": str(doc.id),
        "locus": _locus_to_payload(doc.locus),
        "editType": str(doc.edit_type),
        "outcomes": [_outcome_to_payload(o) for o in doc.outcomes],
    }
    if doc.reference_window is not None:
        payload["referenceWindow"] = _reference_window_to_payload(doc.reference_window)
    if doc.builder_provenance is not None:
        payload["builderProvenance"] = _builder_provenance_to_payload(doc.builder_provenance)
    if doc.phase_stages:
        payload["phaseModel"] = {"stages": [_phase_stage_to_payload(s) for s in doc.phase_stages]}
    if doc.off_targets:
        payload["offTargets"] = [_off_target_to_payload(ot) for ot in doc.off_targets]
    if render_golden_override is not None:
        payload["renderGolden"] = dict(render_golden_override)
    elif doc.render_golden is not None:
        payload["renderGolden"] = _render_golden_to_payload(doc.render_golden)
    if doc.notes is not None:
        payload["notes"] = str(doc.notes)
    return payload

