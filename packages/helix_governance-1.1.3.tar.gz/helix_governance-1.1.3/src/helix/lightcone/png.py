from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping
import struct
import zlib


PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _chunk(chunk_type: bytes, data: bytes) -> bytes:
    length = struct.pack(">I", len(data))
    crc = zlib.crc32(chunk_type)
    crc = zlib.crc32(data, crc)
    crc_bytes = struct.pack(">I", crc & 0xFFFFFFFF)
    return length + chunk_type + data + crc_bytes


def _text_chunk(keyword: str, text: str) -> bytes:
    key = str(keyword)
    if not (1 <= len(key) <= 79):
        raise ValueError("PNG tEXt keyword must be 1..79 characters")
    if "\x00" in key:
        raise ValueError("PNG tEXt keyword cannot contain NUL")
    key_b = key.encode("latin-1", errors="replace")
    text_b = str(text).encode("latin-1", errors="replace")
    return _chunk(b"tEXt", key_b + b"\x00" + text_b)


def encode_png_rgba8(*, width: int, height: int, rgba: bytes, text: Mapping[str, str] | None = None) -> bytes:
    if width <= 0 or height <= 0:
        raise ValueError("width/height must be positive")
    expected = width * height * 4
    if len(rgba) != expected:
        raise ValueError(f"rgba length {len(rgba)} does not match expected {expected}")

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)

    # Each scanline is prefixed with filter type 0 (None).
    stride = width * 4
    raw_rows = bytearray()
    for y in range(height):
        raw_rows.append(0)
        row = rgba[y * stride : (y + 1) * stride]
        raw_rows.extend(row)

    compressed = zlib.compress(bytes(raw_rows), level=9)

    chunks: list[bytes] = [_chunk(b"IHDR", ihdr)]
    if text:
        for k, v in text.items():
            chunks.append(_text_chunk(str(k), str(v)))
    chunks.append(_chunk(b"IDAT", compressed))
    chunks.append(_chunk(b"IEND", b""))
    return PNG_SIGNATURE + b"".join(chunks)


def write_png_rgba8(path: str | Path, *, width: int, height: int, rgba: bytes, text: Mapping[str, str] | None = None) -> None:
    Path(path).write_bytes(encode_png_rgba8(width=width, height=height, rgba=rgba, text=text))


@dataclass(frozen=True, slots=True)
class DecodedPngRGBA8:
    width: int
    height: int
    rgba: bytes


def decode_png_rgba8(png: bytes) -> DecodedPngRGBA8:
    if not png.startswith(PNG_SIGNATURE):
        raise ValueError("Invalid PNG signature")
    i = len(PNG_SIGNATURE)
    width: int | None = None
    height: int | None = None
    bit_depth: int | None = None
    color_type: int | None = None
    compression: int | None = None
    filter_method: int | None = None
    interlace: int | None = None
    idat = bytearray()

    while i + 8 <= len(png):
        length = struct.unpack(">I", png[i : i + 4])[0]
        ctype = png[i + 4 : i + 8]
        i += 8
        if i + length + 4 > len(png):
            raise ValueError("Truncated PNG chunk")
        data = png[i : i + length]
        i += length
        _crc = png[i : i + 4]
        i += 4

        if ctype == b"IHDR":
            if length != 13:
                raise ValueError("Invalid IHDR length")
            width, height, bit_depth, color_type, compression, filter_method, interlace = struct.unpack(">IIBBBBB", data)
        elif ctype == b"IDAT":
            idat.extend(data)
        elif ctype == b"IEND":
            break
        else:
            continue

    if width is None or height is None:
        raise ValueError("Missing IHDR")
    if bit_depth != 8 or color_type != 6:
        raise ValueError(f"Unsupported PNG format: bit_depth={bit_depth} color_type={color_type}")
    if compression != 0 or filter_method != 0 or interlace != 0:
        raise ValueError("Unsupported PNG compression/filter/interlace")

    raw = zlib.decompress(bytes(idat))
    stride = width * 4
    expected = height * (1 + stride)
    if len(raw) != expected:
        raise ValueError(f"Unexpected decoded size: got={len(raw)} expected={expected}")
    rgba = bytearray(width * height * 4)
    src = 0
    dst = 0
    for _y in range(height):
        filt = raw[src]
        src += 1
        if filt != 0:
            raise ValueError(f"Unsupported PNG filter type: {filt}")
        rgba[dst : dst + stride] = raw[src : src + stride]
        src += stride
        dst += stride
    return DecodedPngRGBA8(width=width, height=height, rgba=bytes(rgba))


def read_png_rgba8(path: str | Path) -> DecodedPngRGBA8:
    return decode_png_rgba8(Path(path).read_bytes())
