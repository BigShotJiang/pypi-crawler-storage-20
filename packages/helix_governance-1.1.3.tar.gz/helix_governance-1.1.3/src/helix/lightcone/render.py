from __future__ import annotations

from dataclasses import dataclass
import json
import hashlib
import math
from typing import Any, Iterable, Mapping, Sequence

from .contract import LightconeDocument, Outcome, PhaseStage, RenderGolden, RenderStyle, StyleRule


LIGHTCONE_RENDERER_ID = "helix.lightcone.cpu_canvas"
LIGHTCONE_RENDERER_VERSION = "v0.1"


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


Color = tuple[int, int, int, int]


def _clamp_int(x: int, lo: int, hi: int) -> int:
    return lo if x < lo else hi if x > hi else x


def _clamp_float(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


@dataclass(slots=True)
class CanvasRGBA8:
    width: int
    height: int
    pixels: bytearray

    @classmethod
    def create(cls, width: int, height: int, *, bg: Color = (8, 10, 18, 255)) -> "CanvasRGBA8":
        if width <= 0 or height <= 0:
            raise ValueError("width/height must be positive")
        pixels = bytearray(width * height * 4)
        r, g, b, a = bg
        for i in range(0, len(pixels), 4):
            pixels[i + 0] = r
            pixels[i + 1] = g
            pixels[i + 2] = b
            pixels[i + 3] = a
        return cls(width=width, height=height, pixels=pixels)

    def _idx(self, x: int, y: int) -> int:
        return (y * self.width + x) * 4

    def blend_pixel(self, x: int, y: int, color: Color) -> None:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return
        sr, sg, sb, sa = color
        if sa <= 0:
            return
        i = self._idx(x, y)
        dr = self.pixels[i + 0]
        dg = self.pixels[i + 1]
        db = self.pixels[i + 2]
        da = self.pixels[i + 3]

        inv = 255 - sa
        # Straight alpha compositing in sRGB8 space (deterministic integer math).
        out_a = sa + (da * inv + 127) // 255
        if out_a <= 0:
            self.pixels[i + 0] = 0
            self.pixels[i + 1] = 0
            self.pixels[i + 2] = 0
            self.pixels[i + 3] = 0
            return
        # Convert src/dst to premultiplied (scaled by 255), composite, then unpremultiply back to straight.
        sr_p = sr * sa
        sg_p = sg * sa
        sb_p = sb * sa
        dr_p = dr * da
        dg_p = dg * da
        db_p = db * da

        out_r_p = sr_p + (dr_p * inv + 127) // 255
        out_g_p = sg_p + (dg_p * inv + 127) // 255
        out_b_p = sb_p + (db_p * inv + 127) // 255

        self.pixels[i + 0] = (out_r_p + out_a // 2) // out_a
        self.pixels[i + 1] = (out_g_p + out_a // 2) // out_a
        self.pixels[i + 2] = (out_b_p + out_a // 2) // out_a
        self.pixels[i + 3] = out_a

    def fill_rect(self, x0: int, y0: int, w: int, h: int, color: Color) -> None:
        if w <= 0 or h <= 0:
            return
        x1 = x0 + w
        y1 = y0 + h
        x0_c = _clamp_int(x0, 0, self.width)
        y0_c = _clamp_int(y0, 0, self.height)
        x1_c = _clamp_int(x1, 0, self.width)
        y1_c = _clamp_int(y1, 0, self.height)
        for y in range(y0_c, y1_c):
            for x in range(x0_c, x1_c):
                self.blend_pixel(x, y, color)

    def fill_disc(self, cx: int, cy: int, r: int, color: Color) -> None:
        if r <= 0:
            self.blend_pixel(cx, cy, color)
            return
        r2 = r * r
        x0 = cx - r
        x1 = cx + r
        y0 = cy - r
        y1 = cy + r
        for y in range(y0, y1 + 1):
            dy = y - cy
            dy2 = dy * dy
            for x in range(x0, x1 + 1):
                dx = x - cx
                if dx * dx + dy2 <= r2:
                    self.blend_pixel(x, y, color)

    def draw_line(self, x0: int, y0: int, x1: int, y1: int, *, color: Color, r: int = 0) -> None:
        dx = x1 - x0
        dy = y1 - y0
        steps = max(abs(dx), abs(dy))
        if steps == 0:
            self.fill_disc(x0, y0, r, color)
            return
        for i in range(steps + 1):
            t = i / steps
            x = int(round(x0 + dx * t))
            y = int(round(y0 + dy * t))
            self.fill_disc(x, y, r, color)

    def draw_polyline(self, pts: Sequence[tuple[int, int]], *, color: Color, r: int = 0) -> None:
        if len(pts) < 2:
            return
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            self.draw_line(x0, y0, x1, y1, color=color, r=r)


def _default_phase_stages() -> tuple[PhaseStage, ...]:
    return (
        PhaseStage("bind", 0.0, 0.15),
        PhaseStage("cut_or_nick", 0.15, 0.3),
        PhaseStage("processing", 0.3, 0.55),
        PhaseStage("synthesis", 0.55, 0.85),
        PhaseStage("ligation", 0.85, 1.0),
    )


def _stage_color(name: str) -> Color:
    # Subtle bands; keep low alpha for deterministic compositing.
    base = {
        "bind": (28, 38, 64, 90),
        "cut_or_nick": (42, 32, 72, 90),
        "processing": (30, 52, 62, 90),
        "synthesis": (52, 46, 26, 90),
        "ligation": (44, 44, 50, 90),
    }.get(name, (32, 32, 40, 80))
    return base


def _tag_color(tags: Iterable[str]) -> tuple[int, int, int]:
    tags_l = {str(t).lower() for t in tags}
    if "intended" in tags_l:
        return (58, 232, 200)
    if "no_cut" in tags_l or "no_edit" in tags_l:
        return (138, 147, 168)
    if "mmej" in tags_l:
        return (242, 106, 128)
    if "indel" in tags_l:
        return (246, 186, 90)
    if "byproduct" in tags_l:
        return (246, 186, 90)
    return (143, 152, 180)


def _style_apply_rules(style: RenderStyle, tags: Iterable[str]) -> tuple[tuple[int, int, int], float, bool]:
    tags_l = {str(t).lower() for t in tags}
    rgb = style.default_color_rgb
    thickness_mul = 1.0
    braid = False
    for rule in style.tag_rules:
        if not _rule_matches(rule, tags_l):
            continue
        if rule.color_rgb is not None:
            rgb = rule.color_rgb
        if rule.thickness_mul is not None:
            thickness_mul *= float(rule.thickness_mul)
        if rule.braid is not None:
            braid = braid or bool(rule.braid)
        # First-match-wins for color; other fields accumulate/mix deterministically.
        break
    return rgb, thickness_mul, braid


def _rule_matches(rule: StyleRule, tags_l: set[str]) -> bool:
    for t in rule.match_any:
        if t in tags_l:
            return True
    return False


def _allele_delta_bp(allele_ops: Sequence[Mapping[str, object]]) -> int:
    ins = 0
    dele = 0
    for op in allele_ops:
        kind = str(op.get("op") or "").lower()
        if kind == "ins":
            seq = str(op.get("seq") or "")
            ins += len(seq)
        elif kind == "del":
            dele += int(op.get("n") or 0)
    return ins - dele


def _substitution_positions(allele_ops: Sequence[Mapping[str, object]]) -> list[int]:
    ref_pos = 0
    out: list[int] = []
    for op in allele_ops:
        kind = str(op.get("op") or "").lower()
        if kind == "match":
            ref_pos += int(op.get("n") or 0)
        elif kind == "del":
            ref_pos += int(op.get("n") or 0)
        elif kind == "ins":
            continue
        elif kind == "sub":
            ref = str(op.get("ref") or "")
            ln = len(ref)
            for j in range(ln):
                out.append(ref_pos + j)
            ref_pos += ln
    return out


def _outcome_sort_key(o: Outcome) -> tuple[float, str]:
    # Higher probability first, deterministic tie-breaker by id.
    return (-float(o.probability), str(o.id))


def _assign_lane_offsets(n: int) -> list[int]:
    # [0, +1, -1, +2, -2, ...]
    out: list[int] = []
    k = 0
    while len(out) < n:
        if k == 0:
            out.append(0)
        else:
            out.append(k)
            if len(out) < n:
                out.append(-k)
        k += 1
    return out[:n]


def _bezier_points(p0: tuple[float, float], p1: tuple[float, float], p2: tuple[float, float], p3: tuple[float, float], steps: int) -> list[tuple[float, float]]:
    pts: list[tuple[float, float]] = []
    for i in range(steps + 1):
        t = i / steps
        u = 1.0 - t
        x = (
            u * u * u * p0[0]
            + 3.0 * u * u * t * p1[0]
            + 3.0 * u * t * t * p2[0]
            + t * t * t * p3[0]
        )
        y = (
            u * u * u * p0[1]
            + 3.0 * u * u * t * p1[1]
            + 3.0 * u * t * t * p2[1]
            + t * t * t * p3[1]
        )
        pts.append((x, y))
    return pts


def render_settings_payload(render: RenderGolden) -> dict[str, Any]:
    style = render.style
    payload: dict[str, Any] = {
        "renderer": {
            "id": render.renderer.id,
            "version": render.renderer.version,
        },
        "width": int(render.width),
        "height": int(render.height),
        "phase": float(render.phase),
        "seed": int(render.seed),
        "background": list(render.background),
        "camera": {
            "kind": render.camera.kind,
            "panPx": [float(render.camera.pan_px[0]), float(render.camera.pan_px[1])],
            "zoom": float(render.camera.zoom),
        },
        "projection": {
            "kind": render.projection.kind,
            "phaseDirection": render.projection.phase_direction,
        },
        "colorSpace": render.color_space,
        "alphaMode": render.alpha_mode,
        "compositeSpace": render.composite_space,
        "style": {
            "version": style.version,
            "layoutMode": style.layout_mode,
            "margins": {
                "left": int(style.margins[0]),
                "right": int(style.margins[1]),
                "top": int(style.margins[2]),
                "bottom": int(style.margins[3]),
            },
            "trunkColor": list(style.trunk_color),
            "trunkRadiusPx": int(style.trunk_radius_px),
            "branchRadiusPx": int(style.branch_radius_px),
            "tipRadiusPx": int(style.tip_radius_px),
            "tipAlphaBoost": int(style.tip_alpha_boost),
            "alphaBase": int(style.alpha_base),
            "alphaScale": int(style.alpha_scale),
            "alphaMin": int(style.alpha_min),
            "alphaMax": int(style.alpha_max),
            "laneSpreadPx": float(style.lane_spread_px),
            "laneSpreadFrac": float(style.lane_spread_frac),
            "baseEditLaneSpreadPx": float(style.base_edit_lane_spread_px),
            "baseEditLaneSpreadFrac": float(style.base_edit_lane_spread_frac),
            "deltaBpScalePx": float(style.delta_bp_scale_px),
            "deltaBpClampPx": float(style.delta_bp_clamp_px),
            "treeMaxSpreadPx": float(style.tree_max_spread_px),
            "treeLeafJitterPx": float(style.tree_leaf_jitter_px),
            "bundling": dict(style.bundling),
            "ghosts": dict(style.ghosts),
            "baseSheen": dict(style.base_sheen),
            "defaultColorRgb": list(style.default_color_rgb),
            "tagRules": [
                {
                    "matchAny": list(rule.match_any),
                    **({"colorRgb": list(rule.color_rgb)} if rule.color_rgb is not None else {}),
                    **({"thicknessMul": float(rule.thickness_mul)} if rule.thickness_mul is not None else {}),
                    **({"braid": bool(rule.braid)} if rule.braid is not None else {}),
                }
                for rule in style.tag_rules
            ],
        },
    }
    if render.renderer.shader_sha256 is not None:
        payload["renderer"]["shaderSha256"] = render.renderer.shader_sha256
    return payload


def render_settings_sha256(render: RenderGolden) -> str:
    raw = json.dumps(render_settings_payload(render), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return sha256_hex(raw)


def render_lightcone_rgba_from_golden(doc: LightconeDocument) -> bytes:
    rg = doc.render_golden
    if rg is None:
        raise ValueError("Lightcone document missing renderGolden")
    if rg.color_space != "srgb8":
        raise ValueError(f"Unsupported renderGolden.colorSpace: {rg.color_space!r}")
    if rg.alpha_mode != "straight":
        raise ValueError(f"Unsupported renderGolden.alphaMode: {rg.alpha_mode!r}")
    if rg.composite_space != "srgb":
        raise ValueError(f"Unsupported renderGolden.compositeSpace: {rg.composite_space!r}")
    if rg.camera.kind != "lightcone2d":
        raise ValueError(f"Unsupported renderGolden.camera.kind: {rg.camera.kind!r}")
    if rg.projection.kind != "pixel_ortho" or rg.projection.phase_direction != "up":
        raise ValueError(f"Unsupported renderGolden.projection: kind={rg.projection.kind!r} phaseDirection={rg.projection.phase_direction!r}")
    if rg.style.version != "v0.1":
        raise ValueError(f"Unsupported renderGolden.style.version: {rg.style.version!r}")
    if rg.style.layout_mode not in {"lanes_v0", "tree_v1"}:
        raise ValueError(f"Unsupported renderGolden.style.layoutMode: {rg.style.layout_mode!r}")

    return render_lightcone_rgba(
        doc,
        width=rg.width,
        height=rg.height,
        phase=rg.phase,
        background=rg.background,
        camera_pan_px=rg.camera.pan_px,
        camera_zoom=rg.camera.zoom,
    )


def _camera_transform_px(
    x: float,
    y: float,
    *,
    width: int,
    height: int,
    pan_px: tuple[float, float],
    zoom: float,
) -> tuple[float, float]:
    cx = width * 0.5
    cy = height * 0.5
    x2 = (x - cx) * zoom + cx + pan_px[0]
    y2 = (y - cy) * zoom + cy + pan_px[1]
    return x2, y2


def _scale_radius(r: int, zoom: float) -> int:
    if r <= 0:
        return 0
    return max(0, int(round(r * zoom)))


def render_lightcone_rgba(
    doc: LightconeDocument,
    *,
    width: int,
    height: int,
    phase: float = 1.0,
    background: Color = (8, 10, 18, 255),
    camera_pan_px: tuple[float, float] = (0.0, 0.0),
    camera_zoom: float = 1.0,
) -> bytes:
    style = doc.render_golden.style if doc.render_golden is not None else None
    phase = _clamp_float(float(phase), 0.0, 1.0)
    camera_zoom = float(camera_zoom)
    if camera_zoom <= 0.0:
        raise ValueError("camera_zoom must be positive")

    if style is None:
        raise ValueError("render_lightcone_rgba requires doc.render_golden.style (fixtures must be explicit)")

    canvas = CanvasRGBA8.create(width, height, bg=background)

    # Layout in image coordinates (y grows downward).
    margin_l, margin_r, margin_t, margin_b = style.margins
    x_center = width // 2
    y_top = margin_t
    y_bottom = height - margin_b
    axis_h = max(1, y_bottom - y_top)

    def y_of_phase(p: float) -> float:
        return y_bottom - _clamp_float(p, 0.0, 1.0) * axis_h

    # Stage bands
    stages = doc.phase_stages or _default_phase_stages()
    for st in stages:
        y0 = int(round(y_of_phase(st.end)))
        y1 = int(round(y_of_phase(st.start)))
        if y1 <= y0:
            continue
        x0_t, y0_t = _camera_transform_px(0.0, float(y0), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        x1_t, y1_t = _camera_transform_px(float(width), float(y1), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        x_min = int(round(min(x0_t, x1_t)))
        x_max = int(round(max(x0_t, x1_t)))
        y_min = int(round(min(y0_t, y1_t)))
        y_max = int(round(max(y0_t, y1_t)))
        canvas.fill_rect(x_min, y_min, x_max - x_min, y_max - y_min, _stage_color(st.name))

    outcomes = sorted(doc.outcomes, key=_outcome_sort_key)

    if style.layout_mode == "tree_v1":
        # Milestone 2+ path: compiled branch tree geometry (implemented in helix.lightcone.geometry).
        from .geometry import compile_lightcone_geometry, draw_compiled_geometry

        geom = compile_lightcone_geometry(doc, width=width, height=height, phase=phase, camera_pan_px=camera_pan_px, camera_zoom=camera_zoom)
        # Trunk up to current phase (kept separate so stage bands remain readable).
        y_end = y_of_phase(phase)
        trunk_color: Color = style.trunk_color
        x0_t, y0_t = _camera_transform_px(float(x_center), float(y_bottom), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        x1_t, y1_t = _camera_transform_px(float(x_center), float(y_end), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        canvas.draw_line(
            int(round(x0_t)),
            int(round(y0_t)),
            int(round(x1_t)),
            int(round(y1_t)),
            color=trunk_color,
            r=_scale_radius(int(style.trunk_radius_px), camera_zoom),
        )
        draw_compiled_geometry(canvas, geom, phase=phase, tip_radius_px=int(style.tip_radius_px), tip_alpha_boost=int(style.tip_alpha_boost))
    else:
        # Main trunk up to current phase.
        y_end = y_of_phase(phase)
        trunk_color: Color = style.trunk_color
        x0_t, y0_t = _camera_transform_px(float(x_center), float(y_bottom), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        x1_t, y1_t = _camera_transform_px(float(x_center), float(y_end), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        canvas.draw_line(
            int(round(x0_t)),
            int(round(y0_t)),
            int(round(x1_t)),
            int(round(y1_t)),
            color=trunk_color,
            r=_scale_radius(int(style.trunk_radius_px), camera_zoom),
        )

        # Outcome branches.
        lane_offsets = _assign_lane_offsets(len(outcomes))
        max_lane = max(1, max(abs(i) for i in lane_offsets))
        usable_w = max(1, width - margin_l - margin_r)
        if doc.edit_type == "base_edit":
            # Keep base-edit filaments tight; base edits should read as a localized phase shift, not an explosion.
            total_spread = min(float(style.base_edit_lane_spread_px), usable_w * float(style.base_edit_lane_spread_frac))
            lane_dx = total_spread / max_lane
        else:
            lane_dx = min(float(style.lane_spread_px), (usable_w * float(style.lane_spread_frac)) / max_lane)

        max_prob = max(1e-9, max(float(o.probability) for o in outcomes))

        for outcome, lane in zip(outcomes, lane_offsets):
            div = _clamp_float(float(outcome.divergence_phase), 0.0, 1.0)
            if phase <= div:
                continue

            y_div = y_of_phase(div)
            y_tip = y_end
            # Spread branches by lane + small extra offset from delta bp (net indel).
            delta_bp = _allele_delta_bp(outcome.allele_ops)
            x_tip = x_center + lane_dx * lane + _clamp_float(delta_bp * float(style.delta_bp_scale_px), -float(style.delta_bp_clamp_px), float(style.delta_bp_clamp_px))
            x_tip = _clamp_float(x_tip, float(margin_l), float(width - margin_r))

            # Smooth curve.
            mid_y = (y_div + y_tip) * 0.5
            p0 = (float(x_center), float(y_div))
            p3 = (float(x_tip), float(y_tip))
            p1 = (float(x_center), float(mid_y))
            p2 = (float(x_tip), float(mid_y))
            pts_f = _bezier_points(p0, p1, p2, p3, steps=36)
            pts: list[tuple[int, int]] = []
            for x, y in pts_f:
                x_t, y_t = _camera_transform_px(x, y, width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
                pts.append((int(round(x_t)), int(round(y_t))))

            (base_r, base_g, base_b), thickness_mul, braid = _style_apply_rules(style, outcome.mechanism_tags)
            intensity = math.sqrt(max(0.0, float(outcome.probability)) / max_prob)
            alpha = int(round(int(style.alpha_base) + int(style.alpha_scale) * intensity))
            alpha = _clamp_int(alpha, int(style.alpha_min), int(style.alpha_max))
            color: Color = (base_r, base_g, base_b, alpha)

            r_px = _scale_radius(max(0, int(round(float(style.branch_radius_px) * thickness_mul))), camera_zoom)
            if doc.edit_type == "prime_edit" and braid:
                _draw_braid(canvas, pts, color=color, r=r_px)
            else:
                canvas.draw_polyline(pts, color=color, r=r_px)
            # Tip glow dot.
            x_tip_t, y_tip_t = _camera_transform_px(float(x_tip), float(y_tip), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
            canvas.fill_disc(
                int(round(x_tip_t)),
                int(round(y_tip_t)),
                _scale_radius(int(style.tip_radius_px), camera_zoom),
                (base_r, base_g, base_b, _clamp_int(alpha + int(style.tip_alpha_boost), 0, 255)),
            )

    # Ghost cones for off-target loci.
    ghosts_cfg = style.ghosts
    if doc.off_targets and bool(ghosts_cfg.get("enabled", True)):
        ghosts = list(doc.off_targets)
        # Deterministic ordering: strongest mass first then id.
        ghosts.sort(key=lambda g: (-float(g.probability_mass), str(g.id)))
        total_mass = sum(float(g.probability_mass) for g in ghosts) or 1.0
        # Place ghosts along the top margin, outside the main cone.
        gx0 = margin_l
        gx1 = width - margin_r
        for idx, ghost in enumerate(ghosts):
            if len(ghosts) == 1:
                t = 0.5
            else:
                t = idx / (len(ghosts) - 1)
            gx = int(round(gx0 + t * (gx1 - gx0)))
            gy = int(round(y_of_phase(0.05)))
            mass = float(ghost.probability_mass) / total_mass
            alpha_scale = int(ghosts_cfg.get("alphaScalePrime" if doc.edit_type == "prime_edit" else "alphaScale", 140))
            alpha_base = int(ghosts_cfg.get("alphaBase", 35))
            alpha_min = int(ghosts_cfg.get("alphaMin", 18))
            alpha_max = int(ghosts_cfg.get("alphaMax", 200))
            alpha = _clamp_int(int(round(alpha_base + alpha_scale * math.sqrt(mass))), alpha_min, alpha_max)
            c = (int(ghosts_cfg.get("colorR", 160)), int(ghosts_cfg.get("colorG", 120)), int(ghosts_cfg.get("colorB", 255)), alpha)
            gx_t, gy_t = _camera_transform_px(float(gx), float(gy), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
            radius = int(ghosts_cfg.get("radiusPrime" if doc.edit_type == "prime_edit" else "radius", 5))
            canvas.fill_disc(int(round(gx_t)), int(round(gy_t)), _scale_radius(radius, camera_zoom), c)
            # Thread line back to trunk.
            x2_t, y2_t = _camera_transform_px(float(x_center), float(y_of_phase(0.12)), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
            canvas.draw_line(
                int(round(gx_t)),
                int(round(gy_t)),
                int(round(x2_t)),
                int(round(y2_t)),
                color=(c[0], c[1], c[2], alpha // int(ghosts_cfg.get("threadAlphaDiv", 2))),
                r=0,
            )
            if bool(ghosts_cfg.get("mismatchThreadsEnabled", False)):
                _draw_mismatch_pulses(
                    canvas,
                    gx=int(round(gx_t)),
                    gy=int(round(gy_t)),
                    tx=int(round(x2_t)),
                    ty=int(round(y2_t)),
                    mismatch_signature=ghost.mismatch_signature,
                    color=(c[0], c[1], c[2], alpha),
                    radius=_scale_radius(int(ghosts_cfg.get("mismatchPulseRadius", 2)), camera_zoom),
                )

    # Base-edit sheen: encode per-position edited probability mass as glow on the trunk.
    base_sheen_cfg = style.base_sheen
    if (
        doc.edit_type == "base_edit"
        and doc.reference_window
        and doc.reference_window.sequence
        and bool(base_sheen_cfg.get("enabled", True))
    ):
        ref_len = len(doc.reference_window.sequence)
        if ref_len > 0:
            mass_by_pos = [0.0 for _ in range(ref_len)]
            for oc in outcomes:
                for pos in _substitution_positions(oc.allele_ops):  # type: ignore[arg-type]
                    if 0 <= pos < ref_len:
                        mass_by_pos[pos] += float(oc.probability)
            peak_mass = max(mass_by_pos) if mass_by_pos else 0.0
            if peak_mass > 1e-9:
                # Pick sheen color based on editor kind tags, defaulting to neutral teal.
                tags = {t.lower() for o in outcomes for t in o.mechanism_tags}
                if "cbe" in tags:
                    sheen_rgb = tuple(int(x) for x in (base_sheen_cfg.get("cbeRgb") or (110, 180, 255)))
                elif "abe" in tags:
                    sheen_rgb = tuple(int(x) for x in (base_sheen_cfg.get("abeRgb") or (170, 255, 150)))
                else:
                    sheen_rgb = tuple(int(x) for x in (base_sheen_cfg.get("defaultRgb") or (120, 220, 210)))

                y_center = y_of_phase(float(base_sheen_cfg.get("phaseCenter", 0.72)))
                sheen_h = min(float(base_sheen_cfg.get("spanPx", 80.0)), axis_h * float(base_sheen_cfg.get("phaseSpan", 0.28)))
                for pos, mass in enumerate(mass_by_pos):
                    if mass <= 0.0:
                        continue
                    t = 0.0 if ref_len <= 1 else (pos / (ref_len - 1) - 0.5)
                    y = y_center + t * sheen_h
                    alpha = _clamp_int(
                        int(round(int(base_sheen_cfg.get("alphaBase", 18)) + int(base_sheen_cfg.get("alphaScale", 210)) * (mass / peak_mass) ** 0.5)),
                        0,
                        255,
                    )
                    x_t, y_t = _camera_transform_px(float(x_center), float(y), width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
                    canvas.fill_disc(
                        int(round(x_t)),
                        int(round(y_t)),
                        _scale_radius(int(base_sheen_cfg.get("radiusPx", 3)), camera_zoom),
                        (int(sheen_rgb[0]), int(sheen_rgb[1]), int(sheen_rgb[2]), alpha),
                    )

    return bytes(canvas.pixels)


def _draw_braid(canvas: CanvasRGBA8, pts: Sequence[tuple[int, int]], *, color: Color, r: int) -> None:
    if len(pts) < 2:
        return
    # Simple braided signature: two close strands with alternating lateral offset.
    offset = max(1, r + 1)
    strand_a: list[tuple[int, int]] = []
    strand_b: list[tuple[int, int]] = []
    for i, (x, y) in enumerate(pts):
        sign = 1 if (i // 4) % 2 == 0 else -1
        strand_a.append((x + sign * offset, y))
        strand_b.append((x - sign * offset, y))
    canvas.draw_polyline(strand_a, color=color, r=r)
    canvas.draw_polyline(strand_b, color=color, r=r)


def _draw_mismatch_pulses(
    canvas: CanvasRGBA8,
    *,
    gx: int,
    gy: int,
    tx: int,
    ty: int,
    mismatch_signature: Mapping[str, Any],
    color: Color,
    radius: int,
) -> None:
    mismatches = mismatch_signature.get("mismatches") or []
    if not isinstance(mismatches, Sequence) or isinstance(mismatches, (str, bytes, bytearray)):
        return
    # Deterministic mapping: place pulses along the thread by sorted mismatch index.
    idxs: list[int] = []
    for m in mismatches:
        if not isinstance(m, Mapping):
            continue
        try:
            idxs.append(int(m.get("index") or 0))
        except Exception:
            continue
    if not idxs:
        return
    idxs.sort()
    max_idx = max(idxs) or 1
    # Draw small discs along the line, where earlier mismatches are closer to the trunk.
    for i in idxs:
        t = 0.15 + 0.7 * (i / max_idx)
        x = int(round(tx + (gx - tx) * t))
        y = int(round(ty + (gy - ty) * t))
        canvas.fill_disc(x, y, radius, (color[0], color[1], color[2], _clamp_int(color[3] // 2 + 10, 0, 255)))
