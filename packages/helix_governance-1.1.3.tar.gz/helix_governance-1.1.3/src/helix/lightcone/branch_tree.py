from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Sequence

from .allele_ops import AlleleOp, DelOp, InsOp, MatchOp, SubOp, allele_ops_from_payload, canonicalize_allele_ops
from .contract import Outcome


def _op_key(op: AlleleOp) -> tuple:
    if isinstance(op, MatchOp):
        return ("match", int(op.n))
    if isinstance(op, DelOp):
        return ("del", int(op.n))
    if isinstance(op, InsOp):
        return ("ins", str(op.seq))
    if isinstance(op, SubOp):
        return ("sub", str(op.ref), str(op.alt))
    return ("unknown", str(op))


def _split_op(op: AlleleOp, ref_len: int) -> tuple[AlleleOp, AlleleOp | None]:
    """Split an op into (prefix consuming ref_len, suffix)."""

    if isinstance(op, MatchOp):
        if ref_len <= 0 or ref_len >= op.n:
            raise ValueError("Invalid split length for match")
        return MatchOp(ref_len), MatchOp(op.n - ref_len)
    if isinstance(op, DelOp):
        if ref_len <= 0 or ref_len >= op.n:
            raise ValueError("Invalid split length for del")
        return DelOp(ref_len), DelOp(op.n - ref_len)
    if isinstance(op, SubOp):
        # Only splittable if alt/ref are aligned (same length).
        if len(op.ref) != len(op.alt):
            raise ValueError("Cannot split sub op when len(ref) != len(alt)")
        if ref_len <= 0 or ref_len >= len(op.ref):
            raise ValueError("Invalid split length for sub")
        return (
            SubOp(op.ref[:ref_len], op.alt[:ref_len]),
            SubOp(op.ref[ref_len:], op.alt[ref_len:]),
        )
    if isinstance(op, InsOp):
        raise ValueError("Cannot split ins op by ref length (ref_len=0)")
    raise TypeError(f"Unsupported op type: {type(op)!r}")


def _common_prefix_ref_len(a: AlleleOp, b: AlleleOp) -> int:
    """Return the common prefix length in reference bases (0 means no common prefix)."""

    if type(a) is not type(b):
        return 0
    if isinstance(a, MatchOp) and isinstance(b, MatchOp):
        return min(int(a.n), int(b.n))
    if isinstance(a, DelOp) and isinstance(b, DelOp):
        return min(int(a.n), int(b.n))
    if isinstance(a, InsOp) and isinstance(b, InsOp):
        # ins consumes 0 ref; only exact matching matters (handled separately).
        return 0
    if isinstance(a, SubOp) and isinstance(b, SubOp):
        if a.ref == b.ref and a.alt == b.alt:
            return len(a.ref)
        if len(a.ref) == len(a.alt) == len(b.ref) == len(b.alt):
            # Allow partial split when both substitutions are aligned.
            k = 0
            for ra, aa, rb, ab in zip(a.ref, a.alt, b.ref, b.alt):
                if ra == rb and aa == ab:
                    k += 1
                else:
                    break
            return k
        return 0
    return 0


@dataclass(slots=True)
class BranchEdge:
    op: AlleleOp
    child: "BranchNode"
    probability_mass: float = 0.0


@dataclass(slots=True)
class BranchNode:
    edges: list[BranchEdge] = field(default_factory=list)
    leaves: list[tuple[str, float]] = field(default_factory=list)  # (outcome_id, probability)
    probability_mass: float = 0.0

    def sort_recursive(self) -> None:
        self.edges.sort(key=lambda e: _op_key(e.op))
        for e in self.edges:
            e.child.sort_recursive()


def build_branch_tree(outcomes: Sequence[Outcome]) -> BranchNode:
    """Build a deterministic branch tree from alleleOps.

    Determinism strategy:
    - Canonicalize each outcome's `alleleOps`.
    - Insert outcomes in stable order by outcome id.
    - Sort edges by a stable op key after construction.
    """

    root = BranchNode()
    ordered = sorted(outcomes, key=lambda o: str(o.id))
    for oc in ordered:
        ops = allele_ops_from_payload(oc.allele_ops)
        script = canonicalize_allele_ops(ops)
        _insert_script(root, script, outcome_id=str(oc.id), probability=float(oc.probability))
    _compute_mass(root)
    root.sort_recursive()
    return root


def collect_subtree_leaves(node: BranchNode) -> tuple[tuple[str, float], ...]:
    """Return all (outcome_id, probability) leaves under `node` (stable order)."""

    items: list[tuple[str, float]] = []
    _collect_leaves(node, items)
    items.sort(key=lambda t: t[0])
    return tuple(items)


def _collect_leaves(node: BranchNode, out: list[tuple[str, float]]) -> None:
    out.extend((str(oid), float(p)) for oid, p in node.leaves)
    for e in node.edges:
        _collect_leaves(e.child, out)


def _find_edge(node: BranchNode, op: AlleleOp) -> BranchEdge | None:
    for e in node.edges:
        if e.op == op:
            return e
    return None


def _insert_script(node: BranchNode, script: Sequence[AlleleOp], *, outcome_id: str, probability: float) -> None:
    cur = node
    ops = list(script)
    idx = 0
    while idx < len(ops):
        op = ops[idx]
        edge = _find_edge(cur, op)
        if edge is not None:
            cur = edge.child
            idx += 1
            continue

        # Find best partial match (max prefix length, stable tie-break).
        best: BranchEdge | None = None
        best_k = 0
        for e in cur.edges:
            k = _common_prefix_ref_len(e.op, op)
            if k <= 0:
                continue
            if k > best_k:
                best = e
                best_k = k
            elif k == best_k and best is not None and _op_key(e.op) < _op_key(best.op):
                best = e
        if best is None:
            child = BranchNode()
            cur.edges.append(BranchEdge(op=op, child=child))
            cur = child
            idx += 1
            continue

        existing = best.op
        existing_len = _ref_len(existing)
        op_len = _ref_len(op)
        k = min(best_k, existing_len, op_len)
        if k <= 0:
            child = BranchNode()
            cur.edges.append(BranchEdge(op=op, child=child))
            cur = child
            idx += 1
            continue

        existing_prefix, existing_suffix = (existing, None)
        if k < existing_len:
            existing_prefix, existing_suffix = _split_op(existing, k)
        op_prefix, op_suffix = (op, None)
        if k < op_len:
            op_prefix, op_suffix = _split_op(op, k)

        if existing_prefix != op_prefix:
            # Defensive: if we can't reconcile prefixes, treat as divergent at this node.
            child = BranchNode()
            cur.edges.append(BranchEdge(op=op, child=child))
            cur = child
            idx += 1
            continue

        # Ensure the shared prefix edge exists and traverse it.
        if k < existing_len:
            # Split existing edge into prefix -> mid -> suffix.
            mid = BranchNode()
            old_child = best.child
            best.op = existing_prefix
            best.child = mid
            if existing_suffix is not None:
                mid.edges.append(BranchEdge(op=existing_suffix, child=old_child))
            cur = mid
        else:
            # Existing edge is exactly the shared prefix.
            cur = best.child

        # Continue with any remaining suffix of the current op at the new node.
        if op_suffix is None:
            idx += 1
        else:
            ops[idx] = op_suffix

    cur.leaves.append((outcome_id, probability))


def _ref_len(op: AlleleOp) -> int:
    if isinstance(op, (MatchOp, DelOp)):
        return int(op.n)
    if isinstance(op, SubOp):
        return len(op.ref)
    if isinstance(op, InsOp):
        return 0
    raise TypeError(f"Unsupported op type: {type(op)!r}")


def _compute_mass(node: BranchNode) -> float:
    leaf_mass = sum(p for _, p in node.leaves)
    child_mass = 0.0
    for e in node.edges:
        m = _compute_mass(e.child)
        e.probability_mass = m
        child_mass += m
    node.probability_mass = leaf_mass + child_mass
    return node.probability_mass
