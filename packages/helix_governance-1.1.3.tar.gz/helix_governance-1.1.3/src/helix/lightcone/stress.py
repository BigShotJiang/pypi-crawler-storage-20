from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Mapping

from .allele_ops import InsOp
from .branch_tree import BranchEdge, BranchNode


STRESS_TREE_BUILDER_ID = "helix.lightcone.stress_tree_v0"


@dataclass(frozen=True, slots=True)
class StressTreeParams:
    seed: int
    depth: int
    branching_factor: int
    trunk_length: float
    segments_per_edge: int
    fog_tail_size: int
    ghosts_count: int

    @classmethod
    def from_builder_params(cls, *, seed: int, params: Mapping[str, Any]) -> "StressTreeParams":
        def _int(key: str, default: int) -> int:
            v = params.get(key, default)
            try:
                return int(v)
            except Exception:
                return int(default)

        def _float(key: str, default: float) -> float:
            v = params.get(key, default)
            try:
                return float(v)
            except Exception:
                return float(default)

        depth = max(1, _int("depth", _int("treeDepth", 7)))
        branching_factor = max(1, _int("branchingFactor", _int("branching_factor", 3)))
        trunk_length = _float("trunkLength", _float("trunk_length", 0.16))
        trunk_length = 0.0 if trunk_length < 0.0 else 1.0 if trunk_length > 1.0 else trunk_length
        segments_per_edge = max(4, _int("segmentsPerEdge", _int("segments_per_edge", 32)))
        fog_tail_size = max(0, _int("fogTailSize", _int("fog_tail_size", 0)))
        ghosts_count = max(0, _int("ghostsCount", _int("ghosts_count", 0)))
        return cls(
            seed=int(seed),
            depth=depth,
            branching_factor=branching_factor,
            trunk_length=trunk_length,
            segments_per_edge=segments_per_edge,
            fog_tail_size=fog_tail_size,
            ghosts_count=ghosts_count,
        )


def build_stress_tree(params: StressTreeParams) -> BranchNode:
    """Build a deterministic, controlled branch tree without biology builders.

    This is used for perf/stress fixtures: we generate topology directly, then reuse the existing
    deterministic geometry compilation/picking pipeline.
    """

    depth = int(params.depth)
    bf = int(params.branching_factor)
    fog = int(params.fog_tail_size)

    # Allocate a small probability tail to fog branches at the root (wide + low mass).
    fog_mass_total = 0.0 if fog <= 0 else 0.12
    main_mass = max(0.0, 1.0 - fog_mass_total)

    leaf_counter = [0]

    def dominant_index(path: tuple[int, ...], n: int) -> int:
        if n <= 1:
            return 0
        blob = (str(params.seed) + ":" + ",".join(str(x) for x in path)).encode("utf-8")
        h = hashlib.sha256(blob).digest()
        return int.from_bytes(h[:4], "big") % int(n)

    def split_mass(mass: float, n: int, *, dominant: int) -> list[float]:
        if n <= 0:
            return []
        if n == 1:
            return [float(mass)]
        lead = float(mass) * 0.55
        rest = float(mass) - lead
        each = rest / float(n - 1) if n > 1 else 0.0
        out = [each] * n
        out[int(dominant) % n] = lead
        return out

    def make_leaf_node(*, mass: float) -> BranchNode:
        node = BranchNode()
        leaf_id = f"leaf_{leaf_counter[0]:06d}"
        leaf_counter[0] += 1
        node.leaves.append((leaf_id, float(mass)))
        node.probability_mass = float(mass)
        return node

    def build_subtree(*, remaining_depth: int, mass: float, path: tuple[int, ...]) -> BranchNode:
        if remaining_depth <= 0:
            return make_leaf_node(mass=float(mass))
        node = BranchNode()
        shares = split_mass(float(mass), bf, dominant=dominant_index(path, bf))
        for child_idx, child_mass in enumerate(shares):
            child = build_subtree(remaining_depth=remaining_depth - 1, mass=float(child_mass), path=path + (child_idx,))
            edge = BranchEdge(op=InsOp(seq=f"d{remaining_depth:02d}_b{child_idx:02d}"), child=child, probability_mass=float(child.probability_mass))
            node.edges.append(edge)
        node.probability_mass = float(sum(float(e.probability_mass) for e in node.edges))
        return node

    root = BranchNode()

    # Main subtree edges.
    shares = split_mass(main_mass, bf, dominant=dominant_index((), bf))
    for child_idx, child_mass in enumerate(shares):
        child = build_subtree(remaining_depth=depth - 1, mass=float(child_mass), path=(child_idx,))
        root.edges.append(BranchEdge(op=InsOp(seq=f"main_{child_idx:02d}"), child=child, probability_mass=float(child.probability_mass)))

    # Fog tail: shallow leaves at the root.
    if fog > 0 and fog_mass_total > 0.0:
        each = fog_mass_total / float(fog)
        for i in range(fog):
            child = make_leaf_node(mass=float(each))
            root.edges.append(BranchEdge(op=InsOp(seq=f"fog_{i:05d}"), child=child, probability_mass=float(child.probability_mass)))

    root.probability_mass = float(sum(float(e.probability_mass) for e in root.edges))
    return root
