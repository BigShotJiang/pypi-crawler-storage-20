from __future__ import annotations

from dataclasses import dataclass
import math

from helix.lightcone.allele_ops import DelOp, InsOp, MatchOp, SubOp, allele_ops_to_payload, canonicalize_allele_ops
from helix.lightcone.contract import LightconeDocument, Outcome
from helix.lightcone.outcomes import canonicalize_outcomes
from helix.rng import Rng


@dataclass(frozen=True, slots=True)
class PrimeV0Params:
    intended_weight: float = 0.55
    no_edit_weight: float = 0.12
    byproduct_base_weight: float = 0.18
    indel_weight: float = 0.12
    divergence_phase: float = 0.62


class PrimeOutcomeBuilderV0:
    """Toy prime-edit outcome builder (v0).

    v0 goal: deterministic intended path + a few common-looking byproducts.
    """

    def __init__(self, params: PrimeV0Params | None = None) -> None:
        self.params = params or PrimeV0Params()

    def build_from_document(self, doc: LightconeDocument, *, seed: int, rtt: str) -> tuple[Outcome, ...]:
        if doc.edit_type != "prime_edit":
            raise ValueError(f"Expected editType=prime_edit (got {doc.edit_type!r})")
        if doc.reference_window is None or not doc.reference_window.sequence:
            raise ValueError("PrimeOutcomeBuilderV0 requires referenceWindow.sequence")
        ref = doc.reference_window.sequence.upper()
        nick_index = int(doc.locus.position) - int(doc.locus.window_start)
        return self.build(ref, nick_index=nick_index, rtt=rtt, seed=seed)

    def build(self, reference: str, *, nick_index: int, rtt: str, seed: int) -> tuple[Outcome, ...]:
        ref = str(reference).upper()
        n = len(ref)
        if n <= 0:
            raise ValueError("reference must be non-empty")
        if nick_index < 0 or nick_index > n:
            raise ValueError(f"nick_index must be in [0,{n}] (got {nick_index})")
        rtt_u = str(rtt).upper().strip()
        if not rtt_u:
            raise ValueError("rtt must be non-empty")

        p = self.params
        rng = Rng(int(seed), stream_id=f"lightcone:prime_v0:mutations_v1:seed={int(seed)}")
        outcomes: list[Outcome] = []

        # Intended: full RTT incorporation (modeled as an insertion at the nick site).
        intended_ops = canonicalize_allele_ops((MatchOp(nick_index), InsOp(rtt_u), MatchOp(n - nick_index)))
        outcomes.append(
            Outcome(
                id="intended",
                probability=float(p.intended_weight),
                divergence_phase=float(p.divergence_phase),
                allele_ops=allele_ops_to_payload(intended_ops),
                mechanism_tags=("intended", "prime_flap", "rt_synthesis"),
                notes="Intended RTT incorporation (v0 insertion model).",
            )
        )

        # Byproducts: partial RTT (abortive RT).
        for frac in (0.5, 0.33):
            k = max(1, int(round(len(rtt_u) * frac)))
            seq = rtt_u[:k]
            ops = canonicalize_allele_ops((MatchOp(nick_index), InsOp(seq), MatchOp(n - nick_index)))
            weight = float(p.byproduct_base_weight) * math.exp(-k / max(1.0, len(rtt_u) / 2.0))
            outcomes.append(
                Outcome(
                    id=f"partial_rtt_{k}",
                    probability=float(weight),
                    divergence_phase=max(0.0, float(p.divergence_phase) - 0.12),
                    allele_ops=allele_ops_to_payload(ops),
                    mechanism_tags=("byproduct", "rt_abort"),
                    notes=f"Partial RTT incorporation ({k} nt).",
                )
            )

        # Indels at/near nick.
        for del_size in (1, 2, 5):
            start = max(0, min(nick_index, n - del_size))
            ops = canonicalize_allele_ops((MatchOp(start), DelOp(del_size), MatchOp(n - (start + del_size))))
            weight = float(p.indel_weight) * math.exp(-del_size / 2.0)
            outcomes.append(
                Outcome(
                    id=f"nick_del_{del_size}",
                    probability=float(weight),
                    divergence_phase=max(0.0, float(p.divergence_phase) - 0.25),
                    allele_ops=allele_ops_to_payload(ops),
                    mechanism_tags=("indel", "nhej"),
                    notes=f"Deletion of {del_size} bp near nick site.",
                )
            )

        # Low-probability substitution cluster near nick.
        if nick_index + 2 < n:
            ref_base = ref[nick_index + 2]
            alt_base = rng.choice([b for b in "ACGT" if b != ref_base])
            ops = canonicalize_allele_ops(
                (
                    MatchOp(nick_index + 2),
                    SubOp(ref_base, alt_base),
                    MatchOp(n - (nick_index + 3)),
                )
            )
            outcomes.append(
                Outcome(
                    id="sub_cluster_1",
                    probability=0.03,
                    divergence_phase=float(p.divergence_phase),
                    allele_ops=allele_ops_to_payload(ops),
                    mechanism_tags=("byproduct", "substitutions"),
                    notes="Single-base substitution near nick (v0).",
                )
            )

        # No-edit.
        outcomes.append(
            Outcome(
                id="no_edit",
                probability=float(p.no_edit_weight),
                divergence_phase=0.22,
                allele_ops=allele_ops_to_payload((MatchOp(n),)),
                mechanism_tags=("no_edit", "no_cut"),
                notes="Binding without productive editing.",
            )
        )

        return canonicalize_outcomes(outcomes)
