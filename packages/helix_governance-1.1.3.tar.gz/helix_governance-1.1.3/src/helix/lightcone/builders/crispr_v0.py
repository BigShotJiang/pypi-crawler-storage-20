from __future__ import annotations

from dataclasses import dataclass
import math

from helix.lightcone.allele_ops import DelOp, InsOp, MatchOp, allele_ops_to_payload, canonicalize_allele_ops
from helix.lightcone.contract import LightconeDocument, Outcome
from helix.lightcone.outcomes import canonicalize_outcomes
from helix.rng import Rng


@dataclass(frozen=True, slots=True)
class CrisprV0Params:
    max_deletion_bp: int = 18
    max_insertion_bp: int = 3
    no_edit_weight: float = 0.12
    del_decay: float = 4.5
    ins_decay: float = 1.4
    mmej_threshold_bp: int = 8
    divergence_phase: float = 0.38


class CrisprOutcomeBuilderV0:
    """Very simple CRISPR cut indel spectrum builder (v0).

    This is intentionally a deterministic, parameter-light starting point.
    """

    def __init__(self, params: CrisprV0Params | None = None) -> None:
        self.params = params or CrisprV0Params()

    def build_from_document(self, doc: LightconeDocument, *, seed: int) -> tuple[Outcome, ...]:
        if doc.edit_type != "crispr_cut":
            raise ValueError(f"Expected editType=crispr_cut (got {doc.edit_type!r})")
        if doc.reference_window is None or not doc.reference_window.sequence:
            raise ValueError("CrisprOutcomeBuilderV0 requires referenceWindow.sequence")
        ref = doc.reference_window.sequence.upper()

        # Interpret locus.position as the cut site coordinate within the reference window.
        # (Coordinate conventions are outside the scope of v0; fixtures should be consistent.)
        cut_index = int(doc.locus.position) - int(doc.locus.window_start)
        return self.build(ref, cut_index=cut_index, seed=seed)

    def build(self, reference: str, *, cut_index: int, seed: int) -> tuple[Outcome, ...]:
        ref = str(reference).upper()
        n = len(ref)
        if n <= 0:
            raise ValueError("reference must be non-empty")
        if cut_index < 0 or cut_index > n:
            raise ValueError(f"cut_index must be in [0,{n}] (got {cut_index})")

        p = self.params
        rng = Rng(int(seed), stream_id=f"lightcone:crispr_v0:ins_seq_v1:seed={int(seed)}")

        outcomes: list[Outcome] = []

        # No-edit path (bind/no productive cut); encoded as a full match.
        outcomes.append(
            Outcome(
                id="no_edit",
                probability=float(p.no_edit_weight),
                divergence_phase=0.22,
                allele_ops=allele_ops_to_payload((MatchOp(n),)),
                mechanism_tags=("no_edit", "no_cut"),
                notes="Binding without productive cut.",
            )
        )

        # Deletions centered on the cut index.
        for size in range(1, int(p.max_deletion_bp) + 1):
            # Center deletion around the cut.
            left = size // 2
            start = cut_index - left
            start = max(0, min(start, n - size))
            end = start + size
            if start < 0 or end > n:
                continue
            ops = canonicalize_allele_ops((MatchOp(start), DelOp(size), MatchOp(n - end)))
            tags = ("indel", "mmej") if size >= int(p.mmej_threshold_bp) else ("indel", "nhej")
            weight = math.exp(-size / float(p.del_decay))
            outcomes.append(
                Outcome(
                    id=f"del_{start}_{end}",
                    probability=float(weight),
                    divergence_phase=float(p.divergence_phase),
                    allele_ops=allele_ops_to_payload(ops),
                    mechanism_tags=tags,
                    notes=f"Deletion of {size} bp.",
                )
            )

        # Small insertions at the cut index.
        alphabet = "ACGT"
        for size in range(1, int(p.max_insertion_bp) + 1):
            seq = "".join(rng.choice(alphabet) for _ in range(size))
            ops = canonicalize_allele_ops((MatchOp(cut_index), InsOp(seq), MatchOp(n - cut_index)))
            weight = 0.45 * math.exp(-size / float(p.ins_decay))
            outcomes.append(
                Outcome(
                    id=f"ins_{cut_index}_{seq}",
                    probability=float(weight),
                    divergence_phase=float(p.divergence_phase),
                    allele_ops=allele_ops_to_payload(ops),
                    mechanism_tags=("indel", "nhej"),
                    notes=f"Insertion of {size} bp.",
                )
            )

        # Normalize and stable-sort for deterministic output.
        return canonicalize_outcomes(outcomes)
