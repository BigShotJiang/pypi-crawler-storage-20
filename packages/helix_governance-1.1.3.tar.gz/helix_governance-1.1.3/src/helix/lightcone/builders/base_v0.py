from __future__ import annotations

from dataclasses import dataclass
import math

from helix.lightcone.allele_ops import MatchOp, SubOp, allele_ops_to_payload, canonicalize_allele_ops
from helix.lightcone.contract import LightconeDocument, Outcome
from helix.lightcone.outcomes import canonicalize_outcomes


@dataclass(frozen=True, slots=True)
class BaseV0Params:
    base_rate: float = 0.6
    baseline: float = 0.15
    falloff: float = 2.5
    peak_offset: float | None = None  # reference-window index; default: center of edit window
    tc_boost: float = 1.35  # CBE context boost when previous base is 'T' (TC motif)
    divergence_base: float = 0.62
    divergence_step: float = 0.05
    beam_width: int = 64


class BaseOutcomeBuilderV0:
    """Deterministic base-edit builder (v0) using independent per-position edit probabilities + beam search."""

    def __init__(self, params: BaseV0Params | None = None) -> None:
        self.params = params or BaseV0Params()

    def build_from_document(
        self,
        doc: LightconeDocument,
        *,
        seed: int,
        editor_kind: str,
        edit_window: tuple[int, int],
        intended_offset: int | None = None,
    ) -> tuple[Outcome, ...]:
        if doc.edit_type != "base_edit":
            raise ValueError(f"Expected editType=base_edit (got {doc.edit_type!r})")
        if doc.reference_window is None or not doc.reference_window.sequence:
            raise ValueError("BaseOutcomeBuilderV0 requires referenceWindow.sequence")
        return self.build(
            doc.reference_window.sequence,
            seed=seed,
            editor_kind=editor_kind,
            edit_window=edit_window,
            intended_offset=intended_offset,
        )

    def build(
        self,
        reference: str,
        *,
        seed: int,
        editor_kind: str,
        edit_window: tuple[int, int],
        intended_offset: int | None = None,
    ) -> tuple[Outcome, ...]:
        ref = str(reference).upper()
        n = len(ref)
        if n <= 0:
            raise ValueError("reference must be non-empty")

        kind = str(editor_kind).strip().upper()
        if kind not in {"CBE", "ABE"}:
            raise ValueError("editor_kind must be 'CBE' or 'ABE'")
        target_base, converted_base = ("C", "T") if kind == "CBE" else ("A", "G")

        w0, w1 = int(edit_window[0]), int(edit_window[1])
        if w0 > w1:
            w0, w1 = w1, w0
        if w0 < 0 or w1 >= n:
            raise ValueError(f"edit_window must lie within [0,{n-1}] (got {edit_window})")

        p = self.params
        if p.falloff <= 0:
            raise ValueError("falloff must be > 0")
        base_rate = float(p.base_rate)
        baseline = float(p.baseline)
        if base_rate < 0.0 or base_rate > 1.0:
            raise ValueError("base_rate must be in [0,1]")
        if baseline < 0.0 or baseline > 1.0:
            raise ValueError("baseline must be in [0,1]")

        peak = float(p.peak_offset) if p.peak_offset is not None else (w0 + w1) / 2.0
        editable_positions: list[int] = []
        per_pos_p: dict[int, float] = {}
        for i in range(w0, w1 + 1):
            if ref[i] != target_base:
                continue
            dist = float(i) - peak
            pos_weight = baseline + (1.0 - baseline) * math.exp(-(dist * dist) / (2.0 * p.falloff * p.falloff))
            ctx_weight = 1.0
            if kind == "CBE" and i > 0 and ref[i - 1] == "T":
                ctx_weight *= float(p.tc_boost)
            pi = _clamp01(base_rate * pos_weight * ctx_weight)
            editable_positions.append(i)
            per_pos_p[i] = pi

        # If there are no editable positions, return a deterministic no-edit outcome.
        if not editable_positions:
            return canonicalize_outcomes(
                (
                    Outcome(
                        id="no_edit",
                        probability=1.0,
                        divergence_phase=0.22,
                        allele_ops=allele_ops_to_payload((MatchOp(n),)),
                        mechanism_tags=("base", kind.lower(), "no_edit"),
                        notes="No editable bases in window.",
                    ),
                )
            )

        editable_positions.sort()

        # Beam search over independent edits.
        beam_width = int(p.beam_width)
        if beam_width <= 0:
            raise ValueError("beam_width must be > 0")

        partials: list[tuple[tuple[int, ...], float]] = [((), 1.0)]
        for pos in editable_positions:
            pi = per_pos_p[pos]
            expanded: list[tuple[tuple[int, ...], float]] = []
            for edits, prob in partials:
                p0 = prob * (1.0 - pi)
                if p0 > 0.0:
                    expanded.append((edits, p0))
                p1 = prob * pi
                if p1 > 0.0:
                    expanded.append((edits + (pos,), p1))
            expanded.sort(key=lambda t: (-t[1], t[0]))
            partials = expanded[:beam_width]

        # Ensure explicit no-edit outcome exists even if beam dropped it.
        no_edit_prob = 1.0
        for pos in editable_positions:
            no_edit_prob *= 1.0 - per_pos_p[pos]
        have_no_edit = any(edits == () for edits, _ in partials)
        if not have_no_edit:
            partials.append(((), no_edit_prob))

        # Convert partials to Outcomes.
        outcomes: list[Outcome] = []
        for edits, prob in partials:
            edits_set = set(edits)
            ops = _sub_ops_for_edits(ref, edits_set, converted_base=converted_base)
            tags = ["base", kind.lower()]
            if not edits:
                tags.extend(["no_edit", "no_cut"])
            if intended_offset is not None and intended_offset in edits_set:
                tags.append("intended")
            if len(edits) > 1:
                tags.append("bystander")

            divergence = float(p.divergence_base)
            if edits:
                divergence = min(0.90, divergence + float(p.divergence_step) * max(0, len(edits) - 1))
            else:
                divergence = 0.22

            if edits:
                id_part = "_".join(str(i) for i in edits)
                oid = f"edits_{id_part}"
            else:
                oid = "no_edit"

            outcomes.append(
                Outcome(
                    id=oid,
                    probability=float(prob),
                    divergence_phase=divergence,
                    allele_ops=allele_ops_to_payload(ops),
                    mechanism_tags=tuple(tags),
                    notes=f"{kind} edits at {list(edits)}" if edits else "No edit.",
                )
            )

        return canonicalize_outcomes(outcomes)


def _sub_ops_for_edits(reference: str, edits: set[int], *, converted_base: str) -> tuple[MatchOp | SubOp, ...]:
    ref = str(reference).upper()
    n = len(ref)
    if not edits:
        return (MatchOp(n),)
    positions = sorted(edits)
    cur = 0
    ops: list[MatchOp | SubOp] = []
    for pos in positions:
        if pos < cur or pos < 0 or pos >= n:
            raise ValueError("Invalid edit position")
        if pos > cur:
            ops.append(MatchOp(pos - cur))
        ops.append(SubOp(ref[pos], converted_base))
        cur = pos + 1
    if cur < n:
        ops.append(MatchOp(n - cur))
    return canonicalize_allele_ops(tuple(ops))  # type: ignore[arg-type]


def _clamp01(x: float) -> float:
    return 0.0 if x < 0.0 else 1.0 if x > 1.0 else float(x)
