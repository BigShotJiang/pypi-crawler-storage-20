from __future__ import annotations

import hashlib
import json
import math
import struct
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol, Sequence

from .branch_tree import BranchEdge, BranchNode, build_branch_tree, collect_subtree_leaves
from .contract import LightconeDocument, Outcome, RenderStyle, StyleRule
from .stress import STRESS_TREE_BUILDER_ID, StressTreeParams, build_stress_tree


class _CanvasLike(Protocol):
    def draw_polyline(self, pts: Sequence[tuple[int, int]], *, color: tuple[int, int, int, int], r: int = 0) -> None: ...
    def fill_disc(self, cx: int, cy: int, r: int, color: tuple[int, int, int, int]) -> None: ...


def _clamp_int(x: int, lo: int, hi: int) -> int:
    return lo if x < lo else hi if x > hi else x


def _clamp_float(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


def _camera_transform_px(
    x: float,
    y: float,
    *,
    width: int,
    height: int,
    pan_px: tuple[float, float],
    zoom: float,
) -> tuple[float, float]:
    cx = width * 0.5
    cy = height * 0.5
    x2 = (x - cx) * zoom + cx + pan_px[0]
    y2 = (y - cy) * zoom + cy + pan_px[1]
    return x2, y2


def _rule_matches(rule: StyleRule, tags_l: set[str]) -> bool:
    for t in rule.match_any:
        if t in tags_l:
            return True
    return False


def _style_apply_rules(style: RenderStyle, tags: Sequence[str]) -> tuple[tuple[int, int, int], float, bool]:
    tags_l = {str(t).lower() for t in tags}
    rgb = style.default_color_rgb
    thickness_mul = 1.0
    braid = False
    for rule in style.tag_rules:
        if not _rule_matches(rule, tags_l):
            continue
        if rule.color_rgb is not None:
            rgb = rule.color_rgb
        if rule.thickness_mul is not None:
            thickness_mul *= float(rule.thickness_mul)
        if rule.braid is not None:
            braid = braid or bool(rule.braid)
        break
    return rgb, thickness_mul, braid


def _allele_delta_bp(allele_ops: Sequence[Mapping[str, object]]) -> int:
    ins = 0
    dele = 0
    for op in allele_ops:
        kind = str(op.get("op") or "").lower()
        if kind == "ins":
            seq = str(op.get("seq") or "")
            ins += len(seq)
        elif kind == "del":
            dele += int(op.get("n") or 0)
    return ins - dele


def _dominant_outcome(outcomes: Sequence[tuple[str, float]]) -> str:
    # Max probability, stable tie-break by id.
    best_id = ""
    best_p = -1.0
    for oid, p in outcomes:
        fp = float(p)
        if fp > best_p or (fp == best_p and str(oid) < best_id):
            best_id = str(oid)
            best_p = fp
    return best_id


def _op_key_payload(op: object) -> tuple:
    # Mirrors helix.lightcone.branch_tree op ordering (but as JSON-safe primitives).
    from .allele_ops import DelOp, InsOp, MatchOp, SubOp

    if isinstance(op, MatchOp):
        return ("match", int(op.n))
    if isinstance(op, DelOp):
        return ("del", int(op.n))
    if isinstance(op, InsOp):
        return ("ins", str(op.seq))
    if isinstance(op, SubOp):
        return ("sub", str(op.ref), str(op.alt))
    return ("unknown", str(op))


def _edge_selection_id(path_keys: Sequence[tuple], *, used: dict[int, bytes]) -> int:
    base = json.dumps(path_keys, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    for salt in range(8):
        h = hashlib.sha256(base + b"|" + str(salt).encode("ascii")).digest()
        cand = int.from_bytes(h[:4], "big")
        if cand == 0:
            continue
        if cand not in used or used[cand] == base:
            used[cand] = base
            return cand
    # Extremely unlikely; fall back to a stable non-zero id.
    return int.from_bytes(hashlib.sha256(base).digest()[4:8], "big") or 1


@dataclass(frozen=True, slots=True)
class CompiledEdge:
    selection_id: int
    p0: tuple[int, int]
    p1: tuple[int, int]
    p2: tuple[int, int]
    p3: tuple[int, int]
    start_phase: float
    end_phase: float
    color: tuple[int, int, int, int]
    radius_px: int
    probability_mass: float
    braid: bool
    leaves: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CompiledGeometry:
    width: int
    height: int
    y_bottom_px: float
    axis_h_px: float
    edges: tuple[CompiledEdge, ...]


def compile_lightcone_geometry(
    doc: LightconeDocument,
    *,
    width: int,
    height: int,
    phase: float,
    camera_pan_px: tuple[float, float],
    camera_zoom: float,
) -> CompiledGeometry:
    """Compile a branch tree into deterministic cubic-bezier edges.

    Output is in *post-camera* pixel coordinates so both rendering and picking can share the same buffers.
    """

    if doc.render_golden is None:
        raise ValueError("compile_lightcone_geometry requires doc.render_golden (style/camera invariants)")
    style = doc.render_golden.style
    if style.layout_mode != "tree_v1":
        raise ValueError(f"compile_lightcone_geometry requires style.layoutMode='tree_v1' (got {style.layout_mode!r})")

    phase = _clamp_float(float(phase), 0.0, 1.0)
    camera_zoom = float(camera_zoom)
    if camera_zoom <= 0.0:
        raise ValueError("camera_zoom must be positive")

    margin_l, margin_r, margin_t, margin_b = style.margins
    x_center = width // 2
    y_top = margin_t
    y_bottom = height - margin_b
    axis_h = max(1, y_bottom - y_top)

    def y_of_phase(p: float) -> float:
        return y_bottom - _clamp_float(p, 0.0, 1.0) * axis_h

    # Precompute the post-camera mapping for y(phase) to support fast clipping.
    _, y_bottom_px = _camera_transform_px(
        float(x_center),
        float(y_bottom),
        width=width,
        height=height,
        pan_px=camera_pan_px,
        zoom=camera_zoom,
    )
    _, y_top_px = _camera_transform_px(
        float(x_center),
        float(y_top),
        width=width,
        height=height,
        pan_px=camera_pan_px,
        zoom=camera_zoom,
    )
    axis_h_px = float(y_bottom_px - y_top_px)

    stress_params: StressTreeParams | None = None
    bp = doc.builder_provenance
    if bp is not None and str(bp.builder_id) == STRESS_TREE_BUILDER_ID:
        try:
            stress_params = StressTreeParams.from_builder_params(seed=int(bp.seed), params=bp.params)
        except Exception:
            stress_params = None

    if stress_params is None:
        tree = build_branch_tree(doc.outcomes)
        oc_by_id: dict[str, Outcome] = {str(o.id): o for o in doc.outcomes}

        leaf_x: dict[str, float] = {}
        for oc in doc.outcomes:
            dx = 0.0
            if doc.edit_type in {"crispr_cut", "prime_edit"}:
                delta = _allele_delta_bp(oc.allele_ops)
                dx = _clamp_float(
                    delta * float(style.delta_bp_scale_px),
                    -float(style.tree_max_spread_px),
                    float(style.tree_max_spread_px),
                )
            # Deterministic tiny jitter so equal-magnitude leaves don't collapse.
            jitter = 0.0
            if style.tree_leaf_jitter_px > 0.0:
                h = hashlib.sha256(str(oc.id).encode("utf-8")).digest()
                u = int.from_bytes(h[:2], "big") / 65535.0
                jitter = (u * 2.0 - 1.0) * float(style.tree_leaf_jitter_px)
            x = float(x_center) + dx + jitter
            x = _clamp_float(x, float(margin_l), float(width - margin_r))
            leaf_x[str(oc.id)] = x

        max_depth = _max_depth(tree)
        if max_depth <= 0:
            max_depth = 1

        node_phase: dict[int, float] = {}
        _assign_node_phases(tree, oc_by_id, node_phase, depth=0, max_depth=max_depth)
        _enforce_monotone_phases(tree, node_phase, max_depth=max_depth)

        def selection_id_for_path(path_keys: Sequence[tuple], used_ids: dict[int, bytes]) -> int:
            return _edge_selection_id(path_keys, used=used_ids)
    else:
        tree = build_stress_tree(stress_params)
        oc_by_id = {}
        leaves = collect_subtree_leaves(tree)
        leaf_x = {}
        x0 = float(margin_l)
        x1 = float(width - margin_r)
        n = len(leaves)
        for idx, (oid, _p) in enumerate(leaves):
            t = 0.5 if n <= 1 else idx / float(n - 1)
            jitter = 0.0
            if style.tree_leaf_jitter_px > 0.0:
                h = hashlib.sha256(str(oid).encode("utf-8")).digest()
                u = int.from_bytes(h[:2], "big") / 65535.0
                jitter = (u * 2.0 - 1.0) * float(style.tree_leaf_jitter_px)
            x = x0 + t * (x1 - x0) + jitter
            x = _clamp_float(x, float(margin_l), float(width - margin_r))
            leaf_x[str(oid)] = x

        max_depth = _max_depth(tree)
        if max_depth <= 0:
            max_depth = 1

        node_phase = {}
        _assign_node_phases_stress(
            tree,
            node_phase,
            depth=0,
            max_depth=max_depth,
            trunk_length=float(stress_params.trunk_length),
        )
        _enforce_monotone_phases(tree, node_phase, max_depth=max_depth)

        dense_next = 1

        def selection_id_for_path(_path_keys: Sequence[tuple], _used_ids: dict[int, bytes]) -> int:
            nonlocal dense_next
            sid = dense_next
            dense_next += 1
            return int(sid)

    node_meta: dict[int, tuple[float, float, str]] = {}
    _collect_node_meta(tree, oc_by_id, leaf_x, node_meta)

    used_ids: dict[int, bytes] = {}
    edges: list[CompiledEdge] = []
    _compile_edges(
        node=tree,
        path=(),
        edges_out=edges,
        used_ids=used_ids,
        selection_id_for_path=selection_id_for_path,
        oc_by_id=oc_by_id,
        node_meta=node_meta,
        node_phase=node_phase,
        style=style,
        width=width,
        height=height,
        camera_pan_px=camera_pan_px,
        camera_zoom=camera_zoom,
        x_center=x_center,
        y_of_phase=y_of_phase,
    )

    # Stable edge ordering for buffers: selection id.
    edges.sort(key=lambda e: (int(e.selection_id), float(e.start_phase), float(e.end_phase), int(e.p0[0]), int(e.p0[1])))
    return CompiledGeometry(width=width, height=height, y_bottom_px=float(y_bottom_px), axis_h_px=axis_h_px, edges=tuple(edges))


def _max_depth(node: BranchNode) -> int:
    if not node.edges:
        return 0
    return 1 + max(_max_depth(e.child) for e in node.edges)


def _leaf_divergence_min(node: BranchNode, oc_by_id: Mapping[str, Outcome]) -> float:
    leaves = collect_subtree_leaves(node)
    if not leaves:
        return 0.0
    best = 1.0
    for oid, _p in leaves:
        oc = oc_by_id.get(str(oid))
        if oc is None:
            continue
        d = float(oc.divergence_phase)
        if d < best:
            best = d
    return _clamp_float(best, 0.0, 1.0)


def _collect_node_meta(
    node: BranchNode,
    oc_by_id: Mapping[str, Outcome],
    leaf_x: Mapping[str, float],
    out: dict[int, tuple[float, float, str]],
) -> tuple[float, float, str]:
    """Return (x_weighted, total_prob, dominant_outcome_id) for this subtree.

    Uses stable leaf ordering and deterministic tie-breaks.
    """

    leaves = collect_subtree_leaves(node)
    total_prob = float(sum(float(p) for _oid, p in leaves))
    if total_prob <= 0.0:
        total_prob = 1.0
    wx = 0.0
    for oid, p in leaves:
        oid_s = str(oid)
        wx += float(leaf_x.get(oid_s, 0.0)) * float(p)
    x_weighted = wx / total_prob
    dominant = _dominant_outcome(leaves)
    out[id(node)] = (x_weighted, total_prob, dominant)
    for e in node.edges:
        _collect_node_meta(e.child, oc_by_id, leaf_x, out)
    return x_weighted, total_prob, dominant


def _assign_node_phases(
    node: BranchNode,
    oc_by_id: Mapping[str, Outcome],
    out: dict[int, float],
    *,
    depth: int,
    max_depth: int,
) -> None:
    if depth <= 0:
        out[id(node)] = 0.0
    else:
        struct = depth / max(1, int(max_depth))
        dmin = _leaf_divergence_min(node, oc_by_id)
        out[id(node)] = _clamp_float(max(struct, dmin), 0.0, 1.0)
    for e in node.edges:
        _assign_node_phases(e.child, oc_by_id, out, depth=depth + 1, max_depth=max_depth)


def _assign_node_phases_stress(
    node: BranchNode,
    out: dict[int, float],
    *,
    depth: int,
    max_depth: int,
    trunk_length: float,
) -> None:
    tl = _clamp_float(float(trunk_length), 0.0, 1.0)
    if depth <= 0:
        out[id(node)] = 0.0
    else:
        if max_depth <= 1:
            p = 1.0
        else:
            t = (depth - 1) / float(max_depth - 1)
            p = tl + t * (1.0 - tl)
        out[id(node)] = _clamp_float(p, 0.0, 1.0)
    for e in node.edges:
        _assign_node_phases_stress(e.child, out, depth=depth + 1, max_depth=max_depth, trunk_length=tl)


def _enforce_monotone_phases(node: BranchNode, node_phase: dict[int, float], *, max_depth: int) -> None:
    min_step = 1.0 / max(2, int(max_depth))
    p_here = float(node_phase.get(id(node), 0.0))
    for e in node.edges:
        child_id = id(e.child)
        p_child = float(node_phase.get(child_id, p_here))
        if p_child <= p_here:
            node_phase[child_id] = _clamp_float(p_here + min_step, 0.0, 1.0)
        _enforce_monotone_phases(e.child, node_phase, max_depth=max_depth)


def _compile_edges(
    *,
    node: BranchNode,
    path: tuple[tuple, ...],
    edges_out: list[CompiledEdge],
    used_ids: dict[int, bytes],
    selection_id_for_path: Callable[[Sequence[tuple], dict[int, bytes]], int],
    oc_by_id: Mapping[str, Outcome],
    node_meta: Mapping[int, tuple[float, float, str]],
    node_phase: Mapping[int, float],
    style: RenderStyle,
    width: int,
    height: int,
    camera_pan_px: tuple[float, float],
    camera_zoom: float,
    x_center: int,
    y_of_phase: Any,
) -> None:
    parent_phase = float(node_phase.get(id(node), 0.0))
    parent_xw, _parent_mass, _parent_dom = node_meta.get(id(node), (float(x_center), 1.0, ""))
    parent_y = float(y_of_phase(parent_phase))
    parent_x = float(parent_xw)
    p0x, p0y = _camera_transform_px(parent_x, parent_y, width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
    p0i = (int(round(p0x)), int(round(p0y)))

    bundling_cfg = dict(style.bundling)
    bundling_enabled = bool(bundling_cfg.get("enabled", False))
    bundle_threshold_px = float(bundling_cfg.get("siblingMergePx", 0.0))
    bundle_threshold_q = int(round(bundle_threshold_px * 256.0))
    bundle_t = _clamp_float(float(bundling_cfg.get("bundlePhaseT", 0.55)), 0.05, 0.95)
    keep_intended_separate = bool(bundling_cfg.get("keepIntendedSeparate", True))

    bundle_x_by_edge_idx: dict[int, float] = {}
    if bundling_enabled and bundle_threshold_q > 0 and len(node.edges) > 1:
        _assign_bundles_for_node(
            node=node,
            node_meta=node_meta,
            oc_by_id=oc_by_id,
            bundle_x_by_edge_idx=bundle_x_by_edge_idx,
            threshold_q=bundle_threshold_q,
            keep_intended_separate=keep_intended_separate,
        )

    for edge_idx, edge in enumerate(node.edges):
        child = edge.child
        child_phase = float(node_phase.get(id(child), parent_phase))
        child_xw, _child_mass, dom_id = node_meta.get(id(child), (float(x_center), 1.0, ""))
        child_y = float(y_of_phase(child_phase))
        child_x = float(child_xw)

        p3x, p3y = _camera_transform_px(child_x, child_y, width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
        p3i = (int(round(p3x)), int(round(p3y)))

        dy = p3y - p0y
        c1 = (p0x, p0y + dy * 0.33)
        c2 = (p3x, p0y + dy * 0.66)
        p1i = (int(round(c1[0])), int(round(c1[1])))
        p2i = (int(round(c2[0])), int(round(c2[1])))

        dom = oc_by_id.get(dom_id)
        tags = list(dom.mechanism_tags) if dom is not None else []
        (r, g, b), thickness_mul, braid = _style_apply_rules(style, tags)

        # Alpha + thickness derive from probability mass.
        mass = float(edge.probability_mass)
        intensity = math.sqrt(max(0.0, mass))
        alpha = int(round(int(style.alpha_base) + int(style.alpha_scale) * intensity))
        alpha = _clamp_int(alpha, int(style.alpha_min), int(style.alpha_max))
        radius = max(0, int(round(float(style.branch_radius_px) * float(thickness_mul))))

        path2 = path + (_op_key_payload(edge.op),)
        sel = selection_id_for_path(path2, used_ids)
        leaves = tuple(oid for oid, _p in collect_subtree_leaves(child))

        bundle_xw = bundle_x_by_edge_idx.get(edge_idx)
        if bundling_enabled and bundle_xw is not None:
            # Route parent -> bundle -> child. Both segments share the same selection id / leaf mapping.
            bundle_phase = parent_phase + (child_phase - parent_phase) * bundle_t
            bundle_phase = round(_clamp_float(bundle_phase, 0.0, 1.0) * 65535.0) / 65535.0
            bundle_y = float(y_of_phase(bundle_phase))
            bundle_x = float(bundle_xw)
            bpx, bpy = _camera_transform_px(bundle_x, bundle_y, width=width, height=height, pan_px=camera_pan_px, zoom=camera_zoom)
            bpi = (int(round(bpx)), int(round(bpy)))

            # Segment A: parent -> bundle
            dy_a = bpy - p0y
            a1 = (p0x, p0y + dy_a * 0.33)
            a2 = (bpx, p0y + dy_a * 0.66)
            edges_out.append(
                CompiledEdge(
                    selection_id=sel,
                    p0=p0i,
                    p1=(int(round(a1[0])), int(round(a1[1]))),
                    p2=(int(round(a2[0])), int(round(a2[1]))),
                    p3=bpi,
                    start_phase=parent_phase,
                    end_phase=bundle_phase,
                    color=(int(r), int(g), int(b), alpha),
                    radius_px=radius,
                    probability_mass=mass,
                    braid=(bool(braid) and style.layout_mode == "tree_v1"),
                    leaves=leaves,
                )
            )
            # Segment B: bundle -> child
            dy_b = p3y - bpy
            b1 = (bpx, bpy + dy_b * 0.33)
            b2 = (p3x, bpy + dy_b * 0.66)
            edges_out.append(
                CompiledEdge(
                    selection_id=sel,
                    p0=bpi,
                    p1=(int(round(b1[0])), int(round(b1[1]))),
                    p2=(int(round(b2[0])), int(round(b2[1]))),
                    p3=p3i,
                    start_phase=bundle_phase,
                    end_phase=child_phase,
                    color=(int(r), int(g), int(b), alpha),
                    radius_px=radius,
                    probability_mass=mass,
                    braid=(bool(braid) and style.layout_mode == "tree_v1"),
                    leaves=leaves,
                )
            )
        else:
            edges_out.append(
                CompiledEdge(
                    selection_id=sel,
                    p0=p0i,
                    p1=p1i,
                    p2=p2i,
                    p3=p3i,
                    start_phase=parent_phase,
                    end_phase=child_phase,
                    color=(int(r), int(g), int(b), alpha),
                    radius_px=radius,
                    probability_mass=mass,
                    braid=(bool(braid) and style.layout_mode == "tree_v1"),
                    leaves=leaves,
                )
            )
        _compile_edges(
            node=child,
            path=path2,
            edges_out=edges_out,
            used_ids=used_ids,
            selection_id_for_path=selection_id_for_path,
            oc_by_id=oc_by_id,
            node_meta=node_meta,
            node_phase=node_phase,
            style=style,
            width=width,
            height=height,
            camera_pan_px=camera_pan_px,
            camera_zoom=camera_zoom,
            x_center=x_center,
            y_of_phase=y_of_phase,
        )


def _assign_bundles_for_node(
    *,
    node: BranchNode,
    node_meta: Mapping[int, tuple[float, float, str]],
    oc_by_id: Mapping[str, Outcome],
    bundle_x_by_edge_idx: dict[int, float],
    threshold_q: int,
    keep_intended_separate: bool,
) -> None:
    child_items: list[tuple[int, int, bool]] = []  # (edge_idx, x_q, intended)
    for idx, e in enumerate(node.edges):
        child_xw, _mass, dom_id = node_meta.get(id(e.child), (0.0, 1.0, ""))
        x_q = int(round(float(child_xw) * 256.0))
        dom = oc_by_id.get(str(dom_id))
        tags = {t.lower() for t in (dom.mechanism_tags if dom is not None else ())}
        intended = "intended" in tags
        child_items.append((idx, x_q, intended))

    child_items.sort(key=lambda t: (t[1], t[0]))

    groups: list[list[tuple[int, int, bool]]] = []
    cur: list[tuple[int, int, bool]] = []
    for item in child_items:
        if not cur:
            cur = [item]
            continue
        prev = cur[-1]
        if abs(item[1] - prev[1]) <= threshold_q and (not keep_intended_separate or not (item[2] or prev[2])):
            cur.append(item)
        else:
            groups.append(cur)
            cur = [item]
    if cur:
        groups.append(cur)

    for g in groups:
        if len(g) <= 1:
            continue
        # Deterministic bundle x: mean of quantized child x positions.
        mean_q = int(round(sum(x_q for _idx, x_q, _intended in g) / len(g)))
        bundle_x = mean_q / 256.0
        for edge_idx, _x_q, _intended in g:
            bundle_x_by_edge_idx[edge_idx] = bundle_x


def compiled_geometry_sha256(geom: CompiledGeometry) -> str:
    """Hash the compiled buffers (not the rendered pixels)."""

    buf = bytearray()
    buf.extend(struct.pack(">II", int(geom.width), int(geom.height)))
    # Use a stable fixed-point-ish encoding for floats.
    buf.extend(struct.pack(">i", int(round(float(geom.y_bottom_px) * 256.0))))
    buf.extend(struct.pack(">i", int(round(float(geom.axis_h_px) * 256.0))))

    for e in geom.edges:
        buf.extend(struct.pack(">I", int(e.selection_id)))
        for (x, y) in (e.p0, e.p1, e.p2, e.p3):
            buf.extend(struct.pack(">ii", int(x), int(y)))
        buf.extend(struct.pack(">HH", int(round(_clamp_float(e.start_phase, 0.0, 1.0) * 65535)), int(round(_clamp_float(e.end_phase, 0.0, 1.0) * 65535))))
        buf.extend(struct.pack(">BBBB", int(e.color[0]), int(e.color[1]), int(e.color[2]), int(e.color[3])))
        buf.extend(struct.pack(">H", int(e.radius_px)))
        buf.extend(struct.pack(">I", int(round(_clamp_float(float(e.probability_mass), 0.0, 1.0) * 1_000_000_000))))
        # Leaves: hashed into the buffer to keep selection mapping stable.
        leaf_blob = ("\n".join(e.leaves)).encode("utf-8")
        buf.extend(hashlib.sha256(leaf_blob).digest()[:8])

    return hashlib.sha256(bytes(buf)).hexdigest()


def _bezier_points(p0: tuple[int, int], p1: tuple[int, int], p2: tuple[int, int], p3: tuple[int, int], steps: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for i in range(steps + 1):
        t = i / steps
        u = 1.0 - t
        x = (
            u * u * u * p0[0]
            + 3.0 * u * u * t * p1[0]
            + 3.0 * u * t * t * p2[0]
            + t * t * t * p3[0]
        )
        y = (
            u * u * u * p0[1]
            + 3.0 * u * u * t * p1[1]
            + 3.0 * u * t * t * p2[1]
            + t * t * t * p3[1]
        )
        out.append((int(round(x)), int(round(y))))
    return out


def draw_compiled_geometry(
    canvas: _CanvasLike,
    geom: CompiledGeometry,
    *,
    phase: float,
    tip_radius_px: int,
    tip_alpha_boost: int,
) -> None:
    phase = _clamp_float(float(phase), 0.0, 1.0)
    y_clip = float(geom.y_bottom_px) - phase * float(geom.axis_h_px)
    for e in geom.edges:
        if phase <= float(e.start_phase):
            continue
        pts = _bezier_points(e.p0, e.p1, e.p2, e.p3, steps=32)
        clipped: list[tuple[int, int]] = []
        for x, y in pts:
            if y >= y_clip:
                clipped.append((x, y))
        if len(clipped) < 2:
            continue
        if e.braid and e.radius_px > 0:
            _draw_braid(canvas, clipped, color=e.color, r=int(e.radius_px))
        else:
            canvas.draw_polyline(clipped, color=e.color, r=int(e.radius_px))
        # Tip dot at the last visible sample.
        x_tip, y_tip = clipped[-1]
        canvas.fill_disc(
            x_tip,
            y_tip,
            max(1, int(tip_radius_px)),
            (e.color[0], e.color[1], e.color[2], _clamp_int(int(e.color[3]) + int(tip_alpha_boost), 0, 255)),
        )


def _draw_braid(canvas: _CanvasLike, pts: Sequence[tuple[int, int]], *, color: tuple[int, int, int, int], r: int) -> None:
    if len(pts) < 2:
        return
    offset = max(1, int(r) + 1)
    a: list[tuple[int, int]] = []
    b: list[tuple[int, int]] = []
    for i, (x, y) in enumerate(pts):
        sign = 1 if (i // 4) % 2 == 0 else -1
        a.append((x + sign * offset, y))
        b.append((x - sign * offset, y))
    canvas.draw_polyline(a, color=color, r=r)
    canvas.draw_polyline(b, color=color, r=r)
