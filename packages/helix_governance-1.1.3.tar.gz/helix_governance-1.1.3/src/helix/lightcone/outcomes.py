from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable, Sequence

from helix.rng import Rng

from .contract import Outcome


def _stable_outcome_key(o: Outcome) -> tuple[float, str]:
    return (-float(o.probability), str(o.id))


def stable_sort_outcomes(outcomes: Sequence[Outcome]) -> tuple[Outcome, ...]:
    return tuple(sorted(outcomes, key=_stable_outcome_key))


def normalize_outcomes(outcomes: Sequence[Outcome], *, tol: float = 1e-9) -> tuple[Outcome, ...]:
    """Return outcomes with probabilities normalized to sum to 1.0."""

    if not outcomes:
        raise ValueError("Cannot normalize empty outcome list")
    probs = [float(o.probability) for o in outcomes]
    if any((p < 0.0 or math.isnan(p) or math.isinf(p)) for p in probs):
        raise ValueError("Outcome probabilities must be finite and >= 0")
    # Make normalization deterministic w.r.t input ordering.
    ordered_probs = [float(o.probability) for o in stable_sort_outcomes(outcomes)]
    total = float(math.fsum(ordered_probs))
    if total <= 0.0:
        raise ValueError("Sum of outcome probabilities must be > 0")
    inv = 1.0 / total

    normalized = tuple(
        Outcome(
            id=o.id,
            probability=float(o.probability) * inv,
            divergence_phase=o.divergence_phase,
            allele_ops=o.allele_ops,
            mechanism_tags=o.mechanism_tags,
            notes=o.notes,
        )
        for o in outcomes
    )
    if abs(math.fsum(float(o.probability) for o in normalized) - 1.0) > tol:
        raise AssertionError("Normalization failed to reach 1.0 within tolerance")
    return normalized


def _weighted_sample_without_replacement(
    items: Sequence[Outcome],
    weights: Sequence[float],
    *,
    k: int,
    rng: Rng,
) -> list[Outcome]:
    if k <= 0 or not items:
        return []
    if k >= len(items):
        return list(items)
    remaining = list(items)
    remaining_w = [float(w) for w in weights]
    selected: list[Outcome] = []

    for _ in range(k):
        total = float(sum(remaining_w))
        if total <= 0.0:
            # Degenerate tail: fall back to deterministic first-k in the (already stably-sorted) list.
            selected.extend(remaining[: (k - len(selected))])
            break
        r = rng.random() * total
        acc = 0.0
        pick = 0
        for i, w in enumerate(remaining_w):
            acc += w
            if r <= acc:
                pick = i
                break
        selected.append(remaining.pop(pick))
        remaining_w.pop(pick)
    return selected


@dataclass(frozen=True, slots=True)
class TrimResult:
    outcomes: tuple[Outcome, ...]
    dropped_probability_mass: float


def trim_outcomes(
    outcomes: Sequence[Outcome],
    *,
    top_k: int,
    tail_sample: int,
    seed: int,
    tol: float = 1e-9,
) -> TrimResult:
    """Select top-K + sampled tail outcomes and renormalize.

    Determinism:
    - Stable sorting by (-probability, id) before selection.
    - Tail sampling uses a local RNG seeded by `seed`.
    """

    if top_k < 0 or tail_sample < 0:
        raise ValueError("top_k and tail_sample must be >= 0")
    normalized = normalize_outcomes(outcomes, tol=tol)
    ordered = stable_sort_outcomes(normalized)

    if top_k + tail_sample == 0:
        raise ValueError("top_k + tail_sample must be > 0")

    head = list(ordered[:top_k])
    tail = list(ordered[top_k:])
    rng = Rng(int(seed), stream_id="lightcone:trim_outcomes_tail_v1")
    sampled = _weighted_sample_without_replacement(tail, [float(o.probability) for o in tail], k=tail_sample, rng=rng)

    selected = head + sampled
    # Stable ordering again so output is independent of sampling order.
    selected = list(stable_sort_outcomes(selected))

    kept_mass = float(sum(float(o.probability) for o in selected))
    dropped_mass = max(0.0, 1.0 - kept_mass)
    if kept_mass <= 0.0:
        raise ValueError("Selected outcomes have zero total probability mass")

    renorm = tuple(
        Outcome(
            id=o.id,
            probability=float(o.probability) / kept_mass,
            divergence_phase=o.divergence_phase,
            allele_ops=o.allele_ops,
            mechanism_tags=o.mechanism_tags,
            notes=o.notes,
        )
        for o in selected
    )
    if abs(sum(float(o.probability) for o in renorm) - 1.0) > tol:
        raise AssertionError("Renormalization failed to reach 1.0 within tolerance")
    return TrimResult(outcomes=renorm, dropped_probability_mass=dropped_mass)


def canonicalize_outcomes(
    outcomes: Sequence[Outcome],
    *,
    tol: float = 1e-9,
) -> tuple[Outcome, ...]:
    """Normalize probabilities and stably order outcomes."""

    return stable_sort_outcomes(normalize_outcomes(outcomes, tol=tol))
