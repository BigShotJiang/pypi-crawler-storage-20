from __future__ import annotations

import json
import os
import platform
import statistics
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

from helix import clock
from helix.support.subprocess import no_console_kwargs

from .contract import load_lightcone_document
from .geometry import compiled_geometry_sha256
from .gpu_backend import (
    LightconeGpuRenderer,
    _build_segments_tree_v1,
    _segments_to_dda_disc_stamps,
    gpu_preflight,
    lightcone_gpu_backend_receipts,
    lightcone_gpu_shader_sha256,
)


@dataclass(frozen=True, slots=True)
class PerfStats:
    timing_kind: str  # "gpu_timer_query" | "cpu_wall_finish"
    samples: int
    median_ms: float
    p95_ms: float


def _percentile(values: Sequence[float], p: float) -> float:
    if not values:
        return 0.0
    if p <= 0.0:
        return float(min(values))
    if p >= 1.0:
        return float(max(values))
    xs = sorted(float(x) for x in values)
    idx = int(round((len(xs) - 1) * p))
    if idx < 0:
        idx = 0
    if idx >= len(xs):
        idx = len(xs) - 1
    return float(xs[idx])


def _git_sha(repo_root: Path) -> str | None:
    try:
        return (
            subprocess.check_output(
                ["git", "rev-parse", "HEAD"],
                cwd=str(repo_root),
                stderr=subprocess.DEVNULL,
                **no_console_kwargs(),
            )
            .decode("utf-8", errors="replace")
            .strip()
        )
    except Exception:
        return None


def _repo_root() -> Path:
    # src/helix/lightcone/perf.py -> repo/
    return Path(__file__).resolve().parents[3]


def _try_timer_query(ctx: Any) -> bool:
    try:
        q = ctx.query(time=True)
        # Some implementations require an explicit release; probe quickly.
        q.release()
        return True
    except Exception:
        return False


def _finish(ctx: Any) -> None:
    try:
        ctx.finish()
    except Exception:
        pass


def _measure_pass_ms(
    *,
    ctx: Any,
    warmup_frames: int,
    discard_measure_frames: int,
    measure_frames: int,
    fn: Callable[[], None],
) -> PerfStats:
    warmup = max(0, int(warmup_frames))
    discard = max(0, int(discard_measure_frames))
    frames = max(1, int(measure_frames))

    use_query = _try_timer_query(ctx)
    kind = "gpu_timer_query" if use_query else "cpu_wall_finish"
    samples: list[float] = []

    for _ in range(warmup):
        fn()
        _finish(ctx)

    if use_query:
        for _ in range(frames + discard):
            q = ctx.query(time=True)
            with q:
                fn()
            _finish(ctx)
            # ModernGL reports elapsed time in nanoseconds.
            try:
                ns = float(getattr(q, "elapsed", 0.0))
            except Exception:
                ns = 0.0
            samples.append(ns / 1_000_000.0)
    else:
        for _ in range(frames + discard):
            t0 = clock.perf_counter()
            fn()
            _finish(ctx)
            t1 = clock.perf_counter()
            samples.append((t1 - t0) * 1000.0)

    if discard and len(samples) > 1:
        samples = samples[min(discard, len(samples) - 1) :]

    median_ms = float(statistics.median(samples)) if samples else 0.0
    p95_ms = _percentile(samples, 0.95)
    return PerfStats(timing_kind=kind, samples=len(samples), median_ms=median_ms, p95_ms=p95_ms)


def run_lightcone_gpu_perf(
    fixture_path: str | Path,
    *,
    warmup_frames: int = 30,
    discard_measure_frames: int = 10,
    measure_frames: int = 120,
    measure_id_pass: bool = False,
    output_path: str | Path | None = None,
) -> dict[str, Any]:
    fixture_path = Path(fixture_path)
    doc = load_lightcone_document(fixture_path)
    rg = doc.render_golden
    if rg is None:
        raise ValueError("Perf requires fixture.renderGolden")
    if rg.style.layout_mode != "tree_v1":
        raise ValueError("Perf harness currently targets style.layoutMode='tree_v1'")

    info, skip_reason = gpu_preflight()
    if skip_reason:
        raise RuntimeError(f"GPU preflight failed: {skip_reason} (info={info})")

    gpu_backend = lightcone_gpu_backend_receipts()
    # Perf defaults to the interactive rasterization path (capsules). Allow explicit overrides
    # via HELIX_LIGHTCONE_GPU_RASTER for benchmarking/debug.
    if "HELIX_LIGHTCONE_GPU_RASTER" not in os.environ:
        gpu_backend["rasterMode"] = "capsules"

    raster_mode = str(gpu_backend.get("rasterMode") or "")

    segs_color, y_clip, stage_bands, geom = _build_segments_tree_v1(
        doc,
        width=rg.width,
        height=rg.height,
        phase=rg.phase,
        pick_mode=False,
    )
    if raster_mode == "stamps":
        segs_color = _segments_to_dda_disc_stamps(segs_color)
    geom_sha = compiled_geometry_sha256(geom)

    renderer = LightconeGpuRenderer()
    renderer.upload_segments(segs_color)

    color_stats = _measure_pass_ms(
        ctx=renderer.ctx,
        warmup_frames=warmup_frames,
        discard_measure_frames=discard_measure_frames,
        measure_frames=measure_frames,
        fn=lambda: renderer.render_color(
            doc,
            width=rg.width,
            height=rg.height,
            phase=rg.phase,
            background_rgba8=tuple(int(x) for x in rg.background),
            y_clip=float(y_clip),
            stage_bands=stage_bands,
            readback=False,
        ),
    )

    id_stats: PerfStats | None = None
    id_segments = 0
    if measure_id_pass:
        segs_id, y_clip_id, _stage_bands_id, _geom2 = _build_segments_tree_v1(
            doc,
            width=rg.width,
            height=rg.height,
            phase=rg.phase,
            pick_mode=True,
        )
        if raster_mode == "stamps":
            segs_id = _segments_to_dda_disc_stamps(segs_id)
        renderer.upload_segments(segs_id)
        id_segments = len(segs_id)
        id_stats = _measure_pass_ms(
            ctx=renderer.ctx,
            warmup_frames=warmup_frames,
            discard_measure_frames=discard_measure_frames,
            measure_frames=measure_frames,
            fn=lambda: renderer.render_id_u32(width=rg.width, height=rg.height, y_clip=float(y_clip_id), readback=False),
        )

    total_median = float(color_stats.median_ms + (id_stats.median_ms if id_stats else 0.0))
    total_p95 = float(color_stats.p95_ms + (id_stats.p95_ms if id_stats else 0.0))

    repo_root = _repo_root()
    receipt = {
        "timestamp": clock.utc_now_iso_offset(),
        "gitSha": _git_sha(repo_root),
        "fixture": str(fixture_path),
        "backend": "gpu",
        "shaderSha256": lightcone_gpu_shader_sha256(),
        "gpuBackend": gpu_backend,
        "gpuPreflight": info,
        "env": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "pid": os.getpid(),
        },
        "render": {
            "width": int(rg.width),
            "height": int(rg.height),
            "phase": float(rg.phase),
        },
        "perf": {
            "warmupFrames": int(warmup_frames),
            "discardMeasureFrames": int(discard_measure_frames),
            "measureFrames": int(measure_frames),
            "measureIdPass": bool(measure_id_pass),
        },
        "geometrySha256": geom_sha,
        "segments": {
            "color": int(len(segs_color)),
            "id": int(id_segments),
        },
        "drawCalls": {
            "color": int(2 if len(segs_color) > 0 else 1),  # bg + segments
            "id": int(1 if id_segments > 0 else 0),
        },
        "passes": {
            "color": {
                "timingKind": color_stats.timing_kind,
                "samples": int(color_stats.samples),
                "medianMs": float(color_stats.median_ms),
                "p95Ms": float(color_stats.p95_ms),
            },
            "id": (
                None
                if id_stats is None
                else {
                    "timingKind": id_stats.timing_kind,
                    "samples": int(id_stats.samples),
                    "medianMs": float(id_stats.median_ms),
                    "p95Ms": float(id_stats.p95_ms),
                }
            ),
            "sheen": None,
        },
        "total": {"medianMs": float(total_median), "p95Ms": float(total_p95)},
    }

    if output_path is not None:
        out_path = Path(output_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    return receipt
