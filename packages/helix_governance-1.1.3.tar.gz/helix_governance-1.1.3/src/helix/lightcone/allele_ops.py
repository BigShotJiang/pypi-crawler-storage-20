from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence, Union


@dataclass(frozen=True, slots=True)
class MatchOp:
    n: int


@dataclass(frozen=True, slots=True)
class DelOp:
    n: int


@dataclass(frozen=True, slots=True)
class InsOp:
    seq: str


@dataclass(frozen=True, slots=True)
class SubOp:
    ref: str
    alt: str


AlleleOp = Union[MatchOp, DelOp, InsOp, SubOp]


def allele_ops_from_payload(payload: Sequence[Mapping[str, Any]]) -> tuple[AlleleOp, ...]:
    ops: list[AlleleOp] = []
    for i, entry in enumerate(payload):
        kind = str(entry.get("op") or "").strip().lower()
        if not kind:
            raise ValueError(f"alleleOps[{i}] missing 'op'")
        if kind == "match":
            ops.append(MatchOp(n=int(entry.get("n") or 0)))
        elif kind == "del":
            ops.append(DelOp(n=int(entry.get("n") or 0)))
        elif kind == "ins":
            ops.append(InsOp(seq=str(entry.get("seq") or "")))
        elif kind == "sub":
            ops.append(SubOp(ref=str(entry.get("ref") or ""), alt=str(entry.get("alt") or "")))
        else:
            raise ValueError(f"Unsupported allele op {kind!r} at index {i}")
    return tuple(ops)


def allele_ops_to_payload(ops: Sequence[AlleleOp]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for op in ops:
        if isinstance(op, MatchOp):
            out.append({"op": "match", "n": int(op.n)})
        elif isinstance(op, DelOp):
            out.append({"op": "del", "n": int(op.n)})
        elif isinstance(op, InsOp):
            out.append({"op": "ins", "seq": str(op.seq)})
        elif isinstance(op, SubOp):
            out.append({"op": "sub", "ref": str(op.ref), "alt": str(op.alt)})
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unsupported op type: {type(op)!r}")
    return out


def _validate_nonneg_int(name: str, value: int) -> None:
    if value < 0:
        raise ValueError(f"{name} must be >= 0 (got {value})")


def canonicalize_allele_ops(ops: Sequence[AlleleOp]) -> tuple[AlleleOp, ...]:
    """Return a canonical allele-op sequence (merge runs, drop no-ops, normalize case).

    Canonicalization rules:
    - Drop `match(0)`, `del(0)`, `ins("")`.
    - Normalize sequences/ref/alt to uppercase.
    - Rewrite `sub(ref==alt)` -> `match(len(ref))`.
    - Rewrite `sub(ref=="")` -> `ins(alt)`, `sub(alt=="")` -> `del(len(ref))`.
    - Merge adjacent `match`, `del`, and `ins` runs.
    """

    out: list[AlleleOp] = []

    def push(op: AlleleOp) -> None:
        nonlocal out
        if isinstance(op, MatchOp):
            _validate_nonneg_int("match.n", op.n)
            if op.n == 0:
                return
            if out and isinstance(out[-1], MatchOp):
                out[-1] = MatchOp(n=out[-1].n + op.n)
                return
        elif isinstance(op, DelOp):
            _validate_nonneg_int("del.n", op.n)
            if op.n == 0:
                return
            if out and isinstance(out[-1], DelOp):
                out[-1] = DelOp(n=out[-1].n + op.n)
                return
        elif isinstance(op, InsOp):
            seq = op.seq.upper()
            if not seq:
                return
            if out and isinstance(out[-1], InsOp):
                out[-1] = InsOp(seq=out[-1].seq + seq)
                return
            op = InsOp(seq=seq)
        elif isinstance(op, SubOp):
            ref = op.ref.upper()
            alt = op.alt.upper()
            if ref == alt:
                push(MatchOp(n=len(ref)))
                return
            if not ref:
                push(InsOp(seq=alt))
                return
            if not alt:
                push(DelOp(n=len(ref)))
                return
            op = SubOp(ref=ref, alt=alt)
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unsupported op type: {type(op)!r}")

        out.append(op)

    for op in ops:
        push(op)

    return tuple(out)


def _ref_matches(segment: str, expected: str, *, allow_n_wildcard: bool) -> bool:
    if not allow_n_wildcard:
        return segment == expected
    if len(segment) != len(expected):
        return False
    for a, b in zip(segment, expected):
        if a == b:
            continue
        if a == "N" or b == "N":
            continue
        return False
    return True


def apply_allele_ops(
    reference: str,
    ops: Sequence[AlleleOp],
    *,
    validate_ref: bool = True,
    allow_n_wildcard: bool = True,
) -> str:
    """Apply ops to `reference` and return the allele sequence.

    Semantics (relative to the reference window):
    - match(n): consume n ref bases, emit the same n bases.
    - del(n): consume n ref bases, emit nothing.
    - ins(seq): consume 0 ref bases, emit seq.
    - sub(ref, alt): consume len(ref) bases, emit alt; optionally validate ref matches.

    Determinism:
    - Pure function; does not mutate inputs.
    - Raises on under/over-consumption or invalid ops.
    """

    ref = str(reference).upper()
    ops_c = canonicalize_allele_ops(ops)

    out: list[str] = []
    i = 0
    for idx, op in enumerate(ops_c):
        if isinstance(op, MatchOp):
            n = int(op.n)
            _validate_nonneg_int("match.n", n)
            seg = ref[i : i + n]
            if len(seg) != n:
                raise ValueError(f"match({n}) at op[{idx}] over-consumes reference (pos={i}, ref_len={len(ref)})")
            out.append(seg)
            i += n
        elif isinstance(op, DelOp):
            n = int(op.n)
            _validate_nonneg_int("del.n", n)
            seg = ref[i : i + n]
            if len(seg) != n:
                raise ValueError(f"del({n}) at op[{idx}] over-consumes reference (pos={i}, ref_len={len(ref)})")
            i += n
        elif isinstance(op, InsOp):
            seq = str(op.seq).upper()
            if seq:
                out.append(seq)
        elif isinstance(op, SubOp):
            exp = str(op.ref).upper()
            alt = str(op.alt).upper()
            if not exp:
                raise ValueError(f"sub ref must be non-empty at op[{idx}]")
            seg = ref[i : i + len(exp)]
            if len(seg) != len(exp):
                raise ValueError(
                    f"sub({exp}->{alt}) at op[{idx}] over-consumes reference (pos={i}, ref_len={len(ref)})"
                )
            if validate_ref and not _ref_matches(seg, exp, allow_n_wildcard=allow_n_wildcard):
                raise ValueError(f"sub ref mismatch at op[{idx}]: expected={exp!r} got={seg!r} pos={i}")
            out.append(alt)
            i += len(exp)
        else:  # pragma: no cover - defensive
            raise TypeError(f"Unsupported op type at op[{idx}]: {type(op)!r}")

    if i != len(ref):
        raise ValueError(f"alleleOps did not consume full reference: consumed={i} ref_len={len(ref)}")
    return "".join(out)


def canonical_payload(payload: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Convenience: canonicalize an `alleleOps` JSON payload into a stable form."""

    ops = allele_ops_from_payload(payload)
    return allele_ops_to_payload(canonicalize_allele_ops(ops))

