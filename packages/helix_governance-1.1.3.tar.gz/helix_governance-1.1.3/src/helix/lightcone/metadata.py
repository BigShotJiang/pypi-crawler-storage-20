from __future__ import annotations

import json
import platform
import sys
from typing import Any, Mapping

from helix.provenance import current_git_sha

from .contract import LightconeDocument, RenderGolden
from .render import render_settings_payload


def collect_renderer_fingerprint() -> dict[str, Any]:
    fp: dict[str, Any] = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "gitSha": current_git_sha(),
    }
    try:
        import moderngl  # type: ignore

        try:
            ctx = moderngl.create_standalone_context()
            fp["glVendor"] = str(ctx.info.get("GL_VENDOR", ""))
            fp["glRenderer"] = str(ctx.info.get("GL_RENDERER", ""))
            fp["glVersion"] = str(ctx.info.get("GL_VERSION", ""))
        except Exception as exc:  # pragma: no cover - optional
            fp["glError"] = repr(exc)
    except Exception:
        pass
    return fp


def build_lightcone_png_text(
    doc: LightconeDocument,
    render: RenderGolden,
    *,
    rgba_sha256: str,
    settings_sha256: str,
    geometry_sha256: str | None = None,
    settings: Mapping[str, Any] | None = None,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, str]:
    settings_payload: Mapping[str, Any] = settings or render_settings_payload(render)
    fp = collect_renderer_fingerprint()
    if extra:
        fp["extra"] = dict(extra)

    text: dict[str, str] = {
        "helix.lightcone.specVersion": str(doc.spec_version),
        "helix.lightcone.fixtureId": str(doc.id),
        "helix.lightcone.rendererId": str(render.renderer.id),
        "helix.lightcone.rendererVersion": str(render.renderer.version),
        "helix.lightcone.settingsSha256": str(settings_sha256),
        "helix.lightcone.rgbaSha256": str(rgba_sha256),
        "helix.lightcone.renderSettings": json.dumps(
            settings_payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ),
        "helix.lightcone.fingerprint": json.dumps(fp, sort_keys=True, separators=(",", ":"), ensure_ascii=False),
    }

    if extra and str(extra.get("backend") or "").lower() == "gpu":
        try:
            from .gpu_backend import lightcone_gpu_backend_receipts

            cfg = lightcone_gpu_backend_receipts()
            text["helix.lightcone.gpu.rasterMode"] = str(cfg.get("rasterMode") or "")
            text["helix.lightcone.gpu.scissorMode"] = str(cfg.get("scissorMode") or "")
            text["helix.lightcone.gpu.quadPadPx"] = str(cfg.get("quadPadPx") or "")
        except Exception:
            pass

    geo = geometry_sha256 or render.geometry_sha256
    if geo:
        text["helix.lightcone.geometrySha256"] = str(geo)

    return text
