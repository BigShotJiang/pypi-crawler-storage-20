from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Mapping

from .contract import LightconeDocument, Locus, Outcome
from .geometry import CompiledGeometry, CompiledEdge, compile_lightcone_geometry


def _encode_u32_be(x: int) -> tuple[int, int, int, int]:
    x &= 0xFFFFFFFF
    return ((x >> 24) & 255, (x >> 16) & 255, (x >> 8) & 255, x & 255)


def decode_id_u32_be(rgba: bytes, *, x: int, y: int, width: int, height: int) -> int:
    if x < 0 or y < 0 or x >= width or y >= height:
        return 0
    i = (y * width + x) * 4
    if i + 3 >= len(rgba):
        return 0
    return (rgba[i + 0] << 24) | (rgba[i + 1] << 16) | (rgba[i + 2] << 8) | rgba[i + 3]


class IdBufferRGBA8:
    def __init__(self, width: int, height: int) -> None:
        if width <= 0 or height <= 0:
            raise ValueError("width/height must be positive")
        self.width = int(width)
        self.height = int(height)
        self.pixels = bytearray(width * height * 4)

    def _idx(self, x: int, y: int) -> int:
        return (y * self.width + x) * 4

    def set_pixel(self, x: int, y: int, selection_id: int) -> None:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return
        r, g, b, a = _encode_u32_be(int(selection_id))
        i = self._idx(x, y)
        self.pixels[i + 0] = r
        self.pixels[i + 1] = g
        self.pixels[i + 2] = b
        self.pixels[i + 3] = a

    def fill_disc(self, cx: int, cy: int, r: int, selection_id: int) -> None:
        if r <= 0:
            self.set_pixel(cx, cy, selection_id)
            return
        r2 = r * r
        x0 = cx - r
        x1 = cx + r
        y0 = cy - r
        y1 = cy + r
        for y in range(y0, y1 + 1):
            dy = y - cy
            dy2 = dy * dy
            for x in range(x0, x1 + 1):
                dx = x - cx
                if dx * dx + dy2 <= r2:
                    self.set_pixel(x, y, selection_id)

    def draw_polyline(self, pts: list[tuple[int, int]], *, selection_id: int, r: int) -> None:
        if len(pts) < 2:
            return
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            self._draw_line(x0, y0, x1, y1, selection_id=selection_id, r=r)

    def _draw_line(self, x0: int, y0: int, x1: int, y1: int, *, selection_id: int, r: int) -> None:
        dx = x1 - x0
        dy = y1 - y0
        steps = max(abs(dx), abs(dy))
        if steps == 0:
            self.fill_disc(x0, y0, r, selection_id)
            return
        for i in range(steps + 1):
            t = i / steps
            x = int(round(x0 + dx * t))
            y = int(round(y0 + dy * t))
            self.fill_disc(x, y, r, selection_id)


@dataclass(frozen=True, slots=True)
class SelectionInfo:
    selection_id: int
    kind: str  # "edge" | "ghost"
    outcome_ids: tuple[str, ...]
    probability_mass: float
    dominant_outcome_id: str | None = None
    mechanism_tags: tuple[str, ...] = ()
    ghost_id: str | None = None
    ghost_locus: Locus | None = None


def build_selection_index(doc: LightconeDocument, geom: CompiledGeometry) -> dict[int, SelectionInfo]:
    oc_by_id: dict[str, Outcome] = {str(o.id): o for o in doc.outcomes}
    by_id: dict[int, SelectionInfo] = {}
    for e in geom.edges:
        sid = int(e.selection_id)
        if sid in by_id:
            continue
        leaves = tuple(str(x) for x in e.leaves)
        dominant = _dominant_leaf(leaves, oc_by_id)
        tags = oc_by_id[dominant].mechanism_tags if dominant and dominant in oc_by_id else ()
        by_id[sid] = SelectionInfo(
            selection_id=sid,
            kind="edge",
            outcome_ids=leaves,
            probability_mass=float(e.probability_mass),
            dominant_outcome_id=dominant,
            mechanism_tags=tuple(str(t) for t in tags),
        )

    # Ghost selections (off-target loci).
    if doc.off_targets and doc.render_golden is not None:
        ghosts_cfg = dict(doc.render_golden.style.ghosts)
        if bool(ghosts_cfg.get("enabled", True)):
            used: set[int] = set(by_id.keys())
            ghosts = sorted(doc.off_targets, key=lambda g: str(g.id))
            for ghost in ghosts:
                sid = stable_id_for_label_unique(f"ghost:{ghost.id}", used_ids=used)
                by_id[sid] = SelectionInfo(
                    selection_id=int(sid),
                    kind="ghost",
                    outcome_ids=(),
                    probability_mass=float(ghost.probability_mass),
                    dominant_outcome_id=None,
                    mechanism_tags=("ghost",),
                    ghost_id=str(ghost.id),
                    ghost_locus=ghost.locus,
                )
    return by_id


def _dominant_leaf(leaves: tuple[str, ...], oc_by_id: Mapping[str, Outcome]) -> str | None:
    best_id: str | None = None
    best_p = -1.0
    for oid in leaves:
        oc = oc_by_id.get(str(oid))
        if oc is None:
            continue
        p = float(oc.probability)
        if p > best_p or (p == best_p and (best_id is None or str(oid) < best_id)):
            best_id = str(oid)
            best_p = p
    return best_id


def _camera_transform_px(
    x: float,
    y: float,
    *,
    width: int,
    height: int,
    pan_px: tuple[float, float],
    zoom: float,
) -> tuple[float, float]:
    cx = width * 0.5
    cy = height * 0.5
    x2 = (x - cx) * zoom + cx + pan_px[0]
    y2 = (y - cy) * zoom + cy + pan_px[1]
    return x2, y2


def render_lightcone_id_rgba_from_golden(doc: LightconeDocument) -> bytes:
    rg = doc.render_golden
    if rg is None:
        raise ValueError("Lightcone document missing renderGolden")
    return render_lightcone_id_rgba(
        doc,
        width=rg.width,
        height=rg.height,
        phase=rg.phase,
        camera_pan_px=rg.camera.pan_px,
        camera_zoom=rg.camera.zoom,
    )


def render_lightcone_id_rgba(
    doc: LightconeDocument,
    *,
    width: int,
    height: int,
    phase: float,
    camera_pan_px: tuple[float, float],
    camera_zoom: float,
) -> bytes:
    if doc.render_golden is None:
        raise ValueError("render_lightcone_id_rgba requires doc.render_golden (style/camera invariants)")
    style = doc.render_golden.style
    if style.layout_mode != "tree_v1":
        raise ValueError("Picking requires style.layoutMode='tree_v1'")

    margin_l, margin_r, margin_t, margin_b = style.margins
    x_center = width // 2
    y_top = margin_t
    y_bottom = height - margin_b
    axis_h = max(1, y_bottom - y_top)

    def y_of_phase(p: float) -> float:
        return y_bottom - max(0.0, min(1.0, float(p))) * axis_h

    geom = compile_lightcone_geometry(
        doc,
        width=width,
        height=height,
        phase=phase,
        camera_pan_px=camera_pan_px,
        camera_zoom=camera_zoom,
    )
    y_clip = geom.y_bottom_px - float(phase) * geom.axis_h_px
    idbuf = IdBufferRGBA8(width=width, height=height)

    oc_by_id: dict[str, Outcome] = {str(o.id): o for o in doc.outcomes}
    sel_index = build_selection_index(doc, geom)
    intended_cache: dict[int, bool] = {}

    def is_intended(edge: CompiledEdge) -> bool:
        sid = int(edge.selection_id)
        if sid in intended_cache:
            return intended_cache[sid]
        for oid in edge.leaves:
            oc = oc_by_id.get(str(oid))
            if oc is None:
                continue
            if "intended" in {t.lower() for t in oc.mechanism_tags}:
                intended_cache[sid] = True
                return True
        intended_cache[sid] = False
        return False

    edges = list(geom.edges)
    # Deterministic draw order: low-mass first, intended last.
    edges.sort(key=lambda e: (is_intended(e), float(e.probability_mass), int(e.selection_id)))

    for e in edges:
        if float(phase) <= float(e.start_phase):
            continue
        pts = _bezier_points(e.p0, e.p1, e.p2, e.p3, steps=40)
        clipped: list[tuple[int, int]] = []
        for x, y in pts:
            if y >= y_clip:
                clipped.append((x, y))
        if len(clipped) < 2:
            continue
        r = max(1, int(e.radius_px))
        idbuf.draw_polyline(clipped, selection_id=int(e.selection_id), r=r)
        # Tip sample for easier picking (slightly larger).
        x_tip, y_tip = clipped[-1]
        idbuf.fill_disc(x_tip, y_tip, max(r, 2), int(e.selection_id))

    # Ghost discs are pickable (threads are not).
    ghosts_cfg = dict(style.ghosts)
    if doc.off_targets and bool(ghosts_cfg.get("enabled", True)):
        ghost_sid_by_id = {
            str(info.ghost_id): int(sid)
            for sid, info in sel_index.items()
            if info.kind == "ghost" and info.ghost_id is not None
        }
        ghosts = list(doc.off_targets)
        ghosts.sort(key=lambda g: (-float(g.probability_mass), str(g.id)))
        gx0 = margin_l
        gx1 = width - margin_r
        for idx, ghost in enumerate(ghosts):
            sid = ghost_sid_by_id.get(str(ghost.id))
            if sid is None:
                continue
            t = 0.5 if len(ghosts) == 1 else idx / (len(ghosts) - 1)
            gx = float(gx0 + t * (gx1 - gx0))
            gy = float(y_of_phase(0.05))
            gx_t, gy_t = _camera_transform_px(gx, gy, width=width, height=height, pan_px=doc.render_golden.camera.pan_px, zoom=doc.render_golden.camera.zoom)
            radius = int(ghosts_cfg.get("radiusPrime" if doc.edit_type == "prime_edit" else "radius", 5))
            idbuf.fill_disc(int(round(gx_t)), int(round(gy_t)), max(2, radius), int(sid))

    return bytes(idbuf.pixels)


def _bezier_points(p0: tuple[int, int], p1: tuple[int, int], p2: tuple[int, int], p3: tuple[int, int], steps: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for i in range(steps + 1):
        t = i / steps
        u = 1.0 - t
        x = (
            u * u * u * p0[0]
            + 3.0 * u * u * t * p1[0]
            + 3.0 * u * t * t * p2[0]
            + t * t * t * p3[0]
        )
        y = (
            u * u * u * p0[1]
            + 3.0 * u * u * t * p1[1]
            + 3.0 * u * t * t * p2[1]
            + t * t * t * p3[1]
        )
        out.append((int(round(x)), int(round(y))))
    return out


def stable_id_for_label(label: str) -> int:
    """Deterministic u32 id for non-edge selections (e.g. ghosts)."""

    h = hashlib.sha256(str(label).encode("utf-8")).digest()
    x = int.from_bytes(h[:4], "big")
    return x or 1


def stable_id_for_label_unique(label: str, *, used_ids: set[int]) -> int:
    """Like stable_id_for_label, but guarantees non-zero uniqueness vs `used_ids` deterministically."""

    base = str(label)
    for salt in range(64):
        cand = stable_id_for_label(base if salt == 0 else f"{base}#{salt}")
        cand &= 0xFFFFFFFF
        if cand == 0:
            continue
        if cand not in used_ids:
            used_ids.add(cand)
            return cand

    # Extremely unlikely fallback: linearly probe in u32 space.
    cand = stable_id_for_label(base) & 0xFFFFFFFF
    if cand == 0:
        cand = 1
    while cand in used_ids:
        cand = (cand + 1) & 0xFFFFFFFF
        if cand == 0:
            cand = 1
    used_ids.add(cand)
    return cand
