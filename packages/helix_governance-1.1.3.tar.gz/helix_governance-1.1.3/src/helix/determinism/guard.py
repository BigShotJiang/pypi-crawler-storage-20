from __future__ import annotations

import inspect
import linecache
import os
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime as _dt_datetime
from datetime import timezone as _dt_timezone
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Iterator, Mapping, MutableMapping

from helix.determinism.nondet import force_disallow_nondeterminism, nondeterminism_allowed


class ImplicitRandomnessError(RuntimeError):
    """Raised when a forbidden, implicit entropy source is used."""


_HELIX_CODE_MODULE_PREFIXES: tuple[str, ...] = ("helix", "helixspec", "helix_engine")


def _is_helix_code_module(module_name: str | None) -> bool:
    token = str(module_name or "")
    if not token:
        return False
    for prefix in _HELIX_CODE_MODULE_PREFIXES:
        if token == prefix or token.startswith(prefix + "."):
            return True
    return False


@dataclass(frozen=True)
class DeterminismEnv:
    """Deterministic runtime environment knobs.

    Note: PYTHONHASHSEED is only effective at interpreter start. `apply()` will fail
    closed if it isn't already set correctly.
    """

    @staticmethod
    def apply() -> None:
        required = {
            "PYTHONHASHSEED": "0",
            "TZ": "UTC",
            "LC_ALL": "C.UTF-8",
            "LANG": "C.UTF-8",
            # Numeric stack threading controls.
            "OMP_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "OPENBLAS_NUM_THREADS": "1",
            "NUMEXPR_NUM_THREADS": "1",
            "VECLIB_MAXIMUM_THREADS": "1",
            "BLIS_NUM_THREADS": "1",
            # Avoid parallelism-induced ordering changes in some tokenizers.
            "TOKENIZERS_PARALLELISM": "false",
            # Helix's deterministic mode flag.
            "HELIX_DETERMINISTIC": "1",
        }

        # Fail closed on PYTHONHASHSEED because it can't be changed mid-process.
        expected_hash_seed = required["PYTHONHASHSEED"]
        current_hash_seed = os.environ.get("PYTHONHASHSEED")
        if current_hash_seed != expected_hash_seed:
            raise RuntimeError(
                "DeterminismEnv.apply() requires PYTHONHASHSEED=0 at interpreter start.\n"
                f"Detected PYTHONHASHSEED={current_hash_seed!r}.\n"
                "Fix: re-run with PYTHONHASHSEED=0 (e.g., `PYTHONHASHSEED=0 python -m …`)."
            )

        os.environ.update(required)

        try:
            import locale

            try:
                locale.setlocale(locale.LC_ALL, required["LC_ALL"])
            except Exception:
                locale.setlocale(locale.LC_ALL, "C")
        except Exception:
            pass

        try:
            time.tzset()  # type: ignore[attr-defined]
        except Exception:
            pass


@contextmanager
def deterministic_context() -> Iterator[None]:
    """Apply deterministic env + RNG bans for the duration of a block."""

    required_keys = (
        "PYTHONHASHSEED",
        "TZ",
        "LC_ALL",
        "LANG",
        "OMP_NUM_THREADS",
        "MKL_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "VECLIB_MAXIMUM_THREADS",
        "BLIS_NUM_THREADS",
        "TOKENIZERS_PARALLELISM",
        "HELIX_DETERMINISTIC",
    )
    prior_env = {key: os.environ.get(key) for key in required_keys}

    prior_locale = None
    try:
        import locale

        prior_locale = locale.setlocale(locale.LC_ALL)
    except Exception:
        prior_locale = None

    with force_disallow_nondeterminism():
        DeterminismEnv.apply()
        was_installed = RngBan._installed
        RngBan.install()
        try:
            yield
        finally:
            if not was_installed:
                RngBan.uninstall()
            for key, value in prior_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                import locale

                if prior_locale is not None:
                    locale.setlocale(locale.LC_ALL, prior_locale)
            except Exception:
                pass
            try:
                time.tzset()  # type: ignore[attr-defined]
            except Exception:
                pass


def _repo_root() -> Path | None:
    try:
        path = Path(__file__).resolve()
    except Exception:
        return None
    for parent in path.parents:
        if (parent / "pyproject.toml").exists():
            return parent
        if (parent / ".git").exists():
            return parent
    return None


def _format_path(path: str) -> str:
    try:
        root = _repo_root()
        if root is None:
            return path
        resolved = Path(path).resolve()
        try:
            rel = resolved.relative_to(root)
        except Exception:
            return str(resolved)
        return rel.as_posix()
    except Exception:
        return path


def _code_snippet(path: str, lineno: int, *, context: int = 1) -> str | None:
    if not path or lineno <= 0:
        return None
    start = max(1, int(lineno) - int(context))
    end = int(lineno) + int(context)
    lines: list[str] = []
    for idx in range(start, end + 1):
        line = linecache.getline(path, idx)
        if not line:
            continue
        prefix = ">" if idx == lineno else " "
        lines.append(f"{prefix} {idx:4d} | {line.rstrip()}")
    return "\n".join(lines) if lines else None


def _first_user_frame() -> inspect.FrameInfo | None:
    stack = inspect.stack(context=0)
    try:
        this = Path(__file__).resolve()
    except Exception:
        this = None
    for frame in stack[2:]:
        filename = frame.filename
        if not filename:
            continue
        if this is not None:
            try:
                if Path(filename).resolve() == this:
                    continue
            except Exception:
                pass
        # Skip stdlib frames when possible.
        if filename.startswith("<"):
            continue
        if any(part in filename for part in ("/lib/python", "\\Lib\\", "/site-packages/", "\\site-packages\\")):
            continue
        return frame
    return stack[2] if len(stack) > 2 else None


def _stack_includes_module_prefix(prefixes: tuple[str, ...]) -> bool:
    if not prefixes:
        return False
    stack = inspect.stack(context=0)
    for frame in stack:
        mod = frame.frame.f_globals.get("__name__", "")
        mod_name = str(mod or "")
        if any(mod_name.startswith(prefix) for prefix in prefixes):
            return True
    return False


def _raise_forbidden(source: str) -> None:
    frame = _first_user_frame()
    module = ""
    func = ""
    path = ""
    lineno = 0
    if frame is not None:
        module = str(frame.frame.f_globals.get("__name__", "") or "")
        func = str(frame.function or "")
        path = str(frame.filename or "")
        lineno = int(frame.lineno or 0)

    rel = _format_path(path) if path else ""
    snippet = _code_snippet(path, lineno, context=1) if path and lineno else None

    lines: list[str] = []
    lines.append("Implicit nondeterminism is forbidden in deterministic mode.")
    lines.append(f"Banned call: {source}")
    if rel and lineno:
        lines.append(f"Call site: {rel}:{lineno} in {module}.{func}")
    elif rel:
        lines.append(f"Call site: {rel} in {module}.{func}")
    if snippet:
        lines.append("Code context:")
        lines.append(snippet)
    else:
        # Some call sites are synthetic (e.g., `exec(compile(..., filename=...))`) and do not
        # exist on disk. In those cases, include a stable, human-readable expression token.
        lines.append(f"Call expression: {source}()")
    guidance = ""
    if source.startswith(("random.", "numpy.random.", "torch.", "jax.random.")):
        guidance = "Use `helix.rng.Rng` with an explicit seed and stable `stream_id` from the run context."
    elif source.startswith(("os.listdir", "os.scandir", "os.walk", "pathlib.Path.")):
        guidance = "Use `helix.fs` helpers (iterdir_sorted / glob_sorted / rglob_sorted / walk_sorted) for stable ordering."
    elif source.startswith(("time.", "datetime.", "os.urandom", "uuid.uuid4", "secrets.", "tempfile.")):
        guidance = (
            "Use `helix.clock` / `helix.entropy` / `helix.temp` wrappers. "
            "For UI/telemetry, wrap the call site in `helix.determinism.allow_nondeterminism(reason=...)`."
        )
    else:
        guidance = "Route nondeterminism through explicit Helix wrappers (helix.clock / helix.entropy / helix.temp / helix.rng)."
    lines.append(f"Guidance: {guidance}")
    raise ImplicitRandomnessError("\n".join(lines))


def _forbidden(source: str) -> Callable[..., Any]:
    def _wrapped(*_args: Any, **_kwargs: Any) -> Any:
        _raise_forbidden(source)

    return _wrapped


def _allowed_only_from(
    original: Callable[..., Any],
    source: str,
    *,
    module_prefixes: tuple[str, ...],
) -> Callable[..., Any]:
    def _wrapped(*args: Any, **kwargs: Any) -> Any:
        if _stack_includes_module_prefix(module_prefixes):
            return original(*args, **kwargs)
        _raise_forbidden(source)

    return _wrapped


class _ForbiddenProxy:
    def __init__(self, source: str):
        self._source = str(source or "")

    def __call__(self, *_args: Any, **_kwargs: Any) -> Any:
        _raise_forbidden(self._source)

    def __getattr__(self, name: str) -> Any:
        token = str(name or "")
        suffix = f".{token}" if token else ""
        _raise_forbidden(f"{self._source}{suffix}")


class RngBan:
    _installed: bool = False
    _originals: dict[tuple[object, str], object] = {}

    @classmethod
    def install(cls) -> None:
        if cls._installed:
            return

        cls._patch_stdlib_random()
        cls._patch_os()
        cls._patch_fs_iteration()
        cls._patch_tempfile()
        cls._patch_time()
        cls._patch_datetime()
        cls._patch_uuid()
        cls._patch_secrets()
        cls._patch_numpy_random()
        cls._patch_torch()
        cls._patch_jax()

        cls._installed = True

    @classmethod
    def uninstall(cls) -> None:
        if not cls._installed:
            return
        for (owner, name), original in list(cls._originals.items()):
            try:
                setattr(owner, name, original)
            except Exception:
                pass
        cls._originals.clear()
        cls._installed = False

    @classmethod
    def _patch_attr(cls, owner: object, name: str, replacement: object) -> None:
        key = (owner, name)
        if key in cls._originals:
            return
        try:
            original = getattr(owner, name)
        except Exception:
            return
        cls._originals[key] = original
        try:
            setattr(owner, name, replacement)
        except Exception:
            cls._originals.pop(key, None)

    @classmethod
    def _patch_module_globals_ref(cls, original: object, replacement: object) -> None:
        for mod in list(sys.modules.values()):
            if not isinstance(mod, ModuleType):
                continue
            mod_name = getattr(mod, "__name__", "") or ""
            if not _is_helix_code_module(mod_name):
                continue
            try:
                items = list(vars(mod).items())
            except Exception:
                continue
            for attr, value in items:
                if value is original:
                    cls._patch_attr(mod, attr, replacement)

    @classmethod
    def _allowed_only_from_wrappers(cls, original: Callable[..., Any], source: str, *, wrappers: tuple[str, ...]) -> Callable[..., Any]:
        def _wrapped(*args: Any, **kwargs: Any) -> Any:
            caller = ""
            try:
                caller = str(sys._getframe(1).f_globals.get("__name__", "") or "")
            except Exception:
                caller = ""
            if caller and any(caller.startswith(prefix) for prefix in wrappers) and nondeterminism_allowed():
                return original(*args, **kwargs)
            if _is_helix_code_module(caller):
                _raise_forbidden(source)
            return original(*args, **kwargs)

        return _wrapped

    @classmethod
    def _allowed_only_from_modules(
        cls,
        original: Callable[..., Any],
        source: str,
        *,
        modules: tuple[str, ...],
    ) -> Callable[..., Any]:
        def _wrapped(*args: Any, **kwargs: Any) -> Any:
            caller = ""
            try:
                caller = str(sys._getframe(1).f_globals.get("__name__", "") or "")
            except Exception:
                caller = ""
            allow = False
            if caller and any(caller.startswith(prefix) for prefix in modules):
                allow = True
            if not allow:
                # Some stdlib iterators (e.g., pathlib generators) can shift the direct call site;
                # treat any allowed module in the near stack as sufficient.
                try:
                    for depth in range(2, 9):
                        mod = str(sys._getframe(depth).f_globals.get("__name__", "") or "")
                        if mod and any(mod.startswith(prefix) for prefix in modules):
                            allow = True
                            break
                except Exception:
                    allow = False

            if allow:
                return original(*args, **kwargs)
            if _is_helix_code_module(caller):
                _raise_forbidden(source)
            return original(*args, **kwargs)

        return _wrapped

    @classmethod
    def _patch_stdlib_random(cls) -> None:
        import random

        for name in (
            "random",
            "randrange",
            "randint",
            "shuffle",
            "choice",
            "sample",
            "choices",
            "uniform",
            "gauss",
            "normalvariate",
            "expovariate",
            "betavariate",
            "gammavariate",
            "lognormvariate",
            "vonmisesvariate",
            "paretovariate",
            "weibullvariate",
            "getrandbits",
            "randbytes",
            "seed",
        ):
            if hasattr(random, name):
                original = getattr(random, name)
                if callable(original):
                    replacement = cls._allowed_only_from_modules(original, f"random.{name}", modules=())
                    cls._patch_attr(random, name, replacement)
                    cls._patch_module_globals_ref(original, replacement)

        # Patch constructors by intercepting __init__ (avoid replacing the type objects,
        # which can break imports/subclassing).
        Random = getattr(random, "Random", None)
        if isinstance(Random, type):
            original_init = getattr(Random, "__init__", None)
            if callable(original_init):
                replacement_init = cls._allowed_only_from_modules(
                    original_init,
                    "random.Random",
                    modules=("helix.rng",),
                )
                cls._patch_attr(Random, "__init__", replacement_init)

    @classmethod
    def _patch_uuid(cls) -> None:
        import uuid

        cls._patch_attr(
            uuid,
            "uuid4",
            cls._allowed_only_from_wrappers(uuid.uuid4, "uuid.uuid4", wrappers=("helix.entropy",)),
        )

    @classmethod
    def _patch_secrets(cls) -> None:
        try:
            import secrets
        except Exception:
            return

        for name in ("token_bytes", "token_hex", "token_urlsafe", "choice", "randbelow"):
            if hasattr(secrets, name):
                original = getattr(secrets, name)
                if callable(original):
                    cls._patch_attr(
                        secrets,
                        name,
                        cls._allowed_only_from_wrappers(original, f"secrets.{name}", wrappers=("helix.entropy",)),
                    )

    @classmethod
    def _patch_os(cls) -> None:
        import os as os_mod

        cls._patch_attr(
            os_mod,
            "urandom",
            cls._allowed_only_from_wrappers(os_mod.urandom, "os.urandom", wrappers=("helix.entropy",)),
        )

    @classmethod
    def _patch_fs_iteration(cls) -> None:
        wrappers = ("helix.fs",)

        import os as os_mod

        for name, source in (
            ("listdir", "os.listdir"),
            ("scandir", "os.scandir"),
            ("walk", "os.walk"),
        ):
            if hasattr(os_mod, name):
                original = getattr(os_mod, name)
                if callable(original):
                    replacement = cls._allowed_only_from_modules(original, source, modules=wrappers)
                    cls._patch_attr(os_mod, name, replacement)
                    cls._patch_module_globals_ref(original, replacement)

        try:
            import pathlib
        except Exception:
            return

        for owner in (
            getattr(pathlib, "Path", None),
            getattr(pathlib, "PosixPath", None),
            getattr(pathlib, "WindowsPath", None),
        ):
            if owner is None:
                continue
            owner_dict = getattr(owner, "__dict__", {})
            for method in ("iterdir", "glob", "rglob"):
                # Avoid double-wrapping inherited methods (e.g. PosixPath inheriting Path.iterdir).
                if method in owner_dict:
                    original = getattr(owner, method)
                    if callable(original):
                        source = f"pathlib.Path.{method}"
                        replacement = cls._allowed_only_from_modules(original, source, modules=wrappers)
                        cls._patch_attr(owner, method, replacement)

    @classmethod
    def _patch_tempfile(cls) -> None:
        try:
            import tempfile
        except Exception:
            return

        wrappers = ("helix.temp",)
        for name in (
            "mkdtemp",
            "mkstemp",
            "NamedTemporaryFile",
            "TemporaryDirectory",
            "mktemp",
        ):
            if hasattr(tempfile, name):
                original = getattr(tempfile, name)
                if callable(original):
                    replacement = cls._allowed_only_from_wrappers(original, f"tempfile.{name}", wrappers=wrappers)
                    cls._patch_attr(tempfile, name, replacement)
                    cls._patch_module_globals_ref(original, replacement)

    @classmethod
    def _patch_time(cls) -> None:
        import time as time_mod

        wrappers = ("helix.clock",)
        for name in (
            "time",
            "time_ns",
            "perf_counter",
            "perf_counter_ns",
            "monotonic",
            "monotonic_ns",
        ):
            if hasattr(time_mod, name):
                original = getattr(time_mod, name)
                if callable(original):
                    replacement = cls._allowed_only_from_wrappers(original, f"time.{name}", wrappers=wrappers)
                    cls._patch_attr(time_mod, name, replacement)
                    cls._patch_module_globals_ref(original, replacement)

    @classmethod
    def _patch_datetime(cls) -> None:
        import datetime as datetime_mod

        original_datetime = getattr(datetime_mod, "datetime", None)
        if not isinstance(original_datetime, type):
            return

        base = original_datetime

        class _DeterminismDateTime(base):  # type: ignore[misc, valid-type]
            @classmethod
            def now(cls, tz: _dt_timezone | None = None) -> _dt_datetime:  # type: ignore[override]
                caller = ""
                try:
                    caller = str(sys._getframe(1).f_globals.get("__name__", "") or "")
                except Exception:
                    caller = ""
                if caller and caller.startswith("helix.clock") and nondeterminism_allowed():
                    return base.now(tz=tz)
                if _is_helix_code_module(caller):
                    _raise_forbidden("datetime.datetime.now")
                return base.now(tz=tz)

            @classmethod
            def utcnow(cls) -> _dt_datetime:  # type: ignore[override]
                caller = ""
                try:
                    caller = str(sys._getframe(1).f_globals.get("__name__", "") or "")
                except Exception:
                    caller = ""
                if caller and caller.startswith("helix.clock") and nondeterminism_allowed():
                    return base.utcnow()
                if _is_helix_code_module(caller):
                    _raise_forbidden("datetime.datetime.utcnow")
                return base.utcnow()

        cls._patch_attr(datetime_mod, "datetime", _DeterminismDateTime)
        cls._patch_module_globals_ref(base, _DeterminismDateTime)

    @classmethod
    def _patch_numpy_random(cls) -> None:
        try:
            import numpy as np  # type: ignore
        except Exception:
            return

        rng = getattr(np, "random", None)
        if rng is None:
            return

        allow_from = ("helix.rng",)
        allow_calls = {"Generator", "PCG64", "default_rng"}

        for name in dir(rng):
            if name.startswith("_"):
                continue
            try:
                value = getattr(rng, name)
            except Exception:
                continue
            if isinstance(value, ModuleType):
                cls._patch_attr(rng, name, _ForbiddenProxy(f"numpy.random.{name}"))
                continue
            if not callable(value):
                continue
            source = f"numpy.random.{name}"
            if name in allow_calls:
                cls._patch_attr(rng, name, _allowed_only_from(value, source, module_prefixes=allow_from))
            else:
                cls._patch_attr(rng, name, _forbidden(source))

    @classmethod
    def _patch_torch(cls) -> None:
        try:
            import torch  # type: ignore
        except Exception:
            return

        for name in ("rand", "randn", "randint", "bernoulli", "multinomial"):
            if hasattr(torch, name):
                cls._patch_attr(torch, name, _forbidden(f"torch.{name}"))

        # Common global-seeded generators.
        if hasattr(torch, "manual_seed"):
            cls._patch_attr(torch, "manual_seed", _forbidden("torch.manual_seed"))

    @classmethod
    def _patch_jax(cls) -> None:
        try:
            import jax  # type: ignore
            import jax.random  # type: ignore
        except Exception:
            return

        rng_mod: ModuleType = jax.random  # type: ignore[assignment]
        for name in ("PRNGKey", "key", "split", "uniform", "normal", "randint", "bernoulli", "choice"):
            if hasattr(rng_mod, name):
                cls._patch_attr(rng_mod, name, _forbidden(f"jax.random.{name}"))


def enable_from_env(
    *,
    deterministic_env_flag: str = "HELIX_DETERMINISTIC",
    forbid_random_flag: str = "HELIX_FORBID_RANDOM",
) -> None:
    """Install determinism protections when flags are set.

    This is intentionally explicit (call from entrypoints) to avoid import-time
    side effects in `helix.__init__`.
    """

    def _truthy(value: str | None) -> bool:
        return str(value or "").strip().lower() in {"1", "true", "yes", "on"}

    if _truthy(os.getenv(deterministic_env_flag)) or _truthy(os.getenv(forbid_random_flag)):
        with force_disallow_nondeterminism():
            DeterminismEnv.apply()
            RngBan.install()


__all__ = [
    "DeterminismEnv",
    "ImplicitRandomnessError",
    "RngBan",
    "deterministic_context",
    "enable_from_env",
]
