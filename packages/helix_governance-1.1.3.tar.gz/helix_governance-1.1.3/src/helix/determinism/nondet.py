from __future__ import annotations

import contextvars
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Iterator


_ALLOW_NONDETERMINISM: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "helix_allow_nondeterminism", default=False
)
_ALLOW_REASON: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "helix_allow_nondeterminism_reason", default=None
)


@dataclass(frozen=True)
class NondeterminismAllowance:
    allowed: bool
    reason: str | None = None


def nondeterminism_allowance() -> NondeterminismAllowance:
    return NondeterminismAllowance(allowed=bool(_ALLOW_NONDETERMINISM.get()), reason=_ALLOW_REASON.get())


def nondeterminism_allowed() -> bool:
    return bool(_ALLOW_NONDETERMINISM.get())


@contextmanager
def allow_nondeterminism(reason: str | None = None) -> Iterator[None]:
    """
    Explicitly allow Helix wrappers (helix.clock/helix.entropy) to access OS time/entropy.

    Direct calls to time/entropy APIs should remain forbidden when the determinism guard is active.
    """

    token_allowed = _ALLOW_NONDETERMINISM.set(True)
    token_reason = _ALLOW_REASON.set(str(reason) if reason is not None else None)
    try:
        yield
    finally:
        _ALLOW_NONDETERMINISM.reset(token_allowed)
        _ALLOW_REASON.reset(token_reason)


@contextmanager
def force_disallow_nondeterminism() -> Iterator[None]:
    """Fail-closed: disable nondeterminism allowance inside a deterministic block."""

    token_allowed = _ALLOW_NONDETERMINISM.set(False)
    token_reason = _ALLOW_REASON.set(None)
    try:
        yield
    finally:
        _ALLOW_NONDETERMINISM.reset(token_allowed)
        _ALLOW_REASON.reset(token_reason)


__all__ = [
    "NondeterminismAllowance",
    "allow_nondeterminism",
    "force_disallow_nondeterminism",
    "nondeterminism_allowance",
    "nondeterminism_allowed",
]

