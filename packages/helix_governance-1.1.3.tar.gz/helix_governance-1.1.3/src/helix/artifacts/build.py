from __future__ import annotations

import base64
import hashlib
import json
import shutil
from dataclasses import dataclass
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
from typing import Any, Mapping

from helix.artifacts.bundle import build_artifact_bundle_manifest, file_entry, write_artifact_bundle_manifest
from helix.scientific_contract import canonical_json_bytes
from helix.studio.export_evidence import run_to_evidence, write_evidence_json
from helix.studio.export_run import export_run_artifacts
from helix.studio.reports.run_report import write_single_run_report
from helix.studio.session_io import load_session

_FIXED_ZIP_DT = (2020, 1, 1, 0, 0, 0)


@dataclass(frozen=True)
class ArtifactBundleLayout:
    root: Path
    inputs_dir: Path
    session_dir: Path
    exports_dir: Path
    reports_dir: Path
    evidence_dir: Path
    governance_dir: Path
    manifest_path: Path
    config_path: Path
    session_path: Path
    support_bundle_path: Path


def init_artifact_bundle(out_dir: Path) -> ArtifactBundleLayout:
    out_dir = Path(out_dir).resolve()
    if out_dir.exists() and out_dir.is_file():
        raise RuntimeError(f"Bundle output path is a file, expected directory: {out_dir}")

    # Make bundles safe to re-run into the same output directory by removing
    # the known bundle subtrees and files. This prevents "works once then weird"
    # partner experiences (stale exports/support bundles getting re-zipped).
    for rel in ("inputs", "session", "exports", "reports", "evidence", "governance"):
        path = out_dir / rel
        if path.exists():
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
    for rel in ("manifest.json", "support_bundle.zip"):
        path = out_dir / rel
        if path.exists() and path.is_file():
            path.unlink()

    inputs_dir = out_dir / "inputs"
    session_dir = out_dir / "session"
    exports_dir = out_dir / "exports"
    reports_dir = out_dir / "reports"
    evidence_dir = out_dir / "evidence"
    governance_dir = out_dir / "governance"
    for path in (inputs_dir, session_dir, exports_dir, reports_dir, evidence_dir, governance_dir):
        path.mkdir(parents=True, exist_ok=True)
    return ArtifactBundleLayout(
        root=out_dir,
        inputs_dir=inputs_dir,
        session_dir=session_dir,
        exports_dir=exports_dir,
        reports_dir=reports_dir,
        evidence_dir=evidence_dir,
        governance_dir=governance_dir,
        manifest_path=out_dir / "manifest.json",
        config_path=inputs_dir / "config.json",
        session_path=session_dir / "session.helix.json",
        support_bundle_path=out_dir / "support_bundle.zip",
    )


def populate_artifact_bundle(
    *,
    layout: ArtifactBundleLayout,
    backend: str,
    run_id: str | None = None,
    include_support_bundle: bool = False,
    include_sequence_in_evidence: bool = False,
    sign: bool = False,
    signing_key: str | Path | None = None,
    license_path: str | Path | None = None,
    edit_program_id: str | None = None,
) -> Path:
    """Populate `exports/`, `reports/`, `evidence/`, then write `manifest.json`."""

    session = load_session(layout.session_path)
    runs = list(session.runs)
    if run_id is not None:
        runs = [r for r in runs if str(getattr(r, "run_id", "")) == run_id]
        if not runs:
            available = ", ".join(sorted(str(getattr(r, "run_id", "")) for r in session.runs))
            raise RuntimeError(f"Run '{run_id}' not found in session. Available run_ids: {available or '<none>'}")

    export_paths: list[Path] = []
    report_paths: list[Path] = []
    evidence_paths: list[Path] = []
    for run in runs:
        json_path, png_path = export_run_artifacts(run, layout.exports_dir, governance_signing=bool(sign))
        export_paths.extend([json_path, png_path])
        png_sidecar = png_path.with_name(png_path.name + ".provenance.json")
        if png_sidecar.exists():
            export_paths.append(png_sidecar)
        species_path = layout.exports_dir / f"{run.run_id}.species_detection_v1.json"
        if species_path.exists():
            export_paths.append(species_path)

        report_paths.append(write_single_run_report(run, layout.reports_dir, chart_png=png_path.read_bytes()))

        evidence = run_to_evidence(run, preset=None, include_sequence=include_sequence_in_evidence)
        evidence_path = layout.evidence_dir / f"{run.run_id}.evidence.json"
        write_evidence_json(evidence, evidence_path, governance_signing=bool(sign))
        evidence_paths.append(evidence_path)

    license_json_path: Path | None = None
    attestation_path: Path | None = None
    if sign:
        if signing_key is None:
            raise RuntimeError("signing_key is required when sign=True")

        # Governance signing is license-gated; never phone-home.
        from helix.licensing import require_capability

        resolved_edit_program_id = str(edit_program_id or "").strip() or None
        try:
            spec = getattr(session.state, "experiment_spec", None)
            if isinstance(spec, Mapping):
                cand = str(spec.get("experimentId") or "").strip()
                if cand and cand != "unset":
                    resolved_edit_program_id = cand
        except Exception:
            pass

        lic = require_capability("sign", edit_program_id=resolved_edit_program_id, license_path=license_path)
        if not lic.signing_keys:
            raise RuntimeError("license missing signing_keys (cannot verify signer identity)")

        layout.governance_dir.mkdir(parents=True, exist_ok=True)
        license_json_path = layout.governance_dir / "license.json"
        license_json_path.write_text(json.dumps(lic.raw, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    support_bundle_path: Path | None = None
    if include_support_bundle:
        from helix.support.bundle import write_support_bundle

        write_support_bundle(
            layout.support_bundle_path,
            session_path=str(layout.session_path),
            redact=True,
            max_log_lines=0,
            max_log_files=0,
        )
        support_bundle_path = layout.support_bundle_path

    entries = [
        file_entry(root=layout.root, path=layout.config_path, kind="input.config", role="run_config"),
        file_entry(root=layout.root, path=layout.session_path, kind="session.helix", role="session"),
    ]
    entries.extend(file_entry(root=layout.root, path=p, kind="export") for p in export_paths)
    entries.extend(file_entry(root=layout.root, path=p, kind="report.html") for p in report_paths)
    entries.extend(file_entry(root=layout.root, path=p, kind="evidence") for p in evidence_paths)
    if license_json_path is not None:
        entries.append(file_entry(root=layout.root, path=license_json_path, kind="license", role="governance"))
    if support_bundle_path is not None:
        entries.append(file_entry(root=layout.root, path=support_bundle_path, kind="support_bundle.zip", role="support"))

    manifest = build_artifact_bundle_manifest(
        root=layout.root,
        entries=entries,
        extra_metadata={
            "backend": backend,
            "run_id": run_id,
        },
    )
    write_artifact_bundle_manifest(manifest, layout.manifest_path)

    if sign:
        from helix.licensing import require_capability
        from helix.licensing.verify import CANONICALIZATION_ID, read_private_key_raw, sign_ed25519

        resolved_edit_program_id = str(edit_program_id or "").strip() or None
        try:
            spec = getattr(session.state, "experiment_spec", None)
            if isinstance(spec, Mapping):
                cand = str(spec.get("experimentId") or "").strip()
                if cand and cand != "unset":
                    resolved_edit_program_id = cand
        except Exception:
            pass

        lic = require_capability("sign", edit_program_id=resolved_edit_program_id, license_path=license_path)
        sk_path = Path(signing_key) if signing_key is not None else None
        if sk_path is None:
            raise RuntimeError("signing_key is required when sign=True")

        sk_raw = read_private_key_raw(sk_path)
        attestation_unsigned: dict[str, Any] = {
            "schema": "helix-governance-attestation.v1",
            "bundle": {
                "bundle_id": str(manifest.get("bundle_id") or ""),
                "bundle_sha256": str(manifest.get("bundle_sha256") or ""),
                "manifest_sha256": f"sha256:{str(manifest.get('manifest_sha256') or '')}",
            },
            "license": {
                "license_id": str(lic.license_id),
                "license_sha256": str(lic.license_sha256),
                "org": str(lic.org),
                "edit_program_id": str(lic.edit_program_id),
            },
            "signature": None,
        }
        msg = canonical_json_bytes(attestation_unsigned)
        signed_sha = f"sha256:{hashlib.sha256(msg).hexdigest()}"
        sig_raw, pk_raw = sign_ed25519(msg, private_key_raw=sk_raw)

        # Ensure the signing key is authorized by the license.
        if pk_raw not in {k.public_key_raw for k in lic.signing_keys}:
            raise RuntimeError("signing key is not authorized by this license")

        attestation = dict(attestation_unsigned)
        attestation["signature"] = {
            "algorithm": "ed25519",
            "canonicalization": CANONICALIZATION_ID,
            "publicKeyB64": base64.b64encode(pk_raw).decode("ascii"),
            "signatureB64": base64.b64encode(sig_raw).decode("ascii"),
            "signedPayloadSha256": signed_sha,
        }
        attestation_path = layout.governance_dir / "attestation.json"
        attestation_path.write_text(json.dumps(attestation, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    return layout.manifest_path


def zip_dir(src: Path, out_zip: Path, *, export_kind: str = "artifact_bundle_zip") -> None:
    """Write a deterministic zip of `src` (stable timestamps/permissions)."""

    src = Path(src)
    out_zip = Path(out_zip)
    out_zip.parent.mkdir(parents=True, exist_ok=True)

    # Official exports should route through governance policy gates.
    should_gate = False
    try:
        manifest_path = src / "manifest.json"
        if manifest_path.exists() and manifest_path.is_file():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            schema = manifest.get("schema") if isinstance(manifest, dict) else {}
            should_gate = bool(isinstance(schema, dict) and str(schema.get("kind") or "") == "helix.artifact_bundle")
    except Exception:
        should_gate = False
    if should_gate:
        from helix.governance.enforce import require_official_export_allowed

        require_official_export_allowed(src, export_kind=str(export_kind or "artifact_bundle_zip"))

    with ZipFile(out_zip, mode="w") as zf:
        for path in sorted(src.rglob("*")):
            if path.is_dir():
                continue
            rel = path.relative_to(src).as_posix()
            info = ZipInfo(rel, date_time=_FIXED_ZIP_DT)
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, path.read_bytes())


__all__ = ["ArtifactBundleLayout", "init_artifact_bundle", "populate_artifact_bundle", "zip_dir"]
