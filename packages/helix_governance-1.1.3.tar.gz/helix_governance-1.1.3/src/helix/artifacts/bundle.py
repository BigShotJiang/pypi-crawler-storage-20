from __future__ import annotations

import hashlib
import json
import os
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from helix import clock
from helix import __version__ as helix_version
from helix.provenance import current_git_sha
from helix.schema import SPEC_VERSION


class ArtifactBundleError(RuntimeError):
    """Raised when artifact bundle operations fail."""


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _canonical_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True)
class ArtifactEntry:
    path: str
    sha256: str
    size: int
    kind: str
    role: str | None = None


def file_entry(*, root: Path, path: Path, kind: str, role: str | None = None) -> ArtifactEntry:
    """Create an ArtifactEntry for a file under `root`."""

    root = Path(root).resolve()
    file_path = Path(path).resolve()
    try:
        rel = file_path.relative_to(root).as_posix()
    except ValueError as exc:
        raise ArtifactBundleError(f"File is outside bundle root: {file_path}") from exc
    return ArtifactEntry(
        path=rel,
        sha256=sha256_path(file_path),
        size=file_path.stat().st_size,
        kind=kind,
        role=role,
    )


def _bundle_digest(entries: Iterable[ArtifactEntry]) -> str:
    digest = hashlib.sha256()
    for entry in sorted(entries, key=lambda e: e.path):
        digest.update(entry.path.encode("utf-8"))
        digest.update(entry.sha256.encode("utf-8"))
    return digest.hexdigest()


def _default_bundle_id(bundle_sha256: str) -> str:
    return f"helix_bundle_{str(bundle_sha256)[:12]}"


def build_artifact_bundle_manifest(
    *,
    root: Path,
    entries: Iterable[ArtifactEntry],
    bundle_id: str | None = None,
    created_at_utc: str | None = None,
    extra_metadata: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a deterministic, content-addressed manifest for a bundle directory.

    The manifest is designed to be stable across platforms and to support
    "evidence bundles" that can be emailed or attached to support tickets.
    """

    normalized_entries = list(entries)
    bundle_sha256 = _bundle_digest(normalized_entries)
    manifest: dict[str, Any] = {
        "artifact_spec": "1.0.0",
        "schema": {"kind": "helix.artifact_bundle", "version": 1},
        "bundle_id": bundle_id or _default_bundle_id(bundle_sha256),
        "created_at_utc": created_at_utc or _utc_now_iso(),
        "bundle_sha256": bundle_sha256,
        "helix_version": helix_version,
        "schema_version": f"helix.schema/{SPEC_VERSION}",
        "git_sha": (current_git_sha() or ""),
        "platform": {
            "os": os.name,
        },
        "entries": [
            {
                "path": e.path,
                "sha256": e.sha256,
                "size": e.size,
                "kind": e.kind,
                **({"role": e.role} if e.role else {}),
            }
            for e in sorted(normalized_entries, key=lambda e: e.path)
        ],
        "metadata": dict(extra_metadata or {}),
    }

    manifest_copy = dict(manifest)
    manifest_copy.pop("manifest_sha256", None)
    manifest["manifest_sha256"] = _sha256_bytes(_canonical_bytes(manifest_copy))
    return manifest


def write_artifact_bundle_manifest(manifest: Mapping[str, Any], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path


def load_artifact_bundle_manifest(bundle_path: Path) -> dict[str, Any]:
    """Load manifest.json from a bundle directory or a zipped bundle."""

    bundle_path = Path(bundle_path)
    if bundle_path.is_dir():
        manifest_path = bundle_path / "manifest.json"
        if not manifest_path.exists():
            raise ArtifactBundleError(f"manifest.json not found in bundle dir: {bundle_path}")
        return json.loads(manifest_path.read_text(encoding="utf-8"))
    if bundle_path.is_file() and bundle_path.suffix.lower() in {".zip", ".hxs"}:
        with zipfile.ZipFile(bundle_path, "r") as zf:
            try:
                raw = zf.read("manifest.json")
            except KeyError as exc:
                raise ArtifactBundleError(f"manifest.json not found in bundle: {bundle_path}") from exc
        return json.loads(raw.decode("utf-8"))
    raise ArtifactBundleError(f"Unsupported bundle path (expected dir or .zip/.hxs): {bundle_path}")
