"""Artifact bundle helpers (shareable, manifested evidence outputs)."""

from .bundle import (
    ArtifactBundleError,
    build_artifact_bundle_manifest,
    file_entry,
    load_artifact_bundle_manifest,
    sha256_path,
    write_artifact_bundle_manifest,
)

from importlib import import_module
from typing import Any

_LAZY_EXPORTS = {
    "ArtifactBundleLayout": ("helix.artifacts.build", "ArtifactBundleLayout"),
    "init_artifact_bundle": ("helix.artifacts.build", "init_artifact_bundle"),
    "populate_artifact_bundle": ("helix.artifacts.build", "populate_artifact_bundle"),
    "zip_dir": ("helix.artifacts.build", "zip_dir"),
}


def __getattr__(name: str) -> Any:  # pragma: no cover - exercised via imports
    target = _LAZY_EXPORTS.get(name)
    if target is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_name, attr_name = target
    module = import_module(module_name)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value

__all__ = [
    "ArtifactBundleLayout",
    "ArtifactBundleError",
    "build_artifact_bundle_manifest",
    "file_entry",
    "init_artifact_bundle",
    "load_artifact_bundle_manifest",
    "populate_artifact_bundle",
    "sha256_path",
    "write_artifact_bundle_manifest",
    "zip_dir",
]
