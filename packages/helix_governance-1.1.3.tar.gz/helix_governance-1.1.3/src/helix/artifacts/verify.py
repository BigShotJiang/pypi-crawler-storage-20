from __future__ import annotations

import hashlib
import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from helix.artifacts.bundle import ArtifactBundleError, load_artifact_bundle_manifest
from helix.governance.errors import (
    ATTESTATION_INVALID,
    LICENSE_INVALID,
    LICENSE_SCOPE_MISMATCH,
    MANIFEST_MISMATCH,
    GovernanceIssue,
)
from helix.licensing.license import HelixLicenseV1, parse_license_v1
from helix.licensing.verify import verify_ed25519_signature


class ArtifactBundleVerificationError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class ArtifactBundleVerificationResult:
    ok: bool
    issues: tuple[GovernanceIssue, ...]
    manifest: dict[str, Any] | None = None
    license: dict[str, Any] | None = None
    attestation: dict[str, Any] | None = None

    @property
    def errors(self) -> list[str]:
        return [f"{issue.code}: {issue.message}" for issue in self.issues]


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_manifest_bytes(payload: Mapping[str, Any]) -> bytes:
    # Must match helix.artifacts.bundle._canonical_bytes (no trailing newline).
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _bundle_digest(entries: list[Mapping[str, Any]]) -> str:
    digest = hashlib.sha256()
    for entry in sorted(entries, key=lambda e: str(e.get("path") or "")):
        digest.update(str(entry.get("path") or "").encode("utf-8"))
        digest.update(str(entry.get("sha256") or "").encode("utf-8"))
    return digest.hexdigest()


def _parse_utc(ts: str) -> datetime:
    text = str(ts or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _validate_relpath(rel: str) -> None:
    token = str(rel or "")
    if not token:
        raise ArtifactBundleVerificationError("entry path is empty")
    if token.startswith(("/", "\\")):
        raise ArtifactBundleVerificationError(f"entry path is absolute: {token!r}")
    parts = token.replace("\\", "/").split("/")
    if any(p in {"", ".", ".."} for p in parts):
        raise ArtifactBundleVerificationError(f"entry path is not normalized: {token!r}")


def _read_manifest_payload(bundle_path: Path) -> tuple[dict[str, Any], str]:
    """
    Return (manifest, mode) where mode is:
      - "dir": bundle directory
      - "zip": zipped bundle (.zip/.hxs)
    """

    bundle_path = Path(bundle_path)
    if bundle_path.is_file() and bundle_path.name == "manifest.json":
        try:
            payload = json.loads(bundle_path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise ArtifactBundleVerificationError(f"failed to read manifest.json: {bundle_path}") from exc
        if not isinstance(payload, dict):
            raise ArtifactBundleVerificationError("manifest.json must be a JSON object")
        return payload, "dir"

    try:
        manifest = load_artifact_bundle_manifest(bundle_path)
    except ArtifactBundleError as exc:
        raise ArtifactBundleVerificationError(str(exc)) from exc
    if not isinstance(manifest, dict):
        raise ArtifactBundleVerificationError("manifest must be a JSON object")

    if bundle_path.is_dir():
        return manifest, "dir"
    return manifest, "zip"


def _read_file_bytes(bundle_path: Path, mode: str, rel: str) -> bytes:
    _validate_relpath(rel)

    bundle_path = Path(bundle_path)
    if bundle_path.is_file() and bundle_path.name == "manifest.json":
        bundle_path = bundle_path.parent
        mode = "dir"

    if mode == "dir":
        root = bundle_path
        abs_path = (root / rel).resolve()
        root_resolved = root.resolve()
        if not abs_path.is_relative_to(root_resolved):
            raise ArtifactBundleVerificationError(f"entry path escapes bundle root: {rel!r}")
        if not abs_path.exists() or not abs_path.is_file():
            raise ArtifactBundleVerificationError(f"missing entry file: {rel}")
        return abs_path.read_bytes()

    if mode == "zip":
        if not bundle_path.is_file():
            raise ArtifactBundleVerificationError(f"bundle zip not found: {bundle_path}")
        with zipfile.ZipFile(bundle_path, "r") as zf:
            try:
                return zf.read(rel)
            except KeyError as exc:
                raise ArtifactBundleVerificationError(f"missing entry file in zip: {rel}") from exc

    raise ArtifactBundleVerificationError(f"unsupported bundle mode: {mode!r}")


def _parse_license_from_bundle(bundle_path: Path, mode: str, rel: str) -> tuple[HelixLicenseV1, dict[str, Any]]:
    raw = _read_file_bytes(bundle_path, mode, rel)
    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise ArtifactBundleVerificationError("governance/license.json is not valid JSON") from exc
    if not isinstance(payload, Mapping):
        raise ArtifactBundleVerificationError("governance/license.json must be a JSON object")
    lic = parse_license_v1(payload)
    return lic, dict(payload)


def verify_artifact_bundle(
    bundle_path: str | Path,
    *,
    require_signed: bool = True,
) -> ArtifactBundleVerificationResult:
    """
    Verify a bundle directory or zipped bundle (.zip/.hxs).

    Notes:
      - This verifier never checks for a local license file.
      - When require_signed=True, unsigned bundles are treated as FAIL.
    """

    path = Path(bundle_path)
    issues: list[GovernanceIssue] = []
    license_payload: dict[str, Any] | None = None
    attestation_payload: dict[str, Any] | None = None
    license_obj: HelixLicenseV1 | None = None

    try:
        manifest, mode = _read_manifest_payload(path)
    except Exception as exc:
        issues.append(GovernanceIssue(code=MANIFEST_MISMATCH, details={"reason": "MANIFEST_READ_FAILED", "error": str(exc)}))
        return ArtifactBundleVerificationResult(ok=False, issues=tuple(issues), manifest=None)

    schema = manifest.get("schema") if isinstance(manifest.get("schema"), Mapping) else {}
    kind = schema.get("kind") if isinstance(schema, Mapping) else None
    version = schema.get("version") if isinstance(schema, Mapping) else None
    if not (kind == "helix.artifact_bundle" and (version == 1 or str(version) == "1")):
        issues.append(
            GovernanceIssue(
                code=MANIFEST_MISMATCH,
                details={
                    "reason": "MANIFEST_SCHEMA_MISMATCH",
                    "expected_kind": "helix.artifact_bundle",
                    "expected_version": 1,
                    "kind": kind,
                    "version": version,
                },
            )
        )

    entries_raw = manifest.get("entries")
    entries: list[Mapping[str, Any]] = []
    if not isinstance(entries_raw, list):
        issues.append(GovernanceIssue(code=MANIFEST_MISMATCH, details={"reason": "MANIFEST_ENTRIES_INVALID"}))
    else:
        for item in entries_raw:
            if isinstance(item, Mapping):
                entries.append(item)
            else:
                issues.append(GovernanceIssue(code=MANIFEST_MISMATCH, details={"reason": "MANIFEST_ENTRIES_INVALID_ITEM"}))

    # Verify manifest self-hash.
    try:
        manifest_copy = dict(manifest)
        manifest_copy.pop("manifest_sha256", None)
        expected = str(manifest.get("manifest_sha256") or "")
        computed = _sha256_hex(_canonical_manifest_bytes(manifest_copy))
        if expected != computed:
            issues.append(
                GovernanceIssue(
                    code=MANIFEST_MISMATCH,
                    details={"reason": "MANIFEST_SHA256_MISMATCH", "expected": expected, "computed": computed},
                )
            )
    except Exception as exc:
        issues.append(GovernanceIssue(code=MANIFEST_MISMATCH, details={"reason": "MANIFEST_SHA256_VERIFY_FAILED", "error": str(exc)}))

    # Verify bundle digest (path+sha over entries).
    try:
        expected_bundle = str(manifest.get("bundle_sha256") or "")
        computed_bundle = _bundle_digest(entries)
        if expected_bundle != computed_bundle:
            issues.append(
                GovernanceIssue(
                    code=MANIFEST_MISMATCH,
                    details={"reason": "BUNDLE_SHA256_MISMATCH", "expected": expected_bundle, "computed": computed_bundle},
                )
            )
    except Exception as exc:
        issues.append(GovernanceIssue(code=MANIFEST_MISMATCH, details={"reason": "BUNDLE_SHA256_VERIFY_FAILED", "error": str(exc)}))

    # Verify each entry hash/size.
    for entry in sorted(entries, key=lambda e: str(e.get("path") or "")):
        rel = str(entry.get("path") or "")
        try:
            data = _read_file_bytes(path, mode, rel)
        except Exception as exc:
            issues.append(GovernanceIssue(code=MANIFEST_MISMATCH, details={"reason": "ENTRY_READ_FAILED", "path": rel, "error": str(exc)}))
            continue

        expected_sha = str(entry.get("sha256") or "")
        computed_sha = _sha256_hex(data)
        if expected_sha != computed_sha:
            issues.append(
                GovernanceIssue(
                    code=MANIFEST_MISMATCH,
                    details={"reason": "ENTRY_SHA256_MISMATCH", "path": rel, "expected": expected_sha, "computed": computed_sha},
                )
            )

        expected_size = entry.get("size")
        if isinstance(expected_size, int) and expected_size != len(data):
            issues.append(
                GovernanceIssue(
                    code=MANIFEST_MISMATCH,
                    details={"reason": "ENTRY_SIZE_MISMATCH", "path": rel, "expected": expected_size, "computed": len(data)},
                )
            )

    if require_signed:
        license_entry = next((e for e in entries if str(e.get("path") or "") == "governance/license.json"), None)
        if license_entry is None:
            issues.append(GovernanceIssue(code=LICENSE_INVALID, details={"reason": "LICENSE_MISSING_IN_BUNDLE"}))
        else:
            try:
                lic, license_payload = _parse_license_from_bundle(path, mode, "governance/license.json")
                license_obj = lic
                if "sign" not in lic.capabilities:
                    issues.append(GovernanceIssue(code=LICENSE_SCOPE_MISMATCH, details={"reason": "CAPABILITY_NOT_GRANTED", "capability": "sign"}))

                # Enforce that the manifest creation time was within the licensed window.
                try:
                    created_at = _parse_utc(str(manifest.get("created_at_utc") or ""))
                    nb = _parse_utc(str(lic.not_before_utc))
                    na = _parse_utc(str(lic.not_after_utc))
                    if not (nb <= created_at <= na):
                        issues.append(
                            GovernanceIssue(
                                code=LICENSE_INVALID,
                                details={
                                    "reason": "MANIFEST_CREATED_OUTSIDE_LICENSE_WINDOW",
                                    "created_at_utc": str(manifest.get("created_at_utc") or ""),
                                    "not_before_utc": str(lic.not_before_utc),
                                    "not_after_utc": str(lic.not_after_utc),
                                },
                            )
                        )
                except Exception:
                    issues.append(GovernanceIssue(code=LICENSE_INVALID, details={"reason": "MANIFEST_CREATED_AT_INVALID"}))
            except Exception as exc:
                code = getattr(exc, "code", None)
                details = getattr(exc, "details", None)
                if isinstance(code, str) and isinstance(details, dict):
                    issues.append(GovernanceIssue(code=code, details={"reason": "LICENSE_INVALID_IN_BUNDLE", **details}))
                else:
                    issues.append(GovernanceIssue(code=LICENSE_INVALID, details={"reason": "LICENSE_INVALID_IN_BUNDLE", "error": str(exc)}))
                license_obj = None

            try:
                raw = _read_file_bytes(path, mode, "governance/attestation.json")
                attestation = json.loads(raw.decode("utf-8"))
                if not isinstance(attestation, Mapping):
                    raise ArtifactBundleVerificationError("governance/attestation.json must be a JSON object")
                attestation_payload = dict(attestation)
            except Exception as exc:
                issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_LOAD_FAILED", "error": str(exc)}))
                attestation_payload = None

            if license_payload is not None and license_obj is not None and attestation_payload is not None:
                # Verify attestation invariants before signature.
                if str(attestation_payload.get("schema") or "") != "helix-governance-attestation.v1":
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_SCHEMA_MISMATCH"}))

                bundle_block = (
                    attestation_payload.get("bundle")
                    if isinstance(attestation_payload.get("bundle"), Mapping)
                    else {}
                )
                if str(bundle_block.get("bundle_id") or "") != str(manifest.get("bundle_id") or ""):
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_BUNDLE_ID_MISMATCH"}))
                if str(bundle_block.get("bundle_sha256") or "") != str(manifest.get("bundle_sha256") or ""):
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_BUNDLE_SHA256_MISMATCH"}))
                expected_manifest_sha = f"sha256:{str(manifest.get('manifest_sha256') or '')}"
                if str(bundle_block.get("manifest_sha256") or "") != expected_manifest_sha:
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_MANIFEST_SHA256_MISMATCH"}))

                lic_block = (
                    attestation_payload.get("license")
                    if isinstance(attestation_payload.get("license"), Mapping)
                    else {}
                )
                if str(lic_block.get("license_id") or "") != str(license_payload.get("license_id") or ""):
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_LICENSE_ID_MISMATCH"}))
                if str(lic_block.get("license_sha256") or "") != str(getattr(license_obj, "license_sha256", "")):
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_LICENSE_SHA256_MISMATCH"}))
                if str(lic_block.get("org") or "") != str(license_payload.get("org") or ""):
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_ORG_MISMATCH"}))
                if str(lic_block.get("edit_program_id") or "") != str(license_payload.get("edit_program_id") or ""):
                    issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_EDIT_PROGRAM_ID_MISMATCH"}))

                # Verify signature against the license-authorized signing keys.
                if license_obj.signing_keys:
                    try:
                        allowed = [k.public_key_raw for k in license_obj.signing_keys]
                        verify_ed25519_signature(
                            attestation_payload,
                            allowed_public_keys_raw=allowed,
                            require_allowed_key=True,
                        )
                    except Exception as exc:
                        code = getattr(exc, "code", None)
                        details = getattr(exc, "details", None)
                        if isinstance(code, str) and isinstance(details, dict):
                            issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_SIGNATURE_INVALID", "cause": {"code": code, "details": details}}))
                        else:
                            issues.append(GovernanceIssue(code=ATTESTATION_INVALID, details={"reason": "ATTESTATION_SIGNATURE_INVALID", "error": str(exc)}))
                else:
                    issues.append(GovernanceIssue(code=LICENSE_INVALID, details={"reason": "LICENSE_SIGNING_KEYS_MISSING"}))

    ok = not issues
    return ArtifactBundleVerificationResult(
        ok=bool(ok),
        issues=tuple(issues),
        manifest=dict(manifest),
        license=license_payload,
        attestation=attestation_payload,
    )


__all__ = [
    "ArtifactBundleVerificationError",
    "ArtifactBundleVerificationResult",
    "verify_artifact_bundle",
]
