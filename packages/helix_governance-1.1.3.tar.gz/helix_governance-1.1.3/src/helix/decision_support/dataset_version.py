from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence, TypedDict

from helix import clock
from helix.scientific_contract import canonical_json_bytes


class FastqFileRecord(TypedDict):
    path: str
    sha256: str
    bytes: int


class DatasetVersionInputs(TypedDict, total=False):
    fastq_files: list[FastqFileRecord]
    pipeline_digest: str
    metadata: dict[str, Any]


class DatasetVersionRecordV0(TypedDict):
    schema_version: str
    dataset_version_hash: str
    hash_algorithm: str
    canonicalization: str
    computed_at_utc: str
    inputs: DatasetVersionInputs


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _normalize_path(path: str) -> str:
    return str(path).replace("\\", "/").lstrip("./")


def _normalize_fastq_files(files: Iterable[Mapping[str, Any]]) -> list[FastqFileRecord]:
    out: list[FastqFileRecord] = []
    for f in files:
        p = _normalize_path(str(f.get("path") or ""))
        sha = str(f.get("sha256") or "").strip()
        size = int(f.get("bytes") or 0)
        if not p or not sha.startswith("sha256:") or len(sha) != len("sha256:") + 64:
            raise ValueError("fastq_files[] must include {path, sha256:<64>, bytes}")
        out.append({"path": p, "sha256": sha.lower(), "bytes": size})
    out.sort(key=lambda r: r["path"])
    return out


def compute_dataset_version_hash(*, fastq_files: Sequence[Mapping[str, Any]], pipeline_digest: str) -> str:
    files = _normalize_fastq_files(fastq_files)
    material = {"fastq_files": files, "pipeline_digest": str(pipeline_digest)}
    digest = hashlib.sha256(canonical_json_bytes(material)).hexdigest()
    return f"sha256:{digest}"


def build_dataset_version_record(
    *,
    fastq_files: Sequence[Mapping[str, Any]],
    pipeline_digest: str,
    metadata: Mapping[str, Any] | None = None,
) -> DatasetVersionRecordV0:
    files = _normalize_fastq_files(fastq_files)
    record_inputs: DatasetVersionInputs = {"fastq_files": files, "pipeline_digest": str(pipeline_digest)}
    if metadata is not None:
        record_inputs["metadata"] = dict(metadata)
    return {
        "schema_version": "dataset_version_v0",
        "dataset_version_hash": compute_dataset_version_hash(fastq_files=files, pipeline_digest=pipeline_digest),
        "hash_algorithm": "sha256",
        "canonicalization": "helix.canonical_json_bytes.v1",
        "computed_at_utc": _utc_now_iso(),
        "inputs": record_inputs,
    }


def recompute_dataset_version_hash(record: Mapping[str, Any]) -> str:
    inputs = record.get("inputs")
    if not isinstance(inputs, Mapping):
        raise ValueError("dataset_version.inputs missing")
    files = inputs.get("fastq_files")
    digest = inputs.get("pipeline_digest")
    if not isinstance(files, Sequence) or not isinstance(digest, str):
        raise ValueError("dataset_version.inputs must include fastq_files[] and pipeline_digest")
    return compute_dataset_version_hash(fastq_files=files, pipeline_digest=digest)


__all__ = [
    "DatasetVersionInputs",
    "DatasetVersionRecordV0",
    "FastqFileRecord",
    "build_dataset_version_record",
    "compute_dataset_version_hash",
    "recompute_dataset_version_hash",
]
