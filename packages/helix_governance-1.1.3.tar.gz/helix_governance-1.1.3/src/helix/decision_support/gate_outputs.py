from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class Gate0Outcome:
    outcome_id: str
    score: float
    rank: int
    label: str | None = None


@dataclass(frozen=True, slots=True)
class Gate0Outputs:
    schema_version: Literal["gate0_v0"] = "gate0_v0"
    gate_level: Literal[0] = 0
    outcome_value_label: Literal["score"] = "score"
    outcomes: tuple[Gate0Outcome, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "gate_level": int(self.gate_level),
            "outcome_value_label": self.outcome_value_label,
            "outcomes": [
                {
                    "outcome_id": o.outcome_id,
                    "score": float(o.score),
                    "rank": int(o.rank),
                    "label": o.label,
                }
                for o in self.outcomes
            ],
        }


@dataclass(frozen=True, slots=True)
class Gate1Outcome(Gate0Outcome):
    pass


@dataclass(frozen=True, slots=True)
class Gate1Outputs:
    schema_version: Literal["gate1_v0"] = "gate1_v0"
    gate_level: Literal[1] = 1
    outcome_value_label: Literal["score"] = "score"
    outcomes: tuple[Gate1Outcome, ...] = ()
    baseline_metrics: Mapping[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "schema_version": self.schema_version,
            "gate_level": int(self.gate_level),
            "outcome_value_label": self.outcome_value_label,
            "outcomes": [
                {
                    "outcome_id": o.outcome_id,
                    "score": float(o.score),
                    "rank": int(o.rank),
                    "label": o.label,
                }
                for o in self.outcomes
            ],
        }
        if self.baseline_metrics is not None:
            payload["baseline_metrics"] = dict(self.baseline_metrics)
        return payload


@dataclass(frozen=True, slots=True)
class Gate2CI95:
    lower: float
    upper: float


@dataclass(frozen=True, slots=True)
class Gate2Outcome:
    outcome_id: str
    probability: float
    ci95: Gate2CI95
    rank: int
    label: str | None = None


@dataclass(frozen=True, slots=True)
class Gate2Outputs:
    schema_version: Literal["gate2_v0"] = "gate2_v0"
    gate_level: Literal[2] = 2
    outcome_value_label: Literal["probability"] = "probability"
    outcomes: tuple[Gate2Outcome, ...] = ()
    baseline_metrics: Mapping[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": self.schema_version,
            "gate_level": int(self.gate_level),
            "outcome_value_label": self.outcome_value_label,
            "outcomes": [
                {
                    "outcome_id": o.outcome_id,
                    "probability": float(o.probability),
                    "ci95": {"lower": float(o.ci95.lower), "upper": float(o.ci95.upper)},
                    "rank": int(o.rank),
                    "label": o.label,
                }
                for o in self.outcomes
            ],
        }
        if self.baseline_metrics is not None:
            payload["baseline_metrics"] = dict(self.baseline_metrics)
        return payload


def outputs_has_baseline_metrics(outputs: Mapping[str, Any]) -> bool:
    return isinstance(outputs.get("baseline_metrics"), Mapping)


def outputs_gate_level(outputs: Mapping[str, Any]) -> int | None:
    raw = outputs.get("gate_level")
    try:
        return int(raw) if raw is not None else None
    except Exception:
        return None


def coerce_outputs_dict(outputs: Any) -> Mapping[str, Any]:
    if isinstance(outputs, Gate0Outputs):
        return outputs.to_dict()
    if isinstance(outputs, Gate1Outputs):
        return outputs.to_dict()
    if isinstance(outputs, Gate2Outputs):
        return outputs.to_dict()
    if isinstance(outputs, Mapping):
        return outputs
    raise TypeError("outputs must be a mapping or Gate{0,1,2}Outputs")


__all__ = [
    "Gate0Outcome",
    "Gate0Outputs",
    "Gate1Outcome",
    "Gate1Outputs",
    "Gate2CI95",
    "Gate2Outcome",
    "Gate2Outputs",
    "coerce_outputs_dict",
    "outputs_gate_level",
    "outputs_has_baseline_metrics",
]
