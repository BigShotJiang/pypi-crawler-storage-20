from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

CheckSeverity = Literal["error", "warn"]
CheckCategory = Literal[
    "baseline",
    "calibration",
    "checksums",
    "context",
    "dataset_version",
    "decision_support",
    "internal",
    "io",
    "manifest",
    "schema",
]


@dataclass(frozen=True, slots=True)
class CheckMeta:
    description: str
    severity: CheckSeverity
    introduced_in: str
    category: CheckCategory
    denial_reason_code: str | None = None


CHECKS: dict[str, CheckMeta] = {
    "baseline.pin": CheckMeta(
        description="Baseline manifest/pinning mismatch when baseline metrics are present.",
        severity="error",
        introduced_in="spec_v0",
        category="baseline",
    ),
    "calibration.lookup": CheckMeta(
        description="Calibration bundle lookup failed or did not match the run manifest.",
        severity="error",
        introduced_in="spec_v0",
        category="calibration",
    ),
    "calibration.ref": CheckMeta(
        description="Calibration bundle reference is missing, malformed, or mismatches its sidecar file.",
        severity="error",
        introduced_in="spec_v0",
        category="calibration",
    ),
    "checksums": CheckMeta(
        description="Exported checksums are missing, malformed, or do not match on-disk bytes.",
        severity="error",
        introduced_in="spec_v0",
        category="checksums",
    ),
    "context": CheckMeta(
        description="Supported context block is missing or malformed.",
        severity="error",
        introduced_in="spec_v0",
        category="context",
        denial_reason_code="DENY_UNSUPPORTED_CONTEXT",
    ),
    "context.allowed_gate_max": CheckMeta(
        description="Gate level exceeds the supported context's allowed_gate_max.",
        severity="error",
        introduced_in="spec_v0",
        category="context",
    ),
    "context.hash": CheckMeta(
        description="supported_context_hash does not match the canonical context tuple hash.",
        severity="error",
        introduced_in="spec_v0",
        category="context",
    ),
    "context.id": CheckMeta(
        description="supported_context_id does not match the matched supported context id.",
        severity="error",
        introduced_in="spec_v0",
        category="context",
    ),
    "context.unsupported": CheckMeta(
        description="Unsupported context is not explicitly denied (or is inconsistent with gate level).",
        severity="error",
        introduced_in="spec_v0",
        category="context",
        denial_reason_code="DENY_UNSUPPORTED_CONTEXT",
    ),
    "dataset_version": CheckMeta(
        description="Dataset version record is missing or malformed when required by gate constraints.",
        severity="error",
        introduced_in="spec_v0",
        category="dataset_version",
    ),
    "dataset_version.hash": CheckMeta(
        description="dataset_version_hash does not recompute from the dataset_version record.",
        severity="error",
        introduced_in="spec_v0",
        category="dataset_version",
    ),
    "decision_support.denial_reason_code": CheckMeta(
        description="denial_reason_code is missing/OK when decision support is disabled, or non-OK when enabled.",
        severity="error",
        introduced_in="spec_v0",
        category="decision_support",
    ),
    "decision_support.ood_flag": CheckMeta(
        description="Decision support enabled while ood_flag is true.",
        severity="error",
        introduced_in="spec_v0",
        category="decision_support",
        denial_reason_code="DENY_OOD",
    ),
    "internal_error": CheckMeta(
        description="Internal validator error (bug or unexpected condition).",
        severity="error",
        introduced_in="spec_v0",
        category="internal",
    ),
    "io.outputs": CheckMeta(
        description="Failed to load outputs.json.",
        severity="error",
        introduced_in="spec_v0",
        category="io",
    ),
    "io.run_manifest": CheckMeta(
        description="Failed to load run_manifest.json.",
        severity="error",
        introduced_in="spec_v0",
        category="io",
    ),
    "manifest.gate_level": CheckMeta(
        description="run_manifest.gate_level is missing or not an integer.",
        severity="error",
        introduced_in="spec_v0",
        category="manifest",
    ),
    "schema.outputs": CheckMeta(
        description="Outputs schema validation failed (by gate level).",
        severity="error",
        introduced_in="spec_v0",
        category="schema",
    ),
    "schema.run_manifest": CheckMeta(
        description="Run manifest schema validation failed.",
        severity="error",
        introduced_in="spec_v0",
        category="schema",
    ),
}


def check_names() -> tuple[str, ...]:
    return tuple(sorted(CHECKS.keys()))


def require_check_registered(name: str) -> None:
    if name not in CHECKS:
        raise KeyError(f"unregistered check name: {name}")


__all__ = ["CHECKS", "CheckCategory", "CheckMeta", "CheckSeverity", "check_names", "require_check_registered"]

