from __future__ import annotations

from pathlib import Path


def repo_root() -> Path:
    """Best-effort repository root resolver (for schema/baseline/calibration assets)."""

    here = Path(__file__).resolve()
    for parent in [here] + list(here.parents):
        if (parent / "pyproject.toml").exists():
            return parent
    return here.parents[4]


def root_schemas_dir() -> Path:
    return repo_root() / "schemas"


def root_calibration_dir() -> Path:
    return repo_root() / "calibration"


def root_baselines_dir() -> Path:
    return repo_root() / "baselines"


def root_policies_dir() -> Path:
    return repo_root() / "policies"


__all__ = ["repo_root", "root_baselines_dir", "root_calibration_dir", "root_policies_dir", "root_schemas_dir"]
