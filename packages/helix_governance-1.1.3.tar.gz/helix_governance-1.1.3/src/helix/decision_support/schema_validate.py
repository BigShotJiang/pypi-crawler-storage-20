from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

try:
    import jsonschema  # type: ignore
except Exception:  # pragma: no cover - dev extra
    jsonschema = None


class SchemaValidationError(ValueError):
    pass


@dataclass(frozen=True)
class LoadedSchema:
    path: Path
    schema: dict[str, Any]

    @property
    def schema_id(self) -> str | None:
        raw = self.schema.get("$id")
        return str(raw) if isinstance(raw, str) and raw.strip() else None


def load_schema(path: str | Path) -> LoadedSchema:
    p = Path(path)
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SchemaValidationError(f"schema must be an object: {p}")
    return LoadedSchema(path=p, schema=data)


def _schema_store(schemas: list[LoadedSchema]) -> dict[str, Any]:
    store: dict[str, Any] = {}
    for item in schemas:
        sid = item.schema_id
        if sid:
            store[sid] = item.schema
    return store


def validate_json(instance: Any, schema: LoadedSchema, *, extra_schemas: list[LoadedSchema] | None = None) -> None:
    if jsonschema is None:
        raise RuntimeError("jsonschema is required; install Helix dev extras")
    store = _schema_store([schema] + (extra_schemas or []))
    resolver = jsonschema.RefResolver.from_schema(schema.schema, store=store)  # type: ignore[attr-defined]
    validator = jsonschema.Draft202012Validator(schema.schema, resolver=resolver)
    errors = sorted(validator.iter_errors(instance), key=lambda e: list(e.path))
    if not errors:
        return
    msg = "; ".join(f"{'/'.join(str(p) for p in err.path) or '$'}: {err.message}" for err in errors[:5])
    raise SchemaValidationError(msg)


def require_mapping(payload: Any, *, what: str) -> Mapping[str, Any]:
    if not isinstance(payload, Mapping):
        raise ValueError(f"{what} must be a JSON object")
    return payload


__all__ = [
    "LoadedSchema",
    "SchemaValidationError",
    "load_schema",
    "require_mapping",
    "validate_json",
]
