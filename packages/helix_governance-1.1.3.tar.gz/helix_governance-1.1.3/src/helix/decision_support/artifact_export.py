from __future__ import annotations

import hashlib
import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from helix.scientific_contract import canonical_json_bytes
from helix import fs, temp

from helix.decision_support.baseline_registry import pinned_baseline_h0_identity
from helix.decision_support.gate_outputs import coerce_outputs_dict, outputs_gate_level, outputs_has_baseline_metrics
from helix.decision_support.offline_validate import validate_export_artifact
from helix.decision_support.paths import repo_root, root_schemas_dir
from helix.decision_support.schema_validate import load_schema, require_mapping, validate_json


@dataclass(frozen=True, slots=True)
class ExportedArtifact:
    export_dir: Path
    run_manifest_path: Path
    outputs_path: Path
    checksums_path: Path


def _env_flag(name: str) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return False
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def _sha256_prefixed(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_bytes(canonical_json_bytes(payload))


def _posix_rel(path: Path, *, base: Path) -> str:
    return path.relative_to(base).as_posix()


def _compute_file_record(path: Path, *, base: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    return {"path": _posix_rel(path, base=base), "sha256": _sha256_prefixed(raw), "bytes": len(raw)}


def _checksums_payload(files: list[dict[str, Any]]) -> dict[str, Any]:
    files_sorted = sorted(files, key=lambda r: str(r.get("path") or ""))
    return {
        "schema_version": "checksums_v0",
        "hash_algorithm": "sha256",
        "files": files_sorted,
    }


def export_package(
    run_state: Mapping[str, Any],
    outputs: Any,
    export_dir: str | Path,
    *,
    overwrite: bool = False,
) -> ExportedArtifact:
    """Single non-bypassable export entry point for decision-support artifacts."""

    out_dir = Path(export_dir)
    if out_dir.exists():
        if not overwrite:
            raise FileExistsError(f"export_dir already exists: {out_dir}")
        if out_dir.is_dir():
            shutil.rmtree(out_dir)
        else:
            out_dir.unlink(missing_ok=True)

    parent = out_dir.parent
    parent.mkdir(parents=True, exist_ok=True)
    tmp_dir = temp.mkdtemp(prefix=out_dir.name + ".tmp-", dir=parent)
    debug_export = _env_flag("HELIX_DECISION_SUPPORT_EXPORT_DEBUG")
    succeeded = False
    try:
        manifest = require_mapping(run_state, what="run_state")
        out_payload = require_mapping(coerce_outputs_dict(outputs), what="outputs")

        run_manifest_path = tmp_dir / "run_manifest.json"
        outputs_path = tmp_dir / "outputs.json"
        checksums_path = tmp_dir / "checksums.json"

        _write_json(run_manifest_path, dict(manifest))
        _write_json(outputs_path, dict(out_payload))

        gate = int(manifest.get("gate_level", 0))

        if gate >= 1:
            calib = manifest.get("calibration_bundle_ref")
            if not isinstance(calib, Mapping):
                raise ValueError("gate>=1 requires calibration_bundle_ref in run manifest")
            _write_json(tmp_dir / "calibration_bundle_ref.json", dict(calib))

        if outputs_has_baseline_metrics(out_payload):
            base = pinned_baseline_h0_identity()
            baseline_block = manifest.get("baseline")
            if not isinstance(baseline_block, Mapping):
                raise ValueError("baseline metrics present but run_manifest.baseline is null")
            if str(baseline_block.get("baseline_hash") or "") != base.baseline_hash:
                raise ValueError("baseline_hash mismatch vs pinned baseline")
            _write_json(
                tmp_dir / "baseline_manifest.json",
                json.loads((repo_root() / "baselines" / "h0" / "baseline_manifest.json").read_text(encoding="utf-8")),
            )

        if outputs_gate_level(out_payload) is not None and int(out_payload.get("gate_level")) != gate:
            raise ValueError("outputs.gate_level must match run_manifest.gate_level")

        # Schema validation (manifest + outputs by gate).
        schemas_root = root_schemas_dir()
        manifest_schema = load_schema(schemas_root / "run_manifest.schema.json")
        dataset_schema = load_schema(schemas_root / "dataset_version.schema.json")
        validate_json(manifest, manifest_schema, extra_schemas=[dataset_schema])

        outputs_schema_path = schemas_root / "outputs" / f"gate{gate}.schema.json"
        outputs_schema = load_schema(outputs_schema_path)
        validate_json(out_payload, outputs_schema)

        # Checksums computed after schema validation; checksums.json is not self-hashed.
        files: list[dict[str, Any]] = []
        for p in fs.glob_sorted(tmp_dir, "*"):
            if p.name == "checksums.json" or not p.is_file():
                continue
            files.append(_compute_file_record(p, base=tmp_dir))
        _write_json(checksums_path, _checksums_payload(files))

        # Enforce non-bypassability: the emitted artifact must pass offline validation.
        validation = validate_export_artifact(tmp_dir)
        if not validation.ok:
            denial = str(manifest.get("denial_reason_code") or "").strip()
            errors = validation.errors or []
            failing_check = None
            if errors:
                head = errors[0]
                failing_check = head.split(":", 1)[0].strip() if ":" in head else head.strip()

            lines = ["export_package: offline validation failed"]
            lines.append(
                f"gate_level={gate} denial_reason_code={denial or 'UNKNOWN'} failing_check={failing_check or 'UNKNOWN'}"
            )
            if debug_export:
                lines.append(f"tmp_export_dir={tmp_dir}")
            lines.extend([f"- {err}" for err in errors])
            raise ValueError("\n".join(lines))

        tmp_dir.replace(out_dir)
        succeeded = True
        return ExportedArtifact(
            export_dir=out_dir,
            run_manifest_path=out_dir / "run_manifest.json",
            outputs_path=out_dir / "outputs.json",
            checksums_path=out_dir / "checksums.json",
        )
    finally:
        if tmp_dir.exists():
            if debug_export and not succeeded:
                # Keep the temp export directory for debugging (explicit opt-in).
                pass
            else:
                try:
                    # Best-effort cleanup if replace() failed.
                    for p in fs.rglob_sorted(tmp_dir, "*"):
                        if p.is_file():
                            p.unlink()
                    for p in sorted([d for d in fs.rglob_sorted(tmp_dir, "*") if d.is_dir()], reverse=True):
                        try:
                            p.rmdir()
                        except Exception:
                            pass
                    tmp_dir.rmdir()
                except Exception:
                    pass


__all__ = ["ExportedArtifact", "export_package"]
