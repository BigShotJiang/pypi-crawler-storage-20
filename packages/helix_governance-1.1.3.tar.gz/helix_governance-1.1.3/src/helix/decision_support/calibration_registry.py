from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from helix.decision_support.paths import root_calibration_dir


@dataclass(frozen=True, slots=True)
class ApprovedCalibrationEntry:
    model_hash: str
    context_hash: str
    dataset_version_hash: str
    gate_level: int
    signature: str | None = None


@dataclass(frozen=True, slots=True)
class ApprovedCalibrationBundleIndex:
    bundle_id: str
    entries: tuple[ApprovedCalibrationEntry, ...]

    def find(self, *, model_hash: str, context_hash: str, dataset_version_hash: str) -> ApprovedCalibrationEntry | None:
        key = (model_hash, context_hash, dataset_version_hash)
        for entry in self.entries:
            if (entry.model_hash, entry.context_hash, entry.dataset_version_hash) == key:
                return entry
        return None


def load_approved_calibration_bundle_index(bundle_id: str, *, calibration_root: str | Path | None = None) -> ApprovedCalibrationBundleIndex:
    root = Path(calibration_root) if calibration_root else root_calibration_dir()
    path = root / "bundles" / str(bundle_id) / "bundle.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise ValueError("calibration bundle must be a JSON object")
    if str(payload.get("bundle_id") or "") != str(bundle_id):
        raise ValueError("calibration bundle_id mismatch")
    entries_raw = payload.get("entries")
    if not isinstance(entries_raw, list):
        raise ValueError("calibration entries must be an array")
    entries: list[ApprovedCalibrationEntry] = []
    for idx, item in enumerate(entries_raw):
        if not isinstance(item, Mapping):
            raise ValueError(f"entries[{idx}] must be an object")
        mh = str(item.get("model_hash") or "").strip()
        ch = str(item.get("context_hash") or "").strip()
        dh = str(item.get("dataset_version_hash") or "").strip()
        gl = int(item.get("gate_level", 0))
        sig = item.get("signature")
        sig_s = str(sig).strip() if isinstance(sig, str) and sig.strip() else None
        if not (mh.startswith("sha256:") and ch.startswith("sha256:") and dh.startswith("sha256:")):
            raise ValueError(f"entries[{idx}] missing model/context/dataset hashes")
        entries.append(
            ApprovedCalibrationEntry(
                model_hash=mh.lower(),
                context_hash=ch.lower(),
                dataset_version_hash=dh.lower(),
                gate_level=gl,
                signature=sig_s,
            )
        )
    return ApprovedCalibrationBundleIndex(bundle_id=str(bundle_id), entries=tuple(entries))


__all__ = [
    "ApprovedCalibrationBundleIndex",
    "ApprovedCalibrationEntry",
    "load_approved_calibration_bundle_index",
]
