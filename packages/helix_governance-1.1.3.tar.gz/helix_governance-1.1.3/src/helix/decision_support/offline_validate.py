from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from helix import fs

from helix.decision_support.baseline_registry import pinned_baseline_h0_identity, verify_baseline_manifest_matches_repo
from helix.decision_support.calibration_registry import load_approved_calibration_bundle_index
from helix.decision_support.check_registry import require_check_registered
from helix.decision_support.context_registry import compute_context_hash, match_supported_context
from helix.decision_support.dataset_version import recompute_dataset_version_hash
from helix.decision_support.paths import root_schemas_dir
from helix.decision_support.schema_validate import load_schema, require_mapping, validate_json


@dataclass(frozen=True, slots=True)
class ArtifactValidationResult:
    ok: bool
    gate_level: int | None
    errors: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {"ok": bool(self.ok), "gate_level": self.gate_level, "errors": list(self.errors)}


def _sha256_prefixed(path: Path) -> str:
    return f"sha256:{hashlib.sha256(path.read_bytes()).hexdigest()}"


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_checksums(export_dir: Path) -> dict[str, dict[str, Any]]:
    checksums_path = export_dir / "checksums.json"
    payload = _read_json(checksums_path)
    obj = require_mapping(payload, what="checksums")
    if str(obj.get("schema_version") or "").strip() != "checksums_v0":
        raise ValueError("checksums.schema_version must be checksums_v0")
    if str(obj.get("hash_algorithm") or "").strip() != "sha256":
        raise ValueError("checksums.hash_algorithm must be sha256")
    files = obj.get("files")
    if not isinstance(files, list):
        raise ValueError("checksums.files must be an array")
    out: dict[str, dict[str, Any]] = {}
    for idx, item in enumerate(files):
        if not isinstance(item, Mapping):
            raise ValueError(f"checksums.files[{idx}] must be an object")
        rel = str(item.get("path") or "").strip()
        if not rel:
            raise ValueError(f"checksums.files[{idx}].path must be a non-empty string")
        if rel in out:
            raise ValueError(f"duplicate file path in checksums: {rel}")
        sha = str(item.get("sha256") or "").strip()
        if not (sha.startswith("sha256:") and len(sha) == 7 + 64):
            raise ValueError(f"checksums.files[{idx}].sha256 must be sha256:<hex>")
        try:
            size = int(item.get("bytes"))  # type: ignore[arg-type]
        except Exception as exc:
            raise ValueError(f"checksums.files[{idx}].bytes must be an integer") from exc
        if size < 0:
            raise ValueError(f"checksums.files[{idx}].bytes must be non-negative")

        out[rel] = {"sha256": sha, "bytes": size}
    return out


def _verify_checksums(export_dir: Path) -> list[str]:
    errors: list[str] = []
    try:
        checksums = _load_checksums(export_dir)
    except Exception as exc:
        errors.append(f"checksums.json invalid: {exc}")
        return errors
    required = {"run_manifest.json", "outputs.json"}
    missing_required = sorted(required - set(checksums.keys()))
    if missing_required:
        errors.append(f"checksums missing required files: {', '.join(missing_required)}")

    disk_files = []
    for p in fs.rglob_sorted(export_dir, "*"):
        if not p.is_file():
            continue
        rel = p.relative_to(export_dir).as_posix()
        if rel == "checksums.json":
            continue
        disk_files.append(rel)
        if rel not in checksums:
            errors.append(f"file missing from checksums: {rel}")

    for rel in sorted(set(checksums.keys()) - set(disk_files)):
        errors.append(f"checksums lists non-existent file: {rel}")

    for rel, rec in checksums.items():
        p = export_dir / rel
        if not p.exists():
            errors.append(f"missing file listed in checksums: {rel}")
            continue
        computed = _sha256_prefixed(p)
        declared = str(rec.get("sha256") or "").strip()
        if declared != computed:
            errors.append(f"checksum mismatch for {rel}: declared {declared} computed {computed}")
        try:
            declared_bytes = int(rec.get("bytes") or 0)
        except Exception:
            declared_bytes = -1
        if declared_bytes >= 0 and declared_bytes != p.stat().st_size:
            errors.append(f"bytes mismatch for {rel}: declared {declared_bytes} computed {p.stat().st_size}")
    return errors


def validate_export_artifact(export_dir: str | Path) -> ArtifactValidationResult:
    errors: list[str] = []
    gate_level: int | None = None

    def _add(check: str, message: str) -> None:
        require_check_registered(check)
        errors.append(f"{check}: {message}")

    try:
        root = Path(export_dir)
        try:
            manifest = require_mapping(_read_json(root / "run_manifest.json"), what="run_manifest")
        except Exception as exc:
            _add("io.run_manifest", str(exc))
            return ArtifactValidationResult(ok=False, gate_level=None, errors=errors)

        try:
            outputs = require_mapping(_read_json(root / "outputs.json"), what="outputs")
        except Exception as exc:
            _add("io.outputs", str(exc))
            return ArtifactValidationResult(ok=False, gate_level=None, errors=errors)

        try:
            gate_level = int(manifest.get("gate_level", 0))
        except Exception:
            gate_level = None
            _add("manifest.gate_level", "gate_level must be an integer")

        schemas_root = root_schemas_dir()
        manifest_schema = load_schema(schemas_root / "run_manifest.schema.json")
        dataset_schema = load_schema(schemas_root / "dataset_version.schema.json")
        try:
            validate_json(manifest, manifest_schema, extra_schemas=[dataset_schema])
        except Exception as exc:
            _add("schema.run_manifest", str(exc))

        if gate_level is None:
            _add("schema.outputs", "cannot validate outputs schema without a valid gate_level")
        else:
            outputs_schema = load_schema(schemas_root / "outputs" / f"gate{gate_level}.schema.json")
            try:
                validate_json(outputs, outputs_schema)
            except Exception as exc:
                _add("schema.outputs", str(exc))

        # Context identity: hash and exact supported_context_id match must be consistent with context_tuple.
        supported = manifest.get("supported_context")
        if not isinstance(supported, Mapping):
            _add("context", "run_manifest.supported_context missing or invalid")
        else:
            context_tuple = supported.get("context_tuple")
            if not isinstance(context_tuple, Mapping):
                _add("context", "run_manifest.supported_context.context_tuple missing or invalid")
            else:
                # Schema ensures required keys exist; we still coerce to str for robustness.
                tup = {
                    "organism": str(context_tuple.get("organism") or "").strip(),
                    "genome_build": str(context_tuple.get("genome_build") or "").strip(),
                    "assay": str(context_tuple.get("assay") or "").strip(),
                    "edit_type": str(context_tuple.get("edit_type") or "").strip(),
                    "measurement": str(context_tuple.get("measurement") or "").strip(),
                }
                computed_hash = compute_context_hash(tup)  # type: ignore[arg-type]
                declared_hash = str(supported.get("supported_context_hash") or "").strip()
                if declared_hash != computed_hash:
                    _add(
                        "context.hash",
                        f"supported_context_hash mismatch: declared {declared_hash} computed {computed_hash}",
                    )

                match = match_supported_context(tup)  # type: ignore[arg-type]
                declared_id = supported.get("supported_context_id")
                declared_id_text = str(declared_id).strip() if isinstance(declared_id, str) else None

                if match.supported:
                    if declared_id_text != match.supported_context_id:
                        _add(
                            "context.id",
                            f"supported_context_id mismatch: declared {declared_id_text} expected {match.supported_context_id}"
                        )
                    if gate_level is not None and gate_level > int(match.allowed_gate_max):
                        _add(
                            "context.allowed_gate_max",
                            f"gate_level {gate_level} exceeds supported context allowed_gate_max {match.allowed_gate_max}"
                        )
                else:
                    if declared_id_text:
                        _add("context.unsupported", "unsupported context but supported_context_id is set")
                    if gate_level != 0 and gate_level is not None:
                        _add("context.unsupported", "unsupported context requires gate_level 0")
                    denial = str(manifest.get("denial_reason_code") or "").strip()
                    if denial != match.denial_reason_code:
                        _add(
                            "context.unsupported",
                            f"unsupported context denial_reason_code mismatch: declared {denial} expected {match.denial_reason_code}"
                        )

        # dataset_version_hash internal consistency (gate>=1).
        if gate_level is not None and gate_level >= 1:
            dv = manifest.get("dataset_version")
            if not isinstance(dv, Mapping):
                _add("dataset_version", "gate>=1 requires dataset_version record")
            else:
                try:
                    recomputed = recompute_dataset_version_hash(dv)
                except Exception as exc:
                    _add("dataset_version.hash", f"failed to recompute dataset_version_hash: {exc}")
                else:
                    declared = str(dv.get("dataset_version_hash") or "").strip()
                    if declared != recomputed:
                        _add(
                            "dataset_version.hash",
                            f"dataset_version_hash mismatch: declared {declared} computed {recomputed}",
                        )

        # Calibration bundle match (gate>=1).
        if gate_level is not None and gate_level >= 1:
            calib_ref = manifest.get("calibration_bundle_ref")
            if not isinstance(calib_ref, Mapping):
                _add("calibration.ref", "gate>=1 requires calibration_bundle_ref")
            else:
                try:
                    calib_file = require_mapping(_read_json(root / "calibration_bundle_ref.json"), what="calibration_bundle_ref.json")
                    if dict(calib_file) != dict(calib_ref):
                        _add(
                            "calibration.ref",
                            "calibration_bundle_ref.json does not match run_manifest.calibration_bundle_ref",
                        )
                except Exception as exc:
                    _add("calibration.ref", f"calibration_bundle_ref.json invalid: {exc}")

                bundle_id = str(calib_ref.get("bundle_id") or "").strip()
                try:
                    idx = load_approved_calibration_bundle_index(bundle_id)
                except Exception as exc:
                    _add("calibration.lookup", f"failed to load calibration bundle index: {exc}")
                else:
                    entry = idx.find(
                        model_hash=str(calib_ref.get("model_hash") or "").strip().lower(),
                        context_hash=str(calib_ref.get("context_hash") or "").strip().lower(),
                        dataset_version_hash=str(calib_ref.get("dataset_version_hash") or "").strip().lower(),
                    )
                    if entry is None:
                        _add("calibration.lookup", "calibration bundle entry not found")
                    else:
                        approved_gate = int(entry.gate_level)
                        try:
                            declared_gate = int(calib_ref.get("gate_level", 0))
                        except Exception:
                            declared_gate = 0
                            _add("calibration.ref", "calibration_bundle_ref.gate_level must be an integer")
                        else:
                            if declared_gate != approved_gate:
                                _add(
                                    "calibration.ref",
                                    f"calibration_bundle_ref.gate_level mismatch: declared {declared_gate} approved {approved_gate}",
                                )
                        if gate_level > approved_gate:
                            _add(
                                "calibration.lookup",
                                f"gate_level {gate_level} exceeds approved gate_level {approved_gate}",
                            )

        # Baseline hash pinning when baseline metrics exist.
        if isinstance(outputs.get("baseline_metrics"), Mapping):
            pinned = pinned_baseline_h0_identity()
            baseline = manifest.get("baseline")
            if not isinstance(baseline, Mapping):
                _add("baseline.pin", "baseline_metrics present but run_manifest.baseline is null")
            else:
                if str(baseline.get("baseline_id") or "") != pinned.baseline_id:
                    _add("baseline.pin", "baseline_id mismatch vs pinned baseline")
                if str(baseline.get("baseline_hash") or "") != pinned.baseline_hash:
                    _add("baseline.pin", "baseline_hash mismatch vs pinned baseline")
            try:
                exported_manifest = require_mapping(_read_json(root / "baseline_manifest.json"), what="baseline_manifest")
                verify_baseline_manifest_matches_repo(exported_manifest)
            except Exception as exc:
                _add("baseline.pin", f"baseline_manifest invalid: {exc}")

        for err in _verify_checksums(root):
            _add("checksums", err)

        # Decision support denial reasons must be explicit when disabled.
        decision_support_enabled = bool(manifest.get("decision_support_enabled"))
        if decision_support_enabled:
            code = str(manifest.get("denial_reason_code") or "").strip()
            if code != "OK":
                _add("decision_support.denial_reason_code", "decision_support enabled but denial_reason_code must be OK")
            if bool(manifest.get("ood_flag")):
                _add("decision_support.ood_flag", "decision_support enabled but ood_flag must be false")
        else:
            code = str(manifest.get("denial_reason_code") or "").strip()
            if not code or code == "OK":
                _add(
                    "decision_support.denial_reason_code",
                    "decision_support disabled but denial_reason_code is missing/OK",
                )

        return ArtifactValidationResult(ok=not errors, gate_level=gate_level, errors=errors)
    except Exception as exc:
        _add("internal_error", str(exc))
        return ArtifactValidationResult(ok=False, gate_level=gate_level, errors=errors)


__all__ = ["ArtifactValidationResult", "validate_export_artifact"]
