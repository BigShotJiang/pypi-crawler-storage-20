from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from helix.scientific_contract import canonical_json_bytes

from helix.decision_support.paths import root_baselines_dir


@dataclass(frozen=True, slots=True)
class BaselineFileDigest:
    path: str
    sha256: str
    bytes: int


@dataclass(frozen=True, slots=True)
class BaselineIdentity:
    baseline_id: str
    baseline_hash: str
    files: tuple[BaselineFileDigest, ...]


def _sha256_prefixed(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def compute_baseline_hash(*, baseline_id: str, files: Iterable[BaselineFileDigest]) -> str:
    material = {
        "baseline_id": str(baseline_id),
        "hash_algorithm": "sha256",
        "canonicalization": "helix.canonical_json_bytes.v1",
        "files": [
            {"path": f.path, "sha256": f.sha256, "bytes": int(f.bytes)}
            for f in sorted(files, key=lambda x: x.path)
        ],
    }
    return _sha256_prefixed(canonical_json_bytes(material))


def _digest_file(path: Path, *, base: Path) -> BaselineFileDigest:
    raw = path.read_bytes()
    return BaselineFileDigest(
        path=path.relative_to(base).as_posix(),
        sha256=_sha256_prefixed(raw),
        bytes=len(raw),
    )


def pinned_baseline_h0_identity(*, baselines_root: str | Path | None = None) -> BaselineIdentity:
    root = Path(baselines_root) if baselines_root else root_baselines_dir()
    h0 = root / "h0"
    manifest_path = h0 / "baseline_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, Mapping):
        raise ValueError("baseline_manifest.json must be an object")
    baseline_id = str(manifest.get("baseline_id") or "").strip()
    baseline_hash = str(manifest.get("baseline_hash") or "").strip()
    if not baseline_id or not baseline_hash.startswith("sha256:"):
        raise ValueError("baseline_manifest missing baseline_id/baseline_hash")

    files_raw = manifest.get("files")
    if not isinstance(files_raw, list):
        raise ValueError("baseline_manifest.files must be an array")
    files: list[BaselineFileDigest] = []
    for item in files_raw:
        if not isinstance(item, Mapping):
            continue
        rel = str(item.get("path") or "").strip().replace("\\", "/")
        sha = str(item.get("sha256") or "").strip()
        size = int(item.get("bytes") or 0)
        if not rel or not sha.startswith("sha256:") or len(sha) != len("sha256:") + 64:
            raise ValueError("baseline_manifest.files[] invalid")
        digest = _digest_file(h0 / rel, base=h0)
        if digest.sha256 != sha or digest.bytes != size:
            raise ValueError(f"baseline_manifest.files[] digest mismatch for {rel}")
        files.append(digest)

    computed = compute_baseline_hash(baseline_id=baseline_id, files=files)
    if baseline_hash != computed:
        raise ValueError(f"baseline_manifest baseline_hash mismatch (expected {baseline_hash} computed {computed})")
    return BaselineIdentity(baseline_id=baseline_id, baseline_hash=baseline_hash, files=tuple(files))


def verify_baseline_manifest_matches_repo(manifest_payload: Mapping[str, Any]) -> None:
    """Verify an exported baseline_manifest.json matches the pinned baseline directory."""

    pinned = pinned_baseline_h0_identity()
    bid = str(manifest_payload.get("baseline_id") or "").strip()
    bh = str(manifest_payload.get("baseline_hash") or "").strip()
    if bid != pinned.baseline_id or bh != pinned.baseline_hash:
        raise ValueError("baseline manifest does not match pinned baseline")


__all__ = [
    "BaselineFileDigest",
    "BaselineIdentity",
    "compute_baseline_hash",
    "pinned_baseline_h0_identity",
    "verify_baseline_manifest_matches_repo",
]
