from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, TypedDict

from helix.scientific_contract import sha256_prefixed

from helix.decision_support.paths import root_policies_dir


class ContextTupleV0(TypedDict):
    organism: str
    genome_build: str
    assay: str
    edit_type: str
    measurement: str


@dataclass(frozen=True, slots=True)
class SupportedContext:
    supported_context_id: str
    allowed_gate_max: int
    context_tuple: ContextTupleV0
    context_hash: str


@dataclass(frozen=True, slots=True)
class SupportedContextMatch:
    supported: bool
    supported_context_id: str | None
    supported_context_hash: str | None
    allowed_gate_max: int
    denial_reason_code: str


def _normalize_context_tuple(raw: Mapping[str, Any]) -> ContextTupleV0:
    required = ["organism", "genome_build", "assay", "edit_type", "measurement"]
    out: dict[str, str] = {}
    for k in required:
        v = raw.get(k)
        if not isinstance(v, str) or not v.strip():
            raise ValueError(f"context_tuple missing {k}")
        out[k] = v.strip()
    return out  # type: ignore[return-value]


def compute_context_hash(context_tuple: ContextTupleV0) -> str:
    return sha256_prefixed(dict(context_tuple))


def load_supported_contexts(path: str | Path | None = None) -> list[SupportedContext]:
    p = Path(path) if path else (root_policies_dir() / "supported_contexts.json")
    payload = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        raise ValueError("supported_contexts.json must be a JSON array")
    out: list[SupportedContext] = []
    for idx, item in enumerate(payload):
        if not isinstance(item, Mapping):
            raise ValueError(f"supported_contexts[{idx}] must be an object")
        sid = str(item.get("supported_context_id") or "").strip()
        if not sid:
            raise ValueError(f"supported_contexts[{idx}] missing supported_context_id")
        allowed_gate_max = int(item.get("allowed_gate_max", 0))
        tup_raw = item.get("context_tuple")
        if not isinstance(tup_raw, Mapping):
            raise ValueError(f"supported_contexts[{idx}] missing context_tuple")
        tup = _normalize_context_tuple(tup_raw)
        context_hash = str(item.get("context_hash") or "").strip()
        computed = compute_context_hash(tup)
        if context_hash and context_hash != computed:
            raise ValueError(f"supported_contexts[{idx}] context_hash mismatch (expected {context_hash} computed {computed})")
        out.append(
            SupportedContext(
                supported_context_id=sid,
                allowed_gate_max=allowed_gate_max,
                context_tuple=tup,
                context_hash=computed,
            )
        )
    return out


def match_supported_context(
    context_tuple: ContextTupleV0,
    *,
    supported_contexts: list[SupportedContext] | None = None,
) -> SupportedContextMatch:
    contexts = supported_contexts if supported_contexts is not None else load_supported_contexts()
    computed_hash = compute_context_hash(context_tuple)
    for ctx in contexts:
        if dict(ctx.context_tuple) == dict(context_tuple):
            return SupportedContextMatch(
                supported=True,
                supported_context_id=ctx.supported_context_id,
                supported_context_hash=computed_hash,
                allowed_gate_max=int(ctx.allowed_gate_max),
                denial_reason_code="OK",
            )
    return SupportedContextMatch(
        supported=False,
        supported_context_id=None,
        supported_context_hash=computed_hash,
        allowed_gate_max=0,
        denial_reason_code="DENY_UNSUPPORTED_CONTEXT",
    )


__all__ = [
    "ContextTupleV0",
    "SupportedContext",
    "SupportedContextMatch",
    "compute_context_hash",
    "load_supported_contexts",
    "match_supported_context",
]
