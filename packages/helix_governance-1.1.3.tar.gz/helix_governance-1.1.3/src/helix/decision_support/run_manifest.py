from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from helix import clock
from helix.decision_support.context_registry import ContextTupleV0, SupportedContextMatch


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


@dataclass(frozen=True, slots=True)
class GateDecision:
    gate_level: int
    decision_support_enabled: bool
    denial_reason_code: str


def compute_gate_decision(
    *,
    requested_gate: int,
    supported_context: SupportedContextMatch,
    ood_flag: bool,
    dataset_version_present: bool,
    approved_gate_max: int | None,
) -> GateDecision:
    req = max(0, min(2, int(requested_gate)))
    if ood_flag:
        return GateDecision(gate_level=0, decision_support_enabled=False, denial_reason_code="DENY_OOD")
    if not supported_context.supported:
        return GateDecision(
            gate_level=0, decision_support_enabled=False, denial_reason_code=supported_context.denial_reason_code
        )
    if req >= 1 and not dataset_version_present:
        return GateDecision(gate_level=0, decision_support_enabled=False, denial_reason_code="DENY_DATASET_VERSION_MISSING")
    if req >= 1 and (approved_gate_max is None or int(approved_gate_max) <= 0):
        return GateDecision(gate_level=0, decision_support_enabled=False, denial_reason_code="DENY_CALIBRATION_MISSING")

    allowed = min(int(supported_context.allowed_gate_max), int(approved_gate_max or 0), req)
    gate = max(0, min(2, int(allowed)))
    if gate >= 2:
        return GateDecision(gate_level=2, decision_support_enabled=True, denial_reason_code="OK")
    if gate == 1:
        return GateDecision(gate_level=1, decision_support_enabled=False, denial_reason_code="DENY_GATE_LEVEL_1")
    return GateDecision(gate_level=0, decision_support_enabled=False, denial_reason_code="DENY_GATE_LEVEL_0")


def build_run_manifest_v0(
    *,
    run_id: str,
    helix_version: str,
    git_sha: str | None,
    context_tuple: ContextTupleV0,
    supported_context: SupportedContextMatch,
    gate: GateDecision,
    ood_flag: bool,
    dataset_version: Mapping[str, Any] | None,
    baseline: Mapping[str, Any] | None,
    calibration_bundle_ref: Mapping[str, Any] | None,
    created_at_utc: str | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": "run_manifest_v0",
        "run_id": str(run_id),
        "created_at_utc": created_at_utc or _utc_now_iso(),
        "helix_version": str(helix_version),
        "git_sha": (str(git_sha) if git_sha is not None else None),
        "supported_context": {
            "context_version": "context_v0",
            "context_tuple": dict(context_tuple),
            "supported_context_id": supported_context.supported_context_id,
            "supported_context_hash": supported_context.supported_context_hash,
        },
        "gate_level": int(gate.gate_level),
        "decision_support_enabled": bool(gate.decision_support_enabled),
        "denial_reason_code": str(gate.denial_reason_code),
        "ood_flag": bool(ood_flag),
        "dataset_version": (dict(dataset_version) if dataset_version is not None else None),
        "baseline": (dict(baseline) if baseline is not None else None),
        "calibration_bundle_ref": (dict(calibration_bundle_ref) if calibration_bundle_ref is not None else None),
    }


__all__ = ["GateDecision", "build_run_manifest_v0", "compute_gate_decision"]
