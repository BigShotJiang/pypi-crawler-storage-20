from __future__ import annotations

import hashlib
import json
import locale
import os
import platform
import shutil
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import __version__ as helix_version
from helix import fs
from helix.determinism.guard import deterministic_context
from helix.crispr.physics import CRISPR_SCORING_VERSION
from helix.prime.physics import PRIME_SCORING_VERSION
from helix.provenance import current_git_sha
from helix.run_engine import LocalEngine, RunRequest
from helix.schema import SPEC_VERSION
from helix.scientific_contract import collect_backend_fingerprint
from helixspec.compare import compare_with_policy, DEFAULT_TOLERANCE_MAP
from helixspec.errors import HelixSpecVerifyError


class ReproBundleError(RuntimeError):
    """Raised when repro bundle operations fail."""


CANONICAL_JSON_KWARGS = {
    "sort_keys": True,
    "separators": (",", ":"),
    "ensure_ascii": False,
}


def stable_json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, **CANONICAL_JSON_KWARGS) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_canonical_json(obj: Any) -> str:
    return sha256_bytes(stable_json_bytes(obj))


def _normalize_case_id(raw: object, fallback: str) -> str:
    token = str(raw or fallback).strip() or fallback
    return token.replace(" ", "_")


def _load_json(path: Path) -> Mapping[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # pragma: no cover - surfaced to callers
        raise ReproBundleError(f"Failed to parse JSON: {path}: {exc}") from exc
    if not isinstance(payload, Mapping):
        raise ReproBundleError(f"Expected JSON object at {path}")
    return payload


def _require_int(value: object, *, label: str) -> int:
    if value is None:
        raise ReproBundleError(f"{label} is required for deterministic outputs.")
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ReproBundleError(f"{label} must be an int (got {value!r}).") from exc


def _probability_1e4(count: int, draws: int) -> int:
    if draws <= 0:
        return 0
    return (count * 10000 + draws // 2) // draws


def _normalize_sequence(raw: str) -> str:
    if not raw:
        return ""
    allowed = {"A", "C", "G", "T", "N"}
    cleaned: list[str] = []
    for line in str(raw).splitlines():
        if line.startswith(">"):
            continue
        for char in line.upper():
            if char in {" ", "\t", "\r"}:
                continue
            if char == "U":
                char = "T"
            if char not in allowed:
                raise ReproBundleError(f"Unexpected base '{char}' in sequence.")
            cleaned.append(char)
    return "".join(cleaned)


def _normalize_backends(raw: str | Sequence[str] | None) -> list[str]:
    tokens: list[str] = []
    if raw is None:
        tokens = ["all"]
    elif isinstance(raw, str):
        tokens = [raw]
    else:
        tokens = [str(item) for item in raw]

    expanded: list[str] = []
    for token in tokens:
        for part in str(token).split(","):
            part = part.strip()
            if not part:
                continue
            if part == "all":
                expanded.extend(["cpu-reference", "gpu"])
            else:
                expanded.append(part)
    seen: set[str] = set()
    ordered: list[str] = []
    for backend in expanded:
        if backend in seen:
            continue
        seen.add(backend)
        ordered.append(backend)
    return ordered


def load_case_spec(path: str | Path) -> dict[str, Any]:
    spec_path = Path(path)
    payload = _load_json(spec_path)
    runs = payload.get("runs")
    if not isinstance(runs, list) or not runs:
        raise ReproBundleError(f"Spec must define a non-empty runs list: {spec_path}")
    return dict(payload)


def _canonical_spec_for_hash(spec: Mapping[str, Any]) -> dict[str, Any]:
    copy = json.loads(json.dumps(spec))
    runs = copy.get("runs")
    if isinstance(runs, list):
        def _run_key(item: Any) -> str:
            if not isinstance(item, Mapping):
                return ""
            return str(item.get("run_id") or item.get("guide_id") or item.get("guide") or "")
        copy["runs"] = sorted(runs, key=_run_key)
    return copy


def _build_run_state(spec: Mapping[str, Any]) -> tuple[dict[str, Any], str, str, dict[str, Any], dict[str, Any]]:
    edit_type = str(spec.get("edit_type", "crispr")).lower()

    sequence = spec.get("sequence")
    if not sequence:
        label = spec.get("run_id") or spec.get("guide_id") or "<unknown>"
        raise ReproBundleError(f"Run '{label}' is missing required field 'sequence'.")

    guide = {
        "id": spec.get("guide_id", spec.get("guide")),
        "name": spec.get("guide_id", spec.get("guide")),
        "locus": spec.get("target_locus", spec.get("locus", "")),
        "start": spec.get("guide_start", spec.get("start")),
        "end": spec.get("guide_end", spec.get("end")),
        "strand": spec.get("guide_strand", spec.get("strand", "+")),
        "sequence": spec.get("guide_sequence"),
        "pam_index": spec.get("pam_index"),
        "cut_index": spec.get("cut_index"),
    }

    run_cfg: dict[str, Any] = {}
    crispr_cfg = spec.get("crispr") if isinstance(spec.get("crispr"), Mapping) else {}
    run_cfg["pam_profile"] = crispr_cfg.get("pam_profile") or spec.get("pam_profile", "SpRY_NNN")
    run_cfg["pam_softness"] = crispr_cfg.get("pam_softness", spec.get("pam_softness", 0.0))
    run_cfg["priors_profile"] = crispr_cfg.get("priors_profile") or spec.get("priors_profile") or "default_indel"
    if "draws" in crispr_cfg or "draws" in spec:
        run_cfg["draws"] = crispr_cfg.get("draws", spec.get("draws"))
    if "seed" in crispr_cfg or "seed" in spec:
        run_cfg["seed"] = crispr_cfg.get("seed", spec.get("seed"))

    base_state = {
        "sequence": sequence,
        "genome": {"target": sequence},
        "config": {
            "guide": guide,
            "run_config": dict(run_cfg),
        },
    }

    run_id = str(spec.get("run_id") or guide.get("id") or "run")

    if edit_type == "prime":
        prime_cfg = spec.get("prime") or {}
        pbs = prime_cfg.get("pbs_sequence") or prime_cfg.get("pbs")
        rtt = prime_cfg.get("rt_sequence") or prime_cfg.get("rtt")
        if not pbs or not rtt:
            raise ReproBundleError(
                f"Prime run '{run_id}' is missing prime.pbs_sequence or prime.rt_sequence."
            )
        pam_profile = prime_cfg.get("pam_profile") or spec.get("pam_profile") or "SpRY_NNN"
        draws = prime_cfg.get("draws")
        seed = prime_cfg.get("seed")
        pam_softness = prime_cfg.get("pam_softness", spec.get("pam_softness", run_cfg.get("pam_softness", 0.0)))
        priors_profile = prime_cfg.get("priors_profile") or spec.get("priors_profile") or run_cfg.get("priors_profile")
        peg = {
            "name": prime_cfg.get("nick_guide_id") or guide.get("id"),
            "spacer": prime_cfg.get("spacer") or guide.get("name") or guide.get("id") or "",
            "pbs": pbs,
            "rtt": rtt,
            "nick_index": prime_cfg.get("nick_cut_index"),
        }
        base_state["peg"] = peg
        base_state["config"]["run_config"].update(
            {
                "pam_profile": pam_profile,
                "pam_softness": pam_softness,
                "priors_profile": priors_profile,
            }
        )
        if draws is not None:
            base_state["config"]["run_config"]["draws"] = draws
        if seed is not None:
            base_state["config"]["run_config"]["seed"] = seed
        run_kind = "PRIME"
    elif edit_type == "crispr":
        crispr_draws = crispr_cfg.get("draws", spec.get("draws"))
        crispr_seed = crispr_cfg.get("seed", spec.get("seed"))
        if crispr_draws is not None:
            base_state["config"]["run_config"]["draws"] = crispr_draws
        if crispr_seed is not None:
            base_state["config"]["run_config"]["seed"] = crispr_seed
        run_kind = "CRISPR"
    else:
        raise ReproBundleError(
            f"Run '{run_id}': edit_type '{edit_type}' not supported; use 'crispr' or 'prime'."
        )

    run_config = dict(base_state["config"]["run_config"])
    run_config["seed"] = _require_int(run_config.get("seed"), label=f"run {run_id} seed")
    run_config["draws"] = _require_int(run_config.get("draws"), label=f"run {run_id} draws")
    return base_state, run_kind, run_id, run_config, guide


def _run_engine_snapshot(
    *,
    base_state: Mapping[str, Any],
    run_kind: str,
    run_id: str,
    session_id: str,
) -> Mapping[str, Any]:
    def _truthy(value: str | None) -> bool:
        return str(value or "").strip().lower() in {"1", "true", "yes", "on"}

    engine = LocalEngine()
    request = RunRequest(
        run_kind=run_kind,
        session_id=session_id,
        run_id=run_id,
        snapshot_payload=base_state,
        parameters={},
    )
    if _truthy(os.getenv("HELIX_DETERMINISTIC")) or _truthy(os.getenv("HELIX_FORBID_RANDOM")):
        with deterministic_context():
            result = engine.execute(request)
    else:
        result = engine.execute(request)
    return result.snapshot


def _canonical_run_output(
    *,
    case_id: str,
    backend: str,
    spec_sha256: str,
    snapshot: Mapping[str, Any],
    run_kind: str,
    run_id: str,
    guide: Mapping[str, Any],
    run_config: Mapping[str, Any],
) -> dict[str, Any]:
    state = snapshot.get("state", snapshot)
    config = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    config_run = config.get("run_config") if isinstance(config.get("run_config"), Mapping) else {}
    run_cfg = dict(run_config)
    run_cfg.update(config_run)

    seed = _require_int(run_cfg.get("seed"), label=f"run {run_id} seed")
    draws = _require_int(run_cfg.get("draws"), label=f"run {run_id} draws")
    pam_profile = str(run_cfg.get("pam_profile") or "")
    pam_softness = float(run_cfg.get("pam_softness", 0.0))
    priors_profile = str(run_cfg.get("priors_profile") or "")

    sequence = state.get("sequence") or ""
    if not sequence:
        genome = state.get("genome")
        if isinstance(genome, Mapping) and genome:
            sequence = next(iter(genome.values()))
    normalized_sequence = _normalize_sequence(str(sequence))
    sequence_sha = sha256_bytes(normalized_sequence.encode("utf-8"))

    raw_outcomes = state.get("outcomes")
    if not isinstance(raw_outcomes, list):
        sim_payload = config.get("sim_payload") if isinstance(config.get("sim_payload"), Mapping) else {}
        raw_outcomes = sim_payload.get("outcomes", []) if isinstance(sim_payload.get("outcomes"), list) else []

    outcomes: list[dict[str, Any]] = []
    for entry in raw_outcomes:
        if not isinstance(entry, Mapping):
            continue
        label = str(entry.get("label") or entry.get("name") or "")
        count = int(entry.get("count") or 0)
        diff = entry.get("diff")
        outcomes.append(
            {
                "label": label,
                "count": count,
                "probability_1e4": _probability_1e4(count, draws),
                "diff": diff if diff is None or isinstance(diff, Mapping) else None,
            }
        )
    outcomes.sort(key=lambda item: (-int(item.get("count", 0)), str(item.get("label", ""))))

    engine_info = {
        "name": "helix_cuda" if backend == "gpu" else "helix_native",
        "backend": backend,
        "crispr_scoring_version": CRISPR_SCORING_VERSION,
        "prime_scoring_version": PRIME_SCORING_VERSION,
    }

    guide_block = {
        "id": guide.get("id"),
        "start": guide.get("start"),
        "end": guide.get("end"),
        "strand": guide.get("strand"),
        "pam_index": guide.get("pam_index"),
        "cut_index": guide.get("cut_index"),
    }

    payload = {
        "schema": {"kind": "helix.repro.run", "version": 1},
        "case_id": case_id,
        "backend": backend,
        "input_spec_sha256": spec_sha256,
        "engine": engine_info,
        "run": {
            "run_id": run_id,
            "kind": run_kind.lower(),
            "seed": seed,
            "draws": draws,
            "pam_profile": pam_profile,
            "pam_softness": f"{pam_softness:.6f}",
            "priors_profile": priors_profile,
        },
        "sequence": {
            "length": len(normalized_sequence),
            "sha256": sequence_sha,
        },
        "guide": guide_block,
        "outcomes": outcomes,
    }
    return payload


def run_repro_case(
    *,
    spec_path: str | Path,
    out_dir: str | Path,
    backends: str | Sequence[str] | None = None,
) -> dict[str, Any]:
    spec_path = Path(spec_path)
    spec = load_case_spec(spec_path)
    case_id = _normalize_case_id(spec.get("case_id"), spec_path.stem)
    session_id = str(spec.get("session_id") or f"repro_{case_id}")
    runs = spec.get("runs", [])
    if not isinstance(runs, list) or not runs:
        raise ReproBundleError(f"Spec must define a non-empty runs list: {spec_path}")

    spec_sha = sha256_canonical_json(_canonical_spec_for_hash(spec))
    backend_list = _normalize_backends(backends)

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    outputs: dict[str, list[str]] = {}
    for backend in backend_list:
        backend_dir = out_dir / backend
        if backend_dir.exists():
            shutil.rmtree(backend_dir)
        backend_dir.mkdir(parents=True, exist_ok=True)

        relative_paths: list[str] = []
        multi = len(runs) > 1
        for run_spec in runs:
            if not isinstance(run_spec, Mapping):
                raise ReproBundleError(f"Run spec must be an object in {spec_path}")
            base_state, run_kind, run_id, run_cfg, guide = _build_run_state(run_spec)
            snapshot = _run_engine_snapshot(
                base_state=base_state,
                run_kind=run_kind,
                run_id=run_id,
                session_id=session_id,
            )
            payload = _canonical_run_output(
                case_id=case_id,
                backend=backend,
                spec_sha256=spec_sha,
                snapshot=snapshot,
                run_kind=run_kind,
                run_id=run_id,
                guide=guide,
                run_config=run_cfg,
            )
            if multi:
                rel = Path("runs") / f"{run_id}.run.json"
            else:
                rel = Path("run.json")
            out_path = backend_dir / rel
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_bytes(stable_json_bytes(payload))
            relative_paths.append((Path(backend) / rel).as_posix())
        outputs[backend] = relative_paths

    return {
        "case_id": case_id,
        "spec_sha256": spec_sha,
        "out_dir": str(out_dir),
        "backends": backend_list,
        "outputs": outputs,
    }


def _default_env_fingerprint(backend_kind: str | None = None) -> dict[str, Any]:
    tz = time.tzname[0] if time.tzname else ""
    lang = locale.getdefaultlocale()[0] if locale.getdefaultlocale() else ""
    kind, backend_details = collect_backend_fingerprint(backend_kind=backend_kind, deterministic=False)
    return {
        "os": os.name,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python": {
            "version": platform.python_version(),
            "executable": sys.executable,
        },
        "locale": lang,
        "timezone": tz,
        "helix_version": helix_version,
        "git_sha": current_git_sha() or "",
        "backend": {"kind": kind, "details": backend_details},
    }


def build_case_manifest(
    *,
    spec_path: str | Path,
    expected_root: str | Path,
    policy_path: str | Path,
    optional_backends: Sequence[str] | None = None,
) -> dict[str, Any]:
    spec_path = Path(spec_path)
    expected_root = Path(expected_root)
    policy_path = Path(policy_path)

    spec = load_case_spec(spec_path)
    case_id = _normalize_case_id(spec.get("case_id"), spec_path.stem)

    spec_sha = sha256_canonical_json(_canonical_spec_for_hash(spec))
    policy_bytes = policy_path.read_bytes()
    policy_sha = sha256_bytes(policy_bytes)

    backends: dict[str, Any] = {}
    backend_dirs = [p for p in fs.iterdir_sorted(expected_root) if p.is_dir()]
    for backend_dir in backend_dirs:
        backend = backend_dir.name
        files: list[dict[str, Any]] = []
        for path in fs.rglob_sorted(backend_dir, "*"):
            if path.is_dir():
                continue
            rel = path.relative_to(expected_root).as_posix()
            files.append(
                {
                    "path": rel,
                    "sha256": sha256_path(path),
                    "size": path.stat().st_size,
                    "mode": "strict",
                }
            )
        backends[backend] = {"files": files}

    policy_rel = os.path.relpath(policy_path, spec_path.parent).replace("\\", "/")
    expected_rel = os.path.relpath(expected_root, spec_path.parent).replace("\\", "/")

    manifest = {
        "schema": {"kind": "helix.repro.case_manifest", "version": 1},
        "case_id": case_id,
        "spec_sha256": spec_sha,
        "schema_versions": {
            "helix_version": helix_version,
            "schema_version": f"helix.schema/{SPEC_VERSION}",
            "crispr_scoring_version": CRISPR_SCORING_VERSION,
            "prime_scoring_version": PRIME_SCORING_VERSION,
        },
        "model_packs": [],
        "env_fingerprint": _default_env_fingerprint(),
        "policy": {
            "path": policy_rel,
            "sha256": policy_sha,
        },
        "expected_root": expected_rel,
        "optional_backends": list(optional_backends or []),
        "backends": backends,
    }
    return manifest


def build_bundle_manifest(
    *,
    bundle_root: str | Path,
    env_fingerprint: Mapping[str, Any] | None = None,
    model_packs: Sequence[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    root = Path(bundle_root)
    entries: list[dict[str, Any]] = []
    for path in fs.rglob_sorted(root, "*"):
        if path.is_dir():
            continue
        rel = path.relative_to(root).as_posix()
        if rel == "manifest.json":
            continue
        entries.append(
            {
                "path": rel,
                "sha256": sha256_path(path),
                "size": path.stat().st_size,
            }
        )
    manifest = {
        "schema": {"kind": "helix.repro.bundle_manifest", "version": 1},
        "schema_versions": {
            "helix_version": helix_version,
            "schema_version": f"helix.schema/{SPEC_VERSION}",
            "crispr_scoring_version": CRISPR_SCORING_VERSION,
            "prime_scoring_version": PRIME_SCORING_VERSION,
        },
        "model_packs": list(model_packs or []),
        "env_fingerprint": dict(env_fingerprint or _default_env_fingerprint()),
        "files": entries,
    }
    manifest_sha = sha256_canonical_json(manifest)
    manifest["manifest_sha256"] = manifest_sha
    return manifest


@dataclass
class ReproVerificationReport:
    errors: list[str]
    warnings: list[str]
    diffs: list[str]

    @property
    def ok(self) -> bool:
        return not self.errors


def _load_policy(manifest: Mapping[str, Any], manifest_path: Path) -> Mapping[str, Any]:
    policy_info = manifest.get("policy")
    if not isinstance(policy_info, Mapping):
        return {}
    policy_rel = policy_info.get("path")
    if not policy_rel:
        return {}
    policy_path = (manifest_path.parent / str(policy_rel)).resolve()
    if not policy_path.exists():
        return {}
    return _load_json(policy_path)


def _expected_root(manifest: Mapping[str, Any], manifest_path: Path) -> Path | None:
    root_rel = manifest.get("expected_root")
    if not root_rel:
        return None
    return (manifest_path.parent / str(root_rel)).resolve()


def _diff_text(expected: str, actual: str, *, label: str) -> str:
    import difflib

    exp_lines = expected.splitlines()
    act_lines = actual.splitlines()
    diff = difflib.unified_diff(exp_lines, act_lines, fromfile=f"{label}:expected", tofile=f"{label}:actual", lineterm="")
    return "\n".join(diff)


def verify_repro_case(
    *,
    out_dir: str | Path,
    manifest_path: str | Path,
    deterministic: bool = False,
) -> ReproVerificationReport:
    out_dir = Path(out_dir)
    manifest_path = Path(manifest_path)
    manifest = _load_json(manifest_path)

    backends = manifest.get("backends")
    if not isinstance(backends, Mapping):
        raise ReproBundleError("Manifest missing backends map.")

    policy = _load_policy(manifest, manifest_path)
    determinism_class = str(policy.get("determinismClass") or "D0")
    tolerance_map = DEFAULT_TOLERANCE_MAP
    policy_hash = sha256_canonical_json(policy) if policy else None
    semantics_hash = manifest.get("semantic_hash") or ""
    optional_backends = set()
    if isinstance(manifest.get("optional_backends"), list):
        optional_backends.update(str(b) for b in manifest.get("optional_backends") or [])
    if isinstance(policy.get("optional_backends"), list):
        optional_backends.update(str(b) for b in policy.get("optional_backends") or [])

    expected_root = _expected_root(manifest, manifest_path)

    errors: list[str] = []
    warnings: list[str] = []
    diffs: list[str] = []

    for backend, backend_info in backends.items():
        if not isinstance(backend_info, Mapping):
            errors.append(f"manifest backend {backend} is not an object")
            continue
        files = backend_info.get("files")
        if not isinstance(files, list):
            errors.append(f"manifest backend {backend} missing files list")
            continue
        backend_out_dir = out_dir / backend
        if not backend_out_dir.exists():
            msg = f"missing backend outputs: {backend_out_dir}"
            if backend in optional_backends:
                warnings.append(msg)
                continue
            errors.append(msg)
            continue

        for entry in files:
            if not isinstance(entry, Mapping):
                errors.append(f"{backend}: manifest file entry is not an object")
                continue
            rel = str(entry.get("path") or "")
            if not rel:
                errors.append(f"{backend}: manifest file entry missing path")
                continue
            expected_sha = str(entry.get("sha256") or "")
            expected_size = entry.get("size")
            out_path = out_dir / rel
            if not out_path.exists():
                msg = f"{backend}: missing output file {rel}"
                if backend in optional_backends:
                    warnings.append(msg)
                    continue
                errors.append(msg)
                continue
            actual_bytes = out_path.read_bytes()
            actual_sha = sha256_bytes(actual_bytes)
            if expected_size is not None:
                try:
                    if int(expected_size) != len(actual_bytes):
                        errors.append(
                            f"{backend}: size mismatch {rel}: expected {expected_size} got {len(actual_bytes)}"
                        )
                except Exception:
                    errors.append(f"{backend}: invalid size in manifest for {rel}: {expected_size!r}")
            if expected_sha and actual_sha != expected_sha:
                handled_by_tolerance = False
                # D1 tolerant compare for JSON payloads when expected exists
                if expected_root is not None and out_path.suffix.lower() == ".json":
                    exp_path = expected_root / rel
                    if exp_path.exists():
                        try:
                            expected_payload = _load_json(exp_path)
                            actual_payload = json.loads(actual_bytes.decode("utf-8"))
                            diff_list = compare_with_policy(
                                expected_payload,
                                actual_payload,
                                policy=policy or {},
                                determinism_class=determinism_class,
                                tolerance_map=tolerance_map,
                            )
                            if determinism_class == "D1" and not diff_list:
                                handled_by_tolerance = True
                            elif diff_list:
                                first = diff_list[0]
                                path = first.get("path", rel)
                                msg = (
                                    f"{backend}: D1 tolerance exceeded {rel} path={path} "
                                    f"expected={first.get('expected')} actual={first.get('actual')} "
                                    f"tol={first.get('tolerance')} delta={first.get('delta')} "
                                    f"policyHash={policy_hash or ''} semanticHash={semantics_hash} determinism={determinism_class}"
                                )
                                errors.append(msg)
                        except Exception as exc:  # pragma: no cover
                            errors.append(f"{backend}: failed tolerant compare for {rel}: {exc}")
                if handled_by_tolerance:
                    continue
                errors.append(
                    f"{backend}: sha256 mismatch {rel}: expected {expected_sha} got {actual_sha} "
                    f"(policyHash={policy_hash or ''} determinism={determinism_class})"
                )
                if expected_root is not None:
                    exp_path = expected_root / rel
                    if exp_path.exists():
                        try:
                            exp_text = exp_path.read_text(encoding="utf-8")
                            act_text = actual_bytes.decode("utf-8")
                        except Exception:
                            exp_text = ""
                            act_text = ""
                        if exp_text or act_text:
                            diff = _diff_text(exp_text, act_text, label=rel)
                            if diff:
                                diffs.append(diff)

    if deterministic and warnings:
        warnings = [f"[deterministic] {w}" for w in warnings]

    return ReproVerificationReport(errors=errors, warnings=warnings, diffs=diffs)


def compare_backend_outputs(cpu_path: Path | str, gpu_path: Path | str) -> list[str]:
    errors: list[str] = []
    cpu_payload = _load_json(Path(cpu_path))
    gpu_payload = _load_json(Path(gpu_path))

    def _get(obj: Mapping[str, Any], path: str) -> Any:
        cur: Any = obj
        for part in path.split('.'):
            if not isinstance(cur, Mapping):
                return None
            cur = cur.get(part)
        return cur

    for key in ('case_id', 'input_spec_sha256'):
        if cpu_payload.get(key) != gpu_payload.get(key):
            errors.append(f"{key} mismatch: cpu={cpu_payload.get(key)!r} gpu={gpu_payload.get(key)!r}")

    for key in (
        'run.run_id',
        'run.kind',
        'run.seed',
        'run.draws',
        'run.pam_profile',
        'run.pam_softness',
        'run.priors_profile',
    ):
        cpu_val = _get(cpu_payload, key)
        gpu_val = _get(gpu_payload, key)
        if cpu_val != gpu_val:
            errors.append(f"{key} mismatch: cpu={cpu_val!r} gpu={gpu_val!r}")

    for key in ('sequence.sha256', 'sequence.length'):
        cpu_val = _get(cpu_payload, key)
        gpu_val = _get(gpu_payload, key)
        if cpu_val != gpu_val:
            errors.append(f"{key} mismatch: cpu={cpu_val!r} gpu={gpu_val!r}")

    cpu_outcomes = cpu_payload.get('outcomes') if isinstance(cpu_payload.get('outcomes'), list) else []
    gpu_outcomes = gpu_payload.get('outcomes') if isinstance(gpu_payload.get('outcomes'), list) else []
    cpu_map = {str(o.get('label') or ''): o for o in cpu_outcomes if isinstance(o, Mapping)}
    gpu_map = {str(o.get('label') or ''): o for o in gpu_outcomes if isinstance(o, Mapping)}
    if set(cpu_map) != set(gpu_map):
        missing = sorted(set(cpu_map) - set(gpu_map))
        extra = sorted(set(gpu_map) - set(cpu_map))
        errors.append(f"outcome labels mismatch: missing={missing} extra={extra}")
    for label in sorted(set(cpu_map) & set(gpu_map)):
        cpu_entry = cpu_map[label]
        gpu_entry = gpu_map[label]
        for field in ('count', 'probability_1e4', 'diff'):
            if cpu_entry.get(field) != gpu_entry.get(field):
                errors.append(
                    f"outcome {label} {field} mismatch: cpu={cpu_entry.get(field)!r} gpu={gpu_entry.get(field)!r}"
                )

    return errors


__all__ = [
    "ReproBundleError",
    "ReproVerificationReport",
    "compare_backend_outputs",
    "build_bundle_manifest",
    "build_case_manifest",
    "load_case_spec",
    "run_repro_case",
    "verify_repro_case",
]
