from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from helix import clock

from .errors import (
    LicenseCapabilityError,
    LicenseExpiredError,
    LicenseNotFoundError,
    LicenseScopeError,
    LicenseSchemaError,
)
from .verify import verify_issuer_signature


LICENSE_SCHEMA_ID = "helix-license.v1"

_ENV_LICENSE_PATH = "HELIX_LICENSE_PATH"
_ENV_EDIT_PROGRAM_ID = "HELIX_EDIT_PROGRAM_ID"


def _utc_now() -> datetime:
    ts_ns = int(clock.now_ns())
    return datetime.fromtimestamp(ts_ns / 1_000_000_000, tz=timezone.utc)


def _parse_utc(ts: str) -> datetime:
    text = str(ts or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True)
class SigningPublicKey:
    key_id: str
    public_key_b64: str
    public_key_raw: bytes


@dataclass(frozen=True, slots=True)
class HelixLicenseV1:
    license_id: str
    issuer_key_id: str
    org: str
    edit_program_id: str
    capabilities: frozenset[str]
    not_before_utc: str
    not_after_utc: str
    signed_payload_sha256: str
    signing_keys: tuple[SigningPublicKey, ...]
    raw: dict[str, Any]

    @property
    def license_sha256(self) -> str:
        # Canonical identity for this license, stable across formatting.
        return str(self.signed_payload_sha256)

    def is_active(self, *, now_utc: datetime | None = None) -> bool:
        now = now_utc or _utc_now()
        try:
            nb = _parse_utc(self.not_before_utc)
            na = _parse_utc(self.not_after_utc)
        except Exception:
            return False
        return bool(nb <= now <= na)


def _env_license_path() -> str | None:
    raw = os.getenv(_ENV_LICENSE_PATH)
    return raw.strip() if isinstance(raw, str) and raw.strip() else None


def _env_edit_program_id() -> str | None:
    raw = os.getenv(_ENV_EDIT_PROGRAM_ID)
    return raw.strip() if isinstance(raw, str) and raw.strip() else None


def _load_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise LicenseNotFoundError(code="LICENSE_NOT_FOUND", message=f"license file not found: {path}") from exc
    except Exception as exc:
        raise LicenseSchemaError(code="LICENSE_INVALID_JSON", message=f"invalid license JSON: {path}") from exc
    if not isinstance(payload, dict):
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="license must be a JSON object")
    return payload


def _parse_signing_keys(payload: Mapping[str, Any]) -> tuple[SigningPublicKey, ...]:
    import base64

    keys_raw = payload.get("signing_keys")
    if keys_raw is None:
        return ()
    if not isinstance(keys_raw, list):
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="signing_keys must be an array")
    keys: list[SigningPublicKey] = []
    for idx, item in enumerate(keys_raw):
        if not isinstance(item, Mapping):
            raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message=f"signing_keys[{idx}] must be an object")
        key_id = str(item.get("key_id") or "").strip()
        pk_b64 = str(item.get("publicKeyB64") or "").strip()
        if not key_id:
            raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message=f"signing_keys[{idx}].key_id is required")
        if not pk_b64:
            raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message=f"signing_keys[{idx}].publicKeyB64 is required")
        try:
            pk_raw = base64.b64decode(pk_b64, validate=True)
        except Exception as exc:
            raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message=f"signing_keys[{idx}].publicKeyB64 invalid base64") from exc
        if len(pk_raw) != 32:
            raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message=f"signing_keys[{idx}].publicKeyB64 must be 32 raw bytes")
        keys.append(SigningPublicKey(key_id=key_id, public_key_b64=pk_b64, public_key_raw=pk_raw))
    return tuple(keys)


def parse_license_v1(payload: Mapping[str, Any]) -> HelixLicenseV1:
    schema = payload.get("schema")
    if schema != LICENSE_SCHEMA_ID:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_MISMATCH", message=f"expected schema {LICENSE_SCHEMA_ID!r}")

    issuer = payload.get("issuer")
    issuer_key_id = ""
    if isinstance(issuer, Mapping):
        issuer_key_id = str(issuer.get("key_id") or "").strip()
    if not issuer_key_id:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="issuer.key_id is required")

    license_id = str(payload.get("license_id") or "").strip()
    org = str(payload.get("org") or "").strip()
    edit_program_id = str(payload.get("edit_program_id") or "").strip()
    capabilities_raw = payload.get("capabilities")
    not_before_utc = str(payload.get("not_before_utc") or "").strip()
    not_after_utc = str(payload.get("not_after_utc") or "").strip()

    if not license_id:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="license_id is required")
    if not org:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="org is required")
    if not edit_program_id:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="edit_program_id is required")
    if not not_before_utc or not not_after_utc:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="not_before_utc and not_after_utc are required")
    if not isinstance(capabilities_raw, list) or not all(isinstance(x, str) for x in capabilities_raw):
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="capabilities must be an array of strings")
    capabilities = frozenset(str(x).strip() for x in capabilities_raw if str(x).strip())
    if not capabilities:
        raise LicenseSchemaError(code="LICENSE_SCHEMA_INVALID", message="capabilities must be non-empty")

    # Verify issuer signature (fail-closed).
    signed_payload_sha256 = verify_issuer_signature(payload)

    signing_keys = _parse_signing_keys(payload)

    return HelixLicenseV1(
        license_id=license_id,
        issuer_key_id=issuer_key_id,
        org=org,
        edit_program_id=edit_program_id,
        capabilities=capabilities,
        not_before_utc=not_before_utc,
        not_after_utc=not_after_utc,
        signed_payload_sha256=signed_payload_sha256,
        signing_keys=signing_keys,
        raw=dict(payload),
    )


def load_license(*, path: str | Path | None = None) -> HelixLicenseV1:
    p = Path(path) if path is not None else (Path(_env_license_path()) if _env_license_path() else None)
    if p is None:
        raise LicenseNotFoundError(
            code="LICENSE_NOT_CONFIGURED",
            message=f"license path not configured (set {_ENV_LICENSE_PATH})",
        )
    payload = _load_json(p)
    return parse_license_v1(payload)


def require_capability(
    capability: str,
    *,
    edit_program_id: str | None = None,
    license_path: str | Path | None = None,
    now_utc: datetime | None = None,
) -> HelixLicenseV1:
    lic = load_license(path=license_path)

    required_program = (edit_program_id or _env_edit_program_id() or "").strip()
    if not required_program:
        raise LicenseScopeError(
            code="EDIT_PROGRAM_ID_REQUIRED",
            message=f"edit_program_id is required for licensed operations (set {_ENV_EDIT_PROGRAM_ID})",
        )
    if str(lic.edit_program_id) != required_program:
        raise LicenseScopeError(
            code="LICENSE_SCOPE_MISMATCH",
            message="license does not cover this edit program",
            details={"license_edit_program_id": lic.edit_program_id, "requested_edit_program_id": required_program},
        )

    now = now_utc or _utc_now()
    try:
        nb = _parse_utc(lic.not_before_utc)
        na = _parse_utc(lic.not_after_utc)
    except Exception:
        raise LicenseExpiredError(
            code="LICENSE_EXPIRED",
            message="license time window is invalid",
            details={"not_before_utc": lic.not_before_utc, "not_after_utc": lic.not_after_utc},
        )
    if now < nb:
        raise LicenseExpiredError(
            code="LICENSE_NOT_YET_VALID",
            message="license is not yet valid for the current time window",
            details={"not_before_utc": lic.not_before_utc, "not_after_utc": lic.not_after_utc},
        )
    if now > na:
        raise LicenseExpiredError(
            code="LICENSE_EXPIRED",
            message="license is not active for the current time window",
            details={"not_before_utc": lic.not_before_utc, "not_after_utc": lic.not_after_utc},
        )

    cap = str(capability or "").strip()
    if not cap:
        raise LicenseCapabilityError(code="CAPABILITY_REQUIRED", message="capability is required")
    if cap not in lic.capabilities:
        raise LicenseCapabilityError(
            code="CAPABILITY_NOT_GRANTED",
            message="license does not grant the requested capability",
            details={"capability": cap, "granted": sorted(lic.capabilities)},
        )

    return lic


__all__ = [
    "HelixLicenseV1",
    "LICENSE_SCHEMA_ID",
    "SigningPublicKey",
    "load_license",
    "parse_license_v1",
    "require_capability",
]
