from __future__ import annotations

from typing import Any, Mapping


class LicensingError(RuntimeError):
    def __init__(self, *, code: str, message: str, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(str(message))
        self.code = str(code)
        self.details = dict(details or {})

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": str(self.code),
            "message": str(self),
            "details": dict(self.details),
        }


class LicenseNotFoundError(LicensingError):
    pass


class LicenseSchemaError(LicensingError):
    pass


class LicenseSignatureError(LicensingError):
    pass


class LicenseExpiredError(LicensingError):
    pass


class LicenseScopeError(LicensingError):
    pass


class LicenseCapabilityError(LicensingError):
    pass


__all__ = [
    "LicensingError",
    "LicenseNotFoundError",
    "LicenseSchemaError",
    "LicenseSignatureError",
    "LicenseExpiredError",
    "LicenseScopeError",
    "LicenseCapabilityError",
]

