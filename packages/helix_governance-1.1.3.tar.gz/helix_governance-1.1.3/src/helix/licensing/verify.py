from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import clock
from helix.scientific_contract import canonical_json_bytes

from .errors import LicenseSignatureError, LicensingError


CANONICALIZATION_ID = "helix.canonical_json_bytes.v1"

@dataclass(frozen=True, slots=True)
class IssuerPublicKey:
    key_id: str
    public_key_b64: str
    not_before_utc: str | None = None
    not_after_utc: str | None = None

    @property
    def public_key_raw(self) -> bytes:
        raw = base64.b64decode(self.public_key_b64, validate=True)
        if len(raw) != 32:
            raise ValueError("issuer public key must be 32 raw bytes")
        return raw


def _parse_utc(ts: str) -> datetime:
    text = str(ts or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _utc_now() -> datetime:
    ts_ns = int(clock.now_ns())
    return datetime.fromtimestamp(ts_ns / 1_000_000_000, tz=timezone.utc)


# NOTE: These are the Helix issuer public keys (ed25519, 32 raw bytes) encoded as base64.
# They must be pinned in code so license verification never depends on the network or
# a mutable external trust store. Rotation is supported by overlapping windows.
_ISSUER_KEYRING: tuple[IssuerPublicKey, ...] = (
    # Test/dev issuer key (matches tests/fixtures/validation_verdict_vectors/publisher.pub).
    IssuerPublicKey(
        key_id="helix-issuer-test-v1",
        public_key_b64="A6EHv/POEL4dcN0Y50vAmWfk1jCbpQ1fHdyGZBJVMbg=",
        not_before_utc=None,
        not_after_utc=None,
    ),
)


def issuer_keyring() -> tuple[IssuerPublicKey, ...]:
    return tuple(_ISSUER_KEYRING)


def issuer_key_ids() -> tuple[str, ...]:
    return tuple(k.key_id for k in issuer_keyring())


def active_issuer_key_ids(*, now_utc: datetime | None = None) -> tuple[str, ...]:
    now = now_utc or _utc_now()
    out: list[str] = []
    for key in issuer_keyring():
        try:
            nb = _parse_utc(key.not_before_utc) if key.not_before_utc else None
            na = _parse_utc(key.not_after_utc) if key.not_after_utc else None
        except Exception:
            # Bad window config => treat as inactive.
            continue
        if nb is not None and now < nb:
            continue
        if na is not None and now > na:
            continue
        out.append(key.key_id)
    return tuple(sorted(set(out)))


def issuer_public_keys_raw() -> tuple[bytes, ...]:
    keys: list[bytes] = []
    for entry in issuer_keyring():
        try:
            keys.append(entry.public_key_raw)
        except Exception:
            continue
    return tuple(keys)


def issuer_public_key_raw_for_id(key_id: str) -> bytes | None:
    token = str(key_id or "").strip()
    if not token:
        return None
    for entry in issuer_keyring():
        if entry.key_id == token:
            try:
                return entry.public_key_raw
            except Exception:
                return None
    return None


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_signed_payload_sha256(payload: Mapping[str, Any]) -> str:
    """Return sha256:<hex> of the canonical unsigned payload (signature field set to null)."""
    unsigned = dict(payload)
    unsigned["signature"] = None
    msg = canonical_json_bytes(unsigned)
    return f"sha256:{_sha256_hex(msg)}"


def verify_ed25519_signature(
    payload: Mapping[str, Any],
    *,
    allowed_public_keys_raw: Sequence[bytes] | None = None,
    require_allowed_key: bool = False,
) -> tuple[str, bytes]:
    """
    Verify a canonical-json ed25519 signature block.

    Returns:
      (signed_payload_sha256, signer_public_key_raw)
    """
    sig = payload.get("signature")
    if not isinstance(sig, Mapping):
        raise LicenseSignatureError(code="SIGNATURE_MISSING", message="payload missing signature")

    algorithm = sig.get("algorithm")
    if algorithm != "ed25519":
        raise LicenseSignatureError(
            code="SIGNATURE_UNSUPPORTED_ALGORITHM",
            message=f"unsupported signature algorithm: {algorithm!r}",
        )

    canonicalization = sig.get("canonicalization")
    if canonicalization is None or (isinstance(canonicalization, str) and not canonicalization.strip()):
        canonicalization = CANONICALIZATION_ID
    if canonicalization != CANONICALIZATION_ID:
        raise LicenseSignatureError(
            code="SIGNATURE_UNSUPPORTED_CANONICALIZATION",
            message=f"unsupported signature canonicalization: {canonicalization!r}",
        )

    public_key_b64 = sig.get("publicKeyB64")
    signature_b64 = sig.get("signatureB64")
    signed_payload_sha256 = sig.get("signedPayloadSha256")
    if not isinstance(public_key_b64, str) or not isinstance(signature_b64, str) or not isinstance(signed_payload_sha256, str):
        raise LicenseSignatureError(code="SIGNATURE_FIELDS_MISSING", message="signature missing required fields")

    try:
        public_key_raw = base64.b64decode(public_key_b64, validate=True)
        signature_raw = base64.b64decode(signature_b64, validate=True)
    except Exception as exc:
        raise LicenseSignatureError(code="SIGNATURE_FIELDS_INVALID_BASE64", message="invalid base64 in signature fields") from exc

    if len(public_key_raw) != 32:
        raise LicenseSignatureError(code="SIGNATURE_PUBLIC_KEY_INVALID", message="public key must be 32 raw bytes")

    allow = list(allowed_public_keys_raw or [])
    if require_allowed_key:
        if not allow:
            raise LicenseSignatureError(
                code="SIGNATURE_ALLOWLIST_EMPTY",
                message="no allowed issuer public keys are configured",
            )
        if public_key_raw not in allow:
            raise LicenseSignatureError(code="SIGNATURE_PUBLIC_KEY_NOT_ALLOWED", message="public key not in allowlist")

    unsigned = dict(payload)
    unsigned["signature"] = None
    msg = canonical_json_bytes(unsigned)
    computed_sha = f"sha256:{_sha256_hex(msg)}"
    if signed_payload_sha256 != computed_sha:
        raise LicenseSignatureError(
            code="SIGNATURE_SHA_MISMATCH",
            message="signed payload sha256 mismatch",
            details={"expected": signed_payload_sha256, "computed": computed_sha},
        )

    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except Exception as exc:
        raise LicensingError(code="CRYPTOGRAPHY_REQUIRED", message="cryptography is required to verify signatures") from exc

    try:
        Ed25519PublicKey.from_public_bytes(public_key_raw).verify(signature_raw, msg)
    except Exception as exc:
        raise LicenseSignatureError(code="SIGNATURE_INVALID", message="signature verification failed") from exc

    return computed_sha, public_key_raw


def verify_issuer_signature(payload: Mapping[str, Any]) -> str:
    """Verify a Helix-issued payload and return its signed payload sha256."""
    issuer_key_id = None
    issuer = payload.get("issuer")
    if isinstance(issuer, Mapping):
        key_id = str(issuer.get("key_id") or "").strip()
        if key_id:
            issuer_key_id = key_id

    key_raw = issuer_public_key_raw_for_id(issuer_key_id) if issuer_key_id else None
    allow = [key_raw] if key_raw is not None else list(issuer_public_keys_raw())

    signed_sha, pubkey_raw = verify_ed25519_signature(payload, allowed_public_keys_raw=allow, require_allowed_key=True)

    # If key_id was specified, enforce that it points at the signature key.
    if issuer_key_id:
        expected = issuer_public_key_raw_for_id(issuer_key_id)
        if expected is None:
            raise LicenseSignatureError(
                code="ISSUER_KEY_ID_UNKNOWN",
                message="issuer key id is not recognized by this Helix build",
                details={"issuer_key_id": issuer_key_id},
            )
        if pubkey_raw != expected:
            raise LicenseSignatureError(
                code="ISSUER_KEY_ID_MISMATCH",
                message="issuer key id does not match signature public key",
                details={"issuer_key_id": issuer_key_id},
            )

        # Rotation window enforcement: issuer key must be active at the license start time.
        not_before_utc = payload.get("not_before_utc")
        if isinstance(not_before_utc, str) and not_before_utc.strip():
            try:
                lic_start = _parse_utc(not_before_utc)
                key = next((k for k in issuer_keyring() if k.key_id == issuer_key_id), None)
                if key is not None:
                    nb = _parse_utc(key.not_before_utc) if key.not_before_utc else None
                    na = _parse_utc(key.not_after_utc) if key.not_after_utc else None
                    if nb is not None and lic_start < nb:
                        raise LicenseSignatureError(
                            code="ISSUER_KEY_NOT_ACTIVE",
                            message="issuer key is not active for this license window",
                            details={"issuer_key_id": issuer_key_id},
                        )
                    if na is not None and lic_start > na:
                        raise LicenseSignatureError(
                            code="ISSUER_KEY_NOT_ACTIVE",
                            message="issuer key is not active for this license window",
                            details={"issuer_key_id": issuer_key_id},
                        )
            except LicenseSignatureError:
                raise
            except Exception:
                # If we can't parse timestamps, fail closed.
                raise LicenseSignatureError(
                    code="ISSUER_KEY_WINDOW_INVALID",
                    message="failed to validate issuer key rotation window",
                    details={"issuer_key_id": issuer_key_id},
                )

    return signed_sha


def read_private_key_raw(path: str | Path) -> bytes:
    p = Path(path)
    data = p.read_bytes()
    if len(data) == 32:
        return data
    try:
        text = data.decode("utf-8").strip()
        return base64.b64decode(text, validate=True)
    except Exception as exc:
        raise LicensingError(
            code="PRIVATE_KEY_INVALID",
            message=f"invalid private key (expected 32 raw bytes or base64): {p}",
        ) from exc


def sign_ed25519(message: bytes, *, private_key_raw: bytes) -> tuple[bytes, bytes]:
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except Exception as exc:
        raise LicensingError(code="CRYPTOGRAPHY_REQUIRED", message="cryptography is required to sign payloads") from exc

    sk = Ed25519PrivateKey.from_private_bytes(private_key_raw)
    sig = sk.sign(message)
    pk = sk.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return sig, pk


__all__ = [
    "CANONICALIZATION_ID",
    "canonical_signed_payload_sha256",
    "IssuerPublicKey",
    "active_issuer_key_ids",
    "issuer_key_ids",
    "issuer_keyring",
    "issuer_public_keys_raw",
    "issuer_public_key_raw_for_id",
    "read_private_key_raw",
    "sign_ed25519",
    "verify_ed25519_signature",
    "verify_issuer_signature",
]
