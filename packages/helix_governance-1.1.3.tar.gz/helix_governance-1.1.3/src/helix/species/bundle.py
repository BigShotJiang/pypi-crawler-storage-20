"""Species reference bundle build/load utilities."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from helix import clock

from .core import compute_sketch, SketchResult


@dataclass(frozen=True)
class TaxonEntry:
    taxon_id: str
    rank: str
    name: str
    parent_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "taxon_id": self.taxon_id,
            "rank": self.rank,
            "name": self.name,
            "parent_id": self.parent_id,
        }


@dataclass(frozen=True)
class ReferenceEntry:
    ref_id: str
    taxon_id: str
    species_taxon_id: str
    name: str | None = None
    genome_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "ref_id": self.ref_id,
            "taxon_id": self.taxon_id,
            "species_taxon_id": self.species_taxon_id,
            "name": self.name,
            "genome_id": self.genome_id,
        }


@dataclass(frozen=True)
class ReferenceInput:
    ref_id: str
    sequence: str
    taxon_id: str
    species_taxon_id: str
    name: str | None = None
    genome_id: str | None = None

    def to_entry(self) -> ReferenceEntry:
        return ReferenceEntry(
            ref_id=self.ref_id,
            taxon_id=self.taxon_id,
            species_taxon_id=self.species_taxon_id,
            name=self.name,
            genome_id=self.genome_id,
        )


@dataclass(frozen=True)
class SpeciesDbBundle:
    bundle_id: str
    bundle_hash: str
    manifest: dict[str, Any]
    taxonomy: dict[str, TaxonEntry]
    references: list[ReferenceEntry]
    sketches: np.ndarray
    sketch_size: int
    hash_bits: int


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _canonical_json(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_fasta(path: Path) -> Iterable[tuple[str, str]]:
    """Yield (record_id, sequence) from a FASTA file."""
    path = Path(path)
    name = None
    seq_parts: list[str] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            if line.startswith(">"):
                if name is not None:
                    yield name, "".join(seq_parts)
                header = line[1:].strip()
                name = header.split()[0] if header else ""
                seq_parts = []
            else:
                seq_parts.append(line)
    if name is not None:
        yield name, "".join(seq_parts)


def _write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def build_species_db_bundle(
    *,
    references: Sequence[ReferenceInput],
    taxonomy: Sequence[TaxonEntry],
    out_dir: str | Path,
    k: int = 31,
    sketch_size: int = 1024,
    hash_bits: int = 32,
    seed: int = 0,
    stride: int = 1,
    bundle_id: str | None = None,
) -> dict[str, Any]:
    """Build a compact species DB bundle with sketches + taxonomy."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    ref_entries = [r.to_entry() for r in references]
    sketches: list[SketchResult] = []
    for ref in references:
        sketch = compute_sketch(
            [ref.sequence],
            k=k,
            sketch_size=sketch_size,
            hash_bits=hash_bits,
            seed=seed,
            stride=stride,
        )
        sketches.append(sketch)

    if sketches:
        sketch_matrix = np.zeros((len(sketches), sketch_size), dtype=np.uint64 if hash_bits > 32 else np.uint32)
        for idx, sketch in enumerate(sketches):
            row = np.asarray(sketch.to_list(), dtype=sketch_matrix.dtype)
            if row.size < sketch_size:
                pad = np.full(sketch_size - row.size, np.iinfo(sketch_matrix.dtype).max, dtype=sketch_matrix.dtype)
                row = np.concatenate([row, pad])
            sketch_matrix[idx, :] = row
    else:
        sketch_matrix = np.zeros((0, sketch_size), dtype=np.uint64 if hash_bits > 32 else np.uint32)

    taxonomy_path = out_dir / "taxonomy.jsonl"
    references_path = out_dir / "references.jsonl"
    sketches_path = out_dir / "sketches.npy"

    _write_jsonl(taxonomy_path, [t.to_dict() for t in taxonomy])
    _write_jsonl(references_path, [r.to_dict() for r in ref_entries])
    np.save(sketches_path, sketch_matrix)

    manifest = {
        "schema": "helix_species_db_bundle_v1",
        "bundle_id": bundle_id or f"species_db_{_utc_now_iso().replace(':', '').replace('-', '')}",
        "created_at_utc": _utc_now_iso(),
        "build": {
            "k": int(k),
            "sketch_size": int(sketch_size),
            "hash_bits": int(hash_bits),
            "seed": int(seed),
            "stride": int(stride),
        },
        "counts": {
            "references": len(ref_entries),
            "taxa": len(taxonomy),
        },
        "files": {
            "taxonomy": {"path": taxonomy_path.name, "sha256": _sha256_path(taxonomy_path)},
            "references": {"path": references_path.name, "sha256": _sha256_path(references_path)},
            "sketches": {"path": sketches_path.name, "sha256": _sha256_path(sketches_path)},
        },
    }

    manifest_bytes = _canonical_json(manifest)
    manifest["bundle_hash"] = f"sha256:{_sha256_bytes(manifest_bytes)}"
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def load_species_db_bundle(path: str | Path, *, verify: bool = True) -> SpeciesDbBundle:
    """Load a species DB bundle from a directory."""
    root = Path(path)
    manifest_path = root / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Species DB manifest missing: {manifest_path}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != "helix_species_db_bundle_v1":
        raise ValueError("Unsupported species DB bundle schema")

    def _load_file(entry_key: str) -> Path:
        entry = manifest.get("files", {}).get(entry_key, {})
        rel = entry.get("path")
        if not rel:
            raise ValueError(f"Missing {entry_key} file in bundle manifest")
        return root / rel

    taxonomy_path = _load_file("taxonomy")
    references_path = _load_file("references")
    sketches_path = _load_file("sketches")

    if verify:
        for key, path_obj in ("taxonomy", taxonomy_path), ("references", references_path), ("sketches", sketches_path):
            expected = manifest.get("files", {}).get(key, {}).get("sha256")
            if expected and expected != _sha256_path(path_obj):
                raise ValueError(f"Bundle file hash mismatch: {key}")

    taxonomy_rows = _read_jsonl(taxonomy_path)
    references_rows = _read_jsonl(references_path)
    taxonomy = {
        str(t.get("taxon_id")): TaxonEntry(
            taxon_id=str(t.get("taxon_id")),
            rank=str(t.get("rank")),
            name=str(t.get("name")),
            parent_id=str(t.get("parent_id")) if t.get("parent_id") is not None else None,
        )
        for t in taxonomy_rows
        if t.get("taxon_id") is not None
    }
    references = [
        ReferenceEntry(
            ref_id=str(r.get("ref_id")),
            taxon_id=str(r.get("taxon_id")),
            species_taxon_id=str(r.get("species_taxon_id")),
            name=str(r.get("name")) if r.get("name") is not None else None,
            genome_id=str(r.get("genome_id")) if r.get("genome_id") is not None else None,
        )
        for r in references_rows
        if r.get("ref_id") is not None
    ]

    sketches = np.load(sketches_path)
    build_cfg = manifest.get("build", {}) if isinstance(manifest.get("build"), Mapping) else {}
    sketch_size = int(build_cfg.get("sketch_size") or (sketches.shape[1] if sketches.ndim > 1 else 0))
    hash_bits = int(build_cfg.get("hash_bits") or (64 if sketches.dtype == np.uint64 else 32))

    bundle_hash = str(manifest.get("bundle_hash") or "")
    bundle_id = str(manifest.get("bundle_id") or "")
    return SpeciesDbBundle(
        bundle_id=bundle_id,
        bundle_hash=bundle_hash,
        manifest=manifest,
        taxonomy=taxonomy,
        references=references,
        sketches=sketches,
        sketch_size=sketch_size,
        hash_bits=hash_bits,
    )
