"""Shared utilities for species detection (CPU reference path)."""
from __future__ import annotations

from dataclasses import dataclass
import heapq
from typing import Iterable, Iterator, Sequence

DNA_ALPHABET = "ACGT"
BASE_TO_BITS = {"A": 0, "C": 1, "G": 2, "T": 3}
MASK_64 = 0xFFFFFFFFFFFFFFFF


def normalize_sequence(seq: str) -> str:
    """Uppercase and keep A/C/G/T; leave other bases as 'N' so positions are stable."""
    seq = str(seq or "").upper()
    if not seq:
        return ""
    # Preserve length; replace non-ACGT with N.
    return "".join(ch if ch in DNA_ALPHABET else "N" for ch in seq)


def splitmix64(x: int) -> int:
    """Deterministic 64-bit mix (public domain splitmix64)."""
    z = (x + 0x9E3779B97F4A7C15) & MASK_64
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & MASK_64
    z = (z ^ (z >> 27)) * 0x94D049BB133111EB & MASK_64
    return z ^ (z >> 31)


def _hash_value(value: int, *, seed: int, hash_bits: int) -> int:
    mixed = splitmix64((value ^ seed) & MASK_64)
    if hash_bits <= 32:
        return mixed & 0xFFFFFFFF
    return mixed & MASK_64


def iter_canonical_kmer_hashes(
    seq: str,
    *,
    k: int,
    stride: int,
    seed: int,
    hash_bits: int,
) -> Iterator[int]:
    """Yield deterministic hashes of canonical k-mers in `seq` with stride."""
    seq = normalize_sequence(seq)
    if k <= 0 or not seq:
        return
    stride = max(1, int(stride))

    if k > 32:
        # Fallback: string-based canonicalization (slower but correct).
        table = str.maketrans("ACGT", "TGCA")
        for i in range(0, len(seq) - k + 1, stride):
            kmer = seq[i : i + k]
            if "N" in kmer:
                continue
            rc = kmer.translate(table)[::-1]
            canonical = kmer if kmer <= rc else rc
            val = 0
            for ch in canonical:
                val = (val << 2) | BASE_TO_BITS[ch]
            yield _hash_value(val, seed=seed, hash_bits=hash_bits)
        return

    mask = (1 << (2 * k)) - 1
    shift = (k - 1) * 2
    fwd = 0
    rev = 0
    valid = 0
    for i, ch in enumerate(seq):
        v = BASE_TO_BITS.get(ch)
        if v is None:
            valid = 0
            fwd = 0
            rev = 0
            continue
        fwd = ((fwd << 2) | v) & mask
        rev = (rev >> 2) | ((3 - v) << shift)
        valid += 1
        if valid < k:
            continue
        start = i - k + 1
        if start % stride != 0:
            continue
        canonical = fwd if fwd < rev else rev
        yield _hash_value(canonical, seed=seed, hash_bits=hash_bits)


def bottom_k_unique(values: Iterable[int], k: int) -> list[int]:
    """Deterministically keep the smallest k unique values."""
    if k <= 0:
        return []
    heap: list[int] = []  # max-heap via negatives
    seen: set[int] = set()
    for value in values:
        if value in seen:
            continue
        if len(heap) < k:
            heapq.heappush(heap, -value)
            seen.add(value)
            continue
        current_max = -heap[0]
        if value >= current_max:
            continue
        removed = -heapq.heapreplace(heap, -value)
        seen.discard(removed)
        seen.add(value)
    return sorted(-v for v in heap)


@dataclass(frozen=True)
class SketchResult:
    k: int
    size: int
    hash_bits: int
    hashes: tuple[int, ...]

    def to_list(self) -> list[int]:
        return list(self.hashes)


def compute_sketch(
    sequences: Sequence[str],
    *,
    k: int,
    sketch_size: int,
    hash_bits: int,
    seed: int,
    stride: int,
) -> SketchResult:
    """Compute a deterministic bottom-k sketch across sequences."""
    def _all_hashes() -> Iterator[int]:
        for seq in sequences:
            yield from iter_canonical_kmer_hashes(seq, k=k, stride=stride, seed=seed, hash_bits=hash_bits)

    sketch = bottom_k_unique(_all_hashes(), sketch_size)
    return SketchResult(k=k, size=len(sketch), hash_bits=hash_bits, hashes=tuple(sketch))
