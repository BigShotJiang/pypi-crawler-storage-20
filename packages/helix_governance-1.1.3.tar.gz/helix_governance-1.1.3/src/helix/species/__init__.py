"""Species detection utilities and reference bundles."""
from __future__ import annotations

from .bundle import (
    SpeciesDbBundle,
    TaxonEntry,
    ReferenceEntry,
    ReferenceInput,
    build_species_db_bundle,
    load_species_db_bundle,
    read_fasta,
)
from .detect import SpeciesDetectionParams, species_detect_run_cpu
from .builder import build_bundle_from_fasta, load_reference_map_tsv, load_taxonomy_jsonl

__all__ = [
    "SpeciesDbBundle",
    "TaxonEntry",
    "ReferenceEntry",
    "ReferenceInput",
    "build_species_db_bundle",
    "load_species_db_bundle",
    "read_fasta",
    "SpeciesDetectionParams",
    "species_detect_run_cpu",
    "build_bundle_from_fasta",
    "load_reference_map_tsv",
    "load_taxonomy_jsonl",
]
