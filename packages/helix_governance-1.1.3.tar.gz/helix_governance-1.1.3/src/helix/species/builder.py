"""Helper utilities to build species DB bundles from reference FASTA + maps."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .bundle import ReferenceInput, TaxonEntry, build_species_db_bundle, read_fasta


@dataclass(frozen=True)
class ReferenceMapRow:
    ref_id: str
    taxon_id: str
    species_taxon_id: str
    name: str | None = None
    genome_id: str | None = None


def load_reference_map_tsv(path: str | Path) -> dict[str, ReferenceMapRow]:
    path = Path(path)
    rows: dict[str, ReferenceMapRow] = {}
    with path.open("r", encoding="utf-8") as handle:
        header = None
        for line in handle:
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t")
            if header is None:
                header = [p.strip().lower() for p in parts]
                continue
            if header is None:
                continue
            values = {header[idx]: parts[idx].strip() if idx < len(parts) else "" for idx in range(len(header))}
            ref_id = values.get("ref_id") or values.get("reference_id") or values.get("ref")
            if not ref_id:
                continue
            taxon_id = values.get("taxon_id") or values.get("taxon") or values.get("species_taxon_id")
            species_taxon_id = values.get("species_taxon_id") or values.get("species_id") or values.get("species") or taxon_id
            if not species_taxon_id:
                continue
            rows[str(ref_id)] = ReferenceMapRow(
                ref_id=str(ref_id),
                taxon_id=str(taxon_id or species_taxon_id),
                species_taxon_id=str(species_taxon_id),
                name=values.get("name") or values.get("species_name"),
                genome_id=values.get("genome_id") or values.get("assembly_id"),
            )
    return rows


def load_taxonomy_jsonl(path: str | Path) -> list[TaxonEntry]:
    path = Path(path)
    tax: list[TaxonEntry] = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            import json

            row = json.loads(line)
            taxon_id = row.get("taxon_id")
            rank = row.get("rank")
            name = row.get("name")
            if not taxon_id or not rank or not name:
                continue
            tax.append(
                TaxonEntry(
                    taxon_id=str(taxon_id),
                    rank=str(rank),
                    name=str(name),
                    parent_id=str(row.get("parent_id")) if row.get("parent_id") is not None else None,
                )
            )
    return tax


def build_bundle_from_fasta(
    *,
    fasta_paths: Iterable[str | Path],
    ref_map_path: str | Path,
    taxonomy_path: str | Path | None,
    out_dir: str | Path,
    k: int = 31,
    sketch_size: int = 1024,
    hash_bits: int = 32,
    seed: int = 0,
    stride: int = 1,
    bundle_id: str | None = None,
    strict: bool = False,
) -> dict:
    ref_map = load_reference_map_tsv(ref_map_path)
    references: list[ReferenceInput] = []
    for fasta_path in fasta_paths:
        for ref_id, sequence in read_fasta(Path(fasta_path)):
            meta = ref_map.get(ref_id)
            if meta is None:
                if strict:
                    raise ValueError(f"Missing mapping for reference {ref_id}")
                continue
            references.append(
                ReferenceInput(
                    ref_id=meta.ref_id,
                    sequence=sequence,
                    taxon_id=meta.taxon_id,
                    species_taxon_id=meta.species_taxon_id,
                    name=meta.name,
                    genome_id=meta.genome_id,
                )
            )

    taxonomy: list[TaxonEntry] = []
    if taxonomy_path:
        taxonomy = load_taxonomy_jsonl(taxonomy_path)

    return build_species_db_bundle(
        references=references,
        taxonomy=taxonomy,
        out_dir=out_dir,
        k=k,
        sketch_size=sketch_size,
        hash_bits=hash_bits,
        seed=seed,
        stride=stride,
        bundle_id=bundle_id,
    )
