"""CPU reference implementation for species detection."""
from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
from typing import Any, Mapping, Sequence

import numpy as np

from helix import clock

from .bundle import SpeciesDbBundle, load_species_db_bundle
from .core import compute_sketch


@dataclass(frozen=True)
class SpeciesDetectionParams:
    k: int = 31
    sketch_size: int = 1024
    hash_bits: int = 32
    seed: int = 0
    read_stride: int = 4
    contig_stride: int = 1
    input_kind: str | None = None  # "reads" | "contigs" | "genome"
    top_k: int = 10
    min_score: float = 0.01
    min_margin: float = 0.05
    mixed_min_p: float = 0.2
    mixed_max_p: float = 0.7
    genus_min_p: float = 0.6

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _sha256_json(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _flatten_sequences(input_sequences: Sequence[str] | str) -> list[str]:
    if isinstance(input_sequences, str):
        return [input_sequences]
    return [str(s) for s in input_sequences]


def _infer_input_kind(sequences: Sequence[str]) -> str:
    if not sequences:
        return "reads"
    lengths = [len(s) for s in sequences]
    avg = sum(lengths) / max(1, len(lengths))
    if avg < 500:
        return "reads"
    if avg < 20000:
        return "contigs"
    return "genome"


def _query_sketch(
    sequences: Sequence[str],
    *,
    params: SpeciesDetectionParams,
) -> tuple[list[int], dict[str, Any]]:
    input_kind = params.input_kind or _infer_input_kind(sequences)
    stride = params.read_stride if input_kind == "reads" else params.contig_stride
    sketch = compute_sketch(
        sequences,
        k=params.k,
        sketch_size=params.sketch_size,
        hash_bits=params.hash_bits,
        seed=params.seed,
        stride=stride,
    )
    meta = {
        "input_kind": input_kind,
        "stride": stride,
        "k": params.k,
        "sketch_size": params.sketch_size,
        "hash_bits": params.hash_bits,
    }
    return list(sketch.hashes), meta


def _intersection_count(sorted_a: Sequence[int], sorted_b: Sequence[int]) -> int:
    i = 0
    j = 0
    count = 0
    len_a = len(sorted_a)
    len_b = len(sorted_b)
    while i < len_a and j < len_b:
        a = sorted_a[i]
        b = sorted_b[j]
        if a == b:
            count += 1
            i += 1
            j += 1
        elif a < b:
            i += 1
        else:
            j += 1
    return count


def _aggregate_species_scores(
    scores: Sequence[float],
    species_ids: Sequence[str],
) -> dict[str, float]:
    out: dict[str, float] = {}
    for species_id, score in zip(species_ids, scores):
        if species_id not in out or score > out[species_id]:
            out[species_id] = score
    return out


def _normalize_posterior(scores: Mapping[str, float]) -> dict[str, float]:
    total = float(sum(max(0.0, s) for s in scores.values()))
    if total <= 0.0:
        return {k: 0.0 for k in scores}
    return {k: max(0.0, float(v)) / total for k, v in scores.items()}


def _resolve_species(
    *,
    species_scores: dict[str, float],
    posterior: dict[str, float],
    params: SpeciesDetectionParams,
) -> dict[str, Any]:
    if not species_scores:
        return {
            "status": "unresolved",
            "reason": "no_matches",
            "taxon_id": None,
            "name": None,
            "score": 0.0,
            "posterior": 0.0,
            "margin": 0.0,
        }
    ordered = sorted(species_scores.items(), key=lambda kv: (-kv[1], kv[0]))
    top_id, top_score = ordered[0]
    top_p = posterior.get(top_id, 0.0)
    second_score = ordered[1][1] if len(ordered) > 1 else 0.0
    margin = float(top_score - second_score)
    if top_score >= params.min_score and margin >= params.min_margin:
        return {
            "status": "resolved",
            "taxon_id": top_id,
            "score": float(top_score),
            "posterior": float(top_p),
            "margin": margin,
            "reason": None,
        }
    if top_p <= params.mixed_max_p:
        ordered_p = sorted(posterior.items(), key=lambda kv: (-kv[1], kv[0]))
        second_p = ordered_p[1][1] if len(ordered_p) > 1 else 0.0
        if second_p >= params.mixed_min_p:
            return {
                "status": "mixed",
                "taxon_id": top_id,
                "score": float(top_score),
                "posterior": float(top_p),
                "margin": margin,
                "reason": "posterior_split",
            }
    return {
        "status": "unresolved",
        "taxon_id": top_id,
        "score": float(top_score),
        "posterior": float(top_p),
        "margin": margin,
        "reason": "low_margin",
    }


def _aggregate_genus(
    species_scores: Mapping[str, float],
    taxonomy: Mapping[str, Any],
) -> dict[str, float]:
    genus_scores: dict[str, float] = {}
    for species_id, score in species_scores.items():
        tax = taxonomy.get(species_id)
        if not tax:
            continue
        parent = tax.parent_id if hasattr(tax, "parent_id") else tax.get("parent_id")
        rank = tax.rank if hasattr(tax, "rank") else tax.get("rank")
        genus_id = None
        if rank == "genus":
            genus_id = species_id
        elif parent:
            genus_id = str(parent)
        if genus_id is None:
            continue
        if genus_id not in genus_scores or score > genus_scores[genus_id]:
            genus_scores[genus_id] = score
    return genus_scores


def _summarize_taxon(taxon_id: str | None, taxonomy: Mapping[str, Any]) -> dict[str, Any] | None:
    if not taxon_id:
        return None
    entry = taxonomy.get(taxon_id)
    if entry is None:
        return {"taxon_id": taxon_id, "name": None, "rank": None}
    name = entry.name if hasattr(entry, "name") else entry.get("name")
    rank = entry.rank if hasattr(entry, "rank") else entry.get("rank")
    parent = entry.parent_id if hasattr(entry, "parent_id") else entry.get("parent_id")
    return {"taxon_id": taxon_id, "name": name, "rank": rank, "parent_id": parent}


def species_detect_run_cpu(
    input_sequences: Sequence[str] | str,
    db_bundle: SpeciesDbBundle | str,
    params: SpeciesDetectionParams | None = None,
) -> dict[str, Any]:
    params = params or SpeciesDetectionParams()
    sequences = _flatten_sequences(input_sequences)
    bundle = db_bundle if isinstance(db_bundle, SpeciesDbBundle) else load_species_db_bundle(db_bundle)

    query_sketch, sketch_meta = _query_sketch(sequences, params=params)
    query_sketch_sorted = sorted(query_sketch)
    query_sketch_size = len(query_sketch_sorted)

    reference_sketches = bundle.sketches
    ref_meta = bundle.references
    if reference_sketches.ndim != 2:
        raise ValueError("Reference sketches must be a 2D array")

    scores: list[float] = []
    ref_species_ids: list[str] = []
    for idx, ref in enumerate(ref_meta):
        ref_sketch = reference_sketches[idx].tolist()
        max_val = int(np.iinfo(reference_sketches.dtype).max)
        ref_sketch = [v for v in ref_sketch if int(v) != max_val]
        matches = _intersection_count(query_sketch_sorted, ref_sketch)
        denom = max(1, query_sketch_size)
        score = float(matches) / float(denom)
        scores.append(score)
        ref_species_ids.append(str(ref.species_taxon_id))

    species_scores = _aggregate_species_scores(scores, ref_species_ids)
    posterior = _normalize_posterior(species_scores)

    ordered_species = sorted(species_scores.items(), key=lambda kv: (-kv[1], kv[0]))
    top_k = max(1, int(params.top_k))
    hypotheses = []
    for taxon_id, score in ordered_species[:top_k]:
        taxon_summary = _summarize_taxon(taxon_id, bundle.taxonomy)
        hypotheses.append(
            {
                "taxon": taxon_summary,
                "score": float(score),
                "posterior": float(posterior.get(taxon_id, 0.0)),
            }
        )

    genus_scores = _aggregate_genus(species_scores, bundle.taxonomy)
    genus_posterior = _normalize_posterior(genus_scores)
    genus_ordered = sorted(genus_scores.items(), key=lambda kv: (-kv[1], kv[0]))
    genus_hypotheses = []
    for taxon_id, score in genus_ordered[:top_k]:
        taxon_summary = _summarize_taxon(taxon_id, bundle.taxonomy)
        genus_hypotheses.append(
            {
                "taxon": taxon_summary,
                "score": float(score),
                "posterior": float(genus_posterior.get(taxon_id, 0.0)),
            }
        )

    resolution = _resolve_species(species_scores=species_scores, posterior=posterior, params=params)
    if resolution["status"] != "resolved":
        if genus_ordered:
            genus_top_id, genus_top_score = genus_ordered[0]
            genus_top_p = genus_posterior.get(genus_top_id, 0.0)
            if genus_top_p >= params.genus_min_p:
                resolution = {
                    "status": "genus",
                    "taxon_id": genus_top_id,
                    "score": float(genus_top_score),
                    "posterior": float(genus_top_p),
                    "margin": None,
                    "reason": "genus_only",
                }

    input_bp = sum(len(s) for s in sequences)
    input_digest = _sha256_json({"sequences": sequences})
    sketch_digest = _sha256_json({"sketch": query_sketch_sorted})

    artifact = {
        "schema": "species_detection_v1",
        "created_at_utc": _utc_now_iso(),
        "db_bundle_id": bundle.bundle_id,
        "db_bundle_hash": bundle.bundle_hash,
        "params": params.to_dict(),
        "backend": {
            "kind": "cpu",
            "cuda_available": False,
            "deterministic": True,
        },
        "inputs": {
            "sequence_count": len(sequences),
            "total_bases": int(input_bp),
            "input_kind": sketch_meta.get("input_kind"),
            "input_digest": f"sha256:{input_digest}",
        },
        "sketch": {
            "k": sketch_meta.get("k"),
            "sketch_size": sketch_meta.get("sketch_size"),
            "hash_bits": sketch_meta.get("hash_bits"),
            "query_hashes": query_sketch_sorted,
            "query_digest": f"sha256:{sketch_digest}",
        },
        "methods": {
            "classification": {
                "metric": "minhash_jaccard",
                "top_k": top_k,
            },
            "confirmation": {"status": "not_attempted", "reason": "gpu_ani_not_implemented"},
        },
        "hypotheses": hypotheses,
        "genus_hypotheses": genus_hypotheses,
        "resolution": resolution,
        "novelty": {"status": "unknown", "reason": "no_novelty_model"},
        "blocking_issues": [
            "species_unresolved" if resolution.get("status") in {"unresolved", "mixed"} else ""
        ],
    }
    artifact["blocking_issues"] = [s for s in artifact["blocking_issues"] if s]
    artifact_hash = _sha256_json({**artifact, "artifact_hash": ""})
    artifact["artifact_hash"] = f"sha256:{artifact_hash}"
    return artifact


__all__ = ["SpeciesDetectionParams", "species_detect_run_cpu"]
