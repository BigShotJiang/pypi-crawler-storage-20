from __future__ import annotations

from typing import Any

try:  # optional FastAPI integration
    from fastapi import APIRouter, HTTPException
except ImportError:  # pragma: no cover - FastAPI not installed
    APIRouter = None
    HTTPException = Exception

from .run_registry_client import RunRegistryClient
from .analysis_client import AnalysisClient, AnalysisClientConfig


def list_runs(client: RunRegistryClient) -> list[dict[str, Any]]:
    return client.list_runs()


def get_run(run_id: str, client: RunRegistryClient) -> dict[str, Any] | None:
    return client.get_run(run_id)


if APIRouter:  # pragma: no cover - only when FastAPI available
    router = APIRouter()
    _default_client: RunRegistryClient | None = None
    _analysis_client: AnalysisClient | None = None

    def set_client(client: RunRegistryClient, analysis_client: AnalysisClient | None = None) -> None:
        global _default_client
        global _analysis_client
        _default_client = client
        _analysis_client = analysis_client

    @router.get("/api/instrument_runs")
    def api_list_runs() -> list[dict[str, Any]]:
        if _default_client is None:
            raise HTTPException(status_code=500, detail="RunRegistryClient not configured")
        return list_runs(_default_client)

    @router.get("/api/instrument_runs/{run_id}")
    def api_get_run(run_id: str) -> dict[str, Any]:
        if _default_client is None:
            raise HTTPException(status_code=500, detail="RunRegistryClient not configured")
        detail = get_run(run_id, _default_client)
        if detail is None:
            raise HTTPException(status_code=404, detail="run not found")
        return detail

    @router.get("/api/instrument_runs/{run_id}/analysis")
    def api_get_run_analysis(run_id: str) -> dict[str, Any]:
        if _analysis_client is None:
            raise HTTPException(status_code=404, detail="analysis not configured")
        result = _analysis_client.get_by_run(run_id)
        if result is None:
            raise HTTPException(status_code=404, detail="analysis not found")
        return result
