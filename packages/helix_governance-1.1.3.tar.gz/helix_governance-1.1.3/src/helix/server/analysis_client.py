from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests


@dataclass
class AnalysisClientConfig:
    base_url: str


class AnalysisClient:
    def __init__(self, cfg: AnalysisClientConfig, session: requests.Session | None = None) -> None:
        self._cfg = cfg
        self._session = session or requests.Session()

    def get_by_run(self, run_id: str) -> dict[str, Any] | None:
        resp = self._session.get(f"{self._cfg.base_url}/analysis/by_run/{run_id}", timeout=10)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()
