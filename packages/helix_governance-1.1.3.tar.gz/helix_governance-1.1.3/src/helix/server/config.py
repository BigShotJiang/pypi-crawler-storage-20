from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class IngestRegistryConfig:
    base_url: str = "http://localhost:8001"


@dataclass
class HelixConfig:
    ingest_registry: IngestRegistryConfig = field(default_factory=IngestRegistryConfig)
    # add other server config fields here as needed


def load_config() -> HelixConfig:
    ingest_base = os.getenv("HELIX_INGEST_REGISTRY_URL", IngestRegistryConfig.base_url)
    ingest_cfg = IngestRegistryConfig(base_url=ingest_base)
    return HelixConfig(ingest_registry=ingest_cfg)
