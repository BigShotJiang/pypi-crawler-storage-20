from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests


@dataclass
class RunRegistryConfig:
    base_url: str


class RunRegistryClient:
    def __init__(self, cfg: RunRegistryConfig, session: requests.Session | None = None) -> None:
        self._cfg = cfg
        self._session = session or requests.Session()

    def list_runs(self) -> list[dict[str, Any]]:
        resp = self._session.get(f"{self._cfg.base_url}/runs", timeout=10)
        resp.raise_for_status()
        return resp.json()

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        resp = self._session.get(f"{self._cfg.base_url}/runs/{run_id}", timeout=10)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()
