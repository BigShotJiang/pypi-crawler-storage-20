"""Helix core package.

This module avoids heavy import-time side effects so that lightweight
subsystems (e.g. config + dynamic simulators) remain usable in minimal
environments.
"""

from __future__ import annotations

from importlib import import_module, metadata
from pathlib import Path
import re
from typing import Any, Dict, Tuple

_VERSION_RE = re.compile(r'^version\s*=\s*"(?P<version>[^"]+)"\s*$')


def _read_pyproject_version() -> str | None:
    """Best-effort version lookup when running from a source tree (no dist metadata)."""

    pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
    try:
        text = pyproject.read_text(encoding="utf-8")
    except Exception:
        return None
    in_project = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            in_project = line == "[project]"
            continue
        if not in_project:
            continue
        match = _VERSION_RE.match(line)
        if match:
            return match.group("version").strip()
    return None


try:  # pragma: no cover - metadata only at runtime
    __version__ = metadata.version("helix-governance")
except metadata.PackageNotFoundError:  # pragma: no cover - source tree / editable installs
    __version__ = _read_pyproject_version() or "0.0.0"


_MODULE_EXPORTS: Dict[str, str] = {
    "bioinformatics": "helix.bioinformatics",
    "codon": "helix.codon",
    "cyclospectrum": "helix.cyclospectrum",
    "triage": "helix.triage",
    "string": "helix.string",
    "seed": "helix.seed",
    "motif": "helix.motif",
    "crispr": "helix.crispr",
    "prime": "helix.prime",
    "sim": "helix.sim",
    "pcr": "helix.pcr",
    "core": "helix.core",
    "nodes": "helix.nodes",
    "live": "helix.live",
    "dsl": "helix.dsl",
}

_ATTR_EXPORTS: Dict[str, Tuple[str, str]] = {
    "dna_summary": ("helix.api", "dna_summary"),
    "triage_report": ("helix.api", "triage_report"),
    "fold_rna": ("helix.api", "fold_rna"),
    "spectrum_leaderboard": ("helix.api", "spectrum_leaderboard"),
    "protein_summary": ("helix.api", "protein_summary"),
    "crispr_outcome_posterior": ("helix.api", "crispr_outcome_posterior"),
    "prime_outcome_posterior": ("helix.api", "prime_outcome_posterior"),
    "CasSystem": ("helix.crispr.model", "CasSystem"),
    "CasSystemType": ("helix.crispr.model", "CasSystemType"),
    "DigitalGenome": ("helix.crispr.model", "DigitalGenome"),
    "GuideRNA": ("helix.crispr.model", "GuideRNA"),
    "PAMRule": ("helix.crispr.model", "PAMRule"),
    "TargetSite": ("helix.crispr.model", "TargetSite"),
    "CutEvent": ("helix.crispr.simulator", "CutEvent"),
    "EfficiencyTargetRequest": ("helix.crispr.simulator", "EfficiencyTargetRequest"),
    "EfficiencyPrediction": ("helix.crispr.simulator", "EfficiencyPrediction"),
    "find_candidate_sites": ("helix.crispr.simulator", "find_candidate_sites"),
    "predict_efficiency_for_targets": ("helix.crispr.simulator", "predict_efficiency_for_targets"),
    "simulate_cuts": ("helix.crispr.simulator", "simulate_cuts"),
    "rank_off_targets": ("helix.crispr.simulator", "rank_off_targets"),
    "PegRNA": ("helix.prime.model", "PegRNA"),
    "PrimeEditor": ("helix.prime.model", "PrimeEditor"),
    "PrimeEditOutcome": ("helix.prime.model", "PrimeEditOutcome"),
    "locate_prime_target_site": ("helix.prime.simulator", "locate_prime_target_site"),
    "simulate_prime_edit": ("helix.prime.simulator", "simulate_prime_edit"),
}


def __getattr__(name: str) -> Any:  # pragma: no cover - exercised via imports
    if name in _MODULE_EXPORTS:
        module = import_module(_MODULE_EXPORTS[name])
        globals()[name] = module
        return module
    if name in _ATTR_EXPORTS:
        module_name, attr = _ATTR_EXPORTS[name]
        module = import_module(module_name)
        value = getattr(module, attr)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "bioinformatics",
    "codon",
    "cyclospectrum",
    "triage",
    "string",
    "seed",
    "motif",
    "crispr",
    "pcr",
    "core",
    "nodes",
    "live",
    "dsl",
    "CasSystemType",
    "PAMRule",
    "CasSystem",
    "GuideRNA",
    "TargetSite",
    "DigitalGenome",
    "CutEvent",
    "EfficiencyTargetRequest",
    "EfficiencyPrediction",
    "find_candidate_sites",
    "predict_efficiency_for_targets",
    "simulate_cuts",
    "rank_off_targets",
    "prime",
    "sim",
    "PegRNA",
    "PrimeEditor",
    "PrimeEditOutcome",
    "locate_prime_target_site",
    "simulate_prime_edit",
    "dna_summary",
    "triage_report",
    "fold_rna",
    "spectrum_leaderboard",
    "protein_summary",
    "crispr_outcome_posterior",
    "prime_outcome_posterior",
    "__version__",
]
