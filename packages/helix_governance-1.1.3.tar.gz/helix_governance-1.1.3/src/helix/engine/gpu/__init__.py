"""GPU kernels and helpers (placeholder for L0 thermodynamics CUDA backend).

This module provides a CPU fallback so imports succeed even without CUDA; the
real CUDA implementation will live alongside this interface.
"""

from .l0_thermo import l0_thermo_scores_cpu, l0_thermo_scores_gpu, ThermoParams

__all__ = ["l0_thermo_scores_cpu", "l0_thermo_scores_gpu", "ThermoParams"]
