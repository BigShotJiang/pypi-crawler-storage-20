from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Tuple

import numpy as np

try:  # pragma: no cover - optional native extension
    from helix_engine import native as native_engine  # type: ignore
except Exception:  # pragma: no cover
    native_engine = None


@dataclass
class ThermoParams:
    temperature_c: float = 37.0
    na_mM: float = 50.0
    mg_mM: float = 0.0


# SantaLucia-ish nearest-neighbor ΔG values (kcal/mol) at 37°C, A/C/G/T encoded 0..3.
_NN_DG = np.array(
    [
        -1.00, -1.44, -1.30, -0.88,  # A*
        -1.45, -1.84, -2.24, -1.28,  # C*
        -1.30, -2.17, -1.84, -1.44,  # G*
        -0.58, -1.30, -1.45, -1.00,  # T*
    ],
    dtype=np.float32,
)

_BASE_MAP = {
    ord("A"): 0,
    ord("C"): 1,
    ord("G"): 2,
    ord("T"): 3,
    ord("U"): 3,
}


def _encode_seq(seq: str) -> np.ndarray:
    return np.fromiter((_BASE_MAP.get(ord(ch.upper()), 0) for ch in seq), dtype=np.uint8)


def _encode_batch(seqs: list[str]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    lengths = np.fromiter((len(s) for s in seqs), dtype=np.int32)
    offsets = np.empty(len(seqs), dtype=np.int32)
    total = int(lengths.sum())
    flat = np.empty(total, dtype=np.uint8)
    pos = 0
    for i, seq in enumerate(seqs):
        offsets[i] = pos
        enc = _encode_seq(seq)
        flat[pos : pos + len(seq)] = enc
        pos += len(seq)
    return flat, offsets, lengths


def _tm_from_dg(dg: float, length: int, params: ThermoParams) -> float:
    if length <= 1:
        return params.temperature_c
    # simple monotonic mapping: stronger (more negative) ΔG -> higher Tm
    return params.temperature_c + (-dg) / max(1.0, 0.1 * float(length))


def l0_thermo_scores_cpu(seqs: Iterable[str], params: ThermoParams | None = None) -> Tuple[np.ndarray, np.ndarray]:
    params = params or ThermoParams()
    seq_list = list(seqs)
    n = len(seq_list)
    dG = np.zeros(n, dtype=np.float32)
    tm = np.zeros(n, dtype=np.float32)
    for i, seq in enumerate(seq_list):
        enc = _encode_seq(seq)
        if enc.size < 2:
            tm[i] = params.temperature_c
            continue
        pair_idx = (enc[:-1] << 2) | enc[1:]
        dg_val = float(_NN_DG[pair_idx].sum())
        dG[i] = dg_val
        tm[i] = _tm_from_dg(dg_val, enc.size, params)
    return dG, tm


def l0_thermo_scores_gpu(seqs: Iterable[str], params: ThermoParams | None = None) -> Tuple[np.ndarray, np.ndarray]:
    params = params or ThermoParams()
    seq_list = list(seqs)
    if native_engine is None or not hasattr(native_engine, "l0_thermo_batch_gpu"):
        raise RuntimeError("CUDA L0 kernel unavailable: native engine not built with l0_thermo_batch_gpu")
    if hasattr(native_engine, "cuda_available") and not native_engine.cuda_available():
        raise RuntimeError("CUDA backend unavailable on this machine")
    flat, offsets, lengths = _encode_batch(seq_list)
    dG, tm = native_engine.l0_thermo_batch_gpu(flat, offsets, lengths, params.temperature_c, params.mg_mM, params.na_mM)
    return np.asarray(dG, dtype=np.float32), np.asarray(tm, dtype=np.float32)


__all__ = ["ThermoParams", "l0_thermo_scores_cpu", "l0_thermo_scores_gpu"]
