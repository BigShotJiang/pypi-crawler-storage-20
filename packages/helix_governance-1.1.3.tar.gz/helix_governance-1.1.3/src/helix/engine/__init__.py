"""Engine subpackage: shared utilities like encoding and benchmark helpers."""

__all__ = []
