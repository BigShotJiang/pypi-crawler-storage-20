from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any, Mapping, MutableMapping

try:  # jsonschema is a dev extra; provide a friendly error if missing.
    import jsonschema  # type: ignore
except ModuleNotFoundError:  # pragma: no cover - exercised only when dependency is absent.
    jsonschema = None


SCHEMA_RESOURCE = "run_descriptor.schema.json"
SCHEMA_VERSION = "run_descriptor_v0.1"


def load_schema() -> Mapping[str, Any]:
    """Load the packaged JSON schema for RunDescriptor."""

    with resources.files("helix.schema").joinpath(SCHEMA_RESOURCE).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def validate_descriptor(payload: Mapping[str, Any]) -> None:
    """Validate a RunDescriptor payload against the packaged schema.

    Raises:
        RuntimeError: if `jsonschema` is not installed.
        jsonschema.ValidationError: if the payload fails validation.
    """

    if jsonschema is None:
        raise RuntimeError("jsonschema is required to validate RunDescriptor payloads; install the dev extras")
    schema = load_schema()
    jsonschema.validate(instance=payload, schema=schema)


@dataclass(slots=True)
class RunDescriptor:
    """Typed wrapper around the RunDescriptor payload.

    The wrapper keeps the payload as a mapping while guaranteeing schema validity
    when constructed via :py:meth:`from_dict`.
    """

    payload: MutableMapping[str, Any]

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any], *, validate: bool = True) -> "RunDescriptor":
        if validate:
            validate_descriptor(payload)
        return cls(payload=dict(payload))

    def to_dict(self) -> Mapping[str, Any]:
        return dict(self.payload)

    def to_json(self, *, indent: int | None = 2) -> str:
        return json.dumps(self.payload, indent=indent, sort_keys=True)

    def ensure_schema_version(self) -> None:
        self.payload.setdefault("schema_version", SCHEMA_VERSION)
        if self.payload.get("schema_version") != SCHEMA_VERSION:
            raise ValueError(f"Unexpected schema_version {self.payload.get('schema_version')}, expected {SCHEMA_VERSION}")
