from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping

import requests

from helix import clock
from helix.determinism import allow_nondeterminism

from .config import BaseSpaceConfig


@dataclass
class BaseSpaceAuth:
    client_id: str
    client_secret: str
    access_token: str | None = None
    refresh_token: str | None = None


@dataclass
class TokenState:
    access_token: str
    expires_at: float


class BaseSpaceTokenManager:
    """Refresh-aware token helper for BaseSpace."""

    def __init__(self, cfg: BaseSpaceConfig, session: requests.Session | None = None):
        self._cfg = cfg
        self._session = session or requests.Session()
        self._state: TokenState | None = None

    def _fetch_token(self) -> TokenState:
        resp = self._session.post(
            self._cfg.token_endpoint,
            data={
                "grant_type": "refresh_token",
                "client_id": self._cfg.client_id,
                "client_secret": self._cfg.client_secret,
                "refresh_token": self._cfg.refresh_token,
            },
            timeout=30,
        )
        resp.raise_for_status()
        payload = resp.json()
        access = payload["access_token"]
        expires_in = float(payload.get("expires_in", 3600) or 3600)
        with allow_nondeterminism(reason="edge:basespace_token"):
            expires_at = clock.unix_time_s() + expires_in
        return TokenState(access_token=access, expires_at=expires_at)

    def get_access_token(self) -> str:
        if self._cfg.access_token and not self._cfg.refresh_token:
            return self._cfg.access_token
        with allow_nondeterminism(reason="edge:basespace_token"):
            now = clock.unix_time_s()
        if self._state is None or now > self._state.expires_at - self._cfg.refresh_margin:
            self._state = self._fetch_token()
        return self._state.access_token


class BaseSpaceClient:
    """Thin REST wrapper for BaseSpace Sequence Hub."""

    def __init__(
        self,
        api_base: str,
        auth: BaseSpaceAuth | None = None,
        token_manager: BaseSpaceTokenManager | None = None,
        session: requests.Session | None = None,
    ) -> None:
        self._api_base = api_base.rstrip("/")
        self._auth = auth
        self._tokens = token_manager
        self._session = session or requests.Session()

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        token: str | None = None
        if self._tokens:
            token = self._tokens.get_access_token()
        elif self._auth and self._auth.access_token:
            token = self._auth.access_token
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _get(self, path: str, params: Mapping[str, object] | None = None) -> dict:
        url = f"{self._api_base}{path}"
        resp = self._session.get(url, params=params, headers=self._headers(), timeout=30)
        resp.raise_for_status()
        return resp.json()

    def list_completed_runs(self, project_ids: Iterable[str]) -> list[dict]:
        items: list[dict] = []
        for proj in project_ids:
            data = self._get(f"/v2/projects/{proj}/runs", params={"Status": "Complete", "Limit": 200})
            items.extend(data.get("Items", data.get("Response", [])))
        return items

    def get_run(self, run_id: str) -> dict:
        data = self._get(f"/v2/runs/{run_id}")
        return data.get("Response", data)

    def get_fastq_files(self, run_id: str) -> list[dict]:
        data = self._get(f"/v2/runs/{run_id}/files", params={"Extensions": "fastq"})
        return data.get("Items", data.get("Response", []))

    def download_fastq(self, file_meta: Mapping[str, object], dest: Path) -> Path:
        dest.mkdir(parents=True, exist_ok=True)
        name = str(file_meta.get("Name") or Path(str(file_meta.get("Path", "fastq"))).name)
        href = file_meta.get("HrefContent") or file_meta.get("Href") or file_meta.get("Path")
        if not href:
            raise ValueError("No download URL in BaseSpace file metadata")
        url = href if str(href).startswith("http") else f"{self._api_base}{href}"
        out_path = dest / name
        with self._session.get(url, headers=self._headers(), stream=True, timeout=60) as resp:
            resp.raise_for_status()
            with out_path.open("wb") as handle:
                for chunk in resp.iter_content(chunk_size=8 * 1024 * 1024):
                    if chunk:
                        handle.write(chunk)
        return out_path
