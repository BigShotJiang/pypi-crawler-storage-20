from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Sequence

from helix import clock
from helix import fs
from helix.determinism import allow_nondeterminism

from .bundle import BundleFile, build_run_bundle
from .config import EdgeConfig
from .basespace_client import BaseSpaceClient, BaseSpaceAuth, BaseSpaceTokenManager
from .run_descriptor import RunDescriptor
from .translators.base import RunTranslator
from .translators.basespace import BaseSpaceTranslator
from .translators.illumina import IlluminaRunTranslator
from .translators.thermo_connect import ThermoConnectTranslator
from .uploader import upload_bundle


@dataclass
class RunFolderWatcher:
    """Minimal watcher that looks for complete Illumina-style run folders."""

    root: Path
    translator: RunTranslator
    complete_markers: Sequence[str] = ("RTAComplete.txt", "CopyComplete.txt")

    def discover_complete_runs(self) -> List[Path]:
        if not self.root.exists():
            return []
        runs: List[Path] = []
        for candidate in fs.iterdir_sorted(self.root):
            if not candidate.is_dir():
                continue
            if not self.translator.matches(candidate):
                continue
            if any((candidate / marker).exists() for marker in self.complete_markers):
                runs.append(candidate)
        return runs


@dataclass
class EdgeAgent:
    """Coordinates watch → translate → bundle → upload."""

    watcher: RunFolderWatcher
    bundle_output: Path
    cfg: EdgeConfig

    def process_once(self) -> list[tuple[Path, RunDescriptor, Path]]:
        results: list[tuple[Path, RunDescriptor, Path]] = []
        for run_path in self.watcher.discover_complete_runs():
            descriptor = self.watcher.translator.translate(run_path)
            sample_sheet_path = run_path / "SampleSheet.csv"
            sample_sheet = sample_sheet_path if sample_sheet_path.exists() else None
            bundle_path = build_run_bundle(
                descriptor,
                self.bundle_output,
                sample_sheet=sample_sheet,
                attachments=[
                    BundleFile(source=run_path / marker, target=Path(marker))
                    for marker in self.watcher.complete_markers
                    if (run_path / marker).exists()
                ],
            )
            upload_bundle(bundle_path, self.cfg)
            results.append((run_path, descriptor, bundle_path))
        return results


def _load_state(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return set(json.loads(path.read_text()))


def _save_state(path: Path, run_ids: set[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(sorted(run_ids)), encoding="utf-8")


def _bundle_fastqs(descriptor: RunDescriptor, fastqs: Iterable[Path], output_dir: Path) -> Path:
    attachments = [BundleFile(source=path, target=Path(path.name)) for path in fastqs]
    return build_run_bundle(descriptor, output_dir, attachments=attachments)


def cleanup_scratch(scratch_root: Path, retention_hours: int, enabled: bool = True) -> None:
    if not enabled or retention_hours <= 0:
        return
    with allow_nondeterminism(reason="edge:cleanup_scratch"):
        cutoff = clock.unix_time_s() - retention_hours * 3600
    if not scratch_root.exists():
        return
    for entry in fs.iterdir_sorted(scratch_root):
        try:
            mtime = entry.stat().st_mtime
        except FileNotFoundError:
            continue
        if mtime < cutoff:
            if entry.is_dir():
                for child in fs.rglob_sorted(entry, "*"):
                    try:
                        child.unlink()
                    except Exception:
                        pass
                try:
                    entry.rmdir()
                except Exception:
                    pass
            else:
                try:
                    entry.unlink()
                except Exception:
                    pass


def run_watchers(
    cfg: EdgeConfig,
    *,
    bundle_output: Path | None = None,
    scratch_root: Path | None = None,
    basespace_client: BaseSpaceClient | None = None,
    run_once: bool = True,
) -> list[Path]:
    """Process all configured sources once (or in a simple loop if run_once=False)."""

    bundle_output = bundle_output or cfg.runtime.bundles_root
    scratch_root = scratch_root or cfg.runtime.scratch_root
    bundle_output.mkdir(parents=True, exist_ok=True)
    scratch_root.mkdir(parents=True, exist_ok=True)
    processed_bundles: list[Path] = []

    def process_illumina() -> None:
        translator = IlluminaRunTranslator()
        for root_cfg in cfg.illumina_roots:
            watcher = RunFolderWatcher(root=root_cfg.path, translator=translator)
            agent = EdgeAgent(watcher=watcher, bundle_output=bundle_output, cfg=cfg)
            for _, _, bundle in agent.process_once():
                processed_bundles.append(bundle)

    def process_basespace() -> None:
        if not cfg.basespace or not cfg.basespace.enabled:
            return
        client = basespace_client
        if client is None:
            auth = BaseSpaceAuth(
                client_id=cfg.basespace.client_id,
                client_secret=cfg.basespace.client_secret,
                access_token=cfg.basespace.access_token,
                refresh_token=cfg.basespace.refresh_token,
            )
            token_mgr = BaseSpaceTokenManager(cfg.basespace) if cfg.basespace.refresh_token else None
            client = BaseSpaceClient(cfg.basespace.api_base, auth=auth, token_manager=token_mgr)
        translator = BaseSpaceTranslator(client, projects=cfg.basespace.projects)
        state_path = scratch_root / "basespace_state.json"
        seen = _load_state(state_path)
        for run_id in translator.list_completed_run_ids():
            if run_id in seen:
                continue
            fastqs = translator.materialize_fastqs(run_id, scratch_root / "basespace" / run_id)
            descriptor = translator.build_run_descriptor(run_id)
            bundle_path = _bundle_fastqs(descriptor, fastqs, bundle_output)
            upload_bundle(bundle_path, cfg)
            processed_bundles.append(bundle_path)
            seen.add(run_id)
        _save_state(state_path, seen)

    def process_thermo() -> None:
        thermo_cfg = cfg.thermo_connect
        if not thermo_cfg or not thermo_cfg.enabled or thermo_cfg.root is None:
            return
        translator = ThermoConnectTranslator()
        state_path = scratch_root / "thermo_state.json"
        seen = _load_state(state_path)
        for run_root in translator.discover_runs(thermo_cfg.root):
            run_id = run_root.name
            if run_id in seen:
                continue
            descriptor = translator.build_run_descriptor(run_root)
            fastqs = translator.find_fastqs(run_root)
            bundle_path = _bundle_fastqs(descriptor, fastqs, bundle_output)
            upload_bundle(bundle_path, cfg)
            processed_bundles.append(bundle_path)
            seen.add(run_id)
        _save_state(state_path, seen)

    # Ion Torrent payloads are expected to hit a separate HTTP receiver; no watcher here.

    while True:
        process_illumina()
        process_basespace()
        process_thermo()
        cleanup_scratch(scratch_root, cfg.runtime.scratch_retention_hours, enabled=cfg.runtime.scratch_cleanup_enabled)
        if run_once:
            break
        time.sleep(cfg.runtime.poll_interval_seconds)
    return processed_bundles
