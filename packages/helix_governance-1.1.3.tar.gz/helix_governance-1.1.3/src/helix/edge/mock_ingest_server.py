from __future__ import annotations

import argparse
import hashlib
import json
import tarfile
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .config import EdgeConfig, IngestConfig, load_config
from .run_registry import RunRegistry


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _bundle_digest(files: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    for entry in sorted(files, key=lambda e: e["path"]):
        digest.update(entry["path"].encode("utf-8"))
        digest.update(entry["sha256"].encode("utf-8"))
    return digest.hexdigest()


class RunStatusStore:
    def __init__(self, bundles_root: Path, registry: RunRegistry | None):
        self.bundles_root = bundles_root
        self.bundles_root.mkdir(parents=True, exist_ok=True)
        self.registry = registry
        self._lock = threading.Lock()
        self._status: dict[str, dict] = {}

    def _verify_bundle(self, bundle_path: Path) -> dict:
        result: dict[str, Any] = {"verified": False}
        try:
            with tarfile.open(bundle_path, "r:gz") as tar:
                manifest_member = tar.getmember("manifest.json")
                manifest_file = tar.extractfile(manifest_member) if manifest_member else None
                if manifest_file is None:
                    return {**result, "error": "missing_manifest"}
                manifest = json.load(manifest_file)
                files = manifest.get("files", [])
                for entry in files:
                    path = entry["path"]
                    try:
                        member = tar.getmember(path)
                    except KeyError:
                        return {**result, "error": "missing_file", "file": path}
                    file_obj = tar.extractfile(member)
                    if file_obj is None:
                        return {**result, "error": "missing_file", "file": path}
                    content = file_obj.read()
                    actual_size = len(content)
                    actual_sha = _sha256_bytes(content)
                    if actual_size != entry["size"] or actual_sha != entry["sha256"]:
                        return {**result, "error": "file_checksum_mismatch", "file": path}
                bundle_digest = _bundle_digest(files)
                if manifest.get("bundle_sha256") != bundle_digest:
                    return {**result, "error": "bundle_checksum_mismatch"}
        except Exception as exc:  # pragma: no cover
            return {**result, "error": str(exc)}
        result["verified"] = True
        return result

    def _extract_descriptor(self, bundle_path: Path) -> dict | None:
        try:
            with tarfile.open(bundle_path, "r:gz") as tar:
                member = tar.getmember("descriptor.json")
                file_obj = tar.extractfile(member) if member else None
                if file_obj is None:
                    return None
                return json.load(file_obj)
        except Exception:
            return None

    def register_bundle(self, content: bytes) -> str:
        run_status_id = hashlib.sha256(content).hexdigest()[:32]
        bundle_path = self.bundles_root / f"bundle-{run_status_id}.tar.gz"
        bundle_path.write_bytes(content)
        verification = self._verify_bundle(bundle_path)
        descriptor = self._extract_descriptor(bundle_path)
        if verification.get("verified") and descriptor and self.registry:
            self.registry.save_run(descriptor, verified=True)
        status = {
            "run_status_id": run_status_id,
            "state": "succeeded" if verification.get("verified") else "failed",
            "message": "bundle stored",
            "bundle_path": str(bundle_path),
            "verification": verification,
        }
        with self._lock:
            self._status[run_status_id] = status
        return run_status_id

    def get_status(self, run_id: str) -> dict:
        with self._lock:
            status = self._status.get(run_id)
        if status is None:
            raise KeyError(run_id)
        return status


def handler_factory(store: RunStatusStore, registry: RunRegistry, ingest_cfg: IngestConfig | None = None):
    class Handler(BaseHTTPRequestHandler):
        def _check_status_auth(self) -> bool:
            if ingest_cfg is None or not ingest_cfg.status_update_token:
                return True
            header = self.headers.get("Authorization", "")
            expected = f"Bearer {ingest_cfg.status_update_token}"
            return header == expected

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path == "/run-bundles":
                length = int(self.headers.get("Content-Length", "0"))
                content = self.rfile.read(length)
                run_id = store.register_bundle(content)
                payload = {"run_status_id": run_id}
                body = json.dumps(payload).encode("utf-8")
                self.send_response(HTTPStatus.CREATED)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            if parsed.path.startswith("/runs/") and parsed.path.endswith("/status"):
                run_id = parsed.path.split("/")[2]
                if not self._check_status_auth():
                    self.send_error(HTTPStatus.UNAUTHORIZED, "unauthorized")
                    return
                length = int(self.headers.get("Content-Length", "0"))
                payload = json.loads(self.rfile.read(length) or b"{}")
                state = payload.get("state")
                message = payload.get("message")
                ogn_job_id = payload.get("ogn_job_id")
                if not state:
                    self.send_error(HTTPStatus.BAD_REQUEST, "missing state")
                    return
                detail = registry.update_status(run_id, state, message, ogn_job_id)
                if detail is None:
                    self.send_error(HTTPStatus.NOT_FOUND, "run not found")
                    return
                body = json.dumps({"status": "ok", "run_id": run_id, "state": detail.status}).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return

            self.send_error(HTTPStatus.NOT_FOUND, "Unknown endpoint")

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path.startswith("/run-status/"):
                run_id = parsed.path.split("/", maxsplit=2)[-1]
                try:
                    status = store.get_status(run_id)
                except KeyError:
                    self.send_error(HTTPStatus.NOT_FOUND, "run not found")
                    return
                body = json.dumps(status).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if parsed.path == "/runs":
                runs = [s.__dict__ for s in registry.list_runs()]
                body = json.dumps(runs).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if parsed.path.startswith("/runs/"):
                run_id = parsed.path.split("/", maxsplit=2)[-1]
                detail = registry.get_run(run_id)
                if detail is None:
                    self.send_error(HTTPStatus.NOT_FOUND, "run not found")
                    return
                payload = detail.__dict__.copy()
                payload["status_history"] = [entry.__dict__ for entry in detail.status_history]
                body = json.dumps(payload).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self.send_error(HTTPStatus.NOT_FOUND, "Unknown endpoint")

        def log_message(self, fmt: str, *args) -> None:  # pragma: no cover
            return

    return Handler


def _build_config_from_args(args: argparse.Namespace) -> EdgeConfig:
    if getattr(args, "config", None):
        return load_config(Path(args.config))
    ingest = IngestConfig(registry_root=args.registry)
    return EdgeConfig(illumina_roots=[], ingest_url=args.ingest_url, ingest=ingest)


def run_server(host: str, port: int, cfg: EdgeConfig, bundles_root: Path) -> None:
    registry = RunRegistry(cfg.ingest.registry_root)
    store = RunStatusStore(bundles_root=bundles_root, registry=registry)
    handler = handler_factory(store, registry, ingest_cfg=cfg.ingest)
    with ThreadingHTTPServer((host, port), handler) as httpd:
        print(f"Mock ingest server listening on http://{host}:{port}")
        httpd.serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser(description="Mock OGN run ingest server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8081)
    parser.add_argument("--store", type=Path, default=Path("ogn_store"), help="bundle storage root")
    parser.add_argument("--registry", type=Path, default=None, help="registry root (default store/registry)")
    parser.add_argument("--config", type=Path, default=None, help="edge config yaml to derive ingest paths")
    parser.add_argument("--ingest-url", type=str, default="http://localhost:0/run-bundles")
    args = parser.parse_args()

    if args.registry is None:
        args.registry = args.store / "registry"
    cfg = _build_config_from_args(args)
    cfg.ingest.registry_root = args.registry
    run_server(args.host, args.port, cfg, args.store)


if __name__ == "__main__":
    main()
