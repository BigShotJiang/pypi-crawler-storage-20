from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from helix import clock
from helix import fs
from helix.determinism import allow_nondeterminism


@dataclass
class RunStatus:
    state: str
    updated_at: str
    message: str | None = None
    ogn_job_id: str | None = None


@dataclass
class RunSummary:
    run_id: str
    vendor: str
    status: str
    sample_count: int
    created_at: str  # ISO8601
    instrument: str | None = None
    last_message: str | None = None
    last_updated_at: str | None = None


@dataclass
class RunDetail(RunSummary):
    descriptor: dict[str, Any] = field(default_factory=dict)
    verified: bool = False
    status_history: list[RunStatus] = field(default_factory=list)


class RunRegistry:
    def __init__(self, root: Path):
        self._root = root
        self._root.mkdir(parents=True, exist_ok=True)

    def _path_for(self, run_id: str) -> Path:
        return self._root / f"{run_id}.json"

    def _serialize_status(self, status: RunStatus) -> dict[str, Any]:
        return {
            "state": status.state,
            "updated_at": status.updated_at,
            "message": status.message,
            "ogn_job_id": status.ogn_job_id,
        }

    def _deserialize_status(self, raw: dict[str, Any]) -> RunStatus:
        return RunStatus(
            state=raw.get("state", "unknown"),
            updated_at=raw.get("updated_at", ""),
            message=raw.get("message"),
            ogn_job_id=raw.get("ogn_job_id"),
        )

    def _deserialize_detail(self, data: dict[str, Any]) -> RunDetail:
        history_raw = data.get("status_history", [])
        history = [self._deserialize_status(entry) for entry in history_raw]
        last_message = history[-1].message if history else None
        last_updated = history[-1].updated_at if history else data.get("created_at", "")
        return RunDetail(
            run_id=data["run_id"],
            vendor=data.get("vendor", "unknown"),
            instrument=data.get("instrument"),
            status=data.get("status", "unknown"),
            sample_count=data.get("sample_count", 0),
            created_at=data.get("created_at", ""),
            last_message=last_message,
            last_updated_at=last_updated,
            descriptor=data.get("descriptor", {}),
            verified=bool(data.get("verified", False)),
            status_history=history,
        )

    def save_run(self, descriptor: dict, verified: bool) -> RunDetail:
        instrument_block = descriptor.get("instrument", {}) or descriptor.get("instrument_info", {}) or {}
        run_id = descriptor.get("run_id") or instrument_block.get("vendor_run_id") or instrument_block.get("run_id")
        vendor = instrument_block.get("vendor") or descriptor.get("vendor", "unknown")
        instrument = instrument_block.get("model") or instrument_block.get("instrument") or instrument_block.get("serial")
        samples = descriptor.get("samples") or []
        sample_count = len(samples)
        with allow_nondeterminism(reason="edge:run_registry"):
            now = clock.utc_now_iso_offset()
        status = RunStatus(state="received", updated_at=now)

        detail = RunDetail(
            run_id=run_id,
            vendor=vendor or "unknown",
            instrument=instrument,
            status=status.state,
            sample_count=sample_count,
            created_at=now,
            descriptor=descriptor,
            verified=verified,
            status_history=[status],
            last_message=status.message,
            last_updated_at=status.updated_at,
        )

        payload = detail.__dict__.copy()
        payload["status_history"] = [self._serialize_status(status)]
        self._path_for(run_id).write_text(json.dumps(payload, indent=2))
        return detail

    def list_runs(self) -> list[RunSummary]:
        out: list[RunSummary] = []
        for path in fs.glob_sorted(self._root, "*.json"):
            data = json.loads(path.read_text())
            history = data.get("status_history", [])
            last_message = history[-1].get("message") if history else None
            last_updated = history[-1].get("updated_at") if history else data.get("created_at")
            out.append(
                RunSummary(
                    run_id=data["run_id"],
                    vendor=data.get("vendor", "unknown"),
                    instrument=data.get("instrument"),
                    status=data.get("status", "unknown"),
                    sample_count=data.get("sample_count", 0),
                    created_at=data.get("created_at", ""),
                    last_message=last_message,
                    last_updated_at=last_updated,
                )
            )
        return sorted(out, key=lambda r: r.created_at, reverse=True)

    def get_run(self, run_id: str) -> RunDetail | None:
        path = self._path_for(run_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return self._deserialize_detail(data)

    def update_status(
        self, run_id: str, new_state: str, message: str | None = None, ogn_job_id: str | None = None
    ) -> RunDetail | None:
        path = self._path_for(run_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        history = data.get("status_history", [])
        with allow_nondeterminism(reason="edge:run_registry"):
            now = clock.utc_now_iso_offset()
        status_entry = {
            "state": new_state,
            "updated_at": now,
            "message": message,
            "ogn_job_id": ogn_job_id or data.get("ogn_job_id"),
        }
        history.append(status_entry)
        data["status"] = new_state
        data["status_history"] = history
        data["last_message"] = message or data.get("last_message")
        data["last_updated_at"] = now
        path.write_text(json.dumps(data, indent=2))
        return self._deserialize_detail(data)
