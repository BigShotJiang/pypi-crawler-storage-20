from __future__ import annotations

import json
import logging
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .bundle import BundleFile, build_run_bundle
from .config import EdgeConfig
from .translators.ion_torrent import run_descriptor_from_torrent_payload
from .uploader import upload_bundle as default_upload_bundle

# Backward-compatible alias for tests monkeypatching old name
upload_bundle = default_upload_bundle


def handler_factory(
    cfg: EdgeConfig,
    bundles_root: Path,
    scratch_root: Path,
    *,
    uploader=default_upload_bundle,
    logger: logging.Logger | None = None,
) -> type[BaseHTTPRequestHandler]:
    expected_token = (cfg.ion_torrent.ingest_token if cfg.ion_torrent else None) or cfg.ingest_token
    logger = logger or logging.getLogger(__name__)

    class Handler(BaseHTTPRequestHandler):
        def _check_auth(self) -> bool:
            if not expected_token:
                return True
            header = self.headers.get("Authorization", "")
            prefix = "Bearer "
            if header.startswith(prefix):
                token = header[len(prefix) :]
            else:
                token = header
            return token == expected_token

        def do_POST(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path != "/ion_torrent_runs":
                self.send_error(HTTPStatus.NOT_FOUND, "Unknown endpoint")
                return
            if not self._check_auth():
                self.send_error(HTTPStatus.FORBIDDEN, "invalid token")
                return
            length = int(self.headers.get("Content-Length", "0"))
            payload_bytes = self.rfile.read(length)
            try:
                payload = json.loads(payload_bytes)
            except json.JSONDecodeError:
                self.send_error(HTTPStatus.BAD_REQUEST, "invalid json")
                return

            try:
                descriptor = run_descriptor_from_torrent_payload(payload)
            except Exception as exc:  # pragma: no cover - unexpected payload fields
                self.send_error(HTTPStatus.BAD_REQUEST, f"payload error: {exc}")
                return

            fastq_paths = []
            for item in payload.get("fastq_sets", []):
                pair = item.get("read_pair", {})
                for key in ("r1", "r2"):
                    path = pair.get(key)
                    if path:
                        fastq_paths.append(Path(path))

            attachments = [BundleFile(source=p, target=Path(p.name)) for p in fastq_paths if p.exists()]
            bundles_root.mkdir(parents=True, exist_ok=True)
            bundle_path = build_run_bundle(descriptor, bundles_root, attachments=attachments)
            uploader(bundle_path, cfg)

            body = json.dumps({"run_id": descriptor.payload["instrument"]["vendor_run_id"], "bundle_path": str(bundle_path)}).encode(
                "utf-8"
            )
            self.send_response(HTTPStatus.CREATED)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt: str, *args) -> None:  # pragma: no cover - silence server logs
            logger.debug(fmt, *args)

    return Handler


def run_ion_receiver(host: str, port: int, cfg: EdgeConfig) -> None:
    server = create_app(cfg, host=host, port=port)
    print(f"Ion receiver listening on http://{server.server_address[0]}:{server.server_address[1]}")
    server.serve_forever()


def create_app(
    cfg: EdgeConfig,
    *,
    host: str | None = None,
    port: int | None = None,
    uploader=default_upload_bundle,
    logger: logging.Logger | None = None,
    allow_address_reuse: bool = True,
) -> ThreadingHTTPServer:
    host = host or (cfg.ion_torrent.listen_host if cfg.ion_torrent else "0.0.0.0")
    port = port or (cfg.ion_torrent.listen_port if cfg.ion_torrent else 8082)
    handler = handler_factory(cfg, cfg.runtime.bundles_root, cfg.runtime.scratch_root, uploader=uploader, logger=logger)
    server = ThreadingHTTPServer((host, port), handler)
    server.allow_reuse_address = allow_address_reuse
    return server
