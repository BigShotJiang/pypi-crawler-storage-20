from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

from helix import fs
from helix import clock
from helix.determinism import allow_nondeterminism

from ..run_descriptor import RunDescriptor, SCHEMA_VERSION


class ThermoConnectTranslator:
    def discover_runs(self, root: Path) -> Iterable[Path]:
        if not root.exists():
            return []
        for run_dir in fs.iterdir_sorted(root):
            if not run_dir.is_dir():
                continue
            if (run_dir / "run_completed.json").exists():
                yield run_dir

    def build_run_descriptor(self, run_root: Path) -> RunDescriptor:
        meta_path = run_root / "run_completed.json"
        meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
        sample_meta_path = run_root / "samples.json"
        samples_meta = json.loads(sample_meta_path.read_text()) if sample_meta_path.exists() else []

        instrument = meta.get("instrument", {})
        vendor_run_id = meta.get("run_id") or run_root.name

        fastqs = self.find_fastqs(run_root)
        fastq_sets = _group_fastqs(fastqs)

        payload: Dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "instrument": {
                "vendor": "thermo_connect",
                "model": instrument.get("model", "unknown"),
                "serial": instrument.get("serial"),
                "vendor_run_id": vendor_run_id,
                "data_uri": str(run_root),
                "run_start_at": meta.get("run_start_at"),
                "run_complete_at": meta.get("run_complete_at"),
            },
            "assay": {
                "name": meta.get("assay", "unspecified"),
                "read_structure": meta.get("read_structure"),
                "read_lengths": meta.get("read_lengths", []),
                "sample_sheet": {"source": str(sample_meta_path) if sample_meta_path.exists() else None, "records": samples_meta},
                "barcodes": [],
            },
            "samples": samples_meta if isinstance(samples_meta, list) else [],
            "data_products": {"fastq_sets": fastq_sets},
            "routing": {
                "pipeline": meta.get("pipeline", "generic_align"),
                "reference_build": meta.get("reference_build", "hg38"),
                "fm_index_id": meta.get("fm_index_id"),
                "helix_project_id": meta.get("helix_project_id"),
                "helix_experiment_id": meta.get("helix_experiment_id"),
                "priority": meta.get("priority", "normal"),
            },
            "provenance": {
                "translated_by": "thermo-connect-translator-v0",
                "collected_at": None,
            },
        }

        with allow_nondeterminism(reason="edge:translator"):
            payload["provenance"]["collected_at"] = clock.utc_now_iso_offset()  # type: ignore[index]
        return RunDescriptor.from_dict(payload)

    def find_fastqs(self, run_root: Path) -> list[Path]:
        return fs.glob_sorted(run_root, "**/*.fastq*")


def _group_fastqs(fastqs: Iterable[Path]) -> List[Dict[str, Any]]:
    by_sample: Dict[str, Dict[str, Path]] = {}
    for fq in fastqs:
        # naive parse: SampleX_R1 or SampleX_R2
        name = fq.name
        sample = name.split("_R")[0]
        read = "1" if "_R1" in name else "2" if "_R2" in name else "1"
        lane = "L001"
        key = (sample, lane)
        if key not in by_sample:
            by_sample[key] = {}
        by_sample[key][read] = fq

    fastq_sets: List[Dict[str, Any]] = []
    for (sample, lane), reads in by_sample.items():
        if "1" not in reads or "2" not in reads:
            continue
        fastq_sets.append({"sample_id": sample, "lane": lane, "read_pair": {"r1": str(reads['1']), "r2": str(reads['2'])}})
    return fastq_sets
