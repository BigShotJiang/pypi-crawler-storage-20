from __future__ import annotations

from typing import Any, Dict, Mapping

from helix import clock
from helix.determinism import allow_nondeterminism

from ..run_descriptor import RunDescriptor, SCHEMA_VERSION


def run_descriptor_from_torrent_payload(payload: Mapping[str, Any]) -> RunDescriptor:
    instrument = payload.get("instrument", {})
    samples = payload.get("samples", [])
    fastqs = payload.get("fastq_sets") or []

    instrument_block: Dict[str, Any] = {
        "vendor": "ion_torrent",
        "model": instrument.get("model", "ion_torrent"),
        "serial": instrument.get("serial"),
        "vendor_run_id": payload.get("run_id", instrument.get("run_id", "unknown")),
        "data_uri": payload.get("data_uri") or payload.get("run_path") or "ion:payload",
    }
    if payload.get("run_start_at"):
        instrument_block["run_start_at"] = payload.get("run_start_at")
    if payload.get("run_complete_at"):
        instrument_block["run_complete_at"] = payload.get("run_complete_at")

    assay_block: Dict[str, Any] = {
        "name": payload.get("assay", "unspecified"),
        "read_structure": payload.get("read_structure"),
        "read_lengths": payload.get("read_lengths", []),
        "sample_sheet": {"source": None, "records": samples},
        "barcodes": [],
    }
    if not assay_block["read_lengths"]:
        assay_block.pop("read_lengths", None)

    rd_payload: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "instrument": instrument_block,
        "assay": assay_block,
        "samples": samples,
        "data_products": {"fastq_sets": fastqs},
        "routing": {
            "pipeline": payload.get("pipeline", "generic_align"),
            "reference_build": payload.get("reference_build", "hg38"),
            "fm_index_id": payload.get("fm_index_id"),
            "helix_project_id": payload.get("helix_project_id"),
            "helix_experiment_id": payload.get("helix_experiment_id"),
            "priority": payload.get("priority", "normal"),
        },
        "provenance": {
            "translated_by": "ion-torrent-translator-v0",
            "collected_at": None,
            "notes": payload.get("notes"),
        },
    }

    with allow_nondeterminism(reason="edge:translator"):
        rd_payload["provenance"]["collected_at"] = clock.utc_now_iso_offset()  # type: ignore[index]
    return RunDescriptor.from_dict(rd_payload)
