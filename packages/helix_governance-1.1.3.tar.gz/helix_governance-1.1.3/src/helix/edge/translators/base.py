from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterable

from ..run_descriptor import RunDescriptor


class RunTranslator(ABC):
    """Abstract interface for translating vendor ecosystems into RunDescriptor."""

    vendor: str

    @abstractmethod
    def matches(self, path: Path) -> bool:
        """Return True if the path looks like a run produced by this vendor."""

    @abstractmethod
    def translate(self, path: Path) -> RunDescriptor:
        """Produce a RunDescriptor from the vendor-specific run contents."""

    def required_files(self) -> Iterable[str]:
        """Optional list of files we expect to find (for quick diagnostics)."""

        return []
