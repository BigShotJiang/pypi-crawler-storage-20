from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Tuple

from helix import clock
from helix.determinism import allow_nondeterminism

from ..run_descriptor import RunDescriptor, SCHEMA_VERSION
from ..basespace_client import BaseSpaceClient


class BaseSpaceTranslator:
    def __init__(self, client: BaseSpaceClient, projects: Iterable[str] | None = None) -> None:
        self._client = client
        self._projects = list(projects or [])

    def list_completed_run_ids(self, projects: Iterable[str] | None = None) -> list[str]:
        proj_list = list(projects) if projects is not None else self._projects
        runs = self._client.list_completed_runs(proj_list)
        return [r["Id"] for r in runs if str(r.get("Status", "")).lower() == "complete"]

    def build_run_descriptor(self, run_id: str) -> RunDescriptor:
        meta = self._client.get_run(run_id)
        fastqs = self._client.get_fastq_files(run_id)

        instrument_model = meta.get("InstrumentModel") or meta.get("InstrumentPlatform") or "unknown"
        vendor_run_id = meta.get("Id") or run_id
        read_structure, read_lengths = _read_structure_from_meta(meta)
        samples = _samples_from_fastqs(fastqs)
        fastq_sets = _fastq_sets_from_fastqs(fastqs)

        payload: Dict[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "instrument": {
                "vendor": "illumina",
                "model": instrument_model,
                "serial": meta.get("InstrumentSerial") or None,
                "vendor_run_id": vendor_run_id,
                "data_uri": meta.get("Href") or f"basespace:run:{vendor_run_id}",
                "run_start_at": _maybe_iso(meta.get("DateCreated")),
                "run_complete_at": _maybe_iso(meta.get("DateCompleted")),
            },
            "assay": {
                "name": meta.get("ExperimentName") or meta.get("Name") or "unspecified",
                "read_structure": read_structure,
                "read_lengths": read_lengths,
                "sample_sheet": {"source": meta.get("SampleSheetUri"), "records": []},
                "barcodes": [],
            },
            "samples": samples,
            "data_products": {"fastq_sets": fastq_sets},
            "routing": {
                "pipeline": "generic_align",
                "reference_build": "hg38",
                "fm_index_id": None,
                "helix_project_id": None,
                "helix_experiment_id": None,
                "priority": "normal",
            },
            "provenance": {
                "translated_by": "basespace-translator-v0",
                "collected_at": None,
            },
        }

        with allow_nondeterminism(reason="edge:translator"):
            payload["provenance"]["collected_at"] = clock.utc_now_iso_offset()  # type: ignore[index]
        return RunDescriptor.from_dict(payload)

    def materialize_fastqs(self, run_id: str, dest_root: Path) -> list[Path]:
        fastqs = self._client.get_fastq_files(run_id)
        dest_root.mkdir(parents=True, exist_ok=True)
        outputs: list[Path] = []
        for meta in fastqs:
            outputs.append(self._client.download_fastq(meta, dest_root))
        return outputs


def _maybe_iso(value: str | None) -> str | None:
    if not value:
        return None
    try:
        # Accept already ISO strings
        datetime.fromisoformat(value)
        return value
    except Exception:
        return value


def _read_structure_from_meta(meta: Mapping[str, Any]) -> tuple[str | None, list[int]]:
    read1 = meta.get("Read1") or meta.get("Read1Cycles")
    read2 = meta.get("Read2") or meta.get("Read2Cycles")
    index1 = meta.get("Index1") or meta.get("Index1Cycles")
    index2 = meta.get("Index2") or meta.get("Index2Cycles")
    parts: list[tuple[int, str]] = []
    lengths: list[int] = []
    for cycles, token in (
        (read1, "T"),
        (index1, "I"),
        (index2, "I"),
        (read2, "T"),
    ):
        if cycles is None:
            continue
        try:
            c_int = int(cycles)
        except Exception:
            continue
        parts.append((c_int, token))
        lengths.append(c_int)
    if not parts:
        return None, []
    return "".join(f"{c}{t}" for c, t in parts), lengths


def _fastq_sets_from_fastqs(fastqs: Iterable[Mapping[str, Any]]) -> list[Dict[str, Any]]:
    grouped: Dict[Tuple[str, str], Dict[str, str]] = defaultdict(dict)
    for meta in fastqs:
        sample = meta.get("SampleId") or meta.get("Sample") or meta.get("SampleName") or "unknown"
        lane = meta.get("Lane") or "L001"
        read = _read_from_name(meta)
        uri = meta.get("Path") or meta.get("DownloadUri") or meta.get("Href")
        if not uri:
            continue
        grouped[(str(sample), str(lane))][read] = str(uri)

    fastq_sets: list[Dict[str, Any]] = []
    for (sample, lane), reads in grouped.items():
        if "1" not in reads or "2" not in reads:
            continue
        fastq_sets.append(
            {
                "sample_id": sample,
                "lane": lane,
                "read_pair": {"r1": reads["1"], "r2": reads["2"]},
            }
        )
    return fastq_sets


def _read_from_name(meta: Mapping[str, Any]) -> str:
    name = str(meta.get("Name") or meta.get("Path") or meta.get("Href") or "")
    if "_R2" in name or meta.get("Read") == 2:
        return "2"
    return "1"


def _samples_from_fastqs(fastqs: Iterable[Mapping[str, Any]]) -> list[Dict[str, Any]]:
    samples = sorted({str(meta.get("SampleId") or meta.get("Sample") or meta.get("SampleName") or "unknown") for meta in fastqs})
    return [{"sample_id": s} for s in samples]
