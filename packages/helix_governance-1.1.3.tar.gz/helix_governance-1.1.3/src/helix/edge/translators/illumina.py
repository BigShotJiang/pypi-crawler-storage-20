from __future__ import annotations

import csv
import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Tuple

from helix import fs
from helix import clock
from helix.determinism import allow_nondeterminism

from ..run_descriptor import RunDescriptor, SCHEMA_VERSION
from .base import RunTranslator

_FASTQ_RE = re.compile(r"(?P<sample>.+)_S\d+_L(?P<lane>\d{3})_R(?P<read>[12])_\d{3}\.fastq(?:\.gz)?$")


class IlluminaRunTranslator(RunTranslator):
    """Translate Illumina run folders into the canonical RunDescriptor."""

    vendor = "illumina"

    def __init__(self, routing_defaults: Mapping[str, Any] | None = None, translator_id: str | None = None) -> None:
        self.routing_defaults = dict(routing_defaults or {})
        self.translator_id = translator_id or "illumina-translator-v0"

    def matches(self, path: Path) -> bool:
        return (path / "RunInfo.xml").exists()

    def required_files(self) -> Iterable[str]:
        return ["RunInfo.xml", "SampleSheet.csv"]

    def translate(self, path: Path) -> RunDescriptor:
        path = path.resolve()
        run_info = _parse_run_info(path / "RunInfo.xml")
        run_params = _parse_run_parameters(path / "RunParameters.xml")
        sample_sheet_path = path / "SampleSheet.csv"
        sample_records = _parse_sample_sheet(sample_sheet_path) if sample_sheet_path.exists() else []
        fastq_sets = _collect_fastqs(path)

        read_structure, read_lengths = _build_read_structure(run_info.get("reads", []))

        instrument = {
            "vendor": self.vendor,
            "model": run_params.get("instrument_model") or run_info.get("instrument") or "unknown",
            "serial": run_params.get("serial") or run_info.get("instrument"),
            "vendor_run_id": run_params.get("run_id") or run_info.get("run_id") or path.name,
            "data_uri": str(path),
            "flowcell_id": run_info.get("flowcell"),
            "software_version": run_params.get("software_version"),
        }

        assay = {
            "name": run_params.get("assay_name") or "unspecified",
            "read_structure": read_structure,
            "read_lengths": read_lengths,
            "sample_sheet": {
                "source": str(sample_sheet_path) if sample_sheet_path.exists() else None,
                "records": sample_records,
            },
            "barcodes": [
                {
                    "sample_id": rec["sample_id"],
                    "index_i7": rec.get("index_i7"),
                    "index_i5": rec.get("index_i5"),
                    "project": rec.get("project"),
                }
                for rec in sample_records
            ],
        }

        samples = [
            {
                "sample_id": rec["sample_id"],
                "project": rec.get("project"),
                "library_id": rec.get("library_id"),
                "subject": rec.get("subject"),
                "metadata": rec.get("metadata", {}),
            }
            for rec in sample_records
        ]

        data_products = {"fastq_sets": fastq_sets}

        routing = {
            "pipeline": self.routing_defaults.get("pipeline", "generic_align"),
            "reference_build": self.routing_defaults.get("reference_build", "hg38"),
            "fm_index_id": self.routing_defaults.get("fm_index_id"),
            "helix_project_id": self.routing_defaults.get("helix_project_id"),
            "helix_experiment_id": self.routing_defaults.get("helix_experiment_id"),
            "priority": self.routing_defaults.get("priority", "normal"),
        }

        with allow_nondeterminism(reason="edge:translator"):
            collected_at = clock.utc_now_iso_offset()
        provenance = {
            "translated_by": self.translator_id,
            "collected_at": collected_at,
        }

        payload: MutableMapping[str, Any] = {
            "schema_version": SCHEMA_VERSION,
            "instrument": instrument,
            "assay": assay,
            "samples": samples,
            "data_products": data_products,
            "routing": routing,
            "provenance": provenance,
        }

        return RunDescriptor.from_dict(payload)


def _parse_run_info(path: Path) -> Dict[str, Any]:
    info: Dict[str, Any] = {"reads": []}
    if not path.exists():
        return info
    root = ET.parse(path).getroot()
    run_elem = root.find("Run")
    run = run_elem if run_elem is not None else root
    info["run_id"] = run.attrib.get("Id") or run.attrib.get("ID") or None
    info["instrument"] = (run.findtext("Instrument") or root.findtext("Instrument"))
    info["flowcell"] = run.findtext("Flowcell") or root.findtext("Flowcell")

    reads_parent = run.find("Reads")
    if reads_parent is None:
        reads_parent = root.find("Reads")
    if reads_parent is not None:
        for read_elem in reads_parent.findall("Read"):
            info["reads"].append(
                {
                    "number": int(read_elem.attrib.get("Number", "0")),
                    "cycles": int(read_elem.attrib.get("NumCycles", "0")),
                    "is_index": read_elem.attrib.get("IsIndexedRead", "N").upper() == "Y",
                }
            )
    return info


def _parse_run_parameters(path: Path) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    if not path.exists():
        return params
    root = ET.parse(path).getroot()
    params["run_id"] = root.findtext("RunId") or root.findtext("RunID")
    params["instrument_model"] = root.findtext("InstrumentType") or root.findtext("InstrumentModel")
    params["assay_name"] = root.findtext("ApplicationName")
    params["software_version"] = root.findtext("ApplicationVersion") or root.findtext("RTAVersion")
    params["serial"] = root.findtext("InstrumentID") or root.findtext("InstrumentSerialNumber")
    return params


def _parse_sample_sheet(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []

    lines = path.read_text().splitlines()
    data_start = None
    for idx, line in enumerate(lines):
        if line.strip().lower() == "[data]":
            data_start = idx + 1
            break
    if data_start is None or data_start >= len(lines):
        return []

    # header is the first non-empty line after [Data]
    header_line_index = data_start
    while header_line_index < len(lines) and not lines[header_line_index].strip():
        header_line_index += 1
    if header_line_index >= len(lines):
        return []

    reader = csv.DictReader(lines[header_line_index:])
    records: List[Dict[str, Any]] = []
    for row in reader:
        if not row:
            continue
        sample_id = row.get("Sample_ID") or row.get("SampleID") or row.get("Sample Name") or row.get("SampleName")
        if not sample_id:
            continue
        records.append(
            {
                "sample_id": sample_id.strip(),
                "project": (row.get("Sample_Project") or row.get("Project")) or None,
                "description": row.get("Description") or None,
                "index_i7": row.get("index") or row.get("Index") or None,
                "index_i5": row.get("index2") or row.get("Index2") or None,
            }
        )
    return records


def _collect_fastqs(run_path: Path) -> List[Dict[str, Any]]:
    fastqs: Dict[Tuple[str, str], Dict[str, Path]] = defaultdict(dict)
    for fastq in fs.rglob_sorted(run_path, "*.fastq*"):
        match = _FASTQ_RE.match(fastq.name)
        if not match:
            continue
        key = (match.group("sample"), match.group("lane"))
        fastqs[key][match.group("read")] = fastq.resolve()

    fastq_sets: List[Dict[str, Any]] = []
    for (sample, lane), reads in sorted(fastqs.items()):
        if "1" not in reads or "2" not in reads:
            continue
        fastq_sets.append(
            {
                "sample_id": sample,
                "lane": f"L{lane}",
                "read_pair": {"r1": str(reads["1"]), "r2": str(reads["2"])},
            }
        )
    return fastq_sets


def _build_read_structure(reads: List[Mapping[str, Any]]) -> tuple[str | None, List[int]]:
    if not reads:
        return None, []
    ordered = sorted(reads, key=lambda r: r.get("number", 0))
    tokens = []
    lengths: List[int] = []
    for read in ordered:
        cycles = int(read.get("cycles", 0))
        token = "I" if read.get("is_index") else "T"
        tokens.append(f"{cycles}{token}")
        lengths.append(cycles)
    return "".join(tokens), lengths
