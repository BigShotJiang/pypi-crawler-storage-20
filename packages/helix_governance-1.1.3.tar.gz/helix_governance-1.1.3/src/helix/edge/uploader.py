from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable, Mapping

import requests

from .config import EdgeConfig


def _iter_chunks(handle, chunk_size: int) -> Iterable[bytes]:
    while True:
        chunk = handle.read(chunk_size)
        if not chunk:
            break
        yield chunk


def post_bundle(bundle_path: Path, endpoint_url: str, *, token: str | None = None, timeout: int = 30) -> Mapping[str, Any]:
    data = bundle_path.read_bytes()
    headers = {"Content-Type": "application/gzip", "Content-Length": str(len(data))}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    resp = requests.post(endpoint_url, data=data, headers=headers, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def upload_bundle(bundle_path: Path, cfg: EdgeConfig, *, timeout: int = 30) -> Mapping[str, Any]:
    headers = {"Content-Type": "application/gzip"}
    if cfg.ingest_token:
        headers["Authorization"] = f"Bearer {cfg.ingest_token}"

    if cfg.upload.mode == "stream":
        with bundle_path.open("rb") as handle:
            resp = requests.post(
                cfg.ingest_url,
                data=_iter_chunks(handle, cfg.upload.chunk_bytes),
                headers=headers,
                timeout=timeout,
            )
    else:
        data = bundle_path.read_bytes()
        headers["Content-Length"] = str(len(data))
        resp = requests.post(cfg.ingest_url, data=data, headers=headers, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def fetch_status(status_url: str, *, timeout: int = 10) -> Mapping[str, Any]:
    resp = requests.get(status_url, timeout=timeout)
    resp.raise_for_status()
    return resp.json()
