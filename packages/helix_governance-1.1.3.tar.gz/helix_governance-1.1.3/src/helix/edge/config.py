from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

import yaml


@dataclass
class IlluminaRoot:
    path: Path
    pattern: Optional[str] = None
    vendor: str = "illumina"


@dataclass
class BaseSpaceConfig:
    enabled: bool = False
    client_id: str = ""
    client_secret: str = ""
    api_base: str = "https://api.basespace.illumina.com"
    access_token: str = ""
    refresh_token: str | None = None
    token_endpoint: str = "https://basespace.illumina.com/oauth/token"
    refresh_margin: int = 60
    projects: List[str] = field(default_factory=list)


@dataclass
class ThermoConnectConfig:
    enabled: bool = False
    root: Optional[Path] = None


@dataclass
class IonTorrentConfig:
    enabled: bool = False
    ingest_token: str = ""
    listen_host: str = "0.0.0.0"
    listen_port: int = 8082


@dataclass
class EdgeRuntimeConfig:
    poll_interval_seconds: int = 60
    scratch_root: Path = Path("/var/lib/helix_edge/scratch")
    bundles_root: Path = Path("/var/lib/helix_edge/bundles")
    scratch_retention_hours: int = 24
    scratch_cleanup_enabled: bool = True


@dataclass
class UploadConfig:
    mode: str = "simple"  # "simple" or "stream"
    chunk_bytes: int = 8_388_608


@dataclass
class IngestConfig:
    registry_root: Path = Path("/var/lib/helix_edge/registry")
    status_update_token: str | None = None


@dataclass
class EdgeConfig:
    illumina_roots: List[IlluminaRoot]
    ingest_url: str
    basespace: Optional[BaseSpaceConfig] = None
    thermo_connect: Optional[ThermoConnectConfig] = None
    ion_torrent: Optional[IonTorrentConfig] = None
    ingest_token: Optional[str] = None
    runtime: EdgeRuntimeConfig = field(default_factory=EdgeRuntimeConfig)
    upload: UploadConfig = field(default_factory=UploadConfig)
    ingest: IngestConfig = field(default_factory=IngestConfig)


def _load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def _parse_illumina_roots(raw: list | None) -> List[IlluminaRoot]:
    roots: List[IlluminaRoot] = []
    for item in raw or []:
        roots.append(
            IlluminaRoot(
                path=Path(item["path"]),
                pattern=item.get("pattern"),
                vendor=item.get("vendor", "illumina"),
            )
        )
    return roots


def _parse_basespace(raw: dict | None) -> BaseSpaceConfig | None:
    if not raw:
        return None
    projects = raw.get("projects") or []
    return BaseSpaceConfig(
        enabled=bool(raw.get("enabled", False)),
        client_id=raw.get("client_id", ""),
        client_secret=raw.get("client_secret", ""),
        api_base=raw.get("api_base", BaseSpaceConfig.api_base),
        access_token=raw.get("access_token", ""),
        refresh_token=raw.get("refresh_token"),
        token_endpoint=raw.get("token_endpoint", BaseSpaceConfig.token_endpoint),
        refresh_margin=int(raw.get("refresh_margin", BaseSpaceConfig.refresh_margin)),
        projects=list(projects),
    )


def _parse_thermo(raw: dict | None) -> ThermoConnectConfig | None:
    if not raw:
        return None
    root = raw.get("root")
    return ThermoConnectConfig(enabled=bool(raw.get("enabled", False)), root=Path(root) if root else None)


def _parse_ion(raw: dict | None) -> IonTorrentConfig | None:
    if not raw:
        return None
    return IonTorrentConfig(enabled=bool(raw.get("enabled", False)), ingest_token=raw.get("ingest_token", ""))


def _parse_runtime(raw: dict | None) -> EdgeRuntimeConfig:
    if not raw:
        return EdgeRuntimeConfig()
    return EdgeRuntimeConfig(
        poll_interval_seconds=int(raw.get("poll_interval_seconds", EdgeRuntimeConfig.poll_interval_seconds)),
        scratch_root=Path(raw.get("scratch_root", EdgeRuntimeConfig.scratch_root)),
        bundles_root=Path(raw.get("bundles_root", EdgeRuntimeConfig.bundles_root)),
        scratch_retention_hours=int(raw.get("scratch_retention_hours", EdgeRuntimeConfig.scratch_retention_hours)),
        scratch_cleanup_enabled=bool(raw.get("scratch_cleanup_enabled", EdgeRuntimeConfig.scratch_cleanup_enabled)),
    )


def _parse_upload(raw: dict | None) -> UploadConfig:
    if not raw:
        return UploadConfig()
    return UploadConfig(
        mode=raw.get("mode", UploadConfig.mode),
        chunk_bytes=int(raw.get("chunk_bytes", UploadConfig.chunk_bytes)),
    )


def _parse_ingest(raw: dict | None) -> IngestConfig:
    if not raw:
        return IngestConfig()
    return IngestConfig(
        registry_root=Path(raw.get("registry_root", IngestConfig.registry_root)),
        status_update_token=raw.get("status_update_token"),
    )


def load_config(path: Path) -> EdgeConfig:
    raw = _load_yaml(path)
    illumina_roots = _parse_illumina_roots(raw.get("illumina_roots"))
    basespace = _parse_basespace(raw.get("basespace"))
    thermo = _parse_thermo(raw.get("thermo_connect"))
    ion = _parse_ion(raw.get("ion_torrent"))
    runtime = _parse_runtime(raw.get("runtime"))
    upload = _parse_upload(raw.get("upload"))
    ingest = _parse_ingest(raw.get("ingest"))
    ingest_url = raw.get("ingest_url")
    if not ingest_url:
        raise ValueError("ingest_url is required in edge config")
    ingest_token = raw.get("ingest_token")
    return EdgeConfig(
        illumina_roots=illumina_roots,
        basespace=basespace,
        thermo_connect=thermo,
        ion_torrent=ion,
        ingest_url=ingest_url,
        ingest_token=ingest_token,
        runtime=runtime,
        upload=upload,
        ingest=ingest,
    )


def load_config_from_env() -> EdgeConfig:
    path_env = os.environ.get("HELIX_EDGE_CONFIG")
    if not path_env:
        raise ValueError("HELIX_EDGE_CONFIG env var must point to a config YAML")
    cfg = load_config(Path(path_env))
    ingest_url_override = os.environ.get("HELIX_EDGE_INGEST_URL")
    if ingest_url_override:
        cfg.ingest_url = ingest_url_override
    ingest_token = os.environ.get("HELIX_EDGE_INGEST_TOKEN")
    if ingest_token:
        cfg.ingest_token = ingest_token
    return cfg
