from __future__ import annotations

import gzip
import hashlib
import io
import json
import tarfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping

from helix import clock
from helix.determinism import allow_nondeterminism

from .run_descriptor import RunDescriptor, validate_descriptor


@dataclass(frozen=True)
class BundleFile:
    """A file to be embedded in a run bundle.

    Attributes:
        source: Path to the local file to include.
        target: Relative path within the archive (e.g., ``data/SampleA_R1.fastq.gz``).
    """

    source: Path
    target: Path

    def __post_init__(self) -> None:  # pragma: no cover - tiny guard
        if self.target.is_absolute():
            raise ValueError("BundleFile.target must be relative")


@dataclass(frozen=True)
class ManifestFile:
    path: str
    size: int
    sha256: str


@dataclass(frozen=True)
class BundleManifest:
    version: int
    run_descriptor: str
    files: list[ManifestFile]
    bundle_sha256: str


def _now_ts() -> str:
    with allow_nondeterminism(reason="edge:bundle"):
        return clock.utc_now_stamp().replace("_", "T") + "Z"


def _sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def _sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalize_tarinfo(info: tarfile.TarInfo) -> tarfile.TarInfo:
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    info.mtime = 0
    info.mode = 0o755 if info.isdir() else 0o644
    return info


def _add_bytes(tar: tarfile.TarFile, rel_path: str, data: bytes) -> ManifestFile:
    info = tarfile.TarInfo(rel_path)
    info.size = len(data)
    _normalize_tarinfo(info)
    tar.addfile(info, io.BytesIO(data))
    return ManifestFile(path=rel_path, size=info.size, sha256=_sha256_bytes(data))


def _add_file(tar: tarfile.TarFile, source: Path, target: str) -> ManifestFile:
    tar.add(source, arcname=target, filter=_normalize_tarinfo)
    return ManifestFile(path=target, size=source.stat().st_size, sha256=_sha256_path(source))


def _bundle_digest(entries: list[ManifestFile]) -> str:
    digest = hashlib.sha256()
    for entry in sorted(entries, key=lambda e: e.path):
        digest.update(entry.path.encode("utf-8"))
        digest.update(entry.sha256.encode("utf-8"))
    return digest.hexdigest()


def build_run_bundle(
    descriptor: Mapping[str, object] | RunDescriptor,
    output_dir: Path,
    *,
    attachments: Iterable[BundleFile] = (),
    reports: Iterable[BundleFile] = (),
    sample_sheet: Path | None = None,
    bundle_name: str | None = None,
    timestamp: str | None = None,
    validate: bool = True,
) -> Path:
    """Create a canonical run bundle (tar.gz) with manifest and per-file hashes."""

    output_dir.mkdir(parents=True, exist_ok=True)

    if isinstance(descriptor, RunDescriptor):
        rd = descriptor
    else:
        rd = RunDescriptor.from_dict(descriptor, validate=validate)
    rd.ensure_schema_version()

    payload = rd.to_dict()
    if validate:
        validate_descriptor(payload)

    vendor_run_id = payload["instrument"]["vendor_run_id"]  # type: ignore[index]
    ts = timestamp or _now_ts()
    archive_name = bundle_name or f"run-{vendor_run_id}-{ts}.tar.gz"
    archive_path = output_dir / archive_name

    manifest_entries: list[ManifestFile] = []

    attachments_ordered = sorted(list(attachments), key=lambda item: item.target.as_posix())
    reports_ordered = sorted(list(reports), key=lambda item: item.target.as_posix())

    with archive_path.open("wb") as raw:
        with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode="w", format=tarfile.GNU_FORMAT) as tar:
                descriptor_bytes = rd.to_json().encode("utf-8")
                manifest_entries.append(_add_bytes(tar, "descriptor.json", descriptor_bytes))

                if sample_sheet:
                    sheet_bytes = sample_sheet.read_bytes()
                    manifest_entries.append(_add_bytes(tar, "sample_sheet.raw.csv", sheet_bytes))

                for bundle_file in attachments_ordered:
                    target = str(Path("data") / bundle_file.target)
                    manifest_entries.append(_add_file(tar, bundle_file.source, target))

                for report_file in reports_ordered:
                    target = str(Path("reports") / report_file.target)
                    manifest_entries.append(_add_file(tar, report_file.source, target))

                checksum_text = "\n".join(f"{entry.sha256}  {entry.path}" for entry in manifest_entries) + "\n"
                manifest_entries.append(_add_bytes(tar, "checksums.sha256", checksum_text.encode("utf-8")))

                manifest = BundleManifest(
                    version=1,
                    run_descriptor="descriptor.json",
                    files=manifest_entries,
                    bundle_sha256=_bundle_digest(manifest_entries),
                )
                manifest_bytes = json.dumps(
                    {
                        "version": manifest.version,
                        "run_descriptor": manifest.run_descriptor,
                        "bundle_sha256": manifest.bundle_sha256,
                        "files": [entry.__dict__ for entry in manifest.files],
                    },
                    indent=2,
                ).encode("utf-8")
                _add_bytes(tar, "manifest.json", manifest_bytes)

    return archive_path
