from __future__ import annotations

import contextvars
import hashlib
import random
from dataclasses import dataclass
from typing import Any


DEFAULT_ALGO = "python.random.Random(MT19937)"
DEFAULT_NUMPY_ALGO = "numpy.random.Generator(PCG64)"


@dataclass(frozen=True)
class RngStream:
    seed: int
    stream_id: str
    algo: str


_rng_streams_var: contextvars.ContextVar[list[RngStream] | None] = contextvars.ContextVar(
    "helix_rng_streams", default=None
)


def clear_rng_streams() -> None:
    _rng_streams_var.set([])


def rng_streams() -> list[RngStream]:
    streams = _rng_streams_var.get()
    if not streams:
        return []
    return sorted(list(streams), key=lambda s: (s.stream_id, int(s.seed), s.algo))


def _record_stream(stream: RngStream) -> None:
    streams = _rng_streams_var.get()
    if streams is None:
        streams = []
        _rng_streams_var.set(streams)
    streams.append(stream)


def derive_seed(seed: int, stream_id: str) -> int:
    """Derive a stable per-stream seed from a root seed and stream id."""

    if not isinstance(seed, int):
        raise TypeError(f"seed must be int (got {type(seed).__name__})")
    token = str(stream_id or "").strip()
    if not token:
        raise ValueError("stream_id must be a non-empty string")
    payload = f"{seed}:{token}".encode("utf-8")
    return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), "big")


class Rng(random.Random):
    """Deterministic RNG stream with audit logging."""

    def __init__(self, seed: int, stream_id: str, *, algo: str = DEFAULT_ALGO) -> None:
        if not isinstance(seed, int):
            raise TypeError(f"seed must be int (got {type(seed).__name__})")
        token = str(stream_id or "").strip()
        if not token:
            raise ValueError("stream_id must be a non-empty string")
        self.stream_id = token
        self.seed_value = int(seed)
        self.algo = str(algo or DEFAULT_ALGO)
        self._sealed = False
        _record_stream(RngStream(seed=self.seed_value, stream_id=self.stream_id, algo=self.algo))
        super().__init__(self.seed_value)
        self._sealed = True

    def seed(self, a: Any = None, version: int = 2) -> None:  # pragma: no cover - tiny guard
        if getattr(self, "_sealed", False):
            raise RuntimeError("Do not reseed helix.rng.Rng instances; create a new stream instead.")
        super().seed(a=a, version=version)


def numpy_rng(seed: int, stream_id: str, *, algo: str = DEFAULT_NUMPY_ALGO) -> Any:
    """Return a deterministic NumPy RNG (Generator) with audit logging."""

    try:
        import numpy as np  # type: ignore
    except Exception as exc:  # pragma: no cover - numpy optional
        raise ImportError("numpy is required for numpy_rng") from exc

    if not isinstance(seed, int):
        raise TypeError(f"seed must be int (got {type(seed).__name__})")
    token = str(stream_id or "").strip()
    if not token:
        raise ValueError("stream_id must be a non-empty string")
    algo_token = str(algo or DEFAULT_NUMPY_ALGO)
    _record_stream(RngStream(seed=int(seed), stream_id=token, algo=algo_token))
    bitgen = np.random.PCG64(int(seed))
    return np.random.Generator(bitgen)


__all__ = [
    "DEFAULT_ALGO",
    "DEFAULT_NUMPY_ALGO",
    "Rng",
    "RngStream",
    "clear_rng_streams",
    "derive_seed",
    "numpy_rng",
    "rng_streams",
]
