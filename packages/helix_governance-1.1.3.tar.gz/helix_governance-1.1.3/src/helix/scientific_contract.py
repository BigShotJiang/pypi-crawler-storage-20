from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
import warnings
from datetime import datetime, timezone
import logging
from pathlib import Path
from typing import Any, Mapping, Tuple
import subprocess

from helix.support.subprocess import no_console_kwargs
from helix import clock
from helix.determinism.nondet import nondeterminism_allowed

try:
    import jsonschema  # type: ignore
except Exception:  # pragma: no cover - jsonschema is a dev extra but required for validation
    jsonschema = None

from helix.provenance import current_git_sha

logger = logging.getLogger(__name__)

CANONICAL_JSON_KWARGS = {
    "sort_keys": True,
    "separators": (",", ":"),
    "ensure_ascii": False,
}

TRUST_VALUES = {"core_verified", "core_unverified", "plugin_derived", "viz_derived"}
BACKEND_FP_SCHEMA_VERSION = "backend-fingerprint/v1"

# In-memory contract identity so session/EVS writers can attach hashes even when callers
# don't thread them explicitly.
_CURRENT_CONTRACT_IDENTITY: dict[str, str | None] = {
    "policy_hash": None,
    "semantic_hash": None,
    "determinism_class": None,
}
_ENV_FALLBACK_WARNED = False
_DISTRIBUTION_SAMPLER: Any = None


def _is_gpu_backend(kind: str | None) -> bool:
    if kind is None:
        return False
    lowered = str(kind).lower()
    return "gpu" in lowered or "cuda" in lowered


def _safe_platform() -> str:
    try:
        return platform.platform()
    except Exception:  # pragma: no cover - platform failures are rare
        return os.name


def _to_int(value: str | None) -> int | None:
    if value is None:
        return None
    try:
        return int(float(str(value)))
    except (TypeError, ValueError):  # pragma: no cover - defensive
        return None


def _run_nvidia_smi(fields: list[str]) -> list[dict[str, str | None]]:
    cmd = ["nvidia-smi", f"--query-gpu={','.join(fields)}", "--format=csv,noheader,nounits"]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=True,
            timeout=2,
            **no_console_kwargs(),
        )
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return []

    entries: list[dict[str, str | None]] = []
    for line in result.stdout.strip().splitlines():
        if not line.strip():
            continue
        parts = [p.strip() or None for p in line.split(",")]
        entry = {field: parts[idx] if idx < len(parts) else None for idx, field in enumerate(fields)}
        entries.append(entry)
    return entries


def _probe_cuda_via_nvidia_smi() -> dict[str, Any] | None:
    fields = ["name", "driver_version", "cuda_version", "uuid", "memory.total", "compute_cap"]
    entries = _run_nvidia_smi(fields)
    if not entries:
        fields = [f for f in fields if f != "compute_cap"]
        entries = _run_nvidia_smi(fields)
    if not entries:
        return None

    devices = [
        {
            "index": idx,
            "name": entry.get("name"),
            "uuid": entry.get("uuid"),
            "memory_total_mb": _to_int(entry.get("memory.total")),
            "compute_capability": entry.get("compute_cap"),
        }
        for idx, entry in enumerate(entries)
    ]
    driver = entries[0].get("driver_version")
    runtime = entries[0].get("cuda_version")
    return {
        "available": True,
        "driver": driver,
        "runtime": runtime,
        "devices": devices,
    }


def _probe_cuda_via_torch() -> dict[str, Any] | None:
    try:  # pragma: no cover - optional dependency
        import torch  # type: ignore
    except Exception:
        return None

    try:
        if not torch.cuda.is_available():
            return {"available": False, "devices": []}
        device_count = torch.cuda.device_count()
        devices = []
        for idx in range(device_count):
            props = torch.cuda.get_device_properties(idx)
            cap_major = getattr(props, "major", None)
            cap_minor = getattr(props, "minor", None)
            devices.append(
                {
                    "index": idx,
                    "name": getattr(props, "name", None),
                    "memory_total_mb": _to_int(getattr(props, "total_memory", None)),
                    "compute_capability": f"{cap_major}.{cap_minor}" if cap_major is not None and cap_minor is not None else None,
                    "uuid": getattr(props, "uuid", None),
                }
            )
        runtime = getattr(getattr(torch, "version", None), "cuda", None)
        return {"available": True, "runtime": runtime, "devices": devices}
    except Exception:  # pragma: no cover - torch CUDA probes can fail on misconfigured systems
        return None


def _collect_cuda_fingerprint() -> dict[str, Any] | None:
    info: dict[str, Any] = {
        "available": False,
        "driver": None,
        "runtime": None,
        "devices": [],
        "tf32_allowed": False,
        "fast_math_allowed": False,
        "schema_version": BACKEND_FP_SCHEMA_VERSION,
    }

    smi_info = _probe_cuda_via_nvidia_smi()
    if smi_info:
        info["driver"] = smi_info.get("driver") or info["driver"]
        info["runtime"] = smi_info.get("runtime") or info["runtime"]
        info["devices"] = smi_info.get("devices") or []
        info["available"] = smi_info.get("available", False) or bool(info["devices"])

    torch_info = _probe_cuda_via_torch()
    if torch_info:
        info["available"] = info["available"] or torch_info.get("available", False)
        info["runtime"] = info["runtime"] or torch_info.get("runtime")
        if not info["devices"]:
            info["devices"] = torch_info.get("devices", [])
        # Math flags (best-effort; optional)
        try:  # pragma: no cover - optional dependency
            import torch  # type: ignore

            info["tf32_allowed"] = bool(
                getattr(torch.backends.cuda.matmul, "allow_tf32", False)
                or getattr(torch.backends.cudnn, "allow_tf32", False)
            )
            info["fast_math_allowed"] = bool(
                getattr(torch.backends.cuda.matmul, "allow_fp16_reduced_precision_reduction", False)
                or getattr(torch.backends.cuda.matmul, "allow_bf16_reduced_precision_reduction", False)
            )
        except Exception:
            pass

    if info["available"] or info["devices"] or info.get("driver") or info.get("runtime"):
        info["device_count"] = len(info.get("devices") or [])
        return info
    return None


def _remember_contract_identity(
    *, policy_hash: str | None = None, semantic_hash: str | None = None, determinism_class: str | None = None
) -> None:
    if policy_hash:
        _CURRENT_CONTRACT_IDENTITY["policy_hash"] = policy_hash
    if semantic_hash:
        _CURRENT_CONTRACT_IDENTITY["semantic_hash"] = semantic_hash
    if determinism_class:
        _CURRENT_CONTRACT_IDENTITY["determinism_class"] = determinism_class


def current_contract_identity() -> dict[str, str | None]:
    """Return the best-known contract identity (policy/semantic hashes, determinism class)."""

    return dict(_CURRENT_CONTRACT_IDENTITY)


def _reset_contract_identity_for_tests() -> None:  # pragma: no cover - test helper
    global _ENV_FALLBACK_WARNED
    _CURRENT_CONTRACT_IDENTITY.update({"policy_hash": None, "semantic_hash": None, "determinism_class": None})
    _ENV_FALLBACK_WARNED = False
    _register_distribution_sampler(None)


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    """Canonical JSON encoding used for hashing."""

    return (json.dumps(payload, **CANONICAL_JSON_KWARGS) + "\n").encode("utf-8")


def sha256_prefixed(payload: Mapping[str, Any]) -> str:
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return f"sha256:{digest}"


def _warn_env_fallback(missing: list[str]) -> None:
    """Emit a single-process warning when we have to fall back to env for identity."""

    global _ENV_FALLBACK_WARNED
    if _ENV_FALLBACK_WARNED:
        return
    _ENV_FALLBACK_WARNED = True
    msg = (
        "Contract identity missing in memory. Using env fallback. "
        "This indicates a writer bypassed policy/semantics load; fix the call path so current_contract_identity is set. "
        f"Keys: {', '.join(sorted(missing))}"
    )
    warnings.warn(msg, stacklevel=3)


def _register_distribution_sampler(fn: Any) -> None:
    """Register or clear an optional D2 distribution sampler hook.

    Signature: fn(seed_bytes: bytes, sample_count: int, case_context: dict) -> Mapping with 'outcomes' list.
    """

    global _DISTRIBUTION_SAMPLER
    _DISTRIBUTION_SAMPLER = fn


def register_distribution_sampler(fn: Any) -> None:
    _register_distribution_sampler(fn)


def get_distribution_sampler() -> Any:
    return _DISTRIBUTION_SAMPLER


def _load_json(path: Path) -> Mapping[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, Mapping):
        raise ValueError(f"{path} must contain a JSON object")
    return data


def _validate(schema_path: Path, payload: Mapping[str, Any]) -> None:
    if jsonschema is None:
        raise RuntimeError("jsonschema is required to validate scientific contract payloads; install dev extras")
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    jsonschema.validate(instance=payload, schema=schema)


def _default_paths() -> tuple[Path, Path]:
    root = Path(__file__).resolve().parents[2]
    policy_override = os.getenv("HELIX_POLICY_PATH")
    semantics_override = os.getenv("HELIX_MODEL_SEMANTICS_PATH")
    policy_path = Path(policy_override) if policy_override else (root / "repro" / "policy.example.json")
    semantics_path = (
        Path(semantics_override) if semantics_override else (root / "repro" / "model_semantics.example.json")
    )
    return (policy_path, semantics_path)


def load_policy(
    policy: Mapping[str, Any] | None = None,
    *,
    path: str | Path | None = None,
    schema_path: str | Path | None = None,
) -> Tuple[Mapping[str, Any], str, str, str | None]:
    """Load + validate policy JSON and return (payload, hash, determinismClass, resolved_path)."""

    if policy is None:
        default_policy_path, _ = _default_paths()
        policy_path = Path(path) if path else default_policy_path
        payload = _load_json(policy_path)
    else:
        policy_path = Path(path) if path else None
        payload = dict(policy)
    schema = Path(schema_path) if schema_path else Path(__file__).resolve().parents[2] / "repro" / "policy.schema.json"
    _validate(schema, payload)
    if "determinismClass" not in payload:
        raise ValueError("policy must declare determinismClass")
    determinism = str(payload["determinismClass"])
    resolved_path_str = str(policy_path.resolve()) if policy_path else None
    policy_hash = sha256_prefixed(payload)
    logger.info(
        "Policy resolved",
        extra={
            "policy_path": resolved_path_str or "(inline)",
            "policy_hash": policy_hash,
            "determinism": determinism,
        },
    )
    _remember_contract_identity(policy_hash=policy_hash, determinism_class=determinism)
    return payload, policy_hash, determinism, resolved_path_str


def load_model_semantics(
    semantics: Mapping[str, Any] | None = None,
    *,
    path: str | Path | None = None,
    schema_path: str | Path | None = None,
) -> Tuple[Mapping[str, Any], str]:
    if semantics is None:
        _, default_semantics_path = _default_paths()
        semantics_path = Path(path) if path else default_semantics_path
        payload = _load_json(semantics_path)
    else:
        payload = dict(semantics)
    schema = (
        Path(schema_path)
        if schema_path
        else Path(__file__).resolve().parents[2] / "repro" / "model_semantics.schema.json"
    )
    _validate(schema, payload)
    semantic_hash = sha256_prefixed(payload)
    _remember_contract_identity(semantic_hash=semantic_hash)
    return payload, semantic_hash


def collect_backend_fingerprint(*, backend_kind: str | None = None, deterministic: bool = False) -> tuple[str, dict[str, Any]]:
    """
    Produce a structured backend fingerprint for headers.

    - CPU: records OS + Python version; leaves cuda=None.
    - GPU-kind backends: attempts to collect CUDA runtime/driver/device info (via nvidia-smi, then torch).
    - deterministic=True uses placeholder values for repeatable fixtures.
    """

    kind = backend_kind or "cpu"
    if deterministic:
        return kind, {
            "os": "deterministic",
            "python": "deterministic",
            "cuda": None,
            "schema_version": BACKEND_FP_SCHEMA_VERSION,
            "complete": True,
        }

    details: dict[str, Any] = {
        "os": _safe_platform(),
        "python": sys.version.split()[0],
        "schema_version": BACKEND_FP_SCHEMA_VERSION,
    }

    if _is_gpu_backend(kind):
        cuda_info = _collect_cuda_fingerprint()
        details["cuda"] = cuda_info if cuda_info else {"available": False, "schema_version": BACKEND_FP_SCHEMA_VERSION}
    else:
        details["cuda"] = None

    details["complete"] = is_backend_fingerprint_complete(kind, details)
    return kind, details


def is_backend_fingerprint_complete(backend_kind: str | None, details: Mapping[str, Any] | None) -> bool:
    if details is None:
        return False
    if not isinstance(details, Mapping):
        return False
    if details.get("schema_version") != BACKEND_FP_SCHEMA_VERSION:
        return False
    if not details.get("os") or not details.get("python"):
        return False

    if not _is_gpu_backend(backend_kind):
        # CPU path: os + python + cuda key present (can be None) are sufficient
        return "cuda" in details

    cuda = details.get("cuda")
    if not isinstance(cuda, Mapping):
        return False
    if cuda.get("schema_version") != BACKEND_FP_SCHEMA_VERSION:
        return False
    if not cuda.get("available"):
        return False
    required_simple = ["driver", "runtime", "device_count", "tf32_allowed", "fast_math_allowed"]
    if any(key not in cuda for key in required_simple):
        return False
    if not cuda.get("driver") or not cuda.get("runtime"):
        return False
    if _to_int(str(cuda.get("device_count"))) in (None, 0):
        return False
    devices = cuda.get("devices")
    if not isinstance(devices, list) or len(devices) == 0:
        return False
    for dev in devices:
        if not isinstance(dev, Mapping):
            return False
        if not dev.get("name"):
            return False
        if not (dev.get("uuid") or dev.get("compute_capability")):
            return False
    return True


def build_artifact_header(
    *,
    run_id: str,
    policy_hash: str,
    semantic_hash: str,
    determinism_class: str,
    policy_path: str | None = None,
    trust: str = "core_verified",
    engine_version: str | None = None,
    backend_kind: str | None = None,
    backend_details: Mapping[str, Any] | None = None,
    created_at: datetime | None = None,
    deterministic: bool = False,
) -> dict[str, Any]:
    if trust not in TRUST_VALUES:
        raise ValueError(f"trust must be one of {sorted(TRUST_VALUES)}")

    created_utc = ""
    if created_at is not None:
        created_utc = created_at.isoformat().replace("+00:00", "Z")
    elif deterministic:
        created_utc = clock.deterministic_utc_iso()
    else:
        def _truthy(value: str | None) -> bool:
            return str(value or "").strip().lower() in {"1", "true", "yes", "on"}

        deterministic_mode = _truthy(os.getenv("HELIX_DETERMINISTIC")) or _truthy(os.getenv("HELIX_FORBID_RANDOM"))
        if deterministic_mode and not nondeterminism_allowed():
            raise ValueError(
                "created_at is required when deterministic=False under deterministic mode.\n"
                "Fix: pass created_at explicitly, or wrap the call site in "
                "`helix.determinism.allow_nondeterminism(reason=...)` if this timestamp is for UI/telemetry only."
            )
        created_utc = clock.utc_now_iso()
    resolved_kind = backend_kind or "cpu"

    normalized_backend_details: dict[str, Any] | None = None
    if backend_details is not None:
        normalized_backend_details = dict(backend_details)
        normalized_backend_details.setdefault("schema_version", BACKEND_FP_SCHEMA_VERSION)
        if isinstance(normalized_backend_details.get("cuda"), Mapping):
            normalized_backend_details["cuda"] = dict(normalized_backend_details["cuda"])
            normalized_backend_details["cuda"].setdefault("schema_version", BACKEND_FP_SCHEMA_VERSION)

    need_probe = backend_details is None or not is_backend_fingerprint_complete(
        resolved_kind, normalized_backend_details
    )

    if need_probe:
        probed_kind, default_details = collect_backend_fingerprint(backend_kind=resolved_kind, deterministic=deterministic)
        resolved_kind = backend_kind or probed_kind
        details = dict(default_details)
        if normalized_backend_details:
            for key, value in normalized_backend_details.items():
                if key == "cuda" and isinstance(value, Mapping) and isinstance(details.get("cuda"), Mapping):
                    default_cuda = dict(details.get("cuda") or {})
                    provided_cuda = dict(value)
                    merged_cuda = dict(default_cuda)
                    for k, v in provided_cuda.items():
                        if k == "devices" and isinstance(v, list):
                            merged_devices = []
                            default_devices = default_cuda.get("devices") if isinstance(default_cuda.get("devices"), list) else []
                            for idx, dev in enumerate(v):
                                base = {}
                                if isinstance(default_devices, list) and idx < len(default_devices) and isinstance(default_devices[idx], Mapping):
                                    base.update(default_devices[idx])
                                if isinstance(dev, Mapping):
                                    base.update(dev)
                                if base:
                                    merged_devices.append(base)
                            if len(merged_devices) < len(default_devices):
                                merged_devices.extend([d for d in default_devices[len(merged_devices):] if isinstance(d, Mapping)])
                            merged_cuda["devices"] = merged_devices
                        else:
                            merged_cuda[k] = v
                    merged_cuda.setdefault("schema_version", BACKEND_FP_SCHEMA_VERSION)
                    details["cuda"] = merged_cuda
                else:
                    details[key] = value
    else:
        details = dict(normalized_backend_details) if normalized_backend_details else {}

    details["complete"] = is_backend_fingerprint_complete(resolved_kind, details)

    header = {
        "artifactVersion": "1.0",
        "runId": str(run_id),
        "createdUtc": created_utc,
        "engineVersion": engine_version or current_git_sha() or "unknown",
        "policyHash": policy_hash,
        "semanticHash": semantic_hash,
        "backend": {"kind": resolved_kind, "details": details},
        "determinismClass": determinism_class,
        "trust": trust,
        "trustCheckVersion": "trust-check/v1",
    }
    if policy_path:
        header["policyPath"] = policy_path
        header["policyName"] = Path(policy_path).name
    return header


def attach_header(payload: Mapping[str, Any] | None, header: Mapping[str, Any]) -> dict[str, Any]:
    base: dict[str, Any] = {}
    if isinstance(payload, Mapping):
        base.update(payload)
    base["header"] = dict(header)
    return base


__all__ = [
    "attach_header",
    "build_artifact_header",
    "collect_backend_fingerprint",
    "is_backend_fingerprint_complete",
    "BACKEND_FP_SCHEMA_VERSION",
    "canonical_json_bytes",
    "load_model_semantics",
    "load_policy",
    "current_contract_identity",
    "_reset_contract_identity_for_tests",
    "register_distribution_sampler",
    "get_distribution_sampler",
    "sha256_prefixed",
    "TRUST_VALUES",
]
