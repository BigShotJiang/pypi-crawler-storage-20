from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any, Mapping, Sequence

from .posterior import EvidenceTrace, OutcomeEntry, Posterior, build_outcome_distribution, entropy_bits


@dataclass(frozen=True)
class EvidenceSpec:
    evidence_type: str
    source: str
    evidence_id: str | None = None
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "type": self.evidence_type,
            "source": self.source,
        }
        if self.evidence_id:
            payload["evidence_id"] = self.evidence_id
        if self.notes:
            payload["notes"] = self.notes
        return payload


@dataclass(frozen=True)
class EvidenceBundle:
    spec: EvidenceSpec
    observed_outcomes: tuple[dict[str, Any], ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "spec": self.spec.to_dict(),
            "observed_outcomes": [dict(entry) for entry in self.observed_outcomes],
        }


# Backwards compatibility for prior API
AssimilationTrace = EvidenceTrace


def _extract_observed_prob(entry: Mapping[str, Any]) -> float:
    for key in ("frequency", "probability", "prob", "p"):
        if key in entry:
            try:
                value = float(entry.get(key) or 0.0)
            except (TypeError, ValueError):
                value = 0.0
            return max(0.0, value)
    return 0.0


def _summarize_distribution(entries: Sequence[OutcomeEntry]) -> dict[str, Any]:
    probs = [float(entry.probability) for entry in entries]
    top = max(entries, key=lambda e: float(e.probability)) if entries else None
    return {
        "outcomes": len(entries),
        "entropy_bits": float(entropy_bits(probs)),
        "top_label": top.label if top else None,
        "top_probability": float(top.probability) if top else None,
    }


def _summarize_observed(observed: Mapping[str, float]) -> dict[str, Any]:
    probs = list(observed.values())
    top_label = None
    top_prob = None
    if observed:
        top_label = max(observed.items(), key=lambda kv: kv[1])[0]
        top_prob = float(observed[top_label])
    return {
        "outcomes": len(observed),
        "entropy_bits": float(entropy_bits(probs)),
        "top_label": top_label,
        "top_probability": top_prob,
    }


def _coerce_spec(spec: EvidenceSpec | Mapping[str, Any]) -> EvidenceSpec:
    if isinstance(spec, EvidenceSpec):
        return spec
    if not isinstance(spec, Mapping):
        raise ValueError("EvidenceSpec must be a mapping or EvidenceSpec instance.")
    evidence_type = str(spec.get("type") or spec.get("evidence_type") or "")
    source = str(spec.get("source") or "")
    if not evidence_type or not source:
        raise ValueError("EvidenceSpec requires non-empty 'type' and 'source'.")
    return EvidenceSpec(
        evidence_type=evidence_type,
        source=source,
        evidence_id=str(spec.get("evidence_id") or "") or None,
        notes=str(spec.get("notes") or "") or None,
    )


def normalize_evidence(
    spec: EvidenceSpec | Mapping[str, Any],
    observed_outcomes: Sequence[Mapping[str, Any]] | None,
) -> EvidenceBundle:
    spec_obj = _coerce_spec(spec)
    normalized: list[dict[str, Any]] = []
    if observed_outcomes:
        for entry in observed_outcomes:
            if isinstance(entry, Mapping):
                normalized.append(dict(entry))
    return EvidenceBundle(spec=spec_obj, observed_outcomes=tuple(normalized))


def assimilate_posterior(
    posterior: Posterior,
    spec: EvidenceSpec | Mapping[str, Any],
    observed_outcomes: Sequence[Mapping[str, Any]] | None,
) -> tuple[Posterior, EvidenceTrace]:
    bundle = normalize_evidence(spec, observed_outcomes)
    observed_list = list(bundle.observed_outcomes)
    if not observed_list:
        trace = EvidenceTrace(
            status="no_assimilation",
            reason="no_observed_outcomes",
            notes="Evidence recorded without updating posterior distribution.",
            prior_summary=_summarize_distribution(list(posterior.distribution.outcomes)),
        )
        updated = replace(posterior, evidence=bundle.to_dict(), evidence_trace=trace)
        return updated, trace

    observed_raw: dict[str, float] = {}
    for entry in observed_list:
        label = str(entry.get("label") or entry.get("name") or entry.get("category") or "").strip()
        if not label:
            continue
        observed_raw[label] = observed_raw.get(label, 0.0) + _extract_observed_prob(entry)
    total_obs = sum(observed_raw.values())
    if total_obs > 0.0:
        observed = {k: v / total_obs for k, v in observed_raw.items()}
    else:
        observed = {}

    prior_entries = list(posterior.distribution.outcomes)
    if not prior_entries:
        trace = EvidenceTrace(
            status="no_assimilation",
            reason="no_prior_outcomes",
            notes="Evidence recorded but no prior outcomes were available.",
            observed_summary=_summarize_observed(observed),
        )
        updated = replace(posterior, evidence=bundle.to_dict(), evidence_trace=trace)
        return updated, trace

    epsilon = 1e-6
    weights: list[tuple[OutcomeEntry, float]] = []
    for entry in prior_entries:
        obs_p = observed.get(entry.label, 0.0)
        weight = float(entry.probability) * (obs_p + epsilon)
        weights.append((entry, weight))

    total_weight = sum(w for _, w in weights) or 1.0
    updated_outcomes: list[dict[str, Any]] = []
    for entry, weight in weights:
        prob = weight / total_weight
        updated_outcomes.append(
            {
                "label": entry.label,
                "probability": prob,
                "category": entry.category,
                "tags": list(entry.tags),
                "metadata": dict(entry.metadata),
            }
        )

    new_distribution = build_outcome_distribution(updated_outcomes)
    prior_summary = _summarize_distribution(prior_entries)
    observed_summary = _summarize_observed(observed)
    posterior_summary = _summarize_distribution(list(new_distribution.outcomes))

    prior_map = {e.label: float(e.probability) for e in prior_entries}
    post_map = {e.label: float(e.probability) for e in new_distribution.outcomes}
    tvd = 0.5 * sum(abs(post_map.get(k, 0.0) - prior_map.get(k, 0.0)) for k in set(prior_map) | set(post_map))
    delta_metrics = {
        "entropy_delta_bits": float(posterior_summary["entropy_bits"]) - float(prior_summary["entropy_bits"]),
        "total_variation_distance": float(tvd),
    }

    trace = EvidenceTrace(
        status="assimilated",
        reason="observed_outcomes_reweighted",
        notes="Posterior probabilities reweighted by observed outcome frequencies.",
        prior_summary=prior_summary,
        observed_summary=observed_summary,
        posterior_summary=posterior_summary,
        delta_metrics=delta_metrics,
    )
    updated = replace(
        posterior,
        distribution=new_distribution,
        evidence=bundle.to_dict(),
        evidence_trace=trace,
    )
    return updated, trace


__all__ = [
    "EvidenceSpec",
    "EvidenceBundle",
    "EvidenceTrace",
    "AssimilationTrace",
    "normalize_evidence",
    "assimilate_posterior",
]
