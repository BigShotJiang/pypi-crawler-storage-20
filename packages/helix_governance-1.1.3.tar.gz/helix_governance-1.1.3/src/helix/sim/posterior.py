from __future__ import annotations

import math
import os
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Protocol, Sequence

from helix.clock import deterministic_utc_iso, utc_now_iso

POSTERIOR_SCHEMA = "helix_outcome_posterior_v1"

PROBABILITY_KEYS = ("probability", "prob", "p", "frequency")
LABEL_KEYS = ("label", "name", "category")
CATEGORY_KEYS = ("category", "kind")
TAG_KEYS = ("tags",)

DEFAULT_FAILURE_KEYWORDS = (
    "failure",
    "pegRNA_failure",
    "base_failure",
    "catastrophic",
    "apoptosis",
    "persistent_dsb",
    "rearrangement",
)


def entropy_bits(probs: Iterable[float]) -> float:
    values = [p for p in probs if p > 0.0 and math.isfinite(p)]
    if not values:
        return 0.0
    return float(-sum(p * math.log2(p) for p in values))


def _coerce_float(value: Any, *, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _sanitize_probability(value: Any) -> float:
    prob = _coerce_float(value, default=0.0)
    if not math.isfinite(prob) or prob < 0.0:
        return 0.0
    return prob


def _extract_probability(entry: Mapping[str, Any], *, draws: int | None = None) -> float:
    if draws is not None and draws > 0:
        count = entry.get("count")
        if count is not None:
            return _sanitize_probability(_coerce_float(count, default=0.0) / float(draws))
    for key in PROBABILITY_KEYS:
        if key in entry:
            return _sanitize_probability(entry.get(key))
    return 0.0


def _extract_label(entry: Mapping[str, Any], idx: int) -> str:
    for key in LABEL_KEYS:
        value = entry.get(key)
        if value is None:
            continue
        label = str(value).strip()
        if label:
            return label
    return f"outcome_{idx + 1}"


def _extract_category(entry: Mapping[str, Any]) -> str | None:
    for key in CATEGORY_KEYS:
        value = entry.get(key)
        if value is None:
            continue
        label = str(value).strip()
        if label:
            return label
    diff = entry.get("diff")
    if isinstance(diff, Mapping):
        kind = diff.get("kind")
        if kind is not None:
            label = str(kind).strip()
            if label:
                return label
    delta = entry.get("sequenceDelta")
    if isinstance(delta, Mapping):
        kind = delta.get("type")
        if kind is not None:
            label = str(kind).strip()
            if label:
                return label
    return None


def _extract_tags(entry: Mapping[str, Any]) -> tuple[str, ...]:
    for key in TAG_KEYS:
        raw = entry.get(key)
        if isinstance(raw, (list, tuple)):
            return tuple(str(item) for item in raw if str(item))
    return ()


def _extract_metadata(entry: Mapping[str, Any]) -> dict[str, Any]:
    metadata: dict[str, Any] = {}
    raw_meta = entry.get("metadata")
    if isinstance(raw_meta, Mapping):
        metadata.update(dict(raw_meta))

    for key, value in entry.items():
        if key in PROBABILITY_KEYS or key in LABEL_KEYS or key in TAG_KEYS:
            continue
        if key == "metadata":
            continue
        metadata.setdefault(key, value)

    return metadata


def _matches_failure(entry: "OutcomeEntry", failure_keywords: Sequence[str]) -> bool:
    if not failure_keywords:
        return False
    label = (entry.label or "").lower()
    category = (entry.category or "").lower()
    tags = [t.lower() for t in entry.tags]
    for keyword in failure_keywords:
        token = str(keyword).lower()
        if not token:
            continue
        if token in label or token in category:
            return True
        if any(token in tag for tag in tags):
            return True
    return False


@dataclass(frozen=True)
class IntegritySummary:
    warnings: tuple[str, ...] = ()
    failures: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "warnings": list(self.warnings),
            "failures": list(self.failures),
        }


@dataclass(frozen=True)
class TruncationSummary:
    top_k: int
    tail_label: str
    tail_count: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "top_k": int(self.top_k),
            "tail_label": self.tail_label,
            "tail_count": int(self.tail_count),
        }


@dataclass(frozen=True)
class OutcomeEntry:
    label: str
    probability: float
    category: str | None = None
    tags: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "label": self.label,
            "probability": float(self.probability),
        }
        if self.category:
            payload["category"] = self.category
        if self.tags:
            payload["tags"] = list(self.tags)
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        return payload


@dataclass(frozen=True)
class OutcomeDistribution:
    outcomes: tuple[OutcomeEntry, ...]
    entropy_bits: float
    failure_mass: float
    tail_mass: float
    total_probability: float
    truncation: TruncationSummary | None = None
    integrity: IntegritySummary = field(default_factory=IntegritySummary)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "outcomes": [entry.to_dict() for entry in self.outcomes],
            "entropy_bits": float(self.entropy_bits),
            "failure_mass": float(self.failure_mass),
            "tail_mass": float(self.tail_mass),
            "total_probability": float(self.total_probability),
            "integrity": self.integrity.to_dict(),
        }
        if self.truncation is not None:
            payload["truncation"] = self.truncation.to_dict()
        return payload


@dataclass(frozen=True)
class ModelInfo:
    model_id: str
    model_version: str
    model_kind: str
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "id": self.model_id,
            "version": self.model_version,
            "kind": self.model_kind,
        }
        if self.notes:
            payload["notes"] = self.notes
        return payload


@dataclass(frozen=True)
class CalibrationSummary:
    status: str
    score: float | None = None
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "status": self.status,
            "score": self.score,
        }
        if self.notes:
            payload["notes"] = self.notes
        return payload


@dataclass(frozen=True)
class CredibleInterval:
    mean: float
    lower: float
    upper: float
    level: float | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "mean": float(self.mean),
            "lower": float(self.lower),
            "upper": float(self.upper),
        }
        if self.level is not None:
            payload["level"] = float(self.level)
        return payload


@dataclass(frozen=True)
class TailRiskSummary:
    metric: str
    value: float | None = None
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {"metric": self.metric, "value": self.value}
        if self.notes:
            payload["notes"] = self.notes
        return payload


@dataclass(frozen=True)
class OffTargetBurden:
    status: str
    executed_mode: str
    calibration_status: str
    reason: str | None = None
    provider_id: str | None = None
    expected_cuts: CredibleInterval | None = None
    tail_risk: TailRiskSummary | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "status": self.status,
            "executed_mode": self.executed_mode,
            "calibration_status": self.calibration_status,
        }
        if self.reason:
            payload["reason"] = self.reason
        if self.provider_id:
            payload["provider_id"] = self.provider_id
        if self.expected_cuts is not None:
            payload["expected_cuts"] = self.expected_cuts.to_dict()
        if self.tail_risk is not None:
            payload["tail_risk"] = self.tail_risk.to_dict()
        return payload


@dataclass(frozen=True)
class EvidenceTrace:
    status: str
    reason: str
    notes: str | None = None
    prior_summary: Mapping[str, Any] | None = None
    observed_summary: Mapping[str, Any] | None = None
    posterior_summary: Mapping[str, Any] | None = None
    delta_metrics: Mapping[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "status": self.status,
            "reason": self.reason,
        }
        if self.notes:
            payload["notes"] = self.notes
        if self.prior_summary is not None:
            payload["prior_summary"] = dict(self.prior_summary)
        if self.observed_summary is not None:
            payload["observed_summary"] = dict(self.observed_summary)
        if self.posterior_summary is not None:
            payload["posterior_summary"] = dict(self.posterior_summary)
        if self.delta_metrics is not None:
            payload["delta_metrics"] = dict(self.delta_metrics)
        return payload


@dataclass(frozen=True)
class Posterior:
    schema: str
    generated_at: str
    model: ModelInfo
    distribution: OutcomeDistribution
    calibration: CalibrationSummary
    off_target: OffTargetBurden | None = None
    evidence_trace: EvidenceTrace | None = None
    edit_spec: Mapping[str, Any] | None = None
    context: Mapping[str, Any] | None = None
    evidence: Mapping[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "schema": self.schema,
            "generated_at": self.generated_at,
            "model": self.model.to_dict(),
            "distribution": self.distribution.to_dict(),
            "calibration": self.calibration.to_dict(),
        }
        if self.off_target is not None:
            payload["off_target"] = self.off_target.to_dict()
        if self.evidence_trace is not None:
            payload["evidence_trace"] = self.evidence_trace.to_dict()
        if self.edit_spec is not None:
            payload["edit_spec"] = dict(self.edit_spec)
        if self.context is not None:
            payload["context"] = dict(self.context)
        if self.evidence is not None:
            payload["evidence"] = dict(self.evidence)
        return payload


class OutcomeDistributionModel(Protocol):
    model_id: str
    model_version: str
    model_kind: str

    def predict(
        self,
        edit_spec: Mapping[str, Any],
        context: Mapping[str, Any] | None = None,
        evidence: Mapping[str, Any] | None = None,
    ) -> Posterior: ...


def build_outcome_distribution(
    outcomes: Sequence[Mapping[str, Any] | OutcomeEntry],
    *,
    draws: int | None = None,
    top_k: int | None = None,
    tail_label: str = "other",
    failure_keywords: Sequence[str] = DEFAULT_FAILURE_KEYWORDS,
    epsilon: float = 1e-6,
) -> OutcomeDistribution:
    entries: list[OutcomeEntry] = []
    for idx, entry in enumerate(outcomes):
        if isinstance(entry, OutcomeEntry):
            entries.append(entry)
            continue
        if not isinstance(entry, Mapping):
            continue
        prob = _extract_probability(entry, draws=draws)
        label = _extract_label(entry, idx)
        category = _extract_category(entry)
        tags = _extract_tags(entry)
        metadata = _extract_metadata(entry)
        entries.append(
            OutcomeEntry(
                label=label,
                probability=prob,
                category=category,
                tags=tags,
                metadata=metadata,
            )
        )

    entries.sort(key=lambda e: (-float(e.probability), e.label))

    total_prob = sum(float(entry.probability) for entry in entries)
    warnings: list[str] = []
    failures: list[str] = []
    if total_prob <= 0.0:
        failures.append("probability_total_zero")
    elif abs(total_prob - 1.0) > epsilon:
        warnings.append("probability_not_conserved")

    norm = 1.0 / total_prob if total_prob > 0.0 else 0.0
    normalized_entries = [
        OutcomeEntry(
            label=entry.label,
            probability=float(entry.probability) * norm,
            category=entry.category,
            tags=entry.tags,
            metadata=entry.metadata,
        )
        for entry in entries
    ]

    tail_mass = 0.0
    truncation: TruncationSummary | None = None
    if top_k is not None and top_k > 0 and len(normalized_entries) > top_k:
        kept = normalized_entries[:top_k]
        tail_entries = normalized_entries[top_k:]
        tail_mass = sum(float(entry.probability) for entry in tail_entries)
        truncation = TruncationSummary(top_k=top_k, tail_label=tail_label, tail_count=len(tail_entries))
    else:
        kept = normalized_entries

    failure_mass = sum(
        float(entry.probability)
        for entry in normalized_entries
        if _matches_failure(entry, failure_keywords)
    )

    entropy = entropy_bits(entry.probability for entry in normalized_entries)

    return OutcomeDistribution(
        outcomes=tuple(kept),
        entropy_bits=float(entropy),
        failure_mass=float(failure_mass),
        tail_mass=float(tail_mass),
        total_probability=float(total_prob),
        truncation=truncation,
        integrity=IntegritySummary(warnings=tuple(warnings), failures=tuple(failures)),
    )


def build_posterior(
    outcomes: Sequence[Mapping[str, Any] | OutcomeEntry],
    *,
    draws: int | None = None,
    model_id: str,
    model_version: str,
    model_kind: str,
    model_notes: str | None = None,
    edit_spec: Mapping[str, Any] | None = None,
    context: Mapping[str, Any] | None = None,
    evidence: Mapping[str, Any] | None = None,
    evidence_trace: EvidenceTrace | Mapping[str, Any] | None = None,
    off_target: OffTargetBurden | Mapping[str, Any] | None = None,
    calibration_status: str = "uncalibrated",
    calibration_score: float | None = None,
    calibration_notes: str | None = None,
    top_k: int | None = None,
    tail_label: str = "other",
    failure_keywords: Sequence[str] = DEFAULT_FAILURE_KEYWORDS,
) -> Posterior:
    distribution = build_outcome_distribution(
        outcomes,
        draws=draws,
        top_k=top_k,
        tail_label=tail_label,
        failure_keywords=failure_keywords,
    )
    model = ModelInfo(model_id=model_id, model_version=model_version, model_kind=model_kind, notes=model_notes)
    calibration = CalibrationSummary(status=calibration_status, score=calibration_score, notes=calibration_notes)
    generated_at = deterministic_utc_iso() if os.getenv("HELIX_DETERMINISTIC") else utc_now_iso()
    if off_target is None:
        off_target_payload = OffTargetBurden(
            status="not_computed",
            executed_mode="not_computed",
            calibration_status="not_computed",
            reason="off_target_burden_not_computed",
        )
    elif isinstance(off_target, OffTargetBurden):
        off_target_payload = off_target
    else:
        status = str(off_target.get("status") or "not_computed")
        executed_mode = str(off_target.get("executed_mode") or status)
        calibration_status = str(off_target.get("calibration_status") or status)
        expected = off_target.get("expected_cuts")
        expected_cuts = None
        if isinstance(expected, Mapping):
            expected_cuts = CredibleInterval(
                mean=_coerce_float(expected.get("mean"), default=0.0),
                lower=_coerce_float(expected.get("lower"), default=0.0),
                upper=_coerce_float(expected.get("upper"), default=0.0),
                level=_coerce_float(expected.get("level"), default=0.0) if expected.get("level") is not None else None,
            )
        tail = off_target.get("tail_risk")
        tail_risk = None
        if isinstance(tail, Mapping):
            tail_risk = TailRiskSummary(
                metric=str(tail.get("metric") or "unconfigured"),
                value=_coerce_float(tail.get("value"), default=0.0) if tail.get("value") is not None else None,
                notes=str(tail.get("notes") or "") or None,
            )
        off_target_payload = OffTargetBurden(
            status=status,
            executed_mode=executed_mode,
            calibration_status=calibration_status,
            reason=str(off_target.get("reason") or "") or None,
            provider_id=str(off_target.get("provider_id") or "") or None,
            expected_cuts=expected_cuts,
            tail_risk=tail_risk,
        )
    if off_target_payload is None:
        raise ValueError("off_target_burden must be provided")
    if str(off_target_payload.status).lower() == "not_computed" and not (off_target_payload.reason or "").strip():
        raise ValueError("off_target_burden.status=not_computed requires a non-empty reason")

    if evidence_trace is None:
        evidence_trace_payload = EvidenceTrace(
            status="no_assimilation",
            reason="no_assimilation_performed",
            notes="No assimilation performed; posterior reflects model priors only.",
        )
    elif isinstance(evidence_trace, EvidenceTrace):
        evidence_trace_payload = evidence_trace
    else:
        status = str(evidence_trace.get("status") or "")
        reason = str(evidence_trace.get("reason") or "")
        if not status:
            raise ValueError("evidence_trace.status is required")
        if not reason:
            raise ValueError("evidence_trace.reason is required")
        evidence_trace_payload = EvidenceTrace(
            status=status,
            reason=reason,
            notes=str(evidence_trace.get("notes") or "") or None,
            prior_summary=evidence_trace.get("prior_summary") if isinstance(evidence_trace.get("prior_summary"), Mapping) else None,
            observed_summary=(
                evidence_trace.get("observed_summary")
                if isinstance(evidence_trace.get("observed_summary"), Mapping)
                else None
            ),
            posterior_summary=(
                evidence_trace.get("posterior_summary")
                if isinstance(evidence_trace.get("posterior_summary"), Mapping)
                else None
            ),
            delta_metrics=evidence_trace.get("delta_metrics") if isinstance(evidence_trace.get("delta_metrics"), Mapping) else None,
        )
    if not (evidence_trace_payload.reason or "").strip():
        raise ValueError("evidence_trace.reason must be non-empty")
    return Posterior(
        schema=POSTERIOR_SCHEMA,
        generated_at=generated_at,
        model=model,
        distribution=distribution,
        calibration=calibration,
        off_target=off_target_payload,
        evidence_trace=evidence_trace_payload,
        edit_spec=edit_spec,
        context=context,
        evidence=evidence,
    )


__all__ = [
    "POSTERIOR_SCHEMA",
    "DEFAULT_FAILURE_KEYWORDS",
    "OutcomeEntry",
    "OutcomeDistribution",
    "ModelInfo",
    "CalibrationSummary",
    "CredibleInterval",
    "TailRiskSummary",
    "OffTargetBurden",
    "EvidenceTrace",
    "IntegritySummary",
    "TruncationSummary",
    "Posterior",
    "OutcomeDistributionModel",
    "entropy_bits",
    "build_outcome_distribution",
    "build_posterior",
]
