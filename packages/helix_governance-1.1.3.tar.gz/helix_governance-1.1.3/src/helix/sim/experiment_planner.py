from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from ..rng import Rng
from .posterior import Posterior, entropy_bits

PLANNER_VERSION = "v0_entropy_proxy_dirichlet"
PLANNER_NOTE = "entropy proxy (in silico), not a wet-lab protocol instruction"


@dataclass(frozen=True)
class ExperimentCandidate:
    kind: str
    assay: str
    effective_reads: int
    expected_information_gain_bits: float
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "kind": self.kind,
            "assay": self.assay,
            "effective_reads": int(self.effective_reads),
            "expected_information_gain_bits": float(self.expected_information_gain_bits),
        }
        if self.notes:
            payload["notes"] = self.notes
        return payload


@dataclass(frozen=True)
class ExperimentRecommendation:
    status: str
    reason: str
    objective: str
    prior_entropy_bits: float | None = None
    best: ExperimentCandidate | None = None
    candidates: tuple[ExperimentCandidate, ...] = ()
    target: dict[str, Any] | None = None
    notes: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "status": self.status,
            "reason": self.reason,
            "objective": self.objective,
        }
        if self.prior_entropy_bits is not None:
            payload["prior_entropy_bits"] = float(self.prior_entropy_bits)
        if self.best is not None:
            payload["best"] = self.best.to_dict()
        payload["candidates"] = [candidate.to_dict() for candidate in self.candidates]
        if self.target is not None:
            payload["target"] = dict(self.target)
        if self.notes:
            payload["notes"] = self.notes
        return payload


DEFAULT_ASSAY_READS: Mapping[str, int] = {
    "SANGER": 30,
    "LONGREAD": 150,
    "AMPLICONSEQ": 500,
}


def _digamma(x: float) -> float:
    if x <= 0.0 or not math.isfinite(x):
        raise ValueError("digamma requires a finite x > 0")
    result = 0.0
    while x < 6.0:
        result -= 1.0 / x
        x += 1.0
    inv = 1.0 / x
    inv2 = inv * inv
    # Asymptotic expansion
    result += math.log(x) - 0.5 * inv - inv2 * (1.0 / 12.0 - inv2 * (1.0 / 120.0 - inv2 * (1.0 / 252.0)))
    return result


def _dirichlet_entropy_bits(alpha: Sequence[float]) -> float:
    if not alpha:
        return 0.0
    alpha0 = float(sum(alpha))
    if alpha0 <= 0.0 or not math.isfinite(alpha0):
        return 0.0
    k = float(len(alpha))
    ln_beta = float(sum(math.lgamma(float(a)) for a in alpha) - math.lgamma(alpha0))
    psi_alpha0 = _digamma(alpha0)
    term = (alpha0 - k) * psi_alpha0 - sum((float(a) - 1.0) * _digamma(float(a)) for a in alpha)
    h_nats = ln_beta + term
    return float(h_nats / math.log(2.0))


def _extract_target_metadata(posterior: Mapping[str, Any]) -> dict[str, Any]:
    edit_spec = posterior.get("edit_spec") if isinstance(posterior.get("edit_spec"), Mapping) else {}
    guide = edit_spec.get("guide") if isinstance(edit_spec.get("guide"), Mapping) else {}
    site = edit_spec.get("site") if isinstance(edit_spec.get("site"), Mapping) else {}
    target: dict[str, Any] = {}
    guide_id = str(guide.get("id") or "").strip()
    if guide_id:
        target["guide_id"] = guide_id
    seq_sha = str(site.get("sequence_sha256") or site.get("sequenceSha256") or "").strip()
    if seq_sha:
        target["site_sequence_sha256"] = seq_sha
    return target


def _extract_labels_probs_from_distribution_payload(
    distribution: Mapping[str, Any],
) -> tuple[list[str], list[float]]:
    outcomes = distribution.get("outcomes")
    if not isinstance(outcomes, Sequence) or isinstance(outcomes, (str, bytes, bytearray)):
        return [], []

    labels: list[str] = []
    probs: list[float] = []
    for entry in outcomes:
        if not isinstance(entry, Mapping):
            continue
        label = str(entry.get("label") or "").strip()
        if not label:
            continue
        try:
            prob = float(entry.get("probability") or 0.0)
        except (TypeError, ValueError):
            prob = 0.0
        if not math.isfinite(prob) or prob < 0.0:
            continue
        labels.append(label)
        probs.append(prob)

    tail_mass = distribution.get("tail_mass")
    if tail_mass is not None:
        try:
            tail = float(tail_mass)
        except (TypeError, ValueError):
            tail = 0.0
        if math.isfinite(tail) and tail > 0.0:
            trunc = distribution.get("truncation") if isinstance(distribution.get("truncation"), Mapping) else {}
            tail_label = str(trunc.get("tail_label") or "other").strip() or "other"
            labels.append(tail_label)
            probs.append(tail)

    total = sum(probs)
    if total <= 0.0:
        return [], []
    norm = 1.0 / total
    return labels, [p * norm for p in probs]


def _sample_multinomial(rng: Rng, n: int, probs: Sequence[float]) -> list[int]:
    if n <= 0 or not probs:
        return [0 for _ in probs]
    cum: list[float] = []
    acc = 0.0
    for p in probs:
        acc += float(p)
        cum.append(acc)
    if acc <= 0.0:
        return [0 for _ in probs]
    counts = [0 for _ in probs]
    for _ in range(n):
        r = rng.random() * acc
        idx = 0
        while idx < len(cum) and r > cum[idx]:
            idx += 1
        if idx >= len(counts):
            idx = len(counts) - 1
        counts[idx] += 1
    return counts


def _expected_belief_entropy_after_assay(
    *,
    probs: Sequence[float],
    effective_reads: int,
    prior_strength: float,
    trials: int,
    seed: int,
) -> float:
    rng = Rng(int(seed), stream_id="experiment_planner:entropy_proxy_v0")
    if not probs or effective_reads <= 0 or trials <= 0:
        return 0.0
    strength = max(1e-6, float(prior_strength))
    min_alpha = 1e-3
    alpha = [max(float(p) * strength, min_alpha) for p in probs]
    if sum(alpha) <= 0.0:
        return 0.0
    ent_sum = 0.0
    for _ in range(trials):
        gammas = [rng.gammavariate(float(a), 1.0) for a in alpha]
        total = sum(gammas) or 1.0
        p_true = [g / total for g in gammas]
        counts = _sample_multinomial(rng, effective_reads, p_true)
        alpha_post = [float(a) + float(c) for a, c in zip(alpha, counts)]
        ent_sum += float(_dirichlet_entropy_bits(alpha_post))
    return ent_sum / float(trials)


def recommend_next_experiment_probs(
    labels: Sequence[str],
    probs: Sequence[float],
    *,
    assays: Mapping[str, int] | None = None,
    prior_strength: float = 10.0,
    trials: int = 64,
    seed: int = 0,
) -> ExperimentRecommendation:
    if not labels or not probs:
        return ExperimentRecommendation(
            status="not_computed",
            reason="missing_outcome_distribution",
            objective="entropy_reduction",
            candidates=(),
            notes="No outcome distribution available; cannot plan next data collection.",
        )

    min_prob = 1e-6
    safe_probs = [max(float(p), min_prob) for p in probs]
    total_prob = sum(safe_probs) or 1.0
    safe_probs = [p / total_prob for p in safe_probs]

    belief_alpha = [max(float(p) * max(float(prior_strength), 1e-6), 1e-3) for p in safe_probs]
    prior_belief_entropy = float(_dirichlet_entropy_bits(belief_alpha))
    assay_reads = dict(assays or DEFAULT_ASSAY_READS)
    candidates: list[ExperimentCandidate] = []
    for assay, effective_reads in assay_reads.items():
        try:
            n_reads = int(effective_reads)
        except (TypeError, ValueError):
            continue
        if n_reads <= 0:
            continue
        expected_post_entropy = _expected_belief_entropy_after_assay(
            probs=safe_probs,
            effective_reads=n_reads,
            prior_strength=prior_strength,
            trials=trials,
            seed=seed,
        )
        ig_bits = max(0.0, prior_belief_entropy - expected_post_entropy)
        candidates.append(
            ExperimentCandidate(
                kind="measure_outcome_histogram",
                assay=str(assay),
                effective_reads=n_reads,
                expected_information_gain_bits=float(ig_bits),
                notes="proxy: expected Dirichlet belief entropy reduction under finite-sample observation",
            )
        )

    candidates.sort(key=lambda c: (-float(c.expected_information_gain_bits), c.assay))
    best = candidates[0] if candidates else None
    return ExperimentRecommendation(
        status="computed" if best is not None else "not_computed",
        reason="entropy_reduction_proxy",
        objective="entropy_reduction",
        prior_entropy_bits=prior_belief_entropy,
        best=best,
        candidates=tuple(candidates),
        notes=(
            "Heuristic planner: models each assay as a finite-sample observation and scores candidates by expected "
            "reduction in Dirichlet belief entropy (bits) over outcome probabilities. Not calibrated; intended for "
            "in-silico triage only."
        ),
    )


def recommend_next_experiment(
    posterior: Posterior,
    *,
    assays: Mapping[str, int] | None = None,
    prior_strength: float = 10.0,
    trials: int = 64,
    seed: int = 0,
) -> ExperimentRecommendation:
    labels = [entry.label for entry in posterior.distribution.outcomes]
    probs = [float(entry.probability) for entry in posterior.distribution.outcomes]
    if posterior.distribution.truncation is not None and posterior.distribution.tail_mass > 0.0:
        labels.append(posterior.distribution.truncation.tail_label)
        probs.append(float(posterior.distribution.tail_mass))
    rec = recommend_next_experiment_probs(
        labels,
        probs,
        assays=assays,
        prior_strength=prior_strength,
        trials=trials,
        seed=seed,
    )
    target = _extract_target_metadata(posterior.to_dict())
    if target:
        return ExperimentRecommendation(
            status=rec.status,
            reason=rec.reason,
            objective=rec.objective,
            prior_entropy_bits=rec.prior_entropy_bits,
            best=rec.best,
            candidates=rec.candidates,
            target=target,
            notes=rec.notes,
        )
    return rec


def recommend_next_experiment_from_payload(
    posterior_payload: Mapping[str, Any],
    *,
    assays: Mapping[str, int] | None = None,
    prior_strength: float = 10.0,
    trials: int = 64,
    seed: int = 0,
) -> ExperimentRecommendation:
    distribution = (
        posterior_payload.get("distribution") if isinstance(posterior_payload.get("distribution"), Mapping) else {}
    )
    labels, probs = _extract_labels_probs_from_distribution_payload(distribution)
    rec = recommend_next_experiment_probs(
        labels,
        probs,
        assays=assays,
        prior_strength=prior_strength,
        trials=trials,
        seed=seed,
    )
    target = _extract_target_metadata(posterior_payload)
    if target:
        return ExperimentRecommendation(
            status=rec.status,
            reason=rec.reason,
            objective=rec.objective,
            prior_entropy_bits=rec.prior_entropy_bits,
            best=rec.best,
            candidates=rec.candidates,
            target=target,
            notes=rec.notes,
        )
    return rec


def format_recommendation_short(rec: ExperimentRecommendation) -> str:
    if rec.status != "computed" or rec.best is None:
        return "Next data: not computed"
    best = rec.best
    gain = float(best.expected_information_gain_bits)
    return f"Next data: {best.kind} via {best.assay} (expected IG≈{gain:.2f} bits, proxy)"


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def _sha256_prefixed(payload: Mapping[str, Any]) -> str:
    return f"sha256:{hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()}"


def _posterior_summary_for_hash(posterior_payload: Mapping[str, Any]) -> dict[str, Any]:
    distribution = (
        posterior_payload.get("distribution") if isinstance(posterior_payload.get("distribution"), Mapping) else {}
    )
    outcomes_raw = distribution.get("outcomes")
    outcomes: list[dict[str, Any]] = []
    if isinstance(outcomes_raw, Sequence) and not isinstance(outcomes_raw, (str, bytes, bytearray)):
        for entry in outcomes_raw:
            if not isinstance(entry, Mapping):
                continue
            label = str(entry.get("label") or "").strip()
            if not label:
                continue
            try:
                prob = float(entry.get("probability") or 0.0)
            except (TypeError, ValueError):
                prob = 0.0
            if not math.isfinite(prob) or prob < 0.0:
                continue
            outcomes.append({"label": label, "probability": prob})
    outcomes.sort(key=lambda e: e["label"])

    trunc = distribution.get("truncation") if isinstance(distribution.get("truncation"), Mapping) else {}
    tail_label = str(trunc.get("tail_label") or "other").strip() or "other"
    try:
        tail_mass = float(distribution.get("tail_mass") or 0.0)
    except (TypeError, ValueError):
        tail_mass = 0.0
    tail_mass = max(0.0, tail_mass) if math.isfinite(tail_mass) else 0.0

    calibration = posterior_payload.get("calibration") if isinstance(posterior_payload.get("calibration"), Mapping) else {}
    cal_status = str(calibration.get("status") or "").strip()
    context = posterior_payload.get("context") if isinstance(posterior_payload.get("context"), Mapping) else {}
    context_keys = sorted([str(k) for k, v in context.items() if v not in (None, "", [], {})])

    return {
        "schema": str(posterior_payload.get("schema") or ""),
        "distribution": {"outcomes": outcomes, "tail_mass": tail_mass, "tail_label": tail_label},
        "calibration_status": cal_status,
        "context_present_keys": context_keys,
    }


def build_planner_trace(
    *,
    posterior_payload: Mapping[str, Any],
    recommendation: ExperimentRecommendation,
    assay_candidates: Mapping[str, int],
    prior_strength: float,
    trials: int,
    seed: int,
) -> dict[str, Any]:
    posterior_summary = _posterior_summary_for_hash(posterior_payload)
    posterior_hash = _sha256_prefixed(posterior_summary)

    assays_sorted = sorted((str(k), int(v)) for k, v in assay_candidates.items())
    candidates_hash = _sha256_prefixed({"assays": assays_sorted})

    inputs_hash = _sha256_prefixed(
        {
            "planner_version": PLANNER_VERSION,
            "posterior_hash": posterior_hash,
            "candidates_hash": candidates_hash,
            "prior_strength": float(prior_strength),
            "trials": int(trials),
            "seed": int(seed),
        }
    )

    ranked_candidates = [
        {
            "assay": cand.assay,
            "kind": cand.kind,
            "effective_reads": int(cand.effective_reads),
            "expected_information_gain_bits": float(cand.expected_information_gain_bits),
        }
        for cand in recommendation.candidates
    ]
    trace: dict[str, Any] = {
        "planner_version": PLANNER_VERSION,
        "status": recommendation.status,
        "objective": recommendation.objective,
        "reason": "entropy_proxy",
        "recommendation_reason": recommendation.reason,
        "note": PLANNER_NOTE,
        "inputs_hash": inputs_hash,
        "posterior_hash": posterior_hash,
        "candidates_hash": candidates_hash,
        "prior_entropy_bits": float(recommendation.prior_entropy_bits or 0.0),
        "ranked_candidates": ranked_candidates,
    }
    if recommendation.best is not None:
        trace["top_choice"] = recommendation.best.to_dict()
    if recommendation.target is not None:
        trace["target"] = dict(recommendation.target)
    return trace


def build_planner_trace_not_computed(
    *,
    posterior_payload: Mapping[str, Any],
    assay_candidates: Mapping[str, int],
    prior_strength: float,
    trials: int,
    seed: int,
    error: str,
) -> dict[str, Any]:
    posterior_summary = _posterior_summary_for_hash(posterior_payload)
    posterior_hash = _sha256_prefixed(posterior_summary)

    assays_sorted = sorted((str(k), int(v)) for k, v in assay_candidates.items())
    candidates_hash = _sha256_prefixed({"assays": assays_sorted})

    inputs_hash = _sha256_prefixed(
        {
            "planner_version": PLANNER_VERSION,
            "posterior_hash": posterior_hash,
            "candidates_hash": candidates_hash,
            "prior_strength": float(prior_strength),
            "trials": int(trials),
            "seed": int(seed),
        }
    )

    return {
        "planner_version": PLANNER_VERSION,
        "status": "not_computed",
        "objective": "entropy_reduction",
        "reason": "entropy_proxy",
        "recommendation_reason": "planner_failed",
        "note": PLANNER_NOTE,
        "inputs_hash": inputs_hash,
        "posterior_hash": posterior_hash,
        "candidates_hash": candidates_hash,
        "ranked_candidates": [],
        "error": str(error),
    }


__all__ = [
    "ExperimentCandidate",
    "ExperimentRecommendation",
    "DEFAULT_ASSAY_READS",
    "PLANNER_VERSION",
    "PLANNER_NOTE",
    "recommend_next_experiment_probs",
    "recommend_next_experiment",
    "recommend_next_experiment_from_payload",
    "format_recommendation_short",
    "build_planner_trace",
    "build_planner_trace_not_computed",
]
