from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping, Sequence


STRUCTURAL_RISK_SCHEMA = "helix_structural_risk_v1"

STRUCTURAL_MODE_VALUES = {"none", "local_screening", "genome_screening", "full"}
STRUCTURAL_SCOPE_VALUES = {"none", "local", "window_only", "genome_wide"}


def _clamp01(value: float) -> float:
    try:
        v = float(value)
    except Exception:
        return 0.0
    if not math.isfinite(v):
        return 0.0
    return 0.0 if v < 0.0 else (1.0 if v > 1.0 else v)


def _safe_int(value: Any, *, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _safe_str(value: Any) -> str:
    return str(value or "").strip()


def _strand_token(value: Any) -> str:
    tok = _safe_str(value)
    if tok in {"+", "-"}:
        return tok
    if tok.lower() in {"plus", "forward", "fwd"}:
        return "+"
    if tok.lower() in {"minus", "reverse", "rev"}:
        return "-"
    return "+"


def _site_key(site: "BreakSite") -> tuple:
    # Stable ordering for determinism: highest p first, then locus, then tags.
    return (
        -float(site.cleavage_probability_proxy),
        str(site.chrom),
        int(site.pos),
        str(site.strand),
        str(site.source),
        tuple(site.tags),
    )


@dataclass(frozen=True)
class BreakSite:
    chrom: str
    pos: int
    strand: str
    cleavage_probability_proxy: float
    mismatch_profile: Mapping[str, Any] = field(default_factory=dict)
    tags: tuple[str, ...] = ()
    source: str = "unknown"

    def normalized(self) -> "BreakSite":
        return BreakSite(
            chrom=_safe_str(self.chrom) or "unknown",
            pos=_safe_int(self.pos, default=0),
            strand=_strand_token(self.strand),
            cleavage_probability_proxy=_clamp01(float(self.cleavage_probability_proxy)),
            mismatch_profile=dict(self.mismatch_profile or {}),
            tags=tuple(str(t) for t in self.tags if str(t)),
            source=_safe_str(self.source) or "unknown",
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "chrom": str(self.chrom),
            "pos": int(self.pos),
            "strand": str(self.strand),
            "cleavageProbabilityProxy": float(self.cleavage_probability_proxy),
            "mismatchProfile": dict(self.mismatch_profile or {}),
            "tags": list(self.tags),
            "source": str(self.source),
        }


@dataclass(frozen=True)
class LengthBin:
    start_bp: int
    end_bp: int | None
    probability: float

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "start_bp": int(self.start_bp),
            "end_bp": int(self.end_bp) if self.end_bp is not None else None,
            "probability": float(self.probability),
        }
        return payload


@dataclass(frozen=True)
class BreakPair:
    a: int
    b: int
    probability: float
    joint_cleavage_proxy: float
    joinability: float
    distance_bp: int | None
    chrom_pair: tuple[str, str]

    def to_dict(self, sites: Sequence[BreakSite]) -> dict[str, Any]:
        a_site = sites[self.a]
        b_site = sites[self.b]
        payload: dict[str, Any] = {
            "a": {"chrom": a_site.chrom, "pos": int(a_site.pos), "strand": a_site.strand},
            "b": {"chrom": b_site.chrom, "pos": int(b_site.pos), "strand": b_site.strand},
            "probability": float(self.probability),
            "jointCleavageProxy": float(self.joint_cleavage_proxy),
            "joinability": float(self.joinability),
            "distance_bp": int(self.distance_bp) if self.distance_bp is not None else None,
            "chrom_pair": [self.chrom_pair[0], self.chrom_pair[1]],
        }
        return payload


@dataclass(frozen=True)
class StructuralRiskConfig:
    max_break_sites: int = 200
    same_chrom_window_bp: int = 2_000_000
    distance_scale_bp: float = 100_000.0
    cross_chrom_join_bias: float = 0.02
    inversion_fraction: float = 0.25
    single_large_deletion_rate: float = 0.02
    large_deletion_min_bp: int = 50
    large_deletion_bin_edges_bp: tuple[int, ...] = (
        50,
        100,
        200,
        500,
        1_000,
        2_000,
        5_000,
        10_000,
        20_000,
        50_000,
        100_000,
        200_000,
        500_000,
        1_000_000,
    )
    large_deletion_tail_alpha: float = 1.6
    top_pairs: int = 25
    complex_poisson_weight: float = 1.0
    truncation_complex_weight: float = 0.5

    def to_dict(self) -> dict[str, Any]:
        return {
            "max_break_sites": int(self.max_break_sites),
            "same_chrom_window_bp": int(self.same_chrom_window_bp),
            "distance_scale_bp": float(self.distance_scale_bp),
            "cross_chrom_join_bias": float(self.cross_chrom_join_bias),
            "inversion_fraction": float(self.inversion_fraction),
            "single_large_deletion_rate": float(self.single_large_deletion_rate),
            "large_deletion_min_bp": int(self.large_deletion_min_bp),
            "large_deletion_bin_edges_bp": list(int(x) for x in self.large_deletion_bin_edges_bp),
            "large_deletion_tail_alpha": float(self.large_deletion_tail_alpha),
            "top_pairs": int(self.top_pairs),
            "complex_poisson_weight": float(self.complex_poisson_weight),
            "truncation_complex_weight": float(self.truncation_complex_weight),
        }


@dataclass(frozen=True)
class StructuralRiskResult:
    schema: str
    status: str
    mode: str
    executed_mode: str
    scope: str
    limitations: str
    reason: str | None
    params: dict[str, Any]
    break_sites: tuple[BreakSite, ...]
    event_distribution: dict[str, float]
    large_deletion_length_bins: tuple[LengthBin, ...]
    top_inversion_pairs: tuple[BreakPair, ...]
    top_translocation_pairs: tuple[BreakPair, ...]
    chrom_pair_masses: tuple[dict[str, Any], ...]
    metrics: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": str(self.schema),
            "status": str(self.status),
            "mode": str(self.mode),
            "executed_mode": str(self.executed_mode),
            "scope": str(self.scope),
            "limitations": str(self.limitations),
            "reason": str(self.reason) if self.reason else None,
            "params": dict(self.params or {}),
            "break_sites": [s.to_dict() for s in self.break_sites],
            "event_distribution": dict(self.event_distribution or {}),
            "large_deletion_length_bins": [b.to_dict() for b in self.large_deletion_length_bins],
            "top_inversion_pairs": [p.to_dict(self.break_sites) for p in self.top_inversion_pairs],
            "top_translocation_pairs": [p.to_dict(self.break_sites) for p in self.top_translocation_pairs],
            "chrom_pair_masses": [dict(x) for x in self.chrom_pair_masses],
            "metrics": dict(self.metrics or {}),
        }


def _poisson_p_ge3(lam: float) -> float:
    lam = float(lam)
    if not math.isfinite(lam) or lam <= 0.0:
        return 0.0
    # P(X>=3) = 1 - e^-λ (1 + λ + λ^2/2).
    try:
        return _clamp01(1.0 - math.exp(-lam) * (1.0 + lam + (lam * lam) * 0.5))
    except Exception:
        return 0.0


def _exp_joinability(distance_bp: int, *, scale_bp: float) -> float:
    if distance_bp < 0:
        distance_bp = -distance_bp
    scale = float(scale_bp)
    if not math.isfinite(scale) or scale <= 0.0:
        return 0.0
    try:
        return float(math.exp(-float(distance_bp) / scale))
    except Exception:
        return 0.0


def _heavy_tail_bin_mass(a: float, b: float, *, alpha: float) -> float:
    # Unnormalized mass for p(L) ∝ L^-alpha on [a,b].
    a = float(a)
    b = float(b)
    alpha = float(alpha)
    if not (math.isfinite(a) and math.isfinite(b) and math.isfinite(alpha)):
        return 0.0
    if a <= 0.0 or b <= 0.0 or b <= a:
        return 0.0
    if alpha == 1.0:
        return max(0.0, math.log(b) - math.log(a))
    k = 1.0 - alpha
    return max(0.0, (b**k - a**k) / k)


def _bin_index(value: int, edges: Sequence[int]) -> int | None:
    if value <= 0:
        return None
    for idx, edge in enumerate(edges):
        if value <= int(edge):
            return idx
    return None


def _compute_single_large_deletion_bins(
    *,
    total_weight: float,
    edges: Sequence[int],
    alpha: float,
    min_bp: int,
) -> dict[int, float]:
    if total_weight <= 0.0:
        return {}
    edges_sorted = [int(x) for x in edges if int(x) > 0]
    edges_sorted.sort()
    if not edges_sorted:
        return {}
    min_bp_int = max(1, int(min_bp))
    # Convert edges into bins [start, end]
    bins: list[tuple[int, int]] = []
    prev = min_bp_int
    for edge in edges_sorted:
        if edge < prev:
            continue
        bins.append((prev, edge))
        prev = edge + 1

    masses: dict[int, float] = {}
    for idx, (a, b) in enumerate(bins):
        mass = _heavy_tail_bin_mass(float(a), float(b) + 1.0, alpha=float(alpha))
        if mass <= 0.0:
            continue
        masses[idx] = float(mass)

    tot = sum(masses.values())
    if tot <= 0.0:
        return {}
    scale = float(total_weight) / float(tot)
    return {idx: float(m) * scale for idx, m in masses.items()}


def compute_structural_risk(
    break_sites: Sequence[BreakSite],
    *,
    mode: str = "local_screening",
    config: StructuralRiskConfig | None = None,
) -> StructuralRiskResult:
    cfg = config or StructuralRiskConfig()

    requested_mode = str(mode or "local_screening").strip().lower()
    if requested_mode == "local":
        requested_mode = "local_screening"
    if requested_mode == "genome":
        requested_mode = "genome_screening"
    if requested_mode not in STRUCTURAL_MODE_VALUES:
        requested_mode = "local_screening"

    if requested_mode == "none":
        return StructuralRiskResult(
            schema=STRUCTURAL_RISK_SCHEMA,
            status="not_computed",
            mode="none",
            executed_mode="none",
            scope="none",
            limitations="Structural risk computation disabled by mode.",
            reason="mode=none",
            params=cfg.to_dict(),
            break_sites=tuple(),
            event_distribution={"no_rearrangement": 1.0, "large_deletion": 0.0, "inversion": 0.0, "translocation": 0.0, "complex_rearrangement": 0.0},
            large_deletion_length_bins=tuple(),
            top_inversion_pairs=tuple(),
            top_translocation_pairs=tuple(),
            chrom_pair_masses=tuple(),
            metrics={"n_break_sites_input": int(len(break_sites))},
        )

    sites_norm = [s.normalized() for s in break_sites if isinstance(s, BreakSite)]
    sites_norm.sort(key=_site_key)

    n_input = len(sites_norm)
    max_sites = max(0, int(cfg.max_break_sites))
    truncated = False
    dropped_p = 0.0
    if max_sites and len(sites_norm) > max_sites:
        keep = sites_norm[:max_sites]
        drop = sites_norm[max_sites:]
        dropped_p = sum(float(s.cleavage_probability_proxy) for s in drop)
        sites_norm = keep
        truncated = True

    lam = sum(float(s.cleavage_probability_proxy) for s in sites_norm)
    p_ge3 = _poisson_p_ge3(lam)

    # Scope is derived from tags/sources; callers can override by tagging sites.
    scope = "local"
    if any("genome_wide" in s.tags for s in sites_norm):
        scope = "genome_wide"
    elif any("window_only" in s.tags for s in sites_norm):
        scope = "window_only"

    # Determine executed mode: "full" is not implemented beyond "genome_screening" today.
    executed_mode = requested_mode
    if requested_mode == "full":
        executed_mode = "genome_screening"

    # Event weights (proxy). Normalize into a mixture distribution.
    w_no = 1.0
    w_large = 0.0
    w_inv = 0.0
    w_trans = 0.0
    w_complex = 0.0

    on_target_sites = [s for s in sites_norm if "on_target" in s.tags or s.source == "on_target"]
    if on_target_sites:
        w_large += sum(float(s.cleavage_probability_proxy) for s in on_target_sites) * float(cfg.single_large_deletion_rate)

    # Large deletion bins combine:
    #  - Single-cut heavy-tail prior (scaled by w_large_single),
    #  - Span deletions from same-chrom cut pairs (added later).
    edges = tuple(int(x) for x in cfg.large_deletion_bin_edges_bp if int(x) > 0)
    single_bins: dict[int, float] = _compute_single_large_deletion_bins(
        total_weight=float(w_large),
        edges=edges,
        alpha=float(cfg.large_deletion_tail_alpha),
        min_bp=int(cfg.large_deletion_min_bp),
    )

    span_bin_weights: dict[int, float] = {}
    top_inversions: list[tuple[float, BreakPair]] = []
    top_trans: list[tuple[float, BreakPair]] = []
    chrom_pair_weights: dict[tuple[str, str], float] = {}

    if executed_mode in {"genome_screening"}:
        same_win = max(0, int(cfg.same_chrom_window_bp))
        inv_frac = _clamp01(float(cfg.inversion_fraction))
        cross_bias = max(0.0, float(cfg.cross_chrom_join_bias))
        d_scale = float(cfg.distance_scale_bp)
        for i in range(len(sites_norm)):
            a = sites_norm[i]
            p_a = float(a.cleavage_probability_proxy)
            if p_a <= 0.0:
                continue
            for j in range(i + 1, len(sites_norm)):
                b = sites_norm[j]
                p_b = float(b.cleavage_probability_proxy)
                if p_b <= 0.0:
                    continue
                joint = p_a * p_b
                if a.chrom == b.chrom:
                    dist = abs(int(a.pos) - int(b.pos))
                    if same_win and dist > same_win:
                        continue
                    join = _exp_joinability(dist, scale_bp=d_scale)
                    if join <= 0.0:
                        continue
                    w = joint * join
                    if w <= 0.0:
                        continue
                    inv_w = w * inv_frac
                    del_w = w * (1.0 - inv_frac)
                    w_inv += inv_w
                    w_large += del_w
                    if dist >= int(cfg.large_deletion_min_bp):
                        idx = _bin_index(dist, edges)
                        if idx is not None:
                            span_bin_weights[idx] = span_bin_weights.get(idx, 0.0) + del_w

                    chrom_pair = (str(a.chrom), str(b.chrom))
                    pair = BreakPair(
                        a=i,
                        b=j,
                        probability=0.0,
                        joint_cleavage_proxy=float(joint),
                        joinability=float(join),
                        distance_bp=int(dist),
                        chrom_pair=chrom_pair,
                    )
                    top_inversions.append((inv_w, pair))
                else:
                    if cross_bias <= 0.0:
                        continue
                    join = float(cross_bias)
                    w = joint * join
                    if w <= 0.0:
                        continue
                    w_trans += w
                    chrom_pair = tuple(sorted((str(a.chrom), str(b.chrom))))
                    chrom_pair_weights[chrom_pair] = chrom_pair_weights.get(chrom_pair, 0.0) + w
                    pair = BreakPair(
                        a=i,
                        b=j,
                        probability=0.0,
                        joint_cleavage_proxy=float(joint),
                        joinability=float(join),
                        distance_bp=None,
                        chrom_pair=chrom_pair,
                    )
                    top_trans.append((w, pair))

        # Deterministic top pairs: stable tie-break on indices.
        top_inversions.sort(key=lambda t: (-float(t[0]), int(t[1].a), int(t[1].b)))
        top_trans.sort(key=lambda t: (-float(t[0]), int(t[1].a), int(t[1].b)))
        top_inversions = top_inversions[: max(0, int(cfg.top_pairs))]
        top_trans = top_trans[: max(0, int(cfg.top_pairs))]

    # Complex event proxy: based on ≥3 breaks, plus truncation tail.
    w_complex = float(p_ge3) * float(cfg.complex_poisson_weight)
    if truncated and dropped_p > 0.0:
        w_complex += float(dropped_p) * float(cfg.truncation_complex_weight)

    total_w = float(w_no + w_large + w_inv + w_trans + w_complex)
    if total_w <= 0.0:
        total_w = 1.0

    event_distribution = {
        "no_rearrangement": float(w_no / total_w),
        "large_deletion": float(w_large / total_w),
        "inversion": float(w_inv / total_w),
        "translocation": float(w_trans / total_w),
        "complex_rearrangement": float(w_complex / total_w),
    }

    # Normalize top-pair probabilities relative to their event mass for auditability.
    inv_mass = float(w_inv / total_w)
    trans_mass = float(w_trans / total_w)

    inv_pairs: list[BreakPair] = []
    if top_inversions and w_inv > 0.0:
        for w, pair in top_inversions:
            inv_pairs.append(
                BreakPair(
                    a=pair.a,
                    b=pair.b,
                    probability=float(inv_mass) * float(w / w_inv),
                    joint_cleavage_proxy=pair.joint_cleavage_proxy,
                    joinability=pair.joinability,
                    distance_bp=pair.distance_bp,
                    chrom_pair=pair.chrom_pair,
                )
            )

    trans_pairs: list[BreakPair] = []
    if top_trans and w_trans > 0.0:
        for w, pair in top_trans:
            trans_pairs.append(
                BreakPair(
                    a=pair.a,
                    b=pair.b,
                    probability=float(trans_mass) * float(w / w_trans),
                    joint_cleavage_proxy=pair.joint_cleavage_proxy,
                    joinability=pair.joinability,
                    distance_bp=pair.distance_bp,
                    chrom_pair=pair.chrom_pair,
                )
            )

    chrom_pair_items = [
        {"chrom_a": a, "chrom_b": b, "mass": float((w / total_w))}
        for (a, b), w in chrom_pair_weights.items()
    ]
    chrom_pair_items.sort(key=lambda x: (-float(x["mass"]), str(x["chrom_a"]), str(x["chrom_b"])))
    chrom_pair_items = chrom_pair_items[: max(0, int(cfg.top_pairs))]

    # Combine length bins from single-cut and span deletions, then normalize to sum to 1
    bin_weights: dict[int, float] = {}
    for idx, w in single_bins.items():
        bin_weights[int(idx)] = bin_weights.get(int(idx), 0.0) + float(w)
    for idx, w in span_bin_weights.items():
        bin_weights[int(idx)] = bin_weights.get(int(idx), 0.0) + float(w)

    total_bin_w = sum(bin_weights.values())
    length_bins: list[LengthBin] = []
    if total_bin_w > 0.0:
        for idx in sorted(bin_weights.keys()):
            end_bp = int(edges[idx]) if idx < len(edges) else None
            start_bp = int(cfg.large_deletion_min_bp) if idx == 0 else int(edges[idx - 1] + 1)
            length_bins.append(
                LengthBin(
                    start_bp=int(start_bp),
                    end_bp=int(end_bp) if end_bp is not None else None,
                    probability=float(bin_weights[idx] / total_bin_w),
                )
            )

    limitations_parts: list[str] = []
    if executed_mode == "local_screening":
        limitations_parts.append("Local screening: models large deletions around on-target cuts only.")
        limitations_parts.append("Inversions/translocations are excluded by mode.")
    else:
        limitations_parts.append("Genome screening: models pairwise end-joining between predicted break sites (proxy).")
    if requested_mode == "full":
        limitations_parts.append("Full mode not implemented; executed genome_screening proxy.")
    if truncated:
        limitations_parts.append(f"Break sites truncated to top {max_sites} by cleavageProbabilityProxy.")
    limitations_parts.append("Joinability uses an exponential distance decay; 3D contact and microhomology are not modeled.")
    limitations = " ".join(p for p in limitations_parts if p).strip() or "unconfigured"

    metrics: dict[str, Any] = {
        "n_break_sites_input": int(n_input),
        "n_break_sites_used": int(len(sites_norm)),
        "expected_breaks_proxy": float(lam),
        "p_ge_3_breaks_poisson_proxy": float(p_ge3),
        "dropped_breaks_proxy_mass": float(dropped_p),
    }

    return StructuralRiskResult(
        schema=STRUCTURAL_RISK_SCHEMA,
        status="computed",
        mode=requested_mode,
        executed_mode=executed_mode,
        scope=scope if scope in STRUCTURAL_SCOPE_VALUES else "local",
        limitations=limitations,
        reason=None,
        params=cfg.to_dict(),
        break_sites=tuple(sites_norm),
        event_distribution=event_distribution,
        large_deletion_length_bins=tuple(length_bins),
        top_inversion_pairs=tuple(inv_pairs),
        top_translocation_pairs=tuple(trans_pairs),
        chrom_pair_masses=tuple(chrom_pair_items),
        metrics=metrics,
    )
