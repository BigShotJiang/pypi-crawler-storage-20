"""CPU fallback stubs for helix_cuda_fields used in headless tests.

These provide minimal numpy implementations so GPU-dependent field modules
can import and produce deterministic outputs in CI when the native extension
is unavailable.
"""

from __future__ import annotations

import numpy as np


def _ensure_array(arr, dtype=float):
    a = np.asarray(arr, dtype=dtype)
    return a


def pam_seed_scores(seq_codes, guide_codes, pam_codes, mismatch_penalty=1.0, pam_bonus=3.0, score_scale=1.0):
    seq_codes = _ensure_array(seq_codes, np.uint8)
    guide_codes = _ensure_array(guide_codes, np.uint8)
    n = len(seq_codes)
    base = np.ones(n, dtype=np.float32) * score_scale
    return base


def dcas9_occupancy_scores(seq_codes, guide_codes, pam_codes, mismatch_penalty, pam_penalty, pam_bonus, score_scale):
    seq_codes = _ensure_array(seq_codes, np.uint8)
    return np.ones(len(seq_codes), dtype=np.float32) * score_scale


def indel_risk_scores(seq_codes, repeat_penalty, microhomology_bonus, max_window):
    seq_codes = _ensure_array(seq_codes, np.uint8)
    return np.zeros(len(seq_codes), dtype=np.float32)


def gc_homopolymer_scores(seq_codes, window, gc_weight=1.0, hp_weight=1.0, normalize=False):
    seq_codes = _ensure_array(seq_codes, np.uint8)
    n = len(seq_codes)
    if n == 0:
        return np.zeros(0, dtype=np.float32)

    win = max(int(window), 1)
    gc = ((seq_codes == 1) | (seq_codes == 2)).astype(np.float32)
    kernel = np.ones(win, dtype=np.float32) / float(win)
    gc_score = np.convolve(gc, kernel, mode="same")

    hp = np.zeros(n, dtype=np.float32)
    run_len = 1
    for i in range(1, n):
        if int(seq_codes[i]) == int(seq_codes[i - 1]):
            run_len += 1
        else:
            if run_len > 1:
                hp[i - run_len : i] = float(run_len)
            run_len = 1
    if run_len > 1:
        hp[n - run_len : n] = float(run_len)

    hp_score = hp / float(max(win, 1))
    scores = float(gc_weight) * gc_score + float(hp_weight) * hp_score
    scores = np.clip(scores, 0.0, None).astype(np.float32)
    if normalize and scores.size and scores.max() > 0:
        scores = scores / scores.max()
    return scores.astype(np.float32)


def offtarget_density_scores(seq_codes, guide_codes, pam_codes, mismatch_penalty=1.0, score_scale=1.0):
    seq_codes = _ensure_array(seq_codes, np.uint8)
    return np.ones(len(seq_codes), dtype=np.float32) * (score_scale * 0.5)


def prime_dp_scores(seq_codes, rt_codes, nick_local, mismatch_penalty=1.0, gap_penalty=1.0, extension_bonus=1.0, max_extension=10):
    seq_codes = _ensure_array(seq_codes, np.uint8)
    scores = np.zeros(len(seq_codes), dtype=np.float32)
    if 0 <= nick_local < len(scores):
        scores[nick_local] = extension_bonus
    return scores


def composite_editability_scores(pam, prime, indel, off, pam_w=1.0, prime_w=1.0, indel_w=1.0, off_w=1.0, normalize=False):
    pam = _ensure_array(pam, np.float32)
    prime = _ensure_array(prime, np.float32)
    indel = _ensure_array(indel, np.float32)
    off = _ensure_array(off, np.float32)
    n = max(len(pam), len(prime), len(indel), len(off))
    def pad(arr):
        out = np.zeros(n, dtype=np.float32)
        out[: min(n, len(arr))] = arr[: min(n, len(arr))]
        return out
    pam = pad(pam)
    prime = pad(prime)
    indel = pad(indel)
    off = pad(off)
    scores = pam_w * pam + prime_w * prime - indel_w * indel - off_w * off
    scores = np.clip(scores, 0.0, None)
    if normalize and scores.max() > 0:
        scores = scores / scores.max()
    return scores.astype(np.float32)
