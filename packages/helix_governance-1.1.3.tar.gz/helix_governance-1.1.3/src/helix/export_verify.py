from __future__ import annotations

import hashlib
import json
import re
import zlib
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from helix.studio.export_provenance import export_provenance_sha256, validate_export_provenance_v1
from helix.studio.governance_stamp import export_watermark_label, normalize_decision_mode
from helix.studio.cli_session_contract_stamp import CLI_SESSION_CONTRACT_HASH, CLI_SESSION_CONTRACT_ID
from helix.studio.png_provenance import PNG_PROVENANCE_SCHEMA_V1, png_provenance_sha256, validate_png_provenance_v1


@dataclass(frozen=True)
class ExportVerifyResult:
    ok: bool
    kind: str
    label: str | None
    mode_class: str | None
    decision_grade: bool | None
    is_demo: bool | None
    run_id: str | None
    provenance_sha256: str | None
    export_sha256: str | None
    errors: list[str]
    warnings: list[str]
    contract_id: str | None = None
    contract_hash: str | None = None

    def to_dict(self) -> dict[str, Any]:
        contract_present = bool(self.contract_id and self.contract_hash)
        return {
            "ok": bool(self.ok),
            "kind": self.kind,
            "label": self.label,
            "mode_class": self.mode_class,
            "decision_grade": self.decision_grade,
            "is_demo": self.is_demo,
            "run_id": self.run_id,
            "provenance_sha256": (f"sha256:{self.provenance_sha256}" if self.provenance_sha256 else None),
            "export_sha256": self.export_sha256,
            "contract_id": self.contract_id,
            "contract_hash": self.contract_hash,
            "contract_present": contract_present,
            "errors": list(self.errors),
            "warnings": list(self.warnings),
        }


_HTML_META_RE = re.compile(
    r"<meta[^>]*\bname=[\"']helix:export_provenance_sha256[\"'][^>]*\bcontent=[\"']sha256:(?P<sha>[0-9a-f]{64})[\"'][^>]*>",
    re.IGNORECASE,
)
_HTML_SCRIPT_RE = re.compile(
    r"<script[^>]*\bid=[\"']helix-export-provenance[\"'][^>]*>(?P<body>.*?)</script>",
    re.IGNORECASE | re.DOTALL,
)
_CLI_SESSION_CONTRACT_ID_RE = re.compile(r"^cli_session_contract_v(?P<version>[0-9]+)$")


def _sha256_prefixed(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="strict")


def _read_json(path: Path) -> Any:
    return json.loads(_read_text(path))


def _is_sha256_hex(value: object) -> bool:
    if not isinstance(value, str):
        return False
    token = value.strip()
    if not token:
        return False
    if token.startswith("sha256:"):
        token = token[len("sha256:") :]
    if len(token) != 64:
        return False
    return all(ch in "0123456789abcdef" for ch in token.lower())


def _cli_session_contract_version(contract_id: object) -> int | None:
    if not isinstance(contract_id, str):
        return None
    token = contract_id.strip()
    if not token:
        return None
    m = _CLI_SESSION_CONTRACT_ID_RE.match(token)
    if m is None:
        return None
    try:
        return int(m.group("version"))
    except Exception:
        return None


def _validate_cli_session_contract(
    *,
    contract_id: str | None,
    contract_hash: str | None,
    errors: list[str],
    warnings: list[str],
) -> None:
    if contract_id is None and contract_hash is None:
        return
    if contract_id is None or not str(contract_id).strip():
        warnings.append("contract_hash present without contract_id")
        return
    version = _cli_session_contract_version(contract_id)
    supported_version = _cli_session_contract_version(CLI_SESSION_CONTRACT_ID)
    if version is None:
        warnings.append(f"unknown cli session contract id: {contract_id!r}")
        return
    if supported_version is not None and version > supported_version:
        errors.append(
            f"unsupported cli session contract: {contract_id} (tool supports up to v{supported_version}). "
            f"Fix: upgrade Helix CLI or re-export with a v{supported_version} toolchain."
        )
        return
    if contract_hash is None or not str(contract_hash).strip():
        warnings.append(f"missing contract_hash for {contract_id}")
        return
    if not _is_sha256_hex(contract_hash):
        errors.append(f"invalid contract_hash (expected 64 hex): {contract_hash!r}")
        return
    if supported_version is not None and version == supported_version:
        expected = CLI_SESSION_CONTRACT_HASH
        if contract_hash.strip().lower().removeprefix("sha256:") != expected.lower():
            errors.append(
                "cli session contract hash mismatch: "
                f"artifact {contract_hash.strip()} expected {expected}"
            )


def _extract_html_export_provenance(html_text: str) -> tuple[dict[str, Any], str]:
    script_match = _HTML_SCRIPT_RE.search(html_text)
    if script_match is None:
        raise ValueError("missing <script id=\"helix-export-provenance\" …>")
    body = script_match.group("body").strip()
    payload = json.loads(body)
    if not isinstance(payload, dict):
        raise ValueError("export provenance payload must be a JSON object")

    meta_match = _HTML_META_RE.search(html_text)
    if meta_match is None:
        raise ValueError("missing <meta name=\"helix:export_provenance_sha256\" …>")
    sha_hex = meta_match.group("sha").lower()
    return payload, sha_hex


def _verify_html(path: Path) -> ExportVerifyResult:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        html_text = _read_text(path)
        payload, declared_sha = _extract_html_export_provenance(html_text)
        validate_export_provenance_v1(payload)
        computed_sha = export_provenance_sha256(payload)
        if computed_sha != declared_sha:
            errors.append(f"provenance sha256 mismatch: declared sha256:{declared_sha} computed sha256:{computed_sha}")
        label = str(payload.get("export_label") or "") or None
        mode_class = str(payload.get("mode_class") or "") or None
        decision_grade = bool(payload.get("decision_grade")) if "decision_grade" in payload else None
        is_demo = bool(payload.get("is_demo")) if "is_demo" in payload else None
        run = payload.get("run") if isinstance(payload.get("run"), Mapping) else {}
        run_id = str(run.get("run_id")) if run.get("run_id") is not None else None
        ok = not errors
        return ExportVerifyResult(
            ok=ok,
            kind="html",
            label=label,
            mode_class=mode_class,
            decision_grade=decision_grade,
            is_demo=is_demo,
            run_id=run_id,
            provenance_sha256=declared_sha,
            export_sha256=_sha256_prefixed(path.read_bytes()),
            errors=errors,
            warnings=warnings,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind="html",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def _load_sidecar(sidecar: Path) -> dict[str, Any]:
    payload = _read_json(sidecar)
    if not isinstance(payload, dict):
        raise ValueError("sidecar must be a JSON object")
    validate_export_provenance_v1(payload)
    return payload


def _sidecar_export_path(sidecar: Path, payload: Mapping[str, Any]) -> Path | None:
    export_obj = payload.get("export") if isinstance(payload.get("export"), Mapping) else None
    if not isinstance(export_obj, Mapping):
        return None
    rel = export_obj.get("path")
    if not isinstance(rel, str) or not rel.strip():
        return None
    return sidecar.parent / rel


def _verify_sidecar(sidecar: Path) -> ExportVerifyResult:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        payload = _load_sidecar(sidecar)
        computed_sha = export_provenance_sha256(payload)
        export_obj = payload.get("export") if isinstance(payload.get("export"), Mapping) else {}
        label = str(payload.get("export_label") or "") or None
        mode_class = str(payload.get("mode_class") or "") or None
        decision_grade = bool(payload.get("decision_grade")) if "decision_grade" in payload else None
        is_demo = bool(payload.get("is_demo")) if "is_demo" in payload else None
        run = payload.get("run") if isinstance(payload.get("run"), Mapping) else {}
        run_id = str(run.get("run_id")) if run.get("run_id") is not None else None

        export_path = _sidecar_export_path(sidecar, payload)
        export_sha = None
        declared_export_sha = export_obj.get("sha256") if isinstance(export_obj, Mapping) else None
        if export_path is not None and export_path.exists():
            export_sha = _sha256_prefixed(export_path.read_bytes())
            if isinstance(declared_export_sha, str) and declared_export_sha.strip():
                if declared_export_sha.strip() != export_sha:
                    errors.append(
                        f"export sha256 mismatch: sidecar {declared_export_sha.strip()} computed {export_sha}"
                    )
            else:
                errors.append("missing export.sha256 in sidecar (cannot verify export bytes)")
        else:
            warnings.append("export file not found next to sidecar; verified sidecar schema only")

        return ExportVerifyResult(
            ok=not errors,
            kind="sidecar",
            label=label,
            mode_class=mode_class,
            decision_grade=decision_grade,
            is_demo=is_demo,
            run_id=run_id,
            provenance_sha256=computed_sha,
            export_sha256=export_sha,
            errors=errors,
            warnings=warnings,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind="sidecar",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def _verify_csv(path: Path) -> ExportVerifyResult:
    sidecar = path.with_name(path.name + ".provenance.json")
    if not sidecar.exists():
        return ExportVerifyResult(
            ok=False,
            kind="csv",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=[f"missing provenance sidecar: {sidecar}"],
            warnings=[],
        )
    # Sidecar verification will also verify export.sha256 if present.
    result = _verify_sidecar(sidecar)
    return ExportVerifyResult(
        ok=result.ok,
        kind="csv",
        label=result.label,
        mode_class=result.mode_class,
        decision_grade=result.decision_grade,
        is_demo=result.is_demo,
        run_id=result.run_id,
        provenance_sha256=result.provenance_sha256,
        export_sha256=result.export_sha256,
        errors=result.errors,
        warnings=result.warnings,
    )


def _png_text_chunks(data: bytes) -> dict[str, str]:
    # Minimal PNG text chunk reader (tEXt/zTXt/iTXt). No image decoding required.
    if len(data) < 8 or data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG file")
    out: dict[str, str] = {}
    i = 8
    while i + 8 <= len(data):
        if i + 8 > len(data):
            break
        length = int.from_bytes(data[i : i + 4], "big", signed=False)
        ctype = data[i + 4 : i + 8]
        i += 8
        if i + length + 4 > len(data):
            break
        chunk = data[i : i + length]
        i += length + 4  # skip crc
        if ctype == b"tEXt":
            if b"\x00" not in chunk:
                continue
            key, val = chunk.split(b"\x00", 1)
            out[key.decode("latin1", errors="replace")] = val.decode("utf-8", errors="replace")
        elif ctype == b"zTXt":
            if b"\x00" not in chunk or len(chunk) < 2:
                continue
            key, rest = chunk.split(b"\x00", 1)
            if not rest:
                continue
            # rest[0] compression method (0 = deflate)
            comp = rest[1:]
            try:
                text = zlib.decompress(comp).decode("utf-8", errors="replace")
            except Exception:
                continue
            out[key.decode("latin1", errors="replace")] = text
        elif ctype == b"iTXt":
            # keyword\0 compression_flag\0 compression_method\0 language_tag\0 translated_keyword\0 text
            try:
                parts = chunk.split(b"\x00", 5)
                if len(parts) != 6:
                    continue
                key = parts[0].decode("latin1", errors="replace")
                comp_flag = parts[1][:1]
                comp_method = parts[2][:1]
                # parts[3], parts[4] are language/translated keyword; ignore
                text_bytes = parts[5]
                if comp_flag == b"\x01" and comp_method == b"\x00":
                    try:
                        text_bytes = zlib.decompress(text_bytes)
                    except Exception:
                        continue
                out[key] = text_bytes.decode("utf-8", errors="replace")
            except Exception:
                continue
        if ctype == b"IEND":
            break
    return out


def _verify_png(path: Path) -> ExportVerifyResult:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        sidecar = path.with_name(path.name + ".provenance.json")
        if sidecar.exists():
            return _verify_png_sidecar(sidecar, kind="png")

        raw = path.read_bytes()
        text = _png_text_chunks(raw)
        gov_raw = text.get("helix_governance")
        lim_raw = text.get("helix_limitations")
        if not gov_raw and not lim_raw:
            errors.append("not verifiable: missing provenance sidecar and missing Helix PNG text chunks")
            return ExportVerifyResult(
                ok=False,
                kind="png",
                label=None,
                mode_class=None,
                decision_grade=None,
                is_demo=None,
                run_id=None,
                provenance_sha256=None,
                export_sha256=_sha256_prefixed(raw),
                errors=errors,
                warnings=warnings,
            )
        errors.append("missing provenance sidecar (weakly verifiable: embedded PNG provenance present)")
        warnings.append("regenerate the export to produce <file>.png.provenance.json for audit-grade verification")
        if not gov_raw:
            errors.append("missing helix_governance PNG text chunk")
            return ExportVerifyResult(
                ok=False,
                kind="png",
                label=None,
                mode_class=None,
                decision_grade=None,
                is_demo=None,
                run_id=None,
                provenance_sha256=None,
                export_sha256=_sha256_prefixed(raw),
                errors=errors,
                warnings=warnings,
            )
        try:
            gov = json.loads(gov_raw)
        except Exception as exc:
            errors.append(f"invalid helix_governance JSON: {exc}")
            gov = None
        if not isinstance(gov, Mapping):
            errors.append("helix_governance must be a JSON object")
            gov = {}
        decision_mode = normalize_decision_mode(gov.get("decision_mode"))
        is_demo = bool(gov.get("is_demo", False))
        label = str(gov.get("watermark") or "") or None
        expected = export_watermark_label(decision_mode=decision_mode, is_demo=is_demo)
        if label and label != expected:
            errors.append(f"watermark mismatch: {label!r} vs expected {expected!r}")
        decision_grade = bool(decision_mode == "decision_grade")
        mode_class = "decision_grade" if decision_grade else ("demo" if is_demo else "exploratory")
        _ = lim_raw  # parsed below (best-effort)
        if lim_raw:
            try:
                lim = json.loads(lim_raw)
                if not isinstance(lim, Mapping):
                    warnings.append("helix_limitations is not a JSON object")
            except Exception:
                warnings.append("helix_limitations JSON parse failed")
        else:
            warnings.append("missing helix_limitations PNG text chunk")
        return ExportVerifyResult(
            ok=not errors,
            kind="png",
            label=label or expected,
            mode_class=mode_class,
            decision_grade=decision_grade,
            is_demo=is_demo,
            run_id=None,
            provenance_sha256=None,
            export_sha256=_sha256_prefixed(raw),
            errors=errors,
            warnings=warnings,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind="png",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def _verify_png_sidecar(sidecar: Path, *, kind: str = "png_sidecar") -> ExportVerifyResult:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        payload = _read_json(sidecar)
        if not isinstance(payload, Mapping):
            raise ValueError("png provenance sidecar must be a JSON object")
        validate_png_provenance_v1(payload)
        computed_sha = png_provenance_sha256(payload)
        contract_id = str(payload.get("contract_id") or "").strip() or None
        contract_hash = str(payload.get("contract_hash") or "").strip() or None
        _validate_cli_session_contract(
            contract_id=contract_id,
            contract_hash=contract_hash,
            errors=errors,
            warnings=warnings,
        )

        export_file = None
        raw = None
        expected_sha = str(payload.get("artifact_sha256") or "").strip()
        fname = str(payload.get("artifact_filename") or "").strip()
        if fname:
            export_file = sidecar.parent / fname
        if export_file is not None and export_file.exists():
            raw = export_file.read_bytes()
            export_sha = _sha256_prefixed(raw)
            if expected_sha and expected_sha != export_sha:
                errors.append(f"artifact sha256 mismatch: sidecar {expected_sha} computed {export_sha}")
        else:
            export_sha = None
            warnings.append("png file not found next to sidecar; verified sidecar schema only")

        gov_payload = payload.get("governance_payload") if isinstance(payload.get("governance_payload"), Mapping) else {}
        gov_block = payload.get("governance") if isinstance(payload.get("governance"), Mapping) else {}
        decision_mode = normalize_decision_mode(gov_block.get("governance_decision_mode") or gov_payload.get("decision_mode"))
        is_demo = bool(gov_payload.get("is_demo", False))
        export_class = str(gov_block.get("export_class") or "").strip().lower()
        if export_class == "demo":
            is_demo = True
        if export_class == "exploratory":
            is_demo = False

        label = str(gov_payload.get("watermark") or "").strip() or None
        expected_label = export_watermark_label(decision_mode=decision_mode, is_demo=is_demo)
        if label and label != expected_label:
            errors.append(f"watermark mismatch: {label!r} vs expected {expected_label!r}")

        decision_grade = bool(decision_mode == "decision_grade")
        mode_class = "decision_grade" if decision_grade else ("demo" if is_demo else "exploratory")

        run_id = str(payload.get("run_id") or "").strip() or None
        if not run_id:
            errors.append("missing run_id (required for audit-grade verification)")

        return ExportVerifyResult(
            ok=not errors,
            kind=kind,
            label=label or expected_label,
            mode_class=mode_class,
            decision_grade=decision_grade,
            is_demo=is_demo,
            run_id=run_id,
            provenance_sha256=computed_sha,
            export_sha256=export_sha,
            errors=errors,
            warnings=warnings,
            contract_id=contract_id,
            contract_hash=contract_hash,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind=kind,
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def _verify_export_json(path: Path) -> ExportVerifyResult:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        payload = _read_json(path)
        if not isinstance(payload, Mapping):
            raise ValueError("export JSON must be a JSON object")

        schema = payload.get("schema") if isinstance(payload.get("schema"), Mapping) else {}
        kind = schema.get("kind") if isinstance(schema, Mapping) else None
        version = schema.get("version") if isinstance(schema, Mapping) else None
        if kind != "helix.export.v1":
            raise ValueError("unsupported export JSON schema (expected schema.kind=helix.export.v1)")
        if version != 1 and str(version) != "1":
            raise ValueError("unsupported export JSON schema version (expected schema.version=1)")

        prov_block = payload.get("provenance_block") if isinstance(payload.get("provenance_block"), Mapping) else {}
        contract_id = str(prov_block.get("contract_id") or "").strip() or None
        contract_hash = str(prov_block.get("contract_hash") or "").strip() or None
        _validate_cli_session_contract(
            contract_id=contract_id,
            contract_hash=contract_hash,
            errors=errors,
            warnings=warnings,
        )

        decision_mode = str(payload.get("decision_mode") or "").strip() or None
        decision_grade = bool(decision_mode == "decision_grade") if decision_mode is not None else None
        mode_class = "decision_grade" if decision_grade else "exploratory"
        run = payload.get("run") if isinstance(payload.get("run"), Mapping) else {}
        run_id = str(run.get("run_id") or "").strip() or None

        return ExportVerifyResult(
            ok=not errors,
            kind="export_json",
            label=None,
            mode_class=mode_class,
            decision_grade=decision_grade,
            is_demo=None,
            run_id=run_id,
            provenance_sha256=None,
            export_sha256=_sha256_prefixed(path.read_bytes()),
            errors=errors,
            warnings=warnings,
            contract_id=contract_id,
            contract_hash=contract_hash,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind="export_json",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def _verify_evidence_json(path: Path) -> ExportVerifyResult:
    errors: list[str] = []
    warnings: list[str] = []
    try:
        payload = _read_json(path)
        if not isinstance(payload, Mapping):
            raise ValueError("evidence must be a JSON object")
        if str(payload.get("schema") or "") != "helix_run_evidence_v1":
            raise ValueError("unsupported JSON schema (expected helix_run_evidence_v1)")
        checksums = payload.get("checksums") if isinstance(payload.get("checksums"), Mapping) else {}
        declared = str(checksums.get("payload_sha256") or "").strip()
        if not declared:
            errors.append("missing checksums.payload_sha256")
        else:
            if declared.startswith("sha256:"):
                declared_hex = declared[len("sha256:") :]
            else:
                declared_hex = declared
            # Evidence uses canonical JSON (sorted keys, separators) excluding "checksums".
            obj = {k: v for k, v in payload.items() if k != "checksums"}
            c14n = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
            computed_hex = hashlib.sha256(c14n).hexdigest()
            if computed_hex != declared_hex:
                errors.append(f"payload_sha256 mismatch: declared sha256:{declared_hex} computed sha256:{computed_hex}")

        snap_a = checksums.get("snapshot_sha256")
        snap_b = payload.get("snapshot_sha256")
        if snap_a is not None and snap_b is not None and str(snap_a) != str(snap_b):
            errors.append("snapshot_sha256 mismatch between top-level and checksums")

        gov = payload.get("governance") if isinstance(payload.get("governance"), Mapping) else {}
        label = str(gov.get("watermark") or "") or None
        decision_mode = str(payload.get("decision_mode") or "") or None
        is_demo = bool(gov.get("is_demo", False)) if "is_demo" in gov else None
        run = payload.get("run") if isinstance(payload.get("run"), Mapping) else {}
        run_id = str(run.get("run_id")) if run.get("run_id") is not None else None

        return ExportVerifyResult(
            ok=not errors,
            kind="evidence_json",
            label=label,
            mode_class=None,
            decision_grade=bool(decision_mode == "decision_grade") if decision_mode is not None else None,
            is_demo=is_demo,
            run_id=run_id,
            provenance_sha256=None,
            export_sha256=_sha256_prefixed(path.read_bytes()),
            errors=errors,
            warnings=warnings,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind="evidence_json",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def _verify_clip_zip(path: Path) -> ExportVerifyResult:
    # Best-effort: verify governance/governance.json exists and includes a watermark label.
    errors: list[str] = []
    warnings: list[str] = []
    try:
        with zipfile.ZipFile(path) as zf:
            try:
                raw = zf.read("governance/governance.json")
            except Exception:
                raw = None
            if raw is None:
                raise ValueError("missing governance/governance.json")
            payload = json.loads(raw.decode("utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError("governance/governance.json must be a JSON object")
        decision_mode = normalize_decision_mode(payload.get("decision_mode"))
        is_demo = bool(payload.get("is_demo", False))
        label = str(payload.get("watermark") or "") or None
        expected = export_watermark_label(decision_mode=decision_mode, is_demo=is_demo)
        if not label:
            errors.append("missing watermark in governance/governance.json")
        elif label != expected:
            errors.append(f"watermark mismatch: {label!r} vs expected {expected!r}")
        decision_grade = bool(decision_mode == "decision_grade")
        mode_class = "decision_grade" if decision_grade else ("demo" if is_demo else "exploratory")
        return ExportVerifyResult(
            ok=not errors,
            kind="clip_zip",
            label=label or expected,
            mode_class=mode_class,
            decision_grade=decision_grade,
            is_demo=is_demo,
            run_id=None,
            provenance_sha256=None,
            export_sha256=_sha256_prefixed(path.read_bytes()),
            errors=errors,
            warnings=warnings,
        )
    except Exception as exc:
        errors.append(str(exc))
        return ExportVerifyResult(
            ok=False,
            kind="clip_zip",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=errors,
            warnings=warnings,
        )


def verify_export(path: str | Path) -> ExportVerifyResult:
    p = Path(path)
    if not p.exists():
        return ExportVerifyResult(
            ok=False,
            kind="unknown",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=[f"path not found: {p}"],
            warnings=[],
        )

    name = p.name.lower()
    if name.endswith(".html") or name.endswith(".htm"):
        return _verify_html(p)
    if name.endswith(".csv"):
        return _verify_csv(p)
    if name.endswith(".provenance.json"):
        try:
            payload = _read_json(p)
        except Exception:
            payload = None
        if isinstance(payload, Mapping) and str(payload.get("schema_version") or "") == PNG_PROVENANCE_SCHEMA_V1:
            return _verify_png_sidecar(p)
        return _verify_sidecar(p)
    if name.endswith(".png"):
        return _verify_png(p)
    if name.endswith(".zip"):
        return _verify_clip_zip(p)
    if name.endswith(".json"):
        try:
            payload = _read_json(p)
        except Exception:
            payload = None
        if isinstance(payload, Mapping) and str(payload.get("schema") or "") == "helix_run_evidence_v1":
            return _verify_evidence_json(p)
        schema = payload.get("schema") if isinstance(payload, Mapping) else None
        if isinstance(schema, Mapping) and str(schema.get("kind") or "") == "helix.export.v1":
            return _verify_export_json(p)
        if isinstance(payload, Mapping) and str(payload.get("schema") or "") == "helix_export_provenance_v1":
            return _verify_sidecar(p)
        if isinstance(payload, Mapping) and str(payload.get("schema_version") or "") == PNG_PROVENANCE_SCHEMA_V1:
            return _verify_png_sidecar(p)
        return ExportVerifyResult(
            ok=False,
            kind="json",
            label=None,
            mode_class=None,
            decision_grade=None,
            is_demo=None,
            run_id=None,
            provenance_sha256=None,
            export_sha256=None,
            errors=[
                "unsupported JSON payload (expected helix.export.v1, helix_export_provenance_v1, helix_png_provenance_v1, or helix_run_evidence_v1)"
            ],
            warnings=[],
        )

    return ExportVerifyResult(
        ok=False,
        kind="unknown",
        label=None,
        mode_class=None,
        decision_grade=None,
        is_demo=None,
        run_id=None,
        provenance_sha256=None,
        export_sha256=None,
        errors=[f"unsupported export type: {p.suffix}"],
        warnings=[],
    )


__all__ = ["ExportVerifyResult", "verify_export"]
