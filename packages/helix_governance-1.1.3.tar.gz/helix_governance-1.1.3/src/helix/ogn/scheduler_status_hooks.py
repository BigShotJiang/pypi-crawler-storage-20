from __future__ import annotations

import logging
from pathlib import Path
from typing import Callable, Any

from .ingest_status_client import IngestStatusClient, IngestStatusClientConfig, safe_set_status


logger = logging.getLogger(__name__)
_STATUS_CLIENT = IngestStatusClient(IngestStatusClientConfig.from_env())


def _set_status(run_id: str, state: str, message: str | None = None, job_id: str | None = None) -> None:
    safe_set_status(_STATUS_CLIENT, run_id, state, message=message, ogn_job_id=job_id, logger=logger)


def on_run_submitted(run_id: str, job_id: str) -> None:
    _set_status(run_id, "queued", job_id=job_id)


def on_job_started(job: Any) -> None:
    _set_status(job.run_id, "running", job_id=str(job.id))


def on_job_succeeded(job: Any) -> None:
    _set_status(job.run_id, "finished", job_id=str(job.id))


def on_job_failed(job: Any, exc: Exception) -> None:
    msg = f"{type(exc).__name__}: {exc}"
    _set_status(job.run_id, "failed", message=msg, job_id=str(job.id))


def submit_run(run_id: str, bundle_path: Path, scheduler) -> str:
    """Example helper to enqueue and emit initial status."""
    job = scheduler.enqueue(run_id=run_id, bundle_path=bundle_path)
    on_run_submitted(run_id, str(job.id))
    return str(job.id)


def attach_scheduler_callbacks(scheduler) -> None:
    """Register status callbacks on a scheduler that exposes on_started/on_succeeded/on_failed."""
    try:
        scheduler.on_started(on_job_started)
        scheduler.on_succeeded(on_job_succeeded)
        scheduler.on_failed(on_job_failed)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("Failed to attach ingest status hooks to scheduler: %s", exc)
