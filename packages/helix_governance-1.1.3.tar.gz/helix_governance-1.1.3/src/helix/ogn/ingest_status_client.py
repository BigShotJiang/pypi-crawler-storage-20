from __future__ import annotations

from dataclasses import dataclass
import os
import requests


@dataclass
class IngestStatusClientConfig:
    base_url: str
    token: str | None = None

    @classmethod
    def from_env(cls) -> "IngestStatusClientConfig":
        base = os.getenv("OGN_INGEST_STATUS_URL", "http://localhost:8001")
        token = os.getenv("OGN_INGEST_STATUS_TOKEN")
        return cls(base_url=base.rstrip("/"), token=token)


class IngestStatusClient:
    def __init__(self, cfg: IngestStatusClientConfig):
        self._cfg = cfg
        self._headers_cache: dict[str, str] = {}

    def _headers(self) -> dict[str, str]:
        if not self._cfg.token:
            return {}
        if not self._headers_cache:
            self._headers_cache = {"Authorization": f"Bearer {self._cfg.token}"}
        return self._headers_cache

    def set_status(self, run_id: str, state: str, message: str | None = None, ogn_job_id: str | None = None) -> None:
        payload: dict[str, object] = {"state": state}
        if message:
            payload["message"] = message
        if ogn_job_id:
            payload["ogn_job_id"] = ogn_job_id
        r = requests.post(
            f"{self._cfg.base_url}/runs/{run_id}/status",
            json=payload,
            headers=self._headers(),
            timeout=10,
        )
        r.raise_for_status()


def safe_set_status(client: IngestStatusClient, run_id: str, state: str, logger, **kwargs) -> None:
    try:
        client.set_status(run_id, state, **kwargs)
    except Exception as exc:  # pragma: no cover - logging only
        logger.warning("Failed to update ingest status for run %s to %s: %s", run_id, state, exc)
