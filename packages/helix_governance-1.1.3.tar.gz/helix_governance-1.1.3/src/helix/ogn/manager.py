from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .client import OGNJobSpec, OGNJobResult, MockOGNClient


@dataclass
class OgnJobHandle:
    job_id: str


class OgnManager:
    def __init__(self, client: MockOGNClient | Any) -> None:
        # Use MockOGNClient as default fake client; accept any client with the same API.
        self.client = client

    def submit(self, spec: OGNJobSpec) -> OgnJobHandle:
        job = self.client.submit_job(spec)
        return OgnJobHandle(job_id=job.job_id)

    def status(self, handle: OgnJobHandle) -> str:
        return self.client.job_status(handle.job_id)

    def fetch_results(self, handle: OgnJobHandle) -> Mapping[str, Any]:
        # For v0.5, return a snapshot-like dict.
        result: OGNJobResult = self.client.fetch_job(handle.job_id)
        return result.payload

    def run(self, spec: OGNJobSpec) -> Mapping[str, Any]:
        """Synchronous helper: submit, check status once, and fetch results.

        v0.5 assumes mock/stub clients that complete immediately. Later versions
        can poll/await here.
        """

        handle = self.submit(spec)
        status = self.status(handle)
        if isinstance(status, str):
            state = status
        else:
            # allow status objects with .state
            state = getattr(status, "state", str(status))
        if state != "completed":
            raise RuntimeError(f"OGN job not completed: {state}")
        return self.fetch_results(handle)


__all__ = ["OgnManager", "OgnJobHandle"]
