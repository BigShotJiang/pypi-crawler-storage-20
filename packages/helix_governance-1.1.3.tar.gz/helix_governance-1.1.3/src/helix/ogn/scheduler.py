from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Callable

from .scheduler_status_hooks import attach_scheduler_callbacks, submit_run as submit_run_with_status

logger = logging.getLogger(__name__)


class Job:
    def __init__(self, job_id: str, run_id: str):
        self.id = job_id
        self.run_id = run_id


class Scheduler:
    def __init__(self) -> None:
        self._on_started: list[Callable[[Job], None]] = []
        self._on_succeeded: list[Callable[[Job], None]] = []
        self._on_failed: list[Callable[[Job, Exception], None]] = []
        self._jobs: dict[str, Job] = {}

    def enqueue(self, *, run_id: str, bundle_path: Path) -> Job:
        job = Job(job_id=f"job-{len(self._jobs)+1}", run_id=run_id)
        self._jobs[job.id] = job
        return job

    # Callback registration
    def on_started(self, cb: Callable[[Job], None]) -> None:
        self._on_started.append(cb)

    def on_succeeded(self, cb: Callable[[Job], None]) -> None:
        self._on_succeeded.append(cb)

    def on_failed(self, cb: Callable[[Job, Exception], None]) -> None:
        self._on_failed.append(cb)

    # Simulated run
    def run_job(self, job: Job, succeed: bool = True) -> None:
        for cb in self._on_started:
            try:
                cb(job)
            except Exception:  # pragma: no cover - we don't want to crash
                logger.exception("job start callback failed")
        if succeed:
            for cb in self._on_succeeded:
                try:
                    cb(job)
                except Exception:
                    logger.exception("job success callback failed")
        else:
            exc = RuntimeError("mock failure")
            for cb in self._on_failed:
                try:
                    cb(job, exc)
                except Exception:
                    logger.exception("job failure callback failed")


# Bootstrap helper
scheduler = Scheduler()
attach_scheduler_callbacks(scheduler)


def submit_run(run_id: str, bundle_path: Path) -> Job:
    """Public entry that ensures status updates accompany job lifecycle."""

    job_id = submit_run_with_status(run_id, bundle_path, scheduler)
    return scheduler._jobs[job_id]
