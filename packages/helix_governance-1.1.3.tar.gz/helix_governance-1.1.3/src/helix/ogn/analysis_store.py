from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional


@dataclass
class AnalysisRecord:
    run_id: str
    analysis_id: str
    summary: dict[str, Any] | None = None
    summary_path: str | None = None
    status: str = "ready"

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "analysis_id": self.analysis_id,
            "summary_path": self.summary_path,
            "summary": self.summary,
            "status": self.status,
        }


class AnalysisStore:
    """Tiny filesystem-backed store mapping run_id -> analysis record."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, run_id: str) -> Path:
        return self.root / f"{run_id}.json"

    def save(self, record: AnalysisRecord) -> AnalysisRecord:
        path = self._path(record.run_id)
        path.write_text(json.dumps(record.to_dict(), indent=2))
        return record

    def save_summary(self, run_id: str, analysis_id: str, summary: dict[str, Any], *, status: str = "ready") -> AnalysisRecord:
        record = AnalysisRecord(run_id=run_id, analysis_id=analysis_id, summary=summary, status=status)
        return self.save(record)

    def get_by_run(self, run_id: str) -> Optional[AnalysisRecord]:
        path = self._path(run_id)
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return AnalysisRecord(
            run_id=data["run_id"],
            analysis_id=data["analysis_id"],
            summary=data.get("summary"),
            summary_path=data.get("summary_path"),
            status=data.get("status", "ready"),
        )
