from __future__ import annotations

import argparse
import json
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from .analysis_store import AnalysisStore


def handler_factory(store: AnalysisStore):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path.startswith("/analysis/by_run/"):
                run_id = parsed.path.split("/")[-1]
                record = store.get_by_run(run_id)
                if record is None:
                    self.send_error(HTTPStatus.NOT_FOUND, "analysis not found")
                    return
                body = json.dumps(record.to_dict()).encode("utf-8")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self.send_error(HTTPStatus.NOT_FOUND, "Unknown endpoint")

        def log_message(self, fmt: str, *args) -> None:  # pragma: no cover
            return

    return Handler


def run_server(host: str, port: int, store_root: Path) -> None:
    store = AnalysisStore(store_root)
    handler = handler_factory(store)
    with ThreadingHTTPServer((host, port), handler) as httpd:
        print(f"OGN analysis server listening on http://{host}:{port}")
        httpd.serve_forever()


def main() -> None:
    parser = argparse.ArgumentParser(description="Mock OGN analysis server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8090)
    parser.add_argument("--store", type=Path, default=Path("ogn_analysis_store"))
    args = parser.parse_args()
    run_server(args.host, args.port, args.store)


if __name__ == "__main__":
    main()
