from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from helix.studio.session_io import _ensure_contract_identity


def load_evs_for_run(project_root: Path, run_id: str) -> dict[str, Any] | None:
    """Load an EVS document for a run if present.

    Looks for files named `<run_id>.evs.json` or `<run_id>.v1.1.evs.json` under the
    project's snapshots/reports directories.
    """

    artifacts = project_root / "artifacts"
    snap_dir = artifacts / "snapshots"
    rep_dir = artifacts / "reports"
    candidates = [
        project_root / "snapshots" / f"{run_id}.evs.json",
        project_root / "snapshots" / f"{run_id}.v1.1.evs.json",
        project_root / "reports" / f"{run_id}.evs.json",
        project_root / "reports" / f"{run_id}.v1.1.evs.json",
        snap_dir / f"{run_id}.evs.json",
        snap_dir / f"{run_id}.v1.1.evs.json",
        rep_dir / f"{run_id}.evs.json",
        rep_dir / f"{run_id}.v1.1.evs.json",
    ]
    for path in candidates:
        if path.exists():
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(payload, dict):
                    payload = _ensure_contract_identity(payload)
                return payload
            except Exception:
                continue
    return None
