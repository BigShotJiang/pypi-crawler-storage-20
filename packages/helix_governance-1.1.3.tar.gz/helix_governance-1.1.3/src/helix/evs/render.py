from __future__ import annotations

from typing import Any, Dict

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication

from helix.studio.outcome_explorer import OutcomeExplorerWidget


def _ensure_qapp() -> QApplication:
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    return app


def render_evs(evs: Dict[str, Any], width: int = 800, height: int = 400) -> np.ndarray:
    """
    Render a single EVS document to an RGBA8 numpy array.

    width/height are logical; visualization.pixelRatio scales the physical buffer.
    """
    _ensure_qapp()

    vis = evs.get("visualization", {}) if isinstance(evs, dict) else {}
    pixel_ratio = float(vis.get("pixelRatio", 1.0) or 1.0)
    # Clamp to reasonable bounds so tests cannot explode framebuffer sizes
    pixel_ratio = max(0.5, min(4.0, pixel_ratio))
    phys_w = int(round(width * pixel_ratio))
    phys_h = int(round(height * pixel_ratio))
    phys_w = min(4000, max(50, phys_w))
    phys_h = min(3000, max(50, phys_h))

    widget = OutcomeExplorerWidget()
    widget.setAttribute(Qt.WA_DontShowOnScreen, True)
    widget.set_evs(evs)
    widget.resize(phys_w, phys_h)
    widget.repaint()
    app = QApplication.instance()
    if app is not None:
        app.processEvents()

    qimg = QImage(phys_w, phys_h, QImage.Format_RGBA8888)
    qimg.fill(Qt.transparent)
    widget.render(qimg)

    ptr = qimg.constBits()
    buffer = bytes(ptr)
    arr = np.frombuffer(buffer, dtype=np.uint8).reshape((qimg.height(), qimg.bytesPerLine() // 4, 4))
    # bytesPerLine may be padded; crop to actual width
    arr = arr[:, : qimg.width(), :].copy()

    widget.deleteLater()
    return arr
