from __future__ import annotations

from typing import Any

import numpy as np


def _pam_mask(sequence: str, pam: str, pam_offset: int) -> np.ndarray:
    seq = sequence.upper()
    pam = pam.upper()
    mask = np.zeros(len(seq), dtype=bool)
    for i in range(len(seq) - len(pam) + 1):
        window = seq[i : i + len(pam)]
        ok = True
        for a, b in zip(window, pam):
            if b == "N":
                continue
            if a != b:
                ok = False
                break
        if ok:
            pos = i - pam_offset if pam_offset >= 0 else i
            if 0 <= pos < len(mask):
                mask[pos] = True
    return mask


def compute_offtarget_heat_cpu(evs: dict[str, Any]) -> np.ndarray:
    """CPU off-target field for Track:OffTargetHeat."""

    seq = evs.get("sequence", {}).get("ref") if isinstance(evs, dict) else None
    if not isinstance(seq, str) or not seq:
        return np.zeros(1, dtype=np.float32)

    targets = evs.get("editPlan", {}).get("targets", []) if isinstance(evs, dict) else []
    guide = targets[0] if targets else {}
    guide_seq = guide.get("gRNA", {}).get("sequence") if isinstance(guide, dict) else None
    pam = guide.get("pam", "NGG") if isinstance(guide, dict) else "NGG"
    pam_offset = int(guide.get("pamOffset", 0)) if isinstance(guide, dict) else 0

    if not isinstance(guide_seq, str) or not guide_seq:
        return np.zeros(len(seq), dtype=np.float32)

    off_params = evs.get("simulation", {}).get("params", {}).get("offTarget", {})
    mismatch_max = int(off_params.get("mismatchMax", 3))
    seed_len = int(off_params.get("seedLen", max(1, len(guide_seq) // 2)))

    mask = _pam_mask(seq, pam, pam_offset)
    heat = np.zeros(len(seq), dtype=np.float32)
    g = guide_seq.upper()
    g_len = len(g)

    for i in range(len(seq) - g_len + 1):
        if not mask[i]:
            continue
        window = seq[i : i + g_len].upper()
        mismatches = sum(1 for a, b in zip(window, g) if a != b)
        if mismatches > mismatch_max:
            continue
        seed_mismatch = sum(1 for a, b in zip(window[:seed_len], g[:seed_len]) if a != b)
        score = max(0.0, 1.0 - (mismatches * 0.1 + seed_mismatch * 0.2))
        heat[i : i + g_len] = np.maximum(heat[i : i + g_len], score)

    # Normalize to [0,1]
    if heat.max() > 0:
        heat /= float(heat.max())
    return heat.astype(np.float32)


def compute_offtarget_heat(evs: dict[str, Any], *, backend: str = "auto", gl_ctx=None) -> np.ndarray:
    """Pluggable off-target field. v1 routes to CPU; GPU can be added later."""
    # TODO: when GPU backend lands, honor backend == "gpu" and gl_ctx
    return compute_offtarget_heat_cpu(evs)
