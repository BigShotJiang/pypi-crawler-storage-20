from __future__ import annotations

import json
import hashlib
import math
import os
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import __version__ as HELIX_VERSION
from helix import clock
from helix.provenance import current_git_sha
from helix.support.build_meta import build_info

from helix.studio.experiment_spec import experiment_spec_sha256, experiment_spec_to_dict
from helix.studio.experiment_intent_spec import (
    EXPERIMENT_INTENT_SPEC_SCHEMA_ID,
    experiment_intent_spec_from_dict_with_error,
    experiment_intent_spec_sha256,
    intent_spec_missing_required_fields,
)
from helix.studio.outcomes.cell_context import cell_context_breadcrumb, parse_cell_context
from helix.studio.iterated_dynamics import (
    CutVariant,
    RepairVariant,
    SelectionCoefficients,
    StateMixtureVariant,
    StressPolicy,
    build_scenarios,
    default_claims,
    default_state_bins,
    evaluate_claims,
)
from helix.sim.structural_risk import (
    BreakSite as StructuralBreakSite,
    StructuralRiskConfig as StructuralRiskConfigV1,
    StructuralRiskResult as StructuralRiskResultV1,
    compute_structural_risk,
)
from helix.rng import Rng


MODEL_TYPE_VALUES = {"statistical", "mechanistic", "hybrid"}
FRAMESHIFT_SOURCE_VALUES = {"computed", "assumed_zero", "excluded"}
FUNCTIONAL_CLASS_VALUES = {
    "intended_functional",
    "benign_variant",
    "unknown",
    "likely_harmful",
    "harmful",
}
OFFTARGET_STATUS_VALUES = {"computed", "not_computed"}
OFFTARGET_SEVERITY_VALUES = {"blocking", "warning"}
OFFTARGET_MODE_VALUES = {"none", "screening", "full"}
OFFTARGET_MODE_SOURCE_VALUES = {"policy", "none", "screening", "full"}
OFFTARGET_SCOPE_VALUES = {"none", "window_only", "genome_wide"}
STRUCTURAL_STATUS_VALUES = {"computed", "not_computed"}
STRUCTURAL_MODE_VALUES = {"none", "local_screening", "genome_screening", "full"}
STRUCTURAL_MODE_SOURCE_VALUES = {"policy", "none", "local_screening", "genome_screening", "full"}
STRUCTURAL_SCOPE_VALUES = {"none", "local", "window_only", "genome_wide"}
TOPOLOGY_STATUS_VALUES = {"computed", "not_computed"}
HAZARD_STATUS_VALUES = {"computed", "not_computed"}
HAZARD_SEVERITY_VALUES = {"blocking", "warning"}
CONVERGENCE_STATUS_VALUES = {"computed", "not_computed"}
CONVERGENCE_SEVERITY_VALUES = {"blocking", "warning"}
CONVERGENCE_SELECTION_MODEL_VALUES = {"neutral", "relative_fitness"}
CONVERGENCE_MIXING_VALUES = {"well_mixed", "compartmentalized"}
STABILITY_STATUS_VALUES = {"computed", "not_computed"}
STABILITY_SEVERITY_VALUES = {"blocking", "warning"}
STABILITY_INTERPRETATION_VALUES = {"high", "medium", "low"}
STABILITY_VARIANT_TYPE_VALUES = {"convergence_preset", "off_target_sweep"}
CUT_STRAND_VALUES = {"plus", "minus"}
GRADE_VALUES = {"A", "B", "C", "D", "F"}
DECISION_MODE_VALUES = {"filter_only", "decision_grade"}
DECISION_VALUES = {"go", "no_go", "insufficient_evidence", "redesign_required"}
VALIDITY_STATUS_VALUES = {"valid", "invalid"}
ITERATION_STATUS_VALUES = {"computed", "not_computed"}
CLAIMS_STATUS_VALUES = {"computed", "not_computed"}
HEADLINE_BY_GRADE = {
    "A": "High control, low risk within modeled bounds.",
    "B": "Moderate control, review tail risk and off target.",
    "C": "Weak control or incomplete constraints, not deployment ready.",
    "D": "Plurality regime or tail risk dominates, high mosaic or escape risk.",
    "F": "Loss of control, do not treat as intended edit.",
}
HEADLINE_ESCAPE_DOMINATES_BY_GRADE = {
    "D": "Tail risk dominates; escape dominates under selection.",
    "F": "Loss of control; escape dominates under selection, do not treat as intended edit.",
}

OFFTARGET_ANNOTATION_NOT_COMPUTED_TAG = "annotation_not_computed"
_OFFTARGET_DOWNGRADE_LANGUAGE = (
    "ran screening",
    "screening-only",
    "only window-only screening",
    "window-only",
    "Full off-target requested",
)

HAZARD_SPLICE_WINDOW_BP = 2


def _sha256_prefixed_hex(hex_digest: str) -> str:
    hex_digest = (hex_digest or "").strip().lower()
    if hex_digest.startswith("sha256:"):
        return hex_digest
    return f"sha256:{hex_digest}"

def _sha256_prefixed_payload(payload: Mapping[str, Any]) -> str:
    data = (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
    return _sha256_prefixed_hex(hashlib.sha256(data).hexdigest())

def _safe_text(value: Any) -> str:
    return str(value or "").strip()


def _summary_contract_source_hash() -> str:
    try:
        data = Path(__file__).read_bytes()
    except Exception:
        return "sha256:unavailable"
    return _sha256_prefixed_hex(hashlib.sha256(data).hexdigest())


def _backend_provenance() -> dict[str, Any]:
    info = build_info()
    return {
        "name": "helix",
        "version": str(info.get("helix_version") or HELIX_VERSION),
        "git_commit": _safe_text(info.get("git_sha") or current_git_sha() or "unavailable"),
        "build_timestamp_utc": _safe_text(info.get("build_date_utc") or "unavailable"),
    }


def _extract_posterior_payload_from_state(state: Mapping[str, Any]) -> Mapping[str, Any] | None:
    config = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    meta = config.get("metadata") if isinstance(config.get("metadata"), Mapping) else {}
    if isinstance(meta.get("posterior"), Mapping):
        return meta.get("posterior")
    sim_payload = config.get("sim_payload") if isinstance(config.get("sim_payload"), Mapping) else {}
    posterior = sim_payload.get("posterior") if isinstance(sim_payload.get("posterior"), Mapping) else None
    return posterior


def _extract_model_identity(state: Mapping[str, Any], *, fallback_model_id: str) -> tuple[str, str]:
    posterior = _extract_posterior_payload_from_state(state)
    model_id = ""
    model_version = ""
    if isinstance(posterior, Mapping):
        model = posterior.get("model") if isinstance(posterior.get("model"), Mapping) else {}
        model_id = _safe_text(model.get("id") or posterior.get("modelId") or posterior.get("model_id"))
        model_version = _safe_text(model.get("version") or posterior.get("modelVersion") or posterior.get("model_version"))
    if not model_id:
        model_id = _safe_text(fallback_model_id) or "unconfigured"
    if not model_version:
        model_version = "unconfigured"
    return model_id, model_version


def _extract_assay_decl(state: Mapping[str, Any], experiment_spec: Mapping[str, Any] | None) -> dict[str, Any]:
    spec = experiment_spec_to_dict(experiment_spec)
    constraints = spec.get("constraints") if isinstance(spec.get("constraints"), Mapping) else {}
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}

    def _pick(*keys: str) -> str:
        for src in (constraints, assumptions):
            for key in keys:
                if key in src:
                    value = _safe_text(src.get(key))
                    if value:
                        return value
        return ""

    assay_type = _pick("assayType", "assay_type", "assay")
    assay_def_id = _pick("assayDefinitionId", "assay_definition_id", "assayDefId")

    status = "declared" if (assay_type or assay_def_id) else "absent"
    out: dict[str, Any] = {
        "status": status,
        "assay_type": assay_type or None,
        "assay_definition_id": assay_def_id or None,
    }
    if status == "absent":
        out["reason"] = "assay not declared in experiment_spec.constraints/assumptions"
    return out


def _coerce_text_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return []
        # Accept comma/semicolon separated strings.
        parts = [p.strip() for p in raw.replace(";", ",").split(",")]
        return [p for p in parts if p]
    if isinstance(value, (list, tuple)):
        out: list[str] = []
        for item in value:
            if item is None:
                continue
            txt = str(item).strip()
            if txt:
                out.append(txt)
        return out
    txt = str(value).strip()
    return [txt] if txt else []


def _extract_cell_types(experiment_spec: Mapping[str, Any] | None) -> dict[str, Any]:
    spec = experiment_spec_to_dict(experiment_spec)
    constraints = spec.get("constraints") if isinstance(spec.get("constraints"), Mapping) else {}
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}

    values: list[str] = []
    for src in (constraints, assumptions):
        for key in (
            "cell_type",
            "cellType",
            "cell_types",
            "cellTypes",
            "cell_line",
            "cellLine",
            "cell_lines",
            "cellLines",
            "cell_lineage",
            "cellLineage",
        ):
            if key in src:
                values.extend(_coerce_text_list(src.get(key)))

    # Stable order + dedupe.
    seen: set[str] = set()
    deduped: list[str] = []
    for v in values:
        if v not in seen:
            seen.add(v)
            deduped.append(v)

    if deduped:
        return {"status": "declared", "cell_types": deduped}
    return {"status": "absent", "cell_types": [], "reason": "cell types not declared in experiment_spec.constraints/assumptions"}


def _extract_population_mode(experiment_spec: Mapping[str, Any] | None) -> dict[str, Any]:
    spec = experiment_spec_to_dict(experiment_spec)
    constraints = spec.get("constraints") if isinstance(spec.get("constraints"), Mapping) else {}
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
    for src in (constraints, assumptions):
        for key in ("population_mode", "populationMode", "population", "sample_mode", "sampleMode"):
            if key in src:
                mode = _safe_text(src.get(key)).lower()
                if mode in {"bulk", "clonal", "single_cell", "single-cell"}:
                    mode = "single_cell" if mode in {"single-cell"} else mode
                    return {"status": "declared", "mode": mode}
        # boolean hints
        if bool(src.get("bulk")) is True:
            return {"status": "declared", "mode": "bulk"}
        if bool(src.get("clonal")) is True:
            return {"status": "declared", "mode": "clonal"}
        if bool(src.get("single_cell")) is True or bool(src.get("singleCell")) is True:
            return {"status": "declared", "mode": "single_cell"}
    return {"status": "absent", "mode": None, "reason": "population mode not declared in experiment_spec.constraints/assumptions"}


def _infer_nuclease_family(token: str) -> str | None:
    t = str(token or "").strip().lower()
    if not t:
        return None
    if "cas12a" in t or "cpf1" in t:
        return "cas12a"
    if "cas9" in t or "spcas9" in t or "sacas9" in t or t.startswith("spg") or t.startswith("spry"):
        return "cas9"
    return None


def _extract_editing_modality(
    *,
    state: Mapping[str, Any],
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Best-effort modality declaration for domain-shift auditing."""

    spec = experiment_spec_to_dict(experiment_spec)
    plan = dict(edit_plan or {}) if isinstance(edit_plan, Mapping) else {}

    mode = str(plan.get("mode") or "").strip().lower()
    if not mode:
        modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
        modal_tokens = " ".join(str(m).lower() for m in modalities if isinstance(m, str))
        if "prime" in modal_tokens:
            mode = "prime"
        elif "base" in modal_tokens:
            mode = "base"
        elif "multiplex" in modal_tokens:
            mode = "multiplex"
        elif "cut" in modal_tokens or "crispr" in modal_tokens:
            mode = "cut"
    if mode not in {"cut", "prime", "base", "multiplex"}:
        mode = "cut" if "crispr" in str(state.get("run_kind") or "").lower() else (mode or "unknown")

    # Most explicit: edit_plan.targets[0].pamClass
    pam_class = None
    nuclease = None
    targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
    if targets:
        primary = targets[0] if isinstance(targets[0], Mapping) else None
        if isinstance(primary, Mapping):
            nuclease = _safe_text(primary.get("nuclease") or primary.get("editor") or "") or None
            pam_class = _safe_text(primary.get("pamClass") or primary.get("pam_class") or "") or None
            grna = primary.get("gRNA") if isinstance(primary.get("gRNA"), Mapping) else {}
            if nuclease is None:
                nuclease = _safe_text(grna.get("nuclease") or grna.get("editor") or "") or None
            if pam_class is None:
                pam_class = _safe_text(grna.get("pamClass") or grna.get("pam_class") or "") or None

    # Next: legacy config
    cfg = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    run_cfg = cfg.get("run_config") if isinstance(cfg.get("run_config"), Mapping) else {}
    pam_profile = _safe_text(run_cfg.get("pam_profile") or run_cfg.get("pamProfile") or "")
    pam_profile = pam_profile or _safe_text(cfg.get("pam_profile") or cfg.get("pamProfile") or "")
    pam_profile = pam_profile or None

    # Normalize the "family" for cut editors.
    family = _infer_nuclease_family(" ".join(t for t in (nuclease, pam_class, pam_profile) if t))
    editing_modality = None
    if mode == "prime":
        editing_modality = "prime"
    elif mode == "base":
        editing_modality = "base"
    elif family:
        editing_modality = family
    elif mode in {"cut", "multiplex"}:
        editing_modality = "cas9"  # default for Helix presets

    status = "declared" if any([nuclease, pam_class, pam_profile]) else "inferred"
    if editing_modality in {None, "unknown"}:
        return {"status": "absent", "editing_modality": None, "reason": "unable to infer editing modality"}
    return {
        "status": status,
        "editing_modality": editing_modality,
        "mode": mode,
        "nuclease": nuclease,
        "pam_class": pam_class,
        "pam_profile": pam_profile,
    }


def _build_intended_edit_spec(
    *,
    state: Mapping[str, Any],
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
    cut_site: "CutSiteV2",
) -> dict[str, Any]:
    spec = experiment_spec_to_dict(experiment_spec)
    intent = _safe_text(spec.get("intent") or "").lower() or "unknown"
    modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
    modalities_l = [str(m).strip().lower() for m in modalities if isinstance(m, str)]
    modality = "cut"
    if any("prime" in m for m in modalities_l) or intent == "prime_edit":
        modality = "prime"
    elif any("base" in m for m in modalities_l) or intent == "base_edit":
        modality = "base"

    edit_class = intent if intent not in {"", "unknown"} else ("prime_edit" if modality == "prime" else ("base_edit" if modality == "base" else "crispr_cut"))
    if edit_class not in {
        "crispr_cut",
        "prime_edit",
        "base_edit",
        "knockout",
        "knockin",
        "substitution",
        "insertion",
        "deletion",
        "prime_edit",
        "base_edit",
        "unknown",
    }:
        edit_class = "unknown"

    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    target = {
        "chrom": _safe_text(locus.get("chr") or locus.get("chrom") or locus.get("contig") or cut_site.chrom) or "unknown",
        "start": _maybe_int(locus.get("start")),
        "end": _maybe_int(locus.get("end")),
        "strand": _safe_text(locus.get("strand") or "+") or "+",
        "cut_site": {"chrom": cut_site.chrom, "pos": cut_site.pos, "strand": cut_site.strand},
    }

    plan = dict(edit_plan or {}) if isinstance(edit_plan, Mapping) else {}
    targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
    if targets:
        primary = targets[0] if isinstance(targets[0], Mapping) else None
        if isinstance(primary, Mapping):
            if primary.get("cutIndex") is not None or primary.get("cut_index") is not None:
                cut_index = _maybe_int(primary.get("cutIndex") if primary.get("cutIndex") is not None else primary.get("cut_index"))
                if cut_index is not None:
                    target["cut_index"] = int(cut_index)
            if isinstance(primary.get("gRNA"), Mapping):
                grna = primary.get("gRNA")
                seq = _safe_text(grna.get("sequence"))
                if seq:
                    target["guide_rna_sequence"] = seq

    measurement = _extract_assay_decl(state, experiment_spec)
    cell_types = _extract_cell_types(experiment_spec)
    population = _extract_population_mode(experiment_spec)
    modality = _extract_editing_modality(state=state, experiment_spec=experiment_spec, edit_plan=edit_plan)
    detection_limits = {"status": "absent", "reason": "detection limits not declared"}
    known_biases = {"status": "absent", "reason": "known biases not declared"}

    return {
        "edit_class": edit_class,
        "target": target,
        "allele": {
            "status": "not_specified",
            "reason": "allele sequence definition not provided in helix_experiment_spec_v1; requires assay-linked edit definition",
        },
        "measurement": measurement,
        "cell_types": cell_types,
        "population": population,
        "editing_modality": modality,
        "detection_limits": detection_limits,
        "known_biases": known_biases,
    }


def _build_params_snapshot(
    *,
    state: Mapping[str, Any],
    policy_hash: str,
    spec_hash: str,
    decision_mode_requested: str,
    off_target_policy: dict[str, Any],
    hazard_policy: dict[str, Any],
) -> dict[str, Any]:
    cfg = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
    outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
    genome_cfg = cfg.get("genome") if isinstance(cfg.get("genome"), Mapping) else {}
    sim_payload = cfg.get("sim_payload") if isinstance(cfg.get("sim_payload"), Mapping) else {}
    sim_meta = sim_payload.get("meta") if isinstance(sim_payload.get("meta"), Mapping) else {}
    sim_keep = {
        "draws": sim_payload.get("draws"),
        "seed": sim_meta.get("seed"),
        "pam_mask_scale": sim_meta.get("pam_mask_scale"),
        "priors": sim_payload.get("priors") if isinstance(sim_payload.get("priors"), Mapping) else None,
    }
    return {
        "spec_hash": spec_hash,
        "policy_hash": policy_hash,
        "decision_mode_requested": decision_mode_requested,
        "guide": dict(guide),
        "genome": {
            k: genome_cfg.get(k)
            for k in ("genomeId", "genome_id", "build", "build_id", "genomeBuild", "searchMode", "search_mode")
            if k in genome_cfg
        },
        "outcome_model": dict(outcome_cfg),
        "sim": {k: v for k, v in sim_keep.items() if v is not None},
        "off_target_policy": dict(off_target_policy),
        "hazard_policy": dict(hazard_policy),
    }


def _credible_interval_beta_mc(
    *,
    successes: int,
    trials: int,
    level: float = 0.95,
    samples: int = 4096,
    seed_label: str,
) -> dict[str, Any] | None:
    n = int(trials)
    k = int(successes)
    if n <= 0 or k < 0 or k > n:
        return None
    alpha = 1.0 + float(k)
    beta = 1.0 + float(n - k)
    if not (0.0 < float(level) < 1.0):
        level = 0.95
    if samples <= 256:
        samples = 256

    digest = hashlib.sha256(str(seed_label).encode("utf-8")).digest()
    seed = int.from_bytes(digest[:8], "big") or 1
    rng = Rng(int(seed), stream_id=f"summary_contract_v2:beta_mc_v1:{digest[:8].hex()}")
    draws = [rng.betavariate(alpha, beta) for _ in range(int(samples))]
    draws.sort()
    lo_q = (1.0 - float(level)) / 2.0
    hi_q = 1.0 - lo_q

    def pick(q: float) -> float:
        idx = int(round(q * (len(draws) - 1)))
        idx = max(0, min(idx, len(draws) - 1))
        return float(draws[idx])

    mean = alpha / (alpha + beta)
    return {
        "mean": float(mean),
        "lower": pick(lo_q),
        "upper": pick(hi_q),
        "level": float(level),
        "trials": int(n),
        "successes": int(k),
        "method": "beta_posterior_mc_v1",
    }


def _confidence_interval_wilson(
    *,
    successes: int,
    trials: int,
    level: float = 0.95,
) -> dict[str, Any] | None:
    """Binomial Wilson score interval (fast, no SciPy dependency)."""

    n = int(trials)
    k = int(successes)
    if n <= 0 or k < 0 or k > n:
        return None
    # z for two-sided interval; include common levels only to avoid scipy.
    lvl = float(level)
    if not (0.0 < lvl < 1.0):
        lvl = 0.95
    z = 1.96 if abs(lvl - 0.95) < 1e-9 else (1.64 if abs(lvl - 0.90) < 1e-9 else 1.96)
    phat = float(k) / float(n)
    denom = 1.0 + (z * z) / float(n)
    center = (phat + (z * z) / (2.0 * float(n))) / denom
    margin = (z * math.sqrt((phat * (1.0 - phat) / float(n)) + ((z * z) / (4.0 * float(n) * float(n))))) / denom
    lo = max(0.0, center - margin)
    hi = min(1.0, center + margin)
    return {
        "mean": float(phat),
        "lower": float(lo),
        "upper": float(hi),
        "level": float(lvl),
        "trials": int(n),
        "successes": int(k),
        "method": "wilson_score_interval_v1",
    }


def _compute_uncertainty_from_counts(
    *,
    pending_outcomes: Sequence[Mapping[str, Any]],
    total_draws: int | None,
) -> dict[str, Any]:
    n = int(total_draws) if isinstance(total_draws, int) and total_draws > 0 else None
    counts: list[int] = []
    for oc in pending_outcomes:
        count = oc.get("count")
        if count is None:
            return {"status": "not_computed", "reason": "outcome counts missing"}
        if not isinstance(count, int):
            return {"status": "not_computed", "reason": "outcome counts invalid"}
        if int(count) < 0:
            return {"status": "not_computed", "reason": "outcome counts invalid"}
        counts.append(int(count))

    total_counts = sum(counts)
    if n is None:
        n = int(total_counts) if total_counts > 0 else None
    if n is None or n <= 0:
        return {"status": "not_computed", "reason": "draw count unavailable"}
    if total_counts != n:
        return {"status": "not_computed", "reason": "counts do not sum to draws"}

    intended_k = 0
    no_cut_k = 0
    top_label = ""
    top_count = 0
    for oc in pending_outcomes:
        label = str(oc.get("label") or "")
        count = int(oc.get("count") or 0)
        if count > top_count:
            top_count = count
            top_label = label
        if bool(oc.get("is_no_cut")):
            no_cut_k += count
        if str(oc.get("functional_class") or "") == "intended_functional":
            intended_k += count

    intervals: dict[str, Any] = {}
    intended_ci = _credible_interval_beta_mc(
        successes=intended_k,
        trials=n,
        level=0.95,
        samples=4096,
        seed_label=f"intended:{n}:{intended_k}",
    )
    if intended_ci is not None:
        intervals["control.intended_functional_p"] = intended_ci
    no_cut_ci = _credible_interval_beta_mc(
        successes=no_cut_k,
        trials=n,
        level=0.95,
        samples=4096,
        seed_label=f"no_cut:{n}:{no_cut_k}",
    )
    if no_cut_ci is not None:
        intervals["control.no_cut_p"] = no_cut_ci
    # Dominant and top-k outcome uncertainty (by posterior mass).
    ranked_outcomes: list[tuple[str, int]] = []
    for oc in pending_outcomes:
        label = str(oc.get("label") or "")
        if not label:
            continue
        try:
            count = int(oc.get("count") or 0)
        except Exception:
            count = 0
        ranked_outcomes.append((label, max(0, count)))
    ranked_outcomes.sort(key=lambda kv: (kv[1], kv[0]), reverse=True)
    top_k = 3
    for i, (label, count) in enumerate(ranked_outcomes[:top_k], start=1):
        ci = _credible_interval_beta_mc(
            successes=count,
            trials=n,
            level=0.95,
            samples=4096,
            seed_label=f"top{i}:{label}:{n}:{count}",
        )
        if ci is None:
            continue
        intervals[f"outcomes.top_{i}_p"] = {**ci, "outcome_label": label}
        if i == 1:
            intervals["outcomes.top_p"] = {**ci, "outcome_label": label}

    # Per-outcome uncertainty: include confidence bounds for each outcome probability.
    # This is intended for auditability (domain shift), not as a replacement for calibrated posteriors.
    outcome_intervals: list[dict[str, Any]] = []
    for oc in pending_outcomes:
        label = str(oc.get("label") or "")
        oid = str(oc.get("outcome_id") or "")
        try:
            count = int(oc.get("count") or 0)
        except Exception:
            count = 0
        ci = _confidence_interval_wilson(successes=count, trials=n, level=0.95)
        if ci is None:
            continue
        outcome_intervals.append(
            {
                "outcome_id": oid,
                "label": label,
                **ci,
            }
        )

    if not intervals:
        return {"status": "not_computed", "reason": "intervals unavailable"}

    return {
        "status": "computed",
        "kind": "credible_interval",
        "level": 0.95,
        "draws": n,
        "credible_intervals": intervals,
        "outcome_intervals": outcome_intervals,
    }


def _canonicalize_cache_inputs(cache_inputs: Mapping[str, Any]) -> tuple[dict[str, Any], str]:
    """Canonical cache identity: canonical JSON (sorted keys, fixed separators, newline) is hashed with sha256.
    This byte string is the sole source of truth for cache_key and cache_key_inputs_hash; do not change ordering, formatting, or included fields without updating ratchet tests. Float fields must be pre-normalized before canonicalization; do not rely on JSON float rendering for semantic equality."""
    canonical_json = json.dumps(cache_inputs, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    canonical_obj = json.loads(canonical_json)
    prefixed = _sha256_prefixed_hex(hashlib.sha256((canonical_json + "\n").encode("utf-8")).hexdigest())
    return canonical_obj, prefixed


def _safe_float(value: Any, *, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _safe_int(value: Any, *, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _maybe_int(value: Any) -> int | None:
    try:
        return int(value)
    except Exception:
        return None


def _clamp01(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(0.0, min(1.0, float(value)))


def _entropy_bits(probs: Sequence[float]) -> float:
    h = 0.0
    for p in probs:
        p = float(p)
        if p <= 0.0:
            continue
        h -= p * math.log(p, 2)
    return float(h)


def _dominance_ratio(probs: Sequence[float]) -> float:
    if not probs:
        return 0.0
    ordered = sorted([max(0.0, float(p)) for p in probs], reverse=True)
    top = ordered[0]
    second = ordered[1] if len(ordered) > 1 else 0.0
    if second <= 0.0:
        return float("inf") if top > 0.0 else 0.0
    return float(top / second)


def _quantile_discrete(dist: Mapping[int, float], q: float) -> float:
    q = max(0.0, min(1.0, float(q)))
    items = sorted(((int(v), float(p)) for v, p in dist.items() if float(p) > 0.0), key=lambda x: x[0])
    if not items:
        return 0.0
    total = sum(p for _v, p in items)
    if total <= 0.0:
        return 0.0
    target = q * total
    acc = 0.0
    for value, prob in items:
        acc += prob
        if acc >= target:
            return float(value)
    return float(items[-1][0])


def _mean_discrete(dist: Mapping[int, float]) -> float:
    total = 0.0
    acc = 0.0
    for value, prob in dist.items():
        p = float(prob)
        if p <= 0.0:
            continue
        total += p
        acc += float(value) * p
    if total <= 0.0:
        return 0.0
    return float(acc / total)


def _cvar_discrete(dist: Mapping[int, float], q: float) -> float:
    if not dist:
        return 0.0
    threshold = _quantile_discrete(dist, q)
    tail_total = 0.0
    tail_sum = 0.0
    for value, prob in dist.items():
        p = float(prob)
        if p <= 0.0:
            continue
        if float(value) >= threshold:
            tail_total += p
            tail_sum += float(value) * p
    if tail_total <= 0.0:
        return float(threshold)
    return float(tail_sum / tail_total)


def _p_ge(dist: Mapping[int, float], threshold: int) -> float:
    thr = int(threshold)
    return float(sum(float(p) for v, p in dist.items() if int(v) >= thr and float(p) > 0.0))


def _uniform_int_dist(min_len: int, max_len: int) -> dict[int, float]:
    lo = max(0, int(min_len))
    hi = max(0, int(max_len))
    if hi < lo:
        lo, hi = hi, lo
    if hi == lo:
        return {lo: 1.0}
    values = list(range(lo, hi + 1))
    p = 1.0 / float(len(values))
    return {v: p for v in values}


def _frameshift_prob_from_len_dist(indel_len_dist: Mapping[int, float]) -> float:
    if not indel_len_dist:
        return 0.0
    p = 0.0
    for length, prob in indel_len_dist.items():
        l = int(length)
        if l <= 0:
            continue
        if (l % 3) != 0:
            p += float(prob)
    return _clamp01(p)


def _infer_policy_id(header: Mapping[str, Any] | None) -> str:
    if isinstance(header, Mapping):
        for key in ("policyName", "policyId", "policy_id", "policy"):
            value = header.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    path = os.getenv("HELIX_POLICY_PATH")
    if path:
        try:
            return Path(path).name
        except Exception:
            return str(path)
    return "unknown"


def _load_policy_payload_best_effort() -> Mapping[str, Any]:
    path = os.getenv("HELIX_POLICY_PATH")
    if not path:
        return {}
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, Mapping) else {}


def _resolve_decision_mode_policy(policy_payload: Mapping[str, Any]) -> str | None:
    raw = None
    for key in ("decisionMode", "decision_mode", "decision-mode"):
        if key in policy_payload:
            raw = policy_payload.get(key)
            break
    if raw is None and isinstance(policy_payload.get("decisionPolicy"), Mapping):
        cfg = policy_payload.get("decisionPolicy")
        for key in ("mode", "decisionMode", "decision_mode"):
            if isinstance(cfg, Mapping) and key in cfg:
                raw = cfg.get(key)
                break
    mode = str(raw or "").strip().lower()
    if not mode:
        return None
    if mode in DECISION_MODE_VALUES:
        return mode
    return None


def _resolve_hazard_policy(policy_payload: Mapping[str, Any]) -> dict[str, Any]:
    cfg = policy_payload.get("hazardPolicy") if isinstance(policy_payload.get("hazardPolicy"), Mapping) else {}
    splice_required = bool(cfg.get("spliceRequired") or cfg.get("splice_required") or cfg.get("splice"))
    regulatory_required = bool(cfg.get("regulatoryRequired") or cfg.get("regulatory_required") or cfg.get("regulatory"))
    return {"splice_required": splice_required, "regulatory_required": regulatory_required}


def _resolve_off_target_policy(policy_payload: Mapping[str, Any]) -> tuple[str, bool, dict[str, Any], bool]:
    cfg = policy_payload.get("offTargetPolicy") if isinstance(policy_payload.get("offTargetPolicy"), Mapping) else {}
    compute = str(cfg.get("compute") or cfg.get("mode") or "screening").strip().lower()
    if compute not in {"none", "screening", "full"}:
        compute = "screening"
    required = bool(cfg.get("required")) if "required" in cfg else False
    species_required = bool(
        cfg.get("speciesRequired")
        or cfg.get("species_required")
        or cfg.get("requireSpecies")
        or cfg.get("require_species")
    )
    overrides: dict[str, Any] = {}
    provider_id = cfg.get("providerId") or cfg.get("provider_id") or cfg.get("provider")
    if isinstance(provider_id, str) and provider_id.strip():
        overrides["provider_id"] = provider_id.strip()
    for src_key, dst_key in (
        ("maxMm", "max_mm"),
        ("max_mm", "max_mm"),
        ("maxHits", "max_hits"),
        ("max_hits", "max_hits"),
    ):
        if src_key in cfg:
            try:
                overrides[dst_key] = int(cfg.get(src_key))
            except Exception:
                continue
    return compute, required, overrides, species_required


def _resolve_structural_policy(policy_payload: Mapping[str, Any]) -> tuple[str, bool, dict[str, Any]]:
    cfg = policy_payload.get("structuralPolicy") if isinstance(policy_payload.get("structuralPolicy"), Mapping) else {}
    compute = str(cfg.get("compute") or cfg.get("mode") or "local_screening").strip().lower()
    if compute == "local":
        compute = "local_screening"
    if compute == "genome":
        compute = "genome_screening"
    if compute not in STRUCTURAL_MODE_VALUES:
        compute = "local_screening"
    required = bool(cfg.get("required")) if "required" in cfg else False

    overrides: dict[str, Any] = {}
    for src_key, dst_key in (
        ("maxBreakSites", "max_break_sites"),
        ("max_break_sites", "max_break_sites"),
        ("sameChromWindowBp", "same_chrom_window_bp"),
        ("same_chrom_window_bp", "same_chrom_window_bp"),
        ("distanceScaleBp", "distance_scale_bp"),
        ("distance_scale_bp", "distance_scale_bp"),
        ("crossChromJoinBias", "cross_chrom_join_bias"),
        ("cross_chrom_join_bias", "cross_chrom_join_bias"),
        ("inversionFraction", "inversion_fraction"),
        ("inversion_fraction", "inversion_fraction"),
        ("singleLargeDeletionRate", "single_large_deletion_rate"),
        ("single_large_deletion_rate", "single_large_deletion_rate"),
        ("largeDeletionMinBp", "large_deletion_min_bp"),
        ("large_deletion_min_bp", "large_deletion_min_bp"),
        ("topPairs", "top_pairs"),
        ("top_pairs", "top_pairs"),
    ):
        if src_key not in cfg:
            continue
        overrides[dst_key] = cfg.get(src_key)

    return compute, required, overrides


def _structural_config_from_overrides(overrides: Mapping[str, Any] | None) -> StructuralRiskConfigV1:
    cfg = StructuralRiskConfigV1()
    ov = overrides if isinstance(overrides, Mapping) else {}
    kwargs: dict[str, Any] = {}

    def _int(key: str) -> int | None:
        if key not in ov:
            return None
        try:
            return int(ov.get(key))
        except Exception:
            return None

    def _float(key: str) -> float | None:
        if key not in ov:
            return None
        try:
            return float(ov.get(key))
        except Exception:
            return None

    if (v := _int("max_break_sites")) is not None:
        kwargs["max_break_sites"] = max(0, v)
    if (v := _int("same_chrom_window_bp")) is not None:
        kwargs["same_chrom_window_bp"] = max(0, v)
    if (v := _float("distance_scale_bp")) is not None:
        kwargs["distance_scale_bp"] = float(v)
    if (v := _float("cross_chrom_join_bias")) is not None:
        kwargs["cross_chrom_join_bias"] = max(0.0, float(v))
    if (v := _float("inversion_fraction")) is not None:
        kwargs["inversion_fraction"] = max(0.0, min(1.0, float(v)))
    if (v := _float("single_large_deletion_rate")) is not None:
        kwargs["single_large_deletion_rate"] = max(0.0, float(v))
    if (v := _int("large_deletion_min_bp")) is not None:
        kwargs["large_deletion_min_bp"] = max(1, v)
    if (v := _int("top_pairs")) is not None:
        kwargs["top_pairs"] = max(0, v)

    return replace(cfg, **kwargs) if kwargs else cfg


def _extract_species_detection(state: Mapping[str, Any]) -> dict[str, Any] | None:
    candidates: list[Any] = []
    for key in ("species_detection", "species_detection_artifact", "species_detection_v1"):
        if key in state:
            candidates.append(state.get(key))
    cfg = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    if isinstance(cfg, Mapping):
        for key in ("species_detection", "species_detection_artifact", "species_detection_v1"):
            if key in cfg:
                candidates.append(cfg.get(key))
        meta = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
        if isinstance(meta, Mapping):
            for key in ("species_detection", "species_detection_artifact", "species_detection_v1"):
                if key in meta:
                    candidates.append(meta.get(key))
            path = meta.get("species_detection_path") or meta.get("species_detection_file")
            if isinstance(path, str) and path.strip():
                candidates.append(path.strip())

    path = state.get("species_detection_path")
    if isinstance(path, str) and path.strip():
        candidates.append(path.strip())

    for cand in candidates:
        if isinstance(cand, Mapping):
            if str(cand.get("schema") or "") == "species_detection_v1":
                return dict(cand)
        if isinstance(cand, str):
            try:
                raw = Path(cand)
                if raw.exists():
                    payload = json.loads(raw.read_text(encoding="utf-8"))
                    if isinstance(payload, Mapping) and str(payload.get("schema") or "") == "species_detection_v1":
                        return dict(payload)
            except Exception:
                continue
    return None


def _resolve_convergence_policy(policy_payload: Mapping[str, Any]) -> dict[str, Any]:
    cfg = (
        policy_payload.get("convergencePolicy")
        if isinstance(policy_payload.get("convergencePolicy"), Mapping)
        else {}
    )
    enabled = True
    if "enabled" in cfg:
        enabled = bool(cfg.get("enabled"))
    required = bool(cfg.get("required")) if "required" in cfg else False

    generations: list[int] = []
    gens_raw = cfg.get("generations")
    if isinstance(gens_raw, list):
        for g in gens_raw:
            if isinstance(g, int) and g >= 0:
                generations.append(int(g))
    if not generations:
        generations = [5, 10, 20]
    generations = list(sorted(set(generations)))

    preset = str(cfg.get("preset") or cfg.get("fitnessPreset") or cfg.get("fitness_preset") or "conservative").strip().lower()
    if preset not in {"conservative", "neutral", "optimistic"}:
        preset = "conservative"

    selection_model = str(cfg.get("selectionModel") or cfg.get("selection_model") or "").strip().lower()
    if selection_model not in CONVERGENCE_SELECTION_MODEL_VALUES:
        selection_model = "neutral" if preset == "neutral" else "relative_fitness"

    mixing = str(cfg.get("mixing") or "well_mixed").strip().lower()
    if mixing not in CONVERGENCE_MIXING_VALUES:
        mixing = "well_mixed"

    def _float_list(raw: Any) -> list[float]:
        if not isinstance(raw, list):
            return []
        out: list[float] = []
        for x in raw:
            if isinstance(x, (int, float)) and math.isfinite(float(x)):
                out.append(float(x))
        return out

    grid_raw = cfg.get("fitnessGrid") or cfg.get("fitness_grid") or cfg.get("fitnessGridV1")
    grid: dict[str, list[float]] = {}
    if isinstance(grid_raw, Mapping):
        grid["fitness_intended"] = _float_list(grid_raw.get("fitnessIntended") or grid_raw.get("fitness_intended"))
        grid["fitness_uncut"] = _float_list(grid_raw.get("fitnessUncut") or grid_raw.get("fitness_uncut"))
        grid["fitness_harmful"] = _float_list(grid_raw.get("fitnessHarmful") or grid_raw.get("fitness_harmful"))

    if preset == "neutral":
        defaults = {"fitness_intended": [1.0], "fitness_uncut": [1.0], "fitness_harmful": [1.0]}
    elif preset == "optimistic":
        defaults = {"fitness_intended": [1.0, 1.01], "fitness_uncut": [0.99, 1.0], "fitness_harmful": [0.9, 0.95, 0.99]}
    else:
        defaults = {"fitness_intended": [0.99, 1.0, 1.01], "fitness_uncut": [1.0, 1.01], "fitness_harmful": [0.9, 0.95, 0.99]}

    for k, v in defaults.items():
        if not grid.get(k):
            grid[k] = list(v)

    return {
        "enabled": bool(enabled),
        "required": bool(required),
        "generations": list(generations),
        "preset": str(preset),
        "selection_model": str(selection_model),
        "mixing": str(mixing),
        "fitness_grid": grid,
    }


def _resolve_stability_policy(policy_payload: Mapping[str, Any]) -> dict[str, Any]:
    cfg = (
        policy_payload.get("stabilityPolicy")
        if isinstance(policy_payload.get("stabilityPolicy"), Mapping)
        else {}
    )
    enabled = True
    if "enabled" in cfg:
        enabled = bool(cfg.get("enabled"))
    required = bool(cfg.get("required")) if "required" in cfg else False

    presets: list[str] = []
    raw_presets = cfg.get("presets")
    if isinstance(raw_presets, list):
        for p in raw_presets:
            if isinstance(p, str):
                val = p.strip().lower()
                if val in {"conservative", "neutral", "optimistic"}:
                    presets.append(val)
    if not presets:
        presets = ["conservative", "neutral", "optimistic"]
    presets = list(dict.fromkeys(presets))

    off_target_sweep = {}
    sweep_raw = cfg.get("offTargetSweep") if isinstance(cfg.get("offTargetSweep"), Mapping) else {}
    sweep_enabled = bool(sweep_raw.get("enabled")) if "enabled" in sweep_raw else False
    sweep_required = bool(sweep_raw.get("required")) if "required" in sweep_raw else False
    modes = sweep_raw.get("modes")
    if not isinstance(modes, list):
        modes = ["screening"]
    modes = [str(m).strip().lower() for m in modes if isinstance(m, str)]
    modes = [m for m in modes if m in {"none", "screening", "full"}]
    if not modes:
        modes = ["screening"]
    max_mm = sweep_raw.get("maxMm") or sweep_raw.get("max_mm") or []
    max_mm_list = [int(x) for x in max_mm if isinstance(x, int)]
    if not max_mm_list:
        max_mm_list = [2, 3, 4]
    max_hits = sweep_raw.get("maxHits") or sweep_raw.get("max_hits") or []
    max_hits_list = [int(x) for x in max_hits if isinstance(x, int)]
    if not max_hits_list:
        max_hits_list = [50, 200]
    provider_id = str(sweep_raw.get("providerId") or sweep_raw.get("provider_id") or "offtarget_mismatch_v1")
    allow_full = bool(sweep_raw.get("allowFull")) if "allowFull" in sweep_raw else False
    full_required = bool(sweep_raw.get("fullRequired")) if "fullRequired" in sweep_raw else False

    off_target_sweep = {
        "enabled": sweep_enabled,
        "required": sweep_required,
        "modes": modes,
        "max_mm": max_mm_list,
        "max_hits": max_hits_list,
        "provider_id": provider_id,
        "allow_full": allow_full,
        "full_required": full_required,
    }

    return {"enabled": bool(enabled), "required": bool(required), "presets": presets, "off_target_sweep": off_target_sweep}


def _resolve_iteration_policy(policy_payload: Mapping[str, Any]) -> tuple[bool, bool, bool, StressPolicy]:
    cfg = policy_payload.get("iterationPolicy") if isinstance(policy_payload.get("iterationPolicy"), Mapping) else {}
    enabled = True if "enabled" not in cfg else bool(cfg.get("enabled"))
    required = bool(cfg.get("required")) if "required" in cfg else False
    claims_cfg = cfg.get("claims") if isinstance(cfg.get("claims"), Mapping) else {}
    claims_required = bool(claims_cfg.get("required")) if "required" in claims_cfg else False
    steps = max(0, int(cfg.get("steps") or 5))

    transition_cfg = cfg.get("transition") if isinstance(cfg.get("transition"), Mapping) else {}
    transition_required = bool(transition_cfg.get("required")) if "required" in transition_cfg else False
    transition_model = str(transition_cfg.get("model") or "identity").strip().lower() or "identity"
    if transition_model not in {"identity"}:
        transition_model = "identity"

    def _normalize_weights(weights: Sequence[float], count: int) -> list[float]:
        if count <= 0:
            return []
        raw = [max(0.0, float(w)) for w in weights]
        if len(raw) < count:
            raw.extend([0.0] * (count - len(raw)))
        if len(raw) > count:
            raw = raw[:count]
        total = sum(raw)
        if total <= 0.0:
            return [1.0 / count] * count
        return [w / total for w in raw]

    state_bins = default_state_bins()
    state_count = len(state_bins)
    mixtures: list[StateMixtureVariant] = []
    raw_mixtures = cfg.get("stateMixtures") if isinstance(cfg.get("stateMixtures"), list) else []
    for idx, entry in enumerate(raw_mixtures):
        name = f"mix_{idx}"
        weights: list[float] = []
        if isinstance(entry, list):
            weights = [float(x) for x in entry if isinstance(x, (int, float))]
        elif isinstance(entry, Mapping):
            name = str(entry.get("name") or name)
            weights = [float(x) for x in (entry.get("weights") or []) if isinstance(x, (int, float))]
        if weights:
            mixtures.append(StateMixtureVariant(name=name, weights=_normalize_weights(weights, state_count)))
    if not mixtures:
        mixtures = [StateMixtureVariant(name="uniform", weights=[1.0 / state_count] * state_count)]

    cut_variants: list[CutVariant] = []
    raw_cuts = cfg.get("cutEfficiencyMultipliers") if isinstance(cfg.get("cutEfficiencyMultipliers"), list) else []
    for idx, entry in enumerate(raw_cuts):
        name = f"cut_{idx}"
        chroma: dict[str, float] = {}
        state: dict[str, float] = {}
        if isinstance(entry, Mapping):
            name = str(entry.get("name") or name)
            chroma = {
                str(k): float(v)
                for k, v in (entry.get("byChromatin") or {}).items()
                if isinstance(v, (int, float))
            }
            state = {
                str(k): float(v)
                for k, v in (entry.get("byState") or {}).items()
                if isinstance(v, (int, float))
            }
        cut_variants.append(CutVariant(name=name, chromatin_multipliers=chroma, state_multipliers=state))
    if not cut_variants:
        cut_variants = [CutVariant(name="nominal", chromatin_multipliers={}, state_multipliers={})]

    repair_variants: list[RepairVariant] = []
    raw_repairs = cfg.get("repairBiases") if isinstance(cfg.get("repairBiases"), list) else []
    for idx, entry in enumerate(raw_repairs):
        name = f"repair_{idx}"
        intended: dict[str, float] = {}
        harmful: dict[str, float] = {}
        if isinstance(entry, Mapping):
            name = str(entry.get("name") or name)
            intended = {
                str(k): float(v)
                for k, v in (entry.get("byRegime") or {}).items()
                if isinstance(v, (int, float))
            }
            harmful = {
                str(k): float(v)
                for k, v in (entry.get("harmfulByRegime") or {}).items()
                if isinstance(v, (int, float))
            }
        repair_variants.append(RepairVariant(name=name, intended_by_regime=intended, harmful_by_regime=harmful))
    if not repair_variants:
        repair_variants = [RepairVariant(name="neutral", intended_by_regime={}, harmful_by_regime={})]

    selection_variants: list[SelectionCoefficients] = []
    raw_selection = cfg.get("selectionCoefficients") if isinstance(cfg.get("selectionCoefficients"), list) else []
    for entry in raw_selection:
        if not isinstance(entry, Mapping):
            continue
        fi = entry.get("intended")
        fu = entry.get("uncut")
        fh = entry.get("harmful")
        if not all(isinstance(x, (int, float)) for x in (fi, fu, fh)):
            continue
        selection_variants.append(
            SelectionCoefficients(
                fitness_intended=float(fi),
                fitness_uncut=float(fu),
                fitness_harmful=float(fh),
            )
        )
    if not selection_variants:
        selection_variants = [SelectionCoefficients(1.0, 1.0, 1.0)]

    raw_drifts = cfg.get("cutDriftPerStep") if isinstance(cfg.get("cutDriftPerStep"), list) else []
    cut_drifts: list[float] = []
    for val in raw_drifts:
        if isinstance(val, (int, float)) and math.isfinite(float(val)):
            cut_drifts.append(float(val))
    if not cut_drifts:
        cut_drifts = [0.0]

    stress = StressPolicy(
        steps=steps,
        state_mixtures=mixtures,
        cut_variants=cut_variants,
        repair_variants=repair_variants,
        selection_variants=selection_variants,
        cut_drift_per_step=cut_drifts,
        transition_required=transition_required,
        transition_model=transition_model,
    )
    return enabled, required, claims_required, stress


def _infer_hash(header: Mapping[str, Any] | None, key: str, env: str) -> str:
    if isinstance(header, Mapping):
        value = header.get(key)
        if isinstance(value, str) and value.strip():
            return _sha256_prefixed_hex(value.strip())
    env_val = os.getenv(env)
    if env_val:
        return _sha256_prefixed_hex(env_val.strip())
    return "sha256:unknown"


def _is_no_cut_label(label: str) -> bool:
    norm = (label or "").strip().lower()
    return norm in {
        "no_cut",
        "no_edit",
        "no_change",
        "no_editing",
        "wild_type",
        "unedited",
        "no_edit_detected",
    }


def _delta_bp_from_diff(diff: Mapping[str, Any] | None) -> int:
    if not isinstance(diff, Mapping):
        return 0
    if diff.get("replacement") is not None and diff.get("start") is not None and diff.get("end") is not None:
        try:
            start = int(diff.get("start"))
            end = int(diff.get("end"))
            repl = str(diff.get("replacement") or "")
            return int(len(repl) - (end - start))
        except Exception:
            return 0
    kind = str(diff.get("kind") or diff.get("edit") or "").lower()
    start = diff.get("start")
    end = diff.get("end")
    if start is not None and end is not None:
        try:
            span = int(end) - int(start)
        except Exception:
            span = 0
        if "del" in kind or "deletion" in kind:
            return -max(0, span)
        if "ins" in kind or "insertion" in kind:
            repl = diff.get("sequence") or diff.get("replacement") or ""
            try:
                return int(len(str(repl) or "")) if repl else max(0, span)
            except Exception:
                return max(0, span)
    edit = str(diff.get("edit") or "")
    if edit.startswith("del"):
        try:
            return -abs(int(edit[3:]))
        except Exception:
            return 0
    if edit.startswith("ins"):
        try:
            return abs(int(edit[3:]))
        except Exception:
            return 0
    return 0


def _infer_intent(experiment_spec: Mapping[str, Any] | None) -> str:
    spec = experiment_spec_to_dict(experiment_spec)
    value = spec.get("intent")
    return str(value or "").strip().lower()


def _functional_class_for_outcome(
    *,
    label: str,
    intent: str,
    frameshift_p: float,
    indel_len_mean: float,
    explicit: str | None = None,
) -> str:
    if explicit in FUNCTIONAL_CLASS_VALUES:
        return str(explicit)
    label_norm = (label or "").lower()
    if "intended" in label_norm or "desired" in label_norm or "scarless" in label_norm:
        return "intended_functional"
    if _is_no_cut_label(label_norm):
        return "unknown"
    if intent in {"knockout", "ko"}:
        # KO intent: frameshift is the intended functional outcome.
        if frameshift_p > 0.0:
            return "intended_functional"
        return "unknown"
    # Non-KO: frameshift generally harmful.
    if frameshift_p > 0.0:
        return "likely_harmful" if indel_len_mean < 50.0 else "harmful"
    return "unknown"


def repair_model_ui_label(*, model_type: str) -> str:
    """UI label for the repair model (physics honesty gate)."""
    mt = str(model_type or "").strip().lower()
    if mt not in MODEL_TYPE_VALUES:
        mt = "statistical"
    # Intentionally avoid the word "physics" for statistical models.
    if mt == "statistical":
        return "Repair model, statistical"
    return f"Repair model, {mt}"


def top_outcome_ui_label(*, dominance_ratio: float) -> str:
    ratio = float(dominance_ratio)
    if math.isfinite(ratio) and ratio >= 3.0:
        return "Dominant outcome"
    return "Plurality leader"


@dataclass(frozen=True)
class CalibrationV2:
    dataset_id: str
    domain: str
    notes: str


@dataclass(frozen=True)
class ModelV2:
    name: str
    type: str
    constraints: list[str]
    calibration: CalibrationV2


@dataclass(frozen=True)
class ModelStackV2:
    repair_model: ModelV2
    off_target_model: ModelV2


@dataclass(frozen=True)
class CutSiteV2:
    chrom: str
    pos: int
    strand: str


@dataclass(frozen=True)
class FrameshiftV2:
    p: float
    source: str
    reason: str | None = None


@dataclass(frozen=True)
class IndelLengthV2:
    median_bp: float
    mean_bp: float
    p90_bp: float
    p95_bp: float
    p99_bp: float
    cvar95_bp: float
    cvar99_bp: float
    p_ge_10bp: float
    p_ge_50bp: float
    p_ge_200bp: float


@dataclass(frozen=True)
class RegulatoryOverlapV2:
    p_hits_splice_donor: float
    p_hits_splice_acceptor: float
    p_hits_promoter: float
    p_hits_enhancer: float
    p_hits_boundary_element: float


@dataclass(frozen=True)
class WorstHitV2:
    feature_type: str
    feature_id: str
    p: float


@dataclass(frozen=True)
class OutcomeV2:
    outcome_id: str
    label: str
    p_total: float
    p_given_cut: float | None
    functional_class: str
    frameshift: FrameshiftV2
    indel_length: IndelLengthV2
    regulatory_overlap: RegulatoryOverlapV2
    worst_hit: WorstHitV2


@dataclass(frozen=True)
class ConvergenceAssumptionsV2:
    fitness_intended: float
    fitness_uncut: float
    fitness_harmful: float
    selection_model: str
    harmful_definition: str
    mixing: str | None = None


@dataclass(frozen=True)
class ConvergenceInitialFractionsV2:
    intended_p: float
    uncut_p: float
    harmful_p: float


@dataclass(frozen=True)
class ConvergenceProjectionPointV2:
    gen: int
    intended_p: float
    uncut_p: float
    harmful_p: float
    escape_risk: float
    escape_condition: str


@dataclass(frozen=True)
class ConvergenceV2:
    status: str
    generations: list[int] | None = None
    assumptions: ConvergenceAssumptionsV2 | None = None
    initial_fractions: ConvergenceInitialFractionsV2 | None = None
    projected: list[ConvergenceProjectionPointV2] | None = None
    escape_risk: float | None = None
    escape_worst_case_uncut_p_gen20: float | None = None
    reason: str | None = None
    severity: str | None = None


@dataclass(frozen=True)
class StabilityVariantV2:
    variant_id: str
    variant_type: str
    preset: str
    grade: str
    intended_p: float
    dominance_ratio: float
    entropy_bits: float
    escape_risk: float
    splice_risk: float
    regulatory_risk: float
    off_target_params: dict[str, Any] | None = None
    off_target_status: str | None = None
    off_target_worst_site_score: float | None = None


@dataclass(frozen=True)
class StabilityRangesV2:
    grade_min: str
    grade_max: str
    intended_min: float
    intended_max: float
    escape_min: float
    escape_max: float
    splice_min: float
    splice_max: float
    regulatory_min: float
    regulatory_max: float
    off_target_worst_min: float
    off_target_worst_max: float
    off_target_coding_min: float
    off_target_coding_max: float


@dataclass(frozen=True)
class StabilityAssumptionsV2:
    preset_ids_used: list[str]
    assumptions_hash: str
    off_target_sweep_hash: str | None = None


@dataclass(frozen=True)
class StabilityV2:
    status: str
    assumptions: StabilityAssumptionsV2 | None = None
    variants: list[StabilityVariantV2] | None = None
    ranges: StabilityRangesV2 | None = None
    stability_score: float | None = None
    interpretation: str | None = None
    warnings: list[str] = field(default_factory=list)
    reason: str | None = None
    severity: str | None = None


def _default_stability() -> StabilityV2:
    return StabilityV2(status="not_computed", reason="stability not computed", severity="warning")


@dataclass(frozen=True)
class IterationV2:
    status: str
    steps: int | None = None
    required: bool | None = None
    transition_model: str | None = None
    transition_required: bool | None = None
    limitations: str | None = None
    entropy_joint_bits: list[float] | None = None
    entropy_class_bits: list[float] | None = None
    kappa_max: list[float] | None = None
    kappa_avg: list[float] | None = None
    intended: list[float] | None = None
    uncut: list[float] | None = None
    harmful: list[float] | None = None
    escape: list[float] | None = None
    hazard_splice: list[float] | None = None
    hazard_reg: list[float] | None = None
    kappa_max_overall: float | None = None
    kappa_avg_overall: float | None = None
    reason: str | None = None
    severity: str | None = None


def _default_iteration() -> IterationV2:
    return IterationV2(status="not_computed", reason="iteration not computed", severity="warning")


@dataclass(frozen=True)
class ClaimResultV2:
    claim_id: str
    status: str
    statement: str
    operator: str
    threshold: float
    value: float | None = None
    margin: float | None = None
    scope_steps: int | None = None
    fail_mode: str | None = None
    triggered_by: list[str] = field(default_factory=list)
    counterexample: dict[str, Any] | None = None
    notes: str | None = None


@dataclass(frozen=True)
class ClaimsV2:
    status: str
    required: bool
    scenario_count: int
    results: list[ClaimResultV2] = field(default_factory=list)
    worst_margin: float | None = None
    worst_claim_id: str | None = None
    clean: bool | None = None
    reason: str | None = None


@dataclass(frozen=True)
class ControlV2:
    intended_functional_p: float
    dominance_ratio: float
    entropy_bits: float
    no_cut_p: float
    convergence: ConvergenceV2
    stability: StabilityV2 = field(default_factory=_default_stability)
    iteration: IterationV2 = field(default_factory=_default_iteration)
    claims: ClaimsV2 | None = None
    flags: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class RecommendationTriggerV2:
    metric_path: str
    condition: str
    value: Any


@dataclass(frozen=True)
class RecommendationV2:
    recommendation_id: str
    title: str
    suggestion: str
    triggered_by: list[RecommendationTriggerV2] = field(default_factory=list)


@dataclass(frozen=True)
class TailRiskV2:
    global_p99_del_bp: float
    global_cvar99_del_bp: float
    p_any_splice_disruption: float
    p_any_regulatory_hit: float
    p_any_large_del_ge_50bp: float
    p_any_large_del_ge_200bp: float


@dataclass(frozen=True)
class WorstCaseFeatureHitV2:
    type: str
    id: str
    p: float


@dataclass(frozen=True)
class HazardV2:
    status: str
    severity: str | None = None
    reason: str | None = None
    limitations: str | None = None
    p_hits_splice_donor: float | None = None
    p_hits_splice_acceptor: float | None = None
    p_hits_coding_exon: float | None = None
    p_hits_promoter: float | None = None
    p_hits_enhancer: float | None = None
    worst_case_feature_hit: WorstCaseFeatureHitV2 | None = None


@dataclass(frozen=True)
class OffTargetLocusV2:
    chrom: str
    pos: int
    strand: str


@dataclass(frozen=True)
class OffTargetSiteV2:
    locus: OffTargetLocusV2
    mismatches: int
    pam: str
    score: float
    bulge: dict[str, Any] | None = None
    annotation: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class OffTargetBurdenV2:
    status: str
    off_target_mode: str = "policy"
    mode: str = "screening"
    executed_mode: str = "screening"
    provider_id: str = "unconfigured"
    reference_id: str = "unconfigured"
    params: dict[str, Any] = field(default_factory=dict)
    scope: str = ""
    limitations: str = ""
    annotation_computed: bool = False
    severity: str | None = None
    reason: str | None = None
    provider_version: str | None = None
    cache_key: str | None = None
    cache_key_inputs_hash: str | None = None
    cache_hit: bool | None = None
    cache_namespace: str | None = None
    worst_site_score: float | None = None
    sum_score: float | None = None
    p_hits_coding_exon: float | None = None
    p_hits_promoter: float | None = None
    p_hits_enhancer: float | None = None
    p_hits_splice: float | None = None
    top_sites: list[OffTargetSiteV2] | None = None


@dataclass
class _OffTargetCacheEntry:
    result: OffTargetBurdenV2
    provider_version: str
    created_at_unix_s: float


class OffTargetCache:
    def __init__(self, *, max_entries: int = 128) -> None:
        self._max_entries = int(max_entries)
        self._entries: dict[str, _OffTargetCacheEntry] = {}
        self._lru: list[str] = []

    def get(self, key: str, *, provider_version: str) -> OffTargetBurdenV2 | None:
        entry = self._entries.get(key)
        if entry is None:
            return None
        if str(entry.provider_version or "") != str(provider_version or ""):
            self.delete(key)
            return None
        try:
            self._lru.remove(key)
        except ValueError:
            pass
        self._lru.append(key)
        return entry.result

    def put(self, key: str, result: OffTargetBurdenV2, *, provider_version: str) -> None:
        self._entries[key] = _OffTargetCacheEntry(
            result=result,
            provider_version=str(provider_version or ""),
            created_at_unix_s=clock.unix_time_s(),
        )
        try:
            self._lru.remove(key)
        except ValueError:
            pass
        self._lru.append(key)
        while self._max_entries > 0 and len(self._lru) > self._max_entries:
            old = self._lru.pop(0)
            self._entries.pop(old, None)

    def delete(self, key: str) -> None:
        self._entries.pop(key, None)
        try:
            self._lru.remove(key)
        except ValueError:
            pass


_OFFTARGET_CACHE = OffTargetCache()


@dataclass(frozen=True)
class Topology3dV2:
    status: str
    tad_boundary_distance_bp: float | None = None
    p_contact_high_risk_elements: float | None = None
    top_contacts: list[dict[str, Any]] | None = None
    reason: str | None = None


@dataclass(frozen=True)
class RiskV2:
    tail: TailRiskV2
    hazard: HazardV2
    off_target: OffTargetBurdenV2
    structural: StructuralRiskResultV1
    topology_3d: Topology3dV2


@dataclass(frozen=True)
class IntegrityV2:
    failures: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class VerdictV2:
    grade: str
    headline: str
    decision: str
    decision_mode: str
    compliant_with_policy: bool
    noncompliance_reasons: list[str] = field(default_factory=list)
    decision_notes: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class RunSummaryV2:
    run_id: str
    spec_hash: str
    policy_id: str
    policy_hash: str
    decision_mode_requested: str
    decision_mode: str
    validity: dict[str, Any]
    provenance: dict[str, Any]
    intended_edit_spec: dict[str, Any]
    uncertainty: dict[str, Any]
    model_stack: ModelStackV2
    cut_site: CutSiteV2
    outcomes: list[OutcomeV2]
    control: ControlV2
    risk: RiskV2
    integrity: IntegrityV2
    verdict: VerdictV2
    species_detection: dict[str, Any] | None = None
    recommendations: list[RecommendationV2] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        def calibration_to_dict(cal: CalibrationV2) -> dict[str, Any]:
            return {
                "dataset_id": cal.dataset_id,
                "domain": cal.domain,
                "notes": cal.notes,
            }

        def model_to_dict(m: ModelV2) -> dict[str, Any]:
            return {
                "name": m.name,
                "type": m.type,
                "constraints": list(m.constraints),
                "calibration": calibration_to_dict(m.calibration),
            }

        def frameshift_to_dict(fs: FrameshiftV2) -> dict[str, Any]:
            out: dict[str, Any] = {"p": fs.p, "source": fs.source}
            if fs.source != "computed":
                out["reason"] = fs.reason or ""
            return out

        def indel_to_dict(indel: IndelLengthV2) -> dict[str, Any]:
            return {
                "median_bp": indel.median_bp,
                "mean_bp": indel.mean_bp,
                "p90_bp": indel.p90_bp,
                "p95_bp": indel.p95_bp,
                "p99_bp": indel.p99_bp,
                "cvar95_bp": indel.cvar95_bp,
                "cvar99_bp": indel.cvar99_bp,
                "p_ge_10bp": indel.p_ge_10bp,
                "p_ge_50bp": indel.p_ge_50bp,
                "p_ge_200bp": indel.p_ge_200bp,
            }

        def regulatory_to_dict(reg: RegulatoryOverlapV2) -> dict[str, Any]:
            return {
                "p_hits_splice_donor": reg.p_hits_splice_donor,
                "p_hits_splice_acceptor": reg.p_hits_splice_acceptor,
                "p_hits_promoter": reg.p_hits_promoter,
                "p_hits_enhancer": reg.p_hits_enhancer,
                "p_hits_boundary_element": reg.p_hits_boundary_element,
            }

        def worst_to_dict(w: WorstHitV2) -> dict[str, Any]:
            return {"feature_type": w.feature_type, "feature_id": w.feature_id, "p": w.p}

        def outcome_to_dict(oc: OutcomeV2) -> dict[str, Any]:
            return {
                "outcome_id": oc.outcome_id,
                "label": oc.label,
                "p_total": oc.p_total,
                "p_given_cut": oc.p_given_cut,
                "functional_class": oc.functional_class,
                "frameshift": frameshift_to_dict(oc.frameshift),
                "indel_length": indel_to_dict(oc.indel_length),
                "regulatory_overlap": regulatory_to_dict(oc.regulatory_overlap),
                "worst_hit": worst_to_dict(oc.worst_hit),
            }

        def control_to_dict(ctrl: ControlV2) -> dict[str, Any]:
            def convergence_to_dict(conv: ConvergenceV2) -> dict[str, Any]:
                if conv.status != "computed":
                    return {
                        "status": "not_computed",
                        "reason": str(conv.reason or ""),
                        "severity": str(conv.severity or "blocking"),
                    }
                assumptions = conv.assumptions or ConvergenceAssumptionsV2(
                    fitness_intended=1.0,
                    fitness_uncut=1.0,
                    fitness_harmful=0.95,
                    selection_model="relative_fitness",
                    harmful_definition="harmful outcomes + splice hazard + promoter/enhancer hazard",
                )
                init = conv.initial_fractions or ConvergenceInitialFractionsV2(intended_p=0.0, uncut_p=0.0, harmful_p=0.0)
                out: dict[str, Any] = {
                    "status": "computed",
                    "generations": list(conv.generations or []),
                    "assumptions": {
                        "fitness_intended": float(assumptions.fitness_intended),
                        "fitness_uncut": float(assumptions.fitness_uncut),
                        "fitness_harmful": float(assumptions.fitness_harmful),
                        "selection_model": str(assumptions.selection_model or "relative_fitness"),
                        "harmful_definition": str(assumptions.harmful_definition or ""),
                    },
                    "initial_fractions": {
                        "intended_p": float(init.intended_p),
                        "uncut_p": float(init.uncut_p),
                        "harmful_p": float(init.harmful_p),
                    },
                    "escape_risk": float(conv.escape_risk or 0.0),
                    "escape_worst_case_uncut_p_gen20": float(conv.escape_worst_case_uncut_p_gen20 or 0.0),
                    "projected": [
                        {
                            "gen": int(pt.gen),
                            "intended_p": float(pt.intended_p),
                            "uncut_p": float(pt.uncut_p),
                            "harmful_p": float(pt.harmful_p),
                            "escape_risk": float(pt.escape_risk),
                            "escape_condition": str(pt.escape_condition),
                        }
                        for pt in (conv.projected or [])
                    ],
                }
                if assumptions.mixing:
                    out["assumptions"]["mixing"] = str(assumptions.mixing)
                return out

            def stability_to_dict(stab: StabilityV2) -> dict[str, Any]:
                if stab.status != "computed":
                    return {
                        "status": "not_computed",
                        "reason": str(stab.reason or ""),
                        "severity": str(stab.severity or "blocking"),
                        "warnings": list(stab.warnings or []),
                    }
                assumptions = stab.assumptions or StabilityAssumptionsV2(
                    preset_ids_used=[],
                    assumptions_hash="sha256:unknown",
                    off_target_sweep_hash=None,
                )
                ranges = stab.ranges or StabilityRangesV2(
                    grade_min="F",
                    grade_max="F",
                    intended_min=0.0,
                    intended_max=0.0,
                    escape_min=0.0,
                    escape_max=0.0,
                    splice_min=0.0,
                    splice_max=0.0,
                    regulatory_min=0.0,
                    regulatory_max=0.0,
                    off_target_worst_min=0.0,
                    off_target_worst_max=0.0,
                    off_target_coding_min=0.0,
                    off_target_coding_max=0.0,
                )
                out: dict[str, Any] = {
                    "status": "computed",
                    "stability_score": float(stab.stability_score or 0.0),
                    "interpretation": str(stab.interpretation or "low"),
                    "assumptions": {
                        "preset_ids_used": list(assumptions.preset_ids_used or []),
                        "assumptions_hash": str(assumptions.assumptions_hash or "sha256:unknown"),
                        "off_target_sweep_hash": str(assumptions.off_target_sweep_hash or ""),
                    },
                    "ranges": {
                        "grade_min": str(ranges.grade_min or "F"),
                        "grade_max": str(ranges.grade_max or "F"),
                        "intended_min": float(ranges.intended_min),
                        "intended_max": float(ranges.intended_max),
                        "escape_min": float(ranges.escape_min),
                        "escape_max": float(ranges.escape_max),
                        "splice_min": float(ranges.splice_min),
                        "splice_max": float(ranges.splice_max),
                        "regulatory_min": float(ranges.regulatory_min),
                        "regulatory_max": float(ranges.regulatory_max),
                        "off_target_worst_min": float(ranges.off_target_worst_min),
                        "off_target_worst_max": float(ranges.off_target_worst_max),
                        "off_target_coding_min": float(ranges.off_target_coding_min),
                        "off_target_coding_max": float(ranges.off_target_coding_max),
                    },
                    "variants": [
                        {
                            "variant_id": str(v.variant_id),
                            "variant_type": str(v.variant_type),
                            "preset": str(v.preset),
                            "grade": str(v.grade),
                            "intended_p": float(v.intended_p),
                            "dominance_ratio": float(v.dominance_ratio),
                            "entropy_bits": float(v.entropy_bits),
                            "escape_risk": float(v.escape_risk),
                            "splice_risk": float(v.splice_risk),
                            "regulatory_risk": float(v.regulatory_risk),
                            "off_target_params": dict(v.off_target_params or {}),
                            "off_target_status": str(v.off_target_status or ""),
                            "off_target_worst_site_score": float(v.off_target_worst_site_score or 0.0)
                            if v.off_target_worst_site_score is not None
                            else None,
                        }
                        for v in (stab.variants or [])
                    ],
                    "warnings": list(stab.warnings or []),
                }
                return out

            def iteration_to_dict(it: IterationV2) -> dict[str, Any]:
                if it.status != "computed":
                    return {
                        "status": "not_computed",
                        "reason": str(it.reason or ""),
                        "severity": str(it.severity or "warning"),
                        "required": bool(it.required) if it.required is not None else False,
                        "transition_model": str(it.transition_model or "identity"),
                        "transition_required": bool(it.transition_required) if it.transition_required is not None else False,
                    }
                return {
                    "status": "computed",
                    "steps": int(it.steps or 0),
                    "required": bool(it.required) if it.required is not None else False,
                    "transition_model": str(it.transition_model or "identity"),
                    "transition_required": bool(it.transition_required) if it.transition_required is not None else False,
                    "limitations": str(it.limitations or ""),
                    "entropy_joint_bits": list(it.entropy_joint_bits or []),
                    "entropy_class_bits": list(it.entropy_class_bits or []),
                    "kappa_max": list(it.kappa_max or []),
                    "kappa_avg": list(it.kappa_avg or []),
                    "intended": list(it.intended or []),
                    "uncut": list(it.uncut or []),
                    "harmful": list(it.harmful or []),
                    "escape": list(it.escape or []),
                    "hazard_splice": list(it.hazard_splice or []),
                    "hazard_reg": list(it.hazard_reg or []),
                    "kappa_max_overall": float(it.kappa_max_overall or 0.0),
                    "kappa_avg_overall": float(it.kappa_avg_overall or 0.0),
                }

            def claims_to_dict(claims: ClaimsV2 | None) -> dict[str, Any] | None:
                if claims is None:
                    return None
                out: dict[str, Any] = {
                    "status": str(claims.status or "not_computed"),
                    "required": bool(claims.required),
                    "scenario_count": int(claims.scenario_count),
                    "worst_margin": float(claims.worst_margin) if claims.worst_margin is not None else None,
                    "worst_claim_id": str(claims.worst_claim_id or ""),
                    "clean": bool(claims.clean) if claims.clean is not None else None,
                }
                if claims.status != "computed":
                    out["reason"] = str(claims.reason or "")
                    return out
                out["results"] = [
                    {
                        "claim_id": str(r.claim_id),
                        "status": str(r.status),
                        "statement": str(r.statement),
                        "operator": str(r.operator),
                        "threshold": float(r.threshold),
                        "value": float(r.value) if r.value is not None else None,
                        "margin": float(r.margin) if r.margin is not None else None,
                        "scope_steps": int(r.scope_steps) if r.scope_steps is not None else None,
                        "fail_mode": str(r.fail_mode or ""),
                        "triggered_by": list(r.triggered_by or []),
                        "counterexample": r.counterexample if isinstance(r.counterexample, Mapping) else r.counterexample,
                        "notes": str(r.notes or ""),
                    }
                    for r in (claims.results or [])
                ]
                return out

            return {
                "intended_functional_p": ctrl.intended_functional_p,
                "dominance_ratio": ctrl.dominance_ratio,
                "entropy_bits": ctrl.entropy_bits,
                "no_cut_p": ctrl.no_cut_p,
                "flags": list(ctrl.flags),
                "convergence": convergence_to_dict(ctrl.convergence),
                "stability": stability_to_dict(ctrl.stability),
                "iteration": iteration_to_dict(ctrl.iteration),
                "claims": claims_to_dict(ctrl.claims),
            }

        def offtarget_to_dict(off: OffTargetBurdenV2) -> dict[str, Any]:
            out: dict[str, Any] = {
                "status": "computed" if off.status == "computed" else "not_computed",
                "off_target_mode": str(off.off_target_mode or "policy"),
                "mode": str(off.mode or "screening"),
                "executed_mode": str(off.executed_mode or off.mode or "screening"),
                "provider_id": str(off.provider_id or ""),
                "reference_id": str(off.reference_id or ""),
                "params": dict(off.params or {}),
                "scope": str(off.scope or ""),
                "limitations": str(off.limitations or ""),
                "annotation_computed": bool(off.annotation_computed),
            }
            if off.provider_version:
                out["provider_version"] = str(off.provider_version)
            if off.cache_key:
                out["cache_key"] = str(off.cache_key)
            if off.cache_key_inputs_hash:
                out["cache_key_inputs_hash"] = str(off.cache_key_inputs_hash)
            if off.cache_hit is not None:
                out["cache_hit"] = bool(off.cache_hit)
            if off.cache_namespace:
                out["cache_namespace"] = str(off.cache_namespace)
            out.setdefault("top_sites", list(off.top_sites or []))

            if off.status != "computed":
                out["reason"] = str(off.reason or "")
                out["severity"] = str(off.severity or "blocking")
                return out

            out.update(
                {
                    "worst_site_score": float(off.worst_site_score or 0.0),
                    "sum_score": float(off.sum_score or 0.0),
                    "p_hits_coding_exon": float(off.p_hits_coding_exon or 0.0),
                    "p_hits_promoter": float(off.p_hits_promoter or 0.0),
                    "p_hits_enhancer": float(off.p_hits_enhancer or 0.0),
                    "p_hits_splice": float(off.p_hits_splice or 0.0),
                    "top_sites": [
                        {
                            "locus": {"chrom": s.locus.chrom, "pos": int(s.locus.pos), "strand": str(s.locus.strand)},
                            "mismatches": int(s.mismatches),
                            "bulge": dict(s.bulge) if isinstance(s.bulge, Mapping) else None,
                            "pam": str(s.pam or ""),
                            "score": float(s.score),
                            "annotation": dict(s.annotation or {}),
                        }
                        for s in (off.top_sites or [])
                    ],
                }
            )
            return out

        def topology_to_dict(t: Topology3dV2) -> dict[str, Any]:
            if t.status != "computed":
                return {"status": "not_computed", "reason": str(t.reason or "")}
            return {
                "status": "computed",
                "tad_boundary_distance_bp": float(t.tad_boundary_distance_bp or 0.0),
                "p_contact_high_risk_elements": float(t.p_contact_high_risk_elements or 0.0),
                "top_contacts": list(t.top_contacts or []),
            }

        def hazard_to_dict(h: HazardV2) -> dict[str, Any]:
            if h.status != "computed":
                return {
                    "status": "not_computed",
                    "reason": str(h.reason or ""),
                    "severity": str(h.severity or "blocking"),
                }
            out: dict[str, Any] = {
                "status": "computed",
                "p_hits_splice_donor": float(h.p_hits_splice_donor or 0.0),
                "p_hits_splice_acceptor": float(h.p_hits_splice_acceptor or 0.0),
                "p_hits_coding_exon": float(h.p_hits_coding_exon or 0.0),
                "p_hits_promoter": float(h.p_hits_promoter or 0.0),
                "p_hits_enhancer": float(h.p_hits_enhancer or 0.0),
            }
            if h.worst_case_feature_hit is not None:
                out["worst_case_feature_hit"] = {
                    "type": str(h.worst_case_feature_hit.type),
                    "id": str(h.worst_case_feature_hit.id),
                    "p": float(h.worst_case_feature_hit.p),
                }
            if h.limitations:
                out["limitations"] = str(h.limitations)
            return out

        def risk_to_dict(r: RiskV2) -> dict[str, Any]:
            return {
                "tail": {
                    "global_p99_del_bp": r.tail.global_p99_del_bp,
                    "global_cvar99_del_bp": r.tail.global_cvar99_del_bp,
                    "p_any_splice_disruption": r.tail.p_any_splice_disruption,
                    "p_any_regulatory_hit": r.tail.p_any_regulatory_hit,
                    "p_any_large_del_ge_50bp": r.tail.p_any_large_del_ge_50bp,
                    "p_any_large_del_ge_200bp": r.tail.p_any_large_del_ge_200bp,
                },
                "hazard": hazard_to_dict(r.hazard),
                "off_target": offtarget_to_dict(r.off_target),
                "structural": dict(r.structural.to_dict() if hasattr(r.structural, "to_dict") else r.structural),
                "topology_3d": topology_to_dict(r.topology_3d),
            }

        def recommendations_to_dict(items: Sequence[RecommendationV2]) -> list[dict[str, Any]]:
            out: list[dict[str, Any]] = []
            for rec in items:
                triggers: list[dict[str, Any]] = []
                for t in rec.triggered_by or []:
                    value = t.value
                    if isinstance(value, (int, float, str, bool)) or value is None:
                        pass
                    else:
                        value = str(value)
                    triggers.append(
                        {
                            "metric_path": str(t.metric_path),
                            "condition": str(t.condition),
                            "value": value,
                        }
                    )
                out.append(
                    {
                        "recommendation_id": str(rec.recommendation_id),
                        "title": str(rec.title),
                        "suggestion": str(rec.suggestion),
                        "triggered_by": triggers,
                    }
                )
            return out

        return {
            "run_id": self.run_id,
            "spec_hash": self.spec_hash,
            "policy_id": self.policy_id,
            "policy_hash": self.policy_hash,
            "decision_mode_requested": str(self.decision_mode_requested),
            "decision_mode": str(self.decision_mode),
            "validity": dict(self.validity or {}),
            "provenance": dict(self.provenance or {}),
            "intended_edit_spec": dict(self.intended_edit_spec or {}),
            "uncertainty": dict(self.uncertainty or {}),
            "species_detection": dict(self.species_detection) if isinstance(self.species_detection, Mapping) else None,
            "model_stack": {
                "repair_model": model_to_dict(self.model_stack.repair_model),
                "off_target_model": model_to_dict(self.model_stack.off_target_model),
            },
            "cut_site": {"chrom": self.cut_site.chrom, "pos": self.cut_site.pos, "strand": self.cut_site.strand},
            "outcomes": [outcome_to_dict(o) for o in self.outcomes],
            "control": control_to_dict(self.control),
            "risk": risk_to_dict(self.risk),
            "integrity": {"failures": list(self.integrity.failures), "warnings": list(self.integrity.warnings)},
            "verdict": {
                "grade": self.verdict.grade,
                "headline": self.verdict.headline,
                "decision": str(self.verdict.decision),
                "decision_mode": str(self.verdict.decision_mode),
                "compliant_with_policy": bool(self.verdict.compliant_with_policy),
                "noncompliance_reasons": list(self.verdict.noncompliance_reasons),
                "decision_notes": list(self.verdict.decision_notes),
            },
            "recommendations": recommendations_to_dict(self.recommendations),
        }


__all__ = [
    "HEADLINE_BY_GRADE",
    "RunSummaryV2",
    "build_run_summary_v2_from_snapshot",
    "repair_model_ui_label",
    "top_outcome_ui_label",
    "validate_run_summary_v2",
]


def _infer_cut_site(
    state: Mapping[str, Any],
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
) -> CutSiteV2:
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    chrom = str(locus.get("chr") or "")
    strand_raw = str(locus.get("strand") or "+")

    config = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    guide = config.get("guide") if isinstance(config.get("guide"), Mapping) else {}
    viz = state.get("viz_spec_payload") if isinstance(state.get("viz_spec_payload"), Mapping) else {}
    site = viz.get("site") if isinstance(viz.get("site"), Mapping) else {}
    if not chrom:
        chrom = str(site.get("chrom") or guide.get("chrom") or guide.get("chr") or guide.get("contig") or "") or "unknown"

    if strand_raw not in {"+", "-"}:
        strand_raw = str(guide.get("strand") or "+")
    strand = "minus" if strand_raw == "-" else "plus"

    cut_index = None
    for key in ("cut_index", "cutIndex"):
        if key in guide:
            cut_index = _maybe_int(guide.get(key))
            break
    if cut_index is None:
        pam_index = guide.get("pam_index", guide.get("pamIndex"))
        if pam_index is not None:
            cut_index = _safe_int(pam_index, default=0) - 3
    if cut_index is None:
        cut_index = _safe_int(state.get("cut_index", state.get("cutIndex")), default=0)

    base_start = None
    if isinstance(site, Mapping) and site.get("start") is not None:
        base_start = _maybe_int(site.get("start"))
    if base_start is None:
        base_start = _safe_int(locus.get("start"), default=0)
    pos = int(base_start + int(cut_index or 0))
    return CutSiteV2(chrom=str(chrom), pos=int(pos), strand=strand)


def _infer_indel_len_dist(
    *,
    label: str,
    delta_bp: int,
    priors: Mapping[str, Any] | None,
) -> dict[int, float]:
    if _is_no_cut_label(label) or delta_bp == 0:
        return {0: 1.0}
    if isinstance(priors, Mapping) and label in priors and isinstance(priors.get(label), Mapping):
        cfg = priors.get(label)
        min_len = _safe_int(cfg.get("min"), default=abs(delta_bp))
        max_len = _safe_int(cfg.get("max"), default=abs(delta_bp))
        return _uniform_int_dist(min_len, max_len)
    return {abs(int(delta_bp)): 1.0}


def _indel_length_summary(dist: Mapping[int, float]) -> IndelLengthV2:
    mean = _mean_discrete(dist)
    return IndelLengthV2(
        median_bp=_quantile_discrete(dist, 0.5),
        mean_bp=mean,
        p90_bp=_quantile_discrete(dist, 0.90),
        p95_bp=_quantile_discrete(dist, 0.95),
        p99_bp=_quantile_discrete(dist, 0.99),
        cvar95_bp=_cvar_discrete(dist, 0.95),
        cvar99_bp=_cvar_discrete(dist, 0.99),
        p_ge_10bp=_clamp01(_p_ge(dist, 10)),
        p_ge_50bp=_clamp01(_p_ge(dist, 50)),
        p_ge_200bp=_clamp01(_p_ge(dist, 200)),
    )


@dataclass(frozen=True)
class _TranscriptHazardAnnotation:
    transcript_id: str
    name: str
    strand: str
    cds_start: int
    cds_end: int
    exons: list[tuple[int, int]]


@dataclass(frozen=True)
class _FeatureInterval0:
    feature_type: str
    feature_id: str
    start0: int
    end0: int


def _infer_window_start_bp(state: Mapping[str, Any], experiment_spec: Mapping[str, Any] | None) -> int | None:
    viz = state.get("viz_spec_payload") if isinstance(state.get("viz_spec_payload"), Mapping) else {}
    site = viz.get("site") if isinstance(viz.get("site"), Mapping) else {}
    if site.get("start") is not None:
        return _maybe_int(site.get("start"))
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    if locus.get("start") is not None:
        return _maybe_int(locus.get("start"))
    return None


def _parse_exons_1based(exons_raw: Any) -> list[tuple[int, int]]:
    exons: list[tuple[int, int]] = []
    if isinstance(exons_raw, list):
        for item in exons_raw:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                try:
                    a = int(item[0])
                    b = int(item[1])
                except Exception:
                    continue
                s = min(a, b)
                e = max(a, b)
                if s > 0 and e >= s:
                    exons.append((s, e))
            elif isinstance(item, Mapping):
                start = _maybe_int(item.get("start"))
                end = _maybe_int(item.get("end"))
                if start is None or end is None:
                    continue
                s = min(start, end)
                e = max(start, end)
                if s > 0 and e >= s:
                    exons.append((s, e))
        return exons
    if isinstance(exons_raw, str) and exons_raw.strip():
        text = exons_raw.strip()
        for token in [t.strip() for t in text.replace(";", ",").split(",") if t.strip()]:
            if "-" in token:
                parts = token.split("-", 1)
            elif ".." in token:
                parts = token.split("..", 1)
            else:
                continue
            try:
                a = int(parts[0].strip())
                b = int(parts[1].strip())
            except Exception:
                continue
            s = min(a, b)
            e = max(a, b)
            if s > 0 and e >= s:
                exons.append((s, e))
    return exons


def _load_transcripts_for_hazard(
    state: Mapping[str, Any],
    experiment_spec: Mapping[str, Any] | None,
) -> tuple[list[_TranscriptHazardAnnotation], str | None]:
    annotations = state.get("annotations")
    if not isinstance(annotations, Mapping):
        annotations = state.get("annotation") if isinstance(state.get("annotation"), Mapping) else {}
    tx_raw = annotations.get("transcripts") if isinstance(annotations.get("transcripts"), list) else None

    transcripts: list[_TranscriptHazardAnnotation] = []
    if isinstance(tx_raw, list):
        for idx, tx in enumerate(tx_raw):
            if not isinstance(tx, Mapping):
                continue
            tid = str(tx.get("id") or tx.get("transcript_id") or tx.get("transcriptId") or tx.get("name") or f"TX{idx+1}")
            name = str(tx.get("name") or tid)
            strand_raw = str(tx.get("strand") or "+").strip()
            strand = "-" if strand_raw in {"-", "minus"} else "+"
            cds_start = _maybe_int(tx.get("cds_start") if tx.get("cds_start") is not None else tx.get("cdsStart"))
            cds_end = _maybe_int(tx.get("cds_end") if tx.get("cds_end") is not None else tx.get("cdsEnd"))
            exons = _parse_exons_1based(tx.get("exons"))
            if not cds_start or not cds_end or cds_end < cds_start or not exons:
                continue
            transcripts.append(
                _TranscriptHazardAnnotation(
                    transcript_id=tid,
                    name=name,
                    strand=strand,
                    cds_start=int(cds_start),
                    cds_end=int(cds_end),
                    exons=exons,
                )
            )

    if not transcripts:
        spec = experiment_spec_to_dict(experiment_spec)
        coding = spec.get("coding") if isinstance(spec.get("coding"), Mapping) else {}
        if isinstance(coding, Mapping) and coding:
            cds_start = _maybe_int(coding.get("cds_start"))
            cds_end = _maybe_int(coding.get("cds_end"))
            exons = _parse_exons_1based(coding.get("exons") or coding.get("exon_intervals"))
            strand_raw = str(coding.get("strand") or "+").strip()
            strand = "-" if strand_raw in {"-", "minus"} else "+"
            tid = str(coding.get("id") or coding.get("transcript_id") or coding.get("name") or "TX1")
            name = str(coding.get("name") or tid)
            if cds_start and cds_end and cds_end >= cds_start and exons:
                transcripts.append(
                    _TranscriptHazardAnnotation(
                        transcript_id=tid,
                        name=name,
                        strand=strand,
                        cds_start=int(cds_start),
                        cds_end=int(cds_end),
                        exons=exons,
                    )
                )

    if not transcripts:
        return [], "transcript models not available"
    return transcripts, None


def _load_regulatory_features_for_hazard(
    state: Mapping[str, Any],
) -> tuple[list[_FeatureInterval0], list[_FeatureInterval0], str | None]:
    annotations = state.get("annotations")
    if not isinstance(annotations, Mapping):
        annotations = state.get("annotation") if isinstance(state.get("annotation"), Mapping) else {}
    regulatory = annotations.get("regulatory") if isinstance(annotations.get("regulatory"), Mapping) else {}
    promoter_key = "promoters" if "promoters" in regulatory else ("promoter" if "promoter" in regulatory else None)
    enhancer_key = "enhancers" if "enhancers" in regulatory else ("enhancer" if "enhancer" in regulatory else None)
    promoters_raw = regulatory.get(promoter_key) if promoter_key else None
    enhancers_raw = regulatory.get(enhancer_key) if enhancer_key else None
    if not isinstance(promoters_raw, list) or not isinstance(enhancers_raw, list):
        return [], [], "regulatory tracks not available (promoters/enhancers missing)"

    promoters: list[_FeatureInterval0] = []
    enhancers: list[_FeatureInterval0] = []

    def parse_track(items: Any, feature_type: str) -> list[_FeatureInterval0]:
        out: list[_FeatureInterval0] = []
        if not isinstance(items, list):
            return out
        for idx, item in enumerate(items):
            if not isinstance(item, Mapping):
                continue
            fid = str(item.get("id") or item.get("name") or f"{feature_type}_{idx+1}")
            start = _maybe_int(item.get("start"))
            end = _maybe_int(item.get("end"))
            if start is None or end is None:
                continue
            s = min(int(start), int(end))
            e = max(int(start), int(end))
            if s <= 0 or e < s:
                continue
            out.append(_FeatureInterval0(feature_type=feature_type, feature_id=fid, start0=s - 1, end0=e))
        return out

    promoters = parse_track(promoters_raw, "promoter")
    enhancers = parse_track(enhancers_raw, "enhancer")
    return promoters, enhancers, None


def _intervals_overlap(a_start: int, a_end: int, b_start: int, b_end: int) -> bool:
    return int(a_start) < int(b_end) and int(b_start) < int(a_end)


def _compute_hazard(
    *,
    state: Mapping[str, Any],
    experiment_spec: Mapping[str, Any] | None,
    cut_p: float,
    pending_outcomes: Sequence[Mapping[str, Any]],
) -> tuple[HazardV2, float | None, float | None]:
    transcripts, tx_reason = _load_transcripts_for_hazard(state, experiment_spec)
    if not transcripts:
        return (
            HazardV2(
                status="not_computed",
                severity="blocking",
                reason=tx_reason or "transcript models not available",
            ),
            None,
            None,
        )

    promoters, enhancers, reg_reason = _load_regulatory_features_for_hazard(state)
    if reg_reason:
        return (
            HazardV2(
                status="not_computed",
                severity="blocking",
                reason=reg_reason,
            ),
            None,
            None,
        )

    donors: list[_FeatureInterval0] = []
    acceptors: list[_FeatureInterval0] = []
    coding_exons: list[_FeatureInterval0] = []

    for tx in transcripts:
        ex0 = sorted(((s - 1, e) for s, e in tx.exons if s > 0 and e >= s), key=lambda x: x[0])
        if not ex0:
            continue
        cds0_start = int(tx.cds_start) - 1
        cds0_end = int(tx.cds_end)
        if cds0_end <= cds0_start:
            continue
        tx_order = list(ex0) if tx.strand == "+" else list(reversed(ex0))

        for i, (s0, e0) in enumerate(tx_order):
            if i < len(tx_order) - 1:
                boundary = int(e0) if tx.strand == "+" else int(s0)
                donors.append(
                    _FeatureInterval0(
                        feature_type="splice_donor",
                        feature_id=f"{tx.transcript_id}:donor:{i+1}",
                        start0=boundary - HAZARD_SPLICE_WINDOW_BP,
                        end0=boundary + HAZARD_SPLICE_WINDOW_BP,
                    )
                )
            if i > 0:
                boundary = int(s0) if tx.strand == "+" else int(e0)
                acceptors.append(
                    _FeatureInterval0(
                        feature_type="splice_acceptor",
                        feature_id=f"{tx.transcript_id}:acceptor:{i+1}",
                        start0=boundary - HAZARD_SPLICE_WINDOW_BP,
                        end0=boundary + HAZARD_SPLICE_WINDOW_BP,
                    )
                )

        for j, (s0, e0) in enumerate(ex0):
            s = max(int(s0), int(cds0_start))
            e = min(int(e0), int(cds0_end))
            if e > s:
                coding_exons.append(
                    _FeatureInterval0(
                        feature_type="coding_exon",
                        feature_id=f"{tx.transcript_id}:coding_exon:{j+1}",
                        start0=s,
                        end0=e,
                    )
                )

    if not (donors or acceptors or coding_exons):
        return (
            HazardV2(
                status="not_computed",
                severity="blocking",
                reason="transcript models incomplete: exons/CDS missing",
            ),
            None,
            None,
        )

    p_splice_donor = 0.0
    p_splice_acceptor = 0.0
    p_coding = 0.0
    p_promoter = 0.0
    p_enhancer = 0.0
    p_any_splice = 0.0
    p_any_reg = 0.0

    feature_priority = {
        "splice_donor": 0,
        "splice_acceptor": 1,
        "coding_exon": 2,
        "promoter": 3,
        "enhancer": 4,
    }
    per_feature_mass: dict[tuple[str, str], float] = {}

    for oc in pending_outcomes:
        start0 = _maybe_int(oc.get("edit_start0"))
        end0 = _maybe_int(oc.get("edit_end0"))
        if start0 is None or end0 is None:
            continue
        if end0 <= start0:
            end0 = start0 + 1
        p_total = _safe_float(oc.get("p_total"), default=0.0)
        if p_total <= 0.0:
            continue

        hit_donor_features = [f for f in donors if _intervals_overlap(start0, end0, f.start0, f.end0)]
        hit_acceptor_features = [f for f in acceptors if _intervals_overlap(start0, end0, f.start0, f.end0)]
        hit_coding_features = [f for f in coding_exons if _intervals_overlap(start0, end0, f.start0, f.end0)]
        hit_promoter_features = [f for f in promoters if _intervals_overlap(start0, end0, f.start0, f.end0)]
        hit_enhancer_features = [f for f in enhancers if _intervals_overlap(start0, end0, f.start0, f.end0)]

        hit_donor = bool(hit_donor_features)
        hit_acceptor = bool(hit_acceptor_features)
        hit_coding = bool(hit_coding_features)
        hit_promoter = bool(hit_promoter_features)
        hit_enhancer = bool(hit_enhancer_features)

        if hit_donor:
            p_splice_donor += p_total
        if hit_acceptor:
            p_splice_acceptor += p_total
        if hit_coding:
            p_coding += p_total
        if hit_promoter:
            p_promoter += p_total
        if hit_enhancer:
            p_enhancer += p_total

        any_splice = hit_donor or hit_acceptor
        any_reg = any_splice or hit_promoter or hit_enhancer
        if any_splice:
            p_any_splice += p_total
        if any_reg:
            p_any_reg += p_total

        hit_features: list[_FeatureInterval0] = []
        hit_features.extend(hit_donor_features)
        hit_features.extend(hit_acceptor_features)
        hit_features.extend(hit_coding_features)
        hit_features.extend(hit_promoter_features)
        hit_features.extend(hit_enhancer_features)
        for f in hit_features:
            key = (str(f.feature_type), str(f.feature_id))
            per_feature_mass[key] = per_feature_mass.get(key, 0.0) + float(p_total)

    worst = WorstCaseFeatureHitV2(type="none", id="no_feature_hit", p=0.0)
    if per_feature_mass:
        best_key = None
        for key, mass in per_feature_mass.items():
            if best_key is None:
                best_key = key
                continue
            cur_mass = float(per_feature_mass.get(best_key, 0.0))
            if float(mass) > cur_mass:
                best_key = key
            elif float(mass) == cur_mass:
                cand_type, cand_id = key
                cur_type, cur_id = best_key
                cand_pri = feature_priority.get(cand_type, 99)
                cur_pri = feature_priority.get(cur_type, 99)
                if cand_pri < cur_pri or (cand_pri == cur_pri and cand_id < cur_id):
                    best_key = key
        assert best_key is not None
        worst_type, worst_id = best_key
        worst = WorstCaseFeatureHitV2(type=worst_type, id=worst_id, p=_clamp01(float(per_feature_mass[best_key])))

    hazard = HazardV2(
        status="computed",
        severity=None,
        reason=None,
        limitations=f"Deterministic interval overlap in locus window (splice windows ±{HAZARD_SPLICE_WINDOW_BP}bp).",
        p_hits_splice_donor=_clamp01(p_splice_donor),
        p_hits_splice_acceptor=_clamp01(p_splice_acceptor),
        p_hits_coding_exon=_clamp01(p_coding),
        p_hits_promoter=_clamp01(p_promoter),
        p_hits_enhancer=_clamp01(p_enhancer),
        worst_case_feature_hit=worst,
    )
    return hazard, _clamp01(p_any_splice), _clamp01(p_any_reg)


def _compute_convergence(
    *,
    policy_payload: Mapping[str, Any],
    intended_p: float,
    uncut_p: float,
    harmful_p: float,
) -> ConvergenceV2:
    cfg = _resolve_convergence_policy(policy_payload)
    severity = "blocking" if bool(cfg.get("required")) else "warning"
    if not bool(cfg.get("enabled")):
        return ConvergenceV2(
            status="not_computed",
            reason="convergence projection disabled by policy",
            severity=severity,
        )

    gens = list(cfg.get("generations") or [5, 10, 20])
    if 20 not in gens:
        gens.append(20)
    gens = list(sorted(set(int(g) for g in gens if isinstance(g, int) and g >= 0)))

    start_intended = _clamp01(float(intended_p))
    start_uncut = _clamp01(float(uncut_p))
    start_harmful = _clamp01(float(harmful_p))
    total = start_intended + start_uncut + start_harmful
    if total <= 0.0:
        start_intended = 0.0
        start_uncut = 0.0
        start_harmful = 0.0
    elif abs(total - 1.0) > 1e-9:
        start_intended /= total
        start_uncut /= total
        start_harmful /= total

    initial = ConvergenceInitialFractionsV2(
        intended_p=_clamp01(start_intended),
        uncut_p=_clamp01(start_uncut),
        harmful_p=_clamp01(start_harmful),
    )

    grid = cfg.get("fitness_grid") if isinstance(cfg.get("fitness_grid"), Mapping) else {}
    f_intended = grid.get("fitness_intended") if isinstance(grid.get("fitness_intended"), list) else [1.0]
    f_uncut = grid.get("fitness_uncut") if isinstance(grid.get("fitness_uncut"), list) else [1.0]
    f_harm = grid.get("fitness_harmful") if isinstance(grid.get("fitness_harmful"), list) else [0.95]
    scenarios: list[tuple[float, float, float]] = []
    for fi in f_intended:
        for fu in f_uncut:
            for fh in f_harm:
                if not (isinstance(fi, (int, float)) and isinstance(fu, (int, float)) and isinstance(fh, (int, float))):
                    continue
                scenarios.append((float(fi), float(fu), float(fh)))
    if not scenarios:
        scenarios = [(1.0, 1.0, 0.95)]

    selection_model = str(cfg.get("selection_model") or "relative_fitness")
    if selection_model not in CONVERGENCE_SELECTION_MODEL_VALUES:
        selection_model = "relative_fitness"

    def _project_to_gen(fi: float, fu: float, fh: float, gen: int) -> tuple[float, float, float]:
        i = float(initial.intended_p)
        u = float(initial.uncut_p)
        h = float(initial.harmful_p)
        if selection_model == "neutral" or gen <= 0:
            return i, u, h
        f_i = max(0.0, float(fi)) if math.isfinite(float(fi)) else 0.0
        f_u = max(0.0, float(fu)) if math.isfinite(float(fu)) else 0.0
        f_h = max(0.0, float(fh)) if math.isfinite(float(fh)) else 0.0
        for _ in range(int(gen)):
            w_i = i * f_i
            w_u = u * f_u
            w_h = h * f_h
            denom = w_i + w_u + w_h
            if denom <= 0.0:
                break
            i, u, h = w_i / denom, w_u / denom, w_h / denom
        return _clamp01(i), _clamp01(u), _clamp01(h)

    escape_hits = 0
    best = None
    for fi, fu, fh in scenarios:
        _, u20, _ = _project_to_gen(fi, fu, fh, 20)
        if u20 > 0.5:
            escape_hits += 1
        key = (float(u20), float(fu), -float(fi), -float(fh))
        if best is None or key > best[0]:
            best = (key, (fi, fu, fh), u20)
    if best is None:
        best = ((float(initial.uncut_p), 1.0, -1.0, -0.95), (1.0, 1.0, 0.95), float(initial.uncut_p))

    escape_risk = float(escape_hits) / float(len(scenarios)) if scenarios else 0.0
    (fi_best, fu_best, fh_best) = best[1]
    worst_uncut20 = float(best[2])

    preset = str(cfg.get("preset") or "conservative")
    escape_condition = f"preset={preset}; worst_case(f_intended={fi_best:.3f}, f_uncut={fu_best:.3f}, f_harmful={fh_best:.3f})"

    max_gen = max(gens) if gens else 0
    gens_set = set(gens)
    proj: dict[int, tuple[float, float, float]] = {}
    i = float(initial.intended_p)
    u = float(initial.uncut_p)
    h = float(initial.harmful_p)
    proj[0] = (i, u, h)
    if selection_model != "neutral":
        f_i = max(0.0, float(fi_best)) if math.isfinite(float(fi_best)) else 0.0
        f_u = max(0.0, float(fu_best)) if math.isfinite(float(fu_best)) else 0.0
        f_h = max(0.0, float(fh_best)) if math.isfinite(float(fh_best)) else 0.0
        for t in range(1, max(0, max_gen) + 1):
            w_i = i * f_i
            w_u = u * f_u
            w_h = h * f_h
            denom = w_i + w_u + w_h
            if denom <= 0.0:
                break
            i, u, h = w_i / denom, w_u / denom, w_h / denom
            if t in gens_set:
                proj[int(t)] = (_clamp01(i), _clamp01(u), _clamp01(h))
    for g in gens:
        if g not in proj:
            proj[g] = (_clamp01(initial.intended_p), _clamp01(initial.uncut_p), _clamp01(initial.harmful_p))

    points = [
        ConvergenceProjectionPointV2(
            gen=int(g),
            intended_p=float(proj[g][0]),
            uncut_p=float(proj[g][1]),
            harmful_p=float(proj[g][2]),
            escape_risk=_clamp01(escape_risk),
            escape_condition=escape_condition,
        )
        for g in gens
    ]

    assumptions = ConvergenceAssumptionsV2(
        fitness_intended=float(fi_best),
        fitness_uncut=float(fu_best),
        fitness_harmful=float(fh_best),
        selection_model=selection_model,
        harmful_definition="harmful outcomes + splice hazard + promoter/enhancer hazard",
        mixing=str(cfg.get("mixing") or "well_mixed"),
    )
    return ConvergenceV2(
        status="computed",
        generations=list(gens),
        assumptions=assumptions,
        initial_fractions=initial,
        projected=points,
        escape_risk=_clamp01(escape_risk),
        escape_worst_case_uncut_p_gen20=_clamp01(worst_uncut20),
        reason=None,
        severity=None,
    )


def _compute_iteration_and_claims(
    *,
    policy_payload: Mapping[str, Any],
    intended_p: float,
    uncut_p: float,
    harmful_p: float,
    hazard_splice_mass: float,
    hazard_reg_mass: float,
    cut_p: float,
) -> tuple[IterationV2, ClaimsV2 | None, list[str]]:
    enabled, required, claims_required, stress_policy = _resolve_iteration_policy(policy_payload)
    noncompliance: list[str] = []
    severity = "blocking" if required else "warning"
    if not enabled:
        iteration = IterationV2(
            status="not_computed",
            reason="iteration disabled by policy",
            severity=severity,
            required=required,
            transition_model=stress_policy.transition_model,
            transition_required=stress_policy.transition_required,
        )
        if required:
            noncompliance.append("iteration_required_but_not_computed")
        return iteration, None, noncompliance

    base_cut = max(0.0, float(cut_p))
    base_intended_given_cut = (float(intended_p) / base_cut) if base_cut > 0.0 else 0.0
    base_harmful_given_cut = (float(harmful_p) / base_cut) if base_cut > 0.0 else 0.0
    class_marginal = [float(intended_p), float(uncut_p), float(harmful_p)]
    hazard_ratios: tuple[float, float] | None = None
    if float(harmful_p) > 0.0:
        hazard_ratios = (
            _clamp01(float(hazard_splice_mass) / float(harmful_p)),
            _clamp01(float(hazard_reg_mass) / float(harmful_p)),
        )

    scenarios = build_scenarios(
        state_bins=default_state_bins(),
        class_marginal=class_marginal,
        base_cut_p=base_cut,
        base_intended_given_cut=base_intended_given_cut,
        base_harmful_given_cut=base_harmful_given_cut,
        policy=stress_policy,
        hazard_ratios=hazard_ratios,
    )
    if not scenarios:
        iteration = IterationV2(
            status="not_computed",
            reason="no iteration scenarios configured",
            severity=severity,
            required=required,
            transition_model=stress_policy.transition_model,
            transition_required=stress_policy.transition_required,
        )
        if required:
            noncompliance.append("iteration_required_but_not_computed")
        return iteration, None, noncompliance

    baseline_trace = scenarios[0].run()
    limitations = ""
    if stress_policy.transition_model == "identity":
        limitations = "Transition operator is identity; perturbation propagation not modeled."
        if stress_policy.transition_required:
            noncompliance.append("transition_required_but_identity")

    kappa_max_overall = max(baseline_trace.kappa_max) if baseline_trace.kappa_max else 0.0
    kappa_avg_overall = max(baseline_trace.kappa_avg) if baseline_trace.kappa_avg else 0.0
    iteration = IterationV2(
        status="computed",
        steps=int(stress_policy.steps),
        required=required,
        transition_model=stress_policy.transition_model,
        transition_required=stress_policy.transition_required,
        limitations=limitations,
        entropy_joint_bits=list(baseline_trace.entropy_joint_bits),
        entropy_class_bits=list(baseline_trace.entropy_class_bits),
        kappa_max=list(baseline_trace.kappa_max),
        kappa_avg=list(baseline_trace.kappa_avg),
        intended=list(baseline_trace.intended),
        uncut=list(baseline_trace.uncut),
        harmful=list(baseline_trace.harmful),
        escape=list(baseline_trace.escape),
        hazard_splice=list(baseline_trace.hazard_splice or []),
        hazard_reg=list(baseline_trace.hazard_reg or []),
        kappa_max_overall=float(kappa_max_overall),
        kappa_avg_overall=float(kappa_avg_overall),
    )

    claims_summary = evaluate_claims(
        scenarios=scenarios,
        claims=default_claims(steps=int(stress_policy.steps)),
        summary={},
    )
    clean = all(r.status == "passed" for r in claims_summary.results if r.status != "skipped")
    claims_v2 = ClaimsV2(
        status=str(claims_summary.status),
        required=bool(claims_required),
        scenario_count=int(claims_summary.scenario_count),
        results=[
            ClaimResultV2(
                claim_id=str(r.claim_id),
                status=str(r.status),
                statement=str(r.statement),
                operator=str(r.operator),
                threshold=float(r.threshold),
                value=float(r.value) if r.value is not None else None,
                margin=float(r.margin) if r.margin is not None else None,
                scope_steps=int(r.scope_steps) if r.scope_steps is not None else None,
                fail_mode=str(r.fail_mode or ""),
                triggered_by=list(r.triggered_by or []),
                counterexample=r.counterexample if isinstance(r.counterexample, Mapping) else r.counterexample,
                notes=str(r.notes or ""),
            )
            for r in (claims_summary.results or [])
        ],
        worst_margin=float(claims_summary.worst_margin) if claims_summary.worst_margin is not None else None,
        worst_claim_id=str(claims_summary.worst_claim_id or ""),
        clean=bool(clean),
        reason=str(claims_summary.reason or ""),
    )
    if claims_required and not clean:
        noncompliance.append("claims_failed")

    return iteration, claims_v2, noncompliance


def _compute_stability(
    *,
    policy_payload: Mapping[str, Any],
    control: ControlV2,
    risk: RiskV2,
    integrity: IntegrityV2,
    compliant_with_policy: bool,
    noncompliance_reasons: Sequence[str],
) -> StabilityV2:
    cfg = _resolve_stability_policy(policy_payload)
    severity = "blocking" if bool(cfg.get("required")) else "warning"
    if not bool(cfg.get("enabled")):
        return StabilityV2(status="not_computed", reason="stability disabled by policy", severity=severity)
    if control.convergence.status != "computed":
        return StabilityV2(status="not_computed", reason="stability requires convergence projection", severity=severity)
    conv = control.convergence
    init = conv.initial_fractions
    if init is None:
        return StabilityV2(status="not_computed", reason="stability requires convergence.initial_fractions", severity=severity)

    gens = list(conv.generations or [5, 10, 20])
    if 20 not in gens:
        gens.append(20)
    gens = list(sorted(set(int(g) for g in gens if isinstance(g, int) and g >= 0)))
    mixing = None
    try:
        mixing = conv.assumptions.mixing if conv.assumptions is not None else None
    except Exception:
        mixing = None

    presets = cfg.get("presets") if isinstance(cfg.get("presets"), list) else ["conservative", "neutral", "optimistic"]
    presets = [str(p).strip().lower() for p in presets if isinstance(p, str)]
    presets = [p for p in presets if p in {"conservative", "neutral", "optimistic"}]
    if not presets:
        presets = ["conservative", "neutral", "optimistic"]
    presets = list(dict.fromkeys(presets))

    grade_order = {"F": 0, "D": 1, "C": 2, "B": 3, "A": 4}
    variants: list[StabilityVariantV2] = []
    stability_warnings: list[str] = []
    resolved_convergence_by_preset: dict[str, Any] = {}
    for preset in presets:
        policy_variant = {
            "convergencePolicy": {
                "enabled": True,
                "required": False,
                "preset": preset,
                "generations": list(gens),
            }
        }
        if mixing:
            policy_variant["convergencePolicy"]["mixing"] = str(mixing)
        resolved_cfg = _resolve_convergence_policy(policy_variant)
        resolved_convergence_by_preset[str(preset)] = {
            "preset": str(resolved_cfg.get("preset") or preset),
            "selection_model": str(resolved_cfg.get("selection_model") or ""),
            "mixing": str(resolved_cfg.get("mixing") or ""),
            "generations": list(resolved_cfg.get("generations") or []),
            "fitness_grid": dict(resolved_cfg.get("fitness_grid") or {}),
        }
        conv_variant = _compute_convergence(
            policy_payload=policy_variant,
            intended_p=float(init.intended_p),
            uncut_p=float(init.uncut_p),
            harmful_p=float(init.harmful_p),
        )
        tmp_control = ControlV2(
            intended_functional_p=float(control.intended_functional_p),
            dominance_ratio=float(control.dominance_ratio),
            entropy_bits=float(control.entropy_bits),
            no_cut_p=float(control.no_cut_p),
            convergence=conv_variant,
            stability=_default_stability(),
            iteration=control.iteration,
            claims=control.claims,
            flags=list(control.flags),
        )
        verdict = _compute_verdict(
            control=tmp_control,
            risk=risk,
            integrity=integrity,
            compliant_with_policy=bool(compliant_with_policy),
            noncompliance_reasons=noncompliance_reasons,
        )
        variants.append(
            StabilityVariantV2(
                variant_id=f"convergence_preset:{preset}",
                variant_type="convergence_preset",
                preset=preset,
                grade=str(verdict.grade),
                intended_p=_clamp01(float(control.intended_functional_p)),
                dominance_ratio=float(control.dominance_ratio),
                entropy_bits=float(control.entropy_bits),
                escape_risk=_clamp01(float(conv_variant.escape_risk or 0.0)),
                splice_risk=_clamp01(float(risk.tail.p_any_splice_disruption)),
                regulatory_risk=_clamp01(float(risk.tail.p_any_regulatory_hit)),
                off_target_params=None,
                off_target_status=None,
                off_target_worst_site_score=None,
            )
        )

    # Off-target sweep variants (audit-strict stability)
    sweep_cfg = (cfg.get("off_target_sweep") or {}) if isinstance(cfg, Mapping) else {}
    sweep_enabled = bool(sweep_cfg.get("enabled")) or bool(sweep_cfg.get("required"))
    sweep_modes = sweep_cfg.get("modes") if isinstance(sweep_cfg.get("modes"), list) else ["screening"]
    sweep_modes = [m for m in (sweep_modes or []) if m in {"none", "screening", "full"}]
    if not sweep_modes:
        sweep_modes = ["screening"]
    sweep_max_mm = sweep_cfg.get("max_mm") if isinstance(sweep_cfg.get("max_mm"), list) else [2, 3, 4]
    sweep_max_hits = sweep_cfg.get("max_hits") if isinstance(sweep_cfg.get("max_hits"), list) else [50, 200]
    sweep_provider = str(sweep_cfg.get("provider_id") or "offtarget_mismatch_v1")
    sweep_allow_full = bool(sweep_cfg.get("allow_full"))
    sweep_full_required = bool(sweep_cfg.get("full_required"))

    off_target_sweep_hash = None
    if sweep_enabled:
        combos: list[tuple[str, int, int]] = []
        for mode in sweep_modes:
            if mode == "full" and not sweep_allow_full:
                continue
            for mm in sweep_max_mm:
                for mh in sweep_max_hits:
                    combos.append((mode, int(mm), int(mh)))
        if len(combos) > 12:
            combos = combos[:12]
            stability_warnings.append("off_target_sweep_truncated")
        resolved_grid = [
            {"mode": m, "max_mm": mm, "max_hits": mh, "provider_id": sweep_provider} for (m, mm, mh) in combos
        ]
        off_target_sweep_hash = _sha256_prefixed_payload(
            {
                "algorithm": "stability_v1_off_target_sweep",
                "grid": resolved_grid,
                "reference_id": getattr(risk.off_target, "reference_id", "unconfigured"),
            }
        )
        base_off = risk.off_target
        for idx, (mode, mm, mh) in enumerate(combos):
            status = "not_computed"
            severity = "warning"
            reason = ""
            worst_score = None
            ot_params = {
                "off_target_mode": str(base_off.off_target_mode if hasattr(base_off, "off_target_mode") else "policy"),
                "mode": mode,
                "max_mm": int(mm),
                "max_hits": int(mh),
                "provider_id": sweep_provider,
                "scope": str(getattr(base_off, "scope", "")),
                "p_hits_coding_exon": float(base_off.p_hits_coding_exon or 0.0) if base_off.p_hits_coding_exon is not None else None,
            }
            if base_off.status != "computed":
                status = "not_computed"
                severity = str(base_off.severity or "blocking")
                reason = str(base_off.reason or "off-target not computed in base run")
                ot_variant = OffTargetBurdenV2(
                    status="not_computed",
                    off_target_mode=str(base_off.off_target_mode),
                    mode=mode,
                    executed_mode=str(getattr(base_off, "executed_mode", base_off.mode)),
                    provider_id=sweep_provider,
                    reference_id=base_off.reference_id,
                    params=dict(base_off.params or {}),
                    scope=str(getattr(base_off, "scope", "")),
                    limitations=str(getattr(base_off, "limitations", "")),
                    severity=severity,
                    reason=reason,
                    provider_version=base_off.provider_version,
                    cache_key=base_off.cache_key,
                    cache_key_inputs_hash=None,
                    cache_hit=None,
                    cache_namespace=base_off.cache_namespace,
                )
            elif mode == "full" and str(getattr(base_off, "executed_mode", base_off.mode)) != "full":
                status = "not_computed"
                severity = "blocking" if sweep_full_required else "warning"
                reason = "full off-target not executed; sweep requires full"
                ot_variant = OffTargetBurdenV2(
                    status="not_computed",
                    off_target_mode=str(base_off.off_target_mode),
                    mode="full",
                    executed_mode=str(getattr(base_off, "executed_mode", base_off.mode)),
                    provider_id=sweep_provider,
                    reference_id=base_off.reference_id,
                    params=dict(base_off.params or {}),
                    scope=str(getattr(base_off, "scope", "")),
                    limitations=str(getattr(base_off, "limitations", "")),
                    severity=severity,
                    reason=reason,
                    provider_version=base_off.provider_version,
                    cache_key=base_off.cache_key,
                    cache_key_inputs_hash=None,
                    cache_hit=None,
                    cache_namespace=base_off.cache_namespace,
                )
            else:
                status = "computed"
                severity = None
                reason = ""
                worst_score = base_off.worst_site_score
                ot_variant = OffTargetBurdenV2(
                    status="computed",
                    off_target_mode=str(base_off.off_target_mode),
                    mode=mode,
                    executed_mode=str(getattr(base_off, "executed_mode", base_off.mode)),
                    provider_id=sweep_provider,
                    reference_id=base_off.reference_id,
                    params={**dict(base_off.params or {}), "max_mm": int(mm), "max_hits": int(mh)},
                    scope=str(getattr(base_off, "scope", "")),
                    limitations=str(getattr(base_off, "limitations", "")),
                    severity=None,
                    reason=None,
                    provider_version=base_off.provider_version,
                    cache_key=base_off.cache_key,
                    cache_key_inputs_hash=base_off.cache_key_inputs_hash,
                    cache_hit=base_off.cache_hit,
                    cache_namespace=base_off.cache_namespace,
                    worst_site_score=base_off.worst_site_score,
                    sum_score=base_off.sum_score,
                    p_hits_coding_exon=base_off.p_hits_coding_exon,
                    p_hits_promoter=base_off.p_hits_promoter,
                    p_hits_enhancer=base_off.p_hits_enhancer,
                    p_hits_splice=base_off.p_hits_splice,
                    top_sites=base_off.top_sites,
                    annotation_computed=base_off.annotation_computed,
                )
            # Verdict under this variant
            risk_variant = RiskV2(
                tail=risk.tail,
                hazard=risk.hazard,
                off_target=ot_variant,
                structural=risk.structural,
                topology_3d=risk.topology_3d,
            )
            verdict_variant = _compute_verdict(
                control=control,
                risk=risk_variant,
                integrity=integrity,
                compliant_with_policy=compliant_with_policy,
                noncompliance_reasons=noncompliance_reasons,
            )
            variants.append(
                StabilityVariantV2(
                    variant_id=f"off_target_sweep:{idx+1}:{mode}:mm{mm}:hits{mh}",
                    variant_type="off_target_sweep",
                    preset="off_target",
                    grade=str(verdict_variant.grade),
                    intended_p=_clamp01(float(control.intended_functional_p)),
                    dominance_ratio=float(control.dominance_ratio),
                    entropy_bits=float(control.entropy_bits),
                    escape_risk=_clamp01(float(control.convergence.escape_risk or 0.0)),
                    splice_risk=_clamp01(float(risk.tail.p_any_splice_disruption)),
                    regulatory_risk=_clamp01(float(risk.tail.p_any_regulatory_hit)),
                    off_target_params=ot_params | {"status": status, "reason": reason or "", "severity": severity or ""},
                    off_target_status=status,
                    off_target_worst_site_score=worst_score,
                )
            )
    if not variants:
        return StabilityV2(status="not_computed", reason="stability variants unavailable", severity=severity)

    grade_min = min(variants, key=lambda v: grade_order.get(str(v.grade), 0)).grade
    grade_max = max(variants, key=lambda v: grade_order.get(str(v.grade), 0)).grade

    intended_vals = [float(v.intended_p) for v in variants]
    escape_vals = [float(v.escape_risk) for v in variants]
    splice_vals = [float(v.splice_risk) for v in variants]
    reg_vals = [float(v.regulatory_risk) for v in variants]
    ot_worst_vals = [float(v.off_target_worst_site_score) for v in variants if v.off_target_worst_site_score is not None]
    ot_coding_vals = [
        float(v.off_target_params.get("p_hits_coding_exon"))  # type: ignore[arg-type]
        for v in variants
        if isinstance(v.off_target_params, Mapping) and v.off_target_params.get("p_hits_coding_exon") is not None
    ]

    intended_min = min(intended_vals) if intended_vals else 0.0
    intended_max = max(intended_vals) if intended_vals else 0.0
    escape_min = min(escape_vals) if escape_vals else 0.0
    escape_max = max(escape_vals) if escape_vals else 0.0
    splice_min = min(splice_vals) if splice_vals else 0.0
    splice_max = max(splice_vals) if splice_vals else 0.0
    reg_min = min(reg_vals) if reg_vals else 0.0
    reg_max = max(reg_vals) if reg_vals else 0.0
    ot_worst_min = min(ot_worst_vals) if ot_worst_vals else 0.0
    ot_worst_max = max(ot_worst_vals) if ot_worst_vals else 0.0
    ot_coding_min = min(ot_coding_vals) if ot_coding_vals else 0.0
    ot_coding_max = max(ot_coding_vals) if ot_coding_vals else 0.0

    grade_width = float(grade_order.get(str(grade_max), 0) - grade_order.get(str(grade_min), 0)) / 4.0
    widths = [
        _clamp01(float(intended_max - intended_min)),
        _clamp01(float(escape_max - escape_min)),
        _clamp01(float(splice_max - splice_min)),
        _clamp01(float(reg_max - reg_min)),
        _clamp01(float(ot_worst_max - ot_worst_min)),
        _clamp01(float(grade_width)),
    ]
    stability_score = _clamp01(1.0 - (sum(widths) / float(len(widths)) if widths else 1.0))
    if stability_score >= 0.8:
        interpretation = "high"
    elif stability_score >= 0.5:
        interpretation = "medium"
    else:
        interpretation = "low"

    ranges = StabilityRangesV2(
        grade_min=str(grade_min),
        grade_max=str(grade_max),
        intended_min=_clamp01(float(intended_min)),
        intended_max=_clamp01(float(intended_max)),
        escape_min=_clamp01(float(escape_min)),
        escape_max=_clamp01(float(escape_max)),
        splice_min=_clamp01(float(splice_min)),
        splice_max=_clamp01(float(splice_max)),
        regulatory_min=_clamp01(float(reg_min)),
        regulatory_max=_clamp01(float(reg_max)),
        off_target_worst_min=_clamp01(float(ot_worst_min)),
        off_target_worst_max=_clamp01(float(ot_worst_max)),
        off_target_coding_min=_clamp01(float(ot_coding_min)),
        off_target_coding_max=_clamp01(float(ot_coding_max)),
    )
    assumptions_hash = _sha256_prefixed_payload(
        {
            "algorithm": "stability_v1_convergence_preset_sweep",
            "preset_ids_used": list(presets),
            "resolved_convergence": resolved_convergence_by_preset,
        }
    )
    assumptions = StabilityAssumptionsV2(
        preset_ids_used=list(presets),
        assumptions_hash=assumptions_hash,
        off_target_sweep_hash=off_target_sweep_hash,
    )
    if grade_min != grade_max and interpretation == "high":
        interpretation = "medium"

    return StabilityV2(
        status="computed",
        assumptions=assumptions,
        variants=variants,
        ranges=ranges,
        stability_score=float(stability_score),
        interpretation=str(interpretation),
        warnings=stability_warnings,
        reason=None,
        severity=None,
    )


def _compute_verdict(
    *,
    control: ControlV2,
    risk: RiskV2,
    integrity: IntegrityV2,
    compliant_with_policy: bool,
    noncompliance_reasons: Sequence[str],
) -> VerdictV2:
    failures = list(integrity.failures or [])
    if failures:
        grade = "F"
    elif control.intended_functional_p < 0.6:
        grade = "F"
    elif control.no_cut_p > 0.1:
        grade = "F"
    elif control.dominance_ratio < 1.5:
        grade = "F"
    else:
        grade = "B"
        if (
            control.intended_functional_p >= 0.8
            and control.dominance_ratio >= 3.0
            and control.no_cut_p <= 0.05
            and control.entropy_bits <= 1.5
        ):
            grade = "A"
        elif control.dominance_ratio < 2.0 or control.entropy_bits > 3.0:
            grade = "D"
        else:
            grade = "C" if control.dominance_ratio < 3.0 else "B"

    # Splice tail risk gate: never allow success language above D.
    if risk.tail.p_any_splice_disruption > 1e-4 and grade in {"A", "B", "C"}:
        grade = "D"

    escape_dominates = False
    try:
        conv = control.convergence
        if conv.status == "computed" and float(conv.escape_worst_case_uncut_p_gen20 or 0.0) > 0.5:
            escape_dominates = True
    except Exception:
        escape_dominates = False

    if escape_dominates and grade in {"A", "B", "C"}:
        grade = "D"

    # Caps
    cap_c = False
    if risk.hazard.status != "computed":
        cap_c = True
    if risk.off_target.status != "computed":
        if str(risk.off_target.severity or "") == "blocking":
            cap_c = True
    elif str(risk.off_target.mode or "") == "full" and str(risk.off_target.executed_mode or "") != "full":
        cap_c = True
    if risk.topology_3d.status != "computed":
        cap_c = True
    try:
        if control.convergence.status != "computed":
            cap_c = True
    except Exception:
        cap_c = True
    try:
        iter_cfg = control.iteration
        if iter_cfg.status != "computed" and bool(iter_cfg.required):
            cap_c = True
        if bool(iter_cfg.transition_required) and str(iter_cfg.transition_model or "") == "identity":
            cap_c = True
    except Exception:
        pass
    if cap_c and grade in {"A", "B"}:
        grade = "C"
    if (not bool(compliant_with_policy)) and grade in {"A", "B"}:
        grade = "C"

    headline = HEADLINE_BY_GRADE.get(grade, HEADLINE_BY_GRADE["C"])
    if escape_dominates and grade in HEADLINE_ESCAPE_DOMINATES_BY_GRADE:
        headline = HEADLINE_ESCAPE_DOMINATES_BY_GRADE[grade]
    return VerdictV2(
        grade=grade,
        headline=headline,
        decision="insufficient_evidence",
        decision_mode="filter_only",
        compliant_with_policy=bool(compliant_with_policy),
        noncompliance_reasons=[str(r) for r in noncompliance_reasons if str(r)],
    )


def _build_recommendations(
    *,
    control: ControlV2,
    risk: RiskV2,
    verdict: VerdictV2,
    noncompliance_reasons: Sequence[str],
) -> list[RecommendationV2]:
    recs: list[RecommendationV2] = []

    def add(
        recommendation_id: str,
        title: str,
        suggestion: str,
        triggered_by: Sequence[RecommendationTriggerV2],
    ) -> None:
        rid = str(recommendation_id or "").strip() or "recommendation"
        ttl = str(title or "").strip() or rid
        sug = str(suggestion or "").strip()
        if sug and not sug.lower().startswith(("consider", "review", "avoid")):
            sug = "Consider " + sug
        recs.append(
            RecommendationV2(
                recommendation_id=rid,
                title=ttl,
                suggestion=sug or "Consider reviewing this run.",
                triggered_by=list(triggered_by),
            )
        )

    no_cut = float(control.no_cut_p)
    if no_cut > 0.1:
        add(
            "reduce_no_cut_fraction",
            "Reduce no-cut fraction",
            "increasing guide activity, optimizing delivery, or selecting an alternative guide/PAM to reduce the no-cut fraction.",
            [RecommendationTriggerV2(metric_path="control.no_cut_p", condition="> 0.10", value=no_cut)],
        )

    dominance = float(control.dominance_ratio)
    entropy = float(control.entropy_bits)
    if math.isfinite(dominance) and dominance < 3.0:
        add(
            "reduce_plurality",
            "Reduce plurality / increase dominance",
            "redesigning the guide (or editor modality) to increase dominance and reduce outcome entropy before treating this as a controlled edit.",
            [
                RecommendationTriggerV2(metric_path="control.dominance_ratio", condition="< 3.0", value=dominance),
                RecommendationTriggerV2(metric_path="control.entropy_bits", condition="high implies plurality", value=entropy),
            ],
        )

    hazard = risk.hazard
    if hazard.status == "computed":
        splice = max(float(hazard.p_hits_splice_donor or 0.0), float(hazard.p_hits_splice_acceptor or 0.0))
        if splice > 1e-4:
            add(
                "reduce_splice_hazard",
                "Reduce splice disruption hazard",
                "shifting the cut site away from splice windows or choosing an alternate guide/editor to reduce splice disruption probability.",
                [
                    RecommendationTriggerV2(
                        metric_path="risk.hazard.p_hits_splice_donor",
                        condition="reported",
                        value=float(hazard.p_hits_splice_donor or 0.0),
                    ),
                    RecommendationTriggerV2(
                        metric_path="risk.hazard.p_hits_splice_acceptor",
                        condition="reported",
                        value=float(hazard.p_hits_splice_acceptor or 0.0),
                    ),
                ],
            )
    else:
        add(
            "compute_hazard",
            "Compute hazard (splice/regulatory)",
            "loading transcript and regulatory tracks so splice/regulatory hazard can be computed and gated.",
            [RecommendationTriggerV2(metric_path="risk.hazard.status", condition="!= computed", value=str(hazard.status))],
        )

    conv = control.convergence
    if conv.status == "computed":
        escape_risk = float(conv.escape_risk or 0.0)
        worst_uncut20 = float(conv.escape_worst_case_uncut_p_gen20 or 0.0)
        if escape_risk > 0.5 or worst_uncut20 > 0.5:
            add(
                "reduce_escape_risk",
                "Reduce escape risk under selection",
                "multiplexing guides, changing editor modality, or improving delivery so uncut cells do not gain a selection advantage under the modeled assumptions.",
                [
                    RecommendationTriggerV2(
                        metric_path="control.convergence.escape_risk",
                        condition="> 0.50",
                        value=escape_risk,
                    ),
                    RecommendationTriggerV2(
                        metric_path="control.convergence.escape_worst_case_uncut_p_gen20",
                        condition="> 0.50",
                        value=worst_uncut20,
                    ),
                ],
            )
    else:
        add(
            "compute_convergence",
            "Compute convergence / escape dynamics",
            "enabling convergence projection in policy so escape risk is explicit and grade/language gates can apply.",
            [RecommendationTriggerV2(metric_path="control.convergence.status", condition="!= computed", value=str(conv.status))],
        )

    off = risk.off_target
    if off.status != "computed":
        add(
            "compute_off_target",
            "Compute off-target constraint",
            "computing off-target screening (or full off-target under audit strict) so off-target burden is not an implicit unknown.",
            [
                RecommendationTriggerV2(metric_path="risk.off_target.status", condition="!= computed", value=str(off.status)),
                RecommendationTriggerV2(metric_path="risk.off_target.reason", condition="reported", value=str(off.reason or "")),
            ],
        )
    elif str(off.mode or "") == "screening":
        if "screening_used_but_policy_requires_full" in set(noncompliance_reasons):
            add(
                "off_target_full_required",
                "Run full off-target (policy requirement)",
                "running full off-target under the active policy; the current run used screening only and is marked noncompliant.",
                [
                    RecommendationTriggerV2(metric_path="risk.off_target.mode", condition="== screening", value=str(off.mode)),
                    RecommendationTriggerV2(
                        metric_path="verdict.noncompliance_reasons",
                        condition="contains screening_used_but_policy_requires_full",
                        value=True,
                    ),
                ],
            )
        else:
            add(
                "off_target_review_screening_limits",
                "Review off-target screening limitations",
                "treating window-only screening as a limitation and running full off-target when deployment intent requires whole-genome coverage.",
                [
                    RecommendationTriggerV2(metric_path="risk.off_target.mode", condition="== screening", value=str(off.mode)),
                    RecommendationTriggerV2(metric_path="risk.off_target.limitations", condition="reported", value=str(off.limitations or "")),
                ],
            )

    if verdict.compliant_with_policy is False:
        add(
            "resolve_policy_noncompliance",
            "Resolve policy noncompliance",
            "addressing the listed noncompliance reasons (or recording an explicit waiver) before treating this run as deployment-relevant.",
            [
                RecommendationTriggerV2(metric_path="verdict.compliant_with_policy", condition="== false", value=False),
                RecommendationTriggerV2(
                    metric_path="verdict.noncompliance_reasons", condition="non-empty", value=list(noncompliance_reasons)
                ),
            ],
        )

    return recs


def build_run_summary_v2_from_snapshot(
    snapshot: Mapping[str, Any],
    *,
    off_target_mode: str | None = None,
    structural_mode: str | None = None,
) -> dict[str, Any]:
    """
    Build the Helix Summary Contract v2 payload from a Session snapshot.

    This is a best-effort builder: missing data is surfaced as integrity warnings and/or risk status blocks,
    never silently dropped.
    """

    state = snapshot.get("state", snapshot) if isinstance(snapshot, Mapping) else {}
    if not isinstance(state, Mapping):
        state = {}
    header = snapshot.get("header") if isinstance(snapshot.get("header"), Mapping) else {}

    run_id = str(state.get("run_id") or state.get("runId") or "run")
    experiment_spec = state.get("experiment_spec") if isinstance(state.get("experiment_spec"), Mapping) else {}
    edit_plan = state.get("edit_plan") if isinstance(state.get("edit_plan"), Mapping) else {}

    spec_payload = experiment_spec_to_dict(experiment_spec)
    spec_hash = _sha256_prefixed_hex(experiment_spec_sha256(spec_payload))
    policy_id = _infer_policy_id(header)
    policy_hash = _infer_hash(header, "policyHash", "HELIX_POLICY_HASH")

    intent = _infer_intent(experiment_spec)

    raw_intent_spec = state.get("experiment_intent_spec")
    intent_present = isinstance(raw_intent_spec, Mapping)
    intent_payload, intent_err = experiment_intent_spec_from_dict_with_error(raw_intent_spec if intent_present else None)
    intent_sha_raw = experiment_intent_spec_sha256(intent_payload) if intent_present else ""
    intent_sha_pref = _sha256_prefixed_hex(intent_sha_raw) if intent_sha_raw else "sha256:unavailable"
    intent_missing_fields = intent_spec_missing_required_fields(intent_payload) if intent_present else ["experiment_intent_spec"]
    if not intent_present:
        intent_status = "missing"
    elif intent_err:
        intent_status = "invalid"
    elif intent_missing_fields:
        intent_status = "incomplete"
    else:
        intent_status = "declared"

    intent_ref_block = spec_payload.get("intentRef") if isinstance(spec_payload.get("intentRef"), Mapping) else None
    intent_ref_kind = str(intent_ref_block.get("kind") or "") if isinstance(intent_ref_block, Mapping) else ""
    intent_ref_sha = str(intent_ref_block.get("sha256") or "") if isinstance(intent_ref_block, Mapping) else ""
    if not isinstance(intent_ref_block, Mapping):
        intent_ref_status = "missing"
    elif intent_ref_kind and intent_ref_kind != EXPERIMENT_INTENT_SPEC_SCHEMA_ID:
        intent_ref_status = "invalid"
    elif intent_sha_raw and intent_ref_sha == intent_sha_raw:
        intent_ref_status = "matched"
    elif intent_sha_raw and intent_ref_sha:
        intent_ref_status = "mismatch"
    else:
        intent_ref_status = "missing"

    config = state.get("config") if isinstance(state.get("config"), Mapping) else {}
    sim_payload = config.get("sim_payload") if isinstance(config.get("sim_payload"), Mapping) else {}
    priors = sim_payload.get("priors") if isinstance(sim_payload.get("priors"), Mapping) else None
    on_target_engine = sim_payload.get("on_target") if isinstance(sim_payload.get("on_target"), Mapping) else None
    on_target_ood_flag = bool(on_target_engine.get("ood")) if isinstance(on_target_engine, Mapping) else False
    on_target_encoding_only = False
    on_target_novelty: float | None = None
    if isinstance(on_target_engine, Mapping):
        features = on_target_engine.get("features") if isinstance(on_target_engine.get("features"), Mapping) else {}
        on_target_encoding_only = str(features.get("mode") or "").strip().lower() == "encoding_only"
        novelty_raw = _safe_float(on_target_engine.get("novelty"), default=float("nan"))
        if math.isfinite(float(novelty_raw)):
            on_target_novelty = _clamp01(float(novelty_raw))

    novelty_threshold = _clamp01(
        _safe_float(os.environ.get("HELIX_ON_TARGET_NOVELTY_VALIDATION_THRESHOLD"), default=0.8)
    )
    if novelty_threshold <= 0.0:
        novelty_threshold = 0.8
    on_target_high_novelty = bool(
        on_target_novelty is not None and float(on_target_novelty) >= float(novelty_threshold) and (not on_target_ood_flag)
    )

    species_detection = _extract_species_detection(state)
    species_resolution = {}
    if isinstance(species_detection, Mapping):
        species_resolution = species_detection.get("resolution") if isinstance(species_detection.get("resolution"), Mapping) else {}
    species_status = str(species_resolution.get("status") or "") if isinstance(species_resolution, Mapping) else ""

    run_kind = str(state.get("run_kind") or config.get("sim_type") or "").strip().lower()
    repair_model_name = "cut_repair_v1" if "crispr" in run_kind or "cut" in run_kind else ("prime_v2" if "prime" in run_kind else "unknown")
    repair_constraints = ["NHEJ", "MMEJ"] if "crispr" in run_kind or "cut" in run_kind else []
    repair_model = ModelV2(
        name=repair_model_name,
        type="statistical",
        constraints=repair_constraints,
        calibration=CalibrationV2(
            dataset_id="unconfigured",
            domain=str(experiment_spec_to_dict(experiment_spec).get("reference", {}).get("genomeBuild") or ""),
            notes="",
        ),
    )

    off_target_model = ModelV2(
        name="offtarget_unconfigured",
        type="mechanistic",
        constraints=[],
        calibration=CalibrationV2(
            dataset_id="unconfigured",
            domain=str(experiment_spec_to_dict(experiment_spec).get("reference", {}).get("genomeBuild") or ""),
            notes="",
        ),
    )

    cut_site = _infer_cut_site(state, experiment_spec, edit_plan)
    intended_edit_spec = _build_intended_edit_spec(
        state=state,
        experiment_spec=experiment_spec,
        edit_plan=edit_plan,
        cut_site=cut_site,
    )

    raw_outcomes = state.get("outcomes") or sim_payload.get("outcomes") or []
    if not isinstance(raw_outcomes, list):
        raw_outcomes = []

    no_cut_p = 0.0
    deletion_len_mixture: dict[int, float] = {}
    pending_outcomes: list[dict[str, Any]] = []
    sim_draws = _maybe_int(sim_payload.get("draws")) if isinstance(sim_payload, Mapping) else None
    for idx, raw in enumerate(raw_outcomes):
        if not isinstance(raw, Mapping):
            continue
        label = str(raw.get("label") or raw.get("name") or raw.get("category") or f"outcome_{idx+1}")
        p_total = _clamp01(_safe_float(raw.get("p_total", raw.get("probability", raw.get("prob", 0.0))), default=0.0))
        count = _maybe_int(raw.get("count"))
        diff = raw.get("diff") if isinstance(raw.get("diff"), Mapping) else None
        delta_bp = _safe_int(raw.get("delta_bp"), default=_delta_bp_from_diff(diff))
        if _is_no_cut_label(label):
            no_cut_p += p_total

        indel_dist = _infer_indel_len_dist(label=label, delta_bp=delta_bp, priors=priors)
        # Build a mixture over deletion lengths for tail risk. Non-deletions contribute 0 bp deletion.
        if delta_bp < 0:
            for length, prob in indel_dist.items():
                deletion_len_mixture[int(length)] = deletion_len_mixture.get(int(length), 0.0) + p_total * float(prob)
        else:
            deletion_len_mixture[0] = deletion_len_mixture.get(0, 0.0) + p_total
        indel_summary = _indel_length_summary(indel_dist)
        frameshift_p = _frameshift_prob_from_len_dist(indel_dist)

        frameshift_obj = FrameshiftV2(
            p=frameshift_p,
            source="computed",
            reason=None,
        )

        functional_class = _functional_class_for_outcome(
            label=label,
            intent=intent,
            frameshift_p=frameshift_p,
            indel_len_mean=indel_summary.mean_bp,
            explicit=raw.get("functional_class") if isinstance(raw.get("functional_class"), str) else None,
        )

        regulatory_overlap = raw.get("regulatory_overlap") if isinstance(raw.get("regulatory_overlap"), Mapping) else None
        if regulatory_overlap is None:
            reg = RegulatoryOverlapV2(
                p_hits_splice_donor=0.0,
                p_hits_splice_acceptor=0.0,
                p_hits_promoter=0.0,
                p_hits_enhancer=0.0,
                p_hits_boundary_element=0.0,
            )
            worst = WorstHitV2(feature_type="unknown", feature_id="annotation_not_computed", p=0.0)
        else:
            reg = RegulatoryOverlapV2(
                p_hits_splice_donor=_clamp01(_safe_float(regulatory_overlap.get("p_hits_splice_donor"))),
                p_hits_splice_acceptor=_clamp01(_safe_float(regulatory_overlap.get("p_hits_splice_acceptor"))),
                p_hits_promoter=_clamp01(_safe_float(regulatory_overlap.get("p_hits_promoter"))),
                p_hits_enhancer=_clamp01(_safe_float(regulatory_overlap.get("p_hits_enhancer"))),
                p_hits_boundary_element=_clamp01(_safe_float(regulatory_overlap.get("p_hits_boundary_element"))),
            )
            worst_hit = raw.get("worst_hit") if isinstance(raw.get("worst_hit"), Mapping) else {}
            worst = WorstHitV2(
                feature_type=str(worst_hit.get("feature_type") or "unknown"),
                feature_id=str(worst_hit.get("feature_id") or ""),
                p=_clamp01(_safe_float(worst_hit.get("p"))),
            )

        edit_start0: int | None = None
        edit_end0: int | None = None
        edit_del_len = 0
        if isinstance(diff, Mapping):
            start_raw = _maybe_int(diff.get("start"))
            end_raw = _maybe_int(diff.get("end"))
            if start_raw is not None and end_raw is not None:
                s0 = int(min(start_raw, end_raw))
                e0 = int(max(start_raw, end_raw))
                kind = str(diff.get("kind") or diff.get("edit") or "").strip().lower()
                if "ins" in kind and e0 <= s0:
                    e0 = s0 + 1
                elif kind and kind != "none" and e0 <= s0:
                    e0 = s0 + 1
                edit_start0 = s0
                edit_end0 = e0
                if "del" in kind or delta_bp < 0:
                    edit_del_len = max(0, e0 - s0)

        outcome_id = str(raw.get("outcome_id") or f"{run_id}:{label}:{idx+1}")
        pending_outcomes.append(
            {
                "outcome_id": outcome_id,
                "label": label,
                "p_total": p_total,
                "delta_bp": int(delta_bp),
                "functional_class": functional_class,
                "frameshift": frameshift_obj,
                "indel_length": indel_summary,
                "regulatory_overlap": reg,
                "worst_hit": worst,
                "is_no_cut": _is_no_cut_label(label),
                "count": count,
                "edit_start0": edit_start0,
                "edit_end0": edit_end0,
                "edit_del_len": int(edit_del_len),
            }
        )

    cut_p = max(0.0, 1.0 - no_cut_p)
    uncertainty_payload = _compute_uncertainty_from_counts(pending_outcomes=pending_outcomes, total_draws=sim_draws)
    outcomes_v2: list[OutcomeV2] = []
    for item in pending_outcomes:
        label = str(item["label"])
        p_total = float(item["p_total"])
        p_given_cut = None
        if not bool(item.get("is_no_cut")) and cut_p > 0.0:
            p_given_cut = _clamp01(p_total / cut_p)
        outcomes_v2.append(
            OutcomeV2(
                outcome_id=str(item["outcome_id"]),
                label=label,
                p_total=p_total,
                p_given_cut=p_given_cut,
                functional_class=str(item["functional_class"]),
                frameshift=item["frameshift"],
                indel_length=item["indel_length"],
                regulatory_overlap=item["regulatory_overlap"],
                worst_hit=item["worst_hit"],
            )
        )

    intended_functional_p = _clamp01(
        sum(o.p_total for o in outcomes_v2 if o.functional_class == "intended_functional")
    )
    dominance = _dominance_ratio([o.p_total for o in outcomes_v2])
    entropy = _entropy_bits([o.p_total for o in outcomes_v2])
    control_flags: list[str] = []
    if math.isfinite(float(dominance)) and float(dominance) < 3.0:
        control_flags.append("plurality_regime")

    hazard, hazard_any_splice, hazard_any_reg = _compute_hazard(
        state=state,
        experiment_spec=experiment_spec,
        cut_p=cut_p,
        pending_outcomes=pending_outcomes,
    )

    # Tail risk: best-effort. Deletion-length mixture is derived from per-outcome indel distributions.
    del_dist = deletion_len_mixture or {0: 1.0}
    p_any_splice = _clamp01(
        sum(o.p_total * max(o.regulatory_overlap.p_hits_splice_donor, o.regulatory_overlap.p_hits_splice_acceptor) for o in outcomes_v2)
    )
    p_any_reg = _clamp01(
        sum(
            o.p_total
            * (
                1.0
                - (1.0 - o.regulatory_overlap.p_hits_splice_donor)
                * (1.0 - o.regulatory_overlap.p_hits_splice_acceptor)
                * (1.0 - o.regulatory_overlap.p_hits_promoter)
                * (1.0 - o.regulatory_overlap.p_hits_enhancer)
                * (1.0 - o.regulatory_overlap.p_hits_boundary_element)
            )
            for o in outcomes_v2
        )
    )
    if hazard.status == "computed" and hazard_any_splice is not None and hazard_any_reg is not None:
        p_any_splice = float(hazard_any_splice)
        p_any_reg = float(hazard_any_reg)
    tail = TailRiskV2(
        global_p99_del_bp=_quantile_discrete(del_dist, 0.99),
        global_cvar99_del_bp=_cvar_discrete(del_dist, 0.99),
        p_any_splice_disruption=p_any_splice,
        p_any_regulatory_hit=p_any_reg,
        p_any_large_del_ge_50bp=_clamp01(_p_ge(del_dist, 50)),
        p_any_large_del_ge_200bp=_clamp01(_p_ge(del_dist, 200)),
    )

    policy_payload = _load_policy_payload_best_effort()

    # Convergence coupling (v1): treat splice/regulatory hazard mass as harmful for dynamics, even when the
    # per-outcome functional class is "unknown". This makes escape projections reflect tail risk by default.
    harmful_base = _clamp01(sum(o.p_total for o in outcomes_v2 if o.functional_class in {"likely_harmful", "harmful"}))
    hazard_splice_mass = 0.0
    hazard_reg_mass = 0.0
    if hazard.status == "computed" and hazard_any_splice is not None and hazard_any_reg is not None:
        hazard_splice_mass = _clamp01(float(hazard_any_splice))
        # High-consequence regulatory hazard (promoter/enhancer) excluding splice overlap.
        hazard_reg_mass = _clamp01(max(0.0, float(hazard_any_reg) - float(hazard_any_splice)))

    harmful_init = _clamp01(harmful_base + hazard_splice_mass + hazard_reg_mass)
    harmful_init = _clamp01(min(float(harmful_init), max(0.0, 1.0 - float(no_cut_p))))
    intended_for_dynamics = _clamp01(max(0.0, 1.0 - float(no_cut_p) - float(harmful_init)))
    convergence = _compute_convergence(
        policy_payload=policy_payload,
        intended_p=intended_for_dynamics,
        uncut_p=no_cut_p,
        harmful_p=harmful_init,
    )
    iteration, claims_v2, iteration_noncompliance = _compute_iteration_and_claims(
        policy_payload=policy_payload,
        intended_p=intended_for_dynamics,
        uncut_p=no_cut_p,
        harmful_p=harmful_init,
        hazard_splice_mass=hazard_splice_mass,
        hazard_reg_mass=hazard_reg_mass,
        cut_p=cut_p,
    )

    control = ControlV2(
        intended_functional_p=intended_functional_p,
        dominance_ratio=float(dominance),
        entropy_bits=float(entropy),
        no_cut_p=no_cut_p,
        convergence=convergence,
        iteration=iteration,
        claims=claims_v2,
        flags=control_flags,
    )
    policy_ot_compute, policy_ot_required, ot_overrides, policy_species_required = _resolve_off_target_policy(
        policy_payload
    )
    policy_struct_compute, policy_struct_required, structural_overrides = _resolve_structural_policy(policy_payload)
    species_required_unresolved = bool(policy_species_required) and species_status != "resolved"
    desired_mode = policy_ot_compute
    requested = str(off_target_mode or "policy").strip().lower()
    off_target_mode_src = requested if requested in OFFTARGET_MODE_SOURCE_VALUES else "policy"
    if off_target_mode_src != "policy" and off_target_mode_src in OFFTARGET_MODE_VALUES:
        desired_mode = off_target_mode_src
    not_computed_severity = "blocking" if policy_ot_required else "warning"

    desired_struct_mode = str(policy_struct_compute or "local_screening").strip().lower()
    requested_struct = str(structural_mode or "policy").strip().lower()
    if requested_struct == "local":
        requested_struct = "local_screening"
    if requested_struct == "genome":
        requested_struct = "genome_screening"
    structural_mode_src = requested_struct if requested_struct in STRUCTURAL_MODE_SOURCE_VALUES else "policy"
    if structural_mode_src != "policy" and structural_mode_src in STRUCTURAL_MODE_VALUES:
        desired_struct_mode = structural_mode_src

    reference_id = str(experiment_spec_to_dict(experiment_spec).get("reference", {}).get("genomeBuild") or "unconfigured")
    mode = desired_mode
    executed_mode = "screening" if mode == "full" else mode
    scope = "none" if executed_mode == "none" else ("window_only" if executed_mode == "screening" else "genome_wide")

    # Off-target field is required; computation is policy-gated.
    off_target = OffTargetBurdenV2(
        status="not_computed",
        off_target_mode=off_target_mode_src,
        mode=mode,
        executed_mode=executed_mode,
        provider_id="unconfigured",
        reference_id=reference_id,
        params={},
        scope=scope,
        limitations="off-target not computed",
        annotation_computed=False,
        reason="off-target not computed",
        severity=not_computed_severity,
        cache_key=None,
        cache_key_inputs_hash=None,
        cache_hit=None,
        cache_namespace="offtarget",
    )
    try:
        genome_sequences = state.get("genome") if isinstance(state.get("genome"), Mapping) else None

        guide = None
        if isinstance(config.get("guide"), Mapping):
            guide = dict(config.get("guide") or {})

        merged_params: dict[str, Any] = {}
        if isinstance(config.get("offtarget"), Mapping):
            merged_params.update(dict(config.get("offtarget") or {}))

        # Normalize common legacy keys from snapshots/config.
        if "providerId" in merged_params and "provider_id" not in merged_params:
            merged_params["provider_id"] = merged_params.pop("providerId")
        if "maxMm" in merged_params and "max_mm" not in merged_params:
            merged_params["max_mm"] = merged_params.pop("maxMm")
        if "maxHits" in merged_params and "max_hits" not in merged_params:
            merged_params["max_hits"] = merged_params.pop("maxHits")

        # Apply policy overrides as caps/defaults (do not overwrite stricter snapshot settings).
        if "provider_id" not in merged_params and ot_overrides.get("provider_id"):
            merged_params["provider_id"] = ot_overrides.get("provider_id")
        for key in ("max_mm", "max_hits"):
            if key not in ot_overrides:
                continue
            try:
                cap = int(ot_overrides.get(key))
            except Exception:
                continue
            if cap <= 0:
                continue
            if key in merged_params:
                try:
                    merged_params[key] = min(int(merged_params.get(key)), cap)
                except Exception:
                    merged_params[key] = cap
            else:
                merged_params[key] = cap
        merged_params.setdefault("provider_id", "offtarget_mismatch_v1")

        provider_id = str(merged_params.get("provider_id") or "offtarget_mismatch_v1")
        provider_version = ""
        try:
            from helix.studio.offtargets.model import get_default_registry

            provider = get_default_registry().get(provider_id)
            provider_version = str(getattr(provider, "provider_version", "") or "")
        except Exception:
            provider_version = ""

        policy_constraints: list[str] = []
        max_mm_policy = merged_params.get("max_mm")
        max_hits_policy = merged_params.get("max_hits")
        if max_mm_policy is not None:
            policy_constraints.append(f"max_mm<={int(max_mm_policy)}")
        if max_hits_policy is not None:
            policy_constraints.append(f"max_hits<={int(max_hits_policy)}")
        off_target_model = ModelV2(
            name=provider_id or "offtarget_model",
            type="mechanistic",
            constraints=policy_constraints,
            calibration=CalibrationV2(dataset_id="unconfigured", domain=reference_id, notes=""),
        )

        base_params: dict[str, Any] = dict(merged_params)
        if mode == "full":
            base_params["requested_mode"] = "full"

        # Always populate the common fields, even when not computed.
        off_target = OffTargetBurdenV2(
            status="not_computed",
            off_target_mode=off_target_mode_src,
            mode=mode,
            executed_mode=executed_mode,
            provider_id=provider_id or "unconfigured",
            provider_version=provider_version or None,
            reference_id=reference_id,
            params=base_params,
            scope=scope,
            limitations=(
                "Off-target computation disabled by policy."
                if mode == "none"
                else "Off-target computation not available for this snapshot."
            ),
            reason=(
                "policy compute=none"
                if mode == "none"
                else "off-target screening not computed: missing required inputs"
            ),
            annotation_computed=False,
            severity=not_computed_severity,
            cache_key=None,
            cache_key_inputs_hash=None,
            cache_hit=None,
            cache_namespace="offtarget",
        )

        if executed_mode == "none":
            # Explicit policy gate: do not attempt compute.
            pass
        elif executed_mode == "screening":
            if not isinstance(genome_sequences, Mapping) or not genome_sequences:
                off_target = OffTargetBurdenV2(
                    status="not_computed",
                    off_target_mode=off_target_mode_src,
                    mode=mode,
                    executed_mode=executed_mode,
                    provider_id=provider_id or "unconfigured",
                    provider_version=provider_version or None,
                    reference_id=reference_id,
                    params=base_params,
                    scope=scope,
                    limitations="Requires a genome window in the snapshot; none was provided.",
                    reason="off-target screening unavailable: genome window missing from snapshot",
                    annotation_computed=False,
                    severity=not_computed_severity,
                    cache_key=None,
                    cache_key_inputs_hash=None,
                    cache_hit=None,
                    cache_namespace="offtarget",
                )
            else:
                total_bp = sum(len(seq) for seq in genome_sequences.values() if isinstance(seq, str))
                max_bp = 2_000_000
                if total_bp > max_bp:
                    off_target = OffTargetBurdenV2(
                        status="not_computed",
                        off_target_mode=off_target_mode_src,
                        mode=mode,
                        executed_mode=executed_mode,
                        provider_id=provider_id or "unconfigured",
                        provider_version=provider_version or None,
                        reference_id=reference_id,
                        params=base_params,
                        scope=scope,
                        limitations=f"Screening implementation is window-only and capped at {max_bp} bp total input.",
                        reason=f"off-target screening skipped: genome window too large ({total_bp} bp > {max_bp} bp)",
                        annotation_computed=False,
                        severity=not_computed_severity,
                        cache_key=None,
                        cache_key_inputs_hash=None,
                        cache_hit=None,
                        cache_namespace="offtarget",
                    )
                else:
                    window_digest: list[dict[str, Any]] = []
                    for contig in sorted(genome_sequences.keys()):
                        seq = genome_sequences.get(contig)
                        if not isinstance(seq, str):
                            continue
                        window_digest.append(
                            {
                                "contig": str(contig),
                                "length": len(seq),
                                "sha256": hashlib.sha256(seq.encode("utf-8")).hexdigest(),
                            }
                        )
                    guide_payload = dict(guide) if isinstance(guide, Mapping) else {}
                    pam_rule_id = str(
                        base_params.get("pam")
                        or guide_payload.get("pam")
                        or guide_payload.get("pam_profile")
                        or "NGG"
                    )
                    pam_semantics: dict[str, Any] = {"id": pam_rule_id}
                    try:
                        from helix.crispr.pam import get_pam

                        pam_def = get_pam(pam_rule_id)
                        pam_semantics["name"] = str(pam_def.get("name") or "")
                        pam_semantics["pattern"] = str(pam_def.get("pattern") or "")
                        pam_semantics["orientation"] = str(pam_def.get("orientation") or "")
                    except Exception:
                        pam_semantics["name"] = pam_rule_id
                        pam_semantics["pattern"] = ""
                        pam_semantics["orientation"] = ""

                    spec_dict = experiment_spec_to_dict(experiment_spec)
                    locus_ctx = spec_dict.get("locus") if isinstance(spec_dict.get("locus"), Mapping) else {}
                    window_start_bp = _infer_window_start_bp(state, experiment_spec)
                    cache_inputs = {
                        "reference_id": reference_id,
                        "provider_id": provider_id,
                        "provider_version": provider_version,
                        "mode": mode,
                        "executed_mode": executed_mode,
                        "guide": guide_payload,
                        "pam_rule": pam_semantics,
                        "params": base_params,
                        "window": window_digest,
                        "window_start_bp": window_start_bp,
                        "locus": {
                            "chr": str(locus_ctx.get("chr") or ""),
                            "start": _maybe_int(locus_ctx.get("start")),
                            "end": _maybe_int(locus_ctx.get("end")),
                            "strand": str(locus_ctx.get("strand") or ""),
                        },
                    }
                    canonical_inputs, cache_key = _canonicalize_cache_inputs(cache_inputs)
                    cache_key_inputs_hash = cache_key
                    cached = _OFFTARGET_CACHE.get(cache_key, provider_version=provider_version)
                    if cached is not None:
                        off_target = replace(
                            cached,
                            cache_hit=True,
                            cache_key_inputs_hash=cached.cache_key_inputs_hash or cache_key_inputs_hash,
                            cache_namespace=cached.cache_namespace or "offtarget",
                        )
                        if off_target.status == "computed":
                            params_cached = off_target.params if isinstance(off_target.params, dict) else {}
                            max_mm_cached = params_cached.get("max_mm")
                            max_hits_cached = params_cached.get("max_hits")
                            constraints_cached: list[str] = []
                            if max_mm_cached is not None:
                                constraints_cached.append(f"max_mm<={int(max_mm_cached)}")
                            if max_hits_cached is not None:
                                constraints_cached.append(f"max_hits<={int(max_hits_cached)}")
                            off_target_model = ModelV2(
                                name=str(off_target.provider_id or provider_id or "offtarget_model"),
                                type="mechanistic",
                                constraints=constraints_cached,
                                calibration=CalibrationV2(
                                    dataset_id="unconfigured",
                                    domain=reference_id,
                                    notes=str(off_target.limitations or ""),
                                ),
                            )
                    else:
                        from helix.studio.offtargets.model import compute_offtargets_for_session, offtarget_report_to_dict

                        report = compute_offtargets_for_session(
                            None,
                            guide=guide,
                            genome_sequences=genome_sequences,
                            params=merged_params,
                            edit_plan=edit_plan if isinstance(edit_plan, Mapping) else None,
                        )
                        report_payload = offtarget_report_to_dict(report)
                        hits = report_payload.get("hits") if isinstance(report_payload.get("hits"), list) else []

                        provider_id_out = str(report_payload.get("modelId") or provider_id or "unconfigured")
                        provider_version_out = str(report_payload.get("modelVersion") or provider_version or "")
                        params_out = (
                            dict(report_payload.get("params") or {})
                            if isinstance(report_payload.get("params"), Mapping)
                            else dict(base_params)
                        )
                        if "window" not in params_out:
                            params_out["window"] = {
                                "contigs": [str(d.get("contig") or "") for d in window_digest],
                                "total_bp": int(total_bp),
                            }
                        if mode == "full":
                            params_out["requested_mode"] = "full"
                            params_out["full_mode_available"] = False

                        annotation_placeholder = {"status": "not_computed", "reason": "annotation tracks not loaded"}
                        sites: list[OffTargetSiteV2] = []
                        for hit in hits:
                            if not isinstance(hit, Mapping):
                                continue
                            contig = str(hit.get("contig") or "")
                            if not contig:
                                continue
                            start0 = _safe_int(hit.get("start"), default=0)
                            strand_val = str(hit.get("strand") or "+")
                            pos = int(start0 + int(window_start_bp or 0)) if window_start_bp is not None else int(start0)
                            score = _safe_float(hit.get("riskScore", hit.get("score", 0.0)))
                            mm = hit.get("totalMismatchCount")
                            if mm is None and isinstance(hit.get("mismatchPositions"), list):
                                mm = len([x for x in hit.get("mismatchPositions") if x is not None])
                            mismatches = _safe_int(mm, default=_safe_int(hit.get("distance"), default=0))
                            sites.append(
                                OffTargetSiteV2(
                                    locus=OffTargetLocusV2(chrom=contig, pos=pos, strand=strand_val),
                                    mismatches=int(mismatches),
                                    bulge=None,
                                    pam=str(hit.get("pamSequence") or ""),
                                    score=float(score),
                                    annotation=dict(annotation_placeholder),
                                )
                            )

                        sites.sort(
                            key=lambda s: (
                                -float(s.score),
                                f"{s.locus.chrom}:{int(s.locus.pos)}:{s.locus.strand}",
                            )
                        )
                        top_k = 25
                        sites = sites[:top_k]
                        scores = [float(s.score) for s in sites]
                        worst = max(scores) if scores else 0.0
                        total_score = float(sum(scores))

                        max_mm = report_payload.get("maxMismatches") or merged_params.get("max_mm")
                        max_hits = report_payload.get("hitCap") or merged_params.get("max_hits")

                        limitations_parts = []
                        if mode == "full" and executed_mode != "full":
                            limitations_parts.append(
                                "Full off-target requested, but only window-only screening is implemented here."
                            )
                        limitations_parts.append(
                            f"Screening is window-only ({len(window_digest)} contig(s), {int(total_bp)} bp total input)."
                        )
                        if max_mm is not None:
                            limitations_parts.append(f"Mismatch bound: max_mm<={int(max_mm)}.")
                        if max_hits is not None:
                            limitations_parts.append(f"Hit cap (provider): max_hits<={int(max_hits)}.")
                        limitations_parts.append(f"Summary top_sites truncated to {top_k}.")
                        limitations_parts.append(
                            f"{OFFTARGET_ANNOTATION_NOT_COMPUTED_TAG}: annotation tracks not loaded; feature overlap metrics set to 0."
                        )
                        limitations_parts.append(
                            "Scores are relative risk indicators (uncalibrated), not calibrated cleavage probabilities."
                        )
                        limitations = " ".join(limitations_parts).strip()

                        off_target = OffTargetBurdenV2(
                            status="computed",
                            off_target_mode=off_target_mode_src,
                            mode=mode,
                            executed_mode=executed_mode,
                            provider_id=provider_id_out,
                            provider_version=provider_version_out or None,
                            reference_id=reference_id,
                            params=params_out,
                            scope=scope,
                            limitations=limitations,
                            annotation_computed=False,
                            cache_key=cache_key,
                            cache_key_inputs_hash=cache_key_inputs_hash,
                            cache_hit=False,
                            cache_namespace="offtarget",
                            worst_site_score=float(worst),
                            sum_score=float(total_score),
                            p_hits_coding_exon=0.0,
                            p_hits_promoter=0.0,
                            p_hits_enhancer=0.0,
                            p_hits_splice=0.0,
                            top_sites=sites,
                        )
                        _OFFTARGET_CACHE.put(cache_key, off_target, provider_version=provider_version_out or provider_version)

                        constraints: list[str] = []
                        if max_mm is not None:
                            constraints.append(f"max_mm<={int(max_mm)}")
                        if max_hits is not None:
                            constraints.append(f"max_hits<={int(max_hits)}")
                        off_target_model = ModelV2(
                            name=provider_id_out or "offtarget_model",
                            type="mechanistic",
                            constraints=constraints,
                            calibration=CalibrationV2(
                                dataset_id="unconfigured",
                                domain=reference_id,
                                notes=limitations,
                            ),
                        )
    except Exception:
        pass

    # Structural risk (proxy, deterministic): build a break set and derive an event mixture.
    structural_cfg = _structural_config_from_overrides(structural_overrides)
    structural_sites_raw: list[StructuralBreakSite] = []
    try:
        cut_strand = "+" if str(cut_site.strand or "").lower() != "minus" else "-"
        structural_sites_raw.append(
            StructuralBreakSite(
                chrom=str(cut_site.chrom),
                pos=int(cut_site.pos),
                strand=cut_strand,
                cleavage_probability_proxy=float(cut_p),
                mismatch_profile={"mismatches": 0},
                tags=("on_target",),
                source="on_target",
            )
        )
    except Exception:
        pass

    try:
        targets = edit_plan.get("targets") if isinstance(edit_plan.get("targets"), list) else []
        window_start_bp = _infer_window_start_bp(state, experiment_spec)
        for target in targets:
            if not isinstance(target, Mapping):
                continue
            contig = str(target.get("contig") or target.get("chrom") or target.get("chr") or "")
            if not contig:
                continue
            base_start = _maybe_int(target.get("start")) if target.get("start") is not None else None
            if base_start is None:
                base_start = window_start_bp
            cut_index = _maybe_int(target.get("cutIndex") if target.get("cutIndex") is not None else target.get("cut_index"))
            if base_start is None or cut_index is None:
                continue
            strand_raw = str(target.get("strand") or "+")
            strand = "-" if strand_raw.strip() == "-" else "+"
            pos = int(base_start + int(cut_index))
            structural_sites_raw.append(
                StructuralBreakSite(
                    chrom=contig,
                    pos=int(pos),
                    strand=strand,
                    cleavage_probability_proxy=float(cut_p),
                    mismatch_profile={"mismatches": 0},
                    tags=("on_target", "planned_target"),
                    source="edit_plan",
                )
            )
    except Exception:
        pass

    try:
        if off_target.status == "computed" and off_target.top_sites is not None:
            scope_tag = "genome_wide" if str(off_target.scope or "") == "genome_wide" else "window_only"
            for site in off_target.top_sites or []:
                locus = getattr(site, "locus", None)
                if locus is None:
                    continue
                chrom = str(getattr(locus, "chrom", "") or "")
                strand = str(getattr(locus, "strand", "") or "+") or "+"
                pos = getattr(locus, "pos", None)
                if not chrom or pos is None:
                    continue
                score = float(getattr(site, "score", 0.0) or 0.0)
                mismatches = int(getattr(site, "mismatches", 0) or 0)
                pam = str(getattr(site, "pam", "") or "")
                tags = ("off_target", scope_tag)
                structural_sites_raw.append(
                    StructuralBreakSite(
                        chrom=chrom,
                        pos=int(pos),
                        strand=strand,
                        cleavage_probability_proxy=score,
                        mismatch_profile={"mismatches": mismatches, "pam": pam},
                        tags=tags,
                        source="off_target",
                    )
                )
    except Exception:
        pass

    # Dedupe by locus key (keep max cleavage proxy, merge tags) for stable downstream computations.
    site_by_key: dict[tuple[str, int, str], StructuralBreakSite] = {}
    for s in structural_sites_raw:
        try:
            sn = s.normalized()
        except Exception:
            continue
        key = (str(sn.chrom), int(sn.pos), str(sn.strand))
        prev = site_by_key.get(key)
        if prev is None:
            site_by_key[key] = sn
            continue
        p_prev = float(prev.cleavage_probability_proxy)
        p_new = float(sn.cleavage_probability_proxy)
        p = max(p_prev, p_new)
        tags = tuple(sorted(set(prev.tags).union(sn.tags)))
        source = "on_target" if "on_target" in tags else (prev.source if p_prev >= p_new else sn.source)
        mismatch_profile = dict(prev.mismatch_profile or {})
        mismatch_profile.update(dict(sn.mismatch_profile or {}))
        site_by_key[key] = StructuralBreakSite(
            chrom=prev.chrom,
            pos=prev.pos,
            strand=prev.strand,
            cleavage_probability_proxy=p,
            mismatch_profile=mismatch_profile,
            tags=tags,
            source=source,
        )

    structural_sites = list(site_by_key.values())
    structural_run_mode = str(desired_struct_mode or "local_screening").strip().lower()
    structural_reason: str | None = None
    if structural_run_mode == "full":
        # compute_structural_risk will downshift executed_mode, but requires break set coverage.
        pass
    if structural_run_mode in {"genome_screening", "full"} and off_target.status != "computed":
        structural_run_mode = "local_screening"
        structural_reason = "genome_screening_requested_but_off_target_not_computed"

    structural = compute_structural_risk(structural_sites, mode=structural_run_mode, config=structural_cfg)
    if str(desired_struct_mode or "") and str(structural.mode or "") != str(desired_struct_mode or ""):
        # Preserve requested mode for auditability; executed_mode captures what actually ran.
        limitations = str(structural.limitations or "")
        if structural_reason:
            limitations = (limitations + " " + "Genome screening requested but off-target break set was not computed.").strip()
        structural = StructuralRiskResultV1(
            schema=str(structural.schema),
            status=str(structural.status),
            mode=str(desired_struct_mode),
            executed_mode=str(structural_run_mode),
            scope=str(structural.scope),
            limitations=limitations or "unconfigured",
            reason=structural_reason or structural.reason,
            params=dict(structural.params or {}),
            break_sites=structural.break_sites,
            event_distribution=dict(structural.event_distribution or {}),
            large_deletion_length_bins=structural.large_deletion_length_bins,
            top_inversion_pairs=structural.top_inversion_pairs,
            top_translocation_pairs=structural.top_translocation_pairs,
            chrom_pair_masses=structural.chrom_pair_masses,
            metrics=dict(structural.metrics or {}),
        )

    topology = Topology3dV2(status="not_computed", reason="3D topology overlays not loaded")
    risk = RiskV2(tail=tail, hazard=hazard, off_target=off_target, structural=structural, topology_3d=topology)

    integrity = IntegrityV2(failures=[], warnings=[])
    if abs(sum(o.p_total for o in outcomes_v2) - 1.0) > 1e-6:
        integrity.failures.append("probability_not_conserved")
    if cut_p > 0.0:
        p_gc = sum(o.p_given_cut for o in outcomes_v2 if o.p_given_cut is not None)  # type: ignore[arg-type]
        if abs(float(p_gc) - 1.0) > 1e-6:
            integrity.failures.append("cut_condition_inconsistent")
    if cut_p > 0.05 and any(c.upper() in {"NHEJ", "MMEJ"} for c in repair_constraints):
        frameshift_mass = sum(
            oc.p_total * oc.frameshift.p for oc in outcomes_v2 if oc.p_given_cut is not None and oc.frameshift.source == "computed"
        )
        any_noncomputed = any(
            oc.frameshift.source != "computed" for oc in outcomes_v2 if oc.p_given_cut is not None
        )
        if frameshift_mass == 0.0 and not any_noncomputed:
            integrity.failures.append("frameshift_zero_implausible")
    if risk.off_target.status != "computed":
        integrity.warnings.append("off_target_not_computed")
    elif str(risk.off_target.executed_mode or "") == "screening":
        integrity.warnings.append("off_target_screening")
    if str(getattr(risk.structural, "status", "")) != "computed":
        integrity.warnings.append("structural_not_computed")
    elif str(getattr(risk.structural, "executed_mode", "")) != str(getattr(risk.structural, "mode", "")):
        integrity.warnings.append("structural_mode_degraded")
    if risk.topology_3d.status != "computed":
        integrity.warnings.append("topology_3d_not_computed")
    if risk.hazard.status != "computed":
        integrity.warnings.append("hazard_not_computed")
    if control.convergence.status != "computed":
        integrity.warnings.append("convergence_not_computed")
    if control.iteration.status != "computed":
        integrity.warnings.append("iteration_not_computed")
    elif str(control.iteration.transition_model or "") == "identity":
        integrity.warnings.append("iteration_transition_identity")
    if control.convergence.status == "computed":
        try:
            conv_init = control.convergence.initial_fractions
            if conv_init is not None:
                s_init = float(conv_init.intended_p) + float(conv_init.uncut_p) + float(conv_init.harmful_p)
                if abs(s_init - 1.0) > 1e-6:
                    integrity.failures.append("convergence_fraction_not_conserved")
        except Exception:
            integrity.failures.append("convergence_fraction_not_conserved")
        try:
            for pt in control.convergence.projected or []:
                s_pt = float(pt.intended_p) + float(pt.uncut_p) + float(pt.harmful_p)
                if abs(s_pt - 1.0) > 1e-6:
                    integrity.failures.append("convergence_fraction_not_conserved")
                    break
        except Exception:
            integrity.failures.append("convergence_fraction_not_conserved")

    model_stack = ModelStackV2(repair_model=repair_model, off_target_model=off_target_model)
    noncompliance_reasons: list[str] = []
    if not policy_payload:
        noncompliance_reasons.append("policy_not_loaded")
    expected_domain = str(experiment_spec_to_dict(experiment_spec).get("reference", {}).get("genomeBuild") or "")
    if expected_domain:
        if str(repair_model.calibration.domain or "") != expected_domain:
            noncompliance_reasons.append("calibration_domain_mismatch.repair_model")
        if str(off_target_model.calibration.domain or "") != expected_domain:
            noncompliance_reasons.append("calibration_domain_mismatch.off_target_model")
    if policy_ot_required and risk.off_target.status != "computed":
        noncompliance_reasons.append("off_target_required_but_not_computed")
    if policy_ot_required and policy_ot_compute == "full" and risk.off_target.status == "computed":
        if str(risk.off_target.executed_mode or "") != "full":
            noncompliance_reasons.append("screening_used_but_policy_requires_full")
    if policy_struct_required and str(getattr(risk.structural, "status", "")) != "computed":
        noncompliance_reasons.append("structural_risk_required_but_not_computed")
    if policy_struct_required and str(policy_struct_compute or "") in {"genome_screening", "full"}:
        if str(getattr(risk.structural, "executed_mode", "")) not in {"genome_screening", "full"}:
            noncompliance_reasons.append("structural_screening_used_but_policy_requires_genome")
    conv_policy = _resolve_convergence_policy(policy_payload)
    if bool(conv_policy.get("required")) and control.convergence.status != "computed":
        noncompliance_reasons.append("convergence_required_but_not_computed")
    for reason in iteration_noncompliance:
        noncompliance_reasons.append(reason)
    compliant_with_policy = not noncompliance_reasons

    stability = _compute_stability(
        policy_payload=policy_payload,
        control=control,
        risk=risk,
        integrity=integrity,
        compliant_with_policy=compliant_with_policy,
        noncompliance_reasons=noncompliance_reasons,
    )
    if stability.status != "computed":
        integrity.warnings.append("stability_not_computed")

    control = ControlV2(
        intended_functional_p=float(control.intended_functional_p),
        dominance_ratio=float(control.dominance_ratio),
        entropy_bits=float(control.entropy_bits),
        no_cut_p=float(control.no_cut_p),
        convergence=control.convergence,
        stability=stability,
        iteration=control.iteration,
        claims=control.claims,
        flags=list(control.flags),
    )

    stability_policy = _resolve_stability_policy(policy_payload)
    if bool(stability_policy.get("required")) and control.stability.status != "computed":
        noncompliance_reasons.append("stability_required_but_not_computed")

    compliant_with_policy = not noncompliance_reasons
    verdict = _compute_verdict(
        control=control,
        risk=risk,
        integrity=integrity,
        compliant_with_policy=compliant_with_policy,
        noncompliance_reasons=noncompliance_reasons,
    )

    hazard_policy = _resolve_hazard_policy(policy_payload)
    iter_enabled, _iter_required, claims_required, _stress_policy = _resolve_iteration_policy(policy_payload)
    invalid_causes: list[str] = []
    if policy_ot_required and risk.off_target.status != "computed":
        invalid_causes.append("off_target_required_but_not_computed")
    if policy_struct_required and str(getattr(risk.structural, "status", "")) != "computed":
        invalid_causes.append("structural_risk_required_but_not_computed")
    if policy_struct_required and str(policy_struct_compute or "") in {"genome_screening", "full"}:
        if str(getattr(risk.structural, "executed_mode", "")) not in {"genome_screening", "full"}:
            invalid_causes.append("structural_screening_used_but_policy_requires_genome")
    if hazard_policy.get("splice_required") and risk.hazard.status != "computed":
        invalid_causes.append("splice_risk_required_but_not_computed")
    if hazard_policy.get("regulatory_required") and risk.hazard.status != "computed":
        invalid_causes.append("regulatory_risk_required_but_not_computed")
    if claims_required:
        claims_obj = control.claims
        if claims_obj is None:
            invalid_causes.append("claims_required_but_not_computed")
        elif not bool(getattr(claims_obj, "clean", False)):
            invalid_causes.append("claims_dirty")
    if iter_enabled:
        iter_cfg = control.iteration
        if bool(getattr(iter_cfg, "transition_required", False)) and str(getattr(iter_cfg, "transition_model", "") or "") == "identity":
            invalid_causes.append("perturbations_required_but_unsupported")
    if species_required_unresolved:
        invalid_causes.append("SPECIES_UNRESOLVED")

    validity = {"status": "invalid" if invalid_causes else "valid", "root_causes": list(invalid_causes)}

    # Decision-grade readiness gates.
    model_id, model_version = _extract_model_identity(state, fallback_model_id=repair_model.name)
    model_hash = _sha256_prefixed_payload({"model_id": model_id, "model_version": model_version})
    calibration_dataset_id = str(repair_model.calibration.dataset_id or "") or "unconfigured"

    decision_mode_requested = _resolve_decision_mode_policy(policy_payload)
    calibration_bundle_id = "unconfigured"
    calibration_bundle_hash = "sha256:unavailable"
    calibration_bundle_created_at_utc = "unavailable"
    calibration_dataset_checksum = "sha256:unavailable"
    calibration_ready = False
    calibration_bundle_code_hash = "sha256:unavailable"
    calibration_bundle_model_id = "unconfigured"
    calibration_bundle_model_version = "unconfigured"
    calibration_bundle_model_hash = "sha256:unavailable"
    calibration_bundle_calibration_dataset_id = "unconfigured"
    calibration_bundle_calibration_dataset_checksum = "sha256:unavailable"
    calibration_bundle_heldout_dataset_id = "unconfigured"
    calibration_bundle_heldout_dataset_checksum = "sha256:unavailable"
    calibration_bundle_target_id = "unconfigured"
    calibration_coverage_status = "unspecified"
    calibration_coverage_mismatches: list[str] = []
    calibration_bundle_present = False
    try:
        from helix.calibration.bundle import find_calibration_bundle

        requested_dataset_id = calibration_dataset_id if calibration_dataset_id not in {"", "unconfigured"} else None
        bundle = find_calibration_bundle(
            model_id=model_id,
            model_version=model_version,
            model_hash=model_hash,
            calibration_dataset_id=requested_dataset_id,
        )
        if isinstance(bundle, Mapping):
            calibration_bundle_present = True
            calibration_bundle_id = str(bundle.get("bundle_id") or "calibration_bundle")
            calibration_bundle_hash = str(bundle.get("bundle_hash") or "sha256:unavailable")
            calibration_bundle_created_at_utc = str(bundle.get("created_at_utc") or "unavailable")
            prov = bundle.get("provenance") if isinstance(bundle.get("provenance"), Mapping) else {}
            calibration_bundle_code_hash = str(prov.get("evaluation_code_hash") or "sha256:unavailable")
            target = bundle.get("target") if isinstance(bundle.get("target"), Mapping) else {}
            calibration_bundle_target_id = (
                str(target.get("target_id") or target.get("scalar_id") or target.get("id") or "").strip()
                or "unconfigured"
            )
            bundle_model = bundle.get("model") if isinstance(bundle.get("model"), Mapping) else {}
            calibration_bundle_model_id = str(bundle_model.get("model_id") or "unconfigured")
            calibration_bundle_model_version = str(bundle_model.get("model_version") or "unconfigured")
            calibration_bundle_model_hash = str(bundle_model.get("model_hash") or "sha256:unavailable")
            datasets = bundle.get("datasets") if isinstance(bundle.get("datasets"), Mapping) else {}
            cal_ds = (
                datasets.get("calibration_dataset")
                if isinstance(datasets.get("calibration_dataset"), Mapping)
                else {}
            )
            ds_id = str(cal_ds.get("id") or "")
            ds_checksum = str(cal_ds.get("checksum") or "sha256:unavailable")
            calibration_bundle_calibration_dataset_id = ds_id or "unconfigured"
            calibration_bundle_calibration_dataset_checksum = ds_checksum or "sha256:unavailable"
            held_ds = datasets.get("heldout_dataset") if isinstance(datasets.get("heldout_dataset"), Mapping) else {}
            held_id = str(held_ds.get("id") or "")
            held_checksum = str(held_ds.get("checksum") or "sha256:unavailable")
            calibration_bundle_heldout_dataset_id = held_id or "unconfigured"
            calibration_bundle_heldout_dataset_checksum = held_checksum or "sha256:unavailable"
            if calibration_dataset_id in {"", "unconfigured"} and ds_id:
                calibration_dataset_id = ds_id
                try:
                    repair_model = replace(repair_model, calibration=replace(repair_model.calibration, dataset_id=ds_id))
                    model_stack = replace(model_stack, repair_model=repair_model)
                except Exception:
                    pass
            heldout = bundle.get("heldout_summary") if isinstance(bundle.get("heldout_summary"), Mapping) else {}
            held_metrics = heldout.get("metrics") if isinstance(heldout.get("metrics"), Mapping) else {}
            grade_corr = held_metrics.get("grade_correlation")
            grade_corr_ok = isinstance(grade_corr, (int, float)) and math.isfinite(float(grade_corr))
            if (
                ds_id == calibration_dataset_id
                and ds_checksum.startswith("sha256:")
                and ds_checksum != "sha256:unavailable"
                and calibration_bundle_hash.startswith("sha256:")
                and calibration_bundle_hash != "sha256:unavailable"
                and calibration_bundle_code_hash.startswith("sha256:")
                and calibration_bundle_code_hash != "sha256:unavailable"
                and grade_corr_ok
            ):
                calibration_dataset_checksum = ds_checksum
                calibration_ready = True

            # Coverage: optional but enforceable when present.
            coverage = bundle.get("coverage") if isinstance(bundle.get("coverage"), Mapping) else None
            if isinstance(coverage, Mapping) and coverage:
                try:
                    from helix.studio.calibration_coverage import build_run_context_v1, evaluate_coverage

                    run_ctx = build_run_context_v1(intended_edit_spec=intended_edit_spec, reference_genome_id=reference_id)
                    match = evaluate_coverage(coverage, run_context=run_ctx)
                    calibration_coverage_status = match.status
                    calibration_coverage_mismatches = list(match.reasons)
                    if match.status == "out_of_coverage":
                        calibration_ready = False
                except Exception:
                    calibration_coverage_status = "unspecified"
    except Exception:
        calibration_ready = False
    uncertainty_ready = str(uncertainty_payload.get("status") or "") == "computed"
    backend_prov = _backend_provenance()
    prov_git = _safe_text(backend_prov.get("git_commit"))
    prov_ts = _safe_text(backend_prov.get("build_timestamp_utc"))
    provenance_ready = bool(
        prov_git
        and prov_git != "unavailable"
        and prov_ts
        and prov_ts != "unavailable"
        and str(model_hash or "").startswith("sha256:")
        and str(model_hash or "") != "sha256:unavailable"
        and bool(priors)
    )
    decision_grade_ready = (
        bool(validity["status"] == "valid")
        and calibration_ready
        and uncertainty_ready
        and provenance_ready
        and (not on_target_ood_flag)
    )
    if decision_mode_requested is None:
        decision_mode_requested = "decision_grade" if decision_grade_ready else "filter_only"
    decision_mode = "decision_grade" if (decision_mode_requested == "decision_grade" and decision_grade_ready) else "filter_only"
    if validity["status"] != "valid":
        decision_mode = "filter_only"

    license_block: dict[str, Any] | None = None
    if decision_mode == "decision_grade":
        # Governance / decision-grade assertions are license-gated (offline, fail-fast).
        from helix.licensing import require_capability

        edit_program_id = None
        try:
            spec_payload = experiment_spec_to_dict(experiment_spec)
            cand = str(spec_payload.get("experimentId") or "").strip()
            if cand and cand != "unset":
                edit_program_id = cand
        except Exception:
            edit_program_id = None

        lic = require_capability("governance", edit_program_id=edit_program_id)
        license_block = {
            "status": "licensed",
            "license_id": str(lic.license_id),
            "issuer_key_id": str(lic.issuer_key_id),
            "license_sha256": str(lic.license_sha256),
            "org": str(lic.org),
            "edit_program_id": str(lic.edit_program_id),
            "capabilities": sorted(lic.capabilities),
        }

    if on_target_ood_flag:
        try:
            integrity.warnings.append("on_target_out_of_domain")
        except Exception:
            pass
    if on_target_encoding_only:
        try:
            integrity.warnings.append("on_target_untrusted")
        except Exception:
            pass
    if on_target_high_novelty:
        try:
            integrity.warnings.append("on_target_high_novelty")
        except Exception:
            pass

    decision_notes: list[str] = []
    if decision_mode != "decision_grade":
        if not calibration_ready:
            if calibration_bundle_present and calibration_coverage_status == "out_of_coverage":
                decision_notes.append("not_decision_grade: calibration_out_of_domain")
            else:
                decision_notes.append("not_decision_grade: calibration_bundle_missing")
        if on_target_ood_flag:
            decision_notes.append("not_decision_grade: on_target_out_of_domain")
        if on_target_encoding_only:
            decision_notes.append("not_decision_grade: on_target_untrusted")
        if on_target_high_novelty:
            decision_notes.append("validation_required: on_target_high_novelty")
        if not uncertainty_ready:
            decision_notes.append("not_decision_grade: uncertainty_not_computed")
        if not provenance_ready:
            decision_notes.append("not_decision_grade: provenance_incomplete")
        if invalid_causes:
            decision_notes.extend([f"invalid:{c}" for c in invalid_causes])
    # Grade caps: missing required risk fields must not yield A/B semantics.
    if invalid_causes and verdict.grade in {"A", "B"}:
        verdict = replace(verdict, grade="C", headline=HEADLINE_BY_GRADE["C"])
    # Grade caps: out-of-domain on-target should never carry A/B semantics.
    if on_target_ood_flag and verdict.grade in {"A", "B"}:
        verdict = replace(verdict, grade="C", headline=HEADLINE_BY_GRADE["C"])
        decision_notes.append("grade_capped: on_target_out_of_domain")

    decision = "insufficient_evidence"
    if validity["status"] != "valid":
        decision = "insufficient_evidence"
    elif decision_mode == "filter_only":
        if integrity.failures or verdict.grade == "F":
            decision = "no_go"
        elif (not verdict.compliant_with_policy) or verdict.grade in {"C", "D"}:
            decision = "redesign_required"
        else:
            decision = "insufficient_evidence"
    else:
        decision = (
            "go"
            if (not integrity.failures) and verdict.compliant_with_policy and verdict.grade in {"A", "B"}
            else "no_go"
        )

    verdict = replace(verdict, decision=decision, decision_mode=decision_mode, decision_notes=decision_notes)
    recommendations: list[RecommendationV2] = []
    if decision_mode == "decision_grade":
        recommendations = _build_recommendations(
            control=control,
            risk=risk,
            verdict=verdict,
            noncompliance_reasons=noncompliance_reasons,
        )
        if on_target_high_novelty:
            recommendations.append(
                RecommendationV2(
                    recommendation_id="validate_on_target_high_novelty",
                    title="Validate on-target activity (high novelty)",
                    suggestion="Consider adding a targeted validation at the primary locus (e.g., amplicon sequencing) because the on-target model reports high novelty near its domain boundary.",
                    triggered_by=[
                        RecommendationTriggerV2(
                            metric_path="provenance.assumptions.on_target_engine.novelty",
                            condition=f">= {novelty_threshold:.2f}",
                            value=float(on_target_novelty or 0.0),
                        )
                    ],
                )
            )

    off_target_policy_snapshot = {
        "compute": policy_ot_compute,
        "required": bool(policy_ot_required),
        "overrides": dict(ot_overrides),
        "off_target_mode": off_target_mode_src,
    }
    params_snapshot = _build_params_snapshot(
        state=state,
        policy_hash=policy_hash,
        spec_hash=spec_hash,
        decision_mode_requested=str(decision_mode_requested),
        off_target_policy=off_target_policy_snapshot,
        hazard_policy=dict(hazard_policy),
    )
    params_hash = _sha256_prefixed_payload(params_snapshot)

    priors_hash = "sha256:unavailable"
    priors_id = "unavailable"
    if isinstance(priors, Mapping) and priors:
        priors_id = "sim_payload.priors"
        priors_hash = _sha256_prefixed_payload(priors)

    genome_checksum = "sha256:unavailable"
    try:
        genome_sequences = state.get("genome") if isinstance(state.get("genome"), Mapping) else None
        if isinstance(genome_sequences, Mapping) and genome_sequences:
            digest = [
                {
                    "contig": str(contig),
                    "length": len(seq) if isinstance(seq, str) else None,
                    "sha256": hashlib.sha256(seq.encode("utf-8")).hexdigest() if isinstance(seq, str) else None,
                }
                for contig, seq in sorted(genome_sequences.items(), key=lambda kv: str(kv[0]))
                if isinstance(contig, str) and isinstance(seq, str)
            ]
            genome_checksum = _sha256_prefixed_payload({"contigs": digest})
    except Exception:
        genome_checksum = "sha256:unavailable"

    ann = state.get("annotations")
    if not isinstance(ann, Mapping):
        ann = state.get("annotation") if isinstance(state.get("annotation"), Mapping) else {}
    ann_id = _safe_text(ann.get("dataset_id") or ann.get("datasetId") or ann.get("id") or "embedded")
    ann_checksum = "sha256:unavailable"
    try:
        ann_checksum = _sha256_prefixed_payload(dict(ann))
    except Exception:
        ann_checksum = "sha256:unavailable"

    provenance = {
        "backend": _backend_provenance(),
        "model": {
            "model_id": model_id,
            "model_version": model_version,
            "model_hash": model_hash,
            "off_target_model_id": str(off_target_model.name or ""),
            "off_target_model_version": str(getattr(off_target, "provider_version", "") or ""),
        },
        "params": {
            "params_hash": params_hash,
            "snapshot": params_snapshot,
        },
        "assumptions": {
            "cut_repair_profile": {"id": priors_id, "hash": priors_hash},
        },
        "aggregation": {
            "version": "summary_contract_v2",
            "hash": _summary_contract_source_hash(),
        },
        "data": {
            "experiment_intent_spec": {"id": str(intent_payload.get("intentId") or "unset"), "checksum": intent_sha_pref},
            "reference_genome": {"id": reference_id, "checksum": genome_checksum},
            "annotation_dataset": {"id": ann_id, "checksum": ann_checksum},
            "calibration_dataset": {"id": calibration_dataset_id, "checksum": calibration_dataset_checksum},
            "calibration_bundle": {
                "id": calibration_bundle_id,
                "checksum": calibration_bundle_hash,
                "created_at_utc": calibration_bundle_created_at_utc,
                "evaluation_code_hash": calibration_bundle_code_hash,
                "target_id": calibration_bundle_target_id,
                "model_id": calibration_bundle_model_id,
                "model_version": calibration_bundle_model_version,
                "model_hash": calibration_bundle_model_hash,
                "calibration_dataset_id": calibration_bundle_calibration_dataset_id,
                "calibration_dataset_checksum": calibration_bundle_calibration_dataset_checksum,
                "heldout_dataset_id": calibration_bundle_heldout_dataset_id,
                "heldout_dataset_checksum": calibration_bundle_heldout_dataset_checksum,
                "coverage_status": calibration_coverage_status,
                "coverage_mismatches": list(calibration_coverage_mismatches[:20]),
            },
        },
    }
    if license_block is not None:
        provenance["license"] = license_block
    if isinstance(on_target_engine, Mapping) and on_target_engine:
        try:
            provenance["assumptions"]["on_target_engine"] = dict(on_target_engine)  # type: ignore[index]
        except Exception:
            pass

    species_block: dict[str, Any] | None = None
    if isinstance(species_detection, Mapping):
        res_taxon_id = str(species_resolution.get("taxon_id") or "")
        res_name = ""
        hypotheses = species_detection.get("hypotheses") if isinstance(species_detection.get("hypotheses"), list) else []
        for hyp in hypotheses:
            if not isinstance(hyp, Mapping):
                continue
            tax = hyp.get("taxon") if isinstance(hyp.get("taxon"), Mapping) else {}
            if str(tax.get("taxon_id") or "") == res_taxon_id:
                res_name = str(tax.get("name") or "")
                break
        species_block = {
            "status": str(species_status or "unknown"),
            "required": bool(policy_species_required),
            "resolution": dict(species_resolution) if isinstance(species_resolution, Mapping) else {},
            "db_bundle_id": str(species_detection.get("db_bundle_id") or ""),
            "db_bundle_hash": str(species_detection.get("db_bundle_hash") or ""),
            "artifact_hash": str(species_detection.get("artifact_hash") or ""),
            "taxon_name": res_name,
        }
    elif policy_species_required:
        species_block = {
            "status": "not_available",
            "required": True,
            "resolution": {},
            "db_bundle_id": "",
            "db_bundle_hash": "",
            "artifact_hash": "",
        }

    summary = RunSummaryV2(
        run_id=run_id,
        spec_hash=spec_hash,
        policy_id=policy_id,
        policy_hash=policy_hash,
        decision_mode_requested=str(decision_mode_requested),
        decision_mode=str(decision_mode),
        validity=validity,
        provenance=provenance,
        intended_edit_spec=intended_edit_spec,
        uncertainty=dict(uncertainty_payload),
        species_detection=species_block,
        model_stack=model_stack,
        cut_site=cut_site,
        outcomes=outcomes_v2,
        control=control,
        risk=risk,
        integrity=integrity,
        verdict=verdict,
        recommendations=recommendations,
    )
    payload = summary.to_dict()

    payload["experiment_intent_spec"] = {
        "schema": EXPERIMENT_INTENT_SPEC_SCHEMA_ID,
        "status": str(intent_status),
        "sha256": str(intent_sha_pref),
        "missing_fields": list(intent_missing_fields),
        "validation_error": str(intent_err) if intent_err else None,
    }
    payload["experiment_intent_ref"] = {
        "status": str(intent_ref_status),
        "kind": (intent_ref_kind or None),
        "sha256": (_sha256_prefixed_hex(intent_ref_sha) if intent_ref_sha else None),
    }

    # Declared cell context (export-friendly).
    try:
        spec_payload = experiment_spec_to_dict(experiment_spec)
        assumptions = spec_payload.get("assumptions") if isinstance(spec_payload.get("assumptions"), Mapping) else {}
        cell_ctx, ctx_warnings = parse_cell_context(assumptions)
        payload["cell_context"] = {
            "cellLine": cell_ctx.cell_line,
            "delivery": cell_ctx.delivery_mode or "RNP",
            "deliveryDeclared": cell_ctx.delivery_mode is not None,
            "repairBiasPreset": cell_ctx.repair_bias_preset or "neutral",
            "repairBiasPresetDeclared": cell_ctx.repair_bias_preset is not None,
            "accessibilityScalar": float(cell_ctx.accessibility_scalar) if cell_ctx.accessibility_scalar is not None else 1.0,
            "accessibilityScalarDeclared": cell_ctx.accessibility_scalar is not None,
            "breadcrumb": cell_context_breadcrumb(cell_ctx),
            "warnings": ctx_warnings,
        }
    except Exception:
        pass

    # ---------------------------------------------------------------------
    # Auditability extensions (best-effort; do not gate validation).
    # ---------------------------------------------------------------------

    # Models: multi-model aware identity scaffold (future-proof for kinetics/off-target stacks).
    edit_outcome_calibration = "calibrated" if calibration_ready else "uncalibrated"
    payload["models"] = {
        "edit_outcome": {
            "name": str(model_id),
            "version": str(model_version),
            "hash": str(model_hash),
            "calibration": edit_outcome_calibration,
            "calibration_bundle": {
                "id": str(calibration_bundle_id),
                "checksum": str(calibration_bundle_hash),
                "created_at_utc": str(calibration_bundle_created_at_utc),
                "dataset_id": str(calibration_dataset_id),
                "dataset_checksum": str(calibration_dataset_checksum),
            },
            "training_data": {
                "status": "unknown",
                "reason": "training data provenance not recorded for this model id/version in the snapshot",
            },
        },
        "kinetics": None,
        "off_target": {
            "name": str(off_target_model.name),
            "version": str(getattr(off_target, "provider_version", "") or "unconfigured"),
            "calibration": "uncalibrated" if str(off_target_model.calibration.dataset_id or "") in {"", "unconfigured"} else "calibrated",
        }
        if isinstance(off_target_model, ModelV2)
        else None,
        "structural_risk": {
            "name": "structural_risk_proxy_v1",
            "version": "v1",
            "calibration": "uncalibrated",
            "executed_mode": str(getattr(risk.structural, "executed_mode", "") or "not_computed"),
            "scope": str(getattr(risk.structural, "scope", "") or "not_computed"),
        },
    }

    # Probability namespaces: make semantics explicit so future "rates"/"scores" don't collide.
    has_counts = (
        str(uncertainty_payload.get("status") or "") == "computed"
        and isinstance(uncertainty_payload.get("draws"), int)
        and int(uncertainty_payload.get("draws") or 0) > 0
    )
    estimator = "monte_carlo_frequency" if has_counts else "model_point_estimate"
    payload["probabilities"] = {
        "edit_outcome": {
            "semantics": "point_estimate",
            "estimator": estimator,
            "calibrated": bool(decision_mode == "decision_grade"),
            "calibration_method": None,
            "uncertainty": {
                "status": str(uncertainty_payload.get("status") or "not_computed"),
                "kind": str(uncertainty_payload.get("kind") or "") or None,
                "level": float(uncertainty_payload.get("level")) if isinstance(uncertainty_payload.get("level"), (int, float)) else None,
                "entropy_bits": float(control.entropy_bits),
            },
        },
        "structural_risk": {
            "semantics": "proxy_mixture",
            "estimator": "break_graph_proxy_v1",
            "calibrated": False,
            "status": str(getattr(risk.structural, "status", "") or "not_computed"),
            "mode": str(getattr(risk.structural, "mode", "") or "unconfigured"),
            "executed_mode": str(getattr(risk.structural, "executed_mode", "") or "unconfigured"),
            "scope": str(getattr(risk.structural, "scope", "") or "unconfigured"),
        },
    }
    payload["rates"] = None

    # Contextual assumptions: split into global vs model-local, explicitly.
    intended = payload.get("intended_edit_spec") if isinstance(payload.get("intended_edit_spec"), Mapping) else {}
    pop = intended.get("population") if isinstance(intended.get("population"), Mapping) else {}
    pop_mode = str(pop.get("mode") or "")
    global_assumptions: list[str] = []
    if pop_mode:
        global_assumptions.append(f"{pop_mode.replace('_', ' ')} cell population")
    else:
        global_assumptions.append("cell population unspecified (model interpreted as bulk)")
    global_assumptions.append("steady-state outcome distribution (no kinetics model)")

    # Sequence window used (best-effort; do not persist sequence).
    seq_len = None
    try:
        seq = state.get("sequence")
        if isinstance(seq, str) and seq:
            seq_len = len(seq)
        else:
            viz = state.get("viz_spec_payload") if isinstance(state.get("viz_spec_payload"), Mapping) else {}
            site = viz.get("site") if isinstance(viz.get("site"), Mapping) else {}
            seq2 = site.get("sequence")
            if isinstance(seq2, str) and seq2:
                seq_len = len(seq2)
    except Exception:
        seq_len = None
    try:
        cfg = state.get("config") if isinstance(state.get("config"), Mapping) else {}
        guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
        cut_index = guide.get("cut_index", guide.get("cutIndex"))
        cut_index_int = int(cut_index) if cut_index is not None else None
    except Exception:
        cut_index_int = None
    if isinstance(seq_len, int) and seq_len > 0:
        if cut_index_int is None:
            global_assumptions.append(f"sequence window length {seq_len} bp (cut index unknown)")
        else:
            left = max(0, min(int(cut_index_int), int(seq_len)))
            right = max(0, int(seq_len) - int(left))
            global_assumptions.append(f"sequence window length {seq_len} bp (≈{left} bp left, {right} bp right of cut index)")
    else:
        global_assumptions.append("sequence window length not available in snapshot")

    edit_model_assumptions: list[str] = [
        "chromatin/epigenetic context ignored",
        "cell-cycle effects ignored (averaged)",
        "DSB kinetics/persistence not modeled; structural risk is a proxy mixture over end-joining events",
    ]
    offt_assumptions: list[str] = [
        "off-target model is a mismatch/bulge heuristic unless a genome-wide provider is configured",
        "off-target risk is not calibrated unless an explicit calibration dataset is configured",
    ]
    payload["assumptions"] = {
        "global": global_assumptions,
        "edit_outcome_model": edit_model_assumptions,
        "off_target_model": offt_assumptions,
    }

    # Repair pathway decomposition (bridge to future kinetics/off-target integrations).
    pathway_mass = {"nhej": 0.0, "mmej": 0.0, "religation": 0.0, "no_cut": 0.0, "other": 0.0}
    insertion_total = 0.0
    insertion_len_mixture: dict[int, float] = {}
    for oc in pending_outcomes:
        label = str(oc.get("label") or "")
        p = float(oc.get("p_total") or 0.0)
        if _is_no_cut_label(label):
            pathway_mass["no_cut"] += p
            continue
        norm = label.lower()
        if "microhomology" in norm or "mmej" in norm:
            pathway_mass["mmej"] += p
        elif "religation" in norm or "re-ligation" in norm or "reanneal" in norm:
            pathway_mass["religation"] += p
        elif "hdr" in norm:
            pathway_mass["other"] += p
        else:
            pathway_mass["nhej"] += p

        # Insertion subtype accounting (best-effort).
        try:
            delta = int(oc.get("delta_bp") or 0)
        except Exception:
            delta = 0
        if delta > 0:
            insertion_total += p
            dist = _infer_indel_len_dist(label=label, delta_bp=delta, priors=priors)
            for length, prob in dist.items():
                insertion_len_mixture[int(length)] = insertion_len_mixture.get(int(length), 0.0) + p * float(prob)

    tot = sum(pathway_mass.values()) or 1.0
    for k in list(pathway_mass.keys()):
        pathway_mass[k] = _clamp01(pathway_mass[k] / tot)

    plus1_mass = insertion_len_mixture.get(1, 0.0)
    insertion_mass = sum(insertion_len_mixture.values()) or 0.0
    insertion_types = {
        "+1": _clamp01(plus1_mass / insertion_mass) if insertion_mass > 0.0 else 0.0,
        "templated": 0.0,
        "random_or_other": _clamp01(max(0.0, insertion_mass - plus1_mass) / insertion_mass) if insertion_mass > 0.0 else 0.0,
        "note": "templated insertions not modeled; +1 estimated from indel length mixture",
    }

    payload["repair_decomposition"] = {
        "pathway_mass": pathway_mass,
        "no_cut_p": float(no_cut_p),
        "nhej_p": float(pathway_mass.get("nhej", 0.0)),
        "mmej_p": float(pathway_mass.get("mmej", 0.0)),
        "religation_p": float(pathway_mass.get("religation", 0.0)),
        "microhomology_length_distribution": {
            "status": "not_available",
            "reason": "microhomology length is not emitted by the current outcome models",
        },
        "insertion_types": insertion_types,
    }

    # Baselines & comparatives: per-dimension (computed when possible, else explicit not_available).
    frameshift_p_total = _clamp01(sum(float(oc.p_total) * float(oc.frameshift.p) for oc in outcomes_v2))
    payload["baselines"] = {
        "edit_outcome": {
            "typical_cut_p_random_guide": float(cut_p),
            "typical_frameshift_p_random_guide": float(frameshift_p_total),
            "ranking": {"status": "not_available", "reason": "no guide corpus provided for percentile/z-score baselines"},
        },
        "kinetics": None,
        "off_target": None,
    }

    # Validation hooks: suggest assays + a coarse read-depth heuristic for validation.
    recommended_assays: list[str] = ["amplicon_seq"]
    try:
        if float(tail.global_p99_del_bp) >= 50.0 or float(tail.p_any_large_del_ge_50bp) >= 0.05:
            recommended_assays.append("long_read")
    except Exception:
        pass
    expected_reads = 500
    payload["validation"] = {
        "recommended_assays": recommended_assays,
        "future_assays": ["timecourse_seq", "GUIDE_seq"],
        "expected_reads_for_plusminus_5pct": {
            "reads": int(expected_reads),
            "confidence_level": 0.95,
            "absolute_error": 0.05,
            "note": "worst-case binomial precision heuristic (p=0.5); adjust for locus/assay specifics",
        },
        "posthoc_calibration_slot": {
            "status": "supported",
            "api": "helix.sim.evidence.assimilate_posterior",
            "expected_evidence_spec": {"type": "amplicon_seq", "source": "user"},
            "expected_observed_outcomes_format": [{"label": "no_cut", "frequency": 0.4}],
        },
    }

    # Machine-readable decision metadata: lightweight tiering for automation.
    grade = str(verdict.grade or "")
    confidence = "low"
    recommended_use = "exploration"
    if decision_mode == "decision_grade":
        if grade in {"A"}:
            confidence = "high"
            recommended_use = "primary choice"
        elif grade in {"B", "C"}:
            confidence = "medium"
            recommended_use = "screening"
        else:
            confidence = "low"
            recommended_use = "avoid"
    payload["decision"] = {
        "confidence": confidence,
        "recommended_use": recommended_use,
        "hard_stop_flags": ["do_not_use_for_therapeutic_decisions"],
    }

    # Explicit known failure modes (non-exhaustive, model-specific).
    payload["known_failure_modes"] = [
        "domain_shift: cell type / delivery / chromatin can change cut+repair outcomes",
        "uncalibrated_probabilities: decision_grade requires a matching calibration bundle; otherwise outputs are exploratory",
        "missing_assay_metadata: without assay declaration, intended functional metrics are not auditable",
        "off_target_incomplete: screening mode is window-only and can miss genome-wide liabilities",
        "structural_risk_proxy: structural events are a deterministic proxy model and should be validated with long-read assays when material",
    ]

    return payload


class SummaryValidationError(ValueError):
    def __init__(self, errors: Sequence[str]) -> None:
        super().__init__("\n".join(errors))
        self.errors = list(errors)


def validate_run_summary_v2(payload: Mapping[str, Any], *, tolerance: float = 1e-6) -> None:
    errors: list[str] = []
    detected_failures: set[str] = set()
    detected_warnings: set[str] = set()

    def req(obj: Mapping[str, Any], key: str, typ: Any, path: str) -> Any:
        if key not in obj:
            errors.append(f"missing required field: {path}.{key}")
            return None
        val = obj.get(key)
        if typ is float:
            if not isinstance(val, (int, float)):
                errors.append(f"expected number: {path}.{key}")
                return None
            return float(val)
        if typ is int:
            if not isinstance(val, int):
                errors.append(f"expected int: {path}.{key}")
                return None
            return int(val)
        if not isinstance(val, typ):
            errors.append(f"expected {typ.__name__}: {path}.{key}")
            return None
        return val

    def opt_int(obj: Mapping[str, Any], key: str, path: str) -> int | None:
        if key not in obj:
            errors.append(f"missing required field: {path}.{key}")
            return None
        val = obj.get(key)
        if val is None:
            return None
        if not isinstance(val, int):
            errors.append(f"expected int-or-null: {path}.{key}")
            return None
        return int(val)

    def opt_str(obj: Mapping[str, Any], key: str, path: str) -> str | None:
        if key not in obj:
            errors.append(f"missing required field: {path}.{key}")
            return None
        val = obj.get(key)
        if val is None:
            return None
        if not isinstance(val, str):
            errors.append(f"expected str-or-null: {path}.{key}")
            return None
        return str(val)

    def sha_field(obj: Mapping[str, Any], key: str, path: str) -> str:
        val = str(req(obj, key, str, path) or "")
        if val and not val.startswith("sha256:"):
            errors.append(f"{path}.{key} must be sha256:<hex>")
        return val

    run_id = req(payload, "run_id", str, "root")
    _ = run_id  # quiet unused
    _ = req(payload, "spec_hash", str, "root")
    _ = req(payload, "policy_id", str, "root")
    _ = req(payload, "policy_hash", str, "root")
    decision_mode_requested = str(req(payload, "decision_mode_requested", str, "root") or "")
    decision_mode = str(req(payload, "decision_mode", str, "root") or "")
    if decision_mode_requested and decision_mode_requested not in DECISION_MODE_VALUES:
        errors.append("decision_mode_requested invalid")
    if decision_mode and decision_mode not in DECISION_MODE_VALUES:
        errors.append("decision_mode invalid")

    validity = req(payload, "validity", dict, "root") or {}
    validity_status = str(req(validity, "status", str, "validity") or "")
    if validity_status and validity_status not in VALIDITY_STATUS_VALUES:
        errors.append("validity.status invalid")
    validity_causes = req(validity, "root_causes", list, "validity") or []
    if any(not isinstance(x, str) for x in validity_causes):
        errors.append("validity.root_causes must be array of strings")

    provenance = req(payload, "provenance", dict, "root") or {}
    backend = req(provenance, "backend", dict, "provenance") or {}
    _ = req(backend, "name", str, "provenance.backend")
    _ = req(backend, "version", str, "provenance.backend")
    _ = req(backend, "git_commit", str, "provenance.backend")
    _ = req(backend, "build_timestamp_utc", str, "provenance.backend")

    prov_model = req(provenance, "model", dict, "provenance") or {}
    _ = req(prov_model, "model_id", str, "provenance.model")
    _ = req(prov_model, "model_version", str, "provenance.model")
    _ = sha_field(prov_model, "model_hash", "provenance.model")
    _ = req(prov_model, "off_target_model_id", str, "provenance.model")
    _ = req(prov_model, "off_target_model_version", str, "provenance.model")

    prov_params = req(provenance, "params", dict, "provenance") or {}
    _ = sha_field(prov_params, "params_hash", "provenance.params")
    snap = req(prov_params, "snapshot", dict, "provenance.params") or {}
    _ = snap  # quiet unused

    assumptions = req(provenance, "assumptions", dict, "provenance") or {}
    cut_profile = req(assumptions, "cut_repair_profile", dict, "provenance.assumptions") or {}
    _ = req(cut_profile, "id", str, "provenance.assumptions.cut_repair_profile")
    _ = sha_field(cut_profile, "hash", "provenance.assumptions.cut_repair_profile")

    aggregation = req(provenance, "aggregation", dict, "provenance") or {}
    _ = req(aggregation, "version", str, "provenance.aggregation")
    _ = sha_field(aggregation, "hash", "provenance.aggregation")

    data = req(provenance, "data", dict, "provenance") or {}
    refg = req(data, "reference_genome", dict, "provenance.data") or {}
    _ = req(refg, "id", str, "provenance.data.reference_genome")
    _ = sha_field(refg, "checksum", "provenance.data.reference_genome")
    ann = req(data, "annotation_dataset", dict, "provenance.data") or {}
    _ = req(ann, "id", str, "provenance.data.annotation_dataset")
    _ = sha_field(ann, "checksum", "provenance.data.annotation_dataset")
    cald = req(data, "calibration_dataset", dict, "provenance.data") or {}
    _ = req(cald, "id", str, "provenance.data.calibration_dataset")
    _ = sha_field(cald, "checksum", "provenance.data.calibration_dataset")
    calb = req(data, "calibration_bundle", dict, "provenance.data") or {}
    _ = req(calb, "id", str, "provenance.data.calibration_bundle")
    _ = sha_field(calb, "checksum", "provenance.data.calibration_bundle")
    calb_code_hash = opt_str(calb, "evaluation_code_hash", "provenance.data.calibration_bundle")
    if isinstance(calb_code_hash, str) and calb_code_hash and not calb_code_hash.startswith("sha256:"):
        errors.append("provenance.data.calibration_bundle.evaluation_code_hash must be sha256:<hex>")
    calb_model_id = opt_str(calb, "model_id", "provenance.data.calibration_bundle")
    calb_model_version = opt_str(calb, "model_version", "provenance.data.calibration_bundle")
    calb_model_hash = opt_str(calb, "model_hash", "provenance.data.calibration_bundle")
    if isinstance(calb_model_hash, str) and calb_model_hash and not calb_model_hash.startswith("sha256:"):
        errors.append("provenance.data.calibration_bundle.model_hash must be sha256:<hex>")
    calb_ds_id = opt_str(calb, "calibration_dataset_id", "provenance.data.calibration_bundle")
    calb_ds_checksum = opt_str(calb, "calibration_dataset_checksum", "provenance.data.calibration_bundle")
    if isinstance(calb_ds_checksum, str) and calb_ds_checksum and not calb_ds_checksum.startswith("sha256:"):
        errors.append("provenance.data.calibration_bundle.calibration_dataset_checksum must be sha256:<hex>")

    intended = req(payload, "intended_edit_spec", dict, "root") or {}
    edit_class = req(intended, "edit_class", str, "intended_edit_spec")
    if isinstance(edit_class, str) and not edit_class.strip():
        errors.append("intended_edit_spec.edit_class must be non-empty")
    target = req(intended, "target", dict, "intended_edit_spec") or {}
    _ = req(target, "chrom", str, "intended_edit_spec.target")
    _ = opt_int(target, "start", "intended_edit_spec.target")
    _ = opt_int(target, "end", "intended_edit_spec.target")
    _ = req(target, "strand", str, "intended_edit_spec.target")
    cut_site = req(target, "cut_site", dict, "intended_edit_spec.target") or {}
    _ = req(cut_site, "chrom", str, "intended_edit_spec.target.cut_site")
    _ = req(cut_site, "pos", int, "intended_edit_spec.target.cut_site")
    _ = req(cut_site, "strand", str, "intended_edit_spec.target.cut_site")

    _ = req(intended, "allele", dict, "intended_edit_spec")
    measurement = req(intended, "measurement", dict, "intended_edit_spec") or {}
    m_status = str(req(measurement, "status", str, "intended_edit_spec.measurement") or "")
    if m_status not in {"declared", "absent"}:
        errors.append("intended_edit_spec.measurement.status invalid")
    _ = opt_str(measurement, "assay_type", "intended_edit_spec.measurement")
    _ = opt_str(measurement, "assay_definition_id", "intended_edit_spec.measurement")
    if m_status == "declared":
        if not (measurement.get("assay_type") or measurement.get("assay_definition_id")):
            errors.append("intended_edit_spec.measurement must declare assay_type or assay_definition_id")

    det_lim = req(intended, "detection_limits", dict, "intended_edit_spec") or {}
    _ = req(det_lim, "status", str, "intended_edit_spec.detection_limits")
    biases = req(intended, "known_biases", dict, "intended_edit_spec") or {}
    _ = req(biases, "status", str, "intended_edit_spec.known_biases")

    uncertainty = req(payload, "uncertainty", dict, "root") or {}
    _ = req(uncertainty, "status", str, "uncertainty")

    model_stack = req(payload, "model_stack", dict, "root") or {}
    repair_model = req(model_stack, "repair_model", dict, "model_stack") or {}
    _ = req(repair_model, "name", str, "model_stack.repair_model")
    rm_type = str(req(repair_model, "type", str, "model_stack.repair_model") or "")
    if rm_type and rm_type not in MODEL_TYPE_VALUES:
        errors.append("invalid model_stack.repair_model.type")
    constraints_raw = req(repair_model, "constraints", list, "model_stack.repair_model") or []
    if any(not isinstance(x, str) for x in constraints_raw):
        errors.append("model_stack.repair_model.constraints must be array of strings")
    calibration = req(repair_model, "calibration", dict, "model_stack.repair_model") or {}
    _ = req(calibration, "dataset_id", str, "model_stack.repair_model.calibration")
    _ = req(calibration, "domain", str, "model_stack.repair_model.calibration")
    _ = req(calibration, "notes", str, "model_stack.repair_model.calibration")

    off_target_model = req(model_stack, "off_target_model", dict, "model_stack") or {}
    _ = req(off_target_model, "name", str, "model_stack.off_target_model")
    ot_type = str(req(off_target_model, "type", str, "model_stack.off_target_model") or "")
    if ot_type and ot_type not in MODEL_TYPE_VALUES:
        errors.append("invalid model_stack.off_target_model.type")
    ot_constraints = req(off_target_model, "constraints", list, "model_stack.off_target_model") or []
    if any(not isinstance(x, str) for x in ot_constraints):
        errors.append("model_stack.off_target_model.constraints must be array of strings")
    ot_cal = req(off_target_model, "calibration", dict, "model_stack.off_target_model") or {}
    _ = req(ot_cal, "dataset_id", str, "model_stack.off_target_model.calibration")
    _ = req(ot_cal, "domain", str, "model_stack.off_target_model.calibration")
    _ = req(ot_cal, "notes", str, "model_stack.off_target_model.calibration")

    cut_site = req(payload, "cut_site", dict, "root") or {}
    _ = req(cut_site, "chrom", str, "cut_site")
    _ = req(cut_site, "pos", int, "cut_site")
    strand = str(req(cut_site, "strand", str, "cut_site") or "")
    if strand and strand not in CUT_STRAND_VALUES:
        errors.append("invalid cut_site.strand")

    outcomes = req(payload, "outcomes", list, "root") or []
    if not outcomes:
        errors.append("outcomes must be a non-empty array")
    probs: list[float] = []
    p_given_cut_sum = 0.0
    p_given_cut_any = False
    cut_dependent_count = 0
    frameshift_computed_mass = 0.0
    frameshift_noncomputed_present = False
    for i, oc in enumerate(outcomes):
        if not isinstance(oc, Mapping):
            errors.append(f"outcomes[{i}] must be object")
            continue
        _ = req(oc, "outcome_id", str, f"outcomes[{i}]")
        _ = req(oc, "label", str, f"outcomes[{i}]")
        p_total = req(oc, "p_total", float, f"outcomes[{i}]")
        if p_total is not None:
            if not (0.0 <= p_total <= 1.0):
                errors.append(f"outcomes[{i}].p_total out of range")
            probs.append(float(p_total))
        functional_class = str(req(oc, "functional_class", str, f"outcomes[{i}]") or "")
        if functional_class and functional_class not in FUNCTIONAL_CLASS_VALUES:
            errors.append(f"outcomes[{i}].functional_class invalid")
        p_given_cut = oc.get("p_given_cut")
        if p_given_cut is not None:
            if not isinstance(p_given_cut, (int, float)):
                errors.append(f"outcomes[{i}].p_given_cut must be number or null")
            else:
                p_given_cut_any = True
                p_given_cut_sum += float(p_given_cut)
                cut_dependent_count += 1

        frameshift = req(oc, "frameshift", dict, f"outcomes[{i}]") or {}
        fs_p = frameshift.get("p")
        fs_source = str(frameshift.get("source") or "")
        if fs_source not in FRAMESHIFT_SOURCE_VALUES:
            errors.append(f"outcomes[{i}].frameshift.source invalid")
        if not isinstance(fs_p, (int, float)):
            errors.append(f"outcomes[{i}].frameshift.p must be number")
        else:
            if fs_source == "computed" and float(fs_p) > 0.0 and isinstance(p_total, (int, float)):
                frameshift_computed_mass += float(p_total) * float(fs_p)
        if fs_source != "computed":
            frameshift_noncomputed_present = True
            reason = frameshift.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append(f"outcomes[{i}].frameshift.reason required when source != computed")

        indel = req(oc, "indel_length", dict, f"outcomes[{i}]") or {}
        # Hidden tail risk prohibition: require tail keys (and treat missing as integrity failure).
        required_indel_keys = (
            "median_bp",
            "mean_bp",
            "p90_bp",
            "p95_bp",
            "p99_bp",
            "cvar95_bp",
            "cvar99_bp",
            "p_ge_10bp",
            "p_ge_50bp",
            "p_ge_200bp",
        )
        for k in required_indel_keys:
            if k not in indel:
                detected_failures.add("tail_risk_missing")
                errors.append(f"tail_risk_missing: outcomes[{i}].indel_length.{k} missing")
            elif not isinstance(indel.get(k), (int, float)):
                errors.append(f"outcomes[{i}].indel_length.{k} must be number")

        reg = req(oc, "regulatory_overlap", dict, f"outcomes[{i}]") or {}
        for k in (
            "p_hits_splice_donor",
            "p_hits_splice_acceptor",
            "p_hits_promoter",
            "p_hits_enhancer",
            "p_hits_boundary_element",
        ):
            if k not in reg:
                errors.append(f"missing required field: outcomes[{i}].regulatory_overlap.{k}")
            elif not isinstance(reg.get(k), (int, float)):
                errors.append(f"outcomes[{i}].regulatory_overlap.{k} must be number")

        worst = req(oc, "worst_hit", dict, f"outcomes[{i}]") or {}
        _ = req(worst, "feature_type", str, f"outcomes[{i}].worst_hit")
        _ = req(worst, "feature_id", str, f"outcomes[{i}].worst_hit")
        worst_p = req(worst, "p", float, f"outcomes[{i}].worst_hit")
        if isinstance(worst_p, float) and not (0.0 <= worst_p <= 1.0):
            errors.append(f"outcomes[{i}].worst_hit.p out of range")

    prob_sum = sum(probs)
    if probs and abs(prob_sum - 1.0) > float(tolerance):
        errors.append("probability_not_conserved: sum(outcomes[].p_total) != 1")
        detected_failures.add("probability_not_conserved")

    control = req(payload, "control", dict, "root") or {}
    _ = req(control, "intended_functional_p", float, "control")
    dominance_ratio = req(control, "dominance_ratio", float, "control")
    _ = req(control, "entropy_bits", float, "control")
    no_cut_p = req(control, "no_cut_p", float, "control")
    flags = req(control, "flags", list, "control") or []
    if any(not isinstance(x, str) for x in flags):
        errors.append("control.flags must be array of strings")
    if isinstance(dominance_ratio, float) and math.isfinite(dominance_ratio) and dominance_ratio < 3.0:
        if "plurality_regime" not in {str(x) for x in flags if isinstance(x, str)}:
            errors.append("control.flags must include plurality_regime when dominance_ratio < 3")

    conv_status: str | None = None
    conv_escape_worst: float | None = None
    conv_escape_risk: float | None = None
    conv_initial_uncut: float | None = None

    convergence = control.get("convergence")
    if not isinstance(convergence, Mapping):
        errors.append("control.convergence missing")
    else:
        status = str(convergence.get("status") or "")
        conv_status = status
        if status not in CONVERGENCE_STATUS_VALUES:
            errors.append("control.convergence.status invalid")
        elif status == "not_computed":
            detected_warnings.add("convergence_not_computed")
            severity = convergence.get("severity")
            if not isinstance(severity, str) or severity not in CONVERGENCE_SEVERITY_VALUES:
                errors.append("control.convergence.severity invalid")
            reason = convergence.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append("control.convergence.reason required when not_computed")
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if grade in {"A", "B"}:
                errors.append("convergence not computed must cap verdict.grade at C")
        elif status == "computed":
            gens = req(convergence, "generations", list, "control.convergence") or []
            if any(not isinstance(x, int) for x in gens):
                errors.append("control.convergence.generations must be array of ints")

            assumptions = req(convergence, "assumptions", dict, "control.convergence") or {}
            _ = req(assumptions, "fitness_intended", float, "control.convergence.assumptions")
            _ = req(assumptions, "fitness_uncut", float, "control.convergence.assumptions")
            _ = req(assumptions, "fitness_harmful", float, "control.convergence.assumptions")
            selection_model = str(req(assumptions, "selection_model", str, "control.convergence.assumptions") or "")
            if selection_model and selection_model not in CONVERGENCE_SELECTION_MODEL_VALUES:
                errors.append("control.convergence.assumptions.selection_model invalid")
            harmful_definition = str(req(assumptions, "harmful_definition", str, "control.convergence.assumptions") or "")
            if harmful_definition and not harmful_definition.strip():
                errors.append("control.convergence.assumptions.harmful_definition must be non-empty string")
            mixing = assumptions.get("mixing")
            if mixing is not None:
                if not isinstance(mixing, str) or mixing not in CONVERGENCE_MIXING_VALUES:
                    errors.append("control.convergence.assumptions.mixing invalid")

            init = req(convergence, "initial_fractions", dict, "control.convergence") or {}
            init_intended = req(init, "intended_p", float, "control.convergence.initial_fractions")
            init_uncut = req(init, "uncut_p", float, "control.convergence.initial_fractions")
            init_harmful = req(init, "harmful_p", float, "control.convergence.initial_fractions")
            if isinstance(init_uncut, float):
                conv_initial_uncut = float(init_uncut)
            if all(isinstance(x, float) for x in (init_intended, init_uncut, init_harmful)):
                s = float(init_intended) + float(init_uncut) + float(init_harmful)
                if abs(s - 1.0) > 1e-6:
                    detected_failures.add("convergence_fraction_not_conserved")
                    errors.append("convergence_fraction_not_conserved: control.convergence.initial_fractions must sum to 1 within tolerance")

            conv_escape_risk = req(convergence, "escape_risk", float, "control.convergence")
            conv_escape_worst = req(convergence, "escape_worst_case_uncut_p_gen20", float, "control.convergence")
            if isinstance(conv_escape_risk, float) and not (0.0 <= float(conv_escape_risk) <= 1.0):
                errors.append("control.convergence.escape_risk out of range")
            if isinstance(conv_escape_worst, float) and not (0.0 <= float(conv_escape_worst) <= 1.0):
                errors.append("control.convergence.escape_worst_case_uncut_p_gen20 out of range")

            proj = req(convergence, "projected", list, "control.convergence") or []
            proj_gens: set[int] = set()
            for j, pt in enumerate(proj):
                if not isinstance(pt, Mapping):
                    errors.append(f"control.convergence.projected[{j}] must be object")
                    continue
                g = req(pt, "gen", int, f"control.convergence.projected[{j}]")
                if isinstance(g, int):
                    proj_gens.add(int(g))
                pt_intended = req(pt, "intended_p", float, f"control.convergence.projected[{j}]")
                pt_uncut = req(pt, "uncut_p", float, f"control.convergence.projected[{j}]")
                pt_harm = req(pt, "harmful_p", float, f"control.convergence.projected[{j}]")
                _ = req(pt, "escape_risk", float, f"control.convergence.projected[{j}]")
                cond = req(pt, "escape_condition", str, f"control.convergence.projected[{j}]")
                if isinstance(cond, str) and not cond.strip():
                    errors.append(f"control.convergence.projected[{j}].escape_condition must be non-empty string")
                if all(isinstance(x, float) for x in (pt_intended, pt_uncut, pt_harm)):
                    s = float(pt_intended) + float(pt_uncut) + float(pt_harm)
                    if abs(s - 1.0) > 1e-6:
                        detected_failures.add("convergence_fraction_not_conserved")
                        errors.append(
                            f"convergence_fraction_not_conserved: control.convergence.projected[{j}] intended_p+uncut_p+harmful_p must sum to 1"
                        )
            if gens and any(isinstance(x, int) for x in gens):
                missing = {int(x) for x in gens if isinstance(x, int)} - proj_gens
                if missing:
                    errors.append("control.convergence.projected must include every listed generation")

    stability = control.get("stability")
    if not isinstance(stability, Mapping):
        errors.append("control.stability missing")
    else:
        status = str(stability.get("status") or "")
        if status not in STABILITY_STATUS_VALUES:
            errors.append("control.stability.status invalid")
        elif status == "not_computed":
            detected_warnings.add("stability_not_computed")
            severity = stability.get("severity")
            if not isinstance(severity, str) or severity not in STABILITY_SEVERITY_VALUES:
                errors.append("control.stability.severity invalid")
            reason = stability.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append("control.stability.reason required when not_computed")
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if str(severity or "") == "blocking" and grade in {"A", "B"}:
                errors.append("stability not computed must cap verdict.grade at C")
        elif status == "computed":
            if conv_status != "computed":
                errors.append("control.stability cannot be computed when control.convergence is not computed")
            assumptions = req(stability, "assumptions", dict, "control.stability") or {}
            preset_ids = req(assumptions, "preset_ids_used", list, "control.stability.assumptions") or []
            if not preset_ids:
                errors.append("control.stability.assumptions.preset_ids_used must be non-empty array")
            if any(not isinstance(x, str) for x in preset_ids):
                errors.append("control.stability.assumptions.preset_ids_used must be array of strings")
            else:
                allowed = {"conservative", "neutral", "optimistic"}
                bad = [str(x) for x in preset_ids if str(x) not in allowed]
                if bad:
                    errors.append("control.stability.assumptions.preset_ids_used contains invalid preset id(s)")

            assumptions_hash = str(req(assumptions, "assumptions_hash", str, "control.stability.assumptions") or "")
            if not assumptions_hash.strip() or not assumptions_hash.startswith("sha256:"):
                errors.append("control.stability.assumptions.assumptions_hash must be sha256:*")
            sweep_hash = assumptions.get("off_target_sweep_hash")
            if sweep_hash is not None:
                if not isinstance(sweep_hash, str) or (sweep_hash and not sweep_hash.startswith("sha256:")):
                    errors.append("control.stability.assumptions.off_target_sweep_hash must be sha256:* or empty string")

            score = req(stability, "stability_score", float, "control.stability")
            if isinstance(score, float) and not (0.0 <= float(score) <= 1.0):
                errors.append("control.stability.stability_score out of range")
            interp = str(req(stability, "interpretation", str, "control.stability") or "")
            if interp and interp not in STABILITY_INTERPRETATION_VALUES:
                errors.append("control.stability.interpretation invalid")

            ranges = req(stability, "ranges", dict, "control.stability") or {}
            grade_min = str(req(ranges, "grade_min", str, "control.stability.ranges") or "")
            grade_max = str(req(ranges, "grade_max", str, "control.stability.ranges") or "")
            if grade_min and grade_min not in GRADE_VALUES:
                errors.append("control.stability.ranges.grade_min invalid")
            if grade_max and grade_max not in GRADE_VALUES:
                errors.append("control.stability.ranges.grade_max invalid")
            for k in (
                "intended_min",
                "intended_max",
                "escape_min",
                "escape_max",
                "splice_min",
                "splice_max",
                "regulatory_min",
                "regulatory_max",
                "off_target_worst_min",
                "off_target_worst_max",
                "off_target_coding_min",
                "off_target_coding_max",
            ):
                v = req(ranges, k, float, "control.stability.ranges")
                if isinstance(v, float):
                    if k.startswith("off_target_worst"):
                        if float(v) < 0.0:
                            errors.append(f"control.stability.ranges.{k} out of range")
                    else:
                        if not (0.0 <= float(v) <= 1.0):
                            errors.append(f"control.stability.ranges.{k} out of range")

            variants = req(stability, "variants", list, "control.stability") or []
            if not variants:
                errors.append("control.stability.variants must be non-empty array")
            for j, var in enumerate(variants):
                if not isinstance(var, Mapping):
                    errors.append(f"control.stability.variants[{j}] must be object")
                    continue
                _ = req(var, "variant_id", str, f"control.stability.variants[{j}]")
                vtype = str(req(var, "variant_type", str, f"control.stability.variants[{j}]") or "")
                if vtype and vtype not in STABILITY_VARIANT_TYPE_VALUES:
                    errors.append(f"control.stability.variants[{j}].variant_type invalid")
                preset = str(req(var, "preset", str, f"control.stability.variants[{j}]") or "")
                if preset and preset not in {"conservative", "neutral", "optimistic", "off_target"}:
                    errors.append(f"control.stability.variants[{j}].preset invalid")
                grade = str(req(var, "grade", str, f"control.stability.variants[{j}]") or "")
                if grade and grade not in GRADE_VALUES:
                    errors.append(f"control.stability.variants[{j}].grade invalid")

                intended = req(var, "intended_p", float, f"control.stability.variants[{j}]")
                if isinstance(intended, float) and not (0.0 <= float(intended) <= 1.0):
                    errors.append(f"control.stability.variants[{j}].intended_p out of range")
                _ = req(var, "dominance_ratio", float, f"control.stability.variants[{j}]")
                _ = req(var, "entropy_bits", float, f"control.stability.variants[{j}]")
                escape = req(var, "escape_risk", float, f"control.stability.variants[{j}]")
                if isinstance(escape, float) and not (0.0 <= float(escape) <= 1.0):
                    errors.append(f"control.stability.variants[{j}].escape_risk out of range")
                splice = req(var, "splice_risk", float, f"control.stability.variants[{j}]")
                if isinstance(splice, float) and not (0.0 <= float(splice) <= 1.0):
                    errors.append(f"control.stability.variants[{j}].splice_risk out of range")
                reg = req(var, "regulatory_risk", float, f"control.stability.variants[{j}]")
                if isinstance(reg, float) and not (0.0 <= float(reg) <= 1.0):
                    errors.append(f"control.stability.variants[{j}].regulatory_risk out of range")
                ot_params = var.get("off_target_params")
                if vtype == "off_target_sweep":
                    if not isinstance(ot_params, Mapping):
                        errors.append(f"control.stability.variants[{j}].off_target_params must be object for off_target_sweep")
                    else:
                        mode = str(ot_params.get("mode") or "")
                        if mode and mode not in OFFTARGET_MODE_VALUES:
                            errors.append(f"control.stability.variants[{j}].off_target_params.mode invalid")
                        if "max_mm" not in ot_params or not isinstance(ot_params.get("max_mm"), int):
                            errors.append(f"control.stability.variants[{j}].off_target_params.max_mm missing or not int")
                        if "max_hits" not in ot_params or not isinstance(ot_params.get("max_hits"), int):
                            errors.append(f"control.stability.variants[{j}].off_target_params.max_hits missing or not int")
                        status_ot = str(var.get("off_target_status") or ot_params.get("status") or "")
                        if status_ot and status_ot not in OFFTARGET_STATUS_VALUES:
                            errors.append(f"control.stability.variants[{j}].off_target_status invalid")
                        if status_ot == "not_computed":
                            reason_ot = ot_params.get("reason") or var.get("reason")
                            if not isinstance(reason_ot, str) or not reason_ot.strip():
                                errors.append(f"control.stability.variants[{j}].off_target_params.reason required when not_computed")
                        worst = var.get("off_target_worst_site_score")
                        if worst is not None and not isinstance(worst, (int, float)):
                            errors.append(f"control.stability.variants[{j}].off_target_worst_site_score must be number or null")
                else:
                    if ot_params is not None and not isinstance(ot_params, Mapping):
                        errors.append(f"control.stability.variants[{j}].off_target_params must be object when present")
            warnings = stability.get("warnings")
            if warnings is not None:
                if not isinstance(warnings, list) or any(not isinstance(x, str) for x in warnings):
                    errors.append("control.stability.warnings must be array of strings")

    iteration = control.get("iteration")
    if isinstance(iteration, Mapping):
        status = str(iteration.get("status") or "")
        if status and status not in ITERATION_STATUS_VALUES:
            errors.append("control.iteration.status invalid")
        required = bool(iteration.get("required")) if "required" in iteration else False
        transition_required = bool(iteration.get("transition_required")) if "transition_required" in iteration else False
        transition_model = str(iteration.get("transition_model") or "")
        if status == "not_computed" and required:
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if grade in {"A", "B"}:
                errors.append("iteration not computed must cap verdict.grade at C")
        if transition_required and transition_model == "identity":
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if grade in {"A", "B"}:
                errors.append("iteration transition identity must cap verdict.grade at C")
    cut_p = None if no_cut_p is None else max(0.0, 1.0 - float(no_cut_p))
    if p_given_cut_any and cut_p is not None and cut_p > 0.0:
        if abs(p_given_cut_sum - 1.0) > 1e-6:
            errors.append("cut_condition_inconsistent: sum(p_given_cut) != 1")
            detected_failures.add("cut_condition_inconsistent")

    # Frameshift plausibility gate (run-level).
    if cut_p is not None and cut_p > 0.05:
        constraints = []
        if isinstance(repair_model, Mapping):
            raw = repair_model.get("constraints")
            if isinstance(raw, list):
                constraints = [str(x) for x in raw]
        has_nhej_like = any(c.upper() in {"NHEJ", "MMEJ"} for c in constraints)
        if has_nhej_like and frameshift_computed_mass == 0.0 and not frameshift_noncomputed_present:
            errors.append("frameshift_zero_implausible: cut_p>0.05 with NHEJ/MMEJ but frameshift is 0 computed")
            detected_failures.add("frameshift_zero_implausible")

    risk = req(payload, "risk", dict, "root") or {}
    tail = req(risk, "tail", dict, "risk") or {}
    for k in (
        "global_p99_del_bp",
        "global_cvar99_del_bp",
        "p_any_splice_disruption",
        "p_any_regulatory_hit",
        "p_any_large_del_ge_50bp",
        "p_any_large_del_ge_200bp",
    ):
        _ = req(tail, k, float, "risk.tail")

    hazard = risk.get("hazard")
    if not isinstance(hazard, Mapping):
        errors.append("risk.hazard missing")
    else:
        status = str(hazard.get("status") or "")
        if status not in HAZARD_STATUS_VALUES:
            errors.append("risk.hazard.status invalid")
        if status == "not_computed":
            detected_warnings.add("hazard_not_computed")
            severity = hazard.get("severity")
            if not isinstance(severity, str) or severity not in HAZARD_SEVERITY_VALUES:
                errors.append("risk.hazard.severity invalid")
            reason = hazard.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append("risk.hazard.reason required when not_computed")
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if grade in {"A", "B"}:
                errors.append("hazard not computed must cap verdict.grade at C")
        elif status == "computed":
            for k in (
                "p_hits_splice_donor",
                "p_hits_splice_acceptor",
                "p_hits_coding_exon",
                "p_hits_promoter",
                "p_hits_enhancer",
            ):
                _ = req(hazard, k, float, "risk.hazard")
            worst = hazard.get("worst_case_feature_hit")
            if not isinstance(worst, Mapping):
                errors.append("risk.hazard.worst_case_feature_hit required when computed")
            else:
                _ = req(worst, "type", str, "risk.hazard.worst_case_feature_hit")
                _ = req(worst, "id", str, "risk.hazard.worst_case_feature_hit")
                _ = req(worst, "p", float, "risk.hazard.worst_case_feature_hit")
            limitations = hazard.get("limitations")
            if limitations is not None and (not isinstance(limitations, str) or not limitations.strip()):
                errors.append("risk.hazard.limitations must be non-empty string when present")

    offt = risk.get("off_target")
    if not isinstance(offt, Mapping):
        errors.append("off_target missing: risk.off_target required")
    else:
        status = str(offt.get("status") or "")
        if status not in OFFTARGET_STATUS_VALUES:
            errors.append("risk.off_target.status invalid")
        mode = str(req(offt, "mode", str, "risk.off_target") or "")
        if mode not in OFFTARGET_MODE_VALUES:
            errors.append("risk.off_target.mode invalid")
        executed_mode = str(req(offt, "executed_mode", str, "risk.off_target") or "")
        if executed_mode not in OFFTARGET_MODE_VALUES:
            errors.append("risk.off_target.executed_mode invalid")
        mode_src = str(req(offt, "off_target_mode", str, "risk.off_target") or "")
        if mode_src not in OFFTARGET_MODE_SOURCE_VALUES:
            errors.append("risk.off_target.off_target_mode invalid")
        provider_id = req(offt, "provider_id", str, "risk.off_target")
        if isinstance(provider_id, str) and not provider_id.strip():
            errors.append("risk.off_target.provider_id must be non-empty string")
        reference_id = req(offt, "reference_id", str, "risk.off_target")
        if isinstance(reference_id, str) and not reference_id.strip():
            errors.append("risk.off_target.reference_id must be non-empty string")
        _ = req(offt, "params", dict, "risk.off_target")
        scope = req(offt, "scope", str, "risk.off_target")
        if isinstance(scope, str) and not scope.strip():
            errors.append("risk.off_target.scope must be non-empty string")
        scope_val = str(scope or "").strip()
        if scope_val and scope_val not in OFFTARGET_SCOPE_VALUES:
            errors.append("risk.off_target.scope invalid")
        limitations = req(offt, "limitations", str, "risk.off_target")
        if isinstance(limitations, str) and not limitations.strip():
            errors.append("risk.off_target.limitations must be non-empty string")
        annotation_computed = req(offt, "annotation_computed", bool, "risk.off_target")

        if executed_mode == "none" and scope_val and scope_val != "none":
            errors.append("risk.off_target.scope must be none when executed_mode=none")
        if executed_mode == "screening" and scope_val and scope_val != "window_only":
            errors.append("risk.off_target.scope must be window_only when executed_mode=screening")
        if executed_mode == "full" and scope_val and scope_val != "genome_wide":
            errors.append("risk.off_target.scope must be genome_wide when executed_mode=full")

        if executed_mode == "full" and any(tok in str(limitations or "") for tok in _OFFTARGET_DOWNGRADE_LANGUAGE):
            errors.append("risk.off_target.limitations must not contain downgrade language when executed_mode=full")
        if (
            status == "computed"
            and isinstance(annotation_computed, bool)
            and (not annotation_computed)
            and OFFTARGET_ANNOTATION_NOT_COMPUTED_TAG not in str(limitations or "")
        ):
            errors.append("risk.off_target.limitations must include annotation_not_computed when annotation_computed=false")
        if (
            status == "computed"
            and isinstance(annotation_computed, bool)
            and annotation_computed
            and OFFTARGET_ANNOTATION_NOT_COMPUTED_TAG in str(limitations or "")
        ):
            errors.append("risk.off_target.limitations must not include annotation_not_computed when annotation_computed=true")

        cache_key = offt.get("cache_key")
        if cache_key is not None and (not isinstance(cache_key, str) or not cache_key.strip() or not cache_key.startswith("sha256:")):
            errors.append("risk.off_target.cache_key must be sha256:* when present")
        cache_key_inputs_hash = offt.get("cache_key_inputs_hash")
        if cache_key_inputs_hash is not None:
            if not isinstance(cache_key_inputs_hash, str) or not cache_key_inputs_hash.strip() or not cache_key_inputs_hash.startswith("sha256:"):
                errors.append("risk.off_target.cache_key_inputs_hash must be sha256:* when present")
        if cache_key and cache_key_inputs_hash and cache_key != cache_key_inputs_hash:
            errors.append("risk.off_target.cache_key_inputs_hash must match cache_key for provenance integrity")
        provider_version = offt.get("provider_version")
        if provider_version is not None and (not isinstance(provider_version, str) or not provider_version.strip()):
            errors.append("risk.off_target.provider_version must be non-empty string when present")

        if status == "computed" and mode == "none":
            errors.append("risk.off_target.mode cannot be none when status=computed")
        if status == "computed" and executed_mode == "none":
            errors.append("risk.off_target.executed_mode cannot be none when status=computed")
        if status == "not_computed":
            detected_warnings.add("off_target_not_computed")
            severity = offt.get("severity")
            if not isinstance(severity, str) or severity not in OFFTARGET_SEVERITY_VALUES:
                errors.append("risk.off_target.severity invalid")
            reason = offt.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append("risk.off_target.reason required when not_computed")
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if str(severity or "") == "blocking" and grade in {"A", "B"}:
                errors.append("off_target_not_computed must cap verdict.grade at C")
        elif status == "computed":
            for k in (
                "worst_site_score",
                "sum_score",
                "p_hits_coding_exon",
                "p_hits_promoter",
                "p_hits_enhancer",
                "p_hits_splice",
                "top_sites",
            ):
                if k not in offt:
                    errors.append(f"missing required field: risk.off_target.{k}")
            top_sites = offt.get("top_sites")
            if isinstance(top_sites, list):
                for j, site in enumerate(top_sites):
                    if not isinstance(site, Mapping):
                        errors.append(f"risk.off_target.top_sites[{j}] must be object")
                        continue
                    locus = req(site, "locus", dict, f"risk.off_target.top_sites[{j}]") or {}
                    if isinstance(locus, Mapping):
                        _ = req(locus, "chrom", str, f"risk.off_target.top_sites[{j}].locus")
                        _ = req(locus, "pos", int, f"risk.off_target.top_sites[{j}].locus")
                        strand = str(req(locus, "strand", str, f"risk.off_target.top_sites[{j}].locus") or "")
                        if strand and strand not in {"+", "-"}:
                            errors.append(f"risk.off_target.top_sites[{j}].locus.strand invalid")
                    _ = req(site, "mismatches", int, f"risk.off_target.top_sites[{j}]")
                    _ = req(site, "pam", str, f"risk.off_target.top_sites[{j}]")
                    _ = req(site, "score", float, f"risk.off_target.top_sites[{j}]")
                    annotation = req(site, "annotation", dict, f"risk.off_target.top_sites[{j}]")
                    if status == "computed" and annotation_computed is False and isinstance(annotation, Mapping):
                        if annotation:
                            astatus = annotation.get("status")
                            if astatus is None:
                                errors.append(
                                    f"risk.off_target.top_sites[{j}].annotation must include status when annotation_computed=false"
                                )
                            elif str(astatus) != "not_computed":
                                errors.append(
                                    f"risk.off_target.top_sites[{j}].annotation.status must be not_computed when annotation_computed=false"
                                )
                    bulge = site.get("bulge")
                    if bulge is not None and not isinstance(bulge, Mapping):
                        errors.append(f"risk.off_target.top_sites[{j}].bulge must be object or null")
            if mode == "full" and executed_mode != "full":
                verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
                grade = str(verdict.get("grade") or "")
                if grade in {"A", "B"}:
                    errors.append("off_target_degraded must cap verdict.grade at C")
            if executed_mode == "screening":
                detected_warnings.add("off_target_screening")

    structural = risk.get("structural")
    if not isinstance(structural, Mapping):
        errors.append("risk.structural missing")
    else:
        _ = req(structural, "schema", str, "risk.structural")
        status = str(structural.get("status") or "")
        if status not in STRUCTURAL_STATUS_VALUES:
            errors.append("risk.structural.status invalid")
        mode = str(req(structural, "mode", str, "risk.structural") or "")
        if mode == "local":
            mode = "local_screening"
        if mode == "genome":
            mode = "genome_screening"
        if mode not in STRUCTURAL_MODE_VALUES:
            errors.append("risk.structural.mode invalid")
        executed_mode = str(req(structural, "executed_mode", str, "risk.structural") or "")
        if executed_mode == "local":
            executed_mode = "local_screening"
        if executed_mode == "genome":
            executed_mode = "genome_screening"
        if executed_mode not in STRUCTURAL_MODE_VALUES:
            errors.append("risk.structural.executed_mode invalid")
        scope = str(req(structural, "scope", str, "risk.structural") or "")
        if scope and scope not in STRUCTURAL_SCOPE_VALUES:
            errors.append("risk.structural.scope invalid")
        limitations = req(structural, "limitations", str, "risk.structural")
        if isinstance(limitations, str) and not limitations.strip():
            errors.append("risk.structural.limitations must be non-empty string")
        _ = req(structural, "params", dict, "risk.structural")
        break_sites = req(structural, "break_sites", list, "risk.structural")
        if isinstance(break_sites, list):
            for j, site in enumerate(break_sites):
                if not isinstance(site, Mapping):
                    errors.append(f"risk.structural.break_sites[{j}] must be object")
                    continue
                _ = req(site, "chrom", str, f"risk.structural.break_sites[{j}]")
                _ = req(site, "pos", int, f"risk.structural.break_sites[{j}]")
                strand = str(req(site, "strand", str, f"risk.structural.break_sites[{j}]") or "")
                if strand and strand not in {"+", "-"}:
                    errors.append(f"risk.structural.break_sites[{j}].strand invalid")
                p = req(site, "cleavageProbabilityProxy", float, f"risk.structural.break_sites[{j}]")
                if isinstance(p, float) and not (0.0 <= float(p) <= 1.0):
                    errors.append(f"risk.structural.break_sites[{j}].cleavageProbabilityProxy out of range")
                tags = req(site, "tags", list, f"risk.structural.break_sites[{j}]")
                if isinstance(tags, list) and any(not isinstance(t, str) for t in tags):
                    errors.append(f"risk.structural.break_sites[{j}].tags must be array of strings")
                _ = req(site, "source", str, f"risk.structural.break_sites[{j}]")
                _ = req(site, "mismatchProfile", dict, f"risk.structural.break_sites[{j}]")

        dist = req(structural, "event_distribution", dict, "risk.structural")
        if isinstance(dist, Mapping):
            total = 0.0
            for k in ("no_rearrangement", "large_deletion", "inversion", "translocation", "complex_rearrangement"):
                val = req(dist, k, float, "risk.structural.event_distribution")
                if isinstance(val, float):
                    if not (0.0 <= float(val) <= 1.0):
                        errors.append(f"risk.structural.event_distribution.{k} out of range")
                    total += float(val)
            if abs(float(total) - 1.0) > 5e-3:
                errors.append("risk.structural.event_distribution must sum to 1 (+/- 0.005)")

        _ = req(structural, "large_deletion_length_bins", list, "risk.structural")
        _ = req(structural, "top_inversion_pairs", list, "risk.structural")
        _ = req(structural, "top_translocation_pairs", list, "risk.structural")
        _ = req(structural, "chrom_pair_masses", list, "risk.structural")
        _ = req(structural, "metrics", dict, "risk.structural")

        if executed_mode == "none" and scope and scope != "none":
            errors.append("risk.structural.scope must be none when executed_mode=none")
        if status == "not_computed":
            detected_warnings.add("structural_not_computed")
            reason = structural.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append("risk.structural.reason required when not_computed")

    topo = risk.get("topology_3d")
    if not isinstance(topo, Mapping):
        errors.append("risk.topology_3d missing")
    else:
        status = str(topo.get("status") or "")
        if status not in TOPOLOGY_STATUS_VALUES:
            errors.append("risk.topology_3d.status invalid")
        if status == "not_computed":
            detected_warnings.add("topology_3d_not_computed")
            reason = topo.get("reason")
            if not isinstance(reason, str) or not reason.strip():
                errors.append("risk.topology_3d.reason required when not_computed")
            verdict = payload.get("verdict") if isinstance(payload.get("verdict"), Mapping) else {}
            grade = str(verdict.get("grade") or "")
            if grade in {"A", "B"}:
                errors.append("topology_3d not computed must cap verdict.grade at C")
        elif status == "computed":
            _ = req(topo, "tad_boundary_distance_bp", float, "risk.topology_3d")
            _ = req(topo, "p_contact_high_risk_elements", float, "risk.topology_3d")
            _ = req(topo, "top_contacts", list, "risk.topology_3d")

    integrity = req(payload, "integrity", dict, "root") or {}
    failures_list = req(integrity, "failures", list, "integrity") or []
    warnings_list = req(integrity, "warnings", list, "integrity") or []
    if any(not isinstance(x, str) for x in failures_list):
        errors.append("integrity.failures must be array of strings")
    if any(not isinstance(x, str) for x in warnings_list):
        errors.append("integrity.warnings must be array of strings")
    failures_set = {str(x) for x in failures_list if isinstance(x, str)}
    warnings_set = {str(x) for x in warnings_list if isinstance(x, str)}
    for code in detected_failures:
        if code not in failures_set:
            errors.append(f"integrity.failures missing required code: {code}")
    for code in detected_warnings:
        if code not in warnings_set:
            errors.append(f"integrity.warnings missing required code: {code}")

    verdict = req(payload, "verdict", dict, "root") or {}
    grade = str(req(verdict, "grade", str, "verdict") or "")
    headline = str(req(verdict, "headline", str, "verdict") or "")
    decision = str(req(verdict, "decision", str, "verdict") or "")
    verdict_mode = str(req(verdict, "decision_mode", str, "verdict") or "")
    compliant_with_policy = req(verdict, "compliant_with_policy", bool, "verdict")
    reasons = req(verdict, "noncompliance_reasons", list, "verdict") or []
    decision_notes = req(verdict, "decision_notes", list, "verdict") or []
    if any(not isinstance(x, str) for x in decision_notes):
        errors.append("verdict.decision_notes must be array of strings")
    if any(not isinstance(x, str) for x in reasons):
        errors.append("verdict.noncompliance_reasons must be array of strings")
    if isinstance(compliant_with_policy, bool):
        if compliant_with_policy and reasons:
            errors.append("verdict.noncompliance_reasons must be empty when compliant_with_policy=true")
        if (not compliant_with_policy) and (not reasons):
            errors.append("verdict.noncompliance_reasons must be non-empty when compliant_with_policy=false")
        if (not compliant_with_policy) and grade in {"A", "B"}:
            errors.append("policy noncompliance must cap verdict.grade at C")
    if grade and grade not in GRADE_VALUES:
        errors.append("verdict.grade invalid")
    if decision and decision not in DECISION_VALUES:
        errors.append("verdict.decision invalid")
    if verdict_mode and verdict_mode not in DECISION_MODE_VALUES:
        errors.append("verdict.decision_mode invalid")
    if verdict_mode and decision_mode and verdict_mode != decision_mode:
        errors.append("verdict.decision_mode must match root decision_mode")
    if decision_mode == "filter_only" and decision == "go":
        errors.append("filter_only must not output decision=go")
    if decision_mode == "decision_grade" and decision and decision not in {"go", "no_go"}:
        errors.append("decision_grade must output go/no_go only")
    if decision_mode == "decision_grade":
        lic = provenance.get("license") if isinstance(provenance.get("license"), Mapping) else {}
        lic_status = str(lic.get("status") or "").strip().lower()
        lic_id = str(lic.get("license_id") or "").strip()
        lic_sha = str(lic.get("license_sha256") or "").strip()
        lic_org = str(lic.get("org") or "").strip()
        lic_ep = str(lic.get("edit_program_id") or "").strip()
        if lic_status != "licensed":
            errors.append("decision_grade requires provenance.license.status=licensed")
        if not lic_id:
            errors.append("decision_grade requires provenance.license.license_id")
        if not (lic_sha.startswith("sha256:") and len(lic_sha) == len("sha256:") + 64):
            errors.append("decision_grade requires provenance.license.license_sha256 sha256:<hex>")
        if not lic_org:
            errors.append("decision_grade requires provenance.license.org")
        if not lic_ep:
            errors.append("decision_grade requires provenance.license.edit_program_id")

        cald_id = str(cald.get("id") or "")
        cald_checksum = str(cald.get("checksum") or "")
        if cald_id in {"", "unconfigured"}:
            errors.append("decision_grade requires provenance.data.calibration_dataset.id configured")
        if cald_checksum in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.data.calibration_dataset.checksum")
        calb_id = str(calb.get("id") or "")
        calb_checksum = str(calb.get("checksum") or "")
        if calb_id in {"", "unconfigured"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.id configured")
        if calb_checksum in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.checksum")
        if str(calb_code_hash or "") in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.evaluation_code_hash")
        if str(calb_model_id or "") in {"", "unconfigured"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.model_id configured")
        if str(calb_model_version or "") in {"",}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.model_version configured")
        if str(calb_model_hash or "") in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.model_hash")
        if str(calb_ds_id or "") in {"", "unconfigured"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.calibration_dataset_id configured")
        if str(calb_ds_checksum or "") in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.data.calibration_bundle.calibration_dataset_checksum")

        if str(calb_model_id or "") and str(calb_model_id) != str(prov_model.get("model_id") or ""):
            errors.append("decision_grade requires calibration_bundle.model_id to match provenance.model.model_id")
        if str(calb_model_version or "") and str(calb_model_version) != str(prov_model.get("model_version") or ""):
            errors.append("decision_grade requires calibration_bundle.model_version to match provenance.model.model_version")
        if str(calb_model_hash or "") and str(calb_model_hash) != str(prov_model.get("model_hash") or ""):
            errors.append("decision_grade requires calibration_bundle.model_hash to match provenance.model.model_hash")
        if str(calb_ds_id or "") and cald_id and str(calb_ds_id) != cald_id:
            errors.append("decision_grade requires calibration_bundle.calibration_dataset_id to match provenance.data.calibration_dataset.id")
        if str(calb_ds_checksum or "") and cald_checksum and str(calb_ds_checksum) != cald_checksum:
            errors.append("decision_grade requires calibration_bundle.calibration_dataset_checksum to match provenance.data.calibration_dataset.checksum")

        git_commit = str(backend.get("git_commit") or "")
        if git_commit in {"", "unavailable"}:
            errors.append("decision_grade requires provenance.backend.git_commit configured")
        build_ts = str(backend.get("build_timestamp_utc") or "")
        if build_ts in {"", "unavailable"}:
            errors.append("decision_grade requires provenance.backend.build_timestamp_utc configured")
        model_hash = str(prov_model.get("model_hash") or "")
        if model_hash in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.model.model_hash")
        params_hash = str(prov_params.get("params_hash") or "")
        if params_hash in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.params.params_hash")
        profile_id = str(cut_profile.get("id") or "")
        profile_hash = str(cut_profile.get("hash") or "")
        if profile_id in {"", "unavailable"}:
            errors.append("decision_grade requires provenance.assumptions.cut_repair_profile.id configured")
        if profile_hash in {"", "sha256:unavailable"}:
            errors.append("decision_grade requires provenance.assumptions.cut_repair_profile.hash")
    unc_status = str(uncertainty.get("status") or "")
    if unc_status not in {"computed", "not_computed"}:
        errors.append("uncertainty.status invalid")
    if decision_mode == "decision_grade" and unc_status != "computed":
        errors.append("decision_grade requires uncertainty.status=computed")
    if unc_status == "computed":
        unc_kind = str(uncertainty.get("kind") or "")
        if unc_kind and unc_kind not in {"credible_interval", "bootstrap_interval"}:
            errors.append("uncertainty.kind invalid")
        cis = uncertainty.get("credible_intervals") if isinstance(uncertainty.get("credible_intervals"), Mapping) else None
        if not cis:
            errors.append("uncertainty.computed requires credible_intervals map")
        elif decision_mode == "decision_grade":
            required_keys = ("control.intended_functional_p", "control.no_cut_p", "outcomes.top_p")
            for key in required_keys:
                entry = cis.get(key)
                if not isinstance(entry, Mapping):
                    errors.append(f"decision_grade requires uncertainty.credible_intervals[{key}]")
                    continue
                lo = entry.get("lower")
                hi = entry.get("upper")
                if not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)):
                    errors.append(f"uncertainty.credible_intervals[{key}] requires lower/upper")
    if validity_status == "invalid":
        if decision_mode != "filter_only":
            errors.append("validity.status=invalid must force decision_mode=filter_only")
        if decision != "insufficient_evidence":
            errors.append("validity.status=invalid must force verdict.decision=insufficient_evidence")

    escape_dominates = isinstance(conv_escape_worst, float) and float(conv_escape_worst) > 0.5
    expected_headline = None
    if escape_dominates and grade in HEADLINE_ESCAPE_DOMINATES_BY_GRADE:
        expected_headline = HEADLINE_ESCAPE_DOMINATES_BY_GRADE[grade]
    elif grade in HEADLINE_BY_GRADE:
        expected_headline = HEADLINE_BY_GRADE[grade]
    if expected_headline is not None and headline != expected_headline:
        errors.append("verdict.headline must match allowed text for grade")

    recommendations = req(payload, "recommendations", list, "root") or []
    if decision_mode != "decision_grade" and recommendations:
        errors.append("filter_only must not include recommendations")
    for i, rec in enumerate(recommendations):
        if not isinstance(rec, Mapping):
            errors.append(f"recommendations[{i}] must be object")
            continue
        rid = req(rec, "recommendation_id", str, f"recommendations[{i}]")
        if isinstance(rid, str) and not rid.strip():
            errors.append(f"recommendations[{i}].recommendation_id must be non-empty string")
        title = req(rec, "title", str, f"recommendations[{i}]")
        if isinstance(title, str) and not title.strip():
            errors.append(f"recommendations[{i}].title must be non-empty string")
        suggestion = req(rec, "suggestion", str, f"recommendations[{i}]")
        if isinstance(suggestion, str) and not suggestion.strip():
            errors.append(f"recommendations[{i}].suggestion must be non-empty string")

        triggered_by = req(rec, "triggered_by", list, f"recommendations[{i}]") or []
        if not triggered_by:
            errors.append(f"recommendations[{i}].triggered_by must be non-empty array")
        for j, trig in enumerate(triggered_by):
            if not isinstance(trig, Mapping):
                errors.append(f"recommendations[{i}].triggered_by[{j}] must be object")
                continue
            metric_path = req(trig, "metric_path", str, f"recommendations[{i}].triggered_by[{j}]")
            if isinstance(metric_path, str) and not metric_path.strip():
                errors.append(f"recommendations[{i}].triggered_by[{j}].metric_path must be non-empty string")
            condition = req(trig, "condition", str, f"recommendations[{i}].triggered_by[{j}]")
            if isinstance(condition, str) and not condition.strip():
                errors.append(f"recommendations[{i}].triggered_by[{j}].condition must be non-empty string")
            if "value" not in trig:
                errors.append(f"missing required field: recommendations[{i}].triggered_by[{j}].value")
            else:
                v = trig.get("value")
                if isinstance(v, (list, dict)):
                    errors.append(f"recommendations[{i}].triggered_by[{j}].value must be scalar")

    # Grade gates: never allow a better-than-permitted grade.
    if grade:
        gate_f = False
        if failures_set:
            gate_f = True
        intended = control.get("intended_functional_p")
        if isinstance(intended, (int, float)) and float(intended) < 0.6:
            gate_f = True
        if isinstance(no_cut_p, (int, float)) and float(no_cut_p) > 0.1:
            gate_f = True
        dom = control.get("dominance_ratio")
        if isinstance(dom, (int, float)) and float(dom) < 1.5:
            gate_f = True
        splice = tail.get("p_any_splice_disruption")
        if gate_f and grade != "F":
            errors.append("verdict.grade must be F due to control/risk/integrity gates")
        if isinstance(splice, (int, float)) and float(splice) > 1e-4 and grade in {"A", "B", "C"}:
            errors.append("verdict.grade must be D-or-worse due to splice tail risk gate")
        if escape_dominates and grade in {"A", "B", "C"}:
            errors.append("verdict.grade must be D-or-worse due to escape dynamics gate")
        if (
            isinstance(conv_initial_uncut, float)
            and isinstance(conv_escape_risk, float)
            and float(conv_initial_uncut) > 0.1
            and float(conv_escape_risk) > 0.5
            and grade in {"A", "B", "C"}
        ):
            errors.append("verdict.grade must be D-or-worse due to escape risk gate")

    banned = ("meets intent", "success", "intended edit achieved")
    if grade == "F":
        lower = headline.lower()
        if any(term in lower for term in banned):
            errors.append("language_gate: forbidden success language in grade F headline")
        if "dominant outcome" in lower:
            errors.append("language_gate: 'dominant outcome' forbidden in grade F headline")

    if errors:
        raise SummaryValidationError(errors)
