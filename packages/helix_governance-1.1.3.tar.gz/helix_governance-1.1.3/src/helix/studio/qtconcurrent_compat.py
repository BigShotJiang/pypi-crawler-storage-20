from __future__ import annotations

import concurrent.futures
from typing import Any, Callable

from PySide6.QtCore import QObject, QTimer, Signal

try:
    from PySide6.QtConcurrent import run as qt_run  # type: ignore
    from PySide6.QtConcurrent import QFutureWatcher  # type: ignore
except (ImportError, AttributeError):
    _EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=4)

    class QFutureWatcher(QObject):  # type: ignore
        finished = Signal()

        def __init__(self, parent: QObject | None = None) -> None:
            super().__init__(parent)
            self._future: concurrent.futures.Future | None = None

        def setFuture(self, fut: concurrent.futures.Future) -> None:  # noqa: N802
            self._future = fut

            def _emit_finished(_: Any) -> None:
                QTimer.singleShot(0, self.finished.emit)

            fut.add_done_callback(_emit_finished)

        def result(self) -> Any:
            if self._future is None:
                raise RuntimeError("No future set")
            return self._future.result()

    def qt_run(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> concurrent.futures.Future:  # type: ignore
        return _EXECUTOR.submit(fn, *args, **kwargs)
