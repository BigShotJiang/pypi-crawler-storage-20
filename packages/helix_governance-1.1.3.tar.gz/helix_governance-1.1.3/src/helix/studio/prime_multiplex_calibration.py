from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

PRIME_MULTIPLEX_CAL_PROFILE_SCHEMA_ID = "helix_prime_multiplex_calibration_profile_v1"


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def prime_multiplex_calibration_profile_sha256(profile: Mapping[str, Any]) -> str:
    import hashlib

    return hashlib.sha256(_canonical_json_bytes(profile)).hexdigest()


def clamp_ppm(value_ppm: int, clamp_min_ppm: int, clamp_max_ppm: int) -> int:
    return max(clamp_min_ppm, min(clamp_max_ppm, value_ppm))


def apply_prime_multiplex_calibration_to_report(report: Mapping[str, Any], profile: Mapping[str, Any]) -> dict[str, Any]:
    payload = dict(report)
    mux = None
    if isinstance(payload.get("prime_multiplex"), Mapping):
        mux = dict(payload.get("prime_multiplex"))
    elif isinstance(payload.get("multiplex"), Mapping) and isinstance(payload["multiplex"].get("prime"), Mapping):
        mux = dict(payload["multiplex"]["prime"])
    if mux is None:
        return payload
    combined_ppm = int(round(float(mux.get("combinedDesired") or 0.0) * 1_000_000))
    multiplier_ppm = int(profile.get("multiplierPpm") or 1_000_000)
    clamp_min = int(profile.get("clampMinPpm") or 0)
    clamp_max = int(profile.get("clampMaxPpm") or 1_000_000)
    calibrated_ppm = clamp_ppm(combined_ppm * multiplier_ppm // 1_000_000, clamp_min, clamp_max)
    mux["combinedCalibrated"] = round(calibrated_ppm / 1_000_000.0, 6)
    mux["combinedDesired"] = round(combined_ppm / 1_000_000.0, 6)
    mux["multiplierAppliedPpm"] = multiplier_ppm
    mux["calibrationProfileId"] = profile.get("profileId")
    mux["calibrationSchema"] = PRIME_MULTIPLEX_CAL_PROFILE_SCHEMA_ID
    try:
        mux["calibrationProfileHash"] = prime_multiplex_calibration_profile_sha256(profile)
    except Exception:
        pass
    mux["calibrationClamp"] = {"minPpm": clamp_min, "maxPpm": clamp_max}
    if isinstance(payload.get("multiplex"), Mapping):
        mp = dict(payload.get("multiplex"))
        mp["prime"] = mux
        payload["multiplex"] = mp
    else:
        payload["prime_multiplex"] = mux
    payload["primeMultiplexCalibrationApplied"] = True
    payload["primeMultiplexCalibrationProfileId"] = profile.get("profileId")
    return payload


def _weighted_median(pairs: Sequence[tuple[int, int]]) -> int:
    """pairs of (value_ppm, weight)."""
    if not pairs:
        return 1_000_000
    total = sum(w for _, w in pairs)
    half = total / 2
    acc = 0
    for val, w in sorted(pairs, key=lambda p: p[0]):
        acc += w
        if acc >= half:
            return val
    return pairs[-1][0]


def build_prime_multiplex_calibration_profile(
    *,
    profile_id: str,
    observations: Sequence[Mapping[str, Any]],
    clamp_min_ppm: int = 500_000,
    clamp_max_ppm: int = 2_000_000,
) -> dict[str, Any]:
    ratios: list[tuple[int, int]] = []
    for obs in observations:
        try:
            pred_ppm = int(round(float(obs.get("predCombinedPpm") or 0)))
            obs_ppm = int(round(float(obs.get("obsCombinedPpm") or 0)))
            weight = int(obs.get("totalEvents") or 0)
        except Exception:
            continue
        if pred_ppm <= 0 or obs_ppm < 0:
            continue
        ratio_ppm = int((obs_ppm * 1_000_000) / max(pred_ppm, 1))
        ratio_ppm = clamp_ppm(ratio_ppm, clamp_min_ppm, clamp_max_ppm)
        ratios.append((ratio_ppm, max(1, weight)))
    multiplier_ppm = clamp_ppm(_weighted_median(ratios), clamp_min_ppm, clamp_max_ppm) if ratios else 1_000_000
    profile = {
        "schema": PRIME_MULTIPLEX_CAL_PROFILE_SCHEMA_ID,
        "profileId": profile_id,
        "multiplierPpm": multiplier_ppm,
        "clampMinPpm": clamp_min_ppm,
        "clampMaxPpm": clamp_max_ppm,
    }
    return profile


__all__ = [
    "PRIME_MULTIPLEX_CAL_PROFILE_SCHEMA_ID",
    "prime_multiplex_calibration_profile_sha256",
    "apply_prime_multiplex_calibration_to_report",
    "build_prime_multiplex_calibration_profile",
]
