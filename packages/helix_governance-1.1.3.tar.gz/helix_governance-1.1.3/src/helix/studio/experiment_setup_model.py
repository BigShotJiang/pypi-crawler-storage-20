from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from helix.studio.experiment_intent_spec import EXPERIMENT_INTENT_SPEC_SCHEMA_ID, default_experiment_intent_spec
from helix.studio.experiment_spec import default_experiment_spec


PRIMARY_GOAL_OPTIONS: tuple[tuple[str, str], ...] = (
    ("feasibility", "Validate an edit design feasibility"),
    ("compare_candidates", "Compare guides or pegRNAs"),
    ("optimize_distribution", "Optimize expected outcome distribution"),
    ("reduce_off_target_risk", "Reduce off-target risk"),
    ("plan_assay_and_primers", "Plan assay and primer strategy"),
    ("generate_review_pack", "Generate a decision pack for internal review"),
)

MODALITY_OPTIONS: tuple[tuple[str, str], ...] = (
    ("crispr_cut", "CRISPR cut (Cas9)"),
    ("prime", "Prime editing"),
)

READOUT_LEVEL_OPTIONS: tuple[tuple[str, str], ...] = (
    ("dna_only", "DNA only"),
    ("protein", "DNA + Protein"),
    ("phenotype", "DNA + Phenotype"),
    ("multiple", "DNA + Protein + Phenotype"),
)

REFERENCE_BUILD_OPTIONS: tuple[tuple[str, str], ...] = (
    ("hg38", "hg38 (human)"),
    ("mm10", "mm10 (mouse)"),
    ("synthetic", "Synthetic / custom (no reference yet)"),
)

TARGET_INTENT_OPTIONS: tuple[tuple[str, str], ...] = (
    ("knockout", "Knockout"),
    ("precise_substitution", "Precise substitution (SNV)"),
    ("tag_insertion", "Tag insertion"),
    ("promoter_edit", "Promoter edit"),
    ("prime_edit", "Prime edit"),
    ("multiplex", "Multiplex"),
)

DELIVERY_OPTIONS: tuple[tuple[str, str], ...] = (
    ("rnp", "RNP"),
    ("plasmid", "Plasmid"),
    ("aav", "AAV"),
    ("lentivirus", "Lentivirus"),
    ("mrna", "mRNA"),
)

OFF_TARGET_BASIS_OPTIONS: tuple[tuple[str, str], ...] = (
    ("predicted", "Predicted"),
    ("observed", "Observed"),
    ("both", "Predicted + observed"),
)

OFF_TARGET_SCOPE_OPTIONS: tuple[tuple[str, str], ...] = (
    ("coding_exons", "Coding exons only"),
    ("genome_wide", "Genome-wide"),
    ("panel", "Targeted panel"),
)

CELL_CONTEXT_OPTIONS: tuple[tuple[str, str], ...] = (
    ("unknown", "Unknown / not specified"),
    ("easy", "Easy-to-edit"),
    ("standard", "Standard"),
    ("hard", "Hard-to-edit"),
)

EXPERIMENT_SCALE_OPTIONS: tuple[tuple[str, str], ...] = (
    ("bulk", "Bulk (pooled)"),
    ("clonal", "Clonal / single-cell"),
)

READOUT_OPTIONS: tuple[tuple[str, str, str], ...] = (
    ("ampseq", "Amplicon sequencing", "amplicon sequencing + editing profile"),
    ("flow", "Reporter / flow assay", "reporter assay / flow cytometry"),
    ("western", "Western blot", "western blot"),
    ("ms", "Mass spectrometry", "mass spectrometry"),
    ("wgs", "Whole-genome sequencing", "whole-genome sequencing (screening)"),
    ("phenotype", "Phenotype proxy", "phenotype proxy readout"),
)

OUTPUT_CLASS_OPTIONS: tuple[tuple[str, str], ...] = (
    ("exploratory", "Exploratory (not decision-grade)"),
    ("decision_candidate", "Decision-grade candidate (gates required)"),
)


@dataclass(frozen=True)
class ExperimentSetupSelections:
    preset_id: str | None
    primary_goal: str
    decision_question: str
    hypothesis: str
    success_edit_rate_pct: float
    success_max_high_risk_coding_offtarget_count: int | None
    off_target_basis: str
    off_target_method: str
    off_target_scope: str
    success_requires_editable: bool
    success_protein_loss_pct: float | None
    success_protein_loss_day: int | None
    success_phenotype_effect_size: float | None
    success_phenotype_effect_day: int | None
    modality: str
    reference_build: str
    target_intent: str
    perturbation_target: str
    delivery_modality: str
    cell_context: str
    experiment_scale: str
    readout_level: str
    assay_type: str
    output_class: str


@dataclass(frozen=True)
class IntentCardMeta:
    preset_id: str
    title: str
    decision: str
    evidence_required: str
    export_posture: str
    tag: str | None = None
    recommended_when: str | None = None


def default_setup_selections(*, preset_id: str | None = None) -> ExperimentSetupSelections:
    return ExperimentSetupSelections(
        preset_id=preset_id,
        primary_goal="feasibility",
        decision_question="",
        hypothesis="",
        success_edit_rate_pct=80.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="coding_exons",
        success_requires_editable=True,
        success_protein_loss_pct=None,
        success_protein_loss_day=None,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="crispr_cut",
        reference_build="hg38",
        target_intent="knockout",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="dna_only",
        assay_type="ampseq",
        output_class="exploratory",
    )


def _goal_label(goal: str) -> str:
    for key, label in PRIMARY_GOAL_OPTIONS:
        if key == goal:
            return label
    return goal


def _evidence_tiers_label(sel: ExperimentSetupSelections) -> str:
    tiers: list[str] = ["A"]
    if sel.success_protein_loss_pct is not None:
        tiers.append("B")
    if sel.success_phenotype_effect_size is not None:
        tiers.append("C")
    return "Tier " + "+".join(tiers)


def _intent_card_decision_label(goal: str) -> str:
    key = str(goal or "").strip()
    mapping = {
        "feasibility": "Validate edit design feasibility",
        "compare_candidates": "Compare candidate performance",
        "optimize_distribution": "Optimize outcome distribution",
        "reduce_off_target_risk": "Assess off-target risk",
        "plan_assay_and_primers": "Plan assay and primer strategy",
        "generate_review_pack": "Generate a decision pack for review",
    }
    return mapping.get(key, _goal_label(key))


def _readout_measurement_text(assay_type: str) -> str:
    for key, _label, measurement in READOUT_OPTIONS:
        if key == assay_type:
            return measurement
    return str(assay_type or "").strip()


def _norm_target(value: str) -> str:
    target = str(value or "").strip()
    if not target:
        return ""
    # If the UI tokenizes targets (e.g., "TP53 · hg38 · canonical transcript"), normalize to the primary.
    if "·" in target:
        primary = target.split("·", maxsplit=1)[0].strip()
        if primary:
            target = primary
    if target.lower() in {"tbd", "to do", "todo", "unset", "not set", "not set (draft)"}:
        return ""
    return target


def _premortem_entries(sel: ExperimentSetupSelections) -> list[dict[str, Any]]:
    # Keep this short and generic so it stays useful across modalities, but never emit null mitigation.
    stubs: dict[str, tuple[str, str, str]] = {
        "feasibility": (
            "infeasible constraints",
            "no candidate meets constraints; outcomes are low-confidence or unstable",
            "Mitigation: expand candidates, revisit assumptions, or adjust constraints/policy.",
        ),
        "compare_candidates": (
            "comparison not comparable",
            "rank flips across minor settings changes; results are not stable enough for selection",
            "Mitigation: tighten decision rule, increase candidates, or lock analysis settings before ranking.",
        ),
        "optimize_distribution": (
            "optimization target mismatch",
            "objective improves on paper but fails the stated success criteria",
            "Mitigation: rewrite success criteria, then re-optimize under the same policy and readout plan.",
        ),
        "reduce_off_target_risk": (
            "off-target risk underestimated",
            "unexpected off-target hits appear under stricter search settings",
            "Mitigation: rerun with stricter off-target settings and prioritize coding-region risk reductions.",
        ),
        "plan_assay_and_primers": (
            "assay mismatch",
            "assay/readout cannot discriminate outcomes needed for the decision",
            "Mitigation: choose a readout that can falsify the hypothesis; add timing + controls before export.",
        ),
        "generate_review_pack": (
            "evidence incomplete",
            "review pack missing required controls/assay framing and cannot support a decision",
            "Mitigation: complete the evidence checklist and re-run with the same policy for determinism.",
        ),
    }
    failure_mode, signature, mitigation = stubs.get(
        sel.primary_goal,
        ("assumption mismatch", "evidence does not support the decision", "Mitigation: revisit assumptions and add controls."),
    )
    entries: list[dict[str, Any]] = [
        {"failureMode": failure_mode, "dataSignature": signature, "mitigation": mitigation},
        {
            "failureMode": "low editing due to delivery",
            "dataSignature": "observed edit rate below threshold or high toxicity under the assumed delivery context",
            "mitigation": "Mitigation: pilot delivery DOE (dose/method); include positive + negative controls.",
        },
    ]
    if str(sel.target_intent or "").strip().lower() == "knockout":
        entries.append(
            {
                "failureMode": "high DNA editing but weak functional knockout",
                "dataSignature": "DNA-level edits present but protein/phenotype readouts do not change as expected",
                "mitigation": "Mitigation: target early constitutive exon, use ≥2 guides, and add protein/phenotype criteria + timing.",
            }
        )
    return entries


def _success_criteria_summary(sel: ExperimentSetupSelections) -> str:
    parts: list[str] = []
    if sel.success_edit_rate_pct > 0:
        parts.append(f"Intended edit rate ≥ {sel.success_edit_rate_pct:.0f}%")
    if sel.success_max_high_risk_coding_offtarget_count is not None:
        parts.append(f"High-risk coding off-targets ≤ {int(sel.success_max_high_risk_coding_offtarget_count)}")
    if sel.success_requires_editable:
        parts.append("Editable within declared modality constraints")
    if sel.success_protein_loss_pct is not None:
        day = int(sel.success_protein_loss_day or 0)
        parts.append(
            f"Protein loss ≥ {float(sel.success_protein_loss_pct):.0f}% @ day {day}"
            if day > 0
            else f"Protein loss ≥ {float(sel.success_protein_loss_pct):.0f}%"
        )
    if sel.success_phenotype_effect_size is not None:
        day = int(sel.success_phenotype_effect_day or 0)
        val = float(sel.success_phenotype_effect_size)
        parts.append(
            f"Phenotype effect size ≥ {val:g} @ day {day}" if day > 0 else f"Phenotype effect size ≥ {val:g}"
        )
    return "; ".join(parts) if parts else "Success criteria must be defined"


def _decision_question(sel: ExperimentSetupSelections) -> str:
    override = str(sel.decision_question or "").strip()
    if override:
        return override
    goal = _goal_label(sel.primary_goal)
    target = _norm_target(sel.perturbation_target)
    if target:
        return f"{goal}: can we proceed for target '{target}'?"
    return f"{goal}: can we proceed?"


def _decision_rule(sel: ExperimentSetupSelections) -> dict[str, Any]:
    summary = _success_criteria_summary(sel)
    threshold = float(sel.success_edit_rate_pct) / 100.0 if sel.success_edit_rate_pct > 0 else None

    criteria: list[dict[str, Any]] = []
    if sel.success_edit_rate_pct > 0:
        criteria.append(
            {
                "kind": "intended_edit_rate",
                "op": ">=",
                "value": float(sel.success_edit_rate_pct) / 100.0,
            }
        )
    if sel.success_max_high_risk_coding_offtarget_count is not None:
        criteria.append(
            {
                "kind": "max_high_risk_coding_offtarget_count",
                "op": "<=",
                "value": int(sel.success_max_high_risk_coding_offtarget_count),
                "basis": str(sel.off_target_basis or "").strip() or None,
                "method": str(sel.off_target_method or "").strip() or None,
                "scope": str(sel.off_target_scope or "").strip() or None,
            }
        )
    criteria.append(
        {
            "kind": "editable_within_modality_constraints",
            "op": "==",
            "value": bool(sel.success_requires_editable),
        }
    )
    if sel.success_protein_loss_pct is not None:
        criteria.append(
            {
                "kind": "protein_loss_pct_by_day",
                "op": ">=",
                "value": float(sel.success_protein_loss_pct) / 100.0,
                "day": int(sel.success_protein_loss_day or 0),
            }
        )
    if sel.success_phenotype_effect_size is not None:
        criteria.append(
            {
                "kind": "phenotype_effect_size_by_day",
                "op": ">=",
                "value": float(sel.success_phenotype_effect_size),
                "day": int(sel.success_phenotype_effect_day or 0),
            }
        )

    notes = ""
    if str(sel.target_intent or "").strip().lower() == "knockout" and sel.success_protein_loss_pct is None and sel.success_phenotype_effect_size is None:
        notes = "Note: DNA-level edit rates do not guarantee functional knockout. Add protein/phenotype criteria when needed."

    pattern = json.dumps({"criteria": criteria}, sort_keys=True, separators=(",", ": "))
    return {
        "rule": summary,
        "notes": notes,
        "threshold": threshold,
        "pattern": pattern,
    }


def build_experiment_intent_spec(
    sel: ExperimentSetupSelections,
    *,
    created_at_utc: str | None,
    intent_id: str = "intent_setup",
) -> dict[str, Any]:
    spec = default_experiment_intent_spec()
    spec["schema"] = EXPERIMENT_INTENT_SPEC_SCHEMA_ID
    spec["intentId"] = str(intent_id or "intent_setup").strip() or "intent_setup"
    spec["createdAt"] = str(created_at_utc) if created_at_utc else None
    spec["decisionQuestion"] = _decision_question(sel)
    spec["decisionQuestionSource"] = "override" if str(sel.decision_question or "").strip() else "derived"
    spec["decisionQuestionTemplate"] = "{goal}: can we proceed for target '{target}'?" if _norm_target(sel.perturbation_target) else "{goal}: can we proceed?"
    spec["decisionQuestionParams"] = {
        "goal": _goal_label(sel.primary_goal),
        "target": _norm_target(sel.perturbation_target) or None,
    }
    spec["hypothesis"] = str(sel.hypothesis or "").strip()
    target = _norm_target(sel.perturbation_target)
    target_display = str(sel.perturbation_target or "").strip()
    spec["perturbation"] = {
        "modality": str(sel.modality or "").strip(),
        "target": target,
        "targetDisplay": target_display,
        "targetState": "set" if target else "unset",
        "notes": "",
    }
    spec["readout"] = {
        "measurement": _readout_measurement_text(sel.assay_type),
        "notes": "",
    }
    spec["decisionRule"] = _decision_rule(sel)
    spec["premortem"] = _premortem_entries(sel)
    spec.setdefault("snapshots", default_experiment_intent_spec().get("snapshots"))
    # Extra fields (additionalProperties=true) used for UI + downstream scoping.
    spec["primaryGoal"] = str(sel.primary_goal or "").strip()
    spec["outputClass"] = str(sel.output_class or "").strip()
    spec["readoutLevel"] = str(sel.readout_level or "").strip()
    spec["cellContext"] = str(sel.cell_context or "").strip()
    spec["experimentScale"] = str(sel.experiment_scale or "").strip()
    spec["successCriteria"] = {
        "intendedEditRatePct": float(sel.success_edit_rate_pct) if sel.success_edit_rate_pct > 0 else None,
        "maxHighRiskCodingOffTargetCount": (
            int(sel.success_max_high_risk_coding_offtarget_count) if sel.success_max_high_risk_coding_offtarget_count is not None else None
        ),
        "offTargetBasis": str(sel.off_target_basis or "").strip() or None,
        "offTargetMethod": str(sel.off_target_method or "").strip() or None,
        "offTargetScope": str(sel.off_target_scope or "").strip() or None,
        "requiresEditable": bool(sel.success_requires_editable) if sel.success_requires_editable else None,
        "proteinLossPct": float(sel.success_protein_loss_pct) if sel.success_protein_loss_pct is not None else None,
        "proteinLossDay": int(sel.success_protein_loss_day) if sel.success_protein_loss_day is not None else None,
        "phenotypeEffectSizeMin": float(sel.success_phenotype_effect_size) if sel.success_phenotype_effect_size is not None else None,
        "phenotypeEffectDay": int(sel.success_phenotype_effect_day) if sel.success_phenotype_effect_day is not None else None,
    }
    return spec


def build_experiment_spec(sel: ExperimentSetupSelections) -> dict[str, Any]:
    spec = default_experiment_spec()
    ref = spec.get("reference")
    if not isinstance(ref, dict):
        ref = {}
        spec["reference"] = ref
    ref["genomeBuild"] = str(sel.reference_build or "").strip()

    spec["intent"] = str(sel.target_intent or "").strip()
    spec["editModalities"] = [str(sel.modality or "").strip()]

    constraints = spec.get("constraints")
    if not isinstance(constraints, dict):
        constraints = {}
        spec["constraints"] = constraints
    constraints["assayType"] = str(sel.assay_type or "").strip()

    wetlab = constraints.get("wetlab")
    if not isinstance(wetlab, dict):
        wetlab = {}
        constraints["wetlab"] = wetlab
    wetlab["controls"] = ["non_targeting_sgRNA"]
    wetlab["decisionFraming"] = {"question": _decision_question(sel), "successCriteria": _success_criteria_summary(sel)}
    wetlab["deliveryModality"] = str(sel.delivery_modality or "").strip()
    wetlab["cellContext"] = str(sel.cell_context or "").strip()
    wetlab["experimentScale"] = str(sel.experiment_scale or "").strip()
    wetlab["readoutLevel"] = str(sel.readout_level or "").strip()
    wetlab["offTargetBasis"] = str(sel.off_target_basis or "").strip()
    wetlab["offTargetMethod"] = str(sel.off_target_method or "").strip()
    wetlab["offTargetScope"] = str(sel.off_target_scope or "").strip()

    intent_meta = constraints.get("intent")
    if not isinstance(intent_meta, dict):
        intent_meta = {}
        constraints["intent"] = intent_meta
    intent_meta["primary_goal"] = str(sel.primary_goal or "").strip()
    intent_meta["output_class"] = str(sel.output_class or "").strip()
    intent_meta["success_criteria"] = {
        "intended_edit_rate_pct": float(sel.success_edit_rate_pct),
        "max_high_risk_coding_offtarget_count": (
            int(sel.success_max_high_risk_coding_offtarget_count)
            if sel.success_max_high_risk_coding_offtarget_count is not None
            else None
        ),
        "off_target_basis": str(sel.off_target_basis or "").strip() or None,
        "off_target_method": str(sel.off_target_method or "").strip() or None,
        "off_target_scope": str(sel.off_target_scope or "").strip() or None,
        "requires_editable": bool(sel.success_requires_editable),
        "protein_loss_pct": float(sel.success_protein_loss_pct) if sel.success_protein_loss_pct is not None else None,
        "protein_loss_day": int(sel.success_protein_loss_day) if sel.success_protein_loss_day is not None else None,
        "phenotype_effect_size_min": (
            float(sel.success_phenotype_effect_size) if sel.success_phenotype_effect_size is not None else None
        ),
        "phenotype_effect_day": int(sel.success_phenotype_effect_day) if sel.success_phenotype_effect_day is not None else None,
    }
    intent_meta["readout_basis"] = str(sel.assay_type or "").strip()
    intent_meta["readout_level"] = str(sel.readout_level or "").strip()
    intent_meta["cell_context"] = str(sel.cell_context or "").strip()
    intent_meta["experiment_scale"] = str(sel.experiment_scale or "").strip()

    return spec


def initial_rail_segment_for_goal(primary_goal: str) -> str:
    mapping = {
        "feasibility": "edit_plan",
        "compare_candidates": "outcome_model",
        "optimize_distribution": "outcome_model",
        "reduce_off_target_risk": "edit_plan",
        "plan_assay_and_primers": "evidence",
        "generate_review_pack": "evidence",
    }
    return mapping.get(str(primary_goal or "").strip(), "edit_plan")


def session_class_for_output_class(output_class: str) -> str:
    if str(output_class or "").strip().lower() == "decision_candidate":
        return "decision_candidate"
    return "exploratory"


def load_policy_template(output_class: str) -> dict[str, Any] | None:
    """
    Return a policy payload suitable for helixspec runs.

    Prefer vendored policies in `repro/policies/*.policy.json`; return None if unavailable.
    """
    key = str(output_class or "").strip().lower()
    filename = "dev_fast.policy.json" if key != "decision_candidate" else "audit_strict.policy.json"
    root = Path(__file__).resolve().parents[3]
    path = root / "repro" / "policies" / filename
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


PRESETS: Mapping[str, ExperimentSetupSelections] = {
    "knockout_validation": ExperimentSetupSelections(
        preset_id="knockout_validation",
        primary_goal="feasibility",
        decision_question="",
        hypothesis="A guide can achieve ≥80% frameshift with acceptable off-target risk.",
        success_edit_rate_pct=80.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="coding_exons",
        success_requires_editable=True,
        success_protein_loss_pct=None,
        success_protein_loss_day=None,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="crispr_cut",
        reference_build="hg38",
        target_intent="knockout",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="dna_only",
        assay_type="ampseq",
        output_class="exploratory",
    ),
    "functional_knockout": ExperimentSetupSelections(
        preset_id="functional_knockout",
        primary_goal="feasibility",
        decision_question="",
        hypothesis="A knockout design will produce a measurable functional effect under declared delivery and readout assumptions.",
        success_edit_rate_pct=70.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="coding_exons",
        success_requires_editable=True,
        success_protein_loss_pct=70.0,
        success_protein_loss_day=7,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="crispr_cut",
        reference_build="hg38",
        target_intent="knockout",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="protein",
        assay_type="flow",
        output_class="exploratory",
    ),
    "precise_snv_introduction": ExperimentSetupSelections(
        preset_id="precise_snv_introduction",
        primary_goal="feasibility",
        decision_question="",
        hypothesis="A candidate design can introduce the desired substitution while preserving local sequence context.",
        success_edit_rate_pct=50.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="coding_exons",
        success_requires_editable=True,
        success_protein_loss_pct=None,
        success_protein_loss_day=None,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="prime",
        reference_build="hg38",
        target_intent="precise_substitution",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="dna_only",
        assay_type="ampseq",
        output_class="exploratory",
    ),
    "prime_edit_insertion": ExperimentSetupSelections(
        preset_id="prime_edit_insertion",
        primary_goal="feasibility",
        decision_question="",
        hypothesis="A pegRNA can introduce the desired insertion with acceptable byproducts under declared constraints.",
        success_edit_rate_pct=40.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="coding_exons",
        success_requires_editable=True,
        success_protein_loss_pct=None,
        success_protein_loss_day=None,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="prime",
        reference_build="hg38",
        target_intent="prime_edit",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="dna_only",
        assay_type="ampseq",
        output_class="exploratory",
    ),
    "guide_comparison": ExperimentSetupSelections(
        preset_id="guide_comparison",
        primary_goal="compare_candidates",
        decision_question="",
        hypothesis="At least one candidate is clearly preferred under the declared success criteria.",
        success_edit_rate_pct=70.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="coding_exons",
        success_requires_editable=True,
        success_protein_loss_pct=None,
        success_protein_loss_day=None,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="crispr_cut",
        reference_build="hg38",
        target_intent="knockout",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="dna_only",
        assay_type="ampseq",
        output_class="exploratory",
    ),
    "off_target_screening": ExperimentSetupSelections(
        preset_id="off_target_screening",
        primary_goal="reduce_off_target_risk",
        decision_question="",
        hypothesis="A candidate exists that reduces off-target risk without sacrificing the required intended edit rate.",
        success_edit_rate_pct=70.0,
        success_max_high_risk_coding_offtarget_count=0,
        off_target_basis="predicted",
        off_target_method="offtarget_mismatch_v1",
        off_target_scope="genome_wide",
        success_requires_editable=True,
        success_protein_loss_pct=None,
        success_protein_loss_day=None,
        success_phenotype_effect_size=None,
        success_phenotype_effect_day=None,
        modality="crispr_cut",
        reference_build="hg38",
        target_intent="knockout",
        perturbation_target="",
        delivery_modality="rnp",
        cell_context="standard",
        experiment_scale="bulk",
        readout_level="dna_only",
        assay_type="wgs",
        output_class="exploratory",
    ),
}


PRESET_LABELS: Mapping[str, str] = {
    "knockout_validation": "Bulk knockout (validation / feasibility)",
    "functional_knockout": "Functional knockout (protein / phenotype)",
    "precise_snv_introduction": "Precise SNV (prime editing)",
    "prime_edit_insertion": "Prime edit (insertion / deletion)",
    "guide_comparison": "Compare guides (benchmarking)",
    "off_target_screening": "Off-target screening",
}


def intent_card_meta(preset_id: str) -> IntentCardMeta | None:
    key = str(preset_id or "").strip()
    preset = PRESETS.get(key)
    if preset is None:
        return None
    title = PRESET_LABELS.get(key, key)
    decision = _intent_card_decision_label(preset.primary_goal)
    evidence_required = _evidence_tiers_label(preset)
    export_posture = "Decision-grade" if str(preset.output_class or "").strip() == "decision_candidate" else "Exploratory"
    recommended_when: str | None = None
    if key == "knockout_validation":
        recommended_when = "Default for first pass feasibility checks."
    elif key == "functional_knockout":
        recommended_when = "Best when you need functional confirmation, not just edit rate."
    elif key == "off_target_screening":
        recommended_when = "Best when off-target risk is the primary decision driver."
    return IntentCardMeta(
        preset_id=key,
        title=title,
        decision=decision,
        evidence_required=evidence_required,
        export_posture=export_posture,
        recommended_when=recommended_when,
    )


__all__ = [
    "CELL_CONTEXT_OPTIONS",
    "DELIVERY_OPTIONS",
    "EXPERIMENT_SCALE_OPTIONS",
    "IntentCardMeta",
    "MODALITY_OPTIONS",
    "OFF_TARGET_BASIS_OPTIONS",
    "OFF_TARGET_SCOPE_OPTIONS",
    "OUTPUT_CLASS_OPTIONS",
    "PRIMARY_GOAL_OPTIONS",
    "PRESETS",
    "PRESET_LABELS",
    "READOUT_LEVEL_OPTIONS",
    "READOUT_OPTIONS",
    "REFERENCE_BUILD_OPTIONS",
    "TARGET_INTENT_OPTIONS",
    "ExperimentSetupSelections",
    "build_experiment_intent_spec",
    "build_experiment_spec",
    "default_setup_selections",
    "initial_rail_segment_for_goal",
    "intent_card_meta",
    "load_policy_template",
    "session_class_for_output_class",
]
