from __future__ import annotations

from typing import Any, Mapping

from helix import __version__ as helix_version


def _safe_text(value: Any) -> str:
    return str(value or "").strip()


def _short_sha256(value: str, *, chars: int = 10) -> str:
    token = _safe_text(value).lower()
    if token.startswith("sha256:"):
        token = token[len("sha256:") :]
    if not token:
        return ""
    short = token[: int(chars)]
    return f"sha256:{short}"


def _select_policy_label(
    *,
    policy_id: str,
    policy_profile: str,
    policy_hash: str,
) -> str:
    if policy_id:
        return policy_id
    if policy_profile:
        return policy_profile
    if policy_hash:
        return _short_sha256(policy_hash)
    return "unknown"


def build_provenance_header_v1(
    *,
    decision_mode: Any | None = None,
    run_summary_v2: Mapping[str, Any] | None = None,
    tool_dist: str = "helix",
    tool_version: str = helix_version,
) -> tuple[str, dict[str, Any]]:
    """
    Build a stable provenance header + compact block for export surfaces.

    Header line format (fixed order, placeholders never reorder fields):

      Helix provenance: mode=<MODE> policy=<POLICY> license=<LICENSE> issuer=<ISSUER> attestation=<ATTESTATION>

    Where missing values are rendered as `none` and policy chooses:
      policy_id → policy_profile → policy_hash (short) → unknown

    Guardrails:
    - Offline: no IO and no network.
    - Derived only from fields already present in the run summary / provenance structures.
    - Stable formatting for copy/paste and tests.
    """

    summary = run_summary_v2 if isinstance(run_summary_v2, Mapping) else {}

    mode = _safe_text(decision_mode) or _safe_text(summary.get("decision_mode")) or "filter_only"
    decision_mode_norm = "decision_grade" if mode.lower() == "decision_grade" else "filter_only"
    mode_label = "DECISION_GRADE" if decision_mode_norm == "decision_grade" else "EXPLORATORY"

    policy_id = _safe_text(summary.get("policy_id"))
    policy_hash = _safe_text(summary.get("policy_hash"))
    policy_profile = _safe_text(summary.get("policy_profile"))

    provenance = summary.get("provenance") if isinstance(summary.get("provenance"), Mapping) else {}
    license_block = provenance.get("license") if isinstance(provenance.get("license"), Mapping) else {}

    license_id = _safe_text(license_block.get("license_id"))
    issuer_key_id = _safe_text(license_block.get("issuer_key_id"))
    org_id = _safe_text(license_block.get("org"))
    edit_program_id = _safe_text(license_block.get("edit_program_id"))
    attestation_sha256 = _safe_text(license_block.get("attestation_sha256"))

    policy_label = _select_policy_label(
        policy_id=policy_id,
        policy_profile=policy_profile,
        policy_hash=policy_hash,
    )

    header_line = (
        "Helix provenance: "
        f"mode={mode_label} "
        f"policy={policy_label} "
        f"license={(license_id or 'none')} "
        f"issuer={(issuer_key_id or 'none')} "
        f"attestation={(attestation_sha256 or 'none')}"
    )

    block: dict[str, Any] = {
        "decision_mode": decision_mode_norm,
        "policy_id": (policy_id or None),
        "policy_hash": (policy_hash or None),
        "license_id": (license_id or None),
        "issuer_key_id": (issuer_key_id or None),
        "org_id": (org_id or None),
        "edit_program_id": (edit_program_id or None),
        "attestation_sha256": (attestation_sha256 or None),
        "tool_dist": _safe_text(tool_dist) or "helix",
        "tool_version": _safe_text(tool_version) or None,
    }
    return header_line, block


__all__ = ["build_provenance_header_v1"]
