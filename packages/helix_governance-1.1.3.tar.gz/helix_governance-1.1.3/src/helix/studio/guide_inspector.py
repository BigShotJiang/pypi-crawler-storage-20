from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

from PySide6 import QtGui
from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QTableView,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .ui_tokens import MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font


@dataclass
class GuideRunSummary:
    """Lightweight summary row for a guide in the inspector."""

    run_id: str
    guide_id: str
    target_locus: str
    cut_prob: float
    frameshift_prob: float
    top_outcome: str
    e_pred: float | None
    payload_ref: Any | None = None
    rank: int | None = None
    total: int | None = None
    score: float | None = None
    scenario: str | None = None


class GuideRunTableModel(QAbstractTableModel):
    """Table model backing the Guide Inspector list."""

    HEADERS = [
        "Guide",
        "Target",
        "Scenario",
        "Cut %",
        "Frameshift %",
        "Top outcome",
        "E_pred",
        "Score",
    ]

    # Heuristic weights; could be surfaced later
    W_CUT = 0.3
    W_FS = 0.5
    W_EP = 0.2

    def __init__(
        self,
        rows: Sequence[GuideRunSummary] | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._rows: list[GuideRunSummary] = list(rows or [])
        self._filtered_rows: list[int] = list(range(len(self._rows)))
        self._text_filter: str = ""
        self._min_frameshift: float | None = None
        self._min_e_pred: float | None = None
        self._scenario_filter: str | None = None

    # Qt model API ------------------------------------------------------
    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # type: ignore[override]
        return 0 if parent.isValid() else len(self._filtered_rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:  # type: ignore[override]
        return len(self.HEADERS)

    def headerData(  # type: ignore[override]
        self,
        section: int,
        orientation: Qt.Orientation,
        role: int = Qt.DisplayRole,
    ) -> Any:
        if role != Qt.DisplayRole:
            return None
        if orientation == Qt.Horizontal and 0 <= section < len(self.HEADERS):
            return self.HEADERS[section]
        return None

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole) -> Any:  # type: ignore[override]
        if not index.isValid():
            return None
        row_idx = self._filtered_rows[index.row()]
        row = self._rows[row_idx]
        col = index.column()

        if role == Qt.DisplayRole:
            if col == 0:
                return row.guide_id
            if col == 1:
                return row.target_locus
            if col == 2:
                return row.scenario or "default"
            if col == 3:
                return f"{row.cut_prob * 100.0:.1f}"
            if col == 4:
                return f"{row.frameshift_prob * 100.0:.1f}"
            if col == 5:
                return row.top_outcome
            if col == 6:
                return "" if row.e_pred is None else f"{row.e_pred:.3f}"
            if col == 7:
                return f"{self._score(row):.3f}"
        if role == Qt.TextAlignmentRole:
            if col in (3, 4, 6, 7):
                return int(Qt.AlignRight | Qt.AlignVCenter)
            return int(Qt.AlignLeft | Qt.AlignVCenter)
        if role == Qt.BackgroundRole and col == 7:
            score = self._score(row)
            # simple green-yellow gradient
            t = max(0.0, min(1.0, score))
            r = int(255 * (1 - t) + 80 * t)
            g = int(120 * (1 - t) + 255 * t)
            b = 90
            return QtGui.QColor(r, g, b, 60)
        return None

    def _score(self, row: GuideRunSummary) -> float:
        if row.score is not None:
            return float(row.score)
        ep = row.e_pred if row.e_pred is not None else 0.0
        ep_norm = max(0.0, min(1.0, ep))
        s = (
            self.W_CUT * row.cut_prob
            + self.W_FS * row.frameshift_prob
            + self.W_EP * ep_norm
        )
        return float(s)

    # Filtering ---------------------------------------------------------
    def set_rows(self, rows: Sequence[GuideRunSummary]) -> None:
        self.beginResetModel()
        self._rows = list(rows)
        self._rebuild_filter()
        self.endResetModel()

    def scenario_values(self) -> list[str]:
        scenarios: list[str] = []
        for row in self._rows:
            val = row.scenario or "default"
            if val not in scenarios:
                scenarios.append(val)
        return scenarios

    def _rebuild_filter(self) -> None:
        self._filtered_rows.clear()
        for idx, row in enumerate(self._rows):
            if self._text_filter:
                q = self._text_filter.lower()
                if q not in row.guide_id.lower() and q not in row.target_locus.lower():
                    continue
            if (
                self._min_frameshift is not None
                and row.frameshift_prob * 100.0 < self._min_frameshift
            ):
                continue
            if (
                self._min_e_pred is not None
                and row.e_pred is not None
                and row.e_pred < self._min_e_pred
            ):
                continue
            if (
                self._scenario_filter
                and (row.scenario or "default") != self._scenario_filter
            ):
                continue
            self._filtered_rows.append(idx)

    def filtered_rows(self) -> list[GuideRunSummary]:
        return [self._rows[i] for i in self._filtered_rows]

    def apply_text_filter(self, text: str) -> None:
        self.beginResetModel()
        self._text_filter = text.strip()
        self._rebuild_filter()
        self.endResetModel()

    def apply_frameshift_filter(self, min_fs_percent: float | None) -> None:
        self.beginResetModel()
        self._min_frameshift = min_fs_percent
        self._rebuild_filter()
        self.endResetModel()

    def apply_e_pred_filter(self, min_e_pred: float | None) -> None:
        self.beginResetModel()
        self._min_e_pred = min_e_pred
        self._rebuild_filter()
        self.endResetModel()

    def apply_scenario_filter(self, scenario: str | None) -> None:
        self.beginResetModel()
        self._scenario_filter = scenario
        self._rebuild_filter()
        self.endResetModel()

    # Helper ------------------------------------------------------------
    def summary_at(self, row: int) -> GuideRunSummary | None:
        if row < 0 or row >= len(self._filtered_rows):
            return None
        return self._rows[self._filtered_rows[row]]


class GuideInspectorWidget(QWidget):
    """Guide table + filters + exports.

    Note: visualizations (Realtime 3D, 2.5D workflow, Edit DAG) live in the main
    center tabs. This widget focuses on selection and metadata so the right
    sidebar stays lightweight.
    """

    guideSelected = Signal(GuideRunSummary, int, int)
    compareGuidesRequested = Signal(GuideRunSummary, GuideRunSummary)
    exportAllRequested = Signal(str, list)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._model = GuideRunTableModel()
        self._decision_mode: str = "filter_only"

        root = QVBoxLayout(self)
        root.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        root.setSpacing(SPACING_MEDIUM)

        header = QLabel("Guides in this session", self)
        header.setStyleSheet("font-weight: 600;")
        header.setProperty("helix-section", True)
        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)
        header_row.setSpacing(SPACING_SMALL)
        header_row.addWidget(header)
        help_btn = QToolButton(self)
        help_btn.setText("?")
        help_btn.setFixedSize(22, 22)
        help_btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        help_btn.clicked.connect(
            lambda: QMessageBox.information(
                self,
                "Guides",
                "This tab shows guides for the current session; select one to view "
                "metrics and off-target info.",
            )
        )
        header_row.addStretch(1)
        header_row.addWidget(help_btn)
        root.addLayout(header_row)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(SPACING_SMALL)
        self.search_edit = QLineEdit(self)
        self.search_edit.setPlaceholderText("Filter guides or loci")
        self.search_edit.textChanged.connect(self._on_text_filter_changed)

        self.fs_filter = QComboBox(self)
        self.fs_filter.addItem("Frameshift >= 0%", None)
        self.fs_filter.addItem("Frameshift >= 10%", 10.0)
        self.fs_filter.addItem("Frameshift >= 25%", 25.0)
        self.fs_filter.addItem("Frameshift >= 50%", 50.0)
        self.fs_filter.currentIndexChanged.connect(self._on_fs_filter_changed)

        self.e_pred_filter = QComboBox(self)
        self.e_pred_filter.addItem("E_pred any", None)
        self.e_pred_filter.addItem("E_pred >= 0.5", 0.5)
        self.e_pred_filter.addItem("E_pred >= 0.7", 0.7)
        self.e_pred_filter.addItem("E_pred >= 0.9", 0.9)
        self.e_pred_filter.currentIndexChanged.connect(self._on_e_pred_filter_changed)

        self.scenario_filter = QComboBox(self)
        self.scenario_filter.addItem("Scenario: all", None)
        self.scenario_filter.currentIndexChanged.connect(self._on_scenario_filter_changed)

        filter_row.addWidget(self.search_edit, stretch=2)
        filter_row.addWidget(self.fs_filter, stretch=1)
        filter_row.addWidget(self.e_pred_filter, stretch=1)
        filter_row.addWidget(self.scenario_filter, stretch=1)
        root.addLayout(filter_row)

        # Detail card
        self._detail_card = QFrame(self)
        self._detail_card.setObjectName("GuideDetailCard")
        detail_layout = QVBoxLayout(self._detail_card)
        detail_layout.setContentsMargins(8, 8, 8, 8)
        detail_layout.setSpacing(6)
        self._detail_title = QLabel("Select a guide to view details", self._detail_card)
        self._detail_title.setStyleSheet("font-weight: 600; color: palette(window-text);")
        detail_layout.addWidget(self._detail_title)
        self._detail_seq = QLabel("", self._detail_card)
        self._detail_seq.setStyleSheet(
            "font-family: Consolas, monospace; color: palette(mid);"
        )
        self._detail_seq.setWordWrap(True)
        detail_layout.addWidget(self._detail_seq)
        self._detail_chip_row = QHBoxLayout()
        self._detail_chip_row.setSpacing(6)
        self._detail_chip_row.setContentsMargins(0, 0, 0, 0)
        self._detail_chips: list[QLabel] = []
        detail_layout.addLayout(self._detail_chip_row)
        root.addWidget(self._detail_card)

        export_row = QHBoxLayout()
        export_row.setSpacing(SPACING_SMALL)
        self.export_all_btn = QToolButton(self)
        self.export_all_btn.setText("Export all")
        self.export_all_btn.setToolTip("Export HTML reports for all visible guides")
        self.export_all_btn.clicked.connect(self._on_export_all_clicked)
        export_row.addWidget(self.export_all_btn)

        self.compare_btn = QToolButton(self)
        self.compare_btn.setText("Compare selected")
        self.compare_btn.setToolTip("Select exactly two guides to compare")
        self.compare_btn.clicked.connect(self._on_compare_clicked)
        export_row.addWidget(self.compare_btn)
        export_row.addStretch(1)
        root.addLayout(export_row)

        self.table = QTableView(self)
        self.table.setObjectName("GuideTable")
        self.table.setModel(self._model)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.ExtendedSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.setSortingEnabled(True)
        self.table.sortByColumn(6, Qt.DescendingOrder)
        self.table.doubleClicked.connect(self._on_row_activated)
        self.table.selectionModel().currentRowChanged.connect(self._on_current_row_changed)
        root.addWidget(self.table, stretch=1)

        hint = QLabel(
            "Arrow keys select guide. Compare/export via buttons. Visuals are in the "
            "center tabs (Realtime / Workflow / Edit DAG).",
            self,
        )
        hint.setStyleSheet("color: palette(mid); font-size: 11px;")
        root.addWidget(hint)

    # Public API --------------------------------------------------------
    def set_guide_rows(self, rows: Sequence[GuideRunSummary]) -> None:
        self._model.set_rows(rows)
        self._apply_decision_mode_gate(rows)
        if self._model.rowCount() > 0:
            self.table.selectRow(0)
            self._emit_selection(0)

    def _apply_decision_mode_gate(self, rows: Sequence[GuideRunSummary]) -> None:
        mode = "decision_grade"
        for row in rows:
            payload = getattr(row, "payload_ref", None)
            meta = None
            if payload is not None and hasattr(payload, "metadata"):
                try:
                    meta = payload.metadata
                except Exception:
                    meta = None
            if meta is None and isinstance(payload, dict):
                state = payload.get("state", payload) if isinstance(payload.get("state"), dict) else payload
                cfg = state.get("config", {}) if isinstance(state.get("config"), dict) else {}
                meta = cfg.get("metadata") if isinstance(cfg.get("metadata"), dict) else None
            summary = meta.get("run_summary") if isinstance(meta, dict) else None
            dm = str(summary.get("decision_mode") or "").strip().lower() if isinstance(summary, dict) else ""
            if dm != "decision_grade":
                mode = "filter_only"
                break
        self._decision_mode = mode
        filter_only = mode == "filter_only"
        try:
            self.table.setSortingEnabled(not filter_only)
        except Exception:
            pass
        try:
            # Hide the Score column in filter-only mode.
            self.table.setColumnHidden(7, filter_only)
        except Exception:
            pass
        try:
            self.export_all_btn.setEnabled(not filter_only)
            self.export_all_btn.setToolTip(
                "Disabled in filter-only mode (ranking exports are not decision safe)." if filter_only else "Export HTML reports for all visible guides"
            )
        except Exception:
            pass
        try:
            # Comparing guides is inherently a ranking/selection surface; suppress it in filter-only mode.
            self.compare_btn.setEnabled(not filter_only)
            self.compare_btn.setVisible(not filter_only)
            self.compare_btn.setToolTip(
                "Disabled in filter-only mode (comparison implies ranking/selection)."
                if filter_only
                else "Select exactly two guides to compare"
            )
        except Exception:
            pass

    # Filters -----------------------------------------------------------
    def _on_text_filter_changed(self, text: str) -> None:
        self._model.apply_text_filter(text)

    def _on_fs_filter_changed(self, idx: int) -> None:
        val = self.fs_filter.itemData(idx)
        self._model.apply_frameshift_filter(val if isinstance(val, float) else None)

    def _on_e_pred_filter_changed(self, idx: int) -> None:
        val = self.e_pred_filter.itemData(idx)
        self._model.apply_e_pred_filter(val if isinstance(val, float) else None)
        self._rebuild_scenario_filter_choices()

    def _on_scenario_filter_changed(self, idx: int) -> None:
        val = self.scenario_filter.itemData(idx)
        self._model.apply_scenario_filter(val if isinstance(val, str) else None)

    def _rebuild_scenario_filter_choices(self) -> None:
        scenarios = self._model.scenario_values()
        current = self.scenario_filter.currentData()
        self.scenario_filter.blockSignals(True)
        self.scenario_filter.clear()
        self.scenario_filter.addItem("Scenario: all", None)
        for sc in sorted(scenarios):
            self.scenario_filter.addItem(sc, sc)
        # restore selection if possible
        if current is not None:
            idx = self.scenario_filter.findData(current)
            if idx >= 0:
                self.scenario_filter.setCurrentIndex(idx)
        self.scenario_filter.blockSignals(False)

    # Selection ---------------------------------------------------------
    def _on_current_row_changed(self, current: QModelIndex, _prev: QModelIndex) -> None:
        if current.isValid():
            self._emit_selection(current.row())

    def _on_row_activated(self, index: QModelIndex) -> None:
        if index.isValid():
            self._emit_selection(index.row())

    def _emit_selection(self, row: int) -> None:
        summary = self._model.summary_at(row)
        if summary is None:
            return
        summary.rank = row + 1
        summary.total = self._model.rowCount()
        self.guideSelected.emit(summary, summary.rank, summary.total)
        self._update_detail_card(summary)

    def _update_detail_card(self, summary: GuideRunSummary) -> None:
        self._detail_title.setText(summary.guide_id)
        seq = ""
        payload = getattr(summary, "payload_ref", None)
        if payload is not None and hasattr(payload, "sequence"):
            try:
                seq = payload.sequence or ""
            except Exception:
                seq = ""
        if not seq and hasattr(payload, "site"):
            try:
                seq = getattr(payload, "site", None).get("sequence", "")
            except Exception:
                seq = ""
        self._detail_seq.setText(seq if seq else summary.target_locus)

        for chip in self._detail_chips:
            try:
                chip.hide()
            except Exception:
                pass
            chip.setParent(None)
            chip.deleteLater()
        self._detail_chips.clear()

        def add_chip(text: str) -> None:
            chip = QLabel(text, self._detail_card)
            chip.setObjectName("RunChip")
            self._detail_chips.append(chip)
            self._detail_chip_row.addWidget(chip)

        add_chip(f"Cut: {summary.cut_prob*100:.1f}%")
        add_chip(f"Frameshift: {summary.frameshift_prob*100:.1f}%")
        if summary.top_outcome:
            add_chip(f"Top: {summary.top_outcome}")
        if summary.target_locus:
            add_chip(summary.target_locus)
        if seq:
            gc = (seq.count("G") + seq.count("C")) / max(1, len(seq)) * 100.0
            add_chip(f"GC: {gc:.1f}%")
        # Prime-specific metrics if available
        run = getattr(summary, "payload_ref", None)
        if run is not None:
            kind = (
                getattr(run, "edit_type", "").lower()
                if hasattr(run, "edit_type")
                else ""
            )
            if not kind and hasattr(run, "run_kind"):
                kind = str(run.run_kind).lower()
            if "prime" in kind:
                outcomes = getattr(run, "outcomes", []) or []
                perfect = 0.0
                indel_adj = 0.0

                def _oget(obj, key, default=None):
                    if hasattr(obj, key):
                        try:
                            return getattr(obj, key)
                        except Exception:
                            pass
                    try:
                        return obj.get(key, default)
                    except Exception:
                        return default

                for oc in outcomes:
                    try:
                        p = float(_oget(oc, "probability", 0.0))
                    except Exception:
                        p = 0.0
                    label = str(_oget(oc, "label", "")).lower()
                    frameshift = bool(_oget(oc, "frameshift", False))
                    delta_bp = _oget(oc, "delta_bp", 0)
                    if "intended" in label:
                        if not frameshift and delta_bp == 0:
                            perfect += p
                        else:
                            indel_adj += p
                rtt_util = perfect + indel_adj
                add_chip(f"Perfect prime: {perfect*100:.1f}%")
                add_chip(f"Indel-adj: {indel_adj*100:.1f}%")
                add_chip(f"RTT util: {rtt_util*100:.1f}%")

    def _on_export_all_clicked(self) -> None:
        out_dir = QFileDialog.getExistingDirectory(
            self,
            "Choose export directory for guide reports",
            "",
        )
        if not out_dir:
            return
        rows = self._model.filtered_rows()
        if not rows:
            return
        self.exportAllRequested.emit(out_dir, rows)

    def _on_compare_clicked(self) -> None:
        rows = sorted({idx.row() for idx in self.table.selectionModel().selectedRows()})
        if len(rows) != 2:
            return
        a = self._model.summary_at(rows[0])
        b = self._model.summary_at(rows[1])
        if a is None or b is None:
            return
        self.compareGuidesRequested.emit(a, b)
