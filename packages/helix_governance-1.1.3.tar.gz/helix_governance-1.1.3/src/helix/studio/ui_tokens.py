from __future__ import annotations

import os

from PySide6.QtGui import QFont, QScreen
from PySide6.QtWidgets import QApplication


_UI_SCALE_BASE_W = 1440
_UI_SCALE_BASE_H = 900
_UI_SCALE_MIN = 0.85
_UI_SCALE_MAX = 1.15


def _parse_env_float(key: str) -> float | None:
    raw = os.getenv(key, "").strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def ui_scale_factor(*, screen: QScreen | None = None) -> float:
    override = _parse_env_float("HELIX_UI_SCALE")
    if override is not None and override > 0:
        return override
    platform_env = os.getenv("QT_QPA_PLATFORM", "").strip().lower()
    headless_env = os.getenv("HELIX_STUDIO_HEADLESS", "0") == "1"
    if platform_env == "offscreen" or headless_env:
        return 1.0

    # In tests, QT_QPA_PLATFORM is often set before QApplication is created and then
    # removed via monkeypatch teardown. Use the active Qt platform name to keep
    # scaling stable (offscreen/minimal should never scale down below 1.0).
    try:
        platform_name = str(QApplication.platformName() or "").lower()
    except Exception:
        platform_name = ""
    if platform_name in {"offscreen", "minimal"}:
        return 1.0

    min_scale = _parse_env_float("HELIX_UI_SCALE_MIN")
    max_scale = _parse_env_float("HELIX_UI_SCALE_MAX")
    if min_scale is None:
        min_scale = _UI_SCALE_MIN
    if max_scale is None:
        max_scale = _UI_SCALE_MAX
    if max_scale < min_scale:
        min_scale, max_scale = max_scale, min_scale

    app = QApplication.instance()
    if app is None and screen is None:
        return 1.0
    if screen is None and app is not None:
        screen = app.primaryScreen()
    if screen is None:
        return 1.0
    geom = screen.availableGeometry()
    width = max(1, int(geom.width()))
    height = max(1, int(geom.height()))
    base_area = float(_UI_SCALE_BASE_W * _UI_SCALE_BASE_H)
    area = float(width * height)
    scale = (area / base_area) ** 0.5
    if scale < min_scale:
        return float(min_scale)
    if scale > max_scale:
        return float(max_scale)
    return float(scale)


def scaled_px(value: float, *, screen: QScreen | None = None) -> int:
    scale = ui_scale_factor(screen=screen)
    return max(1, int(round(float(value) * scale)))


def _scaled_point_size(base: float) -> float:
    return base * ui_scale_factor()


def base_font() -> QFont:
    """Primary Studio font; lightly screen-size aware."""
    font = QFont()
    font.setPointSizeF(_scaled_point_size(11.0))
    return font


def monospace_font() -> QFont:
    font = QFont("Consolas")
    font.setPointSizeF(_scaled_point_size(10.0))
    return font

# --- Helix Theme v2 tokens (dark biotech GPU vibe) ---
# Surfaces
HX_BG_0 = "#0B0F14"
HX_BG_1 = "#111721"
HX_BG_2 = "#18212B"
HX_BG_3 = "#202A34"
HX_BORDER = "#2A3541"

# Accents
HX_ACCENT = "#3AE8C8"
HX_ACCENT_DIM = "#2BC0A4"
HX_IRIS = "#7D5CFF"
HX_IRIS_DIM = "#5A3FD4"

# Outcome categories
HX_OUTCOME_INTENDED = "#C889E6"
HX_OUTCOME_NOCUT = "#66B7FF"
HX_OUTCOME_FRAMESHIFT = "#DDA76A"
HX_OUTCOME_HOMOLOGY = "#E18C5C"

# Status
HX_SUCCESS = "#3ECF8E"
HX_WARN = "#EBCB8B"
HX_DANGER = "#E66A6A"
HX_INFO = "#6FA4FF"

# Typography (px sizes)
HX_FONT_XS = 11
HX_FONT_SM = 13
HX_FONT_MD = 14
HX_FONT_LG = 16
HX_FONT_XL = 20
HX_FONT_2XL = 24

# Radii
HX_RADIUS_SM = 3
HX_RADIUS_MD = 5
HX_RADIUS_LG = 8
HX_RADIUS_PILL = 999

# Spacing (px)
HX_SPACE_0 = 0
HX_SPACE_1 = 4
HX_SPACE_2 = 8
HX_SPACE_3 = 12
HX_SPACE_4 = 16
HX_SPACE_5 = 20
HX_SPACE_6 = 24
HX_SPACE_8 = 32
HX_SPACE_10 = 40

# Shadows
HX_SHADOW_1 = "0 1px 2px rgba(0,0,0,0.35)"
HX_SHADOW_2 = "0 3px 6px rgba(0,0,0,0.28)"
HX_SHADOW_3 = "0 4px 12px rgba(0,0,0,0.22)"
HX_INSET_1 = "inset 0 0 4px rgba(0,0,0,0.35)"

# Legacy tokens retained for compatibility (mapped onto v2 palette)
SURFACE_BASE = HX_BG_0
SURFACE_BASE_RIGHT = HX_BG_1
SURFACE_PANEL = HX_BG_2
ACCENT_TEAL = HX_ACCENT
ACCENT_TEAL_SOFT = HX_ACCENT_DIM
ACCENT_TEAL_TEXT = "#b8fff2"
ACCENT_PURPLE = HX_IRIS
ACCENT_PURPLE_SOFT = HX_IRIS_DIM
BORDER_SOFT = "rgba(42,53,65,0.9)"
BORDER_CARD = "rgba(42,53,65,1.0)"
TEXT_PRIMARY = "#e7edf7"
TEXT_SECONDARY = "rgba(203,213,225,0.9)"
TEXT_MICRO = "rgba(148,163,184,0.85)"
SUCCESS = HX_SUCCESS
CAUTION = HX_WARN

# Radii (legacy)
RADIUS_PANEL = 18
RADIUS_CARD = 14
RADIUS_BUTTON = 8
RADIUS_CHIP = 999

# Spacing (legacy rhythm)
SPACING_MICRO = 4
SPACING_SMALL = 8
SPACING_LINE = 14
SPACING_CARD_GAP = 18
SPACING_PANEL_PADDING = 24
SPACING_HERO_PADDING = 28
SPACING_SECTION_GAP = 32

# Legacy margins/spacing kept for gradual migration
MARGIN_WINDOW = 12
MARGIN_PANEL = 8

# Keep legacy names aligned to the new scale
SPACING_MEDIUM = 8
SPACING_LARGE = 12

# New spacing rhythm (use going forward)
GAP_XS = 4
GAP_SM = 8
GAP_MD = 12
GAP_LG = 16
GAP_XL = 24
