from __future__ import annotations

import os
from collections.abc import Mapping
from copy import deepcopy
from typing import TYPE_CHECKING, Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QLabel, QSizePolicy, QSplitter, QTabWidget, QVBoxLayout, QWidget

from helix.bioinformatics import reverse_complement
from helix.studio.outcomes.model import (
    compute_outcomes_for_current_plan,
    outcome_report_to_dict,
)

if TYPE_CHECKING:  # pragma: no cover
    from helix.gui.modern.qt import HelixModernWidget

from .gl_panel import _workflow_from_serializable
from .outcome_explorer import OutcomeExplorerWidget, build_outcome_explorer_data
from .pcr_workflow import summarize_pcr_workflow_meta
from .session import ExperimentState, RunKind, SessionModel
from .run_artifact import artifact_is_valid, artifact_root_causes, artifact_decision_mode_eligible
from .workflow_stats import summarize_workflow_meta


class Workflow2p5DPanel(QWidget):
    outcomeSelected = Signal(object)

    def __init__(
        self,
        session: SessionModel,
        parent: QWidget | None = None,
        *,
        enable_viewer: bool = True,
    ) -> None:
        super().__init__(parent)
        self._session = session
        # Best-effort ModernGL workflow canvas (optional).
        self._viewer: HelixModernWidget | None = None
        self._viewer_container: QWidget | None = None
        self._viewer_enabled = enable_viewer
        self._pending_view_state: Mapping[str, Any] | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        self._status = QLabel("Workflow will appear here after simulation.", self)
        self._status.setWordWrap(True)
        layout.addWidget(self._status)

        # Splitter lets users reallocate space between the GL canvas and explorer.
        self._splitter = QSplitter(Qt.Vertical, self)
        self._splitter.setChildrenCollapsible(False)
        self._splitter.setHandleWidth(10)
        layout.addWidget(self._splitter, stretch=1)

        if self._viewer_enabled:
            self._init_viewer()
            if self._viewer_container is not None:
                self._splitter.addWidget(self._viewer_container)
                self._splitter.setStretchFactor(0, 1)

        # Outcome Explorer replaces the previous text/GL summary.
        self._explorer = OutcomeExplorerWidget(self)
        self._splitter.addWidget(self._explorer)
        explorer_index = self._splitter.indexOf(self._explorer)
        if explorer_index >= 0:
            self._splitter.setStretchFactor(explorer_index, 3)
        if self._viewer_container is not None:
            # Bias toward the explorer so the canvas no longer swallows the view.
            self._splitter.setSizes([320, 680])
        self._explorer.hide()
        self._explorer.outcomeSelected.connect(self.outcomeSelected.emit)

        self._session.stateChanged.connect(self._on_state_changed)
        self._on_state_changed(self._session.state)

        # Fit-to-locus: workflow camera centers on cut + guide context.
        self._fit_locus_undo: dict[str, Any] | None = None
        try:
            from PySide6.QtGui import QKeySequence, QShortcut

            self._fit_locus_shortcut = QShortcut(QKeySequence("Ctrl+L"), self)
            self._fit_locus_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._fit_locus_shortcut.activated.connect(self._fit_to_locus)

            self._undo_fit_locus_shortcut = QShortcut(QKeySequence("Ctrl+Shift+L"), self)
            self._undo_fit_locus_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._undo_fit_locus_shortcut.activated.connect(self._undo_fit_to_locus)
        except Exception:
            self._fit_locus_shortcut = None
            self._undo_fit_locus_shortcut = None

    def _fit_to_locus(self) -> None:
        viewer = getattr(self, "_viewer", None)
        if viewer is None:
            return
        try:
            if getattr(viewer, "_drag_mode", None) is not None:
                return
        except Exception:
            pass
        try:
            self._fit_locus_undo = dict(viewer.get_view_state())  # type: ignore[attr-defined]
        except Exception:
            self._fit_locus_undo = None
        try:
            viewer.fit_to_locus()  # type: ignore[attr-defined]
        except Exception:
            return
        try:
            if hasattr(viewer, "pulse_locus"):
                viewer.pulse_locus("fit")  # type: ignore[attr-defined]
        except Exception:
            pass

    def _undo_fit_to_locus(self) -> None:
        viewer = getattr(self, "_viewer", None)
        state = getattr(self, "_fit_locus_undo", None)
        if viewer is None or not isinstance(state, Mapping):
            return
        try:
            if getattr(viewer, "_drag_mode", None) is not None:
                return
        except Exception:
            pass
        self._fit_locus_undo = None
        try:
            viewer.apply_view_state(state)  # type: ignore[attr-defined]
        except Exception:
            return
        try:
            if hasattr(viewer, "pulse_locus"):
                viewer.pulse_locus("undo")  # type: ignore[attr-defined]
        except Exception:
            pass

    def get_view_state(self) -> dict[str, Any] | None:
        """Return persisted viewer state if ModernGL workflow canvas is enabled."""
        viewer = getattr(self, "_viewer", None)
        if viewer is None:
            return None
        try:
            return dict(viewer.get_view_state())  # type: ignore[attr-defined]
        except Exception:
            return None

    def apply_view_state(self, state: Mapping[str, Any] | None) -> None:
        """Best-effort restore of persisted viewer state."""
        if not isinstance(state, Mapping):
            return
        self._pending_view_state = dict(state)
        viewer = getattr(self, "_viewer", None)
        if viewer is None:
            return
        try:
            viewer.apply_view_state(self._pending_view_state)  # type: ignore[attr-defined]
            self._pending_view_state = None
        except Exception:
            return

    def set_render_active(self, active: bool) -> None:
        """Pause/resume ModernGL workflow canvas when the tab is inactive."""
        viewer = getattr(self, "_viewer", None)
        if viewer is None:
            return
        try:
            viewer.set_render_active(active)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _is_current_tab_selected(self) -> bool:
        parent = self.parent()
        while parent is not None:
            if isinstance(parent, QTabWidget):
                try:
                    return parent.currentWidget() is self
                except Exception:
                    return False
            try:
                parent = parent.parent()
            except Exception:
                break
        return False

    def showEvent(self, event) -> None:  # type: ignore[override]
        try:
            self.set_render_active(self._is_current_tab_selected())
        except Exception:
            pass
        super().showEvent(event)

    def hideEvent(self, event) -> None:  # type: ignore[override]
        try:
            self.set_render_active(False)
        except Exception:
            pass
        super().hideEvent(event)

    def _init_viewer(self) -> None:
        """Best-effort 2.5D workflow viewer (ModernGL) with graceful fallback."""
        try:
            from helix.gui.modern.qt import HelixModernWidget
        except Exception:
            self._viewer_enabled = False
            return

        # Avoid viewer creation in headless/offscreen mode unless explicitly requested.
        if os.environ.get("QT_QPA_PLATFORM", "").lower() == "offscreen":
            self._viewer_enabled = False
            return

        try:
            self._viewer = HelixModernWidget(self)
            # QWidget-composited GL viewport so normal Qt stacking/clipping works.
            self._viewer_container = self._viewer
            self._viewer_container.setObjectName("Workflow2p5DViewport")
            self._viewer_container.setMinimumHeight(220)
            self._viewer_container.setSizePolicy(
                QSizePolicy.Expanding,
                QSizePolicy.Fixed,
            )
            self._viewer_container.hide()
            if self._pending_view_state is not None:
                try:
                    self._viewer.apply_view_state(self._pending_view_state)  # type: ignore[attr-defined]
                    self._pending_view_state = None
                except Exception:
                    pass
        except Exception:
            self._viewer = None
            self._viewer_container = None
            self._viewer_enabled = False
            return

    def raise_surfaces(self) -> None:
        """Keep the embedded workflow canvas above parent widgets."""
        if self._viewer_container is not None:
            try:
                self._viewer_container.raise_()
            except Exception:
                pass

    def _on_state_changed(self, state: ExperimentState) -> None:
        config = state.config if isinstance(state.config, Mapping) else {}
        workflow_meta = self._workflow_meta_from_state(state, config)

        if state.run_kind is RunKind.PCR and state.pcr_result is not None:
            if (
                isinstance(workflow_meta, Mapping)
                and workflow_meta.get("kind") == "PCR"
            ):
                lines = summarize_pcr_workflow_meta(workflow_meta)
            else:
                lines = [
                    f"Amplicon length: {state.pcr_result.amplicon_length} bp",
                    f"Final mass: {state.pcr_result.final_amplicon_mass_ng:.2f} ng",
                    f"Final mutation rate: {state.pcr_result.final_mutation_rate:.4f}",
                ]
            self._set_viewer_buffers(None)
            self._status.setText("\n".join(lines) if lines else "PCR workflow ready.")
            self._explorer.hide()
            return

        if not isinstance(workflow_meta, Mapping):
            self._set_viewer_buffers(None)
            self._status.setText("Workflow will appear here after simulation.")
            self._explorer.hide()
            return

        sequence = self._sequence_from_state(state)
        buffers = self._extract_workflow_buffers(workflow_meta)
        if buffers is not None and sequence:
            try:
                buffers = dict(buffers)
                buffers["sequence"] = sequence
            except Exception:
                pass
        self._set_viewer_buffers(buffers)
        guide = config.get("guide") or {}
        payload_sim = (
            config.get("sim_payload", {})
            if isinstance(config, Mapping)
            else {}
        )
        outcomes = state.outcomes or payload_sim.get("outcomes") or []
        physics_run = (
            payload_sim.get("physics_score")
            if isinstance(payload_sim, Mapping)
            else None
        )

        try:
            if sequence and outcomes:
                artifact = None
                try:
                    artifact = self._session.ensure_run_artifact()
                except Exception:
                    artifact = None
                valid = artifact_is_valid(artifact) if isinstance(artifact, Mapping) else False
                decision_ok = artifact_decision_mode_eligible(artifact) if isinstance(artifact, Mapping) else False
                reasons = artifact_root_causes(artifact) if isinstance(artifact, Mapping) else []
                outcomes_view = outcomes
                data = build_outcome_explorer_data(
                    sequence,
                    guide,
                    outcomes_view,
                    run_id=state.run_id,
                    physics_run=physics_run,
                )
                try:
                    self._explorer.set_run_model(None)
                except Exception:
                    pass
                try:
                    self._explorer.set_decision_mode_gate(
                        valid=valid,
                        decision_mode_eligible=decision_ok,
                        reasons=reasons,
                    )
                except Exception:
                    pass
                self._explorer.set_data(data)
                try:
                    self._explorer.set_perturbation_provider(self._recompute_outcomes)
                except Exception:
                    pass
                self._explorer.set_rank(1, 1)
                self._explorer.show()
                self._status.setText("Outcome Explorer ready.")
            else:
                self._explorer.hide()
                self._status.setText(
                    "Workflow metadata present but no outcomes available."
                )
        except Exception:
            self._explorer.hide()
            self._status.setText("Failed to build Outcome Explorer from this run.")

        sim_kind = config.get("sim_type", "unknown")
        summary = summarize_workflow_meta(workflow_meta)
        if summary:
            self._status.setText(
                f"{sim_kind} workflow ready.\n" + "\n".join(summary)
            )
        else:
            self._status.setText(f"{sim_kind} workflow ready.")

    def _workflow_meta_from_state(
        self,
        state: ExperimentState,
        config: Mapping[str, Any],
    ) -> Mapping[str, Any] | None:
        workflow_meta = config.get("workflow_view")
        if isinstance(workflow_meta, Mapping):
            return workflow_meta
        spec_payload = state.viz_spec_payload
        if isinstance(spec_payload, Mapping):
            metadata = spec_payload.get("metadata")
            if isinstance(metadata, Mapping):
                workflow_meta = metadata.get("workflow_view")
                if isinstance(workflow_meta, Mapping):
                    return workflow_meta
        return None

    def _extract_workflow_buffers(
        self,
        workflow_meta: Mapping[str, Any],
    ) -> dict[str, Any] | None:
        if workflow_meta.get("kind") == "PCR":
            return None
        try:
            buffers = _workflow_from_serializable(workflow_meta)
            return buffers if buffers else None
        except Exception:
            return None

    def _sequence_from_state(self, state: ExperimentState) -> str:
        seq = ""
        config = state.config if isinstance(state.config, Mapping) else {}
        sim_payload = config.get("sim_payload") if isinstance(config, Mapping) else {}
        if isinstance(sim_payload, Mapping):
            seq = (
                sim_payload.get("site", {}).get("sequence")
                or sim_payload.get("sequence")
                or seq
            )
        if not seq and isinstance(state.viz_spec_payload, Mapping):
            seq = state.viz_spec_payload.get("sequence", "")
        return seq

    # ------------------------------------------------------------------
    # Perturbation / recompute provider for OutcomeExplorer
    # ------------------------------------------------------------------
    def _recompute_outcomes(self, delta_bp: int, *, strand_flip: bool = False, target_id: str | None = None):
        """
        Recompute outcomes via the real engine for ±1 bp cut shift and optional strand flip.
        Does not mutate the live session; builds patched edit_plan/reference_context on the fly.
        """
        state = self._session.state
        config = deepcopy(state.config) if isinstance(state.config, Mapping) else {}

        # Clone or synthesize an edit plan with at least one target.
        plan = deepcopy(getattr(state, "edit_plan", None)) if isinstance(getattr(state, "edit_plan", None), Mapping) else {}
        guide_cfg = config.get("guide") if isinstance(config.get("guide"), Mapping) else {}

        targets = plan.get("targets") if isinstance(plan, Mapping) else None
        if not isinstance(targets, list) or not targets:
            gseq = str(guide_cfg.get("sequence") or "")
            pam = guide_cfg.get("pam")
            strand = str(guide_cfg.get("strand") or "+")
            start = int(guide_cfg.get("start", 0) or 0)
            end = int(guide_cfg.get("end", start + (len(gseq) or 20)) or 0)
            cut_index = end - 3 if strand == "+" else start + 3
            targets = [
                {
                    "targetId": str(guide_cfg.get("id") or "t0"),
                    "label": str(guide_cfg.get("name") or guide_cfg.get("id") or "guide"),
                    "strand": strand,
                    "cutIndex": cut_index,
                    "gRNA": {"sequence": gseq, "pam": pam},
                }
            ]
            plan = {"schema": "helix_edit_plan_v1", "mode": "single", "targets": targets}

        # Reference sequence (window)
        sequence = self._sequence_from_state(state)
        if not sequence:
            seq_payload = state.viz_spec_payload if isinstance(state.viz_spec_payload, Mapping) else {}
            sequence = seq_payload.get("sequence", "")
        if not sequence:
            raise NotImplementedError("No reference sequence available for recompute.")
        seq_len = len(sequence)

        # Choose target to perturb
        target = None
        if target_id:
            for t in targets:
                tid = t.get("targetId") or t.get("label") or t.get("id")
                if str(tid) == str(target_id):
                    target = deepcopy(t)
                    break
        if target is None:
            target = deepcopy(targets[0])

        cut_idx = int(target.get("cutIndex", 0) or 0)
        cut_idx = max(0, min(seq_len - 1, cut_idx + int(delta_bp)))
        strand = str(target.get("strand") or "+")
        grna = target.get("gRNA") if isinstance(target.get("gRNA"), Mapping) else {}
        gseq = str(grna.get("sequence") or guide_cfg.get("sequence") or "")

        # Update only the selected target for cut shift
        updated_targets: list[dict] = []
        for t in targets:
            tid = t.get("targetId") or t.get("label") or t.get("id")
            if str(tid) != str(target.get("targetId") or target.get("label") or target.get("id")):
                updated_targets.append(deepcopy(t))
                continue
            t = deepcopy(target)
            t["strand"] = strand
            t["cutIndex"] = cut_idx
            t["gRNA"] = dict(t.get("gRNA") or {})
            t["gRNA"]["sequence"] = gseq
            updated_targets.append(t)

        if strand_flip:
            sequence = reverse_complement(sequence)
            seq_len = len(sequence)
            flipped_targets: list[dict] = []
            for t in updated_targets:
                t = deepcopy(t)
                t_strand = "-" if str(t.get("strand") or "+") == "+" else "+"
                t_cut = int(t.get("cutIndex", 0) or 0)
                t_cut = max(0, min(seq_len - 1, seq_len - 1 - t_cut))
                t_seq = str(t.get("gRNA", {}).get("sequence") or "")
                if t_seq:
                    t_seq = reverse_complement(t_seq)
                t["strand"] = t_strand
                t["cutIndex"] = t_cut
                t["gRNA"] = dict(t.get("gRNA") or {})
                t["gRNA"]["sequence"] = t_seq
                g_len_t = len(t_seq) if t_seq else 20
                if t_strand == "+":
                    end_t = t_cut + 3
                    start_t = end_t - g_len_t
                else:
                    start_t = t_cut - 3
                    end_t = start_t + g_len_t
                t["start"] = start_t
                t["end"] = end_t
                flipped_targets.append(t)
            updated_targets = flipped_targets

        plan = dict(plan)
        plan["targets"] = updated_targets

        # Reference context
        ref_ctx = {
            "contig": "chrGui",
            "windowStart": 0,
            "windowEnd": len(sequence),
            "sequence": sequence,
        }

        report = compute_outcomes_for_current_plan(
            self._session,
            edit_plan=plan,
            reference_context=ref_ctx,
        )
        payload = outcome_report_to_dict(report)
        outcomes = payload.get("alleleSpectrum") or payload.get("allele_spectrum") or []

        # Use the perturbed target (selected) for explorer guide fields.
        selected = None
        for t in plan["targets"]:
            tid = t.get("targetId") or t.get("label") or t.get("id")
            if str(tid) == str(target_id or target.get("targetId") or target.get("label") or target.get("id")):
                selected = t
                break
        if selected is None:
            selected = plan["targets"][0]
        gseq = str(selected.get("gRNA", {}).get("sequence") or "")
        strand = str(selected.get("strand") or "+")
        cut_idx = int(selected.get("cutIndex", 0) or 0)
        g_len = len(gseq) if gseq else 20
        if strand == "+":
            end = cut_idx + 3
            start = end - g_len
        else:
            start = cut_idx - 3
            end = start + g_len
        guide_for_explorer = {
            "id": selected.get("targetId") or guide_cfg.get("id") or "guide",
            "name": selected.get("label") or guide_cfg.get("name") or "guide",
            "sequence": gseq,
            "pam": selected.get("gRNA", {}).get("pam") if isinstance(selected.get("gRNA"), Mapping) else None,
            "start": start,
            "end": end,
            "strand": strand,
            "intent": getattr(state.experiment_spec, "intent", None) if hasattr(state, "experiment_spec") else None,
        }

        data = build_outcome_explorer_data(
            sequence,
            guide_for_explorer,
            outcomes,
            run_id=state.run_id,
            backend_name=payload.get("summary", {}).get("backend") if isinstance(payload.get("summary"), Mapping) else None,
        )
        return data

    def _set_viewer_buffers(self, buffers: dict[str, Any] | None) -> None:
        if self._viewer is not None and self._viewer_container is not None:
            if buffers:
                was_hidden = not self._viewer_container.isVisible()
                self._viewer_container.show()
                self._viewer.set_workflow_view(buffers)
                if was_hidden and hasattr(self, "_splitter"):
                    try:
                        # Default to ~30/70 split (viewer/explorer) when revealing the canvas.
                        size_total = max(1, self._splitter.height() or self.height() or 900)
                        viewer_size = max(220, int(size_total * 0.35))
                        self._splitter.setSizes([viewer_size, max(1, size_total - viewer_size)])
                    except Exception:
                        pass
                try:
                    self._viewer_container.raise_()
                except Exception:
                    pass
            else:
                self._viewer.set_workflow_view(None)
                self._viewer_container.hide()
                if hasattr(self, "_splitter"):
                    try:
                        size_total = max(1, self._splitter.height() or self.height() or 900)
                        self._splitter.setSizes([0, size_total])
                    except Exception:
                        pass
