from __future__ import annotations

PROTOCOL_VERSION = 1

METHOD_HELLO = "host.hello"
METHOD_CANCEL = "host.cancel"
METHOD_LOAD_PLUGINS = "plugins.load"
METHOD_UNLOAD_PLUGINS = "plugins.unload"
METHOD_INVOKE_COMMAND = "commands.invoke"
METHOD_WEB_PANEL_CALL = "ui.web_panel.call"
METHOD_EVENTS_EMIT = "events.emit"
METHOD_SHUTDOWN = "host.shutdown"

NOTIFY_LOG = "host.log"
NOTIFY_COMMAND_REGISTER = "commands.register"
NOTIFY_COMMAND_UNREGISTER = "commands.unregister"
NOTIFY_COMMAND_PROGRESS = "commands.progress"
NOTIFY_WEB_PANEL_REGISTER = "ui.web_panel.register"
NOTIFY_WEB_PANEL_UNREGISTER = "ui.web_panel.unregister"
NOTIFY_WEB_PANEL_MESSAGE = "ui.web_panel.message"
NOTIFY_SYSTEM_OPEN_URL = "system.open_url"
NOTIFY_SYSTEM_CLIPBOARD_SET = "system.clipboard.set"
