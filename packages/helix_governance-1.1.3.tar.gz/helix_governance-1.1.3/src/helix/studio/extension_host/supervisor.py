from __future__ import annotations

import os
from concurrent.futures import Future
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from helix import clock
from .client import ExtensionHostClient
from .protocol import METHOD_HELLO


def _norm_plugin_id(plugin_id: str) -> str:
    return (plugin_id or "").strip().lower()


def _norm_host_mode(value: str) -> str:
    v = (value or "").strip().lower()
    if v in {"shared", "s"}:
        return "shared"
    if v in {"per_plugin", "per-plugin", "perplugin", "dedicated", "plugin"}:
        return "per_plugin"
    return "shared"


def _norm_plugin_host_mode(value: str | None) -> str | None:
    if value is None:
        return None
    v = (value or "").strip().lower()
    if v in {"shared", "s"}:
        return "shared"
    if v in {"dedicated", "per_plugin", "per-plugin", "plugin"}:
        return "dedicated"
    return None


@dataclass(slots=True)
class _HeartbeatInflight:
    future: Future[Any]
    request_id: int | None
    started_at: float
    last_miss_at: float | None = None
    cancel_sent: bool = False


@dataclass(slots=True)
class _HeartbeatState:
    last_sent_at: float = 0.0
    last_ok_at: float | None = None
    last_ok_epoch_s: float | None = None
    last_rtt_ms: float | None = None
    consecutive_misses: int = 0
    last_miss_reason: str | None = None
    timeouts_total: int = 0
    send_failed_max_pending_total: int = 0
    send_failed_other_total: int = 0
    inflight: _HeartbeatInflight | None = None


class ExtensionHostSupervisor:
    """Owns extension-host processes (shared + per-plugin)."""

    def __init__(
        self,
        *,
        project_root: Path,
        src_path: Path,
        mode: str = "shared",
        env: Mapping[str, str] | None = None,
        python_executable: str | None = None,
        on_notification: Callable[[str, str, Any], None] | None = None,
        on_stderr: Callable[[str, str], None] | None = None,
    ) -> None:
        self._project_root = Path(project_root)
        self._src_path = Path(src_path)
        self._mode = _norm_host_mode(mode)
        self._base_env = dict(env) if env is not None else dict(os.environ)
        self._python = python_executable
        self._on_notification = on_notification
        self._on_stderr = on_stderr

        self._shared: ExtensionHostClient | None = None
        self._dedicated: dict[str, ExtensionHostClient] = {}
        self._plugin_host_key: dict[str, str] = {}

        self._restart_counts: dict[str, int] = {}
        self._backoff_until: dict[str, float] = {}
        self._heartbeat: dict[str, _HeartbeatState] = {}

    @property
    def mode(self) -> str:
        return self._mode

    def resolve_host_key(self, plugin_id: str, *, plugin_mode: str | None) -> str:
        pid = _norm_plugin_id(plugin_id)
        override = _norm_plugin_host_mode(plugin_mode)
        if override == "shared":
            return "shared"
        if override == "dedicated":
            return f"plugin:{pid}"
        if self._mode == "per_plugin":
            return f"plugin:{pid}"
        return "shared"

    def map_plugin(self, plugin_id: str, host_key: str) -> None:
        pid = _norm_plugin_id(plugin_id)
        key = (host_key or "").strip() or "shared"
        if pid:
            self._plugin_host_key[pid] = key

    def client_for_plugin(self, plugin_id: str) -> ExtensionHostClient | None:
        pid = _norm_plugin_id(plugin_id)
        key = self._plugin_host_key.get(pid)
        if not key:
            return None
        if key == "shared":
            return self._shared
        if key.startswith("plugin:"):
            return self._dedicated.get(pid)
        return None

    def all_hosts(self) -> list[tuple[str, ExtensionHostClient]]:
        hosts: list[tuple[str, ExtensionHostClient]] = []
        if self._shared is not None:
            hosts.append(("shared", self._shared))
        for pid, client in sorted(self._dedicated.items()):
            hosts.append((f"plugin:{pid}", client))
        return hosts

    def plugins_for_host_key(self, host_key: str) -> list[str]:
        key = (host_key or "").strip() or "shared"
        return sorted(
            pid
            for pid, mapped in self._plugin_host_key.items()
            if mapped == key and pid
        )

    def start_shared_host(self) -> ExtensionHostClient:
        return self._ensure_host("shared", cwd=self._project_root)

    def start_plugin_host(
        self,
        plugin_id: str,
        *,
        cwd: Path | None = None,
    ) -> ExtensionHostClient:
        pid = _norm_plugin_id(plugin_id)
        if not pid:
            raise ValueError("plugin_id is required")
        return self._ensure_host(f"plugin:{pid}", cwd=cwd or self._project_root)

    def notify_all(self, method: str, params: Any) -> None:
        for _key, client in self.all_hosts():
            if not client.is_running():
                continue
            try:
                client.notify(method, params)
            except Exception:
                continue

    def stop_all(self) -> None:
        if self._shared is not None:
            try:
                self._shared.stop()
            except Exception:
                pass
        self._shared = None
        for _pid, client in list(self._dedicated.items()):
            try:
                client.stop()
            except Exception:
                pass
        self._dedicated.clear()
        self._plugin_host_key.clear()
        self._restart_counts.clear()
        self._backoff_until.clear()
        self._heartbeat.clear()

    def stop_host(self, host_key: str, *, timeout_s: float = 2.0) -> None:
        key = (host_key or "").strip() or "shared"
        if key == "shared":
            if self._shared is not None:
                try:
                    self._shared.stop(timeout_s=float(timeout_s))
                except Exception:
                    pass
            self._shared = None
            self._heartbeat.pop("shared", None)
            return
        if key.startswith("plugin:"):
            pid = key.split(":", 1)[-1].strip().lower()
            client = self._dedicated.pop(pid, None)
            if client is not None:
                try:
                    client.stop(timeout_s=float(timeout_s))
                except Exception:
                    pass
            self._heartbeat.pop(f"plugin:{pid}", None)

    def stop_plugin_host(self, plugin_id: str, *, timeout_s: float = 2.0) -> None:
        pid = _norm_plugin_id(plugin_id)
        if not pid:
            return
        self.stop_host(f"plugin:{pid}", timeout_s=float(timeout_s))

    def heartbeat_tick(
        self,
        *,
        interval_s: float,
        timeout_s: float,
        restart_after_misses: int = 2,
    ) -> list[tuple[str, int]]:
        """Non-blocking health check for hosts; returns host keys to restart.

        - Uses monotonic time for all timing.
        - Enforces one outstanding `host.hello` per host (no ping stacking).
        - Cancels a stale ping once it crosses timeout.
        - Restarts after N consecutive misses (timeouts or send failures).
        """
        interval = float(interval_s)
        timeout = float(timeout_s)
        threshold = int(restart_after_misses)
        if interval <= 0.0 or timeout <= 0.0 or threshold <= 0:
            return []

        now = clock.monotonic()
        restarts: list[tuple[str, int]] = []

        for host_key, client in self.all_hosts():
            if not client.is_running():
                self._heartbeat.pop(host_key, None)
                continue
            state = self._heartbeat.setdefault(host_key, _HeartbeatState())

            inflight = state.inflight
            if inflight is not None:
                fut = inflight.future
                if fut.done():
                    try:
                        fut.result()
                        state.last_ok_at = now
                        state.last_ok_epoch_s = clock.unix_time_s()
                        state.last_rtt_ms = (now - inflight.started_at) * 1000.0
                        state.consecutive_misses = 0
                        state.last_miss_reason = None
                    except Exception:
                        state.consecutive_misses += 1
                        state.last_miss_reason = "hello_error"
                        if state.consecutive_misses >= threshold:
                            restarts.append((host_key, state.consecutive_misses))
                    state.inflight = None
                    continue

                age = now - inflight.started_at
                if age < timeout:
                    continue

                # Timed out: cancel once, count at most one miss per interval.
                if inflight.last_miss_at is None or (now - inflight.last_miss_at) >= interval:
                    inflight.last_miss_at = now
                    state.consecutive_misses += 1
                    state.last_miss_reason = "timeout"
                    state.timeouts_total += 1
                    if not inflight.cancel_sent and inflight.request_id is not None:
                        try:
                            client.cancel(int(inflight.request_id))
                            inflight.cancel_sent = True
                        except Exception:
                            pass
                    if state.consecutive_misses >= threshold:
                        restarts.append((host_key, state.consecutive_misses))
                continue

            if now - state.last_sent_at < interval:
                continue

            state.last_sent_at = now
            try:
                fut = client.call_async(METHOD_HELLO, {})
            except Exception as exc:
                msg = str(exc)
                if "too many pending requests" in msg:
                    state.send_failed_max_pending_total += 1
                    state.last_miss_reason = "send_failed_max_pending"
                else:
                    state.send_failed_other_total += 1
                    state.last_miss_reason = "send_failed"
                state.consecutive_misses += 1
                if state.consecutive_misses >= threshold:
                    restarts.append((host_key, state.consecutive_misses))
                continue

            request_id = getattr(fut, "_ext_request_id", None)
            try:
                rid = int(request_id) if request_id is not None else None
            except Exception:
                rid = None

            state.inflight = _HeartbeatInflight(
                future=fut,
                request_id=rid,
                started_at=now,
            )

        return restarts

    def stats(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "mode": self._mode,
            "plugin_hosts": dict(sorted(self._plugin_host_key.items())),
            "hosts": {},
            "restart_counts": dict(sorted(self._restart_counts.items())),
            "backoff_until": dict(sorted(self._backoff_until.items())),
        }
        for key, client in self.all_hosts():
            info: dict[str, Any] = {}
            try:
                info.update(client.stats())
            except Exception:
                info["running"] = client.is_running()
            try:
                proc = getattr(client, "_proc", None)
                info["pid"] = int(proc.pid) if proc is not None and proc.pid else None
            except Exception:
                pass
            try:
                info["stderr_tail"] = client.stderr_tail()
            except Exception:
                pass
            hb = self._heartbeat.get(key)
            if hb is not None:
                hb_info: dict[str, Any] = {
                    "consecutive_misses": int(hb.consecutive_misses),
                    "last_miss_reason": hb.last_miss_reason,
                    "last_ok_epoch_s": hb.last_ok_epoch_s,
                    "last_rtt_ms": hb.last_rtt_ms,
                    "timeouts_total": int(hb.timeouts_total),
                    "send_failed_max_pending_total": int(
                        hb.send_failed_max_pending_total
                    ),
                    "send_failed_other_total": int(hb.send_failed_other_total),
                }
                if hb.inflight is not None:
                    hb_info["inflight_age_s"] = max(
                        0.0, clock.monotonic() - float(hb.inflight.started_at)
                    )
                    hb_info["inflight_request_id"] = hb.inflight.request_id
                    hb_info["inflight_cancel_sent"] = bool(hb.inflight.cancel_sent)
                info["heartbeat"] = hb_info
            data["hosts"][key] = info
        return data

    # ---- internals -------------------------------------------------
    def _build_env(self, *, host_key: str) -> dict[str, str]:
        env = dict(self._base_env)
        if self._src_path.is_dir():
            prev = env.get("PYTHONPATH", "").strip()
            env["PYTHONPATH"] = (
                str(self._src_path)
                if not prev
                else f"{self._src_path}{os.pathsep}{prev}"
            )
        env["HELIX_STUDIO_EXTENSION_HOST_CHILD"] = "1"
        env["HELIX_STUDIO_EXTENSION_HOST_KEY"] = host_key
        return env

    def _ensure_host(self, host_key: str, *, cwd: Path) -> ExtensionHostClient:
        key = (host_key or "").strip() or "shared"
        now = clock.monotonic()
        backoff_until = float(self._backoff_until.get(key, 0.0))
        if now < backoff_until:
            wait_s = backoff_until - now
            raise RuntimeError(
                f"extension host '{key}' restart backoff active "
                f"(wait {wait_s:.1f}s)"
            )

        if key == "shared":
            existing = self._shared
        else:
            pid = key.split(":", 1)[-1].strip().lower()
            existing = self._dedicated.get(pid)

        if existing is not None and existing.is_running():
            return existing

        # Restart with simple exponential backoff when we detect crash loops.
        count = int(self._restart_counts.get(key, 0))
        self._restart_counts[key] = count + 1
        if count >= 2:
            delay = min(30.0, float(2**count))
            self._backoff_until[key] = clock.monotonic() + delay

        if existing is not None:
            try:
                existing.stop()
            except Exception:
                pass

        env = self._build_env(host_key=key)

        def _on_notification(method: str, params: Any) -> None:
            if self._on_notification is not None:
                self._on_notification(key, method, params)

        def _on_stderr(line: str) -> None:
            if self._on_stderr is not None:
                self._on_stderr(key, line)

        client = ExtensionHostClient(
            python_executable=self._python,
            cwd=cwd,
            env=env,
            on_notification=_on_notification,
            on_stderr=_on_stderr,
        )
        client.start()

        if key == "shared":
            self._shared = client
        else:
            pid = key.split(":", 1)[-1].strip().lower()
            self._dedicated[pid] = client
        return client


__all__ = ["ExtensionHostSupervisor"]
