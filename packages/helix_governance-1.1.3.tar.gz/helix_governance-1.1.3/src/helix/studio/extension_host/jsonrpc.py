from __future__ import annotations

import json
from dataclasses import dataclass
from typing import IO, Any, Mapping

JSONRPC_VERSION = "2.0"
DEFAULT_MAX_MESSAGE_BYTES = 4 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class JsonRpcError(Exception):
    code: int
    message: str
    data: Any | None = None

    def as_dict(self) -> dict[str, Any]:
        err: dict[str, Any] = {
            "code": int(self.code),
            "message": str(self.message),
        }
        if self.data is not None:
            err["data"] = self.data
        return err


def encode(message: Mapping[str, Any]) -> str:
    return json.dumps(dict(message), ensure_ascii=False, separators=(",", ":"))


def decode(line: str) -> dict[str, Any]:
    try:
        raw = json.loads(line)
    except json.JSONDecodeError as exc:
        raise JsonRpcError(-32700, f"Parse error: {exc}") from exc
    if not isinstance(raw, dict):
        raise JsonRpcError(-32600, "Invalid Request: expected JSON object")
    return raw


def encode_bytes(message: Mapping[str, Any]) -> bytes:
    return encode(message).encode("utf-8")


def decode_bytes(data: bytes) -> dict[str, Any]:
    try:
        raw = json.loads(data)
    except json.JSONDecodeError as exc:
        raise JsonRpcError(-32700, f"Parse error: {exc}") from exc
    if not isinstance(raw, dict):
        raise JsonRpcError(-32600, "Invalid Request: expected JSON object")
    return raw


def make_request(request_id: int, method: str, params: Any) -> dict[str, Any]:
    if not method or not isinstance(method, str):
        raise ValueError("method must be a non-empty string")
    msg: dict[str, Any] = {
        "jsonrpc": JSONRPC_VERSION,
        "id": request_id,
        "method": method,
    }
    if params is not None:
        msg["params"] = params
    return msg


def make_notification(method: str, params: Any) -> dict[str, Any]:
    if not method or not isinstance(method, str):
        raise ValueError("method must be a non-empty string")
    msg: dict[str, Any] = {"jsonrpc": JSONRPC_VERSION, "method": method}
    if params is not None:
        msg["params"] = params
    return msg


def make_result(request_id: int, result: Any) -> dict[str, Any]:
    return {"jsonrpc": JSONRPC_VERSION, "id": request_id, "result": result}


def make_error(request_id: int | None, err: JsonRpcError) -> dict[str, Any]:
    msg: dict[str, Any] = {
        "jsonrpc": JSONRPC_VERSION,
        "id": request_id,
        "error": err.as_dict(),
    }
    return msg


def encode_frame(
    message: Mapping[str, Any],
    *,
    max_message_bytes: int = DEFAULT_MAX_MESSAGE_BYTES,
) -> bytes:
    payload = encode_bytes(message)
    if len(payload) > int(max_message_bytes):
        raise JsonRpcError(
            -32000,
            f"Message too large ({len(payload)} bytes > {int(max_message_bytes)})",
        )
    return len(payload).to_bytes(4, "big") + payload


def _read_exact(stream: IO[bytes], n: int) -> bytes | None:
    remaining = int(n)
    chunks: list[bytes] = []
    while remaining > 0:
        chunk = stream.read(remaining)
        if not chunk:
            if not chunks:
                return None
            raise JsonRpcError(-32001, "Unexpected EOF while reading frame")
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


def read_frame(
    stream: IO[bytes],
    *,
    max_message_bytes: int = DEFAULT_MAX_MESSAGE_BYTES,
) -> dict[str, Any] | None:
    header = _read_exact(stream, 4)
    if header is None:
        return None
    length = int.from_bytes(header, "big")
    if length <= 0:
        raise JsonRpcError(-32002, f"Invalid frame length={length}")
    if length > int(max_message_bytes):
        raise JsonRpcError(
            -32003,
            f"Frame too large ({length} bytes > {int(max_message_bytes)})",
        )
    payload = _read_exact(stream, length)
    if payload is None:
        raise JsonRpcError(-32001, "Unexpected EOF while reading frame payload")
    return decode_bytes(payload)


def write_frame(
    stream: IO[bytes],
    message: Mapping[str, Any],
    *,
    max_message_bytes: int = DEFAULT_MAX_MESSAGE_BYTES,
) -> None:
    stream.write(encode_frame(message, max_message_bytes=max_message_bytes))
    stream.flush()
