from __future__ import annotations

import os
import subprocess
import sys
import threading
from collections import deque
from concurrent.futures import Future
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from helix import clock
from helix.support.subprocess import no_console_kwargs

from . import jsonrpc
from .protocol import METHOD_CANCEL, METHOD_SHUTDOWN


@dataclass(slots=True)
class _PendingRequest:
    future: Future[Any]
    method: str
    started_at: float


@dataclass(slots=True)
class _MethodLatencyBuckets:
    le_50ms: int = 0
    le_200ms: int = 0
    le_1s: int = 0
    gt_1s: int = 0


class ExtensionHostClient:
    def __init__(
        self,
        *,
        python_executable: str | None = None,
        cwd: str | Path | None = None,
        env: Mapping[str, str] | None = None,
        on_notification: Callable[[str, Any], None] | None = None,
        on_stderr: Callable[[str], None] | None = None,
        max_message_bytes: int = jsonrpc.DEFAULT_MAX_MESSAGE_BYTES,
        max_pending_requests: int = 256,
        max_notifications_per_sec: int = 500,
    ) -> None:
        self._python = python_executable or sys.executable
        self._cwd = str(Path(cwd)) if cwd is not None else None
        self._env = dict(env) if env is not None else dict(os.environ)
        self._on_notification = on_notification
        self._on_stderr = on_stderr
        self._max_message_bytes = int(max_message_bytes)
        self._max_pending = int(max_pending_requests)
        self._max_notifications_per_sec = int(max_notifications_per_sec)

        self._proc: subprocess.Popen[bytes] | None = None
        self._write_lock = threading.Lock()
        self._pending_lock = threading.Lock()
        self._reader: threading.Thread | None = None
        self._stderr_reader: threading.Thread | None = None
        self._next_id = 1
        self._pending: dict[int, _PendingRequest] = {}
        self._pending_peak = 0
        self._stderr_tail: deque[str] = deque(maxlen=200)
        self._notify_window_start = clock.monotonic()
        self._notify_count = 0
        self._notify_dropped = 0
        self._notify_dropped_total = 0
        self._protocol_errors_total = 0
        self._latency_by_method: dict[str, _MethodLatencyBuckets] = {}

    def start(self) -> None:
        if self._proc is not None:
            return
        cmd = [
            self._python,
            "-u",
            "-m",
            "helix.studio.extension_host.host_process",
        ]
        self._proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=False,
            bufsize=0,
            env=self._env,
            cwd=self._cwd,
            **no_console_kwargs(),
        )
        self._reader = threading.Thread(target=self._read_stdout, daemon=True)
        self._reader.start()
        self._stderr_reader = threading.Thread(target=self._read_stderr, daemon=True)
        self._stderr_reader.start()

    def is_running(self) -> bool:
        proc = self._proc
        return proc is not None and proc.poll() is None

    def pid(self) -> int | None:
        proc = self._proc
        try:
            return int(proc.pid) if proc is not None and proc.pid else None
        except Exception:
            return None

    def stop(self, *, timeout_s: float = 2.0) -> None:
        proc = self._proc
        if proc is None:
            return
        try:
            self.call(METHOD_SHUTDOWN, {}, timeout_s=timeout_s)
        except Exception:
            pass
        try:
            proc.terminate()
        except Exception:
            pass
        try:
            proc.wait(timeout=timeout_s)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        self._proc = None
        self._fail_pending(RuntimeError("extension host stopped"))

    def notify(self, method: str, params: Any) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None:
            raise RuntimeError("extension host is not running")
        msg = jsonrpc.make_notification(method, params)
        self._write(msg)

    def call(self, method: str, params: Any, *, timeout_s: float = 10.0) -> Any:
        fut = self.call_async(method, params)
        request_id = getattr(fut, "_ext_request_id", None)
        try:
            return fut.result(timeout=timeout_s)
        except TimeoutError:
            if request_id is not None:
                try:
                    self.cancel(int(request_id))
                except Exception:
                    pass
            raise

    def call_async(self, method: str, params: Any) -> Future[Any]:
        proc = self._proc
        if proc is None or proc.stdin is None:
            raise RuntimeError("extension host is not running")
        fut: Future[Any] = Future()
        with self._pending_lock:
            if len(self._pending) >= self._max_pending:
                raise RuntimeError("extension host: too many pending requests")
            request_id = self._next_id
            self._next_id += 1
            self._pending[request_id] = _PendingRequest(
                future=fut,
                method=(method or "").strip(),
                started_at=clock.monotonic(),
            )
            self._pending_peak = max(self._pending_peak, len(self._pending))
        fut._ext_request_id = request_id  # type: ignore[attr-defined]
        msg = jsonrpc.make_request(request_id, method, params)
        self._write(msg)
        return fut

    def cancel(self, request_id: int) -> None:
        self.notify(METHOD_CANCEL, {"request_id": int(request_id)})

    def stderr_tail(self) -> str:
        return "".join(self._stderr_tail)

    def stats(self) -> dict[str, Any]:
        with self._pending_lock:
            pending = len(self._pending)
            pending_peak = int(self._pending_peak)
            protocol_errors_total = int(self._protocol_errors_total)
            dropped_total = int(self._notify_dropped_total)
            dropped_window = int(self._notify_dropped)
            latency = {
                k: {
                    "le_50ms": v.le_50ms,
                    "le_200ms": v.le_200ms,
                    "le_1s": v.le_1s,
                    "gt_1s": v.gt_1s,
                }
                for k, v in sorted(self._latency_by_method.items())
            }
        return {
            "running": self.is_running(),
            "pending_requests": pending,
            "pending_requests_peak": pending_peak,
            "protocol_errors_total": protocol_errors_total,
            "notifications_dropped_total": dropped_total,
            "notifications_dropped_last_window": dropped_window,
            "latency_buckets_by_method": latency,
            "limits": {
                "max_message_bytes": int(self._max_message_bytes),
                "max_pending_requests": int(self._max_pending),
                "max_notifications_per_sec": int(self._max_notifications_per_sec),
            },
        }

    # ---- internals -------------------------------------------------
    def _write(self, msg: dict[str, Any]) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None:
            raise RuntimeError("extension host is not running")
        with self._write_lock:
            jsonrpc.write_frame(
                proc.stdin,
                msg,
                max_message_bytes=self._max_message_bytes,
            )

    def _read_stdout(self) -> None:
        proc = self._proc
        if proc is None or proc.stdout is None:
            return
        while True:
            try:
                msg = jsonrpc.read_frame(
                    proc.stdout,
                    max_message_bytes=self._max_message_bytes,
                )
            except jsonrpc.JsonRpcError as exc:
                with self._pending_lock:
                    self._protocol_errors_total += 1
                self._fail_pending(
                    RuntimeError(f"extension host protocol error: {exc}")
                )
                return
            if msg is None:
                break

            if "id" in msg and ("result" in msg or "error" in msg):
                self._handle_response(msg)
                continue

            method = msg.get("method")
            if isinstance(method, str) and method:
                params = msg.get("params")
                if self._on_notification is not None:
                    if self._throttle_notification(method):
                        continue
                    try:
                        self._on_notification(method, params)
                    except Exception:
                        continue

        self._fail_pending(RuntimeError("extension host stdout closed"))

    def _read_stderr(self) -> None:
        proc = self._proc
        if proc is None or proc.stderr is None:
            return
        for raw in iter(proc.stderr.readline, b""):
            line = raw.decode("utf-8", errors="replace")
            self._stderr_tail.append(line)
            if self._on_stderr is not None:
                try:
                    self._on_stderr(line.rstrip("\n"))
                except Exception:
                    continue

    def _handle_response(self, msg: dict[str, Any]) -> None:
        request_id = msg.get("id")
        try:
            rid = int(request_id)
        except Exception:
            return
        with self._pending_lock:
            pending = self._pending.pop(rid, None)
            if pending is None:
                return
            fut = pending.future
            try:
                elapsed_ms = (clock.monotonic() - pending.started_at) * 1000.0
                self._record_latency(pending.method, elapsed_ms)
            except Exception:
                pass
        if "error" in msg:
            err = msg.get("error")
            if isinstance(err, dict):
                message = str(err.get("message") or "").strip()
                if not message:
                    message = str(err)
            else:
                message = str(err).strip()
            fut.set_exception(RuntimeError(message or "extension host error"))
            return
        fut.set_result(msg.get("result"))

    def _record_latency(self, method: str, elapsed_ms: float) -> None:
        m = (method or "").strip() or "unknown"
        buckets = self._latency_by_method.get(m)
        if buckets is None:
            buckets = _MethodLatencyBuckets()
            self._latency_by_method[m] = buckets
        if elapsed_ms <= 50.0:
            buckets.le_50ms += 1
        elif elapsed_ms <= 200.0:
            buckets.le_200ms += 1
        elif elapsed_ms <= 1000.0:
            buckets.le_1s += 1
        else:
            buckets.gt_1s += 1

    def _throttle_notification(self, method: str) -> bool:
        if self._max_notifications_per_sec <= 0:
            return False
        now = clock.monotonic()
        if now - self._notify_window_start >= 1.0:
            if self._notify_dropped > 0 and self._on_notification is not None:
                try:
                    self._on_notification(
                        "host.log",
                        {
                            "plugin_id": "host",
                            "message": (
                                f"dropped {self._notify_dropped} extension-host "
                                "notifications (rate limit)"
                            ),
                        },
                    )
                except Exception:
                    pass
            self._notify_window_start = now
            self._notify_count = 0
            self._notify_dropped = 0

        if self._notify_count >= self._max_notifications_per_sec:
            self._notify_dropped += 1
            self._notify_dropped_total += 1
            return True
        self._notify_count += 1
        return False

    def _fail_pending(self, exc: Exception) -> None:
        with self._pending_lock:
            for rid, pending in list(self._pending.items()):
                fut = pending.future
                if not fut.done():
                    fut.set_exception(exc)
                self._pending.pop(rid, None)
