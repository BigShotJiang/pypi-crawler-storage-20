from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Protocol, Sequence

from helix.studio.commands import HelixCommand
from helix.studio.plugins.policy import PluginPolicy
from helix.support.subprocess import no_console_kwargs

from .protocol import (
    METHOD_EVENTS_EMIT,
    NOTIFY_COMMAND_REGISTER,
    NOTIFY_LOG,
    NOTIFY_SYSTEM_CLIPBOARD_SET,
    NOTIFY_SYSTEM_OPEN_URL,
    NOTIFY_WEB_PANEL_MESSAGE,
    NOTIFY_WEB_PANEL_REGISTER,
)


class _Notifier(Protocol):
    def notify(self, method: str, params: Any) -> None: ...


class _HandlerRegistry(Protocol):
    def register_handler(self, plugin_id: str, fn: Callable[[], Any]) -> int: ...

    def register_web_panel_handler(
        self, plugin_id: str, fn: Callable[..., Any]
    ) -> int: ...

    def track_web_panel(self, plugin_id: str, panel_id: str) -> None: ...

    def register_event_handler(
        self, plugin_id: str, topic: str, fn: Callable[..., None]
    ) -> int: ...

    def unregister_event_handler(self, token: int) -> bool: ...


def _ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def _base_dir() -> Path:
    return Path.home() / ".helix" / "studio"


class RemotePluginApi:
    def __init__(
        self,
        plugin_id: str,
        *,
        policy: PluginPolicy,
        notifier: _Notifier,
        registry: _HandlerRegistry,
    ):
        self._plugin_id = (plugin_id or "").strip().lower()
        self._policy = policy
        self._notifier = notifier
        self._registry = registry
        self.net = RemoteNetwork(
            self._plugin_id,
            policy=policy,
        )
        self.files = RemoteFiles(
            self._plugin_id,
            policy=policy,
        )
        self.subprocess = RemoteSubprocess(
            self._plugin_id,
            policy=policy,
        )
        self.system = RemoteSystem(
            self._plugin_id,
            policy=policy,
            notifier=notifier,
        )
        self.commands = RemoteCommands(
            self._plugin_id, notifier=notifier, registry=registry
        )
        self.ui = RemoteUi(
            self._plugin_id, policy=policy, notifier=notifier, registry=registry
        )
        self.settings = RemoteSettings(self._plugin_id)
        self.paths = RemotePaths(self._plugin_id)
        self.events = RemoteEvents(
            self._plugin_id, notifier=notifier, registry=registry
        )

    @property
    def plugin_id(self) -> str:
        return self._plugin_id

    def log(self, message: str) -> None:
        msg = (message or "").strip()
        if not msg:
            return
        self._notifier.notify(
            NOTIFY_LOG,
            {"plugin_id": self._plugin_id, "message": msg},
        )


def _host_matches(pattern: str, host: str) -> bool:
    p = (pattern or "").strip().lower().lstrip(".")
    h = (host or "").strip().lower()
    if not p or not h:
        return False
    if h == p:
        return True
    return h.endswith(f".{p}")


class RemoteNetwork:
    """Network helpers gated by PluginPolicy.network.

    Note: This does not prevent a plugin from using Python stdlib networking
    directly. It exists to provide a sanctioned, policy-checked path.
    """

    def __init__(self, plugin_id: str, *, policy: PluginPolicy) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()
        self._policy = policy

    def _check_url(self, url: str) -> None:
        raw = (url or "").strip()
        if not raw:
            raise ValueError("url is required")

        mode = (self._policy.network.mode or "").strip().lower()
        if mode in {"none", "deny"}:
            raise PermissionError("network is disabled by policy")

        try:
            from urllib.parse import urlparse

            parsed = urlparse(raw)
        except Exception as exc:
            raise ValueError(f"invalid url: {url!r}") from exc

        scheme = (parsed.scheme or "").strip().lower()
        host = (parsed.hostname or "").strip().lower()
        if scheme not in {"http", "https"}:
            raise PermissionError(f"scheme blocked by policy: {scheme or '(none)'}")
        if scheme == "http" and not self._policy.network.allow_insecure_http:
            raise PermissionError("insecure http blocked by policy")
        if mode in {"full", "all", "any"}:
            return

        allow = tuple(
            h for h in self._policy.network.allow if isinstance(h, str) and h.strip()
        )
        for pat in allow:
            if _host_matches(pat, host):
                return
        raise PermissionError(f"host not in allowlist: {host}")

    def get_text(
        self,
        url: str,
        *,
        timeout_s: float = 10.0,
        headers: Mapping[str, str] | None = None,
    ) -> str:
        self._check_url(url)
        raw_url = (url or "").strip()

        try:
            from urllib.request import Request, urlopen

            req = Request(raw_url, method="GET")
            for k, v in dict(headers or {}).items():
                if isinstance(k, str) and isinstance(v, str):
                    req.add_header(k, v)
            with urlopen(req, timeout=float(timeout_s)) as resp:
                data = resp.read()
        except Exception as exc:
            raise RuntimeError(f"network request failed: {exc}") from exc

        try:
            return data.decode("utf-8")
        except Exception:
            return data.decode("utf-8", errors="replace")

    def get_json(
        self,
        url: str,
        *,
        timeout_s: float = 10.0,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        text = self.get_text(url, timeout_s=timeout_s, headers=headers)
        try:
            return json.loads(text)
        except Exception as exc:
            raise ValueError(f"response was not valid JSON: {exc}") from exc


class RemoteFiles:
    """File helpers gated by PluginPolicy.files."""

    def __init__(self, plugin_id: str, *, policy: PluginPolicy) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()
        self._policy = policy

    def read_text(self, path: str | Path, *, encoding: str = "utf-8") -> str:
        if not self._policy.files.can_read():
            raise PermissionError("file read is disabled by policy")
        p = Path(path)
        return p.read_text(encoding=encoding)

    def read_bytes(self, path: str | Path) -> bytes:
        if not self._policy.files.can_read():
            raise PermissionError("file read is disabled by policy")
        p = Path(path)
        return p.read_bytes()

    def write_text(
        self,
        path: str | Path,
        text: str,
        *,
        encoding: str = "utf-8",
        create_parents: bool = True,
    ) -> None:
        if not self._policy.files.can_write():
            raise PermissionError("file write is disabled by policy")
        p = Path(path)
        if create_parents:
            p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding=encoding)

    def write_bytes(
        self,
        path: str | Path,
        data: bytes,
        *,
        create_parents: bool = True,
    ) -> None:
        if not self._policy.files.can_write():
            raise PermissionError("file write is disabled by policy")
        p = Path(path)
        if create_parents:
            p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)


class RemoteSubprocess:
    """Subprocess helpers gated by PluginPolicy.subprocess."""

    def __init__(self, plugin_id: str, *, policy: PluginPolicy) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()
        self._policy = policy

    def run(
        self,
        args: Sequence[str],
        *,
        timeout_s: float | None = None,
        cwd: str | Path | None = None,
        env: Mapping[str, str] | None = None,
        max_output_chars: int = 200_000,
    ) -> dict[str, Any]:
        if not self._policy.subprocess.allowed:
            raise PermissionError("subprocess is disabled by policy")
        if isinstance(args, (str, bytes)):
            raise ValueError("args must be a sequence of strings, not a single string")
        argv = list(args)
        if not argv or not all(isinstance(x, str) and x for x in argv):
            raise ValueError("args must be a non-empty sequence of strings")

        try:
            cp = subprocess.run(
                argv,
                cwd=str(cwd) if cwd is not None else None,
                env=dict(env) if env is not None else None,
                timeout=float(timeout_s) if timeout_s is not None else None,
                capture_output=True,
                text=True,
                **no_console_kwargs(),
            )
        except subprocess.TimeoutExpired as exc:
            raise TimeoutError(str(exc)) from exc

        out = cp.stdout or ""
        err = cp.stderr or ""
        if max_output_chars > 0:
            out = out[: int(max_output_chars)]
            err = err[: int(max_output_chars)]

        return {
            "args": argv,
            "returncode": int(cp.returncode),
            "stdout": out,
            "stderr": err,
        }


class RemoteSystem:
    """System integration helpers gated by PluginPolicy.system."""

    def __init__(
        self,
        plugin_id: str,
        *,
        policy: PluginPolicy,
        notifier: _Notifier,
    ) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()
        self._policy = policy
        self._notifier = notifier

    def open_url(self, url: str) -> None:
        if not self._policy.system.open_url:
            raise PermissionError("open_url is disabled by policy")
        raw = (url or "").strip()
        if not raw:
            raise ValueError("url is required")
        try:
            from urllib.parse import urlparse

            parsed = urlparse(raw)
        except Exception as exc:
            raise ValueError(f"invalid url: {url!r}") from exc
        scheme = (parsed.scheme or "").strip().lower()
        if scheme not in {"http", "https"}:
            raise PermissionError(f"scheme blocked: {scheme or '(none)'}")
        self._notifier.notify(
            NOTIFY_SYSTEM_OPEN_URL,
            {"plugin_id": self._plugin_id, "url": raw},
        )

    def clipboard_set(self, text: str) -> None:
        if not self._policy.system.clipboard:
            raise PermissionError("clipboard is disabled by policy")
        self._notifier.notify(
            NOTIFY_SYSTEM_CLIPBOARD_SET,
            {"plugin_id": self._plugin_id, "text": str(text)},
        )


class RemoteCommands:
    def __init__(
        self, plugin_id: str, *, notifier: _Notifier, registry: _HandlerRegistry
    ):
        self._plugin_id = plugin_id
        self._notifier = notifier
        self._registry = registry

    def register(
        self,
        command_id: str,
        title: str,
        callback: Callable[..., Any],
        *,
        category: str | None = None,
        shortcut: str | None = None,
        menu: str | None = None,
    ) -> HelixCommand:
        cid = (command_id or "").strip().lower()
        if not cid.startswith(f"{self._plugin_id}."):
            raise ValueError(
                "plugin command ids must be namespaced: "
                f"expected '{self._plugin_id}.*' got {command_id!r}"
            )
        if not callable(callback):
            raise TypeError("callback must be callable")
        handler_id = self._registry.register_handler(self._plugin_id, callback)
        self._notifier.notify(
            NOTIFY_COMMAND_REGISTER,
            {
                "plugin_id": self._plugin_id,
                "command_id": cid,
                "title": (title or "").strip(),
                "category": (category or "").strip() or None,
                "shortcut": (shortcut or "").strip() or None,
                "menu": (menu or "").strip() or None,
                "handler_id": handler_id,
            },
        )
        return HelixCommand(
            command_id=cid,
            title=(title or "").strip(),
            callback=callback,
            category=(category or "").strip() or None,
            shortcut=(shortcut or "").strip() or None,
            owner=self._plugin_id,
        )


class RemoteUi:
    def __init__(
        self,
        plugin_id: str,
        *,
        policy: PluginPolicy,
        notifier: _Notifier,
        registry: _HandlerRegistry,
    ) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()
        self._policy = policy
        self._notifier = notifier
        self._registry = registry

    def register_web_panel(
        self,
        panel_id: str,
        title: str,
        entry_html: str,
        *,
        area: str = "bottom",
        visible: bool = False,
        menu: str = "View/Plugin Panels",
        handler: Callable[..., Any] | None = None,
    ) -> None:
        if not self._policy.web_panels.enabled:
            raise PermissionError("web panels are disabled by policy")
        pid = (panel_id or "").strip().lower()
        if not pid.startswith(f"{self._plugin_id}."):
            raise ValueError(
                "plugin panel ids must be namespaced: "
                f"expected '{self._plugin_id}.*' got {panel_id!r}"
            )
        if not isinstance(title, str) or not title.strip():
            raise ValueError("title must be a non-empty string")
        entry = (entry_html or "").strip()
        if not entry:
            raise ValueError("entry_html is required")

        self._registry.track_web_panel(self._plugin_id, pid)

        handler_id: int | None = None
        if handler is not None:
            if not callable(handler):
                raise TypeError("handler must be callable")
            handler_id = self._registry.register_web_panel_handler(
                self._plugin_id, handler
            )

        self._notifier.notify(
            NOTIFY_WEB_PANEL_REGISTER,
            {
                "plugin_id": self._plugin_id,
                "panel_id": pid,
                "title": title.strip(),
                "entry_html": entry,
                "area": (area or "").strip().lower() or "bottom",
                "visible": bool(visible),
                "menu": (menu or "").strip() or "View/Plugin Panels",
                "handler_id": handler_id,
            },
        )

    def post_message(self, panel_id: str, payload: Any) -> None:
        if not self._policy.web_panels.enabled:
            raise PermissionError("web panels are disabled by policy")
        pid = (panel_id or "").strip().lower()
        if not pid.startswith(f"{self._plugin_id}."):
            raise ValueError(
                "plugin panel ids must be namespaced: "
                f"expected '{self._plugin_id}.*' got {panel_id!r}"
            )
        self._notifier.notify(
            NOTIFY_WEB_PANEL_MESSAGE,
            {"plugin_id": self._plugin_id, "panel_id": pid, "payload": payload},
        )


class RemoteSettings:
    def __init__(self, plugin_id: str) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()

    def _path(self) -> Path:
        root = _ensure_dir(_base_dir() / "plugins" / self._plugin_id / "data")
        return root / "settings.json"

    def _load(self) -> dict[str, Any]:
        path = self._path()
        if not path.exists():
            return {}
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return {}
        return raw if isinstance(raw, dict) else {}

    def _save(self, data: dict[str, Any]) -> None:
        path = self._path()
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(path)

    def get(self, key: str, default: Any = None) -> Any:
        k = (key or "").strip()
        if not k:
            raise ValueError("key is required")
        return self._load().get(k, default)

    def set(self, key: str, value: Any) -> None:
        k = (key or "").strip()
        if not k:
            raise ValueError("key is required")
        try:
            json.dumps(value)
        except TypeError as exc:
            raise TypeError("plugin settings values must be JSON-serializable") from exc
        data = self._load()
        data[k] = value
        self._save(data)

    def remove(self, key: str) -> None:
        k = (key or "").strip()
        if not k:
            raise ValueError("key is required")
        data = self._load()
        if k in data:
            data.pop(k, None)
            self._save(data)


class RemotePaths:
    def __init__(self, plugin_id: str) -> None:
        self._plugin_id = (plugin_id or "").strip().lower()

    def user_data_dir(self) -> Path:
        return _ensure_dir(_base_dir() / "plugins" / self._plugin_id / "data")

    def cache_dir(self) -> Path:
        return _ensure_dir(_base_dir() / "cache" / "plugins" / self._plugin_id)

    def temp_dir(self) -> Path:
        return _ensure_dir(
            _base_dir() / "tmp" / "helix_studio" / "plugins" / self._plugin_id
        )


@dataclass(frozen=True, slots=True)
class _EventSub:
    token: int
    topic: str
    handler: Callable[..., None]


class RemoteEvents:
    def __init__(
        self, plugin_id: str, *, notifier: _Notifier, registry: _HandlerRegistry
    ):
        self._plugin_id = plugin_id
        self._notifier = notifier
        self._registry = registry

    def subscribe(self, topic: str, handler: Callable[..., None]) -> int:
        t = (topic or "").strip()
        if not t:
            raise ValueError("topic is required")
        if not callable(handler):
            raise TypeError("handler must be callable")
        return self._registry.register_event_handler(self._plugin_id, t, handler)

    def unsubscribe(self, token: int) -> bool:
        return self._registry.unregister_event_handler(int(token))

    def emit(self, topic: str, payload: Any) -> None:
        t = (topic or "").strip()
        if not t:
            return
        self._notifier.notify(METHOD_EVENTS_EMIT, {"topic": t, "payload": payload})
