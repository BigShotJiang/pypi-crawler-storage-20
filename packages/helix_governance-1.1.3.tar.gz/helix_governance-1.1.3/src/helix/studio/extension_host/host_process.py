from __future__ import annotations

import importlib
import os
import sys
import threading
import time
import traceback
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Callable

from helix import clock
from helix import fs
from helix.studio.plugins.manifest import parse_entry
from helix.studio.plugins.policy import policy_from_dict

from . import jsonrpc
from .protocol import (
    METHOD_CANCEL,
    METHOD_EVENTS_EMIT,
    METHOD_HELLO,
    METHOD_INVOKE_COMMAND,
    METHOD_LOAD_PLUGINS,
    METHOD_SHUTDOWN,
    METHOD_UNLOAD_PLUGINS,
    METHOD_WEB_PANEL_CALL,
    NOTIFY_COMMAND_PROGRESS,
    NOTIFY_LOG,
    NOTIFY_WEB_PANEL_UNREGISTER,
    PROTOCOL_VERSION,
)
from .remote_api import RemotePluginApi


@dataclass(slots=True)
class _LoadedRemotePlugin:
    plugin_id: str
    root: Path
    manifest_path: str | None
    module: ModuleType
    deactivate: Callable[[], None] | None
    load_time_ms: float | None


def _wrap_deactivate(fn: Callable[..., Any], host_api: Any) -> Callable[[], None]:
    def _call() -> None:
        try:
            fn()
            return
        except TypeError as exc:
            msg = str(exc)
            if (
                "required positional argument" not in msg
                and "positional arguments" not in msg
            ):
                raise
        fn(host_api)

    return _call


class CommandCancelled(RuntimeError):
    pass


def _test_stall_hello_s() -> float | None:
    # Test-only: allow simulating a wedged protocol loop without signals.
    # Guard behind PYTEST_CURRENT_TEST so it can't be triggered in production.
    if not os.environ.get("PYTEST_CURRENT_TEST", "").strip():
        return None
    raw = str(os.environ.get("HELIX_STUDIO_EXTENSION_HOST_TEST_STALL_HELLO_S", "")).strip()
    if not raw:
        return None
    try:
        value = float(raw)
    except Exception:
        return None
    if value <= 0.0:
        return None
    return min(60.0, value)


@dataclass(frozen=True, slots=True)
class CommandContext:
    request_id: int
    plugin_id: str
    _cancel_event: threading.Event
    _notify: Callable[[str, Any], None]

    def is_cancelled(self) -> bool:
        return self._cancel_event.is_set()

    def throw_if_cancelled(self) -> None:
        if self.is_cancelled():
            raise CommandCancelled("cancelled")

    def progress(
        self,
        *,
        percent: int | None = None,
        stage: str | None = None,
        message: str | None = None,
    ) -> None:
        pct = None if percent is None else int(percent)
        if pct is not None:
            pct = max(0, min(100, pct))
        payload = {
            "plugin_id": self.plugin_id,
            "request_id": int(self.request_id),
            "percent": pct,
            "stage": (stage or "").strip() or None,
            "message": (message or "").strip() or None,
        }
        self._notify(NOTIFY_COMMAND_PROGRESS, payload)


@dataclass(frozen=True, slots=True)
class WebPanelContext:
    request_id: int
    plugin_id: str
    panel_id: str
    _cancel_event: threading.Event

    def is_cancelled(self) -> bool:
        return self._cancel_event.is_set()

    def throw_if_cancelled(self) -> None:
        if self.is_cancelled():
            raise CommandCancelled("cancelled")


@dataclass(slots=True)
class _PendingInvoke:
    plugin_id: str
    future: Future[Any]
    cancel_event: threading.Event
    cancelled: bool = False


class _ExtensionHostRuntime:
    def __init__(self, *, protocol_out) -> None:
        self._protocol_out = protocol_out
        self._write_lock = threading.Lock()

        self._next_handler_id = 1
        self._command_handlers: dict[int, tuple[str, Callable[[], Any]]] = {}

        self._next_web_handler_id = 1
        self._web_panel_handlers: dict[int, tuple[str, Callable[..., Any]]] = {}
        self._web_panels_by_plugin: dict[str, set[str]] = {}

        self._next_event_token = 1
        self._event_handlers_by_topic: dict[
            str, list[tuple[int, str, Callable[..., None]]]
        ] = {}
        self._event_topic_by_token: dict[int, str] = {}

        self._plugins: dict[str, _LoadedRemotePlugin] = {}
        self._executor = ThreadPoolExecutor(max_workers=4)
        self._pending_invoke: dict[int, _PendingInvoke] = {}

    def _send(self, message: dict[str, Any]) -> None:
        with self._write_lock:
            jsonrpc.write_frame(self._protocol_out, message)

    def notify(self, method: str, params: Any) -> None:
        self._send(jsonrpc.make_notification(method, params))

    def register_handler(self, plugin_id: str, fn: Callable[[], Any]) -> int:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            raise ValueError("plugin_id is required")
        handler_id = self._next_handler_id
        self._next_handler_id += 1
        self._command_handlers[handler_id] = (pid, fn)
        return handler_id

    def register_web_panel_handler(self, plugin_id: str, fn: Callable[..., Any]) -> int:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            raise ValueError("plugin_id is required")
        handler_id = self._next_web_handler_id
        self._next_web_handler_id += 1
        self._web_panel_handlers[handler_id] = (pid, fn)
        return handler_id

    def track_web_panel(self, plugin_id: str, panel_id: str) -> None:
        pid = (plugin_id or "").strip().lower()
        panel = (panel_id or "").strip().lower()
        if not pid or not panel:
            return
        self._web_panels_by_plugin.setdefault(pid, set()).add(panel)

    def register_event_handler(
        self, plugin_id: str, topic: str, fn: Callable[..., None]
    ) -> int:
        pid = (plugin_id or "").strip().lower()
        t = (topic or "").strip()
        if not pid or not t:
            raise ValueError("plugin_id and topic are required")
        token = self._next_event_token
        self._next_event_token += 1
        self._event_handlers_by_topic.setdefault(t, []).append((token, pid, fn))
        self._event_topic_by_token[token] = t
        return token

    def unregister_event_handler(self, token: int) -> bool:
        tok = int(token)
        topic = self._event_topic_by_token.pop(tok, None)
        if topic is None:
            return False
        subs = self._event_handlers_by_topic.get(topic, [])
        next_subs = [s for s in subs if s[0] != tok]
        if next_subs:
            self._event_handlers_by_topic[topic] = next_subs
        else:
            self._event_handlers_by_topic.pop(topic, None)
        return True

    def emit_local_event(self, topic: str, payload: Any) -> None:
        t = (topic or "").strip()
        if not t:
            return
        subs = list(self._event_handlers_by_topic.get(t, []))
        for _token, pid, handler in subs:
            try:
                _call_event_handler(handler, t, payload)
            except Exception as exc:
                self.notify(
                    "host.log",
                    {"plugin_id": pid, "message": f"event '{t}' handler failed: {exc}"},
                )

    def load_plugin(self, spec: dict[str, Any]) -> dict[str, Any]:
        plugin_id = str(spec.get("plugin_id") or "").strip().lower()
        root = str(spec.get("root") or "").strip()
        entry = str(spec.get("entry") or "").strip()
        manifest_path = str(spec.get("manifest_path") or "").strip() or None
        policy = policy_from_dict(spec.get("policy"))
        if not plugin_id or not root or not entry:
            raise ValueError("plugin_id, root, and entry are required")
        if plugin_id in self._plugins:
            return {"plugin_id": plugin_id, "status": "already_loaded"}

        root_path = Path(root)
        self._ensure_sys_path(root_path)

        module_name, func_name = parse_entry(entry)
        if not module_name:
            raise ValueError(f"invalid entry={entry!r}")

        api = RemotePluginApi(plugin_id, policy=policy, notifier=self, registry=self)
        module = importlib.import_module(module_name)
        activate = getattr(module, func_name, None)
        if not callable(activate):
            raise RuntimeError(f"entry callable not found: {module_name}:{func_name}")

        start = clock.perf_counter()
        result = activate(api)
        load_time_ms = (clock.perf_counter() - start) * 1000.0

        deactivate: Callable[[], None] | None = None
        if callable(result):
            deactivate = result
        elif result is not None:
            deactivate_attr = getattr(result, "deactivate", None)
            if callable(deactivate_attr):
                deactivate = deactivate_attr
        if deactivate is None:
            deactivate_attr = getattr(module, "deactivate", None)
            if callable(deactivate_attr):
                deactivate = deactivate_attr
        if deactivate is not None:
            deactivate = _wrap_deactivate(deactivate, api)

        loaded = _LoadedRemotePlugin(
            plugin_id=plugin_id,
            root=root_path,
            manifest_path=manifest_path,
            module=module,
            deactivate=deactivate,
            load_time_ms=load_time_ms,
        )
        self._plugins[plugin_id] = loaded
        return {
            "plugin_id": plugin_id,
            "status": "loaded",
            "load_time_ms": load_time_ms,
        }

    def unload_plugin(self, plugin_id: str) -> dict[str, Any]:
        pid = (plugin_id or "").strip().lower()
        plugin = self._plugins.pop(pid, None)
        if plugin is None:
            return {"plugin_id": pid, "status": "not_loaded"}

        # Best-effort deactivate hook.
        if plugin.deactivate is not None:
            try:
                plugin.deactivate()
            except Exception as exc:
                self.notify(
                    "host.log",
                    {
                        "plugin_id": pid,
                        "message": f"deactivate failed: {exc}",
                    },
                )

        # Remove command handlers owned by this plugin.
        for hid, (owner, _fn) in list(self._command_handlers.items()):
            if owner == pid:
                self._command_handlers.pop(hid, None)

        # Remove web panel handlers owned by this plugin.
        for hid, (owner, _fn) in list(self._web_panel_handlers.items()):
            if owner == pid:
                self._web_panel_handlers.pop(hid, None)

        # Tell Studio to unregister UI panels owned by this plugin.
        panel_ids = sorted(self._web_panels_by_plugin.pop(pid, set()))
        for panel_id in panel_ids:
            self.notify(
                NOTIFY_WEB_PANEL_UNREGISTER,
                {"plugin_id": pid, "panel_id": panel_id},
            )

        # Remove event handlers owned by this plugin.
        for topic, subs in list(self._event_handlers_by_topic.items()):
            next_subs = [s for s in subs if s[1] != pid]
            self._event_handlers_by_topic[topic] = next_subs
            if not next_subs:
                self._event_handlers_by_topic.pop(topic, None)
        for tok, topic in list(self._event_topic_by_token.items()):
            subs = self._event_handlers_by_topic.get(topic, [])
            if not any(s[0] == tok for s in subs):
                self._event_topic_by_token.pop(tok, None)

        return {"plugin_id": pid, "status": "unloaded"}

    def invoke_command(self, handler_id: int) -> Any:
        hid = int(handler_id)
        entry = self._command_handlers.get(hid)
        if entry is None:
            raise ValueError(f"unknown handler_id={hid}")
        plugin_id, fn = entry
        try:
            return fn()
        except Exception:
            self.notify(
                "host.log",
                {"plugin_id": plugin_id, "message": traceback.format_exc().rstrip()},
            )
            raise

    @staticmethod
    def _ensure_sys_path(root: Path) -> None:
        candidates: list[Path] = [root]

        wheels = root / "wheels"
        if wheels.is_dir():
            for whl in fs.glob_sorted(wheels, "*.whl", key=lambda p: p.name.lower()):
                candidates.insert(0, whl)

        code = root / "code"
        if code.is_dir():
            candidates.insert(0, code)
            code_src = code / "src"
            if code_src.is_dir():
                candidates.insert(0, code_src)

        src = root / "src"
        if src.is_dir():
            candidates.insert(0, src)
        for candidate in candidates:
            entry = str(candidate)
            if entry in sys.path:
                continue
            sys.path.insert(0, entry)

    def invoke_command_async(self, request_id: int, handler_id: int) -> None:
        hid = int(handler_id)
        entry = self._command_handlers.get(hid)
        if entry is None:
            self._send(
                jsonrpc.make_error(
                    request_id,
                    jsonrpc.JsonRpcError(-32602, f"unknown handler_id={hid}"),
                )
            )
            return
        plugin_id, fn = entry

        cancel_event = threading.Event()
        ctx = CommandContext(
            request_id=int(request_id),
            plugin_id=plugin_id,
            _cancel_event=cancel_event,
            _notify=self.notify,
        )

        fut = self._executor.submit(_call_command_handler, fn, ctx)
        self._pending_invoke[int(request_id)] = _PendingInvoke(
            plugin_id=plugin_id,
            future=fut,
            cancel_event=cancel_event,
            cancelled=False,
        )

        def _done(f: Future[Any], rid: int = int(request_id)) -> None:
            current = self._pending_invoke.pop(rid, None)
            if current is None:
                return
            if current.cancelled:
                return
            try:
                result = f.result()
                envelope = {
                    "result": result,
                    "trust": "plugin_derived",
                    "provenance": [
                        {
                            "source": "plugin",
                            "plugin_id": current.plugin_id,
                            "op": "commands.invoke",
                            "request_id": rid,
                        }
                    ],
                }
                self._send(jsonrpc.make_result(rid, envelope))
            except Exception as exc:
                if isinstance(exc, CommandCancelled):
                    self._send(
                        jsonrpc.make_error(
                            rid,
                            jsonrpc.JsonRpcError(-32800, "Request cancelled"),
                        )
                    )
                    return
                if isinstance(exc, PermissionError):
                    msg = str(exc).strip() or "Permission denied"
                    self.notify(
                        NOTIFY_LOG,
                        {
                            "plugin_id": current.plugin_id,
                            "message": f"policy blocked command: {msg}",
                        },
                    )
                    self._send(
                        jsonrpc.make_error(
                            rid,
                            jsonrpc.JsonRpcError(-32801, msg),
                        )
                    )
                    return
                msg = str(exc).strip() or "Command failed"
                self.notify(
                    NOTIFY_LOG,
                    {
                        "plugin_id": current.plugin_id,
                        "message": traceback.format_exc().rstrip(),
                    },
                )
                self._send(
                    jsonrpc.make_error(
                        rid,
                        jsonrpc.JsonRpcError(-32603, msg),
                    )
                )

        fut.add_done_callback(_done)

    def web_panel_call_async(
        self,
        request_id: int,
        handler_id: int,
        *,
        panel_id: str,
        method: str,
        params: Any,
    ) -> None:
        hid = int(handler_id)
        entry = self._web_panel_handlers.get(hid)
        if entry is None:
            self._send(
                jsonrpc.make_error(
                    request_id,
                    jsonrpc.JsonRpcError(-32602, f"unknown web handler_id={hid}"),
                )
            )
            return
        plugin_id, fn = entry

        pid = (panel_id or "").strip().lower()
        if not pid or not pid.startswith(f"{plugin_id}."):
            self._send(
                jsonrpc.make_error(
                    request_id,
                    jsonrpc.JsonRpcError(
                        -32602,
                        "web panel call rejected: panel_id not owned by handler plugin",
                    ),
                )
            )
            return
        tracked = self._web_panels_by_plugin.get(plugin_id, set())
        if pid not in tracked:
            self._send(
                jsonrpc.make_error(
                    request_id,
                    jsonrpc.JsonRpcError(
                        -32602,
                        "web panel call rejected: unknown panel_id for plugin",
                    ),
                )
            )
            return

        cancel_event = threading.Event()
        ctx = WebPanelContext(
            request_id=int(request_id),
            plugin_id=plugin_id,
            panel_id=pid,
            _cancel_event=cancel_event,
        )

        fut = self._executor.submit(_call_web_panel_handler, fn, method, params, ctx)
        self._pending_invoke[int(request_id)] = _PendingInvoke(
            plugin_id=plugin_id,
            future=fut,
            cancel_event=cancel_event,
            cancelled=False,
        )

        def _done(f: Future[Any], rid: int = int(request_id)) -> None:
            current = self._pending_invoke.pop(rid, None)
            if current is None:
                return
            if current.cancelled:
                return
            try:
                result = f.result()
                envelope = {
                    "result": result,
                    "trust": "plugin_derived",
                    "provenance": [
                        {
                            "source": "plugin",
                            "plugin_id": current.plugin_id,
                            "panel_id": ctx.panel_id,
                            "op": f"web_panel.{method}",
                            "request_id": rid,
                        }
                    ],
                }
                self._send(jsonrpc.make_result(rid, envelope))
            except Exception as exc:
                if isinstance(exc, CommandCancelled):
                    self._send(
                        jsonrpc.make_error(
                            rid,
                            jsonrpc.JsonRpcError(-32800, "Request cancelled"),
                        )
                    )
                    return
                if isinstance(exc, PermissionError):
                    msg = str(exc).strip() or "Permission denied"
                    self.notify(
                        NOTIFY_LOG,
                        {
                            "plugin_id": current.plugin_id,
                            "message": f"policy blocked web panel RPC: {msg}",
                        },
                    )
                    self._send(
                        jsonrpc.make_error(
                            rid,
                            jsonrpc.JsonRpcError(-32801, msg),
                        )
                    )
                    return
                msg = str(exc).strip() or "Web panel call failed"
                self.notify(
                    NOTIFY_LOG,
                    {
                        "plugin_id": current.plugin_id,
                        "message": traceback.format_exc().rstrip(),
                    },
                )
                self._send(
                    jsonrpc.make_error(
                        rid,
                        jsonrpc.JsonRpcError(-32603, msg),
                    )
                )

        fut.add_done_callback(_done)

    def cancel_request(self, request_id: int) -> bool:
        rid = int(request_id)
        entry = self._pending_invoke.get(rid)
        if entry is None:
            return False
        entry.cancelled = True
        try:
            entry.cancel_event.set()
        except Exception:
            pass
        try:
            entry.future.cancel()
        except Exception:
            pass
        self._send(
            jsonrpc.make_error(
                rid,
                jsonrpc.JsonRpcError(-32800, "Request cancelled"),
            )
        )
        self.notify(
            NOTIFY_LOG,
            {"plugin_id": entry.plugin_id, "message": f"cancelled request id={rid}"},
        )
        return True


def _call_event_handler(fn: Callable[..., None], topic: str, payload: Any) -> None:
    try:
        fn(topic, payload)
        return
    except TypeError as exc:
        msg = str(exc)
        if (
            "required positional argument" not in msg
            and "positional arguments" not in msg
        ):
            raise
        fn(payload)


def _call_command_handler(fn: Callable[..., Any], ctx: CommandContext) -> Any:
    # Prefer an explicit ctx parameter for long-running work (cooperative cancel).
    # Best-effort support for legacy handlers without ctx.
    import inspect

    try:
        sig = inspect.signature(fn)
        if len(sig.parameters) == 0:
            return fn()
        return fn(ctx)
    except (TypeError, ValueError):
        pass

    try:
        return fn(ctx)
    except TypeError as exc:
        msg = str(exc)
        if "positional" in msg or "argument" in msg:
            return fn()
        raise


def _call_web_panel_handler(
    fn: Callable[..., Any],
    method: str,
    params: Any,
    ctx: WebPanelContext,
) -> Any:
    try:
        return fn(method, params, ctx)
    except TypeError as exc:
        msg = str(exc)
        if "positional" not in msg and "argument" not in msg:
            raise
    try:
        return fn(method, params)
    except TypeError as exc:
        msg = str(exc)
        if "positional" not in msg and "argument" not in msg:
            raise
    try:
        return fn(params, ctx)
    except TypeError as exc:
        msg = str(exc)
        if "positional" not in msg and "argument" not in msg:
            raise
    try:
        return fn(params)
    except TypeError as exc:
        msg = str(exc)
        if "positional" not in msg and "argument" not in msg:
            raise
    try:
        return fn(ctx)
    except TypeError as exc:
        msg = str(exc)
        if "positional" in msg or "argument" in msg:
            return fn()
        raise


def main() -> int:
    protocol_in = sys.__stdin__.buffer

    # Make stdout sacred:
    # - Protocol bytes flow on a duplicated copy of the original stdout pipe.
    # - OS fd 1 is redirected to stderr so even os.write(1, ...) can't corrupt protocol.
    proto_fd = os.dup(1)
    try:
        os.dup2(2, 1)
    except Exception:
        pass
    protocol_out = os.fdopen(proto_fd, "wb", buffering=0)
    sys.stdout = sys.stderr
    sys.__stdout__ = sys.stderr

    runtime = _ExtensionHostRuntime(protocol_out=protocol_out)

    def _reply(request_id: int, result: Any) -> None:
        runtime._send(jsonrpc.make_result(request_id, result))

    def _reply_error(request_id: int | None, err: jsonrpc.JsonRpcError) -> None:
        runtime._send(jsonrpc.make_error(request_id, err))

    while True:
        try:
            msg = jsonrpc.read_frame(protocol_in)
        except jsonrpc.JsonRpcError as exc:
            _reply_error(None, exc)
            continue
        if msg is None:
            break

        method = msg.get("method")
        request_id = msg.get("id")
        params = msg.get("params", None)

        is_request = request_id is not None
        if not isinstance(method, str) or not method.strip():
            if is_request:
                _reply_error(
                    int(request_id),
                    jsonrpc.JsonRpcError(-32600, "Invalid Request"),
                )
            continue
        m = method.strip()

        try:
            if m == METHOD_HELLO:
                if is_request:
                    stall = _test_stall_hello_s()
                    if stall is not None:
                        time.sleep(float(stall))
                    _reply(
                        int(request_id),
                        {"protocol_version": PROTOCOL_VERSION, "python": sys.version},
                    )
                continue

            if m == METHOD_LOAD_PLUGINS:
                specs = []
                if isinstance(params, dict):
                    raw_specs = params.get("plugins", [])
                    if isinstance(raw_specs, list):
                        specs = [s for s in raw_specs if isinstance(s, dict)]
                loaded: list[dict[str, Any]] = []
                errors: list[dict[str, Any]] = []
                for spec in specs:
                    pid = str(spec.get("plugin_id") or "").strip().lower()
                    try:
                        loaded.append(runtime.load_plugin(spec))
                    except Exception as exc:
                        errors.append(
                            {
                                "plugin_id": pid or None,
                                "error": str(exc),
                                "traceback": traceback.format_exc(),
                            }
                        )
                if is_request:
                    _reply(int(request_id), {"loaded": loaded, "errors": errors})
                continue

            if m == METHOD_UNLOAD_PLUGINS:
                ids: list[str] = []
                if isinstance(params, dict):
                    raw_ids = params.get("plugin_ids", [])
                    if isinstance(raw_ids, list):
                        ids = [str(x) for x in raw_ids]
                results = [runtime.unload_plugin(x) for x in ids]
                if is_request:
                    _reply(int(request_id), {"results": results})
                continue

            if m == METHOD_INVOKE_COMMAND:
                if not is_request:
                    continue
                hid = None
                if isinstance(params, dict):
                    hid = params.get("handler_id")
                runtime.invoke_command_async(int(request_id), int(hid))  # type: ignore[arg-type]
                continue

            if m == METHOD_WEB_PANEL_CALL:
                if not is_request:
                    continue
                hid = None
                panel_id = ""
                call_method = ""
                call_params = None
                if isinstance(params, dict):
                    hid = params.get("handler_id")
                    panel_id = str(params.get("panel_id") or "")
                    call_method = str(params.get("method") or "")
                    call_params = params.get("params")
                runtime.web_panel_call_async(
                    int(request_id),
                    int(hid),  # type: ignore[arg-type]
                    panel_id=panel_id,
                    method=call_method,
                    params=call_params,
                )
                continue

            if m == METHOD_EVENTS_EMIT:
                topic = ""
                payload = None
                if isinstance(params, dict):
                    topic = str(params.get("topic") or "")
                    payload = params.get("payload")
                runtime.emit_local_event(topic, payload)
                if is_request:
                    _reply(int(request_id), {"ok": True})
                continue

            if m == METHOD_CANCEL:
                rid = None
                if isinstance(params, dict):
                    rid = params.get("request_id")
                if rid is not None:
                    runtime.cancel_request(int(rid))
                if is_request:
                    _reply(int(request_id), {"ok": True})
                continue

            if m == METHOD_SHUTDOWN:
                if is_request:
                    _reply(int(request_id), {"ok": True})
                try:
                    runtime._executor.shutdown(wait=False)
                except Exception:
                    pass
                return 0

            if is_request:
                _reply_error(
                    int(request_id),
                    jsonrpc.JsonRpcError(-32601, "Method not found"),
                )
        except jsonrpc.JsonRpcError as exc:
            if is_request:
                _reply_error(int(request_id), exc)
        except Exception:
            if is_request:
                _reply_error(
                    int(request_id),
                    jsonrpc.JsonRpcError(
                        -32603,
                        "Internal error",
                        traceback.format_exc(),
                    ),
                )
            else:
                runtime.notify(
                    NOTIFY_LOG,
                    {"plugin_id": "host", "message": traceback.format_exc().rstrip()},
                )

    try:
        runtime._executor.shutdown(wait=False)
    except Exception:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
