from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from helix import __version__
from helix import clock
from helix.provenance import current_git_sha
from helix.studio.models import EngineInfo, OutcomeModel, RunModel
from helix.studio.run_artifact import (
    build_run_artifact_from_run_model,
    artifact_decision_mode_eligible,
)
from helix.studio.experiment_spec import experiment_spec_sha256, experiment_spec_to_dict
from helix.studio.experiment_intent_spec import experiment_intent_spec_sha256, experiment_intent_spec_to_dict
from helix.studio.edit_plan import edit_plan_sha256, edit_plan_to_dict
from helix.studio.governance_stamp import export_watermark_label, governance_stamp_lines
from helix.studio.limitations import limitations_stamp
from helix.studio.export_labels import build_governance_provenance
from helix.studio.cli_session_contract_stamp import CLI_SESSION_CONTRACT_HASH, CLI_SESSION_CONTRACT_ID
from helix.studio.png_provenance import build_png_provenance_v1, write_png_provenance_sidecar
from helix.studio.provenance_header import build_provenance_header_v1
from helix.studio.session import SessionModel


def export_payload_for_run(
    run: RunModel,
    *,
    governance_signing: bool = False,
    experiment_intent_spec: Mapping[str, Any] | None = None,
    experiment_spec: Mapping[str, Any] | None = None,
    edit_plan: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the minimal export payload (schema + run + metadata)."""

    stamp = limitations_stamp()
    meta = run.metadata if isinstance(run.metadata, Mapping) else {}
    run_summary_v2 = meta.get("run_summary") if isinstance(meta.get("run_summary"), Mapping) else None
    artifact = meta.get("run_artifact") if isinstance(meta, Mapping) else None
    if not isinstance(artifact, Mapping):
        artifact = build_run_artifact_from_run_model(run)
    decision_mode_requested = (
        str(artifact.get("decision_mode") or "filter_only") if isinstance(artifact, Mapping) else "filter_only"
    )
    decision_mode_eligible = artifact_decision_mode_eligible(artifact) if isinstance(artifact, Mapping) else False
    effective_mode = "decision_grade" if (decision_mode_requested == "decision_grade" and decision_mode_eligible) else "filter_only"
    from helix.governance.gates import require_decision_grade_signing

    require_decision_grade_signing(
        decision_mode=effective_mode,
        governance_signing=bool(governance_signing),
        run_id=str(getattr(run, "run_id", "") or ""),
        surface="run_export_json",
    )
    value_label = "probability" if effective_mode == "decision_grade" else "score"
    interpretation = "decision_grade" if effective_mode == "decision_grade" else "exploratory_uncalibrated"
    payload: dict[str, Any] = {
        "schema": {"kind": "helix.export.v1", "version": 1},
        "exported_at_utc": clock.utc_now_iso(),
        "helix_version": __version__,
        "decision_mode": effective_mode,
        "interpretation": interpretation,
        "outcome_value_label": value_label,
        "limitations": stamp,
        "run": run.to_dict(),
        "run_artifact": artifact,
    }
    prov_header, prov_block = build_provenance_header_v1(decision_mode=effective_mode, run_summary_v2=run_summary_v2)
    payload["provenance_header"] = prov_header
    payload["provenance_block"] = prov_block
    if isinstance(prov_block, dict):
        prov_block.setdefault("contract_id", CLI_SESSION_CONTRACT_ID)
        prov_block.setdefault("contract_hash", CLI_SESSION_CONTRACT_HASH)
    if isinstance(experiment_intent_spec, Mapping):
        intent_payload = experiment_intent_spec_to_dict(experiment_intent_spec)
        payload["experiment_intent_spec"] = intent_payload
        payload["experiment_intent_spec_sha256"] = experiment_intent_spec_sha256(intent_payload)
    if isinstance(experiment_spec, Mapping):
        spec_payload = experiment_spec_to_dict(experiment_spec)
        payload["experiment_spec"] = spec_payload
        payload["experiment_spec_sha256"] = experiment_spec_sha256(spec_payload)
    if isinstance(edit_plan, Mapping):
        plan_payload = edit_plan_to_dict(edit_plan)
        payload["edit_plan"] = plan_payload
        payload["edit_plan_sha256"] = edit_plan_sha256(plan_payload)
    return payload


def export_run_artifacts(
    run: RunModel,
    out_dir: str | Path,
    *,
    governance_signing: bool = False,
    experiment_intent_spec: Mapping[str, Any] | None = None,
    experiment_spec: Mapping[str, Any] | None = None,
    edit_plan: Mapping[str, Any] | None = None,
) -> tuple[Path, Path]:
    """Write `<run_id>.export.json` + `<run_id>.export.png` into `out_dir`."""

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    run_id = str(run.run_id).strip() or "run"
    payload = export_payload_for_run(
        run,
        governance_signing=governance_signing,
        experiment_intent_spec=experiment_intent_spec,
        experiment_spec=experiment_spec,
        edit_plan=edit_plan,
    )

    json_path = out / f"{run_id}.export.json"
    json_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    png_path = out / f"{run_id}.export.png"
    value_label = str(payload.get("outcome_value_label") or "score")
    x_label = "Probability" if value_label == "probability" else "Score (exploratory, uncalibrated)"
    decision_mode = str(payload.get("decision_mode") or "filter_only")
    interpretation = str(payload.get("interpretation") or "")
    artifact = payload.get("run_artifact") if isinstance(payload.get("run_artifact"), Mapping) else None
    proof = artifact.get("decision_grade_proof") if isinstance(artifact, Mapping) else None
    wm_lines = governance_stamp_lines(
        decision_mode=decision_mode,
        interpretation=interpretation,
        decision_grade_proof=proof if isinstance(proof, Mapping) else None,
    )
    meta = run.metadata if isinstance(run.metadata, Mapping) else {}
    is_demo = bool(str(meta.get("scenario") or "").strip().lower() == "demo")
    gov_payload = build_governance_provenance(
        decision_mode=decision_mode,
        is_demo=is_demo,
        interpretation=interpretation,
        decision_grade_proof=(dict(proof) if isinstance(proof, Mapping) else None),
    )
    gov_payload["stamp_lines"] = list(wm_lines)
    _write_run_png(
        run,
        png_path,
        stamp=payload.get("limitations"),
        x_label=x_label,
        watermark_text=export_watermark_label(decision_mode=decision_mode, is_demo=is_demo),
        watermark_lines=wm_lines,
        governance_payload=gov_payload,
    )

    # Always emit a lightweight provenance sidecar for the exported PNG.
    try:
        sidecar_payload = build_png_provenance_v1(
            png_path=png_path,
            artifact_surface="run_export",
            run_id=run_id,
            governance=gov_payload,
            limitations_stamp=payload.get("limitations") if isinstance(payload.get("limitations"), Mapping) else None,
            embedded_png_text_chunks_present=True,
        )
        write_png_provenance_sidecar(png_path, sidecar_payload)
    except Exception:
        # Exporting a PNG without a provenance sidecar defeats chain-of-custody.
        raise

    # Optional: persist species_detection_v1 if present in metadata.
    meta = run.metadata if isinstance(run.metadata, Mapping) else {}
    species_payload = meta.get("species_detection") if isinstance(meta.get("species_detection"), Mapping) else None
    species_path = meta.get("species_detection_path") or meta.get("species_detection_file")
    out_species_path = out / f"{run_id}.species_detection_v1.json"
    if isinstance(species_payload, Mapping) and str(species_payload.get("schema") or "") == "species_detection_v1":
        out_species_path.write_text(json.dumps(species_payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    elif isinstance(species_path, str) and species_path.strip():
        try:
            src = Path(species_path)
            if src.exists():
                out_species_path.write_bytes(src.read_bytes())
        except Exception:
            pass
    return json_path, png_path


def export_run_from_session(session: SessionModel, run_id: str, out_dir: str | Path) -> tuple[Path, Path]:
    run = session.get_run_by_id(run_id)
    if run is None:
        available = ", ".join([str(r.run_id) for r in getattr(session, "runs", [])])
        raise RuntimeError(f"Run '{run_id}' not found in session. Available run_ids: {available or '<none>'}")
    spec = session.state.experiment_spec if isinstance(session.state.experiment_spec, Mapping) else None
    intent = session.state.experiment_intent_spec if isinstance(session.state.experiment_intent_spec, Mapping) else None
    plan = session.state.edit_plan if isinstance(session.state.edit_plan, Mapping) else None
    return export_run_artifacts(run, out_dir, experiment_intent_spec=intent, experiment_spec=spec, edit_plan=plan)


def run_model_from_snapshot(snapshot: Mapping[str, Any]) -> RunModel:
    """Best-effort conversion for legacy UI snapshots without a `runs` block."""

    state = snapshot.get("state", snapshot)
    config = state.get("config", {}) if isinstance(state.get("config"), Mapping) else {}
    run_cfg = config.get("run_config", {}) if isinstance(config.get("run_config"), Mapping) else {}
    guide = config.get("guide", {}) if isinstance(config.get("guide"), Mapping) else {}
    sim_payload = config.get("sim_payload", {}) if isinstance(config.get("sim_payload"), Mapping) else {}

    outcomes_raw = state.get("outcomes") or sim_payload.get("outcomes") or []
    if not isinstance(outcomes_raw, list):
        outcomes_raw = []

    outcomes = [
        OutcomeModel.from_dict(o) if isinstance(o, Mapping) else OutcomeModel(name=str(o), category="", prob=0.0)
        for o in outcomes_raw
    ]

    site = sim_payload.get("site") if isinstance(sim_payload.get("site"), Mapping) else {}
    sequence = str(site.get("sequence") or sim_payload.get("sequence") or state.get("sequence") or "")

    meta = dict(config.get("metadata", {}) or {}) if isinstance(config.get("metadata"), Mapping) else {}
    meta.setdefault("helix_version", __version__)
    sha = current_git_sha()
    if sha is not None:
        meta.setdefault("git_sha", sha)
    if isinstance(state.get("species_detection"), Mapping):
        meta.setdefault("species_detection", dict(state.get("species_detection") or {}))
    if isinstance(state.get("species_detection_path"), str):
        meta.setdefault("species_detection_path", state.get("species_detection_path"))
    if "seed" in run_cfg:
        try:
            meta.setdefault("seed", int(run_cfg.get("seed")))
        except Exception:
            pass
    if "draws" in run_cfg:
        try:
            meta.setdefault("draws", int(run_cfg.get("draws")))
        except Exception:
            pass

    backend = str(run_cfg.get("backend") or state.get("engine_backend") or "cpu-reference")
    engine = EngineInfo(
        name=str(state.get("engine_name") or "helix_studio"),
        backend=backend,
        crispr_scoring_version=state.get("crispr_scoring_version"),
        prime_scoring_version=state.get("prime_scoring_version"),
        backend_reason=run_cfg.get("backend_reason") if isinstance(run_cfg, Mapping) else state.get("engine_backend_reason"),
    )

    return RunModel(
        run_id=str(state.get("run_id", "run")),
        guide_id=str(guide.get("id", "guide")),
        edit_type=str(state.get("run_kind", config.get("sim_type", "crispr"))),
        sequence=sequence,
        target_locus=str(guide.get("locus", "")),
        pam_index=guide.get("pam_index"),
        cut_index=guide.get("cut_index"),
        outcomes=outcomes,
        physics=dict(sim_payload.get("physics_score", {}) or {}) if isinstance(sim_payload.get("physics_score"), Mapping) else {},
        engine=engine,
        metadata=meta,
    )


def _write_run_png(
    run: RunModel,
    out_path: Path,
    *,
    stamp: Mapping[str, Any] | None = None,
    x_label: str = "Score (exploratory, uncalibrated)",
    watermark_text: str | None = None,
    watermark_lines: list[str] | None = None,
    governance_payload: Mapping[str, Any] | None = None,
) -> None:
    """Write a simple outcomes bar chart PNG (best-effort)."""

    # Minimal valid 1x1 PNG fallback (RGBA, transparent).
    fallback_png = (
        b"\x89PNG\r\n\x1a\n"
        b"\x00\x00\x00\rIHDR"
        b"\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x06\x00\x00\x00"
        b"\x1f\x15\xc4\x89"
        b"\x00\x00\x00\x0cIDAT"
        b"\x08\xd7c\xf8\xff\xff?\x00\x05\xfe\x02\xfe"
        b"\xa7\x9e\x1d\x1b"
        b"\x00\x00\x00\x00IEND\xaeB`\x82"
    )

    try:
        import matplotlib

        matplotlib.use("Agg")  # headless-safe
        import matplotlib.pyplot as plt

        labels = [o.name for o in run.outcomes]
        probs = [float(o.prob) for o in run.outcomes]
        if not labels:
            out_path.write_bytes(fallback_png)
            return

        fig, ax = plt.subplots(figsize=(8, max(2.0, 0.4 * len(labels))))
        ax.barh(labels, probs, color=(0.31, 0.49, 1.0))
        ax.set_xlabel(str(x_label or "Score"))
        ax.set_xlim(0.0, 1.0)
        ax.invert_yaxis()
        fig.tight_layout()

        wm_text = str(watermark_text or "").strip()
        wm_lines = [str(l) for l in (watermark_lines or []) if str(l).strip()]
        if wm_text:
            try:
                fig.text(
                    0.5,
                    0.5,
                    wm_text,
                    ha="center",
                    va="center",
                    fontsize=42,
                    rotation=30,
                    color="black",
                    alpha=0.12,
                    zorder=0,
                )
                fig.text(
                    0.99,
                    0.01,
                    wm_text,
                    ha="right",
                    va="bottom",
                    fontsize=8,
                    rotation=0,
                    color="black",
                    alpha=0.35,
                    zorder=3,
                )
            except Exception:
                pass
        if wm_lines:
            try:
                fig.text(
                    0.01,
                    0.01,
                    "\n".join(wm_lines),
                    ha="left",
                    va="bottom",
                    fontsize=6,
                    color="black",
                    alpha=0.85,
                    zorder=3,
                )
            except Exception:
                pass
        metadata = None
        if stamp or governance_payload:
            try:
                meta_obj: dict[str, str] = {}
                if stamp:
                    meta_obj["helix_limitations"] = json.dumps(stamp, sort_keys=True)
                if governance_payload:
                    meta_obj["helix_governance"] = json.dumps(dict(governance_payload), sort_keys=True)
                else:
                    meta_obj["helix_governance"] = json.dumps({"watermark": wm_text, "stamp_lines": wm_lines}, sort_keys=True)
                metadata = meta_obj
            except Exception:
                metadata = None
        fig.savefig(out_path, dpi=150, metadata=metadata)
        plt.close(fig)
    except Exception:
        out_path.write_bytes(fallback_png)


__all__ = [
    "export_payload_for_run",
    "export_run_artifacts",
    "export_run_from_session",
    "run_model_from_snapshot",
]
