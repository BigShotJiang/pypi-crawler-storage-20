from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping, Sequence

try:
    from typing import Protocol
except ImportError:  # pragma: no cover - Python <3.8 fallback
    Protocol = object  # type: ignore


class StageKind(str, Enum):
    GENOME_CONTEXT = "genome_context"
    EDIT_PLAN = "edit_plan"
    PERTURBATIONS = "perturbations"
    OUTCOME_MODEL = "outcome_model"
    EVIDENCE = "evidence"
    CLAIMS = "claims"
    UNKNOWN = "unknown"


class CacheState(str, Enum):
    CLEAN = "clean"
    DIRTY = "dirty"
    COMPUTING = "computing"
    UNSUPPORTED = "unsupported"
    ERROR = "error"


class RecomputeResult(str, Enum):
    CACHE_HIT = "cache_hit"
    CHANGED = "changed"
    FAILED = "failed"
    DROPPED_STALE = "dropped_stale"


@dataclass(frozen=True)
class RailSelection:
    branch_id: str
    segment_id: str


@dataclass(frozen=True)
class RailSegment:
    segment_id: str
    kind: StageKind
    name: str
    input_hash: str
    output_hash: str | None
    cache_state: CacheState
    backend: str | None = None
    determinism: str | None = None
    duration_ms: float | None = None  # last attempt duration
    artifact_count: int | None = None
    parents: tuple[str, ...] = field(default_factory=tuple)
    branch_id: str = "trunk"
    metadata: Mapping[str, Any] = field(default_factory=dict)
    last_recompute_result: RecomputeResult | None = None
    last_compute_ts: float | None = None
    last_success_duration_ms: float | None = None
    last_success_ts: float | None = None
    last_result_reason: str | None = None

    def summary(self) -> Mapping[str, Any]:
        return {
            "segment_id": self.segment_id,
            "kind": self.kind.value,
            "branch_id": self.branch_id,
            "cache_state": self.cache_state.value,
            "input_hash": self.input_hash,
            "output_hash": self.output_hash,
            "backend": self.backend,
            "determinism": self.determinism,
            "duration_ms": self.duration_ms,
            "artifact_count": self.artifact_count,
        }


@dataclass(frozen=True)
class RailGraph:
    segments: Mapping[str, RailSegment]
    order: tuple[str, ...]
    branches: tuple[str, ...] = ("trunk",)

    def ordered_segments(self) -> list[RailSegment]:
        return [self.segments[sid] for sid in self.order if sid in self.segments]

    def get(self, segment_id: str) -> RailSegment | None:
        return self.segments.get(segment_id)

    def downstream(self, segment_id: str) -> list[RailSegment]:
        """Return a stable list of downstream segments (including children of branches)."""
        seen = set()
        out: list[RailSegment] = []
        parent = segment_id
        for sid in self.order:
            seg = self.segments.get(sid)
            if seg is None or sid == segment_id:
                if seg is not None:
                    seen.add(sid)
                continue
            if parent in seg.parents:
                out.append(seg)
                seen.add(sid)
                parent = sid
        return out

    def replace_segment(self, segment: RailSegment) -> "RailGraph":
        segs = dict(self.segments)
        segs[segment.segment_id] = segment
        return RailGraph(segments=segs, order=self.order, branches=self.branches)


def _json_default(obj: Any) -> str:
    try:
        return obj.__dict__  # type: ignore[attr-defined]
    except Exception:
        return repr(obj)


def stable_hash(payload: Mapping[str, Any] | Sequence[Any] | str | bytes | None) -> str:
    """Stable hash helper for mixed payloads (order-insensitive for mappings)."""
    if payload is None:
        payload = "null"
    if isinstance(payload, bytes):
        data = payload
    else:
        try:
            data = json.dumps(payload, sort_keys=True, default=_json_default).encode("utf-8")
        except TypeError:
            # Fallback to string repr if object is not JSON serializable.
            data = repr(payload).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _cap(value: float | None, *, max_ms: float = 10_000.0) -> float | None:
    if value is None:
        return None
    return float(min(value, max_ms))


def build_graph_from_session(state: Any) -> RailGraph:
    """Project the session into a linear rail graph.

    The projection is intentionally forgiving: absent pieces become DIRTY/UNSUPPORTED
    but the rails still render, so the UI always has a spine to hang context on.
    """

    try:
        viz_dirty = bool(getattr(state, "viz_dirty", False))
    except Exception:
        viz_dirty = True

    genome_hash = getattr(state, "genome_hash", None) or stable_hash(getattr(state, "genome", None))
    edit_plan = getattr(state, "edit_plan", None)
    plan_hash = stable_hash(edit_plan)
    perturbations = getattr(state, "calibration_profiles", None) or getattr(state, "apply_history", None)
    perturb_hash = stable_hash(perturbations)
    dag = getattr(state, "dag", None) if hasattr(state, "dag") else getattr(state, "dag_from_runtime", None)
    outcomes = getattr(state, "outcomes", None)
    outcome_hash = stable_hash(outcomes or dag)
    evidence = getattr(state, "results_records", None) or getattr(state, "viz_spec_payload", None)
    evidence_hash = stable_hash(evidence)

    segments: list[RailSegment] = []

    cfg = getattr(state, "config", None)
    meta = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
    preset_id = str(meta.get("preset_id") or "").strip().lower()
    scenario = str(meta.get("scenario") or "").strip().lower()
    is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))

    segments.append(
        RailSegment(
            segment_id="genome",
            kind=StageKind.GENOME_CONTEXT,
            name="Genome Context",
            input_hash=genome_hash,
            output_hash=genome_hash,
            cache_state=CacheState.CLEAN if genome_hash else CacheState.DIRTY,
            backend=None,
            determinism="deterministic",
            duration_ms=None,
            artifact_count=1 if genome_hash else 0,
            parents=(),
        )
    )

    segments.append(
        RailSegment(
            segment_id="edit_plan",
            kind=StageKind.EDIT_PLAN,
            name="Edit Plan",
            input_hash=genome_hash,
            output_hash=plan_hash,
            cache_state=CacheState.CLEAN if edit_plan else CacheState.DIRTY,
            backend=None,
            determinism="deterministic",
            duration_ms=None,
            artifact_count=len(edit_plan or {}),
            parents=("genome",),
        )
    )

    segments.append(
        RailSegment(
            segment_id="perturbations",
            kind=StageKind.PERTURBATIONS,
            name="Perturbations",
            input_hash=plan_hash,
            output_hash=perturb_hash,
            cache_state=CacheState.CLEAN if perturbations else CacheState.UNSUPPORTED,
            backend=None,
            determinism="deterministic",
            duration_ms=None,
            artifact_count=len(perturbations) if hasattr(perturbations, "__len__") else None,
            parents=("edit_plan",),
        )
    )

    segments.append(
        RailSegment(
            segment_id="outcome_model",
            kind=StageKind.OUTCOME_MODEL,
            name="Outcome Model",
            input_hash=perturb_hash,
            output_hash=outcome_hash,
            cache_state=CacheState.DIRTY if viz_dirty else CacheState.CLEAN,
            backend=_infer_backend(state),
            determinism=_infer_determinism(state),
            duration_ms=_cap(_extract_duration(state)),
            artifact_count=len(outcomes or []) if hasattr(outcomes, "__len__") else None,
            parents=("perturbations",),
        )
    )

    segments.append(
        RailSegment(
            segment_id="evidence",
            kind=StageKind.EVIDENCE,
            name="Evidence Aggregation",
            input_hash=outcome_hash,
            output_hash=evidence_hash,
            cache_state=CacheState.CLEAN if evidence else CacheState.DIRTY,
            backend=None,
            determinism="deterministic",
            duration_ms=None,
            artifact_count=len(evidence) if hasattr(evidence, "__len__") else None,
            parents=("outcome_model",),
        )
    )

    segments.append(
        RailSegment(
            segment_id="claims",
            kind=StageKind.CLAIMS,
            name="Claims",
            input_hash=evidence_hash,
            output_hash=stable_hash({"claims": evidence_hash}),
            cache_state=CacheState.UNSUPPORTED if is_demo else CacheState.DIRTY,
            backend=None,
            determinism="deterministic",
            duration_ms=None,
            artifact_count=None,
            parents=("evidence",),
            metadata=(
                {
                    "ui_state_label": "Disabled (demo)" if is_demo else "",
                    "ui_reason": "Claims evaluation is disabled in demo mode (decision-grade only)."
                    if is_demo
                    else "",
                }
                if is_demo
                else {}
            ),
        )
    )

    order = tuple(seg.segment_id for seg in segments)
    return RailGraph(segments={s.segment_id: s for s in segments}, order=order)


def _infer_backend(state: Any) -> str | None:
    try:
        engine = getattr(state, "engine", None)
        return getattr(engine, "backend", None)
    except Exception:
        return None


def _infer_determinism(state: Any) -> str | None:
    try:
        policy = getattr(state, "config", {}).get("determinism")
        return str(policy) if policy is not None else "deterministic"
    except Exception:
        return None


def _extract_duration(state: Any) -> float | None:
    try:
        summary = getattr(state, "run_summary", None)
        if summary and isinstance(summary, Mapping):
            dur = summary.get("duration_ms") or summary.get("durationMs")
            return float(dur) if dur is not None else None
    except Exception:
        return None
    return None
