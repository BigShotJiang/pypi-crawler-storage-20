from __future__ import annotations

import importlib
import sys

from helix import __version__


def _print_stub_help() -> None:
    text = f"""Helix Studio (GUI)

Requires GUI dependencies.

Install:
  python -m pip install "helix-governance[studio]"

Then run:
  helix-studio

Version: {__version__}
"""
    print(text.rstrip("\n"))


def _load_app_main():
    mod = importlib.import_module("helix.studio.app")
    return getattr(mod, "main")


def main(argv: list[str] | None = None) -> None:
    args = list(sys.argv[1:] if argv is None else argv)
    wants_help = any(a in {"-h", "--help"} for a in args)
    wants_version = any(a in {"--version"} for a in args)

    if wants_version:
        print(__version__)
        return

    try:
        app_main = _load_app_main()
    except ModuleNotFoundError as exc:
        missing = (exc.name or "").split(".", 1)[0]
        if missing in {"PySide6", "shiboken6"}:
            _print_stub_help()
            if wants_help:
                return
            raise SystemExit(2)
        raise

    app_main(args)
