from __future__ import annotations

from typing import Dict

from PySide6.QtCore import Qt, QTimer, QPoint, QRect
from PySide6.QtCore import QSettings
from PySide6.QtGui import QGuiApplication, QKeyEvent, QAction
from PySide6.QtWidgets import QGraphicsDropShadowEffect
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QToolButton,
    QWidget,
    QMenu,
    QFormLayout,
    QVBoxLayout,
    QLineEdit,
    QToolTip,
)

from .rail_model import CacheState, RailGraph, RailSegment, RailSelection, RecomputeResult, StageKind
from .rail_state import RailStateStore, with_selection
from .spinner_frames import SPINNER_FRAMES


class InspectorPopover(QWidget):
    """Anchored popover for segment inspection."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent, Qt.Popup | Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self._frame = QFrame(self)
        self._frame.setObjectName("InspectorFrame")
        self._frame.setProperty("role", "panel")
        self._frame.setAttribute(Qt.WA_StyledBackground, True)
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(18)
        shadow.setOffset(0, 4)
        shadow.setColor(Qt.black)
        self._frame.setGraphicsEffect(shadow)

        self._layout = QFormLayout()
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._frame.setLayout(self._layout)
        self.setLayout(QVBoxLayout())
        self.layout().setContentsMargins(0, 0, 0, 0)
        self.layout().addWidget(self._frame)

    def set_data(self, seg: RailSegment, repro: str) -> None:
        def add(label: str, value: str) -> None:
            edit = QLineEdit(value)
            edit.setReadOnly(True)
            edit.setCursorPosition(0)
            self._layout.addRow(label, edit)

        self._clear_rows()
        add("Stage", seg.kind.value)
        add("Backend", seg.backend or "n/a")
        add("Determinism", seg.determinism or "n/a")
        add("Input hash", seg.input_hash or "n/a")
        add("Output hash", seg.output_hash or "n/a")
        last_attempt = (
            "Dropped (stale)"
            if seg.last_recompute_result is RecomputeResult.DROPPED_STALE
            else (seg.last_recompute_result.value if seg.last_recompute_result else "n/a")
        )
        add("Last attempt", last_attempt)
        if seg.last_result_reason and seg.last_recompute_result is RecomputeResult.DROPPED_STALE:
            add("Why", seg.last_result_reason)
        add("Attempt finished", _format_ts(seg.last_compute_ts))
        add("Attempt duration", f"{seg.duration_ms:.0f} ms" if seg.duration_ms is not None else "n/a")
        add("Last success", _format_ts(seg.last_success_ts))
        add("Success duration", f"{seg.last_success_duration_ms:.0f} ms" if seg.last_success_duration_ms is not None else "none")
        add("Repro command", repro)

    def show_at(self, global_pos: QPoint) -> None:
        self.adjustSize()
        # Position to the right of the anchor with small offset; clamp to screen.
        geo = self.frameGeometry()
        rect = QRect(global_pos, geo.size())
        screen = QGuiApplication.primaryScreen().availableGeometry()
        x = min(rect.x(), screen.right() - geo.width())
        y = min(rect.y(), screen.bottom() - geo.height())
        self.move(max(screen.left(), x - geo.width() + 10), max(screen.top(), y))
        self.show()

    def focusOutEvent(self, event) -> None:  # type: ignore[override]
        self.close()
        super().focusOutEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # type: ignore[override]
        if event.key() in (Qt.Key_Escape,):
            self.close()
            return
        super().keyPressEvent(event)

    def _clear_rows(self) -> None:
        while self._layout.rowCount():
            self._layout.removeRow(0)


class RailSegmentButton(QToolButton):
    def __init__(self, segment: RailSegment, store: RailStateStore, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._segment_id = segment.segment_id
        self._store = store
        self._spinner_idx: int = 0
        self._active_chain_id: str | None = None
        self._chain_stage: str | None = None
        self._chain_idx: int = 0
        self._chain_total: int = 0
        self.setObjectName("RailSegmentButton")
        self.setCheckable(True)
        self.setAutoExclusive(True)
        self.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self._apply_segment(segment)
        self.clicked.connect(with_selection(store, segment_id=segment.segment_id))

    def segment_id(self) -> str:
        return self._segment_id

    def update_segment(self, segment: RailSegment) -> None:
        self._apply_segment(segment)

    def set_chain_progress(self, chain_id: str | None, chain_stage: str | None, idx: int, total: int) -> None:
        self._active_chain_id = chain_id
        self._chain_stage = chain_stage
        self._chain_idx = idx
        self._chain_total = total

    def set_spinner_idx(self, idx: int) -> None:
        self._spinner_idx = idx

    # --- internals --------------------------------------------------

    def _apply_segment(self, segment: RailSegment) -> None:
        state = segment.cache_state.value.replace("_", " ").title()
        try:
            meta = segment.metadata if isinstance(segment.metadata, dict) else dict(segment.metadata or {})
            override = meta.get("ui_state_label")
            if isinstance(override, str) and override.strip():
                state = override.strip()
        except Exception:
            pass
        spinner = ""
        if segment.cache_state is CacheState.COMPUTING:
            spinner = f"{SPINNER_FRAMES[self._spinner_idx % len(SPINNER_FRAMES)]} "
        recompute_tag = ""
        if segment.last_recompute_result is RecomputeResult.CACHE_HIT:
            recompute_tag = " · Hit"
        elif segment.last_recompute_result is RecomputeResult.CHANGED:
            recompute_tag = " · Changed"
        elif segment.last_recompute_result is RecomputeResult.FAILED:
            recompute_tag = " · Failed"
        elif segment.last_recompute_result is RecomputeResult.DROPPED_STALE:
            recompute_tag = " · Dropped"
        progress = ""
        if (
            self._active_chain_id
            and self._chain_stage == segment.segment_id
            and segment.cache_state is CacheState.COMPUTING
            and self._chain_total > 0
        ):
            progress = f" ({self._chain_idx}/{self._chain_total})"
        self.setText(f"{segment.name}\n{spinner}{state}{progress}{recompute_tag}")
        try:
            self.setProperty("cache", segment.cache_state.value)
            self.setProperty("stage", segment.kind.value)
        except Exception:
            pass
        try:
            style = self.style()
            style.unpolish(self)
            style.polish(self)
            self.update()
        except Exception:
            pass
        tip_lines = [f"Kind: {segment.kind.value}", f"Input hash: {segment.input_hash}"]
        if segment.output_hash:
            tip_lines.append(f"Output hash: {segment.output_hash}")
        if segment.backend:
            tip_lines.append(f"Backend: {segment.backend}")
        if segment.determinism:
            tip_lines.append(f"Determinism: {segment.determinism}")
        if segment.artifact_count is not None:
            tip_lines.append(f"Artifacts: {segment.artifact_count}")
        if segment.last_recompute_result is not None:
            label = "Last attempt: "
            if segment.last_recompute_result is RecomputeResult.DROPPED_STALE:
                label = "Last attempt: Dropped (stale)"
            else:
                label += segment.last_recompute_result.value
            tip_lines.append(label)
        if segment.duration_ms is not None:
            tip_lines.append(f"Attempt duration: {segment.duration_ms:.0f} ms")
        if segment.last_compute_ts is not None:
            tip_lines.append(f"Attempt finished: {_format_ts(segment.last_compute_ts)}")
        if segment.last_success_ts is not None:
            tip_lines.append(f"Last success: {_format_ts(segment.last_success_ts)} ({segment.last_success_duration_ms or 'n/a'} ms)")
        else:
            tip_lines.append("Last success: none")
        if segment.last_result_reason and segment.last_recompute_result is RecomputeResult.DROPPED_STALE:
            tip_lines.append(f"Why: {segment.last_result_reason}")
        try:
            meta = segment.metadata if isinstance(segment.metadata, dict) else dict(segment.metadata or {})
            note = meta.get("ui_reason")
            if isinstance(note, str) and note.strip():
                tip_lines.append(f"Note: {note.strip()}")
        except Exception:
            pass
        self.setToolTip("\n".join(tip_lines))

    # Double-click to request recompute from this node forward.
    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        try:
            self._store.request_recompute_from(self._segment_id)
        except Exception:
            pass
        super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event) -> None:  # type: ignore[override]
        menu = QMenu(self)
        recompute_here = QAction("Recompute from here", self)
        recompute_downstream = QAction("Recompute downstream", self)
        inspector = QAction("Open inspector", self)
        copy_input = QAction("Copy input hash", self)
        copy_output = QAction("Copy output hash", self)
        copy_repro = QAction("Copy repro command", self)

        recompute_here.triggered.connect(lambda: self._store.request_recompute_from(self._segment_id))
        recompute_downstream.triggered.connect(lambda: self._store.request_recompute_downstream(self._segment_id))
        inspector.triggered.connect(self._show_inspector)
        copy_input.triggered.connect(lambda: self._copy_hash(kind="input"))
        copy_output.triggered.connect(lambda: self._copy_hash(kind="output"))
        copy_repro.triggered.connect(self._copy_repro_command)

        for act in (recompute_here, recompute_downstream, inspector, copy_input, copy_output, copy_repro):
            menu.addAction(act)
        menu.exec(event.globalPos())

    # --- helpers --------------------------------------------------
    def _segment(self) -> RailSegment | None:
        graph = getattr(self._store, "graph", None)
        return graph.get(self._segment_id) if graph else None  # type: ignore[union-attr]

    def _show_inspector(self) -> None:
        seg = self._segment()
        if seg is None:
            return
        # Only outcome_model gets the richer popover for now.
        if seg.kind is not StageKind.OUTCOME_MODEL:
            try:
                from PySide6.QtWidgets import QMessageBox

                QMessageBox.information(self, "Rail Inspector", "Inspector available for outcome_model only.")
            except Exception:
                pass
            return

        pop = InspectorPopover(self)
        pop.set_data(seg, repro=self._repro_command(seg))
        btn_rect = self.rect()
        global_pos = self.mapToGlobal(btn_rect.bottomRight())
        pop.show_at(global_pos)

    def _copy_hash(self, kind: str) -> None:
        seg = self._segment()
        if seg is None:
            return
        value = seg.input_hash if kind == "input" else (seg.output_hash or "")
        try:
            QGuiApplication.clipboard().setText(str(value))
        except Exception:
            pass

    def _copy_repro_command(self) -> None:
        seg = self._segment()
        if seg is None:
            return
        cmd = self._repro_command(seg)
        try:
            QGuiApplication.clipboard().setText(cmd)
        except Exception:
            pass
        QToolTip.showText(self.mapToGlobal(self.rect().center()), "Repro command copied", self)

    def _repro_command(self, seg: RailSegment) -> str:
        # Placeholder repro string; replace with real CLI once wired.
        return f"helix-cli recompute --stage {seg.segment_id}"


def _format_ts(ts: float | None) -> str:
    if ts is None:
        return "n/a"
    try:
        from datetime import datetime

        return datetime.fromtimestamp(ts).isoformat(timespec="seconds")
    except Exception:
        return str(ts)


class RailControlWidget(QFrame):
    """Clickable rail spine that mirrors the execution DAG."""

    def __init__(self, store: RailStateStore, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._store = store
        self.setObjectName("RailControlWidget")
        self.setFrameStyle(QFrame.NoFrame)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(12, 8, 12, 8)
        self._layout.setSpacing(10)
        self._buttons: Dict[str, RailSegmentButton] = {}
        store.graphChanged.connect(self._on_graph_changed)
        store.selectionChanged.connect(self._on_selection_changed)
        store.segmentStatusChanged.connect(self._on_segment_status_changed)
        store.recomputeRejected.connect(self._on_recompute_rejected)
        store.chainProgressChanged.connect(self._on_chain_progress)
        self._active_chain_id: str | None = None
        self._chain_stage: str | None = None
        self._chain_idx: int = 0
        self._chain_total: int = 0
        self._spinner_idx: int = 0
        self._spinner_timer = QTimer(self)
        self._spinner_timer.setInterval(110)
        self._spinner_timer.timeout.connect(self._on_spinner_tick)
        self._spinner_timer.setSingleShot(False)
        self._on_graph_changed(store.graph)

    # --- slots ------------------------------------------------------

    def _on_graph_changed(self, graph: RailGraph | None) -> None:
        # Clear + rebuild to match topo order. Graph is small; rebuild is fine.
        for i in reversed(range(self._layout.count())):
            item = self._layout.takeAt(i)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._buttons.clear()
        if graph is None:
            placeholder = QLabel("Rail unavailable", self)
            placeholder.setProperty("role", "muted")
            self._layout.addWidget(placeholder)
            return
        for seg in graph.ordered_segments():
            btn = RailSegmentButton(seg, self._store, self)
            btn.set_chain_progress(self._active_chain_id, self._chain_stage, self._chain_idx, self._chain_total)
            btn.set_spinner_idx(self._spinner_idx)
            self._buttons[seg.segment_id] = btn
            self._layout.addWidget(btn)
        self._layout.addStretch(1)

    def _on_selection_changed(self, selection: RailSelection | None) -> None:
        for sid, btn in self._buttons.items():
            btn.setChecked(selection is not None and selection.segment_id == sid)

    def _on_segment_status_changed(self, segment_id: str, state: CacheState) -> None:
        btn = self._buttons.get(segment_id)
        graph = self._store.graph
        seg = graph.get(segment_id) if graph else None  # type: ignore[union-attr]
        if btn is not None and seg is not None:
            btn.set_spinner_idx(self._spinner_idx)
            btn.set_chain_progress(self._active_chain_id, self._chain_stage, self._chain_idx, self._chain_total)
            btn.update_segment(seg)

    def _on_recompute_rejected(self, segment_id: str, reason: str) -> None:
        btn = self._buttons.get(segment_id)
        if btn is None:
            return
        btn.setProperty("flash", True)
        btn.style().unpolish(btn)
        btn.style().polish(btn)
        if reason:
            btn.setToolTip(f"{btn.toolTip()}\nRejected: {reason}")
        QTimer.singleShot(350, lambda: self._clear_flash(btn))

    def _clear_flash(self, btn: RailSegmentButton) -> None:
        btn.setProperty("flash", False)
        btn.style().unpolish(btn)
        btn.style().polish(btn)

    def _on_chain_progress(self, chain_id: str, idx: int, total: int, stage: str) -> None:
        if not chain_id or total == 0:
            self._active_chain_id = None
            self._chain_stage = None
            self._chain_idx = 0
            self._chain_total = 0
        else:
            self._active_chain_id = chain_id
        self._chain_stage = stage
        self._chain_idx = idx
        self._chain_total = total
        self._ensure_spinner_running(total > 0 and self.isVisible())
        for btn in self._buttons.values():
            btn.set_chain_progress(self._active_chain_id, self._chain_stage, self._chain_idx, self._chain_total)
            graph = self._store.graph
            seg = graph.get(btn.segment_id()) if graph else None  # type: ignore[union-attr]
            if seg:
                btn.update_segment(seg)

    def _ensure_spinner_running(self, want: bool) -> None:
        if want and not self._spinner_timer.isActive():
            self._spinner_timer.start()
        if not want and self._spinner_timer.isActive():
            self._spinner_timer.stop()

    def _on_spinner_tick(self) -> None:
        self._spinner_idx = (self._spinner_idx + 1) % len(SPINNER_FRAMES)
        any_computing = False
        graph = self._store.graph
        for btn in self._buttons.values():
            seg = graph.get(btn.segment_id()) if graph else None  # type: ignore[union-attr]
            if seg and seg.cache_state is CacheState.COMPUTING:
                any_computing = True
                btn.set_spinner_idx(self._spinner_idx)
                btn.set_chain_progress(self._active_chain_id, self._chain_stage, self._chain_idx, self._chain_total)
                btn.update_segment(seg)
        if not any_computing:
            self._ensure_spinner_running(False)

    # Ensure spinner pauses when widget is hidden to avoid orphan timers.
    def hideEvent(self, event) -> None:  # type: ignore[override]
        self._ensure_spinner_running(False)
        super().hideEvent(event)

    def showEvent(self, event) -> None:  # type: ignore[override]
        # Restart spinner only if we currently have an active chain.
        self._ensure_spinner_running(self._chain_total > 0)
        super().showEvent(event)


class RailHealthBarWidget(QFrame):
    """Compact run-health bar with progressive disclosure into the full rail."""

    def __init__(
        self,
        store: RailStateStore,
        parent: QWidget | None = None,
        *,
        settings_key: str = "mainWindow/railDetailsExpanded",
    ) -> None:
        super().__init__(parent)
        self._store = store
        self._settings_key = str(settings_key or "mainWindow/railDetailsExpanded")
        self.setObjectName("RailHealthBarWidget")
        self.setFrameShape(QFrame.NoFrame)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._bar = QFrame(self)
        self._bar.setObjectName("RailHealthBar")
        self._bar.setAttribute(Qt.WA_StyledBackground, True)
        bar_layout = QHBoxLayout(self._bar)
        bar_layout.setContentsMargins(12, 6, 12, 6)
        bar_layout.setSpacing(8)

        self._title = QLabel("Run health", self._bar)
        self._title.setProperty("role", "muted")
        bar_layout.addWidget(self._title)

        self._summary = QLabel("—", self._bar)
        self._summary.setObjectName("RailHealthSummary")
        self._summary.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._summary.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        bar_layout.addWidget(self._summary, 1)

        self._toggle = QToolButton(self._bar)
        self._toggle.setObjectName("RailHealthToggle")
        self._toggle.setCheckable(True)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.clicked.connect(self._on_toggle_clicked)
        bar_layout.addWidget(self._toggle)

        root.addWidget(self._bar)

        self._rail = RailControlWidget(store, self)
        root.addWidget(self._rail)

        expanded = False
        try:
            expanded = bool(QSettings("Helix", "Studio").value(self._settings_key, False))
        except Exception:
            expanded = False
        self._toggle.blockSignals(True)
        self._toggle.setChecked(bool(expanded))
        self._toggle.blockSignals(False)
        self._apply_expanded_state(bool(expanded))

        store.graphChanged.connect(lambda _g: self._refresh_summary())
        store.segmentStatusChanged.connect(lambda *_args: self._refresh_summary())
        store.chainProgressChanged.connect(lambda *_args: self._refresh_summary())
        self._refresh_summary()

        self._bar.setStyleSheet(
            "QFrame#RailHealthBar {"
            "  background: palette(base);"
            "  border-bottom: 1px solid palette(mid);"
            "}"
        )

    def _on_toggle_clicked(self) -> None:
        expanded = bool(self._toggle.isChecked())
        self._apply_expanded_state(expanded)
        try:
            QSettings("Helix", "Studio").setValue(self._settings_key, expanded)
        except Exception:
            pass

    def _apply_expanded_state(self, expanded: bool) -> None:
        self._rail.setVisible(bool(expanded))
        self._toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._toggle.setText("Details")
        self._refresh_summary()

    def _refresh_summary(self) -> None:
        graph = getattr(self._store, "graph", None)
        if graph is None:
            self._summary.setText("Rail unavailable")
            self._summary.setToolTip("")
            return

        segments = list(graph.ordered_segments())
        counts = {
            CacheState.CLEAN: 0,
            CacheState.DIRTY: 0,
            CacheState.COMPUTING: 0,
            CacheState.UNSUPPORTED: 0,
            CacheState.ERROR: 0,
        }
        for seg in segments:
            try:
                counts[seg.cache_state] += 1
            except Exception:
                pass

        non_clean = len([s for s in segments if s.cache_state is not CacheState.CLEAN])
        parts: list[str] = []
        if counts[CacheState.ERROR]:
            parts.append(f"{counts[CacheState.ERROR]} error")
        if counts[CacheState.DIRTY]:
            parts.append(f"{counts[CacheState.DIRTY]} dirty")
        if counts[CacheState.COMPUTING]:
            parts.append(f"{counts[CacheState.COMPUTING]} computing")
        if counts[CacheState.UNSUPPORTED]:
            parts.append(f"{counts[CacheState.UNSUPPORTED]} unsupported")

        if non_clean == 0:
            summary = "Ready"
        else:
            summary = f"{non_clean} blocker" + ("s" if non_clean != 1 else "")
            if parts:
                summary = summary + " · " + " · ".join(parts)

        tip_lines: list[str] = []
        for seg in segments:
            if seg.cache_state is CacheState.CLEAN:
                continue
            tip_lines.append(f"{seg.name}: {seg.cache_state.value}")
            try:
                meta = seg.metadata if isinstance(seg.metadata, dict) else dict(seg.metadata or {})
                reason = meta.get("ui_reason")
                if isinstance(reason, str) and reason.strip():
                    tip_lines.append(f"  {reason.strip()}")
            except Exception:
                pass
        self._summary.setText(summary)
        self._summary.setToolTip("\n".join(tip_lines).strip())
