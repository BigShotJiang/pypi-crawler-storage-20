from __future__ import annotations

import argparse
import gc
import os
import sys
import time
import faulthandler
from pathlib import Path

from typing import Literal

from PySide6.QtWidgets import QApplication, QTableView, QWidget, QVBoxLayout
from PySide6.QtTest import QAbstractItemModelTester
from PySide6.QtCore import Qt

from helix.studio.experimental.run_history_mv.run_history_model import RunHistoryTableModel, RunHistoryProxy, RunRow


def make_snapshot(i: int) -> dict:
    outcomes = []
    intended = (i % 3) == 0
    outcomes.append({"label": "intended" if intended else "off", "probability": 0.5, "diff": {"kind": "none"}})
    return {
        "timestamp": f"t{i}",
        "state": {
            "run_kind": "CRISPR" if (i % 2 == 0) else "PRIME",
            "run_id": i,
            "viz_dirty": False,
            "config": {"run_config": {"draws": 10}},
            "genome_source": "file",
            "genome_uri": f"chr{i%5}",
            "genome": {"chr": "ACGT" * 4},
            "outcomes": outcomes,
        },
    }


class MVWidget(QWidget):
    def __init__(self, layer: int, *, tester: bool, tester_mode: Literal["fatal", "warning", None] = None,
                 dynamic_sort: bool, show_view: bool) -> None:
        super().__init__()
        self.model = RunHistoryTableModel(self)
        self.proxy = RunHistoryProxy(self.model, self)
        self.view = QTableView(self)

        # Layered enablement for safer bisecting of crashes
        self.layer = layer
        if layer >= 1:
            self.view.setModel(self.proxy)
        else:
            self.view.setModel(self.model)

        if layer >= 3:
            self.view.setSortingEnabled(True)
            self.view.sortByColumn(0, Qt.AscendingOrder)

        self.proxy.setDynamicSortFilter(dynamic_sort)

        layout = QVBoxLayout(self)
        layout.addWidget(self.view)
        self.setLayout(layout)
        self._tester = None
        if tester or os.getenv("HELIX_STUDIO_MV_MODEL_TESTER") == "1":
            try:
                target = self.proxy if layer >= 1 else self.model
                mode = QAbstractItemModelTester.FailureReportingMode.Warning
                if tester_mode == "fatal" or os.getenv("HELIX_STUDIO_MV_MODEL_TESTER_FATAL") == "1":
                    mode = QAbstractItemModelTester.FailureReportingMode.Fatal
                self._tester = QAbstractItemModelTester(target, mode, self)
            except Exception:
                self._tester = None

        if show_view:
            self.show()

    def teardown(self) -> None:
        # Cheap insurance against shutdown oddities
        self.view.setModel(None)
        self.proxy.setSourceModel(None)

    def add_snapshot(self, snap: dict, *, insert_mode: bool = False) -> None:
        # Temporarily disable proxy dynamism while mutating source to avoid reentrancy
        dyn = self.proxy.dynamicSortFilter()
        self.proxy.blockSignals(True)
        self.proxy.setDynamicSortFilter(False)
        if insert_mode:
            self.model.add_snapshot_insert(snap)
        else:
            # Detach proxy during reset to avoid filter/sort recursion (layer 3)
            self.proxy.setSourceModel(None)
            QApplication.processEvents()
            self.model.add_snapshot_reset(snap)
            self.proxy.setSourceModel(self.model)

        self.proxy.setDynamicSortFilter(dyn)
        self.proxy.blockSignals(False)
        if insert_mode:
            if dyn:
                # Only need explicit invalidate for insert-mode when dynamic sorting is enabled
                self.proxy.invalidate()
        else:
            # Reset path always invalidates after reattach to rebuild proxy mapping
            self.proxy.invalidate()

    def churn_filters(self, token: str) -> None:
        if self.layer >= 2 and self.proxy.dynamicSortFilter():
            self.proxy.set_search(token)
            self.proxy.invalidate()

    def toggle_sort(self) -> None:
        self.view.setSortingEnabled(False)
        self.view.setSortingEnabled(True)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--iters", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--offscreen", action="store_true")
    ap.add_argument("--churn-every", type=int, default=25)
    ap.add_argument("--layer", type=int, default=3, help="MV stack layer (0=table only,1=proxy,2=filter,3=sort)")
    ap.add_argument("--tester", action="store_true", help="Force model tester on")
    ap.add_argument("--no-view", action="store_true", help="Do not show the view window")
    ap.add_argument("--no-dynamic-sort", action="store_true", help="Disable proxy dynamic sort/filter")
    ap.add_argument("--reset-mode", action="store_true", help="Use beginResetModel instead of per-row insert (diagnostic)")
    ap.add_argument("--insert-mode", action="store_true", help="Force insert-mode (beginInsertRows) instead of reset")
    ap.add_argument("--ci", action="store_true", help="CI-friendly run (fewer iters, tighter churn)")
    ap.add_argument("--smoke-insert-ladder", action="store_true", help="Run a small insert-mode ladder (local debug)")
    ap.add_argument("--insert-batch-size", type=int, default=1, help="Batch size for insert-mode (>=1)")
    args = ap.parse_args()

    ci_mode = args.ci or os.getenv("CI") == "1"
    if ci_mode:
        # Keep crash coverage but shorten runtime for CI
        if args.iters > 800:
            args.iters = 700
        if args.churn_every >= 25:
            args.churn_every = 10
        args.tester = True

    log_path = Path(os.environ.get("HELIX_MV_REPRO_LOG", "artifacts/mv_repro.log"))
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = log_path.open("w", buffering=1)
    faulthandler.enable(file=log_file, all_threads=True)
    from PySide6 import QtCore
    log_file.write(f"ARGV: {' '.join(sys.argv)}\n")
    log_file.write(
        "toggles: "
        f"ci={int(ci_mode)} iters={args.iters} churn={args.churn_every} layer={args.layer} "
        f"insert_mode={int(args.insert_mode)} reset_mode={int(args.reset_mode)} "
        f"no_view={int(args.no_view)} no_dynamic_sort={int(args.no_dynamic_sort)} "
        f"tester={int(args.tester)} offscreen={int(args.offscreen)}\n"
    )
    log_file.write(f"Qt={QtCore.qVersion()} PySide6={QtCore.__version__}\n\n")

    if args.offscreen:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

    app = QApplication.instance() or QApplication(sys.argv)

    def run_case(*, layer: int, insert_mode_flag: bool, reset_mode: bool, show_view: bool, dyn_sort: bool, seed: int,
                 label: str) -> int:
        widget = MVWidget(
            layer=layer,
            tester=args.tester or insert_mode_flag,
            tester_mode="fatal" if insert_mode_flag else None,
            dynamic_sort=dyn_sort,
            show_view=show_view,
        )
        try:
            insert_mode = insert_mode_flag and not reset_mode
            batch_size = max(1, args.insert_batch_size)
            if reset_mode:
                widget.proxy.setDynamicSortFilter(False)
                widget.model.beginResetModel()
                widget.model._rows = []
                widget.model._pinned.clear()
                widget.model._summary_cache.clear()
                for i in range(args.iters):
                    snap = make_snapshot(i)
                    run_id = widget.model._run_id_for(snap)
                    widget.model._rows.append(RunRow(snapshot=snap, order=len(widget.model._rows), run_id=run_id))
                widget.model.endResetModel()
                app.processEvents()
            else:
                if insert_mode:
                    # No churn/toggle during insert-mode; keep processing minimal to avoid reentrancy
                    bucket: list[dict] = []
                    for i in range(args.iters):
                        bucket.append(make_snapshot(i))
                        if len(bucket) >= batch_size:
                            widget.model.add_snapshots_insert_batch(bucket)
                            bucket = []
                    if bucket:
                        widget.model.add_snapshots_insert_batch(bucket)
                    app.processEvents()
                else:
                    for i in range(args.iters):
                        snap = make_snapshot(i)
                        widget.add_snapshot(snap, insert_mode=insert_mode)
                        if layer >= 2 and dyn_sort and i % args.churn_every == 0:
                            widget.churn_filters(str(i % 100))
                        if layer >= 3 and i % (args.churn_every * 4) == 0:
                            widget.toggle_sort()
                        if i % 200 == 0:
                            gc.collect()
                        app.processEvents()

            widget.teardown()
            widget.view.deleteLater()
            widget.proxy.deleteLater()
            widget.model.deleteLater()
            app.processEvents()
            gc.collect()
            log_file.write("DONE\n")
            log_file.write("TEARDOWN_DONE\n")
            verdict = (
                f"SEED={seed} PASS DONE=1 TEARDOWN_DONE=1 layer={layer} rung={label} "
                f"ci={int(ci_mode)} iters={args.iters} insert_mode={int(insert_mode)} dyn_sort={int(dyn_sort)} "
                f"batch={batch_size}"
            )
            print(verdict)
            log_file.write(verdict + "\n")
            return 0
        except (AssertionError, RuntimeError) as exc:  # pragma: no cover - diagnostic
            log_file.write(f"Assertion: {exc}\n")
            verdict = (
                f"SEED={seed} FAIL kind=assertion layer={layer} rung={label} "
                f"ci={int(ci_mode)} iters={args.iters} insert_mode={int(insert_mode_flag)} dyn_sort={int(dyn_sort)} "
                f"batch={batch_size}"
            )
            print(verdict)
            log_file.write(verdict + "\n")
            return 2
        except Exception as exc:  # pragma: no cover - diagnostic
            log_file.write(f"Exception: {exc}\n")
            verdict = (
                f"SEED={seed} FAIL kind=exception layer={layer} rung={label} "
                f"ci={int(ci_mode)} iters={args.iters} insert_mode={int(insert_mode_flag)} dyn_sort={int(dyn_sort)} "
                f"batch={batch_size}"
            )
            print(verdict)
            log_file.write(verdict + "\n")
            return 3

    if args.smoke_insert_ladder:
        ladder = [
            ("l0_no_view_no_dyn", 0, True, False, False),
            ("l1_no_view_no_dyn", 1, True, False, False),
            ("l1_view_no_dyn", 1, True, True, False),
            ("l2_view_filter", 2, True, True, False),
            ("l3_view_sort", 3, True, True, False),
            ("l3_view_sort_dyn", 3, True, True, True),
        ]
        worst = 0
        for name, layer, insert_flag, show_view, dyn in ladder:
            rc = run_case(
                layer=layer,
                insert_mode_flag=insert_flag,
                reset_mode=False,
                show_view=show_view,
                dyn_sort=dyn,
                seed=args.seed,
                label=name,
            )
            worst = max(worst, rc)
        return worst

    return run_case(
        layer=args.layer,
        insert_mode_flag=args.insert_mode,
        reset_mode=args.reset_mode,
        show_view=not args.no_view,
        dyn_sort=not args.no_dynamic_sort,
        seed=args.seed,
        label="default",
    )


if __name__ == "__main__":
    sys.exit(main())
