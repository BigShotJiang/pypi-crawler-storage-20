from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from PySide6.QtCore import QAbstractTableModel, QModelIndex, Qt, Signal, QSortFilterProxyModel, QIdentityProxyModel

from helix.studio.run_metrics import ensure_state_payload, summarize_snapshot
from helix.studio.workers import run_bg, CancelToken


@dataclass(frozen=True)
class RunRow:
    snapshot: Mapping[str, Any]
    order: int
    run_id: str


class RunHistoryTableModel(QAbstractTableModel):
    layoutHintChanged = Signal()
    summaryReady = Signal()

    COL_HEADERS = ["Run #", "Pinned", "Kind", "Guide", "Genome", "Label", "Timestamp", "Draws", "Outcomes"]

    ROLE_SNAPSHOT = Qt.UserRole + 1
    ROLE_RUN_ID = Qt.UserRole + 2
    ROLE_PINNED = Qt.UserRole + 3
    ROLE_ORDER = Qt.UserRole + 4
    ROLE_SUMMARY = Qt.UserRole + 5

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._rows: list[RunRow] = []
        self._pinned: set[str] = set()
        self._metrics_cache: dict[str, Any] = {}
        self._summary_cache: dict[str, Mapping[str, Any]] = {}

    # ----- mutation helpers -----
    def add_snapshot_reset(self, snapshot: Mapping[str, Any]) -> None:
        run_id = self._run_id_for(snapshot)
        row = RunRow(snapshot=snapshot, order=len(self._rows), run_id=run_id)
        # Detach proxy to avoid reentrancy during reset
        proxy = None
        for proxy_candidate in self.findChildren(QSortFilterProxyModel):
            proxy = proxy_candidate
        if proxy is not None:
            proxy.setSourceModel(None)
        self.beginResetModel()
        self._rows.append(row)
        self.endResetModel()
        if proxy is not None:
            proxy.setSourceModel(self)
            proxy.invalidate()
        self._start_metrics(row)
        self.layoutHintChanged.emit()

    def add_snapshot_insert(self, snapshot: Mapping[str, Any]) -> None:
        run_id = self._run_id_for(snapshot)
        row = RunRow(snapshot=snapshot, order=len(self._rows), run_id=run_id)
        self.beginInsertRows(QModelIndex(), len(self._rows), len(self._rows))
        self._rows.append(row)
        self.endInsertRows()
        self._start_metrics(row)
        self.layoutHintChanged.emit()

    def add_snapshots_insert_batch(self, snapshots: list[Mapping[str, Any]]) -> None:
        if not snapshots:
            return
        start = len(self._rows)
        end = start + len(snapshots) - 1
        self.beginInsertRows(QModelIndex(), start, end)
        for snap in snapshots:
            run_id = self._run_id_for(snap)
            self._rows.append(RunRow(snapshot=snap, order=len(self._rows), run_id=run_id))
        self.endInsertRows()
        for row in self._rows[start: end + 1]:
            self._start_metrics(row)
        self.layoutHintChanged.emit()

    def set_pinned(self, run_id: str, pinned: bool) -> None:
        if pinned:
            self._pinned.add(run_id)
        else:
            self._pinned.discard(run_id)
        self._emit_row_data_changed(run_id, [1])

    def toggle_pin(self, run_id: str) -> None:
        self.set_pinned(run_id, run_id not in self._pinned)

    # ----- Qt model API -----
    def rowCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        return 0 if parent.isValid() else len(self.COL_HEADERS)

    def headerData(self, section: int, orientation, role=Qt.DisplayRole):  # type: ignore[override]
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            if 0 <= section < len(self.COL_HEADERS):
                return self.COL_HEADERS[section]
        return None

    def data(self, index: QModelIndex, role=Qt.DisplayRole):  # type: ignore[override]
        if not index.isValid():
            return None
        row = self._rows[index.row()]
        run_id = row.run_id

        if role == self.ROLE_SNAPSHOT:
            return row.snapshot
        if role == self.ROLE_RUN_ID:
            return run_id
        if role == self.ROLE_PINNED:
            return run_id in self._pinned
        if role == self.ROLE_ORDER:
            return row.order

        summary = self._summary_cache.get(run_id)
        if summary is None:
            self._start_metrics(row)
            summary = self._summary_cache.get(run_id)
            if summary is None:
                if role == self.ROLE_SUMMARY:
                    return None
                if role == Qt.DisplayRole:
                    return "…"
                return None

        if role == self.ROLE_SUMMARY:
            return summary

        if role != Qt.DisplayRole:
            return None

        col = index.column()
        if col == 0:
            return summary.get("run_id")
        if col == 1:
            return "PIN" if run_id in self._pinned else ""
        if col == 2:
            return summary.get("run_kind")
        if col == 3:
            return summary.get("guide")
        if col == 4:
            return summary.get("genome")
        if col == 5:
            return summary.get("label")
        if col == 6:
            return summary.get("timestamp")
        if col == 7:
            return summary.get("draws")
        if col == 8:
            return summary.get("outcomes")
        return None

    # ----- internals -----
    def _run_id_for(self, snapshot: Mapping[str, Any]) -> str:
        state = ensure_state_payload(snapshot) or {}
        rid = state.get("run_id")
        return str(rid) if rid is not None else str(len(self._rows) + 1)

    def _start_metrics(self, row: RunRow) -> None:
        run_id = row.run_id
        try:
            summary = summarize_snapshot(row.snapshot)
            self._summary_cache[run_id] = summary
            self._emit_row_data_changed(run_id)
            self.summaryReady.emit()
        except Exception:
            self._summary_cache[run_id] = {"run_id": run_id, "label": "error"}
            self._emit_row_data_changed(run_id)

    def _emit_row_data_changed(self, run_id: str, columns: list[int] | None = None) -> None:
        for row_idx, row in enumerate(self._rows):
            if row.run_id == run_id:
                left_col = 0 if columns is None else min(columns)
                right_col = self.columnCount() - 1 if columns is None else max(columns)
                left = self.index(row_idx, left_col)
                right = self.index(row_idx, right_col)
                self.dataChanged.emit(left, right, [Qt.DisplayRole, self.ROLE_SUMMARY])
                break

    def runs(self) -> list[Mapping[str, Any]]:
        return [r.snapshot for r in self._rows]

    def is_pinned(self, run_id: str) -> bool:
        return run_id in self._pinned


class RunHistoryProxy(QSortFilterProxyModel):
    def __init__(self, model: RunHistoryTableModel, parent=None) -> None:
        super().__init__(parent)
        self.setSourceModel(model)
        self._search = ""
        self._kind = "ALL"
        self._intended_only = False
        self._profile_key = None
        model.summaryReady.connect(self.invalidate)

    # filter setters
    def set_search(self, text: str) -> None:
        self._search = text.strip().lower()
        self.invalidateFilter()

    def set_kind(self, kind: str) -> None:
        self._kind = kind
        self.invalidate()

    def set_intended_only(self, flag: bool) -> None:
        self._intended_only = flag
        self.invalidate()

    def set_profile_key(self, key) -> None:
        self._profile_key = key
        self.invalidate()

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:  # type: ignore[override]
        model: RunHistoryTableModel = self.sourceModel()  # type: ignore[assignment]
        if model is None:
            return False
        if source_parent.isValid():
            return False
        if source_row < 0 or source_row >= model.rowCount():
            return False
        idx = model.index(source_row, 0, source_parent)
        if not idx.isValid():
            return False
        run_id = model.data(idx, RunHistoryTableModel.ROLE_RUN_ID)
        if model.is_pinned(run_id):
            return True

        summary = model.data(idx, RunHistoryTableModel.ROLE_SUMMARY)
        if summary is None:
            return True

        if self._kind and self._kind != "ALL" and summary.get("run_kind_key") != self._kind:
            return False
        if self._intended_only and not summary.get("has_intended"):
            return False
        if self._profile_key and summary.get("profile_key") != self._profile_key:
            return False
        if self._search:
            hay = f"{summary.get('genome','')} {summary.get('guide','')} {summary.get('label','')}".lower()
            if self._search not in hay:
                return False
        return True

    def lessThan(self, left: QModelIndex, right: QModelIndex) -> bool:  # type: ignore[override]
        model: RunHistoryTableModel = self.sourceModel()  # type: ignore[assignment]
        if model is None:
            return False
        if not left.isValid() or not right.isValid():
            return False
        # Lightweight, stable ordering: row index then order field if available.
        if left.row() != right.row():
            return left.row() < right.row()
        l_order = model.data(left, RunHistoryTableModel.ROLE_ORDER)
        r_order = model.data(right, RunHistoryTableModel.ROLE_ORDER)
        try:
            return int(l_order) < int(r_order)
        except Exception:
            return False


class CapProxyModel(QIdentityProxyModel):
    def __init__(self, max_rows: int = 500, parent=None) -> None:
        super().__init__(parent)
        self._max_rows = max_rows

    @property
    def max_rows(self) -> int:
        return self._max_rows

    @max_rows.setter
    def max_rows(self, value: int) -> None:
        self._max_rows = max(1, value)
        self.invalidate()

    @property
    def total_rows(self) -> int:
        src = self.sourceModel()
        return src.rowCount() if src else 0

    @property
    def shown_rows(self) -> int:
        return min(self.total_rows, self._max_rows)

    def rowCount(self, parent=QModelIndex()) -> int:  # type: ignore[override]
        src = self.sourceModel()
        if parent.isValid() or src is None:
            return 0
        return min(self._max_rows, src.rowCount())

    def index(self, row: int, column: int, parent=QModelIndex()):  # type: ignore[override]
        if row >= self.rowCount(parent):
            return QModelIndex()
        return super().index(row, column, parent)

    def mapToSource(self, proxyIndex: QModelIndex) -> QModelIndex:  # type: ignore[override]
        if not proxyIndex.isValid() or proxyIndex.row() >= self._max_rows:
            return QModelIndex()
        return super().mapToSource(proxyIndex)

    def mapFromSource(self, sourceIndex: QModelIndex) -> QModelIndex:  # type: ignore[override]
        if not sourceIndex.isValid() or sourceIndex.row() >= self._max_rows:
            return QModelIndex()
        return super().mapFromSource(sourceIndex)
