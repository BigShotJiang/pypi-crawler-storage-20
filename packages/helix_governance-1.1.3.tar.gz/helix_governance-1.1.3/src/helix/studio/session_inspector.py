from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Optional

from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget, QHBoxLayout, QGridLayout

from .session import ExperimentState, SessionModel
from .ui_tokens import base_font, MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL
from .experiment_spec_panel import ExperimentSpecEditor
from .outcomes.outcome_spectrum_panel import OutcomeSpectrumPanel
from .offtargets.offtarget_list_panel import OffTargetListPanel
from .batch.batch_compare_panel import BatchComparePanel
from .results_panel import ResultsPanel


class SessionInspector(QWidget):
    def __init__(self, session: SessionModel | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self.setFont(base_font())

        root = QVBoxLayout(self)
        root.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        root.setSpacing(SPACING_MEDIUM)

        self._pill_row = QHBoxLayout()
        self._pill_row.setSpacing(SPACING_SMALL)
        self._pill_row.setContentsMargins(0, 0, 0, 0)
        root.addLayout(self._pill_row)

        self._experiment_editor = ExperimentSpecEditor(self._session, self)
        root.addWidget(self._experiment_editor)

        self._outcome_spectrum = OutcomeSpectrumPanel(self._session, self)
        root.addWidget(self._outcome_spectrum)

        self._offtarget_list = OffTargetListPanel(self._session, self)
        root.addWidget(self._offtarget_list)

        self._batch_compare = BatchComparePanel(self._session, self)
        root.addWidget(self._batch_compare)

        self._results_panel = ResultsPanel(self._session, self)
        root.addWidget(self._results_panel)

        self._grid = QGridLayout()
        self._grid.setHorizontalSpacing(SPACING_MEDIUM)
        self._grid.setVerticalSpacing(SPACING_SMALL)
        root.addLayout(self._grid)
        root.addStretch(1)

        self._status = QLabel("Awaiting simulation run.", self)
        root.addWidget(self._status)

        self._session.stateChanged.connect(self._on_state_changed)
        self._on_state_changed(self._session.state)

    def set_evs(self, evs: dict | None) -> None:
        self._clear_layouts()
        if evs is None:
            self._status.setText("Awaiting simulation run.")
            return
        self._status.setText("Loaded EVS")
        org = evs.get("organism", {}) if isinstance(evs, dict) else {}
        seq = evs.get("sequence", {}) if isinstance(evs, dict) else {}
        locus = seq.get("referenceLocus", {}) if isinstance(seq, dict) else {}
        sim = evs.get("simulation", {}) if isinstance(evs, dict) else {}
        prov = evs.get("provenance", {}) if isinstance(evs, dict) else {}

        chrom = locus.get("chrom", "chr?")
        start = locus.get("start", "?")
        end = locus.get("end", "?")
        genome_pill = f"{org.get('assembly','?')} ({chrom}:{start}-{end})"
        mode_pill = evs.get("editPlan", {}).get("mode", "Unknown") if isinstance(evs, dict) else "Unknown"
        engine = sim.get("engine", "Not run") if isinstance(sim, dict) else "Not run"
        alleles = len(sim.get("results", {}).get("alleles", []) or []) if isinstance(sim, dict) else 0
        outcomes_pill = f"{alleles} outcome{'s' if alleles != 1 else ''}"

        try:
            run_chip_text = f"{mode_pill} · {outcomes_pill}"
            guide_label = evs.get("editPlan", {}).get("targets", [{}])[0].get("label") if isinstance(evs, dict) else None
            if guide_label:
                run_chip_text = f"{guide_label} · {mode_pill} · {outcomes_pill}"
            self._add_pill(run_chip_text, accent=True)
        except Exception:
            pass

        for text in (genome_pill, mode_pill, engine, outcomes_pill):
            self._add_pill(text)

        row = 0
        def add_kv(key: str, val: str) -> None:
            nonlocal row
            k = QLabel(key + ":", self)
            v = QLabel(val, self)
            self._grid.addWidget(k, row, 0)
            self._grid.addWidget(v, row, 1)
            row += 1

        add_kv("Taxon", str(org.get("taxon", "N/A")))
        add_kv("Created at", evs.get("createdAt", "N/A") if isinstance(evs, dict) else "N/A")
        add_kv("App version", prov.get("appVersion", "N/A"))
        add_kv("User", prov.get("user", "N/A"))
        add_kv("Engine", engine)

    def _clear_layouts(self) -> None:
        while self._pill_row.count():
            item = self._pill_row.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        while self._grid.count():
            item = self._grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def _on_state_changed(self, state: ExperimentState) -> None:
        self._clear_layouts()
        self._status.setText("Session updated.")
        try:
            self._experiment_editor.set_spec(state.experiment_spec)
        except Exception:
            pass

        genome_label = self._describe_genome(state.genome)
        if state.run_kind:
            self._add_pill(f"{state.run_kind.name} · {len(state.outcomes)} outcome(s)", accent=True)
        for text in (genome_label,):
            if text:
                self._add_pill(text)

        row = 0
        def add_kv(key: str, val: str) -> None:
            nonlocal row
            k = QLabel(key + ":", self)
            v = QLabel(val, self)
            self._grid.addWidget(k, row, 0)
            self._grid.addWidget(v, row, 1)
            row += 1

        add_kv("Genome", genome_label)
        add_kv("Genome source", self._describe_genome_source(state))
        add_kv("Genome hash", state.genome_hash or "—")
        add_kv("Guide", self._guide_summary(state.config))
        add_kv("pegRNA", self._peg_summary(state.peg))
        add_kv("Editor", self._editor_summary(state.editor))
        run_config = state.config.get("run_config") if isinstance(state.config, Mapping) else {}
        add_kv("Last run", self._format_run_config(run_config))
        add_kv("Run kind", state.run_kind.name)
        add_kv("Viz dirty", "yes" if state.viz_dirty else "no")
        add_kv("Outcomes", f"{len(state.outcomes)} recorded")

    def _describe_genome(self, genome: Optional[Any]) -> str:
        if genome is None or not getattr(genome, "sequences", None):
            return "—"
        seqs = getattr(genome, "sequences", {})
        lengths = [len(seq) for seq in seqs.values()]
        total = sum(lengths)
        chroms = len(lengths)
        return f"{total} bp across {chroms} contig(s)"

    def _guide_summary(self, config: Mapping[str, Any] | None) -> str:
        if not isinstance(config, Mapping):
            return "—"
        guide = config.get("guide")
        if isinstance(guide, Mapping):
            label = guide.get("id") or guide.get("name") or "guide"
            start = guide.get("start")
            end = guide.get("end")
            strand = guide.get("strand", "+")
            if start is not None and end is not None:
                return f"{label}: {start}-{end} ({strand})"
            return str(label)
        return "—"

    def _peg_summary(self, peg: Optional[Any]) -> str:
        if peg is None:
            return "—"
        name = getattr(peg, "name", None) or "pegRNA"
        spacer = getattr(peg, "spacer", "")
        return f"{name} (spacer {len(spacer)} bp)"

    def _add_pill(self, text: str, *, accent: bool = False) -> None:
        pill = QLabel(text, self)
        base = "padding:4px 10px; border-radius:12px; color:#eaf0ff;"
        if accent:
            base += " background: rgba(58,232,200,0.18); font-weight: 600;"
        else:
            base += " background: rgba(255,255,255,0.08);"
        pill.setStyleSheet(base)
        self._pill_row.addWidget(pill)

    def _editor_summary(self, editor: Optional[Any]) -> str:
        if editor is None:
            return "—"
        name = getattr(editor, "name", "Editor")
        offset = getattr(editor, "nick_to_edit_offset", 0)
        return f"{name} (nick offset {offset})"

    def _format_run_config(self, config: Mapping[str, Any] | None) -> str:
        if not isinstance(config, Mapping) or not config:
            return "—"
        parts: list[str] = []
        for key in ("mode", "draws", "seed", "pam_profile", "priors_profile"):
            if key in config and config[key] is not None:
                parts.append(f"{key}={config[key]}")
        return ", ".join(parts) if parts else "—"

    def _describe_genome_source(self, state: ExperimentState) -> str:
        source = state.genome_source or "inline"
        uri = state.genome_uri
        if source == "file" and uri:
            return f"file: {uri}"
        if uri:
            return f"{source}: {uri}"
        return source
