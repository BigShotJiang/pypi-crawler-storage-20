from __future__ import annotations

import hashlib
import io
import json
import math
import os
import shutil
import subprocess
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np

from helix import __version__ as helix_version
from helix import clock
from helix import temp
from helix.provenance import current_git_sha
from helix.gui.modern.spec import EditEventType, EditVisualizationSpec
from helix.support.subprocess import no_console_kwargs


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _stable_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def sha256_json(obj: Any) -> str:
    return _sha256_bytes(_stable_json_bytes(obj))


def sha256_text(text: str) -> str:
    return _sha256_bytes(text.encode("utf-8"))


def utc_now_iso() -> str:
    return clock.utc_now_iso()

_FIXED_ZIP_DT = (2020, 1, 1, 0, 0, 0)


def _zip_write_bytes(zf: zipfile.ZipFile, arcname: str, data: bytes) -> None:
    name = arcname.replace(os.sep, "/")
    info = zipfile.ZipInfo(filename=name, date_time=_FIXED_ZIP_DT)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o644 << 16
    zf.writestr(info, data)


def event_time_seconds(*, t_evt: float, loop_s: float, normalized: bool) -> float | None:
    """Match HelixVizEngine event-time semantics (seconds within [0, loop))."""
    try:
        t_evt = float(t_evt)
        loop = float(loop_s)
    except Exception:
        return None
    if not math.isfinite(t_evt) or not (loop > 1e-6):
        return None

    t_s_raw = float(t_evt) * float(loop) if normalized else float(t_evt)
    if abs(float(t_s_raw) - float(loop)) <= 1e-6:
        return float(loop) - 1e-6

    t_mod = float(t_s_raw) % float(loop)
    if abs(float(t_mod)) <= 1e-12 and abs(float(t_s_raw)) > 1e-6:
        return float(loop) - 1e-6
    return max(0.0, min(float(loop) - 1e-6, float(t_mod)))


def _clamp_window(
    start_s: float,
    end_s: float,
    *,
    clamp_start_s: float,
    clamp_end_s: float,
) -> tuple[float, float]:
    """Shift/clamp a window to live entirely inside [clamp_start_s, clamp_end_s]."""
    a = float(clamp_start_s)
    b = float(clamp_end_s)
    if b < a:
        a, b = b, a
    span_total = max(0.0, float(b) - float(a))

    start = float(start_s)
    end = float(end_s)
    if end < start:
        start, end = end, start
    span = max(0.0, float(end) - float(start))

    if span_total <= 1e-9:
        return a, a
    if span >= span_total - 1e-9:
        return a, b

    if start < a:
        end += a - start
        start = a
    if end > b:
        start -= end - b
        end = b
    start = max(a, min(b - span, start))
    end = start + span
    return float(start), float(end)


def event_cluster_bounds_seconds(
    *,
    t_s: float,
    event_times_s: Sequence[float],
    duration_s: float,
    loop_range_s: tuple[float, float] | None = None,
    gap_threshold_s: float = 0.25,
    max_cluster_span_s: float = 6.0,
) -> tuple[float, float] | None:
    """Return (cluster_start, cluster_end) using the same semantics as the Fit-to-Locus window."""

    try:
        loop = float(duration_s)
    except Exception:
        loop = 0.0
    if not (loop > 1e-6):
        return None

    clamp_a = 0.0
    clamp_b = loop
    if loop_range_s is not None:
        try:
            a = float(loop_range_s[0])
            b = float(loop_range_s[1])
        except Exception:
            a = b = 0.0
        if math.isfinite(a) and math.isfinite(b):
            if b < a:
                a, b = b, a
            a = max(0.0, min(loop, a))
            b = max(0.0, min(loop, b))
            if b - a > 1e-6:
                clamp_a, clamp_b = float(a), float(b)

    try:
        t = float(t_s)
    except Exception:
        t = 0.0
    if not math.isfinite(t):
        t = 0.0
    t = max(clamp_a, min(clamp_b, t))

    times: list[float] = []
    for raw in event_times_s or ():
        try:
            x = float(raw)
        except Exception:
            continue
        if not math.isfinite(x):
            continue
        if clamp_a - 1e-9 <= x <= clamp_b + 1e-9:
            times.append(x)
    times.sort()
    if not times:
        return None

    max_span = max(0.05, float(max_cluster_span_s))
    gap = max(0.0, float(gap_threshold_s))

    i = min(range(len(times)), key=lambda idx: abs(times[idx] - t))
    left = i
    right = i

    while True:
        can_left = False
        can_right = False
        gap_left = gap_right = 0.0
        if left > 0:
            gap_left = float(times[left]) - float(times[left - 1])
            can_left = gap_left <= gap and (float(times[right]) - float(times[left - 1])) <= max_span
        if right < len(times) - 1:
            gap_right = float(times[right + 1]) - float(times[right])
            can_right = gap_right <= gap and (float(times[right + 1]) - float(times[left])) <= max_span

        if can_left and can_right:
            if gap_left <= gap_right:
                left -= 1
            else:
                right += 1
            continue
        if can_left:
            left -= 1
            continue
        if can_right:
            right += 1
            continue
        break

    # Match fit-to-locus behavior: if the "cluster" is a single event, include
    # one neighbor for context when within the max span.
    if left == i and i > 0:
        cand = i - 1
        if float(times[right]) - float(times[cand]) <= max_span + 1e-9:
            left = cand
    if right == i and i < len(times) - 1:
        cand = i + 1
        if float(times[cand]) - float(times[left]) <= max_span + 1e-9:
            right = cand

    a = float(times[left])
    b = float(times[right])
    if b < a:
        a, b = b, a
    return a, b


@dataclass(frozen=True)
class ClipWindow:
    start_s: float
    end_s: float
    anchor_time_s: float
    anchor_source: str

    @property
    def span_s(self) -> float:
        return max(0.0, float(self.end_s) - float(self.start_s))


def compute_clip_window(
    *,
    now_s: float,
    loop_duration_s: float,
    event_times_s: Sequence[float],
    spec: EditVisualizationSpec,
    event_times_normalized: bool,
    loop_enabled: bool,
    loop_range_s: tuple[float, float] | None,
    half_span_s: float = 2.0,
    fps: int = 24,
) -> ClipWindow:
    """Compute the capture window around resolve (or the active event cluster).

    Rules:
    - Default: ±half_span around resolve anchor (repair_complete if present else cluster tail).
    - If loop enabled: clamp inside loop range; if range span is smaller than 2*half_span, pin to range.
    """
    _ = fps  # kept for future expansion; currently windowing is time-based only.

    loop = float(loop_duration_s) if loop_duration_s > 1e-6 else 0.0
    if not (loop > 1e-6):
        return ClipWindow(0.0, 0.0, 0.0, "no_loop")

    try:
        now = float(now_s)
    except Exception:
        now = 0.0
    if not math.isfinite(now):
        now = 0.0
    now = max(0.0, min(loop, now))

    # Resolve anchor = explicit repair_complete if present; else last event in the current cluster.
    resolve_times: list[float] = []
    for ev in getattr(spec, "events", ()) or ():
        if getattr(ev, "type", None) != EditEventType.REPAIR_COMPLETE:
            continue
        t_s = event_time_seconds(t_evt=float(getattr(ev, "t", 0.0)), loop_s=loop, normalized=event_times_normalized)
        if t_s is not None:
            resolve_times.append(float(t_s))
    if resolve_times:
        anchor = max(resolve_times)
        anchor_source = "repair_complete"
    else:
        cluster = event_cluster_bounds_seconds(
            t_s=now,
            event_times_s=event_times_s,
            duration_s=loop,
            loop_range_s=(loop_range_s if loop_enabled else None),
        )
        if cluster is not None:
            _cluster_start, cluster_end = cluster
            anchor = float(cluster_end)
            anchor_source = "cluster_tail"
        elif event_times_s:
            anchor = float(max(float(t) for t in event_times_s))
            anchor_source = "last_event"
        else:
            anchor = now
            anchor_source = "playhead"

    desired = max(0.0, float(half_span_s)) * 2.0
    desired = max(0.05, min(loop, desired))

    if loop_enabled and loop_range_s is not None:
        try:
            a = float(loop_range_s[0])
            b = float(loop_range_s[1])
        except Exception:
            a = b = 0.0
        if math.isfinite(a) and math.isfinite(b):
            if b < a:
                a, b = b, a
            a = max(0.0, min(loop, a))
            b = max(0.0, min(loop, b))
            span = max(0.0, float(b) - float(a))
            if span <= 1e-9:
                return ClipWindow(a, a, anchor, "loop_empty")
            if span <= desired + 1e-9:
                return ClipWindow(a, b, anchor, anchor_source)
            start = float(anchor) - desired * 0.5
            start = max(float(a), min(float(b) - desired, start))
            end = start + desired
            return ClipWindow(float(start), float(end), anchor, anchor_source)

    start = float(anchor) - desired * 0.5
    end = float(anchor) + desired * 0.5
    start, end = _clamp_window(start, end, clamp_start_s=0.0, clamp_end_s=loop)
    return ClipWindow(float(start), float(end), anchor, anchor_source)


def frame_times_seconds(*, start_s: float, end_s: float, fps: int) -> list[float]:
    """Generate capture frame timestamps, inclusive of end_s."""
    try:
        start = float(start_s)
        end = float(end_s)
        fps_i = int(fps)
    except Exception:
        return []
    if fps_i <= 0:
        return []
    if end < start:
        start, end = end, start
    span = max(0.0, end - start)
    dt = 1.0 / float(fps_i)
    if span <= 1e-9:
        return [start]
    times: list[float] = []
    t = start
    while t < end - 1e-9:
        times.append(float(t))
        t += dt
    times.append(float(end))
    return times


@dataclass(frozen=True)
class Mp4Encoder:
    exe: str
    codec: str


def detect_mp4_encoder() -> Mp4Encoder | None:
    exe = shutil.which("ffmpeg")
    if not exe:
        try:
            import imageio_ffmpeg  # type: ignore[import-not-found]

            exe = imageio_ffmpeg.get_ffmpeg_exe()  # pragma: no cover - optional runtime path
        except Exception:
            exe = None
    if not exe:
        return None
    codec = _choose_ffmpeg_codec(exe)
    return Mp4Encoder(exe=str(exe), codec=str(codec))


def _choose_ffmpeg_codec(ffmpeg_exe: str) -> str:
    """Prefer libx264 when available; otherwise fall back to mpeg4."""
    try:
        proc = subprocess.run(
            [ffmpeg_exe, "-hide_banner", "-encoders"],
            capture_output=True,
            text=True,
            timeout=2.5,
            **no_console_kwargs(),
        )
        text = (proc.stdout or "") + "\n" + (proc.stderr or "")
        if "libx264" in text:
            return "libx264"
    except Exception:
        pass
    return "mpeg4"


def encode_gif_bytes(*, frames_rgb: Iterable[np.ndarray], fps: int) -> bytes:
    """Encode frames (H,W,3 uint8) into a GIF in memory."""
    try:
        import imageio.v2 as iio
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("GIF export requires 'imageio' (install the Helix Studio realtime extras).") from exc

    buf = io.BytesIO()
    duration_s = 1.0 / float(max(1, int(fps)))
    with iio.get_writer(buf, format="GIF", mode="I", duration=duration_s) as writer:
        for frame in frames_rgb:
            writer.append_data(frame)
    return buf.getvalue()


def encode_mp4_bytes_ffmpeg(
    *,
    frames_rgb: Iterable[np.ndarray],
    fps: int,
    encoder: Mp4Encoder,
) -> bytes | None:
    """Best-effort MP4 encoder using ffmpeg, streaming raw RGB frames to stdin."""
    tmpdir = temp.mkdtemp(prefix="helix_clip_")
    out_path = tmpdir / "clip.mp4"
    proc = None
    try:
        fps_i = int(fps)
        fps_i = max(1, min(120, fps_i))
        first: np.ndarray | None = None
        it = iter(frames_rgb)
        try:
            first = next(it)
        except StopIteration:
            return None
        if first is None:
            return None
        if first.ndim != 3 or first.shape[2] != 3:
            return None
        h, w = int(first.shape[0]), int(first.shape[1])
        if h <= 0 or w <= 0:
            return None

        cmd = [
            str(encoder.exe),
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "rawvideo",
            "-vcodec",
            "rawvideo",
            "-pix_fmt",
            "rgb24",
            "-s",
            f"{w}x{h}",
            "-r",
            str(fps_i),
            "-i",
            "pipe:0",
            "-an",
            "-vcodec",
            str(encoder.codec),
            "-pix_fmt",
            "yuv420p",
            str(out_path),
        ]
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            **no_console_kwargs(),
        )
        assert proc.stdin is not None
        proc.stdin.write(np.ascontiguousarray(first).tobytes())
        for frame in it:
            if frame is None:
                continue
            if frame.shape[0] != h or frame.shape[1] != w or frame.shape[2] != 3:
                continue
            proc.stdin.write(np.ascontiguousarray(frame).tobytes())
        try:
            proc.stdin.close()
        except Exception:
            pass
        stderr = proc.communicate(timeout=20.0)[1] if proc is not None else b""
        if proc is None or proc.returncode != 0:
            # Optional output: skip MP4 rather than failing export.
            _ = stderr
            return None
        return out_path.read_bytes() if out_path.exists() else None
    except Exception:
        return None
    finally:
        try:
            if proc is not None and proc.poll() is None:
                proc.kill()
        except Exception:
            pass
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except Exception:
            pass


def redacted_spec_summary(spec: EditVisualizationSpec) -> dict[str, Any]:
    """Return a safe summary that avoids embedding raw sequence payloads."""
    seq = getattr(spec, "sequence", "") or ""
    return {
        "edit_type": getattr(spec, "edit_type", None),
        "pam_index": getattr(spec, "pam_index", None),
        "guide_range": list(getattr(spec, "guide_range", (0, 0))),
        "time_units": getattr(spec, "time_units", None),
        "sequence_length": len(seq),
        "sequence_sha256": sha256_text(str(seq)) if seq else None,
        "event_count": len(getattr(spec, "events", ()) or ()),
    }


def build_capture_metadata(
    *,
    spec: EditVisualizationSpec,
    loop_duration_s: float,
    now_s: float,
    event_times_s: Sequence[float],
    event_times_normalized: bool,
    event_time_units: str,
    event_time_units_source: str,
    loop_enabled: bool,
    loop_range_s: tuple[float, float] | None,
    clip: ClipWindow,
    fps: int,
    view_state: Mapping[str, Any] | None,
    time_view_window_s: tuple[float, float] | None,
    mp4_encoder: Mp4Encoder | None,
    include_full_spec: bool,
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """Build metadata.json (and optional spec payload) for a clip export."""

    spec_payload = spec.to_payload()
    spec_sha = sha256_json(spec_payload)
    seq = getattr(spec, "sequence", "") or ""
    seq_sha = sha256_text(str(seq)) if seq else None

    # Event timeline summary (type + seconds) so viewers can interpret the clip without the full spec.
    events: list[dict[str, Any]] = []
    for ev in getattr(spec, "events", ()) or ():
        try:
            t_evt = float(getattr(ev, "t", 0.0))
        except Exception:
            continue
        t_s = event_time_seconds(t_evt=t_evt, loop_s=float(loop_duration_s), normalized=bool(event_times_normalized))
        if t_s is None:
            continue
        events.append(
            {
                "type": getattr(getattr(ev, "type", None), "value", None) or str(getattr(ev, "type", "custom")),
                "t": t_evt,
                "t_s": float(t_s),
                "index": getattr(ev, "index", None),
                "start": getattr(ev, "start", None),
                "length": getattr(ev, "length", None),
            }
        )
    events.sort(key=lambda e: (float(e.get("t_s", 0.0)), str(e.get("type", ""))))

    metadata = {
        "schema": "helix_clip_export_v1",
        "generated_at": utc_now_iso(),
        "helix_version": helix_version,
        "git_sha": current_git_sha(),
        "clip": {
            "format": "zip",
            "fps": int(fps),
            "start_s": float(clip.start_s),
            "end_s": float(clip.end_s),
            "duration_s": float(clip.span_s),
            "anchor_time_s": float(clip.anchor_time_s),
            "anchor_source": str(clip.anchor_source),
            "mp4_requested": bool(mp4_encoder is not None),
        },
        "timeline": {
            "loop_duration_s": float(loop_duration_s),
            "now_s": float(now_s),
            "time_units": str(event_time_units),
            "time_units_source": str(event_time_units_source),
            "loop_enabled": bool(loop_enabled),
            "loop_range_s": list(loop_range_s) if loop_range_s is not None else None,
            "event_times_s": [float(t) for t in event_times_s],
            "events": events,
        },
        "view": {
            "view_state": dict(view_state) if isinstance(view_state, Mapping) else None,
            "time_view_window_s": list(time_view_window_s) if time_view_window_s is not None else None,
        },
        "spec": {
            "spec_sha256": spec_sha,
            "sequence_sha256": seq_sha,
            "summary": redacted_spec_summary(spec),
        },
        "options": {
            "include_full_spec": bool(include_full_spec),
        },
        "encoder": (
            {"kind": "ffmpeg", "exe": mp4_encoder.exe, "codec": mp4_encoder.codec} if mp4_encoder is not None else None
        ),
    }

    return metadata, (spec_payload if include_full_spec else None)


def write_clip_zip(
    *,
    out_path: str | Path,
    gif_bytes: bytes,
    metadata: Mapping[str, Any],
    governance: Mapping[str, Any] | None = None,
    mp4_bytes: bytes | None = None,
    spec_payload: Mapping[str, Any] | None = None,
) -> str:
    path = Path(out_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)

    meta_bytes = json.dumps(dict(metadata), indent=2, sort_keys=True).encode("utf-8")

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        _zip_write_bytes(zf, "clip.gif", gif_bytes)
        _zip_write_bytes(zf, "metadata.json", meta_bytes)
        if governance is not None:
            try:
                gov_obj = dict(governance)
            except Exception:
                gov_obj = {"value": governance}
            _zip_write_bytes(
                zf,
                "governance/governance.json",
                json.dumps(gov_obj, indent=2, sort_keys=True).encode("utf-8"),
            )
            lines = gov_obj.get("stamp_lines") if isinstance(gov_obj, dict) else None
            if isinstance(lines, list) and lines:
                text = "Helix governance stamp\n" + "\n".join([str(line) for line in lines]) + "\n"
            else:
                text = "Helix governance stamp\n"
            _zip_write_bytes(zf, "governance/governance.txt", text.encode("utf-8"))
        if mp4_bytes:
            _zip_write_bytes(zf, "clip.mp4", mp4_bytes)
        if spec_payload is not None:
            _zip_write_bytes(zf, "spec.json", json.dumps(dict(spec_payload), indent=2, sort_keys=True).encode("utf-8"))
    return str(path)


__all__ = [
    "ClipWindow",
    "Mp4Encoder",
    "build_capture_metadata",
    "compute_clip_window",
    "detect_mp4_encoder",
    "encode_gif_bytes",
    "encode_mp4_bytes_ffmpeg",
    "event_cluster_bounds_seconds",
    "event_time_seconds",
    "frame_times_seconds",
    "redacted_spec_summary",
    "sha256_json",
    "sha256_text",
    "utc_now_iso",
    "write_clip_zip",
]
