from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class StudioBackendConfig:
    base_url: str = "http://localhost:8000"


def load_backend_config() -> StudioBackendConfig:
    base = os.getenv("HELIX_BACKEND_URL", StudioBackendConfig.base_url)
    return StudioBackendConfig(base_url=base)
