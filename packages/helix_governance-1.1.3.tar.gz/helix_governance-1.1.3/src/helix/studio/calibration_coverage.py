from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class CoverageMatch:
    """
    Coverage evaluation result for a run-context against a bundle coverage spec.

    - status:
        - "unspecified": bundle provides no usable coverage constraints
        - "in_coverage": run matches all constraints
        - "out_of_coverage": run violates one or more constraints
    """

    status: str
    matched: bool | None
    reasons: tuple[str, ...]


def _mapping(raw: Any) -> Mapping[str, Any]:
    return raw if isinstance(raw, Mapping) else {}


def _text(raw: Any) -> str:
    return str(raw or "").strip()


def _norm(raw: Any) -> str:
    return _text(raw).lower()


def _coerce_text_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return []
        parts = [p.strip() for p in raw.replace(";", ",").split(",")]
        return [p for p in parts if p]
    if isinstance(value, (list, tuple)):
        out: list[str] = []
        for item in value:
            txt = _text(item)
            if txt:
                out.append(txt)
        return out
    txt = _text(value)
    return [txt] if txt else []


def build_run_context_v1(
    *,
    intended_edit_spec: Mapping[str, Any] | None,
    reference_genome_id: str | None,
) -> dict[str, Any]:
    """
    Extract a stable, JSON-serializable run-context snapshot used for coverage matching.

    This is intentionally small: it contains only the fields most relevant to domain
    shift / calibration applicability, not the full run payload.
    """

    intended = _mapping(intended_edit_spec)
    measurement = _mapping(intended.get("measurement"))
    cell_types = _mapping(intended.get("cell_types"))
    editing_modality = _mapping(intended.get("editing_modality"))
    target = _mapping(intended.get("target"))
    guide_seq = _text(target.get("guide_rna_sequence"))
    guide_len = len(guide_seq) if guide_seq else None

    return {
        "schema": "helix.run_context/v1",
        "reference_genome_id": _text(reference_genome_id) or "unconfigured",
        "assay_type": measurement.get("assay_type"),
        "assay_definition_id": measurement.get("assay_definition_id"),
        "cell_types": _coerce_text_list(cell_types.get("cell_types")),
        "editing_modality": editing_modality.get("editing_modality"),
        "mode": editing_modality.get("mode"),
        "nuclease": editing_modality.get("nuclease"),
        "pam_class": editing_modality.get("pam_class"),
        "pam_profile": editing_modality.get("pam_profile"),
        "guide_length_nt": guide_len,
    }


def build_run_context_v1_from_summary(summary_v2: Mapping[str, Any]) -> dict[str, Any]:
    prov = _mapping(summary_v2.get("provenance"))
    data = _mapping(prov.get("data"))
    ref = _mapping(data.get("reference_genome"))
    intended = summary_v2.get("intended_edit_spec") if isinstance(summary_v2.get("intended_edit_spec"), Mapping) else None
    return build_run_context_v1(
        intended_edit_spec=intended,
        reference_genome_id=_text(ref.get("id") or "") or None,
    )


def evaluate_coverage(
    coverage: Mapping[str, Any] | None,
    *,
    run_context: Mapping[str, Any],
) -> CoverageMatch:
    """
    Evaluate a coverage spec against a run_context snapshot.

    Supported constraint forms (per field):
    - string: exact match
    - array: any-of match
    - object:
        - {"any_of": [...]}: any-of match
        - {"min": <n>, "max": <n>}: numeric range
    """

    cov = _mapping(coverage)
    if not cov:
        return CoverageMatch(status="unspecified", matched=None, reasons=tuple())

    constraints = cov.get("constraints")
    if isinstance(constraints, Mapping):
        rules = dict(constraints)
    else:
        # Back-compat: allow coverage to directly be a constraint map.
        rules = dict(cov)

    if not rules:
        return CoverageMatch(status="unspecified", matched=None, reasons=tuple())

    ctx = dict(run_context)
    mismatches: list[str] = []

    for key in sorted(rules.keys()):
        rule = rules.get(key)
        if key == "schema":
            continue

        value = ctx.get(key)
        if value is None or value == "" or value == []:
            mismatches.append(f"missing: {key}")
            continue

        # Normalize the run-side value.
        if isinstance(value, (list, tuple)):
            value_list = [_norm(v) for v in value if _norm(v)]
            value_scalar = ""
        else:
            value_list = []
            value_scalar = _norm(value)

        # Interpret rule forms.
        allowed: list[str] | None = None
        rmin: float | None = None
        rmax: float | None = None

        if isinstance(rule, Mapping):
            any_of = rule.get("any_of")
            if isinstance(any_of, Sequence) and not isinstance(any_of, (str, bytes)):
                allowed = [_norm(v) for v in any_of if _norm(v)]
            if "min" in rule:
                try:
                    rmin = float(rule.get("min"))
                except Exception:
                    rmin = None
            if "max" in rule:
                try:
                    rmax = float(rule.get("max"))
                except Exception:
                    rmax = None
        elif isinstance(rule, Sequence) and not isinstance(rule, (str, bytes)):
            allowed = [_norm(v) for v in rule if _norm(v)]
        else:
            txt = _norm(rule)
            allowed = [txt] if txt else None

        # Apply any_of match.
        if allowed is not None:
            if value_list:
                if not any(v in allowed for v in value_list):
                    mismatches.append(f"{key}: {sorted(set(value_list))} not in any_of={sorted(set(allowed))}")
            else:
                if value_scalar not in allowed:
                    mismatches.append(f"{key}: {value_scalar} not in any_of={sorted(set(allowed))}")
            continue

        # Apply numeric range.
        if rmin is not None or rmax is not None:
            try:
                vnum = float(value)
            except Exception:
                mismatches.append(f"{key}: non-numeric value")
                continue
            if rmin is not None and vnum < rmin:
                mismatches.append(f"{key}: {vnum} < min {rmin}")
            if rmax is not None and vnum > rmax:
                mismatches.append(f"{key}: {vnum} > max {rmax}")
            continue

        # Unknown rule shape; treat as non-blocking (coverage authoring error).
        continue

    matched = not mismatches
    return CoverageMatch(
        status="in_coverage" if matched else "out_of_coverage",
        matched=matched,
        reasons=tuple(mismatches),
    )


__all__ = [
    "CoverageMatch",
    "build_run_context_v1",
    "build_run_context_v1_from_summary",
    "evaluate_coverage",
]

