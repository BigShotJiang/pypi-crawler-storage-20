from __future__ import annotations

import math
from collections.abc import Sequence


def _clamp_window(
    start_s: float,
    end_s: float,
    *,
    clamp_start_s: float,
    clamp_end_s: float,
) -> tuple[float, float]:
    """Shift/clamp a window to live entirely inside [clamp_start_s, clamp_end_s]."""
    a = float(clamp_start_s)
    b = float(clamp_end_s)
    if b < a:
        a, b = b, a
    span_total = max(0.0, float(b) - float(a))

    start = float(start_s)
    end = float(end_s)
    if end < start:
        start, end = end, start
    span = max(0.0, float(end) - float(start))

    if span_total <= 1e-9:
        return a, a
    if span >= span_total - 1e-9:
        return a, b

    if start < a:
        end += a - start
        start = a
    if end > b:
        start -= end - b
        end = b
    start = max(a, min(b - span, start))
    end = start + span
    return float(start), float(end)


def fit_time_window_to_event_cluster(
    *,
    t_s: float,
    event_times_s: Sequence[float],
    duration_s: float,
    loop_range_s: tuple[float, float] | None = None,
    gap_threshold_s: float = 0.25,
    max_cluster_span_s: float = 6.0,
    pad_fraction: float = 0.15,
    default_span_s: float = 2.0,
) -> tuple[float, float]:
    """Fit a time window around the local "event cluster" near the playhead.

    This is used by the Studio scrubber "Fit to Locus" action so users land on
    the interesting part (events) instead of empty time.
    """
    try:
        loop = float(duration_s)
    except Exception:
        loop = 0.0
    if not (loop > 1e-6):
        return 0.0, 0.0

    clamp_a = 0.0
    clamp_b = loop
    if loop_range_s is not None:
        try:
            a = float(loop_range_s[0])
            b = float(loop_range_s[1])
        except Exception:
            a = b = 0.0
        if math.isfinite(a) and math.isfinite(b):
            if b < a:
                a, b = b, a
            a = max(0.0, min(loop, a))
            b = max(0.0, min(loop, b))
            if b - a > 1e-6:
                clamp_a, clamp_b = float(a), float(b)

    try:
        t = float(t_s)
    except Exception:
        t = 0.0
    if not math.isfinite(t):
        t = 0.0
    t = max(clamp_a, min(clamp_b, t))

    times: list[float] = []
    for raw in event_times_s or ():
        try:
            x = float(raw)
        except Exception:
            continue
        if not math.isfinite(x):
            continue
        if clamp_a - 1e-9 <= x <= clamp_b + 1e-9:
            times.append(x)
    times.sort()

    max_span = max(0.05, float(max_cluster_span_s))
    gap = max(0.0, float(gap_threshold_s))
    pad_frac = max(0.0, min(0.4, float(pad_fraction)))
    default_span = max(0.05, min(loop, float(default_span_s)))

    if not times:
        start = float(t) - default_span * 0.5
        end = float(t) + default_span * 0.5
        return _clamp_window(start, end, clamp_start_s=clamp_a, clamp_end_s=clamp_b)

    # Anchor = nearest event to current time.
    i = min(range(len(times)), key=lambda idx: abs(times[idx] - t))
    left = i
    right = i

    # Expand to form a local cluster: include neighbors while gaps are small.
    while True:
        can_left = False
        can_right = False
        gap_left = gap_right = 0.0
        if left > 0:
            gap_left = float(times[left]) - float(times[left - 1])
            can_left = gap_left <= gap and (float(times[right]) - float(times[left - 1])) <= max_span
        if right < len(times) - 1:
            gap_right = float(times[right + 1]) - float(times[right])
            can_right = gap_right <= gap and (float(times[right + 1]) - float(times[left])) <= max_span

        if can_left and can_right:
            if gap_left <= gap_right:
                left -= 1
            else:
                right += 1
            continue
        if can_left:
            left -= 1
            continue
        if can_right:
            right += 1
            continue
        break

    # Always try to include one neighbor on each side (context), if possible.
    if left == i and i > 0:
        cand = i - 1
        if float(times[right]) - float(times[cand]) <= max_span + 1e-9:
            left = cand
    if right == i and i < len(times) - 1:
        cand = i + 1
        if float(times[cand]) - float(times[left]) <= max_span + 1e-9:
            right = cand

    cluster_start = float(times[left])
    cluster_end = float(times[right])
    if cluster_end < cluster_start:
        cluster_start, cluster_end = cluster_end, cluster_start

    span = float(cluster_end) - float(cluster_start)
    if span <= 1e-6:
        # Single (or effectively single) event: give it a small readable window.
        start = float(times[i]) - default_span * 0.5
        end = float(times[i]) + default_span * 0.5
        return _clamp_window(start, end, clamp_start_s=clamp_a, clamp_end_s=clamp_b)

    pad = span * pad_frac
    start = cluster_start - pad
    end = cluster_end + pad

    # Ensure a minimum usable window, even for tight clusters.
    min_span = min(max_span, default_span)
    if float(end) - float(start) < min_span:
        center = float(times[i])
        start = center - min_span * 0.5
        end = center + min_span * 0.5

    return _clamp_window(start, end, clamp_start_s=clamp_a, clamp_end_s=clamp_b)

