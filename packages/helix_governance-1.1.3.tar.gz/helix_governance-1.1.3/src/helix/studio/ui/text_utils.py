"""UI helpers for text presentation."""

from __future__ import annotations

from PySide6.QtWidgets import QLabel, QWidget


def enable_word_wrap(container: QWidget) -> None:
    """Set word-wrap on all QLabel descendants so text gracefully wraps when space is tight."""

    for label in container.findChildren(QLabel):
        try:
            if not label.wordWrap():
                label.setWordWrap(True)
        except Exception:
            # Some custom label subclasses may not expose wordWrap; best-effort only.
            pass

