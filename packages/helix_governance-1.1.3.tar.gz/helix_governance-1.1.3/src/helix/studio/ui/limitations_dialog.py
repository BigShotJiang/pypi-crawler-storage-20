from __future__ import annotations

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget


class LimitationsDialog(QDialog):
    def __init__(
        self,
        *,
        summary_lines: list[str] | tuple[str, ...],
        banner: str,
        link_url: str | None,
        copy_text: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("CRISPR Edit DAG limitations")
        self.setModal(True)
        self.resize(620, 360)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Model limitations & invalid use cases", self)
        title.setStyleSheet("font-weight: 650; font-size: 14px; color: palette(window-text);")
        layout.addWidget(title)

        banner_label = QLabel(banner, self)
        banner_label.setWordWrap(True)
        banner_label.setStyleSheet("color: palette(window-text); font-size: 12px;")
        layout.addWidget(banner_label)

        bullets = "\n".join(f"<li>{line}</li>" for line in summary_lines)
        summary = QLabel(self)
        summary.setTextFormat(Qt.RichText)
        summary.setText(f"<ul>{bullets}</ul>")
        summary.setWordWrap(True)
        summary.setStyleSheet("color: palette(window-text); font-size: 12px;")
        layout.addWidget(summary)

        link_label = QLabel(self)
        link_label.setTextFormat(Qt.RichText)
        if link_url:
            link_label.setText(f"<a href=\"open\">{link_url}</a>")
            link_label.setTextInteractionFlags(Qt.TextBrowserInteraction)
            link_label.setStyleSheet("color: palette(link); font-size: 11px;")
            link_label.linkActivated.connect(lambda _=None: self._open_link(link_url))
        else:
            link_label.setText("Documentation link unavailable. Set DOCS_BASE_URL to enable.")
            link_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        layout.addWidget(link_label)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy link", self)
        copy_btn.clicked.connect(lambda: self._copy_to_clipboard(copy_text))
        actions.addWidget(copy_btn)

        close_btn = QPushButton("Close", self)
        close_btn.clicked.connect(self.accept)
        actions.addWidget(close_btn)

        layout.addStretch(1)
        layout.addLayout(actions)

    def _open_link(self, url: str) -> None:
        try:
            QDesktopServices.openUrl(QUrl(url))
        except Exception:
            pass

    def _copy_to_clipboard(self, text: str) -> None:
        try:
            QGuiApplication.clipboard().setText(text)
        except Exception:
            pass


__all__ = ["LimitationsDialog"]
