from __future__ import annotations

import json
import os
from typing import Any, Mapping

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from helix.studio.evidence_view_model import (
    build_evidence_overview,
    format_evidence_overview,
    load_matching_calibration_bundle_report,
    load_matching_calibration_metrics,
    mode_help_text,
    tier_help_text,
)
from helix.studio.calibration_coverage import build_run_context_v1_from_summary, evaluate_coverage


def _pretty_json(obj: Any) -> str:
    try:
        return json.dumps(obj, indent=2, sort_keys=True) + "\n"
    except Exception:
        return str(obj).strip() + "\n"


def _metric_definitions_text() -> str:
    return (
        "Heldout calibration metrics (scalar pred vs observed frequency)\n"
        "\n"
        "Definitions:\n"
        "- pearson_r / grade_correlation: correlation between pred and obs.\n"
        "- rmse: sqrt(mean((pred-obs)^2)). Lower is better.\n"
        "- mae: mean(|pred-obs|). Lower is better.\n"
        "- bias: mean(pred-obs). Near 0 is better.\n"
        "- ece: expected calibration error from reliability bins. Near 0 is better.\n"
        "- mce: max per-bin |pred_mean-obs_mean|. Near 0 is better.\n"
        "- brier: mean((pred-obs)^2). Lower is better.\n"
        "- log_loss: Bernoulli cross-entropy using obs as the Bernoulli mean. Lower is better.\n"
        "\n"
        "What “good” looks like (heuristics):\n"
        "- Reliability curve near the diagonal across the range users care about.\n"
        "- Small ece/mce, and metrics that stay stable across slices.\n"
        "- Adequate n in each slice/bin; otherwise metrics can look deceptively clean.\n"
    )


class ReliabilityPlot(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFrameShape(QFrame.NoFrame)
        self.setMinimumHeight(220)
        self._points: list[tuple[float, float, int]] = []
        self._accent = QColor(58, 232, 200)

    def set_bins(self, bins) -> None:
        points: list[tuple[float, float, int]] = []
        for b in bins or []:
            pm = getattr(b, "pred_mean", None)
            om = getattr(b, "obs_mean", None)
            n = int(getattr(b, "n", 0) or 0)
            if pm is None or om is None:
                continue
            try:
                x = float(pm)
                y = float(om)
            except Exception:
                continue
            if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
                continue
            points.append((x, y, n))
        points.sort(key=lambda t: t[0])
        self._points = points
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)

        rect = QRectF(self.rect()).adjusted(10, 10, -10, -10)
        if rect.width() <= 10 or rect.height() <= 10:
            return

        bg = QColor(self.palette().base().color())
        p.fillRect(rect, bg)

        border = QColor(self.palette().mid().color())
        p.setPen(QPen(border, 1.0))
        p.drawRoundedRect(rect, 8, 8)

        # Axes and diagonal.
        axis = QColor(self.palette().mid().color())
        axis.setAlphaF(0.55)
        p.setPen(QPen(axis, 1.0))
        p.drawLine(QPointF(rect.left(), rect.bottom()), QPointF(rect.right(), rect.bottom()))
        p.drawLine(QPointF(rect.left(), rect.bottom()), QPointF(rect.left(), rect.top()))

        diag = QColor(self.palette().mid().color())
        diag.setAlphaF(0.45)
        p.setPen(QPen(diag, 1.2, Qt.DashLine))
        p.drawLine(QPointF(rect.left(), rect.bottom()), QPointF(rect.right(), rect.top()))

        if not self._points:
            p.setPen(QPen(QColor(self.palette().mid().color()), 1.0))
            p.drawText(rect, Qt.AlignCenter, "No reliability data available")
            return

        def to_px(x: float, y: float) -> QPointF:
            px = rect.left() + rect.width() * max(0.0, min(1.0, x))
            py = rect.bottom() - rect.height() * max(0.0, min(1.0, y))
            return QPointF(px, py)

        pts = [to_px(x, y) for (x, y, _n) in self._points]
        if len(pts) >= 2:
            p.setPen(QPen(self._accent, 2.0))
            for a, b in zip(pts[:-1], pts[1:]):
                p.drawLine(a, b)

        p.setPen(Qt.NoPen)
        p.setBrush(self._accent)
        for (x, y, n) in self._points:
            pt = to_px(x, y)
            r = 3.0
            if n >= 50:
                r = 5.0
            elif n >= 10:
                r = 4.0
            p.drawEllipse(pt, r, r)


class HeldoutCalibrationPanel(QWidget):
    def __init__(self, *, overview, run_context: Mapping[str, Any], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._overview = overview
        self._run_context = dict(run_context)
        self._report = load_matching_calibration_bundle_report(overview)
        self._coverage_match = (
            evaluate_coverage(self._report.coverage, run_context=self._run_context) if self._report is not None else None
        )

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)

        header_row = QWidget(self)
        header_layout = QHBoxLayout(header_row)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(8)

        title = QLabel("Heldout calibration", header_row)
        title.setStyleSheet("font-weight: 700;")
        header_layout.addWidget(title)
        header_layout.addStretch(1)

        self._slice_combo = QComboBox(header_row)
        self._slice_combo.setMinimumWidth(220)
        self._slice_combo.setToolTip("Slice selector (e.g., overall vs locus_set subsets)")
        self._slice_combo.currentIndexChanged.connect(self._on_slice_changed)
        header_layout.addWidget(self._slice_combo)

        copy_btn = QPushButton("Copy bundle JSON", header_row)
        copy_btn.setObjectName("SecondaryButton")
        copy_btn.clicked.connect(self._copy_bundle_json)
        header_layout.addWidget(copy_btn)

        root.addWidget(header_row)

        body = QWidget(self)
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(10)

        self._plot = ReliabilityPlot(body)
        body_layout.addWidget(self._plot, stretch=2)

        right = QWidget(body)
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(6)

        self._meta = QLabel("", right)
        self._meta.setWordWrap(True)
        self._meta.setStyleSheet("color: palette(mid); font-size: 11px;")
        right_layout.addWidget(self._meta)

        self._metrics = QLabel("", right)
        self._metrics.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._metrics.setStyleSheet("font-size: 11px;")
        self._metrics.setWordWrap(True)
        right_layout.addWidget(self._metrics, stretch=1)

        self._coverage = QLabel("", right)
        self._coverage.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._coverage.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._coverage.setWordWrap(True)
        right_layout.addWidget(self._coverage)

        body_layout.addWidget(right, stretch=3)
        root.addWidget(body)

        if self._report is None or not self._report.slices:
            self._slice_combo.addItem("overall")
            self._meta.setText("No calibration bundle found (configure HELIX_CALIBRATION_BUNDLE_DIR/PATH).")
            self._metrics.setText("Metrics unavailable.")
            self._coverage.setText("")
            self._plot.set_bins([])
        else:
            for s in self._report.slices:
                self._slice_combo.addItem(s.slice_id)
            self._on_slice_changed(0)

    def _matching_bundle_json(self) -> Mapping[str, Any] | None:
        try:
            from helix.calibration.bundle import find_calibration_bundle
        except Exception:
            return None

        requested_ds = self._overview.calibration_dataset.id
        calibration_dataset_id = None if requested_ds in {"", "unconfigured", "unavailable"} else requested_ds
        try:
            bundle = find_calibration_bundle(
                model_id=self._overview.model.model_id,
                model_version=self._overview.model.model_version,
                model_hash=self._overview.model.model_hash if self._overview.model.model_hash.startswith("sha256:") else None,
                calibration_dataset_id=calibration_dataset_id,
            )
        except Exception:
            return None
        return bundle if isinstance(bundle, Mapping) else None

    def _copy_bundle_json(self) -> None:
        bundle = self._matching_bundle_json()
        payload: Any = bundle if bundle is not None else (self._report.__dict__ if self._report is not None else {})
        try:
            QApplication.clipboard().setText(_pretty_json(payload))
        except Exception:
            return

    def _on_slice_changed(self, idx: int) -> None:
        if self._report is None or not self._report.slices:
            return
        sid = self._slice_combo.currentText().strip()
        slice_obj = next((s for s in self._report.slices if s.slice_id == sid), None)
        if slice_obj is None:
            return

        self._plot.set_bins(slice_obj.bins)

        m = slice_obj.metrics
        parts: list[str] = []
        if m.n is not None:
            parts.append(f"n={m.n}")
        if m.pearson_r is not None:
            parts.append(f"pearson_r={m.pearson_r:.3f}")
        if m.rmse is not None:
            parts.append(f"rmse={m.rmse:.3f}")
        if m.mae is not None:
            parts.append(f"mae={m.mae:.3f}")
        if m.bias is not None:
            parts.append(f"bias={m.bias:.3f}")
        if m.ece is not None:
            parts.append(f"ece={m.ece:.3f}")
        if m.mce is not None:
            parts.append(f"mce={m.mce:.3f}")
        if m.brier is not None:
            parts.append(f"brier={m.brier:.3f}")
        if m.log_loss is not None:
            parts.append(f"log_loss={m.log_loss:.3f}")
        self._metrics.setText(" · ".join(parts) if parts else "Metrics unavailable.")

        bins = self._report.bins_count
        bins_txt = str(bins) if isinstance(bins, int) else "unavailable"
        target_txt = ""
        if isinstance(self._report.target, Mapping) and self._report.target:
            tgt = self._report.target
            target_id = str(tgt.get("target_id") or tgt.get("scalar_id") or tgt.get("id") or "").strip()
            if target_id:
                target_txt = f" · target={target_id}"

        cov_status = ""
        cov_details = ""
        if self._coverage_match is None or self._coverage_match.status == "unspecified":
            cov_status = "coverage=UNSPECIFIED"
        elif self._coverage_match.status == "in_coverage":
            cov_status = "coverage=IN_COVERAGE"
        else:
            cov_status = "coverage=OUT_OF_COVERAGE"
            cov_details = "\n".join(self._coverage_match.reasons[:12])
            if len(self._coverage_match.reasons) > 12:
                cov_details = cov_details + f"\n…({len(self._coverage_match.reasons) - 12} more)"

        self._meta.setText(
            f"{cov_status} · bundle={self._report.bundle_id} · {self._report.bundle_hash} · bins={bins_txt} · eval_code={self._report.evaluation_code_hash}{target_txt}"
        )

        if self._report.coverage is None:
            self._coverage.setText("Coverage: not specified")
        else:
            base = "Coverage:\n" + _pretty_json(self._report.coverage).strip()
            if cov_details:
                base = base + "\n\nCoverage mismatches:\n" + cov_details
            self._coverage.setText(base)


class EvidenceDialog(QDialog):
    def __init__(
        self,
        *,
        run_summary_v2: Mapping[str, Any],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Evidence & Calibration")
        self.setModal(False)
        self.resize(880, 620)

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(8)

        overview = build_evidence_overview(run_summary_v2)
        metrics = load_matching_calibration_metrics(overview)

        header = QLabel(mode_help_text(decision_mode=overview.decision_mode).strip(), self)
        header.setWordWrap(True)
        header.setStyleSheet("color: palette(window-text); font-size: 12px; font-weight: 700;")
        root.addWidget(header)

        env_row = QWidget(self)
        env_layout = QHBoxLayout(env_row)
        env_layout.setContentsMargins(0, 0, 0, 0)
        env_layout.setSpacing(8)
        env_label = QLabel("Calibration bundle lookup:", env_row)
        env_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        env_layout.addWidget(env_label)
        bundle_path = os.getenv("HELIX_CALIBRATION_BUNDLE_PATH") or ""
        bundle_dir = os.getenv("HELIX_CALIBRATION_BUNDLE_DIR") or ""
        env_value = bundle_path or bundle_dir or "unconfigured"
        env_value_label = QLabel(env_value, env_row)
        env_value_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        env_value_label.setStyleSheet("color: palette(window-text); font-size: 11px;")
        env_layout.addWidget(env_value_label, stretch=1)
        root.addWidget(env_row)

        tabs = QTabWidget(self)
        root.addWidget(tabs, stretch=1)

        # ---- Evidence / Calibration ----
        evidence_tab = QWidget(tabs)
        evidence_layout = QVBoxLayout(evidence_tab)
        evidence_layout.setContentsMargins(0, 0, 0, 0)
        evidence_layout.setSpacing(6)
        run_ctx = build_run_context_v1_from_summary(run_summary_v2)
        evidence_layout.addWidget(HeldoutCalibrationPanel(overview=overview, run_context=run_ctx, parent=evidence_tab))
        evidence_text = QPlainTextEdit(evidence_tab)
        evidence_text.setReadOnly(True)
        evidence_text.setPlainText(format_evidence_overview(overview, calibration_metrics=metrics))
        evidence_layout.addWidget(evidence_text)
        tabs.addTab(evidence_tab, "Evidence")

        # ---- Provenance JSON ----
        provenance_tab = QWidget(tabs)
        prov_layout = QVBoxLayout(provenance_tab)
        prov_layout.setContentsMargins(0, 0, 0, 0)
        prov_layout.setSpacing(6)
        prov = run_summary_v2.get("provenance") if isinstance(run_summary_v2.get("provenance"), Mapping) else {}
        prov_text = QPlainTextEdit(provenance_tab)
        prov_text.setReadOnly(True)
        prov_text.setPlainText(_pretty_json(prov))
        prov_layout.addWidget(prov_text)
        tabs.addTab(provenance_tab, "Provenance JSON")

        # ---- Tiers ----
        tiers_tab = QWidget(tabs)
        tiers_layout = QVBoxLayout(tiers_tab)
        tiers_layout.setContentsMargins(0, 0, 0, 0)
        tiers_layout.setSpacing(6)
        tiers_text = QPlainTextEdit(tiers_tab)
        tiers_text.setReadOnly(True)
        tiers_text.setPlainText(tier_help_text(max_rank=64))
        tiers_layout.addWidget(tiers_text)
        tabs.addTab(tiers_tab, "Tiers")

        # ---- Run context ----
        context_tab = QWidget(tabs)
        context_layout = QVBoxLayout(context_tab)
        context_layout.setContentsMargins(0, 0, 0, 0)
        context_layout.setSpacing(6)
        ctx_text = QPlainTextEdit(context_tab)
        ctx_text.setReadOnly(True)
        ctx_text.setPlainText(_pretty_json(run_ctx))
        context_layout.addWidget(ctx_text)
        tabs.addTab(context_tab, "Run context")

        # ---- Bundle JSON ----
        bundle_tab = QWidget(tabs)
        bundle_layout = QVBoxLayout(bundle_tab)
        bundle_layout.setContentsMargins(0, 0, 0, 0)
        bundle_layout.setSpacing(6)
        bundle_text = QPlainTextEdit(bundle_tab)
        bundle_text.setReadOnly(True)
        bundle_payload: Mapping[str, Any] | None = None
        try:
            from helix.calibration.bundle import find_calibration_bundle

            requested_ds = overview.calibration_dataset.id
            calibration_dataset_id = None if requested_ds in {"", "unconfigured", "unavailable"} else requested_ds
            found = find_calibration_bundle(
                model_id=overview.model.model_id,
                model_version=overview.model.model_version,
                model_hash=overview.model.model_hash if overview.model.model_hash.startswith("sha256:") else None,
                calibration_dataset_id=calibration_dataset_id,
            )
            if isinstance(found, Mapping):
                bundle_payload = found
        except Exception:
            bundle_payload = None
        bundle_text.setPlainText(_pretty_json(bundle_payload) if bundle_payload is not None else "No calibration bundle found.\n")
        bundle_layout.addWidget(bundle_text)
        tabs.addTab(bundle_tab, "Bundle JSON")

        # ---- Metrics ----
        metrics_tab = QWidget(tabs)
        metrics_layout = QVBoxLayout(metrics_tab)
        metrics_layout.setContentsMargins(0, 0, 0, 0)
        metrics_layout.setSpacing(6)
        metrics_text = QPlainTextEdit(metrics_tab)
        metrics_text.setReadOnly(True)
        metrics_text.setPlainText(_metric_definitions_text())
        metrics_layout.addWidget(metrics_text)
        tabs.addTab(metrics_tab, "Metrics")

        # ---- Footer ----
        footer = QWidget(self)
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(0, 0, 0, 0)
        footer_layout.setSpacing(8)
        footer_layout.addStretch(1)
        close_btn = QPushButton("Close", footer)
        close_btn.clicked.connect(self.close)
        footer_layout.addWidget(close_btn)
        root.addWidget(footer)
