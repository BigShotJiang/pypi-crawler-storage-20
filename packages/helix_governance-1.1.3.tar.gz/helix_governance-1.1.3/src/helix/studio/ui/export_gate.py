from __future__ import annotations

from typing import Any, Mapping, MutableMapping

from PySide6.QtWidgets import QDialog, QWidget

from helix.studio.export_gate import ExportDecisionContext, set_export_prompt_suppressed, should_prompt_export
from helix.studio.governance_stamp import decision_grade_blocked_reasons
from helix.studio.experiment_intent_spec import (
    EXPERIMENT_INTENT_SPEC_SCHEMA_ID,
    experiment_intent_spec_from_dict_with_error,
    experiment_intent_spec_sha256,
    intent_spec_missing_required_fields,
)
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.ui.export_gate_dialog import ExportGateDialog


def ensure_export_allowed(
    parent: QWidget,
    *,
    action_title: str,
    ctx: ExportDecisionContext,
    session_acks: MutableMapping[str, bool],
    run_summary_v2: Mapping[str, Any] | None = None,
    experiment_intent_spec: Mapping[str, Any] | None = None,
    experiment_spec: Mapping[str, Any] | None = None,
    edit_plan: Mapping[str, Any] | None = None,
    require_wetlab_preflight: bool = False,
    policy: Mapping[str, Any] | None = None,
) -> bool:
    """
    Enforce an explicit acknowledgement for non-decision-grade exports.

    - Decision-grade: allowed without prompting.
    - Exploratory/demo: prompt once per session key (mode_class + run_id when available).
    """
    # Hard gate: intent spec must exist, validate, and be bound to the design spec.
    intent_errors: list[str] = []

    intent_status = None
    intent_missing_fields: list[str] = []
    ref_status = None

    summary_has_intent = isinstance(run_summary_v2, Mapping) and isinstance(run_summary_v2.get("experiment_intent_spec"), Mapping)
    if summary_has_intent:
        block = run_summary_v2.get("experiment_intent_spec") if isinstance(run_summary_v2.get("experiment_intent_spec"), Mapping) else {}
        intent_status = str(block.get("status") or "").strip().lower()
        missing = block.get("missing_fields") if isinstance(block.get("missing_fields"), list) else []
        intent_missing_fields = [str(x) for x in missing if str(x)]
        ref = run_summary_v2.get("experiment_intent_ref") if isinstance(run_summary_v2.get("experiment_intent_ref"), Mapping) else {}
        ref_status = str(ref.get("status") or "").strip().lower()
    else:
        present = isinstance(experiment_intent_spec, Mapping)
        if not present:
            intent_status = "missing"
        else:
            payload, err = experiment_intent_spec_from_dict_with_error(experiment_intent_spec)
            if err:
                intent_status = "invalid"
                intent_errors.append(f"INTENT_SPEC_INVALID_SCHEMA: {err}")
            else:
                intent_status = "incomplete" if intent_spec_missing_required_fields(payload) else "declared"
                intent_missing_fields = intent_spec_missing_required_fields(payload)

            if isinstance(experiment_spec, Mapping):
                spec_payload = experiment_spec_to_dict(experiment_spec)
                ref_block = spec_payload.get("intentRef") if isinstance(spec_payload.get("intentRef"), Mapping) else None
                ref_kind = str(ref_block.get("kind") or "") if isinstance(ref_block, Mapping) else ""
                ref_sha = str(ref_block.get("sha256") or "") if isinstance(ref_block, Mapping) else ""
                intent_sha = experiment_intent_spec_sha256(payload)
                if not isinstance(ref_block, Mapping):
                    ref_status = "missing"
                elif ref_kind and ref_kind != EXPERIMENT_INTENT_SPEC_SCHEMA_ID:
                    ref_status = "invalid"
                elif ref_sha and ref_sha == intent_sha:
                    ref_status = "matched"
                else:
                    ref_status = "mismatch" if ref_sha else "missing"

    if intent_status in {"", None, "missing"}:
        intent_errors.append("MISSING_INTENT_SPEC")
    elif intent_status == "invalid":
        if not intent_errors:
            intent_errors.append("INTENT_SPEC_INVALID_SCHEMA")
    elif intent_status == "incomplete":
        detail = "INTENT_SPEC_INCOMPLETE_REQUIRED_FIELDS"
        if intent_missing_fields:
            detail += " (missing: " + ", ".join(intent_missing_fields) + ")"
        intent_errors.append(detail)

    if ref_status in {"", None, "missing", "mismatch", "invalid"}:
        intent_errors.append(f"INTENT_REF_NOT_BOUND (intentRef.status={ref_status or 'missing'})")

    if intent_errors:
        try:
            from PySide6.QtWidgets import QMessageBox

            QMessageBox.warning(
                parent,
                action_title,
                "Export blocked: Experiment Intent Spec is required.\n\n"
                + "\n".join([f"- {e}" for e in intent_errors])
                + "\n\nFix: Fill the Experiment intent (decision record) panel and save; it will auto-bind `experiment_spec.intentRef`.",
            )
        except Exception:
            pass
        return False

    if require_wetlab_preflight:
        wetlab_errors: list[str] = []
        wetlab_paths: list[str] = []
        wetlab_failed_to_run = False
        try:
            from helix.wetlab.preflight_linter import lint_wetlab_preflight, wetlab_preflight_report_to_dict

            export_policy = policy if isinstance(policy, Mapping) else None
            export_policy_hash = None
            if export_policy is None:
                try:
                    from helix.scientific_contract import load_policy

                    export_policy, export_policy_hash, _det_class, _policy_path = load_policy(None)
                except Exception:
                    export_policy = {}
                    export_policy_hash = None

            wetlab_cfg = (
                export_policy.get("wetlabPreflight")
                if isinstance(export_policy, Mapping) and isinstance(export_policy.get("wetlabPreflight"), Mapping)
                else {}
            )
            if not bool(wetlab_cfg.get("enabled", False)):
                export_policy = {
                    "wetlabPreflight": {
                        "enabled": True,
                        "rules": {
                            "WLP001": {"enabled": True, "severity": "error"},
                            "WLP002": {"enabled": True, "severity": "error"},
                            "WLP005": {"enabled": True, "severity": "error"},
                            "WLP003": {"enabled": False},
                            "WLP004": {"enabled": False},
                            "WLP101": {"enabled": False},
                            "WLP102": {"enabled": False},
                            "WLP103": {"enabled": False},
                        },
                    }
                }
                export_policy_hash = None

            spec_payload = experiment_spec_to_dict(experiment_spec) if isinstance(experiment_spec, Mapping) else {}
            plan_payload = dict(edit_plan) if isinstance(edit_plan, Mapping) else {}
            report = lint_wetlab_preflight(
                experiment_spec=spec_payload,
                edit_plan=plan_payload,
                policy=export_policy,
                generated_at_utc="1970-01-01T00:00:00Z",
                policy_id=str(export_policy.get("policyId") or export_policy.get("policy_id") or "").strip() or None,
                policy_hash=str(export_policy_hash or "").strip() or None,
            )
            report_payload = wetlab_preflight_report_to_dict(report)
            if not bool(report_payload.get("ok")):
                findings = report_payload.get("findings") if isinstance(report_payload.get("findings"), list) else []
                for finding in findings:
                    if not isinstance(finding, Mapping):
                        continue
                    if str(finding.get("severity") or "").strip().lower() != "error":
                        continue
                    msg = str(finding.get("message") or "").strip()
                    if msg:
                        wetlab_errors.append(msg)
                    ev_required = (
                        finding.get("evidence_required") if isinstance(finding.get("evidence_required"), list) else []
                    )
                    for ev in ev_required:
                        if not isinstance(ev, Mapping):
                            continue
                        ph = str(ev.get("path_hint") or "").strip()
                        if ph:
                            wetlab_paths.append(ph)
        except Exception as exc:
            wetlab_failed_to_run = True
            detail = str(exc).strip()
            wetlab_errors = ["WETLAB_PREFLIGHT_UNAVAILABLE" + (f": {detail}" if detail else "")]
            wetlab_paths = []

        if wetlab_errors:
            try:
                from PySide6.QtWidgets import QMessageBox

                unique_paths = sorted({p for p in wetlab_paths if p})
                fix = (
                    "Fix: restart Studio and ensure the active policy enables wet-lab preflight."
                    if wetlab_failed_to_run
                    else (
                        "Fix: add the required fields (HelixSpec) and re-run:\n" + "\n".join([f"- {p}" for p in unique_paths])
                        if unique_paths
                        else "Fix: add the required controls/validation metadata (HelixSpec) and re-run."
                    )
                )
                msg = (
                    "Export blocked: wet-lab readiness gates failed.\n\n"
                    + "\n".join([f"- {e}" for e in wetlab_errors])
                    + "\n\n"
                    + fix
                )
                QMessageBox.warning(parent, action_title, msg)
            except Exception:
                pass
            return False

    if not should_prompt_export(ctx, session_acks):
        return True

    mode_label = "DEMO" if ctx.is_demo else "EXPLORATORY"
    title = f"{mode_label} export (not decision-grade)"
    try:
        blockers = decision_grade_blocked_reasons(run_summary_v2) if isinstance(run_summary_v2, Mapping) else []
        dialog = ExportGateDialog(
            title=title,
            decision_grade_enabled=False,
            decision_grade_disabled_reason="Decision-grade export is disabled until readiness gates pass.",
            decision_grade_disabled_blockers=blockers,
            require_exploratory_ack=True,
            default_export_class="exploratory",
            parent=parent,
        )
        dialog.setWindowTitle(title)
        try:
            dialog.setProperty("export_action_title", str(action_title))
        except Exception:
            pass
        if dialog.exec() != QDialog.Accepted:
            return False
        payload = dialog.result_payload()
    except Exception:
        return True

    if payload is None:
        return False
    if payload.suppress_exploratory_prompt_this_session:
        set_export_prompt_suppressed(ctx, session_acks)
    return True


__all__ = ["ensure_export_allowed"]
