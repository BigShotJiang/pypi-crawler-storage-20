from __future__ import annotations

import logging
import os
from typing import Optional

from PySide6.QtCore import QRect
from PySide6.QtGui import QGuiApplication, QWindow
from PySide6.QtWidgets import QWidget

from helix.gui.qt_geometry import qt_move

LOGGER = logging.getLogger(__name__)
_DEBUG_GEOMETRY = os.getenv("HELIX_STUDIO_DEBUG_GEOMETRY", "0") == "1"


def _safe_available_geometry(screen) -> QRect | None:
    try:
        geo: QRect = screen.availableGeometry()
    except RuntimeError:
        return None
    if geo.width() <= 0 or geo.height() <= 0:
        return None
    return geo


def _available_geometry_for_widget(
    widget: QWidget,
    *,
    prefer_window_center: bool,
) -> QRect | None:
    """
    Choose an available geometry rectangle for positioning.

    Notes:
    - In PySide6, returning a QScreen derived from QWindow.screen() can be fragile
      because the wrapper may be tied to the lifetime of the temporary QWindow
      wrapper. Returning a QRect avoids that class of issues.
    """
    # For restored windows, prefer the screen containing the window center.
    if prefer_window_center:
        try:
            center = widget.frameGeometry().center()
        except Exception:
            center = None
        if center is not None:
            for screen in QGuiApplication.screens() or []:
                geo = _safe_available_geometry(screen)
                if geo is not None and geo.contains(center):
                    return geo

    # For new dialogs, prefer the screen of the currently focused window.
    focus_win: Optional[QWindow] = QGuiApplication.focusWindow()
    if focus_win is not None:
        try:
            focus_screen = focus_win.screen()
        except RuntimeError:
            focus_screen = None
        if focus_screen is not None:
            geo = _safe_available_geometry(focus_screen)
            if geo is not None:
                return geo

    handle = widget.windowHandle()
    if handle is not None:
        try:
            handle_screen = handle.screen()
        except RuntimeError:
            handle_screen = None
        if handle_screen is not None:
            geo = _safe_available_geometry(handle_screen)
            if geo is not None:
                return geo

    primary = QGuiApplication.primaryScreen()
    if primary is None:
        return None
    return _safe_available_geometry(primary)


def _clamp_int(value: int, lo: int, hi: int) -> int:
    if hi < lo:
        return lo
    return max(lo, min(int(value), hi))


def ensure_on_screen(widget: QWidget, *, margin: int = 24) -> None:
    """Ensure *widget* is fully visible within the active screen.

    This is a best-effort helper for multi-monitor and laptop/external-display
    workflows where restored geometry can end up partially offscreen.
    """
    if os.environ.get("HELIX_STUDIO_HEADLESS", "0") == "1":
        return
    geo = _available_geometry_for_widget(widget, prefer_window_center=True)
    if geo is None:
        return

    # If the widget is larger than the available screen, shrink it (frameless
    # dialogs are otherwise impossible to recover without dragging blind).
    try:
        frame = widget.frameGeometry()
        extra_w = max(0, int(frame.width()) - int(widget.width()))
        extra_h = max(0, int(frame.height()) - int(widget.height()))
    except Exception:
        extra_w = 0
        extra_h = 0

    # Shrink based on the *frame* size, not just client area, so decorated
    # windows also end up fully contained within the available geometry.
    max_w = max(320, geo.width() - margin - extra_w)
    max_h = max(240, geo.height() - margin - extra_h)
    old_w = widget.width()
    old_h = widget.height()
    w = min(widget.width(), max_w)
    h = min(widget.height(), max_h)
    if w != widget.width() or h != widget.height():
        try:
            widget.resize(w, h)
        except Exception:
            pass
        if _DEBUG_GEOMETRY and (w < old_w or h < old_h):
            LOGGER.debug(
                "Restored geometry exceeds available screen, shrinking: "
                "widget=%s %sx%s -> %sx%s available=%s margin=%s",
                type(widget).__name__,
                old_w,
                old_h,
                w,
                h,
                geo,
                margin,
            )

    frame = widget.frameGeometry()
    x_min = geo.x()
    y_min = geo.y()
    x_max = geo.x() + geo.width() - frame.width()
    y_max = geo.y() + geo.height() - frame.height()
    x = _clamp_int(frame.x(), x_min, x_max)
    y = _clamp_int(frame.y(), y_min, y_max)
    qt_move(widget, x, y)


def center_on_focused_window(widget: QWidget) -> None:
    """
    Center the given widget on the screen that currently has the
    focused Helix window (or its own window), falling back to primary.
    """
    if os.environ.get("HELIX_STUDIO_HEADLESS", "0") == "1":
        return
    try:
        platform_name = (QGuiApplication.platformName() or "").lower()
    except Exception:
        platform_name = ""
    if os.environ.get("QT_QPA_PLATFORM", "").lower() in {"offscreen", "minimal"} or platform_name in {"offscreen", "minimal"}:
        return
    geo = _available_geometry_for_widget(widget, prefer_window_center=False)
    if geo is None:
        return

    # Shrink to fit before centering so the widget never opens offscreen on
    # small displays or when DPI scaling increases logical pixel sizes.
    try:
        max_w = max(320, geo.width() - 24)
        max_h = max(240, geo.height() - 24)
        widget.resize(min(widget.width(), max_w), min(widget.height(), max_h))
    except Exception:
        pass

    frame = widget.frameGeometry()
    frame.moveCenter(geo.center())
    qt_move(widget, frame.topLeft())
    ensure_on_screen(widget)
