from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QRadioButton,
    QVBoxLayout,
    QWidget,
)


@dataclass(frozen=True)
class ExportGateResult:
    export_class: str  # "exploratory" | "decision_grade"
    suppress_exploratory_prompt_this_session: bool


class ExportGateDialog(QDialog):
    def __init__(
        self,
        *,
        title: str,
        decision_grade_enabled: bool,
        decision_grade_disabled_reason: str | None = None,
        decision_grade_disabled_blockers: Sequence[Mapping[str, Any]] | None = None,
        require_exploratory_ack: bool,
        default_export_class: str = "exploratory",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.resize(620, 280)

        self._result: ExportGateResult | None = None
        self._require_exploratory_ack = bool(require_exploratory_ack)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        header = QLabel("Choose export class", self)
        header.setStyleSheet("font-weight: 650; font-size: 14px; color: palette(window-text);")
        layout.addWidget(header)

        body = QLabel(
            "Exports always embed provenance.\n"
            "Exploratory/Demo exports are explicitly marked as not decision-grade.\n"
            "Decision-grade export is only available when readiness gates pass.",
            self,
        )
        body.setWordWrap(True)
        body.setStyleSheet("color: palette(window-text); font-size: 12px;")
        layout.addWidget(body)

        self._radio_group = QButtonGroup(self)
        self._expl_radio = QRadioButton("Export (Exploratory / Demo)", self)
        self._dg_radio = QRadioButton("Export (Decision-grade)", self)
        self._radio_group.addButton(self._expl_radio)
        self._radio_group.addButton(self._dg_radio)

        if not decision_grade_enabled:
            self._dg_radio.setEnabled(False)
            if decision_grade_disabled_reason:
                self._dg_radio.setToolTip(str(decision_grade_disabled_reason))

        default = str(default_export_class or "exploratory")
        if default == "decision_grade" and decision_grade_enabled:
            self._dg_radio.setChecked(True)
        else:
            self._expl_radio.setChecked(True)

        layout.addWidget(self._expl_radio)
        layout.addWidget(self._dg_radio)

        blockers = list(decision_grade_disabled_blockers or [])
        if (not decision_grade_enabled) and blockers:
            block_header = QLabel("Why decision-grade is disabled", self)
            block_header.setStyleSheet("font-weight: 650; font-size: 12px; color: palette(window-text);")
            layout.addWidget(block_header)

            lines: list[str] = []
            for r in blockers:
                title = str(r.get("title") or "").strip()
                detail = str(r.get("detail") or "").strip()
                fix = str(r.get("fix") or "").strip()
                if not title:
                    continue
                body = title + (f" — {detail}" if detail else "")
                lines.append(f"• {body}")
                if fix:
                    lines.append(f"  Fix: {fix}")
            block_text = QLabel("\n".join(lines).strip(), self)
            block_text.setWordWrap(True)
            block_text.setTextInteractionFlags(Qt.TextSelectableByMouse)
            block_text.setStyleSheet("color: palette(window-text); font-size: 11px;")
            layout.addWidget(block_text)

        self._ack = QCheckBox("I understand this export is exploratory and not decision-grade.", self)
        self._ack.setChecked(False)
        layout.addWidget(self._ack)

        self._suppress = QCheckBox("Don’t show this prompt again this session", self)
        self._suppress.setChecked(False)
        layout.addWidget(self._suppress)

        actions = QHBoxLayout()
        actions.addStretch(1)

        cancel_btn = QPushButton("Cancel", self)
        cancel_btn.clicked.connect(self.reject)
        actions.addWidget(cancel_btn)

        self._continue_btn = QPushButton("Continue", self)
        self._continue_btn.clicked.connect(self._on_continue)
        self._continue_btn.setDefault(True)
        actions.addWidget(self._continue_btn)

        layout.addStretch(1)
        layout.addLayout(actions)

        self._radio_group.buttonToggled.connect(lambda *_: self._refresh_enabled())  # type: ignore[arg-type]
        self._ack.stateChanged.connect(lambda *_: self._refresh_enabled())  # type: ignore[arg-type]
        self._refresh_enabled()

    def _refresh_enabled(self) -> None:
        is_expl = bool(self._expl_radio.isChecked())
        show_ack = bool(is_expl and self._require_exploratory_ack)
        self._ack.setVisible(show_ack)
        self._suppress.setVisible(show_ack)

        if show_ack:
            self._continue_btn.setEnabled(bool(self._ack.isChecked()))
        else:
            self._continue_btn.setEnabled(True)

    def _on_continue(self) -> None:
        export_class = "decision_grade" if bool(self._dg_radio.isChecked()) else "exploratory"
        suppress = bool(self._suppress.isChecked()) if export_class == "exploratory" else False
        self._result = ExportGateResult(
            export_class=export_class,
            suppress_exploratory_prompt_this_session=suppress,
        )
        self.accept()

    def result_payload(self) -> ExportGateResult | None:
        return self._result


__all__ = ["ExportGateDialog", "ExportGateResult"]
