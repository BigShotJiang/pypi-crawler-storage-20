from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel


class StatusChip(QLabel):
    """Tiny pill to show chain progress like '2/3 evidence'."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("StatusChip")
        self.setVisible(False)
        self._set_style()

    def _set_style(self) -> None:
        self.setStyleSheet(
            """
            QLabel#StatusChip {
                background: #1f2937;
                color: #e5e7eb;
                border-radius: 10px;
                padding: 4px 8px;
                font-size: 11px;
            }
            """
        )
        self.setAlignment(Qt.AlignCenter)

    def show_progress(self, chain_id: str, idx: int, total: int, stage: str) -> None:
        self.setText(f"{idx}/{total} {stage}")
        self.setVisible(True)

    def reset(self) -> None:
        self.setText("")
        self.setVisible(False)
