from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence
import math


CLASS_LABELS = ("intended", "uncut", "harmful")
INTENDED_IDX = 0
UNCUT_IDX = 1
HARMFUL_IDX = 2


@dataclass(frozen=True)
class StateBin:
    chromatin: str
    cell_cycle: str
    repair_regime: str

    @property
    def key(self) -> str:
        return f"{self.chromatin}_{self.cell_cycle}_{self.repair_regime}"


def default_state_bins() -> list[StateBin]:
    # Coarse 6-bin grid: chromatin x cell-cycle x repair regime.
    return [
        StateBin("open", "G1", "NHEJ"),
        StateBin("open", "S", "HDR"),
        StateBin("open", "G2M", "MMEJ"),
        StateBin("closed", "G1", "NHEJ"),
        StateBin("closed", "S", "HDR"),
        StateBin("closed", "G2M", "MMEJ"),
    ]


def _clamp01(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    return max(0.0, min(1.0, float(value)))


def _normalize_weights(weights: Sequence[float], *, count: int) -> list[float]:
    if count <= 0:
        return []
    cleaned = [max(0.0, float(w)) for w in (list(weights) if weights else [])]
    if len(cleaned) < count:
        cleaned.extend([0.0] * (count - len(cleaned)))
    if len(cleaned) > count:
        cleaned = cleaned[:count]
    total = sum(cleaned)
    if total <= 0.0:
        return [1.0 / count] * count
    return [w / total for w in cleaned]


@dataclass(frozen=True)
class KappaStats:
    kappa_max: float
    kappa_avg: float


@dataclass
class StateDistribution:
    mass: list[list[float]]
    state_bins: list[StateBin] = field(default_factory=default_state_bins)
    class_labels: Sequence[str] = CLASS_LABELS

    @classmethod
    def from_marginals(
        cls,
        class_marginal: Sequence[float],
        state_marginal: Sequence[float],
        *,
        state_bins: Sequence[StateBin] | None = None,
        class_labels: Sequence[str] = CLASS_LABELS,
    ) -> "StateDistribution":
        states = list(state_bins) if state_bins is not None else default_state_bins()
        class_weights = _normalize_weights(class_marginal, count=len(class_labels))
        state_weights = _normalize_weights(state_marginal, count=len(states))
        mass = [
            [float(cw) * float(sw) for sw in state_weights]
            for cw in class_weights
        ]
        return cls(mass=mass, state_bins=list(states), class_labels=class_labels)

    def clone(self) -> "StateDistribution":
        return StateDistribution(
            mass=[list(row) for row in self.mass],
            state_bins=list(self.state_bins),
            class_labels=tuple(self.class_labels),
        )

    @property
    def n_classes(self) -> int:
        return len(self.mass)

    @property
    def n_states(self) -> int:
        if not self.mass:
            return 0
        return len(self.mass[0])

    def total_mass(self) -> float:
        return float(sum(sum(row) for row in self.mass))

    def normalize(self) -> "StateDistribution":
        total = self.total_mass()
        if total <= 0.0:
            # Fall back to uniform joint mass to avoid divide-by-zero later.
            if self.n_classes <= 0 or self.n_states <= 0:
                return self
            uniform = 1.0 / float(self.n_classes * self.n_states)
            self.mass = [[uniform for _ in range(self.n_states)] for _ in range(self.n_classes)]
            return self
        for ci in range(self.n_classes):
            for si in range(self.n_states):
                self.mass[ci][si] = float(self.mass[ci][si]) / total
        return self

    def class_marginal(self) -> list[float]:
        return [float(sum(row)) for row in self.mass]

    def state_marginal(self) -> list[float]:
        if self.n_states <= 0:
            return []
        totals = [0.0 for _ in range(self.n_states)]
        for row in self.mass:
            for si, value in enumerate(row):
                totals[si] += float(value)
        return totals

    def conditional_on_state(self, state_index: int) -> list[float]:
        if state_index < 0 or state_index >= self.n_states:
            return [1.0 / max(1, self.n_classes) for _ in range(self.n_classes)]
        state_mass = sum(float(self.mass[ci][state_index]) for ci in range(self.n_classes))
        if state_mass <= 0.0:
            return [1.0 / max(1, self.n_classes) for _ in range(self.n_classes)]
        return [float(self.mass[ci][state_index]) / state_mass for ci in range(self.n_classes)]

    def entropy_joint_bits(self) -> float:
        h = 0.0
        for row in self.mass:
            for p in row:
                p = float(p)
                if p <= 0.0:
                    continue
                h -= p * math.log(p, 2)
        return float(h)

    def entropy_class_bits(self) -> float:
        h = 0.0
        for p in self.class_marginal():
            if p <= 0.0:
                continue
            h -= p * math.log(p, 2)
        return float(h)

    def kappa_stats(self) -> KappaStats:
        if self.n_states <= 1:
            return KappaStats(kappa_max=0.0, kappa_avg=0.0)
        state_weights = _normalize_weights(self.state_marginal(), count=self.n_states)
        cond = [self.conditional_on_state(i) for i in range(self.n_states)]
        kappa_max = 0.0
        weighted_sum = 0.0
        weight_denom = 0.0
        for i in range(self.n_states):
            for j in range(i + 1, self.n_states):
                tv = 0.5 * sum(abs(cond[i][k] - cond[j][k]) for k in range(self.n_classes))
                kappa_max = max(kappa_max, tv)
                w = state_weights[i] * state_weights[j]
                weighted_sum += w * tv
                weight_denom += w
        kappa_avg = weighted_sum / weight_denom if weight_denom > 0.0 else 0.0
        return KappaStats(kappa_max=float(kappa_max), kappa_avg=float(kappa_avg))


@dataclass(frozen=True)
class CutModel:
    p_cut_by_state: list[float]

    def p_cut(self, state_index: int) -> float:
        if state_index < 0 or state_index >= len(self.p_cut_by_state):
            return 0.0
        return _clamp01(float(self.p_cut_by_state[state_index]))


@dataclass(frozen=True)
class RepairModel:
    p_intended_given_cut: list[float]
    p_harmful_given_cut: list[float]

    def probabilities(self, state_index: int) -> tuple[float, float]:
        if state_index < 0 or state_index >= len(self.p_intended_given_cut):
            return 0.0, 0.0
        p_intended = max(0.0, float(self.p_intended_given_cut[state_index]))
        p_harmful = max(0.0, float(self.p_harmful_given_cut[state_index]))
        total = p_intended + p_harmful
        if total <= 0.0:
            return 0.0, 0.0
        return p_intended / total, p_harmful / total


@dataclass(frozen=True)
class SelectionCoefficients:
    fitness_intended: float
    fitness_uncut: float
    fitness_harmful: float


@dataclass
class EditOperator:
    cut_model: CutModel
    repair_model: RepairModel

    def apply(self, dist: StateDistribution, *, cut_scale: float = 1.0) -> StateDistribution:
        out = dist.clone()
        for si in range(dist.n_states):
            p_cut = _clamp01(self.cut_model.p_cut(si) * float(cut_scale))
            p_intended, p_harmful = self.repair_model.probabilities(si)
            uncut_mass = float(dist.mass[UNCUT_IDX][si])
            intended_mass = float(dist.mass[INTENDED_IDX][si])
            harmful_mass = float(dist.mass[HARMFUL_IDX][si])
            cut_mass = uncut_mass * p_cut
            out.mass[UNCUT_IDX][si] = max(0.0, uncut_mass - cut_mass)
            out.mass[INTENDED_IDX][si] = intended_mass + cut_mass * p_intended
            out.mass[HARMFUL_IDX][si] = harmful_mass + cut_mass * p_harmful
        return out


@dataclass
class TransitionOperator:
    def apply(self, dist: StateDistribution) -> StateDistribution:
        return dist.clone()


class IdentityTransition(TransitionOperator):
    pass


@dataclass
class SelectionOperator:
    coeffs: SelectionCoefficients

    def apply(self, dist: StateDistribution) -> StateDistribution:
        out = dist.clone()
        weights = [
            max(0.0, float(self.coeffs.fitness_intended)),
            max(0.0, float(self.coeffs.fitness_uncut)),
            max(0.0, float(self.coeffs.fitness_harmful)),
        ]
        for ci in range(out.n_classes):
            for si in range(out.n_states):
                out.mass[ci][si] = float(out.mass[ci][si]) * weights[ci]
        out.normalize()
        return out


@dataclass(frozen=True)
class IterationTrace:
    steps: list[int]
    entropy_joint_bits: list[float]
    entropy_class_bits: list[float]
    kappa_max: list[float]
    kappa_avg: list[float]
    intended: list[float]
    uncut: list[float]
    harmful: list[float]
    escape: list[float]
    hazard_splice: list[float] | None = None
    hazard_reg: list[float] | None = None


class IterationEngine:
    def __init__(self, *, edit: EditOperator, transition: TransitionOperator, selection: SelectionOperator) -> None:
        self._edit = edit
        self._transition = transition
        self._selection = selection

    def step(self, dist: StateDistribution, *, cut_scale: float = 1.0) -> StateDistribution:
        after_edit = self._edit.apply(dist, cut_scale=cut_scale)
        after_transition = self._transition.apply(after_edit)
        after_select = self._selection.apply(after_transition)
        after_select.normalize()
        return after_select

    def run(
        self,
        dist: StateDistribution,
        *,
        steps: int,
        cut_drift_per_step: float = 0.0,
        hazard_ratios: tuple[float, float] | None = None,
    ) -> IterationTrace:
        current = dist.clone().normalize()
        steps_int = max(0, int(steps))
        step_ids: list[int] = []
        entropy_joint: list[float] = []
        entropy_class: list[float] = []
        kappa_max: list[float] = []
        kappa_avg: list[float] = []
        intended: list[float] = []
        uncut: list[float] = []
        harmful: list[float] = []
        escape: list[float] = []
        hazard_splice: list[float] | None = [] if hazard_ratios is not None else None
        hazard_reg: list[float] | None = [] if hazard_ratios is not None else None

        def _record(dist_now: StateDistribution) -> None:
            step_ids.append(len(step_ids))
            entropy_joint.append(dist_now.entropy_joint_bits())
            entropy_class.append(dist_now.entropy_class_bits())
            kappa = dist_now.kappa_stats()
            kappa_max.append(kappa.kappa_max)
            kappa_avg.append(kappa.kappa_avg)
            class_marg = dist_now.class_marginal()
            i_val = float(class_marg[INTENDED_IDX]) if len(class_marg) > INTENDED_IDX else 0.0
            u_val = float(class_marg[UNCUT_IDX]) if len(class_marg) > UNCUT_IDX else 0.0
            h_val = float(class_marg[HARMFUL_IDX]) if len(class_marg) > HARMFUL_IDX else 0.0
            intended.append(i_val)
            uncut.append(u_val)
            harmful.append(h_val)
            escape.append(u_val)
            if hazard_ratios is not None:
                ratio_splice, ratio_reg = hazard_ratios
                hazard_splice.append(_clamp01(h_val * float(ratio_splice)))
                hazard_reg.append(_clamp01(h_val * float(ratio_reg)))

        _record(current)
        drift = max(0.0, float(cut_drift_per_step))
        for step_idx in range(1, steps_int + 1):
            cut_scale = max(0.0, 1.0 - drift) ** float(step_idx - 1)
            current = self.step(current, cut_scale=cut_scale)
            _record(current)
        return IterationTrace(
            steps=step_ids,
            entropy_joint_bits=entropy_joint,
            entropy_class_bits=entropy_class,
            kappa_max=kappa_max,
            kappa_avg=kappa_avg,
            intended=intended,
            uncut=uncut,
            harmful=harmful,
            escape=escape,
            hazard_splice=hazard_splice,
            hazard_reg=hazard_reg,
        )


@dataclass(frozen=True)
class StateMixtureVariant:
    name: str
    weights: list[float]


@dataclass(frozen=True)
class CutVariant:
    name: str
    chromatin_multipliers: dict[str, float] = field(default_factory=dict)
    state_multipliers: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class RepairVariant:
    name: str
    intended_by_regime: dict[str, float] = field(default_factory=dict)
    harmful_by_regime: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class StressPolicy:
    steps: int
    state_mixtures: list[StateMixtureVariant]
    cut_variants: list[CutVariant]
    repair_variants: list[RepairVariant]
    selection_variants: list[SelectionCoefficients]
    cut_drift_per_step: list[float]
    transition_required: bool
    transition_model: str


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    state_bins: list[StateBin]
    initial: StateDistribution
    edit: EditOperator
    transition: TransitionOperator
    selection: SelectionOperator
    cut_drift_per_step: float
    steps: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def run(self) -> IterationTrace:
        engine = IterationEngine(edit=self.edit, transition=self.transition, selection=self.selection)
        hazard_ratios = self.metadata.get("hazard_ratios")
        return engine.run(self.initial, steps=self.steps, cut_drift_per_step=self.cut_drift_per_step, hazard_ratios=hazard_ratios)

    def to_dict(self) -> dict[str, Any]:
        out = {
            "scenario_id": self.scenario_id,
            "cut_drift_per_step": float(self.cut_drift_per_step),
            "steps": int(self.steps),
        }
        out.update(self.metadata)
        return out


@dataclass(frozen=True)
class ClaimResult:
    claim_id: str
    status: str  # passed | failed | skipped
    statement: str
    operator: str
    threshold: float
    value: float | None
    margin: float | None
    scope_steps: int | None
    fail_mode: str
    triggered_by: list[str] = field(default_factory=list)
    counterexample: dict[str, Any] | None = None
    notes: str | None = None


@dataclass(frozen=True)
class Claim:
    claim_id: str
    statement: str
    operator: str
    threshold: float
    scope_steps: int | None
    assumptions: list[str]
    fail_mode: str
    evaluator: Any

    def evaluate(self, trace: IterationTrace, summary: Mapping[str, Any], scenario: Scenario) -> ClaimResult:
        return self.evaluator(trace, summary, scenario, self)


@dataclass(frozen=True)
class ClaimsSummary:
    status: str
    results: list[ClaimResult]
    scenario_count: int
    worst_margin: float | None = None
    worst_claim_id: str | None = None
    reason: str | None = None


def _trace_value(series: Sequence[float], step: int) -> float:
    if not series:
        return 0.0
    idx = min(max(0, int(step)), len(series) - 1)
    return float(series[idx])


def _evaluate_simple_threshold(trace: IterationTrace, _summary: Mapping[str, Any], scenario: Scenario, claim: Claim, *, series: Sequence[float]) -> ClaimResult:
    step = claim.scope_steps if claim.scope_steps is not None else (len(series) - 1)
    value = _trace_value(series, step)
    operator = claim.operator
    passed = False
    margin = None
    if operator == ">=":
        margin = float(value - claim.threshold)
        passed = margin >= 0.0
    elif operator == "<=":
        margin = float(claim.threshold - value)
        passed = margin >= 0.0
    else:
        return ClaimResult(
            claim_id=claim.claim_id,
            status="failed",
            statement=claim.statement,
            operator=operator,
            threshold=claim.threshold,
            value=value,
            margin=None,
            scope_steps=claim.scope_steps,
            fail_mode=claim.fail_mode,
            triggered_by=["unsupported_operator"],
            counterexample=scenario.to_dict(),
        )
    status = "passed" if passed else "failed"
    return ClaimResult(
        claim_id=claim.claim_id,
        status=status,
        statement=claim.statement,
        operator=operator,
        threshold=claim.threshold,
        value=value,
        margin=margin,
        scope_steps=claim.scope_steps,
        fail_mode=claim.fail_mode,
        triggered_by=[f"step={step}"] if not passed else [],
        counterexample=scenario.to_dict() if not passed else None,
    )


def _claim_intended_at_k(trace: IterationTrace, summary: Mapping[str, Any], scenario: Scenario, claim: Claim) -> ClaimResult:
    return _evaluate_simple_threshold(trace, summary, scenario, claim, series=trace.intended)


def _claim_uncut_at_k(trace: IterationTrace, summary: Mapping[str, Any], scenario: Scenario, claim: Claim) -> ClaimResult:
    coeffs = scenario.metadata.get("selection")
    if coeffs and coeffs.get("model") == "neutral":
        return _evaluate_simple_threshold(trace, summary, scenario, claim, series=trace.uncut)
    return ClaimResult(
        claim_id=claim.claim_id,
        status="skipped",
        statement=claim.statement,
        operator=claim.operator,
        threshold=claim.threshold,
        value=None,
        margin=None,
        scope_steps=claim.scope_steps,
        fail_mode=claim.fail_mode,
        notes="non-neutral selection",
    )


def _claim_hazard_at_k(trace: IterationTrace, summary: Mapping[str, Any], scenario: Scenario, claim: Claim) -> ClaimResult:
    step = claim.scope_steps if claim.scope_steps is not None else (len(trace.hazard_splice or []) - 1)
    splice_series = trace.hazard_splice or []
    reg_series = trace.hazard_reg or []
    if not splice_series or not reg_series:
        return ClaimResult(
            claim_id=claim.claim_id,
            status="skipped",
            statement=claim.statement,
            operator=claim.operator,
            threshold=claim.threshold,
            value=None,
            margin=None,
            scope_steps=claim.scope_steps,
            fail_mode=claim.fail_mode,
            notes="hazard ratios unavailable",
        )
    splice_val = _trace_value(splice_series, step)
    reg_val = _trace_value(reg_series, step)
    margin_splice = claim.threshold - splice_val
    margin_reg = claim.threshold - reg_val
    margin = min(margin_splice, margin_reg)
    passed = margin >= 0.0
    status = "passed" if passed else "failed"
    triggered = []
    if margin_splice < 0.0:
        triggered.append("splice")
    if margin_reg < 0.0:
        triggered.append("regulatory")
    return ClaimResult(
        claim_id=claim.claim_id,
        status=status,
        statement=claim.statement,
        operator=claim.operator,
        threshold=claim.threshold,
        value=max(splice_val, reg_val),
        margin=margin,
        scope_steps=claim.scope_steps,
        fail_mode=claim.fail_mode,
        triggered_by=triggered,
        counterexample=scenario.to_dict() if not passed else None,
    )


def _claim_kappa_max(trace: IterationTrace, summary: Mapping[str, Any], scenario: Scenario, claim: Claim) -> ClaimResult:
    kappa_max = max(trace.kappa_max) if trace.kappa_max else 0.0
    margin = claim.threshold - kappa_max
    passed = margin >= 0.0
    return ClaimResult(
        claim_id=claim.claim_id,
        status="passed" if passed else "failed",
        statement=claim.statement,
        operator=claim.operator,
        threshold=claim.threshold,
        value=kappa_max,
        margin=margin,
        scope_steps=claim.scope_steps,
        fail_mode=claim.fail_mode,
        triggered_by=["kappa_max"] if not passed else [],
        counterexample=scenario.to_dict() if not passed else None,
    )


def _claim_transition_required(trace: IterationTrace, summary: Mapping[str, Any], scenario: Scenario, claim: Claim) -> ClaimResult:
    required = bool(scenario.metadata.get("transition_required"))
    transition_model = str(scenario.metadata.get("transition_model") or "identity")
    if not required:
        return ClaimResult(
            claim_id=claim.claim_id,
            status="skipped",
            statement=claim.statement,
            operator=claim.operator,
            threshold=claim.threshold,
            value=None,
            margin=None,
            scope_steps=claim.scope_steps,
            fail_mode=claim.fail_mode,
            notes="transition not required",
        )
    passed = transition_model != "identity"
    return ClaimResult(
        claim_id=claim.claim_id,
        status="passed" if passed else "failed",
        statement=claim.statement,
        operator=claim.operator,
        threshold=claim.threshold,
        value=0.0 if passed else 1.0,
        margin=0.0 if passed else -1.0,
        scope_steps=claim.scope_steps,
        fail_mode=claim.fail_mode,
        triggered_by=[f"transition_model={transition_model}"] if not passed else [],
        counterexample=scenario.to_dict() if not passed else None,
    )


def default_claims(*, steps: int) -> list[Claim]:
    k = max(1, int(steps))
    return [
        Claim(
            claim_id="C1_convergence_intended",
            statement=f"After {k} edits, intended functional >= 0.95",
            operator=">=",
            threshold=0.95,
            scope_steps=k,
            assumptions=["E(theta) uses per-step cut + repair; intended/harmful are absorbing"],
            fail_mode="intended_mass_below_threshold",
            evaluator=_claim_intended_at_k,
        ),
        Claim(
            claim_id="C2_escape_uncut_neutral",
            statement=f"After {k} edits, uncut <= 0.05 under neutral fitness",
            operator="<=",
            threshold=0.05,
            scope_steps=k,
            assumptions=["neutral fitness", "uncut treated as escape"],
            fail_mode="uncut_escape_exceeds_threshold",
            evaluator=_claim_uncut_at_k,
        ),
        Claim(
            claim_id="C3_hazard_splice_reg",
            statement=f"After {k} edits, splice/regulatory hazard <= 1e-6",
            operator="<=",
            threshold=1e-6,
            scope_steps=k,
            assumptions=["hazard mass proportional to harmful mass"],
            fail_mode="hazard_exceeds_threshold",
            evaluator=_claim_hazard_at_k,
        ),
        Claim(
            claim_id="C4_state_robustness_kappa",
            statement="Kappa max <= 0.3 across state bins",
            operator="<=",
            threshold=0.3,
            scope_steps=None,
            assumptions=["kappa computed on class distributions"],
            fail_mode="state_heterogeneity_dominates",
            evaluator=_claim_kappa_max,
        ),
        Claim(
            claim_id="C5_transition_required",
            statement="Perturbation transition must be modeled when required",
            operator="!=",
            threshold=0.0,
            scope_steps=None,
            assumptions=["identity transition is optimistic"],
            fail_mode="transition_required_but_identity",
            evaluator=_claim_transition_required,
        ),
    ]


def build_scenarios(
    *,
    state_bins: Sequence[StateBin],
    class_marginal: Sequence[float],
    base_cut_p: float,
    base_intended_given_cut: float,
    base_harmful_given_cut: float,
    policy: StressPolicy,
    hazard_ratios: tuple[float, float] | None,
) -> list[Scenario]:
    states = list(state_bins)
    base_cut = max(0.0, float(base_cut_p))
    base_intended = max(0.0, float(base_intended_given_cut))
    base_harmful = max(0.0, float(base_harmful_given_cut))
    base_total = base_intended + base_harmful
    if base_total <= 0.0:
        base_intended = 0.0
        base_harmful = 0.0
    else:
        base_intended /= base_total
        base_harmful /= base_total

    scenarios: list[Scenario] = []

    for mix_idx, mix in enumerate(policy.state_mixtures):
        mix_weights = _normalize_weights(mix.weights, count=len(states))
        initial = StateDistribution.from_marginals(class_marginal, mix_weights, state_bins=states)
        for cut_idx, cut_var in enumerate(policy.cut_variants):
            p_cut_by_state: list[float] = []
            for sb in states:
                mult = 1.0
                if sb.chromatin in cut_var.chromatin_multipliers:
                    mult *= float(cut_var.chromatin_multipliers[sb.chromatin])
                if sb.key in cut_var.state_multipliers:
                    mult *= float(cut_var.state_multipliers[sb.key])
                p_cut_by_state.append(_clamp01(base_cut * mult))
            cut_model = CutModel(p_cut_by_state=p_cut_by_state)
            for rep_idx, rep_var in enumerate(policy.repair_variants):
                p_intended_by_state: list[float] = []
                p_harmful_by_state: list[float] = []
                for sb in states:
                    mult_i = float(rep_var.intended_by_regime.get(sb.repair_regime, 1.0))
                    mult_h = float(rep_var.harmful_by_regime.get(sb.repair_regime, 1.0))
                    p_i = max(0.0, base_intended * mult_i)
                    p_h = max(0.0, base_harmful * mult_h)
                    total = p_i + p_h
                    if total <= 0.0:
                        p_intended_by_state.append(0.0)
                        p_harmful_by_state.append(0.0)
                    else:
                        p_intended_by_state.append(p_i / total)
                        p_harmful_by_state.append(p_h / total)
                repair_model = RepairModel(
                    p_intended_given_cut=p_intended_by_state,
                    p_harmful_given_cut=p_harmful_by_state,
                )
                edit = EditOperator(cut_model=cut_model, repair_model=repair_model)
                for sel_idx, sel in enumerate(policy.selection_variants):
                    selection = SelectionOperator(coeffs=sel)
                    for drift_idx, drift in enumerate(policy.cut_drift_per_step):
                        scenario_id = f"mix{mix_idx}_cut{cut_idx}_rep{rep_idx}_sel{sel_idx}_drift{drift_idx}"
                        metadata = {
                            "state_mixture": mix.name,
                            "cut_variant": cut_var.name,
                            "repair_variant": rep_var.name,
                            "selection": {
                                "model": "neutral" if sel.fitness_intended == sel.fitness_uncut == sel.fitness_harmful else "relative_fitness",
                                "fitness_intended": sel.fitness_intended,
                                "fitness_uncut": sel.fitness_uncut,
                                "fitness_harmful": sel.fitness_harmful,
                            },
                            "transition_model": policy.transition_model,
                            "transition_required": policy.transition_required,
                            "hazard_ratios": hazard_ratios,
                        }
                        scenario = Scenario(
                            scenario_id=scenario_id,
                            state_bins=list(states),
                            initial=initial,
                            edit=edit,
                            transition=IdentityTransition(),
                            selection=selection,
                            cut_drift_per_step=float(drift),
                            steps=int(policy.steps),
                            metadata=metadata,
                        )
                        scenarios.append(scenario)
    return scenarios


def evaluate_claims(
    *,
    scenarios: Sequence[Scenario],
    claims: Sequence[Claim],
    summary: Mapping[str, Any],
) -> ClaimsSummary:
    if not scenarios:
        return ClaimsSummary(status="not_computed", results=[], scenario_count=0, reason="no scenarios")
    results: dict[str, ClaimResult] = {}
    worst_margin = None
    worst_claim_id = None

    best_results: dict[str, ClaimResult | None] = {c.claim_id: None for c in claims}
    for scenario in scenarios:
        trace = scenario.run()
        for claim in claims:
            result = claim.evaluate(trace, summary, scenario)
            if result.status == "skipped":
                continue
            current = best_results.get(claim.claim_id)
            if current is None:
                best_results[claim.claim_id] = result
                continue
            if current.margin is None or result.margin is None:
                continue
            if result.margin < current.margin:
                best_results[claim.claim_id] = result

    for claim in claims:
        best_result = best_results.get(claim.claim_id)
        if best_result is None:
            best_result = ClaimResult(
                claim_id=claim.claim_id,
                status="skipped",
                statement=claim.statement,
                operator=claim.operator,
                threshold=claim.threshold,
                value=None,
                margin=None,
                scope_steps=claim.scope_steps,
                fail_mode=claim.fail_mode,
                notes="no applicable scenarios",
            )
        results[claim.claim_id] = best_result
        if best_result.margin is not None:
            if worst_margin is None or best_result.margin < worst_margin:
                worst_margin = best_result.margin
                worst_claim_id = best_result.claim_id

    ordered_results = [results[c.claim_id] for c in claims if c.claim_id in results]
    status = "computed"
    return ClaimsSummary(
        status=status,
        results=ordered_results,
        scenario_count=len(scenarios),
        worst_margin=worst_margin,
        worst_claim_id=worst_claim_id,
    )
