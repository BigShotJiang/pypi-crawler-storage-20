from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import clock
from helix.studio.results_io import sanitize_results_id

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def sha256_json(obj: Any) -> str:
    data = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return sha256_hex(data)


def build_manifest(*, files: Mapping[str, bytes], receipts: Mapping[str, Any] | None = None) -> dict[str, Any]:
    entries = []
    for path in sorted(files.keys()):
        data = files[path]
        entries.append(
            {
                "path": str(path),
                "bytes": int(len(data)),
                "sha256": sha256_hex(data),
            }
        )
    return {
        "packVersion": "v0.1",
        "createdUtc": clock.utc_now_iso(),
        "receipts": dict(receipts or {}),
        "files": entries,
    }


def build_readme_text(*, receipts: Mapping[str, Any] | None = None) -> str:
    r = dict(receipts or {})

    spec_version = str(r.get("specVersion") or "")
    fixture_id = str(r.get("fixtureId") or "")
    backend = str(r.get("backend") or "")
    gpu_backend = r.get("gpuBackend") if isinstance(r.get("gpuBackend"), dict) else {}
    gpu_preflight = r.get("gpuPreflight") if isinstance(r.get("gpuPreflight"), dict) else {}
    results_list = r.get("resultsRecordSha256") if isinstance(r.get("resultsRecordSha256"), list) else []

    def line(k: str, v: object) -> str:
        s = str(v) if v is not None else ""
        return f"- {k}: {s if s else '—'}\n"

    fp = ""
    fp += line("specVersion", spec_version)
    fp += line("fixtureId", fixture_id)
    fp += line("backend", backend)
    fp += line("settingsSha256", r.get("settingsSha256"))
    fp += line("experimentIntentSpecSha256", r.get("experimentIntentSpecSha256"))
    fp += line("experimentSpecSha256", r.get("experimentSpecSha256"))
    fp += line("editPlanSha256", r.get("editPlanSha256"))
    fp += line("outcomeReportSha256", r.get("outcomeReportSha256"))
    fp += line("clonePlanSha256", r.get("clonePlanSha256"))
    fp += line("assayPlanSha256", r.get("assayPlanSha256"))
    fp += line("offTargetReportSha256", r.get("offTargetReportSha256"))
    fp += line("offTargetPackId", r.get("offTargetPackId"))
    fp += line("offTargetPackFingerprint", r.get("offTargetPackFingerprint"))
    fp += line("validationPlanSha256", r.get("validationPlanSha256"))
    fp += line("primerPlanSha256", r.get("primerPlanSha256"))
    fp += line("calibrationPreviewSha256", r.get("calibrationPreviewSha256"))
    fp += line("basePositionCalibrationPreviewSha256", r.get("basePositionCalibrationPreviewSha256"))
    fp += line("basePositionCalibrationProfileSha256", r.get("basePositionCalibrationProfileSha256"))
    fp += line("basePositionCalibrationEvalSha256", r.get("basePositionCalibrationEvalSha256"))
    fp += line("suggestedPriorsSha256", r.get("suggestedPriorsSha256"))
    if results_list:
        fp += line("resultsRecordSha256", f"{len(results_list)} record(s)")
    fp += line("geometrySha256", r.get("geometrySha256"))
    fp += line("gpuShaderSha256", r.get("gpuShaderSha256"))
    fp += line("gpuRenderer", gpu_preflight.get("GL_RENDERER") if gpu_preflight else "")
    fp += line("glVendor", gpu_preflight.get("GL_VENDOR") if gpu_preflight else "")
    fp += line("glVersion", gpu_preflight.get("GL_VERSION") if gpu_preflight else "")
    fp += line("gpuRasterMode", gpu_backend.get("rasterMode") if gpu_backend else "")
    fp += line("gpuScissorMode", gpu_backend.get("scissorMode") if gpu_backend else "")
    fp += line("gpuQuadPadPx", gpu_backend.get("quadPadPx") if gpu_backend else "")

    return (
        "Helix Lightcone audit pack\n"
        "\n"
        "Environment:\n"
        f"{fp}"
        "\n"
        "Contents:\n"
        "- fixture_snapshot.v0.1.json: exact lightcone document used for export\n"
        "- experiment_intent_spec.v1.json: decision intent spec (decision question/hypothesis/rule/premortem)\n"
        "- experiment_spec.v1.json: experiment intent/constraints snapshot (session-scoped)\n"
        "- edit_plan.v1.json: edit plan targets (session-scoped)\n"
        "- results_record.<id>.json: imported wet-lab results records\n"
        "- calibration_preview.v1.json: calibration preview report (optional)\n"
        "- base_position_calibration_preview.v1.json: base position calibration preview (optional)\n"
        "- base_position_calibration_profile.v1.json: base position calibration profile (optional)\n"
        "- base_position_calibration_eval.v1.json: base position calibration evaluation (optional)\n"
        "- suggested_priors.v1.json: suggested model priors (optional)\n"
        "- outcome_report.v1.json: outcome model report (nullable predictions)\n"
        "- clone_plan.v1.json: clone yield plan derived from outcomes\n"
        "- assay_plan.v1.json: assay recommendation plan (target + off-target)\n"
        "- offtarget_report.v1.json: off-target report (nullable predictions)\n"
        "- validation_plan.v1.json: off-target validation plan\n"
        "- primer_plan.v1.json: primer plan for validation hits\n"
        "- render_cpu.png: canonical CPU renderer output (science-grade reference)\n"
        "- render_gpu.png: interactive GPU renderer output (optional)\n"
        "- perf_receipt.json: GPU perf receipt (optional)\n"
        "- selection_dump.json: selected branch outcome dump (optional)\n"
        "- manifest.json: sha256 for each content file (excluding manifest.json itself)\n"
        "\n"
        "Verify:\n"
        "- Recompute sha256 for each file and compare to manifest.json.\n"
        "\n"
        "Receipts:\n"
        "- settingsSha256: render invariants (resolution, camera, phase, style map)\n"
        "- geometrySha256: compiled branch geometry artifact\n"
        "- gpuShaderSha256: shader source hash (GPU backend)\n"
        "- gpuBackend: GPU raster/quad/scissor knobs (avoid comparing apples to oranges)\n"
    )


def build_audit_pack_zip_bytes(*, pack_dirname: str, files: Mapping[str, bytes], receipts: Mapping[str, Any] | None = None) -> bytes:
    """Build a zipped audit pack with deterministic ordering and fixed zip timestamps."""

    pack_dirname = str(pack_dirname).strip().strip("/").strip("\\") or "lightcone_audit_pack"

    base_files = dict(files)
    base_files["README.txt"] = build_readme_text(receipts=receipts).encode("utf-8")
    manifest = build_manifest(files=base_files, receipts=receipts)
    base_files["manifest.json"] = stable_json_bytes(manifest)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel_path in sorted(base_files.keys()):
            data = base_files[rel_path]
            arcname = f"{pack_dirname}/{rel_path}"
            info = zipfile.ZipInfo(arcname)
            # Fixed timestamp for stable zips; content integrity is asserted via manifest.json.
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, data)
    return buf.getvalue()


def _find_pack_dirname(zf: zipfile.ZipFile) -> tuple[str | None, list[str]]:
    manifest_paths = [n for n in zf.namelist() if n.endswith("/manifest.json")]
    if len(manifest_paths) != 1:
        return None, [f"expected exactly 1 manifest.json (found {len(manifest_paths)})"]
    manifest_path = manifest_paths[0]
    if manifest_path.count("/") < 1:
        return None, [f"invalid manifest path: {manifest_path!r}"]
    pack_dirname = manifest_path.rsplit("/", 1)[0]
    return pack_dirname, []


def verify_audit_pack_zip_bytes(data: bytes) -> list[str]:
    """Verify a Lightcone audit pack ZIP (manifest hashes + file set). Returns a list of errors."""

    errors: list[str] = []
    try:
        buf = io.BytesIO(data)
    except Exception as exc:
        return [f"invalid zip: {exc}"]

    with zipfile.ZipFile(buf) as zf:
        pack_dir, errs = _find_pack_dirname(zf)
        errors.extend(errs)
        if not pack_dir:
            return errors

        try:
            manifest_raw = zf.read(f"{pack_dir}/manifest.json")
        except Exception as exc:
            return errors + [f"missing manifest.json: {exc}"]

        try:
            manifest = json.loads(manifest_raw.decode("utf-8"))
        except Exception as exc:
            return errors + [f"invalid manifest.json: {exc}"]
        if not isinstance(manifest, dict):
            return errors + ["manifest.json must be a JSON object"]

        files_list = manifest.get("files")
        if not isinstance(files_list, list):
            return errors + ["manifest.json missing 'files' list"]

        receipts = manifest.get("receipts") if isinstance(manifest.get("receipts"), dict) else {}

        expected: dict[str, dict[str, object]] = {}
        for i, entry in enumerate(files_list):
            if not isinstance(entry, dict):
                errors.append(f"manifest.files[{i}] is not an object")
                continue
            rel = str(entry.get("path") or "")
            if not rel:
                errors.append(f"manifest.files[{i}] missing path")
                continue
            if rel in expected:
                errors.append(f"manifest has duplicate entry: {rel}")
                continue
            expected[rel] = entry

        # Verify file set: every non-directory entry (except manifest.json) must be present in manifest.
        present_rel: set[str] = set()
        for name in zf.namelist():
            if not name.startswith(f"{pack_dir}/"):
                continue
            if name.endswith("/"):
                continue
            rel = name[len(pack_dir) + 1 :]
            if rel == "manifest.json":
                continue
            present_rel.add(rel)

        missing_in_zip = [rel for rel in expected.keys() if rel not in present_rel]
        for rel in sorted(missing_in_zip):
            errors.append(f"missing file in zip: {rel}")

        extra_in_zip = [rel for rel in present_rel if rel not in expected]
        for rel in sorted(extra_in_zip):
            errors.append(f"unexpected file in zip: {rel}")

        # Verify hashes/sizes.
        for rel, entry in sorted(expected.items()):
            try:
                blob = zf.read(f"{pack_dir}/{rel}")
            except Exception as exc:
                errors.append(f"cannot read {rel}: {exc}")
                continue
            exp_bytes = entry.get("bytes")
            exp_sha = str(entry.get("sha256") or "")
            if exp_bytes is not None:
                try:
                    if int(exp_bytes) != len(blob):
                        errors.append(f"size mismatch {rel}: expected {exp_bytes} got {len(blob)}")
                except Exception:
                    errors.append(f"invalid bytes field for {rel}: {exp_bytes!r}")
            got_sha = sha256_hex(blob)
            if exp_sha and got_sha != exp_sha:
                errors.append(f"sha256 mismatch {rel}: expected {exp_sha} got {got_sha}")

        spec_receipt = str(receipts.get("experimentSpecSha256") or "")
        if spec_receipt:
            spec_path = f"{pack_dir}/experiment_spec.v1.json"
            try:
                spec_blob = zf.read(spec_path)
            except Exception as exc:
                errors.append(f"missing experiment_spec.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(spec_blob)
                if got_sha != spec_receipt:
                    errors.append(
                        f"experimentSpecSha256 mismatch: expected {spec_receipt} got {got_sha}"
                    )

        intent_receipt = str(receipts.get("experimentIntentSpecSha256") or "")
        if intent_receipt:
            intent_path = f"{pack_dir}/experiment_intent_spec.v1.json"
            try:
                intent_blob = zf.read(intent_path)
            except Exception as exc:
                errors.append(f"missing experiment_intent_spec.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(intent_blob)
                if got_sha != intent_receipt:
                    errors.append(
                        f"experimentIntentSpecSha256 mismatch: expected {intent_receipt} got {got_sha}"
                    )

        edit_plan_receipt = str(receipts.get("editPlanSha256") or "")
        if edit_plan_receipt:
            plan_path = f"{pack_dir}/edit_plan.v1.json"
            try:
                plan_blob = zf.read(plan_path)
            except Exception as exc:
                errors.append(f"missing edit_plan.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(plan_blob)
                if got_sha != edit_plan_receipt:
                    errors.append(
                        f"editPlanSha256 mismatch: expected {edit_plan_receipt} got {got_sha}"
                    )

        report_receipt = str(receipts.get("outcomeReportSha256") or "")
        if report_receipt:
            report_path = f"{pack_dir}/outcome_report.v1.json"
            try:
                report_blob = zf.read(report_path)
            except Exception as exc:
                errors.append(f"missing outcome_report.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(report_blob)
                if got_sha != report_receipt:
                    errors.append(
                        f"outcomeReportSha256 mismatch: expected {report_receipt} got {got_sha}"
                    )

        clone_receipt = str(receipts.get("clonePlanSha256") or "")
        if clone_receipt:
            clone_path = f"{pack_dir}/clone_plan.v1.json"
            try:
                clone_blob = zf.read(clone_path)
            except Exception as exc:
                errors.append(f"missing clone_plan.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(clone_blob)
                if got_sha != clone_receipt:
                    errors.append(
                        f"clonePlanSha256 mismatch: expected {clone_receipt} got {got_sha}"
                    )

        assay_receipt = str(receipts.get("assayPlanSha256") or "")
        if assay_receipt:
            assay_path = f"{pack_dir}/assay_plan.v1.json"
            try:
                assay_blob = zf.read(assay_path)
            except Exception as exc:
                errors.append(f"missing assay_plan.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(assay_blob)
                if got_sha != assay_receipt:
                    errors.append(
                        f"assayPlanSha256 mismatch: expected {assay_receipt} got {got_sha}"
                    )

        off_receipt = str(receipts.get("offTargetReportSha256") or "")
        if off_receipt:
            report_path = f"{pack_dir}/offtarget_report.v1.json"
            try:
                report_blob = zf.read(report_path)
            except Exception as exc:
                errors.append(f"missing offtarget_report.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(report_blob)
                if got_sha != off_receipt:
                    errors.append(
                        f"offTargetReportSha256 mismatch: expected {off_receipt} got {got_sha}"
                    )

        plan_receipt = str(receipts.get("validationPlanSha256") or "")
        if plan_receipt:
            plan_path = f"{pack_dir}/validation_plan.v1.json"
            try:
                plan_blob = zf.read(plan_path)
            except Exception as exc:
                errors.append(f"missing validation_plan.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(plan_blob)
                if got_sha != plan_receipt:
                    errors.append(
                        f"validationPlanSha256 mismatch: expected {plan_receipt} got {got_sha}"
                    )

        primer_receipt = str(receipts.get("primerPlanSha256") or "")
        if primer_receipt:
            primer_path = f"{pack_dir}/primer_plan.v1.json"
            try:
                primer_blob = zf.read(primer_path)
            except Exception as exc:
                errors.append(f"missing primer_plan.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(primer_blob)
                if got_sha != primer_receipt:
                    errors.append(
                        f"primerPlanSha256 mismatch: expected {primer_receipt} got {got_sha}"
                    )

        calibration_receipt = str(receipts.get("calibrationPreviewSha256") or "")
        if calibration_receipt:
            preview_path = f"{pack_dir}/calibration_preview.v1.json"
            try:
                preview_blob = zf.read(preview_path)
            except Exception as exc:
                errors.append(f"missing calibration_preview.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(preview_blob)
                if got_sha != calibration_receipt:
                    errors.append(
                        f"calibrationPreviewSha256 mismatch: expected {calibration_receipt} got {got_sha}"
                    )

        base_preview_receipt = str(receipts.get("basePositionCalibrationPreviewSha256") or "")
        if base_preview_receipt:
            preview_path = f"{pack_dir}/base_position_calibration_preview.v1.json"
            try:
                preview_blob = zf.read(preview_path)
            except Exception as exc:
                errors.append(
                    f"missing base_position_calibration_preview.v1.json for receipt: {exc}"
                )
            else:
                got_sha = sha256_hex(preview_blob)
                if got_sha != base_preview_receipt:
                    errors.append(
                        f"basePositionCalibrationPreviewSha256 mismatch: expected {base_preview_receipt} got {got_sha}"
                    )

        base_profile_receipt = str(receipts.get("basePositionCalibrationProfileSha256") or "")
        if base_profile_receipt:
            profile_path = f"{pack_dir}/base_position_calibration_profile.v1.json"
            try:
                profile_blob = zf.read(profile_path)
            except Exception as exc:
                errors.append(
                    f"missing base_position_calibration_profile.v1.json for receipt: {exc}"
                )
            else:
                got_sha = sha256_hex(profile_blob)
                if got_sha != base_profile_receipt:
                    errors.append(
                        f"basePositionCalibrationProfileSha256 mismatch: expected {base_profile_receipt} got {got_sha}"
                    )

        base_eval_receipt = str(receipts.get("basePositionCalibrationEvalSha256") or "")
        if base_eval_receipt:
            eval_path = f"{pack_dir}/base_position_calibration_eval.v1.json"
            try:
                eval_blob = zf.read(eval_path)
            except Exception as exc:
                errors.append(
                    f"missing base_position_calibration_eval.v1.json for receipt: {exc}"
                )
            else:
                got_sha = sha256_hex(eval_blob)
                if got_sha != base_eval_receipt:
                    errors.append(
                        f"basePositionCalibrationEvalSha256 mismatch: expected {base_eval_receipt} got {got_sha}"
                    )

        suggested_receipt = str(receipts.get("suggestedPriorsSha256") or "")
        if suggested_receipt:
            suggested_path = f"{pack_dir}/suggested_priors.v1.json"
            try:
                suggested_blob = zf.read(suggested_path)
            except Exception as exc:
                errors.append(f"missing suggested_priors.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(suggested_blob)
                if got_sha != suggested_receipt:
                    errors.append(
                        f"suggestedPriorsSha256 mismatch: expected {suggested_receipt} got {got_sha}"
                    )

        results_receipt = receipts.get("resultsRecordSha256")
        if results_receipt is not None:
            if not isinstance(results_receipt, list):
                errors.append("resultsRecordSha256 must be a list")
            else:
                for idx, entry in enumerate(results_receipt):
                    if not isinstance(entry, dict):
                        errors.append(f"resultsRecordSha256[{idx}] is not an object")
                        continue
                    results_id = str(entry.get("resultsId") or "")
                    exp_sha = str(entry.get("sha256") or "")
                    path = str(entry.get("path") or "")
                    if not path and results_id:
                        path = f"results_record.{sanitize_results_id(results_id)}.json"
                    if not path:
                        errors.append(f"resultsRecordSha256[{idx}] missing path")
                        continue
                    if not exp_sha:
                        errors.append(f"resultsRecordSha256[{idx}] missing sha256")
                        continue
                    try:
                        blob = zf.read(f"{pack_dir}/{path}")
                    except Exception as exc:
                        errors.append(f"missing {path} for resultsRecordSha256: {exc}")
                        continue
                    got_sha = sha256_hex(blob)
                    if got_sha != exp_sha:
                        errors.append(
                            f"resultsRecordSha256 mismatch for {path}: expected {exp_sha} got {got_sha}"
                        )

        return errors


def verify_audit_pack_path(path: str | Path) -> list[str]:
    return verify_audit_pack_zip_bytes(Path(path).read_bytes())


def build_selection_dump_payload_v1(
    *,
    spec_version: str,
    fixture_id: str,
    locus: Mapping[str, Any],
    reference_window_sha256: str | None,
    selection: Mapping[str, Any],
    outcomes: Sequence[Mapping[str, Any]],
    quantitative_allowed: bool = True,
) -> dict[str, Any]:
    """Build a stable selection dump payload suitable for audit packs.

    Required fields:
    - selectionId
    - locus
    - referenceWindowSha256
    - outcomes[*]: id, mechanismTags, alleleOpsSha256 (+ probability in decision grade)
    """

    from helix.lightcone.allele_ops import allele_ops_from_payload, allele_ops_to_payload, canonicalize_allele_ops

    out_items_with_prob: list[tuple[float, dict[str, Any]]] = []
    for entry in outcomes:
        oid = str(entry.get("id") or "")
        if not oid:
            continue
        try:
            prob_val = float(entry.get("probability") or 0.0)
        except Exception:
            prob_val = 0.0
        allele_ops_payload = entry.get("alleleOps") or []
        try:
            ops = canonicalize_allele_ops(allele_ops_from_payload(allele_ops_payload))  # type: ignore[arg-type]
            canon = allele_ops_to_payload(ops)
            ops_sha = sha256_json(canon)
        except Exception:
            ops_sha = ""
        item: dict[str, Any] = {
            "id": oid,
            "mechanismTags": [str(t) for t in (entry.get("mechanismTags") or [])],
            "alleleOpsSha256": str(ops_sha),
        }
        if quantitative_allowed:
            item["probability"] = float(prob_val)
        out_items_with_prob.append((float(prob_val), item))

    # Deterministic ordering: prob desc, then id.
    out_items_with_prob.sort(key=lambda t: (-float(t[0]), str(t[1].get("id") or "")))
    out_items: list[dict[str, Any]] = []
    for idx, (prob_val, item) in enumerate(out_items_with_prob):
        if not quantitative_allowed:
            from helix.studio.ordinal_bins import tier_for_rank

            rank = int(idx + 1)
            item["rank"] = rank
            item["tier"] = tier_for_rank(rank).label
        out_items.append(item)

    return {
        "schema": "helix_lightcone_selection_dump_v1",
        "generatedUtc": clock.utc_now_iso(),
        "specVersion": str(spec_version),
        "fixtureId": str(fixture_id),
        "locus": dict(locus),
        "referenceWindowSha256": (str(reference_window_sha256) if reference_window_sha256 is not None else None),
        "selection": dict(selection),
        "outcomes": out_items,
    }
