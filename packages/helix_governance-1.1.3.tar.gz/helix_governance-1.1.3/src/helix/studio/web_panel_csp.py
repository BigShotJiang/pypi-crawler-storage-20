from __future__ import annotations

import re

from helix.studio.plugins.policy import NetworkPolicy, WebPanelsPolicy

_IP_RE = re.compile(r"^(?:\\d{1,3}\\.){3}\\d{1,3}$")


def _is_ipv4(host: str) -> bool:
    h = (host or "").strip()
    if not _IP_RE.match(h):
        return False
    try:
        parts = [int(x) for x in h.split(".")]
    except Exception:
        return False
    return all(0 <= p <= 255 for p in parts)


def _sources_for_allowlist(
    policy: NetworkPolicy,
    *,
    scheme: str,
) -> list[str]:
    sources: list[str] = []
    s = (scheme or "").strip().lower()
    for host in policy.allow:
        h = str(host or "").strip().lower()
        if not h:
            continue
        sources.append(f"{s}://{h}")
        if not _is_ipv4(h) and h != "localhost":
            sources.append(f"{s}://*.{h}")
    return sources


def _connect_src(policy: NetworkPolicy) -> list[str]:
    mode = (policy.mode or "").strip().lower()
    if mode in {"none", "deny"}:
        return ["'none'"]
    if mode in {"full", "all", "any"}:
        sources: list[str] = ["https:"]
        if policy.allow_insecure_http:
            sources.append("http:")
        if policy.allow_websocket:
            sources.append("wss:")
            if policy.allow_insecure_http:
                sources.append("ws:")
        return sources

    sources = _sources_for_allowlist(policy, scheme="https")
    if policy.allow_insecure_http:
        sources.extend(_sources_for_allowlist(policy, scheme="http"))
    if policy.allow_websocket:
        sources.extend(_sources_for_allowlist(policy, scheme="wss"))
        if policy.allow_insecure_http:
            sources.extend(_sources_for_allowlist(policy, scheme="ws"))
    return sources or ["'none'"]


def _script_src(policy: WebPanelsPolicy) -> list[str]:
    sources: list[str] = ["'self'", "qrc:", "file:"]
    if policy.csp_allow_inline_script:
        sources.append("'unsafe-inline'")
    if policy.csp_allow_eval:
        sources.append("'unsafe-eval'")
    if not policy.csp_allow_remote_scripts:
        return sources

    net = policy.network
    mode = (net.mode or "").strip().lower()
    if mode in {"none", "deny"}:
        return sources
    if mode in {"full", "all", "any"}:
        sources.append("https:")
        if net.allow_insecure_http:
            sources.append("http:")
        return sources

    sources.extend(_sources_for_allowlist(net, scheme="https"))
    if net.allow_insecure_http:
        sources.extend(_sources_for_allowlist(net, scheme="http"))
    return sources


def build_web_panel_csp(policy: WebPanelsPolicy) -> str:
    """Build a strict CSP for Qt WebEngine web panels.

    This CSP is meant to be an additional safety layer alongside the URL request
    interceptor (which is authoritative).
    """

    script_src = _script_src(policy)
    connect_src = _connect_src(policy.network)

    # Note: In meta CSP, some directives may not be fully enforced in all engines,
    # but it still meaningfully reduces the attack surface.
    directives: list[str] = [
        "default-src 'none'",
        "base-uri 'none'",
        "object-src 'none'",
        "frame-ancestors 'none'",
        "form-action 'none'",
        "img-src 'self' data: qrc: file:",
        "font-src 'self' data: qrc: file:",
        "style-src 'self' 'unsafe-inline' qrc: file:",
        f"script-src {' '.join(script_src)}",
        f"connect-src {' '.join(connect_src)}",
    ]
    return "; ".join(directives)


__all__ = ["build_web_panel_csp"]

