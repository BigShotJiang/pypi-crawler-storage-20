from __future__ import annotations

import requests


class InstrumentRunsApiClient:
    def __init__(self, backend_base_url: str):
        self._base = backend_base_url.rstrip("/")

    def list_runs(self) -> list[dict]:
        resp = requests.get(f"{self._base}/api/instrument_runs", timeout=10)
        resp.raise_for_status()
        return resp.json()

    def get_run(self, run_id: str) -> dict:
        resp = requests.get(f"{self._base}/api/instrument_runs/{run_id}", timeout=10)
        resp.raise_for_status()
        return resp.json()

    def get_run_analysis(self, run_id: str) -> dict | None:
        resp = requests.get(f"{self._base}/api/instrument_runs/{run_id}/analysis", timeout=10)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()
