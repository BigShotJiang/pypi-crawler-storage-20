from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .project import ProjectModel
from helix.config import HelixFeatures
from helix.ogn.manager import OgnManager


@dataclass
class StudioContext:
    project: ProjectModel
    features: HelixFeatures
    ogn_manager: OgnManager | None = None

    @property
    def project_root(self) -> Path:
        return self.project.root_path


__all__ = ["StudioContext"]
