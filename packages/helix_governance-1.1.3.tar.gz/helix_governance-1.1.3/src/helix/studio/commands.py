from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable

_COMMAND_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{1,80}$")


class CommandRegistrationError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class HelixCommand:
    command_id: str
    title: str
    callback: Callable[[], None]
    category: str | None = None
    shortcut: str | None = None
    owner: str = "core"


class CommandRegistry:
    def __init__(self) -> None:
        self._commands: dict[str, HelixCommand] = {}
        self._owners: dict[str, set[str]] = {}

    def register(
        self,
        command_id: str,
        title: str,
        callback: Callable[[], None],
        *,
        category: str | None = None,
        shortcut: str | None = None,
        owner: str = "core",
        replace: bool = False,
    ) -> HelixCommand:
        cid = (command_id or "").strip().lower()
        if not _COMMAND_ID_RE.match(cid):
            raise CommandRegistrationError(
                f"invalid command id '{command_id}' "
                "(expected 2-81 chars: a-z0-9 plus ._-)"
            )
        if not isinstance(title, str) or not title.strip():
            raise CommandRegistrationError("title must be a non-empty string")
        if not callable(callback):
            raise CommandRegistrationError("callback must be callable")

        if cid in self._commands and not replace:
            raise CommandRegistrationError(f"command already registered: {cid}")
        if cid in self._commands and replace:
            existing = self._commands[cid]
            next_owner = (owner or "core").strip().lower() or "core"
            if existing.owner != next_owner:
                raise CommandRegistrationError(
                    f"command id collision: {cid} already owned by '{existing.owner}'"
                )

        cmd = HelixCommand(
            command_id=cid,
            title=title.strip(),
            callback=callback,
            category=(category or "").strip() or None,
            shortcut=(shortcut or "").strip() or None,
            owner=(owner or "core").strip().lower() or "core",
        )
        self._commands[cid] = cmd
        self._owners.setdefault(cmd.owner, set()).add(cid)
        return cmd

    def unregister(self, command_id: str) -> bool:
        cid = (command_id or "").strip().lower()
        cmd = self._commands.pop(cid, None)
        if cmd is None:
            return False
        owner_ids = self._owners.get(cmd.owner)
        if owner_ids is not None:
            owner_ids.discard(cid)
            if not owner_ids:
                self._owners.pop(cmd.owner, None)
        return True

    def unregister_owner(self, owner: str) -> int:
        key = (owner or "").strip().lower()
        ids = sorted(self._owners.get(key, set()))
        removed = 0
        for cid in ids:
            if self.unregister(cid):
                removed += 1
        return removed

    def get(self, command_id: str) -> HelixCommand | None:
        return self._commands.get((command_id or "").strip().lower())

    def list(self) -> list[HelixCommand]:
        return sorted(
            self._commands.values(),
            key=lambda c: (c.category or "", c.title.lower(), c.command_id),
        )

    def run(self, command_id: str) -> bool:
        cmd = self.get(command_id)
        if cmd is None:
            return False
        cmd.callback()
        return True


__all__ = [
    "CommandRegistrationError",
    "CommandRegistry",
    "HelixCommand",
]
