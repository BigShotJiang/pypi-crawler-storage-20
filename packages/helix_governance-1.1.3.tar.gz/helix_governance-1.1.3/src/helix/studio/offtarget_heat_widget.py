from __future__ import annotations

from typing import Sequence

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter, QPaintEvent
from PySide6.QtWidgets import QWidget


class OffTargetHeatWidget(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._heat: list[float] | None = None
        self._min_val: float = 0.0
        self._max_val: float = 1.0
        self.setMinimumHeight(24)
        self.setMaximumHeight(48)

    def set_heat(self, heat: Sequence[float], *, min_val: float | None = None, max_val: float | None = None) -> None:
        self._heat = list(heat)
        if self._heat:
            hmin = min(self._heat)
            hmax = max(self._heat)
            self._min_val = hmin if min_val is None else min_val
            self._max_val = hmax if max_val is None else max_val
        self.update()

    def clear_heat(self) -> None:
        self._heat = None
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:  # type: ignore[override]
        painter = QPainter(self)
        try:
            painter.fillRect(self.rect(), self.palette().window())

            if not self._heat:
                return

            w = self.width()
            h = self.height()
            n = len(self._heat)
            if n <= 1 or w <= 0:
                return

            for x in range(w):
                idx_f = (float(x) / max(1.0, float(w - 1))) * float(n - 1)
                i0 = int(idx_f)
                i1 = min(i0 + 1, n - 1)
                t = idx_f - float(i0)
                val = (1.0 - t) * self._heat[i0] + t * self._heat[i1]
                c = self._map_value_to_color(val)
                painter.setPen(c)
                painter.drawLine(x, 0, x, h - 1)
        finally:
            painter.end()

    def _map_value_to_color(self, val: float) -> QColor:
        if self._max_val <= self._min_val + 1e-6:
            t = 0.0
        else:
            t = (val - self._min_val) / (self._max_val - self._min_val)
        t = max(0.0, min(1.0, t))

        # magma-ish gradient: black -> purple -> orange -> yellow
        if t < 0.33:
            r, g, b = (0, 0, int(255 * (t / 0.33)))
        elif t < 0.66:
            a = (t - 0.33) / 0.33
            r = int(64 + 191 * a)
            g = int(0 + 128 * a)
            b = int(128 - 64 * a)
        else:
            a = (t - 0.66) / 0.34
            r = 255
            g = int(128 + 127 * a)
            b = int(64 + 191 * a)
        return QColor(r, g, b)
