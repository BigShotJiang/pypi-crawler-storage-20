from __future__ import annotations

from typing import List, Any

import os
from PySide6 import QtCore, QtWidgets, QtGui


class _RunsFetchThread(QtCore.QThread):
    done = QtCore.Signal(int, object)  # token, runs
    failed = QtCore.Signal(int, str)  # token, error

    def __init__(self, api_client, *, token: int, parent=None) -> None:
        super().__init__(parent)
        self._api = api_client
        self._token = int(token)

    def run(self) -> None:  # noqa: N802
        try:
            runs = self._api.list_runs()
        except Exception as exc:
            self.failed.emit(self._token, str(exc))
            return
        self.done.emit(self._token, runs)


class _RunDetailFetchThread(QtCore.QThread):
    done = QtCore.Signal(int, str, object)  # token, run_id, detail
    failed = QtCore.Signal(int, str, str)  # token, run_id, error

    def __init__(self, api_client, *, run_id: str, token: int, parent=None) -> None:
        super().__init__(parent)
        self._api = api_client
        self._run_id = str(run_id)
        self._token = int(token)

    def run(self) -> None:  # noqa: N802
        run_id = str(self._run_id)
        try:
            detail = self._api.get_run(run_id)
            analysis = self._api.get_run_analysis(run_id)
        except Exception as exc:
            self.failed.emit(self._token, run_id, str(exc))
            return
        if analysis:
            try:
                detail = dict(detail)
                detail["analysis_id"] = analysis.get("analysis_id")
                detail["analysis"] = analysis
            except Exception:
                pass
        self.done.emit(self._token, run_id, detail)


class InstrumentRunsModel(QtCore.QAbstractTableModel):
    HEADERS = ["Run ID", "Vendor", "Instrument", "Status", "Samples", "Created"]
    COL_STATUS = 3

    def __init__(self, runs: List[dict] | None = None, parent=None) -> None:
        super().__init__(parent)
        self._all_runs: List[dict[str, Any]] = runs or []
        self._visible_runs: List[dict[str, Any]] = list(self._all_runs)
        self._status_filter: set[str] | None = None

    def set_runs(self, runs: List[dict]) -> None:
        self._all_runs = runs
        self._apply_filter()

    def set_status_filter(self, statuses: set[str] | None) -> None:
        self._status_filter = statuses
        self._apply_filter()

    def _apply_filter(self) -> None:
        self.beginResetModel()
        if not self._status_filter:
            self._visible_runs = list(self._all_runs)
        else:
            self._visible_runs = [r for r in self._all_runs if r.get("status") in self._status_filter]
        self.endResetModel()

    def rowCount(self, parent=QtCore.QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._visible_runs)

    def columnCount(self, parent=QtCore.QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self.HEADERS)

    def data(self, index: QtCore.QModelIndex, role=QtCore.Qt.DisplayRole):  # noqa: N802
        if not index.isValid():
            return None
        run = self._visible_runs[index.row()]
        mapping = [
            run.get("run_id"),
            run.get("vendor"),
            run.get("instrument"),
            run.get("status"),
            run.get("sample_count"),
            run.get("created_at"),
        ]
        if role == QtCore.Qt.DisplayRole:
            return mapping[index.column()]
        if role == QtCore.Qt.ToolTipRole and index.column() == self.COL_STATUS:
            last_state = run.get("status") or ""
            msg = run.get("last_message") or ""
            ts = run.get("last_updated_at") or run.get("created_at") or ""
            parts = [f"State: {last_state}", f"Updated: {ts}"]
            if msg:
                parts.append(f"Info: {msg}")
            return "\n".join(parts)
        if role == QtCore.Qt.ForegroundRole and index.column() == self.COL_STATUS:
            state = (run.get("status") or "").lower()
            color = None
            if state == "finished":
                color = QtGui.QColor("green")
            elif state == "running":
                color = QtGui.QColor("blue")
            elif state in ("queued", "received"):
                color = QtGui.QColor("darkorange")
            elif state == "failed":
                color = QtGui.QColor("red")
            if color:
                return QtGui.QBrush(color)
        return None

    def headerData(self, section: int, orientation: QtCore.Qt.Orientation, role=QtCore.Qt.DisplayRole):  # noqa: N802
        if orientation == QtCore.Qt.Horizontal and role == QtCore.Qt.DisplayRole:
            return self.HEADERS[section]
        return super().headerData(section, orientation, role)


STATUS_COLORS: dict[str, tuple[str, str]] = {
    "received": ("#f0ad4e", "Received"),
    "queued": ("#f0ad4e", "Queued"),
    "running": ("#0275d8", "Running"),
    "finished": ("#5cb85c", "Finished"),
    "failed": ("#d9534f", "Failed"),
}


class StatusPillDelegate(QtWidgets.QStyledItemDelegate):
    def paint(self, painter: QtGui.QPainter, option: QtWidgets.QStyleOptionViewItem, index: QtCore.QModelIndex) -> None:
        state = (index.data(QtCore.Qt.DisplayRole) or "").lower()
        color_hex, _ = STATUS_COLORS.get(state, ("#cccccc", state or ""))
        text = state or ""
        painter.save()
        rect = option.rect.adjusted(4, 4, -4, -4)
        color = QtGui.QColor(color_hex)
        painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
        painter.setBrush(color)
        painter.setPen(QtCore.Qt.NoPen)
        painter.drawRoundedRect(rect, 8, 8)
        painter.setPen(QtGui.QColor("white"))
        painter.drawText(rect, QtCore.Qt.AlignCenter, text)
        painter.restore()


class RunDetailPanel(QtWidgets.QWidget):
    def __init__(self, parent=None, on_view_analysis=None):
        super().__init__(parent)
        self._layout = QtWidgets.QFormLayout(self)
        self._labels = {
            "run_id": QtWidgets.QLabel(""),
            "vendor": QtWidgets.QLabel(""),
            "instrument": QtWidgets.QLabel(""),
            "sample_count": QtWidgets.QLabel(""),
        }
        for key, label in self._labels.items():
            self._layout.addRow(key.replace("_", " ").title(), label)
        self._on_view_analysis = on_view_analysis
        self._analysis_button = QtWidgets.QPushButton("View analysis")
        self._analysis_button.setEnabled(False)
        self._analysis_button.clicked.connect(self._handle_view_analysis)
        self._current_analysis_id: str | None = None
        self._layout.addRow(self._analysis_button)
        # Summary labels
        self._summary_reads = QtWidgets.QLabel("")
        self._summary_targets = QtWidgets.QLabel("")
        self._qc_label = QtWidgets.QLabel("")
        self._qc_label.setAlignment(QtCore.Qt.AlignCenter)
        self._qc_label.setStyleSheet("border-radius:6px; padding:2px 6px;")
        self._summary_box = QtWidgets.QGroupBox("Analysis summary")
        summary_layout = QtWidgets.QFormLayout(self._summary_box)
        summary_layout.addRow("Reads", self._summary_reads)
        summary_layout.addRow("Targets", self._summary_targets)
        summary_layout.addRow("QC", self._qc_label)
        self._summary_box.hide()
        self._layout.addRow(self._summary_box)

    def set_detail(self, detail: dict[str, Any] | None) -> None:
        if detail is None:
            for label in self._labels.values():
                label.setText("")
            self._analysis_button.setEnabled(False)
            self._summary_box.hide()
            return
        self._labels["run_id"].setText(str(detail.get("run_id", "")))
        self._labels["vendor"].setText(str(detail.get("vendor", "")))
        self._labels["instrument"].setText(str(detail.get("instrument", "")))
        self._labels["sample_count"].setText(str(detail.get("sample_count", "")))
        self._current_analysis_id = detail.get("analysis_id") or detail.get("analysis", {}).get("analysis_id")
        state = detail.get("status")
        self._summary_box.hide()
        can_view = bool(self._current_analysis_id) and state == "finished"
        self._analysis_button.setEnabled(can_view)
        summary = None
        if state == "finished":
            summary = detail.get("analysis", {}).get("summary") or detail.get("summary")
        if summary:
            self._summary_reads.setText(
                f"{summary.get('total_reads', 0):,} total, {summary.get('mapped_reads', 0):,} mapped "
                f"({summary.get('mapped_rate', 0.0):.1%})"
            )
            self._summary_targets.setText(
                f"{summary.get('target_sites', 0)} target, {summary.get('offtarget_sites', 0)} off-target"
            )
            qc_status = summary.get("qc_status", "unknown")
            qc_msg = summary.get("qc_message", "")
            self._set_qc_pill(qc_status, qc_msg)
            self._summary_box.show()

    def _handle_view_analysis(self) -> None:
        if self._on_view_analysis and self._current_analysis_id:
            self._on_view_analysis(self._current_analysis_id)

    def _set_qc_pill(self, qc_status: str, msg: str) -> None:
        colors = {
            "pass": "#5cb85c",
            "warn": "#f0ad4e",
            "fail": "#d9534f",
        }
        color = colors.get(qc_status.lower(), "#999999")
        self._qc_label.setStyleSheet(f"border-radius:6px; padding:2px 6px; background:{color}; color:white;")
        text = qc_status.title() if qc_status else "Unknown"
        if msg:
            text = f"{text} — {msg}"
        self._qc_label.setText(text)


class InstrumentRunsWidget(QtWidgets.QWidget):
    def __init__(self, api_client, parent=None, *, on_view_analysis=None):
        super().__init__(parent)
        self._api = api_client
        self._model = InstrumentRunsModel()
        self._table = QtWidgets.QTableView(self)
        self._table.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Expanding,
        )
        self._table.setModel(self._model)
        self._table.setItemDelegateForColumn(self._model.COL_STATUS, StatusPillDelegate(self._table))
        self._detail = RunDetailPanel(self, on_view_analysis=on_view_analysis)
        self._detail.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Expanding,
        )
        self._has_loaded = False
        self._suppress_selection_changed = False
        self._runs_refresh_token = 0
        self._runs_refresh_thread: _RunsFetchThread | None = None
        self._runs_refresh_pending = False
        self._detail_refresh_token = 0
        self._detail_refresh_thread: _RunDetailFetchThread | None = None
        self._detail_refresh_pending_run_id: str | None = None
        self._detail_refresh_pending_force = False
        self._detail_signature_by_run_id: dict[str, str] = {}
        self._timer = QtCore.QTimer(self)
        interval_ms = int(os.getenv("HELIX_INSTRUMENT_RUNS_REFRESH_MS", "10000"))
        self._timer.setInterval(interval_ms)
        self._timer.timeout.connect(self.refresh)

        legend_layout = QtWidgets.QHBoxLayout()
        legend_layout.setContentsMargins(0, 0, 0, 0)
        legend_layout.setSpacing(8)
        for state, (color_hex, label_text) in STATUS_COLORS.items():
            pill = QtWidgets.QLabel(label_text)
            pill.setAlignment(QtCore.Qt.AlignCenter)
            pill.setStyleSheet(
                f"border-radius: 8px; padding: 2px 8px; background-color: {color_hex}; color: white; font-size: 10px;"
            )
            legend_layout.addWidget(pill)
        legend_layout.addStretch(1)
        legend_widget = QtWidgets.QWidget()
        legend_widget.setLayout(legend_layout)

        self._filter_combo = QtWidgets.QComboBox(self)
        self._filter_combo.addItem("All", userData=None)
        self._filter_combo.addItem("Active", userData={"received", "queued", "running"})
        self._filter_combo.addItem("Finished", userData={"finished"})
        self._filter_combo.addItem("Failed", userData={"failed"})
        self._filter_combo.currentIndexChanged.connect(self._on_filter_changed)

        self._splitter = QtWidgets.QSplitter(self)
        self._splitter.addWidget(self._table)
        self._splitter.addWidget(self._detail)
        self._splitter.setStretchFactor(0, 3)
        self._splitter.setStretchFactor(1, 2)
        self._table.setMinimumWidth(0)
        self._detail.setMinimumWidth(0)

        # Make the run list actually fill available width (avoid dead space).
        hdr = self._table.horizontalHeader()
        hdr.setStretchLastSection(True)
        try:
            last_col = int(self._model.columnCount() - 1)
            hdr.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Interactive)
            hdr.setSectionResizeMode(last_col, QtWidgets.QHeaderView.ResizeMode.Stretch)
        except Exception:
            pass
        layout = QtWidgets.QVBoxLayout(self)
        layout.addWidget(self._filter_combo)
        layout.addWidget(legend_widget)
        layout.addWidget(self._splitter)

        self._table.selectionModel().selectionChanged.connect(self._on_selection_changed)
        refresh_btn = QtWidgets.QPushButton("Refresh", self)
        refresh_btn.clicked.connect(self.refresh)
        layout.addWidget(refresh_btn)
        self._apply_compact_if_needed()

    def _run_signature(self, run: dict) -> str:
        try:
            status = str(run.get("status") or "")
        except Exception:
            status = ""
        try:
            updated = str(run.get("last_updated_at") or "")
        except Exception:
            updated = ""
        try:
            created = str(run.get("created_at") or "")
        except Exception:
            created = ""
        try:
            samples = str(run.get("sample_count") or "")
        except Exception:
            samples = ""
        return "|".join((status, updated, created, samples))

    def _signature_for_run_id(self, run_id: str) -> str | None:
        target = str(run_id)
        for run in getattr(self._model, "_visible_runs", []) or []:
            try:
                if str(run.get("run_id")) == target:
                    return self._run_signature(run)
            except Exception:
                continue
        return None

    def _apply_compact_if_needed(self) -> None:
        """Responsive behavior: stack detail under table on narrow widths."""

        splitter = getattr(self, "_splitter", None)
        if splitter is None:
            return
        try:
            w = int(self.width() or 0)
        except Exception:
            w = 0
        if w <= 0:
            return
        threshold = int(os.getenv("HELIX_INSTRUMENT_RUNS_COMPACT_WIDTH", "1150"))
        desired = QtCore.Qt.Vertical if w < threshold else QtCore.Qt.Horizontal
        if splitter.orientation() != desired:
            splitter.setOrientation(desired)
            splitter.setStretchFactor(0, 3)
            splitter.setStretchFactor(1, 2)

    def resizeEvent(self, event):  # noqa: N802
        super().resizeEvent(event)
        try:
            self._apply_compact_if_needed()
        except Exception:
            pass

    def refresh(self) -> None:
        self._request_runs_refresh()

    def _request_runs_refresh(self) -> None:
        thr = self._runs_refresh_thread
        if thr is not None:
            try:
                if thr.isRunning():
                    self._runs_refresh_pending = True
                    return
            except RuntimeError:
                self._runs_refresh_thread = None
        self._runs_refresh_pending = False
        self._runs_refresh_token += 1
        token = int(self._runs_refresh_token)
        thread = _RunsFetchThread(self._api, token=token, parent=self)
        thread.done.connect(self._on_runs_refresh_done)
        thread.failed.connect(self._on_runs_refresh_failed)
        thread.finished.connect(self._on_runs_refresh_thread_finished)
        thread.finished.connect(thread.deleteLater)
        self._runs_refresh_thread = thread
        thread.start()

    def _on_runs_refresh_thread_finished(self) -> None:
        self._runs_refresh_thread = None
        if self._runs_refresh_pending:
            self._request_runs_refresh()

    def _on_runs_refresh_done(self, token: int, runs_obj: object) -> None:
        if int(token) != int(self._runs_refresh_token):
            return
        runs = runs_obj if isinstance(runs_obj, list) else []
        selected = self._current_selection_id()
        self._suppress_selection_changed = True
        try:
            self._model.set_runs(runs)
            if runs:
                self._restore_selection(selected)
            else:
                self._detail.set_detail(None)
        finally:
            self._suppress_selection_changed = False

        run_id = self._current_selection_id()
        if run_id:
            sig = self._signature_for_run_id(run_id)
            prev = self._detail_signature_by_run_id.get(str(run_id))
            if sig is None or sig != prev:
                self._request_detail_refresh(str(run_id), force=True)

    def _on_runs_refresh_failed(self, token: int, _error: str) -> None:
        if int(token) != int(self._runs_refresh_token):
            return

    def _on_selection_changed(self, *_args) -> None:
        if self._suppress_selection_changed:
            return
        indexes = self._table.selectionModel().selectedRows()
        if not indexes:
            self._detail.set_detail(None)
            return
        row = indexes[0].row()
        run_id = str(self._model._visible_runs[row].get("run_id"))
        if not run_id:
            self._detail.set_detail(None)
            return
        self._request_detail_refresh(run_id, force=True)

    def _request_detail_refresh(self, run_id: str, *, force: bool) -> None:
        run_id = str(run_id)
        if not run_id:
            self._detail.set_detail(None)
            return
        if not force:
            sig = self._signature_for_run_id(run_id)
            prev = self._detail_signature_by_run_id.get(run_id)
            if sig is not None and sig == prev:
                return

        thr = self._detail_refresh_thread
        if thr is not None:
            try:
                if thr.isRunning():
                    self._detail_refresh_pending_run_id = run_id
                    self._detail_refresh_pending_force = bool(self._detail_refresh_pending_force or force)
                    return
            except RuntimeError:
                self._detail_refresh_thread = None

        self._detail_refresh_pending_run_id = None
        self._detail_refresh_pending_force = False
        self._detail_refresh_token += 1
        token = int(self._detail_refresh_token)
        thread = _RunDetailFetchThread(self._api, run_id=run_id, token=token, parent=self)
        thread.done.connect(self._on_detail_refresh_done)
        thread.failed.connect(self._on_detail_refresh_failed)
        thread.finished.connect(self._on_detail_refresh_thread_finished)
        thread.finished.connect(thread.deleteLater)
        self._detail_refresh_thread = thread
        thread.start()

    def _on_detail_refresh_thread_finished(self) -> None:
        self._detail_refresh_thread = None
        pending = self._detail_refresh_pending_run_id
        pending_force = bool(self._detail_refresh_pending_force)
        self._detail_refresh_pending_run_id = None
        self._detail_refresh_pending_force = False
        if pending:
            self._request_detail_refresh(str(pending), force=pending_force)

    def _on_detail_refresh_done(self, token: int, run_id: str, detail_obj: object) -> None:
        if int(token) != int(self._detail_refresh_token):
            return
        if str(run_id) != str(self._current_selection_id() or ""):
            # Selection changed mid-flight; ignore and let the next request land.
            pass
        else:
            detail = detail_obj if isinstance(detail_obj, dict) else None
            self._detail.set_detail(detail)
            sig = self._signature_for_run_id(str(run_id))
            if sig is not None:
                self._detail_signature_by_run_id[str(run_id)] = str(sig)

    def _on_detail_refresh_failed(self, token: int, _run_id: str, _error: str) -> None:
        if int(token) != int(self._detail_refresh_token):
            return

    def _current_selection_id(self) -> str | None:
        indexes = self._table.selectionModel().selectedRows()
        if not indexes:
            return None
        return self._model._visible_runs[indexes[0].row()].get("run_id")

    def _restore_selection(self, run_id: str | None) -> None:
        if run_id is None:
            if self._model.rowCount() > 0:
                self._table.selectRow(0)
            return
        for row, run in enumerate(self._model._visible_runs):
            if run.get("run_id") == run_id:
                self._table.selectRow(row)
                return
        if self._model.rowCount() > 0:
            self._table.selectRow(0)

    def _on_filter_changed(self) -> None:
        statuses = self._filter_combo.currentData()
        self._model.set_status_filter(statuses)
        self._restore_selection(self._current_selection_id())

    def showEvent(self, event):  # noqa: N802
        super().showEvent(event)
        try:
            self.refresh()
        except Exception:
            pass
        self._has_loaded = True
        self._timer.start()

    def hideEvent(self, event):  # noqa: N802
        super().hideEvent(event)
        self._timer.stop()
