from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import clock
from helix.gui.modern.spec import EditEvent, EditEventType, EditVisualizationSpec
from .guide_inspector import GuideRunSummary
from .models import EngineInfo, OutcomeModel, RunModel
from .session_io import load_session
from .session import SESSION_SNAPSHOT_VERSION

_REPO_ROOT = Path(__file__).resolve().parents[3]

DEMO_HELIX_PATH = _REPO_ROOT / "docs" / "demo" / "demo_session.helix"

DEMO_SESSION_PATH = _REPO_ROOT / "docs" / "demo" / "demo_session.json"

_CRISPR_DEMO_PRESET_ID = "crispr_demo_emx1_v1"


def _sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _apply_text_diff(seq: str, start: int, end: int, replacement: str) -> str:
    start = max(0, min(len(seq), int(start)))
    end = max(start, min(len(seq), int(end)))
    return f"{seq[:start]}{replacement}{seq[end:]}"


def _json_safe_obj(obj: Any) -> Any:
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, Mapping):
        return {k: _json_safe_obj(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_json_safe_obj(v) for v in obj]

    tolist = getattr(obj, "tolist", None)
    if callable(tolist):
        try:
            return _json_safe_obj(tolist())
        except Exception:
            pass

    item = getattr(obj, "item", None)
    if callable(item):
        try:
            return item()
        except Exception:
            pass

    return str(obj)


def _counts_from_probs(probs: Sequence[float], *, total: int) -> list[int]:
    n = len(probs)
    total = int(total)
    if n <= 0 or total <= 0:
        return [0] * n

    cleaned = [max(0.0, float(p)) for p in probs]
    s = float(sum(cleaned))
    if not math.isfinite(s) or s <= 0.0:
        base = total // n
        counts = [base] * n
        counts[0] += total - sum(counts)
        return counts

    norm = [p / s for p in cleaned]
    raw = [p * float(total) for p in norm]
    floors = [int(math.floor(x)) for x in raw]
    remainder = total - sum(floors)
    if remainder > 0:
        order = sorted(range(n), key=lambda i: raw[i] - float(floors[i]), reverse=True)
        for i in order[:remainder]:
            floors[i] += 1
    elif remainder < 0:
        order = sorted(range(n), key=lambda i: raw[i] - float(floors[i]))
        need = -remainder
        for i in order:
            if need <= 0:
                break
            if floors[i] <= 0:
                continue
            floors[i] -= 1
            need -= 1
    return floors


def _load_demo_json(path: Path = DEMO_SESSION_PATH) -> Mapping[str, Any]:
    return json.loads(path.read_text(encoding="utf8"))


def build_canonical_demo_snapshot() -> dict[str, Any]:
    """Return a ready-to-emit session snapshot that lights up the UI."""

    try:
        from .experiment_presets import load_preset, preset_to_snapshot

        preset = load_preset(_CRISPR_DEMO_PRESET_ID)
        snapshot = preset_to_snapshot(preset)
        raw = preset.raw or {}

        state = snapshot.setdefault("state", {})
        if not isinstance(state, dict):
            raise TypeError("Preset snapshot state must be a dict.")

        genome = state.get("genome") if isinstance(state.get("genome"), Mapping) else {}
        if not genome:
            raise ValueError("Demo preset did not resolve a genome sequence.")

        genome_raw = raw.get("genome") if isinstance(raw.get("genome"), Mapping) else {}
        coords = genome_raw.get("coords") if isinstance(genome_raw.get("coords"), Mapping) else {}
        reference_build = str(coords.get("reference") or coords.get("build") or "").strip() or "n/a"
        chrom = str(coords.get("contig") or coords.get("chrom") or coords.get("chr") or "") or next(iter(genome.keys()))
        window_start_bp = coords.get("start")
        try:
            window_start_bp = int(window_start_bp) if window_start_bp is not None else None
        except Exception:
            window_start_bp = None

        full_seq = str(genome.get(chrom) or "")
        if not full_seq:
            raise ValueError(f"Demo genome missing contig '{chrom}'.")

        crispr = raw.get("crispr") if isinstance(raw.get("crispr"), Mapping) else {}
        guide_id = str(crispr.get("guide_id") or "EMX1_g1")
        spacer_start = int(crispr.get("spacer_start") or 0)
        spacer_len = int(crispr.get("spacer_len") or 20)
        pam_start = int(crispr.get("pam_start") or (spacer_start + spacer_len))

        ui_defaults = raw.get("ui_defaults") if isinstance(raw.get("ui_defaults"), Mapping) else {}
        focus_region = ui_defaults.get("focus_region")
        if isinstance(focus_region, (list, tuple)) and len(focus_region) == 2:
            viz0 = int(focus_region[0])
            viz1 = int(focus_region[1])
        else:
            viz0 = max(0, spacer_start - 30)
            viz1 = min(len(full_seq), pam_start + 30)

        viz0 = max(0, min(len(full_seq), viz0))
        viz1 = max(viz0 + 1, min(len(full_seq), viz1))
        sequence = full_seq[viz0:viz1]

        guide_range = (spacer_start - viz0, spacer_start - viz0 + spacer_len)
        pam_index = pam_start - viz0
        cut_index = pam_index - 3
        if guide_range[0] < 0 or guide_range[1] > len(sequence):
            raise ValueError("Guide is outside demo visualization window.")

        locus = f"{chrom}:{coords.get('start', '')}-{coords.get('end', '')}" if coords else chrom
        run_id = "101"

        outcomes: list[dict[str, Any]] = [
            {
                "label": "intended_edit",
                "category": "small_insertion",
                "probability": 0.38,
                "delta_bp": 1,
                "diff": {"kind": "insertion", "start": cut_index, "end": cut_index, "replacement": "A"},
                "frameshift": False,
                "tags": ["intended"],
            },
            {
                "label": "frameshift_del",
                "category": "small_deletion",
                "probability": 0.22,
                "delta_bp": -3,
                "diff": {"kind": "deletion", "start": cut_index - 1, "end": cut_index + 2},
                "frameshift": True,
            },
            {
                "label": "microhomology_del",
                "category": "large_deletion",
                "probability": 0.14,
                "delta_bp": -12,
                "diff": {"kind": "deletion", "start": cut_index - 6, "end": cut_index + 6, "microhomology": 4},
                "frameshift": True,
            },
            {
                "label": "no_cut",
                "category": "no_cut",
                "probability": 0.26,
                "delta_bp": 0,
                "diff": {"kind": "no_cut"},
                "frameshift": False,
            },
        ]

        # Add count fields so uncertainty can be computed deterministically from draws.
        sim_draws = raw.get("simulation", {}).get("draws") if isinstance(raw.get("simulation"), Mapping) else None
        try:
            draws_int = int(sim_draws) if sim_draws is not None else 0
        except Exception:
            draws_int = 0
        if draws_int > 0:
            probs = [float(o.get("probability") or 0.0) for o in outcomes]
            counts = _counts_from_probs(probs, total=draws_int)
            for o, c in zip(outcomes, counts):
                o["count"] = int(c)

        site_start = None
        if window_start_bp is not None:
            site_start = int(window_start_bp) + int(viz0)
        site_end = site_start + len(sequence) if site_start is not None else None

        spec = EditVisualizationSpec(
            sequence=sequence,
            pam_index=pam_index,
            guide_range=guide_range,
            edit_type="CRISPR",
            events=[
                EditEvent(t=0.1, type=EditEventType.RECOGNITION, index=guide_range[0]),
                EditEvent(t=0.2, type=EditEventType.NICK_PRIMARY, index=cut_index),
                EditEvent(t=0.4, type=EditEventType.CUT, index=cut_index),
                EditEvent(t=0.8, type=EditEventType.REPAIR_COMPLETE, index=cut_index),
            ],
            time_units="normalized",
            metadata={
                "guide": {
                    "id": guide_id,
                    "sequence": sequence[guide_range[0] : guide_range[1]],
                    "pam": "NGG",
                    "strand": "+",
                },
                "site": {
                    "sequence": sequence,
                    "length": len(sequence),
                    "chrom": chrom,
                    "start": site_start,
                    "end": site_end,
                    "reference": reference_build,
                },
            },
        )
        viz_payload = spec.to_payload()
        viz_payload["guide"] = {
            "id": guide_id,
            "name": "EMX1",
            "sequence": sequence[guide_range[0] : guide_range[1]],
            "pam": "NGG",
            "strand": "+",
            "start": guide_range[0],
            "end": guide_range[1],
        }
        viz_payload["site"] = {
            "sequence": sequence,
            "length": len(sequence),
            "chrom": chrom,
            "start": site_start,
            "end": site_end,
        }

        workflow_view = None
        try:
            from helix.gui.modern.builders_2p5d import build_workflow2p5d_crispr

            workflow_view = build_workflow2p5d_crispr(
                sequence,
                {"start": guide_range[0], "end": guide_range[1], "strand": "+", "id": guide_id},
                {"outcomes": outcomes},
            )
            workflow_view = _json_safe_obj(workflow_view) if workflow_view is not None else None
        except Exception:
            workflow_view = None

        cut_event = {"chrom": chrom, "start": cut_index, "end": cut_index, "replacement": ""}
        cut_node_id = "n_cut"
        root_id = "n_root"
        nodes: dict[str, Any] = {
            root_id: {
                "log_prob": 0.0,
                "metadata": {"time_step": 0, "stage": "root"},
                "parent_ids": [],
                "seq_hashes": {chrom: _sha256_hex(sequence)},
                "sequences": {chrom: sequence},
            },
            cut_node_id: {
                "log_prob": math.log(0.74),
                "metadata": {
                    "time_step": 1,
                    "stage": "cut",
                    "site_chrom": chrom,
                    "site_start": viz0,
                    "site_end": viz1,
                    "cut_position": cut_index,
                    "strand": 1,
                },
                "parent_ids": [root_id],
                "seq_hashes": {chrom: _sha256_hex(sequence)},
                "sequences": {chrom: sequence},
                "diffs": [
                    {
                        **cut_event,
                        "metadata": {"label": "clean_cut", "mechanism": "crispr", "stage": "cut"},
                    }
                ],
            },
        }
        edges: list[dict[str, Any]] = [
            {
                "source": root_id,
                "target": cut_node_id,
                "rule": "crispr.clean_cut",
                "event": {**cut_event, "metadata": {"label": "clean_cut", "mechanism": "crispr", "stage": "cut"}},
                "metadata": {"stage": "cut"},
            }
        ]

        # Root-level no-cut branch
        nodes["n_no_cut"] = {
            "log_prob": math.log(0.26),
            "metadata": {"time_step": 1, "stage": "no_edit"},
            "parent_ids": [root_id],
            "seq_hashes": {chrom: _sha256_hex(sequence)},
            "sequences": {chrom: sequence},
            "diffs": [
                {
                    "chrom": "__none__",
                    "start": 0,
                    "end": 0,
                    "replacement": "",
                    "metadata": {"label": "no_cut", "mechanism": "crispr", "stage": "no_edit", "edit_class": "no_cut"},
                }
            ],
        }
        edges.append(
            {
                "source": root_id,
                "target": "n_no_cut",
                "rule": "crispr.no_cut",
                "event": {"chrom": "__none__", "start": 0, "end": 0, "replacement": "", "metadata": {"label": "no_cut"}},
                "metadata": {"stage": "no_edit"},
            }
        )

        def _add_repair_node(node_id: str, prob: float, diff: dict[str, Any], meta: dict[str, Any]) -> None:
            s = int(diff.get("start", 0))
            e = int(diff.get("end", s))
            repl = str(diff.get("replacement") or "")
            mutated = _apply_text_diff(sequence, s, e, repl)
            nodes[node_id] = {
                "log_prob": math.log(prob),
                "metadata": {"time_step": 2, "stage": "repaired", **meta},
                "parent_ids": [cut_node_id],
                "seq_hashes": {chrom: _sha256_hex(mutated)},
                "sequences": {chrom: mutated},
                "diffs": [
                    {
                        "chrom": chrom,
                        "start": s,
                        "end": e,
                        "replacement": repl,
                        "metadata": meta,
                    }
                ],
            }
            edges.append(
                {
                    "source": cut_node_id,
                    "target": node_id,
                    "rule": f"crispr.{meta.get('edit_class', 'repair')}",
                    "event": {
                        "chrom": chrom,
                        "start": s,
                        "end": e,
                        "replacement": repl,
                        "metadata": meta,
                    },
                    "metadata": {"stage": "repaired"},
                }
            )

        for idx, oc in enumerate(outcomes):
            label = str(oc.get("label") or f"outcome_{idx}")
            prob = float(oc.get("probability", 0.0))
            diff = oc.get("diff") if isinstance(oc.get("diff"), Mapping) else {}
            kind = str(diff.get("kind") or "no_cut")
            if kind == "no_cut":
                continue
            _add_repair_node(
                f"n_{idx}_{label}",
                prob,
                dict(diff),
                {"label": label, "mechanism": "crispr", "edit_class": kind, "stage": "repaired"},
            )

        dag_payload: dict[str, Any] = {
            "artifact": "helix.crispr.edit_dag.v1.1",
            "version": "1.1",
            "schema_version": "1.1",
            "meta": {
                "mechanism": "crispr",
                "demo": "emx1_hg38_slice",
                "schema_version": "1.1",
                "rule_version": "1.0",
                "created_at": clock.utc_now_iso_offset(),
                "guide": {
                    "id": guide_id,
                    "start": guide_range[0],
                    "end": guide_range[1],
                    "strand": "+",
                    "pam": "NGG",
                },
                "site": {"chrom": chrom, "start": site_start, "end": site_end},
            },
            "nodes": nodes,
            "edges": edges,
            "root_id": root_id,
        }

        cfg = state.get("config")
        if not isinstance(cfg, dict):
            cfg = {}
            state["config"] = cfg
        cfg.setdefault("sim_type", "CRISPR")
        # Ensure the demo session has a stable metadata surface for the UI.
        meta = cfg.get("metadata")
        if not isinstance(meta, dict):
            meta = {}
            cfg["metadata"] = meta
        meta.setdefault("preset_id", _CRISPR_DEMO_PRESET_ID)
        meta.setdefault("preset_label", raw.get("label") if isinstance(raw.get("label"), str) else "CRISPR demo")
        sim_settings = cfg.get("sim_settings")
        if not isinstance(sim_settings, dict):
            cfg["sim_settings"] = {
                "viz_mode": "workflow_2p5d",
                "pam_profile": "SpCas9_NGG",
                "draws": raw.get("simulation", {}).get("draws") if isinstance(raw.get("simulation"), Mapping) else 1000,
                "seed": raw.get("simulation", {}).get("random_seed") if isinstance(raw.get("simulation"), Mapping) else 42,
                "pam_softness": 0.2,
                "priors_profile": raw.get("simulation", {}).get("priors_profile") if isinstance(raw.get("simulation"), Mapping) else "default_indel",
            }
        else:
            sim_settings.setdefault("viz_mode", "workflow_2p5d")

        if workflow_view is not None:
            cfg["workflow_view"] = workflow_view

        # Align the legacy sim payload + guide config with the visualization window.
        sim_payload = cfg.get("sim_payload")
        if not isinstance(sim_payload, dict):
            sim_payload = {}
            cfg["sim_payload"] = sim_payload

        draws = sim_settings.get("draws") if isinstance(sim_settings, Mapping) else None
        seed = sim_settings.get("seed") if isinstance(sim_settings, Mapping) else None
        if isinstance(draws, int) and draws > 0:
            sim_payload["draws"] = int(draws)
        if isinstance(seed, int):
            sim_payload["seed"] = int(seed)
        sim_payload.setdefault("artifact", f"preset:{_CRISPR_DEMO_PRESET_ID}")
        sim_payload["site"] = {
            "sequence": sequence,
            "length": len(sequence),
            "chrom": chrom,
            "start": site_start,
            "end": site_end,
            "reference": reference_build,
        }
        sim_payload["guide"] = {
            "id": guide_id,
            "sequence": sequence[guide_range[0] : guide_range[1]],
            "pam": "NGG",
            "strand": "+",
            "start": guide_range[0],
            "end": guide_range[1],
            "pam_index": pam_index,
            "cut_index": cut_index,
        }
        sim_payload["outcomes"] = outcomes
        state["outcomes"] = outcomes

        guide_cfg = cfg.get("guide")
        if not isinstance(guide_cfg, dict):
            guide_cfg = {}
            cfg["guide"] = guide_cfg
        guide_cfg.update(
            {
                "id": guide_id,
                "name": str(guide_cfg.get("name") or "EMX1"),
                "locus": locus,
                "sequence": sequence[guide_range[0] : guide_range[1]],
                "pam": "NGG",
                "pam_index": pam_index,
                "cut_index": cut_index,
                "start": guide_range[0],
                "end": guide_range[1],
                "strand": "+",
                "chrom": chrom,
            }
        )

        # Pre-seed a declared intent + edit plan for the canonical demo.
        abs_guide_start = None
        abs_target_end = None
        if isinstance(coords, Mapping) and isinstance(coords.get("start"), int):
            abs_guide_start = int(coords.get("start")) + int(spacer_start)
            pam_len = int(crispr.get("pam_len") or 3)
            abs_target_end = int(coords.get("start")) + int(pam_start) + pam_len - 1
        experiment_spec = {
            "schema": "helix_experiment_spec_v1",
            "experimentId": f"demo:{_CRISPR_DEMO_PRESET_ID}",
            "createdAt": raw.get("created_at") if isinstance(raw.get("created_at"), str) else None,
            "reference": {
                "genomeBuild": reference_build,
                "contig": chrom,
                "genomeSha256": state.get("genome_hash"),
            },
            "locus": {
                "chr": chrom,
                "start": int(abs_guide_start or 0),
                "end": int(abs_target_end or 0),
                "strand": "+",
            },
            "intent": "knockout",
            "editModalities": ["crispr_cut"],
            "constraints": {"assayType": "AmpliconSeq"},
            "assumptions": {
                "repairModel": "NHEJ_D1",
                "demo": True,
                "notes": "Exploratory demo intent; decision-grade evidence disabled.",
            },
        }
        edit_plan = {
            "schema": "helix_edit_plan_v1",
            "mode": "cut",
            "targets": [
                {
                    "targetId": guide_id,
                    "label": "EMX1",
                    "role": "primary",
                    "strand": "+",
                    "cutIndex": cut_index,
                    "pamClass": str(crispr.get("nuclease") or "SpCas9"),
                    "nuclease": str(crispr.get("nuclease") or "SpCas9"),
                    "gRNA": {
                        "sequence": sequence[guide_range[0] : guide_range[1]],
                        "pam": "NGG",
                        "pamClass": str(crispr.get("nuclease") or "SpCas9"),
                    },
                }
            ],
            "notes": ["Exploratory demo (hg38 EMX1 slice)"],
        }
        state.setdefault("experiment_spec", experiment_spec)
        state.setdefault("edit_plan", edit_plan)

        state["viz_spec_payload"] = viz_payload
        state["dag_from_runtime"] = dag_payload
        state["viz_dirty"] = True
        state.setdefault("genome_source", f"preset:{reference_build}" if reference_build and reference_build != "n/a" else "preset")
        state.setdefault("genome_uri", f"{reference_build}://{chrom}:{coords.get('start')}-{coords.get('end')}" if coords else f"preset://{_CRISPR_DEMO_PRESET_ID}")
        state.setdefault("genome_hash", genome_raw.get("sequence_sha256") if isinstance(genome_raw, Mapping) else _CRISPR_DEMO_PRESET_ID)

        engine = EngineInfo(name="helix_cuda", backend="gpu", crispr_scoring_version="1.0", prime_scoring_version=None)
        run_model = RunModel(
            run_id=run_id,
            guide_id=guide_id,
            edit_type="crispr",
            sequence=sequence,
            target_locus=locus,
            pam_index=pam_index,
            cut_index=cut_index,
            outcomes=[OutcomeModel.from_dict(o) for o in outcomes],
            physics={"cut_prob": 0.74, "frameshift_prob": 0.52},
            engine=engine,
            metadata={"scenario": "demo"},
        )

        # Keep snapshot/run metadata aligned with the canonical (windowed) demo payload.
        try:
            state["run_id"] = int(run_id)
        except Exception:
            pass
        try:
            runs = snapshot.get("runs")
            if isinstance(runs, list) and runs and isinstance(runs[0], dict):
                runs[0].update(
                    {
                        "run_id": run_id,
                        "guide_id": guide_id,
                        "edit_type": "crispr",
                        "sequence": sequence,
                        "target_locus": locus,
                        "pam_index": pam_index,
                        "cut_index": cut_index,
                        "outcomes": outcomes,
                        "physics": dict(run_model.physics or {}),
                        "engine": engine.to_dict(),
                    }
                )
                run_meta = runs[0].get("metadata")
                if not isinstance(run_meta, dict):
                    run_meta = {}
                run_meta.setdefault("scenario", "demo")
                runs[0]["metadata"] = run_meta
        except Exception:
            pass

        snapshot["version"] = SESSION_SNAPSHOT_VERSION
        snapshot.setdefault("runs", [run_model.to_dict()])
        # Attach Summary Contract v2 so OutcomeExplorer can render without waiting on run-history injection.
        try:
            from helix.studio.summary_contract_v2 import build_run_summary_v2_from_snapshot

            run_summary = build_run_summary_v2_from_snapshot(snapshot, off_target_mode="policy")
        except Exception:
            run_summary = None
        if isinstance(run_summary, Mapping):
            meta["run_summary"] = dict(run_summary)
            try:
                runs = snapshot.get("runs")
                if isinstance(runs, list) and runs and isinstance(runs[0], dict):
                    run_meta = runs[0].get("metadata")
                    if not isinstance(run_meta, dict):
                        run_meta = {}
                    run_meta.setdefault("scenario", "demo")
                    run_meta["run_summary"] = dict(run_summary)
                    runs[0]["metadata"] = run_meta
            except Exception:
                pass
        snapshot["timestamp"] = clock.utc_now_iso_offset()
        return snapshot
    except Exception:
        # Fall back to a minimal synthetic demo if the preset is unavailable.
        sequence = "TTGCTGGAACAGGAAGAGGATGGAGTCCGAGCAGAAGAAGAAGGGCTGGTGAAGGGAACGTTGTCCTCTAACGTGGC"
        guide_range = (21, 41)  # inclusive start, exclusive end
        pam_index = 41
        cut_index = pam_index - 3
        guide_id = "EMX1_g1"
        locus = "chr19:55,200,021-55,200,097"
        run_id = "101"

        outcomes: list[dict[str, Any]] = [
            {
                "label": "intended_edit",
                "category": "small_insertion",
                "probability": 0.38,
                "delta_bp": 1,
                "diff": {"kind": "insertion", "start": cut_index, "end": cut_index, "replacement": "A"},
                "frameshift": False,
                "tags": ["intended"],
            },
            {
                "label": "frameshift_del",
                "category": "small_deletion",
                "probability": 0.22,
                "delta_bp": -3,
                "diff": {"kind": "deletion", "start": cut_index - 1, "end": cut_index + 2},
                "frameshift": True,
            },
            {
                "label": "microhomology_del",
                "category": "large_deletion",
                "probability": 0.14,
                "delta_bp": -12,
                "diff": {"kind": "deletion", "start": cut_index - 6, "end": cut_index + 6, "microhomology": 4},
                "frameshift": True,
            },
            {
                "label": "no_cut",
                "category": "no_cut",
                "probability": 0.26,
                "delta_bp": 0,
                "diff": {"kind": "no_cut"},
                "frameshift": False,
            },
        ]

        spec = EditVisualizationSpec(
            sequence=sequence,
            pam_index=pam_index,
            guide_range=guide_range,
            edit_type="CRISPR",
            events=[
                EditEvent(t=0.1, type=EditEventType.RECOGNITION, index=guide_range[0]),
                EditEvent(t=0.2, type=EditEventType.NICK_PRIMARY, index=cut_index),
                EditEvent(t=0.4, type=EditEventType.CUT, index=cut_index),
                EditEvent(t=0.8, type=EditEventType.REPAIR_COMPLETE, index=cut_index),
            ],
            time_units="normalized",
            metadata={
                "guide": {
                    "id": guide_id,
                    "sequence": sequence[guide_range[0] : guide_range[1]],
                    "pam": "NGG",
                    "strand": "+",
                },
                "site": {
                    "sequence": sequence,
                    "length": len(sequence),
                    "chrom": "chr19",
                    "start": 55_200_021,
                    "end": 55_200_021 + len(sequence),
                },
            },
        )
        viz_payload = spec.to_payload()
        viz_payload["guide"] = {
            "id": guide_id,
            "name": "EMX1",
            "sequence": sequence[guide_range[0] : guide_range[1]],
            "pam": "NGG",
            "strand": "+",
            "start": guide_range[0],
            "end": guide_range[1],
        }
        viz_payload["site"] = {
            "sequence": sequence,
            "length": len(sequence),
            "chrom": "chr19",
            "start": 55_200_021,
            "end": 55_200_021 + len(sequence),
        }

        config = {
            "sim_type": "CRISPR",
            "sim_settings": {
                "viz_mode": "workflow_2p5d",
                "pam_profile": "SpCas9_NGG",
                "draws": 1000,
                "seed": 42,
                "pam_softness": 0.2,
                "priors_profile": "default_indel",
            },
            "run_config": {
                "mode": "SpCas9_NGG",
                "draws": 1000,
                "seed": 42,
                "pam_profile": "SpCas9_NGG",
                "pam_softness": 0.2,
                "priors_profile": "default_indel",
            },
            "guide": {
                "id": guide_id,
                "name": "EMX1",
                "start": guide_range[0],
                "end": guide_range[1],
                "strand": "+",
                "pam": "NGG",
                "locus": locus,
                "sequence": sequence[guide_range[0] : guide_range[1]],
            },
            "sim_payload": {
                "site": viz_payload["site"],
                "guide": viz_payload["guide"],
                "outcomes": outcomes,
                "artifact": "helix.demo.crispr.v1",
            },
        }

        engine = EngineInfo(name="helix_cuda", backend="gpu", crispr_scoring_version="1.0", prime_scoring_version=None)
        run_model = RunModel(
            run_id=run_id,
            guide_id=guide_id,
            edit_type="crispr",
            sequence=sequence,
            target_locus=locus,
            pam_index=pam_index,
            cut_index=cut_index,
            outcomes=[OutcomeModel.from_dict(o) for o in outcomes],
            physics={"cut_prob": 0.74, "frameshift_prob": 0.52},
            engine=engine,
            metadata={"scenario": "demo"},
        )

        state = {
            "run_kind": "CRISPR",
            "run_id": int(run_id),
            "viz_dirty": True,
            "config": config,
            "outcomes": outcomes,
            "dag_from_runtime": {},
            "viz_spec_payload": viz_payload,
            "genome_source": "demo",
            "genome_uri": "demo://emx1",
            "genome_hash": "demo-emx1-v1",
            "genome": {"chr19": sequence},
        }

        return {
            "version": SESSION_SNAPSHOT_VERSION,
            "state": state,
            "runs": [run_model.to_dict()],
            "timestamp": clock.utc_now_iso_offset(),
        }


def build_runmodels_from_demo() -> list[RunModel]:
    if DEMO_HELIX_PATH.exists():
        try:
            session = load_session(DEMO_HELIX_PATH)
            return list(session.runs)
        except Exception:
            pass
    raw = _load_demo_json()
    runs: list[RunModel] = []
    for gd in raw.get("guides", []):
        engine = EngineInfo(
            name="helix_cuda",
            backend="gpu",
            crispr_scoring_version=None,
            prime_scoring_version=None,
        )
        outcomes = [OutcomeModel.from_dict(o) for o in gd.get("outcomes", [])]
        run = RunModel(
            run_id=str(gd.get("run_id", "demo")),
            guide_id=str(gd.get("guide_id", "guide")),
            edit_type=str(gd.get("edit_type", "")),
            sequence=str(gd.get("sequence", "")),
            target_locus=str(gd.get("target_locus", "")),
            pam_index=gd.get("pam_index"),
            cut_index=gd.get("cut_index"),
            outcomes=outcomes,
            physics=dict(gd.get("physics", {}) or {}),
            engine=engine,
            metadata={},
        )
        runs.append(run)
    return runs


def build_guide_summaries_from_demo() -> Sequence[GuideRunSummary]:
    runs = build_runmodels_from_demo()
    return build_guide_summaries_from_runs(runs)


def build_guide_summaries_from_runs(runs: Sequence[RunModel]) -> list[GuideRunSummary]:
    rows: list[GuideRunSummary] = []
    for run in runs:
        physics = run.physics or {}
        cut_prob = float(physics.get("cut_prob", 0.0))
        fs_prob = float(physics.get("frameshift_prob", 0.0))
        e_pred = physics.get("E_pred")
        top_outcome = "--"
        if run.outcomes:
            try:
                top = max(run.outcomes, key=lambda o: o.prob)
                top_outcome = top.name
            except Exception:
                top_outcome = run.outcomes[0].name
        rows.append(
            GuideRunSummary(
                run_id=run.run_id,
                guide_id=run.guide_id,
                target_locus=run.target_locus,
                cut_prob=cut_prob,
                frameshift_prob=fs_prob,
                top_outcome=top_outcome,
                e_pred=e_pred if e_pred is None else float(e_pred),
                payload_ref=run,
                scenario=(run.metadata or {}).get("scenario"),
            )
        )
    return rows


def build_guide_summaries_from_session(session) -> Sequence[GuideRunSummary]:
    runs = getattr(session, "runs", []) or []
    if runs:
        return build_guide_summaries_from_runs(runs)
    return []


def demo_guides_payload() -> Mapping[str, Any]:
    return _load_demo_json()
