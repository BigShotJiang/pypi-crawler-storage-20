from __future__ import annotations

from typing import Any, Mapping
from dataclasses import dataclass

from PySide6.QtWidgets import (
    QWidget,
    QStackedLayout,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QFrame,
    QSizePolicy,
    QMessageBox,
)
from PySide6.QtCore import Qt, QPropertyAnimation, QSettings
from PySide6.QtWidgets import QGraphicsOpacityEffect

from .outcome_explorer import OutcomeExplorerWidget
from .ui_tokens import base_font, MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL
from .hint_banner import HintBanner

SETTINGS_ORG = "Helix"
SETTINGS_APP = "Studio"


@dataclass
class HeroStatusModel:
    has_runs: bool = False
    latest_run_name: str | None = None
    latest_run_kind: str | None = None
    latest_outcomes_count: int = 0
    is_running: bool = False
    last_error: str | None = None


class CenterPanel(QWidget):
    """Holds hero state + summary + outcome explorer bound to an EVS."""

    def __init__(self, ctx: object, main_window: object, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._evs: dict[str, Any] | None = None
        self._ctx = ctx
        self._main_window = main_window
        self._session = None
        self._hero_status_model = HeroStatusModel()
        self._status_anim: QPropertyAnimation | None = None
        self._settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        self._onboarding_seen = bool(self._settings.value("onboarding/seen", False))

        self._stack = QStackedLayout(self)
        self._hero = self._build_hero()
        self._summary_panel = self._build_summary_panel()

        self._stack.addWidget(self._hero)
        self._stack.addWidget(self._summary_panel)

        self.update_status(HeroStatusModel())
        self._compact_mode = False
        self._focus_layout_enabled = False
        self._explorer.set_run_select_handler(self._on_run_selected_from_timeline)
        self._explorer.compareRunRequested.connect(self._on_compare_requested_from_timeline)
        try:
            self._explorer.cloneRunRequested.connect(self._on_clone_requested_from_timeline)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._update_hero_card_padding()
        except Exception:
            pass

    def set_compact_mode(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if self._compact_mode == enabled:
            return
        self._compact_mode = enabled
        try:
            self._explorer.set_compact_mode(enabled)
        except Exception:
            pass

    def bind_session(self, session: object) -> None:
        self._session = session
        try:
            session.stateChanged.connect(self._on_session_state_changed)
            session.errorOccurred.connect(self._on_session_error)
            session.statusChanged.connect(self._on_session_status)
            session.runRecorded.connect(self._on_session_run_recorded)
            self._on_session_state_changed(getattr(session, "state", None))
        except Exception:
            pass

    def _build_hero(self) -> QWidget:
        outer = QWidget(self)
        outer.setObjectName("CenterHeroCanvas")
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        outer_layout.setSpacing(SPACING_MEDIUM)

        outer_layout.addStretch(1)

        card = QFrame(outer)
        card.setObjectName("CenterHeroCard")
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        # Keep hero card comfortably wide on desktop; tests expect onboarding width.
        card.setMinimumWidth(720)
        card.setMaximumWidth(980)
        self._hero_card = card
        card_layout = QVBoxLayout(card)
        self._hero_card_layout = card_layout
        card_layout.setContentsMargins(32, 32, 32, 32)
        card_layout.setSpacing(14)

        pill = QLabel("THE GENOME IDE", card)
        pill.setObjectName("StudioHero")
        card_layout.addWidget(pill, alignment=Qt.AlignLeft)

        help_btn = QPushButton("?")
        help_btn.setFixedSize(30, 30)
        help_btn.setObjectName("SecondaryButton")
        help_btn.clicked.connect(lambda: QMessageBox.information(self, "Hero", "This panel shows edit status, last run, and quick access to demo/latest runs."))
        pill_row = QHBoxLayout()
        pill_row.setContentsMargins(0, 0, 0, 0)
        pill_row.addWidget(pill)
        pill_row.addStretch(1)
        pill_row.addWidget(help_btn)
        card_layout.addLayout(pill_row)

        title = QLabel("Ready to visualize your edit", card)
        title.setObjectName("StudioHeroTitle")
        title.setWordWrap(True)
        card_layout.addWidget(title)

        subtitle = QLabel(
            "Design guides, run CRISPR or prime simulations, and inspect outcomes in one genome console.",
            card,
        )
        subtitle.setObjectName("StudioHeroSubtitle")
        subtitle.setWordWrap(True)
        card_layout.addWidget(subtitle)

        self._hero_status = QLabel("", card)
        self._hero_status.setObjectName("StudioHeroStatus")
        self._hero_status.setProperty("tone", "muted")
        self._hero_status.setVisible(False)
        card_layout.addWidget(self._hero_status)

        stats_row = QHBoxLayout()
        stats_row.setContentsMargins(0, 6, 0, 4)
        stats_row.setSpacing(12)

        run_card, self._stat_run_value, self._stat_run_meta = self._build_stat_card("Latest run")
        outcome_card, self._stat_outcome_value, self._stat_outcome_meta = self._build_stat_card("Outcomes")
        state_card, self._stat_state_value, self._stat_state_meta = self._build_stat_card("State")
        self._stat_run_card = run_card
        self._stat_outcome_card = outcome_card
        self._stat_state_card = state_card

        stats_row.addWidget(run_card, 1)
        stats_row.addWidget(outcome_card, 1)
        stats_row.addWidget(state_card, 1)
        card_layout.addLayout(stats_row)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(12)
        btn_row.setContentsMargins(0, 12, 0, 0)
        self._demo_btn = QPushButton("Open CRISPR demo (Ctrl+D)", card)
        self._demo_btn.setObjectName("PrimaryButton")
        self._demo_btn.setMinimumWidth(170)
        self._demo_btn.setMinimumHeight(38)
        self._demo_btn.clicked.connect(self._on_open_demo_clicked)
        self._latest_btn = QPushButton("Open latest run (Ctrl+L)", card)
        self._latest_btn.setObjectName("SecondaryButton")
        self._latest_btn.setMinimumWidth(170)
        self._latest_btn.setMinimumHeight(38)
        self._latest_btn.clicked.connect(self._on_open_latest_clicked)
        btn_row.addWidget(self._demo_btn)
        btn_row.addWidget(self._latest_btn)
        card_layout.addLayout(btn_row)

        outer_layout.addWidget(card, alignment=Qt.AlignHCenter | Qt.AlignVCenter)
        if not self._onboarding_seen:
            self._hero_hint = HintBanner(
                "Tip: Start with the EMX1 demo to see a complete CRISPR run with outcomes.",
                outer,
            )
            self._hero_hint.closed.connect(lambda: self._set_onboarding_seen(True))
            outer_layout.addWidget(self._hero_hint)
        outer_layout.addStretch(1)
        return outer

    def _build_stat_card(self, title: str) -> tuple[QFrame, QLabel, QLabel]:
        card = QFrame(self)
        card.setObjectName("HeroStatCard")
        card.setProperty("tone", "muted")
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(2)

        label = QLabel(title, card)
        label.setObjectName("HeroStatLabel")
        label.setTextFormat(Qt.PlainText)

        value = QLabel("—", card)
        value.setObjectName("HeroStatValue")
        value.setTextFormat(Qt.PlainText)

        meta = QLabel(" ", card)
        meta.setObjectName("HeroStatMeta")
        meta.setTextFormat(Qt.PlainText)
        meta.setWordWrap(True)

        layout.addWidget(label)
        layout.addWidget(value)
        layout.addWidget(meta)
        return card, value, meta

    def _update_hero_card_padding(self) -> None:
        layout = getattr(self, "_hero_card_layout", None)
        if layout is None:
            return
        # Height constrained → reduce padding, never font size.
        # Keep horizontal padding stable so the card still reads as intentional.
        h = int(self.height() or 0)
        if h and h < 620:
            vpad = 18
        elif h and h < 720:
            vpad = 24
        else:
            vpad = 32
        layout.setContentsMargins(32, vpad, 32, vpad)

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        try:
            self._update_hero_card_padding()
        except Exception:
            pass

    def _build_summary_panel(self) -> QWidget:
        w = QWidget(self)
        w.setObjectName("CenterSummaryPanel")
        v = QVBoxLayout(w)
        v.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        v.setSpacing(SPACING_MEDIUM)

        self._summary_label = QLabel("", w)
        self._summary_label.setObjectName("CenterSummaryLabel")
        self._summary_label.setProperty("role", "muted")
        v.addWidget(self._summary_label)

        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(0, 0, 0, 0)
        btn_row.setSpacing(SPACING_MEDIUM)
        self._summary_latest_btn = QPushButton("Open latest run", w)
        self._summary_latest_btn.setObjectName("SecondaryButton")
        self._summary_latest_btn.setMinimumWidth(140)
        self._summary_latest_btn.clicked.connect(self._on_open_latest_clicked)
        btn_row.addWidget(self._summary_latest_btn, alignment=Qt.AlignLeft)
        btn_row.addStretch(1)
        v.addLayout(btn_row)

        self._explorer = OutcomeExplorerWidget(w)
        explorer_card = QFrame(w)
        explorer_card.setObjectName("EVSOutcomeCard")
        explorer_card_layout = QVBoxLayout(explorer_card)
        explorer_card_layout.setContentsMargins(12, 12, 12, 12)
        explorer_card_layout.setSpacing(SPACING_SMALL)
        explorer_card_layout.addWidget(self._explorer)

        v.addWidget(explorer_card)

        self._evs_hint = None
        if not self._onboarding_seen:
            self._evs_hint = HintBanner(
                "Tip: Hover bars and rows to inspect outcomes; click to lock one.",
                w,
            )
            self._evs_hint.hide()
            self._evs_hint.closed.connect(lambda: self._set_onboarding_seen(True))
            v.addWidget(self._evs_hint)
        return w

    def set_focus_layout(self, enabled: bool) -> None:
        """
        Collapse non-essential widgets so the outcome explorer can own the space.
        Focus mode hides the details/table split and lets the chart expand.
        """
        if self._focus_layout_enabled == enabled:
            return
        self._focus_layout_enabled = enabled

        if not hasattr(self, "_explorer"):
            return
        try:
            self._explorer.set_focus_mode(enabled)
        except Exception:
            pass

    def set_run_list(self, runs) -> None:
        """Pass run list into explorer for focus-mode timeline."""
        try:
            self._explorer.set_run_list(runs)
        except Exception:
            pass

    def set_compare_handler(self, handler) -> None:
        """Set a callable(run_id) to handle overlay requests from explorer."""
        try:
            self._compare_handler = handler
            self._explorer.compareRunRequested.connect(handler)
        except Exception:
            pass

    def _on_run_selected_from_timeline(self, run_id: str) -> None:
        """Bubble timeline selection to the main window to load that run."""
        try:
            if hasattr(self._main_window, "on_run_activated"):
                self._main_window.on_run_activated(run_id)
        except Exception:
            pass

    def _on_compare_requested_from_timeline(self, run_id: str) -> None:
        """Forward overlay requests to main window to load baseline overlay."""
        try:
            if hasattr(self._main_window, "_on_focus_compare_requested"):
                self._main_window._on_focus_compare_requested(run_id)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _on_clone_requested_from_timeline(self, run_id: str) -> None:
        try:
            if hasattr(self._main_window, "_clone_run_to_builder"):
                self._main_window._clone_run_to_builder(run_id)  # type: ignore[attr-defined]
        except Exception:
            pass

    def show_hero(self) -> None:
        self._stack.setCurrentWidget(self._hero)

    @staticmethod
    def _repolish_widget(widget: QWidget | None) -> None:
        if widget is None:
            return
        try:
            style = widget.style()
            style.unpolish(widget)
            style.polish(widget)
            widget.update()
        except Exception:
            pass

    def _apply_card_tone(self, card: QWidget | None, tone: str) -> None:
        if card is None:
            return
        card.setProperty("tone", tone)
        self._repolish_widget(card)

    def _transition_to_summary(self) -> None:
        self._stack.setCurrentWidget(self._summary_panel)
        effect = QGraphicsOpacityEffect(self._summary_panel)
        self._summary_panel.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity", self)
        anim.setDuration(220)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.start(QPropertyAnimation.DeleteWhenStopped)
        self._status_anim = anim

    def _set_onboarding_seen(self, seen: bool = True) -> None:
        self._onboarding_seen = seen
        try:
            self._settings.setValue("onboarding/seen", bool(seen))
        except Exception:
            pass
        if seen:
            if getattr(self, "_hero_hint", None) is not None:
                self._hero_hint.hide()
            if getattr(self, "_evs_hint", None) is not None:
                self._evs_hint.hide()

    def _on_open_latest_clicked(self) -> None:
        run_id = None
        try:
            run_id = self._main_window.latest_run_id()
        except Exception:
            run_id = None
        if not run_id:
            return
        try:
            self._main_window.on_run_activated(run_id)
        except Exception:
            pass

    def _on_open_demo_clicked(self) -> None:
        try:
            action = getattr(self._main_window, "actionOpenDemo", None)
            if action is not None:
                action.trigger()
        except Exception:
            pass

    def set_evs(self, evs: dict[str, Any] | None) -> None:
        self._evs = evs
        if evs is None:
            self.update_status(HeroStatusModel())
            try:
                self._explorer.clear_view()
            except Exception:
                pass
            self.show_hero()
            return
        # Build summary text from an EVS or from a Studio session snapshot state.
        mode = "?"
        guide = "guide"
        guide_seq = ""
        locus_text = "chr?:?-?"
        outcomes_count: int | None = None

        edit_plan = evs.get("editPlan") if isinstance(evs.get("editPlan"), Mapping) else None
        if isinstance(edit_plan, Mapping):
            mode = str(edit_plan.get("mode") or mode)
            targets = edit_plan.get("targets") if isinstance(edit_plan.get("targets"), list) else []
            if targets and isinstance(targets[0], Mapping):
                guide = str(targets[0].get("label") or guide)
                grna = targets[0].get("gRNA") if isinstance(targets[0].get("gRNA"), Mapping) else {}
                if isinstance(grna, Mapping):
                    guide_seq = str(grna.get("sequence") or "")

        if mode == "?" or not mode:
            run_kind = evs.get("run_kind")
            if run_kind is not None:
                mode = str(run_kind)
        if mode == "?" or not mode:
            cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
            if isinstance(cfg, Mapping):
                mode = str(cfg.get("sim_type") or mode)

        cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
        guide_cfg = cfg.get("guide") if isinstance(cfg, Mapping) and isinstance(cfg.get("guide"), Mapping) else {}
        if guide == "guide" and isinstance(guide_cfg, Mapping):
            guide = str(guide_cfg.get("id") or guide_cfg.get("name") or guide)
        if not guide_seq and isinstance(guide_cfg, Mapping):
            guide_seq = str(guide_cfg.get("sequence") or "")

        seq = evs.get("sequence") if isinstance(evs.get("sequence"), Mapping) else {}
        locus = seq.get("referenceLocus") if isinstance(seq.get("referenceLocus"), Mapping) else {}
        if isinstance(locus, Mapping) and locus.get("chrom") is not None:
            chrom = locus.get("chrom", "chr?")
            start = locus.get("start", "?")
            end = locus.get("end", "?")
            locus_text = f"{chrom}:{start}-{end}"
        elif isinstance(guide_cfg, Mapping) and guide_cfg.get("locus"):
            locus_text = str(guide_cfg.get("locus"))

        sim = evs.get("simulation") if isinstance(evs.get("simulation"), Mapping) else None
        if isinstance(sim, Mapping):
            results = sim.get("results") if isinstance(sim.get("results"), Mapping) else {}
            alleles = results.get("alleles")
            if isinstance(alleles, list):
                outcomes_count = len(alleles)
        if outcomes_count is None:
            outcomes = evs.get("outcomes")
            if isinstance(outcomes, list):
                outcomes_count = len(outcomes)
        if outcomes_count is None and isinstance(cfg, Mapping):
            sim_payload = cfg.get("sim_payload") if isinstance(cfg.get("sim_payload"), Mapping) else {}
            if isinstance(sim_payload, Mapping) and isinstance(sim_payload.get("outcomes"), list):
                outcomes_count = len(sim_payload.get("outcomes") or [])
        if outcomes_count is None:
            try:
                outcomes_count = int(evs.get("outcomes_count") or 0)
            except Exception:
                outcomes_count = 0

        meta = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
        run_label = evs.get("run_label") or (meta.get("run_label") if isinstance(meta, Mapping) else None) or guide
        outcomes_text = f"{outcomes_count} outcome{'s' if outcomes_count != 1 else ''}"

        guide_part = ""
        if guide_seq:
            guide_seq_trim = guide_seq
            if len(guide_seq_trim) > 32:
                guide_seq_trim = guide_seq_trim[:29] + "…"
            guide_part = f" ({guide_seq_trim})"
        self._summary_label.setText(f"{mode} – {guide}{guide_part} · {locus_text} · {outcomes_text}")
        try:
            self._explorer.set_evs(evs)
        except Exception:
            pass
        status = HeroStatusModel(
            has_runs=True,
            latest_run_name=str(run_label),
            latest_run_kind=str(mode).upper(),
            latest_outcomes_count=int(outcomes_count or 0),
            is_running=False,
        )
        self.update_status(status)
        self._transition_to_summary()
        if getattr(self, "_evs_hint", None) is not None and not self._onboarding_seen:
            self._evs_hint.show()

    def _on_session_state_changed(self, state: object) -> None:
        if state is None:
            self._hero_status.setVisible(False)
            return
        config = getattr(state, "config", {}) if hasattr(state, "config") else {}
        if not isinstance(config, Mapping):
            config = {}
        run_config = config.get("run_config") if isinstance(config, Mapping) else {}
        guide = config.get("guide") if isinstance(config, Mapping) else {}
        outcomes = getattr(state, "outcomes", []) if hasattr(state, "outcomes") else []
        run_id = getattr(state, "run_id", None) if hasattr(state, "run_id") else None
        run_kind = getattr(state, "run_kind", None) if hasattr(state, "run_kind") else None
        draws = ""
        if isinstance(run_config, Mapping):
            draws = str(run_config.get("draws") or "")
        guide_label = ""
        locus = ""
        if isinstance(guide, Mapping):
            guide_label = guide.get("name") or guide.get("id") or ""
            locus = guide.get("locus") or ""
        mode = ""
        if isinstance(run_config, Mapping):
            mode = run_config.get("mode") or ""
        if not mode and run_kind:
            mode = getattr(run_kind, "name", str(run_kind))
        if mode:
            mode = str(mode)
        summary_parts = []
        if mode:
            summary_parts.append(mode)
        if guide_label:
            summary_parts.append(guide_label if not locus else f"{guide_label} @ {locus}")
        if draws:
            summary_parts.append(f"{draws} draws")
        if outcomes:
            summary_parts.append(f"{len(outcomes)} outcomes")
        elif getattr(state, "run_kind", None) is not None and getattr(state, "run_kind", None) != getattr(state, "RunKind", None):
            summary_parts.append("no outcomes yet")
        text = "Last run: " + " • ".join(summary_parts) if summary_parts else ""
        if run_id not in (None, 0, "0"):
            text = f"Last run #{run_id}: " + " • ".join(summary_parts) if summary_parts else f"Last run #{run_id}"

        status = HeroStatusModel(
            has_runs=bool(outcomes or run_id not in (None, 0, "0")),
            latest_run_name=guide_label or (f"Run #{run_id}" if run_id not in (None, 0, "0") else None),
            latest_run_kind=str(mode) if mode else None,
            latest_outcomes_count=len(outcomes),
            is_running=getattr(state, "viz_dirty", False) and not outcomes,
            last_error=None,
        )
        self.update_status(status, fallback_text=text)

    def explorer(self) -> OutcomeExplorerWidget:
        return self._explorer

    # --- Hero status management -------------------------------------

    def _refresh_insight_cards(self, status: HeroStatusModel) -> None:
        if not hasattr(self, "_stat_run_value"):
            return

        run_label = status.latest_run_name or "No run yet"
        run_kind = (status.latest_run_kind or "Ready").upper()
        self._stat_run_value.setText(run_label)
        self._stat_run_meta.setText(run_kind)
        self._apply_card_tone(getattr(self, "_stat_run_card", None), "ok" if status.has_runs else "muted")

        outcomes = max(0, int(status.latest_outcomes_count or 0))
        self._stat_outcome_value.setText(f"{outcomes:,}")
        outcome_meta = "outcomes observed" if outcomes else "awaiting first outcomes"
        self._stat_outcome_meta.setText(outcome_meta)
        self._apply_card_tone(getattr(self, "_stat_outcome_card", None), "active" if outcomes else "muted")

        state_text = "Running" if status.is_running else ("Ready" if status.has_runs else "Idle")
        if status.last_error:
            state_meta = status.last_error
            tone = "warn"
        elif status.is_running:
            state_meta = "live simulation"
            tone = "active"
        elif status.has_runs:
            state_meta = "resume or compare latest run"
            tone = "ok"
        else:
            state_meta = "start with the guided demo"
            tone = "muted"
        self._stat_state_value.setText(state_text)
        self._stat_state_meta.setText(state_meta)
        self._apply_card_tone(getattr(self, "_stat_state_card", None), tone)

    def update_status(self, status: HeroStatusModel, fallback_text: str | None = None) -> None:
        self._hero_status_model = status
        running = bool(status.is_running)
        has_runs = bool(status.has_runs)
        self._demo_btn.setEnabled(not running)
        self._latest_btn.setEnabled(has_runs and not running)
        if hasattr(self, "_summary_latest_btn"):
            self._summary_latest_btn.setEnabled(has_runs and not running)
        self._latest_btn.setToolTip("Run a simulation to enable" if not has_runs else "Open the most recent run")
        self._demo_btn.setToolTip("Demo is disabled while a run is executing" if running else "Load EMX1 CRISPR demo")

        if status.is_running:
            text = f"Running: {status.latest_run_name or 'active simulation'}"
            tone = "warn"
        elif status.last_error:
            text = f"Last run failed: {status.last_error}"
            tone = "error"
        elif status.has_runs:
            pieces = []
            if status.latest_run_name:
                pieces.append(status.latest_run_name)
            if status.latest_run_kind:
                pieces.append(str(status.latest_run_kind))
            if status.latest_outcomes_count:
                pieces.append(f"{status.latest_outcomes_count} outcomes")
            text = "Last run: " + " · ".join(pieces)
            tone = "muted"
        else:
            text = fallback_text or "Last run: NONE · no outcomes yet"
            tone = "disabled"

        self._hero_status.setText(text)
        self._hero_status.setProperty("tone", tone)
        self._repolish_widget(self._hero_status)
        self._hero_status.setVisible(bool(text))
        self._refresh_insight_cards(status)

    def _on_session_error(self, message: str) -> None:
        status = HeroStatusModel(
            has_runs=self._hero_status_model.has_runs,
            latest_run_name=self._hero_status_model.latest_run_name,
            latest_run_kind=self._hero_status_model.latest_run_kind,
            latest_outcomes_count=self._hero_status_model.latest_outcomes_count,
            is_running=False,
            last_error=message,
        )
        self.update_status(status)

    def _on_session_status(self, message: str) -> None:
        msg = str(message).lower()
        running = "running" in msg or "simulating" in msg
        status = HeroStatusModel(
            has_runs=self._hero_status_model.has_runs,
            latest_run_name=self._hero_status_model.latest_run_name,
            latest_run_kind=self._hero_status_model.latest_run_kind,
            latest_outcomes_count=self._hero_status_model.latest_outcomes_count,
            is_running=running,
            last_error=None,
        )
        self.update_status(status)

    def _on_session_run_recorded(self, snapshot: Mapping[str, Any]) -> None:
        try:
            state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
            outcomes = state.get("outcomes", []) if isinstance(state, Mapping) else []
            meta = state.get("config", {}).get("metadata", {}) if isinstance(state, Mapping) and isinstance(state.get("config"), Mapping) else {}
            guide = (state.get("config", {}).get("guide", {}) if isinstance(state, Mapping) else {}).get("id")
            run_label = state.get("run_label") or meta.get("run_label") or guide
            run_kind = state.get("run_kind") if isinstance(state, Mapping) else None
            status = HeroStatusModel(
                has_runs=True,
                latest_run_name=run_label or f"Run #{state.get('run_id', '')}",
                latest_run_kind=str(run_kind) if run_kind else None,
                latest_outcomes_count=len(outcomes),
                is_running=False,
            )
            self.update_status(status)
        except Exception:
            pass
