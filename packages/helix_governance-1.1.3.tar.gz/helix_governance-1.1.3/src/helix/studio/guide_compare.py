from __future__ import annotations

from typing import Any, Callable

from PySide6.QtWidgets import QHBoxLayout, QLabel, QVBoxLayout, QWidget, QFrame

from .outcome_explorer import OutcomeExplorerWidget, build_outcome_explorer_data


def _data_from_payload(payload: Any) -> Any:
    if payload is None:
        return None
    if hasattr(payload, "to_payload"):
        try:
            payload = payload.to_payload()
        except Exception:
            pass
    seq = ""
    guide = {}
    outcomes = []
    physics = None
    run_id = None
    backend_name = None
    backend_kind = None
    if isinstance(payload, dict):
        state = payload.get("state", payload)
        cfg = state.get("config", {}) if isinstance(state, dict) else {}
        sim_payload = cfg.get("sim_payload", {}) if isinstance(cfg, dict) else {}
        outcomes = state.get("outcomes") or sim_payload.get("outcomes") or []
        guide = cfg.get("guide", {}) if isinstance(cfg, dict) else {}
        physics = sim_payload.get("physics_score") if isinstance(sim_payload, dict) else None
        seq = sim_payload.get("site", {}).get("sequence") or sim_payload.get("sequence", "")
        run_id = state.get("run_id") if isinstance(state, dict) else None
        backend_name = cfg.get("backend") if isinstance(cfg, dict) else None
        backend_kind = cfg.get("backend_kind") if isinstance(cfg, dict) else backend_name
    if not seq or not outcomes:
        return None
    return build_outcome_explorer_data(
        seq,
        guide,
        outcomes,
        run_id=run_id,
        physics_run=physics,
        backend_name=backend_name,
        backend_kind=backend_kind,
    )


def _summary(data) -> dict | None:
    if data is None:
        return None
    backend_kind = getattr(data, "backend_kind", "") or ""
    backend_name = getattr(data, "backend_name", "") or ""
    is_prime = "prime" in str(backend_kind).lower() or "prime" in str(backend_name).lower()
    rows = getattr(data, "rows", []) or []
    perfect = 0.0
    indel_adj = 0.0
    if is_prime:
        for r in rows:
            try:
                p = float(r.probability)
            except Exception:
                p = 0.0
            label = str(getattr(r, "label", "")).lower()
            if "intended" in label:
                frameshift = bool(getattr(r, "frameshift", False))
                delta_bp = getattr(r, "delta_bp", 0)
                if not frameshift and delta_bp == 0:
                    perfect += p
                else:
                    indel_adj += p
    return {
        "cut": getattr(data.summary, "cut_prob", 0.0),
        "frameshift": getattr(data.summary, "frameshift_prob", 0.0),
        "outcomes": len(rows),
        "draws": None,
        "guide": getattr(data, "guide_id", ""),
        "is_prime": is_prime,
        "prime_perfect": perfect,
        "prime_indel_adj": indel_adj,
        "prime_rtt_util": perfect + indel_adj,
    }


def _chip_text(s: dict | None) -> str:
    if s is None:
        return ""
    parts = []
    if s.get("guide"):
        parts.append(str(s["guide"]))
    parts.append(f"Intended (exploratory): {s['cut']*100:.1f}%")
    parts.append(f"Frameshift (exploratory): {s['frameshift']*100:.1f}%")
    parts.append(f"Outcomes: {s['outcomes']}")
    if s.get("is_prime"):
        parts.append(f"Perfect prime (exploratory): {s['prime_perfect']*100:.1f}%")
        parts.append(f"Indel-adj (exploratory): {s['prime_indel_adj']*100:.1f}%")
        parts.append(f"RTT util (exploratory): {s['prime_rtt_util']*100:.1f}%")
    return " · ".join(parts)


class GuideCompareWidget(QWidget):
    """Side-by-side Outcome Explorer comparison for two guides."""

    def __init__(self, explorer_factory: Callable[[], OutcomeExplorerWidget], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._factory = explorer_factory

        root = QVBoxLayout(self)
        root.setContentsMargins(8, 8, 8, 8)
        root.setSpacing(6)

        self.diff_strip = QLabel("", self)
        self.diff_strip.setStyleSheet("color: palette(window-text); font-weight: 600;")
        root.addWidget(self.diff_strip)

        header_chips = QHBoxLayout()
        header_chips.setContentsMargins(0, 0, 0, 0)
        header_chips.setSpacing(6)
        self.baseline_chip = QLabel("Baseline: none", self)
        self.baseline_chip.setObjectName("RunChip")
        self.candidate_chip = QLabel("Candidate: none", self)
        self.candidate_chip.setObjectName("RunChip")
        header_chips.addWidget(self.baseline_chip)
        header_chips.addWidget(self.candidate_chip)
        header_chips.addStretch(1)
        root.addLayout(header_chips)

        layout = QHBoxLayout()
        layout.setSpacing(8)
        root.addLayout(layout)

        self.left_header = QLabel("Guide A", self)
        self.right_header = QLabel("Guide B", self)
        for lab in (self.left_header, self.right_header):
            lab.setStyleSheet("font-weight: 600;")
            lab.setProperty("helix-section", True)

        left_col = QVBoxLayout()
        right_col = QVBoxLayout()

        self.left_card = QFrame(self)
        self.left_card.setObjectName("CompareCard")
        lcard_layout = QVBoxLayout(self.left_card)
        lcard_layout.setContentsMargins(8, 8, 8, 8)
        lcard_layout.setSpacing(6)

        self.right_card = QFrame(self)
        self.right_card.setObjectName("CompareCard")
        rcard_layout = QVBoxLayout(self.right_card)
        rcard_layout.setContentsMargins(8, 8, 8, 8)
        rcard_layout.setSpacing(6)

        self.left_chip = QLabel("", self.left_card)
        self.left_chip.setObjectName("RunChip")
        self.right_chip = QLabel("", self.right_card)
        self.right_chip.setObjectName("RunChip")

        self.left_explorer = self._factory()
        self.right_explorer = self._factory()

        lcard_layout.addWidget(self.left_header)
        lcard_layout.addWidget(self.left_chip)
        lcard_layout.addWidget(self.left_explorer, stretch=1)

        rcard_layout.addWidget(self.right_header)
        rcard_layout.addWidget(self.right_chip)
        rcard_layout.addWidget(self.right_explorer, stretch=1)

        left_col.addWidget(self.left_card)
        right_col.addWidget(self.right_card)

        layout.addLayout(left_col, stretch=1)
        layout.addLayout(right_col, stretch=1)

    def set_runs(
        self,
        a_payload: Any,
        a_label: str,
        a_rank: int | None,
        a_total: int | None,
        b_payload: Any,
        b_label: str,
        b_rank: int | None,
        b_total: int | None,
    ) -> None:
        self.left_header.setText(a_label)
        self.right_header.setText(b_label)

        data_a = _data_from_payload(a_payload)
        data_b = _data_from_payload(b_payload)

        sa = _summary(data_a)
        sb = _summary(data_b)
        self.left_chip.setText(_chip_text(sa))
        self.right_chip.setText(_chip_text(sb))
        self.baseline_chip.setText(f"Baseline: {a_label}")
        self.candidate_chip.setText(f"Candidate: {b_label}")
        self._update_diff_strip(sa, sb)

        if data_a is not None:
            try:
                self.left_explorer.set_run_model(a_payload)
            except Exception:
                pass
            self.left_explorer.set_data(data_a)
            self.left_explorer.set_rank(a_rank, a_total)
            if hasattr(a_payload, "engine"):
                try:
                    self.left_explorer.set_engine_info(a_payload.engine)
                except Exception:
                    pass
        if data_b is not None:
            try:
                self.right_explorer.set_run_model(b_payload)
            except Exception:
                pass
            self.right_explorer.set_data(data_b)
            self.right_explorer.set_rank(b_rank, b_total)
            if hasattr(b_payload, "engine"):
                try:
                    self.right_explorer.set_engine_info(b_payload.engine)
                except Exception:
                    pass

    def _update_diff_strip(self, sa, sb) -> None:
        if sa is None or sb is None:
            self.diff_strip.setText("")
            return
        d_intended = (sb["cut"] - sa["cut"]) * 100.0
        d_frame = (sb["frameshift"] - sa["frameshift"]) * 100.0
        self.diff_strip.setText(f"Δ intended_edit: {d_intended:+.2f}% · Δ frameshift: {d_frame:+.2f}%")
