from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Mapping

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from helix.studio.models import RunModel
from helix.studio.outcome_explorer import FlowLayout
from helix.studio.rail_model import CacheState, RailGraph
from helix.studio.rail_state import RailStateStore
from helix.studio.rail_widget import RailControlWidget
from helix.studio.session import ExperimentState, SessionModel
from helix.studio.simulation_diagnostics import SimulationDiagnostics, build_simulation_diagnostics
from helix.studio.ui_tokens import CAUTION, HX_DANGER, MARGIN_PANEL, SPACING_SMALL, SUCCESS, base_font, monospace_font
from helix.studio.governance_stamp import decision_grade_blocked_reasons, ui_mode_label, ui_mode_subtext
from helix.studio.export_labels import is_demo_from_metadata


class RunStatusPanel(QFrame):
    """
    Unified status stack for run health + simulation diagnostics.

    Always shows a single screenshot-safe summary line; all details are reachable
    with progressive disclosure.
    """

    def __init__(
        self,
        session: SessionModel | None,
        rail_store: RailStateStore | None,
        parent: QWidget | None = None,
        *,
        project_root: str | Path | None = None,
    ) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self.setFrameShape(QFrame.NoFrame)

        self._session = session
        self._rail_store = rail_store
        self._project_root = Path(project_root) if project_root else None

        self._evs: Mapping[str, Any] | None = None
        self._run_model: RunModel | None = None
        self._state: ExperimentState | None = session.state if session is not None else None
        self._last_diag: SimulationDiagnostics | None = None
        self._last_rail_graph: RailGraph | None = None
        self._last_readiness_blockers: list[Mapping[str, Any]] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self._bar = QFrame(self)
        self._bar.setObjectName("RunStatusBar")
        self._bar.setAttribute(Qt.WA_StyledBackground, True)
        bar_layout = QHBoxLayout(self._bar)
        bar_layout.setContentsMargins(12, 6, 12, 6)
        bar_layout.setSpacing(8)

        self._title = QLabel("Status", self._bar)
        self._title.setProperty("role", "muted")
        bar_layout.addWidget(self._title)

        self._summary_container = QWidget(self._bar)
        self._summary_container.setObjectName("RunStatusSummary")
        self._summary_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._summary_layout = FlowLayout(self._summary_container, hspacing=8, vspacing=6)
        self._summary_pills: list[QLabel] = []
        bar_layout.addWidget(self._summary_container, 1)

        self._toggle = QToolButton(self._bar)
        self._toggle.setObjectName("RunStatusToggle")
        self._toggle.setCheckable(True)
        self._toggle.setChecked(False)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.clicked.connect(self._toggle_details)
        bar_layout.addWidget(self._toggle)

        root.addWidget(self._bar)

        self._details = QWidget(self)
        self._details.setObjectName("RunStatusDetails")
        details_layout = QVBoxLayout(self._details)
        details_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        details_layout.setSpacing(SPACING_SMALL)

        # --- Decision readiness -------------------------------------------------
        self._decision_toggle = QToolButton(self._details)
        self._decision_toggle.setObjectName("RunStatusDecisionToggle")
        self._decision_toggle.setCheckable(True)
        self._decision_toggle.setChecked(True)
        self._decision_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._decision_toggle.clicked.connect(self._toggle_decision)
        self._decision_toggle_label = "Decision readiness"
        details_layout.addWidget(self._decision_toggle)

        self._decision_box = QFrame(self._details)
        self._decision_box.setObjectName("RunStatusDecisionBox")
        decision_layout = QVBoxLayout(self._decision_box)
        decision_layout.setContentsMargins(0, 0, 0, 0)
        decision_layout.setSpacing(SPACING_SMALL)
        self._rail_widget = RailControlWidget(rail_store, self._decision_box) if rail_store is not None else None
        if self._rail_widget is not None:
            decision_layout.addWidget(self._rail_widget)
        else:
            missing = QLabel("Rail unavailable.", self._decision_box)
            missing.setProperty("tone", "muted")
            decision_layout.addWidget(missing)

        self._decision_meta = QFrame(self._decision_box)
        self._decision_meta.setObjectName("RunStatusDecisionMeta")
        self._decision_meta.setStyleSheet(
            "QFrame#RunStatusDecisionMeta { border: 1px solid palette(mid); border-radius: 6px; }"
        )
        decision_meta_layout = QVBoxLayout(self._decision_meta)
        decision_meta_layout.setContentsMargins(10, 8, 10, 8)
        decision_meta_layout.setSpacing(6)

        self._decision_output = QLabel("", self._decision_meta)
        self._decision_output.setObjectName("RunStatusDecisionOutput")
        self._decision_output.setWordWrap(True)
        self._decision_output.setTextInteractionFlags(Qt.TextSelectableByMouse)
        decision_meta_layout.addWidget(self._decision_output)

        self._uncertainty_row = QLabel("", self._decision_meta)
        self._uncertainty_row.setObjectName("RunStatusUncertaintyRow")
        self._uncertainty_row.setWordWrap(True)
        self._uncertainty_row.setTextInteractionFlags(Qt.TextSelectableByMouse)
        decision_meta_layout.addWidget(self._uncertainty_row)

        self._on_target_row = QLabel("", self._decision_meta)
        self._on_target_row.setObjectName("RunStatusOnTargetRow")
        self._on_target_row.setWordWrap(True)
        self._on_target_row.setTextInteractionFlags(Qt.TextSelectableByMouse)
        decision_meta_layout.addWidget(self._on_target_row)

        self._recommendations = QLabel("", self._decision_meta)
        self._recommendations.setObjectName("RunStatusRecommendations")
        self._recommendations.setWordWrap(True)
        self._recommendations.setTextInteractionFlags(Qt.TextSelectableByMouse)
        decision_meta_layout.addWidget(self._recommendations)

        self._blocked_reasons = QLabel("", self._decision_meta)
        self._blocked_reasons.setObjectName("RunStatusBlockedReasons")
        self._blocked_reasons.setWordWrap(True)
        self._blocked_reasons.setTextInteractionFlags(Qt.TextSelectableByMouse)
        decision_meta_layout.addWidget(self._blocked_reasons)

        decision_layout.addWidget(self._decision_meta)
        details_layout.addWidget(self._decision_box)

        # --- Integrity & diagnostics ------------------------------------------
        self._diag_toggle = QToolButton(self._details)
        self._diag_toggle.setObjectName("RunStatusDiagnosticsToggle")
        self._diag_toggle.setCheckable(True)
        self._diag_toggle.setChecked(True)
        self._diag_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._diag_toggle.clicked.connect(self._toggle_diag)
        details_layout.addWidget(self._diag_toggle)

        self._diag_box = QFrame(self._details)
        self._diag_box.setObjectName("RunStatusDiagnosticsBox")
        diag_layout = QVBoxLayout(self._diag_box)
        diag_layout.setContentsMargins(0, 0, 0, 0)
        diag_layout.setSpacing(SPACING_SMALL)

        self._diag_explain = QLabel("", self._diag_box)
        self._diag_explain.setObjectName("RunStatusExplain")
        self._diag_explain.setWordWrap(True)
        self._diag_explain.setProperty("tone", "muted")
        self._diag_explain.setTextInteractionFlags(Qt.TextSelectableByMouse)
        diag_layout.addWidget(self._diag_explain)

        self._chip_row = QWidget(self._diag_box)
        self._chip_row.setObjectName("RunStatusChipRow")
        self._chip_layout = FlowLayout(self._chip_row, hspacing=8, vspacing=6)
        self._chips: list[QLabel] = []
        diag_layout.addWidget(self._chip_row)
        details_layout.addWidget(self._diag_box)

        # --- Raw diagnostics ----------------------------------------------------
        self._raw_toggle = QToolButton(self._details)
        self._raw_toggle.setObjectName("RunStatusRawToggle")
        self._raw_toggle.setCheckable(True)
        self._raw_toggle.setChecked(False)
        self._raw_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._raw_toggle.clicked.connect(self._toggle_raw)
        details_layout.addWidget(self._raw_toggle)

        self._raw_box = QFrame(self._details)
        self._raw_box.setObjectName("RunStatusRawBox")
        raw_layout = QVBoxLayout(self._raw_box)
        raw_layout.setContentsMargins(8, 8, 8, 8)
        raw_layout.setSpacing(SPACING_SMALL)
        raw_title = QLabel("Raw diagnostics (schema-level, not user-facing)", self._raw_box)
        raw_title.setProperty("tone", "muted")
        raw_layout.addWidget(raw_title)
        self._raw_text = QPlainTextEdit(self._raw_box)
        self._raw_text.setReadOnly(True)
        self._raw_text.setFont(monospace_font())
        self._raw_text.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._raw_text.setFixedHeight(160)
        self._raw_text.setStyleSheet(
            "background-color: palette(base); border: 1px solid palette(mid); color: palette(window-text);"
        )
        raw_layout.addWidget(self._raw_text)
        self._raw_box.setStyleSheet("QFrame#RunStatusRawBox { border: 1px solid palette(mid); border-radius: 6px; }")
        details_layout.addWidget(self._raw_box)

        root.addWidget(self._details)

        self._bar.setStyleSheet(
            "QFrame#RunStatusBar {"
            "  background: palette(base);"
            "  border-bottom: 1px solid palette(mid);"
            "}"
        )

        self._toggle_details()
        self._toggle_decision()
        self._toggle_diag()
        self._toggle_raw()

        if self._session is not None:
            try:
                self._session.stateChanged.connect(self._on_state_changed)
            except Exception:
                pass
        if self._rail_store is not None:
            self._rail_store.graphChanged.connect(lambda *_args: self._refresh())
            self._rail_store.segmentStatusChanged.connect(lambda *_args: self._refresh())
            self._rail_store.chainProgressChanged.connect(lambda *_args: self._refresh())

        self._refresh()

    def set_evs(self, evs: Mapping[str, Any] | None) -> None:
        self._evs = evs
        if evs is not None:
            self._run_model = None
        self._refresh()

    def set_run_model(self, run: RunModel | None) -> None:
        self._run_model = run
        self._refresh()

    def _on_state_changed(self, state: ExperimentState) -> None:
        self._state = state
        self._refresh()

    def _toggle_details(self) -> None:
        expanded = bool(self._toggle.isChecked())
        self._details.setVisible(expanded)
        self._toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._toggle.setText("Details")
        if expanded:
            self._apply_context_aware_details()

    def _apply_context_aware_details(self) -> None:
        """
        When expanding Details, guide the user to the highest-severity section.

        Priority: blockers (rail) > diagnostics (integrity/evidence) > raw.
        """
        graph = self._last_rail_graph
        diag = self._last_diag

        blockers = 0
        any_error = False
        if graph is not None:
            segments = list(graph.ordered_segments())
            blockers = len([s for s in segments if s.cache_state is not CacheState.CLEAN])
            any_error = any(s.cache_state is CacheState.ERROR for s in segments)

        diag_issue = False
        if diag is not None:
            if diag.integrity_failures or diag.integrity_warnings:
                diag_issue = True
            if diag.evidence is not None and bool(getattr(diag.evidence, "missing", 0) or 0):
                diag_issue = True
            if diag.mass is not None and bool(getattr(diag.mass, "violated", False)):
                diag_issue = True
            sev, _label = self._status_severity(diag.stability_status)
            if sev in {"warn", "danger"}:
                diag_issue = True
            sev, _label = self._status_severity(diag.off_target_status)
            if sev in {"warn", "danger"}:
                diag_issue = True
            if diag.schema_issues is not None and bool(getattr(diag.schema_issues, "rows_with_issues", 0) or 0):
                diag_issue = True

        readiness_blocked = any(r.get("severity") == "danger" for r in (self._last_readiness_blockers or []))
        if blockers or any_error or readiness_blocked:
            self._decision_toggle.setChecked(True)
            self._diag_toggle.setChecked(False)
            self._raw_toggle.setChecked(False)
            self._toggle_decision()
            self._toggle_diag()
            self._toggle_raw()
            self._decision_toggle.setFocus(Qt.TabFocusReason)
            return

        if diag_issue:
            self._decision_toggle.setChecked(False)
            self._diag_toggle.setChecked(True)
            self._raw_toggle.setChecked(False)
            self._toggle_decision()
            self._toggle_diag()
            self._toggle_raw()
            self._diag_toggle.setFocus(Qt.TabFocusReason)
            return

        # Default: keep the friendly sections open; raw remains collapsed.
        self._decision_toggle.setChecked(True)
        self._diag_toggle.setChecked(True)
        self._raw_toggle.setChecked(False)
        self._toggle_decision()
        self._toggle_diag()
        self._toggle_raw()

    def _toggle_decision(self) -> None:
        expanded = bool(self._decision_toggle.isChecked())
        self._decision_box.setVisible(expanded)
        self._decision_toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._decision_toggle.setText(str(getattr(self, "_decision_toggle_label", "Decision readiness")))

    def _toggle_diag(self) -> None:
        expanded = bool(self._diag_toggle.isChecked())
        self._diag_box.setVisible(expanded)
        self._diag_toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._diag_toggle.setText("Integrity & diagnostics")

    def _toggle_raw(self) -> None:
        expanded = bool(self._raw_toggle.isChecked())
        self._raw_box.setVisible(expanded)
        self._raw_toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._raw_toggle.setText("Raw diagnostics")

    def _resolve_run_model(self) -> RunModel | None:
        run = self._run_model
        if run is not None and isinstance(self._evs, Mapping):
            evs_id = self._evs.get("id") or self._evs.get("run_id")
            if evs_id is not None and str(getattr(run, "run_id", "")) != str(evs_id):
                run = None
        if run is None and self._session is not None:
            run_id = None
            if isinstance(self._evs, Mapping):
                run_id = self._evs.get("id") or self._evs.get("run_id")
            if run_id is None and self._state is not None:
                run_id = self._state.run_id
            if run_id is not None:
                try:
                    run = self._session.get_run_by_id(str(run_id))
                except Exception:
                    run = None
        return run

    def _is_demo_context(self, *, run: RunModel | None) -> bool:
        if run is not None:
            meta = getattr(run, "metadata", None)
            if isinstance(meta, Mapping) and is_demo_from_metadata(meta):
                return True
        for src in (self._evs, getattr(self._state, "config", None) if self._state is not None else None):
            if not isinstance(src, Mapping):
                continue
            cfg = src.get("config") if isinstance(src.get("config"), Mapping) else src
            meta = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else None
            if isinstance(meta, Mapping) and is_demo_from_metadata(meta):
                return True
        return False

    def _run_summary_v2(self, *, run: RunModel | None) -> Mapping[str, Any] | None:
        meta = getattr(run, "metadata", None) if run is not None else None
        if isinstance(meta, Mapping):
            if meta.get("invalid") or meta.get("claims_disabled"):
                return None
            summary = meta.get("run_summary")
            if isinstance(summary, Mapping):
                return summary

        for src in (self._evs, getattr(self._state, "config", None) if self._state is not None else None):
            if not isinstance(src, Mapping):
                continue
            cfg = src.get("config") if isinstance(src.get("config"), Mapping) else src
            meta2 = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else None
            if not isinstance(meta2, Mapping):
                continue
            cand = meta2.get("run_summary")
            if isinstance(cand, Mapping):
                return cand
        return None

    def _decision_label(self, decision: str) -> str:
        mapping = {
            "go": "GO",
            "no_go": "NO GO",
            "insufficient_evidence": "INSUFFICIENT EVIDENCE",
            "redesign_required": "REDESIGN REQUIRED",
        }
        key = str(decision or "").strip().lower()
        return mapping.get(key, str(decision or "").strip().upper() or "—")

    def _format_prob(self, value: Any) -> str:
        if not isinstance(value, (int, float)):
            return "—"
        return f"{float(value):.3f}"

    def _format_ci(self, entry: Mapping[str, Any] | None) -> str:
        if not isinstance(entry, Mapping):
            return "—"
        mean = entry.get("mean")
        lo = entry.get("lower")
        hi = entry.get("upper")
        if not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)):
            return self._format_prob(mean)
        return f"{self._format_prob(mean)} [{float(lo):.3f}, {float(hi):.3f}]"

    def _on_target_engine_from_summary(self, run_summary: Mapping[str, Any] | None) -> Mapping[str, Any] | None:
        if not isinstance(run_summary, Mapping):
            return None
        provenance = run_summary.get("provenance") if isinstance(run_summary.get("provenance"), Mapping) else {}
        assumptions = provenance.get("assumptions") if isinstance(provenance.get("assumptions"), Mapping) else {}
        engine = assumptions.get("on_target_engine") if isinstance(assumptions.get("on_target_engine"), Mapping) else None
        return dict(engine) if isinstance(engine, Mapping) else None

    def _format_on_target_tooltip(self, on_target: Mapping[str, Any]) -> str:
        engine_id = str(on_target.get("engine_id") or "--")
        engine_version = str(on_target.get("engine_version") or "--")
        model_hash = str(on_target.get("model_hash") or "--")
        p_edit = self._format_prob(on_target.get("p_edit"))
        novelty = self._format_prob(on_target.get("novelty"))
        ood = bool(on_target.get("ood")) if "ood" in on_target else None
        parts = [
            f"Engine: {engine_id}",
            f"Version: {engine_version}",
            f"Model: {model_hash}",
            f"p_edit: {p_edit}",
            f"novelty: {novelty}",
            f"ood: {ood if ood is not None else 'unknown'}",
        ]
        features = on_target.get("features") if isinstance(on_target.get("features"), Mapping) else {}
        mode = str(features.get("mode") or "").strip()
        reason = str(features.get("reason") or "").strip()
        if mode:
            parts.append(f"mode: {mode}")
        if reason:
            parts.append(f"reason: {reason}")
        return "\n".join(parts)

    def _rail_summary(self, graph: RailGraph | None) -> tuple[str, str]:
        if graph is None:
            return "unavailable", ""
        segments = list(graph.ordered_segments())
        counts = {
            CacheState.CLEAN: 0,
            CacheState.DIRTY: 0,
            CacheState.COMPUTING: 0,
            CacheState.UNSUPPORTED: 0,
            CacheState.ERROR: 0,
        }
        for seg in segments:
            try:
                counts[seg.cache_state] += 1
            except Exception:
                pass

        non_clean = len([s for s in segments if s.cache_state is not CacheState.CLEAN])
        if non_clean == 0:
            summary = "ready"
        else:
            summary = f"{non_clean} blocker" + ("s" if non_clean != 1 else "")
            parts: list[str] = []
            if counts[CacheState.UNSUPPORTED]:
                parts.append(f"{counts[CacheState.UNSUPPORTED]} unsupported")
            if parts:
                summary = summary + " · " + " · ".join(parts)

        tip_lines: list[str] = []
        for seg in segments:
            if seg.cache_state is CacheState.CLEAN:
                continue
            tip_lines.append(f"{seg.name}: {seg.cache_state.value}")
            try:
                meta = seg.metadata if isinstance(seg.metadata, dict) else dict(seg.metadata or {})
                reason = meta.get("ui_reason")
                if isinstance(reason, str) and reason.strip():
                    tip_lines.append(f"  {reason.strip()}")
            except Exception:
                pass
        return summary, "\n".join(tip_lines).strip()

    def _format_integrity_summary(self, diag: SimulationDiagnostics | None) -> str:
        if diag is None:
            return "integrity --"
        if diag.integrity_failures:
            return f"integrity FAIL ({len(diag.integrity_failures)})"
        if diag.integrity_warnings:
            return f"integrity WARN ({len(diag.integrity_warnings)})"
        return "integrity ok"

    def _format_evidence_summary(self, diag: SimulationDiagnostics | None) -> str:
        if diag is None or diag.evidence is None:
            return "evidence --"
        missing = int(getattr(diag.evidence, "missing", 0) or 0)
        if missing:
            return f"evidence missing {missing}"
        return "evidence ok"

    def _set_summary_pills(self, specs: list[tuple[str, str, str]]) -> None:
        for pill in self._summary_pills:
            try:
                pill.hide()
            except Exception:
                pass
            pill.setParent(None)
            pill.deleteLater()
        self._summary_pills.clear()
        for text, severity, tooltip in specs:
            pill = QLabel(str(text), self._summary_container)
            pill.setTextFormat(Qt.PlainText)
            pill.setToolTip(str(tooltip or ""))
            pill.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self._apply_pill_style(pill, severity)
            self._summary_layout.addWidget(pill)
            self._summary_pills.append(pill)
        self._summary_container.setVisible(bool(specs))

    def _build_chip_specs(
        self, diag: SimulationDiagnostics, *, run_summary: Mapping[str, Any] | None
    ) -> list[tuple[str, str, str, str]]:
        specs: list[tuple[str, str, str, str]] = []
        if diag.integrity_failures:
            specs.append(("Integrity", f"FAIL ({len(diag.integrity_failures)})", "danger", self._format_integrity(diag)))
        elif diag.integrity_warnings:
            specs.append(("Integrity", f"WARN ({len(diag.integrity_warnings)})", "warn", self._format_integrity(diag)))
        else:
            specs.append(("Integrity", "ok", "ok", self._format_integrity(diag)))

        sev, label = self._status_severity(diag.stability_status)
        specs.append(("Stability", label, sev, self._format_status(diag.stability_status, diag.stability_reason)))

        sev, label = self._status_severity(diag.off_target_status)
        specs.append(("Off-target", label, sev, self._format_status(diag.off_target_status, diag.off_target_reason)))

        if diag.mass is None:
            specs.append(("Mass audit", "--", "muted", "unavailable"))
        else:
            status = "FAIL" if diag.mass.violated else "OK"
            sev = "danger" if diag.mass.violated else "ok"
            specs.append(("Mass audit", status, sev, self._format_mass(diag)))

        if diag.evidence is None:
            specs.append(("Evidence", "--", "muted", "unavailable"))
        elif diag.evidence.missing:
            specs.append(("Evidence", f"missing {diag.evidence.missing}", "danger", self._format_evidence(diag)))
        else:
            specs.append(("Evidence", "ok", "ok", self._format_evidence(diag)))

        on_target = self._on_target_engine_from_summary(run_summary)
        if on_target is None:
            specs.append(("On-target", "--", "muted", "unavailable"))
        else:
            ood = bool(on_target.get("ood")) if "ood" in on_target else False
            novelty = on_target.get("novelty")
            is_high_novelty = "on_target_high_novelty" in (diag.integrity_warnings or ())
            if not is_high_novelty and isinstance(novelty, (int, float)):
                threshold_raw = os.environ.get("HELIX_ON_TARGET_NOVELTY_VALIDATION_THRESHOLD")
                try:
                    threshold = float(threshold_raw) if threshold_raw is not None else 0.8
                except Exception:
                    threshold = 0.8
                is_high_novelty = float(novelty) >= max(0.0, min(1.0, threshold))

            if ood:
                specs.append(("On-target", "OOD", "danger", self._format_on_target_tooltip(on_target)))
            elif is_high_novelty:
                specs.append(("On-target", "novelty high", "warn", self._format_on_target_tooltip(on_target)))
            else:
                specs.append(("On-target", "ok", "ok", self._format_on_target_tooltip(on_target)))

        return specs

    def _set_chip_specs(self, specs: list[tuple[str, str, str, str]]) -> None:
        for chip in self._chips:
            try:
                chip.hide()
            except Exception:
                pass
            chip.setParent(None)
            chip.deleteLater()
        self._chips.clear()
        for label, value, severity, tooltip in specs:
            chip = QLabel(f"{label}: {value}", self._chip_row)
            chip.setTextFormat(Qt.PlainText)
            chip.setToolTip(tooltip)
            self._apply_chip_style(chip, severity)
            self._chip_layout.addWidget(chip)
            self._chips.append(chip)
        self._chip_row.setVisible(bool(specs))

    def _apply_chip_style(self, chip: QLabel, severity: str) -> None:
        base = "padding:4px 10px; border-radius:10px; font-size:11px;"
        if severity == "muted":
            chip.setStyleSheet(
                base + "background-color: palette(base); border: 1px solid palette(mid); color: palette(mid);"
            )
            return
        color = {
            "ok": SUCCESS,
            "warn": CAUTION,
            "danger": HX_DANGER,
        }.get(severity, SUCCESS)
        tone = QColor(color)
        bg = QColor(tone)
        bg.setAlphaF(0.22)
        border = QColor(tone)
        border.setAlphaF(0.60)
        chip.setStyleSheet(
            base
            + f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; "
            "color: palette(window-text);"
        )

    def _apply_pill_style(self, pill: QLabel, severity: str) -> None:
        # Slightly tighter than the detail chips; used in the always-visible summary row.
        base = "padding:3px 10px; border-radius:10px; font-size:11px;"
        if severity == "muted":
            pill.setStyleSheet(
                base + "background-color: palette(base); border: 1px solid palette(mid); color: palette(mid);"
            )
            return
        color = {
            "ok": SUCCESS,
            "warn": CAUTION,
            "danger": HX_DANGER,
        }.get(severity, SUCCESS)
        tone = QColor(color)
        bg = QColor(tone)
        bg.setAlphaF(0.22)
        border = QColor(tone)
        border.setAlphaF(0.60)
        pill.setStyleSheet(
            base
            + f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; "
            "color: palette(window-text);"
        )

    def _status_severity(self, status: str | None) -> tuple[str, str]:
        if not status:
            return "muted", "--"
        text = str(status).strip()
        lowered = text.lower()
        if lowered in {"ok", "pass", "stable", "good", "nominal"}:
            return "ok", text
        if lowered in {"unknown", "not reported", "n/a"}:
            return "muted", "--"
        if "warn" in lowered or "limit" in lowered or "partial" in lowered:
            return "warn", text
        return "danger", text

    def _format_status(self, status: str | None, reason: str | None) -> str:
        if not status:
            return "not reported"
        if reason:
            return f"{status} ({reason})"
        return status

    def _format_integrity(self, diag: SimulationDiagnostics) -> str:
        failures = ", ".join(diag.integrity_failures) if diag.integrity_failures else "none"
        warnings = ", ".join(diag.integrity_warnings) if diag.integrity_warnings else "none"
        return f"failures: {failures} | warnings: {warnings}"

    def _format_mass(self, diag: SimulationDiagnostics) -> str:
        mass = diag.mass
        if mass is None:
            return "unavailable"
        status = "FAIL" if mass.violated else "OK"
        return (
            f"root total {mass.root_total:.4f} | suppressed {mass.root_suppressed:.4f} | "
            f"unaccounted {mass.root_unaccounted:.4f} | eps {mass.epsilon:.3g} | "
            f"max dev {mass.max_violation:.4f} | {status}"
        )

    def _format_evidence(self, diag: SimulationDiagnostics) -> str:
        ev = diag.evidence
        if ev is None:
            return "unavailable"
        return f"support {ev.support} | conflict {ev.conflict} | missing {ev.missing}"

    def _build_explain_line(self, diag: SimulationDiagnostics) -> str:
        headline = diag.verdict_headline or "Diagnostics ready."
        details: list[str] = []
        if diag.integrity_failures:
            details.append("Integrity failures: " + ", ".join(diag.integrity_failures))
        elif diag.integrity_warnings:
            details.append("Integrity warnings: " + ", ".join(diag.integrity_warnings))
        if diag.evidence and diag.evidence.missing:
            details.append(f"Evidence missing {diag.evidence.missing}.")
        if diag.mass and diag.mass.violated:
            details.append("Mass audit failed.")
        if diag.schema_issues and diag.schema_issues.rows_with_issues:
            details.append(f"Schema issues in {diag.schema_issues.rows_with_issues} rows.")
        if not details:
            return headline
        return f"{headline}  " + " ".join(details)

    def _build_raw_text(self, diag: SimulationDiagnostics) -> str:
        lines: list[str] = []
        run_text = diag.run_label or "--"
        if diag.run_id:
            run_text = f"{run_text} (id {diag.run_id})"
        lines.append(f"Run: {run_text}")
        engine = diag.engine or "--"
        if diag.backend:
            engine = f"{engine} ({diag.backend})"
        lines.append(f"Engine: {engine}")
        policy = diag.policy_hash or "--"
        semantic = diag.semantic_hash or "--"
        determinism = diag.determinism_class or "--"
        lines.append(f"Contract: policy {policy} | semantic {semantic} | determinism {determinism}")
        decision_mode = diag.decision_mode or "--"
        lines.append(f"Decision mode: {decision_mode}")
        lines.append(f"Verdict: {diag.verdict_grade or '--'} | {diag.verdict_headline or ''}".strip())
        lines.append(f"Policy compliant: {diag.policy_compliant if diag.policy_compliant is not None else 'unknown'}")
        if diag.noncompliance_reasons:
            lines.append("Noncompliance reasons: " + ", ".join(diag.noncompliance_reasons))
        lines.append(f"Integrity: {self._format_integrity(diag)}")
        lines.append(f"Stability: {self._format_status(diag.stability_status, diag.stability_reason)}")
        lines.append(f"Off-target: {self._format_status(diag.off_target_status, diag.off_target_reason)}")
        lines.append(f"Mass audit: {self._format_mass(diag)}")
        lines.append(f"Evidence: {self._format_evidence(diag)}")
        return "\n".join(lines)

    def _refresh(self) -> None:
        run = self._resolve_run_model()
        run_summary = self._run_summary_v2(run=run)
        diag = build_simulation_diagnostics(
            evs=self._evs,
            state=self._state,
            run=run,
            project_root=self._project_root,
        )
        graph = getattr(self._rail_store, "graph", None) if self._rail_store is not None else None
        is_demo = self._is_demo_context(run=run)
        self._last_diag = diag
        self._last_rail_graph = graph
        self._last_readiness_blockers = decision_grade_blocked_reasons(run_summary) if isinstance(run_summary, Mapping) else []

        summary_specs: list[tuple[str, str, str]] = []
        if diag is None:
            if graph is None:
                summary_specs.append(("No run loaded", "muted", ""))
            else:
                segments = list(graph.ordered_segments())
                blockers_count = len([s for s in segments if s.cache_state is not CacheState.CLEAN])
                unsupported_count = len([s for s in segments if s.cache_state is CacheState.UNSUPPORTED])
                any_error = any(s.cache_state is CacheState.ERROR for s in segments)
                rail_tip = self._rail_summary(graph)[1]
                summary_specs.append(("No run loaded", "muted", ""))
                sev = "danger" if any_error else ("warn" if blockers_count else "ok")
                summary_specs.append((f"Blockers: {blockers_count}", sev, rail_tip))
                if unsupported_count:
                    summary_specs.append((f"Unsupported: {unsupported_count}", "warn", rail_tip))
            self._set_summary_pills(summary_specs)
            self._diag_explain.setText("No run loaded.")
            self._diag_explain.setVisible(True)
            self._set_chip_specs([])
            self._raw_text.setPlainText("")
            self._decision_meta.setVisible(False)
            self._decision_output.setText("")
            self._decision_output.setVisible(False)
            self._uncertainty_row.setText("")
            self._on_target_row.setText("")
            self._on_target_row.setVisible(False)
            self._recommendations.setText("")
            self._recommendations.setVisible(False)
            self._blocked_reasons.setText("")
            self._blocked_reasons.setVisible(False)
            return

        decision_mode = getattr(diag, "decision_mode", None) or "filter_only"
        label = ui_mode_label(decision_mode=str(decision_mode), is_demo=bool(is_demo))
        mode_sev = "ok" if str(decision_mode) == "decision_grade" else ("danger" if is_demo else "warn")
        summary_specs.append((label, mode_sev, ui_mode_subtext(decision_mode=str(decision_mode)) or ""))

        if str(decision_mode) == "decision_grade" and isinstance(run_summary, Mapping):
            verdict = run_summary.get("verdict") if isinstance(run_summary.get("verdict"), Mapping) else {}
            decision = self._decision_label(str(verdict.get("decision") or ""))
            grade = str(verdict.get("grade") or "").strip().upper()
            headline = str(verdict.get("headline") or "").strip()
            tooltip_parts = [p for p in [grade, headline] if p]
            tooltip = " — ".join(tooltip_parts)
            sev = "ok" if decision == "GO" else ("danger" if decision == "NO GO" else "warn")
            summary_specs.append((f"Decision: {decision}", sev, tooltip))

        rail_summary, rail_tip = self._rail_summary(graph)
        blockers_count = 0
        unsupported_count = 0
        any_error = False
        if graph is not None:
            segments = list(graph.ordered_segments())
            blockers_count = len([s for s in segments if s.cache_state is not CacheState.CLEAN])
            unsupported_count = len([s for s in segments if s.cache_state is CacheState.UNSUPPORTED])
            any_error = any(s.cache_state is CacheState.ERROR for s in segments)
        rail_sev = "danger" if any_error else ("warn" if blockers_count else "ok")
        summary_specs.append((f"Blockers: {blockers_count}", rail_sev, rail_tip))
        if unsupported_count:
            summary_specs.append((f"Unsupported: {unsupported_count}", "warn", rail_tip))

        if diag.integrity_failures:
            summary_specs.append(
                (f"Integrity: FAIL ({len(diag.integrity_failures)})", "danger", self._format_integrity(diag))
            )
        elif diag.integrity_warnings:
            summary_specs.append(
                (f"Integrity: WARN ({len(diag.integrity_warnings)})", "warn", self._format_integrity(diag))
            )
        else:
            summary_specs.append(("Integrity: ok", "ok", self._format_integrity(diag)))

        if diag.evidence is None:
            summary_specs.append(("Evidence: --", "muted", "unavailable"))
        elif diag.evidence.missing:
            summary_specs.append(
                (f"Evidence: missing {diag.evidence.missing}", "danger", self._format_evidence(diag))
            )
        else:
            summary_specs.append(("Evidence: ok", "ok", self._format_evidence(diag)))

        self._set_summary_pills(summary_specs)

        # --- Decision-grade UX: recommendation + uncertainty -------------------
        verdict = run_summary.get("verdict") if isinstance(run_summary, Mapping) and isinstance(run_summary.get("verdict"), Mapping) else {}
        decision = str(verdict.get("decision") or "").strip()
        grade = str(verdict.get("grade") or "").strip().upper()
        headline = str(verdict.get("headline") or "").strip()

        self._decision_meta.setVisible(True)
        on_target_engine = self._on_target_engine_from_summary(run_summary)
        if on_target_engine is None:
            self._on_target_row.setText("")
            self._on_target_row.setToolTip("")
            self._on_target_row.setVisible(False)
        else:
            p_edit = self._format_prob(on_target_engine.get("p_edit"))
            novelty = self._format_prob(on_target_engine.get("novelty"))
            ood = bool(on_target_engine.get("ood")) if "ood" in on_target_engine else False
            status = "OOD" if ood else "in-domain"
            engine_id = str(on_target_engine.get("engine_id") or "--")
            engine_version = str(on_target_engine.get("engine_version") or "--")
            model_hash = str(on_target_engine.get("model_hash") or "--")
            text = f"On-target: p_edit {p_edit} · novelty {novelty} · {status}\nEngine: {engine_id} · {engine_version} · {model_hash}"
            features = (
                on_target_engine.get("features") if isinstance(on_target_engine.get("features"), Mapping) else {}
            )
            mode = str(features.get("mode") or "").strip()
            if mode == "encoding_only":
                text = text + "\nUntrusted: encoding-only mode (no validated model bundle loaded)."
            elif ood:
                text = text + "\nUntrusted: out-of-domain per model threshold; validate at the primary locus."
            self._on_target_row.setText(text)
            self._on_target_row.setToolTip(self._format_on_target_tooltip(on_target_engine))
            self._on_target_row.setVisible(True)
        if str(decision_mode) == "decision_grade":
            self._decision_output.setVisible(True)
            parts = []
            if decision:
                parts.append(f"Decision: {self._decision_label(decision)}")
            if grade:
                parts.append(f"Grade: {grade}")
            if headline:
                parts.append(headline)
            self._decision_output.setText(" · ".join(parts) if parts else "Decision: —")

            recs = run_summary.get("recommendations") if isinstance(run_summary, Mapping) and isinstance(run_summary.get("recommendations"), list) else []
            if recs:
                lines: list[str] = ["Recommendations:"]
                for rec in recs:
                    if not isinstance(rec, Mapping):
                        continue
                    title = str(rec.get("title") or "").strip()
                    suggestion = str(rec.get("suggestion") or "").strip()
                    if title and suggestion:
                        lines.append(f"• {title}: {suggestion}")
                    elif title:
                        lines.append(f"• {title}")
                    elif suggestion:
                        lines.append(f"• {suggestion}")
                self._recommendations.setText("\n".join(lines) if len(lines) > 1 else "Recommendations: none")
            else:
                self._recommendations.setText("Recommendations: none")
            self._recommendations.setVisible(True)

            unc = run_summary.get("uncertainty") if isinstance(run_summary, Mapping) and isinstance(run_summary.get("uncertainty"), Mapping) else {}
            cis = unc.get("credible_intervals") if isinstance(unc.get("credible_intervals"), Mapping) else {}
            lvl = None
            try:
                lvl = float(unc.get("level")) if isinstance(unc.get("level"), (int, float)) else None
            except Exception:
                lvl = None
            pct = int(round((lvl or 0.95) * 100))
            lines = [f"Uncertainty ({pct}% credible intervals):"]
            lines.append(f"Intended functional p: {self._format_ci(cis.get('control.intended_functional_p'))}")
            lines.append(f"No cut p: {self._format_ci(cis.get('control.no_cut_p'))}")
            top_entry = cis.get("outcomes.top_p")
            top_label = ""
            if isinstance(top_entry, Mapping):
                top_outcome_label = str(top_entry.get("outcome_label") or "").strip()
                if top_outcome_label:
                    top_label = f" ({top_outcome_label})"
            lines.append(f"Top outcome p{top_label}: {self._format_ci(top_entry if isinstance(top_entry, Mapping) else None)}")
            self._uncertainty_row.setText("\n".join(lines))
        else:
            self._decision_output.setText("")
            self._decision_output.setVisible(False)
            self._recommendations.setText("")
            self._recommendations.setVisible(False)

            unc = run_summary.get("uncertainty") if isinstance(run_summary, Mapping) and isinstance(run_summary.get("uncertainty"), Mapping) else {}
            status = str(unc.get("status") or "not_computed")
            reason = str(unc.get("reason") or "").strip()
            msg = "Uncertainty: not computed or suppressed."
            if status == "computed":
                msg = "Uncertainty: suppressed (filter-only)."
            elif reason:
                msg = msg + f"  Reason: {reason}"
            self._uncertainty_row.setText(msg)

        reasons = self._last_readiness_blockers
        if reasons:
            lines = ["Blocked because:"]
            for r in reasons:
                severity = str(r.get("severity") or "warn")
                title = str(r.get("title") or "").strip()
                detail = str(r.get("detail") or "").strip()
                fix = str(r.get("fix") or "").strip()
                if not title:
                    continue
                tag = "BLOCKER" if severity == "danger" else "Warning"
                body = f"{title}"
                if detail:
                    body = body + f" — {detail}"
                lines.append(f"• {tag}: {body}")
                if fix:
                    lines.append(f"  Fix: {fix}")
            self._blocked_reasons.setText("\n".join(lines).strip())
            self._blocked_reasons.setVisible(True)
        else:
            self._blocked_reasons.setText("")
            self._blocked_reasons.setVisible(False)

        explain = self._build_explain_line(diag)
        self._diag_explain.setText(explain)
        self._diag_explain.setVisible(bool(explain.strip()))
        self._set_chip_specs(self._build_chip_specs(diag, run_summary=run_summary))
        self._raw_text.setPlainText(self._build_raw_text(diag))

        # Update section headers with lightweight summaries.
        self._decision_toggle.setToolTip(rail_tip)
        self._decision_toggle_label = "Decision readiness" + (f" ({rail_summary})" if rail_summary else "")
        self._decision_toggle.setText(self._decision_toggle_label)


__all__ = ["RunStatusPanel"]
