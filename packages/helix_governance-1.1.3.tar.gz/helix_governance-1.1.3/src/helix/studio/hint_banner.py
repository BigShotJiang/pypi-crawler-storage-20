from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton


class HintBanner(QFrame):
    closed = Signal()

    def __init__(self, text: str, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("HintBanner")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(8)
        self._label = QLabel(text, self)
        self._label.setWordWrap(True)
        layout.addWidget(self._label)
        layout.addStretch(1)
        btn = QPushButton("✕", self)
        btn.setFixedSize(22, 22)
        btn.setObjectName("SecondaryButton")
        btn.clicked.connect(self._on_close)
        layout.addWidget(btn)

    def _on_close(self) -> None:
        self.hide()
        self.closed.emit()

    def set_text(self, text: str) -> None:
        self._label.setText(text)
