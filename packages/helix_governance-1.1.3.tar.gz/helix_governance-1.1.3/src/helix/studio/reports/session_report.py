from __future__ import annotations

import base64
import html
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_summary,
    governance_stamp_lines,
    interpretation_for_mode,
    export_watermark_label,
)
from helix.studio.export_labels import build_governance_provenance, is_demo_from_metadata
from helix.studio.export_provenance import build_export_provenance_v1, export_provenance_sha256
from helix.studio.provenance_header import build_provenance_header_v1
from helix.studio.repair_pathways import (
    PATHWAY_ORDER,
    PATHWAY_UI_LABEL,
    build_repair_pathway_mixture,
    build_stochastic_narrative_v1,
)


def _b64_png(data: bytes) -> str:
    return "data:image/png;base64," + base64.b64encode(data).decode("ascii")


def _esc(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _fmt_pct(value: Any, *, decimals: int = 1) -> str:
    try:
        x = float(value)
    except Exception:
        return "—"
    return f"{x*100:.{int(decimals)}f}%"


def _fmt_float(value: Any, *, decimals: int = 2, suffix: str = "") -> str:
    try:
        x = float(value)
    except Exception:
        return "—"
    return f"{x:.{int(decimals)}f}{suffix}"


def _build_repair_pathway_block_html(
    *,
    outcomes: Sequence[Mapping[str, Any]],
    quantitative_allowed: bool,
) -> str:
    if not outcomes:
        return "<p>No repair pathway data available.</p>"

    present: list[str] = []
    seen: set[str] = set()
    for oc in outcomes:
        pid = str(oc.get("pathway") or "").strip().lower()
        if not pid or pid in seen:
            continue
        seen.add(pid)
        present.append(pid)
    if not present:
        return "<p>No repair pathway data available.</p>"

    present = [p for p in PATHWAY_ORDER if p in seen] + [p for p in present if p not in PATHWAY_ORDER]

    if not quantitative_allowed:
        labels = ", ".join(_esc(PATHWAY_UI_LABEL.get(pid, pid)) for pid in present)
        return (
            "<h3>Repair pathway mixture (derived)</h3>"
            "<p>Non-decision-grade export: probability mass is suppressed.</p>"
            f"<p><b>Pathways present:</b> {labels}</p>"
        )

    # Decision-grade: show a full mixture decomposition + narrative.
    try:
        mixture = build_repair_pathway_mixture(outcomes, label_key="name", category_key="category", probability_key="prob")
    except Exception:
        mixture = ()
    if not mixture:
        return "<p>No repair pathway data available.</p>"

    li = []
    for pid in PATHWAY_ORDER:
        comp = next((p for p in mixture if str(getattr(p, "pathway", "")) == pid), None)
        if comp is None:
            continue
        try:
            mass = float(getattr(comp, "probability_mass", 0.0) or 0.0)
        except Exception:
            mass = 0.0
        if mass <= 0.0:
            continue
        li.append(f"<li><b>{_esc(PATHWAY_UI_LABEL.get(pid, pid))}</b>: {_fmt_pct(mass, decimals=1)}</li>")

    narrative = build_stochastic_narrative_v1(mixture)
    step_lines: list[str] = []
    try:
        steps = narrative.get("steps") if isinstance(narrative, Mapping) else None
        if isinstance(steps, list) and steps:
            cleavage = steps[0] if isinstance(steps[0], Mapping) else {}
            pc = cleavage.get("Pc")
            pnc = cleavage.get("P_no_cut")
            step_lines.append(f"Step 1: cleavage with Pc={_fmt_pct(pc)}; no-cut with {_fmt_pct(pnc)}")
            choice = steps[1] if len(steps) > 1 and isinstance(steps[1], Mapping) else {}
            dist = choice.get("P_pathway_given_cut") if isinstance(choice.get("P_pathway_given_cut"), Mapping) else {}
            if dist:
                parts = [f"{PATHWAY_UI_LABEL.get(k, k)}={_fmt_pct(v)}" for k, v in dist.items()]
                step_lines.append("Step 2: pathway choice given cut: " + ", ".join(parts))
            step_lines.append("Step 3: outcome sampled from P(outcome | pathway)")
    except Exception:
        step_lines = []

    narrative_block = ""
    if step_lines:
        narrative_block = "<pre>" + _esc("\n".join(step_lines)) + "</pre>"

    return (
        "<h3>Repair pathway mixture (derived)</h3>"
        "<p><b>Mixture identity:</b> P(outcome) = Σ P(pathway) × P(outcome | pathway)</p>"
        "<ul>"
        + "".join(li)
        + "</ul>"
        + narrative_block
        + "<p><i>Note:</i> pathway assignment is derived from labeled outcomes and conservative heuristics unless the simulator explicitly emits pathways.</p>"
    )


def _build_verdict_card_html(contract_v2: Mapping[str, Any]) -> str:
    if not contract_v2:
        return ""

    def _decision_label(value: Any) -> str:
        mapping = {
            "go": "Go",
            "no_go": "No Go",
            "insufficient_evidence": "Insufficient evidence",
            "redesign_required": "Redesign required",
        }
        key = str(value or "").strip().lower()
        return mapping.get(key, key or "Insufficient evidence")

    decision_mode = str(contract_v2.get("decision_mode") or "filter_only").strip().lower()
    if decision_mode not in {"filter_only", "decision_grade"}:
        decision_mode = "filter_only"
    quantitative_allowed = decision_mode == "decision_grade"

    verdict = contract_v2.get("verdict") if isinstance(contract_v2.get("verdict"), Mapping) else {}
    control = contract_v2.get("control") if isinstance(contract_v2.get("control"), Mapping) else {}
    risk = contract_v2.get("risk") if isinstance(contract_v2.get("risk"), Mapping) else {}
    tail = risk.get("tail") if isinstance(risk.get("tail"), Mapping) else {}
    uncertainty = contract_v2.get("uncertainty") if isinstance(contract_v2.get("uncertainty"), Mapping) else {}
    provenance = contract_v2.get("provenance") if isinstance(contract_v2.get("provenance"), Mapping) else {}
    intended_spec = contract_v2.get("intended_edit_spec") if isinstance(contract_v2.get("intended_edit_spec"), Mapping) else {}

    grade = str(verdict.get("grade") or "—")
    headline = str(verdict.get("headline") or "—")
    policy_id = str(contract_v2.get("policy_id") or "—")
    decision_txt = _decision_label(verdict.get("decision"))
    compliant = verdict.get("compliant_with_policy")
    compliant_txt = "—"
    if isinstance(compliant, bool):
        compliant_txt = "Compliant" if compliant else "Noncompliant"

    stability = control.get("stability") if isinstance(control.get("stability"), Mapping) else {}
    stability_status = str(stability.get("status") or "")
    stab_assum = stability.get("assumptions") if isinstance(stability.get("assumptions"), Mapping) else {}
    assumptions_hash = str(stab_assum.get("assumptions_hash") or "—")

    conv = control.get("convergence") if isinstance(control.get("convergence"), Mapping) else {}
    conv_status = str(conv.get("status") or "")

    hazard = risk.get("hazard") if isinstance(risk.get("hazard"), Mapping) else {}
    hazard_status = str(hazard.get("status") or "")

    off_target = risk.get("off_target") if isinstance(risk.get("off_target"), Mapping) else {}
    offt_status = str(off_target.get("status") or "")

    tail_p99 = tail.get("global_p99_del_bp")
    tail_cvar99 = tail.get("global_cvar99_del_bp")
    tail_txt = "—"
    if tail_p99 is not None and tail_cvar99 is not None:
        tail_txt = f"p99 {float(tail_p99):.0f} bp · cvar99 {float(tail_cvar99):.0f} bp"
    if not quantitative_allowed:
        tail_txt = "suppressed"

    escape_txt = "—"
    if conv_status == "computed":
        if not quantitative_allowed:
            escape_txt = "suppressed"
        else:
            escape_txt = f"{_fmt_pct(conv.get('escape_risk'), decimals=2)} · worst uncut@20 {_fmt_pct(conv.get('escape_worst_case_uncut_p_gen20'), decimals=1)}"
    elif conv_status == "not_computed":
        escape_txt = f"Not computed · {str(conv.get('reason') or '—')}"

    stab_txt = "—"
    if stability_status == "computed":
        if not quantitative_allowed:
            stab_txt = f"{str(stability.get('interpretation') or '').title()} · suppressed"
        else:
            stab_txt = f"{str(stability.get('interpretation') or '').title()} · score {_fmt_float(stability.get('stability_score'), decimals=2)}"
    elif stability_status == "not_computed":
        stab_txt = f"Not computed · {str(stability.get('reason') or '—')}"

    splice_txt = "—"
    if hazard_status == "computed":
        splice_txt = "suppressed" if not quantitative_allowed else f"Donor {_fmt_pct(hazard.get('p_hits_splice_donor'), decimals=3)} · Acc {_fmt_pct(hazard.get('p_hits_splice_acceptor'), decimals=3)}"
    elif hazard_status == "not_computed":
        splice_txt = f"Not computed · {str(hazard.get('reason') or '—')}"

    offt_txt = "—"
    if offt_status == "computed":
        if not quantitative_allowed:
            offt_txt = str(off_target.get("mode") or "computed") + " · suppressed"
        else:
            mode = str(off_target.get("mode") or "")
            worst = off_target.get("worst_site_score")
            offt_txt = f"{mode or 'computed'} · worst {_fmt_float(worst, decimals=3)}"
    elif offt_status == "not_computed":
        offt_txt = f"Not computed · {str(off_target.get('reason') or '—')}"

    def _intended_short(spec: Mapping[str, Any]) -> str:
        if not spec:
            return "edit: not specified"
        edit_class = str(spec.get("edit_class") or "unknown")
        target = spec.get("target") if isinstance(spec.get("target"), Mapping) else {}
        chrom = str(target.get("chrom") or "unknown")
        start = target.get("start")
        end = target.get("end")
        locus = chrom
        if isinstance(start, int) and isinstance(end, int):
            locus = f"{chrom}:{start}-{end}"
        cut = target.get("cut_site") if isinstance(target.get("cut_site"), Mapping) else {}
        cut_pos = cut.get("pos")
        cut_txt = f"cut@{int(cut_pos)}" if isinstance(cut_pos, int) else "cut@?"
        meas = spec.get("measurement") if isinstance(spec.get("measurement"), Mapping) else {}
        assay = str(meas.get("assay_type") or meas.get("assay_definition_id") or "")
        if not assay:
            assay = "assay=absent"
        return f"{edit_class} · {locus} · {cut_txt} · {assay}"

    def _ci_band(metric_key: str) -> str | None:
        if not quantitative_allowed:
            return None
        if str(uncertainty.get("status") or "") != "computed":
            return None
        cis = uncertainty.get("credible_intervals") if isinstance(uncertainty.get("credible_intervals"), Mapping) else {}
        ci = cis.get(metric_key) if isinstance(cis.get(metric_key), Mapping) else None
        if not isinstance(ci, Mapping):
            return None
        lo = ci.get("lower")
        hi = ci.get("upper")
        level = ci.get("level")
        if not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)):
            return None
        pct = lambda x: f"{float(x) * 100:.1f}%"
        lvl = float(level) if isinstance(level, (int, float)) else 0.95
        return f"{pct(lo)}–{pct(hi)} ({int(round(lvl * 100))}% CI)"

    def _fmt_mode_value(value: Any, *, decimals_pct: int = 1, decimals_score: int = 3) -> str:
        if not quantitative_allowed:
            return "suppressed"
        return _fmt_pct(value, decimals=decimals_pct)

    def _intended_auditability(spec: Mapping[str, Any]) -> tuple[bool, str]:
        if not spec:
            return False, "intended edit spec missing"
        meas = spec.get("measurement") if isinstance(spec.get("measurement"), Mapping) else {}
        m_status = str(meas.get("status") or "").strip().lower()
        if m_status != "declared":
            reason = str(meas.get("reason") or "").strip()
            return False, reason or "assay not declared"
        if not (meas.get("assay_type") or meas.get("assay_definition_id")):
            return False, "assay not declared"
        allele = spec.get("allele") if isinstance(spec.get("allele"), Mapping) else {}
        a_status = str(allele.get("status") or "").strip().lower()
        if a_status in {"", "not_specified", "absent"}:
            reason = str(allele.get("reason") or "").strip()
            return False, reason or "allele definition not specified"
        return True, ""

    intended_ok, intended_reason = _intended_auditability(intended_spec)
    if intended_ok:
        intended_value = _fmt_mode_value(control.get("intended_functional_p"), decimals_pct=1, decimals_score=3)
    else:
        intended_value = "Not auditable" + (f" · {intended_reason}" if intended_reason else "")
    ci_txt = _ci_band("control.intended_functional_p")
    if ci_txt:
        intended_value = intended_value + f" · {ci_txt}"

    unc_status = str(uncertainty.get("status") or "not_computed")
    unc_txt = "Computed" if unc_status == "computed" else "Not computed"
    if unc_status != "computed" and uncertainty.get("reason"):
        unc_txt = unc_txt + f" · {str(uncertainty.get('reason') or '')}"

    chips_2 = [
        ("Intended functional", intended_value),
        ("Intended edit", _intended_short(intended_spec)),
        ("Dominance", "suppressed" if not quantitative_allowed else _fmt_float(control.get("dominance_ratio"), decimals=2)),
        ("Outcome entropy", "suppressed" if not quantitative_allowed else _fmt_float(control.get("entropy_bits"), decimals=2, suffix=" bits")),
        ("No cut", _fmt_mode_value(control.get("no_cut_p"), decimals_pct=1, decimals_score=3)),
        ("Escape risk", escape_txt),
        ("Stability", stab_txt),
        ("Tail risk", tail_txt),
        ("Splice risk", splice_txt),
        ("Off target", offt_txt),
        ("Uncertainty", unc_txt),
    ]

    def chip_row(items: Sequence[tuple[str, str]]) -> str:
        parts = [f'<span class="chip"><b>{_esc(k)}</b>: {_esc(v)}</span>' for k, v in items]
        return '<div class="chip-row">' + "\n".join(parts) + "</div>"

    reasons = verdict.get("noncompliance_reasons") if isinstance(verdict.get("noncompliance_reasons"), list) else []
    reasons_block = ""
    if isinstance(compliant, bool) and (not compliant) and reasons:
        li = "\n".join(f"<li>{_esc(r)}</li>" for r in reasons if r)
        reasons_block = f"<h3>Noncompliance reasons</h3><ul>{li}</ul>"

    recommendations = contract_v2.get("recommendations") if isinstance(contract_v2.get("recommendations"), list) else []
    rec_block = ""
    if decision_mode == "decision_grade":
        rec_items = [r for r in recommendations if isinstance(r, Mapping)]
        if rec_items:
            lines: list[str] = []
            for r in rec_items:
                title = str(r.get("title") or "Recommendation")
                suggestion = str(r.get("suggestion") or "").strip()
                lines.append(f"<li><b>{_esc(title)}</b>: {_esc(suggestion)}</li>" if suggestion else f"<li><b>{_esc(title)}</b></li>")
            rec_block = "<h3>Recommendations</h3><ul>" + "\n".join(lines) + "</ul>"

    prov_block = ""
    if provenance:
        try:
            prov_json = json.dumps(dict(provenance), indent=2, sort_keys=True)
            prov_block = "<h3>Provenance</h3><pre>" + _esc(prov_json) + "</pre>"
        except Exception:
            prov_block = ""

    verdict_mode_chip = ("Decision grade", "Not decision grade") if decision_mode != "decision_grade" else ("Grade", f"{grade} · {headline}")
    chips_1 = [
        ("Decision", decision_txt),
        verdict_mode_chip,
        ("Policy", policy_id),
        ("Policy status", compliant_txt),
    ]
    if stability_status == "computed" and assumptions_hash != "—":
        chips_1.append(("Stability assumptions", assumptions_hash))

    return (
        "<div class=\"panel\">"
        "<h2>Verdict card (Summary Contract v2)</h2>"
        + chip_row(chips_1)
        + chip_row(chips_2)
        + reasons_block
        + rec_block
        + prov_block
        + "</div>"
    )


def _build_governance_block(
    contract_v2: Mapping[str, Any] | None,
    *,
    extra_metadata: Mapping[str, Any] | None = None,
) -> tuple[str, list[str], dict[str, Any]]:
    decision_mode = str(contract_v2.get("decision_mode") or "filter_only").strip().lower() if contract_v2 else "filter_only"
    if decision_mode not in {"filter_only", "decision_grade"}:
        decision_mode = "filter_only"
    interpretation = interpretation_for_mode(decision_mode)
    proof = extract_decision_grade_proof_from_summary(contract_v2) if contract_v2 else None
    lines = governance_stamp_lines(
        decision_mode=decision_mode,
        interpretation=interpretation,
        decision_grade_proof=proof,
    )
    is_demo = bool(is_demo_from_metadata(extra_metadata))
    prov = build_governance_provenance(
        decision_mode=decision_mode,
        is_demo=is_demo,
        interpretation=interpretation,
        decision_grade_proof=(dict(proof) if isinstance(proof, Mapping) else None),
    )
    wm_text = str(prov.get("watermark") or export_watermark_label(decision_mode=decision_mode, is_demo=is_demo))
    watermark_html = f"<div class=\"watermark\">{_esc(wm_text)}</div>"
    return watermark_html, list(lines), dict(prov)


def _json_script_tag(*, element_id: str, payload: Mapping[str, Any]) -> str:
    raw = json.dumps(dict(payload), sort_keys=True, indent=2)
    # Prevent the classic `</script>` HTML parse hazard.
    safe = raw.replace("</", "<\\/")
    return f"<script id=\"{_esc(element_id)}\" type=\"application/json\">{safe}</script>"


def build_session_report_html(
    guide_meta: Mapping[str, Any],
    physics: Mapping[str, Any] | None,
    outcomes: Sequence[Mapping[str, Any]],
    chart_png: bytes | None,
    helix_flat_png: bytes | None = None,
    helix_helix_png: bytes | None = None,
    csv_text: str | None = None,
    extra_metadata: Mapping[str, Any] | None = None,
    contract_v2: Mapping[str, Any] | None = None,
    limitations: Mapping[str, Any] | None = None,
) -> str:
    """Return a self-contained HTML string summarizing a single guide run."""

    guide_json = json.dumps(dict(guide_meta), indent=2, sort_keys=True)
    meta_json = json.dumps(dict(extra_metadata or {}), indent=2, sort_keys=True)
    outcomes_json = json.dumps(list(outcomes), indent=2, sort_keys=True)

    decision_mode = str(contract_v2.get("decision_mode") or "filter_only").strip().lower() if contract_v2 else "filter_only"
    if decision_mode not in {"filter_only", "decision_grade"}:
        decision_mode = "filter_only"
    quantitative_allowed = decision_mode == "decision_grade" and any("prob" in o for o in outcomes)

    physics_lines: list[str] = []
    if physics:
        for key in (
            "pbs_dG",
            "flap_ddG",
            "E_pred",
            "microhomology",
            "frameshift_prob",
            "cut_prob",
            "engine_name",
            "backend",
            "crispr_scoring_version",
            "prime_scoring_version",
        ):
            if key in physics and physics[key] is not None:
                physics_lines.append(f"<li><b>{key}</b>: {physics[key]}</li>")

    chart_src = _b64_png(chart_png) if chart_png is not None else ""
    flat_src = _b64_png(helix_flat_png) if helix_flat_png else ""
    helix_src = _b64_png(helix_helix_png) if helix_helix_png else ""

    meta_lines: list[str] = []
    if extra_metadata:
        for key in ("project_id", "sample_id", "created_at", "author", "run_id"):
            if key in extra_metadata and extra_metadata[key]:
                meta_lines.append(f"<li><b>{key}</b>: {extra_metadata[key]}</li>")

    run_meta_block = "<p>No run metadata provided.</p>"
    if meta_lines:
        run_meta_block = "<ul>" + "\n".join(meta_lines) + "</ul>"

    chart_block = "<p>No chart image was provided for this export.</p>"
    if chart_src:
        chart_block = f'<img src="{chart_src}" alt="Outcome chart" style="max-width:100%;"/>'

    csv_block = ""
    if csv_text:
        csv_escaped = (
            csv_text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        )
        csv_block = f"""
        <h2>Top outcomes (CSV)</h2>
        <pre style=\"white-space: pre; font-family: monospace; font-size: 12px;\">{csv_escaped}</pre>
        """

    physics_block = "<p>No repair model data available for this run.</p>"
    if physics_lines:
        physics_block = "<ul>" + "\n".join(physics_lines) + "</ul>"
    repair_pathways_block = _build_repair_pathway_block_html(outcomes=outcomes, quantitative_allowed=quantitative_allowed)

    helix_images_block = ""
    if flat_src or helix_src:
        helix_images_block = "<h2>Helix views</h2><div>"
        if flat_src:
            helix_images_block += (
                f'<img src="{flat_src}" alt="Helix flat view" style="max-width:48%; margin-right:1%;" />'
            )
        if helix_src:
            helix_images_block += f'<img src="{helix_src}" alt="Helix 3D view" style="max-width:48%;" />'
        helix_images_block += "</div>"

    verdict_card_block = _build_verdict_card_html(contract_v2) if contract_v2 else ""
    watermark_overlay, governance_lines, governance_prov = _build_governance_block(contract_v2, extra_metadata=extra_metadata)
    prov_header_line, prov_block = build_provenance_header_v1(decision_mode=decision_mode, run_summary_v2=contract_v2)
    prov_block_json = json.dumps(prov_block, indent=2, sort_keys=True)
    provenance_panel = (
        "<div class=\"panel\">"
        "<h2>Provenance</h2>"
        f"<pre>{_esc(prov_header_line)}</pre>"
        f"<pre>{_esc(prov_block_json)}</pre>"
        "</div>"
    )
    run_id = None
    try:
        if isinstance(extra_metadata, Mapping):
            run_id = extra_metadata.get("run_id") or extra_metadata.get("runId")
    except Exception:
        run_id = None
    export_prov = build_export_provenance_v1(
        export_kind="session_report_html",
        export_path=None,
        run_id=run_id,
        governance=governance_prov,
        limitations_stamp=limitations,
    )
    prov_sha = export_provenance_sha256(export_prov)
    governance_lines_with_hash = list(governance_lines) + [f"export_provenance_sha256: sha256:{prov_sha}"]
    governance_block = (
        "<div class=\"panel governance-banner\">"
        "<h2>Governance</h2><pre>"
        + _esc("\n".join(governance_lines_with_hash))
        + "</pre></div>"
    )
    export_prov_meta = f"<meta name=\"helix:export_provenance_sha256\" content=\"sha256:{_esc(prov_sha)}\" />"
    export_prov_script = _json_script_tag(element_id="helix-export-provenance", payload=export_prov)

    limitations_block = ""
    if limitations:
        lim_items: list[str] = []
        banner = limitations.get("banner")
        if banner:
            lim_items.append(f"<li><b>Banner</b>: {_esc(banner)}</li>")
        doc_slug = limitations.get("doc_slug")
        doc_version = limitations.get("doc_version")
        if doc_slug or doc_version:
            lim_items.append(f"<li><b>Doc</b>: {_esc(doc_slug or '')}@{_esc(doc_version or '')}</li>")
        doc_updated = limitations.get("doc_last_updated")
        if doc_updated:
            lim_items.append(f"<li><b>Doc last updated</b>: {_esc(doc_updated)}</li>")
        exported_at = limitations.get("timestamp_utc")
        if exported_at:
            lim_items.append(f"<li><b>Exported at</b>: {_esc(exported_at)}</li>")
        doc_url = limitations.get("doc_url")
        if doc_url:
            lim_items.append(f"<li><b>Doc URL</b>: {_esc(doc_url)}</li>")
        if lim_items:
            limitations_block = "<div class=\"panel\"><h2>Limitations</h2><ul>" + "".join(lim_items) + "</ul></div>"

    return f"""<!doctype html>
<html>
<head>
  <meta charset=\"utf-8\" />
  <title>Helix session report – {guide_meta.get('guide_id', '')}</title>
  {export_prov_meta}
  {export_prov_script}
  <style>
    body {{
      font-family: system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif;
      margin: 24px;
    }}
    .watermark {{
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) rotate(-30deg);
      font-size: 82px;
      font-weight: 700;
      opacity: 0.08;
      pointer-events: none;
      user-select: none;
      white-space: nowrap;
      z-index: 9999;
    }}
    .governance-banner pre {{
      white-space: pre-wrap;
      word-break: break-word;
    }}
    .chip-row {{
      margin: 8px 0 16px 0;
    }}
    .chip {{
      display: inline-block;
      padding: 4px 10px;
      margin: 2px 6px 2px 0;
      border-radius: 999px;
      font-size: 12px;
      background: transparent;
      border: 1px solid currentColor;
    }}
    .panel {{
      background: transparent;
      border: 1px solid currentColor;
      border-radius: 12px;
      padding: 16px 18px;
      margin-bottom: 18px;
    }}
    pre {{
      border-radius: 10px;
      padding: 12px;
      background: transparent;
      border: 1px solid currentColor;
      overflow-x: auto;
    }}
    img {{
      border-radius: 10px;
      border: 1px solid currentColor;
    }}
  </style>
</head>
<body>
  <h1>Helix session report</h1>

  {watermark_overlay}
  {governance_block}
  {provenance_panel}
  {verdict_card_block}
  {limitations_block}

    <div class=\"panel\">
    <h2>Guide</h2>
    <div class=\"chip-row\">
      <span class=\"chip\">Guide: {guide_meta.get('guide_id','')}</span>
      <span class=\"chip\">Target: {guide_meta.get('target_locus','')}</span>
      <span class=\"chip\">Edit type: {guide_meta.get('edit_type','')}</span>
    </div>
    <h3>Repair model</h3>
    {physics_block}
    {repair_pathways_block}
  </div>

  <div class=\"panel\">
    <h2>Outcome summary</h2>
    {chart_block}
  </div>

  <div class=\"panel\">
    <h2>Data artifacts</h2>
    <h3>Guide metadata</h3>
    <pre>{guide_json}</pre>

    <h3>Run metadata</h3>
    {run_meta_block}

    <h3>Session metadata</h3>
    <pre>{meta_json}</pre>

    <h3>Outcomes (JSON)</h3>
    <pre>{outcomes_json}</pre>

    {csv_block}
    {helix_images_block}
  </div>

</body>
</html>
"""


def save_session_report(path: str | Path, *args: Any, **kwargs: Any) -> Path:
    """Build and write a session report to `path`."""

    html = build_session_report_html(*args, **kwargs)
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf8")

    try:
        from helix.support.events import log_event

        meta = kwargs.get("extra_metadata")
        run_id = ""
        if isinstance(meta, Mapping):
            rid = meta.get("run_id") or meta.get("runId")
            if rid is not None:
                run_id = str(rid)
        log_event("report.exported", filename=out.name, run_id=run_id)
    except Exception:
        pass
    return out
