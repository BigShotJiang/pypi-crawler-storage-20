from __future__ import annotations

import csv
from io import StringIO
from pathlib import Path

from helix.studio.models import RunModel
from helix.studio.reports.session_report import save_session_report
from helix.studio.limitations import limitations_csv_prefix, limitations_stamp
from helix.studio.run_artifact import build_run_artifact_from_run_model, artifact_decision_mode_eligible
from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_artifact,
    governance_csv_prefix,
    interpretation_for_mode,
)


def outcomes_to_csv_text(run: RunModel) -> str:
    buf = StringIO()
    writer = csv.writer(buf)
    writer.writerow(
        [
            "name",
            "category",
            "prob",
            "delta_bp",
            "peak_position",
            "position_min",
            "position_max",
            "frameshift",
            "microhomology",
        ]
    )
    for outcome in run.outcomes:
        writer.writerow(
            [
                outcome.name,
                outcome.category,
                f"{outcome.prob:.6f}",
                "" if outcome.delta_bp is None else outcome.delta_bp,
                "" if outcome.peak_position is None else outcome.peak_position,
                "" if outcome.position_min is None else outcome.position_min,
                "" if outcome.position_max is None else outcome.position_max,
                "" if outcome.frameshift is None else int(bool(outcome.frameshift)),
                "" if outcome.microhomology is None else outcome.microhomology,
            ]
        )
    stamp = limitations_stamp()

    meta = run.metadata if isinstance(run.metadata, dict) else {}
    artifact = meta.get("run_artifact") if isinstance(meta, dict) else None
    if not isinstance(artifact, dict):
        artifact = build_run_artifact_from_run_model(run)
    requested_mode = str(artifact.get("decision_mode") or "filter_only")
    effective_mode = (
        "decision_grade"
        if (requested_mode == "decision_grade" and artifact_decision_mode_eligible(artifact))
        else "filter_only"
    )
    interpretation = interpretation_for_mode(effective_mode)
    proof = extract_decision_grade_proof_from_artifact(artifact) if effective_mode == "decision_grade" else None
    gov_prefix = governance_csv_prefix(
        decision_mode=effective_mode,
        interpretation=interpretation,
        decision_grade_proof=proof,
    )

    return limitations_csv_prefix(stamp) + gov_prefix + buf.getvalue()


def report_path_for_run(run: RunModel, out_dir: Path) -> Path:
    return Path(out_dir) / f"helix_report_{run.guide_id}_{run.run_id}.html"


def write_single_run_report(run: RunModel, out_dir: Path, *, chart_png: bytes | None = None) -> Path:
    """Write a single-run HTML report and return its path."""

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    guide_meta = {
        "guide_id": run.guide_id,
        "target_locus": run.target_locus,
        "edit_type": run.edit_type,
        "run_id": run.run_id,
    }
    physics = dict(run.physics or {})
    physics.update(
        {
            "engine_name": run.engine.name,
            "backend": run.engine.backend,
            "crispr_scoring_version": run.engine.crispr_scoring_version,
            "prime_scoring_version": run.engine.prime_scoring_version,
        }
    )
    outcomes = [o.to_dict() for o in run.outcomes]
    csv_text = outcomes_to_csv_text(run)

    html_path = report_path_for_run(run, out_dir)
    meta = dict(run.metadata or {})
    meta.setdefault("run_id", run.run_id)
    stamp = limitations_stamp()
    meta["limitations"] = stamp
    contract_v2 = None
    try:
        cand = meta.get("run_summary")
        contract_v2 = cand if isinstance(cand, dict) else None
    except Exception:
        contract_v2 = None

    save_session_report(
        html_path,
        guide_meta,
        physics,
        outcomes,
        chart_png=chart_png,
        helix_flat_png=None,
        helix_helix_png=None,
        csv_text=csv_text,
        extra_metadata=meta,
        contract_v2=contract_v2,
        limitations=stamp,
    )
    return html_path


__all__ = ["outcomes_to_csv_text", "report_path_for_run", "write_single_run_report"]
