from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from helix.support.doctor import render_doctor_report


class DoctorDialog(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Helix Doctor")
        self.setModal(True)
        self.resize(860, 560)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Environment diagnostics (copy/paste for support).", self)
        title.setStyleSheet("font-weight: 650; font-size: 15px; color: #f4f6ff;")
        layout.addWidget(title)

        self._text = QPlainTextEdit(self)
        self._text.setReadOnly(True)
        self._text.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._text.setPlainText(render_doctor_report())
        self._text.setStyleSheet("background: rgba(8, 10, 20, 0.9); color: #e6edf7;")
        layout.addWidget(self._text, stretch=1)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy to clipboard", self)
        copy_btn.clicked.connect(self._copy_to_clipboard)
        actions.addWidget(copy_btn)

        save_btn = QPushButton("Save…", self)
        save_btn.clicked.connect(self._save_to_file)
        actions.addWidget(save_btn)

        close_btn = QPushButton("Close", self)
        close_btn.clicked.connect(self.accept)
        actions.addWidget(close_btn)

        layout.addLayout(actions)

    def _copy_to_clipboard(self) -> None:
        try:
            QGuiApplication.clipboard().setText(self._text.toPlainText())
        except Exception as exc:
            QMessageBox.critical(self, "Clipboard", f"Failed to copy doctor output: {exc}")

    def _save_to_file(self) -> None:
        default_name = str(Path.cwd() / "helix_doctor.txt")
        path_str, _ = QFileDialog.getSaveFileName(self, "Save doctor output", default_name, "Text file (*.txt)")
        if not path_str:
            return
        try:
            Path(path_str).write_text(self._text.toPlainText(), encoding="utf-8")
        except Exception as exc:
            QMessageBox.critical(self, "Save", f"Failed to write doctor output: {exc}")


__all__ = ["DoctorDialog"]

