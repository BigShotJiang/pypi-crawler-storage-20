from __future__ import annotations

import hashlib
import os
import shutil
from dataclasses import dataclass
from pathlib import Path

import requests

from helix import fs
from helix import temp
from .install_txn import (
    PREV_DIRNAME,
    STAGING_DIRNAME,
    clear_txn,
    new_txn,
    recover_incomplete_installs,
    txn_path,
    write_txn,
)
from .manifest import DEFAULT_MANIFEST_FILENAME, PluginManifestError, load_plugin_manifest
from .plugin_package import (
    DEFAULT_PACKAGE_EXTENSION,
    PluginPackageError,
    PluginPackageVerification,
    extract_plugin_package,
)
from .trust_store import PluginTrustStore, default_trust_store_path


class PluginInstallError(RuntimeError):
    pass


_CACHE_DIRNAME = ".helix_pkg_cache"


@dataclass(frozen=True, slots=True)
class PluginSignaturePolicy:
    """Policy for accepting plugin packages at install time.

    Note: this is not an OS sandbox. It only governs whether Studio accepts a package.
    """

    require_signed: bool = False
    require_trusted: bool = False

    @classmethod
    def from_env(cls) -> PluginSignaturePolicy:
        return cls(
            require_signed=os.environ.get("HELIX_STUDIO_PLUGIN_REQUIRE_SIGNED", "0")
            == "1",
            require_trusted=os.environ.get("HELIX_STUDIO_PLUGIN_REQUIRE_TRUSTED", "0")
            == "1",
        )


@dataclass(frozen=True, slots=True)
class PluginInstallResult:
    plugin_id: str
    version: str
    plugin_root: Path
    cached_package: Path
    signature_status: str  # "unsigned" | "untrusted" | "trusted"
    verification: PluginPackageVerification


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _cache_package_path(*, plugins_dir: Path, plugin_id: str, version: str) -> Path:
    root = Path(plugins_dir) / _CACHE_DIRNAME / plugin_id / version
    return root / f"{plugin_id}-{version}{DEFAULT_PACKAGE_EXTENSION}"


def list_cached_versions(*, plugins_dir: Path, plugin_id: str) -> list[str]:
    root = Path(plugins_dir) / _CACHE_DIRNAME / str(plugin_id or "").strip().lower()
    if not root.is_dir():
        return []
    entries = fs.iterdir_sorted(root, key=lambda p: p.name.lower())
    return [p.name for p in entries if p.is_dir()]


def _download_package(
    url: str,
    *,
    expected_sha256: str | None = None,
    tmp_dir: Path,
) -> Path:
    u = str(url or "").strip()
    if not u:
        raise PluginInstallError("URL is required")
    resp = requests.get(u, stream=True, timeout=30.0)
    resp.raise_for_status()
    tmp_dir.mkdir(parents=True, exist_ok=True)
    out = tmp_dir / f"download{DEFAULT_PACKAGE_EXTENSION}"

    h = hashlib.sha256()
    with out.open("wb") as f:
        for chunk in resp.iter_content(chunk_size=1024 * 128):
            if not chunk:
                continue
            f.write(chunk)
            h.update(chunk)

    actual = h.hexdigest()
    if expected_sha256 and actual.lower() != expected_sha256.strip().lower():
        raise PluginInstallError(
            f"download sha256 mismatch (expected {expected_sha256} got {actual})"
        )
    return out


def install_plugin_package_from_file(
    package_path: Path,
    *,
    plugins_dir: Path,
    trust_store_path: Path | None = None,
    policy: PluginSignaturePolicy | None = None,
) -> PluginInstallResult:
    pkg = Path(package_path)
    if not pkg.is_file():
        raise PluginInstallError(f"package not found: {pkg}")
    return _install_from_path(
        pkg,
        plugins_dir=Path(plugins_dir),
        trust_store_path=trust_store_path,
        policy=policy,
        source=str(pkg),
    )


def install_plugin_package_from_url(
    url: str,
    *,
    plugins_dir: Path,
    expected_sha256: str | None = None,
    trust_store_path: Path | None = None,
    policy: PluginSignaturePolicy | None = None,
) -> PluginInstallResult:
    plugins_root = Path(plugins_dir)
    plugins_root.mkdir(parents=True, exist_ok=True)
    with temp.TemporaryDirectory(dir=plugins_root) as tmp_dir:
        pkg = _download_package(url, expected_sha256=expected_sha256, tmp_dir=tmp_dir)
        return _install_from_path(
            pkg,
            plugins_dir=plugins_root,
            trust_store_path=trust_store_path,
            policy=policy,
            source=url,
        )


def rollback_plugin(
    plugin_id: str,
    *,
    plugins_dir: Path,
    version: str,
    trust_store_path: Path | None = None,
    policy: PluginSignaturePolicy | None = None,
) -> PluginInstallResult:
    pid = str(plugin_id or "").strip().lower()
    ver = str(version or "").strip()
    if not pid or not ver:
        raise PluginInstallError("plugin_id and version are required")
    cached = _cache_package_path(plugins_dir=Path(plugins_dir), plugin_id=pid, version=ver)
    if not cached.is_file():
        raise PluginInstallError(f"cached package not found: {cached}")
    return _install_from_path(
        cached,
        plugins_dir=Path(plugins_dir),
        trust_store_path=trust_store_path,
        policy=policy,
        source=str(cached),
    )


def _install_from_path(
    package_path: Path,
    *,
    plugins_dir: Path,
    trust_store_path: Path | None,
    policy: PluginSignaturePolicy | None,
    source: str | None,
) -> PluginInstallResult:
    plugins_root = Path(plugins_dir)
    plugins_root.mkdir(parents=True, exist_ok=True)
    recover_incomplete_installs(plugins_dir=plugins_root)
    policy = policy or PluginSignaturePolicy.from_env()
    trust_path = (
        Path(trust_store_path)
        if trust_store_path is not None
        else default_trust_store_path()
    )
    trust = PluginTrustStore.load(trust_path)

    staging_dir: Path | None = None
    prev_dir: Path | None = None
    txn_file: Path | None = None
    simulated_crash = False

    def _maybe_test_fail(step: str) -> None:
        nonlocal simulated_crash
        if not os.environ.get("PYTEST_CURRENT_TEST"):
            return
        if os.environ.get("HELIX_TEST_PLUGIN_INSTALL_FAIL_STEP") != step:
            return
        simulated_crash = True
        raise RuntimeError(f"simulated crash at {step}")

    try:
        staging_root = plugins_root / STAGING_DIRNAME / "extract"
        staging_root.mkdir(parents=True, exist_ok=True)
        staging_dir = temp.mkdtemp(prefix="plugin-", dir=staging_root)

        try:
            verification = extract_plugin_package(Path(package_path), out_dir=staging_dir)
        except PluginPackageError as exc:
            raise PluginInstallError(str(exc)) from exc

        try:
            load_plugin_manifest(staging_dir / DEFAULT_MANIFEST_FILENAME)
        except PluginManifestError as exc:
            raise PluginInstallError(str(exc)) from exc

        signature_status = "unsigned"
        if verification.signature_present:
            trusted = trust.is_trusted(
                publisher=verification.publisher,
                public_key_b64=verification.public_key_b64,
            )
            signature_status = "trusted" if trusted else "untrusted"

        if policy.require_signed and signature_status == "unsigned":
            raise PluginInstallError(
                f"{verification.plugin_id}: unsigned packages are blocked by policy"
            )
        if policy.require_trusted and signature_status != "trusted":
            raise PluginInstallError(
                f"{verification.plugin_id}: untrusted publisher key is blocked by policy"
            )

        pkg_sha = _sha256_file(Path(package_path))
        cached = _cache_package_path(
            plugins_dir=plugins_root,
            plugin_id=verification.plugin_id,
            version=verification.version,
        )
        cached.parent.mkdir(parents=True, exist_ok=True)
        if cached.exists() and _sha256_file(cached) != pkg_sha:
            cached.unlink()
        if not cached.exists():
            tmp = cached.with_suffix(cached.suffix + ".tmp")
            shutil.copy2(Path(package_path), tmp)
            os.replace(tmp, cached)
            if _sha256_file(cached) != pkg_sha:
                raise PluginInstallError(
                    f"{verification.plugin_id}: cached package sha256 mismatch"
                )

        dest = plugins_root / verification.plugin_id
        if dest.exists():
            prev_dir = plugins_root / PREV_DIRNAME / verification.plugin_id / "previous"
            if prev_dir.exists():
                shutil.rmtree(prev_dir)
            prev_dir.parent.mkdir(parents=True, exist_ok=True)

        txn_file = txn_path(plugins_dir=plugins_root, plugin_id=verification.plugin_id)
        write_txn(
            txn_file,
            new_txn(
                plugin_id=verification.plugin_id,
                version=verification.version,
                dest=dest,
                staging=staging_dir,
                prev=prev_dir,
                package_sha256=pkg_sha,
                source=source or str(package_path),
            ),
        )
        _maybe_test_fail("after_txn_write")

        try:
            if dest.exists() and prev_dir is not None:
                os.replace(dest, prev_dir)
                _maybe_test_fail("after_dest_to_prev")
            os.replace(staging_dir, dest)
            _maybe_test_fail("after_staging_to_dest")
        except Exception as exc:
            if simulated_crash:
                raise

            try:
                if not dest.exists() and prev_dir is not None and prev_dir.exists():
                    os.replace(prev_dir, dest)
            except Exception:
                raise PluginInstallError(
                    f"{verification.plugin_id}: install failed and rollback failed: {exc}"
                ) from exc

            try:
                if txn_file is not None:
                    clear_txn(txn_file)
            except Exception:
                pass
            raise PluginInstallError(f"{verification.plugin_id}: install failed: {exc}") from exc

        clear_txn(txn_file)
        if prev_dir is not None and prev_dir.exists():
            shutil.rmtree(prev_dir)

        return PluginInstallResult(
            plugin_id=verification.plugin_id,
            version=verification.version,
            plugin_root=dest,
            cached_package=cached,
            signature_status=signature_status,
            verification=verification,
        )
    finally:
        if simulated_crash:
            # Leave txn/staging/prev state intact so recovery can be tested.
            # Guarded by PYTEST_CURRENT_TEST.
            pass
        else:
            try:
                if staging_dir is not None and staging_dir.exists():
                    shutil.rmtree(staging_dir)
            except Exception:
                pass
