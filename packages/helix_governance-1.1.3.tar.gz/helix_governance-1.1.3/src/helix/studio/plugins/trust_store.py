from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


class PluginTrustStoreError(ValueError):
    pass


def default_trust_store_path() -> Path:
    return Path.home() / ".helix" / "plugins" / "trust_store.json"


@dataclass(slots=True)
class PluginTrustStore:
    """Local trust store for plugin publisher keys.

    Stored as:
    {
      "format": 1,
      "trusted": {
        "publisher_id": ["base64_ed25519_pubkey", ...]
      }
    }
    """

    trusted: dict[str, set[str]]

    @classmethod
    def load(cls, path: Path | None = None) -> PluginTrustStore:
        p = Path(path) if path is not None else default_trust_store_path()
        if not p.exists():
            return cls(trusted={})
        try:
            doc = json.loads(p.read_text(encoding="utf-8"))
        except Exception as exc:
            raise PluginTrustStoreError(f"failed to read trust store: {exc}") from exc
        if not isinstance(doc, dict):
            return cls(trusted={})
        raw = doc.get("trusted")
        trusted: dict[str, set[str]] = {}
        if isinstance(raw, dict):
            for publisher, keys in raw.items():
                pub = str(publisher or "").strip().lower()
                if not pub or not isinstance(keys, list):
                    continue
                trusted[pub] = {str(k).strip() for k in keys if str(k).strip()}
        return cls(trusted=trusted)

    def save(self, path: Path | None = None) -> None:
        p = Path(path) if path is not None else default_trust_store_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        doc = {
            "format": 1,
            "trusted": {k: sorted(v) for k, v in sorted(self.trusted.items())},
        }
        p.write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def is_trusted(self, *, publisher: str | None, public_key_b64: str | None) -> bool:
        pub = str(publisher or "").strip().lower()
        key = str(public_key_b64 or "").strip()
        if not pub or not key:
            return False
        return key in self.trusted.get(pub, set())

    def trust(self, *, publisher: str, public_key_b64: str) -> None:
        pub = str(publisher or "").strip().lower()
        key = str(public_key_b64 or "").strip()
        if not pub or not key:
            raise PluginTrustStoreError("publisher and public_key_b64 are required")
        self.trusted.setdefault(pub, set()).add(key)

