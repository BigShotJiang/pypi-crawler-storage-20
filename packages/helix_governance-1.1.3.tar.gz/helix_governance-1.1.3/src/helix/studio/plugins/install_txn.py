from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from helix import clock
from helix import fs

TXN_DIRNAME = ".helix_pkg_txn"
STAGING_DIRNAME = ".helix_pkg_staging"
PREV_DIRNAME = ".helix_pkg_prev"


class PluginInstallTxnError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class PluginInstallTxn:
    plugin_id: str
    version: str
    dest: Path
    staging: Path
    prev: Path | None
    started_at: str
    package_sha256: str | None = None
    source: str | None = None

    def to_json(self) -> dict[str, Any]:
        return {
            "format": 1,
            "plugin_id": self.plugin_id,
            "version": self.version,
            "dest": str(self.dest),
            "staging": str(self.staging),
            "prev": str(self.prev) if self.prev is not None else None,
            "started_at": self.started_at,
            "package_sha256": self.package_sha256,
            "source": self.source,
        }

    @classmethod
    def from_json(cls, doc: Any) -> PluginInstallTxn:
        if not isinstance(doc, dict) or int(doc.get("format") or 0) != 1:
            raise PluginInstallTxnError("invalid install txn format")
        plugin_id = str(doc.get("plugin_id") or "").strip().lower()
        version = str(doc.get("version") or "").strip()
        dest = Path(str(doc.get("dest") or "").strip())
        staging = Path(str(doc.get("staging") or "").strip())
        prev_raw = str(doc.get("prev") or "").strip()
        prev = Path(prev_raw) if prev_raw else None
        started_at = str(doc.get("started_at") or "").strip()
        package_sha256 = str(doc.get("package_sha256") or "").strip() or None
        source = str(doc.get("source") or "").strip() or None
        if not plugin_id or not version or not dest or not staging or not started_at:
            raise PluginInstallTxnError("invalid install txn fields")
        return cls(
            plugin_id=plugin_id,
            version=version,
            dest=dest,
            staging=staging,
            prev=prev,
            started_at=started_at,
            package_sha256=package_sha256,
            source=source,
        )


def txn_path(*, plugins_dir: Path, plugin_id: str) -> Path:
    pid = str(plugin_id or "").strip().lower()
    return Path(plugins_dir) / TXN_DIRNAME / pid / "txn.json"


def write_txn(path: Path, txn: PluginInstallTxn) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(txn.to_json(), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, p)


def read_txn(path: Path) -> PluginInstallTxn:
    p = Path(path)
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        raise PluginInstallTxnError(f"failed to read install txn: {exc}") from exc
    return PluginInstallTxn.from_json(doc)


def clear_txn(path: Path) -> None:
    p = Path(path)
    try:
        p.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        return
    try:
        parent = p.parent
        if parent.is_dir() and not fs.dir_has_any(parent):
            parent.rmdir()
    except Exception:
        pass


def _try_rmtree(path: Path) -> None:
    try:
        if Path(path).is_dir():
            shutil.rmtree(path)
    except Exception:
        pass


def recover_txn(txn_path: Path) -> bool:
    """Best-effort recovery for a single install transaction.

    Returns True if recovery took an action (rename/cleanup), False otherwise.
    Never raises for routine cases; only raises on invalid txn format.
    """
    txn = read_txn(txn_path)
    dest = txn.dest
    staging = txn.staging
    prev = txn.prev

    if dest.is_dir():
        # Install completed; clean up leftovers.
        _try_rmtree(staging)
        if prev is not None:
            _try_rmtree(prev)
        clear_txn(txn_path)
        return True

    if staging.is_dir():
        dest.parent.mkdir(parents=True, exist_ok=True)
        os.replace(staging, dest)
        if prev is not None:
            _try_rmtree(prev)
        clear_txn(txn_path)
        return True

    if prev is not None and prev.is_dir():
        dest.parent.mkdir(parents=True, exist_ok=True)
        os.replace(prev, dest)
        clear_txn(txn_path)
        return True

    # Nothing left to recover; clear the txn so we don't loop forever.
    clear_txn(txn_path)
    return False


def recover_incomplete_installs(*, plugins_dir: Path) -> None:
    root = Path(plugins_dir) / TXN_DIRNAME
    if not root.is_dir():
        return
    for pid_dir in fs.iterdir_sorted(root, key=lambda p: p.name.lower()):
        if not pid_dir.is_dir():
            continue
        path = pid_dir / "txn.json"
        if not path.is_file():
            continue
        try:
            recover_txn(path)
        except PluginInstallTxnError:
            # Bad txn file should not brick startup; leave it for inspection.
            continue
        except Exception:
            continue


def new_txn(
    *,
    plugin_id: str,
    version: str,
    staging: Path,
    dest: Path,
    prev: Path | None,
    package_sha256: str | None,
    source: str | None,
) -> PluginInstallTxn:
    return PluginInstallTxn(
        plugin_id=str(plugin_id or "").strip().lower(),
        version=str(version or "").strip(),
        dest=Path(dest),
        staging=Path(staging),
        prev=Path(prev) if prev is not None else None,
        started_at=clock.utc_now_iso_offset(),
        package_sha256=str(package_sha256 or "").strip() or None,
        source=str(source or "").strip() or None,
    )
