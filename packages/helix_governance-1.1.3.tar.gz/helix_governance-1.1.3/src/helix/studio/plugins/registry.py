from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

from helix import clock

class PluginRegistryError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class RegistryRelease:
    version: str
    url: str
    sha256: str | None = None
    publisher: str | None = None
    capabilities: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class RegistryPlugin:
    plugin_id: str
    name: str | None
    releases: list[RegistryRelease]

    def latest(self) -> RegistryRelease | None:
        return self.releases[0] if self.releases else None


@dataclass(frozen=True, slots=True)
class PluginRegistryIndex:
    plugins: dict[str, RegistryPlugin]

    def get(self, plugin_id: str) -> RegistryPlugin | None:
        return self.plugins.get(str(plugin_id or "").strip().lower())


@dataclass(frozen=True, slots=True)
class RegistryFetchResult:
    index: PluginRegistryIndex
    cache_path: Path | None
    from_cache: bool
    stale: bool
    checked_at: str | None
    fetched_at: str | None
    etag: str | None
    last_modified: str | None


def default_registry_cache_root() -> Path:
    return Path.home() / ".helix" / "plugins" / "registry_cache"


def _now_iso() -> str:
    return clock.utc_now_iso_offset()


def _cache_path_for_url(url: str, *, cache_root: Path) -> Path:
    key = hashlib.sha256(url.encode("utf-8")).hexdigest()
    return Path(cache_root) / f"{key}.json"


def _load_cache(path: Path) -> dict[str, Any] | None:
    p = Path(path)
    if not p.is_file():
        return None
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None
    if not isinstance(doc, dict) or int(doc.get("format") or 0) != 1:
        return None
    return doc


def _save_cache(path: Path, doc: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(p)


def fetch_registry_index(url: str, *, timeout_s: float = 15.0) -> PluginRegistryIndex:
    u = str(url or "").strip()
    if not u:
        raise PluginRegistryError("registry URL is required")
    resp = requests.get(u, timeout=float(timeout_s))
    resp.raise_for_status()
    try:
        doc = resp.json()
    except json.JSONDecodeError as exc:
        raise PluginRegistryError(f"invalid registry JSON: {exc}") from exc
    return parse_registry_index(doc)


def fetch_registry_index_cached(
    url: str,
    *,
    cache_root: Path | None = None,
    timeout_s: float = 15.0,
    allow_stale: bool = True,
) -> RegistryFetchResult:
    u = str(url or "").strip()
    if not u:
        raise PluginRegistryError("registry URL is required")

    root = Path(cache_root) if cache_root is not None else default_registry_cache_root()
    cache_path = _cache_path_for_url(u, cache_root=root)
    cached = _load_cache(cache_path)

    checked_at = _now_iso()
    headers: dict[str, str] = {}
    if isinstance(cached, dict):
        etag = str(cached.get("etag") or "").strip()
        if etag:
            headers["If-None-Match"] = etag
        lm = str(cached.get("last_modified") or "").strip()
        if lm:
            headers["If-Modified-Since"] = lm

    try:
        resp = requests.get(u, timeout=float(timeout_s), headers=headers or None)
        if resp.status_code == 304 and isinstance(cached, dict):
            cached["checked_at"] = checked_at
            _save_cache(cache_path, cached)
            doc = cached.get("doc")
            index = parse_registry_index(doc)
            return RegistryFetchResult(
                index=index,
                cache_path=cache_path,
                from_cache=True,
                stale=False,
                checked_at=checked_at,
                fetched_at=str(cached.get("fetched_at") or "").strip() or None,
                etag=str(cached.get("etag") or "").strip() or None,
                last_modified=str(cached.get("last_modified") or "").strip() or None,
            )

        resp.raise_for_status()
        try:
            doc = resp.json()
        except json.JSONDecodeError as exc:
            raise PluginRegistryError(f"invalid registry JSON: {exc}") from exc

        index = parse_registry_index(doc)
        record = {
            "format": 1,
            "url": u,
            "checked_at": checked_at,
            "fetched_at": checked_at,
            "etag": str(resp.headers.get("ETag") or "").strip() or None,
            "last_modified": str(resp.headers.get("Last-Modified") or "").strip() or None,
            "doc": doc,
        }
        _save_cache(cache_path, record)
        return RegistryFetchResult(
            index=index,
            cache_path=cache_path,
            from_cache=False,
            stale=False,
            checked_at=checked_at,
            fetched_at=checked_at,
            etag=record["etag"],
            last_modified=record["last_modified"],
        )
    except PluginRegistryError:
        raise
    except Exception as exc:
        if isinstance(cached, dict) and allow_stale:
            doc = cached.get("doc")
            index = parse_registry_index(doc)
            return RegistryFetchResult(
                index=index,
                cache_path=cache_path,
                from_cache=True,
                stale=True,
                checked_at=checked_at,
                fetched_at=str(cached.get("fetched_at") or "").strip() or None,
                etag=str(cached.get("etag") or "").strip() or None,
                last_modified=str(cached.get("last_modified") or "").strip() or None,
            )
        raise PluginRegistryError(f"failed to fetch registry: {exc}") from exc


def parse_registry_index(doc: Any) -> PluginRegistryIndex:
    if not isinstance(doc, dict):
        raise PluginRegistryError("registry index must be a JSON object")
    if int(doc.get("format") or 0) != 1:
        raise PluginRegistryError("unsupported registry format")

    raw_plugins = doc.get("plugins")
    if not isinstance(raw_plugins, list):
        raise PluginRegistryError("registry index missing plugins list")

    plugins: dict[str, RegistryPlugin] = {}
    for item in raw_plugins:
        if not isinstance(item, dict):
            continue
        pid = str(item.get("plugin_id") or item.get("id") or "").strip().lower()
        if not pid:
            continue
        name = str(item.get("name") or "").strip() or None
        raw_versions = item.get("versions") or item.get("releases") or []
        if not isinstance(raw_versions, list):
            continue
        releases: list[RegistryRelease] = []
        for rel in raw_versions:
            if not isinstance(rel, dict):
                continue
            ver = str(rel.get("version") or "").strip()
            url = str(rel.get("url") or "").strip()
            if not ver or not url:
                continue
            releases.append(
                RegistryRelease(
                    version=ver,
                    url=url,
                    sha256=str(rel.get("sha256") or "").strip() or None,
                    publisher=str(rel.get("publisher") or "").strip() or None,
                    capabilities=rel.get("capabilities")
                    if isinstance(rel.get("capabilities"), dict)
                    else None,
                )
            )

        try:
            from packaging.version import Version

            releases.sort(key=lambda r: Version(r.version), reverse=True)
        except Exception:
            releases.sort(key=lambda r: r.version, reverse=True)

        plugins[pid] = RegistryPlugin(plugin_id=pid, name=name, releases=releases)

    return PluginRegistryIndex(plugins=plugins)
