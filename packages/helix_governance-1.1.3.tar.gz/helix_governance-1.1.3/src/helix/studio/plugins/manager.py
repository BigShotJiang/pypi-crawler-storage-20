from __future__ import annotations

import importlib
import importlib.metadata as metadata
import os
import re
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Any, Callable, Iterable, Sequence

from helix import clock
from helix import fs
from .manifest import (
    DEFAULT_MANIFEST_FILENAME,
    HELIX_PLUGIN_API_VERSION,
    HelixPluginManifest,
    PluginManifestError,
    api_major,
    load_plugin_manifest,
    parse_entry,
)
from .install_txn import recover_incomplete_installs


@dataclass(frozen=True, slots=True)
class HelixPluginDescriptor:
    root: Path
    manifest_path: Path
    manifest: HelixPluginManifest

    @property
    def plugin_id(self) -> str:
        return self.manifest.plugin_id


@dataclass(slots=True)
class LoadedPlugin:
    descriptor: HelixPluginDescriptor
    module: ModuleType
    deactivate: Callable[[], None] | None = None
    load_time_ms: float | None = None


_PYPROJECT_VERSION_RE = re.compile(r'^version\\s*=\\s*"(?P<version>[^"]+)"\\s*$')
_BASE_VERSION_RE = re.compile(
    r"^(?P<major>\\d+)(?:\\.(?P<minor>\\d+))?(?:\\.(?P<patch>\\d+))?(?P<rest>.*)$"
)


def _read_pyproject_version() -> str | None:
    start = Path(__file__).resolve()
    pyproject: Path | None = None
    for parent in start.parents:
        candidate = parent / "pyproject.toml"
        if candidate.exists():
            pyproject = candidate
            break
    if pyproject is None:
        return None
    try:
        text = pyproject.read_text(encoding="utf-8")
    except Exception:
        return None
    in_project = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            in_project = line == "[project]"
            continue
        if not in_project:
            continue
        match = _PYPROJECT_VERSION_RE.match(line)
        if match:
            return match.group("version").strip()
    return None


def _host_helix_version() -> str:
    try:
        return metadata.version("helix-governance")
    except metadata.PackageNotFoundError:
        return _read_pyproject_version() or "0.0.0"


def _normalize_version_str(value: str) -> str:
    v = (value or "").strip()
    if v.lower().startswith("v") and len(v) > 1 and v[1].isdigit():
        v = v[1:]
    return v


def _parse_base_version_tuple(value: str) -> tuple[int, int, int]:
    normalized = _normalize_version_str(value)
    if not normalized:
        raise ValueError("empty version")

    try:
        from packaging.version import InvalidVersion as PkgInvalidVersion
        from packaging.version import Version as PkgVersion
    except Exception:
        PkgVersion = None  # type: ignore[assignment]
        PkgInvalidVersion = Exception  # type: ignore[assignment]

    if PkgVersion is not None:
        try:
            ver = PkgVersion(normalized)
            release = tuple(int(x) for x in ver.release)
            if not release:
                raise ValueError("missing numeric release segments")
            if len(release) > 3:
                raise ValueError("too many numeric segments (expected up to 3)")
            major = release[0]
            minor = release[1] if len(release) >= 2 else 0
            patch = release[2] if len(release) >= 3 else 0
            return major, minor, patch
        except PkgInvalidVersion:
            pass
        except Exception:
            pass

    match = _BASE_VERSION_RE.match(normalized)
    if not match:
        raise ValueError("invalid version format (expected digits like 1.2.3)")
    major = int(match.group("major") or "0")
    minor = int(match.group("minor") or "0")
    patch = int(match.group("patch") or "0")
    rest = match.group("rest") or ""
    if rest.startswith("."):
        if len(rest) > 1 and rest[1].isdigit():
            raise ValueError("too many numeric segments (expected up to 3)")

        # When `packaging` isn't available, accept a small subset of common
        # PEP440-style dot suffixes (e.g. ".post4", ".dev0", ".rc1") so host
        # versions like "1.2.post4" still gate correctly. Everything else is
        # rejected to avoid treating "1.2.x" as "1.2.0".
        suffix = rest[1:].lower()
        if suffix.startswith("post"):
            tail = suffix[4:]
            if not tail or tail[0].isdigit():
                return major, minor, patch
        elif suffix.startswith("dev"):
            tail = suffix[3:]
            if not tail or tail[0].isdigit():
                return major, minor, patch
        elif suffix.startswith("rc"):
            tail = suffix[2:]
            if not tail or tail[0].isdigit():
                return major, minor, patch
        elif suffix.startswith("a") and len(suffix) > 1 and suffix[1].isdigit():
            return major, minor, patch
        elif suffix.startswith("b") and len(suffix) > 1 and suffix[1].isdigit():
            return major, minor, patch

        raise ValueError("invalid version format (unexpected dot suffix)")
    return major, minor, patch


def _base_version_str(value: str) -> str:
    major, minor, patch = _parse_base_version_tuple(value)
    return f"{major}.{minor}.{patch}"


def default_plugin_search_paths(project_root: Path) -> list[Path]:
    paths: list[Path] = []
    paths.append(project_root / "plugins")

    if os.environ.get("HELIX_STUDIO_USER_PLUGINS", "0") == "1":
        home = Path.home()
        paths.append(home / ".helix" / "plugins")

    raw = (os.environ.get("HELIX_STUDIO_PLUGIN_PATHS") or "").strip()
    if raw:
        for token in raw.split(os.pathsep):
            token = token.strip()
            if token:
                paths.append(Path(token))

    return paths


class HelixPluginManager:
    def __init__(
        self,
        *,
        search_paths: Sequence[Path],
        api_version: str = HELIX_PLUGIN_API_VERSION,
        host_helix_version: str | None = None,
        disabled: Iterable[str] = (),
    ) -> None:
        self._search_paths = list(search_paths)
        self._api_version = api_version
        self._host_helix_version = (
            (host_helix_version or "").strip() or _host_helix_version()
        )
        try:
            self._host_helix_version_base_tuple = _parse_base_version_tuple(
                self._host_helix_version
            )
            self._host_helix_version_base = (
                f"{self._host_helix_version_base_tuple[0]}."
                f"{self._host_helix_version_base_tuple[1]}."
                f"{self._host_helix_version_base_tuple[2]}"
            )
        except Exception:
            self._host_helix_version_base = "0.0.0"
            self._host_helix_version_base_tuple = (0, 0, 0)
        self._disabled = {str(x).strip().lower() for x in disabled if str(x).strip()}
        self._added_sys_paths: set[str] = set()

        self.discovered: dict[str, HelixPluginDescriptor] = {}
        self.loaded: dict[str, LoadedPlugin] = {}
        self.errors: dict[str, str] = {}

    @property
    def api_version(self) -> str:
        return self._api_version

    @property
    def helix_version(self) -> str:
        return self._host_helix_version

    @property
    def helix_version_base(self) -> str:
        return self._host_helix_version_base

    @property
    def search_paths(self) -> Sequence[Path]:
        return tuple(self._search_paths)

    @property
    def added_sys_paths(self) -> Sequence[str]:
        return tuple(sorted(self._added_sys_paths))

    def is_disabled(self, plugin_id: str) -> bool:
        return (plugin_id or "").strip().lower() in self._disabled

    def set_disabled(self, disabled: Iterable[str]) -> None:
        self._disabled = {str(x).strip().lower() for x in disabled if str(x).strip()}

    def discover(self) -> list[HelixPluginDescriptor]:
        self.discovered.clear()
        self.errors.clear()
        for path in self._search_paths:
            try:
                recover_incomplete_installs(plugins_dir=Path(path))
            except Exception:
                continue
        for candidate in self._iter_manifest_paths(self._search_paths):
            try:
                manifest = load_plugin_manifest(candidate)
            except PluginManifestError as exc:
                self.errors[str(candidate)] = str(exc)
                continue

            if api_major(manifest.api_version) != api_major(self._api_version):
                self.errors[manifest.plugin_id] = (
                    f"{candidate}: incompatible api_version={manifest.api_version} "
                    f"(host={self._api_version})"
                )
                continue
            min_raw = manifest.helix_min_version
            max_raw = manifest.helix_max_version
            min_base: tuple[int, int, int] | None = None
            max_base: tuple[int, int, int] | None = None

            if min_raw:
                try:
                    min_base = _parse_base_version_tuple(min_raw)
                except Exception as exc:
                    self.errors[manifest.plugin_id] = (
                        f"{manifest.plugin_id} ({candidate}): "
                        f"helix_min_version: {min_raw!r} is invalid; expected a "
                        'numeric dotted version like "1.2.3" (use "1", "1.2", or '
                        '"1.2.3"; optional leading "v"). '
                        f"({exc})"
                    )
                    continue

            if max_raw:
                try:
                    max_base = _parse_base_version_tuple(max_raw)
                except Exception as exc:
                    self.errors[manifest.plugin_id] = (
                        f"{manifest.plugin_id} ({candidate}): "
                        f"helix_max_version: {max_raw!r} is invalid; expected a "
                        'numeric dotted version like "1.2.3" (use "1", "1.2", or '
                        '"1.2.3"; optional leading "v"). '
                        f"({exc})"
                    )
                    continue

            if min_base is not None and max_base is not None and min_base > max_base:
                self.errors[manifest.plugin_id] = (
                    f"{manifest.plugin_id} ({candidate}): "
                    "invalid Helix version range: helix_min_version must be <= "
                    "helix_max_version "
                    f"(min={min_raw!r} max={max_raw!r})"
                )
                continue

            host_base = self._host_helix_version_base_tuple
            if min_base is not None and host_base < min_base:
                self.errors[manifest.plugin_id] = (
                    f"{manifest.plugin_id} ({candidate}): "
                    "helix_min_version check failed (inclusive): "
                    f"requires>={min_raw!r} (host_base={self._host_helix_version_base} "
                    f"host={self._host_helix_version})"
                )
                continue
            if max_base is not None and host_base > max_base:
                self.errors[manifest.plugin_id] = (
                    f"{manifest.plugin_id} ({candidate}): "
                    "helix_max_version check failed (inclusive): "
                    f"requires<={max_raw!r} (host_base={self._host_helix_version_base} "
                    f"host={self._host_helix_version})"
                )
                continue

            root = candidate.parent
            desc = HelixPluginDescriptor(
                root=root,
                manifest_path=candidate,
                manifest=manifest,
            )
            if manifest.plugin_id in self.discovered:
                prev = self.discovered[manifest.plugin_id].manifest_path
                self.errors[manifest.plugin_id] = (
                    f"duplicate plugin id '{manifest.plugin_id}' "
                    f"({prev} vs {candidate})"
                )
                continue
            self.discovered[manifest.plugin_id] = desc

        return list(self.discovered.values())

    def load_all(self, host_api: Any) -> list[LoadedPlugin]:
        loaded: list[LoadedPlugin] = []
        for desc in self.discover():
            if desc.plugin_id in self._disabled:
                continue
            plugin = self.load(desc.plugin_id, host_api)
            if plugin is not None:
                loaded.append(plugin)
        return loaded

    def load(self, plugin_id: str, host_api: Any) -> LoadedPlugin | None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return None
        if pid in self.loaded:
            return self.loaded[pid]
        desc = self.discovered.get(pid)
        if desc is None:
            return None

        module_name, func_name = parse_entry(desc.manifest.entry)
        if not module_name:
            self.errors[pid] = (
                f"{desc.manifest_path}: invalid entry={desc.manifest.entry!r}"
            )
            return None

        try:
            self._ensure_sys_path(desc.root)
            module = importlib.import_module(module_name)
            activate = getattr(module, func_name, None)
            if not callable(activate):
                raise RuntimeError(
                    f"entry callable not found: {module_name}:{func_name}"
                )

            start = clock.perf_counter()
            result = activate(host_api)
            load_time_ms = (clock.perf_counter() - start) * 1000.0
            deactivate: Callable[[], None] | None = None
            if callable(result):
                deactivate = result
            elif result is not None:
                try:
                    deactivate_attr = result.deactivate  # type: ignore[attr-defined]
                except Exception:
                    deactivate_attr = None
                if callable(deactivate_attr):
                    deactivate = deactivate_attr
            if deactivate is None:
                try:
                    deactivate_attr = module.deactivate  # type: ignore[attr-defined]
                except Exception:
                    deactivate_attr = None
                if callable(deactivate_attr):
                    deactivate = deactivate_attr  # type: ignore[assignment]

            if deactivate is not None:
                deactivate = _wrap_deactivate(deactivate, host_api)

            loaded = LoadedPlugin(
                descriptor=desc,
                module=module,
                deactivate=deactivate,
                load_time_ms=load_time_ms,
            )
            self.loaded[pid] = loaded
            return loaded
        except Exception:
            self.errors[pid] = traceback.format_exc()
            return None

    def unload(self, plugin_id: str) -> bool:
        pid = (plugin_id or "").strip().lower()
        plugin = self.loaded.pop(pid, None)
        if plugin is None:
            return False
        if plugin.deactivate is not None:
            try:
                plugin.deactivate()
            except Exception:
                self.errors[pid] = traceback.format_exc()
        return True

    def _ensure_sys_path(self, root: Path) -> None:
        # Support common plugin layouts:
        # - <plugin_root>/code/<pkg>/... (packaged plugins)
        # - <plugin_root>/code/src/<pkg>/... (packaged src layout)
        # - <plugin_root>/<pkg>/...
        # - <plugin_root>/src/<pkg>/...
        candidates = [root]
        code = root / "code"
        if code.is_dir():
            candidates.insert(0, code)
            code_src = code / "src"
            if code_src.is_dir():
                candidates.insert(0, code_src)
        src = root / "src"
        if src.is_dir():
            candidates.insert(0, src)

        for candidate in candidates:
            entry = str(candidate)
            if entry in self._added_sys_paths:
                continue
            sys.path.insert(0, entry)
            self._added_sys_paths.add(entry)

    @staticmethod
    def _iter_manifest_paths(search_paths: Sequence[Path]) -> Iterable[Path]:
        seen: set[Path] = set()

        def _yield(path: Path) -> Iterable[Path]:
            resolved = path.resolve()
            if resolved in seen:
                return []
            seen.add(resolved)
            return [resolved]

        for base in search_paths:
            if not base:
                continue
            try:
                base = base.expanduser()
            except Exception:
                pass

            if base.is_file() and base.name.endswith(".json"):
                yield from _yield(base)
                continue

            if base.is_dir():
                direct_manifest = base / DEFAULT_MANIFEST_FILENAME
                if direct_manifest.exists():
                    yield from _yield(direct_manifest)

                try:
                    entries = fs.iterdir_sorted(base, key=lambda p: p.name.lower())
                except OSError:
                    continue
                for entry in entries:
                    if entry.is_dir():
                        manifest = entry / DEFAULT_MANIFEST_FILENAME
                        if manifest.exists():
                            yield from _yield(manifest)
                    elif entry.is_file() and entry.name == DEFAULT_MANIFEST_FILENAME:
                        yield from _yield(entry)


def _wrap_deactivate(fn: Callable[..., Any], host_api: Any) -> Callable[[], None]:
    def _call() -> None:
        try:
            fn()
            return
        except TypeError as exc:
            # Best-effort support for older deactivate(host_api) style.
            msg = str(exc)
            if (
                "required positional argument" not in msg
                and "positional arguments" not in msg
            ):
                raise
        fn(host_api)

    return _call


__all__ = [
    "HelixPluginDescriptor",
    "HelixPluginManager",
    "LoadedPlugin",
    "default_plugin_search_paths",
]
