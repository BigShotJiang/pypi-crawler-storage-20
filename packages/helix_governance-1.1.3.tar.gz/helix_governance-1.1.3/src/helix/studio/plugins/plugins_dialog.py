from __future__ import annotations

import json
import os
import platform
import sys
import zipfile
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from helix import clock
from .installer import (
    PluginInstallError,
    PluginSignaturePolicy,
    install_plugin_package_from_file,
    install_plugin_package_from_url,
    list_cached_versions,
    rollback_plugin,
)
from .manager import HelixPluginManager
from .plugin_package import (
    DEFAULT_PACKAGE_EXTENSION,
    PluginPackageError,
    verify_extracted_plugin_dir,
)
from .registry import PluginRegistryIndex, fetch_registry_index
from .trust_store import PluginTrustStore, default_trust_store_path


class PluginsDialog(QDialog):
    def __init__(self, parent: QWidget, *, manager: HelixPluginManager) -> None:
        super().__init__(parent)
        self._host = parent
        self._manager = manager
        self._env_disabled: set[str] = set()
        self._registry: PluginRegistryIndex | None = None
        self._registry_url: str = ""
        self._trust_store_path = default_trust_store_path()

        self.setWindowTitle("Plugins")
        self.setModal(True)
        self.resize(980, 560)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("Plugins", self)
        title.setStyleSheet("font-weight: 700; font-size: 16px;")
        header.addWidget(title, 1)

        refresh_btn = QPushButton("Refresh", self)
        refresh_btn.clicked.connect(self._refresh)
        header.addWidget(refresh_btn, 0)

        install_file_btn = QPushButton("Install from file…", self)
        install_file_btn.clicked.connect(self._install_from_file)
        header.addWidget(install_file_btn, 0)

        install_url_btn = QPushButton("Install from URL…", self)
        install_url_btn.clicked.connect(self._install_from_url)
        header.addWidget(install_url_btn, 0)

        check_updates_btn = QPushButton("Check updates…", self)
        check_updates_btn.clicked.connect(self._check_updates)
        header.addWidget(check_updates_btn, 0)

        self._update_btn = QPushButton("Update selected", self)
        self._update_btn.clicked.connect(self._update_selected)
        self._update_btn.setEnabled(False)
        header.addWidget(self._update_btn, 0)

        self._rollback_btn = QPushButton("Rollback…", self)
        self._rollback_btn.clicked.connect(self._rollback_selected)
        self._rollback_btn.setEnabled(False)
        header.addWidget(self._rollback_btn, 0)

        self._trust_btn = QPushButton("Trust publisher key", self)
        self._trust_btn.clicked.connect(self._trust_selected)
        self._trust_btn.setEnabled(False)
        header.addWidget(self._trust_btn, 0)

        self._pin_btn = QPushButton("Pin version", self)
        self._pin_btn.clicked.connect(self._toggle_pin_selected)
        self._pin_btn.setEnabled(False)
        header.addWidget(self._pin_btn, 0)

        reload_btn = QPushButton("Reload (soft)", self)
        reload_btn.clicked.connect(lambda: self._call_host("_reload_plugins"))
        header.addWidget(reload_btn, 0)

        self._retry_quarantine_btn = QPushButton("Clear quarantine & retry", self)
        self._retry_quarantine_btn.clicked.connect(self._retry_quarantined_selected)
        self._retry_quarantine_btn.setEnabled(False)
        header.addWidget(self._retry_quarantine_btn, 0)

        restart_btn = QPushButton("Restart (clean)", self)
        restart_btn.clicked.connect(lambda: self._call_host("_restart_studio_clean"))
        header.addWidget(restart_btn, 0)

        open_folder_btn = QPushButton("Open plugins folder", self)
        open_folder_btn.clicked.connect(lambda: self._call_host("_open_plugins_folder"))
        header.addWidget(open_folder_btn, 0)

        export_btn = QPushButton("Save diagnostics bundle…", self)
        export_btn.clicked.connect(self._save_diagnostics_bundle)
        header.addWidget(export_btn, 0)

        close_btn = QPushButton("Close", self)
        close_btn.clicked.connect(self.accept)
        header.addWidget(close_btn, 0)

        layout.addLayout(header)

        paths = ", ".join(str(p) for p in manager.search_paths)
        subtitle = QLabel(f"Search paths: {paths}", self)
        subtitle.setTextInteractionFlags(Qt.TextSelectableByMouse)
        subtitle.setStyleSheet("color: rgba(203,213,225,0.75);")
        layout.addWidget(subtitle)

        versions = QLabel(
            self._version_label(manager),
            self,
        )
        versions.setStyleSheet("color: rgba(203,213,225,0.75);")
        layout.addWidget(versions)

        warning = QLabel(
            "Security: plugins run arbitrary code "
            "(in-process plugins run in the Studio UI process; "
            "extension-host plugins run in a separate process). "
            "Capabilities are API gating only, not an OS sandbox. "
            "Only enable trusted plugins.",
            self,
        )
        warning.setWordWrap(True)
        warning.setStyleSheet("color: rgba(230,106,106,0.95);")
        layout.addWidget(warning)

        self._quarantine_banner = QLabel("", self)
        self._quarantine_banner.setWordWrap(True)
        self._quarantine_banner.setStyleSheet(
            "color: rgba(230,106,106,0.95); font-weight: 600;"
        )
        self._quarantine_banner.hide()
        layout.addWidget(self._quarantine_banner)

        splitter = QSplitter(Qt.Horizontal, self)
        layout.addWidget(splitter, 1)

        left = QWidget(splitter)
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        self._table = QTableWidget(left)
        self._table.setColumnCount(7)
        self._table.setHorizontalHeaderLabels(
            ["Enabled", "ID", "Name", "Version", "Status", "Load ms", "Path"]
        )
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setSelectionMode(QAbstractItemView.SingleSelection)
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.verticalHeader().setVisible(False)
        self._table.itemSelectionChanged.connect(self._on_selection_changed)
        self._table.itemChanged.connect(self._on_item_changed)
        left_layout.addWidget(self._table, 1)

        self._other_errors = QPlainTextEdit(left)
        self._other_errors.setReadOnly(True)
        self._other_errors.setPlaceholderText("Plugin discovery/load errors…")
        self._other_errors.setMaximumBlockCount(2000)
        left_layout.addWidget(self._other_errors, 1)

        right = QWidget(splitter)
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        self._details = QPlainTextEdit(right)
        self._details.setReadOnly(True)
        self._details.setPlaceholderText("Select a plugin to see details…")
        self._details.setMaximumBlockCount(4000)
        right_layout.addWidget(QLabel("Details", right))
        right_layout.addWidget(self._details, 2)

        self._logs = QPlainTextEdit(right)
        self._logs.setReadOnly(True)
        self._logs.setPlaceholderText("Plugin logs (host_api.log)…")
        self._logs.setMaximumBlockCount(4000)
        right_layout.addWidget(QLabel("Logs", right))
        right_layout.addWidget(self._logs, 1)

        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 4)

        self._refresh()

    @staticmethod
    def _version_label(manager: HelixPluginManager) -> str:
        helix = manager.helix_version
        base = getattr(manager, "helix_version_base", helix)
        base_str = str(base or "").strip()
        if base_str and base_str != helix:
            return (
                f"Helix: {helix} (base {base_str}) • Plugin API: {manager.api_version}"
            )
        return f"Helix: {helix} • Plugin API: {manager.api_version}"

    def _call_host(self, name: str) -> None:
        fn = getattr(self._host, name, None)
        if callable(fn):
            fn()

    def _effective_disabled(self) -> set[str]:
        fn = getattr(self._host, "_effective_disabled_plugins", None)
        if callable(fn):
            try:
                return set(fn())
            except Exception:
                return set()
        return set()

    def _settings_disabled(self) -> set[str]:
        fn = getattr(self._host, "_settings_disabled_plugins", None)
        if callable(fn):
            try:
                return set(fn())
            except Exception:
                return set()
        return set()

    def _settings_value(self, key: str, default: object = "") -> object:
        settings = getattr(self._host, "_settings", None)
        if settings is None:
            return default
        try:
            return settings.value(key, default)
        except Exception:
            return default

    def _settings_set(self, key: str, value: object) -> None:
        settings = getattr(self._host, "_settings", None)
        if settings is None:
            return
        try:
            settings.setValue(key, value)
        except Exception:
            return

    def _project_plugins_dir(self) -> Path:
        try:
            root = getattr(self._host, "ctx").project_root  # type: ignore[attr-defined]
            return Path(root) / "plugins"
        except Exception:
            return Path.cwd() / "plugins"

    @staticmethod
    def _user_plugins_dir() -> Path:
        return Path.home() / ".helix" / "plugins"

    def _pinned_version(self, plugin_id: str) -> str | None:
        pid = str(plugin_id or "").strip().lower()
        if not pid:
            return None
        key = f"plugins/pins/{pid}"
        raw = str(self._settings_value(key, "") or "").strip()
        return raw or None

    def _set_pinned_version(self, plugin_id: str, version: str | None) -> None:
        pid = str(plugin_id or "").strip().lower()
        if not pid:
            return
        key = f"plugins/pins/{pid}"
        self._settings_set(key, (version or "").strip())

    def _choose_install_dir(self) -> Path | None:
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle("Install plugin")
        box.setText("Install this plugin package to:")
        user_btn = box.addButton(
            f"User ({self._user_plugins_dir()})", QMessageBox.AcceptRole
        )
        proj_btn = box.addButton(
            f"Project ({self._project_plugins_dir()})", QMessageBox.AcceptRole
        )
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.setDefaultButton(proj_btn)
        box.exec()

        clicked = box.clickedButton()
        if clicked == user_btn:
            return self._user_plugins_dir()
        if clicked == proj_btn:
            return self._project_plugins_dir()
        return None

    def _infer_plugins_dir_for(self, desc) -> Path | None:
        try:
            root = Path(desc.root).resolve()
        except Exception:
            return None
        proj = self._project_plugins_dir().resolve()
        user = self._user_plugins_dir().resolve()
        try:
            if str(root).startswith(str(proj)):
                return proj
            if str(root).startswith(str(user)):
                return user
        except Exception:
            pass
        return None

    def _registry_url_default(self) -> str:
        env = str(os.environ.get("HELIX_STUDIO_PLUGIN_REGISTRY_URL") or "").strip()
        if env:
            return env
        return str(self._settings_value("plugins/registry_url", "") or "").strip()

    def _update_available_version(self, pid: str, current_version: str) -> str | None:
        if self._registry is None:
            return None
        if self._pinned_version(pid):
            return None
        plugin = self._registry.get(pid)
        rel = plugin.latest() if plugin is not None else None
        if rel is None:
            return None
        try:
            from packaging.version import Version

            if Version(rel.version) > Version(current_version):
                return rel.version
            return None
        except Exception:
            return rel.version if rel.version != current_version else None

    def _refresh(self) -> None:
        quarantine: dict[str, str] = {}
        qfn = getattr(self._host, "_quarantined_plugins", None)
        if callable(qfn):
            try:
                quarantine = dict(qfn())
            except Exception:
                quarantine = {}
        if quarantine:
            ids = ", ".join(sorted(quarantine.keys()))
            self._quarantine_banner.setText(
                "Quarantined (auto-disabled): "
                f"{ids}\n"
                "Re-enable a plugin to clear quarantine and try again."
            )
            self._quarantine_banner.show()
        else:
            self._quarantine_banner.hide()

        discovered = sorted(
            self._manager.discovered.values(),
            key=lambda d: d.plugin_id,
        )
        loaded = self._manager.loaded
        errors = self._manager.errors
        disabled = self._effective_disabled()
        settings_disabled = self._settings_disabled()
        env_disabled = disabled - settings_disabled
        self._env_disabled = set(env_disabled)

        self._table.blockSignals(True)
        self._table.setRowCount(len(discovered))

        for row, desc in enumerate(discovered):
            pid = desc.plugin_id
            manifest = desc.manifest
            is_enabled = pid not in disabled

            status = "discovered"
            load_ms = ""
            if pid in disabled:
                status = "quarantined" if pid in quarantine else "disabled"
            elif pid in loaded:
                status = "loaded"
                ms = loaded[pid].load_time_ms
                load_ms = f"{ms:.1f}" if ms is not None else ""
            elif pid in errors:
                status = "error"

            upd = self._update_available_version(pid, manifest.version)
            if upd:
                status = f"{status} (update {upd})"

            enabled_item = QTableWidgetItem("")
            enabled_item.setData(Qt.UserRole, pid)
            flags = Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsUserCheckable
            if pid in env_disabled:
                flags = Qt.ItemIsSelectable | Qt.ItemIsEnabled
                enabled_item.setToolTip("Disabled by HELIX_STUDIO_DISABLED_PLUGINS")
            enabled_item.setFlags(flags)
            enabled_item.setCheckState(Qt.Checked if is_enabled else Qt.Unchecked)
            self._table.setItem(row, 0, enabled_item)

            self._table.setItem(row, 1, QTableWidgetItem(pid))
            self._table.setItem(row, 2, QTableWidgetItem(manifest.name))
            self._table.setItem(row, 3, QTableWidgetItem(manifest.version))
            self._table.setItem(row, 4, QTableWidgetItem(status))
            self._table.setItem(row, 5, QTableWidgetItem(load_ms))
            self._table.setItem(row, 6, QTableWidgetItem(str(desc.manifest_path)))

        self._table.blockSignals(False)
        self._table.resizeColumnsToContents()

        other = []
        discovered_ids = {d.plugin_id for d in discovered}
        for key, err in sorted(errors.items(), key=lambda kv: str(kv[0])):
            if key in discovered_ids:
                continue
            other.append(f"{key}\n{err}".rstrip())
        self._other_errors.setPlainText("\n\n".join(other).strip())

        if self._table.currentRow() < 0 and self._table.rowCount() > 0:
            self._table.setCurrentCell(0, 1)
        self._update_details()

    def _retry_quarantined_selected(self) -> None:
        pid = self._selected_plugin_id()
        if not pid:
            return
        if pid in self._env_disabled:
            QMessageBox.information(
                self,
                "Plugins",
                "This plugin is disabled by HELIX_STUDIO_DISABLED_PLUGINS and cannot "
                "be re-enabled from the UI.",
            )
            return
        setter = getattr(self._host, "_set_plugin_enabled", None)
        if callable(setter):
            try:
                setter(pid, True)
            except Exception:
                return
        self._call_host("_reload_plugins")
        self._refresh()

    def _on_item_changed(self, item: QTableWidgetItem) -> None:
        if item.column() != 0:
            return
        pid = item.data(Qt.UserRole)
        if not isinstance(pid, str) or not pid:
            return
        enabled = item.checkState() == Qt.Checked
        setter = getattr(self._host, "_set_plugin_enabled", None)
        if callable(setter):
            try:
                setter(pid, enabled)
            except Exception:
                return
        self._call_host("_reload_plugins")
        self._refresh()

    def _on_selection_changed(self) -> None:
        self._update_details()

    def _selected_plugin_id(self) -> str | None:
        row = self._table.currentRow()
        if row < 0:
            return None
        item = self._table.item(row, 1)
        if item is None:
            return None
        value = (item.text() or "").strip()
        return value or None

    def _update_details(self) -> None:
        pid = self._selected_plugin_id()
        if pid is None:
            self._details.clear()
            self._logs.clear()
            try:
                self._retry_quarantine_btn.setEnabled(False)
            except Exception:
                pass
            try:
                self._update_btn.setEnabled(False)
                self._rollback_btn.setEnabled(False)
                self._trust_btn.setEnabled(False)
                self._pin_btn.setEnabled(False)
            except Exception:
                pass
            return

        desc = self._manager.discovered.get(pid)
        loaded = self._manager.loaded.get(pid)
        err = self._manager.errors.get(pid)
        disabled = pid in self._effective_disabled()
        pinned = self._pinned_version(pid)

        publisher: str | None = None
        signature_present = False
        public_key_b64: str | None = None
        signature_status: str | None = None
        trust_store: PluginTrustStore | None = None
        try:
            trust_store = PluginTrustStore.load(self._trust_store_path)
        except Exception:
            trust_store = None

        parts: list[str] = []
        parts.append(f"id: {pid}")
        if desc is not None:
            parts.append(f"name: {desc.manifest.name}")
            parts.append(f"version: {desc.manifest.version}")
            if desc.manifest.publisher:
                publisher = desc.manifest.publisher
                parts.append(f"publisher: {publisher}")
            parts.append(f"api_version: {desc.manifest.api_version}")
            parts.append(f"isolation: {desc.manifest.isolation}")
            if desc.manifest.extension_host_mode:
                parts.append(
                    f"extension_host_mode: {desc.manifest.extension_host_mode}"
                )
            if desc.manifest.helix_min_version:
                parts.append(f"helix_min_version: {desc.manifest.helix_min_version}")
            if desc.manifest.helix_max_version:
                parts.append(f"helix_max_version: {desc.manifest.helix_max_version}")
            parts.append(f"entry: {desc.manifest.entry}")
            parts.append(f"path: {desc.manifest_path}")
            parts.append(f"root: {desc.root}")
            if desc.manifest.permissions is not None:
                parts.append(f"permissions: {dict(desc.manifest.permissions)}")
            if pinned:
                parts.append(f"pinned_version: {pinned}")
            if self._registry is not None:
                plugin = self._registry.get(pid)
                rel = plugin.latest() if plugin is not None else None
                if rel is not None and rel.version != desc.manifest.version:
                    parts.append(f"registry_latest: {rel.version}")

            root = Path(desc.root)
            if (root / "HASHES.json").is_file():
                parts.append("")
                parts.append("package: extracted")
                sig_path = root / "SIGNATURE.ed25519"
                pub_path = root / "PUBLISHER.pub"
                signature_present = sig_path.is_file() and pub_path.is_file()
                if signature_present:
                    try:
                        public_key_b64 = (
                            pub_path.read_text(encoding="utf-8").strip() or None
                        )
                    except Exception:
                        public_key_b64 = None
                    if (
                        trust_store is not None
                        and publisher
                        and public_key_b64
                        and trust_store.is_trusted(
                            publisher=publisher,
                            public_key_b64=public_key_b64,
                        )
                    ):
                        signature_status = "trusted"
                    else:
                        signature_status = "untrusted"
                else:
                    signature_status = "unsigned"
                parts.append(f"signature: {signature_status}")
                if signature_present and public_key_b64:
                    parts.append(f"publisher_key_b64: {public_key_b64}")
        parts.append(f"status: {'disabled' if disabled else 'enabled'}")
        qinfo = None
        qfn = getattr(self._host, "_plugin_quarantine_info", None)
        if callable(qfn):
            try:
                qinfo = qfn(pid)
            except Exception:
                qinfo = None
        else:
            try:
                qreason_fn = self._host._plugin_quarantine_reason  # type: ignore[attr-defined]
            except Exception:
                qreason_fn = None
            if callable(qreason_fn):
                try:
                    qreason = qreason_fn(pid)
                    qinfo = {"reason": qreason} if qreason else None
                except Exception:
                    qinfo = None
        if isinstance(qinfo, dict):
            reason = str(qinfo.get("reason") or "").strip()
            at = str(qinfo.get("at") or "").strip()
            if reason:
                parts.append(f"quarantine_reason: {reason}")
            if at:
                parts.append(f"quarantine_at: {at}")
        try:
            can_retry = bool(qinfo) and pid not in self._env_disabled
            self._retry_quarantine_btn.setEnabled(can_retry)
        except Exception:
            pass
        progress = None
        progress_map = getattr(self._host, "_plugin_progress", None)
        if isinstance(progress_map, dict):
            progress = progress_map.get(pid)
        if isinstance(progress, str) and progress.strip():
            parts.append(f"last_progress: {progress.strip()}")
        viol_map = getattr(self._host, "_plugin_policy_violations", None)
        if isinstance(viol_map, dict):
            try:
                count = int(viol_map.get(pid, 0))
            except Exception:
                count = 0
            if count > 0:
                parts.append(f"policy_violations: {count}")
        if loaded is not None:
            parts.append(f"module: {loaded.module.__name__}")
            if loaded.load_time_ms is not None:
                parts.append(f"load_time_ms: {loaded.load_time_ms:.1f}")
        if err:
            parts.append("")
            parts.append("last_error:")
            parts.append(err.rstrip())

        self._details.setPlainText("\n".join(parts).strip())

        self._logs.setPlainText(self._plugin_logs_text(pid))

        # Button enablement / labels.
        try:
            self._pin_btn.setEnabled(desc is not None)
            self._pin_btn.setText("Unpin version" if pinned else "Pin version")
        except Exception:
            pass
        try:
            if desc is None or self._registry is None:
                self._update_btn.setEnabled(False)
            else:
                upd = self._update_available_version(pid, desc.manifest.version)
                can_update = bool(upd) and self._infer_plugins_dir_for(desc) is not None
                self._update_btn.setEnabled(can_update)
        except Exception:
            pass
        try:
            can_rollback = False
            if desc is not None:
                base = self._infer_plugins_dir_for(desc)
                if base is not None:
                    cached = list_cached_versions(plugins_dir=base, plugin_id=pid)
                    can_rollback = bool(cached)
            self._rollback_btn.setEnabled(can_rollback)
        except Exception:
            pass
        try:
            can_trust = bool(
                signature_present
                and publisher
                and public_key_b64
                and signature_status == "untrusted"
            )
            self._trust_btn.setEnabled(can_trust)
        except Exception:
            pass

    @staticmethod
    def _sorted_versions(versions: list[str]) -> list[str]:
        try:
            from packaging.version import Version

            return sorted(versions, key=Version, reverse=True)
        except Exception:
            return sorted(versions, key=str.lower, reverse=True)

    def _install_from_file(self) -> None:
        plugins_dir = self._choose_install_dir()
        if plugins_dir is None:
            return

        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Install plugin package",
            str(Path.cwd()),
            f"Helix plugin package (*{DEFAULT_PACKAGE_EXTENSION})",
        )
        if not path_str:
            return

        try:
            res = install_plugin_package_from_file(
                Path(path_str),
                plugins_dir=plugins_dir,
                trust_store_path=self._trust_store_path,
                policy=PluginSignaturePolicy.from_env(),
            )
        except PluginInstallError as exc:
            QMessageBox.critical(self, "Plugins", f"Install failed:\n{exc}")
            return

        if res.plugin_id not in self._env_disabled:
            setter = getattr(self._host, "_set_plugin_enabled", None)
            if callable(setter):
                try:
                    setter(res.plugin_id, True)
                except Exception:
                    pass

        self._call_host("_reload_plugins")
        self._refresh()

        note = ""
        if plugins_dir.resolve() == self._user_plugins_dir().resolve():
            if os.environ.get("HELIX_STUDIO_USER_PLUGINS", "0") != "1":
                note = "\n\nNote: set HELIX_STUDIO_USER_PLUGINS=1 to load user plugins."
        QMessageBox.information(
            self,
            "Plugins",
            f"Installed {res.plugin_id} {res.version}\nSignature: {res.signature_status}{note}",
        )

    def _install_from_url(self) -> None:
        plugins_dir = self._choose_install_dir()
        if plugins_dir is None:
            return

        default_url = str(self._settings_value("plugins/install_url_last", "") or "")
        url, ok = QInputDialog.getText(
            self,
            "Install plugin from URL",
            "Plugin package URL:",
            text=default_url,
        )
        if not ok or not str(url).strip():
            return
        url = str(url).strip()
        self._settings_set("plugins/install_url_last", url)

        expected_sha, _ok2 = QInputDialog.getText(
            self,
            "Install plugin from URL",
            "Expected SHA256 (optional):",
            text="",
        )
        expected_sha = str(expected_sha or "").strip() or None

        try:
            res = install_plugin_package_from_url(
                url,
                plugins_dir=plugins_dir,
                expected_sha256=expected_sha,
                trust_store_path=self._trust_store_path,
                policy=PluginSignaturePolicy.from_env(),
            )
        except PluginInstallError as exc:
            QMessageBox.critical(self, "Plugins", f"Install failed:\n{exc}")
            return

        if res.plugin_id not in self._env_disabled:
            setter = getattr(self._host, "_set_plugin_enabled", None)
            if callable(setter):
                try:
                    setter(res.plugin_id, True)
                except Exception:
                    pass

        self._call_host("_reload_plugins")
        self._refresh()
        QMessageBox.information(
            self,
            "Plugins",
            f"Installed {res.plugin_id} {res.version}\nSignature: {res.signature_status}",
        )

    def _check_updates(self) -> None:
        default_url = self._registry_url_default()
        url, ok = QInputDialog.getText(
            self,
            "Plugin registry",
            "Registry index URL:",
            text=default_url,
        )
        if not ok:
            return
        url = str(url or "").strip()
        if not url:
            return

        try:
            reg = fetch_registry_index(url)
        except Exception as exc:
            QMessageBox.critical(self, "Plugins", f"Failed to fetch registry:\n{exc}")
            return

        self._registry = reg
        self._registry_url = url
        self._settings_set("plugins/registry_url", url)
        self._refresh()
        QMessageBox.information(
            self,
            "Plugins",
            f"Loaded registry ({len(reg.plugins)} plugins).",
        )

    def _update_selected(self) -> None:
        pid = self._selected_plugin_id()
        if not pid:
            return
        desc = self._manager.discovered.get(pid)
        if desc is None:
            return
        if self._registry is None:
            QMessageBox.information(
                self, "Plugins", "No registry loaded. Click “Check updates…” first."
            )
            return
        if self._pinned_version(pid):
            QMessageBox.information(
                self, "Plugins", "This plugin is pinned; updates are disabled."
            )
            return

        plugin = self._registry.get(pid)
        rel = plugin.latest() if plugin is not None else None
        if rel is None or rel.version == desc.manifest.version:
            QMessageBox.information(self, "Plugins", "No update available.")
            return

        plugins_dir = self._infer_plugins_dir_for(desc)
        if plugins_dir is None:
            QMessageBox.information(
                self,
                "Plugins",
                "Update is only supported for plugins installed in the project or user plugins folder.",
            )
            return

        res = QMessageBox.question(
            self,
            "Update plugin",
            f"Update {pid} from {desc.manifest.version} → {rel.version}?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if res != QMessageBox.Yes:
            return

        try:
            result = install_plugin_package_from_url(
                rel.url,
                plugins_dir=plugins_dir,
                expected_sha256=rel.sha256,
                trust_store_path=self._trust_store_path,
                policy=PluginSignaturePolicy.from_env(),
            )
        except PluginInstallError as exc:
            QMessageBox.critical(self, "Plugins", f"Update failed:\n{exc}")
            return

        self._call_host("_reload_plugins")
        self._refresh()
        QMessageBox.information(
            self,
            "Plugins",
            f"Updated {result.plugin_id} to {result.version}\nSignature: {result.signature_status}",
        )

    def _rollback_selected(self) -> None:
        pid = self._selected_plugin_id()
        if not pid:
            return
        desc = self._manager.discovered.get(pid)
        if desc is None:
            return

        plugins_dir = self._infer_plugins_dir_for(desc)
        if plugins_dir is None:
            QMessageBox.information(
                self,
                "Plugins",
                "Rollback is only supported for plugins installed in the project or user plugins folder.",
            )
            return

        versions = list_cached_versions(plugins_dir=plugins_dir, plugin_id=pid)
        versions = self._sorted_versions(versions)
        if not versions:
            QMessageBox.information(
                self, "Plugins", "No cached versions available for rollback."
            )
            return

        chosen, ok = QInputDialog.getItem(
            self,
            "Rollback plugin",
            "Select version:",
            versions,
            editable=False,
        )
        if not ok:
            return
        target = str(chosen or "").strip()
        if not target or target == desc.manifest.version:
            return

        try:
            result = rollback_plugin(
                pid,
                plugins_dir=plugins_dir,
                version=target,
                trust_store_path=self._trust_store_path,
                policy=PluginSignaturePolicy.from_env(),
            )
        except PluginInstallError as exc:
            QMessageBox.critical(self, "Plugins", f"Rollback failed:\n{exc}")
            return

        self._call_host("_reload_plugins")
        self._refresh()
        QMessageBox.information(
            self,
            "Plugins",
            f"Rolled back {result.plugin_id} to {result.version}\nSignature: {result.signature_status}",
        )

    def _trust_selected(self) -> None:
        pid = self._selected_plugin_id()
        if not pid:
            return
        desc = self._manager.discovered.get(pid)
        if desc is None:
            return
        if not desc.manifest.publisher:
            QMessageBox.information(
                self, "Plugins", "Manifest must include publisher to trust a key."
            )
            return

        try:
            verification = verify_extracted_plugin_dir(Path(desc.root))
        except PluginPackageError as exc:
            QMessageBox.information(self, "Plugins", f"Not a packaged plugin:\n{exc}")
            return

        if not verification.signature_present or not verification.public_key_b64:
            QMessageBox.information(self, "Plugins", "This plugin package is not signed.")
            return

        store = PluginTrustStore.load(self._trust_store_path)
        if store.is_trusted(
            publisher=desc.manifest.publisher,
            public_key_b64=verification.public_key_b64,
        ):
            QMessageBox.information(self, "Plugins", "Publisher key is already trusted.")
            return

        res = QMessageBox.question(
            self,
            "Trust publisher key",
            f"Trust publisher “{desc.manifest.publisher}” for future installs/updates?\n\n"
            "This allows signed packages from this key to be treated as trusted.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if res != QMessageBox.Yes:
            return

        try:
            store.trust(
                publisher=desc.manifest.publisher,
                public_key_b64=verification.public_key_b64,
            )
            store.save(self._trust_store_path)
        except Exception as exc:
            QMessageBox.critical(self, "Plugins", f"Failed to save trust store:\n{exc}")
            return

        self._refresh()

    def _toggle_pin_selected(self) -> None:
        pid = self._selected_plugin_id()
        if not pid:
            return
        desc = self._manager.discovered.get(pid)
        if desc is None:
            return

        pinned = self._pinned_version(pid)
        if pinned:
            self._set_pinned_version(pid, None)
        else:
            self._set_pinned_version(pid, desc.manifest.version)
        self._refresh()

    def _plugin_log_path(self, plugin_id: str) -> Path | None:
        fn = getattr(self._host, "_plugin_log_path", None)
        if callable(fn):
            try:
                path = fn(plugin_id)
                return Path(path) if path else None
            except Exception:
                return None
        return None

    def _plugin_logs_text(self, plugin_id: str) -> str:
        path = self._plugin_log_path(plugin_id)
        if path is not None and path.exists():
            try:
                return _read_tail(path, 250_000)
            except Exception:
                pass
        plugin_logs = getattr(self._host, "_plugin_logs", None)
        if isinstance(plugin_logs, dict):
            lines = plugin_logs.get(plugin_id, [])
            if isinstance(lines, list):
                return "\n".join(str(x) for x in lines if str(x).strip()).strip()
        return ""

    def _save_diagnostics_bundle(self) -> None:
        stamp = clock.utc_now_stamp()
        default_name = str(Path.cwd() / f"helix_plugins_diagnostics_{stamp}.zip")
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            "Save plugins diagnostics bundle",
            default_name,
            "Zip archive (*.zip)",
        )
        if not path_str:
            return
        out = Path(path_str)
        if out.suffix.lower() != ".zip":
            out = out.with_suffix(".zip")

        try:
            self._write_bundle(out)
            QMessageBox.information(
                self,
                "Plugins",
                f"Saved diagnostics bundle:\n{out}",
            )
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Plugins",
                f"Failed to write diagnostics bundle: {exc}",
            )

    def _write_bundle(self, out: Path) -> None:
        disabled = self._effective_disabled()
        discovered = sorted(
            self._manager.discovered.values(),
            key=lambda d: d.plugin_id,
        )
        enabled_ids = [d.plugin_id for d in discovered if d.plugin_id not in disabled]
        loaded = self._manager.loaded
        errors = self._manager.errors

        def _writestr(zf: zipfile.ZipFile, name: str, text: str) -> None:
            zf.writestr(name, text.encode("utf-8"))

        meta = {
            "created_at": clock.utc_now_iso_offset(),
            "helix_version": self._manager.helix_version,
            "helix_version_base": getattr(
                self._manager, "helix_version_base", self._manager.helix_version
            ),
            "python": {
                "version": platform.python_version(),
                "implementation": platform.python_implementation(),
                "executable": sys.executable,
            },
            "os": {
                "platform": platform.platform(),
                "system": platform.system(),
                "release": platform.release(),
                "machine": platform.machine(),
            },
            "plugin_api_version": self._manager.api_version,
            "search_paths": [str(p) for p in self._manager.search_paths],
            "plugin_sys_paths": list(getattr(self._manager, "added_sys_paths", ())),
            "env": {
                "HELIX_STUDIO_PLUGINS": (os.environ.get("HELIX_STUDIO_PLUGINS") or ""),
                "HELIX_STUDIO_USER_PLUGINS": (
                    os.environ.get("HELIX_STUDIO_USER_PLUGINS") or ""
                ),
                "HELIX_STUDIO_PLUGIN_PATHS": (
                    os.environ.get("HELIX_STUDIO_PLUGIN_PATHS") or ""
                ),
                "HELIX_STUDIO_DISABLED_PLUGINS": (
                    os.environ.get("HELIX_STUDIO_DISABLED_PLUGINS") or ""
                ),
                "HELIX_STUDIO_PLUGIN_REGISTRY_URL": (
                    os.environ.get("HELIX_STUDIO_PLUGIN_REGISTRY_URL") or ""
                ),
                "HELIX_STUDIO_PLUGIN_REQUIRE_SIGNED": (
                    os.environ.get("HELIX_STUDIO_PLUGIN_REQUIRE_SIGNED") or ""
                ),
                "HELIX_STUDIO_PLUGIN_REQUIRE_TRUSTED": (
                    os.environ.get("HELIX_STUDIO_PLUGIN_REQUIRE_TRUSTED") or ""
                ),
                "HELIX_STUDIO_EXTENSION_HOST": (
                    os.environ.get("HELIX_STUDIO_EXTENSION_HOST") or ""
                ),
                "HELIX_STUDIO_EXTENSION_HOST_MODE": (
                    os.environ.get("HELIX_STUDIO_EXTENSION_HOST_MODE") or ""
                ),
            },
            "disabled": sorted(disabled),
            "enabled": sorted(enabled_ids),
            "discovered": [d.plugin_id for d in discovered],
            "load_order": enabled_ids,
            "loaded": sorted(loaded.keys()),
            "plugin_registry_url": self._registry_url_default(),
            "trust_store_path": str(self._trust_store_path),
            "pinned_versions": {
                d.plugin_id: self._pinned_version(d.plugin_id) for d in discovered
            },
        }
        try:
            fn = getattr(self._host, "_extension_host_stats", None)
            if callable(fn):
                meta["extension_host"] = fn()
        except Exception:
            pass

        trust_store = None
        try:
            trust_store = PluginTrustStore.load(self._trust_store_path)
        except Exception:
            trust_store = None

        out.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            _writestr(zf, "meta.json", json.dumps(meta, indent=2))

            for desc in discovered:
                pid = desc.plugin_id
                base = f"plugins/{pid}"
                pinned = self._pinned_version(pid)

                pkg = None
                try:
                    if (Path(desc.root) / "HASHES.json").is_file():
                        verification = verify_extracted_plugin_dir(Path(desc.root))
                        sig_status = (
                            "unsigned" if not verification.signature_present else "untrusted"
                        )
                        if (
                            verification.signature_present
                            and trust_store is not None
                            and trust_store.is_trusted(
                                publisher=desc.manifest.publisher,
                                public_key_b64=verification.public_key_b64,
                            )
                        ):
                            sig_status = "trusted"
                        pkg = {
                            "signature_present": verification.signature_present,
                            "public_key_b64": verification.public_key_b64,
                            "signature_status": sig_status,
                        }
                except Exception as exc:
                    pkg = {"error": str(exc)}
                qinfo = None
                qfn = getattr(self._host, "_plugin_quarantine_info", None)
                if callable(qfn):
                    try:
                        qinfo = qfn(pid)
                    except Exception:
                        qinfo = None
                qreason = (
                    str(qinfo.get("reason") or "").strip()
                    if isinstance(qinfo, dict)
                    else ""
                )
                qat = (
                    str(qinfo.get("at") or "").strip()
                    if isinstance(qinfo, dict)
                    else ""
                )
                status = {
                    "id": pid,
                    "name": desc.manifest.name,
                    "version": desc.manifest.version,
                    "publisher": desc.manifest.publisher,
                    "plugin_api": desc.manifest.api_version,
                    "entry": desc.manifest.entry,
                    "isolation": desc.manifest.isolation,
                    "pinned_version": pinned,
                    "extension_host_mode": desc.manifest.extension_host_mode,
                    "helix_min_version": desc.manifest.helix_min_version,
                    "helix_max_version": desc.manifest.helix_max_version,
                    "manifest_path": str(desc.manifest_path),
                    "root": str(desc.root),
                    "enabled": pid not in disabled,
                    "loaded": pid in loaded,
                    "load_time_ms": loaded[pid].load_time_ms if pid in loaded else None,
                    "quarantined": bool(qreason),
                    "quarantine_reason": qreason or None,
                    "quarantine_at": qat or None,
                    "package": pkg,
                }
                _writestr(zf, f"{base}/status.json", json.dumps(status, indent=2))

                try:
                    _writestr(
                        zf,
                        f"{base}/helix_plugin.json",
                        desc.manifest_path.read_text(encoding="utf-8"),
                    )
                except Exception:
                    pass

                log_text = self._plugin_logs_text(pid)
                if log_text.strip():
                    _writestr(zf, f"{base}/logs.txt", log_text)

                err = errors.get(pid)
                if err:
                    _writestr(zf, f"{base}/error.txt", err)

            other = []
            discovered_ids = {d.plugin_id for d in discovered}
            for key, err in sorted(errors.items(), key=lambda kv: str(kv[0])):
                if key in discovered_ids:
                    continue
                other.append(f"{key}\n{err}".rstrip())
            if other:
                _writestr(zf, "errors.txt", "\n\n".join(other))


def _read_tail(path: Path, max_bytes: int) -> str:
    size = path.stat().st_size
    offset = max(0, size - max_bytes)
    with path.open("rb") as f:
        f.seek(offset)
        data = f.read()
    if offset > 0:
        nl = data.find(b"\n")
        if nl >= 0:
            data = data[nl + 1 :]
    return data.decode("utf-8", errors="replace")


__all__ = ["PluginsDialog"]
