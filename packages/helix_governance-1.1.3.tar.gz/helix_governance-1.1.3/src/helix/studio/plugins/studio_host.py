from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from PySide6.QtCore import QSettings, QStandardPaths, Qt, QThread, QTimer
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import QDockWidget, QMainWindow, QMenu, QWidget

from helix.studio.commands import CommandRegistry, HelixCommand
from helix.studio.dock_panels import DockPanelRegistry


def _norm_menu_title(title: str) -> str:
    return (title or "").replace("&", "").strip().lower()


def _dock_area(area: str) -> Qt.DockWidgetArea:
    value = (area or "").strip().lower()
    if value in {"left", "l"}:
        return Qt.LeftDockWidgetArea
    if value in {"right", "r"}:
        return Qt.RightDockWidgetArea
    if value in {"top", "t"}:
        return Qt.TopDockWidgetArea
    return Qt.BottomDockWidgetArea


@dataclass(frozen=True, slots=True)
class _TrackedAction:
    action: QAction
    menu: QMenu | None


@dataclass(frozen=True, slots=True)
class _TrackedDock:
    dock: QDockWidget
    toggle_action: QAction | None
    menu: QMenu | None


@dataclass(frozen=True, slots=True)
class _EventSubscription:
    token: int
    topic: str
    plugin_id: str
    handler: Callable[..., None]


class StudioPluginHost:
    """Host integration for in-process Studio plugins (Layer 1)."""

    def __init__(
        self,
        window: QMainWindow,
        command_registry: CommandRegistry,
        dock_registry: DockPanelRegistry,
        *,
        log_fn: Callable[[str, str], None] | None = None,
    ) -> None:
        self._window = window
        self._commands = command_registry
        self._dock_panels = dock_registry
        self._actions: dict[str, list[_TrackedAction]] = {}
        self._docks: dict[str, list[_TrackedDock]] = {}
        self._log_fn = log_fn
        self._event_next_token = 1
        self._event_subs_by_topic: dict[str, list[_EventSubscription]] = {}
        self._event_sub_tokens_by_plugin: dict[str, set[int]] = {}

    def api(self, plugin_id: str) -> StudioPluginApi:
        return StudioPluginApi(self, plugin_id)

    def unregister_plugin(self, plugin_id: str) -> None:
        pid = (plugin_id or "").strip().lower()

        # Commands
        try:
            self._commands.unregister_owner(pid)
        except Exception:
            pass
        try:
            self._dock_panels.unregister_owner(pid)
        except Exception:
            pass
        self._unsubscribe_all(pid)

        # Menu/shortcut actions
        tracked_actions = self._actions.pop(pid, [])
        for tracked in tracked_actions:
            try:
                if tracked.menu is not None:
                    tracked.menu.removeAction(tracked.action)
            except Exception:
                pass
            try:
                self._window.removeAction(tracked.action)
            except Exception:
                pass
            try:
                tracked.action.setParent(None)
                tracked.action.deleteLater()
            except Exception:
                pass

        # Docks
        tracked_docks = self._docks.pop(pid, [])
        for tracked in tracked_docks:
            try:
                if tracked.menu is not None and tracked.toggle_action is not None:
                    tracked.menu.removeAction(tracked.toggle_action)
            except Exception:
                pass
            try:
                tracked.dock.hide()
            except Exception:
                pass
            try:
                tracked.dock.setParent(None)
                tracked.dock.deleteLater()
            except Exception:
                pass

    def log(self, plugin_id: str, message: str) -> None:
        msg = (message or "").strip()
        if not msg:
            return
        if self._log_fn is not None:
            self._log_fn((plugin_id or "").strip().lower(), msg)
            return
        print(f"[Plugin:{plugin_id}] {msg}", flush=True)

    def subscribe(
        self,
        plugin_id: str,
        topic: str,
        handler: Callable[..., None],
    ) -> int:
        pid = (plugin_id or "").strip().lower()
        t = (topic or "").strip()
        if not pid or not t:
            raise ValueError("plugin_id and topic are required")
        if not callable(handler):
            raise TypeError("handler must be callable")
        token = self._event_next_token
        self._event_next_token += 1
        sub = _EventSubscription(token=token, topic=t, plugin_id=pid, handler=handler)
        self._event_subs_by_topic.setdefault(t, []).append(sub)
        self._event_sub_tokens_by_plugin.setdefault(pid, set()).add(token)
        return token

    def unsubscribe(self, token: int) -> bool:
        tok = int(token)
        removed = False
        for topic, subs in list(self._event_subs_by_topic.items()):
            next_subs = [s for s in subs if s.token != tok]
            if len(next_subs) != len(subs):
                self._event_subs_by_topic[topic] = next_subs
                removed = True
                if not next_subs:
                    self._event_subs_by_topic.pop(topic, None)
        for pid, toks in list(self._event_sub_tokens_by_plugin.items()):
            if tok in toks:
                toks.discard(tok)
                removed = True
                if not toks:
                    self._event_sub_tokens_by_plugin.pop(pid, None)
        return removed

    def emit(self, topic: str, payload: Any) -> None:
        t = (topic or "").strip()
        if not t:
            return
        subs = list(self._event_subs_by_topic.get(t, []))

        def _deliver(sub: _EventSubscription) -> None:
            try:
                _call_event_handler(sub.handler, t, payload)
            except Exception as exc:
                self.log(sub.plugin_id, f"event '{t}' handler failed: {exc}")

        if QThread.currentThread() == self._window.thread():
            for sub in subs:
                _deliver(sub)
            return

        for sub in subs:
            QTimer.singleShot(0, self._window, lambda s=sub: _deliver(s))

    def _unsubscribe_all(self, plugin_id: str) -> None:
        pid = (plugin_id or "").strip().lower()
        tokens = list(self._event_sub_tokens_by_plugin.get(pid, set()))
        for tok in tokens:
            try:
                self.unsubscribe(tok)
            except Exception:
                continue

    # ---- internals -------------------------------------------------
    def _track_action(
        self,
        plugin_id: str,
        action: QAction,
        menu: QMenu | None,
    ) -> None:
        pid = (plugin_id or "").strip().lower()
        self._actions.setdefault(pid, []).append(
            _TrackedAction(action=action, menu=menu)
        )

    def _track_dock(
        self,
        plugin_id: str,
        dock: QDockWidget,
        *,
        menu: QMenu | None,
        toggle_action: QAction | None,
    ) -> None:
        pid = (plugin_id or "").strip().lower()
        self._docks.setdefault(pid, []).append(
            _TrackedDock(dock=dock, toggle_action=toggle_action, menu=menu)
        )

    def _resolve_menu_path(self, menu_path: str) -> QMenu | None:
        path = (menu_path or "").strip()
        if not path:
            return None

        parts = [p.strip() for p in path.split("/") if p.strip()]
        if not parts:
            return None

        top = parts[0].lower()
        window = self._window

        # Prefer explicit handles exposed by HelixStudioMainWindow.
        base: QMenu | None = None
        for attr, key in (
            ("menuFile", "file"),
            ("_menu_import", "import"),
            ("_menu_view", "view"),
            ("_menu_tools", "tools"),
            ("_menu_help", "help"),
        ):
            if top == key:
                base = getattr(window, attr, None)
                break

        if base is None:
            # Last resort: match by title.
            try:
                for action in window.menuBar().actions():
                    menu = action.menu()
                    if menu is None:
                        continue
                    if _norm_menu_title(menu.title()) == _norm_menu_title(parts[0]):
                        base = menu
                        break
            except Exception:
                base = None

        if base is None:
            return None

        current = base
        for segment in parts[1:]:
            seg_norm = _norm_menu_title(segment)
            found: QMenu | None = None
            try:
                for action in current.actions():
                    submenu = action.menu()
                    if submenu is None:
                        continue
                    if _norm_menu_title(submenu.title()) == seg_norm:
                        found = submenu
                        break
            except Exception:
                found = None

            if found is None:
                found = current.addMenu(segment)
            current = found

        return current


class StudioPluginApi:
    def __init__(self, host: StudioPluginHost, plugin_id: str) -> None:
        self._host = host
        self._plugin_id = (plugin_id or "").strip().lower()
        self.commands = StudioPluginCommands(host, self._plugin_id)
        self.ui = StudioPluginUi(host, self._plugin_id)
        self.settings = StudioPluginSettings(host, self._plugin_id)
        self.paths = StudioPluginPaths(host, self._plugin_id)
        self.events = StudioPluginEvents(host, self._plugin_id)

    @property
    def plugin_id(self) -> str:
        return self._plugin_id

    def log(self, message: str) -> None:
        self._host.log(self._plugin_id, message)


class StudioPluginCommands:
    def __init__(self, host: StudioPluginHost, plugin_id: str) -> None:
        self._host = host
        self._plugin_id = plugin_id

    def register(
        self,
        command_id: str,
        title: str,
        callback: Callable[[], None],
        *,
        category: str | None = None,
        shortcut: str | None = None,
        menu: str | None = None,
        replace: bool = False,
    ) -> HelixCommand:
        cid = (command_id or "").strip().lower()
        if not cid.startswith(f"{self._plugin_id}."):
            raise ValueError(
                f"plugin command ids must be namespaced: "
                f"expected '{self._plugin_id}.*' got {command_id!r}"
            )
        cmd = self._host._commands.register(
            command_id,
            title,
            callback,
            category=category,
            shortcut=shortcut,
            owner=self._plugin_id,
            replace=replace,
        )

        if not shortcut and not menu:
            return cmd

        window = self._host._window
        action = QAction(title, window)
        action.triggered.connect(callback)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
            # Ensure shortcut works even if menus are hidden.
            try:
                window.addAction(action)
            except Exception:
                pass

        resolved_menu: QMenu | None = None
        if menu:
            resolved_menu = self._host._resolve_menu_path(menu)
            if resolved_menu is not None:
                resolved_menu.addAction(action)

        self._host._track_action(self._plugin_id, action, resolved_menu)
        return cmd


class StudioPluginUi:
    def __init__(self, host: StudioPluginHost, plugin_id: str) -> None:
        self._host = host
        self._plugin_id = plugin_id

    def register_dock_panel(
        self,
        panel_id: str,
        title: str,
        widget_factory: Callable[[], QWidget],
        *,
        area: str = "bottom",
        visible: bool = False,
        menu: str = "View/Plugin Panels",
    ) -> QDockWidget:
        window = self._host._window
        full_id = (panel_id or "").strip().lower()
        if not full_id.startswith(f"{self._plugin_id}."):
            raise ValueError(
                f"plugin dock panel ids must be namespaced: "
                f"expected '{self._plugin_id}.*' got {panel_id!r}"
            )
        self._host._dock_panels.register(full_id, title, owner=self._plugin_id)
        widget = widget_factory()
        dock = QDockWidget(title, window)
        dock.setObjectName(f"plugin_dock_{full_id}")
        dock.setWidget(widget)
        dock.setAllowedAreas(Qt.AllDockWidgetAreas)
        dock.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable)

        area_enum = _dock_area(area)
        window.addDockWidget(area_enum, dock)

        # Prefer tabifying into the existing Console dock when registering
        # bottom panels.
        if area_enum == Qt.BottomDockWidgetArea:
            console = getattr(window, "_console_dock", None)
            if isinstance(console, QDockWidget):
                try:
                    window.tabifyDockWidget(console, dock)
                except Exception:
                    pass

        toggle_action = None
        panel_menu = self._host._resolve_menu_path(menu)
        if panel_menu is not None:
            try:
                toggle_action = dock.toggleViewAction()
                toggle_action.setText(title)
                panel_menu.addAction(toggle_action)
            except Exception:
                toggle_action = None

        if visible:
            dock.show()
        else:
            dock.hide()

        # Keep consistent behavior with internal docks if available.
        try:
            register = getattr(window, "_register_dock", None)
            if callable(register):
                register(dock)
        except Exception:
            pass

        self._host._track_dock(
            self._plugin_id,
            dock,
            menu=panel_menu,
            toggle_action=toggle_action,
        )
        return dock

    def is_main_thread(self) -> bool:
        try:
            return QThread.currentThread() == self._host._window.thread()
        except Exception:
            return True

    def run_on_main_thread(self, fn: Callable[[], None]) -> None:
        if self.is_main_thread():
            fn()
            return
        try:
            QTimer.singleShot(0, self._host._window, fn)
        except Exception:
            QTimer.singleShot(0, fn)


class StudioPluginSettings:
    def __init__(self, host: StudioPluginHost, plugin_id: str) -> None:
        self._host = host
        self._plugin_id = plugin_id

    def _key(self, key: str) -> str:
        k = (key or "").strip()
        if not k:
            raise ValueError("key is required")
        return f"plugins/plugin_settings/{self._plugin_id}/{k}"

    def get(self, key: str, default: Any = None) -> Any:
        settings = QSettings("Helix", "Studio")
        raw = settings.value(self._key(key), None)
        if raw is None:
            return default
        if isinstance(raw, str):
            try:
                return json.loads(raw)
            except Exception:
                return raw
        return raw

    def set(self, key: str, value: Any) -> None:
        try:
            encoded = json.dumps(value)
        except TypeError as exc:
            raise TypeError(
                "plugin settings values must be JSON-serializable"
            ) from exc
        settings = QSettings("Helix", "Studio")
        settings.setValue(self._key(key), encoded)

    def remove(self, key: str) -> None:
        settings = QSettings("Helix", "Studio")
        settings.remove(self._key(key))


class StudioPluginPaths:
    def __init__(self, host: StudioPluginHost, plugin_id: str) -> None:
        self._host = host
        self._plugin_id = plugin_id

    def _ensure(self, path: Path) -> Path:
        try:
            path.mkdir(parents=True, exist_ok=True)
        except Exception as exc:
            self._host.log(self._plugin_id, f"failed to create dir: {path} ({exc})")
        return path

    def user_data_dir(self) -> Path:
        base = QStandardPaths.writableLocation(QStandardPaths.AppDataLocation)
        root = Path(base) if base else (Path.home() / ".helix" / "studio")
        return self._ensure(root / "plugins" / self._plugin_id / "data")

    def cache_dir(self) -> Path:
        base = QStandardPaths.writableLocation(QStandardPaths.CacheLocation)
        root = Path(base) if base else (Path.home() / ".helix" / "studio" / "cache")
        return self._ensure(root / "plugins" / self._plugin_id)

    def temp_dir(self) -> Path:
        base = QStandardPaths.writableLocation(QStandardPaths.TempLocation)
        root = Path(base) if base else (Path.home() / ".helix" / "studio" / "tmp")
        return self._ensure(root / "helix_studio" / "plugins" / self._plugin_id)

    def log_file(self) -> Path:
        return self.cache_dir() / "plugin.log"


class StudioPluginEvents:
    def __init__(self, host: StudioPluginHost, plugin_id: str) -> None:
        self._host = host
        self._plugin_id = plugin_id

    def subscribe(self, topic: str, handler: Callable[..., None]) -> int:
        return self._host.subscribe(self._plugin_id, topic, handler)

    def unsubscribe(self, token: int) -> bool:
        return self._host.unsubscribe(token)

    def emit(self, topic: str, payload: Any) -> None:
        self._host.emit(topic, payload)


def _call_event_handler(fn: Callable[..., None], topic: str, payload: Any) -> None:
    try:
        fn(topic, payload)
        return
    except TypeError as exc:
        msg = str(exc)
        if (
            "required positional argument" not in msg
            and "positional arguments" not in msg
        ):
            raise
        fn(payload)


__all__ = [
    "StudioPluginApi",
    "StudioPluginHost",
]
