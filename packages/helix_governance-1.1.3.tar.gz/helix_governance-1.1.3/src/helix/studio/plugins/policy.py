from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


def _is_str_seq(value: Any) -> bool:
    return isinstance(value, (list, tuple)) and all(isinstance(x, str) for x in value)


def _norm_host(value: str) -> str:
    raw = (value or "").strip().lower()
    if not raw:
        return ""
    # Accept entries like "https://example.com/path" or "example.com:443".
    if "://" in raw:
        try:
            from urllib.parse import urlparse

            parsed = urlparse(raw)
            host = (parsed.hostname or "").strip().lower()
            return host
        except Exception:
            return ""
    raw = raw.split("/", 1)[0]
    raw = raw.split(":", 1)[0]
    if raw.startswith("*."):
        raw = raw[2:]
    if raw.startswith("."):
        raw = raw[1:]
    return raw.strip().lower()


@dataclass(frozen=True, slots=True)
class NetworkPolicy:
    """Serializable network capability policy (enforced only at narrow boundaries)."""

    mode: str = "none"  # none|allowlist|full
    allow: tuple[str, ...] = ()
    allow_insecure_http: bool = False
    allow_websocket: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "allow": list(self.allow),
            "allow_insecure_http": bool(self.allow_insecure_http),
            "allow_websocket": bool(self.allow_websocket),
        }


@dataclass(frozen=True, slots=True)
class FilePolicy:
    mode: str = "none"  # none|read-only|read-write

    def can_read(self) -> bool:
        return self.mode in {"read-only", "read-write"}

    def can_write(self) -> bool:
        return self.mode == "read-write"

    def as_dict(self) -> dict[str, Any]:
        return {"mode": self.mode}


@dataclass(frozen=True, slots=True)
class SubprocessPolicy:
    allowed: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {"allowed": bool(self.allowed)}


@dataclass(frozen=True, slots=True)
class SystemPolicy:
    open_url: bool = False
    clipboard: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {"open_url": bool(self.open_url), "clipboard": bool(self.clipboard)}


@dataclass(frozen=True, slots=True)
class WebPanelsPolicy:
    enabled: bool = True
    network: NetworkPolicy = NetworkPolicy()
    allow_external_navigation: bool = False
    allow_popups: bool = False
    allow_downloads: bool = False
    allow_cookies: bool = False
    allow_persistent_storage: bool = False
    csp_enabled: bool = True
    csp_allow_inline_script: bool = False
    csp_allow_eval: bool = False
    csp_allow_remote_scripts: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "enabled": bool(self.enabled),
            "network": self.network.as_dict(),
            "allow_external_navigation": bool(self.allow_external_navigation),
            "allow_popups": bool(self.allow_popups),
            "allow_downloads": bool(self.allow_downloads),
            "allow_cookies": bool(self.allow_cookies),
            "allow_persistent_storage": bool(self.allow_persistent_storage),
            "csp_enabled": bool(self.csp_enabled),
            "csp_allow_inline_script": bool(self.csp_allow_inline_script),
            "csp_allow_eval": bool(self.csp_allow_eval),
            "csp_allow_remote_scripts": bool(self.csp_allow_remote_scripts),
        }


@dataclass(frozen=True, slots=True)
class PluginPolicy:
    network: NetworkPolicy = NetworkPolicy()
    files: FilePolicy = FilePolicy()
    subprocess: SubprocessPolicy = SubprocessPolicy()
    system: SystemPolicy = SystemPolicy()
    web_panels: WebPanelsPolicy = WebPanelsPolicy()

    def as_dict(self) -> dict[str, Any]:
        return {
            "network": self.network.as_dict(),
            "files": self.files.as_dict(),
            "subprocess": self.subprocess.as_dict(),
            "system": self.system.as_dict(),
            "web_panels": self.web_panels.as_dict(),
        }


def _parse_network_policy(raw: Any) -> NetworkPolicy:
    if raw is None:
        return NetworkPolicy()

    if isinstance(raw, str):
        v = raw.strip().lower()
        if v in {"none", "deny", "disabled"}:
            return NetworkPolicy(mode="none")
        if v in {"full", "all", "any"}:
            return NetworkPolicy(mode="full")
        host = _norm_host(v)
        if host:
            return NetworkPolicy(mode="allowlist", allow=(host,))
        return NetworkPolicy()

    if _is_str_seq(raw):
        hosts = tuple(h for h in (_norm_host(x) for x in raw) if h)
        if hosts:
            return NetworkPolicy(mode="allowlist", allow=hosts)
        return NetworkPolicy()

    if isinstance(raw, Mapping):
        mode = str(raw.get("mode") or "").strip().lower()
        if not mode:
            mode = "allowlist" if raw.get("allow") is not None else "none"
        if mode in {"none", "deny"}:
            return NetworkPolicy(mode="none")
        if mode in {"full", "all", "any"}:
            return NetworkPolicy(
                mode="full",
                allow_insecure_http=bool(raw.get("allow_insecure_http", False)),
                allow_websocket=bool(raw.get("allow_websocket", False)),
            )
        allow_raw = raw.get("allow") or raw.get("hosts") or raw.get("domains")
        hosts: tuple[str, ...] = ()
        if isinstance(allow_raw, str):
            host = _norm_host(allow_raw)
            hosts = (host,) if host else ()
        elif _is_str_seq(allow_raw):
            hosts = tuple(h for h in (_norm_host(x) for x in allow_raw) if h)
        return NetworkPolicy(
            mode="allowlist" if hosts else "none",
            allow=hosts,
            allow_insecure_http=bool(raw.get("allow_insecure_http", False)),
            allow_websocket=bool(raw.get("allow_websocket", False)),
        )

    return NetworkPolicy()


def _parse_file_policy(raw: Any) -> FilePolicy:
    if raw is None:
        return FilePolicy()

    if isinstance(raw, str):
        v = raw.strip().lower()
        if v in {"none", "deny", "disabled"}:
            return FilePolicy(mode="none")
        if v in {"read", "ro", "read-only", "readonly"}:
            return FilePolicy(mode="read-only")
        if v in {"write", "rw", "read-write", "readwrite"}:
            return FilePolicy(mode="read-write")
        return FilePolicy()

    if isinstance(raw, Mapping):
        mode = raw.get("mode")
        if isinstance(mode, str) and mode.strip():
            return _parse_file_policy(mode)
        read = bool(raw.get("read", False))
        write = bool(raw.get("write", False))
        if write:
            return FilePolicy(mode="read-write")
        if read:
            return FilePolicy(mode="read-only")
        return FilePolicy(mode="none")

    if isinstance(raw, bool):
        return FilePolicy(mode="read-write" if raw else "none")

    return FilePolicy()


def _parse_subprocess_policy(raw: Any) -> SubprocessPolicy:
    if raw is None:
        return SubprocessPolicy()
    if isinstance(raw, bool):
        return SubprocessPolicy(allowed=bool(raw))
    if isinstance(raw, str):
        v = raw.strip().lower()
        if v in {"allow", "allowed", "true", "yes", "1"}:
            return SubprocessPolicy(allowed=True)
        if v in {"deny", "denied", "false", "no", "0"}:
            return SubprocessPolicy(allowed=False)
        return SubprocessPolicy()
    if isinstance(raw, Mapping):
        return SubprocessPolicy(allowed=bool(raw.get("allowed", False)))
    return SubprocessPolicy()


def _parse_system_policy(raw: Any, *, permissions: Mapping[str, Any]) -> SystemPolicy:
    if raw is None:
        # Allow top-level shortcuts.
        return SystemPolicy(
            open_url=bool(permissions.get("open_url", False)),
            clipboard=bool(permissions.get("clipboard", False)),
        )
    if isinstance(raw, bool):
        return SystemPolicy(open_url=bool(raw), clipboard=False)
    if isinstance(raw, Mapping):
        return SystemPolicy(
            open_url=bool(raw.get("open_url", False)),
            clipboard=bool(raw.get("clipboard", False)),
        )
    return SystemPolicy()


def policy_from_permissions(permissions: Mapping[str, Any] | None) -> PluginPolicy:
    if not isinstance(permissions, Mapping):
        return PluginPolicy()

    network = _parse_network_policy(permissions.get("network"))
    files = _parse_file_policy(permissions.get("file"))
    subprocess = _parse_subprocess_policy(permissions.get("subprocess"))
    system = _parse_system_policy(permissions.get("system"), permissions=permissions)

    web_raw = permissions.get("web_panels")
    if isinstance(web_raw, Mapping):
        web_network_raw = web_raw.get("network", permissions.get("network"))
        web_network = _parse_network_policy(web_network_raw)
        # Allow web_panels.network to extend defaults.
        web_network = NetworkPolicy(
            mode=web_network.mode,
            allow=web_network.allow,
            allow_insecure_http=bool(
                web_raw.get("allow_insecure_http", web_network.allow_insecure_http)
            ),
            allow_websocket=bool(
                web_raw.get("allow_websocket", web_network.allow_websocket)
            ),
        )
        web_panels = WebPanelsPolicy(
            enabled=bool(web_raw.get("enabled", True)),
            network=web_network,
            allow_external_navigation=bool(
                web_raw.get("allow_external_navigation", False)
            ),
            allow_popups=bool(web_raw.get("allow_popups", False)),
            allow_downloads=bool(web_raw.get("allow_downloads", False)),
            allow_cookies=bool(web_raw.get("allow_cookies", False)),
            allow_persistent_storage=bool(web_raw.get("allow_persistent_storage", False)),
            csp_enabled=bool(web_raw.get("csp_enabled", True)),
            csp_allow_inline_script=bool(web_raw.get("csp_allow_inline_script", False)),
            csp_allow_eval=bool(web_raw.get("csp_allow_eval", False)),
            csp_allow_remote_scripts=bool(
                web_raw.get("csp_allow_remote_scripts", False)
            ),
        )
    else:
        web_panels = WebPanelsPolicy(enabled=True, network=network)

    return PluginPolicy(
        network=network,
        files=files,
        subprocess=subprocess,
        system=system,
        web_panels=web_panels,
    )


def policy_from_dict(raw: Any) -> PluginPolicy:
    if not isinstance(raw, Mapping):
        return PluginPolicy()
    network = _parse_network_policy(raw.get("network"))
    files = _parse_file_policy(raw.get("files"))
    subprocess = _parse_subprocess_policy(raw.get("subprocess"))
    system = _parse_system_policy(raw.get("system"), permissions={})
    web_raw = raw.get("web_panels")
    if isinstance(web_raw, Mapping):
        web_network = _parse_network_policy(web_raw.get("network"))
        web_panels = WebPanelsPolicy(
            enabled=bool(web_raw.get("enabled", True)),
            network=web_network,
            allow_external_navigation=bool(
                web_raw.get("allow_external_navigation", False)
            ),
            allow_popups=bool(web_raw.get("allow_popups", False)),
            allow_downloads=bool(web_raw.get("allow_downloads", False)),
            allow_cookies=bool(web_raw.get("allow_cookies", False)),
            allow_persistent_storage=bool(web_raw.get("allow_persistent_storage", False)),
            csp_enabled=bool(web_raw.get("csp_enabled", True)),
            csp_allow_inline_script=bool(web_raw.get("csp_allow_inline_script", False)),
            csp_allow_eval=bool(web_raw.get("csp_allow_eval", False)),
            csp_allow_remote_scripts=bool(
                web_raw.get("csp_allow_remote_scripts", False)
            ),
        )
    else:
        web_panels = WebPanelsPolicy(enabled=True, network=network)
    return PluginPolicy(
        network=network,
        files=files,
        subprocess=subprocess,
        system=system,
        web_panels=web_panels,
    )


__all__ = [
    "FilePolicy",
    "NetworkPolicy",
    "PluginPolicy",
    "SubprocessPolicy",
    "SystemPolicy",
    "WebPanelsPolicy",
    "policy_from_dict",
    "policy_from_permissions",
]
