from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

HELIX_PLUGIN_API_VERSION = "1"
DEFAULT_MANIFEST_FILENAME = "helix_plugin.json"

_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{1,63}$")


class PluginManifestError(ValueError):
    pass


def _require_str(data: Mapping[str, Any], key: str, *, source: str) -> str:
    raw = data.get(key)
    if not isinstance(raw, str) or not raw.strip():
        raise PluginManifestError(
            f"{source}: missing/invalid '{key}' (expected non-empty string)"
        )
    return raw.strip()


def _optional_str(data: Mapping[str, Any], key: str) -> str | None:
    raw = data.get(key)
    if raw is None:
        return None
    if not isinstance(raw, str):
        return None
    value = raw.strip()
    return value or None


@dataclass(frozen=True, slots=True)
class HelixPluginManifest:
    plugin_id: str
    name: str
    version: str
    api_version: str
    entry: str
    publisher: str | None = None
    isolation: str = "in_process"
    extension_host_mode: str | None = None
    helix_min_version: str | None = None
    helix_max_version: str | None = None
    description: str | None = None
    author: str | None = None
    permissions: Mapping[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], *, source: str) -> HelixPluginManifest:
        plugin_id = _require_str(data, "id", source=source).lower()
        if not _ID_RE.match(plugin_id):
            raise PluginManifestError(
                f"{source}: invalid plugin id '{plugin_id}' "
                "(expected 2-64 chars: a-z0-9 plus ._-)"
            )
        name = _require_str(data, "name", source=source)
        version = _require_str(data, "version", source=source)
        publisher = _optional_str(data, "publisher")
        api_version_key = "plugin_api" if "plugin_api" in data else "api_version"
        api_version = _require_str(data, api_version_key, source=source)
        entry = _require_str(data, "entry", source=source)

        isolation = _optional_str(data, "isolation") or "in_process"
        isolation = isolation.strip().lower()
        if isolation not in {"in_process", "extension_host"}:
            raise PluginManifestError(
                f"{source}: invalid 'isolation'={isolation!r} "
                "(expected 'in_process' or 'extension_host')"
            )

        extension_host_mode = _optional_str(data, "extension_host_mode")
        if extension_host_mode is not None:
            mode = extension_host_mode.strip().lower()
            if mode in {"shared"}:
                extension_host_mode = "shared"
            elif mode in {"dedicated", "per_plugin", "per-plugin"}:
                extension_host_mode = "dedicated"
            else:
                raise PluginManifestError(
                    f"{source}: invalid 'extension_host_mode'={extension_host_mode!r} "
                    "(expected 'shared' or 'dedicated')"
                )

        helix_min_version = _optional_str(data, "helix_min_version")
        helix_max_version = _optional_str(data, "helix_max_version")

        permissions = data.get("permissions")
        if permissions is not None and not isinstance(permissions, Mapping):
            raise PluginManifestError(
                f"{source}: invalid 'permissions' (expected an object/map)"
            )

        return cls(
            plugin_id=plugin_id,
            name=name,
            version=version,
            publisher=publisher,
            api_version=api_version,
            entry=entry,
            isolation=isolation,
            extension_host_mode=extension_host_mode,
            helix_min_version=helix_min_version,
            helix_max_version=helix_max_version,
            description=_optional_str(data, "description"),
            author=_optional_str(data, "author"),
            permissions=permissions if isinstance(permissions, Mapping) else None,
        )


def load_plugin_manifest(path: Path) -> HelixPluginManifest:
    source = str(path)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise PluginManifestError(f"{source}: manifest not found") from exc
    except json.JSONDecodeError as exc:
        raise PluginManifestError(f"{source}: invalid JSON ({exc})") from exc
    except OSError as exc:
        raise PluginManifestError(f"{source}: failed to read manifest ({exc})") from exc

    if not isinstance(raw, Mapping):
        raise PluginManifestError(
            f"{source}: invalid manifest (expected a JSON object)"
        )
    return HelixPluginManifest.from_dict(raw, source=source)


def api_major(version: str) -> int:
    # We intentionally keep this tiny and boring: a major integer prefix.
    # Examples: "1", "1.2", "1.0.0" -> 1
    head = (version or "").strip().split(".", 1)[0]
    try:
        return int(head)
    except ValueError:
        return -1


def parse_entry(entry: str) -> tuple[str, str]:
    # Allow "pkg.module" (defaults to activate) or "pkg.module:callable".
    value = (entry or "").strip()
    if not value:
        return "", "activate"
    if ":" in value:
        module, func = value.split(":", 1)
        module = module.strip()
        func = func.strip() or "activate"
        return module, func
    return value, "activate"


__all__ = [
    "DEFAULT_MANIFEST_FILENAME",
    "HELIX_PLUGIN_API_VERSION",
    "HelixPluginManifest",
    "PluginManifestError",
    "api_major",
    "load_plugin_manifest",
    "parse_entry",
]
