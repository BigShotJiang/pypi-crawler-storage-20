from __future__ import annotations

import base64
import hashlib
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from helix import fs

from .manifest import DEFAULT_MANIFEST_FILENAME


DEFAULT_PACKAGE_EXTENSION = ".helixplugin"

HASHES_FILENAME = "HASHES.json"
SIGNATURE_FILENAME = "SIGNATURE.ed25519"
PUBLISHER_KEY_FILENAME = "PUBLISHER.pub"

_ZIP_FIXED_DATE_TIME = (1980, 1, 1, 0, 0, 0)
_DEFAULT_COMPRESSLEVEL = 9


class PluginPackageError(ValueError):
    pass


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _b64encode(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _b64decode(text: str) -> bytes:
    try:
        return base64.b64decode((text or "").strip(), validate=True)
    except Exception as exc:
        raise PluginPackageError("invalid base64") from exc


def _safe_arcname(name: str) -> str:
    value = str(name or "").replace("\\", "/").strip()
    if not value or value.startswith("/") or value.startswith("../") or "/../" in value:
        raise PluginPackageError(f"unsafe package path: {name!r}")
    return value


def _iter_files(root: Path) -> Iterable[Path]:
    for base, _, files in fs.walk_sorted(root, name_key=lambda name: (name.lower(), name)):
        for fn in files:
            path = Path(base) / fn
            if path.is_symlink():
                continue
            yield path


def _zipinfo(arcname: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(_safe_arcname(arcname), date_time=_ZIP_FIXED_DATE_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (0o644 & 0xFFFF) << 16
    return info


def _sign_ed25519(message: bytes, *, private_key_raw: bytes) -> tuple[bytes, bytes]:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
    except Exception as exc:
        raise PluginPackageError("cryptography is required for signing") from exc

    sk = Ed25519PrivateKey.from_private_bytes(private_key_raw)
    sig = sk.sign(message)
    pk = sk.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return sig, pk


def _verify_ed25519(message: bytes, *, signature_raw: bytes, public_key_raw: bytes) -> bool:
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except Exception as exc:
        raise PluginPackageError(
            "cryptography is required for signature verification"
        ) from exc
    try:
        Ed25519PublicKey.from_public_bytes(public_key_raw).verify(signature_raw, message)
    except Exception:
        return False
    return True


@dataclass(frozen=True, slots=True)
class PluginPackageMetadata:
    plugin_id: str
    version: str
    name: str | None
    publisher: str | None
    package_sha256: str


@dataclass(frozen=True, slots=True)
class PluginPackageVerification:
    plugin_id: str
    version: str
    name: str | None
    publisher: str | None
    file_hashes: dict[str, str]
    signature_present: bool
    public_key_b64: str | None


def _canonical_json_bytes(doc: Any) -> bytes:
    return json.dumps(doc, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _read_manifest_fields(manifest_path: Path) -> tuple[str, str, str | None, str | None]:
    try:
        manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    except Exception as exc:
        raise PluginPackageError(f"invalid {DEFAULT_MANIFEST_FILENAME}: {exc}") from exc
    if not isinstance(manifest, dict):
        raise PluginPackageError(f"invalid {DEFAULT_MANIFEST_FILENAME}: expected object")

    plugin_id = str(manifest.get("id") or "").strip().lower()
    version = str(manifest.get("version") or "").strip()
    name = str(manifest.get("name") or "").strip() or None
    publisher = str(manifest.get("publisher") or "").strip() or None
    if not plugin_id or not version:
        raise PluginPackageError("manifest must include id and version")
    return plugin_id, version, name, publisher


def _collect_package_pairs(root: Path) -> tuple[Path, list[tuple[Path, str]]]:
    root = Path(root)
    manifest_path = root / DEFAULT_MANIFEST_FILENAME
    if not manifest_path.exists():
        raise PluginPackageError(f"missing {DEFAULT_MANIFEST_FILENAME} in {root}")

    pairs: list[tuple[Path, str]] = [(manifest_path, DEFAULT_MANIFEST_FILENAME)]

    assets = root / "assets"
    if assets.is_dir():
        for path in _iter_files(assets):
            rel = path.relative_to(assets).as_posix()
            pairs.append((path, _safe_arcname(f"assets/{rel}")))

    wheels = root / "wheels"
    if wheels.is_dir():
        for path in _iter_files(wheels):
            rel = path.relative_to(wheels).as_posix()
            pairs.append((path, _safe_arcname(f"wheels/{rel}")))

    code = root / "code"
    if code.is_dir():
        for path in _iter_files(code):
            rel = path.relative_to(code).as_posix()
            pairs.append((path, _safe_arcname(f"code/{rel}")))
    else:
        exclude_dirs = {
            ".git",
            ".hg",
            ".svn",
            "__pycache__",
            ".mypy_cache",
            ".pytest_cache",
            ".ruff_cache",
            ".venv",
            "venv",
            "assets",
            "wheels",
            ".helix_pkg_cache",
            ".helix_pkg_txn",
            ".helix_pkg_prev",
            ".helix_pkg_staging",
        }
        exclude_files = {
            DEFAULT_MANIFEST_FILENAME,
            HASHES_FILENAME,
            SIGNATURE_FILENAME,
            PUBLISHER_KEY_FILENAME,
        }
        for entry in fs.iterdir_sorted(root, key=lambda p: p.name.lower()):
            if entry.is_symlink():
                continue
            if entry.is_dir():
                if entry.name in exclude_dirs:
                    continue
                for path in _iter_files(entry):
                    rel = path.relative_to(root).as_posix()
                    pairs.append((path, _safe_arcname(f"code/{rel}")))
            elif entry.is_file():
                if entry.name in exclude_files:
                    continue
                pairs.append((entry, _safe_arcname(f"code/{entry.name}")))

    pairs = sorted(pairs, key=lambda t: t[1])
    return manifest_path, pairs


def _compute_file_hashes(pairs: list[tuple[Path, str]]) -> dict[str, str]:
    file_hashes: dict[str, str] = {}
    for src, arcname in pairs:
        file_hashes[arcname] = _sha256_file(src)
    return file_hashes


def _hashes_json_bytes(file_hashes: dict[str, str]) -> bytes:
    hashes_doc = {"format": 1, "sha256": {k: file_hashes[k] for k in sorted(file_hashes)}}
    return _canonical_json_bytes(hashes_doc)


def build_plugin_package(
    plugin_root: Path,
    out_path: Path,
    *,
    private_key_raw: bytes | None = None,
) -> PluginPackageMetadata:
    root = Path(plugin_root)

    out = Path(out_path)
    if out.suffix != DEFAULT_PACKAGE_EXTENSION:
        raise PluginPackageError(
            f"plugin package must end with {DEFAULT_PACKAGE_EXTENSION}"
        )

    manifest_path, pairs = _collect_package_pairs(root)
    plugin_id, version, name, publisher = _read_manifest_fields(manifest_path)
    file_hashes = _compute_file_hashes(pairs)
    hashes_bytes = _hashes_json_bytes(file_hashes)

    sig_b64: str | None = None
    pub_b64: str | None = None
    if private_key_raw is not None:
        sig_raw, pub_raw = _sign_ed25519(hashes_bytes, private_key_raw=private_key_raw)
        sig_b64 = _b64encode(sig_raw)
        pub_b64 = _b64encode(pub_raw)

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(out.suffix + ".tmp")
    try:
        tmp.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        pass

    with zipfile.ZipFile(
        tmp,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=_DEFAULT_COMPRESSLEVEL,
    ) as zf:
        for src, arcname in pairs:
            zf.writestr(
                _zipinfo(arcname),
                Path(src).read_bytes(),
                compresslevel=_DEFAULT_COMPRESSLEVEL,
            )
        zf.writestr(
            _zipinfo(HASHES_FILENAME),
            hashes_bytes,
            compresslevel=_DEFAULT_COMPRESSLEVEL,
        )
        if sig_b64 is not None and pub_b64 is not None:
            zf.writestr(
                _zipinfo(SIGNATURE_FILENAME),
                sig_b64.encode("ascii"),
                compresslevel=_DEFAULT_COMPRESSLEVEL,
            )
            zf.writestr(
                _zipinfo(PUBLISHER_KEY_FILENAME),
                pub_b64.encode("ascii"),
                compresslevel=_DEFAULT_COMPRESSLEVEL,
            )

    tmp.replace(out)
    return PluginPackageMetadata(
        plugin_id=plugin_id,
        version=version,
        name=name,
        publisher=publisher,
        package_sha256=_sha256_file(out),
    )


def write_hashes_json(plugin_root: Path, *, out_path: Path | None = None) -> dict[str, str]:
    """Write a canonical HASHES.json for a plugin directory."""
    root = Path(plugin_root)
    manifest_path, pairs = _collect_package_pairs(root)
    _read_manifest_fields(manifest_path)
    file_hashes = _compute_file_hashes(pairs)
    bytes_out = _hashes_json_bytes(file_hashes)
    target = Path(out_path) if out_path is not None else (root / HASHES_FILENAME)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(bytes_out)
    return file_hashes


def generate_ed25519_keypair() -> tuple[bytes, bytes]:
    """Return (private_key_raw, public_key_raw) for Ed25519."""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
    except Exception as exc:
        raise PluginPackageError("cryptography is required for key generation") from exc

    sk = Ed25519PrivateKey.generate()
    private_key_raw = sk.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_key_raw = sk.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return private_key_raw, public_key_raw


def sign_hashes_json(hashes_bytes: bytes, *, private_key_raw: bytes) -> tuple[str, str]:
    """Return (signature_b64, public_key_b64) for HASHES.json bytes."""
    sig_raw, pub_raw = _sign_ed25519(hashes_bytes, private_key_raw=private_key_raw)
    return _b64encode(sig_raw), _b64encode(pub_raw)


def sign_plugin_package(
    package_path: Path,
    out_path: Path,
    *,
    private_key_raw: bytes,
) -> PluginPackageMetadata:
    """Verify an existing package, then write a deterministically signed package."""
    verification = verify_plugin_package(Path(package_path))
    pkg = Path(package_path)
    out = Path(out_path)
    if out.suffix != DEFAULT_PACKAGE_EXTENSION:
        raise PluginPackageError(
            f"plugin package must end with {DEFAULT_PACKAGE_EXTENSION}"
        )

    file_bytes: dict[str, bytes] = {}
    with zipfile.ZipFile(pkg, "r") as zf:
        for arcname in sorted(verification.file_hashes):
            file_bytes[arcname] = zf.read(arcname)

    hashes_bytes = _hashes_json_bytes(verification.file_hashes)
    sig_b64, pub_b64 = sign_hashes_json(hashes_bytes, private_key_raw=private_key_raw)

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(out.suffix + ".tmp")
    try:
        tmp.unlink()
    except FileNotFoundError:
        pass
    except Exception:
        pass

    with zipfile.ZipFile(
        tmp,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=_DEFAULT_COMPRESSLEVEL,
    ) as zf:
        for arcname in sorted(file_bytes):
            zf.writestr(
                _zipinfo(arcname),
                file_bytes[arcname],
                compresslevel=_DEFAULT_COMPRESSLEVEL,
            )
        zf.writestr(
            _zipinfo(HASHES_FILENAME),
            hashes_bytes,
            compresslevel=_DEFAULT_COMPRESSLEVEL,
        )
        zf.writestr(
            _zipinfo(SIGNATURE_FILENAME),
            sig_b64.encode("ascii"),
            compresslevel=_DEFAULT_COMPRESSLEVEL,
        )
        zf.writestr(
            _zipinfo(PUBLISHER_KEY_FILENAME),
            pub_b64.encode("ascii"),
            compresslevel=_DEFAULT_COMPRESSLEVEL,
        )

    tmp.replace(out)
    return PluginPackageMetadata(
        plugin_id=verification.plugin_id,
        version=verification.version,
        name=verification.name,
        publisher=verification.publisher,
        package_sha256=_sha256_file(out),
    )


def verify_plugin_package(package_path: Path) -> PluginPackageVerification:
    pkg = Path(package_path)
    if not pkg.is_file():
        raise PluginPackageError(f"package not found: {pkg}")

    with zipfile.ZipFile(pkg, "r") as zf:
        try:
            manifest_bytes = zf.read(DEFAULT_MANIFEST_FILENAME)
        except KeyError as exc:
            raise PluginPackageError(f"missing {DEFAULT_MANIFEST_FILENAME}") from exc
        try:
            manifest = json.loads(manifest_bytes.decode("utf-8"))
        except Exception as exc:
            raise PluginPackageError(f"invalid {DEFAULT_MANIFEST_FILENAME}: {exc}") from exc
        if not isinstance(manifest, dict):
            raise PluginPackageError(f"invalid {DEFAULT_MANIFEST_FILENAME}: expected object")

        plugin_id = str(manifest.get("id") or "").strip().lower()
        version = str(manifest.get("version") or "").strip()
        name = str(manifest.get("name") or "").strip() or None
        publisher = str(manifest.get("publisher") or "").strip() or None
        if not plugin_id or not version:
            raise PluginPackageError("manifest must include id and version")

        try:
            hashes_bytes = zf.read(HASHES_FILENAME)
        except KeyError as exc:
            raise PluginPackageError(f"missing {HASHES_FILENAME}") from exc
        try:
            hashes_doc = json.loads(hashes_bytes.decode("utf-8"))
        except Exception as exc:
            raise PluginPackageError(f"invalid {HASHES_FILENAME}: {exc}") from exc
        if not isinstance(hashes_doc, dict) or int(hashes_doc.get("format") or 0) != 1:
            raise PluginPackageError(f"invalid {HASHES_FILENAME}: unsupported format")
        raw_map = hashes_doc.get("sha256")
        if not isinstance(raw_map, dict) or not raw_map:
            raise PluginPackageError(f"invalid {HASHES_FILENAME}: missing sha256 map")

        file_hashes: dict[str, str] = {}
        for k, v in raw_map.items():
            if isinstance(k, str) and isinstance(v, str):
                file_hashes[_safe_arcname(k)] = v.strip().lower()

        for arcname in sorted(file_hashes):
            expected = file_hashes[arcname]
            try:
                data = zf.read(arcname)
            except KeyError as exc:
                raise PluginPackageError(f"missing file in package: {arcname}") from exc
            actual = _sha256_bytes(data)
            if actual != expected:
                raise PluginPackageError(
                    f"{plugin_id}: {arcname}: sha256 mismatch (expected {expected} got {actual})"
                )

        signature_present = (
            SIGNATURE_FILENAME in zf.namelist()
            and PUBLISHER_KEY_FILENAME in zf.namelist()
        )
        public_key_b64: str | None = None
        if signature_present:
            sig_raw = _b64decode(
                zf.read(SIGNATURE_FILENAME).decode("ascii", errors="replace")
            )
            pub_b64 = zf.read(PUBLISHER_KEY_FILENAME).decode(
                "ascii", errors="replace"
            ).strip()
            pub_raw = _b64decode(pub_b64)
            if not _verify_ed25519(
                hashes_bytes,
                signature_raw=sig_raw,
                public_key_raw=pub_raw,
            ):
                raise PluginPackageError(f"{plugin_id}: signature verification failed")
            public_key_b64 = pub_b64

    return PluginPackageVerification(
        plugin_id=plugin_id,
        version=version,
        name=name,
        publisher=publisher,
        file_hashes=file_hashes,
        signature_present=bool(signature_present),
        public_key_b64=public_key_b64,
    )


def extract_plugin_package(package_path: Path, *, out_dir: Path) -> PluginPackageVerification:
    """Verify then extract a plugin package into `out_dir` (must be empty or absent)."""
    verification = verify_plugin_package(package_path)
    target = Path(out_dir)
    if target.exists():
        if not target.is_dir():
            raise PluginPackageError(f"extract target is not a directory: {target}")
        if fs.dir_has_any(target):
            raise PluginPackageError(f"extract target must be empty: {target}")
    target.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(Path(package_path), "r") as zf:
        allow = set(verification.file_hashes.keys()) | {
            HASHES_FILENAME,
            SIGNATURE_FILENAME,
            PUBLISHER_KEY_FILENAME,
        }
        names = set(zf.namelist())
        for arcname in sorted(allow):
            if arcname not in names:
                continue
            data = zf.read(arcname)
            dest = (target / arcname).resolve()
            if not str(dest).startswith(str(target.resolve())):
                raise PluginPackageError(f"unsafe extraction path: {arcname}")
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)

    return verification


def verify_extracted_plugin_dir(plugin_root: Path) -> PluginPackageVerification:
    """Verify HASHES.json (+ optional signature) for an extracted plugin directory."""
    root = Path(plugin_root)
    manifest_path = root / DEFAULT_MANIFEST_FILENAME
    hashes_path = root / HASHES_FILENAME
    if not manifest_path.is_file():
        raise PluginPackageError(f"missing {DEFAULT_MANIFEST_FILENAME}")
    if not hashes_path.is_file():
        raise PluginPackageError(f"missing {HASHES_FILENAME}")

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise PluginPackageError(f"invalid {DEFAULT_MANIFEST_FILENAME}: {exc}") from exc
    if not isinstance(manifest, dict):
        raise PluginPackageError(f"invalid {DEFAULT_MANIFEST_FILENAME}: expected object")

    plugin_id = str(manifest.get("id") or "").strip().lower()
    version = str(manifest.get("version") or "").strip()
    name = str(manifest.get("name") or "").strip() or None
    publisher = str(manifest.get("publisher") or "").strip() or None
    if not plugin_id or not version:
        raise PluginPackageError("manifest must include id and version")

    hashes_bytes = hashes_path.read_bytes()
    try:
        hashes_doc = json.loads(hashes_bytes.decode("utf-8"))
    except Exception as exc:
        raise PluginPackageError(f"invalid {HASHES_FILENAME}: {exc}") from exc
    raw_map = hashes_doc.get("sha256") if isinstance(hashes_doc, dict) else None
    if not isinstance(raw_map, dict) or not raw_map:
        raise PluginPackageError(f"invalid {HASHES_FILENAME}: missing sha256 map")

    file_hashes: dict[str, str] = {}
    for k, v in raw_map.items():
        if isinstance(k, str) and isinstance(v, str):
            file_hashes[_safe_arcname(k)] = v.strip().lower()

    for rel, expected in sorted(file_hashes.items()):
        p = root / rel
        if not p.is_file():
            raise PluginPackageError(f"{plugin_id}: missing file: {rel}")
        actual = _sha256_file(p)
        if actual != expected:
            raise PluginPackageError(
                f"{plugin_id}: {rel}: sha256 mismatch (expected {expected} got {actual})"
            )

    signature_path = root / SIGNATURE_FILENAME
    pub_path = root / PUBLISHER_KEY_FILENAME
    signature_present = signature_path.is_file() and pub_path.is_file()
    public_key_b64: str | None = None
    if signature_present:
        sig_raw = _b64decode(signature_path.read_text(encoding="utf-8"))
        pub_b64 = pub_path.read_text(encoding="utf-8").strip()
        pub_raw = _b64decode(pub_b64)
        if not _verify_ed25519(
            hashes_bytes,
            signature_raw=sig_raw,
            public_key_raw=pub_raw,
        ):
            raise PluginPackageError(f"{plugin_id}: signature verification failed")
        public_key_b64 = pub_b64

    return PluginPackageVerification(
        plugin_id=plugin_id,
        version=version,
        name=name,
        publisher=publisher,
        file_hashes=file_hashes,
        signature_present=bool(signature_present),
        public_key_b64=public_key_b64,
    )
