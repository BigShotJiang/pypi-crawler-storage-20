from __future__ import annotations

from helix.studio.plugins.policy import PluginPolicy


def should_use_dedicated_extension_host(policy: PluginPolicy) -> bool:
    """Heuristic isolation choice for extension-host plugins.

    Dedicated hosts provide better dependency isolation and crash blame at the
    cost of additional processes.

    Manifest `extension_host_mode` (explicit) always wins; this only applies
    when no per-plugin override is provided.
    """

    if policy.subprocess.allowed:
        return True
    if policy.system.open_url or policy.system.clipboard:
        return True

    net_mode = (policy.network.mode or "").strip().lower()
    if net_mode not in {"", "none", "deny"}:
        return True

    wp = policy.web_panels
    if (
        wp.allow_external_navigation
        or wp.allow_popups
        or wp.allow_downloads
        or wp.csp_allow_remote_scripts
        or wp.csp_allow_eval
    ):
        return True

    wp_net_mode = (wp.network.mode or "").strip().lower()
    if wp_net_mode not in {"", "none", "deny"}:
        return True

    return False


__all__ = ["should_use_dedicated_extension_host"]

