from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Mapping

from helix import bioinformatics
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.outcomes.model import get_default_registry, outcome_report_to_dict
from helix.studio.offtargets.model import (
    _genome_digest as offtarget_genome_digest,
    compute_inputs_sha256 as offtarget_inputs_sha256,
    get_default_registry as get_offtarget_registry,
    offtarget_report_to_dict,
)
from helix.studio.offtargets.reference_accessor import (
    OffTargetReferenceCache,
    build_reference_cache_from_config,
    get_default_reference_cache,
)
from helix.studio.offtargets.validation_plan import build_validation_plan
from helix.studio.assays.primer_design import build_primer_plan
from helix.studio.outcomes.clone_yield import build_clone_plan
from helix.studio.assays.assay_chooser import build_assay_plan

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    Field = lambda *args, **kwargs: None  # type: ignore
    PYDANTIC_AVAILABLE = False


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def batch_spec_json_bytes(spec: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(spec))


def batch_report_json_bytes(report: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(report))


def batch_spec_sha256(spec: Mapping[str, Any]) -> str:
    return hashlib.sha256(batch_spec_json_bytes(spec)).hexdigest()


def batch_report_sha256(report: Mapping[str, Any]) -> str:
    return hashlib.sha256(batch_report_json_bytes(report)).hexdigest()


def _genome_digest(genome_sequences: Mapping[str, Any] | None, contig: str, window_start: int, window_end: int) -> dict[str, Any]:
    if not isinstance(genome_sequences, Mapping):
        return {}
    seq = genome_sequences.get(contig)
    if not isinstance(seq, str) or not seq:
        return {}
    window = seq[window_start:window_end]
    return {
        "contig": contig,
        "windowStart": int(window_start),
        "windowEnd": int(window_end),
        "windowSha256": hashlib.sha256(window.encode("utf-8")).hexdigest(),
        "length": len(window),
    }


def _scan_pam_candidates(
    sequence: str,
    *,
    contig: str,
    window_start: int,
    guide_length: int,
    pam_pattern: str,
    strand_policy: str,
) -> list[dict[str, Any]]:
    seq = sequence.upper()
    pam = pam_pattern.upper()
    pam_len = len(pam)
    if pam_len <= 0:
        return []

    def match_at(idx: int, pattern: str) -> bool:
        chunk = seq[idx : idx + pam_len]
        if len(chunk) != pam_len:
            return False
        for c, p in zip(chunk, pattern):
            if p == "N":
                continue
            if c != p:
                return False
        return True

    rev_pam = bioinformatics.reverse_complement(pam)

    candidates: list[dict[str, Any]] = []
    for pam_start in range(0, len(seq) - pam_len + 1):
        if strand_policy in {"both", "plus"} and match_at(pam_start, pam):
            guide_start = pam_start - guide_length
            guide_end = pam_start
            if guide_start >= 0:
                guide_seq = seq[guide_start:guide_end]
                start_abs = window_start + guide_start
                end_abs = window_start + guide_end
                cut_index = window_start + pam_start - 3
                candidates.append(
                    {
                        "candidateKey": f"{contig}:{start_abs}-{end_abs}:+",
                        "guide": {
                            "contig": contig,
                            "start": start_abs,
                            "end": end_abs,
                            "strand": "+",
                            "sequence": guide_seq,
                        "pam": pam,
                        },
                        "cutIndex": cut_index,
                    }
                )
        if strand_policy in {"both", "minus"} and match_at(pam_start, rev_pam):
            guide_start = pam_start + pam_len
            guide_end = guide_start + guide_length
            if guide_end <= len(seq):
                guide_seq = bioinformatics.reverse_complement(seq[guide_start:guide_end])
                start_abs = window_start + guide_start
                end_abs = window_start + guide_end
                cut_index = window_start + guide_start + 3
                candidates.append(
                    {
                        "candidateKey": f"{contig}:{start_abs}-{end_abs}:-",
                        "guide": {
                            "contig": contig,
                            "start": start_abs,
                            "end": end_abs,
                            "strand": "-",
                            "sequence": guide_seq,
                        "pam": pam,
                        },
                        "cutIndex": cut_index,
                    }
                )

    candidates.sort(key=lambda c: (c["guide"]["start"], c["guide"]["strand"], c["guide"]["end"]))
    return candidates


def _pareto_front(vectors: list[dict[str, Any]]) -> list[bool]:
    flags = [True] * len(vectors)
    for i, vi in enumerate(vectors):
        if not flags[i]:
            continue
        for j, vj in enumerate(vectors):
            if i == j:
                continue
            if _dominates(vj, vi):
                flags[i] = False
                break
    return flags


def _dominates(a: dict[str, Any], b: dict[str, Any]) -> bool:
    if a["desiredFrequency"] < b["desiredFrequency"]:
        return False
    if a["highRiskOffTargets"] > b["highRiskOffTargets"]:
        return False
    if a["clonesNeeded"] > b["clonesNeeded"]:
        return False
    if a["validationBurden"] > b["validationBurden"]:
        return False
    if (
        a["desiredFrequency"] > b["desiredFrequency"]
        or a["highRiskOffTargets"] < b["highRiskOffTargets"]
        or a["clonesNeeded"] < b["clonesNeeded"]
        or a["validationBurden"] < b["validationBurden"]
    ):
        return True
    return False


def _composite_score(vector: dict[str, Any], weights: Mapping[str, Any]) -> float:
    w_desired = float(weights.get("desiredFrequency", 1.0))
    w_high = float(weights.get("highRiskOffTargets", 2.0))
    w_clones = float(weights.get("clonesNeeded", 0.01))
    w_validation = float(weights.get("validationBurden", 0.5))

    p_desired = float(vector.get("desiredFrequency") or 0.0)
    high_risk = float(vector.get("highRiskOffTargets") or 0.0)
    clones = float(vector.get("clonesNeeded") or 0.0)
    validation = float(vector.get("validationBurden") or 0.0)

    score = (1.0 - p_desired) * w_desired + high_risk * w_high + clones * w_clones + validation * w_validation
    return round(score, 6)


DEFAULT_OBJECTIVES = [
    "desiredFrequency",
    "highRiskOffTargets",
    "clonesNeeded95",
    "validationBurden",
    "validationCost",
]
DEFAULT_WEIGHTS = {
    "desiredFrequency": 0.40,
    "highRiskOffTargets": 0.30,
    "clonesNeeded95": 0.15,
    "validationBurden": 0.05,
    "validationCost": 0.10,
}
DEFAULT_TIEBREAK = "candidateKey"
DEFAULT_NORMALIZATION = {
    "desiredFrequency": "one_minus",
    "highRiskOffTargets": "cap10",
    "clonesNeeded95": "cap384",
    "validationBurden": "cap10",
    "validationCost": "cap20",
}
PAIR_OBJECTIVES = [
    "allTargetsEdited",
    "highRiskOffTargets",
    "worstClonesNeeded",
    "validationCost",
]
PAIR_WEIGHTS = {
    "allTargetsEdited": 0.45,
    "highRiskOffTargets": 0.30,
    "worstClonesNeeded": 0.15,
    "validationCost": 0.10,
}
PAIR_NORMALIZATION = {
    "allTargetsEdited": "one_minus",
    "highRiskOffTargets": "cap10",
    "worstClonesNeeded": "cap384",
    "validationCost": "cap20",
}


def _ranking_spec(payload: Mapping[str, Any], *, pair_mode: bool = False) -> dict[str, Any]:
    objectives = payload.get("objectives")
    if not isinstance(objectives, list) or not objectives:
        objectives = list(PAIR_OBJECTIVES if pair_mode else DEFAULT_OBJECTIVES)
    weights = payload.get("weights")
    weights = dict(weights) if isinstance(weights, Mapping) else dict(PAIR_WEIGHTS if pair_mode else DEFAULT_WEIGHTS)
    if pair_mode:
        if "allTargetsEdited" not in weights and "desiredFrequency" in weights:
            weights["allTargetsEdited"] = weights.get("desiredFrequency")
        if "worstClonesNeeded" not in weights and "clonesNeeded95" in weights:
            weights["worstClonesNeeded"] = weights.get("clonesNeeded95")
        if "worstClonesNeeded" not in weights and "clonesNeeded" in weights:
            weights["worstClonesNeeded"] = weights.get("clonesNeeded")
    else:
        if "clonesNeeded95" not in weights and "clonesNeeded" in weights:
            weights["clonesNeeded95"] = weights.pop("clonesNeeded")
    tie_break = str(payload.get("tieBreak") or DEFAULT_TIEBREAK)
    normalization = payload.get("normalization")
    normalization = dict(normalization) if isinstance(normalization, Mapping) else dict(
        PAIR_NORMALIZATION if pair_mode else DEFAULT_NORMALIZATION
    )
    return {
        "objectives": list(objectives),
        "weights": weights,
        "tieBreak": tie_break,
        "normalization": normalization,
    }


def _objective_value(vector: Mapping[str, Any], objective: str) -> float:
    if objective == "allTargetsEdited":
        return float(vector.get("allTargetsEdited") or vector.get("expectedAllTargetsEdited") or 0.0)
    if objective == "desiredFrequency":
        return float(vector.get("desiredFrequency") or 0.0)
    if objective == "highRiskOffTargets":
        return float(vector.get("highRiskOffTargets") or 0.0)
    if objective == "clonesNeeded95":
        value = vector.get("clonesNeeded95")
        if value is None:
            return 1e9
        return float(value)
    if objective == "worstClonesNeeded":
        value = vector.get("worstClonesNeeded")
        if value is None:
            return 1e9
        return float(value)
    if objective == "validationBurden":
        return float(vector.get("validationBurden") or 0.0)
    if objective == "validationCost":
        return float(vector.get("validationCost") or 0.0)
    return float(vector.get(objective) or 0.0)


def _objective_dominates(a: Mapping[str, Any], b: Mapping[str, Any], objectives: list[str]) -> bool:
    better = False
    for obj in objectives:
        a_val = _objective_value(a, obj)
        b_val = _objective_value(b, obj)
        if obj == "desiredFrequency":
            if a_val < b_val:
                return False
            if a_val > b_val:
                better = True
        else:
            if a_val > b_val:
                return False
            if a_val < b_val:
                better = True
    return better


def compute_pareto_flags(vectors: list[Mapping[str, Any]], objectives: list[str]) -> list[bool]:
    flags = [True] * len(vectors)
    for i, vi in enumerate(vectors):
        if not flags[i]:
            continue
        for j, vj in enumerate(vectors):
            if i == j:
                continue
            if _objective_dominates(vj, vi, objectives):
                flags[i] = False
                break
    return flags


def normalized_composite_score(vector: Mapping[str, Any], weights: Mapping[str, Any]) -> float:
    all_targets = float(vector.get("allTargetsEdited") or vector.get("expectedAllTargetsEdited") or 0.0)
    desired = float(vector.get("desiredFrequency") or 0.0)
    use_all_targets = bool("allTargetsEdited" in weights or vector.get("allTargetsEdited") is not None)
    desired_value = all_targets if use_all_targets else desired
    desired_norm = 1.0 - max(0.0, min(desired_value, 1.0))

    high = float(vector.get("highRiskOffTargets") or 0.0)
    high_norm = min(high, 10.0) / 10.0

    clones = vector.get("worstClonesNeeded") if use_all_targets else vector.get("clonesNeeded95")
    if clones is None:
        clones_norm = 1.0
    else:
        clones_norm = min(float(clones), 384.0) / 384.0

    validation = float(vector.get("validationBurden") or 0.0)
    validation_norm = min(validation, 10.0) / 10.0

    validation_cost = float(vector.get("validationCost") or 0.0)
    validation_cost_norm = min(validation_cost, 20.0) / 20.0

    w_desired = float(
        weights.get(
            "allTargetsEdited" if use_all_targets else "desiredFrequency",
            DEFAULT_WEIGHTS["desiredFrequency"],
        )
    )
    w_high = float(weights.get("highRiskOffTargets", DEFAULT_WEIGHTS["highRiskOffTargets"]))
    w_clones = float(
        weights.get(
            "worstClonesNeeded" if use_all_targets else "clonesNeeded95",
            DEFAULT_WEIGHTS["clonesNeeded95"],
        )
    )
    w_validation = float(weights.get("validationBurden", DEFAULT_WEIGHTS["validationBurden"]))
    w_validation_cost = float(weights.get("validationCost", DEFAULT_WEIGHTS["validationCost"]))

    score = (
        desired_norm * w_desired
        + high_norm * w_high
        + clones_norm * w_clones
        + validation_norm * w_validation
        + validation_cost_norm * w_validation_cost
    )
    return round(score, 6)


if PYDANTIC_AVAILABLE:

    class BatchSpecV1(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)

        schema_: str = Field(default="helix_batch_spec_v1", alias="schema")
        reference: dict[str, Any] = Field(default_factory=dict)
        nuclease: dict[str, Any] = Field(default_factory=dict)
        constraints: dict[str, Any] = Field(default_factory=dict)
        candidate_settings: dict[str, Any] = Field(default_factory=dict, alias="candidateSettings")
        caps: dict[str, Any] = Field(default_factory=dict)
        ranking: dict[str, Any] = Field(default_factory=dict)
        experiment_spec: dict[str, Any] = Field(default_factory=dict, alias="experimentSpec")

        @property
        def schema(self) -> str:
            return self.schema_


    class BatchReportV1(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)

        schema_: str = Field(default="helix_batch_report_v1", alias="schema")
        inputs_sha256: str = Field(alias="inputsSha256")
        candidates: list[dict[str, Any]] = Field(default_factory=list)
        is_truncated: bool = Field(alias="isTruncated")
        caps_used: dict[str, Any] = Field(default_factory=dict, alias="capsUsed")
        ranking_version: str = Field(default="v1", alias="rankingVersion")

        @property
        def schema(self) -> str:
            return self.schema_
else:

    @dataclass
    class BatchSpecV1:
        schema: str = "helix_batch_spec_v1"
        reference: dict[str, Any] = field(default_factory=dict)
        nuclease: dict[str, Any] = field(default_factory=dict)
        constraints: dict[str, Any] = field(default_factory=dict)
        candidate_settings: dict[str, Any] = field(default_factory=dict)
        caps: dict[str, Any] = field(default_factory=dict)
        ranking: dict[str, Any] = field(default_factory=dict)
        experiment_spec: dict[str, Any] = field(default_factory=dict)


    @dataclass
    class BatchReportV1:
        schema: str = "helix_batch_report_v1"
        inputs_sha256: str = ""
        candidates: list[dict[str, Any]] = field(default_factory=list)
        is_truncated: bool = False
        caps_used: dict[str, Any] = field(default_factory=dict)
        ranking_version: str = "v1"


def batch_spec_to_dict(spec: BatchSpecV1 | Mapping[str, Any]) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and isinstance(spec, BatchSpecV1):
        return spec.model_dump(exclude_none=True, by_alias=True)
    if isinstance(spec, Mapping):
        return dict(spec)
    return {}


def batch_report_to_dict(report: BatchReportV1 | Mapping[str, Any]) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and isinstance(report, BatchReportV1):
        return report.model_dump(exclude_none=True, by_alias=True)
    if isinstance(report, Mapping):
        return dict(report)
    return {}


def compute_inputs_sha256(spec: Mapping[str, Any], genome_sequences: Mapping[str, Any] | None) -> str:
    payload = {
        "spec": dict(spec),
    }
    reference = spec.get("reference") if isinstance(spec.get("reference"), Mapping) else {}
    contig = str(reference.get("contig") or "")
    window_start = int(reference.get("windowStart") or 0)
    window_end = int(reference.get("windowEnd") or 0)
    if contig and window_end > window_start:
        payload["referenceDigest"] = _genome_digest(genome_sequences, contig, window_start, window_end)
    return hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()


def run_batch(
    spec: Mapping[str, Any],
    *,
    genome_sequences: Mapping[str, Any] | None,
    reference_cache: OffTargetReferenceCache | None = None,
    prefetch_targets: bool | None = None,
    reference_cache_config: Mapping[str, Any] | None = None,
    workers: int | None = None,
) -> dict[str, Any]:
    spec_payload = batch_spec_to_dict(spec)
    reference = spec_payload.get("reference") if isinstance(spec_payload.get("reference"), Mapping) else {}
    contig = str(reference.get("contig") or "")
    window_start = int(reference.get("windowStart") or 0)
    window_end = int(reference.get("windowEnd") or 0)
    if not contig or window_end <= window_start:
        return {
            "schema": "helix_batch_report_v1",
            "inputsSha256": compute_inputs_sha256(spec_payload, genome_sequences),
            "candidates": [],
            "isTruncated": False,
            "capsUsed": dict(spec_payload.get("caps") or {}),
            "rankingVersion": str((spec_payload.get("ranking") or {}).get("version") or "v1"),
        }

    seq = ""
    if isinstance(genome_sequences, Mapping):
        seq = str(genome_sequences.get(contig) or "")
    window_seq = seq[window_start:window_end] if seq else ""

    candidate_settings = spec_payload.get("candidateSettings") if isinstance(spec_payload.get("candidateSettings"), Mapping) else {}
    guide_length = int(candidate_settings.get("guideLength") or 20)
    pam_pattern = str(candidate_settings.get("pamPattern") or "NGG")
    nuclease = spec_payload.get("nuclease") if isinstance(spec_payload.get("nuclease"), Mapping) else {}
    pam_profile = str(nuclease.get("pamClass") or nuclease.get("pamProfile") or nuclease.get("pamPattern") or "SpCas9-NGG")
    strand_policy = str(candidate_settings.get("strandPolicy") or "both").lower()
    caps = spec_payload.get("caps") if isinstance(spec_payload.get("caps"), Mapping) else {}
    max_candidates = int(caps.get("maxCandidates") or 0)
    pair_mode = bool(
        candidate_settings.get("pairMode")
        or candidate_settings.get("pair_mode")
        or str(candidate_settings.get("pairing") or "").lower() == "pairs"
    )
    pair_top_n = int(candidate_settings.get("pairTopN") or candidate_settings.get("pair_top_n") or 0)
    if pair_mode and pair_top_n <= 0:
        pair_top_n = 20
    max_pairs = int(caps.get("maxPairs") or 0)
    if pair_mode and max_pairs <= 0:
        max_pairs = 100

    candidates = _scan_pam_candidates(
        window_seq,
        contig=contig,
        window_start=window_start,
        guide_length=guide_length,
        pam_pattern=pam_pattern,
        strand_policy=strand_policy,
    )

    is_truncated = False
    if max_candidates > 0 and len(candidates) > max_candidates:
        candidates = candidates[:max_candidates]
        is_truncated = True

    ranking = spec_payload.get("ranking") if isinstance(spec_payload.get("ranking"), Mapping) else {}
    ranking_spec = _ranking_spec(ranking, pair_mode=pair_mode)
    objectives = ranking_spec["objectives"]
    weights = ranking_spec["weights"]

    registry = get_default_registry()
    off_registry = get_offtarget_registry()
    experiment_spec = spec_payload.get("experimentSpec") if isinstance(spec_payload.get("experimentSpec"), Mapping) else {}
    if workers is None:
        workers = 1
    try:
        workers = int(workers)
    except Exception:
        workers = 1
    workers = max(1, workers)
    if reference_cache is None:
        if isinstance(reference_cache_config, Mapping):
            reference_cache = build_reference_cache_from_config(reference_cache_config)
        else:
            reference_cache = get_default_reference_cache()
    reference_accessor = reference_cache.accessor(genome_sequences)

    def _run_offtargets_for_guides(
        guides: list[Mapping[str, Any]],
        *,
        accessor: Any | None,
        params_payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        combined_hits: list[dict[str, Any]] = []
        truncated_any = False
        provider_id_local = None
        provider_version_local = None
        resolved_params = dict(params_payload or {})
        max_mismatches = None
        for guide_entry in guides:
            local_provider = off_registry.select(experiment_spec, guide_entry, genome_sequences, resolved_params)
            local_report = local_provider.run(
                experiment_spec,
                guide_entry,
                genome_sequences,
                resolved_params,
                reference_accessor=accessor,
            )
            payload = offtarget_report_to_dict(local_report)
            if provider_id_local is None:
                provider_id_local = payload.get("modelId") or getattr(local_provider, "provider_id", "")
                provider_version_local = payload.get("modelVersion") or getattr(local_provider, "provider_version", "")
            local_hits = payload.get("hits") if isinstance(payload.get("hits"), list) else []
            for hit in local_hits:
                if isinstance(hit, Mapping):
                    combined_hits.append(dict(hit))
            if bool(payload.get("isTruncated")):
                truncated_any = True
            if max_mismatches is None:
                max_mismatches = payload.get("maxMismatches")
            if payload.get("params") and isinstance(payload.get("params"), Mapping):
                resolved_params = dict(payload.get("params") or {})

        combined_hits.sort(
            key=lambda h: (
                int(h.get("effectiveDistance", h.get("distance", 0)) or 0),
                int(h.get("totalMismatchCount", h.get("distance", 0)) or 0),
                {"NONE": 0, "DNA": 1, "RNA": 2}.get(str(h.get("bulgeType") or "NONE").upper(), 3),
                str(h.get("contig") or ""),
                int(h.get("start") or 0),
            )
        )
        high_count = 0
        medium_count = 0
        low_count = 0
        for hit in combined_hits:
            tier = str(hit.get("riskTier") or "")
            if tier == "High":
                high_count += 1
            elif tier == "Medium":
                medium_count += 1
            else:
                low_count += 1

        guide_payload = {
            "mode": "multiplex" if len(guides) > 1 else "single",
            "targets": [dict(g) for g in guides],
        }
        inputs_sha = offtarget_inputs_sha256(experiment_spec, guide_payload, genome_sequences, resolved_params)
        summary = [
            f"Multiplex off-target search across {len(guides)} target(s).",
            f"{len(combined_hits)} candidate site(s) scored.",
        ]
        if truncated_any:
            hit_cap = resolved_params.get("max_hits")
            if hit_cap is not None:
                summary.append(f"Truncated to top {hit_cap} hits per target.")
        genome_meta = {"contigs": offtarget_genome_digest(genome_sequences)}
        return {
            "schema": "helix_offtarget_report_v1",
            "modelId": provider_id_local or "",
            "modelVersion": provider_version_local or "",
            "inputsSha256": inputs_sha,
            "summary": summary,
            "guide": guide_payload,
            "genome": genome_meta,
            "params": resolved_params,
            "hits": combined_hits,
            "totalHits": None if truncated_any else len(combined_hits),
            "hitCap": resolved_params.get("max_hits"),
            "isTruncated": truncated_any,
            "hitsReturned": len(combined_hits),
            "maxMismatches": max_mismatches if max_mismatches is not None else resolved_params.get("max_mm"),
            "highRiskCount": high_count,
            "mediumRiskCount": medium_count,
            "lowRiskCount": low_count,
        }

    def _build_candidate_result(entry: Mapping[str, Any]) -> dict[str, Any]:
        if isinstance(entry.get("guides"), list) and len(entry.get("guides")) > 1:
            guides = [dict(g) for g in entry.get("guides") if isinstance(g, Mapping)]
            cut_indices = entry.get("cutIndices") if isinstance(entry.get("cutIndices"), list) else []
            target_entries: list[dict[str, Any]] = []
            guide_payloads: list[dict[str, Any]] = []
            for idx, guide in enumerate(guides):
                target_id = f"t{idx + 1}"
                guide_entry = dict(guide)
                guide_entry["targetId"] = target_id
                guide_payloads.append(guide_entry)
                cut_index = None
                if idx < len(cut_indices):
                    cut_index = cut_indices[idx]
                target_entries.append(
                    {
                        "targetId": target_id,
                        "contig": contig,
                        "start": guide_entry.get("start"),
                        "end": guide_entry.get("end"),
                        "strand": guide_entry.get("strand"),
                        "cutIndex": cut_index,
                        "gRNA": {
                            "sequence": guide_entry.get("sequence"),
                            "pam": guide_entry.get("pam") or pam_profile,
                            "pamClass": guide_entry.get("pamClass") or pam_profile,
                        },
                    }
                )
            edit_plan = {
                "schema": "helix_edit_plan_v1",
                "mode": "multiplex",
                "targets": target_entries,
                "notes": [],
            }
            reference_context = {
                "contig": contig,
                "windowStart": window_start,
                "windowEnd": window_end,
                "sequence": window_seq,
            }
            model = registry.select(experiment_spec, edit_plan, reference_context)
            outcome_report = model.run(experiment_spec, edit_plan, reference_context)
            outcome_payload = outcome_report_to_dict(outcome_report)

            params = {
                "max_mm": int(caps.get("maxMismatches") or 3),
                "max_hits": int(caps.get("maxOffTargetHits") or 200),
                "pam": pam_profile,
            }
            if prefetch_targets is not None:
                params["prefetch_targets"] = bool(prefetch_targets)
            if workers > 1:
                if isinstance(reference_cache_config, Mapping):
                    local_cache = build_reference_cache_from_config(reference_cache_config)
                else:
                    local_cache = OffTargetReferenceCache()
                local_accessor = local_cache.accessor(genome_sequences)
            else:
                local_accessor = reference_accessor
            off_payload = _run_offtargets_for_guides(
                guide_payloads,
                accessor=local_accessor,
                params_payload=params,
            )

            validation_plan = build_validation_plan(
                off_payload,
                off_target_report_sha256="",
                genome_sequences=genome_sequences,
                experiment_spec=experiment_spec,
                guide=guide_payloads[0] if guide_payloads else {},
                edit_plan=edit_plan,
                outcome_report=outcome_payload,
            )
            primer_plan = build_primer_plan(
                validation_plan,
                genome_sequences=genome_sequences,
                validation_plan_sha256="",
                experiment_spec=experiment_spec,
                guide=guide_payloads[0] if guide_payloads else {},
            )
            clone_plan = build_clone_plan(outcome_payload)
            assay_plan = build_assay_plan(
                outcome_payload,
                validation_plan,
                primer_plan,
                clone_plan,
                experiment_spec=experiment_spec,
            )

            multiplex = outcome_payload.get("multiplex") if isinstance(outcome_payload.get("multiplex"), Mapping) else {}
            multiplex_targets = multiplex.get("targets") if isinstance(multiplex.get("targets"), list) else []
            multiplex_targets = [t for t in multiplex_targets if isinstance(t, Mapping)]
            multiplex_targets.sort(key=lambda t: str(t.get("targetId") or ""))
            combined = multiplex.get("combined") if isinstance(multiplex.get("combined"), Mapping) else {}
            expected_all = float(combined.get("expectedAllTargetsEdited") or 0.0)
            expected_any = float(combined.get("expectedAnyEdited") or 0.0)
            if not combined and multiplex_targets:
                prod = 1.0
                for entry in multiplex_targets:
                    prod *= float(entry.get("desiredFrequency") or 0.0)
                expected_all = prod
                expected_any = 1.0 - prod

            per_target = []
            clones_needed_vals: list[int] = []
            any_clone_none = False
            primary_status_by_target: dict[str, str] = {}
            primary_notes_by_target: dict[str, list[str]] = {}
            assay_by_target: dict[str, dict[str, Any]] = {}

            assay_targets = assay_plan.get("targets") if isinstance(assay_plan.get("targets"), list) else []
            for target_entry in assay_targets:
                if isinstance(target_entry, Mapping):
                    tid = str(target_entry.get("targetId") or "")
                    if tid:
                        primary = target_entry.get("primary") if isinstance(target_entry.get("primary"), Mapping) else {}
                        assay_by_target[tid] = dict(primary)

            primer_pairs = primer_plan.get("primerPairs") if isinstance(primer_plan.get("primerPairs"), list) else []
            for target_entry in multiplex_targets:
                tid = str(target_entry.get("targetId") or "")
                allele_spectrum = (
                    target_entry.get("alleleSpectrum") if isinstance(target_entry.get("alleleSpectrum"), list) else []
                )
                target_payload = dict(outcome_payload)
                target_payload["alleleSpectrum"] = list(allele_spectrum)
                target_clone = build_clone_plan(target_payload)
                clones_needed = target_clone.get("clonesNeededSingleCell")
                if clones_needed is None:
                    any_clone_none = True
                else:
                    clones_needed_vals.append(int(clones_needed))
                desired = float(target_entry.get("desiredFrequency") or 0.0)
                assay_entry = assay_by_target.get(tid, {})
                assay_label = str(assay_entry.get("recommendedAssay") or "—")
                status = "missing"
                notes: list[str] = []
                for pair in primer_pairs:
                    if not isinstance(pair, Mapping):
                        continue
                    if str(pair.get("hitKey") or "") != f"{tid}::primary_target":
                        continue
                    status = str(pair.get("status") or "failed") or "failed"
                    notes = list(pair.get("notes") or [])
                    break
                primary_status_by_target[tid] = status
                primary_notes_by_target[tid] = notes
                per_target.append(
                    {
                        "targetId": tid,
                        "desiredFrequency": round(desired, 8),
                        "clonesNeeded": clones_needed,
                        "recommendedAssay": assay_label,
                    }
                )

            worst_clones = None
            if not any_clone_none and clones_needed_vals:
                worst_clones = max(clones_needed_vals)

            union_block = validation_plan.get("union") if isinstance(validation_plan.get("union"), Mapping) else None
            union_high = int((union_block or {}).get("highRiskCount") or validation_plan.get("highRiskCount") or 0)
            union_medium = int((union_block or {}).get("mediumRiskCount") or validation_plan.get("mediumRiskCount") or 0)
            union_low = int((union_block or {}).get("lowRiskCount") or validation_plan.get("lowRiskCount") or 0)
            validation_burden = union_high * 3 + union_medium * 1 + union_low * 0

            top_hits = (union_block or {}).get("topHits") if isinstance((union_block or {}).get("topHits"), list) else []
            if not top_hits:
                top_hits = validation_plan.get("topHits") if isinstance(validation_plan.get("topHits"), list) else []
            top_offtargets = []
            for hit in top_hits[:3]:
                if not isinstance(hit, Mapping):
                    continue
                hit_contig = hit.get("contig")
                start = hit.get("start")
                end = hit.get("end")
                locus = f"{hit_contig}:{start}-{end}" if hit_contig is not None else ""
                top_offtargets.append(
                    {
                        "riskTier": str(hit.get("riskTier") or ""),
                        "locus": locus,
                    }
                )

            assay_cost_map = {"SANGER": 1, "AMPLICONSEQ": 3, "LONGREAD": 8}
            assay_cost = 3
            primer_feasibility = 0
            if assay_by_target:
                assay_cost = max(
                    assay_cost_map.get(str(entry.get("recommendedAssay") or "").upper(), 3)
                    for entry in assay_by_target.values()
                )
            for status in primary_status_by_target.values():
                if str(status).lower() != "ok":
                    primer_feasibility = 5
                    break
            offtarget_validation_count = min(union_high + union_medium, 10)
            total_validation_cost = assay_cost + primer_feasibility + offtarget_validation_count

            objective_vector = {
                "allTargetsEdited": round(expected_all, 6),
                "desiredFrequency": round(expected_all, 6),
                "highRiskOffTargets": union_high,
                "worstClonesNeeded": worst_clones,
                "clonesNeeded95": worst_clones,
                "validationBurden": validation_burden,
                "validationCost": total_validation_cost,
            }

            primary_assay = assay_by_target.get("t1", {}) if assay_by_target else {}

            return {
                "candidateKey": entry.get("candidateKey"),
                "guides": guides,
                "pairKeys": entry.get("pairKeys") or [],
                "cutIndices": list(cut_indices),
                "pairTargets": per_target,
                "combinedSummary": {
                    "expectedAllTargetsEdited": round(expected_all, 8),
                    "expectedAnyEdited": round(expected_any, 8),
                },
                "outcomeSummary": {
                    "modelId": outcome_payload.get("modelId"),
                    "desiredFrequency": round(expected_all, 8),
                },
                "offTargetSummary": {
                    "highRiskCount": union_high,
                    "mediumRiskCount": union_medium,
                    "lowRiskCount": union_low,
                },
                "clonePlanSummary": {
                    "clonesNeeded": worst_clones,
                },
                "assayPlanSummary": {
                    "recommendedAssay": str(primary_assay.get("recommendedAssay") or ""),
                },
                "assayTargets": [
                    {"targetId": tid, "recommendedAssay": str(entry.get("recommendedAssay") or "")}
                    for tid, entry in assay_by_target.items()
                ],
                "assayCostScore": assay_cost,
                "primerFeasibilityScore": primer_feasibility,
                "offtargetValidationCount": offtarget_validation_count,
                "totalValidationCost": total_validation_cost,
                "topOffTargets": top_offtargets,
                "primaryPrimerStatusByTarget": primary_status_by_target,
                "primaryPrimerNotesByTarget": primary_notes_by_target,
                "assayRationaleByTarget": {
                    tid: list(entry.get("rationale") or []) for tid, entry in assay_by_target.items()
                },
                "objectiveVector": objective_vector,
                "paretoVector": objective_vector,
                "compositeScore": 0.0,
            }

        guide = dict(entry.get("guide") or {})
        cut_index = entry.get("cutIndex")
        edit_plan = {
            "contig": contig,
            "guide": dict(guide),
        }
        if cut_index is not None:
            edit_plan["cutIndex"] = cut_index
        reference_context = {
            "contig": contig,
            "windowStart": window_start,
            "windowEnd": window_end,
            "sequence": window_seq,
        }
        model = registry.select(experiment_spec, edit_plan, reference_context)
        outcome_report = model.run(experiment_spec, edit_plan, reference_context)
        outcome_payload = outcome_report_to_dict(outcome_report)

        params = {
            "max_mm": int(caps.get("maxMismatches") or 3),
            "max_hits": int(caps.get("maxOffTargetHits") or 200),
            "pam": pam_profile,
        }
        if prefetch_targets is not None:
            params["prefetch_targets"] = bool(prefetch_targets)
        provider = off_registry.select(experiment_spec, guide, genome_sequences, params)
        if workers > 1:
            if isinstance(reference_cache_config, Mapping):
                local_cache = build_reference_cache_from_config(reference_cache_config)
            else:
                local_cache = OffTargetReferenceCache()
            local_accessor = local_cache.accessor(genome_sequences)
        else:
            local_accessor = reference_accessor
        off_report = provider.run(
            experiment_spec,
            guide,
            genome_sequences,
            params,
            reference_accessor=local_accessor,
        )
        off_payload = offtarget_report_to_dict(off_report)

        validation_plan = build_validation_plan(
            off_payload,
            off_target_report_sha256="",
            genome_sequences=genome_sequences,
            experiment_spec=experiment_spec,
            guide=guide,
        )
        primer_plan = build_primer_plan(
            validation_plan,
            genome_sequences=genome_sequences,
            validation_plan_sha256="",
            experiment_spec=experiment_spec,
            guide=guide,
        )
        clone_plan = build_clone_plan(outcome_payload)
        assay_plan = build_assay_plan(outcome_payload, validation_plan, primer_plan, clone_plan, experiment_spec=experiment_spec)

        primary = assay_plan.get("primary") if isinstance(assay_plan.get("primary"), Mapping) else {}
        top_hits = validation_plan.get("topHits") if isinstance(validation_plan.get("topHits"), list) else []
        top_offtargets = []
        for hit in top_hits[:3]:
            if not isinstance(hit, Mapping):
                continue
            hit_contig = hit.get("contig")
            start = hit.get("start")
            end = hit.get("end")
            locus = f"{hit_contig}:{start}-{end}" if hit_contig is not None else ""
            top_offtargets.append(
                {
                    "riskTier": str(hit.get("riskTier") or ""),
                    "locus": locus,
                }
            )
        primary_status = "missing"
        primary_notes = []
        for pair in primer_plan.get("primerPairs", []):
            if not isinstance(pair, Mapping):
                continue
            if str(pair.get("hitKey") or "") != "primary_target":
                continue
            primary_status = str(pair.get("status") or "failed") or "failed"
            primary_notes = list(pair.get("notes") or [])
            break
        p_desired = float(primary.get("pDesired") or 0.0)
        clones_needed = primary.get("clonesNeeded")
        if clones_needed is None:
            clones_needed_val = 999
        else:
            clones_needed_val = int(clones_needed)

        high_risk = int(validation_plan.get("highRiskCount") or 0)
        medium_risk = int(validation_plan.get("mediumRiskCount") or 0)
        low_risk = int(validation_plan.get("lowRiskCount") or 0)
        validation_burden = high_risk * 3 + medium_risk * 1 + low_risk * 0

        assay_label = str(primary.get("recommendedAssay") or "")
        assay_cost_map = {"SANGER": 1, "AMPLICONSEQ": 3, "LONGREAD": 8}
        assay_cost = assay_cost_map.get(assay_label.upper(), 3)
        primer_feasibility = 0 if str(primary_status).lower() == "ok" else 5
        offtarget_validation_count = min(high_risk + medium_risk, 10)
        total_validation_cost = assay_cost + primer_feasibility + offtarget_validation_count

        objective_vector = {
            "desiredFrequency": round(p_desired, 6),
            "highRiskOffTargets": high_risk,
            "clonesNeeded95": clones_needed if clones_needed is None else int(clones_needed),
            "validationBurden": validation_burden,
            "validationCost": total_validation_cost,
        }
        return {
            "candidateKey": entry.get("candidateKey"),
            "cutIndex": entry.get("cutIndex"),
            "guide": guide,
            "outcomeSummary": {
                "modelId": outcome_payload.get("modelId"),
                "desiredFrequency": round(p_desired, 8),
            },
            "offTargetSummary": {
                "highRiskCount": high_risk,
                "mediumRiskCount": medium_risk,
                "lowRiskCount": low_risk,
            },
            "clonePlanSummary": {
                "clonesNeeded": clones_needed,
            },
            "assayPlanSummary": {
                "recommendedAssay": str(primary.get("recommendedAssay") or ""),
            },
            "assayCostScore": assay_cost,
            "primerFeasibilityScore": primer_feasibility,
            "offtargetValidationCount": offtarget_validation_count,
            "totalValidationCost": total_validation_cost,
            "topOffTargets": top_offtargets,
            "primaryPrimerStatus": primary_status,
            "primaryPrimerNotes": primary_notes,
            "assayRationale": list(primary.get("rationale") or []),
            "objectiveVector": objective_vector,
            "paretoVector": objective_vector,
            "compositeScore": 0.0,
        }

    if pair_mode:
        ordered = sorted(candidates, key=lambda c: str(c.get("candidateKey") or ""))
        if pair_top_n > 0 and len(ordered) > pair_top_n:
            ordered = ordered[:pair_top_n]
        pairs: list[dict[str, Any]] = []
        for i in range(len(ordered)):
            for j in range(i + 1, len(ordered)):
                a = ordered[i]
                b = ordered[j]
                key_a = str(a.get("candidateKey") or "")
                key_b = str(b.get("candidateKey") or "")
                pair_key = f"{key_a}+{key_b}"
                pairs.append(
                    {
                        "candidateKey": pair_key,
                        "pairKeys": [key_a, key_b],
                        "guides": [dict(a.get("guide") or {}), dict(b.get("guide") or {})],
                        "cutIndices": [a.get("cutIndex"), b.get("cutIndex")],
                    }
                )
        if max_pairs > 0 and len(pairs) > max_pairs:
            pairs = pairs[:max_pairs]
            is_truncated = True
        candidates = pairs

    candidate_results: list[dict[str, Any]] = []
    if workers > 1 and len(candidates) > 1:
        from concurrent.futures import ThreadPoolExecutor

        futures = []
        with ThreadPoolExecutor(max_workers=workers) as executor:
            for entry in candidates:
                futures.append(executor.submit(_build_candidate_result, entry))
            for future in futures:
                candidate_results.append(future.result())
    else:
        for entry in candidates:
            candidate_results.append(_build_candidate_result(entry))

    candidate_results.sort(key=lambda c: str(c.get("candidateKey") or ""))

    vectors = [c.get("objectiveVector", {}) for c in candidate_results]
    pareto_flags = compute_pareto_flags(vectors, objectives) if vectors else []
    for idx, candidate in enumerate(candidate_results):
        is_pareto = bool(pareto_flags[idx]) if idx < len(pareto_flags) else False
        candidate["isPareto"] = is_pareto
        candidate["paretoFront"] = is_pareto
        candidate["compositeScore"] = normalized_composite_score(candidate.get("objectiveVector", {}), weights)

    candidate_results.sort(
        key=lambda c: (
            float(c.get("compositeScore") or 0.0),
            str(c.get("candidateKey") or ""),
        )
    )

    report = {
        "schema": "helix_batch_report_v1",
        "inputsSha256": compute_inputs_sha256(spec_payload, genome_sequences),
        "candidates": candidate_results,
        "isTruncated": bool(is_truncated),
        "capsUsed": dict(caps),
        "rankingVersion": str(ranking.get("version") or "v1"),
        "rankingSpec": ranking_spec,
        "paretoFrontKeys": [
            str(c.get("candidateKey") or "")
            for c in candidate_results
            if bool(c.get("isPareto"))
        ],
    }
    if pair_mode:
        report["pairMode"] = True
    return report


__all__ = [
    "BatchSpecV1",
    "BatchReportV1",
    "batch_spec_json_bytes",
    "batch_spec_sha256",
    "batch_report_json_bytes",
    "batch_report_sha256",
    "batch_spec_to_dict",
    "batch_report_to_dict",
    "compute_inputs_sha256",
    "normalized_composite_score",
    "compute_pareto_flags",
    "DEFAULT_OBJECTIVES",
    "DEFAULT_WEIGHTS",
    "PAIR_OBJECTIVES",
    "PAIR_WEIGHTS",
    "PAIR_NORMALIZATION",
    "run_batch",
]
