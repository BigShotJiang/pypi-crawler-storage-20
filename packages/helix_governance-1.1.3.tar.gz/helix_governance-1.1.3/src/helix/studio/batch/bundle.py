from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path
from typing import Any, Mapping

from .model import batch_report_json_bytes, batch_report_sha256, batch_spec_json_bytes, batch_spec_sha256


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def _created_utc() -> str:
    # Fixed timestamp keeps bundle bytes stable across runs.
    return "1980-01-01T00:00:00Z"


def build_manifest(*, files: Mapping[str, bytes], receipts: Mapping[str, Any] | None = None) -> dict[str, Any]:
    entries = []
    for path in sorted(files.keys()):
        data = files[path]
        entries.append(
            {
                "path": str(path),
                "bytes": int(len(data)),
                "sha256": sha256_hex(data),
            }
        )
    return {
        "packVersion": "v0.1",
        "createdUtc": _created_utc(),
        "receipts": dict(receipts or {}),
        "files": entries,
    }


def build_batch_bundle_zip_bytes(
    *,
    pack_dirname: str,
    spec: Mapping[str, Any],
    report: Mapping[str, Any],
) -> bytes:
    pack_dirname = str(pack_dirname).strip().strip("/").strip("\\") or "helix_batch_bundle"
    spec_bytes = batch_spec_json_bytes(spec)
    report_bytes = batch_report_json_bytes(report)
    receipts = {
        "batchSpecSha256": batch_spec_sha256(spec),
        "batchReportSha256": batch_report_sha256(report),
    }
    files = {
        "batch_spec.v1.json": spec_bytes,
        "batch_report.v1.json": report_bytes,
    }
    manifest = build_manifest(files=files, receipts=receipts)
    files_with_manifest = dict(files)
    files_with_manifest["manifest.json"] = stable_json_bytes(manifest)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for rel_path in sorted(files_with_manifest.keys()):
            data = files_with_manifest[rel_path]
            arcname = f"{pack_dirname}/{rel_path}"
            info = zipfile.ZipInfo(arcname)
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, data)
    return buf.getvalue()


def write_batch_bundle(path: Path | str, *, spec: Mapping[str, Any], report: Mapping[str, Any], pack_dirname: str) -> Path:
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    data = build_batch_bundle_zip_bytes(pack_dirname=pack_dirname, spec=spec, report=report)
    out_path.write_bytes(data)
    return out_path


def _find_pack_dirname(zf: zipfile.ZipFile) -> tuple[str | None, list[str]]:
    manifest_paths = [n for n in zf.namelist() if n.endswith("/manifest.json")]
    if len(manifest_paths) != 1:
        return None, [f"expected exactly 1 manifest.json (found {len(manifest_paths)})"]
    manifest_path = manifest_paths[0]
    if manifest_path.count("/") < 1:
        return None, [f"invalid manifest path: {manifest_path!r}"]
    pack_dirname = manifest_path.rsplit("/", 1)[0]
    return pack_dirname, []


def verify_batch_bundle_zip_bytes(data: bytes) -> list[str]:
    errors: list[str] = []
    try:
        buf = io.BytesIO(data)
    except Exception as exc:
        return [f"invalid zip: {exc}"]

    with zipfile.ZipFile(buf) as zf:
        pack_dir, errs = _find_pack_dirname(zf)
        errors.extend(errs)
        if not pack_dir:
            return errors

        try:
            manifest_raw = zf.read(f"{pack_dir}/manifest.json")
        except Exception as exc:
            return errors + [f"missing manifest.json: {exc}"]

        try:
            manifest = json.loads(manifest_raw.decode("utf-8"))
        except Exception as exc:
            return errors + [f"invalid manifest.json: {exc}"]
        if not isinstance(manifest, dict):
            return errors + ["manifest.json must be a JSON object"]

        files_list = manifest.get("files")
        if not isinstance(files_list, list):
            return errors + ["manifest.json missing 'files' list"]

        receipts = manifest.get("receipts") if isinstance(manifest.get("receipts"), dict) else {}

        expected: dict[str, dict[str, object]] = {}
        for i, entry in enumerate(files_list):
            if not isinstance(entry, dict):
                errors.append(f"manifest.files[{i}] is not an object")
                continue
            rel = str(entry.get("path") or "")
            if not rel:
                errors.append(f"manifest.files[{i}] missing path")
                continue
            if rel in expected:
                errors.append(f"manifest has duplicate entry: {rel}")
                continue
            expected[rel] = entry

        present_rel: set[str] = set()
        for name in zf.namelist():
            if not name.startswith(f"{pack_dir}/"):
                continue
            if name.endswith("/"):
                continue
            rel = name[len(pack_dir) + 1 :]
            if rel == "manifest.json":
                continue
            present_rel.add(rel)

        missing_in_zip = [rel for rel in expected.keys() if rel not in present_rel]
        for rel in sorted(missing_in_zip):
            errors.append(f"missing file in zip: {rel}")

        extra_in_zip = [rel for rel in present_rel if rel not in expected]
        for rel in sorted(extra_in_zip):
            errors.append(f"unexpected file in zip: {rel}")

        for rel, entry in sorted(expected.items()):
            try:
                blob = zf.read(f"{pack_dir}/{rel}")
            except Exception as exc:
                errors.append(f"cannot read {rel}: {exc}")
                continue
            exp_bytes = entry.get("bytes")
            exp_sha = str(entry.get("sha256") or "")
            if exp_bytes is not None:
                try:
                    if int(exp_bytes) != len(blob):
                        errors.append(f"size mismatch {rel}: expected {exp_bytes} got {len(blob)}")
                except Exception:
                    errors.append(f"invalid bytes field for {rel}: {exp_bytes!r}")
            got_sha = sha256_hex(blob)
            if exp_sha and got_sha != exp_sha:
                errors.append(f"sha256 mismatch {rel}: expected {exp_sha} got {got_sha}")

        spec_receipt = str(receipts.get("batchSpecSha256") or "")
        if spec_receipt:
            try:
                spec_blob = zf.read(f"{pack_dir}/batch_spec.v1.json")
            except Exception as exc:
                errors.append(f"missing batch_spec.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(spec_blob)
                if got_sha != spec_receipt:
                    errors.append(f"batchSpecSha256 mismatch: expected {spec_receipt} got {got_sha}")

        report_receipt = str(receipts.get("batchReportSha256") or "")
        if report_receipt:
            try:
                report_blob = zf.read(f"{pack_dir}/batch_report.v1.json")
            except Exception as exc:
                errors.append(f"missing batch_report.v1.json for receipt: {exc}")
            else:
                got_sha = sha256_hex(report_blob)
                if got_sha != report_receipt:
                    errors.append(f"batchReportSha256 mismatch: expected {report_receipt} got {got_sha}")

    return errors


__all__ = [
    "build_batch_bundle_zip_bytes",
    "build_manifest",
    "sha256_hex",
    "stable_json_bytes",
    "verify_batch_bundle_zip_bytes",
    "write_batch_bundle",
]
