from __future__ import annotations

import hashlib
from collections.abc import Mapping
from copy import deepcopy
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QCheckBox,
    QDoubleSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
    QHeaderView,
    QFileDialog,
)

from helix.studio.batch.bundle import write_batch_bundle
from helix.studio.batch.model import (
    DEFAULT_OBJECTIVES,
    DEFAULT_WEIGHTS,
    PAIR_OBJECTIVES,
    PAIR_WEIGHTS,
    PAIR_NORMALIZATION,
    normalized_composite_score,
    run_batch,
)
from helix.studio.edit_plan import edit_plan_to_dict
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.session import SessionModel, RunKind
from helix.studio.export_gate import build_export_context
from helix.studio.ui.export_gate import ensure_export_allowed
from helix.studio.ui_tokens import MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font
from helix.studio.workers import CancelToken, run_bg


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _pam_pattern_from(value: Any) -> str:
    if isinstance(value, str):
        token = value.strip().upper()
        if len(token) == 3 and all(ch in {"A", "C", "G", "T", "N"} for ch in token):
            return token
        if "NGG" in token:
            return "NGG"
        if "NAG" in token:
            return "NAG"
    return "NGG"


def _pam_class_from(value: Any, pam_pattern: str) -> str:
    if isinstance(value, str) and value.strip():
        return value.strip().replace("_", "-")
    return f"SpCas9-{pam_pattern}"


def _build_batch_spec(session: SessionModel, *, pair_mode: bool = False) -> tuple[dict[str, Any], dict[str, Any]] | None:
    spec_payload = experiment_spec_to_dict(session.state.experiment_spec)
    locus = spec_payload.get("locus") if isinstance(spec_payload.get("locus"), Mapping) else {}
    contig = str(locus.get("chr") or locus.get("contig") or "")
    window_start = _safe_int(locus.get("start"), 0)
    window_end = _safe_int(locus.get("end"), 0)

    genome = getattr(session.state, "genome", None)
    sequences = getattr(genome, "sequences", None)
    if not contig or not isinstance(sequences, Mapping):
        return None
    seq = sequences.get(contig)
    if not isinstance(seq, str) or not seq:
        return None

    window_start = max(0, min(window_start, len(seq)))
    window_end = max(window_start, min(window_end, len(seq)))
    if window_end <= window_start:
        return None
    window_seq = seq[window_start:window_end]
    window_sha = hashlib.sha256(window_seq.encode("utf-8")).hexdigest()

    cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
    guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
    run_cfg = cfg.get("run_config") if isinstance(cfg.get("run_config"), Mapping) else {}

    guide_len = len(str(guide.get("sequence") or "")) if isinstance(guide, Mapping) else 0
    guide_len = guide_len if guide_len > 0 else 20
    pam_pattern = _pam_pattern_from(guide.get("pam") if isinstance(guide, Mapping) else None)
    pam_profile = run_cfg.get("pam_profile") if isinstance(run_cfg, Mapping) else None
    pam_class = _pam_class_from(pam_profile, pam_pattern)

    spec = {
        "schema": "helix_batch_spec_v1",
        "reference": {
            "contig": contig,
            "windowStart": window_start,
            "windowEnd": window_end,
            "windowSha256": window_sha,
        },
        "nuclease": {
            "name": "SpCas9",
            "pamPattern": pam_pattern,
            "pamClass": pam_class,
        },
        "constraints": dict(spec_payload.get("constraints") or {}),
        "candidateSettings": {
            "guideLength": guide_len,
            "pamPattern": pam_pattern,
            "strandPolicy": "both",
        },
        "caps": {
            "maxCandidates": 50,
            "maxOffTargetHits": 200,
            "maxMismatches": 3,
        },
        "ranking": {
            "version": "v1",
            "weights": {
                "desiredFrequency": 1.0,
                "highRiskOffTargets": 2.0,
                "clonesNeeded": 0.01,
                "validationBurden": 0.5,
            },
        },
        "experimentSpec": spec_payload,
    }
    if pair_mode:
        spec["candidateSettings"]["pairMode"] = True
        spec["candidateSettings"]["pairTopN"] = 20
        spec["caps"]["maxPairs"] = 100
        spec["caps"]["maxCandidates"] = max(int(spec["caps"].get("maxCandidates") or 0), 20)
        spec["ranking"]["objectives"] = list(PAIR_OBJECTIVES)
        spec["ranking"]["weights"] = dict(PAIR_WEIGHTS)
        spec["ranking"]["normalization"] = dict(PAIR_NORMALIZATION)
    return spec, dict(sequences)


class BatchComparePanel(QWidget):
    def __init__(self, session: SessionModel | None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._spec: dict[str, Any] | None = None
        self._report: dict[str, Any] | None = None
        self._candidates: list[dict[str, Any]] = []
        self._visible_candidates: list[dict[str, Any]] = []
        self._run_token = CancelToken()
        self._syncing = False
        self._weight_inputs: dict[str, QDoubleSpinBox] = {}
        self._weights_order = list(DEFAULT_OBJECTIVES)
        self._pareto_only = False
        self._validation_cost_enabled = True
        self._pair_mode = False
        self._decision_mode: str = "filter_only"
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}

        self.setFont(base_font())
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(SPACING_MEDIUM)

        header = QHBoxLayout()
        header.setSpacing(SPACING_SMALL)
        self._toggle = QToolButton(self)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(True)
        self._toggle.setArrowType(Qt.DownArrow)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.setText("Batch compare")
        header.addWidget(self._toggle)
        header.addStretch(1)

        self._run_button = QToolButton(self)
        self._run_button.setText("Run batch scan")
        header.addWidget(self._run_button)

        self._pair_toggle = QCheckBox("Pairs mode (2 guides)", self)
        self._pair_toggle.setChecked(False)
        header.addWidget(self._pair_toggle)

        self._export_button = QToolButton(self)
        self._export_button.setText("Export batch report")
        self._export_button.setEnabled(False)
        header.addWidget(self._export_button)

        self._apply_button = QToolButton(self)
        self._apply_button.setText("Apply to session")
        self._apply_button.setEnabled(False)
        header.addWidget(self._apply_button)

        root.addLayout(header)

        self._body = QFrame(self)
        body_layout = QVBoxLayout(self._body)
        body_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        body_layout.setSpacing(SPACING_MEDIUM)

        self._summary_label = QLabel("Run a batch scan to compare candidates.", self)
        self._summary_label.setWordWrap(True)
        body_layout.addWidget(self._summary_label)

        self._status_label = QLabel("", self)
        self._status_label.setStyleSheet("color: palette(mid);")
        self._status_label.hide()
        body_layout.addWidget(self._status_label)

        ranking_box = QFrame(self)
        self._ranking_box = ranking_box
        ranking_layout = QHBoxLayout(ranking_box)
        ranking_layout.setContentsMargins(0, 0, 0, 0)
        ranking_layout.setSpacing(SPACING_MEDIUM)

        ranking_title = QLabel("Ranking", self)
        ranking_title.setStyleSheet("font-weight: 600;")
        ranking_layout.addWidget(ranking_title)

        weights_layout = QHBoxLayout()
        weights_layout.setSpacing(SPACING_SMALL)
        for key, label in [
            ("desiredFrequency", "Desired"),
            ("highRiskOffTargets", "High risk"),
            ("clonesNeeded95", "Clones"),
            ("validationBurden", "Validation"),
            ("validationCost", "Validation cost"),
        ]:
            item = QVBoxLayout()
            item.setSpacing(2)
            item.addWidget(QLabel(label, self))
            spin = QDoubleSpinBox(self)
            spin.setRange(0.0, 1.0)
            spin.setDecimals(2)
            spin.setSingleStep(0.05)
            spin.setValue(float(DEFAULT_WEIGHTS.get(key, 0.0)))
            spin.valueChanged.connect(lambda _=0.0, k=key: self._on_weight_changed(k))
            self._weight_inputs[key] = spin
            item.addWidget(spin)
            weights_layout.addLayout(item)
        ranking_layout.addLayout(weights_layout)

        self._pareto_toggle = QCheckBox("Show Pareto only", self)
        self._pareto_toggle.toggled.connect(self._on_pareto_toggled)
        ranking_layout.addWidget(self._pareto_toggle)
        ranking_layout.addStretch(1)
        body_layout.addWidget(ranking_box)

        table_row = QHBoxLayout()
        table_row.setSpacing(SPACING_MEDIUM)

        self._table = QTableWidget(self)
        self._table.setColumnCount(9)
        self._table.setHorizontalHeaderLabels(
            [
                "Rank",
                "Guide",
                "Desired %",
                "High risk",
                "Clones (95%)",
                "Val cost",
                "Assay",
                "Score",
                "Pareto",
            ]
        )
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setSelectionMode(QTableWidget.SingleSelection)
        self._table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._table.setShowGrid(True)
        try:
            header_widget = self._table.horizontalHeader()
            header_widget.setSectionResizeMode(0, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(1, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(2, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(3, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(4, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(5, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(6, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(7, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(8, QHeaderView.ResizeToContents)
        except Exception:
            pass
        table_row.addWidget(self._table, stretch=3)

        self._detail = QFrame(self)
        detail_layout = QVBoxLayout(self._detail)
        detail_layout.setContentsMargins(SPACING_SMALL, SPACING_SMALL, SPACING_SMALL, SPACING_SMALL)
        detail_layout.setSpacing(SPACING_SMALL)

        self._detail_title = QLabel("Details", self)
        self._detail_title.setStyleSheet("font-weight: 600;")
        detail_layout.addWidget(self._detail_title)

        self._detail_targets = QLabel("Targets: —", self)
        self._detail_targets.setWordWrap(True)
        detail_layout.addWidget(self._detail_targets)

        self._detail_offtargets = QLabel("Top off-target hits: —", self)
        self._detail_offtargets.setWordWrap(True)
        detail_layout.addWidget(self._detail_offtargets)

        self._detail_primers = QLabel("Primary primers: —", self)
        self._detail_primers.setWordWrap(True)
        detail_layout.addWidget(self._detail_primers)

        self._detail_assay = QLabel("Assay rationale: —", self)
        self._detail_assay.setWordWrap(True)
        detail_layout.addWidget(self._detail_assay)

        self._detail_validation_cost = QLabel("Validation cost: —", self)
        self._detail_validation_cost.setWordWrap(True)
        detail_layout.addWidget(self._detail_validation_cost)

        self._history_container = QFrame(self)
        history_layout = QVBoxLayout(self._history_container)
        history_layout.setContentsMargins(0, SPACING_SMALL, 0, 0)
        history_layout.setSpacing(SPACING_SMALL)

        self._history_title = QLabel("Applied history", self)
        self._history_title.setStyleSheet("font-weight: 600;")
        history_layout.addWidget(self._history_title)
        self._history_list = QVBoxLayout()
        self._history_list.setSpacing(SPACING_SMALL)
        history_layout.addLayout(self._history_list)
        detail_layout.addWidget(self._history_container)

        detail_layout.addStretch(1)
        table_row.addWidget(self._detail, stretch=2)

        body_layout.addLayout(table_row)

        self._empty_label = QLabel("No batch results yet.", self)
        self._empty_label.setStyleSheet("color: palette(mid);")
        self._empty_label.hide()
        body_layout.addWidget(self._empty_label)

        root.addWidget(self._body)

        self._toggle.toggled.connect(self._on_toggle)
        self._run_button.clicked.connect(self._on_run_clicked)
        self._pair_toggle.toggled.connect(self._on_pair_mode_toggled)
        self._export_button.clicked.connect(self._on_export_clicked)
        self._apply_button.clicked.connect(self._apply_selected)
        self._table.itemSelectionChanged.connect(self._on_selection_changed)
        self._table.cellDoubleClicked.connect(self._on_row_activated)

        if self._session is not None:
            try:
                self._session.stateChanged.connect(self._on_state_changed)
            except Exception:
                pass
        self._update_decision_mode_from_session()
        self._render_history()

    def _update_decision_mode_from_session(self) -> None:
        mode = "filter_only"
        if self._session is not None:
            try:
                from helix.studio.run_artifact import artifact_decision_mode_eligible, artifact_is_valid

                artifact = self._session.ensure_run_artifact()
                if artifact_is_valid(artifact) and artifact_decision_mode_eligible(artifact):
                    mode = "decision_grade"
            except Exception:
                mode = "filter_only"
        self._decision_mode = mode
        self._apply_decision_mode_gate()

    def _apply_decision_mode_gate(self) -> None:
        filter_only = self._decision_mode != "decision_grade"
        try:
            if hasattr(self, "_ranking_box") and getattr(self, "_ranking_box") is not None:
                self._ranking_box.setVisible(not filter_only)
        except Exception:
            pass
        try:
            # Hide ranking-derived columns in filter-only mode (no guide ranking).
            self._table.setColumnHidden(0, filter_only)  # Rank
            self._table.setColumnHidden(7, filter_only)  # Score
            self._table.setColumnHidden(8, filter_only)  # Pareto
        except Exception:
            pass
        try:
            if filter_only:
                self._export_button.setEnabled(False)
                self._export_button.setToolTip("Disabled in filter-only mode (batch ranking export is not decision safe).")
            else:
                self._export_button.setToolTip("Export batch report")
                self._export_button.setEnabled(bool(self._candidates))
        except Exception:
            pass

    def _on_toggle(self, checked: bool) -> None:
        try:
            self._body.setVisible(bool(checked))
        except Exception:
            pass
        try:
            self._toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        except Exception:
            pass

    def _on_pair_mode_toggled(self, checked: bool) -> None:
        if self._syncing:
            self._pair_mode = bool(checked)
            return
        self._pair_mode = bool(checked)
        self._syncing = True
        try:
            if self._pair_mode:
                burden_spin = self._weight_inputs.get("validationBurden")
                if burden_spin is not None:
                    burden_spin.setValue(0.0)
                    burden_spin.setEnabled(False)
            else:
                burden_spin = self._weight_inputs.get("validationBurden")
                if burden_spin is not None:
                    burden_spin.setEnabled(True)
        finally:
            self._syncing = False
        if self._report is not None:
            self._summary_label.setText("Pair mode changed; run batch scan to refresh candidates.")

    def _on_state_changed(self, _state) -> None:
        self._update_decision_mode_from_session()
        if self._report is None:
            self._render_history()
            return
        self._summary_label.setText("Session changed; run batch scan to refresh candidates.")
        self._render_history()

    def _set_running(self, running: bool, message: str | None = None) -> None:
        self._run_button.setEnabled(not running)
        if message:
            self._status_label.setText(message)
            self._status_label.show()
        else:
            self._status_label.hide()

    def _report_is_pair_mode(self, report: Mapping[str, Any]) -> bool:
        if bool(report.get("pairMode")):
            return True
        candidates = report.get("candidates") if isinstance(report.get("candidates"), list) else []
        for cand in candidates:
            if isinstance(cand, Mapping) and isinstance(cand.get("guides"), list) and len(cand.get("guides")) > 1:
                return True
        return False

    def _on_run_clicked(self) -> None:
        if self._session is None:
            return
        built = _build_batch_spec(self._session, pair_mode=self._pair_mode)
        if built is None:
            self._summary_label.setText("Batch scan unavailable: missing locus window or genome.")
            return
        spec, genome_sequences = built
        self._set_running(True, "Running batch scan…")

        def _run() -> dict[str, Any]:
            cache_cfg = None
            workers = None
            try:
                cfg = self._session.state.config if self._session is not None else {}
                if isinstance(cfg, Mapping):
                    cache_cfg = cfg.get("reference_cache") or cfg.get("referenceCache")
                    batch_cfg = cfg.get("batch_parallelism") or cfg.get("batchParallelism")
                    if isinstance(batch_cfg, Mapping):
                        workers = batch_cfg.get("workers")
            except Exception:
                cache_cfg = None
            report = run_batch(
                spec,
                genome_sequences=genome_sequences,
                reference_cache_config=cache_cfg,
                workers=workers,
            )
            return {"spec": spec, "report": report}

        def _on_ok(result: dict[str, Any]) -> None:
            self._set_running(False)
            self._set_results(result["spec"], result["report"])

        def _on_err(err: str) -> None:
            self._set_running(False)
            self._summary_label.setText(err)

        run_bg(_run, _on_ok, _on_err, label="Batch scan", token=self._run_token)

    def _set_results(self, spec: Mapping[str, Any], report: Mapping[str, Any]) -> None:
        self._spec = dict(spec)
        self._report = dict(report)
        self._pair_mode = self._report_is_pair_mode(report)
        self._update_decision_mode_from_session()
        self._syncing = True
        try:
            self._pair_toggle.setChecked(self._pair_mode)
        finally:
            self._syncing = False
        self._candidates = [dict(c) for c in report.get("candidates", []) if isinstance(c, Mapping)]
        if self._decision_mode == "decision_grade":
            self._load_ranking_spec(report)
            self._rerank_candidates()
            self._summary_label.setText(
                f"Batch scan ranked {len(self._candidates)} candidate(s)."
                + (" Truncated." if bool(report.get("isTruncated")) else "")
            )
        else:
            # Filter-only: no ranking. Preserve a stable, non-scored ordering.
            for cand in self._candidates:
                cand.pop("compositeScore", None)
            self._candidates.sort(key=self._candidate_sort_key)
            self._summary_label.setText(
                f"Batch scan evaluated {len(self._candidates)} candidate(s) (filter-only; not ranked)."
                + (" Truncated." if bool(report.get("isTruncated")) else "")
            )
        self._render_table(self._filtered_candidates())
        self._empty_label.setVisible(len(self._candidates) == 0)

    def _candidate_sort_key(self, cand: Mapping[str, Any]) -> tuple[str, int, str, str]:
        pair_guides = cand.get("guides") if isinstance(cand.get("guides"), list) else []
        guide = None
        if pair_guides and isinstance(pair_guides[0], Mapping):
            guide = pair_guides[0]
        if guide is None and isinstance(cand.get("guide"), Mapping):
            guide = cand.get("guide")
        guide = guide if isinstance(guide, Mapping) else {}
        contig = str(guide.get("contig") or "")
        strand = str(guide.get("strand") or "+")
        pos = cand.get("cutIndex")
        if pos is None:
            pos = guide.get("start")
        return (contig, _safe_int(pos, 0), strand, str(cand.get("candidateKey") or ""))

    def _render_table(self, rows: list[dict[str, Any]]) -> None:
        self._visible_candidates = list(rows)
        self._table.setRowCount(len(rows))
        for idx, cand in enumerate(rows, start=1):
            pair_guides = cand.get("guides") if isinstance(cand.get("guides"), list) else []
            is_pair = bool(pair_guides) and len(pair_guides) > 1
            if is_pair:
                cut_indices = cand.get("cutIndices") if isinstance(cand.get("cutIndices"), list) else []
                labels = []
                for idx_guide, guide_entry in enumerate(pair_guides):
                    if not isinstance(guide_entry, Mapping):
                        continue
                    contig = str(guide_entry.get("contig") or "")
                    strand = str(guide_entry.get("strand") or "+")
                    cut_index = None
                    if idx_guide < len(cut_indices):
                        cut_index = cut_indices[idx_guide]
                    if cut_index is None:
                        cut_index = guide_entry.get("start")
                    pos = _safe_int(cut_index, 0)
                    labels.append(f"{contig}:{pos} {strand}".strip())
                guide_label = " + ".join(labels) if labels else str(cand.get("candidateKey") or "—")
            else:
                guide = cand.get("guide") if isinstance(cand.get("guide"), Mapping) else {}
                contig = str(guide.get("contig") or "")
                strand = str(guide.get("strand") or "+")
                cut_index = cand.get("cutIndex")
                if cut_index is None:
                    cut_index = guide.get("start")
                pos = _safe_int(cut_index, 0)
                guide_label = f"{contig}:{pos} {strand}".strip()

            desired = float(
                (cand.get("combinedSummary") or {}).get("expectedAllTargetsEdited")
                or (cand.get("outcomeSummary") or {}).get("desiredFrequency")
                or 0.0
            )
            desired_text = f"{desired * 100:.2f}%"
            high_risk = int((cand.get("offTargetSummary") or {}).get("highRiskCount") or 0)
            clones = (cand.get("clonePlanSummary") or {}).get("clonesNeeded")
            clones_text = "N/A" if clones is None else str(int(clones))
            val_cost = cand.get("totalValidationCost")
            val_cost_text = "—" if val_cost is None else str(int(val_cost))
            assay = str((cand.get("assayPlanSummary") or {}).get("recommendedAssay") or "—")
            assay_targets = cand.get("assayTargets") if isinstance(cand.get("assayTargets"), list) else []
            if assay_targets:
                entries = [e for e in assay_targets if isinstance(e, Mapping)]
                entries.sort(key=lambda e: str(e.get("targetId") or ""))
                assays = [str(e.get("recommendedAssay") or "—") for e in entries]
                if assays:
                    if len(set(assays)) == 1:
                        assay = assays[0]
                    else:
                        assay = "/".join(assays)
            score = float(cand.get("compositeScore") or 0.0)
            score_text = f"{score:.3f}"
            is_pareto = bool(cand.get("isPareto") or cand.get("paretoFront"))
            pareto_text = "Pareto" if is_pareto else "—"

            cells = [
                str(idx),
                guide_label,
                desired_text,
                str(high_risk),
                clones_text,
                val_cost_text,
                assay,
                score_text,
                pareto_text,
            ]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._table.setItem(idx - 1, col, item)

        self._apply_button.setEnabled(False)
        self._render_details(None)

    def _on_selection_changed(self) -> None:
        rows = self._table.selectionModel().selectedRows() if self._table.selectionModel() else []
        if not rows:
            self._apply_button.setEnabled(False)
            self._render_details(None)
            return
        row = rows[0].row()
        if 0 <= row < len(self._visible_candidates):
            self._apply_button.setEnabled(True)
            self._render_details(self._visible_candidates[row])

    def _render_details(self, candidate: Mapping[str, Any] | None) -> None:
        if not candidate:
            self._detail_targets.setText("Targets: —")
            self._detail_offtargets.setText("Top off-target hits: —")
            self._detail_primers.setText("Primary primers: —")
            self._detail_assay.setText("Assay rationale: —")
            self._detail_validation_cost.setText("Validation cost: —")
            return

        pair_targets = candidate.get("pairTargets") if isinstance(candidate.get("pairTargets"), list) else []
        if pair_targets:
            entries = [t for t in pair_targets if isinstance(t, Mapping)]
            entries.sort(key=lambda t: str(t.get("targetId") or ""))
            lines = []
            for entry in entries:
                tid = str(entry.get("targetId") or "")
                desired = float(entry.get("desiredFrequency") or 0.0)
                clones = entry.get("clonesNeeded")
                clones_text = "N/A" if clones is None else str(int(clones))
                assay = str(entry.get("recommendedAssay") or "—")
                lines.append(f"{tid}: desired {desired * 100:.2f}%, clones {clones_text}, assay {assay}")
            self._detail_targets.setText("Targets:\n" + "\n".join(lines) if lines else "Targets: —")
        else:
            self._detail_targets.setText("Targets: primary")

        top_hits = candidate.get("topOffTargets") if isinstance(candidate.get("topOffTargets"), list) else []
        if top_hits:
            lines = []
            for hit in top_hits[:5]:
                if not isinstance(hit, Mapping):
                    continue
                tier = str(hit.get("riskTier") or "—")
                locus = str(hit.get("locus") or "—")
                lines.append(f"{tier} • {locus}")
            text = "Top off-target hits:\n" + "\n".join(lines) if lines else "Top off-target hits: —"
        else:
            text = "Top off-target hits: —"
        union_high = int((candidate.get("offTargetSummary") or {}).get("highRiskCount") or 0)
        union_medium = int((candidate.get("offTargetSummary") or {}).get("mediumRiskCount") or 0)
        union_low = int((candidate.get("offTargetSummary") or {}).get("lowRiskCount") or 0)
        union_line = f"Union off-targets: High {union_high}, Medium {union_medium}, Low {union_low}"
        if text != "Top off-target hits: —":
            text = union_line + "\n" + text
        else:
            text = union_line
        self._detail_offtargets.setText(text)

        status_by_target = (
            candidate.get("primaryPrimerStatusByTarget")
            if isinstance(candidate.get("primaryPrimerStatusByTarget"), Mapping)
            else {}
        )
        notes_by_target = (
            candidate.get("primaryPrimerNotesByTarget")
            if isinstance(candidate.get("primaryPrimerNotesByTarget"), Mapping)
            else {}
        )
        if status_by_target:
            lines = []
            for tid in sorted(status_by_target.keys()):
                status = str(status_by_target.get(tid) or "missing")
                notes = notes_by_target.get(tid) if isinstance(notes_by_target.get(tid), list) else []
                line = f"{tid}: {status}"
                if notes:
                    line += " (" + "; ".join(str(note) for note in notes) + ")"
                lines.append(line)
            primer_text = "Primary primers:\n" + "\n".join(lines) if lines else "Primary primers: —"
        else:
            status = str(candidate.get("primaryPrimerStatus") or "missing")
            notes = candidate.get("primaryPrimerNotes") if isinstance(candidate.get("primaryPrimerNotes"), list) else []
            primer_text = f"Primary primers: {status}"
            if notes:
                primer_text += "\n" + "\n".join(str(note) for note in notes)
        self._detail_primers.setText(primer_text)

        rationale_by_target = (
            candidate.get("assayRationaleByTarget")
            if isinstance(candidate.get("assayRationaleByTarget"), Mapping)
            else {}
        )
        if rationale_by_target:
            lines = []
            for tid in sorted(rationale_by_target.keys()):
                reasons = rationale_by_target.get(tid) if isinstance(rationale_by_target.get(tid), list) else []
                if reasons:
                    lines.append(f"{tid}: " + "; ".join(str(r) for r in reasons))
                else:
                    lines.append(f"{tid}: —")
            rationale_text = "Assay rationale:\n" + "\n".join(lines) if lines else "Assay rationale: —"
        else:
            rationale = candidate.get("assayRationale") if isinstance(candidate.get("assayRationale"), list) else []
            if rationale:
                rationale_text = "Assay rationale:\n" + "\n".join(f"• {r}" for r in rationale)
            else:
                rationale_text = "Assay rationale: —"
        self._detail_assay.setText(rationale_text)

        assay_label = str((candidate.get("assayPlanSummary") or {}).get("recommendedAssay") or "—")
        assay_cost = int(candidate.get("assayCostScore") or 0)
        primer_status = str(candidate.get("primaryPrimerStatus") or "missing")
        primer_label = "ok" if primer_status.lower() == "ok" else "failed"
        if status_by_target:
            if all(str(val).lower() == "ok" for val in status_by_target.values()):
                primer_label = "ok"
            else:
                primer_label = "failed"
        primer_cost = int(candidate.get("primerFeasibilityScore") or 0)
        offtarget_count = int(candidate.get("offtargetValidationCount") or 0)
        total_cost = int(candidate.get("totalValidationCost") or (assay_cost + primer_cost + offtarget_count))
        self._detail_validation_cost.setText(
            f"Validation cost: {total_cost} (assay {assay_label}={assay_cost}, primers {primer_label}, {offtarget_count} sites)"
        )

    def _display_weights(self) -> dict[str, float]:
        weights = {}
        for key, spin in self._weight_inputs.items():
            try:
                weights[key] = float(spin.value())
            except Exception:
                weights[key] = float(DEFAULT_WEIGHTS.get(key, 0.0))
        return weights

    def _map_weights_for_display(self, weights: Mapping[str, Any]) -> dict[str, float]:
        if self._pair_mode:
            desired_weight = weights.get("allTargetsEdited")
            if desired_weight is None:
                desired_weight = weights.get("desiredFrequency")
            clones_weight = weights.get("worstClonesNeeded")
            if clones_weight is None:
                clones_weight = weights.get("clonesNeeded95")
            return {
                "desiredFrequency": float(desired_weight or DEFAULT_WEIGHTS["desiredFrequency"]),
                "highRiskOffTargets": float(weights.get("highRiskOffTargets", DEFAULT_WEIGHTS["highRiskOffTargets"])),
                "clonesNeeded95": float(clones_weight or DEFAULT_WEIGHTS["clonesNeeded95"]),
                "validationBurden": 0.0,
                "validationCost": float(weights.get("validationCost", DEFAULT_WEIGHTS["validationCost"])),
            }
        return {**DEFAULT_WEIGHTS, **{k: float(v) for k, v in dict(weights).items()}}

    def _map_weights_for_spec(self, weights: Mapping[str, Any]) -> dict[str, float]:
        if self._pair_mode:
            return {
                "allTargetsEdited": float(weights.get("desiredFrequency", 0.0)),
                "highRiskOffTargets": float(weights.get("highRiskOffTargets", 0.0)),
                "worstClonesNeeded": float(weights.get("clonesNeeded95", 0.0)),
                "validationCost": float(weights.get("validationCost", 0.0)),
            }
        return {k: float(v) for k, v in dict(weights).items()}

    def _current_weights(self) -> dict[str, float]:
        display = self._normalize_weights(self._display_weights())
        if not self._validation_cost_enabled:
            display["validationCost"] = 0.0
        return self._map_weights_for_spec(display)

    def _normalize_weights(self, weights: dict[str, float]) -> dict[str, float]:
        clamped = {k: max(0.0, min(1.0, float(v))) for k, v in weights.items()}
        if not self._validation_cost_enabled:
            clamped["validationCost"] = 0.0
        if self._pair_mode:
            clamped["validationBurden"] = 0.0
        allowed_keys = [
            key
            for key in clamped.keys()
            if (key != "validationCost" or self._validation_cost_enabled)
            and not (self._pair_mode and key == "validationBurden")
        ]
        total = sum(clamped[key] for key in allowed_keys)
        if total <= 0:
            keys = allowed_keys
            equal = round(1.0 / max(1, len(keys)), 2)
            normalized = {
                k: (equal if k in keys else 0.0) for k in clamped.keys()
            }
        else:
            normalized = {}
            for key, value in clamped.items():
                if key not in allowed_keys:
                    normalized[key] = 0.0
                else:
                    normalized[key] = round(value / total, 2)
        sum_norm = round(sum(normalized.values()), 2)
        delta = round(1.0 - sum_norm, 2)
        if abs(delta) >= 0.01:
            # Adjust the largest weight deterministically to keep sum == 1.0.
            ordered = [k for k in self._weights_order if k in allowed_keys]
            max_key = max(ordered, key=lambda k: (normalized.get(k, 0.0), -ordered.index(k)))
            normalized[max_key] = round(max(0.0, min(1.0, normalized.get(max_key, 0.0) + delta)), 2)
        return normalized

    def _load_ranking_spec(self, report: Mapping[str, Any]) -> None:
        ranking_spec = report.get("rankingSpec") if isinstance(report.get("rankingSpec"), Mapping) else {}
        raw_weights = ranking_spec.get("weights") if isinstance(ranking_spec.get("weights"), Mapping) else {}
        weights = self._map_weights_for_display(raw_weights)
        has_validation_cost = False
        if "validationCost" in raw_weights:
            has_validation_cost = True
        else:
            for cand in report.get("candidates", []) if isinstance(report.get("candidates"), list) else []:
                if isinstance(cand, Mapping):
                    vector = cand.get("objectiveVector") or {}
                    if isinstance(vector, Mapping) and "validationCost" in vector:
                        has_validation_cost = True
                        break
                    if "totalValidationCost" in cand:
                        has_validation_cost = True
                        break
        self._validation_cost_enabled = has_validation_cost
        if not has_validation_cost:
            weights["validationCost"] = 0.0
        weights = self._normalize_weights(weights)
        self._syncing = True
        try:
            for key, spin in self._weight_inputs.items():
                spin.setValue(float(weights.get(key, DEFAULT_WEIGHTS.get(key, 0.0))))
                if key == "validationCost":
                    spin.setEnabled(self._validation_cost_enabled)
                if key == "validationBurden":
                    spin.setEnabled(not self._pair_mode)
        finally:
            self._syncing = False

    def _on_weight_changed(self, _key: str) -> None:
        if self._decision_mode != "decision_grade":
            return
        if self._syncing:
            return
        weights = self._normalize_weights(self._display_weights())
        self._syncing = True
        try:
            for key, spin in self._weight_inputs.items():
                spin.setValue(float(weights.get(key, DEFAULT_WEIGHTS.get(key, 0.0))))
        finally:
            self._syncing = False
        self._apply_weights(self._map_weights_for_spec(weights))

    def _apply_weights(self, weights: dict[str, float]) -> None:
        if self._decision_mode != "decision_grade":
            return
        if self._report is None:
            return
        ranking_spec = self._report.get("rankingSpec") if isinstance(self._report.get("rankingSpec"), Mapping) else {}
        ranking_spec = dict(ranking_spec)
        ranking_spec["weights"] = dict(weights)
        self._report["rankingSpec"] = ranking_spec
        if self._spec is not None:
            ranking = self._spec.get("ranking") if isinstance(self._spec.get("ranking"), Mapping) else {}
            ranking = dict(ranking)
            ranking["weights"] = dict(weights)
            self._spec["ranking"] = ranking
        self._rerank_candidates()

    def _rerank_candidates(self) -> None:
        if self._decision_mode != "decision_grade":
            return
        if not self._candidates:
            return
        weights = self._current_weights()
        for candidate in self._candidates:
            vector = candidate.get("objectiveVector") or candidate.get("paretoVector") or {}
            candidate["compositeScore"] = normalized_composite_score(vector, weights)
        self._candidates.sort(
            key=lambda c: (
                float(c.get("compositeScore") or 0.0),
                str(c.get("candidateKey") or ""),
            )
        )
        if self._report is not None:
            self._report["candidates"] = list(self._candidates)
        self._render_table(self._filtered_candidates())

    def _filtered_candidates(self) -> list[dict[str, Any]]:
        if self._decision_mode != "decision_grade":
            return list(self._candidates)
        if not self._pareto_only:
            return list(self._candidates)
        return [c for c in self._candidates if bool(c.get("isPareto") or c.get("paretoFront"))]

    def _on_pareto_toggled(self, checked: bool) -> None:
        if self._decision_mode != "decision_grade":
            return
        self._pareto_only = bool(checked)
        self._render_table(self._filtered_candidates())

    def _render_history(self) -> None:
        while self._history_list.count():
            item = self._history_list.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        if self._session is None:
            self._history_container.hide()
            return
        history = getattr(self._session.state, "apply_history", []) or []
        if not isinstance(history, list) or not history:
            self._history_container.hide()
            return
        self._history_container.show()

        def _history_key(entry: Mapping[str, Any]) -> int:
            return _safe_int(entry.get("id"), 0)

        ordered = sorted(
            [entry for entry in history if isinstance(entry, Mapping)],
            key=_history_key,
            reverse=True,
        )
        for entry in ordered[:5]:
            row = QHBoxLayout()
            row.setSpacing(SPACING_SMALL)
            entry_id = _safe_int(entry.get("id"), 0)
            candidate_key = str(entry.get("candidateKey") or "unknown")
            note = str(entry.get("note") or "").strip()
            label = f"#{entry_id} {candidate_key}"
            if note:
                label = f"{label} · {note}"
            text = QLabel(label, self)
            row.addWidget(text)
            row.addStretch(1)
            btn = QToolButton(self)
            btn.setText("Revert")
            btn.clicked.connect(lambda _=False, e=dict(entry): self._revert_history_entry(e))
            row.addWidget(btn)
            container = QFrame(self)
            container.setLayout(row)
            self._history_list.addWidget(container)

    def _next_history_id(self) -> int:
        if self._session is None:
            return 1
        history = getattr(self._session.state, "apply_history", []) or []
        if not isinstance(history, list) or not history:
            return 1
        return max(_safe_int(entry.get("id"), 0) for entry in history if isinstance(entry, Mapping)) + 1

    def _capture_plan_snapshot(self) -> dict[str, Any]:
        if self._session is None:
            return {}
        cfg = self._session.state.config if isinstance(self._session.state.config, Mapping) else {}
        snapshot_cfg: dict[str, Any] = {}
        for key in ("guide", "sim_payload", "sim_type"):
            if key in cfg:
                snapshot_cfg[key] = deepcopy(cfg.get(key))
            else:
                snapshot_cfg[key] = None
        spec_payload = experiment_spec_to_dict(self._session.state.experiment_spec)
        locus = spec_payload.get("locus") if isinstance(spec_payload.get("locus"), Mapping) else {}
        snapshot_spec = {"locus": deepcopy(dict(locus))}
        snapshot_plan = edit_plan_to_dict(self._session.state.edit_plan)
        return {
            "config": snapshot_cfg,
            "experiment_spec": snapshot_spec,
            "edit_plan": deepcopy(snapshot_plan),
            "run_kind": self._session.state.run_kind.name,
        }

    def _apply_snapshot(self, snapshot: Mapping[str, Any], *, candidate_key: str, note: str) -> None:
        if self._session is None:
            return
        cfg = dict(self._session.state.config or {})
        snap_cfg = snapshot.get("config") if isinstance(snapshot.get("config"), Mapping) else {}
        for key, value in snap_cfg.items():
            if value is None:
                cfg.pop(key, None)
            else:
                cfg[key] = deepcopy(value)
        spec_payload = experiment_spec_to_dict(self._session.state.experiment_spec)
        snap_spec = snapshot.get("experiment_spec") if isinstance(snapshot.get("experiment_spec"), Mapping) else {}
        locus = snap_spec.get("locus") if isinstance(snap_spec.get("locus"), Mapping) else None
        if locus is not None:
            spec_payload["locus"] = deepcopy(dict(locus))
        snap_plan = snapshot.get("edit_plan")

        update_kwargs = {"config": cfg, "experiment_spec": spec_payload, "viz_dirty": True}
        if snap_plan is not None:
            update_kwargs["edit_plan"] = deepcopy(edit_plan_to_dict(snap_plan))
        run_kind_name = str(snapshot.get("run_kind") or "")
        if run_kind_name and run_kind_name in RunKind.__members__:
            update_kwargs["run_kind"] = RunKind[run_kind_name]

        history = getattr(self._session.state, "apply_history", []) or []
        history = list(history) if isinstance(history, list) else []
        next_id = self._next_history_id()
        history.append(
            {
                "id": next_id,
                "seq": next_id,
                "candidateKey": candidate_key,
                "previous": self._capture_plan_snapshot(),
                "next": snapshot,
                "note": note,
            }
        )
        update_kwargs["apply_history"] = history
        self._session.update(**update_kwargs)

    def _revert_history_entry(self, entry: Mapping[str, Any]) -> None:
        previous = entry.get("previous") if isinstance(entry.get("previous"), Mapping) else None
        if not previous:
            return
        candidate_key = str(entry.get("candidateKey") or "history")
        self._apply_snapshot(previous, candidate_key=candidate_key, note="Reverted from history")

    def _on_row_activated(self, row: int, _column: int) -> None:
        if 0 <= row < len(self._visible_candidates):
            self._apply_candidate(self._visible_candidates[row])

    def _apply_selected(self) -> None:
        rows = self._table.selectionModel().selectedRows() if self._table.selectionModel() else []
        if not rows:
            return
        row = rows[0].row()
        if 0 <= row < len(self._visible_candidates):
            self._apply_candidate(self._visible_candidates[row])

    def _apply_candidate(self, candidate: Mapping[str, Any]) -> None:
        if self._session is None:
            return
        previous_snapshot = self._capture_plan_snapshot()
        spec = self._spec or experiment_spec_to_dict(self._session.state.experiment_spec)
        reference = spec.get("reference") if isinstance(spec.get("reference"), Mapping) else {}
        contig = str(reference.get("contig") or "")
        window_start = _safe_int(reference.get("windowStart"), 0)
        window_end = _safe_int(reference.get("windowEnd"), 0)

        genome = getattr(self._session.state, "genome", None)
        sequences = getattr(genome, "sequences", None)
        if not isinstance(sequences, Mapping):
            return
        seq = sequences.get(contig)
        if not isinstance(seq, str) or not seq:
            return
        window_start = max(0, min(window_start, len(seq)))
        window_end = max(window_start, min(window_end, len(seq)))
        if window_end <= window_start:
            return
        window_seq = seq[window_start:window_end]

        pair_guides = candidate.get("guides") if isinstance(candidate.get("guides"), list) else []
        is_pair = bool(pair_guides) and len(pair_guides) > 1
        guides = [dict(g) for g in pair_guides if isinstance(g, Mapping)] if is_pair else [
            dict(candidate.get("guide") or {})
        ]
        cut_indices = candidate.get("cutIndices") if isinstance(candidate.get("cutIndices"), list) else []
        if not cut_indices:
            cut_indices = [candidate.get("cutIndex")] if not is_pair else [None for _ in guides]

        primary_guide = guides[0] if guides else {}
        guide_start_abs = _safe_int(primary_guide.get("start"), 0)
        guide_end_abs = _safe_int(primary_guide.get("end"), guide_start_abs + 1)
        guide_start = max(0, min(guide_start_abs - window_start, len(window_seq)))
        guide_end = max(guide_start + 1, min(guide_end_abs - window_start, len(window_seq)))
        strand = str(primary_guide.get("strand") or "+")
        locus_label = f"{contig}:{guide_start_abs}-{guide_end_abs}"

        guide_payload = {
            "id": str(primary_guide.get("id") or candidate.get("candidateKey") or "batch_candidate"),
            "contig": contig,
            "start": guide_start,
            "end": guide_end,
            "strand": strand,
            "sequence": str(primary_guide.get("sequence") or ""),
            "locus": locus_label,
            "pam": str(primary_guide.get("pam") or ""),
        }
        primary_cut = cut_indices[0] if cut_indices else candidate.get("cutIndex")
        if primary_cut is not None:
            cut_rel = _safe_int(primary_cut, 0) - window_start
            if 0 <= cut_rel <= len(window_seq):
                guide_payload["cut_index"] = cut_rel

        sim_payload = {
            "site": {"sequence": window_seq},
            "guide": dict(guide_payload),
            "outcomes": [],
            "artifact": "helix.batch.apply.v1",
        }

        spec_payload = experiment_spec_to_dict(self._session.state.experiment_spec)
        locus_payload = dict(spec_payload.get("locus") or {})
        locus_payload["chr"] = contig
        locus_payload["start"] = window_start
        locus_payload["end"] = window_end
        locus_payload["strand"] = strand if strand in {"+", "-"} else "+"
        spec_payload["locus"] = locus_payload

        targets = []
        for idx, guide in enumerate(guides):
            target_id = f"t{idx + 1}" if is_pair else "primary"
            cut_index = cut_indices[idx] if idx < len(cut_indices) else None
            targets.append(
                {
                    "targetId": target_id,
                    "contig": contig,
                    "start": guide.get("start"),
                    "end": guide.get("end"),
                    "strand": guide.get("strand") or "+",
                    "cutIndex": cut_index,
                    "gRNA": {
                        "sequence": guide.get("sequence"),
                        "pam": guide.get("pam"),
                        "pamClass": guide.get("pamClass"),
                    },
                }
            )
        edit_plan = {
            "schema": "helix_edit_plan_v1",
            "mode": "multiplex" if is_pair else "cut",
            "targets": targets,
            "notes": [],
        }

        cfg = dict(self._session.state.config or {})
        cfg["guide"] = guide_payload
        cfg["sim_payload"] = sim_payload
        cfg.setdefault("sim_type", "CRISPR")

        update_kwargs = {
            "config": cfg,
            "experiment_spec": spec_payload,
            "edit_plan": edit_plan_to_dict(edit_plan),
            "viz_dirty": True,
        }
        if self._session.state.run_kind != RunKind.CRISPR:
            update_kwargs["run_kind"] = RunKind.CRISPR
        history = getattr(self._session.state, "apply_history", []) or []
        history = list(history) if isinstance(history, list) else []
        next_id = self._next_history_id()
        candidate_key = str(candidate.get("candidateKey") or "")
        next_snapshot = {
            "config": {
                "guide": deepcopy(guide_payload),
                "sim_payload": deepcopy(sim_payload),
                "sim_type": "CRISPR",
            },
            "experiment_spec": {"locus": deepcopy(locus_payload)},
            "edit_plan": deepcopy(edit_plan_to_dict(edit_plan)),
            "run_kind": RunKind.CRISPR.name,
        }
        history.append(
            {
                "id": next_id,
                "seq": next_id,
                "candidateKey": candidate_key,
                "previous": previous_snapshot,
                "next": next_snapshot,
                "note": "Applied from batch scan",
            }
        )
        update_kwargs["apply_history"] = history
        self._session.update(**update_kwargs)
        self._render_history()

    def _on_export_clicked(self) -> None:
        if self._decision_mode != "decision_grade":
            return
        ctx = build_export_context(decision_mode=self._decision_mode, is_demo=False, run_id=None)
        intent_spec = getattr(getattr(self._session, "state", None), "experiment_intent_spec", None)
        exp_spec = getattr(getattr(self._session, "state", None), "experiment_spec", None)
        if not ensure_export_allowed(
            self,
            action_title="Export batch report",
            ctx=ctx,
            session_acks=self._export_prompt_suppressed_by_key,
            experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
            experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
        ):
            return
        if not self._spec or not self._report:
            return
        default_name = str(Path.cwd() / "helix_batch_report.zip")
        path_str, _ = QFileDialog.getSaveFileName(self, "Export batch report", default_name, "Zip archive (*.zip)")
        if not path_str:
            return
        self._write_bundle(Path(path_str))

    def _write_bundle(self, path: Path) -> None:
        if not self._spec or not self._report:
            return
        write_batch_bundle(path, spec=self._spec, report=self._report, pack_dirname="helix_batch_report")


__all__ = ["BatchComparePanel"]
