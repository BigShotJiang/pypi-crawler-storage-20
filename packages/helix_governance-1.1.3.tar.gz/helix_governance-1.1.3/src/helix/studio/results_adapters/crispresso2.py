from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix import fs
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.results_io import results_record_from_dict, sanitize_results_id

DNA_BASES = {"A", "C", "G", "T", "N"}


@dataclass(frozen=True)
class Crispresso2SubstitutionTable:
    reference: str
    counts: dict[str, list[int]]


@dataclass(frozen=True)
class Crispresso2NucleotideTable:
    reference: str
    counts: dict[str, list[int]]  # includes A,C,G,T,N,DEL


def _reverse_complement(seq: str) -> str:
    comp = {"A": "T", "C": "G", "G": "C", "T": "A", "N": "N"}
    return "".join(comp.get(base, "N") for base in reversed(seq.upper()))


def _clean_line(line: str) -> str:
    return line.strip().replace("\ufeff", "")


def _split_tokens(line: str) -> list[str]:
    return [tok for tok in line.replace(",", "\t").split() if tok]


def _is_base_row(label: str) -> bool:
    return len(label) == 1 and label.upper() in {"A", "C", "G", "T"}


def _parse_reference(tokens: list[str]) -> str | None:
    if not tokens:
        return None
    head = tokens[0].strip().upper()
    if head.startswith("REF"):
        bases = tokens[1:]
        if bases and all(len(b) == 1 and b.upper() in DNA_BASES for b in bases):
            return "".join(b.upper() for b in bases)
    if len(tokens) == 1:
        seq = tokens[0].strip().upper()
        if seq and all(ch in DNA_BASES for ch in seq):
            return seq
    if len(tokens) > 1 and all(len(b) == 1 and b.upper() in DNA_BASES for b in tokens):
        return "".join(b.upper() for b in tokens)
    return None


def parse_substitution_frequency_table(text: str) -> Crispresso2SubstitutionTable:
    lines = [_clean_line(line) for line in text.splitlines()]
    rows = [line for line in lines if line and not line.startswith("#")]
    if not rows:
        raise ValueError("Empty substitution frequency table")

    ref_seq = None
    idx = 0
    for i, line in enumerate(rows):
        tokens = _split_tokens(line)
        ref_seq = _parse_reference(tokens)
        if ref_seq:
            idx = i + 1
            break
    if not ref_seq:
        raise ValueError("Reference row not found in substitution frequency table")

    counts: dict[str, list[int]] = {"A": [], "C": [], "G": [], "T": []}
    for line in rows[idx:]:
        tokens = _split_tokens(line)
        if not tokens:
            continue
        label = tokens[0].strip().upper()
        if not _is_base_row(label):
            continue
        values = tokens[1:]
        if len(values) < len(ref_seq):
            continue
        parsed = []
        for tok in values[: len(ref_seq)]:
            try:
                parsed.append(int(round(float(tok))))
            except Exception:
                parsed.append(0)
        counts[label] = parsed

    if not any(sum(values) for values in counts.values()):
        raise ValueError("No substitution counts parsed from table")

    return Crispresso2SubstitutionTable(reference=ref_seq, counts=counts)


def parse_nucleotide_frequency_table(text: str) -> Crispresso2NucleotideTable:
    lines = [_clean_line(line) for line in text.splitlines()]
    rows = [line for line in lines if line and not line.startswith("#")]
    if not rows:
        raise ValueError("Empty nucleotide frequency table")

    ref_seq = None
    idx = 0
    for i, line in enumerate(rows):
        tokens = _split_tokens(line)
        ref_seq = _parse_reference(tokens)
        if ref_seq:
            idx = i + 1
            break
    if not ref_seq:
        raise ValueError("Reference row not found in nucleotide frequency table")

    labels = {"A", "C", "G", "T", "N", "DEL", "-"}
    counts: dict[str, list[int]] = {k: [] for k in ["A", "C", "G", "T", "N", "DEL"]}
    for line in rows[idx:]:
        tokens = _split_tokens(line)
        if not tokens:
            continue
        label = tokens[0].strip().upper()
        if label == "-":
            label = "DEL"
        if label not in labels:
            continue
        values = tokens[1:]
        if len(values) < len(ref_seq):
            continue
        parsed: list[int] = []
        for tok in values[: len(ref_seq)]:
            try:
                parsed.append(int(round(float(tok))))
            except Exception:
                parsed.append(0)
        counts[label] = parsed

    if not any(sum(values) for values in counts.values()):
        raise ValueError("No nucleotide counts parsed from table")

    return Crispresso2NucleotideTable(reference=ref_seq, counts=counts)


def _infer_editor_type(session: Any) -> str:
    editor_type = ""
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
    except Exception:
        spec = {}
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
    base_edit = assumptions.get("baseEdit") if isinstance(assumptions.get("baseEdit"), Mapping) else {}
    editor_type = str(base_edit.get("editorType") or "").strip().upper()
    if editor_type not in {"ABE", "CBE"}:
        editor_type = "ABE"
    return editor_type


def _infer_intended_index(session: Any) -> int | None:
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
    except Exception:
        return None
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
    base_edit = assumptions.get("baseEdit") if isinstance(assumptions.get("baseEdit"), Mapping) else {}
    value = base_edit.get("intendedIndex")
    if value is None:
        return None
    try:
        return int(value)
    except Exception:
        return None


def _infer_guide_sequence(session: Any) -> str | None:
    try:
        plan = session.state.edit_plan
    except Exception:
        plan = None
    if isinstance(plan, Mapping):
        targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
        for target in targets:
            if not isinstance(target, Mapping):
                continue
            g = target.get("gRNA") if isinstance(target.get("gRNA"), Mapping) else {}
            seq = g.get("sequence") if isinstance(g, Mapping) else None
            if seq:
                return str(seq).strip().upper()
    try:
        cfg = session.state.config
    except Exception:
        cfg = {}
    guide = cfg.get("guide") if isinstance(cfg, Mapping) else {}
    seq = guide.get("sequence") if isinstance(guide, Mapping) else None
    if seq:
        return str(seq).strip().upper()
    return None


def _match_guide(reference: str, guide_seq: str) -> tuple[int, str] | None:
    if not reference or not guide_seq:
        return None
    ref = reference.upper()
    guide = guide_seq.upper()
    idx = ref.find(guide)
    if idx >= 0:
        return idx, "+"
    rc = _reverse_complement(guide)
    idx = ref.find(rc)
    if idx >= 0:
        return idx, "-"
    return None


def _ppm_distribution(counts: Sequence[int]) -> list[int]:
    total = sum(counts)
    if total <= 0:
        return [0 for _ in counts]
    raw = [c * 1_000_000 / total for c in counts]
    floors = [int(val) for val in raw]
    remainder = 1_000_000 - sum(floors)
    fracs = [(raw[i] - floors[i], i) for i in range(len(raw))]
    fracs.sort(key=lambda item: (-item[0], item[1]))
    for _, idx in fracs[: max(0, remainder)]:
        floors[idx] += 1
    return floors


def build_observed_position_probs(
    table: Crispresso2SubstitutionTable,
    guide_sequence: str,
    conversion_from: str,
    conversion_to: str,
) -> tuple[list[dict[str, Any]], int, list[str]]:
    notes: list[str] = []
    if not guide_sequence:
        raise ValueError("Guide sequence is required")
    match = _match_guide(table.reference, guide_sequence)
    if match is None:
        raise ValueError("Guide sequence not found in reference row")
    guide_start, strand = match
    guide_len = len(guide_sequence)
    guide_end = guide_start + guide_len

    ref = table.reference.upper()
    from_base = conversion_from.upper()
    to_base = conversion_to.upper()
    if to_base not in table.counts:
        raise ValueError(f"No substitution counts for base {to_base}")

    conv_counts: list[int] = []
    positions: list[int] = []

    for idx in range(guide_start, guide_end):
        if idx >= len(ref):
            continue
        if ref[idx] != from_base:
            continue
        count = table.counts[to_base][idx]
        guide_idx = idx - guide_start
        if strand == "-":
            guide_idx = (guide_len - 1) - guide_idx
        pos_rel = guide_idx - (guide_len - 1)
        positions.append(pos_rel)
        conv_counts.append(int(count))

    total_events = sum(conv_counts)
    if total_events <= 0:
        notes.append("No conversion events in guide window")
        return [], 0, notes

    ppm = _ppm_distribution(conv_counts)
    probs = [val / 1_000_000.0 for val in ppm]

    observed: list[dict[str, Any]] = []
    for pos, prob in sorted(zip(positions, probs), key=lambda item: item[0]):
        observed.append({"pos": int(pos), "prob": round(prob, 6)})

    return observed, total_events, notes


def build_observed_position_probs_from_nucleotide_counts(
    table: Crispresso2NucleotideTable,
    guide_sequence: str,
    conversion_from: str,
    conversion_to: str,
    *,
    inferred_note: str,
) -> tuple[list[dict[str, Any]], int, list[str]]:
    notes: list[str] = [inferred_note]
    if not guide_sequence:
        raise ValueError("Guide sequence is required")
    match = _match_guide(table.reference, guide_sequence)
    if match is None:
        raise ValueError("Guide sequence not found in reference row")
    guide_start, strand = match
    guide_len = len(guide_sequence)
    guide_end = guide_start + guide_len

    ref = table.reference.upper()
    from_base = conversion_from.upper()
    to_base = conversion_to.upper()
    counts_map = table.counts.get(to_base)
    if counts_map is None:
        raise ValueError(f"No nucleotide counts for base {to_base}")

    conv_counts: list[int] = []
    positions: list[int] = []

    for idx in range(guide_start, guide_end):
        if idx >= len(ref):
            continue
        if ref[idx] != from_base:
            continue
        count = counts_map[idx]
        guide_idx = idx - guide_start
        if strand == "-":
            guide_idx = (guide_len - 1) - guide_idx
        pos_rel = guide_idx - (guide_len - 1)
        positions.append(pos_rel)
        conv_counts.append(int(count))

    total_events = sum(conv_counts)
    if total_events <= 0:
        notes.append("No conversion events in guide window")
        return [], 0, notes

    ppm = _ppm_distribution(conv_counts)
    probs = [val / 1_000_000.0 for val in ppm]

    observed: list[dict[str, Any]] = []
    for pos, prob in sorted(zip(positions, probs), key=lambda item: item[0]):
        observed.append({"pos": int(pos), "prob": round(prob, 6)})

    return observed, total_events, notes


def _normalize_table_path(path: Path) -> str:
    # Use POSIX-style separators and strip any leading "./" for portability.
    norm = path.as_posix()
    while norm.startswith("./"):
        norm = norm[2:]
    return norm


def _relative_table_path(table_path: Path, base_dir: Path | None) -> str:
    if base_dir is not None:
        try:
            rel = table_path.relative_to(base_dir)
            return _normalize_table_path(rel)
        except Exception:
            pass
    return _normalize_table_path(Path(table_path.name))


def build_results_record_from_crispresso2_table(
    path: Path,
    *,
    guide_sequence: str,
    conversion_from: str,
    conversion_to: str,
    intended_index: int | None = None,
    results_id: str | None = None,
    assay_type: str = "AmpliconSeq",
    table_type: str = "around",
    table_base_dir: Path | None = None,
    observed_source: str | None = "crispresso2_substitution",
    observed_inferred: bool = False,
    extra_notes: Sequence[str] | None = None,
) -> dict[str, Any]:
    raw_bytes = Path(path).read_bytes()
    text = raw_bytes.decode("utf-8")
    table = parse_substitution_frequency_table(text)
    observed_positions, total_events, notes = build_observed_position_probs(
        table,
        guide_sequence,
        conversion_from,
        conversion_to,
    )
    return _build_results_record_common(
        path=path,
        table_base_dir=table_base_dir,
        table_type=table_type,
        raw_bytes=raw_bytes,
        observed_positions=observed_positions,
        total_events=total_events,
        intended_index=intended_index,
        results_id=results_id,
        assay_type=assay_type,
        observed_source=observed_source,
        observed_inferred=observed_inferred,
        extra_notes=extra_notes,
    )


def build_results_record_from_nucleotide_table(
    path: Path,
    *,
    table: Crispresso2NucleotideTable,
    guide_sequence: str,
    conversion_from: str,
    conversion_to: str,
    intended_index: int | None = None,
    results_id: str | None = None,
    assay_type: str = "AmpliconSeq",
    table_type: str = "nf_quant",
    table_base_dir: Path | None = None,
    observed_source: str | None = "crispresso2_nucleotide_frequency",
    inferred_note: str = "ObservedPositionProbs inferred from nucleotide frequency table; may include sequencing noise",
) -> dict[str, Any]:
    raw_bytes = Path(path).read_bytes()
    observed_positions, total_events, notes = build_observed_position_probs_from_nucleotide_counts(
        table,
        guide_sequence,
        conversion_from,
        conversion_to,
        inferred_note=inferred_note,
    )
    return _build_results_record_common(
        path=path,
        table_base_dir=table_base_dir,
        table_type=table_type,
        raw_bytes=raw_bytes,
        observed_positions=observed_positions,
        total_events=total_events,
        intended_index=intended_index,
        results_id=results_id,
        assay_type=assay_type,
        observed_source=observed_source,
        observed_inferred=True,
        extra_notes=notes,
    )


def _build_results_record_common(
    *,
    path: Path,
    table_base_dir: Path | None,
    table_type: str,
    raw_bytes: bytes,
    observed_positions: list[dict[str, Any]],
    total_events: int,
    intended_index: int | None,
    results_id: str | None,
    assay_type: str,
    observed_source: str | None,
    observed_inferred: bool,
    extra_notes: Sequence[str] | None,
) -> dict[str, Any]:
    observed_desired = None
    if intended_index is not None and observed_positions:
        for entry in observed_positions:
            if int(entry.get("pos")) == int(intended_index):
                observed_desired = float(entry.get("prob") or 0.0)
                break

    note_map = {
        "around": "CRISPResso2 substitution frequency table around sgRNA",
        "full": "CRISPResso2 substitution frequency table full amplicon",
        "nf_quant": "CRISPResso2 nucleotide frequency table (quantification window, inferred conversions)",
        "nf_full": "CRISPResso2 nucleotide frequency table (full amplicon, inferred conversions)",
    }
    notes = []
    base_note = note_map.get(table_type, "CRISPResso2 substitution frequency table")
    notes.append(base_note)
    if extra_notes:
        notes.extend(extra_notes)

    conditions = {
        "source": {
            "tableKind": table_type,
            "tablePath": _relative_table_path(path, table_base_dir),
            "tableHash": sha256(raw_bytes).hexdigest(),
        }
    }
    if observed_source:
        conditions["source"]["observedDerivedFrom"] = observed_source
    if observed_inferred:
        conditions["source"]["observedInferred"] = True

    record = {
        "schema": "helix_results_record_v1",
        "resultsId": sanitize_results_id(results_id or path.stem or "crispresso2_results"),
        "modality": "base",
        "conditions": conditions,
        "primaryTarget": {
            "observedPositionProbs": observed_positions,
            "observedDesiredFrequency": observed_desired,
            "observedTotalEvents": int(total_events),
        },
        "assayMetadata": {"assayType": assay_type},
        "notes": notes,
    }

    return results_record_from_dict(record)


_TABLE_ORDER = [
    ("around", "Substitution_frequency_table_around_sgRNA_*.txt"),
    ("full", "Substitution_frequency_table.txt"),
    ("nf_quant", "Quantification_window_nucleotide_frequency_table*.txt"),
    ("nf_full", "Nucleotide_frequency_table*.txt"),
]


def find_substitution_table_path(path: Path) -> tuple[Path, str]:
    if path.is_file():
        name = path.name
        if path.match("Substitution_frequency_table_around_sgRNA_*.txt"):
            return path, "around"
        if path.name == "Substitution_frequency_table.txt":
            return path, "full"
        if path.match("Quantification_window_nucleotide_frequency_table*.txt"):
            return path, "nf_quant"
        if path.match("Nucleotide_frequency_table*.txt"):
            return path, "nf_full"
        raise ValueError("Unsupported substitution frequency file")
    if not path.is_dir():
        raise ValueError("Path must be a file or directory")
    for tag, pattern in _TABLE_ORDER:
        candidates = fs.glob_sorted(path, "**/" + pattern)
        if candidates:
            return candidates[0], tag
    found = []
    for entry in fs.iterdir_sorted(path):
        if entry.is_file():
            found.append(entry.name)
    raise ValueError(
        f"Substitution frequency table not found. Supported patterns: "
        f"{', '.join(p for _, p in _TABLE_ORDER)}. Found: {found}"
    )


def import_crispresso2_substitution_table(path: Path | str, session: Any) -> tuple[dict[str, Any], str]:
    if session is None:
        raise ValueError("Session is required")
    path_obj = Path(path)
    table_path, table_type = find_substitution_table_path(path_obj)
    guide_seq = _infer_guide_sequence(session)
    if not guide_seq:
        raise ValueError("Guide sequence not found in session")
    editor_type = _infer_editor_type(session)
    intended_index = _infer_intended_index(session)
    if editor_type == "CBE":
        conversion_from, conversion_to = "C", "T"
    else:
        conversion_from, conversion_to = "A", "G"

    base_dir = path_obj if path_obj.is_dir() else path_obj.parent
    if table_type in {"around", "full"}:
        record = build_results_record_from_crispresso2_table(
            table_path,
            guide_sequence=guide_seq,
            conversion_from=conversion_from,
            conversion_to=conversion_to,
            intended_index=intended_index,
            results_id=table_path.stem,
            table_type=table_type,
            table_base_dir=base_dir,
            observed_source="crispresso2_substitution",
            observed_inferred=False,
        )
    else:
        nf_table = parse_nucleotide_frequency_table(table_path.read_text(encoding="utf-8"))
        record = build_results_record_from_nucleotide_table(
            table_path,
            table=nf_table,
            guide_sequence=guide_seq,
            conversion_from=conversion_from,
            conversion_to=conversion_to,
            intended_index=intended_index,
            results_id=table_path.stem,
            table_type=table_type,
            table_base_dir=base_dir,
            observed_source="crispresso2_nucleotide_frequency",
        )
    return record, table_type


__all__ = [
    "Crispresso2SubstitutionTable",
    "parse_substitution_frequency_table",
    "build_observed_position_probs",
    "build_results_record_from_crispresso2_table",
    "import_crispresso2_substitution_table",
]
