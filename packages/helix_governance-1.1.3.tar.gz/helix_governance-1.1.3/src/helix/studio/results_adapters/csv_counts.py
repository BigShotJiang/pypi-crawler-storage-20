from __future__ import annotations

import csv
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping

from helix.studio.results_io import results_record_from_dict, sanitize_results_id
from helix.studio.results_adapters.pileup import _normalize_path, _ppm_distribution
from helix.studio.results_adapters.crispresso2 import _infer_editor_type, _infer_guide_sequence, _infer_intended_index
from helix.studio.experiment_spec import experiment_spec_to_dict


CANON_COLS = {
    "relpos": "relPos",
    "rel_pos": "relPos",
    "offset": "relPos",
    "ref": "refBase",
    "refbase": "refBase",
    "ref_base": "refBase",
    "alt": "altBase",
    "altbase": "altBase",
    "alt_base": "altBase",
    "count": "count",
    "n": "count",
    "reads": "count",
    "events": "count",
}


def _canonicalize_header(name: str) -> str:
    return name.strip().lower().replace(" ", "").replace("\t", "").replace(",", "")


def _detect_delimiter(sample: str) -> str:
    return "\t" if "\t" in sample and sample.count("\t") >= sample.count(",") else ","


def _parse_csv_counts(path: Path) -> tuple[list[dict[str, Any]], str, list[str]]:
    raw = path.read_bytes()
    text = raw.decode("utf-8")
    lines = [line for line in text.splitlines() if line and not line.lstrip().startswith("#")]
    if not lines:
        raise ValueError("CSV counts file is empty")
    delimiter = _detect_delimiter(lines[0])
    reader = csv.reader(lines, delimiter=delimiter)
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("CSV counts missing header")
    canon_map: dict[str, str] = {}
    extras: list[str] = []
    for col in header:
        canon = CANON_COLS.get(_canonicalize_header(col))
        if canon:
            canon_map[canon] = col
        else:
            extras.append(col.strip())
    required = {"relPos", "refBase", "altBase", "count"}
    if not required.issubset(canon_map):
        missing = required - set(canon_map)
        raise ValueError(f"CSV counts missing required columns: {', '.join(sorted(missing))}")

    rows: list[dict[str, Any]] = []
    for rec in reader:
        if not rec:
            continue
        row = dict(zip(header, rec))
        rows.append(row)
    return rows, delimiter, extras


def _build_events(
    rows: list[dict[str, Any]],
    canon_map: dict[str, str],
    *,
    conversion_from: str,
    conversion_to: str,
    window_start: int | None,
    window_end: int | None,
) -> tuple[dict[int, int], dict[str, int], list[str]]:
    stats = {"total_rows": 0, "outside_window": 0, "base_mismatch": 0, "invalid": 0}
    notes: list[str] = []
    events: dict[int, int] = {}
    for row in rows:
        stats["total_rows"] += 1
        try:
            rel_pos = int(row[canon_map["relPos"]])
            ref_base = str(row[canon_map["refBase"]]).strip().upper()
            alt_base = str(row[canon_map["altBase"]]).strip().upper()
            count = int(row[canon_map["count"]])
        except Exception:
            stats["invalid"] += 1
            continue
        if window_start is not None and rel_pos < window_start:
            stats["outside_window"] += 1
            continue
        if window_end is not None and rel_pos > window_end:
            stats["outside_window"] += 1
            continue
        if ref_base != conversion_from or alt_base != conversion_to:
            stats["base_mismatch"] += 1
            continue
        if count < 0:
            stats["invalid"] += 1
            continue
        events[rel_pos] = events.get(rel_pos, 0) + count
    notes.append(
        f"Rows: {stats['total_rows']}; outside window: {stats['outside_window']}; "
        f"base mismatch: {stats['base_mismatch']}; invalid: {stats['invalid']}"
    )
    return events, stats, notes


def build_results_record_from_csv_counts(
    path: Path,
    *,
    conversion_from: str,
    conversion_to: str,
    window_start: int | None,
    window_end: int | None,
    intended_index: int | None = None,
    results_id: str | None = None,
    base_dir: Path | None = None,
) -> dict[str, Any]:
    raw_bytes = Path(path).read_bytes()
    rows, delimiter, extras = _parse_csv_counts(path)
    canon_map = {}
    header = rows[0].keys() if rows else []
    for col in header:
        canon = CANON_COLS.get(_canonicalize_header(col))
        if canon:
            canon_map[canon] = col

    events, stats, notes = _build_events(
        rows,
        canon_map,
        conversion_from=conversion_from,
        conversion_to=conversion_to,
        window_start=window_start,
        window_end=window_end,
    )

    total_events = sum(events.values())
    observed = []
    if total_events > 0:
        ppm = _ppm_distribution([events[k] for k in sorted(events)])
        probs = [val / 1_000_000.0 for val in ppm]
        for rel_pos, prob in zip(sorted(events), probs):
            observed.append({"pos": int(rel_pos), "prob": round(prob, 6)})
    else:
        notes.append("No conversion events in CSV window")

    observed_desired = None
    if intended_index is not None and observed:
        for entry in observed:
            if int(entry.get("pos")) == int(intended_index):
                observed_desired = float(entry.get("prob") or 0.0)
                break

    if extras:
        notes.append(f"Ignored extra columns: {', '.join(sorted(extras))}")

    record = {
        "schema": "helix_results_record_v1",
        "resultsId": sanitize_results_id(results_id or path.stem or "csv_counts"),
        "modality": "base",
        "conditions": {
            "source": {
                "observedDerivedFrom": "csv_counts_v1",
                "observedInferred": True,
                "tableHash": sha256(raw_bytes).hexdigest(),
                "tableKind": "csv_counts_v1",
                "tablePath": _normalize_path(path, base_dir),
                "csvDelimiter": "tab" if delimiter == "\t" else "comma",
                "csvColumnsNormalized": sorted(set(canon_map.values())),
                "filteredToEditorWindow": True,
                "windowStart": window_start,
                "windowEnd": window_end,
            }
        },
        "primaryTarget": {
            "observedPositionProbs": observed,
            "observedDesiredFrequency": observed_desired,
            "observedTotalEvents": int(total_events),
        },
        "assayMetadata": {"assayType": "AmpliconSeq"},
        "notes": ["CSV counts ingest (observed inferred)", *notes],
    }

    return results_record_from_dict(record)


def import_csv_counts(path: Path | str, session: Any) -> dict[str, Any]:
    if session is None:
        raise ValueError("Session is required")
    guide_seq = _infer_guide_sequence(session)
    if not guide_seq:
        raise ValueError("Guide sequence not found in session")
    editor_type = _infer_editor_type(session)
    intended_index = _infer_intended_index(session)

    window_start = None
    window_end = None
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
        assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
        base_edit = assumptions.get("baseEdit") if isinstance(assumptions.get("baseEdit"), Mapping) else {}
        if "windowStart" in base_edit and "windowEnd" in base_edit:
            window_start = int(base_edit.get("windowStart"))
            window_end = int(base_edit.get("windowEnd"))
    except Exception:
        pass

    if editor_type == "CBE":
        conv_from, conv_to = "C", "T"
    else:
        conv_from, conv_to = "A", "G"

    path_obj = Path(path)
    return build_results_record_from_csv_counts(
        path_obj,
        conversion_from=conv_from,
        conversion_to=conv_to,
        window_start=window_start,
        window_end=window_end,
        intended_index=intended_index,
        results_id=path_obj.stem,
        base_dir=path_obj.parent,
    )


__all__ = ["build_results_record_from_csv_counts", "import_csv_counts"]
