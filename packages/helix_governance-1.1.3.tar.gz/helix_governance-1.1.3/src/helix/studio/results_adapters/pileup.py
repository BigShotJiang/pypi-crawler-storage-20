from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.results_io import results_record_from_dict, sanitize_results_id

DNA_BASES = {"A", "C", "G", "T", "N"}


def _reverse_complement(seq: str) -> str:
    comp = {"A": "T", "C": "G", "G": "C", "T": "A", "N": "N"}
    return "".join(comp.get(ch, "N") for ch in reversed(seq.upper()))


def _normalize_path(path: Path, base_dir: Path | None) -> str:
    if base_dir is not None:
        try:
            rel = path.relative_to(base_dir)
        except Exception:
            rel = path
    else:
        rel = path.name
    norm = Path(rel).as_posix()
    while norm.startswith("./"):
        norm = norm[2:]
    return norm


def _decode_qual(ch: str) -> int:
    return max(0, ord(ch) - 33)


def _ppm_distribution(counts: list[int]) -> list[int]:
    total = sum(counts)
    if total <= 0:
        return [0 for _ in counts]
    raw = [c * 1_000_000 / total for c in counts]
    floors = [int(val) for val in raw]
    remainder = 1_000_000 - sum(floors)
    fracs = [(raw[i] - floors[i], i) for i in range(len(raw))]
    fracs.sort(key=lambda item: (-item[0], item[1]))
    for _, idx in fracs[: max(0, remainder)]:
        floors[idx] += 1
    return floors


@dataclass(frozen=True)
class PileupLine:
    contig: str
    pos: int  # 1-based
    ref: str
    bases: str
    quals: str
    mapqs: str | None = None


def _parse_pileup_line(line: str) -> PileupLine:
    parts = line.strip().split()
    if len(parts) < 6:
        raise ValueError("Pileup line must have at least 6 columns")
    contig = parts[0]
    pos = int(parts[1])
    ref = parts[2].upper()
    bases = parts[4]
    quals = parts[5]
    mapqs = parts[6] if len(parts) > 6 else None
    return PileupLine(contig=contig, pos=pos, ref=ref, bases=bases, quals=quals, mapqs=mapqs)


def _match_guide(reference_seq: str, guide_seq: str) -> tuple[int, str] | None:
    ref = reference_seq.upper()
    guide = guide_seq.upper()
    idx = ref.find(guide)
    if idx >= 0:
        return idx, "+"
    rc = _reverse_complement(guide)
    idx = ref.find(rc)
    if idx >= 0:
        return idx, "-"
    return None


def _collect_reference(lines: list[PileupLine]) -> tuple[str, int]:
    if not lines:
        return "", 0
    lines_sorted = sorted(lines, key=lambda ln: ln.pos)
    start = lines_sorted[0].pos
    seq_chars: list[str] = []
    for ln in lines_sorted:
        if ln.ref.upper() not in DNA_BASES or ln.ref.upper() == "N":
            raise ValueError("Pileup missing reference base (supply pileup with reference)")
        seq_chars.append(ln.ref.upper())
    return "".join(seq_chars), start


def _token_stream(bases_field: str) -> Iterable[str]:
    i = 0
    n = len(bases_field)
    while i < n:
        ch = bases_field[i]
        if ch == "^":
            i += 2  # skip mapping qual char
            continue
        if ch == "$":
            i += 1
            continue
        if ch in "+-":
            i += 1
            num_start = i
            while i < n and bases_field[i].isdigit():
                i += 1
            if num_start == i:
                continue
            length = int(bases_field[num_start:i]) if i > num_start else 0
            i += length
            continue
        if ch in "><":
            i += 1
            continue
        # base or placeholder consumes one quality
        yield ch
        i += 1


def _count_conversions_for_line(
    ln: PileupLine,
    guide_start_idx: int,
    guide_len: int,
    strand: str,
    min_base_q: int,
    min_map_q: int,
    include_indels: bool,
) -> tuple[int, int | None]:
    bases = ln.bases
    quals = ln.quals
    mapqs = ln.mapqs
    qual_idx = 0
    conversions = 0
    depth_pass = 0
    for token in _token_stream(bases):
        if token in "+-><^$":
            continue
        if token == "*":
            # deletion placeholder; counts toward depth if include_indels
            if qual_idx < len(quals):
                bq = _decode_qual(quals[qual_idx])
            else:
                bq = 0
            mq = _decode_qual(mapqs[qual_idx]) if mapqs and qual_idx < len(mapqs) else 0
            qual_idx += 1
            if not include_indels:
                continue
            if bq < min_base_q or mq < min_map_q:
                continue
            depth_pass += 1
            continue

        # real base token
        base_call = token
        if qual_idx >= len(quals):
            break
        bq = _decode_qual(quals[qual_idx])
        mq = _decode_qual(mapqs[qual_idx]) if mapqs and qual_idx < len(mapqs) else 0
        qual_idx += 1
        if bq < min_base_q or mq < min_map_q:
            continue
        depth_pass += 1

        if base_call in {".", ","}:
            continue
        base_upper = base_call.upper()
        if base_upper not in DNA_BASES:
            continue
        # we count conversions later at caller; here just pass base if needed
    return depth_pass, None  # conversions counted at caller


def build_results_record_from_pileup(
    path: Path,
    *,
    guide_sequence: str,
    conversion_from: str,
    conversion_to: str,
    intended_index: int | None,
    assay_type: str = "AmpliconSeq",
    min_base_q: int = 20,
    min_map_q: int = 20,
    min_depth: int = 10,
    include_indels: bool = False,
    results_id: str | None = None,
    base_dir: Path | None = None,
) -> dict[str, Any]:
    raw_bytes = Path(path).read_bytes()
    lines: list[PileupLine] = []
    for line in raw_bytes.decode("utf-8").splitlines():
        if not line.strip():
            continue
        lines.append(_parse_pileup_line(line))
    if not lines:
        raise ValueError("Empty pileup file")

    by_contig: dict[str, list[PileupLine]] = {}
    for ln in lines:
        by_contig.setdefault(ln.contig, []).append(ln)

    guide_match: tuple[str, int, str, str, int] | None = None  # contig, start_pos, strand, seq, guide_start_idx
    for contig, contig_lines in by_contig.items():
        ref_seq, start_pos = _collect_reference(contig_lines)
        m = _match_guide(ref_seq, guide_sequence)
        if m:
            guide_start_idx, strand = m
            guide_match = (contig, start_pos, strand, ref_seq, guide_start_idx)
            break
    if guide_match is None:
        raise ValueError("Guide sequence not found in pileup reference")

    contig, start_pos, strand, ref_seq, guide_start_idx = guide_match
    guide_len = len(guide_sequence)
    guide_start_refpos = start_pos + guide_start_idx  # 1-based

    conversion_from = conversion_from.upper()
    conversion_to = conversion_to.upper()

    positions: list[int] = []
    conv_counts: list[int] = []
    notes: list[str] = []

    if all(ln.mapqs is None for ln in lines):
        notes.append("Mapping qualities column absent; minMapQ treated as 0")
        min_map_q_effective = 0
    else:
        min_map_q_effective = min_map_q

    for ln in by_contig[contig]:
        if ln.ref.upper() != conversion_from:
            continue
        depth_pass = 0
        conversions_here = 0

        bases = ln.bases
        quals = ln.quals
        mapqs = ln.mapqs
        qual_idx = 0
        n = len(bases)
        i = 0
        while i < n:
            ch = bases[i]
            if ch == "^":
                i += 2
                continue
            if ch == "$":
                i += 1
                continue
            if ch in "+-":
                i += 1
                num_start = i
                while i < n and bases[i].isdigit():
                    i += 1
                if num_start == i:
                    continue
                length = int(bases[num_start:i]) if i > num_start else 0
                i += length
                continue
            if ch in "><":
                i += 1
                continue

            # consume quality / mapQ if available
            if qual_idx >= len(quals):
                break
            bq = _decode_qual(quals[qual_idx])
            mq = _decode_qual(mapqs[qual_idx]) if mapqs and qual_idx < len(mapqs) else 0
            qual_idx += 1
            i += 1

            if ch == "*":
                if not include_indels:
                    continue
                if bq < min_base_q or mq < min_map_q_effective:
                    continue
                depth_pass += 1
                continue

            if bq < min_base_q or mq < min_map_q_effective:
                continue
            depth_pass += 1

            if ch in {".", ","}:
                continue
            base_call = ch.upper()
            if base_call == conversion_to:
                conversions_here += 1

        if depth_pass < min_depth:
            continue

        # compute relPos
        pos_idx_zero = ln.pos - guide_start_refpos
        guide_idx = pos_idx_zero
        if strand == "-":
            guide_idx = (guide_len - 1) - guide_idx
        rel_pos = guide_idx - (guide_len - 1)
        positions.append(rel_pos)
        conv_counts.append(conversions_here)

    total_events = sum(conv_counts)
    observed = []
    if total_events > 0:
        ppm = _ppm_distribution(conv_counts)
        probs = [val / 1_000_000.0 for val in ppm]
        for pos, prob in sorted(zip(positions, probs), key=lambda item: item[0]):
            observed.append({"pos": int(pos), "prob": round(prob, 6)})
    else:
        notes.append("No conversion events in guide window")

    base_note = "Pileup-derived observedPositionProbs (mpileup)"
    notes.append("ObservedPositionProbs inferred from pileup; may include sequencing noise")

    observed_desired = None
    if intended_index is not None and observed:
        for entry in observed:
            if int(entry.get("pos")) == int(intended_index):
                observed_desired = float(entry.get("prob") or 0.0)
                break

    record = {
        "schema": "helix_results_record_v1",
        "resultsId": sanitize_results_id(results_id or path.stem or "pileup_results"),
        "modality": "base",
        "conditions": {
            "source": {
                "observedDerivedFrom": "pileup_mpileup",
                "observedInferred": True,
                "tableHash": sha256(raw_bytes).hexdigest(),
                "tableKind": "pileup",
                "tablePath": _normalize_path(path, base_dir),
                "pileupColumns": 6 if all(ln.mapqs is None for ln in lines) else 7,
                "minBaseQ": int(min_base_q),
                "minMapQ": int(min_map_q_effective),
                "minDepth": int(min_depth),
                "includeIndels": bool(include_indels),
            }
        },
        "primaryTarget": {
            "observedPositionProbs": observed,
            "observedDesiredFrequency": observed_desired,
            "observedTotalEvents": int(total_events),
        },
        "assayMetadata": {"assayType": assay_type},
        "notes": [base_note, *notes],
    }

    return results_record_from_dict(record)


def import_pileup_results(path: Path | str, session: Any) -> dict[str, Any]:
    if session is None:
        raise ValueError("Session is required")
    guide_seq = _infer_guide_sequence(session)
    if not guide_seq:
        raise ValueError("Guide sequence not found in session")
    editor_type = _infer_editor_type(session)
    intended_index = _infer_intended_index(session)
    if editor_type == "CBE":
        conv_from, conv_to = "C", "T"
    else:
        conv_from, conv_to = "A", "G"
    path_obj = Path(path)
    return build_results_record_from_pileup(
        path_obj,
        guide_sequence=guide_seq,
        conversion_from=conv_from,
        conversion_to=conv_to,
        intended_index=intended_index,
        base_dir=path_obj.parent,
    )


def _infer_editor_type(session: Any) -> str:
    editor_type = ""
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
    except Exception:
        spec = {}
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
    base_edit = assumptions.get("baseEdit") if isinstance(assumptions.get("baseEdit"), Mapping) else {}
    editor_type = str(base_edit.get("editorType") or "").strip().upper()
    if editor_type not in {"ABE", "CBE"}:
        editor_type = "ABE"
    return editor_type


def _infer_intended_index(session: Any) -> int | None:
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
    except Exception:
        return None
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
    base_edit = assumptions.get("baseEdit") if isinstance(assumptions.get("baseEdit"), Mapping) else {}
    value = base_edit.get("intendedIndex") if isinstance(base_edit, Mapping) else None
    if value is None:
        return None
    try:
        return int(value)
    except Exception:
        return None


def _infer_guide_sequence(session: Any) -> str | None:
    try:
        plan = session.state.edit_plan
    except Exception:
        plan = None
    if isinstance(plan, Mapping):
        targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
        for target in targets:
            if not isinstance(target, Mapping):
                continue
            g = target.get("gRNA") if isinstance(target.get("gRNA"), Mapping) else {}
            seq = g.get("sequence") if isinstance(g, Mapping) else None
            if seq:
                return str(seq).strip().upper()
    try:
        cfg = session.state.config
    except Exception:
        cfg = {}
    guide = cfg.get("guide") if isinstance(cfg, Mapping) else {}
    seq = guide.get("sequence") if isinstance(guide, Mapping) else None
    if seq:
        return str(seq).strip().upper()
    return None


__all__ = [
    "build_results_record_from_pileup",
    "import_pileup_results",
]
