from __future__ import annotations

import json
import re
import zipfile
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable, List, Mapping

from helix import fs
from helix.studio.results_adapters.crispresso2 import import_crispresso2_substitution_table
from helix.studio.results_adapters.pileup import import_pileup_results
from helix.studio.results_adapters.csv_counts import import_csv_counts
from helix.studio.results_io import results_record_json_bytes


_CRISPRESSO_PATTERNS = [
    "Substitution_frequency_table_around_sgRNA_*.txt",
    "Substitution_frequency_table.txt",
    "Quantification_window_nucleotide_frequency_table*.txt",
    "Nucleotide_frequency_table*.txt",
]


@dataclass(frozen=True)
class BatchItem:
    status: str
    kind: str
    relPath: str
    sourceHash: str
    tableKind: str | None
    totalEvents: int | None
    lowEvidence: bool
    notes: list[str] = field(default_factory=list)
    id: str | None = None
    errorCode: str | None = None
    errorMessage: str | None = None
    record: dict[str, Any] | None = None


@dataclass
class BatchIngestResult:
    items: list[BatchItem]

    @property
    def counts(self) -> dict[str, int]:
        total = len(self.items)
        ok = sum(1 for i in self.items if i.status == "ok")
        error = total - ok
        low = sum(1 for i in self.items if i.lowEvidence)
        return {"total": total, "ok": ok, "error": error, "lowEvidence": low}


def _normalize_rel_path(path: Path, root: Path) -> str:
    rel = path.relative_to(root)
    norm = rel.as_posix()
    while norm.startswith("./"):
        norm = norm[2:]
    return norm


def _sha_bytes(data: bytes) -> str:
    return sha256(data).hexdigest()


def _candidate_id(kind: str, rel_path: str, source_hash: str) -> str:
    payload = f"{kind}\n{rel_path}\n{source_hash}".encode()
    return sha256(payload).hexdigest()


def _iter_candidates(folder: Path) -> Iterable[tuple[str, Path]]:
    # crispresso2 run directories first: identify by contained patterns
    seen_dirs: set[Path] = set()
    for pattern in _CRISPRESSO_PATTERNS:
        for f in fs.rglob_sorted(folder, pattern):
            run_dir = f.parent
            if run_dir in seen_dirs:
                continue
            seen_dirs.add(run_dir)
            yield "crispresso2", run_dir
    # pileup files
    for ext in (".pileup", ".mpileup"):
        for f in fs.rglob_sorted(folder, f"*{ext}"):
            yield "pileup", f
    # csv / tsv
    for ext in (".csv", ".tsv"):
        for f in fs.rglob_sorted(folder, f"*{ext}"):
            yield "csv_counts_v1", f


def _ingest_candidate(kind: str, path: Path, session: Any, root: Path) -> BatchItem:
    rel_path = _normalize_rel_path(path, root)
    raw_bytes = (
        path.read_bytes()
        if path.is_file()
        else b"".join(sorted(p.read_bytes() for p in fs.glob_sorted(path, "**/*") if p.is_file()))
    )
    source_hash = _sha_bytes(raw_bytes) if raw_bytes else ""
    table_kind = None
    try:
        if kind == "crispresso2":
            record, table_kind = import_crispresso2_substitution_table(path, session)
        elif kind == "pileup":
            record = import_pileup_results(path, session)
        elif kind == "csv_counts_v1":
            record = import_csv_counts(path, session)
        else:
            raise ValueError(f"Unsupported kind {kind}")
        src = record.get("conditions", {}).get("source", {}) if isinstance(record, Mapping) else {}
        total_events = record.get("primaryTarget", {}).get("observedTotalEvents") if isinstance(record, Mapping) else None
        low = False
        notes = record.get("notes", []) if isinstance(record, Mapping) else []
        if any("No conversion events" in str(n) for n in notes):
            low = True
        item_id = _candidate_id(kind, rel_path, source_hash)
        return BatchItem(
            status="ok",
            kind=kind,
            relPath=rel_path,
            sourceHash=source_hash,
            tableKind=table_kind or src.get("tableKind"),
            totalEvents=int(total_events) if total_events is not None else None,
            lowEvidence=low,
            notes=list(notes) if notes else [],
            id=item_id,
            record=record,
        )
    except Exception as exc:  # pragma: no cover - exercised in tests via error branch
        item_id = _candidate_id(kind, rel_path, source_hash)
        return BatchItem(
            status="error",
            kind=kind,
            relPath=rel_path,
            sourceHash=source_hash,
            tableKind=table_kind,
            totalEvents=None,
            lowEvidence=False,
            notes=[],
            id=item_id,
            errorCode="ingest_error",
            errorMessage=str(exc),
        )


def batch_ingest_folder(folder: Path | str, session: Any) -> BatchIngestResult:
    root = Path(folder).resolve()
    if not root.is_dir():
        raise ValueError("Folder path must be a directory")
    items: list[BatchItem] = []
    for kind, path in _iter_candidates(root):
        items.append(_ingest_candidate(kind, path, session, root))
    items.sort(key=lambda it: it.relPath)
    return BatchIngestResult(items=items)


def batch_summary_json(result: BatchIngestResult, folder_root: Path | None = None) -> bytes:
    folder_root_value: str | None
    if folder_root is None:
        folder_root_value = None
    else:
        try:
            p = Path(folder_root)
        except Exception:
            p = None
        if p is None:
            folder_root_value = str(folder_root)
        elif not p.is_absolute():
            folder_root_value = p.as_posix()
        else:
            # Prefer a repo-relative POSIX path for deterministic, portable bundles.
            try:
                repo_root = Path(__file__).resolve().parents[4]
                folder_root_value = p.resolve().relative_to(repo_root).as_posix()
            except Exception:
                folder_root_value = p.as_posix()

    payload = {
        "schema": "helix_results_batch_summary_v1",
        "summaryVersion": 1,
        "folderRoot": folder_root_value,
        "counts": result.counts,
        "items": [
            {
                "id": it.id,
                "status": it.status,
                "kind": it.kind,
                "relPath": it.relPath,
                "sourceHash": it.sourceHash,
                "tableKind": it.tableKind,
                "totalEvents": it.totalEvents,
                "lowEvidence": it.lowEvidence,
                "notes": it.notes,
                "errorCode": it.errorCode,
                "errorMessage": it.errorMessage,
            }
            for it in result.items
        ],
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def write_batch_bundle(
    result: BatchIngestResult,
    *,
    bundle_path: Path,
    folder_root: Path | None = None,
    extra_files: Mapping[str, bytes] | None = None,
) -> None:
    manifest: dict[str, Any] = {
        "schema": "helix_results_batch_bundle_v1",
        "counts": result.counts,
        "items": [
            {"id": it.id, "relPath": it.relPath, "kind": it.kind, "status": it.status}
            for it in result.items
        ],
    }
    records = {it.id: results_record_json_bytes(it.record) for it in result.items if it.status == "ok" and it.record}
    summary_bytes = batch_summary_json(result, folder_root)

    prime_cal_hash = None
    if extra_files and "calibration/prime_multiplex_profile.json" in extra_files:
        try:
            import hashlib

            prime_bytes = extra_files["calibration/prime_multiplex_profile.json"]
            prime_cal_hash = hashlib.sha256(prime_bytes).hexdigest()
            manifest["primeMultiplexCalibrationProfileHash"] = prime_cal_hash
        except Exception:
            prime_cal_hash = None

    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_STORED) as zf:
        def _writestr(name: str, data: bytes) -> None:
            info = zipfile.ZipInfo(filename=name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.external_attr = 0o644 << 16
            zf.writestr(info, data)

        _writestr("manifest.json", json.dumps(manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode())
        _writestr("batch_summary.json", summary_bytes)
        for rec_id in sorted(records):
            _writestr(f"records/{rec_id}.json", records[rec_id])
        if extra_files:
            for name in sorted(extra_files):
                _writestr(name, extra_files[name])


__all__ = [
    "BatchItem",
    "BatchIngestResult",
    "batch_ingest_folder",
    "batch_summary_json",
    "write_batch_bundle",
]
