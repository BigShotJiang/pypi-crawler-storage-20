from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from typing import Mapping

LAYOUT_STATE_VERSION = 2


def _encode_bytes(data: bytes | bytearray | None) -> str | None:
    """Return a base64 string for bytes; None when payload is missing or invalid."""
    if data is None:
        return None
    try:
        return base64.b64encode(bytes(data)).decode("ascii")
    except Exception:
        return None


def _decode_bytes(value: object) -> bytes | None:
    """Inverse of _encode_bytes; tolerant of None and malformed data."""
    if value is None:
        return None
    if isinstance(value, (bytes, bytearray)):
        candidate = bytes(value)
    elif isinstance(value, str):
        if not value:
            return None
        candidate = value.encode("ascii", errors="ignore")
    else:
        return None
    try:
        return base64.b64decode(candidate, validate=True)
    except Exception:
        return None


def _coerce_version(value: object) -> int | None:
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        text = value.strip()
        if text.isdigit():
            try:
                return int(text)
            except Exception:
                return None
    return None


def _coerce_dict(raw: object) -> dict[str, object] | None:
    if raw is None:
        return None
    if isinstance(raw, Mapping):
        return dict(raw)
    if isinstance(raw, (bytes, bytearray)):
        try:
            raw = raw.decode("utf-8")
        except Exception:
            return None
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
        except Exception:
            return None
        return dict(parsed) if isinstance(parsed, Mapping) else None
    return None


def _coerce_bool(value: object) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        if value in (0, 1):
            return bool(value)
    if isinstance(value, str):
        text = value.strip().lower()
        if text in {"1", "true", "yes", "y", "on"}:
            return True
        if text in {"0", "false", "no", "n", "off"}:
            return False
    return None


def _coerce_int_list(value: object) -> list[int] | None:
    if value is None:
        return None
    if not isinstance(value, (list, tuple)):
        return None
    result: list[int] = []
    for item in value:
        if isinstance(item, bool):
            return None
        if isinstance(item, int):
            v = item
        elif isinstance(item, float):
            v = int(item)
        elif isinstance(item, str):
            text = item.strip()
            if not text:
                return None
            try:
                v = int(float(text))
            except Exception:
                return None
        else:
            return None
        if v < 0:
            v = 0
        result.append(v)
    return result


@dataclass
class CenterTabLayout:
    """Visible/ordering state for the center tab strip."""

    order: list[str] = field(default_factory=list)
    hidden: set[str] = field(default_factory=set)
    active: str | None = None


@dataclass
class LayoutState:
    """JSON-serializable layout snapshot persisted in QSettings."""

    geometry: bytes | None = None
    qt_state: bytes | None = None
    center_tabs: CenterTabLayout = field(default_factory=CenterTabLayout)
    splitter_wide: list[int] = field(default_factory=list)
    splitter_overlay: list[int] = field(default_factory=list)
    left_hidden: bool | None = None
    right_hidden: bool | None = None
    right_overlay_pinned_open: bool | None = None
    sidebar_last_size: int | None = None
    left_last_size: int | None = None
    right_last_size: int | None = None
    view_states: dict[str, str] = field(default_factory=dict)

    def to_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {"v": LAYOUT_STATE_VERSION, "layout_version": LAYOUT_STATE_VERSION}
        geom_b64 = _encode_bytes(self.geometry)
        state_b64 = _encode_bytes(self.qt_state)
        if geom_b64 is not None:
            payload["geometry"] = geom_b64
        if state_b64 is not None:
            payload["qt_state"] = state_b64

        tabs = self.center_tabs
        tabs_payload: dict[str, object] = {
            "order": [key for key in tabs.order if isinstance(key, str) and key],
            "hidden": sorted({key for key in tabs.hidden if isinstance(key, str) and key}),
        }
        if isinstance(tabs.active, str) and tabs.active:
            tabs_payload["active"] = tabs.active
        payload["center_tabs"] = tabs_payload

        splitter: dict[str, object] = {}
        if self.splitter_wide:
            splitter["wide"] = [int(v) for v in self.splitter_wide if isinstance(v, int)]
        if self.splitter_overlay:
            splitter["overlay"] = [int(v) for v in self.splitter_overlay if isinstance(v, int)]
        if isinstance(self.left_hidden, bool):
            splitter["left_hidden"] = self.left_hidden
        if isinstance(self.right_hidden, bool):
            splitter["right_hidden"] = self.right_hidden
        if isinstance(self.right_overlay_pinned_open, bool):
            splitter["right_overlay_pinned_open"] = self.right_overlay_pinned_open
        if isinstance(self.sidebar_last_size, int):
            splitter["sidebar_last_size"] = max(0, int(self.sidebar_last_size))
        if isinstance(self.left_last_size, int):
            splitter["left_last_size"] = max(0, int(self.left_last_size))
        if isinstance(self.right_last_size, int):
            splitter["right_last_size"] = max(0, int(self.right_last_size))
        if splitter:
            payload["splitter"] = splitter

        views = {
            str(key): str(value)
            for key, value in (self.view_states or {}).items()
            if isinstance(key, str) and key and isinstance(value, str) and value
        }
        if views:
            payload["views"] = dict(sorted(views.items()))
        return payload

    def to_json(self) -> str:
        return json.dumps(self.to_payload())

    @classmethod
    def from_raw(cls, raw: object) -> LayoutState | None:
        data = _coerce_dict(raw)
        if data is None:
            return None

        version = _coerce_version(data.get("v") or data.get("layout_version") or data.get("version"))
        if version is not None and version > LAYOUT_STATE_VERSION:
            # Future schema; ignore to avoid misapplying layout.
            return None

        geometry = _decode_bytes(data.get("geometry"))
        qt_state = _decode_bytes(data.get("qt_state") or data.get("state"))

        tabs_raw = data.get("center_tabs", {})
        if not isinstance(tabs_raw, Mapping):
            tabs_raw = {}
        order = [
            str(key)
            for key in tabs_raw.get("order", [])
            if isinstance(key, str) and key
        ]
        hidden = {
            str(key)
            for key in tabs_raw.get("hidden", [])
            if isinstance(key, str) and key
        }
        active = tabs_raw.get("active")
        if not isinstance(active, str) or not active:
            active = None

        splitter_wide: list[int] = []
        splitter_overlay: list[int] = []
        left_hidden: bool | None = None
        right_hidden: bool | None = None
        right_overlay_pinned_open: bool | None = None
        sidebar_last_size: int | None = None
        left_last_size: int | None = None
        right_last_size: int | None = None
        splitter_raw = data.get("splitter", {})
        if isinstance(splitter_raw, Mapping):
            wide = _coerce_int_list(splitter_raw.get("wide"))
            overlay = _coerce_int_list(splitter_raw.get("overlay"))
            if wide:
                splitter_wide = wide
            if overlay:
                splitter_overlay = overlay
            left_hidden = _coerce_bool(splitter_raw.get("left_hidden"))
            right_hidden = _coerce_bool(splitter_raw.get("right_hidden"))
            right_overlay_pinned_open = _coerce_bool(splitter_raw.get("right_overlay_pinned_open"))
            for raw_key, target in (
                ("sidebar_last_size", "sidebar_last_size"),
                ("left_last_size", "left_last_size"),
                ("right_last_size", "right_last_size"),
            ):
                value = splitter_raw.get(raw_key)
                if isinstance(value, bool):
                    continue
                if isinstance(value, int):
                    v = value
                elif isinstance(value, float):
                    v = int(value)
                elif isinstance(value, str) and value.strip().lstrip("-").isdigit():
                    try:
                        v = int(value.strip())
                    except Exception:
                        continue
                else:
                    continue
                v = max(0, int(v))
                if target == "sidebar_last_size":
                    sidebar_last_size = v
                elif target == "left_last_size":
                    left_last_size = v
                else:
                    right_last_size = v

        view_states: dict[str, str] = {}
        views_raw = data.get("views", {})
        if isinstance(views_raw, Mapping):
            for key, value in views_raw.items():
                if not isinstance(key, str) or not key:
                    continue
                if isinstance(value, str) and value:
                    view_states[key] = value

        return cls(
            geometry=geometry,
            qt_state=qt_state,
            center_tabs=CenterTabLayout(order=order, hidden=hidden, active=active),
            splitter_wide=splitter_wide,
            splitter_overlay=splitter_overlay,
            left_hidden=left_hidden,
            right_hidden=right_hidden,
            right_overlay_pinned_open=right_overlay_pinned_open,
            sidebar_last_size=sidebar_last_size,
            left_last_size=left_last_size,
            right_last_size=right_last_size,
            view_states=view_states,
        )
