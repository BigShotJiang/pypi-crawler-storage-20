from __future__ import annotations

import logging
import traceback
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Callable, Iterable

from helix import clock
from PySide6.QtCore import QObject, Signal


LOGGER = logging.getLogger("helix.studio.perf")

_sections: "deque[tuple[str, float]]" = deque(maxlen=256)


class PerfBus(QObject):
    updated = Signal()


perf_bus = PerfBus()


@dataclass
class PerfRecord:
    name: str
    ms: float


def _record(name: str, elapsed_ms: float) -> None:
    _sections.append((name, elapsed_ms))
    perf_bus.updated.emit()
    LOGGER.debug("perf %s %.2f ms", name, elapsed_ms)


@contextmanager
def perf_section(name: str, warn_ms: float = 16.0, error_ms: float = 50.0) -> Iterable[None]:
    start = clock.perf_counter()
    try:
        yield
    finally:
        elapsed_ms = (clock.perf_counter() - start) * 1000.0
        _record(name, elapsed_ms)
        if elapsed_ms >= error_ms:
            LOGGER.error("perf %s %.2f ms", name, elapsed_ms)
        elif elapsed_ms >= warn_ms:
            LOGGER.warning("perf %s %.2f ms", name, elapsed_ms)


def timed_slot(name: str, warn_ms: float = 16.0, error_ms: float = 100.0) -> Callable:
    def decorator(fn: Callable) -> Callable:
        def wrapper(*args, **kwargs):  # type: ignore[override]
            with perf_section(name, warn_ms, error_ms):
                return fn(*args, **kwargs)

        return wrapper

    return decorator


class PerfOverlay(QObject):
    """Simple data provider for an optional on-screen overlay."""

    updated = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        perf_bus.updated.connect(self._emit_text)

    def _emit_text(self) -> None:
        parts = [self._format_entry(name, ms) for name, ms in list(_sections)[-10:]]
        self.updated.emit("\n".join(parts))

    def text(self) -> str:
        parts = [self._format_entry(name, ms) for name, ms in list(_sections)[-10:]]
        return "\n".join(parts)

    @staticmethod
    def _format_entry(name: str, ms: float) -> str:
        badge = ""
        if ms >= 50.0:
            badge = " !!"
        elif ms >= 16.0:
            badge = " !"
        return f"{name}: {ms:.1f}ms{badge}"


def recent_sections(limit: int = 256) -> list[PerfRecord]:
    return [PerfRecord(name, ms) for name, ms in list(_sections)[-limit:]]


def install_exception_shield() -> None:
    import sys
    import threading

    try:
        from helix.support.crash import write_crash_record
    except Exception:  # pragma: no cover - support module missing or import issues
        write_crash_record = None  # type: ignore[assignment]

    def _excepthook(exc_type, exc_value, exc_tb):
        tb = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        if write_crash_record is not None:
            try:
                write_crash_record(exc_type, exc_value, exc_tb, context={"source": "sys.excepthook"})
            except Exception:
                pass
        LOGGER.error("Uncaught exception:\n%s", tb)
        sys.stderr.write(tb)

    sys.excepthook = _excepthook

    try:
        def _thread_hook(args: threading.ExceptHookArgs) -> None:  # pragma: no cover - smoke-tested indirectly
            _excepthook(args.exc_type, args.exc_value, args.exc_traceback)

        threading.excepthook = _thread_hook
    except Exception:
        pass
