from __future__ import annotations

from datetime import date, datetime
import json
import os
import sys
from pathlib import Path
from typing import Any, Callable, Mapping

from PySide6.QtCore import Qt, QEvent, QSettings, QUrl, Signal
from PySide6.QtGui import QCursor, QDesktopServices, QKeySequence, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QBoxLayout,
    QCheckBox,
    QDialog,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSizePolicy,
    QStyle,
    QToolButton,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from helix import __version__
from helix.gui.qt_geometry import qt_move
from helix.studio.ui.window_positioning import center_on_focused_window
from helix.studio.ui_tokens import (
    HX_FONT_MD,
    HX_FONT_SM,
    HX_FONT_XL,
    monospace_font,
)


class QuickActionsPanel(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("QuickActionsPanel")
        self.setProperty("role", "card")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setAutoFillBackground(True)
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)


class RecentSessionCard(QFrame):
    activated = Signal()
    move_focus_requested = Signal(int)
    actions_requested = Signal(object)

    def __init__(
        self,
        title: str,
        subtitle: str,
        detail: str,
        *,
        variant: str,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("RecentSessionCard")
        self.setProperty("variant", variant)
        self.setProperty("role", "card")
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self.setAttribute(Qt.WA_Hover, True)
        self.setAttribute(Qt.WA_StyledBackground, True)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(10)

        text_container = QWidget(self)
        text_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        text_layout = QVBoxLayout(text_container)
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(1)

        title_row = QWidget(text_container)
        title_row_layout = QHBoxLayout(title_row)
        title_row_layout.setContentsMargins(0, 0, 0, 0)
        title_row_layout.setSpacing(8)

        title_label = QLabel(title, title_row)
        title_label.setObjectName("RecentCardTitle")
        title_label.setTextFormat(Qt.PlainText)

        self._badge = QLabel(title_row)
        self._badge.setObjectName("RecentCardBadge")
        self._badge.setProperty("role", "chip")
        self._badge.setTextFormat(Qt.PlainText)
        if variant == "missing":
            self._badge.setText("Missing")
            self._badge.show()
        elif variant == "demo":
            self._badge.setText("DEMO")
            self._badge.show()
        else:
            self._badge.hide()

        title_row_layout.addWidget(title_label, 0)
        title_row_layout.addWidget(self._badge, 0, Qt.AlignLeft)
        title_row_layout.addStretch(1)

        subtitle_label = QLabel(subtitle, text_container)
        subtitle_label.setObjectName("RecentCardSubtitle")
        subtitle_label.setTextFormat(Qt.PlainText)
        subtitle_label.setProperty("role", "muted")
        subtitle_label.setWordWrap(True)

        detail_label = QLabel(detail, text_container)
        detail_label.setObjectName("RecentCardDetail")
        detail_label.setFont(monospace_font())
        detail_label.setTextFormat(Qt.PlainText)
        detail_label.setProperty("role", "muted")
        detail_label.setWordWrap(False)

        text_layout.addWidget(title_row)
        text_layout.addWidget(subtitle_label)
        text_layout.addWidget(detail_label)

        chevron = QLabel("›", self)
        chevron.setObjectName("RecentCardChevron")
        chevron.setAlignment(Qt.AlignCenter)
        chevron.setFixedWidth(18)
        chevron.setProperty("role", "muted")

        self._menu_btn = QToolButton(self)
        self._menu_btn.setObjectName("RecentCardMenu")
        self._menu_btn.setText("⋯")
        self._menu_btn.setToolTip("Session actions")
        self._menu_btn.setCursor(Qt.PointingHandCursor)
        self._menu_btn.setAutoRaise(True)
        self._menu_btn.setFocusPolicy(Qt.NoFocus)
        self._menu_btn.setEnabled(False)
        self._menu_btn.setFixedWidth(28)
        self._menu_btn.clicked.connect(self._request_actions_from_button)
        self._menu_btn.show()

        layout.addWidget(text_container, 1)
        layout.addWidget(chevron, 0, Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(self._menu_btn, 0, Qt.AlignRight | Qt.AlignVCenter)

        self.setAccessibleName(title)
        self.setAccessibleDescription(subtitle)

    def enterEvent(self, event) -> None:  # type: ignore[override]
        self._menu_btn.setEnabled(True)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        if not self.hasFocus():
            self._menu_btn.setEnabled(False)
        super().leaveEvent(event)

    def focusInEvent(self, event) -> None:  # type: ignore[override]
        self._menu_btn.setEnabled(True)
        super().focusInEvent(event)

    def focusOutEvent(self, event) -> None:  # type: ignore[override]
        if not self.underMouse():
            self._menu_btn.setEnabled(False)
        super().focusOutEvent(event)

    def contextMenuEvent(self, event) -> None:  # type: ignore[override]
        self.actions_requested.emit(event.globalPos())
        event.accept()

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton:
            self.activated.emit()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        key = event.key()
        if key in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.activated.emit()
            event.accept()
            return
        if key == Qt.Key_Down:
            self.move_focus_requested.emit(1)
            event.accept()
            return
        if key == Qt.Key_Up:
            self.move_focus_requested.emit(-1)
            event.accept()
            return
        if key == Qt.Key_Menu or (
            key == Qt.Key_F10 and bool(event.modifiers() & Qt.ShiftModifier)
        ):
            self.actions_requested.emit(self.mapToGlobal(self.rect().center()))
            event.accept()
            return
        super().keyPressEvent(event)

    def _request_actions_from_button(self) -> None:
        self.actions_requested.emit(
            self._menu_btn.mapToGlobal(self._menu_btn.rect().bottomLeft())
        )


class WelcomeDialog(QDialog):
    """Simple start dialog to guide first-time users into demo/open/new flows."""

    _DEMO_RECENT_CRISPR = "helix://demo/crispr"
    _CRISPR_DEMO_PRESET_ID = "crispr_demo_emx1_v1"
    _PRIME_DEMO_PRESET_ID = "prime_demo_emx1_v1"
    _CRISPR_DEMO_ACK_KEY = "welcome/crispr_demo_acknowledged"

    def __init__(self, parent=None, recent_sessions: list[str] | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Welcome to Helix Studio")
        frameless = os.getenv("HELIX_WELCOME_FRAMELESS", "0") == "1"
        flags = self.windowFlags()
        if frameless:
            flags |= Qt.FramelessWindowHint
            self.setSizeGripEnabled(True)
        else:
            flags &= ~Qt.FramelessWindowHint
            # Make the welcome surface resizable (notably on Windows where dialogs default to fixed-size
            # chrome unless a maximize button hint is present).
            flags |= Qt.WindowMaximizeButtonHint
        self.setWindowFlags(flags)
        self.setObjectName("WelcomeDialog")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setProperty("role", "card")
        # The welcome screen should read as an IDE workspace surface.
        self.setAutoFillBackground(True)
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)
        # Responsive sizing: the dialog should remain usable on laptop screens.
        # We still prefer a wide, IDE-like surface on larger displays.
        self.setMinimumSize(560, 440)
        screen = QApplication.screenAt(QCursor.pos()) or QApplication.primaryScreen()
        available = screen.availableGeometry() if screen else None
        target_w, target_h = 1200, 620
        if available:
            target_w = min(target_w, max(self.minimumWidth(), available.width() - 40))
            target_h = min(target_h, max(self.minimumHeight(), available.height() - 80))
        self.resize(target_w, target_h)
        self._recent_sessions: list[str] = []
        self._on_open_recent: Callable[[str], None] | None = None
        self._on_remove_recent: Callable[[str], None] | None = None
        self._on_new_handler: Callable[[str | None], None] | None = None
        self._on_demo_handler: Callable[[], None] | None = None
        self._on_prime_demo_handler: Callable[[], None] | None = None
        self._responsive_mode: str | None = None
        self._drag_offset = None
        self._recent_cards: list[RecentSessionCard] = []
        self._recent_tab_anchor: QWidget | None = None

        main = QVBoxLayout(self)
        main.setContentsMargins(24, 24, 24, 24)
        main.setSpacing(16)

        # --- Custom chrome/header ---
        header = QWidget(self)
        header.setObjectName("WelcomeHeader")
        header.setProperty("role", "panel")
        header.setAttribute(Qt.WA_StyledBackground, True)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(12, 10, 12, 6)
        header_layout.setSpacing(10)

        brand_icon = QLabel(header)
        brand_icon.setObjectName("WelcomeBrandIcon")
        brand_icon.setFixedSize(24, 24)
        brand_icon.setAlignment(Qt.AlignCenter)
        icon = self._load_header_icon()
        if icon is not None:
            brand_icon.setPixmap(icon)
        else:
            brand_icon.setText("⌬")

        brand_stack = QWidget(header)
        brand_stack_layout = QVBoxLayout(brand_stack)
        brand_stack_layout.setContentsMargins(0, 0, 0, 0)
        brand_stack_layout.setSpacing(1)

        brand_title = QLabel("Helix Studio", brand_stack)
        brand_title.setObjectName("WelcomeBrand")

        brand_stack_layout.addWidget(brand_title)
        brand_tagline = QLabel(
            "The Genome IDE\n"
            "Supports: KO · Prime · Roadmap: KI · Base · CRISPRi/a",
            brand_stack,
        )
        brand_tagline.setObjectName("WelcomeBrandTagline")
        brand_tagline.setProperty("role", "muted")
        brand_stack_layout.addWidget(brand_tagline)

        header_spacer = QWidget(header)
        header_spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

        header_layout.addWidget(brand_icon, 0, Qt.AlignVCenter)
        header_layout.addWidget(brand_stack, 0, Qt.AlignVCenter)
        header_layout.addWidget(header_spacer)
        if frameless:
            close_btn = QToolButton(header)
            close_btn.setObjectName("ChromeClose")
            close_btn.setIcon(self.style().standardIcon(QStyle.SP_TitleBarCloseButton))
            close_btn.setFocusPolicy(Qt.NoFocus)
            close_btn.setProperty("role", "windowbtn")
            close_btn.setProperty("kind", "close")
            close_btn.clicked.connect(self.reject)
            header_layout.addWidget(close_btn, 0, Qt.AlignRight)
        main.addWidget(header)

        # --- Top (hero) area ---
        top_area = QWidget(self)
        top_area.setObjectName("WelcomeTopArea")
        top_area.setProperty("role", "panel")
        top_area.setAttribute(Qt.WA_StyledBackground, True)
        top_layout = QVBoxLayout(top_area)
        top_layout.setContentsMargins(16, 16, 16, 16)
        top_layout.setSpacing(12)

        title = QLabel("Welcome", self)
        title.setObjectName("WelcomeTitle")
        subtitle = QLabel(
            "Design, simulate, and validate genome edits in silico.\n"
            "GPU accelerated. Deterministic. Reproducible.",
            self,
        )
        subtitle.setObjectName("WelcomeSubtitle")
        subtitle.setProperty("role", "muted")
        subtitle.setWordWrap(True)
        subtitle.setTextFormat(Qt.PlainText)
        top_layout.addWidget(title)
        top_layout.addWidget(subtitle)

        # Buttons row
        buttons = QBoxLayout(QBoxLayout.LeftToRight)
        buttons.setSpacing(12)
        self._buttons_layout = buttons
        self.start_btn = QPushButton("Start new experiment", self)
        self.start_btn.setObjectName("WelcomeStartExperiment")
        self.start_btn.setProperty("role", "btnPrimary")
        self.start_btn.setMinimumWidth(170)
        self.start_btn.setDefault(True)

        self.open_btn = QPushButton("Open saved session…", self)
        self.open_btn.setProperty("role", "panel")
        self.open_btn.setMinimumWidth(150)

        self.demo_btn = QPushButton("Open CRISPR Demo (DEMO)", self)
        self.demo_btn.setObjectName("WelcomeOpenDemo")
        self.demo_btn.setProperty("role", "panel")
        self.demo_btn.setMinimumWidth(200)
        self.demo_btn.setToolTip(self._crispr_demo_tooltip())

        demo_block = QWidget(self)
        demo_block_layout = QVBoxLayout(demo_block)
        demo_block_layout.setContentsMargins(0, 0, 0, 0)
        demo_block_layout.setSpacing(4)
        demo_block_layout.addWidget(self.demo_btn)

        demo_subtext = QLabel(
            "DEMO (NON-CALIBRATED) • Quantitative outputs suppressed • Exports watermarked",
            demo_block,
        )
        demo_subtext.setObjectName("WelcomeDemoSubtext")
        demo_subtext.setProperty("role", "muted")
        demo_subtext.setWordWrap(True)
        demo_subtext.setTextFormat(Qt.PlainText)
        demo_subtext.setStyleSheet("color: palette(mid); font-size: 11px;")
        demo_block_layout.addWidget(demo_subtext)

        buttons.addWidget(self.start_btn)
        buttons.addWidget(self.open_btn)
        buttons.addWidget(demo_block)
        top_layout.addLayout(buttons)

        demo_contract = QLabel(self)
        demo_contract.setObjectName("WelcomeDemoContract")
        demo_contract.setTextFormat(Qt.RichText)
        demo_contract.setTextInteractionFlags(Qt.TextBrowserInteraction)
        demo_contract.setOpenExternalLinks(False)
        demo_contract.setProperty("role", "muted")
        demo_contract.setStyleSheet("color: palette(link); font-size: 11px;")
        demo_contract.setText('<a href="demo_contract">View CRISPR demo contract</a>')
        demo_contract.linkActivated.connect(lambda _=None: self._on_demo_contract_clicked())
        top_layout.addWidget(demo_contract)

        # Keyboard hierarchy: start → open saved → demo.
        self.setTabOrder(self.start_btn, self.open_btn)
        self.setTabOrder(self.open_btn, self.demo_btn)

        # Always allow Esc to close the dialog.
        # Frameless chrome still needs a clear exit path.
        self._esc_shortcut = QShortcut(QKeySequence(Qt.Key_Escape), self)
        self._esc_shortcut.activated.connect(self.reject)

        main.addWidget(top_area)

        # --- Bottom grid: left quick actions, right recents (responsive) ---
        bottom = QBoxLayout(QBoxLayout.LeftToRight)
        bottom.setSpacing(24)
        bottom.setContentsMargins(0, 0, 0, 0)
        bottom.setAlignment(Qt.AlignTop)
        self._bottom_layout = bottom

        left = QWidget(self)
        self._bottom_left = left
        left.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        quick_card = QuickActionsPanel(left)
        self._quick_card = quick_card
        quick_card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        quick_card.setMinimumHeight(240)
        quick_layout = QVBoxLayout(quick_card)
        quick_layout.setContentsMargins(16, 18, 16, 14)
        quick_layout.setSpacing(10)

        quick_header = QLabel("Active toolchain", quick_card)
        quick_header.setObjectName("QuickHeader")
        quick_layout.addWidget(quick_header)

        quick_subtitle = QLabel(
            "Execution environment (locked for reproducibility)",
            quick_card,
        )
        quick_subtitle.setObjectName("QuickSubtitle")
        quick_subtitle.setProperty("role", "muted")
        quick_subtitle.setStyleSheet("color: palette(mid); font-size: 11px;")
        quick_subtitle.setWordWrap(True)
        quick_layout.addWidget(quick_subtitle)

        toolchain = QLabel(self._toolchain_summary_rich(), quick_card)
        toolchain.setObjectName("ToolchainMeta")
        toolchain.setFont(monospace_font())
        toolchain.setTextFormat(Qt.RichText)
        toolchain.setTextInteractionFlags(Qt.TextBrowserInteraction)
        toolchain.setOpenExternalLinks(False)
        toolchain.setProperty("role", "muted")
        toolchain.setWordWrap(True)
        toolchain.setToolTip("Click Deterministic D* for details, or open full toolchain details.")
        toolchain.linkActivated.connect(self._on_toolchain_link_activated)
        quick_layout.addWidget(toolchain)

        self._demo_reference_badge = QLabel(self._crispr_demo_reference_line(), quick_card)
        self._demo_reference_badge.setObjectName("ToolchainDemoReference")
        self._demo_reference_badge.setProperty("role", "chip")
        self._demo_reference_badge.setTextFormat(Qt.PlainText)
        self._demo_reference_badge.setWordWrap(True)
        self._demo_reference_badge.setToolTip("Demo reference dataset • DEMO (NON-CALIBRATED)")
        self._demo_reference_badge.hide()
        quick_layout.addWidget(self._demo_reference_badge)

        def make_link(text: str, handler) -> QPushButton:
            btn = QPushButton(text, quick_card)
            btn.setFlat(True)
            btn.setProperty("role", "link")
            btn.clicked.connect(handler)
            f = btn.font()
            f.setPointSize(HX_FONT_MD)
            btn.setFont(f)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            return btn

        create_experiment = make_link("Start new experiment", self._on_start_experiment_clicked)
        create_experiment.setFlat(True)
        create_experiment.setObjectName("CapabilitiesStartExperiment")
        quick_layout.addWidget(create_experiment)

        docs_btn = make_link("Documentation", self._on_open_docs_clicked)
        docs_btn.setObjectName("CapabilitiesDocs")
        quick_layout.addWidget(docs_btn)
        self._recent_tab_anchor = docs_btn

        quick_layout.addStretch(1)
        left_layout.addWidget(quick_card)

        bottom.addWidget(left, 2)

        right = QWidget(self)
        self._bottom_right = right
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        recent_group = QGroupBox("Recent sessions", right)
        self._recent_group = recent_group
        recent_group.setObjectName("RecentSessions")
        recent_group.setProperty("role", "card")
        recent_group.setMinimumHeight(130)
        group_layout = QVBoxLayout(recent_group)
        group_layout.setContentsMargins(12, 16, 12, 12)
        group_layout.setSpacing(6)

        self.recent_scroll = QScrollArea(recent_group)
        self.recent_scroll.setObjectName("RecentScroll")
        self.recent_scroll.setWidgetResizable(True)
        self.recent_scroll.setFocusPolicy(Qt.NoFocus)
        self.recent_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.recent_scroll.setFrameShape(QFrame.NoFrame)
        self.recent_scroll.setMinimumWidth(0)

        self.recent_container = QWidget(self.recent_scroll)
        self.recent_container.setObjectName("RecentContainer")
        self.recent_layout = QVBoxLayout(self.recent_container)
        self.recent_layout.setContentsMargins(0, 0, 0, 0)
        self.recent_layout.setSpacing(8)
        self.recent_scroll.setWidget(self.recent_container)

        group_layout.addWidget(self.recent_scroll)

        # Continue tab navigation in a stable, top-to-bottom order.
        self.setTabOrder(self.demo_btn, create_experiment)
        self.setTabOrder(create_experiment, docs_btn)

        right_layout.addWidget(recent_group)

        bottom.addWidget(right, 1)

        main.addLayout(bottom)

        # Footer: technical credibility + runtime hints
        footer_frame = QWidget(self)
        footer_frame.setObjectName("WelcomeFooter")
        footer_frame.setAttribute(Qt.WA_StyledBackground, True)
        footer_layout = QHBoxLayout(footer_frame)
        footer_layout.setContentsMargins(12, 6, 12, 6)
        footer_layout.setSpacing(10)
        credibility_label = QLabel(
            "Local-first execution · GPU native · Deterministic outputs · All runs are provenance-tracked",
            footer_frame,
        )
        credibility_label.setObjectName("FooterCredibility")
        credibility_label.setProperty("role", "muted")
        footer_layout.addWidget(credibility_label)
        footer_layout.addStretch(1)

        gpu_status = "enabled" if self._cuda_fields_available() else "not detected"
        gpu_name = self._detect_gpu_name()
        gpu_meta = f"{gpu_status} ({gpu_name})" if gpu_name else gpu_status
        meta_label = QLabel(f"GPU: {gpu_meta} · v{__version__}", footer_frame)
        meta_label.setObjectName("FooterLabel")
        meta_label.setProperty("role", "muted")
        footer_layout.addWidget(meta_label, 0, Qt.AlignRight)

        main.addWidget(footer_frame)

        # Connect close actions; actual handlers are wired by caller
        self.demo_btn.clicked.connect(self.accept)
        self.open_btn.clicked.connect(self.accept)
        self.start_btn.clicked.connect(self.accept)

        self.set_recent_sessions(recent_sessions or [])
        self.start_btn.setFocus(Qt.TabFocusReason)
        self._apply_responsive_layout()

        self.demo_btn.installEventFilter(self)
        self.open_btn.installEventFilter(self)
        self.start_btn.installEventFilter(self)

    def eventFilter(self, watched, event) -> bool:  # type: ignore[override]
        if watched is self.demo_btn:
            if event.type() == QEvent.FocusIn:
                self._set_demo_reference_visible(True)
            elif event.type() == QEvent.FocusOut:
                self._set_demo_reference_visible(False)
        return super().eventFilter(watched, event)

    def set_handlers(
        self,
        on_demo: Callable[[], None],
        on_open: Callable[[], None],
        on_new: Callable[[str | None], None],
    ) -> None:
        self._on_demo_handler = on_demo
        self._on_new_handler = on_new

        self.demo_btn.clicked.disconnect()
        self.demo_btn.clicked.connect(self._on_demo_clicked_guarded)

        self.open_btn.clicked.disconnect()
        self.open_btn.clicked.connect(on_open)

        self.start_btn.clicked.disconnect()
        self.start_btn.clicked.connect(self._on_start_experiment_clicked)

    def set_recent_handler(self, on_recent: Callable[[str], None]) -> None:
        self._on_open_recent = on_recent

    def set_recent_remove_handler(
        self,
        on_remove_recent: Callable[[str], None],
    ) -> None:
        self._on_remove_recent = on_remove_recent

    def set_prime_demo_handler(self, on_prime_demo: Callable[[], None]) -> None:
        self._on_prime_demo_handler = on_prime_demo

    def set_recent_sessions(self, paths: list[str]) -> None:
        self._recent_sessions = paths or []
        self._rebuild_recent_list()

    def _on_start_empty_clicked(self) -> None:
        self._on_start_experiment_clicked()

    def _on_start_experiment_clicked(self) -> None:
        mode = self._prompt_new_experiment_mode()
        if mode is None:
            return
        if callable(self._on_new_handler):
            self._on_new_handler(mode)
        else:
            self.start_btn.click()
        if self.isVisible():
            self.accept()

    def _prompt_new_experiment_mode(self) -> str | None:
        dlg = QDialog(self)
        dlg.setWindowTitle("Start new experiment")
        dlg.setModal(True)
        dlg.setObjectName("WelcomeNewExperimentDialog")
        dlg.resize(520, 300)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        intro = QLabel("Choose a starting point:", dlg)
        intro.setTextFormat(Qt.PlainText)
        intro.setStyleSheet("font-weight: 650; font-size: 14px;")
        layout.addWidget(intro)

        radio_goal = QRadioButton("Define experiment goal (recommended)", dlg)
        radio_goal.setChecked(True)
        layout.addWidget(radio_goal)

        goal_help = QLabel(
            "Begin with the biological question and success criteria. Helix will enforce design and validation policies.",
            dlg,
        )
        goal_help.setTextFormat(Qt.PlainText)
        goal_help.setWordWrap(True)
        goal_help.setStyleSheet("margin-left: 24px; color: palette(mid); font-size: 12px;")
        layout.addWidget(goal_help)

        radio_gene = QRadioButton("Explore a gene or locus", dlg)
        layout.addWidget(radio_gene)

        gene_help = QLabel(
            "Inspect targets and feasibility. You will still need an experiment goal, validation plan, and controls before export.",
            dlg,
        )
        gene_help.setTextFormat(Qt.PlainText)
        gene_help.setWordWrap(True)
        gene_help.setStyleSheet("margin-left: 24px; color: palette(mid); font-size: 12px;")
        layout.addWidget(gene_help)

        layout.addStretch(1)

        actions = QHBoxLayout()
        actions.addStretch(1)

        cancel_btn = QPushButton("Cancel", dlg)
        cancel_btn.clicked.connect(dlg.reject)
        actions.addWidget(cancel_btn)

        continue_btn = QPushButton("Continue", dlg)
        continue_btn.setProperty("role", "btnPrimary")
        continue_btn.clicked.connect(dlg.accept)
        actions.addWidget(continue_btn)

        layout.addLayout(actions)

        if dlg.exec() != QDialog.Accepted:
            return None
        return "experiment_goal" if radio_goal.isChecked() else "gene_locus"

    def _set_demo_reference_visible(self, visible: bool) -> None:
        try:
            self._demo_reference_badge.setVisible(bool(visible))
        except Exception:
            return

    def _on_demo_clicked_guarded(self) -> None:
        if not self._ensure_crispr_demo_acknowledged():
            return
        if callable(self._on_demo_handler):
            self._on_demo_handler()
            return
        self.accept()

    def _ensure_crispr_demo_acknowledged(self) -> bool:
        """Return True if user has acknowledged the demo contract on this machine."""

        try:
            settings = QSettings("Helix", "Studio")
            if bool(settings.value(self._CRISPR_DEMO_ACK_KEY, False)):
                return True
        except Exception:
            settings = None

        dlg = QDialog(self)
        dlg.setWindowTitle("CRISPR demo (exploratory)")
        dlg.setModal(True)
        dlg.setObjectName("WelcomeDemoContractPreview")
        dlg.resize(560, 260)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Demo contract preview", dlg)
        title.setStyleSheet("font-weight: 650; font-size: 14px;")
        title.setTextFormat(Qt.PlainText)
        layout.addWidget(title)

        bullets = [
            "Exploratory demo session — not decision-grade.",
            "Exports are watermarked and provenance-tracked.",
            "Uses built-in reference data to stay local-first.",
        ]
        for line in bullets:
            label = QLabel(f"• {line}", dlg)
            label.setTextFormat(Qt.PlainText)
            label.setWordWrap(True)
            layout.addWidget(label)

        ack = QCheckBox("I understand demo runs are exploratory", dlg)
        ack.setChecked(False)
        layout.addWidget(ack)

        actions = QHBoxLayout()
        actions.addStretch(1)

        cancel_btn = QPushButton("Cancel", dlg)
        cancel_btn.clicked.connect(dlg.reject)
        actions.addWidget(cancel_btn)

        continue_btn = QPushButton("Continue", dlg)
        continue_btn.setProperty("role", "btnPrimary")
        continue_btn.setEnabled(False)
        continue_btn.clicked.connect(dlg.accept)
        actions.addWidget(continue_btn)

        ack.toggled.connect(continue_btn.setEnabled)
        layout.addLayout(actions)

        if dlg.exec() != QDialog.Accepted or not ack.isChecked():
            return False

        try:
            if settings is not None:
                settings.setValue(self._CRISPR_DEMO_ACK_KEY, True)
        except Exception:
            pass

        try:
            from helix.support.events import log_event

            log_event(
                "studio.demo_acknowledged",
                demo="crispr",
                source="welcome",
                key=self._CRISPR_DEMO_ACK_KEY,
            )
        except Exception:
            pass
        return True

    def _on_open_examples_clicked(self) -> None:
        examples = [
            ("EMX1 CRISPR demo", "examples/sessions/emx1_crispr.helix"),
            ("HEK3 off-target demo", "examples/sessions/hek3_offtargets.helix"),
            ("Prime editing demo", "examples/sessions/prime_demo.helix"),
        ]
        items = [name for name, _ in examples]
        choice, ok = QInputDialog.getItem(
            self,
            "Open example genome",
            "Example:",
            items,
            0,
            False,
        )
        if not ok:
            return
        mapping = dict(examples)
        path = mapping.get(choice)
        if path and callable(self._on_open_recent):
            self._on_open_recent(path)
            self.accept()

    def _on_open_docs_clicked(self) -> None:
        try:
            QDesktopServices.openUrl(QUrl("https://helix-studio.com/docs"))
        except Exception:
            pass

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        self._apply_responsive_layout()
        center_on_focused_window(self)

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._apply_responsive_layout()

    def _apply_responsive_layout(self) -> None:
        width = max(1, int(self.width()))
        mode = "compact" if width < 980 else "wide"
        if mode == self._responsive_mode:
            return
        self._responsive_mode = mode

        if mode == "compact":
            try:
                self._buttons_layout.setDirection(QBoxLayout.TopToBottom)
            except Exception:
                pass
            try:
                self._bottom_layout.setDirection(QBoxLayout.TopToBottom)
            except Exception:
                pass
            try:
                self._bottom_layout.setStretchFactor(self._bottom_left, 0)
                self._bottom_layout.setStretchFactor(self._bottom_right, 1)
            except Exception:
                pass
            try:
                self._quick_card.setMinimumHeight(0)
                self._recent_group.setMinimumHeight(0)
            except Exception:
                pass
            return

        try:
            self._buttons_layout.setDirection(QBoxLayout.LeftToRight)
        except Exception:
            pass
        try:
            self._bottom_layout.setDirection(QBoxLayout.LeftToRight)
        except Exception:
            pass
        try:
            self._bottom_layout.setStretchFactor(self._bottom_left, 2)
            self._bottom_layout.setStretchFactor(self._bottom_right, 1)
        except Exception:
            pass
        try:
            self._quick_card.setMinimumHeight(240)
            self._recent_group.setMinimumHeight(130)
        except Exception:
            pass

    def _rebuild_recent_list(self) -> None:
        self._clear_recent_cards()

        if not self._recent_sessions:
            demo_contract = self._crispr_demo_contract()
            seed = demo_contract.get("seed")
            seed_txt = str(seed) if seed is not None else "?"
            demo = self._make_recent_card(
                title="Open CRISPR demo",
                subtitle="DEMO (NON-CALIBRATED) • Quantitative outputs suppressed",
                detail=(
                    f"Reference: {demo_contract.get('genome_id')} · "
                    f"Build: {demo_contract.get('genome_build')} · "
                    f"Seed: {seed_txt} · No files required"
                ),
                payload=self._DEMO_RECENT_CRISPR,
                variant="demo",
            )
            demo.setToolTip("DEMO (NON-CALIBRATED) • Quantitative outputs suppressed")
            self.recent_layout.addWidget(demo)
            self._recent_cards = [demo]
            self.recent_layout.addStretch(1)
            self._wire_recent_tab_order()
            return

        cards: list[RecentSessionCard] = []
        for path_str in self._recent_sessions:
            path = Path(path_str)
            title = path.name or path_str
            recency = self._recency_label(path)
            if path.exists():
                session_class = self._infer_session_class_from_path(path)
                is_demo = bool(session_class == "demo")
                if is_demo:
                    subtitle = "DEMO (NON-CALIBRATED) • Quantitative outputs suppressed"
                    if recency:
                        subtitle += f" · Last opened: {recency}"
                    variant = "demo"
                else:
                    subtitle = (
                        f"Open session · Last opened: {recency}"
                        if recency
                        else "Open session"
                    )
                    variant = "session"
            else:
                subtitle = "Missing on disk · Open to locate or remove"
                variant = "missing"
            card = self._make_recent_card(
                title=title,
                subtitle=subtitle,
                detail=str(path),
                payload=path_str,
                variant=variant,
            )
            if variant == "demo":
                card.setToolTip("DEMO (NON-CALIBRATED) • Quantitative outputs suppressed")
            else:
                card.setToolTip(str(path))
            cards.append(card)
            self.recent_layout.addWidget(card)

        self._recent_cards = cards
        self.recent_layout.addStretch(1)
        self._wire_recent_tab_order()

    def _recency_label(self, path: Path) -> str | None:
        try:
            modified = datetime.fromtimestamp(path.stat().st_mtime).date()
            delta = (date.today() - modified).days
            if delta == 0:
                return "today"
            if delta == 1:
                return "yesterday"
            if delta >= 0:
                return f"{delta} days ago"
        except Exception:
            return None
        return None

    def _infer_session_class_from_path(self, path: Path) -> str | None:
        """Best-effort extraction of session_class for a saved session file."""

        try:
            raw = json.loads(path.read_text(encoding="utf8"))
        except Exception:
            return None
        if not isinstance(raw, Mapping):
            return None
        return self._infer_session_class_from_payload(raw)

    def _infer_session_class_from_payload(self, payload: Mapping[str, Any]) -> str | None:
        allowed = {"demo", "exploratory", "decision_candidate"}
        state = payload.get("state") if isinstance(payload.get("state"), Mapping) else None
        cfg = None
        if isinstance(state, Mapping):
            cfg = state.get("config") if isinstance(state.get("config"), Mapping) else None
        meta = None
        if isinstance(cfg, Mapping):
            meta = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else None

        if isinstance(meta, Mapping):
            session_class = str(meta.get("session_class") or "").strip().lower()
            if session_class in allowed:
                return session_class
            scenario = str(meta.get("scenario") or "").strip().lower()
            preset_id = str(meta.get("preset_id") or "").strip().lower()
            if scenario == "demo" or preset_id.startswith(("crispr_demo_", "prime_demo_")):
                return "demo"

        runs = payload.get("runs") if isinstance(payload.get("runs"), list) else []
        for run in runs:
            if not isinstance(run, Mapping):
                continue
            rmeta = run.get("metadata") if isinstance(run.get("metadata"), Mapping) else None
            if not isinstance(rmeta, Mapping):
                continue
            scenario = str(rmeta.get("scenario") or "").strip().lower()
            if scenario == "demo":
                return "demo"
            preset_id = str(rmeta.get("preset_id") or "").strip().lower()
            if preset_id.startswith(("crispr_demo_", "prime_demo_")):
                return "demo"

        return None

    def _on_open_crispr_demo_clicked(self) -> None:
        self._on_demo_clicked_guarded()

    def _on_open_prime_demo_clicked(self) -> None:
        if callable(self._on_prime_demo_handler):
            self._on_prime_demo_handler()
            if self.isVisible():
                self.accept()
            return
        if callable(self._on_open_recent):
            self._on_open_recent("examples/sessions/prime_demo.helix")
            if self.isVisible():
                self.accept()

    def _make_recent_card(
        self,
        *,
        title: str,
        subtitle: str,
        detail: str,
        payload: str,
        variant: str,
    ) -> RecentSessionCard:
        card = RecentSessionCard(
            title,
            subtitle,
            detail,
            variant=variant,
            parent=self.recent_container,
        )
        card.setProperty("payload", payload)
        card.activated.connect(self._on_recent_card_activated)
        card.move_focus_requested.connect(self._on_recent_card_move_focus_requested)
        card.actions_requested.connect(self._on_recent_card_actions_requested)
        return card

    def _clear_recent_cards(self) -> None:
        self._recent_cards = []
        while self.recent_layout.count():
            item = self.recent_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _wire_recent_tab_order(self) -> None:
        anchor = self._recent_tab_anchor
        if anchor is None or not self._recent_cards:
            return
        self.setTabOrder(anchor, self._recent_cards[0])
        for a, b in zip(self._recent_cards, self._recent_cards[1:]):
            self.setTabOrder(a, b)
        self.setTabOrder(self._recent_cards[-1], self._esc_shortcut.parent())

    def _on_recent_card_actions_requested(self, global_pos) -> None:
        card = self.sender()
        if not isinstance(card, RecentSessionCard):
            return
        payload = card.property("payload")
        if not payload:
            return
        menu = self._build_recent_actions_menu(payload, global_pos)
        selected = menu.exec(global_pos)
        action = selected.data() if selected is not None else None
        if action == "remove":
            if callable(self._on_remove_recent):
                self._on_remove_recent(payload)
            try:
                self._recent_sessions.remove(payload)
            except ValueError:
                pass
            self._rebuild_recent_list()
        elif action == "copy":
            self._copy_to_clipboard(payload, global_pos=global_pos)
        elif action == "reveal":
            self._reveal_in_explorer(payload)

    def _reveal_in_explorer(self, path_str: str) -> None:
        path = Path(path_str)
        target = path
        if not path.exists():
            target = path.parent
        if not target.exists():
            return
        try:
            if sys.platform.startswith("darwin"):
                import subprocess

                subprocess.check_call(["open", "--", str(target.resolve())])
            elif sys.platform.startswith("win"):
                import subprocess

                subprocess.check_call(["explorer.exe", str(target.resolve())])
            else:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(target.resolve())))
        except Exception:
            pass

    def _copy_to_clipboard(self, text: str, *, global_pos=None) -> None:
        clipboard = QApplication.clipboard()
        if clipboard is None:
            return
        clipboard.setText(text)
        try:
            QToolTip.showText(global_pos or QCursor.pos(), "Copied path")
        except Exception:
            pass

    def _build_recent_actions_menu(self, payload: str, global_pos) -> QMenu:
        _ = global_pos
        path = Path(payload)
        parent_ok = False
        try:
            parent_ok = path.parent.exists()
        except Exception:
            parent_ok = False
        menu = QMenu(self)
        copy = menu.addAction("Copy path")
        copy.setData("copy")
        reveal = menu.addAction("Reveal in folder")
        reveal.setData("reveal")
        reveal.setEnabled(bool(parent_ok))
        remove = menu.addAction("Remove from recents")
        remove.setData("remove")
        return menu

    def _on_recent_card_activated(self) -> None:
        card = self.sender()
        if not isinstance(card, RecentSessionCard):
            return
        payload = card.property("payload")
        variant = card.property("variant")
        if str(variant or "") == "missing" and payload:
            action = self._prompt_missing_session_action(str(payload))
            if action == "remove":
                if callable(self._on_remove_recent):
                    self._on_remove_recent(str(payload))
                try:
                    self._recent_sessions.remove(str(payload))
                except ValueError:
                    pass
                self._rebuild_recent_list()
            return

        if str(payload or "") == self._DEMO_RECENT_CRISPR:
            self._on_open_crispr_demo_clicked()
            return

        if payload and callable(self._on_open_recent):
            self._on_open_recent(payload)
        self.accept()

    def _prompt_missing_session_action(self, path_str: str) -> str:
        """Prompt for what to do when a recent session path is missing."""
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Warning)
        msg.setWindowTitle("Session missing")
        msg.setText("This session path was not found on disk:\n\n" + str(path_str))
        locate = msg.addButton("Locate…", QMessageBox.AcceptRole)
        remove = msg.addButton("Remove from recents", QMessageBox.DestructiveRole)
        cancel = msg.addButton("Cancel", QMessageBox.RejectRole)
        _ = locate
        msg.setDefaultButton(remove)
        msg.exec()
        clicked = msg.clickedButton()
        if clicked is remove:
            return "remove"
        if clicked is locate:
            return "locate"
        if clicked is cancel:
            return "cancel"
        return "cancel"

    def _on_recent_card_move_focus_requested(self, delta: int) -> None:
        if not self._recent_cards:
            return
        card = self.sender()
        if card not in self._recent_cards:
            return
        idx = self._recent_cards.index(card)
        nxt = max(0, min(len(self._recent_cards) - 1, idx + delta))
        try:
            self._recent_cards[nxt].setFocus(Qt.TabFocusReason)
        except Exception:
            pass

    def _toolchain_summary_info(self) -> dict[str, Any]:
        try:
            from helix import __version__ as HELIX_VERSION
        except Exception:
            HELIX_VERSION = ""

        determinism = None
        locked = False
        try:
            from helix.scientific_contract import current_contract_identity, load_model_semantics, load_policy

            ident = current_contract_identity()
            if not ident.get("policy_hash") or not ident.get("determinism_class"):
                try:
                    load_policy(None)
                except Exception:
                    pass
            if not ident.get("semantic_hash"):
                try:
                    load_model_semantics(None)
                except Exception:
                    pass
            ident = current_contract_identity()
            determinism = ident.get("determinism_class")
            locked = bool(ident.get("policy_hash") and ident.get("semantic_hash") and determinism)
        except Exception:
            determinism = None
            locked = False

        version = str(HELIX_VERSION or "unknown").strip()
        lock_word = "locked" if locked else "unlocked"
        determinism_label = str(determinism or "unknown")

        cuda_fields_loaded = False
        try:
            import helix_cuda_fields  # type: ignore

            cuda_fields_loaded = True
        except Exception:
            cuda_fields_loaded = False

        moderngl_ready = False
        try:
            import moderngl  # type: ignore

            moderngl_ready = True
        except Exception:
            moderngl_ready = False

        return {
            "version": version,
            "locked": locked,
            "lock_word": lock_word,
            "determinism_class": determinism_label,
            "cuda_fields_loaded": cuda_fields_loaded,
            "moderngl_ready": moderngl_ready,
        }

    def _toolchain_summary(self) -> str:
        info = self._toolchain_summary_info()
        parts = [
            f"Kernel v{info.get('version')} {info.get('lock_word')}",
            f"Deterministic {info.get('determinism_class')}",
            "CUDA fields loaded" if info.get("cuda_fields_loaded") else "CUDA fields missing",
            "ModernGL ready" if info.get("moderngl_ready") else "ModernGL missing",
        ]
        return " · ".join(parts)

    def _toolchain_summary_rich(self) -> str:
        info = self._toolchain_summary_info()
        version = info.get("version") or "unknown"
        lock_word = info.get("lock_word") or "unlocked"
        det = info.get("determinism_class") or "unknown"
        cuda_txt = "CUDA fields loaded" if info.get("cuda_fields_loaded") else "CUDA fields missing"
        gl_txt = "ModernGL ready" if info.get("moderngl_ready") else "ModernGL missing"
        return (
            f"Kernel v{version} {lock_word} · "
            f'<a href="determinism">Deterministic {det}</a> · '
            f"{cuda_txt} · {gl_txt} · "
            f'<a href="toolchain">Details…</a>'
        )

    def _on_toolchain_link_activated(self, href: str) -> None:
        if str(href or "") == "determinism":
            self._on_determinism_details_clicked()
            return
        self._on_toolchain_details_clicked()

    def _load_preset_raw(self, preset_id: str) -> dict[str, Any] | None:
        try:
            from helix.studio.experiment_presets import load_preset

            preset = load_preset(preset_id)
            return dict(preset.raw or {})
        except Exception:
            return None

    def _crispr_demo_contract(self) -> dict[str, Any]:
        raw = self._load_preset_raw(self._CRISPR_DEMO_PRESET_ID) or {}
        genome = raw.get("genome") if isinstance(raw.get("genome"), Mapping) else {}
        coords = genome.get("coords") if isinstance(genome.get("coords"), Mapping) else {}
        annotation = genome.get("annotation") if isinstance(genome.get("annotation"), Mapping) else {}
        sim = raw.get("simulation") if isinstance(raw.get("simulation"), Mapping) else {}
        crispr = raw.get("crispr") if isinstance(raw.get("crispr"), Mapping) else {}
        edit_spec = raw.get("edit_spec") if isinstance(raw.get("edit_spec"), Mapping) else {}

        reference_build = coords.get("reference") or coords.get("build") or coords.get("genome_build")
        build_value = str(reference_build).strip() if reference_build else ""
        build_note = ""
        if not build_value:
            build_value = "n/a"
            build_note = "synthetic demo sequence; no reference build declared"

        contig = str(coords.get("contig") or coords.get("chrom") or coords.get("chr") or "").strip()
        start = coords.get("start")
        end = coords.get("end")
        genome_region = None
        if contig and start is not None and end is not None:
            genome_region = f"{contig}:{start}-{end}"

        annotation_source = str(annotation.get("source") or "").strip() or None
        annotation_release = annotation.get("release")
        gene_symbol = str(annotation.get("gene_symbol") or annotation.get("geneSymbol") or "").strip() or None
        gene_id = str(annotation.get("gene_id") or annotation.get("geneId") or "").strip() or None

        nuclease = str(crispr.get("nuclease") or "").strip() or "unknown"
        pam = str(crispr.get("pam_pattern") or "").strip() or "unknown"
        engine = str(sim.get("engine") or "").strip() or "unknown"
        priors = str(sim.get("priors_profile") or "").strip() or "unknown"
        draws = sim.get("draws")
        seed = sim.get("random_seed")
        edit_type = str(edit_spec.get("type") or "").strip() or "unknown"

        organism_note = ""
        if build_note:
            organism_note = "synthetic demo locus"
        else:
            note_parts: list[str] = []
            if genome_region:
                note_parts.append(str(genome_region))
            if annotation_source and annotation_release:
                note_parts.append(f"{annotation_source} r{annotation_release}")
            elif annotation_source:
                note_parts.append(str(annotation_source))
            if note_parts:
                organism_note = " · ".join(note_parts)

        return {
            "preset_id": str(raw.get("id") or self._CRISPR_DEMO_PRESET_ID),
            "label": str(raw.get("label") or "CRISPR demo"),
            "organism": "Human",
            "organism_note": organism_note,
            "genome_id": str(genome.get("id") or "demo_emx1"),
            "genome_description": str(genome.get("description") or ""),
            "genome_build": build_value,
            "genome_build_note": build_note,
            "genome_region": genome_region,
            "genome_sha256": str(genome.get("sequence_sha256") or "").strip() or None,
            "annotation_source": annotation_source,
            "annotation_release": annotation_release,
            "gene_symbol": gene_symbol,
            "gene_id": gene_id,
            "repair_engine": engine,
            "priors_profile": priors,
            "repair_model": f"{engine} (priors_profile={priors})",
            "edit_type": edit_type,
            "nuclease": nuclease,
            "pam": pam,
            "draws": draws,
            "seed": seed,
            "editable": True,
            "offtarget_model": str(crispr.get("offtarget_model") or "").strip() or "unknown",
        }

    def _crispr_demo_tooltip(self) -> str:
        c = self._crispr_demo_contract()
        organism = str(c.get("organism") or "unknown").strip() or "unknown"
        organism_note = str(c.get("organism_note") or "").strip()
        organism_label = f"{organism} ({organism_note})" if organism_note else organism
        draws = c.get("draws")
        seed = c.get("seed")
        draws_txt = str(draws) if draws is not None else "?"
        seed_txt = str(seed) if seed is not None else "?"
        build_note = str(c.get("genome_build_note") or "").strip()
        build_extra = f" ({build_note})" if build_note else ""
        edit_type = str(c.get("edit_type") or "unknown").strip() or "unknown"
        nuclease = str(c.get("nuclease") or "unknown").strip() or "unknown"
        pam = str(c.get("pam") or "unknown").strip() or "unknown"
        genome_region = str(c.get("genome_region") or "").strip()
        region_line = f"Region: {genome_region}\n" if genome_region else ""
        return (
            f"{organism_label}\n"
            f"Genome: {c.get('genome_id')} · Build: {c.get('genome_build')}{build_extra}\n"
            f"{region_line}"
            f"Edit: {edit_type} · {nuclease} · PAM {pam}\n"
            f"Repair: {c.get('repair_model')}\n"
            f"Seed={seed_txt} · Draws={draws_txt} · Session=editable"
        )

    def _crispr_demo_reference_line(self) -> str:
        c = self._crispr_demo_contract()
        organism = str(c.get("organism") or "unknown").strip() or "unknown"
        build = str(c.get("genome_build") or "unknown").strip() or "unknown"
        region = str(c.get("genome_region") or "").strip()
        annotation_source = str(c.get("annotation_source") or "").strip()
        annotation_release = c.get("annotation_release")
        build_note = str(c.get("genome_build_note") or "").strip()
        build_extra = f" ({build_note})" if build_note else ""
        parts = [f"Reference (demo): {organism}", f"{build}{build_extra}"]
        if region:
            parts.append(region)
        if annotation_source and annotation_release:
            parts.append(f"{annotation_source} r{annotation_release}")
        return " · ".join(parts)

    def _crispr_demo_contract_report(self) -> str:
        c = self._crispr_demo_contract()
        lines: list[str] = []

        def section(title: str) -> None:
            if lines:
                lines.append("")
            lines.append(f"== {title} ==")

        section("CRISPR Demo Contract")
        lines.append(f"preset_id={c.get('preset_id')}")
        lines.append(f"label={c.get('label')}")
        lines.append(f"organism={c.get('organism')}")
        if c.get("organism_note"):
            lines.append(f"organism_note={c.get('organism_note')}")
        lines.append(f"genome_id={c.get('genome_id')}")
        if c.get("genome_description"):
            lines.append(f"genome_description={c.get('genome_description')}")
        lines.append(f"genome_build={c.get('genome_build')}")
        if c.get("genome_build_note"):
            lines.append(f"genome_build_note={c.get('genome_build_note')}")
        if c.get("genome_region"):
            lines.append(f"genome_region={c.get('genome_region')}")
        if c.get("genome_sha256"):
            lines.append(f"genome_sha256={c.get('genome_sha256')}")
        if c.get("annotation_source"):
            lines.append(f"annotation_source={c.get('annotation_source')}")
        if c.get("annotation_release") is not None:
            lines.append(f"annotation_release={c.get('annotation_release')}")
        if c.get("gene_symbol"):
            lines.append(f"gene_symbol={c.get('gene_symbol')}")
        if c.get("gene_id"):
            lines.append(f"gene_id={c.get('gene_id')}")
        lines.append(f"edit_type={c.get('edit_type')}")
        lines.append(f"nuclease={c.get('nuclease')}")
        lines.append(f"pam={c.get('pam')}")
        lines.append(f"repair_model={c.get('repair_model')}")
        lines.append(f"offtarget_model={c.get('offtarget_model')}")
        lines.append(f"draws={c.get('draws')}")
        lines.append(f"seed={c.get('seed')}")
        lines.append("session_mode=editable (loads preset into your workspace)")

        section("Notes")
        lines.append("This demo uses a small synthetic locus for local-first execution.")
        lines.append("Off-target landscapes and coordinate-dependent analysis require ingesting a reference genome and building an FM index.")

        section("Kernel")
        lines.append(self._toolchain_summary())
        return "\n".join(lines).rstrip() + "\n"

    def _on_demo_contract_clicked(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("CRISPR demo contract")
        dlg.setModal(True)
        dlg.resize(860, 520)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("CRISPR demo contract (copy/paste for reproducibility).", dlg)
        title.setStyleSheet("font-weight: 650; font-size: 15px; color: palette(window-text);")
        layout.addWidget(title)

        body = QPlainTextEdit(dlg)
        body.setReadOnly(True)
        body.setLineWrapMode(QPlainTextEdit.NoWrap)
        body.setFont(monospace_font())
        body.setPlainText(self._crispr_demo_contract_report())
        body.setStyleSheet("background-color: palette(base); color: palette(window-text);")
        layout.addWidget(body, stretch=1)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy to clipboard", dlg)
        copy_btn.clicked.connect(lambda: QApplication.clipboard() and QApplication.clipboard().setText(body.toPlainText()))
        actions.addWidget(copy_btn)

        close_btn = QPushButton("Close", dlg)
        close_btn.clicked.connect(dlg.accept)
        actions.addWidget(close_btn)

        layout.addLayout(actions)
        dlg.exec()

    def _determinism_details_report(self) -> str:
        lines: list[str] = []

        def section(title: str) -> None:
            if lines:
                lines.append("")
            lines.append(f"== {title} ==")

        section("Determinism Classes (v1)")
        lines.append("D0=best-effort; nondeterminism allowed")
        lines.append("D1=deterministic within declared float tolerances; seeded RNG; fixed locale")
        lines.append("D2=distribution-stable; verifier enforces policy metrics under deterministic seeding")
        lines.append("biological_meaning=none (this is a compute reproducibility class, not a biological claim)")
        lines.append("source=docs/scientific_contract_v1.md")

        section("Active Contract")
        try:
            from helix.scientific_contract import load_model_semantics, load_policy

            policy, policy_hash, determinism, policy_path = load_policy(None)
            _semantics, semantic_hash = load_model_semantics(None)
            lines.append(f"determinism_class={determinism}")
            lines.append(f"policy_path={policy_path or 'unavailable'}")
            lines.append(f"policy_hash={policy_hash}")
            lines.append(f"semantic_hash={semantic_hash}")
            float_policy = policy.get("floatPolicy") if isinstance(policy.get("floatPolicy"), Mapping) else {}
            rng_policy = policy.get("rngPolicy") if isinstance(policy.get("rngPolicy"), Mapping) else {}
            lines.append(f"float_policy.mode={float_policy.get('mode', 'unknown')}")
            lines.append(f"float_policy.reduction={float_policy.get('reduction', 'unknown')}")
            lines.append(f"float_policy.fma_allowed={float_policy.get('fmaAllowed', 'unknown')}")
            lines.append(f"rng_policy.kdf={rng_policy.get('kdf', 'unknown')}")
            lines.append(f"rng_policy.root_seed_source={rng_policy.get('rootSeedSource', 'unknown')}")
            lines.append(f"rng_policy.ban_implicit_global_rng={rng_policy.get('banImplicitGlobalRng', 'unknown')}")
        except Exception as exc:
            lines.append(f"status=unavailable ({exc!r})")

        section("Repair Model (CRISPR demo)")
        c = self._crispr_demo_contract()
        lines.append(f"engine={c.get('repair_engine')}")
        lines.append(f"priors_profile={c.get('priors_profile')}")
        lines.append(f"edit_type={c.get('edit_type')}")
        lines.append(f"offtarget_model={c.get('offtarget_model')}")
        lines.append("training_provenance=not declared (heuristic priors)")

        section("Scope (model envelope)")
        lines.append("models_local_indels=yes (cut/repair outcomes around a single cut site)")
        lines.append("repair_mechanism=NHEJ-like indel categories (not a mechanistic DSB repair simulator)")
        lines.append("models_large_rearrangements=no (not chromothripsis / translocations)")
        lines.append("models_base_editing=no (roadmap)")
        lines.append("models_prime_editing=separate demo/model (prime_demo_emx1_v1)")
        lines.append("models_cell_type_effects=no (not cell-line calibrated)")
        lines.append("models_full_genome_offtargets=requires ingested reference + FM index")

        return "\n".join(lines).rstrip() + "\n"

    def _on_determinism_details_clicked(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("Determinism & model envelope")
        dlg.setModal(True)
        dlg.resize(860, 520)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Determinism & model envelope (copy/paste for reproducibility).", dlg)
        title.setStyleSheet("font-weight: 650; font-size: 15px; color: palette(window-text);")
        layout.addWidget(title)

        body = QPlainTextEdit(dlg)
        body.setReadOnly(True)
        body.setLineWrapMode(QPlainTextEdit.NoWrap)
        body.setFont(monospace_font())
        body.setPlainText(self._determinism_details_report())
        body.setStyleSheet("background-color: palette(base); color: palette(window-text);")
        layout.addWidget(body, stretch=1)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy to clipboard", dlg)
        copy_btn.clicked.connect(lambda: QApplication.clipboard() and QApplication.clipboard().setText(body.toPlainText()))
        actions.addWidget(copy_btn)

        close_btn = QPushButton("Close", dlg)
        close_btn.clicked.connect(dlg.accept)
        actions.addWidget(close_btn)

        layout.addLayout(actions)
        dlg.exec()

    def _toolchain_details_report(self) -> str:
        lines: list[str] = []

        def section(title: str) -> None:
            if lines:
                lines.append("")
            lines.append(f"== {title} ==")

        section("Toolchain")
        lines.append(f"helix_version={__version__}")
        lines.append(self._toolchain_summary())

        section("Reproducibility Contract")
        try:
            from helix.scientific_contract import current_contract_identity, load_model_semantics, load_policy

            ident = current_contract_identity()
            if not ident.get("policy_hash") or not ident.get("determinism_class"):
                try:
                    load_policy(None)
                except Exception:
                    pass
            if not ident.get("semantic_hash"):
                try:
                    load_model_semantics(None)
                except Exception:
                    pass
            ident = current_contract_identity()
            policy_hash = ident.get("policy_hash")
            semantic_hash = ident.get("semantic_hash")
            determinism = ident.get("determinism_class")
            locked = bool(policy_hash and semantic_hash and determinism)
            lines.append(f"locked={locked}")
            lines.append(f"policy_hash={policy_hash or 'unavailable'}")
            lines.append(f"semantic_hash={semantic_hash or 'unavailable'}")
            lines.append(f"determinism_class={determinism or 'unavailable'}")
            lines.append("export_note=Run/session exports record these fields when available.")
        except Exception as exc:
            lines.append(f"status=unavailable ({exc!r})")

        section("Scoring Models")
        try:
            from helix.crispr.physics import CRISPR_SCORING_VERSION
        except Exception:
            CRISPR_SCORING_VERSION = None
        try:
            from helix.prime.physics import PRIME_SCORING_VERSION
        except Exception:
            PRIME_SCORING_VERSION = None
        lines.append(f"crispr_scoring_version={CRISPR_SCORING_VERSION or 'unavailable'}")
        lines.append(f"prime_scoring_version={PRIME_SCORING_VERSION or 'unavailable'}")

        section("Backend")
        lines.append(f"cuda_fields_available={self._cuda_fields_available()}")
        gpu_name = self._detect_gpu_name()
        if gpu_name:
            lines.append(f"gpu_name={gpu_name}")
        try:
            from helix.genome.fm_registry import load_registry

            entries = load_registry()
            genome_ids = sorted(entries.keys())
            lines.append(f"genomes_registry_count={len(genome_ids)}")
            if genome_ids:
                lines.append("genomes_registry=" + ", ".join(genome_ids))
            else:
                lines.append("genomes_registry=(none)")
        except Exception as exc:
            lines.append(f"genomes_registry=(unavailable {exc!r})")

        section("Backend Fingerprint")
        try:
            from helix.scientific_contract import collect_backend_fingerprint

            backend_kind = "gpu" if self._cuda_fields_available() else "cpu"
            kind, details = collect_backend_fingerprint(backend_kind=backend_kind)
            lines.append(f"backend_kind={kind}")
            lines.append(json.dumps(details, indent=2, sort_keys=True))
        except Exception as exc:
            lines.append(f"status=unavailable ({exc!r})")

        section("Built-in Demos")
        demo = self._crispr_demo_contract()
        demo_org = str(demo.get("organism") or "unknown").strip() or "unknown"
        demo_org_note = str(demo.get("organism_note") or "").strip()
        demo_org_label = f"{demo_org} ({demo_org_note})" if demo_org_note else demo_org
        lines.append(
            f"{demo.get('preset_id')}="
            f"{demo_org_label} · "
            f"{demo.get('nuclease')} · "
            f"{demo.get('edit_type')} · "
            f"draws={demo.get('draws')} · "
            f"seed={demo.get('seed')} · "
            f"build={demo.get('genome_build')}"
        )
        lines.append("prime_demo_emx1_v1=Prime editing demo · draws=1000 · seed=12345 · build=n/a")
        return "\n".join(lines).rstrip() + "\n"

    def _on_toolchain_details_clicked(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle("Active toolchain details")
        dlg.setModal(True)
        dlg.resize(860, 520)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Active toolchain (copy/paste for reproducibility).", dlg)
        title.setStyleSheet("font-weight: 650; font-size: 15px; color: palette(window-text);")
        layout.addWidget(title)

        body = QPlainTextEdit(dlg)
        body.setReadOnly(True)
        body.setLineWrapMode(QPlainTextEdit.NoWrap)
        body.setFont(monospace_font())
        body.setPlainText(self._toolchain_details_report())
        body.setStyleSheet("background-color: palette(base); color: palette(window-text);")
        layout.addWidget(body, stretch=1)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy to clipboard", dlg)
        copy_btn.clicked.connect(lambda: QApplication.clipboard() and QApplication.clipboard().setText(body.toPlainText()))
        actions.addWidget(copy_btn)

        close_btn = QPushButton("Close", dlg)
        close_btn.clicked.connect(dlg.accept)
        actions.addWidget(close_btn)

        layout.addLayout(actions)
        dlg.exec()

    def _detect_gpu_name(self) -> str | None:
        env_name = None
        try:
            env_name = os.environ.get("HELIX_GPU_NAME")
        except Exception:
            env_name = None
        if env_name:
            return env_name
        try:
            from helix.gui.opengl import describe_gpu

            return describe_gpu()
        except Exception:
            return None

    def _cuda_fields_available(self) -> bool:
        try:
            import helix_cuda_fields  # noqa: F401
            return True
        except Exception:
            return False

    def _load_header_icon(self) -> QPixmap | None:
        studio_dir = Path(__file__).resolve().parent
        root = studio_dir.parents[3]
        candidates = [
            studio_dir / "resources" / "images" / "helix-studio-logo.png",
            studio_dir / "resources" / "images" / "helix-studio-logo.ico",
        ]
        candidates += [root / name for name in ("helix-studio-logo.png", "helix-studio-logo.ico", "logo.png", "icon.png")]

        for candidate in candidates:
            if not candidate.exists():
                continue
            pix = QPixmap(str(candidate))
            if not pix.isNull():
                return pix.scaled(
                    20,
                    20,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation,
                )
        return None
