from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, Sequence


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")


def _safe_float(val: Any) -> float:
    try:
        return float(val)
    except Exception:
        return 0.0


def _extract_pred_obs(record: Mapping[str, Any]) -> tuple[int, int, int]:
    """Return pred_ppm, obs_ppm, total_events (all ints) from a ResultsRecord."""
    outcome = record.get("outcomeReport") if isinstance(record, Mapping) else {}
    mux = None
    if isinstance(outcome, Mapping):
        if isinstance(outcome.get("multiplex"), Mapping):
            mux = outcome["multiplex"].get("prime") if isinstance(outcome["multiplex"].get("prime"), Mapping) else None
        if mux is None and isinstance(outcome.get("prime_multiplex"), Mapping):
            mux = outcome.get("prime_multiplex")
    pred_ppm = int(round(_safe_float(mux.get("combinedDesired")) * 1_000_000)) if isinstance(mux, Mapping) else 0

    obs_block = record.get("prime_multiplex_observed") if isinstance(record, Mapping) else {}
    obs_ppm = int(obs_block.get("combinedObsPpm") or 0) if isinstance(obs_block, Mapping) else 0
    total_events = int(obs_block.get("totalEvents") or 0) if isinstance(obs_block, Mapping) else 0
    return pred_ppm, obs_ppm, total_events


def build_prime_multiplex_leaderboard(
    *,
    profiles: Sequence[Mapping[str, Any]],
    batch_summary: Mapping[str, Any],
    records: Mapping[str, Mapping[str, Any]],
    min_events: int = 0,
    exclude_inferred: bool = False,
    batch_summary_hash: str | None = None,
) -> Mapping[str, Any]:
    items = batch_summary.get("items") if isinstance(batch_summary, Mapping) else []
    evaluable: list[dict[str, Any]] = []
    for it in items or []:
        if not (isinstance(it, Mapping) and it.get("status") == "ok"):
            continue
        rec_id = it.get("id")
        rec = records.get(rec_id) if rec_id in records else None
        if not isinstance(rec, Mapping):
            continue
        if exclude_inferred and rec.get("observedInferred"):
            continue
        pred_ppm, obs_ppm, total_events = _extract_pred_obs(rec)
        if total_events < min_events or pred_ppm <= 0:
            continue
        evaluable.append(
            {
                "id": rec_id,
                "predPpm": pred_ppm,
                "obsPpm": obs_ppm,
                "totalEvents": total_events,
                "relPath": it.get("relPath"),
                "kind": it.get("kind"),
            }
        )

    def _score_profile(profile: Mapping[str, Any]) -> dict[str, Any]:
        multiplier = int(profile.get("multiplierPpm") or 1_000_000)
        clamp_min = int(profile.get("clampMinPpm") or 0)
        clamp_max = int(profile.get("clampMaxPpm") or 2_000_000)
        per_items = []
        improvements: list[int] = []
        for ev in evaluable:
            pred = ev["predPpm"]
            obs = ev["obsPpm"]
            after = max(clamp_min, min(clamp_max, pred * multiplier // 1_000_000))
            err_before = abs(pred - obs)
            err_after = abs(after - obs)
            imp = err_before - err_after
            improvements.append(imp)
            per_items.append(
                {
                    "id": ev["id"],
                    "relPath": ev["relPath"],
                    "kind": ev["kind"],
                    "pred": pred,
                    "obs": obs,
                    "after": after,
                    "improvement": imp,
                }
            )
        mean_imp = sum(improvements) / len(improvements) if improvements else 0.0
        median_imp = sorted(improvements)[len(improvements) // 2] / 1_000_000 if improvements else 0.0
        return {
            "profileId": profile.get("profileId"),
            "schema": profile.get("schema"),
            "multiplierPpm": multiplier,
            "meanImprovementPpm": int(round(mean_imp)),
            "medianImprovement": median_imp,
            "items": per_items,
            "count": len(per_items),
        }

    scored = [_score_profile(p) for p in profiles]
    scored.sort(key=lambda p: (-p["meanImprovementPpm"], str(p["profileId"])))
    report = {
        "schema": "helix_prime_multiplex_leaderboard_v1",
        "batchSummaryHash": batch_summary_hash,
        "filters": {"minEvents": min_events, "excludeInferred": exclude_inferred},
        "counts": {"profiles": len(scored), "evaluableItems": len(evaluable)},
        "profiles": scored,
        "ranking": {"metric": "meanImprovementPpm", "tieBreak": "profileId"},
    }
    return report


def prime_multiplex_leaderboard_json_bytes(report: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(report)


__all__ = [
    "build_prime_multiplex_leaderboard",
    "prime_multiplex_leaderboard_json_bytes",
]
