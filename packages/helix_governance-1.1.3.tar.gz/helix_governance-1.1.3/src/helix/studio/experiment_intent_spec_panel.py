from __future__ import annotations

import json
from typing import Any, Mapping

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)

from helix import clock
from helix.studio.experiment_intent_spec import (
    experiment_intent_spec_to_dict,
    intent_spec_missing_required_fields,
)
from helix.studio.session import SessionModel
from helix.studio.ui_tokens import CAUTION, MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font, monospace_font


class ExperimentIntentSpecEditor(QWidget):
    """Editor for the top-level ExperimentIntentSpec (decision record)."""

    def __init__(self, session: SessionModel, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._updating = False
        self._premortem_valid = True
        self._snapshots_valid = True
        self._pending_premortem: list[dict[str, Any]] = []
        self._pending_snapshots: dict[str, Any] = {}

        self.setFont(base_font())
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(SPACING_MEDIUM)

        group = QGroupBox("Experiment intent (decision record)", self)
        group_layout = QVBoxLayout(group)
        group_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        group_layout.setSpacing(SPACING_MEDIUM)

        form = QFormLayout()
        form.setHorizontalSpacing(SPACING_MEDIUM)
        form.setVerticalSpacing(SPACING_SMALL)

        self._intent_id = QLineEdit(self)
        self._intent_id.setPlaceholderText("e.g. INT-001")
        form.addRow("Intent ID", self._intent_id)

        self._decision_question = QPlainTextEdit(self)
        self._decision_question.setMinimumHeight(50)
        self._decision_question.setPlaceholderText(
            "Which gRNA minimizes frameshift risk while preserving on-target efficiency?"
        )
        form.addRow("Decision question", self._decision_question)

        self._hypothesis = QPlainTextEdit(self)
        self._hypothesis.setMinimumHeight(50)
        self._hypothesis.setPlaceholderText(
            "gRNA g2 yields higher intended edit and lower frameshift than gRNA g1 at this locus."
        )
        form.addRow("Hypothesis", self._hypothesis)

        self._perturbation_modality = QLineEdit(self)
        self._perturbation_modality.setPlaceholderText("e.g. CRISPR cut, CRISPRi, base edit, prime edit")
        form.addRow("Perturbation modality", self._perturbation_modality)

        self._perturbation_target = QLineEdit(self)
        self._perturbation_target.setPlaceholderText("e.g. gene/transcript/isoform/target window")
        form.addRow("Perturbation target", self._perturbation_target)

        self._readout = QPlainTextEdit(self)
        self._readout.setMinimumHeight(50)
        self._readout.setPlaceholderText(
            "Amplicon-seq at the on-target locus; quantify frameshift fraction and intended allele fraction."
        )
        form.addRow("Readout", self._readout)

        self._decision_rule = QPlainTextEdit(self)
        self._decision_rule.setMinimumHeight(50)
        self._decision_rule.setPlaceholderText(
            "Decision rule example: GO if frameshift ≤ 10% and intended edit ≥ 25%; otherwise redesign."
        )
        form.addRow("Decision rule", self._decision_rule)

        premortem_label = QLabel("Premortem (JSON array)", self)
        premortem_label.setStyleSheet("font-weight: 600;")
        group_layout.addLayout(form)
        group_layout.addWidget(premortem_label)

        self._premortem = QPlainTextEdit(self)
        self._premortem.setFont(monospace_font())
        self._premortem.setMinimumHeight(90)
        self._premortem.setPlaceholderText(
            "[\n"
            "  {\n"
            "    \"failureMode\": \"wrong isoform\",\n"
            "    \"dataSignature\": \"high edit rate but phenotype unchanged\",\n"
            "    \"mitigation\": \"target CDS exon shared by all isoforms\"\n"
            "  }\n"
            "]"
        )
        group_layout.addWidget(self._premortem)
        self._premortem_warning = QLabel("", self)
        self._premortem_warning.setStyleSheet(f"color: {CAUTION};")
        self._premortem_warning.hide()
        group_layout.addWidget(self._premortem_warning)

        snapshots_label = QLabel("Auto-bound snapshots (JSON, optional)", self)
        snapshots_label.setStyleSheet("font-weight: 600;")
        group_layout.addWidget(snapshots_label)
        self._snapshots = QPlainTextEdit(self)
        self._snapshots.setFont(monospace_font())
        self._snapshots.setMinimumHeight(80)
        self._snapshots.setPlaceholderText("{\n  \"targetLocusResolution\": null,\n  \"guideSet\": null\n}")
        group_layout.addWidget(self._snapshots)
        self._snapshots_warning = QLabel("", self)
        self._snapshots_warning.setStyleSheet(f"color: {CAUTION};")
        self._snapshots_warning.hide()
        group_layout.addWidget(self._snapshots_warning)

        self._required_warning = QLabel("", self)
        self._required_warning.setStyleSheet(f"color: {CAUTION};")
        self._required_warning.hide()
        group_layout.addWidget(self._required_warning)

        root.addWidget(group)

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(250)
        self._debounce.timeout.connect(self._commit)

        self._wire_inputs()

    def _wire_inputs(self) -> None:
        for w in (
            self._intent_id,
            self._decision_question,
            self._hypothesis,
            self._perturbation_modality,
            self._perturbation_target,
            self._readout,
            self._decision_rule,
        ):
            try:
                w.textChanged.connect(self._schedule_commit)  # type: ignore[attr-defined]
            except Exception:
                pass
        self._premortem.textChanged.connect(self._schedule_premortem)
        self._snapshots.textChanged.connect(self._schedule_snapshots)

    def set_intent_spec(self, payload: Mapping[str, Any] | None) -> None:
        self._updating = True
        try:
            spec = experiment_intent_spec_to_dict(payload)
            self._intent_id.setText(str(spec.get("intentId") or ""))
            self._decision_question.setPlainText(str(spec.get("decisionQuestion") or ""))
            self._hypothesis.setPlainText(str(spec.get("hypothesis") or ""))
            perturb = spec.get("perturbation") if isinstance(spec.get("perturbation"), Mapping) else {}
            self._perturbation_modality.setText(str(perturb.get("modality") or ""))
            self._perturbation_target.setText(str(perturb.get("target") or ""))
            readout = spec.get("readout") if isinstance(spec.get("readout"), Mapping) else {}
            self._readout.setPlainText(str(readout.get("measurement") or ""))
            rule = spec.get("decisionRule") if isinstance(spec.get("decisionRule"), Mapping) else {}
            self._decision_rule.setPlainText(str(rule.get("rule") or ""))

            premortem = spec.get("premortem") if isinstance(spec.get("premortem"), list) else []
            self._pending_premortem = [dict(e) for e in premortem if isinstance(e, Mapping)]
            self._premortem_valid = True
            self._premortem.setPlainText(json.dumps(self._pending_premortem, indent=2, sort_keys=True))

            snaps = spec.get("snapshots") if isinstance(spec.get("snapshots"), Mapping) else {}
            self._pending_snapshots = dict(snaps)
            self._snapshots_valid = True
            self._snapshots.setPlainText(json.dumps(self._pending_snapshots, indent=2, sort_keys=True))
        finally:
            self._updating = False
        self._refresh_warnings()

    def _schedule_commit(self) -> None:
        if self._updating:
            return
        self._debounce.start()

    def _schedule_premortem(self) -> None:
        if self._updating:
            return
        if self._parse_premortem():
            self._debounce.start()

    def _schedule_snapshots(self) -> None:
        if self._updating:
            return
        if self._parse_snapshots():
            self._debounce.start()

    def _parse_premortem(self) -> bool:
        text = self._premortem.toPlainText().strip()
        if not text:
            self._pending_premortem = []
            self._premortem_warning.hide()
            self._premortem_valid = True
            return True
        try:
            data = json.loads(text)
        except Exception:
            self._premortem_warning.setText("Premortem JSON is invalid; changes not applied.")
            self._premortem_warning.show()
            self._premortem_valid = False
            return False
        if not isinstance(data, list):
            self._premortem_warning.setText("Premortem must be a JSON array.")
            self._premortem_warning.show()
            self._premortem_valid = False
            return False
        cleaned: list[dict[str, Any]] = []
        for entry in data:
            if isinstance(entry, Mapping):
                cleaned.append(dict(entry))
        self._pending_premortem = cleaned
        self._premortem_warning.hide()
        self._premortem_valid = True
        return True

    def _parse_snapshots(self) -> bool:
        text = self._snapshots.toPlainText().strip()
        if not text:
            self._pending_snapshots = {}
            self._snapshots_warning.hide()
            self._snapshots_valid = True
            return True
        try:
            data = json.loads(text)
        except Exception:
            self._snapshots_warning.setText("Snapshots JSON is invalid; changes not applied.")
            self._snapshots_warning.show()
            self._snapshots_valid = False
            return False
        if not isinstance(data, dict):
            self._snapshots_warning.setText("Snapshots must be a JSON object.")
            self._snapshots_warning.show()
            self._snapshots_valid = False
            return False
        self._pending_snapshots = dict(data)
        self._snapshots_warning.hide()
        self._snapshots_valid = True
        return True

    def _refresh_warnings(self) -> None:
        if self._updating:
            return
        if not (self._premortem_valid and self._snapshots_valid):
            return
        payload = self._build_payload()
        missing = intent_spec_missing_required_fields(payload)
        if missing:
            self._required_warning.setText("Intent incomplete (blocks export): " + ", ".join(missing))
            self._required_warning.show()
        else:
            self._required_warning.hide()

    def _build_payload(self) -> dict[str, Any]:
        now_ts = clock.utc_now_iso()
        payload: dict[str, Any] = {
            "schema": "helix_experiment_intent_spec_v1",
            "intentId": self._intent_id.text().strip() or "unset",
            "createdAt": now_ts,
            "decisionQuestion": self._decision_question.toPlainText().strip(),
            "hypothesis": self._hypothesis.toPlainText().strip(),
            "perturbation": {
                "modality": self._perturbation_modality.text().strip(),
                "target": self._perturbation_target.text().strip(),
                "notes": "",
            },
            "readout": {
                "measurement": self._readout.toPlainText().strip(),
                "notes": "",
            },
            "decisionRule": {
                "rule": self._decision_rule.toPlainText().strip(),
                "notes": "",
                "threshold": None,
                "pattern": None,
            },
            "premortem": list(self._pending_premortem),
            "snapshots": dict(self._pending_snapshots),
        }
        return payload

    def _commit(self) -> None:
        if self._updating:
            return
        if not (self._premortem_valid and self._snapshots_valid):
            return
        payload = self._build_payload()
        try:
            self._session.set_experiment_intent_spec(payload)
        except Exception:
            return
        self._refresh_warnings()


__all__ = ["ExperimentIntentSpecEditor"]
