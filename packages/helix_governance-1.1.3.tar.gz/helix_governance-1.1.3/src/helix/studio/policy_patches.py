from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping


def apply_policy_patch(policy: Mapping[str, Any], patch: Mapping[str, Any]) -> dict[str, Any]:
    """
    Deterministically merge a patch into a policy payload.

    Intended for Studio "Quick Fix" actions:
    - Recursively merges dicts
    - For lists, appends only missing items (preserves existing order)
    - Does not overwrite existing non-empty scalars
    """

    out: dict[str, Any] = deepcopy(dict(policy))
    _merge_into(out, patch)
    return out


def _is_empty_value(value: Any) -> bool:
    return value is None or value == "" or value == {} or value == []


def _merge_into(dst: dict[str, Any], patch: Mapping[str, Any]) -> None:
    for key, patch_value in patch.items():
        if key not in dst or _is_empty_value(dst.get(key)):
            dst[key] = deepcopy(patch_value)
            continue

        cur = dst.get(key)
        if isinstance(cur, dict) and isinstance(patch_value, Mapping):
            _merge_into(cur, patch_value)
            continue

        if isinstance(cur, list) and isinstance(patch_value, list):
            merged = list(cur)
            for item in patch_value:
                if item not in merged:
                    merged.append(item)
            dst[key] = merged
            continue

        # Preserve existing non-empty scalar or mismatched type.

