from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Sequence

from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.results_io import results_record_sha256

BASE_POSITION_CAL_PROFILE_SCHEMA_ID = "helix_base_position_calibration_profile_v1"
BASE_POSITION_CAL_PREVIEW_SCHEMA_ID = "helix_base_position_calibration_preview_v1"
BASE_POSITION_CAL_EVAL_SCHEMA_ID = "helix_base_position_calibration_eval_v1"
BASE_POSITION_CAL_BATCH_EVAL_SCHEMA_ID = "helix_base_position_calibration_batch_eval_v1"
BASE_POSITION_CAL_PROFILES_CAP = 20
BASE_POSITION_CAL_PREVIEWS_CAP = 20
BASE_POSITION_CAL_BATCH_EVAL_CAP = 10

DEFAULT_SAMPLE_POLICY = {
    "defaultN": 50,
    "assayOverrides": {"AmpliconSeq": 200, "Sanger": 20},
    "caps": {"maxN": 1000},
}


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def base_position_calibration_profile_json_bytes(profile: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(profile))


def base_position_calibration_profile_sha256(profile: Mapping[str, Any]) -> str:
    return hashlib.sha256(base_position_calibration_profile_json_bytes(profile)).hexdigest()


def base_position_calibration_preview_json_bytes(preview: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(preview))


def base_position_calibration_preview_sha256(preview: Mapping[str, Any]) -> str:
    return hashlib.sha256(base_position_calibration_preview_json_bytes(preview)).hexdigest()


def base_position_calibration_eval_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(payload))


def base_position_calibration_eval_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(base_position_calibration_eval_json_bytes(payload)).hexdigest()


def base_position_calibration_batch_eval_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(payload))


def base_position_calibration_batch_eval_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(base_position_calibration_batch_eval_json_bytes(payload)).hexdigest()


def format_base_position_batch_eval_summary(payload: Mapping[str, Any]) -> str:
    """Return a deterministic one-line summary for batch eval outputs."""
    counts = payload.get("counts", {}) if isinstance(payload, Mapping) else {}
    overall = payload.get("overall", {}) if isinstance(payload, Mapping) else {}
    total = counts.get("total", 0) or 0
    ok = counts.get("ok", 0) or 0
    skip = counts.get("skip", 0) or 0
    mean_before = overall.get("meanL1Before", 0) or 0.0
    mean_after = overall.get("meanL1After", 0) or 0.0
    improvement = overall.get("meanImprovement", 0) or 0.0
    return (
        f"Batch eval: total={int(total)}, ok={int(ok)}, skip={int(skip)}, "
        f"mean L1 {mean_before:.6f} -> {mean_after:.6f}, improvement {improvement:.6f}"
    )


def base_position_batch_eval_markdown(payload: Mapping[str, Any]) -> str:
    """Deterministic markdown summary for batch eval."""
    summary_line = format_base_position_batch_eval_summary(payload)
    lines = [summary_line, ""]

    items = payload.get("items", []) if isinstance(payload, Mapping) else []
    if not isinstance(items, list):
        items = []

    # Top regressions section
    regressions = [i for i in items if isinstance(i, Mapping) and float(i.get("improvement") or 0) < 0]
    regressions.sort(key=lambda e: (float(e.get("improvement") or 0), str(e.get("relPath") or "")))
    if regressions:
        lines.append("### Top regressions")
        lines.append("")
        lines.append("|Rel path|Kind|Improvement|Reason|")
        lines.append("|---|---|---|---|")
        for entry in regressions[:5]:
            rel_path = str(entry.get("relPath") or "—")
            kind = str(entry.get("kind") or "—")
            if entry.get("tableKind"):
                kind = f"{kind} ({entry.get('tableKind')})"
            improvement = f"{float(entry.get('improvement') or 0):+.6f}"
            reason = str(entry.get("reason") or "—") if entry.get("status") == "skip" else "regressed"
            lines.append(f"|{rel_path}|{kind}|{improvement}|{reason}|")
        lines.append("")

    # Skipped section
    skipped = [i for i in items if isinstance(i, Mapping) and str(i.get("status") or "").lower() == "skip"]
    if skipped:
        lines.append("### Skipped")
        lines.append("")
        lines.append("|Rel path|Kind|Reason|")
        lines.append("|---|---|---|")
        for entry in sorted(skipped, key=lambda e: str(e.get("relPath") or "")):
            rel_path = str(entry.get("relPath") or "—")
            kind = str(entry.get("kind") or "—")
            if entry.get("tableKind"):
                kind = f"{kind} ({entry.get('tableKind')})"
            reason = str(entry.get("reason") or "—")
            lines.append(f"|{rel_path}|{kind}|{reason}|")
        lines.append("")

    lines.append("### Full table")
    lines.append("")
    lines.append("|Status|Rel path|Kind|Events|L1 before|L1 after|Δ|Flags|")
    lines.append("|---|---|---|---|---|---|---|---|")
    items = payload.get("items", []) if isinstance(payload, Mapping) else []
    if not isinstance(items, list):
        items = []
    for entry in items:
        if not isinstance(entry, Mapping):
            continue
        status = str(entry.get("status") or "—").upper()
        rel_path = str(entry.get("relPath") or "—")
        kind = str(entry.get("kind") or "—")
        if entry.get("tableKind"):
            kind = f"{kind} ({entry.get('tableKind')})"
        events = entry.get("totalEvents")
        events_text = "—" if events is None else str(events)
        flags = []
        if entry.get("lowEvidence"):
            flags.append("Low")
        if entry.get("inferred"):
            flags.append("Inferred")
        if status == "SKIP":
            flags_text = str(entry.get("reason") or "skip")
            l1_before = l1_after = delta = "—"
        else:
            flags_text = ",".join(flags) if flags else "—"
            l1_before = f"{float(entry.get('l1Before') or 0):.6f}"
            l1_after = f"{float(entry.get('l1After') or 0):.6f}"
            delta = f"{float(entry.get('improvement') or 0):+.6f}"
        lines.append(
            f"|{status}|{rel_path}|{kind}|{events_text}|{l1_before}|{l1_after}|{delta}|{flags_text}|"
        )
    return "\n".join(lines)


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _round_prob(value: float, digits: int = 6) -> float:
    return round(float(value), digits)


def _normalize_text(value: Any) -> str:
    return str(value or "").strip()


def _effective_sample_size(record: Mapping[str, Any], policy: Mapping[str, Any]) -> int:
    caps = policy.get("caps") if isinstance(policy.get("caps"), Mapping) else {}
    max_n = int(_safe_float(caps.get("maxN"), 1000)) if isinstance(caps, Mapping) else 1000
    if max_n <= 0:
        max_n = 1000

    assay_meta = record.get("assayMetadata") if isinstance(record.get("assayMetadata"), Mapping) else {}
    read_depth = assay_meta.get("readDepth") if isinstance(assay_meta, Mapping) else None
    if read_depth is not None:
        n = int(round(_safe_float(read_depth, 0.0)))
        n = max(1, min(n, max_n))
        return n

    assay_type = _normalize_text(assay_meta.get("assayType")) if isinstance(assay_meta, Mapping) else ""
    overrides = policy.get("assayOverrides") if isinstance(policy.get("assayOverrides"), Mapping) else {}
    if assay_type in overrides:
        n = int(round(_safe_float(overrides.get(assay_type), 0.0)))
    else:
        n = int(round(_safe_float(policy.get("defaultN"), 50.0)))
    if n <= 0:
        n = 1
    return max(1, min(n, max_n))


def _extract_predicted_positions(report_payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    base_probs = report_payload.get("basePositionProbs") if isinstance(report_payload.get("basePositionProbs"), Mapping) else {}
    positions = base_probs.get("positions") if isinstance(base_probs.get("positions"), list) else []
    entries = [dict(p) for p in positions if isinstance(p, Mapping)]
    entries.sort(key=lambda p: int(_safe_float(p.get("pos"), 0.0)))
    return entries


def _extract_observed_positions(record: Mapping[str, Any]) -> dict[int, float]:
    primary = record.get("primaryTarget") if isinstance(record.get("primaryTarget"), Mapping) else {}
    observed_positions = primary.get("observedPositionProbs") if isinstance(primary.get("observedPositionProbs"), list) else None
    positions: dict[int, float] = {}

    if isinstance(observed_positions, list):
        for entry in observed_positions:
            if not isinstance(entry, Mapping):
                continue
            pos = entry.get("pos", entry.get("position"))
            if pos is None:
                continue
            try:
                pos_int = int(pos)
            except Exception:
                continue
            prob = entry.get("prob", entry.get("probability", entry.get("frequency")))
            if prob is None:
                continue
            prob_val = _safe_float(prob, 0.0)
            if prob_val <= 0.0:
                continue
            positions[pos_int] = prob_val
        return positions

    spectrum = primary.get("observedAlleleSpectrum") if isinstance(primary.get("observedAlleleSpectrum"), list) else []
    for entry in spectrum:
        if not isinstance(entry, Mapping):
            continue
        pos = entry.get("pos", entry.get("position"))
        if pos is None:
            delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
            pos = delta.get("pos")
        if pos is None:
            continue
        try:
            pos_int = int(pos)
        except Exception:
            continue
        prob = entry.get("prob", entry.get("probability", entry.get("frequency")))
        if prob is None:
            continue
        prob_val = _safe_float(prob, 0.0)
        if prob_val <= 0.0:
            continue
        positions[pos_int] = prob_val
    return positions


def build_base_position_calibration_profile_and_preview(
    results_records: Sequence[Mapping[str, Any]] | None,
    outcome_report_payload: Mapping[str, Any] | None,
    experiment_spec: Mapping[str, Any] | None = None,
    *,
    sample_policy: Mapping[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    policy = dict(sample_policy or DEFAULT_SAMPLE_POLICY)
    report_payload = dict(outcome_report_payload or {})

    predicted_entries = _extract_predicted_positions(report_payload)
    predicted_map = {
        int(_safe_float(entry.get("pos"), 0.0)): _safe_float(entry.get("prob"), 0.0)
        for entry in predicted_entries
    }
    role_map = {
        int(_safe_float(entry.get("pos"), 0.0)): str(entry.get("role") or "") for entry in predicted_entries
    }
    predicted_total = sum(predicted_map.values())
    if predicted_entries:
        window_start = min(predicted_map.keys())
        window_end = max(predicted_map.keys())
    else:
        window_start = 0
        window_end = 0

    base_editor = report_payload.get("baseEditor") if isinstance(report_payload.get("baseEditor"), Mapping) else {}
    editor_type = _normalize_text(base_editor.get("editorType"))
    if not editor_type and experiment_spec is not None:
        spec = experiment_spec_to_dict(experiment_spec)
        assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
        editor_type = _normalize_text(assumptions.get("editorType") or assumptions.get("baseEditor"))

    included_ids: list[str] = []
    skipped_results: list[dict[str, str]] = []
    totals: dict[int, dict[str, int]] = {}
    skipped_positions: dict[int, str] = {}
    total_effective_n = 0

    ordered_records: list[Mapping[str, Any]] = []
    if results_records:
        ordered_records = sorted(
            [r for r in results_records if isinstance(r, Mapping)],
            key=lambda r: str(r.get("resultsId") or ""),
        )

    for record in ordered_records:
        results_id = _normalize_text(record.get("resultsId"))
        if not results_id:
            skipped_results.append({"resultsId": "", "reason": "missing resultsId"})
            continue
        modality = _normalize_text(record.get("modality")).lower()
        if modality and modality != "base":
            skipped_results.append({"resultsId": results_id, "reason": "modality mismatch"})
            continue
        observed = _extract_observed_positions(record)
        if not observed:
            skipped_results.append({"resultsId": results_id, "reason": "missing observed positions"})
            continue
        n_eff = _effective_sample_size(record, policy)
        total_effective_n += n_eff
        included_ids.append(results_id)
        for pos, prob in observed.items():
            if pos not in predicted_map:
                skipped_positions.setdefault(pos, "position not in predicted window")
                continue
            k = int(round(max(0.0, min(1.0, prob)) * n_eff))
            entry = totals.setdefault(pos, {"k": 0, "n": 0})
            entry["k"] += k
            entry["n"] += n_eff

    observed_map: dict[int, float | None] = {}
    for pos in predicted_map:
        entry = totals.get(pos)
        if entry and entry["n"] > 0:
            observed_map[pos] = entry["k"] / entry["n"]
        else:
            observed_map[pos] = None
            skipped_positions.setdefault(pos, "missing observations")

    scale_map: dict[int, float] = {}
    for pos, pred in predicted_map.items():
        obs = observed_map.get(pos)
        if obs is None:
            continue
        if pred <= 0.0:
            skipped_positions.setdefault(pos, "predicted probability is 0")
            continue
        scale = obs / pred
        scale = max(0.25, min(4.0, scale))
        scale_map[pos] = round(scale, 3)

    scaled_total = 0.0
    scaled_map: dict[int, float] = {}
    for pos, pred in predicted_map.items():
        scale = scale_map.get(pos, 1.0)
        scaled = pred * scale
        scaled_map[pos] = scaled
        scaled_total += scaled
    factor = (predicted_total / scaled_total) if scaled_total > 0 else 1.0

    calibrated_map: dict[int, float] = {}
    for pos, scaled in scaled_map.items():
        calibrated_map[pos] = _round_prob(scaled * factor, digits=6)

    residual = _round_prob(predicted_total - sum(calibrated_map.values()), digits=6)
    if abs(residual) > 1e-6 and calibrated_map:
        adjust_pos = sorted(calibrated_map.items(), key=lambda item: (-item[1], item[0]))[0][0]
        calibrated_map[adjust_pos] = _round_prob(calibrated_map[adjust_pos] + residual, digits=6)

    positions_preview: list[dict[str, Any]] = []
    for pos in sorted(predicted_map.keys()):
        positions_preview.append(
            {
                "pos": pos,
                "role": role_map.get(pos, ""),
                "predicted": _round_prob(predicted_map.get(pos, 0.0), digits=6),
                "observed": _round_prob(observed_map[pos], digits=6) if observed_map.get(pos) is not None else None,
                "calibrated": _round_prob(calibrated_map.get(pos, 0.0), digits=6),
                "scale": _round_prob(scale_map.get(pos, 1.0), digits=3),
                "delta": _round_prob(calibrated_map.get(pos, 0.0) - predicted_map.get(pos, 0.0), digits=6),
            }
        )

    scope: dict[str, Any] = {}
    if editor_type:
        scope["editorType"] = editor_type
    if included_ids:
        for key, field in (("cellLine", "cellLine"), ("delivery", "delivery")):
            values = {
                _normalize_text(rec.get("conditions", {}).get(field))
                for rec in ordered_records
                if isinstance(rec.get("conditions"), Mapping) and _normalize_text(rec.get("resultsId")) in included_ids
            }
            values.discard("")
            if len(values) == 1:
                scope[key] = values.pop()

    notes: list[str] = []
    notes.append(f"Derived from {len(included_ids)} result record(s).")
    if scale_map:
        notes.append("Scaled relative to predicted basePositionProbs.")

    low_evidence = total_effective_n < 50
    evidence_note = ""
    if low_evidence:
        evidence_note = f"Low evidence: effective N={total_effective_n}."
        notes.append(evidence_note)

    profile_payload = {
        "schema": BASE_POSITION_CAL_PROFILE_SCHEMA_ID,
        "profileId": "",
        "scope": scope,
        "window": {"start": window_start, "end": window_end},
        "derivedFrom": {"resultsRecordIds": list(included_ids)},
        "positionScale": {str(pos): scale for pos, scale in scale_map.items()},
        "notes": notes,
    }

    profile_id = hashlib.sha256(_canonical_json_bytes(dict(profile_payload))).hexdigest()
    profile_payload["profileId"] = profile_id

    preview_payload = {
        "schema": BASE_POSITION_CAL_PREVIEW_SCHEMA_ID,
        "profileId": profile_id,
        "editorType": editor_type,
        "window": {"start": window_start, "end": window_end},
        "includedResults": list(included_ids),
        "skippedResults": skipped_results,
        "positions": positions_preview,
        "skippedPositions": [
            {"pos": pos, "reason": reason} for pos, reason in sorted(skipped_positions.items())
        ],
        "lowEvidence": low_evidence,
        "lowEvidenceNote": evidence_note,
        "notes": notes,
        "evidenceN": int(total_effective_n),
    }

    return profile_payload, preview_payload


def build_base_position_calibration_eval(
    preview_payload: Mapping[str, Any],
    *,
    results_records: Sequence[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    positions = preview_payload.get("positions") if isinstance(preview_payload.get("positions"), list) else []
    observed_positions = [p for p in positions if isinstance(p, Mapping) and p.get("observed") is not None]

    def _ppm(value: Any) -> int:
        return int(round(_safe_float(value, 0.0) * 1_000_000))

    pred_ppm = []
    cal_ppm = []
    obs_ppm = []
    pos_entries: list[tuple[int, int, int, int]] = []
    for entry in observed_positions:
        try:
            pos = int(entry.get("pos"))
        except Exception:
            continue
        pred = _ppm(entry.get("predicted"))
        cal = _ppm(entry.get("calibrated"))
        obs = _ppm(entry.get("observed"))
        pred_ppm.append(pred)
        cal_ppm.append(cal)
        obs_ppm.append(obs)
        pos_entries.append((pos, pred, cal, obs))

    l1_before_ppm = sum(abs(p - o) for p, o in zip(pred_ppm, obs_ppm))
    l1_after_ppm = sum(abs(c - o) for c, o in zip(cal_ppm, obs_ppm))

    def _ppm_to_float(value: int) -> float:
        return round(value / 1_000_000.0, 6)

    deltas = []
    for pos, pred, cal, _obs in pos_entries:
        delta_ppm = abs(cal - pred)
        deltas.append((delta_ppm, pos, pred, cal))
    deltas.sort(key=lambda item: (-item[0], item[1]))
    top_deltas = [
        {
            "pos": pos,
            "predicted": _ppm_to_float(pred),
            "calibrated": _ppm_to_float(cal),
            "delta": _ppm_to_float(delta_ppm),
        }
        for delta_ppm, pos, pred, cal in deltas[:5]
    ]

    results_ids = preview_payload.get("includedResults") if isinstance(preview_payload.get("includedResults"), list) else []
    results_ids = [str(r) for r in results_ids if str(r)]
    fingerprint = ""
    if results_records:
        ordered_records = sorted(
            [r for r in results_records if isinstance(r, Mapping)],
            key=lambda r: str(r.get("resultsId") or ""),
        )
        included = {rid for rid in results_ids}
        blob = ""
        for record in ordered_records:
            rid = str(record.get("resultsId") or "")
            if rid and rid in included:
                blob += rid + "\n" + results_record_sha256(record) + "\n"
        if blob:
            fingerprint = hashlib.sha256(blob.encode("utf-8")).hexdigest()

    editable_count = len(positions)
    low_evidence = bool(preview_payload.get("lowEvidence"))
    evidence_n = int(_safe_float(preview_payload.get("evidenceN"), 0.0))

    warning_note = ""
    if l1_after_ppm > l1_before_ppm:
        warning_note = "Calibration increased L1 distance."

    return {
        "schema": BASE_POSITION_CAL_EVAL_SCHEMA_ID,
        "profileId": str(preview_payload.get("profileId") or ""),
        "resultsRecordIds": results_ids,
        "resultsFingerprintSha256": fingerprint,
        "l1Before": _ppm_to_float(l1_before_ppm),
        "l1After": _ppm_to_float(l1_after_ppm),
        "topDeltas": top_deltas,
        "evidenceN": evidence_n,
        "editableCount": editable_count,
        "lowEvidence": low_evidence,
        "warningNote": warning_note,
    }


def build_base_position_calibration_batch_eval(
    *,
    profile: Mapping[str, Any],
    batch_items: Sequence[Mapping[str, Any]],
    results_records: Sequence[Mapping[str, Any]] | None = None,
    window_start: int | None = None,
    window_end: int | None = None,
) -> dict[str, Any]:
    scale_raw = profile.get("positionScale") if isinstance(profile.get("positionScale"), Mapping) else {}
    scale_map: dict[int, float] = {}
    for key, value in scale_raw.items():
        try:
            pos = int(key)
        except Exception:
            continue
        scale_map[pos] = _safe_float(value, 1.0)

    def _ppm_distribution_int(counts: list[int]) -> list[int]:
        total = sum(counts)
        if total <= 0:
            return [0 for _ in counts]
        raw = [c * 1_000_000 / total for c in counts]
        floors = [int(val) for val in raw]
        remainder = 1_000_000 - sum(floors)
        fracs = [(raw[i] - floors[i], i) for i in range(len(raw))]
        fracs.sort(key=lambda item: (-item[0], item[1]))
        for _, idx in fracs[: max(0, remainder)]:
            floors[idx] += 1
        return floors

    items_out: list[dict[str, Any]] = []
    l1_before_total = 0.0
    l1_after_total = 0.0
    ok_count = 0
    for item in sorted(batch_items, key=lambda it: str(it.get("relPath") or "")):
        record = item.get("record") if isinstance(item, Mapping) else None
        rel_path = str(item.get("relPath") or "")
        kind = str(item.get("kind") or "")
        table_kind = item.get("tableKind") if isinstance(item, Mapping) else None
        source_hash = str(item.get("sourceHash") or "")
        primary = record.get("primaryTarget") if isinstance(record, Mapping) else {}
        observed_positions = primary.get("observedPositionProbs") if isinstance(primary, Mapping) else []
        if not isinstance(observed_positions, list) or not observed_positions:
            items_out.append(
                {
                    "relPath": rel_path,
                    "kind": kind,
                    "tableKind": table_kind,
                    "sourceHash": source_hash,
                    "status": "skip",
                    "reason": "missing observedPositionProbs",
                }
            )
            continue

        # window filter
        obs_ppm_map: dict[int, int] = {}
        for entry in observed_positions:
            if not isinstance(entry, Mapping):
                continue
            try:
                pos = int(entry.get("pos"))
                prob = _safe_float(entry.get("prob"), 0.0)
            except Exception:
                continue
            if window_start is not None and pos < window_start:
                continue
            if window_end is not None and pos > window_end:
                continue
            obs_ppm_map[pos] = int(round(prob * 1_000_000))
        if not obs_ppm_map:
            items_out.append(
                {
                    "relPath": rel_path,
                    "kind": kind,
                    "tableKind": table_kind,
                    "sourceHash": source_hash,
                    "status": "skip",
                    "reason": "outside window",
                }
            )
            continue

        positions = sorted(obs_ppm_map)
        n = len(positions)
        base_ppm = _ppm_distribution_int([1 for _ in positions])
        pred_ppm_map = {pos: base_ppm[i] for i, pos in enumerate(positions)}

        scaled_counts = []
        for pos in positions:
            scale = scale_map.get(pos, 1.0)
            scaled_counts.append(int(round(pred_ppm_map[pos] * scale)))
        calibrated_ppm = _ppm_distribution_int(scaled_counts)
        cal_ppm_map = {pos: calibrated_ppm[i] for i, pos in enumerate(positions)}

        l1_before_ppm = sum(abs(pred_ppm_map[pos] - obs_ppm_map.get(pos, 0)) for pos in positions)
        l1_after_ppm = sum(abs(cal_ppm_map[pos] - obs_ppm_map.get(pos, 0)) for pos in positions)
        l1_before = round(l1_before_ppm / 1_000_000.0, 6)
        l1_after = round(l1_after_ppm / 1_000_000.0, 6)
        improvement = round(l1_before - l1_after, 6)
        delta_entries = []
        for pos in positions:
            delta_entries.append((abs(cal_ppm_map[pos] - pred_ppm_map[pos]), pos))
        delta_entries.sort(key=lambda item: (-item[0], item[1]))
        top_moves = [{"pos": pos, "deltaPpm": diff} for diff, pos in delta_entries[:5]]

        low_flag = "No conversion events" in " ".join(item.get("notes", [])) if isinstance(item, Mapping) else False

        items_out.append(
            {
                "relPath": rel_path,
                "kind": kind,
                "tableKind": table_kind,
                "sourceHash": source_hash,
                "status": "ok",
                "totalEvents": int(primary.get("observedTotalEvents") or 0) if isinstance(primary, Mapping) else None,
                "lowEvidence": low_flag,
                "l1Before": l1_before,
                "l1After": l1_after,
                "improvement": improvement,
                "topMovedPositions": top_moves,
            }
        )
        l1_before_total += l1_before
        l1_after_total += l1_after
        ok_count += 1

    overall = {
        "meanL1Before": round(l1_before_total / ok_count, 6) if ok_count else 0.0,
        "meanL1After": round(l1_after_total / ok_count, 6) if ok_count else 0.0,
        "meanImprovement": round((l1_before_total - l1_after_total) / ok_count, 6) if ok_count else 0.0,
    }

    payload = {
        "schema": BASE_POSITION_CAL_BATCH_EVAL_SCHEMA_ID,
        "profileId": str(profile.get("profileId") or ""),
        "counts": {"total": len(items_out), "ok": ok_count, "skip": len([i for i in items_out if i.get("status") == "skip"])},
        "items": items_out,
        "overall": overall,
    }
    return payload


def attach_base_position_calibration_profile(
    session: Any,
    profile: Mapping[str, Any],
    preview: Mapping[str, Any] | None = None,
    *,
    cap: int = BASE_POSITION_CAL_PROFILES_CAP,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    profiles = list(getattr(session.state, "base_position_calibration_profiles", []) or []) if session is not None else []
    previews = list(getattr(session.state, "base_position_calibration_previews", []) or []) if session is not None else []

    profile_id = str(profile.get("profileId") or "")
    profiles = [p for p in profiles if str(p.get("profileId") or "") != profile_id]
    profiles.append(dict(profile))
    if cap > 0 and len(profiles) > cap:
        profiles = profiles[-cap:]

    if preview is not None:
        previews = [p for p in previews if str(p.get("profileId") or "") != profile_id]
        previews.append(dict(preview))
        if cap > 0 and len(previews) > cap:
            previews = previews[-cap:]

    if session is not None:
        session.update(
            base_position_calibration_profiles=profiles,
            base_position_calibration_previews=previews,
        )

    return profiles, previews


def apply_base_position_calibration_to_report(
    report_payload: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    payload = json.loads(json.dumps(report_payload))
    base_probs = payload.get("basePositionProbs") if isinstance(payload.get("basePositionProbs"), Mapping) else None
    positions = base_probs.get("positions") if isinstance(base_probs, Mapping) and isinstance(base_probs.get("positions"), list) else None
    if not positions:
        return payload

    scale_map_raw = profile.get("positionScale") if isinstance(profile.get("positionScale"), Mapping) else {}
    scale_map: dict[int, float] = {}
    for key, value in scale_map_raw.items():
        try:
            pos = int(key)
        except Exception:
            continue
        scale_map[pos] = _safe_float(value, 1.0)

    pos_entries: list[dict[str, Any]] = []
    total_pred = 0.0
    for entry in positions:
        if not isinstance(entry, Mapping):
            continue
        pos = entry.get("pos")
        try:
            pos_int = int(pos)
        except Exception:
            continue
        prob = _safe_float(entry.get("prob"), 0.0)
        total_pred += prob
        pos_entries.append({"pos": pos_int, "prob": prob, "role": str(entry.get("role") or ""), "base": entry.get("base")})

    if not pos_entries or total_pred <= 0.0:
        return payload

    scaled_total = 0.0
    scaled: list[dict[str, Any]] = []
    for entry in pos_entries:
        scale = scale_map.get(entry["pos"], 1.0)
        scaled_prob = entry["prob"] * scale
        scaled_total += scaled_prob
        scaled.append({**entry, "scaled": scaled_prob})

    factor = total_pred / scaled_total if scaled_total > 0 else 1.0
    calibrated = []
    for entry in scaled:
        calibrated.append({**entry, "prob": _round_prob(entry["scaled"] * factor, digits=6)})

    residual = _round_prob(total_pred - sum(e["prob"] for e in calibrated), digits=6)
    if abs(residual) > 1e-6:
        calibrated.sort(key=lambda e: (-e["prob"], e["pos"]))
        calibrated[0]["prob"] = _round_prob(calibrated[0]["prob"] + residual, digits=6)
        calibrated.sort(key=lambda e: e["pos"])

    payload["basePositionProbs"] = {"positions": [
        {"pos": e["pos"], "base": e.get("base"), "prob": e["prob"], "role": e.get("role")} for e in calibrated
    ]}

    allele_spectrum = payload.get("alleleSpectrum") if isinstance(payload.get("alleleSpectrum"), list) else []
    updated_alleles: list[dict[str, Any]] = []
    pos_to_prob = {e["pos"]: e["prob"] for e in calibrated}
    desired_sum = 0.0
    bystander_sum = 0.0
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = str(delta.get("type") or "").lower().strip()
        new_entry = dict(entry)
        if kind == "base_substitution":
            try:
                pos = int(delta.get("pos"))
            except Exception:
                updated_alleles.append(new_entry)
                continue
            if pos in pos_to_prob:
                new_entry["frequency"] = _round_prob(pos_to_prob[pos], digits=8)
            role = str(delta.get("role") or delta.get("label") or "").lower()
            if "desired" in role:
                desired_sum += _safe_float(new_entry.get("frequency"), 0.0)
            else:
                bystander_sum += _safe_float(new_entry.get("frequency"), 0.0)
        updated_alleles.append(new_entry)

    payload["alleleSpectrum"] = updated_alleles

    base_outcomes = payload.get("baseOutcomes") if isinstance(payload.get("baseOutcomes"), list) else []
    updated_outcomes: list[dict[str, Any]] = []
    off_target_prob = 0.0
    for entry in base_outcomes:
        if not isinstance(entry, Mapping):
            continue
        category = str(entry.get("category") or "")
        out = dict(entry)
        if category == "desired_edit":
            out["probability"] = _round_prob(desired_sum, digits=6)
        elif category == "bystander_edit":
            out["probability"] = _round_prob(bystander_sum, digits=6)
        elif category == "off_target_deamination":
            off_target_prob = _safe_float(out.get("probability"), 0.0)
        updated_outcomes.append(out)
    if updated_outcomes:
        failure_prob = _round_prob(max(0.0, 1.0 - (desired_sum + bystander_sum + off_target_prob)), digits=6)
        for entry in updated_outcomes:
            if str(entry.get("category") or "") == "failure":
                entry["probability"] = failure_prob
        payload["baseOutcomes"] = updated_outcomes

    total_freq = sum(_safe_float(e.get("frequency"), 0.0) for e in updated_alleles)
    remainder = _round_prob(1.0 - total_freq, digits=8)
    if abs(remainder) > 1e-6 and updated_alleles:
        adjust_idx = len(updated_alleles) - 1
        delta = updated_alleles[adjust_idx].get("sequenceDelta") if isinstance(updated_alleles[adjust_idx].get("sequenceDelta"), Mapping) else {}
        if str(delta.get("type") or "") != "base_failure" and len(updated_alleles) > 1:
            adjust_idx -= 1
        updated_alleles[adjust_idx]["frequency"] = _round_prob(
            _safe_float(updated_alleles[adjust_idx].get("frequency"), 0.0) + remainder,
            digits=8,
        )
        payload["alleleSpectrum"] = updated_alleles

    payload["basePositionCalibrationApplied"] = True
    payload["basePositionCalibrationProfileId"] = str(profile.get("profileId") or "")
    return payload


def check_base_position_calibration_compatibility(
    report_payload: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    reasons: list[str] = []
    status = "compatible"

    if str(profile.get("schema") or "") not in {BASE_POSITION_CAL_PROFILE_SCHEMA_ID, ""}:
        return {"status": "incompatible", "reasons": ["schema mismatch"]}

    base_editor = report_payload.get("baseEditor") if isinstance(report_payload.get("baseEditor"), Mapping) else {}
    editor_type = _normalize_text(base_editor.get("editorType"))
    scope = profile.get("scope") if isinstance(profile.get("scope"), Mapping) else {}
    profile_editor = _normalize_text(scope.get("editorType"))

    if editor_type and profile_editor and editor_type != profile_editor:
        status = "incompatible"
        reasons.append("editorType mismatch")
    elif not editor_type or not profile_editor:
        status = "unknown"
        reasons.append("missing editorType")

    predicted_positions = _extract_predicted_positions(report_payload)
    if predicted_positions:
        positions = [int(_safe_float(p.get("pos"), 0.0)) for p in predicted_positions]
        window_start = min(positions)
        window_end = max(positions)
    else:
        window_start = None
        window_end = None

    window = profile.get("window") if isinstance(profile.get("window"), Mapping) else {}
    prof_start = window.get("start")
    prof_end = window.get("end")
    if window_start is not None and window_end is not None and prof_start is not None and prof_end is not None:
        try:
            prof_start_int = int(prof_start)
            prof_end_int = int(prof_end)
        except Exception:
            prof_start_int = None
            prof_end_int = None
        if prof_start_int is not None and prof_end_int is not None:
            if window_start != prof_start_int or window_end != prof_end_int:
                status = "incompatible"
                reasons.append("window mismatch")
    else:
        if status == "compatible":
            status = "unknown"
        reasons.append("missing window")

    return {"status": status, "reasons": reasons}


__all__ = [
    "BASE_POSITION_CAL_PROFILE_SCHEMA_ID",
    "BASE_POSITION_CAL_PREVIEW_SCHEMA_ID",
    "BASE_POSITION_CAL_EVAL_SCHEMA_ID",
    "BASE_POSITION_CAL_PROFILES_CAP",
    "BASE_POSITION_CAL_PREVIEWS_CAP",
    "base_position_calibration_profile_json_bytes",
    "base_position_calibration_profile_sha256",
    "base_position_calibration_preview_json_bytes",
    "base_position_calibration_preview_sha256",
    "base_position_calibration_eval_json_bytes",
    "base_position_calibration_eval_sha256",
    "build_base_position_calibration_profile_and_preview",
    "build_base_position_calibration_eval",
    "attach_base_position_calibration_profile",
    "apply_base_position_calibration_to_report",
    "check_base_position_calibration_compatibility",
]
