from __future__ import annotations

from typing import Any, Literal, Mapping, TypedDict


def normalize_decision_mode(value: Any) -> str:
    mode = str(value or "").strip().lower()
    return "decision_grade" if mode == "decision_grade" else "filter_only"


def interpretation_for_mode(decision_mode: str) -> str:
    return "decision_grade" if normalize_decision_mode(decision_mode) == "decision_grade" else "exploratory_uncalibrated"


def watermark_label(*, decision_mode: str, interpretation: str | None = None) -> str:
    mode = normalize_decision_mode(decision_mode)
    interp = interpretation_for_mode(mode) if interpretation is None else str(interpretation)
    if mode == "decision_grade":
        return "DECISION_GRADE"
    return str(interp).strip().upper() or "EXPLORATORY_UNCALIBRATED"


def export_watermark_label(*, decision_mode: str, is_demo: bool = False) -> str:
    """
    User-facing, screenshot-safe watermark label for exported artifacts.

    Keep this intentionally boring and explicit: it should survive copy/paste and screenshots.
    """
    mode = normalize_decision_mode(decision_mode)
    if mode == "decision_grade":
        return "DECISION_GRADE"
    if bool(is_demo):
        return "DEMO — NOT DECISION-GRADE"
    return "EXPLORATORY — NOT DECISION-GRADE"


def ui_mode_label(*, decision_mode: str, is_demo: bool = False) -> str:
    """
    Screenshot-safe mode label for on-screen UI (not exports).

    In non-decision-grade mode, the product must not emit probability-shaped values
    unless explicitly flagged as synthetic. Keep this label stable and unambiguous.
    """

    _ = is_demo  # UI label is intentionally conservative: demo/non-demo both read as non-calibrated.
    mode = normalize_decision_mode(decision_mode)
    if mode == "decision_grade":
        return "DECISION-GRADE"
    return "DEMO (NON-CALIBRATED)"


def ui_mode_subtext(*, decision_mode: str) -> str | None:
    mode = normalize_decision_mode(decision_mode)
    if mode == "decision_grade":
        return None
    return "Quantitative outputs suppressed. Not comparable across guides or runs. Not for experimental planning."


def extract_decision_grade_proof_from_artifact(artifact: Mapping[str, Any] | None) -> Mapping[str, Any] | None:
    if not isinstance(artifact, Mapping):
        return None
    proof = artifact.get("decision_grade_proof")
    return proof if isinstance(proof, Mapping) else None


def extract_decision_grade_proof_from_summary(summary_v2: Mapping[str, Any] | None) -> Mapping[str, Any] | None:
    if not isinstance(summary_v2, Mapping):
        return None
    prov = summary_v2.get("provenance") if isinstance(summary_v2.get("provenance"), Mapping) else {}
    pdata = prov.get("data") if isinstance(prov.get("data"), Mapping) else {}
    cald = pdata.get("calibration_dataset") if isinstance(pdata.get("calibration_dataset"), Mapping) else {}
    calb = pdata.get("calibration_bundle") if isinstance(pdata.get("calibration_bundle"), Mapping) else {}
    unc = summary_v2.get("uncertainty") if isinstance(summary_v2.get("uncertainty"), Mapping) else {}
    unc_status = str(unc.get("status") or "not_computed")
    unc_kind = str(unc.get("kind") or "")
    decision_mode = normalize_decision_mode(summary_v2.get("decision_mode"))
    eligible = decision_mode == "decision_grade"
    required_ci_keys = [
        "control.intended_functional_p",
        "control.no_cut_p",
        "outcomes.top_p",
    ]
    return {
        "status": "present" if eligible else "absent",
        "calibration_dataset": {
            "id": str(cald.get("id") or "").strip() or None,
            "checksum": str(cald.get("checksum") or "").strip() or None,
        },
        "calibration_bundle": {
            "id": str(calb.get("id") or "").strip() or None,
            "checksum": str(calb.get("checksum") or "").strip() or None,
            "evaluation_code_hash": str(calb.get("evaluation_code_hash") or "").strip() or None,
        },
        "uncertainty": {
            "status": unc_status,
            "kind": (unc_kind or None),
            "required_credible_interval_keys": required_ci_keys,
        },
    }


class DecisionReadinessBlockedReason(TypedDict):
    severity: Literal["danger", "warn"]
    title: str
    detail: str
    fix: str


def decision_grade_blocked_reasons(summary_v2: Mapping[str, Any] | None) -> list[DecisionReadinessBlockedReason]:
    """
    Return actionable reasons decision-grade outputs are blocked or incomplete.

    Intended for UI surfaces (Run Status, export gate prompts). Keep the output
    stable and screenshot-safe: no probabilities in filter-only mode.
    """
    if not isinstance(summary_v2, Mapping):
        return [
            {
                "severity": "danger",
                "title": "Run summary missing",
                "detail": "Decision-grade readiness cannot be evaluated without a Summary Contract v2 payload.",
                "fix": "Rerun or reload the run so `metadata.run_summary` is available.",
            }
        ]

    verdict = summary_v2.get("verdict") if isinstance(summary_v2.get("verdict"), Mapping) else {}
    decision_notes = verdict.get("decision_notes") if isinstance(verdict.get("decision_notes"), list) else []
    notes = [str(n).strip() for n in decision_notes if isinstance(n, str) and str(n).strip()]

    proof = extract_decision_grade_proof_from_summary(summary_v2) or {}
    cald = proof.get("calibration_dataset") if isinstance(proof.get("calibration_dataset"), Mapping) else {}
    calb = proof.get("calibration_bundle") if isinstance(proof.get("calibration_bundle"), Mapping) else {}
    unc_proof = proof.get("uncertainty") if isinstance(proof.get("uncertainty"), Mapping) else {}

    reasons: list[DecisionReadinessBlockedReason] = []

    # Invalid / non-decision-grade root causes (machine notes).
    for note in notes:
        if note.lower().startswith("invalid:"):
            cause = note.split(":", 1)[1].strip()
            if cause:
                reasons.append(
                    {
                        "severity": "danger",
                        "title": "Run invalid",
                        "detail": cause,
                        "fix": "Resolve the invalidity root cause and rerun.",
                    }
                )

    # Calibration bundle / dataset.
    missing_cal: list[str] = []
    if not str(calb.get("id") or "").strip():
        missing_cal.append("bundle id")
    if not str(calb.get("checksum") or "").strip():
        missing_cal.append("bundle checksum")
    if not str(calb.get("evaluation_code_hash") or "").strip():
        missing_cal.append("evaluation code hash")
    if not str(cald.get("id") or "").strip():
        missing_cal.append("dataset id")
    if not str(cald.get("checksum") or "").strip():
        missing_cal.append("dataset checksum")
    if missing_cal or any("not_decision_grade" in n and "calibration_bundle_missing" in n for n in notes):
        detail = "Missing: " + ", ".join(missing_cal) if missing_cal else "Calibration bundle not configured."
        reasons.append(
            {
                "severity": "danger",
                "title": "Calibration bundle missing",
                "detail": detail,
                "fix": "Configure a calibration bundle (e.g., set `HELIX_CALIBRATION_BUNDLE_DIR`) and rerun.",
            }
        )

    # Uncertainty + required CI keys (decision-grade proof requires these keys).
    unc = summary_v2.get("uncertainty") if isinstance(summary_v2.get("uncertainty"), Mapping) else {}
    unc_status = str(unc.get("status") or unc_proof.get("status") or "not_computed")
    unc_reason = str(unc.get("reason") or "").strip()
    if unc_status != "computed" or any("not_decision_grade" in n and "uncertainty_not_computed" in n for n in notes):
        detail = f"status={unc_status}"
        if unc_reason:
            detail = detail + f" ({unc_reason})"
        reasons.append(
            {
                "severity": "danger",
                "title": "Uncertainty not computed",
                "detail": detail,
                "fix": "Rerun with outcome counts available and uncertainty enabled.",
            }
        )

    required_keys = (
        unc_proof.get("required_credible_interval_keys")
        if isinstance(unc_proof.get("required_credible_interval_keys"), list)
        else ["control.intended_functional_p", "control.no_cut_p", "outcomes.top_p"]
    )
    cis = unc.get("credible_intervals") if isinstance(unc.get("credible_intervals"), Mapping) else {}
    missing_ci: list[str] = []
    for key in [str(k) for k in required_keys if str(k).strip()]:
        entry = cis.get(key)
        if not isinstance(entry, Mapping):
            missing_ci.append(key)
            continue
        lo = entry.get("lower")
        hi = entry.get("upper")
        if not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)):
            missing_ci.append(key)
    if missing_ci:
        reasons.append(
            {
                "severity": "danger",
                "title": "Required confidence intervals missing",
                "detail": "Missing keys: " + ", ".join(missing_ci),
                "fix": "Ensure the summary emits the required credible intervals and rerun.",
            }
        )

    if any("not_decision_grade" in n and "provenance_incomplete" in n for n in notes):
        reasons.append(
            {
                "severity": "danger",
                "title": "Provenance incomplete",
                "detail": "Build/run provenance is incomplete for decision-grade export.",
                "fix": "Ensure backend git commit + build timestamp, model hash, and priors are configured, then rerun.",
            }
        )

    # Intent readiness: required decision record must be present and bound to the design spec.
    intent_block = summary_v2.get("experiment_intent_spec") if isinstance(summary_v2.get("experiment_intent_spec"), Mapping) else {}
    intent_status = str(intent_block.get("status") or "").strip().lower()
    intent_missing = intent_block.get("missing_fields") if isinstance(intent_block.get("missing_fields"), list) else []
    intent_missing = [str(x) for x in intent_missing if str(x)]
    intent_err = str(intent_block.get("validation_error") or "").strip()

    if intent_status in {"", "missing"}:
        reasons.append(
            {
                "severity": "danger",
                "title": "Experiment intent missing",
                "detail": "MISSING_INTENT_SPEC",
                "fix": "Fill in the Experiment intent (decision record) fields and re-export.",
            }
        )
    elif intent_status == "invalid":
        reasons.append(
            {
                "severity": "danger",
                "title": "Experiment intent invalid",
                "detail": f"INTENT_SPEC_INVALID_SCHEMA{(': ' + intent_err) if intent_err else ''}",
                "fix": "Fix the intent spec so it validates against helix_experiment_intent_spec_v1, then re-export.",
            }
        )
    elif intent_status == "incomplete":
        detail = "INTENT_SPEC_INCOMPLETE_REQUIRED_FIELDS"
        if intent_missing:
            detail = detail + " (missing: " + ", ".join(intent_missing) + ")"
        reasons.append(
            {
                "severity": "danger",
                "title": "Experiment intent incomplete",
                "detail": detail,
                "fix": "Complete the required intent fields (decision question, hypothesis, perturbation, readout, decision rule, premortem).",
            }
        )

    intent_ref = summary_v2.get("experiment_intent_ref") if isinstance(summary_v2.get("experiment_intent_ref"), Mapping) else {}
    ref_status = str(intent_ref.get("status") or "").strip().lower()
    if ref_status in {"", "missing", "mismatch", "invalid"}:
        reasons.append(
            {
                "severity": "danger",
                "title": "Experiment intent not bound to design spec",
                "detail": f"intentRef.status={ref_status or 'missing'}",
                "fix": "Ensure ExperimentSpec.intentRef points at the current ExperimentIntentSpec sha256 (auto-set when saving intent).",
            }
        )

    # Off-target readiness: computed vs not_computed, and screening vs full.
    risk = summary_v2.get("risk") if isinstance(summary_v2.get("risk"), Mapping) else {}
    off = risk.get("off_target") if isinstance(risk.get("off_target"), Mapping) else {}
    ot_status = str(off.get("status") or "").strip()
    ot_mode = str(off.get("mode") or "").strip()
    ot_executed = str(off.get("executed_mode") or "").strip()
    ot_reason = str(off.get("reason") or off.get("limitations") or "").strip()
    ot_severity = str(off.get("severity") or "").strip().lower()

    if ot_status and ot_status != "computed":
        sev: Literal["danger", "warn"] = "danger" if ot_severity in {"", "blocking"} else "warn"
        detail = f"status={ot_status}"
        if ot_reason:
            detail = detail + f" ({ot_reason})"
        reasons.append(
            {
                "severity": sev,
                "title": "Off-target risk not computed",
                "detail": detail,
                "fix": "Run off-target in policy/full mode and rerun.",
            }
        )
    elif ot_status == "computed" and ot_mode == "screening":
        detail = "computed in screening mode"
        if ot_reason:
            detail = detail + f" ({ot_reason})"
        reasons.append(
            {
                "severity": "warn",
                "title": "Off-target risk screening only",
                "detail": detail,
                "fix": "If required by policy, rerun with full off-target enabled.",
            }
        )
    elif ot_status == "computed" and ot_mode == "full" and ot_executed and ot_executed != "full":
        reasons.append(
            {
                "severity": "danger",
                "title": "Off-target full mode required",
                "detail": f"requested full but executed {ot_executed}",
                "fix": "Rerun with full off-target enabled and available in this environment.",
            }
        )

    intended = summary_v2.get("intended_edit_spec") if isinstance(summary_v2.get("intended_edit_spec"), Mapping) else {}
    measurement = intended.get("measurement") if isinstance(intended.get("measurement"), Mapping) else {}
    cell_types = intended.get("cell_types") if isinstance(intended.get("cell_types"), Mapping) else {}
    population = intended.get("population") if isinstance(intended.get("population"), Mapping) else {}
    missing_spec: list[str] = []
    if str(measurement.get("status") or "").strip().lower() != "declared":
        missing_spec.append("assay")
    if str(cell_types.get("status") or "").strip().lower() != "declared":
        missing_spec.append("cell types")
    if str(population.get("status") or "").strip().lower() != "declared":
        missing_spec.append("population mode")
    if missing_spec:
        reasons.append(
            {
                "severity": "warn",
                "title": "Evidence metadata incomplete",
                "detail": "Missing: " + ", ".join(missing_spec),
                "fix": "Declare assay, population mode, and cell types in experiment_spec constraints/assumptions.",
            }
        )

    # De-dupe by title (stable order).
    seen_titles: set[str] = set()
    deduped: list[DecisionReadinessBlockedReason] = []
    for r in reasons:
        title = str(r.get("title") or "").strip()
        if not title or title in seen_titles:
            continue
        seen_titles.add(title)
        deduped.append(r)
    return deduped


def governance_stamp_lines(
    *,
    decision_mode: str,
    interpretation: str | None = None,
    decision_grade_proof: Mapping[str, Any] | None = None,
) -> list[str]:
    mode = normalize_decision_mode(decision_mode)
    interp = interpretation_for_mode(mode) if interpretation is None else str(interpretation)
    lines = [
        f"governance_decision_mode: {mode}",
        f"governance_interpretation: {interp}",
    ]

    if mode != "decision_grade":
        return lines

    proof = decision_grade_proof if isinstance(decision_grade_proof, Mapping) else {}
    cald = proof.get("calibration_dataset") if isinstance(proof.get("calibration_dataset"), Mapping) else {}
    calb = proof.get("calibration_bundle") if isinstance(proof.get("calibration_bundle"), Mapping) else {}
    unc = proof.get("uncertainty") if isinstance(proof.get("uncertainty"), Mapping) else {}

    ds_id = str(cald.get("id") or "").strip()
    ds_sha = str(cald.get("checksum") or "").strip()
    lines.append(f"governance_calibration_dataset: {ds_id or 'unconfigured'} {ds_sha or 'sha256:unavailable'}")

    b_id = str(calb.get("id") or "").strip()
    b_sha = str(calb.get("checksum") or "").strip()
    b_code = str(calb.get("evaluation_code_hash") or "").strip()
    lines.append(
        "governance_calibration_bundle: "
        + f"{b_id or 'unconfigured'} {b_sha or 'sha256:unavailable'} evaluation_code_hash={b_code or 'sha256:unavailable'}"
    )

    unc_status = str(unc.get("status") or "")
    unc_kind = str(unc.get("kind") or "")
    if unc_kind:
        lines.append(f"governance_uncertainty: {unc_status} kind={unc_kind}")
    else:
        lines.append(f"governance_uncertainty: {unc_status or 'unknown'}")

    required_keys = unc.get("required_credible_interval_keys") if isinstance(unc.get("required_credible_interval_keys"), list) else None
    if required_keys:
        keys_txt = ",".join([str(k) for k in required_keys if str(k)])
        lines.append(f"governance_uncertainty_ci_keys: {keys_txt}")
    return lines


def governance_csv_prefix(
    *,
    decision_mode: str,
    interpretation: str | None = None,
    decision_grade_proof: Mapping[str, Any] | None = None,
) -> str:
    lines = governance_stamp_lines(
        decision_mode=decision_mode,
        interpretation=interpretation,
        decision_grade_proof=decision_grade_proof,
    )
    return "\n".join([f"# {line}" for line in lines]) + "\n"


__all__ = [
    "normalize_decision_mode",
    "interpretation_for_mode",
    "watermark_label",
    "export_watermark_label",
    "ui_mode_label",
    "ui_mode_subtext",
    "extract_decision_grade_proof_from_artifact",
    "extract_decision_grade_proof_from_summary",
    "DecisionReadinessBlockedReason",
    "decision_grade_blocked_reasons",
    "governance_stamp_lines",
    "governance_csv_prefix",
]
