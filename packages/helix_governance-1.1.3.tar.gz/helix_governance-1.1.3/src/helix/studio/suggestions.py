"""Suggestion data model and gating for inferred locus/genome build.

All suggestion payloads live here to avoid drift. Execution code must never
consume suggestions; they are display-only until the user explicitly applies
them, at which point provenance is recorded on the canonical fields.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass
from typing import List, Mapping, Sequence

from helix import clock
SOURCE_INFERRED = "inferred"
SOURCE_USER = "user"
SOURCE_IMPORTED = "imported"
SOURCE_USER_APPLIED = "user_applied_inference"

CONF_HIGH = "high"
CONF_MED = "med"
CONF_LOW = "low"

TOP_K = 5
GAP_HIGH = 0.10
GAP_MED = 0.05
SCORE_HIGH = 0.90
SCORE_MED = 0.75
SUGGESTIONS_FLAG_ENV = "HELIX_ENABLE_SUGGESTIONS"
_SUGGESTIONS_ENABLED_CACHE: bool | None = None


def now_iso() -> str:
    return clock.utc_now_iso()


def normalize_sequence_for_digest(seq: str) -> str:
    """Normalize for digest using the first FASTA record only.

    - Uppercase.
    - Drop FASTA headers.
    - Stop at the second record to avoid multi-record concatenation.
    - Map RNA U->T.
    - Replace non-IUPAC with N.
    """
    valid = set("ACGTRYSWKMBDHVN")
    cleaned: List[str] = []
    saw_sequence = False
    for line in seq.splitlines():
        if line.startswith(">"):
            if saw_sequence:
                break
            continue
        if not line.strip():
            continue
        saw_sequence = True
        for ch in line.upper():
            if ch.isspace():
                continue
            if ch == "U":
                ch = "T"
            cleaned.append(ch if ch in valid else "N")
    return "".join(cleaned)


def compute_input_digest(seq: str, params: Mapping[str, object] | None = None) -> str:
    norm = normalize_sequence_for_digest(seq)
    payload = {"sequence": norm, "params": params or {}}
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class SuggestionCandidate:
    label: str
    kind: str
    score: float
    confidence: str
    method: str
    source: str
    details: str | None = None
    genome_build: str | None = None
    index_id: str | None = None
    index_checksum: str | None = None

    def to_dict(self) -> dict:
        payload = {
            "label": self.label,
            "kind": self.kind,
            "score": float(self.score),
            "confidence": self.confidence,
            "method": self.method,
            "source": self.source,
        }
        if self.details:
            payload["details"] = self.details
        if self.genome_build:
            payload["genomeBuild"] = self.genome_build
        if self.index_id:
            payload["index_id"] = self.index_id
        if self.index_checksum:
            payload["index_checksum"] = self.index_checksum
        return payload


def confidence_and_ambiguity(candidates: Sequence[Mapping[str, object]]) -> tuple[str, bool]:
    if not candidates:
        return CONF_LOW, True
    scores = sorted((float(c.get("score", 0.0)) for c in candidates), reverse=True)
    top = scores[0]
    gap = (scores[0] - scores[1]) if len(scores) > 1 else 1.0
    ambiguous = len(scores) > 1 and gap < GAP_MED
    if top >= SCORE_HIGH and gap >= GAP_HIGH:
        return CONF_HIGH, ambiguous
    if top >= SCORE_MED and gap >= GAP_MED:
        return CONF_MED, ambiguous
    return CONF_LOW, True


def build_locus_suggestion(*, input_digest: str, candidates: Sequence[SuggestionCandidate], created_at: str | None = None) -> dict:
    top_k = [c.to_dict() for c in list(candidates)[:TOP_K]]
    confidence, ambiguous = confidence_and_ambiguity(top_k)
    suggestion_id = f"{input_digest[:12]}:{(created_at or now_iso())}"
    if top_k:
        top_k[0]["confidence"] = confidence
    return {
        "suggestion_id": suggestion_id,
        "input_digest": input_digest,
        "created_at": created_at or now_iso(),
        "best": top_k[0] if top_k else {},
        "candidates": top_k,
        "ambiguous": ambiguous,
    }


def build_genome_suggestion(*, input_digest: str, candidates: Sequence[SuggestionCandidate], created_at: str | None = None) -> dict:
    top_k = [c.to_dict() for c in list(candidates)[:TOP_K]]
    confidence, ambiguous = confidence_and_ambiguity(top_k)
    suggestion_id = f"{input_digest[:12]}:{(created_at or now_iso())}"
    if top_k:
        top_k[0]["confidence"] = confidence
    return {
        "suggestion_id": suggestion_id,
        "input_digest": input_digest,
        "created_at": created_at or now_iso(),
        "best": top_k[0] if top_k else {},
        "candidates": top_k,
        "ambiguous": ambiguous,
    }


def actionable(suggestion: Mapping[str, object] | None, current_digest: str | None) -> bool:
    if not isinstance(suggestion, Mapping):
        return False
    if not current_digest or suggestion.get("input_digest") != current_digest:
        return False
    if suggestion.get("ambiguous"):
        return False
    best = suggestion.get("best") if isinstance(suggestion.get("best"), Mapping) else {}
    return str(best.get("confidence") or "low") == CONF_HIGH


def suggestions_enabled() -> bool:
    global _SUGGESTIONS_ENABLED_CACHE
    if _SUGGESTIONS_ENABLED_CACHE is None:
        raw = os.environ.get(SUGGESTIONS_FLAG_ENV, "0").strip().lower()
        _SUGGESTIONS_ENABLED_CACHE = raw in {"1", "true", "yes", "on"}
    return bool(_SUGGESTIONS_ENABLED_CACHE)


def _reset_suggestions_enabled_cache_for_tests() -> None:  # pragma: no cover - test hook
    global _SUGGESTIONS_ENABLED_CACHE
    _SUGGESTIONS_ENABLED_CACHE = None


def build_index_anchored_genome_suggestion(
    *,
    input_digest: str,
    genome_build: str | None,
    index_id: str | None,
    index_checksum: str | None,
    method: str = "fm_index",
    created_at: str | None = None,
) -> dict | None:
    if not (input_digest and genome_build and index_id and index_checksum):
        return None
    candidate = SuggestionCandidate(
        label=str(genome_build),
        kind="genome_build",
        score=1.0,
        confidence=CONF_HIGH,
        method=method,
        source="index",
        genome_build=str(genome_build),
        index_id=str(index_id),
        index_checksum=str(index_checksum),
    )
    return build_genome_suggestion(
        input_digest=input_digest,
        candidates=[candidate],
        created_at=created_at,
    )


__all__ = [
    "normalize_sequence_for_digest",
    "compute_input_digest",
    "now_iso",
    "SuggestionCandidate",
    "build_locus_suggestion",
    "build_genome_suggestion",
    "build_index_anchored_genome_suggestion",
    "actionable",
    "suggestions_enabled",
    "CONF_HIGH",
    "CONF_MED",
    "CONF_LOW",
    "SOURCE_INFERRED",
    "SOURCE_USER",
    "SOURCE_IMPORTED",
    "SOURCE_USER_APPLIED",
    "_reset_suggestions_enabled_cache_for_tests",
]
