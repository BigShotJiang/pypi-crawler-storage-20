from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, List, Mapping

from helix import fs

_PRESETS_DIR = Path(__file__).resolve().parent / "resources" / "presets"
_USER_DIR = Path(os.path.expanduser("~/.helix/presets/helix_experiment_preset_v1"))


@dataclass
class ExperimentPreset:
    id: str
    kind: str
    raw: dict[str, Any]

    @property
    def label(self) -> str:
        return self.raw.get("label", self.id)

    @property
    def ui_defaults(self) -> dict[str, Any]:
        return self.raw.get("ui_defaults", {})


def _load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema") != "helix_experiment_preset_v1":
        raise ValueError(f"Unsupported preset schema: {data.get('schema')}")
    return data


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _read_single_contig_fasta(path: Path) -> tuple[str, str]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    name: str | None = None
    seq_parts: list[str] = []
    sequences: dict[str, str] = {}

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if name is not None:
                sequences[name] = "".join(seq_parts).upper()
            name = line[1:].split()[0]
            seq_parts = []
            continue
        seq_parts.append(line)

    if name is not None:
        sequences[name] = "".join(seq_parts).upper()

    if not sequences:
        raise ValueError(f"FASTA is empty: {path}")
    if len(sequences) != 1:
        raise ValueError(f"FASTA must contain exactly one contig (got {len(sequences)}): {path}")
    contig, seq = next(iter(sequences.items()))
    if not seq:
        raise ValueError(f"FASTA sequence is empty: {path}")
    return contig, seq


def _resolve_genome_sequence(genome: Mapping[str, Any]) -> tuple[str | None, str]:
    """Return (contig, sequence) for a preset genome block.

    Supports inline genomes via genome.sequence and local FASTA via genome.sequence_fasta.
    """

    seq = genome.get("sequence")
    if isinstance(seq, str) and seq.strip():
        return None, seq.strip().upper()

    fasta_path = genome.get("sequence_fasta") or genome.get("fasta_path") or genome.get("fasta")
    if isinstance(fasta_path, str) and fasta_path.strip():
        path = Path(fasta_path)
        if not path.is_absolute():
            path = _repo_root() / path
        contig, seq = _read_single_contig_fasta(path)
        return contig, seq

    raise ValueError("Preset genome is missing 'sequence' (inline) or 'sequence_fasta' (path).")


def load_preset(preset_id: str) -> ExperimentPreset:
    for base in (_USER_DIR, _PRESETS_DIR):
        path = base / f"{preset_id}.json"
        if path.exists():
            data = _load_json(path)
            return ExperimentPreset(id=data["id"], kind=data["kind"], raw=data)
    raise FileNotFoundError(f"Preset not found: {preset_id}")


def preset_to_snapshot(preset: ExperimentPreset) -> dict[str, Any]:
    raw = preset.raw
    genome = raw.get("genome", {})
    coords = genome.get("coords") if isinstance(genome.get("coords"), Mapping) else {}
    ref_build = coords.get("reference") or coords.get("build") or coords.get("genome_build")
    ref_build = str(ref_build).strip() if ref_build else ""
    coord_contig = coords.get("contig") or coords.get("chrom") or coords.get("chr")
    coord_contig = str(coord_contig).strip() if coord_contig else ""
    coord_start = coords.get("start")
    coord_end = coords.get("end")
    contig_from_fasta, seq = _resolve_genome_sequence(genome if isinstance(genome, Mapping) else {})
    contig = coord_contig or contig_from_fasta or genome.get("id") or "demo"
    contig = str(contig).strip() if contig else "demo"
    locus = f"{genome.get('id', 'demo')}:{genome.get('coords', {}).get('start', 0)}-{genome.get('coords', {}).get('end', len(seq))}"
    if coord_contig and coord_start is not None and coord_end is not None:
        try:
            locus = f"{coord_contig}:{int(coord_start)}-{int(coord_end)}"
        except Exception:
            locus = f"{coord_contig}:{coord_start}-{coord_end}"
    elif contig and coord_start is not None and coord_end is not None:
        try:
            locus = f"{contig}:{int(coord_start)}-{int(coord_end)}"
        except Exception:
            locus = f"{contig}:{coord_start}-{coord_end}"
    outcomes = raw.get("outcomes", [])
    sim = raw.get("simulation", {})
    crispr_cfg = raw.get("crispr") or {}
    prime_cfg = raw.get("prime") or {}
    guide_id = crispr_cfg.get("guide_id") or prime_cfg.get("peg_id") or "demo_guide"
    run_id = raw.get("id", "demo")

    edit_spec = raw.get("edit_spec") if isinstance(raw.get("edit_spec"), Mapping) else {}
    cut_index = edit_spec.get("pos")
    pam_index = crispr_cfg.get("pam_start") if isinstance(crispr_cfg, Mapping) else None

    draws = sim.get("draws") if isinstance(sim, Mapping) else None
    seed = sim.get("random_seed") if isinstance(sim, Mapping) else None
    priors_profile = sim.get("priors_profile") if isinstance(sim, Mapping) else None

    nuclease = crispr_cfg.get("nuclease") if isinstance(crispr_cfg, Mapping) else None
    pam_pattern = crispr_cfg.get("pam_pattern") if isinstance(crispr_cfg, Mapping) else None
    pam_profile = None
    try:
        if nuclease and pam_pattern:
            pam_profile = f"{str(nuclease).strip()}_{str(pam_pattern).strip()}"
    except Exception:
        pam_profile = None

    genome_hash = genome.get("sequence_sha256") if isinstance(genome, Mapping) else None
    if not isinstance(genome_hash, str) or not genome_hash.strip():
        genome_hash = preset.id

    genome_uri = f"preset://{preset.id}"
    if ref_build and contig and coord_start is not None and coord_end is not None:
        genome_uri = f"{ref_build}://{contig}:{coord_start}-{coord_end}"

    reference_context: dict[str, Any] | None = None
    if ref_build or contig or coord_start is not None or coord_end is not None:
        reference_context = {
            "organism": "human" if ref_build or preset.id.lower().endswith("emx1_v1") else "unknown",
            "genomeBuild": ref_build or None,
            "reference": ref_build or None,
            "contig": contig,
            "windowStart": coord_start,
            "windowEnd": coord_end,
            "coordinateSystem": "1-based-inclusive" if (coord_start is not None and coord_end is not None) else None,
        }
        ann = genome.get("annotation") if isinstance(genome, Mapping) and isinstance(genome.get("annotation"), Mapping) else {}
        if ann:
            try:
                reference_context["annotationSource"] = ann.get("source")
                reference_context["annotationRelease"] = ann.get("release")
                reference_context["annotationGeneSymbol"] = ann.get("gene_symbol") or ann.get("geneSymbol")
                reference_context["annotationGeneId"] = ann.get("gene_id") or ann.get("geneId")
            except Exception:
                pass
        reference_context = {k: v for k, v in reference_context.items() if v is not None}

    spacer_start = crispr_cfg.get("spacer_start", 0) if isinstance(crispr_cfg, Mapping) else 0
    spacer_len = crispr_cfg.get("spacer_len", 20) if isinstance(crispr_cfg, Mapping) else 20
    guide_seq = ""
    try:
        s = int(spacer_start)
        ln = int(spacer_len)
        if 0 <= s < len(seq) and 0 < ln and s + ln <= len(seq):
            guide_seq = seq[s : s + ln]
    except Exception:
        guide_seq = ""
    if not guide_seq:
        guide_seq = seq[:23]

    state: dict[str, Any] = {
        "run_kind": raw.get("kind", "NONE").upper(),
        "run_id": run_id,
        "viz_dirty": True,
        "config": {
            "run_config": {
                "mode": pam_profile or (sim.get("engine", "") if isinstance(sim, Mapping) else ""),
                "draws": draws,
                "seed": seed,
                "pam_profile": pam_profile,
                "priors_profile": priors_profile,
            },
            "guide": {
                "id": guide_id,
                "name": guide_id,
                "locus": locus,
                "sequence": guide_seq,
                "pam": crispr_cfg.get("pam_pattern", "NGG") if crispr_cfg else "NGG",
                "pam_index": pam_index,
                "cut_index": cut_index,
                "start": crispr_cfg.get("spacer_start", 0),
                "end": crispr_cfg.get("spacer_start", 0) + crispr_cfg.get("spacer_len", 20),
                "strand": crispr_cfg.get("strand", "+"),
            },
            "sim_payload": {
                "site": {"sequence": seq, "length": len(seq)},
                "guide": {
                    "id": guide_id,
                    "sequence": seq[crispr_cfg.get("spacer_start", 0) : crispr_cfg.get("spacer_start", 0) + crispr_cfg.get("spacer_len", 20)],
                    "pam": crispr_cfg.get("pam_pattern", "NGG") if crispr_cfg else "NGG",
                },
                "outcomes": outcomes,
                "artifact": f"preset:{preset.id}",
                "physics_score": {},
            },
        },
        "outcomes": outcomes,
        "viz_spec_payload": None,
        "genome_source": f"preset:{ref_build}" if ref_build else "preset",
        "genome_uri": genome_uri,
        "genome_hash": genome_hash,
        "genome": {contig: seq},
    }
    if reference_context:
        state["reference_context"] = reference_context


    return {
        "version": 2,
        "state": state,
        "runs": [
            {
                "run_id": run_id,
                "guide_id": guide_id,
                "edit_type": raw.get("kind", "demo"),
                "sequence": seq,
                "target_locus": locus,
                "pam_index": crispr_cfg.get("pam_start"),
                "cut_index": raw.get("edit_spec", {}).get("pos"),
                "outcomes": outcomes,
                "physics": {},
                "engine": {"name": sim.get("engine", "demo_engine"), "backend": "cpu"},
                "metadata": {"scenario": "demo"},
            }
        ],
    }


def list_presets() -> list[ExperimentPreset]:
    presets: list[ExperimentPreset] = []
    for base in (_PRESETS_DIR, _USER_DIR):
        if not base.exists():
            continue
        for path in fs.glob_sorted(base, "*.json"):
            try:
                data = _load_json(path)
                presets.append(ExperimentPreset(id=data["id"], kind=data["kind"], raw=data))
            except Exception:
                continue
    # dedupe by id, prefer user presets
    seen = {}
    for p in presets:
        seen[p.id] = p
    return list(seen.values())


def save_user_preset(preset_id: str, data: dict[str, Any]) -> Path:
    _USER_DIR.mkdir(parents=True, exist_ok=True)
    path = _USER_DIR / f"{preset_id}.json"
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path
