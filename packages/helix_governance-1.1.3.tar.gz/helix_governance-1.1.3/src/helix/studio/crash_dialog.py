from __future__ import annotations

import json
import os
import zipfile
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QCheckBox,
    QLabel,
    QMessageBox,
    QPushButton,
    QPlainTextEdit,
    QSettings,
    QVBoxLayout,
    QWidget,
)

from helix.support.bundle import write_support_bundle
from helix.support.crash import CrashRecordRef, format_crash_text, latest_crash

_SETTINGS_ORG = "Helix"
_SETTINGS_APP = "Studio"
_SETTINGS_KEY_LAST_CRASH = "support/last_crash_seen"
_SETTINGS_KEY_CRASH_DIALOG_ENABLED = "support/crash_dialog_enabled"


class CrashReportDialog(QDialog):
    def __init__(self, crash: CrashRecordRef, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._crash = crash
        self._settings = QSettings(_SETTINGS_ORG, _SETTINGS_APP)
        self.setWindowTitle("Recovered from a crash")
        self.setModal(True)
        self.resize(780, 520)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Helix Studio recovered from a crash.", self)
        title.setStyleSheet("font-weight: 650; font-size: 15px; color: #f4f6ff;")
        layout.addWidget(title)

        meta = QLabel(f"Crash record: {crash.path}\ncreated_at_utc: {crash.created_at_utc}", self)
        meta.setTextInteractionFlags(Qt.TextSelectableByMouse)
        meta.setStyleSheet("color: rgba(210,220,240,0.75); font-size: 12px;")
        layout.addWidget(meta)

        self._text = QPlainTextEdit(self)
        self._text.setReadOnly(True)
        self._text.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._text.setPlainText(format_crash_text(crash.path))
        self._text.setStyleSheet("background: rgba(8, 10, 20, 0.9); color: #e6edf7;")
        layout.addWidget(self._text, stretch=1)

        self._disable_future = QCheckBox("Don’t show crash dialog again on startup", self)
        self._disable_future.setChecked(False)
        layout.addWidget(self._disable_future)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy to clipboard", self)
        copy_btn.clicked.connect(self._copy_to_clipboard)
        actions.addWidget(copy_btn)

        bundle_btn = QPushButton("Export support bundle…", self)
        bundle_btn.clicked.connect(self._export_support_bundle)
        actions.addWidget(bundle_btn)

        upload_url = os.getenv("HELIX_SUPPORT_UPLOAD_URL", "").strip()
        if upload_url:
            upload_btn = QPushButton("Upload (opt-in)…", self)
            upload_btn.clicked.connect(lambda: self._upload_support_bundle(upload_url))
            actions.addWidget(upload_btn)

        close_btn = QPushButton("Close", self)
        close_btn.clicked.connect(self._close_dialog)
        actions.addWidget(close_btn)

        layout.addLayout(actions)

    def _close_dialog(self) -> None:
        if self._disable_future.isChecked():
            self._settings.setValue(_SETTINGS_KEY_CRASH_DIALOG_ENABLED, False)
        self.accept()

    def _copy_to_clipboard(self) -> None:
        try:
            clipboard = QGuiApplication.clipboard()
            clipboard.setText(self._text.toPlainText())
        except Exception as exc:
            QMessageBox.critical(self, "Clipboard", f"Failed to copy crash report: {exc}")

    def _export_support_bundle(self) -> None:
        default_name = str(Path.cwd() / "helix_support_bundle.zip")
        out_path, _ = QFileDialog.getSaveFileName(self, "Export support bundle", default_name, "Zip archive (*.zip)")
        if not out_path:
            return
        try:
            out = write_support_bundle(out_path, redact=True)
            QMessageBox.information(self, "Support bundle", f"Support bundle saved to:\n{out}")
        except Exception as exc:
            QMessageBox.critical(self, "Support bundle", f"Failed to write support bundle: {exc}")

    def _upload_support_bundle(self, upload_url: str) -> None:
        temp = Path(self._crash.path).with_suffix(".support_bundle.zip")
        try:
            out = write_support_bundle(temp, redact=True)
        except Exception as exc:
            QMessageBox.critical(self, "Upload", f"Failed to build support bundle: {exc}")
            return

        try:
            with zipfile.ZipFile(out, "r") as zf:
                manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
            entries = manifest.get("entries", [])
            listing = "\n".join(
                f"- {e.get('path')} ({e.get('bytes', 0)} bytes)" for e in entries if isinstance(e, dict)
            )
        except Exception:
            listing = "(Unable to read manifest.json from bundle.)"

        confirm = QMessageBox.question(
            self,
            "Upload support bundle (opt-in)",
            "This will upload a support bundle to:\n"
            f"{upload_url}\n\n"
            "Contents (from manifest.json):\n"
            f"{listing}\n\n"
            "Proceed?",
        )
        if confirm != QMessageBox.Yes:
            return

        try:
            import requests

            with open(out, "rb") as handle:
                resp = requests.post(upload_url, files={"bundle": handle})
            if 200 <= resp.status_code < 300:
                QMessageBox.information(self, "Upload", f"Upload succeeded (HTTP {resp.status_code}).")
            else:
                QMessageBox.warning(
                    self,
                    "Upload",
                    f"Upload failed (HTTP {resp.status_code}).\n\n{resp.text[:8000]}",
                )
        except Exception as exc:
            QMessageBox.critical(self, "Upload", f"Upload failed: {exc}")


def maybe_show_crash_dialog(parent: QWidget | None = None) -> None:
    """Show a crash dialog on next startup if a new crash record exists."""

    if os.getenv("HELIX_STUDIO_SHOW_CRASH_DIALOG", "1") != "1":
        return
    if os.getenv("QT_QPA_PLATFORM", "").lower() == "offscreen":
        return
    if os.getenv("HELIX_STUDIO_HEADLESS", "0") == "1":
        return

    crash = latest_crash()
    if crash is None:
        return

    settings = QSettings(_SETTINGS_ORG, _SETTINGS_APP)
    enabled = settings.value(_SETTINGS_KEY_CRASH_DIALOG_ENABLED, True)
    if enabled in (False, "0", 0, "false", "False"):
        return

    last_seen = str(settings.value(_SETTINGS_KEY_LAST_CRASH, "") or "")
    if last_seen == str(crash.path):
        return

    dlg = CrashReportDialog(crash, parent)
    dlg.exec()
    settings.setValue(_SETTINGS_KEY_LAST_CRASH, str(crash.path))


__all__ = ["CrashReportDialog", "maybe_show_crash_dialog"]
