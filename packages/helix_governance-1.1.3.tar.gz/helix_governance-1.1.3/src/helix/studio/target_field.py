from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace

from PySide6.QtCore import QEvent, QObject, QMargins, QSettings, Qt, QTimer, Signal, QItemSelectionModel
from PySide6.QtGui import QStandardItem, QStandardItemModel
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLineEdit, QPushButton, QWidget


_TOKEN_SEP = " · "
_RECENTS_KEY = "experimentSetup/recentTargetsV1"
_RECENTS_LIMIT = 8
_TARGET_LINE_MIN_HEIGHT = 40
_TYPEAHEAD_DEBOUNCE_MS = 45

_LOCUS_RE = re.compile(
    r"^\s*(?P<contig>[^:\s]+)\s*:\s*(?P<start>[\d,]+)\s*(?:[-–]\s*(?P<end>[\d,]+)\s*)?$"
)
_RS_RE = re.compile(r"^rs\d+$", re.IGNORECASE)
_TRANSCRIPT_RE = re.compile(r"^(ENST\d+(?:\.\d+)?)$", re.IGNORECASE)
_GENE_RE = re.compile(r"^[A-Za-z][A-Za-z0-9]{1,9}$")

_GENE_STOPWORDS = {
    "CRISPR",
    "PRIME",
    "PAM",
    "NGG",
    "GUIDE",
    "TARGET",
    "LOCUS",
    "GENOME",
    "BUILD",
    "REF",
    "REFERENCE",
    "HUMAN",
    "MOUSE",
    "WT",
    "MUT",
    "ALT",
    "VAR",
    "SNP",
    "INDEL",
}


def _norm_int(text: str) -> int:
    return int(str(text).replace(",", ""))


def _format_coord(num: int) -> str:
    return f"{int(num):,}"


def _canon_locus(contig: str, start: int, end: int | None) -> str:
    if end is None:
        return f"{contig}:{_format_coord(start)}"
    if end < start:
        start, end = end, start
    return f"{contig}:{_format_coord(start)}-{_format_coord(end)}"


def _looks_like_gene(text: str) -> bool:
    cand = str(text or "").strip()
    if not _GENE_RE.fullmatch(cand):
        return False
    return cand.upper() not in _GENE_STOPWORDS


def _infer_kind(primary: str) -> str:
    value = str(primary or "").strip()
    if not value:
        return "unset"
    if _LOCUS_RE.match(value):
        return "locus"
    if _RS_RE.match(value):
        return "variant"
    if _TRANSCRIPT_RE.match(value):
        return "transcript"
    if _looks_like_gene(value):
        return "gene"
    if "," in value:
        return "panel"
    return "freeform"


@dataclass(frozen=True)
class TargetToken:
    """Compact, auditable target token line used by the ExperimentSetup dialog.

    This is intentionally small and UI-oriented (not a full structured target spec).
    """

    primary: str
    build: str
    kind: str = "freeform"
    transcript: str | None = None
    window: str | None = None
    window_mode: str | None = None  # e.g., "early_constitutive_exon"

    def display_line(self) -> str:
        parts = [str(self.primary).strip(), str(self.build).strip()]
        if self.kind == "gene":
            if self.transcript:
                parts.append(f"transcript {self.transcript}")
            else:
                parts.append("canonical transcript")
        if self.window_mode == "early_constitutive_exon":
            parts.append("early constitutive exon")
        elif self.window:
            parts.append(f"window {self.window}")
        return _TOKEN_SEP.join([p for p in parts if p])

    def to_settings_dict(self) -> dict[str, str]:
        payload: dict[str, str] = {
            "primary": self.primary,
            "build": self.build,
            "kind": self.kind,
        }
        if self.transcript:
            payload["transcript"] = self.transcript
        if self.window:
            payload["window"] = self.window
        if self.window_mode:
            payload["window_mode"] = self.window_mode
        return payload

    @classmethod
    def from_settings_dict(cls, data: object) -> TargetToken | None:
        if not isinstance(data, dict):
            return None
        primary = str(data.get("primary") or "").strip()
        build = str(data.get("build") or "").strip()
        if not primary or not build:
            return None
        kind = str(data.get("kind") or _infer_kind(primary)).strip() or _infer_kind(primary)
        transcript = str(data.get("transcript") or "").strip() or None
        window = str(data.get("window") or "").strip() or None
        window_mode = str(data.get("window_mode") or "").strip() or None
        return cls(primary=primary, build=build, kind=kind, transcript=transcript, window=window, window_mode=window_mode)

    @classmethod
    def tokenize(cls, raw: str, *, build: str) -> TargetToken | None:
        text = str(raw or "").strip()
        if not text:
            return None
        m = _LOCUS_RE.match(text)
        if m:
            contig = str(m.group("contig")).strip()
            start = _norm_int(m.group("start"))
            end_raw = m.group("end")
            end = _norm_int(end_raw) if end_raw else None
            return cls(primary=_canon_locus(contig, start, end), build=str(build).strip() or "", kind="locus")

        if _RS_RE.match(text):
            return cls(primary=text.lower(), build=str(build).strip() or "", kind="variant")

        tx = _TRANSCRIPT_RE.match(text)
        if tx:
            return cls(primary=tx.group(1).upper(), build=str(build).strip() or "", kind="transcript")

        if _looks_like_gene(text):
            return cls(primary=text.upper(), build=str(build).strip() or "", kind="gene")

        if "," in text:
            cleaned = ",".join([seg.strip() for seg in text.split(",") if seg.strip()])
            return cls(primary=cleaned, build=str(build).strip() or "", kind="panel")

        return cls(primary=text, build=str(build).strip() or "", kind="freeform")

    @classmethod
    def parse_token_line(cls, text: str, *, default_build: str) -> TargetToken | None:
        raw = str(text or "").strip()
        if not raw:
            return None
        if _TOKEN_SEP in raw:
            parts = [p.strip() for p in raw.split("·")]
            if len(parts) >= 2:
                primary = parts[0]
                build = parts[1] or default_build
                transcript = None
                kind = _infer_kind(primary)
                window = None
                window_mode = None
                for detail in parts[2:]:
                    d = str(detail or "").strip()
                    if not d:
                        continue
                    low = d.lower()
                    if low.startswith("transcript "):
                        transcript = d.split(" ", maxsplit=1)[-1].strip() or None
                    elif low == "canonical transcript":
                        transcript = None
                    elif low.startswith("window "):
                        window = d.split(" ", maxsplit=1)[-1].strip() or None
                    elif low == "early constitutive exon":
                        window_mode = "early_constitutive_exon"
                return cls(
                    primary=primary,
                    build=build,
                    kind=kind,
                    transcript=transcript,
                    window=window,
                    window_mode=window_mode,
                )
        return cls.tokenize(raw, build=default_build)


class TargetFieldWidget(QWidget):
    targetChanged = Signal(object)  # TargetToken | None
    refineRequested = Signal()

    def __init__(self, *, placeholder: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._build = "hg38"
        self._token: TargetToken | None = None
        self._programmatic_change = False
        self._suppress_next_text_edited = False
        self._typeahead_pending_query = ""
        self._typeahead_pending_open_popup = False
        self._typeahead_last_applied_query: str | None = None
        self._line_edit: QLineEdit | None = None
        self._base_margins = QMargins(0, 0, 0, 0)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        combo = QComboBox(self)
        combo.setEditable(True)
        combo.setInsertPolicy(QComboBox.NoInsert)
        combo.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
        combo.setMinimumHeight(_TARGET_LINE_MIN_HEIGHT)
        self._combo = combo

        line = combo.lineEdit()
        if isinstance(line, QLineEdit):
            self._line_edit = line
            try:
                self._base_margins = line.textMargins()
            except Exception:
                self._base_margins = QMargins(0, 0, 0, 0)
            line.setPlaceholderText(str(placeholder))
            line.setMinimumHeight(_TARGET_LINE_MIN_HEIGHT)
            line.installEventFilter(self)
            line.returnPressed.connect(self._commit_current_text)  # type: ignore[arg-type]

        model = QStandardItemModel(combo)
        combo.setModel(model)
        self._model = model

        combo.activated.connect(self._on_activated)  # type: ignore[arg-type]
        combo.highlighted.connect(self._on_popup_highlighted)  # type: ignore[arg-type]
        # IMPORTANT: avoid `currentTextChanged` here. When the popup is open, Qt updates the
        # editable text while the user navigates suggestions (hover/arrow keys), which can
        # cause us to rebuild the model repeatedly and effectively freeze the UI.
        if self._line_edit is not None:
            self._line_edit.textEdited.connect(self._on_text_changed)  # type: ignore[arg-type]
        else:
            combo.currentTextChanged.connect(self._on_text_changed)  # type: ignore[arg-type]

        typeahead_timer = QTimer(self)
        typeahead_timer.setSingleShot(True)
        typeahead_timer.timeout.connect(self._apply_typeahead_refresh)  # type: ignore[arg-type]
        self._typeahead_timer = typeahead_timer

        set_btn_parent = self._line_edit if self._line_edit is not None else self
        set_btn = QPushButton("Define…", set_btn_parent)
        set_btn.setFlat(True)
        set_btn.setFocusPolicy(Qt.NoFocus)
        set_btn.setProperty("role", "link")
        set_btn.setCursor(Qt.PointingHandCursor)
        set_btn.clicked.connect(self.focus_and_open)  # type: ignore[arg-type]
        set_btn.setToolTip("Define genomic target…")
        self._set_btn = set_btn

        refine_btn = QPushButton("Details", self)
        refine_btn.setFlat(True)
        refine_btn.setProperty("role", "link")
        refine_btn.setCursor(Qt.PointingHandCursor)
        refine_btn.clicked.connect(self.refineRequested.emit)  # type: ignore[arg-type]
        refine_btn.hide()
        self._refine_btn = refine_btn

        change_btn = QPushButton("Change", self)
        change_btn.setFlat(True)
        change_btn.setProperty("role", "link")
        change_btn.setCursor(Qt.PointingHandCursor)
        change_btn.clicked.connect(self.clear)  # type: ignore[arg-type]
        change_btn.hide()
        self._change_btn = change_btn

        layout.addWidget(combo, stretch=1)
        layout.addWidget(refine_btn)
        layout.addWidget(change_btn)

        self._refresh_model("", open_popup=False)
        self._set_btn.show()
        self._position_set_button()

    def set_reference_build(self, build: str) -> None:
        build_key = str(build or "").strip() or "hg38"
        if build_key == getattr(self, "_build", None):
            return
        self._build = build_key
        if self._token is None:
            self._refresh_model(self._current_edit_text(), open_popup=False)
            return

        updated = replace(self._token, build=build_key)
        self._set_token(updated, store_recent=False)

    def set_token(self, token: TargetToken | None, *, store_recent: bool = False) -> None:
        if token is None:
            self.clear()
            return
        token = replace(token, build=self._build)
        self._set_token(token, store_recent=store_recent)

    def set_from_text(self, value: str, *, store_recent: bool = False) -> None:
        token = TargetToken.parse_token_line(str(value or "").strip(), default_build=self._build)
        if token is None:
            self.clear()
            return
        # Coerce build to the active selection; keep typed transcript detail if present.
        token = replace(token, build=self._build)
        self._set_token(token, store_recent=store_recent)

    def is_set(self) -> bool:
        return self._token is not None and bool(str(self._token.primary or "").strip())

    def token(self) -> TargetToken | None:
        return self._token

    def text(self) -> str:
        return str(self._current_edit_text()).strip()

    def focus_and_open(self) -> None:
        line = self._line_edit
        if isinstance(line, QLineEdit):
            try:
                line.setFocus(Qt.OtherFocusReason)
                if self._token is None:
                    line.selectAll()
            except Exception:
                pass
        if self._token is None:
            self._refresh_model(self._current_edit_text(), open_popup=True)

    def clear(self) -> None:
        self._token = None
        self._programmatic_change = True
        try:
            line = self._line_edit
            if isinstance(line, QLineEdit):
                line.setReadOnly(False)
                self._apply_set_button_margins(show=True)
            self._combo.setCurrentIndex(-1)
            self._combo.setEditText("")
        finally:
            self._programmatic_change = False
        self._set_btn.show()
        self._refine_btn.hide()
        self._change_btn.hide()
        self._position_set_button()
        self._refresh_model("", open_popup=True)
        self.targetChanged.emit(None)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:  # type: ignore[override]
        if obj is self._line_edit:
            if event.type() == QEvent.KeyPress:
                try:
                    key = int(event.key())  # type: ignore[attr-defined]
                except Exception:
                    key = None
                if key in (Qt.Key_Down, Qt.Key_Up) and self._token is None:
                    if not self._combo.view().isVisible():
                        self._refresh_model(self._current_edit_text(), open_popup=True)
                    else:
                        delta = 1 if key == Qt.Key_Down else -1
                        self._navigate_popup(delta)
                    return True
            elif event.type() == QEvent.FocusIn:
                if self._token is None:
                    QTimer.singleShot(0, lambda: self._refresh_model(self._current_edit_text(), open_popup=True))
            elif event.type() in (QEvent.Resize, QEvent.Show, QEvent.FontChange):
                QTimer.singleShot(0, self._position_set_button)
        return super().eventFilter(obj, event)

    def _navigate_popup(self, delta: int) -> None:
        view = self._combo.view()
        model = self._model
        try:
            row_count = int(model.rowCount())
        except Exception:
            return

        try:
            current = view.currentIndex()
            row = int(current.row()) if current.isValid() else -1
        except Exception:
            row = -1

        step = 1 if int(delta) >= 0 else -1
        row = row + step
        while 0 <= row < row_count:
            item = model.item(row)
            if item is None:
                row += step
                continue
            if bool(item.data(Qt.UserRole + 1)):
                row += step
                continue
            if not bool(item.flags() & Qt.ItemIsEnabled):
                row += step
                continue

            idx = model.index(row, 0)
            try:
                view.setCurrentIndex(idx)
            except Exception:
                return
            try:
                sel = view.selectionModel()
                if sel is not None:
                    sel.setCurrentIndex(idx, QItemSelectionModel.ClearAndSelect | QItemSelectionModel.Rows)
            except Exception:
                pass
            try:
                view.scrollTo(idx)
            except Exception:
                pass
            return

        # No move (at start/end) -> keep current.

    def _current_edit_text(self) -> str:
        line = self._line_edit
        if isinstance(line, QLineEdit):
            return str(line.text() or "")
        return str(self._combo.currentText() or "")

    def _on_text_changed(self, text: str) -> None:
        if self._programmatic_change:
            return
        if self._token is not None:
            return
        if getattr(self, "_suppress_next_text_edited", False):
            self._suppress_next_text_edited = False
            return
        self._schedule_typeahead_refresh(text, open_popup=True)

    def _on_popup_highlighted(self, *_args) -> None:
        # When navigating the popup, Qt may update the editable text to match the highlighted
        # row. Treat that as navigation (not user query edits) to prevent model rebuild storms.
        self._suppress_next_text_edited = True

    def _schedule_typeahead_refresh(self, query: str, *, open_popup: bool) -> None:
        self._typeahead_pending_query = str(query or "")
        self._typeahead_pending_open_popup = bool(open_popup)
        try:
            self._typeahead_timer.start(_TYPEAHEAD_DEBOUNCE_MS)
        except Exception:
            self._apply_typeahead_refresh()

    def _apply_typeahead_refresh(self) -> None:
        if self._programmatic_change or self._token is not None:
            return
        query = str(getattr(self, "_typeahead_pending_query", "") or "")
        open_popup = bool(getattr(self, "_typeahead_pending_open_popup", False))
        if query == getattr(self, "_typeahead_last_applied_query", None) and not open_popup:
            return
        self._typeahead_last_applied_query = query
        self._refresh_model(query, open_popup=open_popup)

    def _on_activated(self, index: int) -> None:
        item = self._model.item(index) if index >= 0 else None
        if item is None:
            return
        if bool(item.data(Qt.UserRole + 1)):
            return
        token = TargetToken.from_settings_dict(item.data(Qt.UserRole))
        if token is None:
            return
        self._set_token(token, store_recent=True)

    def _commit_current_text(self) -> None:
        if self._token is not None:
            return
        # If the suggestion popup is open, prefer committing the highlighted suggestion.
        try:
            view = self._combo.view()
            if view.isVisible():
                idx = view.currentIndex()
                if idx.isValid():
                    item = self._model.item(int(idx.row()))
                    if item is not None and not bool(item.data(Qt.UserRole + 1)):
                        token = TargetToken.from_settings_dict(item.data(Qt.UserRole))
                        if token is not None:
                            self._set_token(token, store_recent=True)
                            return
        except Exception:
            pass
        raw = self._current_edit_text()
        token = TargetToken.parse_token_line(raw, default_build=self._build)
        if token is None:
            return
        # Ensure build matches current selection when user types only a primary.
        token = replace(token, build=self._build)
        self._set_token(token, store_recent=True)

    def _set_token(self, token: TargetToken, *, store_recent: bool) -> None:
        if not str(token.primary or "").strip():
            self.clear()
            return
        if not str(token.build or "").strip():
            token = replace(token, build=self._build)

        self._programmatic_change = True
        try:
            self._token = token
            try:
                self._combo.hidePopup()
            except Exception:
                pass
            line = self._line_edit
            if isinstance(line, QLineEdit):
                line.setReadOnly(True)
                self._apply_set_button_margins(show=False)
            self._combo.setCurrentIndex(-1)
            self._combo.setEditText(token.display_line())
        finally:
            self._programmatic_change = False

        self._set_btn.hide()
        self._refine_btn.show()
        self._change_btn.show()
        self._refresh_model("", open_popup=False)
        if store_recent:
            self._store_recent(token)
        self.targetChanged.emit(token)

    def _apply_set_button_margins(self, *, show: bool) -> None:
        line = self._line_edit
        if not isinstance(line, QLineEdit):
            return
        try:
            base = self._base_margins
        except Exception:
            base = QMargins(0, 0, 0, 0)
        if not show:
            try:
                line.setTextMargins(base)
            except Exception:
                pass
            return

        try:
            hint = self._set_btn.sizeHint()
            extra = int(hint.width()) + 10
        except Exception:
            extra = 46
        try:
            line.setTextMargins(base.left(), base.top(), base.right() + extra, base.bottom())
        except Exception:
            pass

    def _position_set_button(self) -> None:
        if self._token is not None:
            return
        line = self._line_edit
        if not isinstance(line, QLineEdit):
            return
        self._apply_set_button_margins(show=True)
        try:
            btn = self._set_btn
            btn.raise_()
            hint = btn.sizeHint()
            w = max(36, int(hint.width()))
            h = max(20, min(int(hint.height()), max(20, int(line.height()) - 6)))
            btn.resize(w, h)
            x = max(2, int(line.width()) - w - 4)
            y = max(2, int((line.height() - h) / 2))
            btn.move(x, y)
            btn.setVisible(self._token is None)
        except Exception:
            return

    def _refresh_model(self, query: str, *, open_popup: bool) -> None:
        q = str(query or "").strip()
        groups = self._build_groups(q)
        keep_text = self._current_edit_text()

        self._model.blockSignals(True)
        try:
            self._model.clear()
            for header, tokens in groups:
                header_item = QStandardItem(str(header))
                # Disable header rows so keyboard/mouse navigation doesn't push the header text
                # into the editable field (Qt may treat enabled-but-not-selectable rows as current).
                header_item.setFlags(Qt.NoItemFlags)
                header_item.setData(True, Qt.UserRole + 1)
                font = header_item.font()
                font.setBold(True)
                header_item.setFont(font)
                self._model.appendRow(header_item)

                for token in tokens:
                    row = QStandardItem("  " + token.display_line())
                    row.setData(token.to_settings_dict(), Qt.UserRole)
                    self._model.appendRow(row)
        finally:
            self._model.blockSignals(False)

        # Preserve the user's current edit text across model resets. Qt may update
        # the editable text when the model changes (e.g., selecting index 0).
        self._programmatic_change = True
        try:
            self._combo.setCurrentIndex(-1)
            self._combo.setEditText(keep_text)
        finally:
            self._programmatic_change = False

        if open_popup and self._token is None:
            try:
                self._combo.showPopup()
            except Exception:
                pass

    def _build_groups(self, query: str) -> list[tuple[str, list[TargetToken]]]:
        q = str(query or "").strip()
        build = self._build

        if not q:
            recents = self._load_recents()
            examples = [
                TargetToken.tokenize("TP53", build=build),
                TargetToken.tokenize("chr17:7,576,000-7,590,000", build=build),
                TargetToken.tokenize("rs123", build=build),
                TargetToken.tokenize("ENST00000269305", build=build),
            ]
            groups: list[tuple[str, list[TargetToken]]] = []
            if recents:
                groups.append(("Recent", recents))
            groups.append(("Examples", [t for t in examples if t is not None]))
            return groups

        genes: list[TargetToken] = []
        transcripts: list[TargetToken] = []
        loci: list[TargetToken] = []
        variants: list[TargetToken] = []
        panels: list[TargetToken] = []
        freeform: list[TargetToken] = []

        if _looks_like_gene(q):
            genes.append(TargetToken(primary=q.upper(), build=build, kind="gene"))

        if _TRANSCRIPT_RE.match(q):
            transcripts.append(TargetToken(primary=q.upper(), build=build, kind="transcript"))

        m = _LOCUS_RE.match(q)
        if m:
            contig = str(m.group("contig")).strip()
            start = _norm_int(m.group("start"))
            end_raw = m.group("end")
            end = _norm_int(end_raw) if end_raw else None
            loci.append(TargetToken(primary=_canon_locus(contig, start, end), build=build, kind="locus"))

        if _RS_RE.match(q):
            variants.append(TargetToken(primary=q.lower(), build=build, kind="variant"))

        if "," in q:
            cleaned = ",".join([seg.strip() for seg in q.split(",") if seg.strip()])
            if cleaned:
                panels.append(TargetToken(primary=cleaned, build=build, kind="panel"))

        if not any((genes, transcripts, loci, variants, panels)):
            freeform.append(TargetToken(primary=q, build=build, kind=_infer_kind(q)))

        groups2: list[tuple[str, list[TargetToken]]] = []
        if genes:
            groups2.append(("Genes", genes))
        if transcripts:
            groups2.append(("Transcripts", transcripts))
        if loci:
            groups2.append(("Loci", loci))
        if variants:
            groups2.append(("Variants", variants))
        if panels:
            groups2.append(("Panels", panels))
        if freeform:
            groups2.append(("Freeform", freeform))
        return groups2

    def _settings(self) -> QSettings | None:
        try:
            return QSettings("Helix", "Studio")
        except Exception:
            return None

    def _load_recents(self) -> list[TargetToken]:
        settings = self._settings()
        if settings is None:
            return []
        raw = settings.value(_RECENTS_KEY, "")
        if not raw:
            return []
        try:
            items = json.loads(str(raw))
        except Exception:
            return []
        if not isinstance(items, list):
            return []
        out: list[TargetToken] = []
        for item in items:
            tok = TargetToken.from_settings_dict(item)
            if tok is not None:
                out.append(tok)
        return out[:_RECENTS_LIMIT]

    def _store_recent(self, token: TargetToken) -> None:
        settings = self._settings()
        if settings is None:
            return
        cur = self._load_recents()
        deduped = [t for t in cur if t.display_line() != token.display_line()]
        deduped.insert(0, token)
        deduped = deduped[:_RECENTS_LIMIT]
        payload = [t.to_settings_dict() for t in deduped]
        try:
            settings.setValue(_RECENTS_KEY, json.dumps(payload, sort_keys=True))
        except Exception:
            return


__all__ = ["TargetFieldWidget", "TargetToken"]
