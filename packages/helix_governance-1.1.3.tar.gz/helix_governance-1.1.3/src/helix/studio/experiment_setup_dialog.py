from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPalette, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QGraphicsOpacityEffect,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QMenu,
    QScrollArea,
    QSpinBox,
    QDoubleSpinBox,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from helix import clock
from helix.gui.icon_resources import ensure_icon_resources_loaded
from helix.studio.experiment_setup_model import (
    CELL_CONTEXT_OPTIONS,
    DELIVERY_OPTIONS,
    EXPERIMENT_SCALE_OPTIONS,
    IntentCardMeta,
    MODALITY_OPTIONS,
    OFF_TARGET_BASIS_OPTIONS,
    OFF_TARGET_SCOPE_OPTIONS,
    OUTPUT_CLASS_OPTIONS,
    PRIMARY_GOAL_OPTIONS,
    PRESETS,
    PRESET_LABELS,
    READOUT_LEVEL_OPTIONS,
    READOUT_OPTIONS,
    REFERENCE_BUILD_OPTIONS,
    TARGET_INTENT_OPTIONS,
    ExperimentSetupSelections,
    build_experiment_intent_spec,
    build_experiment_spec,
    initial_rail_segment_for_goal,
    intent_card_meta,
    load_policy_template,
    session_class_for_output_class,
)
from helix.studio.qtconcurrent_compat import QFutureWatcher, qt_run
from helix.studio.target_field import TargetFieldWidget
from helix.studio.target_refine_drawer import TargetRefineDrawer
from helix.studio.target_resolution import (
    OverlapGene,
    ScopeSelection,
    TargetLocusResolutionState,
    fetch_ensembl_gene_exon_summary,
    fetch_ensembl_region_overlaps,
    parse_locus_primary,
)
from helix.studio.ui_tokens import GAP_LG, GAP_XL, MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font, monospace_font
from helix.studio.ui.window_positioning import center_on_focused_window


ensure_icon_resources_loaded()

_TOKENS_PATH = Path(__file__).resolve().parents[3] / "helix" / "theme" / "tokens.json"
_STATUS_COLORS: dict[str, dict[str, str]] | None = None


def _active_theme_name() -> str:
    app = QApplication.instance()
    if app is not None:
        name = app.property("helix_theme_name")
        if isinstance(name, str) and name.strip():
            return name.strip()
    return os.environ.get("HELIX_THEME", "dark")


def _status_color_hex(kind: str) -> str | None:
    """Return the status color hex string for the active theme (warning/error/success/info)."""

    global _STATUS_COLORS
    if _STATUS_COLORS is None:
        try:
            data = json.loads(_TOKENS_PATH.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        mapping: dict[str, dict[str, str]] = {}
        themes = data.get("themes") if isinstance(data, dict) else None
        if isinstance(themes, dict):
            for theme_name, theme in themes.items():
                if not isinstance(theme, dict):
                    continue
                status = theme.get("status")
                if not isinstance(status, dict):
                    continue
                theme_map: dict[str, str] = {}
                for key in ("info", "success", "warning", "error"):
                    val = status.get(key)
                    if isinstance(val, str) and val.strip().startswith("#"):
                        theme_map[key] = val.strip()
                if theme_map:
                    mapping[str(theme_name)] = theme_map
        _STATUS_COLORS = mapping

    theme = _active_theme_name()
    return (_STATUS_COLORS.get(theme) or _STATUS_COLORS.get("dark") or {}).get(str(kind).strip().lower())


def _blend_color(bg: QColor, fg: QColor, *, fg_percent: int) -> QColor:
    p = max(0, min(100, int(fg_percent)))
    if p <= 0:
        return QColor(bg)
    if p >= 100:
        return QColor(fg)
    r = (bg.red() * (100 - p) + fg.red() * p + 50) // 100
    g = (bg.green() * (100 - p) + fg.green() * p + 50) // 100
    b = (bg.blue() * (100 - p) + fg.blue() * p + 50) // 100
    return QColor(int(r), int(g), int(b))


def _hex_rgb(color: QColor) -> str:
    return f"#{color.red():02X}{color.green():02X}{color.blue():02X}"


@dataclass(frozen=True)
class ExperimentSetupResult:
    experiment_intent_spec: dict[str, Any]
    experiment_spec: dict[str, Any]
    config_patch: dict[str, Any]
    initial_rail_segment_id: str
    session_class: str
    preset_id: str | None
    primary_goal: str
    output_class: str


class IntentCard(QFrame):
    activated = Signal(str)

    def __init__(self, meta: IntentCardMeta, *, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._meta = meta
        self._selected = False
        self._dimmed = False
        self._hovered = False

        self.setCursor(Qt.PointingHandCursor)
        self.setFrameShape(QFrame.NoFrame)
        self.setMinimumHeight(112)
        self._opacity_effect = QGraphicsOpacityEffect(self)
        self._opacity_effect.setOpacity(1.0)
        self.setGraphicsEffect(self._opacity_effect)

        layout = QVBoxLayout(self)
        self._layout = layout
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(6)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(8)

        title = QLabel(str(meta.title), self)
        title.setWordWrap(True)
        title.setStyleSheet("font-weight: 650; font-size: 14px; color: palette(window-text);")
        title.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._title = title
        header.addWidget(title, stretch=1)

        check = QLabel(self)
        check.setFixedSize(16, 16)
        check.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._check = check
        header.addWidget(check)
        layout.addLayout(header)

        decision = QLabel(str(meta.decision), self)
        decision.setWordWrap(True)
        decision.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._decision = decision
        layout.addWidget(decision)

        hint_text = str(meta.recommended_when or "").strip()
        # Keep height stable across cards for the 2-column grid, even when no hint applies.
        recommended = QLabel(hint_text if hint_text else " ", self)
        recommended.setWordWrap(True)
        recommended.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self._recommended = recommended
        layout.addWidget(recommended)

        meta_bar = QWidget(self)
        meta_bar_layout = QHBoxLayout(meta_bar)
        meta_bar_layout.setContentsMargins(0, 0, 0, 0)
        meta_bar_layout.setSpacing(6)

        self._tier_icon = QLabel(meta_bar)
        self._tier_icon.setFixedSize(12, 12)
        self._tier_icon.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        meta_bar_layout.addWidget(self._tier_icon)

        self._tier_text = QLabel(str(meta.evidence_required), meta_bar)
        self._tier_text.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        meta_bar_layout.addWidget(self._tier_text)

        self._dot_icon = QLabel(meta_bar)
        self._dot_icon.setFixedSize(8, 8)
        self._dot_icon.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        meta_bar_layout.addWidget(self._dot_icon)

        self._export_icon = QLabel(meta_bar)
        self._export_icon.setFixedSize(12, 12)
        self._export_icon.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        meta_bar_layout.addWidget(self._export_icon)

        self._export_text = QLabel(str(meta.export_posture), meta_bar)
        self._export_text.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        meta_bar_layout.addWidget(self._export_text)

        meta_bar_layout.addStretch(1)
        layout.addWidget(meta_bar)

        self._apply_visual_state()

    def preset_id(self) -> str:
        return str(self._meta.preset_id)

    def set_selected(self, selected: bool, *, dimmed: bool) -> None:
        self._selected = bool(selected)
        self._dimmed = bool(dimmed)
        self._apply_visual_state()

    def _apply_visual_state(self) -> None:
        opacity = 1.0
        if self._selected:
            opacity = 1.0
        elif self._hovered:
            opacity = 0.92
        elif self._dimmed:
            opacity = 0.82
        try:
            self._opacity_effect.setOpacity(float(opacity))
        except Exception:
            pass

        # Keep border width constant to avoid layout/sizeHint jitter when selection changes.
        border = "palette(highlight)" if self._selected else ("palette(mid)" if self._hovered else "transparent")
        width = 2
        bg = "palette(alternate-base)" if self._selected else "palette(base)"
        self.setStyleSheet(
            f"QFrame {{ border: {width}px solid {border}; border-radius: 10px; background: {bg}; }}"
            "QLabel { border: 0px; background: transparent; padding: 0px; }"
        )

        self._check.setPixmap(self._check_pixmap())

        title_color = "palette(window-text)"
        title_weight = 700 if self._selected else 650
        self._title.setStyleSheet(
            f"font-weight: {title_weight}; font-size: 14px; color: {title_color}; border: 0px;"
        )

        decision_color = "palette(window-text)"
        self._decision.setStyleSheet(f"color: {decision_color}; font-size: 12px; border: 0px;")

        minor_color = "palette(mid)"
        self._recommended.setStyleSheet(f"color: {minor_color}; font-size: 11px; font-style: italic; border: 0px;")
        self._tier_text.setStyleSheet(f"color: {minor_color}; font-size: 10px; border: 0px;")
        self._export_text.setStyleSheet(f"color: {minor_color}; font-size: 10px; border: 0px;")
        self._tier_icon.setPixmap(self._tinted_icon(":/icons/dna.svg", 12, QPalette.Mid))
        self._export_icon.setPixmap(self._tinted_icon(":/icons/export.svg", 12, QPalette.Mid))
        self._dot_icon.setPixmap(self._tinted_icon(":/icons/dot.svg", 8, QPalette.Mid))

    def _tinted_icon(self, resource_path: str, size: int, role: QPalette.ColorRole) -> QPixmap:
        base = QIcon(resource_path).pixmap(size, size)
        if base.isNull():
            return base
        tinted = QPixmap(base.size())
        tinted.setDevicePixelRatio(base.devicePixelRatio())
        tinted.fill(Qt.transparent)
        painter = QPainter(tinted)
        painter.drawPixmap(0, 0, base)
        painter.setCompositionMode(QPainter.CompositionMode_SourceIn)
        painter.fillRect(tinted.rect(), self.palette().color(role))
        painter.end()
        return tinted

    def _check_pixmap(self) -> QPixmap:
        if not self._selected:
            blank = QPixmap(16, 16)
            blank.fill(Qt.transparent)
            return blank
        return self._tinted_icon(":/icons/check.svg", 16, QPalette.Highlight)

    def enterEvent(self, event) -> None:  # type: ignore[override]
        self._hovered = True
        self._apply_visual_state()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # type: ignore[override]
        self._hovered = False
        self._apply_visual_state()
        super().leaveEvent(event)

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        try:
            if hasattr(event, "button") and event.button() == Qt.LeftButton:
                self.activated.emit(self.preset_id())
        except Exception:
            pass
        super().mousePressEvent(event)


class ExperimentSetupDialog(QDialog):
    """
    Goal-first experiment setup gate.

    Intentionally uses plain language in UI; internally it emits ExperimentIntentSpec + ExperimentSpec.
    """

    def __init__(self, *, start_mode: str | None = None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Define experiment intent")
        self.setModal(True)
        try:
            self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        except Exception:
            pass
        self.resize(1080, 720)
        try:
            self.setWindowState(self.windowState() | Qt.WindowMaximized)
        except Exception:
            pass
        self.setFont(base_font())

        self._start_mode = str(start_mode or "").strip().lower()
        self._created_at_utc = clock.utc_now_iso()
        self._result: ExperimentSetupResult | None = None
        self._active_preset_id: str | None = None
        self._maximize_once = True
        self._decision_question_user_edited = False
        self._setting_decision_question = False
        self._primary_goal_override_active = False
        self._sec2_auto_expanded = False
        self._target_refine_auto_prompted = False
        self._target_refine_auto_suppressed = False
        self._setting_readout_suggestion = False
        self._protein_req_user_edited = False
        self._phenotype_req_user_edited = False
        self._setting_auto_require = False
        self._readiness_primary_action_key: str | None = None
        self._target_locus_resolution: TargetLocusResolutionState | None = None
        self._target_locus_resolve_job = 0
        self._target_locus_gene_job = 0
        self._target_locus_resolve_watcher: QFutureWatcher | None = None
        self._target_locus_gene_watcher: QFutureWatcher | None = None
        self._updating_target_scope = False

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(10)

        title_row = QHBoxLayout()
        title_row.setContentsMargins(0, 0, 0, 0)
        title_row.setSpacing(10)
        title = QLabel("Define experiment intent", self)
        title.setStyleSheet("font-weight: 650; font-size: 16px; color: palette(window-text);")
        title_row.addWidget(title)
        title_row.addStretch(1)
        self._policy_badge = QPushButton("", self)
        self._policy_badge.setFlat(True)
        self._policy_badge.setCursor(Qt.PointingHandCursor)
        self._policy_badge.setToolTip("Click for export posture details")
        self._policy_badge.clicked.connect(self._on_policy_badge_clicked)
        self._policy_badge.setStyleSheet(
            "QPushButton { border: 1px solid palette(mid); border-radius: 10px; padding: 3px 8px; font-size: 12px; color: palette(window-text); background: palette(alternate-base); }"
            "QPushButton:hover { border-color: palette(highlight); }"
        )
        title_row.addWidget(self._policy_badge)
        root.addLayout(title_row)

        subtitle = QLabel(
            "Choose the intent. We'll set defaults for evidence, controls, and export readiness.",
            self,
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color: palette(mid); font-size: 12px;")
        root.addWidget(subtitle)

        intent_header = QHBoxLayout()
        intent_header.setContentsMargins(0, 0, 0, 0)
        intent_header.setSpacing(8)
        intent_title = QLabel("0) Choose intent template", self)
        intent_title.setStyleSheet("font-weight: 650; font-size: 13px; color: palette(window-text);")
        intent_header.addWidget(intent_title)
        intent_header.addStretch(1)
        intent_info = QPushButton("ⓘ What this unlocks", self)
        intent_info.setFlat(True)
        intent_info.setProperty("role", "link")
        intent_info.setCursor(Qt.PointingHandCursor)
        intent_info.clicked.connect(self._show_unlocks_panel)

        intent_decision_type = QPushButton("Edit intent", self)
        intent_decision_type.setFlat(True)
        intent_decision_type.setProperty("role", "muted")
        intent_decision_type.setCursor(Qt.PointingHandCursor)
        intent_decision_type.setEnabled(False)
        intent_decision_type.clicked.connect(self._on_primary_goal_change_clicked)
        self._primary_goal_change_btn = intent_decision_type
        intent_header.addWidget(intent_decision_type)
        intent_header.addWidget(intent_info)
        root.addLayout(intent_header)

        intent_cards = QWidget(self)
        intent_cards_layout = QGridLayout(intent_cards)
        intent_cards_layout.setContentsMargins(0, 0, 0, 0)
        intent_cards_layout.setHorizontalSpacing(GAP_LG)
        intent_cards_layout.setVerticalSpacing(GAP_LG)
        intent_cards_layout.setColumnStretch(0, 1)
        intent_cards_layout.setColumnStretch(1, 1)
        self._intent_cards: dict[str, IntentCard] = {}

        preset_ids = [k for k in PRESET_LABELS.keys() if k in PRESETS]
        cols = 2
        for idx, pid in enumerate(preset_ids):
            meta = intent_card_meta(pid)
            if meta is None:
                meta = IntentCardMeta(
                    preset_id=pid,
                    title=PRESET_LABELS.get(pid, pid),
                    decision=pid,
                    evidence_required="Tier A",
                    export_posture="Exploratory",
                )
            card = IntentCard(meta, parent=intent_cards)
            card.activated.connect(self._apply_preset)  # type: ignore[arg-type]
            self._intent_cards[str(pid)] = card
            r = idx // cols
            c = idx % cols
            intent_cards_layout.addWidget(card, r, c)
        root.addWidget(intent_cards)

        intent_note = QLabel("You can change intent later, but evidence requirements and exports will update.", self)
        intent_note.setWordWrap(True)
        intent_note.setStyleSheet("color: palette(mid); font-size: 12px;")
        root.addWidget(intent_note)

        workflow_hint = QLabel(
            "Typical workflow: Bulk knockout (feasibility) → Functional knockout → Clonal line (if needed)",
            self,
        )
        workflow_hint.setWordWrap(True)
        workflow_hint.setStyleSheet("color: palette(mid); font-size: 12px; font-style: italic;")
        root.addWidget(workflow_hint)

        root.addSpacing(6)
        divider = QFrame(self)
        divider.setFixedHeight(2)
        divider.setStyleSheet("background: palette(alternate-base); border-radius: 1px;")
        root.addWidget(divider)
        root.addSpacing(2)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(12)
        root.addLayout(body, stretch=1)

        # ---- Left: setup form (scrollable) ----
        left_scroll = QScrollArea(self)
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        self._left_scroll = left_scroll
        body.addWidget(left_scroll, stretch=3)

        left = QWidget(left_scroll)
        left_scroll.setWidget(left)
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(GAP_XL + 8)

        # Section 1: goal
        sec1 = QFrame(left)
        sec1.setFrameShape(QFrame.NoFrame)
        sec1_layout = QVBoxLayout(sec1)
        sec1_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        sec1_layout.setSpacing(SPACING_SMALL)

        self._sec1_toggle = QToolButton(sec1)
        self._sec1_toggle.setText("1) Goal and decision")
        self._sec1_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._sec1_toggle.setArrowType(Qt.RightArrow)
        self._sec1_toggle.setCheckable(True)
        self._sec1_toggle.setChecked(False)
        self._sec1_toggle.setStyleSheet(
            "QToolButton { border: 0px; padding: 10px 0px; font-weight: 700; font-size: 13px; color: palette(window-text); }"
            "QToolButton:disabled { color: palette(mid); }"
        )
        sec1_layout.addWidget(self._sec1_toggle)

        self._sec1_body = QWidget(sec1)
        self._sec1_body.setVisible(False)
        sec1_body_layout = QVBoxLayout(self._sec1_body)
        sec1_body_layout.setContentsMargins(0, 0, 0, 0)
        sec1_body_layout.setSpacing(SPACING_SMALL)

        form1 = QFormLayout()
        form1.setHorizontalSpacing(SPACING_MEDIUM)
        form1.setVerticalSpacing(SPACING_SMALL)

        self._primary_goal = QComboBox(sec1)
        for key, label in PRIMARY_GOAL_OPTIONS:
            self._primary_goal.addItem(label, key)
        goal_field = QWidget(sec1)
        goal_field_layout = QVBoxLayout(goal_field)
        goal_field_layout.setContentsMargins(0, 0, 0, 0)
        goal_field_layout.setSpacing(6)
        goal_display = QWidget(goal_field)
        goal_display_layout = QHBoxLayout(goal_display)
        goal_display_layout.setContentsMargins(0, 0, 0, 0)
        goal_display_layout.setSpacing(8)
        self._primary_goal_readonly = QLabel("", goal_display)
        self._primary_goal_readonly.setWordWrap(True)
        self._primary_goal_readonly.setStyleSheet("color: palette(window-text); font-size: 12px;")
        self._primary_goal.setVisible(False)
        goal_display_layout.addWidget(self._primary_goal_readonly, stretch=1)
        goal_field_layout.addWidget(goal_display)
        goal_field_layout.addWidget(self._primary_goal)
        form1.addRow("Decision type", goal_field)

        self._decision_question = QLineEdit(sec1)
        self._decision_question.setPlaceholderText("Auto-generated decision statement (editable)")
        self._decision_question.setToolTip("Decision statement used as the experiment's intent contract header.")
        self._decision_question.textEdited.connect(self._on_decision_question_text_edited)  # type: ignore[arg-type]
        form1.addRow("Decision", self._decision_question)
        sec1_body_layout.addLayout(form1)

        # Contract-critical: target should be hard to miss.
        target_contract = QFrame(sec1)
        target_contract.setFrameShape(QFrame.NoFrame)
        target_contract.setStyleSheet("QFrame { border: 0px; border-radius: 12px; background: palette(base); }")
        self._target_contract = target_contract
        target_contract_layout = QVBoxLayout(target_contract)
        target_contract_layout.setContentsMargins(10, 10, 10, 10)
        target_contract_layout.setSpacing(6)

        target_header = QHBoxLayout()
        target_header.setContentsMargins(0, 0, 0, 0)
        target_header.setSpacing(8)
        target_label = QLabel("Target", target_contract)
        target_label.setStyleSheet("font-weight: 650; font-size: 12px; color: palette(window-text);")
        target_header.addWidget(target_label)
        target_header.addStretch(1)
        self._target_required_pill = QLabel("Required", target_contract)
        self._target_required_pill.setStyleSheet(
            "border: 0px; border-radius: 10px; padding: 2px 8px; font-size: 11px; color: palette(window); background: palette(highlight);"
        )
        target_header.addWidget(self._target_required_pill)
        target_contract_layout.addLayout(target_header)

        self._target_field = TargetFieldWidget(placeholder="Search gene, locus, or variant…", parent=target_contract)
        self._target_field.setToolTip("Required to define locus and isoform scope for design and export readiness.")
        self._target_field.refineRequested.connect(self._open_target_refine_drawer)  # type: ignore[arg-type]
        target_contract_layout.addWidget(self._target_field)

        self._target_contract_hint = QLabel("Required for export.", target_contract)
        self._target_contract_hint.setWordWrap(True)
        self._target_contract_hint.setStyleSheet("color: palette(mid); font-size: 12px;")
        target_contract_layout.addWidget(self._target_contract_hint)

        # ---- Coordinate target resolution (locus → features → scope) ----
        target_res = QFrame(target_contract)
        target_res.setFrameShape(QFrame.NoFrame)
        target_res.setStyleSheet("QFrame { border: 0px; border-radius: 10px; background: palette(alternate-base); }")
        target_res.hide()
        self._target_resolution_frame = target_res

        res_layout = QVBoxLayout(target_res)
        res_layout.setContentsMargins(10, 10, 10, 10)
        res_layout.setSpacing(6)

        res_title = QLabel("Target resolution", target_res)
        res_title.setStyleSheet("font-weight: 650; font-size: 12px; color: palette(window-text);")
        res_layout.addWidget(res_title)

        res_hint = QLabel(
            "Advanced: define target by genomic coordinates. Helix will resolve overlaps and require an explicit scope.",
            target_res,
        )
        res_hint.setWordWrap(True)
        res_hint.setStyleSheet("color: palette(mid); font-size: 12px;")
        res_layout.addWidget(res_hint)

        self._target_resolution_region = QLabel("", target_res)
        self._target_resolution_region.setWordWrap(True)
        self._target_resolution_region.setStyleSheet("color: palette(window-text); font-size: 12px;")
        res_layout.addWidget(self._target_resolution_region)

        self._target_resolution_overlaps = QLabel("", target_res)
        self._target_resolution_overlaps.setWordWrap(True)
        self._target_resolution_overlaps.setStyleSheet("color: palette(mid); font-size: 12px;")
        res_layout.addWidget(self._target_resolution_overlaps)

        scope_row = QWidget(target_res)
        scope_layout = QHBoxLayout(scope_row)
        scope_layout.setContentsMargins(0, 0, 0, 0)
        scope_layout.setSpacing(8)
        scope_label = QLabel("Scope", scope_row)
        scope_label.setStyleSheet("color: palette(window-text); font-size: 12px;")
        scope_layout.addWidget(scope_label)

        self._target_scope = QComboBox(scope_row)
        self._target_scope.addItem("Select scope…", "unset")
        self._target_scope.setEnabled(False)
        self._target_scope.currentIndexChanged.connect(self._on_target_scope_changed)  # type: ignore[arg-type]
        scope_layout.addWidget(self._target_scope, stretch=1)
        res_layout.addWidget(scope_row)

        self._target_scope_custom = QLineEdit(target_res)
        self._target_scope_custom.setPlaceholderText("Custom feature label (optional)")
        self._target_scope_custom.textChanged.connect(self._on_target_scope_custom_changed)  # type: ignore[arg-type]
        self._target_scope_custom.hide()
        res_layout.addWidget(self._target_scope_custom)

        self._target_gene_summary = QLabel("", target_res)
        self._target_gene_summary.setWordWrap(True)
        self._target_gene_summary.setStyleSheet("color: palette(window-text); font-size: 12px;")
        self._target_gene_summary.hide()
        res_layout.addWidget(self._target_gene_summary)

        self._target_compatibility = QLabel("", target_res)
        self._target_compatibility.setWordWrap(True)
        self._target_compatibility.setStyleSheet("color: palette(mid); font-size: 12px;")
        res_layout.addWidget(self._target_compatibility)

        target_contract_layout.addWidget(target_res)

        sec1_body_layout.addWidget(target_contract)

        sec1_layout.addWidget(self._sec1_body)

        left_layout.addWidget(sec1)

        # Section 2: hypothesis + success criteria
        sec2 = QFrame(left)
        sec2.setFrameShape(QFrame.NoFrame)
        sec2_layout = QVBoxLayout(sec2)
        sec2_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        sec2_layout.setSpacing(SPACING_SMALL)

        self._sec2_toggle = QToolButton(sec2)
        self._sec2_toggle.setText("2) Hypothesis and success criteria")
        self._sec2_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._sec2_toggle.setArrowType(Qt.RightArrow)
        self._sec2_toggle.setCheckable(True)
        self._sec2_toggle.setChecked(False)
        self._sec2_toggle.setStyleSheet(
            "QToolButton { border: 0px; padding: 10px 0px; font-weight: 700; font-size: 13px; color: palette(window-text); }"
            "QToolButton:disabled { color: palette(mid); }"
        )
        sec2_layout.addWidget(self._sec2_toggle)

        self._sec2_body = QWidget(sec2)
        self._sec2_body.setVisible(False)
        sec2_body_layout = QVBoxLayout(self._sec2_body)
        sec2_body_layout.setContentsMargins(0, 0, 0, 0)
        sec2_body_layout.setSpacing(SPACING_SMALL)

        form2 = QFormLayout()
        form2.setHorizontalSpacing(SPACING_MEDIUM)
        form2.setVerticalSpacing(SPACING_SMALL)

        self._hypothesis = QLineEdit(sec2)
        self._hypothesis.setPlaceholderText("One sentence hypothesis (recommended)")
        form2.addRow("Hypothesis", self._hypothesis)

        # Structured success criteria (fast defaults; still editable).
        tier_a = QLabel("DNA evidence (Tier A)", sec2)
        tier_a.setStyleSheet("font-weight: 650; color: palette(window-text);")
        form2.addRow("", tier_a)

        self._crit_edit_rate_enabled = QCheckBox("Intended edit rate ≥", sec2)
        self._crit_edit_rate_enabled.setChecked(True)
        self._crit_edit_rate_pct = QDoubleSpinBox(sec2)
        self._crit_edit_rate_pct.setRange(0.0, 100.0)
        self._crit_edit_rate_pct.setDecimals(0)
        self._crit_edit_rate_pct.setValue(80.0)
        self._crit_edit_rate_pct.setSuffix("%")
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        row.addWidget(self._crit_edit_rate_enabled)
        row.addWidget(self._crit_edit_rate_pct)
        row.addStretch(1)
        form2.addRow("Success criteria", row)

        self._crit_offtarget_enabled = QCheckBox("High-risk coding off-targets ≤", sec2)
        self._crit_offtarget_enabled.setChecked(True)
        self._crit_offtarget_max_count = QSpinBox(sec2)
        self._crit_offtarget_max_count.setRange(0, 10_000)
        self._crit_offtarget_max_count.setSingleStep(1)
        self._crit_offtarget_max_count.setValue(0)
        self._crit_offtarget_max_count.setToolTip(
            "High-risk is policy-defined. This is a coarse gate: treat off-target screening as genome-wide and context-dependent."
        )
        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        row2.setSpacing(8)
        row2.addWidget(self._crit_offtarget_enabled)
        row2.addWidget(self._crit_offtarget_max_count)
        row2.addStretch(1)
        form2.addRow("", row2)

        meta_row_widget = QWidget(sec2)
        meta_row = QHBoxLayout(meta_row_widget)
        meta_row.setContentsMargins(0, 0, 0, 0)
        meta_row.setSpacing(8)
        basis_lbl = QLabel("Basis", sec2)
        basis_lbl.setStyleSheet("color: palette(mid); font-size: 12px;")
        self._offtarget_basis = QComboBox(sec2)
        for key, label in OFF_TARGET_BASIS_OPTIONS:
            self._offtarget_basis.addItem(label, key)
        scope_lbl = QLabel("Scope", sec2)
        scope_lbl.setStyleSheet("color: palette(mid); font-size: 12px;")
        self._offtarget_scope = QComboBox(sec2)
        for key, label in OFF_TARGET_SCOPE_OPTIONS:
            self._offtarget_scope.addItem(label, key)
        self._offtarget_method = QComboBox(sec2)
        self._offtarget_method.setEditable(True)
        self._offtarget_method.addItem("Mismatch v1", "offtarget_mismatch_v1")
        try:
            le = self._offtarget_method.lineEdit()
            if le is not None:
                le.setPlaceholderText("Model / method (e.g., CFD vX, GUIDE-seq, WGS…)")
        except Exception:
            pass
        self._offtarget_method.setToolTip(
            "Off-target model/provider used for scoring.\n\n"
            "Mismatch v1 is the default policy baseline (mismatch-based search + scoring). You can change this later; the chosen method is recorded in the intent contract."
        )
        self._offtarget_scope.setToolTip(
            "Which loci count toward off-target risk in this intent.\n\n"
            "This is a policy default, not immutable—you can widen scope later (e.g., genome-wide) as screening matures."
        )
        meta_row.addWidget(basis_lbl)
        meta_row.addWidget(self._offtarget_basis)
        meta_row.addWidget(scope_lbl)
        meta_row.addWidget(self._offtarget_scope)
        meta_row.addWidget(self._offtarget_method, stretch=1)
        form2.addRow("", meta_row_widget)
        self._offtarget_meta_row = meta_row_widget

        self._crit_editable = QCheckBox("Editable within declared modality constraints", sec2)
        self._crit_editable.setChecked(True)
        form2.addRow("", self._crit_editable)

        # Tier B (Protein) — progressive disclosure (only expand when required).
        protein_header_widget = QWidget(sec2)
        protein_header = QHBoxLayout(protein_header_widget)
        protein_header.setContentsMargins(0, 0, 0, 0)
        protein_header.setSpacing(8)
        protein_header_label = QLabel("Protein evidence (Tier B)", sec2)
        protein_header_label.setStyleSheet("font-weight: 650; color: palette(window-text);")
        protein_header.addWidget(protein_header_label)
        protein_header.addStretch(1)
        self._protein_req = QComboBox(sec2)
        self._protein_req.addItem("Not required", "not_required")
        self._protein_req.addItem("Required", "required")
        self._protein_req.currentIndexChanged.connect(self._on_protein_req_changed)  # type: ignore[arg-type]
        protein_header.addWidget(self._protein_req)
        form2.addRow("", protein_header_widget)
        self._protein_header_row = protein_header_widget

        self._protein_rationale = QLabel("", sec2)
        self._protein_rationale.setWordWrap(True)
        self._protein_rationale.setStyleSheet("color: palette(mid); font-size: 12px; font-style: italic;")
        form2.addRow("", self._protein_rationale)

        self._crit_protein_loss_pct = QDoubleSpinBox(sec2)
        self._crit_protein_loss_pct.setRange(0.0, 100.0)
        self._crit_protein_loss_pct.setDecimals(0)
        self._crit_protein_loss_pct.setValue(70.0)
        self._crit_protein_loss_pct.setSuffix("%")
        self._protein_day_label = QLabel("Measure at: Day", sec2)
        self._protein_day_label.setStyleSheet("color: palette(mid); font-size: 12px;")
        self._crit_protein_day = QSpinBox(sec2)
        self._crit_protein_day.setRange(1, 120)
        self._crit_protein_day.setSingleStep(1)
        self._crit_protein_day.setValue(7)
        self._protein_day_suffix = QLabel("(post-delivery)", sec2)
        self._protein_day_suffix.setStyleSheet("color: palette(mid); font-size: 12px;")
        protein_details_widget = QWidget(sec2)
        protein_row = QHBoxLayout(protein_details_widget)
        protein_row.setContentsMargins(0, 0, 0, 0)
        protein_row.setSpacing(8)
        protein_row.addWidget(self._crit_protein_loss_pct)
        protein_row.addWidget(self._protein_day_label)
        protein_row.addWidget(self._crit_protein_day)
        protein_row.addWidget(self._protein_day_suffix)
        protein_row.addStretch(1)
        self._protein_loss_label = QLabel("Protein loss", sec2)
        form2.addRow(self._protein_loss_label, protein_details_widget)
        self._protein_details_row = protein_details_widget

        # Tier C (Phenotype) — collapsed by default.
        phenotype_header_widget = QWidget(sec2)
        phenotype_header = QHBoxLayout(phenotype_header_widget)
        phenotype_header.setContentsMargins(0, 0, 0, 0)
        phenotype_header.setSpacing(8)
        phenotype_header_label = QLabel("Phenotype evidence (Tier C)", sec2)
        phenotype_header_label.setStyleSheet("font-weight: 650; color: palette(window-text);")
        phenotype_header.addWidget(phenotype_header_label)
        phenotype_header.addStretch(1)
        self._phenotype_req = QComboBox(sec2)
        self._phenotype_req.addItem("Not required", "not_required")
        self._phenotype_req.addItem("Required", "required")
        self._phenotype_req.currentIndexChanged.connect(self._on_phenotype_req_changed)  # type: ignore[arg-type]
        phenotype_header.addWidget(self._phenotype_req)
        form2.addRow("", phenotype_header_widget)
        self._phenotype_header_row = phenotype_header_widget

        self._phenotype_rationale = QLabel("", sec2)
        self._phenotype_rationale.setWordWrap(True)
        self._phenotype_rationale.setStyleSheet("color: palette(mid); font-size: 12px; font-style: italic;")
        form2.addRow("", self._phenotype_rationale)

        self._crit_phenotype_effect = QDoubleSpinBox(sec2)
        self._crit_phenotype_effect.setRange(0.0, 10_000.0)
        self._crit_phenotype_effect.setDecimals(2)
        self._crit_phenotype_effect.setValue(2.0)
        self._phenotype_day_label = QLabel("Measure at: Day", sec2)
        self._phenotype_day_label.setStyleSheet("color: palette(mid); font-size: 12px;")
        self._crit_phenotype_day = QSpinBox(sec2)
        self._crit_phenotype_day.setRange(1, 120)
        self._crit_phenotype_day.setSingleStep(1)
        self._crit_phenotype_day.setValue(7)
        self._phenotype_day_suffix = QLabel("(post-delivery)", sec2)
        self._phenotype_day_suffix.setStyleSheet("color: palette(mid); font-size: 12px;")
        phenotype_details_widget = QWidget(sec2)
        phenotype_row = QHBoxLayout(phenotype_details_widget)
        phenotype_row.setContentsMargins(0, 0, 0, 0)
        phenotype_row.setSpacing(8)
        phenotype_row.addWidget(self._crit_phenotype_effect)
        phenotype_row.addWidget(self._phenotype_day_label)
        phenotype_row.addWidget(self._crit_phenotype_day)
        phenotype_row.addWidget(self._phenotype_day_suffix)
        phenotype_row.addStretch(1)
        self._phenotype_label = QLabel("Phenotype", sec2)
        form2.addRow(self._phenotype_label, phenotype_details_widget)
        self._phenotype_details_row = phenotype_details_widget

        self._ko_warning = QLabel(
            "Note: DNA-level edit rates do not guarantee functional knockout. Add protein/phenotype success criteria when needed.",
            sec2,
        )
        self._ko_warning.setWordWrap(True)
        self._ko_warning.setStyleSheet("color: palette(mid); font-size: 12px;")
        form2.addRow("", self._ko_warning)

        sec2_body_layout.addLayout(form2)
        sec2_layout.addWidget(self._sec2_body)
        left_layout.addWidget(sec2)

        # Section 3: modality + constraints
        sec3 = QFrame(left)
        sec3.setFrameShape(QFrame.NoFrame)
        sec3_layout = QVBoxLayout(sec3)
        sec3_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        sec3_layout.setSpacing(SPACING_SMALL)

        self._sec3_toggle = QToolButton(sec3)
        self._sec3_toggle.setText("3) Modality and constraints")
        self._sec3_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._sec3_toggle.setArrowType(Qt.RightArrow)
        self._sec3_toggle.setCheckable(True)
        self._sec3_toggle.setChecked(False)
        self._sec3_toggle.setStyleSheet(
            "QToolButton { border: 0px; padding: 10px 0px; font-weight: 700; font-size: 13px; color: palette(window-text); }"
            "QToolButton:disabled { color: palette(mid); }"
        )
        sec3_layout.addWidget(self._sec3_toggle)

        self._sec3_body = QWidget(sec3)
        self._sec3_body.setVisible(False)
        sec3_body_layout = QVBoxLayout(self._sec3_body)
        sec3_body_layout.setContentsMargins(0, 0, 0, 0)
        sec3_body_layout.setSpacing(SPACING_SMALL)

        form3 = QFormLayout()
        form3.setHorizontalSpacing(SPACING_MEDIUM)
        form3.setVerticalSpacing(SPACING_SMALL)

        self._modality = QComboBox(sec3)
        for key, label in MODALITY_OPTIONS:
            self._modality.addItem(label, key)
        form3.addRow("Modality", self._modality)

        self._target_intent = QComboBox(sec3)
        for key, label in TARGET_INTENT_OPTIONS:
            self._target_intent.addItem(label, key)
        form3.addRow("Target type", self._target_intent)

        self._reference_build = QComboBox(sec3)
        for key, label in REFERENCE_BUILD_OPTIONS:
            self._reference_build.addItem(label, key)
        form3.addRow("Reference build", self._reference_build)

        self._delivery = QComboBox(sec3)
        for key, label in DELIVERY_OPTIONS:
            self._delivery.addItem(label, key)
        self._delivery.setToolTip("Declared delivery method used for feasibility assumptions and auditability.")
        form3.addRow("Delivery method", self._delivery)

        self._cell_context = QComboBox(sec3)
        for key, label in CELL_CONTEXT_OPTIONS:
            self._cell_context.addItem(label, key)
        self._cell_context.setToolTip("Context bucket used for feasibility assumptions (e.g., easy vs hard to edit).")
        form3.addRow("Cell context", self._cell_context)

        self._experiment_scale = QComboBox(sec3)
        for key, label in EXPERIMENT_SCALE_OPTIONS:
            self._experiment_scale.addItem(label, key)
        form3.addRow("Scale", self._experiment_scale)

        sec3_body_layout.addLayout(form3)
        sec3_layout.addWidget(self._sec3_body)
        left_layout.addWidget(sec3)

        # Section 4: readout plan
        sec4 = QFrame(left)
        sec4.setFrameShape(QFrame.NoFrame)
        sec4_layout = QVBoxLayout(sec4)
        sec4_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        sec4_layout.setSpacing(SPACING_SMALL)

        self._sec4_toggle = QToolButton(sec4)
        self._sec4_toggle.setText("4) Readout plan")
        self._sec4_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._sec4_toggle.setArrowType(Qt.RightArrow)
        self._sec4_toggle.setCheckable(True)
        self._sec4_toggle.setChecked(False)
        self._sec4_toggle.setStyleSheet(
            "QToolButton { border: 0px; padding: 10px 0px; font-weight: 700; font-size: 13px; color: palette(window-text); }"
            "QToolButton:disabled { color: palette(mid); }"
        )
        sec4_layout.addWidget(self._sec4_toggle)

        self._sec4_body = QWidget(sec4)
        self._sec4_body.setVisible(False)
        sec4_body_layout = QVBoxLayout(self._sec4_body)
        sec4_body_layout.setContentsMargins(0, 0, 0, 0)
        sec4_body_layout.setSpacing(SPACING_SMALL)

        form4 = QFormLayout()
        form4.setHorizontalSpacing(SPACING_MEDIUM)
        form4.setVerticalSpacing(SPACING_SMALL)

        self._readout_level = QComboBox(sec4)
        for key, label in READOUT_LEVEL_OPTIONS:
            self._readout_level.addItem(label, key)
        self._readout_level.setToolTip("Must cover the highest required evidence tier. DNA-only supports Tier A only.")
        form4.addRow("Readout level", self._readout_level)

        self._readout = QComboBox(sec4)
        for key, label, _measurement in READOUT_OPTIONS:
            self._readout.addItem(label, key)
        form4.addRow("Primary measurement", self._readout)
        sec4_body_layout.addLayout(form4)
        self._readout_hint = QLabel("", sec4)
        self._readout_hint.setWordWrap(True)
        self._readout_hint.setStyleSheet("color: palette(mid); font-size: 12px;")
        sec4_body_layout.addWidget(self._readout_hint)
        self._readout_sync = QLabel("", sec4)
        self._readout_sync.setWordWrap(True)
        self._readout_sync.setTextFormat(Qt.RichText)
        self._readout_sync.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self._readout_sync.setOpenExternalLinks(False)
        self._readout_sync.setStyleSheet("color: palette(window-text); font-size: 12px;")
        self._readout_sync.linkActivated.connect(self._on_readout_link_activated)
        sec4_body_layout.addWidget(self._readout_sync)
        sec4_layout.addWidget(self._sec4_body)
        left_layout.addWidget(sec4)

        # Section 5: governance
        sec5 = QFrame(left)
        sec5.setFrameShape(QFrame.NoFrame)
        sec5_layout = QVBoxLayout(sec5)
        sec5_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        sec5_layout.setSpacing(SPACING_SMALL)

        self._sec5_toggle = QToolButton(sec5)
        self._sec5_toggle.setText("5) Provenance & export policy")
        self._sec5_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._sec5_toggle.setArrowType(Qt.RightArrow)
        self._sec5_toggle.setCheckable(True)
        self._sec5_toggle.setChecked(False)
        self._sec5_toggle.setStyleSheet(
            "QToolButton { border: 0px; padding: 10px 0px; font-weight: 700; font-size: 13px; color: palette(window-text); }"
            "QToolButton:disabled { color: palette(mid); }"
        )
        sec5_layout.addWidget(self._sec5_toggle)

        self._sec5_body = QWidget(sec5)
        self._sec5_body.setVisible(False)
        sec5_body_layout = QVBoxLayout(self._sec5_body)
        sec5_body_layout.setContentsMargins(0, 0, 0, 0)
        sec5_body_layout.setSpacing(SPACING_SMALL)

        self._output_class = QComboBox(sec5)
        for key, label in OUTPUT_CLASS_OPTIONS:
            self._output_class.addItem(label, key)
        sec5_body_layout.addWidget(self._output_class)
        self._policy_effect = QLabel("", sec5)
        self._policy_effect.setWordWrap(True)
        self._policy_effect.setStyleSheet("color: palette(mid); font-size: 12px;")
        sec5_body_layout.addWidget(self._policy_effect)

        gov_hint = QLabel(
            "Exports are blocked until required intent + readiness gates pass. This selection controls default policy and labeling.",
            sec5,
        )
        gov_hint.setWordWrap(True)
        gov_hint.setStyleSheet("color: palette(mid); font-size: 12px;")
        sec5_body_layout.addWidget(gov_hint)

        sec5_layout.addWidget(self._sec5_body)

        left_layout.addWidget(sec5)

        # Progressive disclosure: sections collapse by default and expand on demand.
        self._sections: dict[str, tuple[QToolButton, QWidget]] = {
            "sec1": (self._sec1_toggle, self._sec1_body),
            "sec2": (self._sec2_toggle, self._sec2_body),
            "sec3": (self._sec3_toggle, self._sec3_body),
            "sec4": (self._sec4_toggle, self._sec4_body),
            "sec5": (self._sec5_toggle, self._sec5_body),
        }
        for key, (toggle, _body) in self._sections.items():
            toggle.toggled.connect(lambda checked, k=key: self._on_section_toggled(k, bool(checked)))  # type: ignore[arg-type]
            self._on_section_toggled(key, False)

        left_layout.addStretch(1)

        # ---- Right: unlocks + live preview ----
        preview_wrap = QVBoxLayout()
        preview_wrap.setContentsMargins(0, 0, 0, 0)
        preview_wrap.setSpacing(6)

        readiness_frame = QFrame(self)
        readiness_frame.setFrameShape(QFrame.NoFrame)
        readiness_frame.setStyleSheet("QFrame { border: 0px; border-radius: 10px; background: palette(alternate-base); }")
        readiness_layout = QVBoxLayout(readiness_frame)
        readiness_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        readiness_layout.setSpacing(SPACING_SMALL)
        readiness_title = QLabel("Readiness", readiness_frame)
        readiness_title.setStyleSheet("font-weight: 650; font-size: 13px; color: palette(window-text);")
        readiness_layout.addWidget(readiness_title)

        # Dominant gate surface.
        self._readiness_status = QLabel("", readiness_frame)
        self._readiness_status.setWordWrap(True)
        self._readiness_status.setStyleSheet("font-weight: 700; font-size: 16px; color: palette(window-text);")
        readiness_layout.addWidget(self._readiness_status)

        self._readiness_progress = QProgressBar(readiness_frame)
        self._readiness_progress.setRange(0, 100)
        self._readiness_progress.setValue(0)
        self._readiness_progress.setTextVisible(False)
        self._readiness_progress.setFixedHeight(10)
        self._readiness_progress.setStyleSheet(
            "QProgressBar { border: 0px; border-radius: 6px; background: palette(base); }"
            "QProgressBar::chunk { border-radius: 6px; background: palette(highlight); }"
        )
        readiness_layout.addWidget(self._readiness_progress)

        blocker_row = QHBoxLayout()
        blocker_row.setContentsMargins(0, 0, 0, 0)
        blocker_row.setSpacing(8)

        self._readiness_blocker_pill = QLabel("", readiness_frame)
        self._readiness_blocker_pill.setStyleSheet(
            "border: 0px; border-radius: 10px; padding: 3px 10px; font-size: 12px; font-weight: 650; color: palette(window); background: palette(highlight);"
        )
        blocker_row.addWidget(self._readiness_blocker_pill)
        blocker_row.addStretch(1)

        self._readiness_details_toggle = QPushButton("Show details", readiness_frame)
        self._readiness_details_toggle.setFlat(True)
        self._readiness_details_toggle.setProperty("role", "link")
        self._readiness_details_toggle.setCursor(Qt.PointingHandCursor)
        self._readiness_details_toggle.clicked.connect(self._toggle_readiness_details)  # type: ignore[arg-type]
        blocker_row.addWidget(self._readiness_details_toggle)
        readiness_layout.addLayout(blocker_row)

        readiness_actions = QHBoxLayout()
        readiness_actions.setContentsMargins(0, 0, 0, 0)
        readiness_actions.setSpacing(10)
        self._readiness_primary_action = QPushButton("Define target", readiness_frame)
        self._readiness_primary_action.setProperty("role", "btnPrimary")
        self._readiness_primary_action.clicked.connect(self._on_readiness_primary_action_clicked)
        readiness_actions.addWidget(self._readiness_primary_action)
        readiness_actions.addStretch(1)
        readiness_layout.addLayout(readiness_actions)

        self._readiness_details_container = QWidget(readiness_frame)
        self._readiness_details_container.setVisible(False)
        details_layout = QVBoxLayout(self._readiness_details_container)
        details_layout.setContentsMargins(0, 0, 0, 0)
        details_layout.setSpacing(SPACING_SMALL)

        chips_row = QHBoxLayout()
        chips_row.setContentsMargins(0, 0, 0, 0)
        chips_row.setSpacing(6)

        self._modality_chip = QPushButton("", readiness_frame)
        self._modality_chip.setFlat(True)
        self._modality_chip.setProperty("role", "chip")
        self._modality_chip.setCursor(Qt.PointingHandCursor)
        self._modality_chip.setToolTip("Declared modality (assumption) used to interpret feasibility and policy defaults.")
        self._modality_chip.clicked.connect(self._focus_modality_field)
        chips_row.addWidget(self._modality_chip)

        self._target_type_chip = QPushButton("", readiness_frame)
        self._target_type_chip.setFlat(True)
        self._target_type_chip.setProperty("role", "chip")
        self._target_type_chip.setCursor(Qt.PointingHandCursor)
        self._target_type_chip.setToolTip("Declared target type (assumption) used to set defaults for evidence and constraints.")
        self._target_type_chip.clicked.connect(self._focus_target_intent_field)
        chips_row.addWidget(self._target_type_chip)

        self._delivery_chip = QPushButton("", readiness_frame)
        self._delivery_chip.setFlat(True)
        self._delivery_chip.setProperty("role", "chip")
        self._delivery_chip.setCursor(Qt.PointingHandCursor)
        self._delivery_chip.setToolTip("Delivery assumptions affect thresholds and feasibility; this can be revised later.")
        self._delivery_chip.clicked.connect(self._focus_delivery_field)
        chips_row.addWidget(self._delivery_chip)

        chips_row.addStretch(1)
        details_layout.addLayout(chips_row)

        self._intent_completeness = QLabel("", readiness_frame)
        self._intent_completeness.setWordWrap(True)
        self._intent_completeness.setStyleSheet("color: palette(mid); font-size: 12px;")
        details_layout.addWidget(self._intent_completeness)

        self._readiness = QLabel("", readiness_frame)
        self._readiness.setWordWrap(True)
        self._readiness.setTextFormat(Qt.RichText)
        self._readiness.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self._readiness.setOpenExternalLinks(False)
        self._readiness.linkActivated.connect(self._on_readiness_link_activated)
        self._readiness.setStyleSheet("color: palette(window-text); font-size: 12px;")
        details_layout.addWidget(self._readiness)

        self._readiness_target_policy_context = QLabel(
            "Target defines the genomic locus and isoform scope used to enforce evidence and off-target policies.",
            readiness_frame,
        )
        self._readiness_target_policy_context.setWordWrap(True)
        self._readiness_target_policy_context.setStyleSheet("color: palette(mid); font-size: 12px;")
        details_layout.addWidget(self._readiness_target_policy_context)

        self._readiness_target_help = QPushButton("Why is target required?", readiness_frame)
        self._readiness_target_help.setFlat(True)
        self._readiness_target_help.setProperty("role", "link")
        self._readiness_target_help.setCursor(Qt.PointingHandCursor)
        self._readiness_target_help.clicked.connect(self._show_target_required_help)
        details_layout.addWidget(self._readiness_target_help)

        self._export_status = QLabel("", readiness_frame)
        self._export_status.setWordWrap(True)
        self._export_status.setTextFormat(Qt.RichText)
        self._export_status.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self._export_status.setOpenExternalLinks(False)
        self._export_status.linkActivated.connect(self._on_readiness_link_activated)
        self._export_status.setStyleSheet("color: palette(window-text); font-size: 12px;")
        details_layout.addWidget(self._export_status)

        readiness_layout.addWidget(self._readiness_details_container)
        preview_wrap.addWidget(readiness_frame)

        unlocks_frame = QFrame(self)
        unlocks_frame.setFrameShape(QFrame.NoFrame)
        unlocks_frame.setStyleSheet("QFrame { border: 0px; border-radius: 10px; background: palette(alternate-base); }")
        unlocks_layout = QVBoxLayout(unlocks_frame)
        unlocks_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        unlocks_layout.setSpacing(SPACING_SMALL)
        unlocks_title_row = QHBoxLayout()
        unlocks_title_row.setContentsMargins(0, 0, 0, 0)
        unlocks_title_row.setSpacing(8)
        unlocks_title = QLabel("What this decision unlocks", unlocks_frame)
        unlocks_title.setStyleSheet("font-weight: 650; font-size: 13px; color: palette(window-text);")
        unlocks_title_row.addWidget(unlocks_title)
        self._unlocks = QLabel("", unlocks_frame)
        self._unlocks.setWordWrap(True)
        self._unlocks.setStyleSheet("color: palette(window-text); font-size: 12px;")
        self._unlocks.setVisible(False)
        unlocks_title_row.addStretch(1)
        self._show_unlocks = QCheckBox("Show", unlocks_frame)
        self._show_unlocks.setChecked(False)
        self._show_unlocks.toggled.connect(lambda checked: self._unlocks.setVisible(bool(checked)))  # type: ignore[arg-type]
        unlocks_title_row.addWidget(self._show_unlocks)
        unlocks_layout.addLayout(unlocks_title_row)
        unlocks_layout.addWidget(self._unlocks)
        preview_wrap.addWidget(unlocks_frame)

        summary_frame = QFrame(self)
        summary_frame.setFrameShape(QFrame.NoFrame)
        summary_frame.setStyleSheet("QFrame { border: 0px; border-radius: 10px; background: palette(alternate-base); }")
        summary_layout = QVBoxLayout(summary_frame)
        summary_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        summary_layout.setSpacing(SPACING_SMALL)
        summary_title = QLabel("Contract summary", summary_frame)
        summary_title.setStyleSheet("font-weight: 650; font-size: 13px; color: palette(window-text);")
        summary_layout.addWidget(summary_title)
        self._summary = QLabel("", summary_frame)
        self._summary.setWordWrap(True)
        self._summary.setStyleSheet("color: palette(window-text); font-size: 12px;")
        summary_layout.addWidget(self._summary)
        preview_wrap.addWidget(summary_frame)

        preview_title_row = QHBoxLayout()
        preview_title_row.setContentsMargins(0, 0, 0, 0)
        preview_title_row.setSpacing(8)
        preview_title = QLabel("Spec JSON", self)
        preview_title.setStyleSheet("font-weight: 650; font-size: 13px; color: palette(window-text);")
        preview_title_row.addWidget(preview_title)
        preview_title_row.addStretch(1)
        self._show_json = QCheckBox("Show", self)
        self._show_json.setChecked(False)
        self._show_json.toggled.connect(lambda *_: self._refresh_preview())  # type: ignore[arg-type]
        preview_title_row.addWidget(self._show_json)
        preview_wrap.addLayout(preview_title_row)

        self._preview = QPlainTextEdit(self)
        self._preview.setReadOnly(True)
        self._preview.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._preview.setFont(monospace_font())
        self._preview.setFrameShape(QFrame.NoFrame)
        self._preview.setStyleSheet("background-color: palette(base); color: palette(window-text);")
        preview_wrap.addWidget(self._preview, stretch=1)

        preview_container = QWidget(self)
        preview_container.setLayout(preview_wrap)
        body.addWidget(preview_container, stretch=2)

        # ---- Target refine drawer (non-blocking) ----
        self._target_refine_drawer = TargetRefineDrawer(self)
        self._target_refine_drawer.hide()
        self._target_refine_drawer.applied.connect(self._on_target_refine_applied)  # type: ignore[arg-type]
        self._target_refine_drawer.cancelled.connect(self._close_target_refine_drawer)  # type: ignore[arg-type]
        body.addWidget(self._target_refine_drawer, stretch=0)

        # ---- Actions ----
        actions = QHBoxLayout()

        more_btn = QToolButton(self)
        more_btn.setText("More")
        more_btn.setAutoRaise(True)
        more_btn.setCursor(Qt.PointingHandCursor)
        more_btn.setProperty("role", "muted")
        more_menu = QMenu(more_btn)
        more_menu.addAction("Save as template…", self._on_save_template_clicked)
        more_btn.setMenu(more_menu)
        more_btn.setPopupMode(QToolButton.InstantPopup)
        actions.addWidget(more_btn)
        actions.addStretch(1)

        cancel_btn = QPushButton("Cancel", self)
        cancel_btn.setFlat(True)
        cancel_btn.setCursor(Qt.PointingHandCursor)
        cancel_btn.setProperty("role", "muted")
        cancel_btn.setStyleSheet(
            "QPushButton { color: palette(mid); }"
            "QPushButton:hover { color: palette(window-text); }"
        )
        cancel_btn.clicked.connect(self.reject)
        actions.addWidget(cancel_btn)

        self._create_btn = QPushButton("Create experiment", self)
        self._create_btn.setProperty("role", "btnPrimary")
        self._create_btn.clicked.connect(self._on_create_clicked)
        actions.addWidget(self._create_btn)

        root.addLayout(actions)

        # Local dialog styling: prefer calm surfaces and show borders only on focus/state.
        # Keep this scoped to the dialog so other Studio panels can evolve independently.
        self.setStyleSheet(
            """
            QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit {
              border: 1px solid transparent;
              border-radius: 10px;
              padding: 6px 10px;
            }
            QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QPlainTextEdit:focus {
              border-color: palette(highlight);
            }
            /* Avoid double-borders on editable combo boxes (they contain a QLineEdit). */
            QComboBox QLineEdit {
              border: 0px;
              padding: 0px;
              background: transparent;
            }
            """
        )

        # Wire changes -> preview
        for w in (
            self._primary_goal,
            self._decision_question,
            self._hypothesis,
            self._modality,
            self._target_intent,
            self._reference_build,
            self._target_field,
            self._delivery,
            self._cell_context,
            self._experiment_scale,
            self._readout_level,
            self._readout,
            self._output_class,
            self._crit_edit_rate_enabled,
            self._crit_edit_rate_pct,
            self._crit_offtarget_enabled,
            self._crit_offtarget_max_count,
            self._offtarget_basis,
            self._offtarget_scope,
            self._offtarget_method,
            self._crit_editable,
            self._protein_req,
            self._crit_protein_loss_pct,
            self._crit_protein_day,
            self._phenotype_req,
            self._crit_phenotype_effect,
            self._crit_phenotype_day,
        ):
            self._wire_refresh(w)

        # Keep target tokens' build in sync with the reference build selector.
        try:
            self._reference_build.currentIndexChanged.connect(lambda *_: self._target_field.set_reference_build(str(self._reference_build.currentData() or "hg38")))  # type: ignore[arg-type]
        except Exception:
            pass
        try:
            self._target_field.targetChanged.connect(self._on_target_field_changed)  # type: ignore[arg-type]
        except Exception:
            pass

        # Seed defaults
        self._apply_default_by_start_mode()
        self._refresh_preview()

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)

        if not getattr(self, "_maximize_once", False):
            return
        self._maximize_once = False

        def _apply() -> None:
            center_on_focused_window(self)
            try:
                self.showMaximized()
            except Exception:
                pass
            # Prevent the dialog from jittering in height when intent selection
            # changes which fields are visible. This gate is meant to behave
            # like a full-screen wizard, not a layout-driven auto-resizing form.
            QTimer.singleShot(0, self._lock_window_size_to_current)

        QTimer.singleShot(0, _apply)

    def _lock_window_size_to_current(self) -> None:
        try:
            self.setFixedSize(self.size())
        except Exception:
            pass

    def _toggle_readiness_details(self) -> None:
        try:
            visible = bool(self._readiness_details_container.isVisible())
        except Exception:
            visible = False
        new_visible = not visible
        try:
            self._readiness_details_container.setVisible(new_visible)
        except Exception:
            pass
        try:
            self._readiness_details_toggle.setText("Hide details" if new_visible else "Show details")
        except Exception:
            pass

    def _on_section_toggled(self, section: str, expanded: bool) -> None:
        sections = getattr(self, "_sections", None)
        if not isinstance(sections, dict):
            return
        entry = sections.get(str(section))
        if not entry or len(entry) != 2:
            return
        toggle, body = entry
        if not isinstance(toggle, QToolButton) or not isinstance(body, QWidget):
            return
        try:
            body.setVisible(bool(expanded))
        except Exception:
            pass
        try:
            toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        except Exception:
            pass

    def _set_section_expanded(self, section: str, expanded: bool) -> None:
        sections = getattr(self, "_sections", None)
        if not isinstance(sections, dict):
            return
        entry = sections.get(str(section))
        if not entry or len(entry) != 2:
            return
        toggle, body = entry
        if not isinstance(toggle, QToolButton) or not isinstance(body, QWidget):
            return
        try:
            if bool(toggle.isChecked()) == bool(expanded):
                self._on_section_toggled(section, bool(expanded))
                return
        except Exception:
            pass
        try:
            toggle.blockSignals(True)
            toggle.setChecked(bool(expanded))
        except Exception:
            return
        finally:
            try:
                toggle.blockSignals(False)
            except Exception:
                pass
        self._on_section_toggled(section, bool(expanded))

    def _on_primary_goal_change_clicked(self) -> None:
        self._primary_goal_override_active = not bool(getattr(self, "_primary_goal_override_active", False))
        if self._primary_goal_override_active:
            try:
                self._set_section_expanded("sec1", True)
                self._focus_widget(self._primary_goal)
            except Exception:
                pass
        self._refresh_preview()

    def _focus_target_field(self) -> None:
        self._set_section_expanded("sec1", True)
        token = self._target_field.token()
        if token is not None and str(getattr(token, "kind", "") or "").strip() == "locus":
            state = getattr(self, "_target_locus_resolution", None)
            if isinstance(state, TargetLocusResolutionState) and state.scope.mode == "unset":
                scroll = getattr(self, "_left_scroll", None)
                if isinstance(scroll, QScrollArea):
                    try:
                        scroll.ensureWidgetVisible(self._target_resolution_frame, xMargin=20, yMargin=20)
                    except Exception:
                        pass
                try:
                    self._target_scope.setFocus(Qt.FocusReason.OtherFocusReason)
                    if self._target_scope.isEnabled():
                        self._target_scope.showPopup()
                except Exception:
                    pass
                return
        scroll = getattr(self, "_left_scroll", None)
        if isinstance(scroll, QScrollArea):
            try:
                scroll.ensureWidgetVisible(self._target_field, xMargin=20, yMargin=20)
            except Exception:
                pass
        try:
            self._target_field.focus_and_open()
        except Exception:
            pass

    def _focus_widget(self, widget: QWidget) -> None:
        scroll = getattr(self, "_left_scroll", None)
        if isinstance(scroll, QScrollArea):
            try:
                scroll.ensureWidgetVisible(widget, xMargin=20, yMargin=20)
            except Exception:
                pass
        try:
            widget.setFocus(Qt.FocusReason.OtherFocusReason)
        except Exception:
            pass
        try:
            if isinstance(widget, QComboBox):
                widget.showPopup()
        except Exception:
            pass

    def _focus_hypothesis_field(self) -> None:
        self._set_section_expanded("sec2", True)
        self._focus_widget(self._hypothesis)
        try:
            self._hypothesis.selectAll()
        except Exception:
            pass

    def _focus_success_criteria(self) -> None:
        self._set_section_expanded("sec2", True)
        # Prefer the Tier A edit-rate toggle/spinbox as a sensible "first" control.
        try:
            if bool(self._crit_edit_rate_enabled.isChecked()):
                self._focus_widget(self._crit_edit_rate_pct)
                return
        except Exception:
            pass
        self._focus_widget(self._crit_edit_rate_enabled)

    def _focus_validation_readout(self) -> None:
        self._set_section_expanded("sec4", True)
        self._focus_widget(self._readout)

    def _focus_offtarget_definition(self) -> None:
        self._set_section_expanded("sec2", True)
        self._focus_widget(self._offtarget_method)

    def _on_readiness_primary_action_clicked(self) -> None:
        key = str(getattr(self, "_readiness_primary_action_key", "") or "").strip().lower()
        if not key:
            return
        if key == "use-recommended-intent":
            self._apply_preset("knockout_validation")
            return
        if key in {"set-target", "fix-readout"}:
            self._on_readiness_link_activated(key)
            return
        if key == "focus-hypothesis":
            self._focus_hypothesis_field()
            return
        if key == "focus-success":
            self._focus_success_criteria()
            return
        if key == "focus-validation":
            self._focus_validation_readout()
            return
        if key == "focus-offtarget":
            self._focus_offtarget_definition()
            return
        if key == "focus-modality":
            self._focus_modality_field()
            return
        if key == "focus-reference":
            self._set_section_expanded("sec3", True)
            self._focus_widget(self._reference_build)
            return
        if key == "focus-target-type":
            self._focus_target_intent_field()
            return

    def _focus_modality_field(self) -> None:
        self._set_section_expanded("sec3", True)
        self._focus_widget(self._modality)

    def _focus_target_intent_field(self) -> None:
        self._set_section_expanded("sec3", True)
        self._focus_widget(self._target_intent)

    def _focus_delivery_field(self) -> None:
        self._set_section_expanded("sec3", True)
        self._focus_widget(self._delivery)

    def _show_target_required_help(self) -> None:
        QMessageBox.information(
            self,
            "Why is target required?",
            "Target defines the genomic locus and isoform scope used to enforce evidence and off-target policies.\n\n"
            "Helix needs a target to design candidates, evaluate feasibility, and scope off-target risk.\n\n"
            "You can create an intent contract without a target, but guide/oligo/protocol exports remain blocked until a target is set and required intent fields are filled.",
        )

    def _open_target_refine_drawer(self) -> None:
        build = str(self._reference_build.currentData() or "hg38")
        try:
            self._target_refine_drawer.set_reference_build(build)
        except Exception:
            pass

        token = self._target_field.token()
        if token is None:
            try:
                from helix.studio.target_field import TargetToken

                token = TargetToken.parse_token_line(self._target_field.text(), default_build=build)
            except Exception:
                token = None

        if token is None:
            self._focus_target_field()
            return

        try:
            self._target_refine_drawer.set_token(token)
        except Exception:
            return
        self._target_refine_drawer.show()
        self._target_refine_drawer.raise_()
        try:
            self._target_refine_drawer.focus_first()
        except Exception:
            pass

    def _close_target_refine_drawer(self) -> None:
        self._target_refine_auto_suppressed = True
        try:
            self._target_refine_drawer.hide()
        except Exception:
            pass

    def _on_target_refine_applied(self, token_obj: object) -> None:
        try:
            from helix.studio.target_field import TargetToken

            token = token_obj if isinstance(token_obj, TargetToken) else None
        except Exception:
            token = None
        if token is None:
            return
        build = str(self._reference_build.currentData() or "hg38")
        try:
            self._target_field.set_reference_build(build)
            self._target_field.set_token(token, store_recent=True)
        except Exception:
            return
        self._target_refine_auto_suppressed = False
        try:
            self._target_refine_drawer.hide()
        except Exception:
            pass

    def _maybe_auto_open_target_refine(self, sel: ExperimentSetupSelections) -> None:
        token = self._target_field.token()
        if token is None:
            return
        if getattr(self, "_target_refine_auto_suppressed", False) or getattr(self, "_target_refine_auto_prompted", False):
            return

        needs_precision = str(sel.modality or "").strip() == "prime" or str(sel.target_intent or "").strip() in {
            "precise_substitution",
            "prime_edit",
        }
        if not needs_precision:
            return
        if str(token.kind or "").strip() != "gene":
            return
        if token.transcript or token.window or token.window_mode:
            return

        self._target_refine_auto_prompted = True
        self._open_target_refine_drawer()

    def _on_target_field_changed(self, _token: object) -> None:
        # Auto-open refine when the intent requires more specificity (prime / SNV),
        # but only once unless the user explicitly opens it.
        token = self._target_field.token()
        if token is None:
            self._clear_target_locus_resolution()
            try:
                self._target_refine_drawer.hide()
            except Exception:
                pass
            return

        if str(getattr(token, "kind", "") or "").strip() != "locus":
            self._clear_target_locus_resolution()
        else:
            try:
                self._start_target_locus_resolution(token)
            except Exception:
                self._clear_target_locus_resolution()

        if not bool(getattr(self, "_sec2_auto_expanded", False)):
            self._sec2_auto_expanded = True
            try:
                self._set_section_expanded("sec2", True)
            except Exception:
                pass

        self._maybe_auto_open_target_refine(self._current_selections())

    def _clear_target_locus_resolution(self) -> None:
        self._target_locus_resolution = None
        try:
            self._target_locus_resolve_job += 1
            self._target_locus_gene_job += 1
        except Exception:
            pass
        try:
            self._target_scope.blockSignals(True)
            self._target_scope.clear()
            self._target_scope.addItem("Select scope…", "unset")
            self._target_scope.setEnabled(False)
        finally:
            try:
                self._target_scope.blockSignals(False)
            except Exception:
                pass
        try:
            self._target_scope_custom.hide()
            self._target_scope_custom.setText("")
        except Exception:
            pass
        try:
            self._target_gene_summary.hide()
            self._target_gene_summary.setText("")
        except Exception:
            pass
        try:
            self._target_resolution_frame.hide()
        except Exception:
            pass

    def _start_target_locus_resolution(self, token_obj: object) -> None:
        try:
            from helix.studio.target_field import TargetToken

            token = token_obj if isinstance(token_obj, TargetToken) else None
        except Exception:
            token = None
        if token is None:
            return

        build = str(self._reference_build.currentData() or "hg38")
        region = parse_locus_primary(str(token.primary or ""), build=build)
        if region is None:
            state = TargetLocusResolutionState(token_primary=str(token.primary or ""), build=build, status="unavailable")
            state.error = "Invalid locus format."
            self._target_locus_resolution = state
            self._render_target_locus_resolution(self._current_selections())
            self._refresh_preview()
            return

        state = TargetLocusResolutionState(token_primary=str(token.primary or ""), build=build, status="pending")
        state.region = region
        self._target_locus_resolution = state
        try:
            self._target_scope.blockSignals(True)
            self._target_scope.clear()
            self._target_scope.addItem("Select scope…", "unset")
            self._target_scope.setEnabled(False)
        finally:
            try:
                self._target_scope.blockSignals(False)
            except Exception:
                pass
        try:
            self._target_scope_custom.hide()
            self._target_scope_custom.setText("")
        except Exception:
            pass
        try:
            self._target_gene_summary.hide()
            self._target_gene_summary.setText("")
        except Exception:
            pass
        self._render_target_locus_resolution(self._current_selections())

        self._target_locus_resolve_job += 1
        job_id = int(self._target_locus_resolve_job)

        fut = qt_run(fetch_ensembl_region_overlaps, region)
        watcher = QFutureWatcher(self)
        watcher.setFuture(fut)
        self._target_locus_resolve_watcher = watcher

        def _on_done() -> None:
            if job_id != int(getattr(self, "_target_locus_resolve_job", 0)):
                return
            current = getattr(self, "_target_locus_resolution", None)
            if not isinstance(current, TargetLocusResolutionState):
                return
            try:
                genes, ann, err = watcher.result()
            except Exception as exc:
                genes, ann, err = [], None, str(exc)
            current.overlaps = genes or []
            current.annotation = ann if isinstance(ann, dict) else None
            if err:
                current.status = "unavailable"
                current.error = str(err)
            else:
                current.status = "resolved"
                current.error = None
            self._populate_target_scope_options(current)
            self._render_target_locus_resolution(self._current_selections())
            self._refresh_preview()

        watcher.finished.connect(_on_done)  # type: ignore[arg-type]

    def _populate_target_scope_options(self, state: TargetLocusResolutionState) -> None:
        if not isinstance(state, TargetLocusResolutionState):
            return
        self._updating_target_scope = True
        try:
            self._target_scope.blockSignals(True)
            self._target_scope.clear()
            self._target_scope.addItem("Select scope…", "unset")

            for gene in sorted(state.overlaps, key=lambda g: str(getattr(g, "symbol", "") or "").upper()):
                if not isinstance(gene, OverlapGene):
                    continue
                label = f"Gene: {gene.symbol}"
                if gene.biotype:
                    label = f"{label} ({gene.biotype})"
                self._target_scope.addItem(label, {"mode": "gene", "geneId": gene.gene_id, "geneSymbol": gene.symbol})

            self._target_scope.addItem("Multiple genes/features (explicit multi-target)", {"mode": "multi"})
            self._target_scope.addItem("Non-coding region", {"mode": "noncoding"})
            self._target_scope.addItem("Custom feature…", {"mode": "custom"})

            self._target_scope.setEnabled(True)

            # Restore scope selection if possible (e.g., after annotation refresh).
            scope = state.scope
            if scope.mode == "gene" and scope.gene_id:
                for i in range(int(self._target_scope.count())):
                    data = self._target_scope.itemData(i)
                    if isinstance(data, dict) and data.get("mode") == "gene" and str(data.get("geneId") or "") == scope.gene_id:
                        self._target_scope.setCurrentIndex(i)
                        break
            elif scope.mode != "unset":
                for i in range(int(self._target_scope.count())):
                    data = self._target_scope.itemData(i)
                    if isinstance(data, dict) and data.get("mode") == scope.mode:
                        self._target_scope.setCurrentIndex(i)
                        break
        finally:
            try:
                self._target_scope.blockSignals(False)
            except Exception:
                pass
            self._updating_target_scope = False

    def _on_target_scope_changed(self, *_args) -> None:
        if bool(getattr(self, "_updating_target_scope", False)):
            return
        state = getattr(self, "_target_locus_resolution", None)
        if not isinstance(state, TargetLocusResolutionState):
            return

        data = self._target_scope.currentData()
        mode = "unset"
        gene_id = None
        gene_symbol = None
        if isinstance(data, dict):
            mode = str(data.get("mode") or "unset")
            gene_id = str(data.get("geneId") or "").strip() or None
            gene_symbol = str(data.get("geneSymbol") or "").strip() or None
        else:
            mode = str(data or "unset")

        if mode == "custom":
            state.scope = ScopeSelection(mode="custom", custom_label=str(self._target_scope_custom.text() or "").strip() or None)
            state.gene_summary = None
            state.coding_sequence_present = None
            state.constitutive_exons_affected = None
            try:
                self._target_scope_custom.show()
            except Exception:
                pass
        elif mode == "noncoding":
            state.scope = ScopeSelection(mode="noncoding")
            state.gene_summary = None
            state.coding_sequence_present = False
            state.constitutive_exons_affected = False
            try:
                self._target_scope_custom.hide()
            except Exception:
                pass
        elif mode == "multi":
            state.scope = ScopeSelection(mode="multi")
            state.gene_summary = None
            state.coding_sequence_present = None
            state.constitutive_exons_affected = None
            try:
                self._target_scope_custom.hide()
            except Exception:
                pass
        elif mode == "gene" and gene_id and gene_symbol:
            state.scope = ScopeSelection(mode="gene", gene_id=gene_id, gene_symbol=gene_symbol)
            state.gene_summary = None
            state.coding_sequence_present = None
            state.constitutive_exons_affected = None
            try:
                self._target_scope_custom.hide()
            except Exception:
                pass
            self._start_target_gene_resolution(gene_id)
        else:
            state.scope = ScopeSelection(mode="unset")
            state.gene_summary = None
            state.coding_sequence_present = None
            state.constitutive_exons_affected = None
            try:
                self._target_scope_custom.hide()
            except Exception:
                pass

        self._render_target_locus_resolution(self._current_selections())
        self._refresh_preview()

    def _on_target_scope_custom_changed(self, *_args) -> None:
        state = getattr(self, "_target_locus_resolution", None)
        if not isinstance(state, TargetLocusResolutionState):
            return
        if state.scope.mode != "custom":
            return
        state.scope = ScopeSelection(mode="custom", custom_label=str(self._target_scope_custom.text() or "").strip() or None)
        self._render_target_locus_resolution(self._current_selections())
        self._refresh_preview()

    def _start_target_gene_resolution(self, gene_id: str) -> None:
        state = getattr(self, "_target_locus_resolution", None)
        if not isinstance(state, TargetLocusResolutionState):
            return
        region = state.region
        if region is None:
            return
        gene = next((g for g in state.overlaps if isinstance(g, OverlapGene) and g.gene_id == gene_id), None)
        if gene is None:
            return

        self._target_locus_gene_job += 1
        job_id = int(self._target_locus_gene_job)

        fut = qt_run(fetch_ensembl_gene_exon_summary, gene=gene, region=region)
        watcher = QFutureWatcher(self)
        watcher.setFuture(fut)
        self._target_locus_gene_watcher = watcher

        def _on_done() -> None:
            if job_id != int(getattr(self, "_target_locus_gene_job", 0)):
                return
            current = getattr(self, "_target_locus_resolution", None)
            if not isinstance(current, TargetLocusResolutionState):
                return
            try:
                summary, coding_present, constitutive_affected, err = watcher.result()
            except Exception as exc:
                summary, coding_present, constitutive_affected, err = None, None, None, str(exc)
            current.gene_summary = summary
            current.coding_sequence_present = coding_present
            current.constitutive_exons_affected = constitutive_affected
            if err:
                current.error = str(err)
            self._render_target_locus_resolution(self._current_selections())
            self._refresh_preview()

        watcher.finished.connect(_on_done)  # type: ignore[arg-type]

    def _render_target_locus_resolution(self, sel: ExperimentSetupSelections) -> None:
        state = getattr(self, "_target_locus_resolution", None)
        if not isinstance(state, TargetLocusResolutionState):
            try:
                self._target_resolution_frame.hide()
            except Exception:
                pass
            return

        try:
            self._target_resolution_frame.show()
        except Exception:
            pass

        region = state.region
        if region is None:
            self._target_resolution_region.setText("Region: unavailable")
        else:
            self._target_resolution_region.setText(
                f"Resolved target region ({region.build}): {region.contig}:{region.start1:,}–{region.end1:,} ({region.length_bp:,} bp)"
            )

        if state.status == "pending":
            self._target_resolution_overlaps.setText("Resolving overlaps…")
            try:
                self._target_scope.setEnabled(False)
            except Exception:
                pass
        elif state.status == "unavailable":
            err = str(state.error or "").strip() or "Resolution unavailable."
            self._target_resolution_overlaps.setText(f"Overlaps: (resolution unavailable) — {err}")
            try:
                self._target_scope.setEnabled(True)
            except Exception:
                pass
        else:
            if not state.overlaps:
                self._target_resolution_overlaps.setText("Overlaps: none detected")
            else:
                lines: list[str] = []
                for gene in state.overlaps[:6]:
                    if not isinstance(gene, OverlapGene):
                        continue
                    tail = f" ({gene.biotype})" if gene.biotype else ""
                    lines.append(f"{gene.symbol}{tail}")
                extra = f" (+{len(state.overlaps) - len(lines)} more)" if len(state.overlaps) > len(lines) else ""
                self._target_resolution_overlaps.setText("Overlaps: " + ", ".join(lines) + extra)

        if state.scope.mode == "custom":
            try:
                self._target_scope_custom.show()
            except Exception:
                pass
        else:
            try:
                self._target_scope_custom.hide()
            except Exception:
                pass

        if state.gene_summary is not None and state.scope.mode == "gene":
            summary = state.gene_summary
            exon_bits: list[str] = []
            if summary.exon_range:
                exon_bits.append(f"exons {summary.exon_range}")
            if summary.canonical_transcript:
                exon_bits.append(f"canonical {summary.canonical_transcript}")
            if summary.constitutive_exon_indices:
                exon_bits.append("constitutive exons detected")
            line = " · ".join(exon_bits) if exon_bits else "exon detail unavailable"
            self._target_gene_summary.setText(f"Scoped gene: {summary.symbol} · {line}")
            self._target_gene_summary.show()
        else:
            self._target_gene_summary.hide()
            self._target_gene_summary.setText("")

        snap = state.snapshot(target_type=str(sel.target_intent or "").strip())
        compat = snap.get("compatibility") if isinstance(snap.get("compatibility"), dict) else {}
        verdict = str(compat.get("verdict") or "").strip()
        reasons = compat.get("reasons") if isinstance(compat.get("reasons"), list) else []
        reason_text = ", ".join([str(r) for r in reasons if str(r)]) if reasons else ""
        if verdict == "compatible":
            self._target_compatibility.setText("Intent compatibility: OK")
        elif verdict == "incompatible":
            self._target_compatibility.setText(
                "Intent compatibility: INCOMPATIBLE"
                + (f" — {reason_text}" if reason_text else "")
            )
        else:
            self._target_compatibility.setText(
                "Intent compatibility: Needs review"
                + (f" — {reason_text}" if reason_text else "")
            )

    def _on_decision_question_text_edited(self, *_args) -> None:
        if getattr(self, "_setting_decision_question", False):
            return
        self._decision_question_user_edited = True

    def _on_protein_req_changed(self, *_args) -> None:
        if getattr(self, "_setting_auto_require", False):
            return
        self._protein_req_user_edited = True

    def _on_phenotype_req_changed(self, *_args) -> None:
        if getattr(self, "_setting_auto_require", False):
            return
        self._phenotype_req_user_edited = True

    def _wire_refresh(self, widget: QWidget) -> None:
        try:
            if isinstance(widget, QComboBox):
                widget.currentIndexChanged.connect(lambda *_: self._refresh_preview())  # type: ignore[arg-type]
                try:
                    widget.editTextChanged.connect(lambda *_: self._refresh_preview())  # type: ignore[attr-defined,arg-type]
                except Exception:
                    pass
            elif isinstance(widget, QLineEdit):
                widget.textChanged.connect(lambda *_: self._refresh_preview())  # type: ignore[arg-type]
            elif isinstance(widget, TargetFieldWidget):
                widget.targetChanged.connect(lambda *_: self._refresh_preview())  # type: ignore[arg-type]
            elif isinstance(widget, QCheckBox):
                widget.toggled.connect(lambda *_: self._refresh_preview())  # type: ignore[arg-type]
            elif isinstance(widget, (QSpinBox, QDoubleSpinBox)):
                widget.valueChanged.connect(lambda *_: self._refresh_preview())  # type: ignore[arg-type]
        except Exception:
            return

    def _apply_default_by_start_mode(self) -> None:
        # If the user chose the "goal-first" route in welcome, preload a goal-oriented preset.
        if self._start_mode == "experiment_goal":
            self._apply_preset("knockout_validation")
        elif self._start_mode == "gene_locus":
            self._apply_preset("guide_comparison")

    def _apply_preset(self, preset_id: str) -> None:
        sel = PRESETS.get(preset_id)
        if sel is None:
            return
        self._active_preset_id = preset_id
        self._apply_selections(sel)
        try:
            self._update_intent_cards()
        except Exception:
            pass
        try:
            self._set_section_expanded("sec1", True)
        except Exception:
            pass

    def _update_intent_cards(self) -> None:
        cards = getattr(self, "_intent_cards", None)
        if not isinstance(cards, dict):
            return
        selected = str(getattr(self, "_active_preset_id", "") or "").strip()
        has_selection = bool(selected)
        for pid, card in cards.items():
            if not isinstance(card, IntentCard):
                continue
            is_selected = str(pid) == selected
            card.set_selected(is_selected, dimmed=(has_selection and not is_selected))

    def _show_unlocks_panel(self) -> None:
        try:
            self._show_unlocks.setChecked(True)
        except Exception:
            pass

    def _on_policy_badge_clicked(self) -> None:
        try:
            sel = self._current_selections()
        except Exception:
            return
        try:
            QMessageBox.information(self, "Provenance & export policy", self._policy_effect_text(sel))
        except Exception:
            return

    def _update_policy_badge(self, sel: ExperimentSetupSelections) -> None:
        key = str(sel.output_class or "").strip().lower()
        if key == "decision_candidate":
            self._policy_badge.setText("Decision-grade candidate")
            self._policy_badge.setStyleSheet(
                "QPushButton { border: 1px solid palette(highlight); border-radius: 10px; padding: 3px 8px; font-size: 12px; color: palette(window-text); background: palette(alternate-base); }"
                "QPushButton:hover { border-color: palette(highlight); }"
            )
            return
        self._policy_badge.setText("Exploratory results only")
        self._policy_badge.setStyleSheet(
            "QPushButton { border: 1px solid palette(mid); border-radius: 10px; padding: 3px 8px; font-size: 12px; color: palette(window-text); background: palette(alternate-base); }"
            "QPushButton:hover { border-color: palette(highlight); }"
        )

    def _apply_selections(self, sel: ExperimentSetupSelections) -> None:
        self._protein_req_user_edited = False
        self._phenotype_req_user_edited = False
        try:
            self._primary_goal.setCurrentIndex(max(0, self._primary_goal.findData(sel.primary_goal)))
        except Exception:
            pass
        self._decision_question_user_edited = False
        try:
            self._setting_decision_question = True
            self._decision_question.setText(str(sel.decision_question or "").strip())
        except Exception:
            pass
        finally:
            self._setting_decision_question = False
        try:
            self._hypothesis.setText(sel.hypothesis)
        except Exception:
            pass
        try:
            self._crit_edit_rate_enabled.setChecked(bool(sel.success_edit_rate_pct > 0))
            self._crit_edit_rate_pct.setValue(float(sel.success_edit_rate_pct))
        except Exception:
            pass
        try:
            self._crit_offtarget_enabled.setChecked(sel.success_max_high_risk_coding_offtarget_count is not None)
            self._crit_offtarget_max_count.setValue(int(sel.success_max_high_risk_coding_offtarget_count or 0))
        except Exception:
            pass
        try:
            self._crit_editable.setChecked(bool(sel.success_requires_editable))
        except Exception:
            pass
        try:
            self._crit_protein_loss_pct.setValue(float(sel.success_protein_loss_pct or 0.0))
            self._crit_protein_day.setValue(int(sel.success_protein_loss_day or 7))
        except Exception:
            pass
        try:
            self._crit_phenotype_effect.setValue(float(sel.success_phenotype_effect_size or 0.0))
            self._crit_phenotype_day.setValue(int(sel.success_phenotype_effect_day or 7))
        except Exception:
            pass
        try:
            self._offtarget_basis.setCurrentIndex(max(0, self._offtarget_basis.findData(sel.off_target_basis)))
        except Exception:
            pass
        try:
            self._offtarget_scope.setCurrentIndex(max(0, self._offtarget_scope.findData(sel.off_target_scope)))
        except Exception:
            pass
        try:
            method_id = str(sel.off_target_method or "").strip()
            idx = self._offtarget_method.findData(method_id)
            if idx >= 0:
                self._offtarget_method.setCurrentIndex(idx)
            else:
                self._offtarget_method.setEditText(method_id)
        except Exception:
            pass
        try:
            self._protein_req.setCurrentIndex(1 if sel.success_protein_loss_pct is not None else 0)
        except Exception:
            pass
        try:
            self._phenotype_req.setCurrentIndex(1 if sel.success_phenotype_effect_size is not None else 0)
        except Exception:
            pass
        try:
            self._modality.setCurrentIndex(max(0, self._modality.findData(sel.modality)))
        except Exception:
            pass
        try:
            self._reference_build.setCurrentIndex(max(0, self._reference_build.findData(sel.reference_build)))
        except Exception:
            pass
        try:
            self._target_intent.setCurrentIndex(max(0, self._target_intent.findData(sel.target_intent)))
        except Exception:
            pass
        try:
            self._target_field.set_reference_build(str(sel.reference_build or "hg38"))
            self._target_field.set_from_text(str(sel.perturbation_target or "").strip(), store_recent=False)
        except Exception:
            pass
        try:
            self._delivery.setCurrentIndex(max(0, self._delivery.findData(sel.delivery_modality)))
        except Exception:
            pass
        try:
            self._cell_context.setCurrentIndex(max(0, self._cell_context.findData(sel.cell_context)))
        except Exception:
            pass
        try:
            self._experiment_scale.setCurrentIndex(max(0, self._experiment_scale.findData(sel.experiment_scale)))
        except Exception:
            pass
        try:
            self._readout_level.setCurrentIndex(max(0, self._readout_level.findData(sel.readout_level)))
        except Exception:
            pass
        try:
            self._readout.setCurrentIndex(max(0, self._readout.findData(sel.assay_type)))
        except Exception:
            pass
        try:
            self._output_class.setCurrentIndex(max(0, self._output_class.findData(sel.output_class)))
        except Exception:
            pass
        self._refresh_preview()

    def _current_selections(self) -> ExperimentSetupSelections:
        primary_goal = str(self._primary_goal.currentData() or "feasibility")
        modality = str(self._modality.currentData() or "crispr_cut")
        reference_build = str(self._reference_build.currentData() or "hg38")
        target_intent = str(self._target_intent.currentData() or "knockout")
        delivery_modality = str(self._delivery.currentData() or "rnp")
        cell_context = str(self._cell_context.currentData() or "standard")
        experiment_scale = str(self._experiment_scale.currentData() or "bulk")
        readout_level = str(self._readout_level.currentData() or "dna_only")
        assay_type = str(self._readout.currentData() or "ampseq")
        output_class = str(self._output_class.currentData() or "exploratory")

        is_knockout = target_intent.strip().lower() == "knockout"
        edit_rate = float(self._crit_edit_rate_pct.value()) if bool(self._crit_edit_rate_enabled.isChecked()) else 0.0
        off_target_max_count = (
            int(self._crit_offtarget_max_count.value()) if bool(self._crit_offtarget_enabled.isChecked()) else None
        )
        protein_required = bool(str(self._protein_req.currentData() or "").strip() == "required")
        phenotype_required = bool(str(self._phenotype_req.currentData() or "").strip() == "required")
        protein_loss_pct = float(self._crit_protein_loss_pct.value()) if is_knockout and protein_required else None
        protein_day = int(self._crit_protein_day.value()) if is_knockout and protein_required else None
        phenotype_effect = float(self._crit_phenotype_effect.value()) if is_knockout and phenotype_required else None
        phenotype_day = int(self._crit_phenotype_day.value()) if is_knockout and phenotype_required else None

        off_basis = str(self._offtarget_basis.currentData() or "").strip()
        off_scope = str(self._offtarget_scope.currentData() or "").strip()
        off_method = str(self._offtarget_method.currentText() or "").strip()
        try:
            idx = int(self._offtarget_method.currentIndex())
        except Exception:
            idx = -1
        if idx >= 0:
            try:
                item_text = str(self._offtarget_method.itemText(idx) or "").strip()
            except Exception:
                item_text = ""
            data = str(self._offtarget_method.currentData() or "").strip()
            if data and item_text and off_method == item_text:
                off_method = data

        decision_question = str(self._decision_question.text() or "").strip()
        if not bool(getattr(self, "_decision_question_user_edited", False)):
            decision_question = ""

        return ExperimentSetupSelections(
            preset_id=self._active_preset_id,
            primary_goal=primary_goal,
            decision_question=decision_question,
            hypothesis=str(self._hypothesis.text() or "").strip(),
            success_edit_rate_pct=edit_rate,
            success_max_high_risk_coding_offtarget_count=off_target_max_count,
            off_target_basis=off_basis,
            off_target_method=off_method,
            off_target_scope=off_scope,
            success_requires_editable=bool(self._crit_editable.isChecked()),
            success_protein_loss_pct=protein_loss_pct,
            success_protein_loss_day=protein_day,
            success_phenotype_effect_size=phenotype_effect,
            success_phenotype_effect_day=phenotype_day,
            modality=modality,
            reference_build=reference_build,
            target_intent=target_intent,
            perturbation_target=str(self._target_field.text() or "").strip(),
            delivery_modality=delivery_modality,
            cell_context=cell_context,
            experiment_scale=experiment_scale,
            readout_level=readout_level,
            assay_type=assay_type,
            output_class=output_class,
        )

    def _build_payload(self) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], str]:
        sel = self._current_selections()
        intent = build_experiment_intent_spec(sel, created_at_utc=self._created_at_utc, intent_id="intent_setup")
        exp_spec = build_experiment_spec(sel)

        # Attach locus resolution snapshot (if applicable) and avoid treating raw coordinates
        # as a bound target until scope + compatibility gates are satisfied.
        state = getattr(self, "_target_locus_resolution", None)
        if isinstance(state, TargetLocusResolutionState):
            snaps = intent.get("snapshots")
            if not isinstance(snaps, dict):
                snaps = {}
                intent["snapshots"] = snaps
            snaps["targetLocusResolution"] = state.snapshot(target_type=str(sel.target_intent or "").strip())

        if not self._target_is_bound(sel):
            perturbation = intent.get("perturbation")
            if isinstance(perturbation, dict):
                perturbation["target"] = ""
                perturbation["targetState"] = "unset"
            params = intent.get("decisionQuestionParams")
            if isinstance(params, dict):
                params["target"] = None
            if str(intent.get("decisionQuestionSource") or "").strip() == "derived":
                goal = str((params or {}).get("goal") or "").strip() if isinstance(params, dict) else ""
                goal = goal or str(sel.primary_goal or "").strip() or "Decision"
                intent["decisionQuestion"] = f"{goal}: can we proceed?"
                intent["decisionQuestionTemplate"] = "{goal}: can we proceed?"

        # Session config patch: store human-facing metadata and a helixspec policy default.
        draft_ok, _draft_missing = self._draft_ready(sel)
        design_ok, _design_missing = self._design_ready(sel)
        run_ok, _run_missing = self._run_ready(sel)
        meta: dict[str, Any] = {
            "intent_primary_goal": sel.primary_goal,
            "intent_output_class": sel.output_class,
            "intent_setup_created_at_utc": self._created_at_utc,
            "intent_setup_create_mode": self._create_mode(sel),
            "intent_setup_draft_ready": bool(draft_ok),
            "intent_setup_design_ready": bool(design_ok),
            "intent_setup_run_ready": bool(run_ok),
        }
        policy = load_policy_template(sel.output_class)
        cfg_patch: dict[str, Any] = {"metadata": meta}
        if policy is not None:
            cfg_patch["helixspec_policy"] = policy

        rail_segment = initial_rail_segment_for_goal(sel.primary_goal)
        return intent, exp_spec, cfg_patch, rail_segment

    def _target_status(self, target: str) -> str:
        t = str(target or "").strip()
        if not t:
            return "unset"
        if t.lower() in {"tbd", "to do", "todo", "unset", "not set", "not set (draft)"}:
            return "unset"
        return "set"

    def _target_is_bound(self, sel: ExperimentSetupSelections) -> bool:
        """
        Return True when the target is sufficiently defined to behave as a contract input.

        For gene/variant/panel tokens: any selected token counts as bound.
        For locus (coordinate) tokens: require an explicit scope, and (for knockout) a compatible scope.
        """
        token = self._target_field.token()
        if token is None:
            return False
        if str(getattr(token, "kind", "") or "").strip() != "locus":
            return True
        state = getattr(self, "_target_locus_resolution", None)
        if not isinstance(state, TargetLocusResolutionState):
            return False
        if state.status == "pending" or state.scope.mode == "unset":
            return False
        if str(sel.target_intent or "").strip().lower() == "knockout":
            snap = state.snapshot(target_type=str(sel.target_intent or "").strip())
            compat = snap.get("compatibility") if isinstance(snap.get("compatibility"), dict) else {}
            return str(compat.get("verdict") or "").strip() == "compatible"
        return True

    def _has_min_success_criteria(self, sel: ExperimentSetupSelections) -> bool:
        return bool(
            (sel.success_edit_rate_pct > 0)
            or (sel.success_max_high_risk_coding_offtarget_count is not None)
            or bool(sel.success_requires_editable)
            or (sel.success_protein_loss_pct is not None)
            or (sel.success_phenotype_effect_size is not None)
        )

    def _draft_ready(self, sel: ExperimentSetupSelections) -> tuple[bool, list[str]]:
        missing: list[str] = []
        if not str(sel.preset_id or "").strip():
            missing.append("intent template")
        if not self._has_min_success_criteria(sel):
            missing.append("success criteria")
        if not str(sel.modality or "").strip():
            missing.append("modality")
        if not str(sel.reference_build or "").strip():
            missing.append("reference build")
        if not str(sel.target_intent or "").strip():
            missing.append("target type")
        if not str(sel.assay_type or "").strip():
            missing.append("validation readout")
        return (not missing), missing

    def _design_ready(self, sel: ExperimentSetupSelections) -> tuple[bool, list[str]]:
        missing: list[str] = []
        token = self._target_field.token()
        if token is None:
            missing.append("target")
        elif str(getattr(token, "kind", "") or "").strip() == "locus":
            state = getattr(self, "_target_locus_resolution", None)
            if not isinstance(state, TargetLocusResolutionState) or state.status == "pending":
                missing.append("target")
            elif state.scope.mode == "unset":
                missing.append("target")
            else:
                # Knockout is strict: require a compatible scoped feature before guide design.
                if str(sel.target_intent or "").strip().lower() == "knockout":
                    snap = state.snapshot(target_type=str(sel.target_intent or "").strip())
                    compat = snap.get("compatibility") if isinstance(snap.get("compatibility"), dict) else {}
                    verdict = str(compat.get("verdict") or "").strip()
                    if verdict != "compatible":
                        missing.append("target")
        if not str(sel.modality or "").strip():
            missing.append("modality")
        if not str(sel.reference_build or "").strip():
            missing.append("reference build")
        return (not missing), missing

    def _run_ready(self, sel: ExperimentSetupSelections) -> tuple[bool, list[str]]:
        missing: list[str] = []
        design_ok, design_missing = self._design_ready(sel)
        if not design_ok:
            missing.extend(design_missing)
        if not str(sel.hypothesis or "").strip():
            missing.append("hypothesis")
        if not self._has_min_success_criteria(sel):
            missing.append("success criteria")
        required = self._required_evidence_tiers(sel)
        if required and not self._readout_level_satisfies(sel.readout_level, required):
            missing.append("readout plan")
        if sel.success_max_high_risk_coding_offtarget_count is not None:
            if not str(sel.off_target_method or "").strip():
                missing.append("off-target method/version")
            if not str(sel.off_target_scope or "").strip():
                missing.append("off-target scope")
        return (not missing), missing

    def _create_mode(self, sel: ExperimentSetupSelections) -> str:
        draft_ok, _ = self._draft_ready(sel)
        run_ok, _ = self._run_ready(sel)
        return "experiment" if (draft_ok and run_ok) else "draft"

    def _is_valid(self, sel: ExperimentSetupSelections) -> bool:
        draft_ok, _missing = self._draft_ready(sel)
        if not draft_ok:
            return False
        if sel.success_protein_loss_pct is not None:
            if sel.success_protein_loss_pct <= 0:
                return False
            if int(sel.success_protein_loss_day or 0) <= 0:
                return False
        if sel.success_phenotype_effect_size is not None:
            if sel.success_phenotype_effect_size <= 0:
                return False
            if int(sel.success_phenotype_effect_day or 0) <= 0:
                return False

        return True

    def _refresh_preview(self) -> None:
        sel = self._current_selections()
        self._update_dynamic_ui(sel)
        valid = self._is_valid(sel)
        try:
            self._create_btn.setEnabled(valid)
        except Exception:
            pass
        try:
            mode = self._create_mode(sel)
            self._create_btn.setText("Create experiment" if mode == "experiment" else "Create intent contract")
        except Exception:
            pass

        try:
            intent, exp_spec, cfg_patch, rail_segment = self._build_payload()
            preview = {
                "experiment_intent_spec": intent,
                "experiment_spec": exp_spec,
                "session_config_patch": cfg_patch,
                "initial_rail_segment_id": rail_segment,
            }
            show = bool(getattr(self, "_show_json", None) is None or self._show_json.isChecked())
            self._preview.setVisible(show)
            self._preview.setPlainText(json.dumps(preview, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
        except Exception as exc:
            self._preview.setPlainText(f"Preview unavailable: {exc}")

    def _update_dynamic_ui(self, sel: ExperimentSetupSelections) -> None:
        self._update_decision_question_default(sel)
        self._constrain_assay_options(sel)
        try:
            sel = self._current_selections()
        except Exception:
            pass
        try:
            self._update_intent_cards()
        except Exception:
            pass
        try:
            self._update_policy_badge(sel)
        except Exception:
            pass
        try:
            self._update_section_gating(sel)
        except Exception:
            pass
        is_knockout = str(sel.target_intent or "").strip().lower() == "knockout"
        try:
            if is_knockout:
                level = str(sel.readout_level or "").strip()

                if level in {"protein", "multiple"} and not bool(getattr(self, "_protein_req_user_edited", False)):
                    if str(self._protein_req.currentData() or "").strip() != "required":
                        self._setting_auto_require = True
                        try:
                            idx = self._protein_req.findData("required")
                            if idx >= 0:
                                self._protein_req.setCurrentIndex(idx)
                        finally:
                            self._setting_auto_require = False

                if level in {"phenotype", "multiple"} and not bool(getattr(self, "_phenotype_req_user_edited", False)):
                    if str(self._phenotype_req.currentData() or "").strip() != "required":
                        self._setting_auto_require = True
                        try:
                            idx = self._phenotype_req.findData("required")
                            if idx >= 0:
                                self._phenotype_req.setCurrentIndex(idx)
                        finally:
                            self._setting_auto_require = False

                sel = self._current_selections()
        except Exception:
            pass
        try:
            self._maybe_auto_open_target_refine(sel)
        except Exception:
            pass
        try:
            token = self._target_field.token()
            warn = _status_color_hex("warning") or "palette(highlight)"
            warn_fill: str | None = None
            try:
                if isinstance(warn, str) and warn.strip().startswith("#"):
                    warn_color = QColor(warn.strip())
                    if warn_color.isValid():
                        base_bg = self.palette().color(QPalette.Base)
                        warn_fill = _hex_rgb(_blend_color(base_bg, warn_color, fg_percent=12))
            except Exception:
                warn_fill = None
            missing_bg = warn_fill or "palette(alternate-base)"
            set_bg = "palette(base)"
            if token is None:
                self._target_required_pill.setText("Missing")
                self._target_contract_hint.setText("Required for export.")
                self._target_required_pill.setStyleSheet(
                    f"border: 0px; border-radius: 10px; padding: 2px 8px; font-size: 11px; color: palette(window); background: {warn};"
                )
                self._target_contract_hint.setVisible(True)
                self._target_contract.setStyleSheet(
                    f"QFrame {{ border: 0px; border-radius: 12px; background: {missing_bg}; }}"
                )
            else:
                if str(getattr(token, "kind", "") or "").strip() == "locus" and not self._target_is_bound(sel):
                    self._target_required_pill.setText("Not bound (Draft)")
                    self._target_contract_hint.setText("Bind scope to enable export.")
                    self._target_required_pill.setStyleSheet(
                        f"border: 0px; border-radius: 10px; padding: 2px 8px; font-size: 11px; color: palette(window); background: {warn};"
                    )
                    self._target_contract_hint.setVisible(True)
                    self._target_contract.setStyleSheet(
                        f"QFrame {{ border: 0px; border-radius: 12px; background: {missing_bg}; }}"
                    )
                else:
                    self._target_required_pill.setText("Set")
                    self._target_contract_hint.setText("")
                    self._target_required_pill.setStyleSheet(
                        "border: 1px solid palette(mid); border-radius: 10px; padding: 2px 8px; font-size: 11px; color: palette(mid); background: transparent;"
                    )
                    self._target_contract_hint.setVisible(False)
                    self._target_contract.setStyleSheet(
                        f"QFrame {{ border: 0px; border-radius: 12px; background: {set_bg}; }}"
                    )
        except Exception:
            pass
        try:
            self._render_target_locus_resolution(sel)
        except Exception:
            pass
        try:
            self._intent_completeness.setText(self._intent_completeness_text(sel))
        except Exception:
            pass
        try:
            modality_label = self._label_for(MODALITY_OPTIONS, sel.modality) or str(sel.modality or "").strip()
            self._modality_chip.setText(f"Modality: {modality_label}")
        except Exception:
            pass
        try:
            target_type_label = self._label_for(TARGET_INTENT_OPTIONS, sel.target_intent) or str(sel.target_intent or "").strip()
            self._target_type_chip.setText(f"Target type: {target_type_label}")
        except Exception:
            pass
        try:
            delivery_label = self._label_for(DELIVERY_OPTIONS, sel.delivery_modality) or str(sel.delivery_modality or "").strip()
            self._delivery_chip.setText(f"Delivery: {delivery_label} (assumed)")
        except Exception:
            pass
        try:
            override = bool(getattr(self, "_primary_goal_override_active", False))
            self._primary_goal.setVisible(override)
            self._primary_goal_readonly.setVisible(not override)
            self._primary_goal_readonly.setText(str(self._primary_goal.currentText() or "").strip())
            btn = getattr(self, "_primary_goal_change_btn", None)
            if isinstance(btn, QPushButton):
                btn.setText("Done" if override else "Edit intent")
        except Exception:
            pass
        try:
            self._offtarget_meta_row.setVisible(sel.success_max_high_risk_coding_offtarget_count is not None)
        except Exception:
            pass
        try:
            for w in (self._protein_header_row, self._protein_rationale, self._protein_details_row):
                w.setVisible(bool(is_knockout))
        except Exception:
            pass
        try:
            for w in (self._phenotype_header_row, self._phenotype_rationale, self._phenotype_details_row):
                w.setVisible(bool(is_knockout))
        except Exception:
            pass
        try:
            protein_required = bool(str(self._protein_req.currentData() or "").strip() == "required")
            self._protein_details_row.setVisible(bool(is_knockout and protein_required))
            self._protein_loss_label.setVisible(bool(is_knockout and protein_required))
            if is_knockout:
                self._protein_rationale.setText(
                    "Required to support functional conclusions for this intent."
                    if protein_required
                    else "Not required for this intent."
                )
        except Exception:
            pass
        try:
            phenotype_required = bool(str(self._phenotype_req.currentData() or "").strip() == "required")
            self._phenotype_details_row.setVisible(bool(is_knockout and phenotype_required))
            self._phenotype_label.setVisible(bool(is_knockout and phenotype_required))
            if is_knockout:
                self._phenotype_rationale.setText(
                    "Not required for this intent."
                    if not phenotype_required
                    else "Required to support phenotype conclusions for this intent."
                )
        except Exception:
            pass
        try:
            show_warning = (
                is_knockout
                and sel.success_protein_loss_pct is None
                and sel.success_phenotype_effect_size is None
                and (sel.success_edit_rate_pct > 0)
            )
            self._ko_warning.setVisible(show_warning)
        except Exception:
            pass
        try:
            self._unlocks.setText(self._unlocks_text(sel))
        except Exception:
            pass
        try:
            self._readiness.setText(self._readiness_text(sel))
        except Exception:
            pass
        try:
            self._update_readiness_gate(sel)
        except Exception:
            pass
        try:
            action = self._primary_readiness_action(sel)
            if action is None:
                self._readiness_primary_action_key = None
                self._readiness_primary_action.setVisible(False)
                self._readiness_target_help.setVisible(False)
                self._readiness_target_policy_context.setVisible(False)
            else:
                label, key = action
                self._readiness_primary_action_key = key
                self._readiness_primary_action.setText(label)
                self._readiness_primary_action.setVisible(True)
                show_target_help = key == "set-target"
                self._readiness_target_help.setVisible(show_target_help)
                self._readiness_target_policy_context.setVisible(show_target_help)
        except Exception:
            pass
        try:
            self._export_status.setText(self._export_status_text(sel))
        except Exception:
            pass
        try:
            self._summary.setText(self._summary_text(sel))
        except Exception:
            pass
        try:
            self._policy_effect.setText(self._policy_effect_text(sel))
        except Exception:
            pass
        try:
            self._readout_hint.setText(self._readout_hint_text(sel))
            self._readout_sync.setText(self._readout_sync_text(sel))
            self._readout_sync.setVisible(bool(str(self._readout_sync.text() or "").strip()))
        except Exception:
            pass

    def _update_section_gating(self, sel: ExperimentSetupSelections) -> None:
        sections = getattr(self, "_sections", None)
        if not isinstance(sections, dict):
            return
        has_intent = bool(str(sel.preset_id or "").strip())
        try:
            btn = getattr(self, "_primary_goal_change_btn", None)
            if isinstance(btn, QPushButton):
                btn.setEnabled(has_intent)
                btn.setToolTip("" if has_intent else "Choose an intent template to unlock this.")
        except Exception:
            pass
        for key, (toggle, _body) in sections.items():
            if not isinstance(toggle, QToolButton):
                continue
            toggle.setEnabled(has_intent)
            if not has_intent:
                toggle.setToolTip("Choose an intent template to unlock this section.")
            else:
                toggle.setToolTip("")
        if not has_intent:
            for key in list(sections.keys()):
                self._set_section_expanded(str(key), False)

    def _update_readiness_gate(self, sel: ExperimentSetupSelections) -> None:
        draft_ok, draft_missing = self._draft_ready(sel)
        design_ok, design_missing = self._design_ready(sel)
        run_ok, run_missing = self._run_ready(sel)

        if draft_ok and design_ok and run_ok:
            headline = "Run ready"
            progress = 100
            missing: list[str] = []
        elif draft_ok and design_ok:
            headline = "Run not ready"
            progress = 66
            missing = run_missing
        elif draft_ok:
            headline = "Contract incomplete"
            progress = 33
            missing = design_missing
        else:
            headline = "Draft not ready"
            progress = 0
            missing = draft_missing

        try:
            self._readiness_status.setText(headline)
        except Exception:
            pass
        try:
            self._readiness_progress.setValue(int(progress))
        except Exception:
            pass

        action = self._primary_readiness_action(sel)
        key = ""
        if action is not None:
            _label, key = action

        reason_map = {
            "use-recommended-intent": "Intent not selected",
            "set-target": "Target not defined",
            "focus-hypothesis": "Hypothesis missing",
            "focus-success": "Success criteria incomplete",
            "fix-readout": "Readout plan incomplete",
            "focus-offtarget": "Off-target criteria incomplete",
            "focus-validation": "Validation readout not selected",
            "focus-modality": "Modality not selected",
            "focus-reference": "Reference build not selected",
            "focus-target-type": "Target type not selected",
        }
        reason = reason_map.get(key) if key else None
        if reason is None:
            reason = "All required fields set" if not missing else f"Missing: {missing[0]}"

        # Blockers should read as blockers: use status colors from theme tokens.
        if draft_ok and design_ok and run_ok:
            bg = _status_color_hex("success") or "palette(highlight)"
        else:
            bg = _status_color_hex("warning") or "palette(highlight)"

        try:
            self._readiness_blocker_pill.setText(reason)
            self._readiness_blocker_pill.setStyleSheet(
                f"border: 0px; border-radius: 10px; padding: 3px 10px; font-size: 12px; font-weight: 650; color: palette(window); background: {bg};"
            )
        except Exception:
            pass

        # Keep details collapsed by default until the user opts in.
        try:
            visible = bool(self._readiness_details_container.isVisible())
            self._readiness_details_toggle.setText("Hide details" if visible else "Show details")
        except Exception:
            pass

    def _update_decision_question_default(self, sel: ExperimentSetupSelections) -> None:
        if getattr(self, "_decision_question_user_edited", False):
            if str(sel.decision_question or "").strip():
                return
        derived = self._derived_decision_question(sel)
        if not derived:
            return
        try:
            if str(self._decision_question.text() or "").strip() == derived.strip():
                self._decision_question_user_edited = False
                return
        except Exception:
            pass
        try:
            self._setting_decision_question = True
            self._decision_question.setText(derived)
        except Exception:
            return
        finally:
            self._setting_decision_question = False
        self._decision_question_user_edited = False

    def _derived_decision_question(self, sel: ExperimentSetupSelections) -> str:
        primary_goal = str(sel.primary_goal or "").strip()
        goal_label = None
        for key, label in PRIMARY_GOAL_OPTIONS:
            if key == primary_goal:
                goal_label = label
                break
        goal = goal_label or primary_goal or "Decision"
        tgt = str(sel.perturbation_target or "").strip()
        if tgt and self._target_is_bound(sel):
            return f"{goal}: can we proceed for target '{tgt}'?"
        return f"{goal}: can we proceed?"

    def _intent_completeness_text(self, sel: ExperimentSetupSelections) -> str:
        required: list[str] = [
            "intent template",
            "success criteria",
            "modality",
            "reference build",
            "target type",
            "validation readout",
            "target",
            "hypothesis",
        ]
        if self._required_evidence_tiers(sel):
            required.append("readout plan")
        if sel.success_max_high_risk_coding_offtarget_count is not None:
            required.extend(
                [
                    "off-target method/version",
                    "off-target scope",
                ]
            )

        required_unique: list[str] = []
        seen_required: set[str] = set()
        for item in required:
            if item in seen_required:
                continue
            seen_required.add(item)
            required_unique.append(item)
        required = required_unique

        _draft_ok, draft_missing = self._draft_ready(sel)
        _design_ok, design_missing = self._design_ready(sel)
        _run_ok, run_missing = self._run_ready(sel)
        missing: list[str] = []
        seen_missing: set[str] = set()
        for item in (draft_missing + design_missing + run_missing):
            if item in required and item not in seen_missing:
                seen_missing.add(item)
                missing.append(item)

        total = max(1, len(required))
        pct = int(round(100.0 * (total - len(missing)) / total))
        pct = max(0, min(100, pct))

        label_map = {
            "intent template": "Intent template",
            "success criteria": "Success criteria",
            "modality": "Modality",
            "reference build": "Reference build",
            "target type": "Target type",
            "validation readout": "Validation readout",
            "target": "Target",
            "hypothesis": "Hypothesis",
            "readout plan": "Readout plan",
            "off-target method/version": "Off-target method",
            "off-target scope": "Off-target scope",
        }
        missing_labels = [label_map.get(item, str(item)) for item in missing]
        missing_suffix = f" — Missing: {', '.join(missing_labels)}" if missing_labels else ""
        return f"Intent completeness: {pct}%{missing_suffix}"

    def _primary_readiness_action(self, sel: ExperimentSetupSelections) -> tuple[str, str] | None:
        draft_ok, draft_missing = self._draft_ready(sel)
        design_ok, design_missing = self._design_ready(sel)
        run_ok, run_missing = self._run_ready(sel)

        missing: list[str] = []
        if not draft_ok:
            missing = draft_missing
        elif not design_ok:
            missing = design_missing
        elif not run_ok:
            missing = run_missing
        else:
            return None

        priority = [
            "intent template",
            "target",
            "hypothesis",
            "success criteria",
            "readout plan",
            "off-target method/version",
            "off-target scope",
            "validation readout",
            "modality",
            "reference build",
            "target type",
        ]
        blocker = next((p for p in priority if p in missing), missing[0] if missing else "")

        if blocker == "intent template":
            return ("Use recommended intent", "use-recommended-intent")
        if blocker == "target":
            return ("Define target", "set-target")
        if blocker == "hypothesis":
            return ("Add hypothesis", "focus-hypothesis")
        if blocker == "success criteria":
            return ("Define success criteria", "focus-success")
        if blocker == "readout plan":
            return ("Update readout plan", "fix-readout")
        if blocker in {"off-target method/version", "off-target scope"}:
            return ("Define off-target criteria", "focus-offtarget")
        if blocker == "validation readout":
            return ("Select validation readout", "focus-validation")
        if blocker == "modality":
            return ("Select modality", "focus-modality")
        if blocker == "reference build":
            return ("Select reference build", "focus-reference")
        if blocker == "target type":
            return ("Select target type", "focus-target-type")
        return None

    def _readiness_text(self, sel: ExperimentSetupSelections) -> str:
        template = PRESET_LABELS.get(sel.preset_id or "", "Custom")

        draft_ok, draft_missing = self._draft_ready(sel)
        design_ok, design_missing = self._design_ready(sel)
        run_ok, run_missing = self._run_ready(sel)

        def _format_missing(items: list[str]) -> str:
            parts: list[str] = []
            for item in items:
                if item == "target":
                    parts.append('<b><a href="set-target">Target</a></b>')
                elif item == "readout plan":
                    parts.append('<b><a href="fix-readout">Readout plan</a></b>')
                else:
                    parts.append(str(item))
            return ", ".join(parts)

        def _state_line(name: str, state: str, missing: list[str] | None = None) -> str:
            st = str(state or "").strip().lower()
            if st == "ok":
                return f"{name}: <b>OK</b>"
            if st == "pending":
                return f"{name}: <i>pending</i>"
            detail = _format_missing(missing or []) if (missing or []) else "missing required fields"
            return f"{name}: <b>blocked</b> — Missing: {detail}"

        # Only one stage should present as BLOCKED. Later stages read as PENDING until the blocker is cleared.
        design_state = "pending" if not draft_ok else ("ok" if design_ok else "blocked")
        run_state = "pending" if (not draft_ok or not design_ok) else ("ok" if run_ok else "blocked")

        draft_line = _state_line("Draft-ready", "ok" if draft_ok else "blocked", draft_missing)
        design_line = _state_line("Design-ready", design_state, design_missing if design_state == "blocked" else None)
        run_line = _state_line("Run-ready", run_state, run_missing if run_state == "blocked" else None)

        lines: list[str] = [f"Template: {template}"]
        if draft_ok and design_ok and run_ok:
            lines.append("All stages: OK")
            return "<br>".join(lines).strip()

        # Collapse OK states by default; keep only the active blocker and future stages.
        for state, line in (
            ("ok" if draft_ok else "blocked", draft_line),
            (design_state, design_line),
            (run_state, run_line),
        ):
            if state == "ok":
                continue
            lines.append(line)
        return "<br>".join(lines).strip()

    def _label_for(self, options: tuple[tuple[str, str], ...], key: str) -> str:
        needle = str(key or "").strip()
        if not needle:
            return ""
        for opt_key, label in options:
            if opt_key == needle:
                return label
        return needle

    def _off_target_method_display(self, method: str) -> tuple[str, str]:
        method_id = str(method or "").strip()
        if not method_id:
            return "", ""
        mapping = {
            "offtarget_mismatch_v1": "Mismatch v1",
        }
        label = mapping.get(method_id)
        if label:
            return label, method_id
        return method_id, method_id

    def _assay_label(self, assay_type: str) -> str:
        needle = str(assay_type or "").strip()
        if not needle:
            return ""
        for key, label, _measurement in READOUT_OPTIONS:
            if key == needle:
                return label
        return needle

    def _required_evidence_tiers(self, sel: ExperimentSetupSelections) -> set[str]:
        required: set[str] = set()
        if sel.success_protein_loss_pct is not None:
            required.add("protein")
        if sel.success_phenotype_effect_size is not None:
            required.add("phenotype")
        return required

    def _readout_level_satisfies(self, readout_level: str, required: set[str]) -> bool:
        level = str(readout_level or "").strip()
        if not required:
            return True
        if level == "multiple":
            return True
        if level == "protein":
            return required <= {"protein"}
        if level == "phenotype":
            return required <= {"phenotype"}
        return False

    def _suggested_readout_plan(self, sel: ExperimentSetupSelections) -> tuple[str, str] | None:
        required = self._required_evidence_tiers(sel)
        if not required:
            return None
        if required == {"protein"}:
            return ("protein", "flow")
        if required == {"phenotype"}:
            return ("phenotype", "phenotype")
        if required == {"protein", "phenotype"}:
            return ("multiple", "phenotype")
        return None

    def _on_readiness_link_activated(self, link: str) -> None:
        key = str(link or "").strip().lower()
        if key == "set-target":
            self._focus_target_field()
            return
        if key == "fix-readout":
            self._apply_readout_suggestion()
            return

    def _on_readout_link_activated(self, link: str) -> None:
        self._on_readiness_link_activated(link)

    def _apply_readout_suggestion(self) -> None:
        if getattr(self, "_setting_readout_suggestion", False):
            return
        sel = self._current_selections()
        suggestion = self._suggested_readout_plan(sel)
        if suggestion is None:
            return
        level_key, assay_key = suggestion

        self._setting_readout_suggestion = True
        try:
            self._focus_readout_plan()
            try:
                self._readout_level.blockSignals(True)
                idx = self._readout_level.findData(level_key)
                if idx >= 0:
                    self._readout_level.setCurrentIndex(idx)
            finally:
                self._readout_level.blockSignals(False)

            # Refresh available assays after changing readout level.
            self._constrain_assay_options(self._current_selections())

            try:
                self._readout.blockSignals(True)
                idx = self._readout.findData(assay_key)
                if idx >= 0:
                    self._readout.setCurrentIndex(idx)
            finally:
                self._readout.blockSignals(False)
        finally:
            self._setting_readout_suggestion = False
        self._refresh_preview()

    def _focus_readout_plan(self) -> None:
        self._set_section_expanded("sec4", True)
        self._focus_widget(self._readout_level)

    def _allowed_assay_keys(self, sel: ExperimentSetupSelections) -> list[str]:
        # Keep this conservative: the combo should not allow nonsensical primary measurements.
        level = str(sel.readout_level or "").strip()
        preset = str(sel.preset_id or "").strip()
        if preset == "off_target_screening":
            return ["wgs"]
        if level == "dna_only":
            return ["ampseq", "wgs"]
        if level == "protein":
            return ["flow", "western", "ms"]
        if level == "phenotype":
            return ["phenotype"]
        return ["ampseq", "flow", "western", "ms", "wgs", "phenotype"]

    def _constrain_assay_options(self, sel: ExperimentSetupSelections) -> None:
        allowed = self._allowed_assay_keys(sel)
        if not allowed:
            return
        try:
            current_keys = [str(self._readout.itemData(i) or "") for i in range(int(self._readout.count()))]
        except Exception:
            current_keys = []
        if current_keys == allowed:
            return

        current = str(sel.assay_type or "").strip()
        try:
            self._readout.blockSignals(True)
            self._readout.clear()
            for key, label, _measurement in READOUT_OPTIONS:
                if key in allowed:
                    self._readout.addItem(label, key)
            idx = self._readout.findData(current)
            if idx >= 0:
                self._readout.setCurrentIndex(idx)
            else:
                self._readout.setCurrentIndex(0)
        finally:
            try:
                self._readout.blockSignals(False)
            except Exception:
                pass

    def _readout_hint_text(self, sel: ExperimentSetupSelections) -> str:
        level = str(sel.readout_level or "").strip()
        base = "Readout level must cover the highest required evidence tier."
        if level == "dna_only":
            base += " DNA-only supports Tier A evidence."
            if str(sel.target_intent or "").strip().lower() == "knockout":
                base += " Not sufficient for functional conclusions."
        elif level == "protein":
            base += " Supports Tier A + Tier B evidence."
        elif level == "phenotype":
            base += " Supports Tier A + Tier C evidence."
        else:
            base += " Supports Tier A + Tier B/C evidence."

        required = self._required_evidence_tiers(sel)
        if not required:
            return base

        ordered = [k for k in ("protein", "phenotype") if k in required]
        tiers = " + ".join([t.capitalize() for t in ordered]) if ordered else "Required"
        return f"{base} Required evidence: {tiers}."

    def _readout_sync_text(self, sel: ExperimentSetupSelections) -> str:
        required = self._required_evidence_tiers(sel)
        if not required:
            return ""
        if self._readout_level_satisfies(sel.readout_level, required):
            return ""
        current = self._label_for(READOUT_LEVEL_OPTIONS, sel.readout_level) or str(sel.readout_level or "").strip()
        ordered = [k for k in ("protein", "phenotype") if k in required]
        tiers = " and ".join([t.capitalize() for t in ordered]) if ordered else "Required"
        return (
            f"{tiers} evidence is required, but Readout level is {current}. "
            + '<a href="fix-readout">Update readout plan</a> to proceed to Run-ready.'
        )

    def _policy_effect_text(self, sel: ExperimentSetupSelections) -> str:
        output_class = str(sel.output_class or "").strip()
        label = self._label_for(OUTPUT_CLASS_OPTIONS, output_class) or output_class
        if output_class.lower() == "decision_candidate":
            return (
                f"Policy effect: {label}\n"
                "• Labeling: decision-grade candidate (strict defaults)\n"
                "• Exports: blocked until intent + readiness gates pass\n"
                "• Off-target: required by default under strict policy"
            )
        return (
            f"Policy effect: {label}\n"
            "• Labeling: exploratory (not decision-grade)\n"
            "• Exports: blocked until intent + readiness gates pass\n"
            "• Policy: faster defaults (still deterministic)"
        )

    def _export_status_text(self, sel: ExperimentSetupSelections) -> str:
        design_ok, design_missing = self._design_ready(sel)
        run_ok, run_missing = self._run_ready(sel)
        if run_ok:
            return "Exports: <b>Allowed</b> (subject to policy gates)"

        def _unblock_by(items: list[str]) -> str:
            actions: list[str] = []
            if "target" in items:
                actions.append('<a href="set-target">Define genomic target</a>')
            if "readout plan" in items:
                actions.append('<a href="fix-readout">Update readout plan</a>')
            return ("<br>Unblock by: " + " · ".join(actions)) if actions else ""

        if not design_ok:
            missing = ", ".join(['<a href="set-target">Target</a>' if x == "target" else str(x) for x in design_missing])
            return (
                f"Exports: <b>Blocked</b> (Design-ready: NO → missing: {missing})"
                + _unblock_by(design_missing)
            )
        missing = ", ".join(['<a href="set-target">Target</a>' if x == "target" else str(x) for x in run_missing])
        if "readout plan" in run_missing:
            missing = missing.replace("readout plan", '<a href="fix-readout">Readout plan</a>')
        return f"Exports: <b>Blocked</b> (Run-ready: NO → missing: {missing})" + _unblock_by(run_missing)

    def _export_status_plain(self, sel: ExperimentSetupSelections) -> str:
        design_ok, design_missing = self._design_ready(sel)
        run_ok, run_missing = self._run_ready(sel)
        if run_ok:
            return "Allowed"
        missing = design_missing if not design_ok else run_missing
        detail = ", ".join([str(x) for x in missing if str(x)]) if missing else "missing required fields"
        return f"Blocked (missing: {detail})"

    def _summary_text(self, sel: ExperimentSetupSelections) -> str:
        decision = str(sel.decision_question or "").strip() or self._derived_decision_question(sel)
        criteria_bits: list[str] = []
        if sel.success_edit_rate_pct > 0:
            criteria_bits.append(f"edit rate ≥ {sel.success_edit_rate_pct:.0f}%")
        if sel.success_max_high_risk_coding_offtarget_count is not None:
            criteria_bits.append(f"high-risk coding off-targets ≤ {int(sel.success_max_high_risk_coding_offtarget_count)}")
        if sel.success_requires_editable:
            criteria_bits.append("editable within modality constraints")
        if sel.success_protein_loss_pct is not None:
            day = int(sel.success_protein_loss_day or 0)
            criteria_bits.append(
                f"protein loss ≥ {float(sel.success_protein_loss_pct):.0f}% @ day {day}" if day > 0 else f"protein loss ≥ {float(sel.success_protein_loss_pct):.0f}%"
            )
        if sel.success_phenotype_effect_size is not None:
            day = int(sel.success_phenotype_effect_day or 0)
            criteria_bits.append(
                f"phenotype effect ≥ {float(sel.success_phenotype_effect_size):g} @ day {day}"
                if day > 0
                else f"phenotype effect ≥ {float(sel.success_phenotype_effect_size):g}"
            )
        criteria = ", ".join(criteria_bits) if criteria_bits else "(none)"
        token = self._target_field.token()
        target_lines: list[str] = []
        if token is None:
            target_lines.append("• Target: Not set (Draft)")
        elif str(getattr(token, "kind", "") or "").strip() == "locus":
            target_lines.append(f"• Target locus: {token.display_line()}")
            state = getattr(self, "_target_locus_resolution", None)
            scope_line = "Not set (Draft)"
            if isinstance(state, TargetLocusResolutionState):
                scope = state.scope
                if scope.mode == "gene":
                    if state.gene_summary is not None and state.gene_summary.exon_range:
                        scope_line = f"{scope.gene_symbol} (exons {state.gene_summary.exon_range})"
                    else:
                        scope_line = scope.gene_symbol or "Gene"
                elif scope.mode == "multi":
                    scope_line = "Multiple genes/features"
                elif scope.mode == "noncoding":
                    scope_line = "Non-coding region"
                elif scope.mode == "custom":
                    scope_line = scope.custom_label or "Custom feature"
            target_lines.append(f"• Scoped feature: {scope_line}")
        else:
            target_lines.append(f"• Target: {token.display_line()}")
        hypothesis_line = str(sel.hypothesis or "").strip() or "Not set"
        off_target_line = ""
        if sel.success_max_high_risk_coding_offtarget_count is not None:
            basis = self._label_for(OFF_TARGET_BASIS_OPTIONS, sel.off_target_basis)
            scope = self._label_for(OFF_TARGET_SCOPE_OPTIONS, sel.off_target_scope)
            method_label, method_id = self._off_target_method_display(sel.off_target_method)
            meta_parts = [x for x in (basis, scope, method_label) if x]
            meta = " · ".join(meta_parts) if meta_parts else "Not specified"
            if method_id and method_id != method_label:
                meta = f"{meta} ({method_id})"
            off_target_line = f"• Off-target definition: {meta}"

        readout_level_label = self._label_for(READOUT_LEVEL_OPTIONS, sel.readout_level) or str(sel.readout_level or "").strip()
        assay_label = self._assay_label(sel.assay_type)
        output_class_label = self._label_for(OUTPUT_CLASS_OPTIONS, sel.output_class) or str(sel.output_class or "").strip()

        lines = [
            f"• Decision: {decision}",
            *target_lines,
            f"• Hypothesis: {hypothesis_line}",
            f"• Success: {criteria}",
            off_target_line,
            f"• Readout: {readout_level_label} / {assay_label}",
            f"• Constraints: {sel.modality}, {sel.delivery_modality}, {sel.cell_context}, {sel.experiment_scale}",
            f"• Export policy: {output_class_label}",
            f"• Export status: {self._export_status_plain(sel)}",
        ]
        return "\n".join([x for x in lines if x]).strip()

    def _unlocks_text(self, sel: ExperimentSetupSelections) -> str:
        items: list[str] = []
        items.append("Instantiates an Experiment Intent Spec (decision contract) and binds it to this session.")
        items.append("Configures rails and evidence requirements around the selected goal.")
        items.append("Blocks guide/evidence exports until wet-lab readiness gates pass (controls, assay, decision framing).")
        if str(sel.output_class or "").strip().lower() == "decision_candidate":
            items.append("Uses strict policy defaults (off-target required; deterministic replay requirements).")
        else:
            items.append("Labels outputs as exploratory by default (watermarked exports where applicable).")
        if str(sel.target_intent or "").strip().lower() == "knockout":
            items.append("Knockout intent: add protein/phenotype criteria when you need functional conclusions.")
        return "\n".join([f"• {x}" for x in items if x])

    def _on_create_clicked(self) -> None:
        sel = self._current_selections()
        if not self._is_valid(sel):
            return
        intent, exp_spec, cfg_patch, rail_segment = self._build_payload()
        output_class = str(sel.output_class or "").strip()
        self._result = ExperimentSetupResult(
            experiment_intent_spec=intent,
            experiment_spec=exp_spec,
            config_patch=cfg_patch,
            initial_rail_segment_id=rail_segment,
            session_class=session_class_for_output_class(output_class),
            preset_id=sel.preset_id,
            primary_goal=str(sel.primary_goal),
            output_class=output_class,
        )
        self.accept()

    def _on_save_template_clicked(self) -> None:
        try:
            intent, exp_spec, cfg_patch, rail_segment = self._build_payload()
        except Exception:
            return
        default_name = str(Path.cwd() / "helix_experiment_template.json")
        path_str, _ = QFileDialog.getSaveFileName(self, "Save experiment template", default_name, "JSON (*.json)")
        if not path_str:
            return
        template = {
            "schema": "helix.experiment.template/v1",
            "experiment_intent_spec": intent,
            "experiment_spec": exp_spec,
            "session_config_patch": cfg_patch,
            "initial_rail_segment_id": rail_segment,
        }
        try:
            Path(path_str).write_text(json.dumps(template, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
        except Exception:
            return

    def result_payload(self) -> ExperimentSetupResult | None:
        return self._result


__all__ = ["ExperimentSetupDialog", "ExperimentSetupResult"]
