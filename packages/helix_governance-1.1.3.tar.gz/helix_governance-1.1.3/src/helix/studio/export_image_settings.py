from __future__ import annotations

from typing import Any

from helix.support.build_meta import is_enterprise_build

SETTINGS_ORG = "Helix"
SETTINGS_APP = "Studio"

SETTINGS_WRITE_IMAGE_PROVENANCE_SIDECAR_KEY = "exports/write_image_provenance_sidecar"


def _boolish(value: Any, *, default: bool) -> bool:
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        token = value.strip().lower()
        if token in {"0", "false", "no", "off"}:
            return False
        if token in {"1", "true", "yes", "on"}:
            return True
    return bool(default)


def write_image_provenance_sidecars_enabled(*, settings: object | None = None) -> bool:
    """
    Whether Studio should emit `*.png.provenance.json` sidecars for bitmap exports.

    Enterprise builds always force this ON.
    """
    if is_enterprise_build():
        return True
    try:
        from PySide6.QtCore import QSettings  # type: ignore
    except Exception:
        return True
    s = settings if isinstance(settings, QSettings) else QSettings(SETTINGS_ORG, SETTINGS_APP)
    return _boolish(s.value(SETTINGS_WRITE_IMAGE_PROVENANCE_SIDECAR_KEY, True), default=True)


def set_write_image_provenance_sidecars_enabled(enabled: bool, *, settings: object | None = None) -> None:
    try:
        from PySide6.QtCore import QSettings  # type: ignore
    except Exception:
        return
    s = settings if isinstance(settings, QSettings) else QSettings(SETTINGS_ORG, SETTINGS_APP)
    s.setValue(SETTINGS_WRITE_IMAGE_PROVENANCE_SIDECAR_KEY, bool(enabled))


__all__ = [
    "SETTINGS_WRITE_IMAGE_PROVENANCE_SIDECAR_KEY",
    "write_image_provenance_sidecars_enabled",
    "set_write_image_provenance_sidecars_enabled",
]

