from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence


# Canonical pathway ids used across Helix (lowercase, stable for exports).
PATHWAY_NO_CUT = "no_cut"
PATHWAY_NHEJ = "nhej"
PATHWAY_MMEJ = "mmej"
PATHWAY_RELIGATION = "religation"
PATHWAY_HDR = "hdr"
PATHWAY_OTHER = "other"

PATHWAY_ORDER: tuple[str, ...] = (
    PATHWAY_NO_CUT,
    PATHWAY_NHEJ,
    PATHWAY_MMEJ,
    PATHWAY_RELIGATION,
    PATHWAY_HDR,
    PATHWAY_OTHER,
)

PATHWAY_UI_LABEL: Mapping[str, str] = {
    PATHWAY_NO_CUT: "No cut / escape",
    PATHWAY_NHEJ: "NHEJ",
    PATHWAY_MMEJ: "MMEJ",
    PATHWAY_RELIGATION: "Religation",
    PATHWAY_HDR: "HDR",
    PATHWAY_OTHER: "Other",
}


@dataclass(frozen=True, slots=True)
class RepairPathway:
    """
    A derived mixture component over outcomes.

    This is a representation layer: it does not change any underlying simulation
    math. It exposes a mechanistic narrative for reviewers and UI tooling:

        P(outcome) = Σ_pathway P(pathway) * P(outcome | pathway)
    """

    pathway: str
    probability_mass: float  # P(pathway)
    outcome_distribution: tuple[tuple[str, float], ...]  # P(outcome | pathway)

    @property
    def ui_label(self) -> str:
        return str(PATHWAY_UI_LABEL.get(self.pathway, self.pathway))


def classify_repair_pathway(*, label: str, category: str | None = None) -> str:
    """
    Heuristic pathway classifier used to derive a mixture view.

    The classifier is intentionally conservative: it prefers `other` unless a
    label/category strongly implies a pathway.
    """

    lab = str(label or "").strip()
    cat = str(category or "").strip().lower()
    norm = lab.lower()

    if cat == "no_cut" or "no_cut" in norm or "uncut" in norm or "no cut" in norm:
        return PATHWAY_NO_CUT

    # Microhomology-mediated end joining (MMEJ / alt-EJ).
    if "microhomology" in norm or "mmej" in norm or "alt-ej" in norm or "altej" in norm:
        return PATHWAY_MMEJ

    # Simple religation / reanneal / perfect repair labels.
    if "religation" in norm or "re-ligation" in norm or "reanneal" in norm or "re-anneal" in norm:
        return PATHWAY_RELIGATION

    # HDR labels, when present in producers.
    if "hdr" in norm:
        return PATHWAY_HDR

    # If the producer already tagged this as "other", keep it separate to avoid
    # implying DSB-mechanistic specificity for an aggregated bucket (e.g. tail).
    if cat in {"other", "unknown"}:
        return PATHWAY_OTHER

    # Prime-editing / non-DSB categories: keep separate.
    if cat in {"intended", "intended_edit", "desired", "byproduct", "indel"}:
        return PATHWAY_OTHER

    # Prime-editing style categories ("desired"/"byproduct") and other non-DSB
    # producers should not be force-mapped into NHEJ.
    if cat and ("deletion" not in cat and "insertion" not in cat and cat not in {"frameshift"}):
        if cat not in {"small_deletion", "small_insertion", "large_deletion", "large_insertion"}:
            return PATHWAY_OTHER

    # Default: treat as canonical NHEJ bucket.
    return PATHWAY_NHEJ


def build_repair_pathway_mixture(
    outcomes: Iterable[Mapping[str, object]],
    *,
    label_key: str = "label",
    category_key: str = "category",
    probability_key: str = "probability",
) -> tuple[RepairPathway, ...]:
    """
    Build a pathway mixture from an outcome distribution.

    Input is a sequence of dict-like outcome objects (e.g. rows/bars) containing:
      - `label` (str)
      - `category` (str, optional)
      - `probability` (float)
    """

    by_path: dict[str, list[tuple[str, float]]] = {k: [] for k in PATHWAY_ORDER}
    for oc in outcomes:
        try:
            label = str(oc.get(label_key) or "")
            if not label:
                continue
            prob = float(oc.get(probability_key) or 0.0)
            if prob <= 0.0:
                continue
            category = oc.get(category_key)
            pathway = classify_repair_pathway(label=label, category=str(category) if category is not None else None)
            if pathway not in by_path:
                by_path[pathway] = []
            by_path[pathway].append((label, prob))
        except Exception:
            continue

    mixture: list[RepairPathway] = []
    for pathway in PATHWAY_ORDER:
        pairs = by_path.get(pathway) or []
        mass = sum(p for _, p in pairs)
        if mass <= 0.0:
            continue
        # Deterministic ordering: descending unconditional probability, then label.
        pairs_sorted = sorted(pairs, key=lambda x: (-float(x[1]), str(x[0])))
        cond = tuple((lab, float(p) / float(mass)) for lab, p in pairs_sorted if p > 0.0)
        mixture.append(RepairPathway(pathway=pathway, probability_mass=float(mass), outcome_distribution=cond))

    # Normalize small float drift so downstream UIs can rely on sum≈1.
    tot = sum(p.probability_mass for p in mixture)
    if tot > 0.0 and abs(tot - 1.0) > 1e-8:
        mixture = [
            RepairPathway(
                pathway=p.pathway,
                probability_mass=float(p.probability_mass) / float(tot),
                outcome_distribution=p.outcome_distribution,
            )
            for p in mixture
        ]
    return tuple(mixture)


def pathway_mass_by_id(pathways: Sequence[RepairPathway]) -> dict[str, float]:
    return {p.pathway: float(p.probability_mass) for p in pathways}


def build_stochastic_narrative_v1(pathways: Sequence[RepairPathway]) -> dict[str, object]:
    """
    Return a deterministic, reviewer-facing stochastic narrative (no sampling).
    """

    mass = pathway_mass_by_id(pathways)
    no_cut = float(mass.get(PATHWAY_NO_CUT, 0.0))
    cut = max(0.0, min(1.0, 1.0 - no_cut))
    denom = cut if cut > 0.0 else 1.0
    given_cut = {
        p.pathway: (float(p.probability_mass) / denom)
        for p in pathways
        if p.pathway not in {PATHWAY_NO_CUT} and float(p.probability_mass) > 0.0
    }

    return {
        "version": "1",
        "steps": [
            {"name": "cleavage", "Pc": cut, "P_no_cut": no_cut},
            {"name": "pathway_choice_given_cleavage", "P_pathway_given_cut": given_cut},
            {
                "name": "outcome_given_pathway",
                "P_outcome_given_pathway": {p.pathway: dict(p.outcome_distribution) for p in pathways},
            },
        ],
        "mixture_identity": "P(outcome) = sum_pathway P(pathway)*P(outcome|pathway)",
        "note": "Derived from labeled outcomes; pathway assignment is heuristic unless explicitly emitted by the simulator.",
    }


__all__ = [
    "RepairPathway",
    "PATHWAY_NO_CUT",
    "PATHWAY_NHEJ",
    "PATHWAY_MMEJ",
    "PATHWAY_RELIGATION",
    "PATHWAY_HDR",
    "PATHWAY_OTHER",
    "PATHWAY_ORDER",
    "PATHWAY_UI_LABEL",
    "classify_repair_pathway",
    "build_repair_pathway_mixture",
    "pathway_mass_by_id",
    "build_stochastic_narrative_v1",
]
