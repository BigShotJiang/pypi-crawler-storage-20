from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from helix.support.build_meta import build_info


class AboutDialog(QDialog):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("About Helix Studio")
        self.setModal(True)
        self.resize(560, 260)

        info = build_info()
        version = info.get("helix_version", "")
        sha = info.get("git_sha", "")
        built = info.get("build_date_utc", "")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Helix Studio", self)
        title.setStyleSheet("font-weight: 650; font-size: 16px; color: #f4f6ff;")
        layout.addWidget(title)

        rows = []
        if version:
            rows.append(f"Version: {version}")
        if sha:
            rows.append(f"Git SHA: {sha}")
        if built:
            rows.append(f"Build date (UTC): {built}")
        if not rows:
            rows.append("Build info unavailable.")

        body = QLabel("\n".join(rows), self)
        body.setTextInteractionFlags(Qt.TextSelectableByMouse)
        body.setStyleSheet("color: rgba(210,220,240,0.9); font-size: 12px;")
        layout.addWidget(body)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy", self)
        copy_btn.clicked.connect(lambda: self._copy_to_clipboard("\n".join(rows)))
        actions.addWidget(copy_btn)

        close_btn = QPushButton("Close", self)
        close_btn.clicked.connect(self.accept)
        actions.addWidget(close_btn)

        layout.addStretch(1)
        layout.addLayout(actions)

    def _copy_to_clipboard(self, text: str) -> None:
        try:
            QGuiApplication.clipboard().setText(text)
        except Exception:
            pass


__all__ = ["AboutDialog"]

