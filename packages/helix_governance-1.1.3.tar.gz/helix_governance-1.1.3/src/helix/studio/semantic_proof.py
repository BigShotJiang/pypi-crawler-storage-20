from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Sequence


def _canonical_bytes(payload: Mapping[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": ")) + "\n").encode("utf-8")


def build_causal_proof(
    *,
    nodes: Sequence[Mapping[str, Any]],
    edges: Sequence[Mapping[str, Any]],
    constraints: Sequence[Mapping[str, Any]] | None = None,
    model_versions: Mapping[str, Any] | None = None,
    input_seal: Mapping[str, Any] | None = None,
    proof_version: str = "v1",
) -> dict[str, Any]:
    constraints = list(constraints or [])
    model_versions = dict(model_versions or {})
    input_seal = dict(input_seal or {})

    nodes_sorted = sorted(nodes, key=lambda n: str(n.get("id") or n.get("node_id") or ""))
    edges_sorted = sorted(
        edges,
        key=lambda e: (str(e.get("source") or ""), str(e.get("target") or ""), str(e.get("rule") or "")),
    )
    constraints_sorted = sorted(
        constraints,
        key=lambda c: (str(c.get("edge_id") or ""), str(c.get("type") or "")),
    )

    claims = [
        {
            "claim_id": f"state:{node.get('id') or node.get('node_id')}",
            "statement": "State exists at node",
            "node_id": node.get("id") or node.get("node_id"),
            "semantics": node.get("semantics"),
        }
        for node in nodes_sorted
    ]
    premises = [
        {
            "premise_id": f"edge:{edge.get('source')}->{edge.get('target')}",
            "source": edge.get("source"),
            "target": edge.get("target"),
            "rule": edge.get("rule"),
            "branch_probability": edge.get("branch_probability"),
            "constraints": edge.get("constraints"),
        }
        for edge in edges_sorted
    ]
    evidence_links = []
    for claim in claims:
        sem = claim.get("semantics") if isinstance(claim.get("semantics"), Mapping) else {}
        evidence = sem.get("evidence") if isinstance(sem, Mapping) else None
        if evidence:
            evidence_links.append({"claim_id": claim["claim_id"], "evidence": evidence})

    proof_graph = {
        "proof_version": proof_version,
        "claims": claims,
        "premises": premises,
        "constraints": constraints_sorted,
        "evidence_links": evidence_links,
        "inference_rules": [
            "causal_transition",
            "mass_conservation",
            "constraint_satisfaction",
        ],
        "confidence_aggregation": {
            "method": "min",
            "notes": "confidence uses minimum of linked evidence/confidence until calibrated aggregation is supplied",
        },
        "model_versions": model_versions,
        "input_seal": input_seal,
    }

    proof_hash = hashlib.sha256(_canonical_bytes(proof_graph)).hexdigest()
    proof_graph["proof_hash"] = proof_hash
    return proof_graph


__all__ = ["build_causal_proof"]
