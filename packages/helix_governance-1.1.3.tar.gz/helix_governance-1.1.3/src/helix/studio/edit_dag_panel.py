from __future__ import annotations

import json
import hashlib
import html
import math
import os
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, asdict, is_dataclass
from helix import clock
from typing import Any, Callable
from enum import Enum

try:  # Optional dependency; DAG panel is not required for most Studio workflows/tests.
    import networkx as nx
except Exception:  # pragma: no cover
    nx = None  # type: ignore[assignment]
from PySide6.QtCore import QEvent, QObject, QPointF, Qt, Signal
from PySide6.QtGui import QColor, QBrush, QFont, QLinearGradient, QPainter, QPainterPath, QPalette, QPen
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QDialog,
    QFrame,
    QFileDialog,
    QGraphicsDropShadowEffect,
    QGraphicsItem,
    QGraphicsPathItem,
    QGraphicsScene,
    QGraphicsTextItem,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QPlainTextEdit,
    QSizePolicy,
    QStackedLayout,
    QTabWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from helix.edit.dag import EditDAG, EditNode, dag_from_payload
from helix.provenance import current_git_sha
from helix.studio.limitations import open_limitations, limitations_doc_url
from helix.studio.offtargets.tail_risk_helpers import (
    DOMINANT_CALLOUT_TEXT,
    TailRiskEntry,
    build_tail_risk_entries,
    tail_risk_flag_from_config,
    update_tail_risk_flag,
)
from helix.studio.sink_ui_helpers import SINK_TOOLTIP, format_mass_audit_line, sink_badge_and_tooltip
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.models import RunModel
from helix.studio.session import ExperimentState, RunKind, SessionModel
from helix.studio.suggestions import SOURCE_USER_APPLIED, actionable, suggestions_enabled
from helix.studio.workers import CancelToken, run_bg
from helix.studio.semantic_schema import (
    CalibrationBadge,
    CausalRole,
    EdgeConstraints,
    Evidence,
    EvidenceType,
    MassAudit,
    PhysicalState,
    ScalarValue,
    SemanticBinding,
    TimeLocality,
    TimeStage,
    Unit,
    build_provenance,
    build_scalar,
    build_uncertainty,
    format_scalar,
    unknown,
    validate_semantic_binding,
)
from helix.studio.semantic_audit import SuppressedNode, audit_mass_conservation, max_mass_violation
from helix.studio.semantic_proof import build_causal_proof
from helix.studio.run_artifact import (
    artifact_is_valid,
    artifact_root_causes,
    artifact_decision_mode_eligible,
)
from helix.studio.ui_tokens import base_font, monospace_font


def require_networkx():
    if nx is None:
        raise RuntimeError("Edit DAG view requires 'networkx'. Install the Helix Studio realtime extras.")
    return nx


DECISION_VIEW_ENV = "HELIX_STUDIO_DAG_DECISION_VIEW"
TAIL_RISK_TOP_K_ENV = "HELIX_STUDIO_DAG_TAIL_RISK_TOP_K"
TAIL_RISK_TOP_K_DEFAULT = 5
LARGE_DELETION_BP_DEFAULT = 20


def _approx_display_band(value: float) -> tuple[float, float, int]:
    """
    Return a coarse [low, high] band to avoid implying false numeric precision.

    This is a display-only approximation (not a statistical CI).
    """

    v = max(0.0, min(1.0, float(value)))
    if v <= 0.0:
        return 0.0, 0.0, 1
    if v >= 1.0:
        return 1.0, 1.0, 1
    if v >= 0.1:
        step, decimals = 0.1, 1
    elif v >= 0.01:
        step, decimals = 0.01, 2
    elif v >= 0.001:
        step, decimals = 0.001, 3
    else:
        step, decimals = 0.0001, 4
    low = math.floor(v / step) * step
    high = min(1.0, low + step)
    return round(float(low), decimals), round(float(high), decimals), decimals


def _format_weight_display(*, label: str, value: float, exact: bool) -> str:
    if exact:
        return f"{label}={float(value):.4f}"
    low, high, decimals = _approx_display_band(value)
    if low == high:
        return f"{label}≈{low:.{decimals}f}"
    return f"{label}≈{low:.{decimals}f}–{high:.{decimals}f}"


def _format_outcome_receipt_markdown(receipt: Mapping[str, Any]) -> str:
    def _line(label: str, value: object | None) -> str | None:
        if value is None:
            return None
        text = str(value).strip()
        if not text:
            return None
        return f"- {label}: `{text}`"

    lines: list[str] = ["# Outcome summary receipt", ""]
    lines.append(f"- Schema: `{str(receipt.get('schema') or '').strip()}`")
    created = _line("Created (UTC)", receipt.get("created_at_utc"))
    if created:
        lines.append(created)
    rhash = _line("Receipt hash", receipt.get("receipt_hash"))
    if rhash:
        lines.append(rhash)
    lines.append("")

    run = receipt.get("run") if isinstance(receipt.get("run"), Mapping) else {}
    run_kind = str(run.get("run_kind") or "").strip()
    run_id = run.get("run_id")
    if run_kind or run_id is not None:
        lines.append(f"- Run: `{run_kind or 'run'}` `{run_id}`".rstrip())
    artifact_hash = _line("Run artifact hash", run.get("run_artifact_hash"))
    if artifact_hash:
        lines.append(artifact_hash)

    input_block = receipt.get("input") if isinstance(receipt.get("input"), Mapping) else {}
    input_digest = _line("Input digest", input_block.get("input_digest"))
    if input_digest:
        lines.append(input_digest)
    intent_sha = _line("Experiment intent spec sha256", input_block.get("experiment_intent_spec_sha256"))
    if intent_sha:
        lines.append(intent_sha)
    spec_sha = _line("Experiment spec sha256", input_block.get("experiment_spec_sha256"))
    if spec_sha:
        lines.append(spec_sha)
    lines.append("")

    summary = str(receipt.get("summary_sentence") or "").strip()
    if summary:
        lines.append("## Summary")
        lines.append(summary)
        lines.append("")

    conf = receipt.get("confidence") if isinstance(receipt.get("confidence"), Mapping) else {}
    level = str(conf.get("level") or "").strip()
    reasons = conf.get("reasons") if isinstance(conf.get("reasons"), list) else []
    if level:
        extra = f" ({', '.join(str(r) for r in reasons if r)})" if reasons else ""
        lines.append(f"- Confidence: {level}{extra}")
    calib = receipt.get("calibration") if isinstance(receipt.get("calibration"), Mapping) else {}
    cal_badge = str(calib.get("badge") or "").strip()
    if cal_badge:
        lines.append(f"- Calibration: `{cal_badge}`")
    lines.append("")

    dag = receipt.get("dag") if isinstance(receipt.get("dag"), Mapping) else {}
    dom_path = dag.get("dominant_path") if isinstance(dag.get("dominant_path"), list) else []
    if dom_path:
        titles: list[str] = []
        for step in dom_path:
            if not isinstance(step, Mapping):
                continue
            t = str(step.get("title") or step.get("id") or "").strip()
            if t:
                titles.append(t)
        if titles:
            lines.append("## Dominant path")
            lines.append(" → ".join(titles))
            lines.append("")

    top = dag.get("top_outcomes") if isinstance(dag.get("top_outcomes"), list) else []
    if top:
        lines.append("## Top outcomes")
        for idx, item in enumerate(top, start=1):
            if not isinstance(item, Mapping):
                continue
            title = str(item.get("title") or item.get("id") or "").strip()
            display = str(item.get("display") or "").strip()
            suffix = f" ({display})" if display else ""
            lines.append(f"{idx}. {title}{suffix}".rstrip())
        lines.append("")

    limitations = receipt.get("limitations") if isinstance(receipt.get("limitations"), Mapping) else {}
    notes = limitations.get("notes") if isinstance(limitations.get("notes"), list) else []
    url = str(limitations.get("url") or "").strip()
    if notes or url:
        lines.append("## Limitations")
        if url:
            lines.append(f"- See: {url}")
        for note in notes:
            text = str(note).strip()
            if text:
                lines.append(f"- {text}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _humanize_label(label: str) -> str:
    text = str(label or "").strip()
    if not text:
        return ""
    if any(ch in text for ch in ("_", "-")):
        return text.replace("_", " ").replace("-", " ").strip().title()
    if " " not in text and text.islower():
        return text.title()
    return text


def _node_label(node: EditNode | None) -> str | None:
    if node is None:
        return None
    meta = node.metadata if isinstance(getattr(node, "metadata", None), Mapping) else {}
    for key in ("label", "outcome_label", "name", "display_label"):
        raw = meta.get(key)
        if isinstance(raw, str) and raw.strip():
            return raw.strip()
    diffs = getattr(node, "diffs", ()) or ()
    for diff in diffs:
        try:
            diff_meta = diff.metadata if isinstance(getattr(diff, "metadata", None), Mapping) else {}
        except Exception:
            diff_meta = {}
        for key in ("label", "outcome_label", "name"):
            raw = diff_meta.get(key)
            if isinstance(raw, str) and raw.strip():
                return raw.strip()
    return None


def _node_delta_summary(node: EditNode | None) -> str | None:
    if node is None:
        return None
    diffs = getattr(node, "diffs", ()) or ()
    if not diffs:
        return None
    event = diffs[-1]
    try:
        start = int(getattr(event, "start", 0))
        end = int(getattr(event, "end", start))
        repl = str(getattr(event, "replacement", "") or "")
        span = max(0, end - start)
        if span == 0 and repl:
            return f"ins{len(repl)}"
        if span > 0 and not repl:
            return f"del{span}"
        if span > 0 and repl:
            return f"replace{span}→{len(repl)}"
        return "no-op"
    except Exception:
        return None


def _format_node_title(*, stage: str, node: EditNode | None, role: str) -> str:
    stage_key = str(stage or "unknown").strip().lower()
    default = str(stage or "unknown").replace("_", " ").strip().title() or "Unknown"
    if stage_key == "cut":
        # Avoid overloading "Cut" as an outcome; this is the branching event.
        return "DSB Event"
    if stage_key == "repaired":
        label = _node_label(node)
        delta = _node_delta_summary(node)
        base = _humanize_label(label) if label else "Repair outcome"
        if delta and delta != "no-op":
            return f"{base} ({delta})"
        return base
    if stage_key in {"no_edit", "no_cut"} and role == "terminal":
        return "No edit"
    return default


def _is_empty_payload(payload: object) -> bool:
    if payload is None:
        return True
    if isinstance(payload, (bytes, bytearray)):
        try:
            payload = payload.decode("utf-8")
        except Exception:
            return False
    if isinstance(payload, str):
        return not payload.strip()
    if isinstance(payload, Mapping):
        if not payload:
            return True
        nodes = payload.get("nodes")
        edges = payload.get("edges")
        frames = payload.get("frames")
        if isinstance(nodes, Mapping) and not nodes:
            return True
        if isinstance(frames, Sequence) and not frames:
            return True
        if isinstance(edges, Sequence) and not edges and isinstance(nodes, Mapping) and not nodes:
            return True
        return False
    if isinstance(payload, Sequence):
        return len(payload) == 0
    return False


def _frames_to_artifact_payload(frames: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    nodes: dict[str, Any] = {}
    edges: list[Any] = []
    root_id: str | None = None
    for frame in frames:
        if not isinstance(frame, Mapping):
            continue
        new_nodes = frame.get("new_nodes") or {}
        if isinstance(new_nodes, Mapping):
            for node_id, node in new_nodes.items():
                nodes[str(node_id)] = node
                if root_id is None:
                    root_id = str(node_id)
        new_edges = frame.get("new_edges") or []
        if isinstance(new_edges, Sequence):
            for edge in new_edges:
                edges.append(dict(edge) if isinstance(edge, Mapping) else edge)
    if not nodes:
        return {}
    return {
        "artifact": "helix.edit_dag.frame.v1",
        "root_id": root_id or next(iter(nodes)),
        "nodes": nodes,
        "edges": edges,
    }


def _coerce_payload(payload: object) -> Mapping[str, Any] | None:
    if payload is None:
        return None
    if isinstance(payload, (bytes, bytearray)):
        try:
            payload = payload.decode("utf-8")
        except Exception:
            return None
    if isinstance(payload, str):
        text = payload.strip()
        if not text:
            return None
        try:
            payload = json.loads(text)
        except Exception as exc:
            raise ValueError("Edit DAG payload was a string but not valid JSON.") from exc

    if isinstance(payload, Mapping):
        if "nodes" in payload or "edges" in payload:
            return payload
        frames = payload.get("frames")
        if isinstance(frames, Sequence):
            merged = _frames_to_artifact_payload([f for f in frames if isinstance(f, Mapping)])
            return merged or None
        if "new_nodes" in payload or "new_edges" in payload or str(payload.get("kind", "")).startswith(
            "helix.edit_dag.frame"
        ):
            merged = _frames_to_artifact_payload([payload])
            return merged or None
        return None

    if isinstance(payload, Sequence):
        frames = [f for f in payload if isinstance(f, Mapping)]
        if frames:
            merged = _frames_to_artifact_payload(frames)
            return merged or None
    return None


def _coerce_dag(payload: object) -> EditDAG:
    if isinstance(payload, EditDAG):
        return payload
    normalized = _coerce_payload(payload)
    if normalized is None:
        raise ValueError("Edit DAG payload missing or unsupported format.")
    if not normalized.get("nodes"):
        raise ValueError("Edit DAG payload contained no nodes.")
    return dag_from_payload(dict(normalized))


@dataclass(frozen=True)
class _SemanticBinding:
    """Wrapper around strict semantic schema + validation issues."""

    binding: SemanticBinding
    issues: tuple[str, ...] = ()


@dataclass(frozen=True)
class _DagNodeView:
    node_id: str
    stage: str
    title: str
    subtitle: str
    prob: float
    time_step: int
    x: float
    y: float
    role: str  # root | terminal | internal
    width: float
    height: float
    semantics: _SemanticBinding


@dataclass(frozen=True)
class _DagEdgeView:
    source: str
    target: str
    rule: str
    weight: float
    constraints: EdgeConstraints | None = None
    issues: tuple[str, ...] = ()


@dataclass(frozen=True)
class _DagSceneModel:
    nodes: list[_DagNodeView]
    edges: list[_DagEdgeView]
    suppressed: list[tuple[str, float, tuple[str, ...]]]
    dominant_leaf_id: str | None = None
    decision: dict[str, object] | None = None
    dag: EditDAG | None = None
    mass_audit: dict[str, MassAudit] | None = None
    edge_events: dict[tuple[str, str], object] | None = None
    edge_meta: dict[tuple[str, str], Mapping[str, Any]] | None = None


class _DagGraphicsView(QGraphicsView):
    def __init__(self, scene: QGraphicsScene, parent: QWidget | None = None) -> None:
        super().__init__(scene, parent)
        # Keep this cheap; we want pan/zoom to feel snappy even with larger DAGs.
        self.setDragMode(QGraphicsView.NoDrag)
        self.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.AnchorViewCenter)
        self._pan_candidate = False
        self._panning = False
        self._pan_start: QPointF | None = None
        self._pan_last: QPointF | None = None
        self._pan_threshold_px = 6
        try:
            self.setRenderHints(QPainter.Antialiasing | QPainter.TextAntialiasing)
        except Exception:
            pass

    def wheelEvent(self, event) -> None:  # type: ignore[override]
        delta = event.angleDelta().y()
        if delta == 0:
            return super().wheelEvent(event)
        factor = 1.15 if delta > 0 else 1.0 / 1.15
        self.scale(factor, factor)
        event.accept()

    def _node_item_at(self, viewport_pos) -> _DagNodeItem | None:
        try:
            item = self.itemAt(viewport_pos)
        except Exception:
            item = None
        while item is not None:
            if isinstance(item, _DagNodeItem):
                return item
            try:
                item = item.parentItem()
            except Exception:
                return None
        return None

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton:
            pos = event.position().toPoint()
            if self._node_item_at(pos) is None:
                self._pan_candidate = True
                self._panning = False
                self._pan_start = event.position()
                self._pan_last = event.position()
                event.accept()
                return
        return super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        if self._pan_candidate and self._pan_start is not None:
            dx0 = float(event.position().x() - self._pan_start.x())
            dy0 = float(event.position().y() - self._pan_start.y())
            if not self._panning:
                if (dx0 * dx0 + dy0 * dy0) < float(self._pan_threshold_px * self._pan_threshold_px):
                    event.accept()
                    return
                self._panning = True
                try:
                    self.viewport().setCursor(Qt.ClosedHandCursor)
                except Exception:
                    pass
            last = self._pan_last or event.position()
            dx = float(event.position().x() - last.x())
            dy = float(event.position().y() - last.y())
            self._pan_last = event.position()
            try:
                hbar = self.horizontalScrollBar()
                vbar = self.verticalScrollBar()
                hbar.setValue(int(hbar.value() - round(dx)))
                vbar.setValue(int(vbar.value() - round(dy)))
            except Exception:
                pass
            event.accept()
            return
        return super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton and self._pan_candidate:
            if not self._panning:
                try:
                    scene = self.scene()
                    if scene is not None:
                        scene.clearSelection()
                except Exception:
                    pass
            self._pan_candidate = False
            self._panning = False
            self._pan_start = None
            self._pan_last = None
            try:
                self.viewport().unsetCursor()
            except Exception:
                pass
            event.accept()
            return
        return super().mouseReleaseEvent(event)


class _DagEdgeItem(QGraphicsPathItem):
    def __init__(
        self,
        edge: _DagEdgeView,
        src_item: QGraphicsItem,
        dst_item: QGraphicsItem,
        *,
        max_weight: float,
        main_path: bool,
        palette: QPalette,
    ) -> None:
        super().__init__()
        self._edge = edge
        self._src_item = src_item
        self._dst_item = dst_item
        self._main_path = bool(main_path)
        self._palette = palette
        norm_w = 0.0 if max_weight <= 0 else edge.weight / max_weight
        self._norm_w = max(0.0, min(1.0, float(norm_w)))
        # Keep edges visually quiet by default; dominant-path emphasis is layered on top.
        self._base_thickness = max(0.8, (1.0 + 3.6 * math.sqrt(self._norm_w)) - 1.0)
        self._apply_pen()
        self.setZValue(-10.0)
        self.setFlag(QGraphicsItem.ItemIsSelectable, False)
        self.setData(1, edge.source)
        self.setData(2, edge.target)
        self.setData(3, float(self._base_thickness))
        self.update_path()

    def _apply_pen(self) -> None:
        base_role = QPalette.Highlight if self._main_path else QPalette.Mid
        base_color = QColor(self._palette.color(base_role))
        if self._main_path:
            alpha = int(120 + 120 * math.sqrt(self._norm_w))
        else:
            alpha = int(40 + 110 * math.sqrt(self._norm_w))
        base_color.setAlpha(alpha)
        pen = QPen(base_color, self._base_thickness)
        try:
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
        except Exception:
            pass
        self.setPen(pen)

    def update_path(self) -> None:
        src, dst = self._anchor_points()
        path = QPainterPath(src)
        if self._main_path:
            path.lineTo(dst)
        else:
            mid_x = (src.x() + dst.x()) / 2.0
            path.cubicTo(QPointF(mid_x, src.y()), QPointF(mid_x, dst.y()), dst)

        angle = math.atan2(dst.y() - src.y(), dst.x() - src.x())
        arrow_len = 6.0 + 4.0 * math.sqrt(self._norm_w)
        arrow_angle = math.pi / 7.0
        p1 = QPointF(
            dst.x() - arrow_len * math.cos(angle - arrow_angle),
            dst.y() - arrow_len * math.sin(angle - arrow_angle),
        )
        p2 = QPointF(
            dst.x() - arrow_len * math.cos(angle + arrow_angle),
            dst.y() - arrow_len * math.sin(angle + arrow_angle),
        )
        path.moveTo(p1)
        path.lineTo(dst)
        path.lineTo(p2)
        self.setPath(path)

    def _anchor_points(self) -> tuple[QPointF, QPointF]:
        src_rect = self._src_item.sceneBoundingRect()
        dst_rect = self._dst_item.sceneBoundingRect()
        src_center = src_rect.center()
        dst_center = dst_rect.center()
        dx = dst_center.x() - src_center.x()
        dy = dst_center.y() - src_center.y()
        dist = math.hypot(dx, dy) or 1.0
        ux = dx / dist
        uy = dy / dist
        src_offset = min(src_rect.width(), src_rect.height()) * 0.45
        dst_offset = min(dst_rect.width(), dst_rect.height()) * 0.45
        src = QPointF(src_center.x() + ux * src_offset, src_center.y() + uy * src_offset)
        dst = QPointF(dst_center.x() - ux * dst_offset, dst_center.y() - uy * dst_offset)
        return src, dst


class _DagNodeItem(QGraphicsPathItem):
    def __init__(
        self,
        node_id: str,
        path: QPainterPath,
        *,
        fill: QBrush,
        border_color: QColor,
        pen_width: float,
        pen_style: Qt.PenStyle = Qt.SolidLine,
        selected_color: QColor,
        palette: QPalette,
        on_move: Callable[[str, QPointF], None] | None,
    ) -> None:
        super().__init__(path)
        self._node_id = node_id
        self._on_move = on_move
        self._palette = palette
        self._edges: list[_DagEdgeItem] = []
        self._main_path_glow = False
        base_border = QColor(border_color)
        hover_border = QColor(border_color)
        # Dotted/dashed borders should read as "uncertain/inferred", not "disabled".
        # Keep them subtle until hovered/selected.
        if pen_style != Qt.SolidLine:
            base_border.setAlpha(120)
            hover_border.setAlpha(190)
        self._base_pen = QPen(base_border, pen_width)
        self._hover_pen = QPen(hover_border, pen_width + 0.6)
        self._selected_pen = QPen(QColor(selected_color), pen_width + 1.2)
        try:
            for pen in (self._base_pen, self._hover_pen, self._selected_pen):
                pen.setJoinStyle(Qt.RoundJoin)
                pen.setStyle(pen_style)
        except Exception:
            pass
        self.setBrush(fill)
        self.setPen(self._base_pen)
        self.setAcceptHoverEvents(True)
        self.setFlag(QGraphicsItem.ItemIsSelectable, True)
        self.setFlag(QGraphicsItem.ItemIsFocusable, True)
        self.setFlag(QGraphicsItem.ItemSendsGeometryChanges, True)
        self.setFlag(QGraphicsItem.ItemIsMovable, False)
        self.setData(0, node_id)

        self._shadow = QGraphicsDropShadowEffect()
        self._shadow_base_blur = 14.0
        self._shadow_base_offset = QPointF(0.0, 3.0)
        self._shadow_base_alpha = 160
        self._shadow.setBlurRadius(self._shadow_base_blur)
        self._shadow.setOffset(self._shadow_base_offset)
        shadow_color = QColor(self._palette.color(QPalette.Shadow))
        shadow_color.setAlpha(self._shadow_base_alpha)
        self._shadow.setColor(shadow_color)
        self.setGraphicsEffect(self._shadow)

    def set_drag_enabled(self, enabled: bool) -> None:
        self.setFlag(QGraphicsItem.ItemIsMovable, bool(enabled))

    def set_main_path_glow(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._main_path_glow:
            return
        self._main_path_glow = enabled
        if enabled:
            try:
                self._shadow.setBlurRadius(19.0)
                self._shadow.setOffset(0.0, 1.0)
                glow = QColor(self._palette.color(QPalette.Highlight))
                glow.setAlpha(210)
                self._shadow.setColor(glow)
            except Exception:
                pass
            return

        try:
            self._shadow.setBlurRadius(self._shadow_base_blur)
            self._shadow.setOffset(self._shadow_base_offset)
            base = QColor(self._palette.color(QPalette.Shadow))
            base.setAlpha(self._shadow_base_alpha)
            self._shadow.setColor(base)
        except Exception:
            pass

    def add_edge(self, edge: _DagEdgeItem) -> None:
        self._edges.append(edge)

    def hoverEnterEvent(self, event) -> None:  # type: ignore[override]
        if not self.isSelected():
            self.setPen(self._hover_pen)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event) -> None:  # type: ignore[override]
        if self.isSelected():
            self.setPen(self._selected_pen)
        else:
            self.setPen(self._base_pen)
        super().hoverLeaveEvent(event)

    def itemChange(self, change, value):  # type: ignore[override]
        if change == QGraphicsItem.ItemSelectedHasChanged:
            self.setPen(self._selected_pen if self.isSelected() else self._base_pen)
        if change == QGraphicsItem.ItemPositionHasChanged:
            try:
                if callable(self._on_move):
                    self._on_move(self._node_id, self.sceneBoundingRect().center())
            except Exception:
                pass
            for edge in list(self._edges):
                try:
                    edge.update_path()
                except Exception:
                    pass
        return super().itemChange(change, value)


class _CanvasOverlayGuard(QObject):
    def __init__(self, on_change: Callable[[], None], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._on_change = on_change

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:  # type: ignore[override]
        if event.type() in (QEvent.Resize, QEvent.Move, QEvent.Show, QEvent.Hide):
            try:
                self._on_change()
            except Exception:
                pass
        return False


class EditDAGPanel(QWidget):
    """Visualize the session's edit DAG as an interactive graph."""

    nodeSelected = Signal(str)

    def __init__(self, session: SessionModel, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._render_token = CancelToken()
        self._latest_payload: object | None = None
        self._latest_artifact: Mapping[str, Any] | None = None
        self._pending_select_node_id: str | None = None
        self._main_path_nodes: set[str] = set()
        self._main_path_edges: set[tuple[str, str]] = set()
        self._prob_label: str = "p"
        self._decision_view_enabled = os.getenv(DECISION_VIEW_ENV, "0") == "1"
        self._decision_draws: int | None = None
        self._decision_panel: QFrame | None = None
        self._empty_message = (
            "No edit DAG yet.\n\n"
            "Run a CRISPR/Prime simulation to populate the edit DAG graph."
        )
        self._tail_risk_enabled = tail_risk_flag_from_config(self._session.state.config)
        self._tail_entries: list[TailRiskEntry] = []
        self._tail_panel: QFrame | None = None
        self._tail_toggle: QCheckBox | None = None
        self._tail_list: QListWidget | None = None
        self._tail_summary: QLabel | None = None
        self._exact_values_toggle: QCheckBox | None = None
        self._dominant_leaf_id: str | None = None
        self._suppressed_label: QLabel | None = None
        self._mass_audit_label: QLabel | None = None
        self._mass_audit_ok: bool | None = None
        self._mass_audit_callout: QFrame | None = None
        self._structural_mode: bool = False
        self._latest_model: _DagSceneModel | None = None
        self._banner_suggestion: Mapping[str, Any] | None = None
        self._banner_digest: str | None = None
        self._node_overrides: dict[str, QPointF] = {}
        self._layout_signature: tuple[str, int, int] | None = None
        self._layout_editing = False
        self._node_detail_panel: QFrame | None = None
        self._node_detail_body: QPlainTextEdit | None = None
        self._node_detail_title: QLabel | None = None
        self._node_detail_advanced_toggle: QToolButton | None = None
        self._node_detail_close_btn: QToolButton | None = None
        self._details_dismissed_for_node_id: str | None = None
        self._canvas_stack_holder: QWidget | None = None
        self._canvas_overlay_guard: QObject | None = None
        self._canvas_notice: QFrame | None = None
        self._canvas_disclosure: QFrame | None = None
        self._canvas_disclosure_body: QLabel | None = None
        self._canvas_disclosure_toggle: QToolButton | None = None
        self._summary_bar: QFrame | None = None
        self._summary_label: QLabel | None = None
        self._summary_sentence_plain: str | None = None
        self._confidence_label: QLabel | None = None
        self._summary_receipt_btn: QPushButton | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(8)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(10)

        title = QLabel("Edit DAG", self)
        title.setStyleSheet("font-weight: 650; color: palette(window-text);")
        header.addWidget(title)

        header.addStretch(1)

        header.addWidget(QLabel("Layout", self))
        self._layout_combo = QComboBox(self)
        self._layout_combo.addItem("Timeline", "timeline")
        self._layout_combo.addItem("Spring", "spring")
        self._layout_combo.currentIndexChanged.connect(self._on_layout_changed)
        header.addWidget(self._layout_combo)

        self._collapse_spin = QDoubleSpinBox(self)
        self._collapse_spin.setRange(0.0, 50.0)
        self._collapse_spin.setSingleStep(0.5)
        self._collapse_spin.setSuffix("% mass")
        self._collapse_spin.setValue(1.0)
        self._collapse_spin.setToolTip("Hide branches whose node mass is below this percent of total mass.")
        self._collapse_spin.valueChanged.connect(self._on_layout_changed)
        header.addWidget(self._collapse_spin)

        self._exact_values_toggle = QCheckBox("Exact values (advanced)", self)
        self._exact_values_toggle.setChecked(False)
        self._exact_values_toggle.setToolTip(
            "Default uses approximate bands to avoid false precision.\n"
            "Enable to show exact flow weights on nodes (use with care)."
        )
        self._exact_values_toggle.toggled.connect(self._on_display_options_changed)
        header.addWidget(self._exact_values_toggle)

        self._highlight_main = QCheckBox("Highlight dominant path", self)
        self._highlight_main.setChecked(True)
        dom_tooltip = "Dominant ≠ most important. Tail risks not shown.\nDo not interpret as safety or correctness."
        doc_url = limitations_doc_url()
        if doc_url:
            dom_tooltip += f"\nSee: {doc_url}"
        else:
            dom_tooltip += "\nSee Model limitations & invalid use cases."
        self._highlight_main.setToolTip(dom_tooltip)
        self._highlight_main.toggled.connect(self._on_highlight_toggled)
        header.addWidget(self._highlight_main)

        header.addWidget(QLabel("Emphasis", self))

        self._layout_edit_toggle = QCheckBox("Drag nodes", self)
        self._layout_edit_toggle.setToolTip(
            "Enable drag-to-reposition nodes.\n"
            "Tip: drag the background to pan; scroll to zoom.\n"
            "Positions persist for this run until reset or the DAG changes."
        )
        self._layout_edit_toggle.setChecked(True)
        self._layout_edit_toggle.toggled.connect(self._on_layout_edit_toggled)
        header.addWidget(self._layout_edit_toggle)

        self._layout_reset_btn = QToolButton(self)
        self._layout_reset_btn.setText("Reset positions")
        self._layout_reset_btn.setToolTip("Clear manual node positions and reapply layout.")
        self._layout_reset_btn.clicked.connect(self._on_layout_reset)
        header.addWidget(self._layout_reset_btn)

        root.addLayout(header)

        self._suppressed_label = QLabel("", self)
        self._suppressed_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        self._suppressed_label.setWordWrap(True)
        self._suppressed_label.hide()
        root.addWidget(self._suppressed_label)

        self._mass_audit_label = QLabel("", self)
        self._mass_audit_label.setStyleSheet("color: palette(highlight); font-size: 11px;")
        self._mass_audit_label.setWordWrap(True)
        self._mass_audit_label.hide()
        root.addWidget(self._mass_audit_label)

        if self._decision_view_enabled:
            self._decision_panel = self._build_decision_panel()
            root.addWidget(self._decision_panel)

        self._mass_audit_callout = self._build_inline_callout(
            "Mass audit failed: edge weights are not normalized. "
            "Node flow weights are relative visual weights, not causal probabilities. "
            "<a href=\"open\">Limitations</a>"
        )
        self._mass_audit_callout.setVisible(False)
        root.addWidget(self._mass_audit_callout)

        self._dominant_callout_shown = False
        self._dominant_callout = self._build_inline_callout(
            f"{DOMINANT_CALLOUT_TEXT} <a href=\"open\">Limitations</a>"
        )
        self._dominant_callout.setVisible(False)
        root.addWidget(self._dominant_callout)

        self._zero_outcomes_panel = self._build_zero_outcomes_panel()
        self._zero_outcomes_panel.setVisible(False)
        root.addWidget(self._zero_outcomes_panel)

        self._summary_bar = QFrame(self)
        self._summary_bar.setObjectName("DagSummaryBar")
        summary_layout = QHBoxLayout(self._summary_bar)
        summary_layout.setContentsMargins(0, 0, 0, 0)
        summary_layout.setSpacing(10)
        summary_text_col = QVBoxLayout()
        summary_text_col.setContentsMargins(0, 0, 0, 0)
        summary_text_col.setSpacing(2)
        self._summary_label = QLabel("", self._summary_bar)
        self._summary_label.setWordWrap(True)
        self._summary_label.setTextFormat(Qt.RichText)
        self._summary_label.setStyleSheet("color: palette(window-text); font-size: 12px;")
        summary_text_col.addWidget(self._summary_label)
        self._confidence_label = QLabel("", self._summary_bar)
        self._confidence_label.setWordWrap(True)
        self._confidence_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        self._confidence_label.setVisible(False)
        summary_text_col.addWidget(self._confidence_label)
        summary_layout.addLayout(summary_text_col, stretch=1)
        self._summary_receipt_btn = QPushButton("Generate outcome summary", self._summary_bar)
        self._summary_receipt_btn.setEnabled(False)
        self._summary_receipt_btn.setToolTip("Generate a deterministic outcome receipt (copy/save).")
        self._summary_receipt_btn.clicked.connect(self._on_generate_outcome_summary)
        summary_layout.addWidget(self._summary_receipt_btn, stretch=0)
        self._summary_bar.setVisible(False)
        root.addWidget(self._summary_bar)

        card = QFrame(self)
        card.setObjectName("DagCanvasCard")
        card.setStyleSheet(
            "QFrame#DagCanvasCard {"
            " background: palette(base);"
            " border: 1px solid palette(mid);"
            " border-radius: 12px;"
            " }"
        )

        self._scene = QGraphicsScene(self)
        self._view = _DagGraphicsView(self._scene, card)
        self._view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self._placeholder = QLabel(self._empty_message, card)
        self._placeholder.setAlignment(Qt.AlignCenter)
        self._placeholder.setWordWrap(True)
        self._placeholder.setStyleSheet("color: palette(mid); font-size: 13px;")

        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(10, 10, 10, 10)
        card_layout.setSpacing(8)

        self._canvas_notice = self._build_canvas_notice(card)
        card_layout.addWidget(self._canvas_notice)

        self._canvas_disclosure = self._build_canvas_disclosure(card)
        card_layout.addWidget(self._canvas_disclosure)

        stack_holder = QWidget(card)
        self._stack = QStackedLayout(stack_holder)
        self._stack.setContentsMargins(0, 0, 0, 0)
        self._stack.addWidget(self._view)
        self._stack.addWidget(self._placeholder)
        self._stack.setCurrentWidget(self._placeholder)
        card_layout.addWidget(stack_holder, stretch=1)

        self._canvas_stack_holder = stack_holder
        self._selection = QLabel("", stack_holder)
        self._selection.setObjectName("DagSelection")
        self._selection.setStyleSheet(
            "QLabel#DagSelection {"
            " color: palette(window-text);"
            " background: palette(alternate-base);"
            " border: 1px solid palette(mid);"
            " border-radius: 8px;"
            " padding: 4px 6px;"
            " font-size: 11px;"
            " }"
        )
        self._selection.setWordWrap(True)
        self._selection.hide()

        self._node_detail_panel = QFrame(stack_holder)
        self._node_detail_panel.setObjectName("DagNodeDetails")
        self._node_detail_panel.setStyleSheet(
            "QFrame#DagNodeDetails {"
            " background: palette(base);"
            " border: 1px solid palette(mid);"
            " border-radius: 10px;"
            " }"
            "QLabel { font-size: 11px; }"
            "QToolButton { color: palette(mid); font-size: 12px; }"
        )
        self._node_detail_panel.hide()
        detail_layout = QVBoxLayout(self._node_detail_panel)
        detail_layout.setContentsMargins(10, 8, 10, 8)
        detail_layout.setSpacing(6)

        detail_header = QHBoxLayout()
        detail_header.setContentsMargins(0, 0, 0, 0)
        detail_header.setSpacing(8)
        self._node_detail_title = QLabel("Node details", self._node_detail_panel)
        self._node_detail_title.setStyleSheet("font-weight: 650; color: palette(window-text);")
        detail_header.addWidget(self._node_detail_title, stretch=1)

        self._node_detail_advanced_toggle = QToolButton(self._node_detail_panel)
        self._node_detail_advanced_toggle.setText("Advanced")
        self._node_detail_advanced_toggle.setCheckable(True)
        self._node_detail_advanced_toggle.setChecked(False)
        self._node_detail_advanced_toggle.setToolTip("Toggle raw fields and internal identifiers.")
        self._node_detail_advanced_toggle.toggled.connect(self._on_node_detail_advanced_toggled)
        detail_header.addWidget(self._node_detail_advanced_toggle, stretch=0)

        self._node_detail_close_btn = QToolButton(self._node_detail_panel)
        self._node_detail_close_btn.setText("×")
        self._node_detail_close_btn.setToolTip("Hide node details (does not clear selection).")
        self._node_detail_close_btn.clicked.connect(self._dismiss_node_details)
        detail_header.addWidget(self._node_detail_close_btn, stretch=0)
        detail_layout.addLayout(detail_header)

        self._node_detail_body = QPlainTextEdit(self._node_detail_panel)
        self._node_detail_body.setReadOnly(True)
        self._node_detail_body.setFont(monospace_font())
        self._node_detail_body.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        self._node_detail_body.setFrameStyle(QFrame.NoFrame)
        self._node_detail_body.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._node_detail_body.setFocusPolicy(Qt.NoFocus)
        detail_layout.addWidget(self._node_detail_body, stretch=1)

        self._canvas_overlay_guard = _CanvasOverlayGuard(self._position_canvas_overlays, stack_holder)
        stack_holder.installEventFilter(self._canvas_overlay_guard)

        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(12)
        body.addWidget(card, stretch=1)

        self._tail_panel = self._build_tail_risk_panel()
        if self._tail_panel is not None:
            self._tail_panel.setVisible(self._tail_risk_enabled)
            body.addWidget(self._tail_panel, stretch=0)

        root.addLayout(body, stretch=1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        self._limitations_link = QLabel(self)
        self._limitations_link.setTextFormat(Qt.RichText)
        self._limitations_link.setText('<a href="open">Model limitations & invalid use cases</a>')
        self._limitations_link.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self._limitations_link.setStyleSheet("color: palette(link); font-size: 11px;")
        self._limitations_link.linkActivated.connect(self._on_open_limitations)
        footer.addWidget(self._limitations_link)
        root.addLayout(footer)

        self._scene.selectionChanged.connect(self._on_scene_selection_changed)

        self._session.stateChanged.connect(self._on_state_changed)
        self._on_state_changed(self._session.state)

    def _position_canvas_overlays(self) -> None:
        holder = getattr(self, "_canvas_stack_holder", None)
        if holder is None:
            return

        pad = 10
        holder_w = max(1, int(holder.width()))
        holder_h = max(1, int(holder.height()))

        selection = getattr(self, "_selection", None)
        if selection is not None:
            try:
                selection.raise_()
            except Exception:
                pass
            if selection.isVisible():
                selection.setMaximumWidth(max(120, holder_w - pad * 2))
                selection.adjustSize()
                selection.move(pad, pad)

        panel = getattr(self, "_node_detail_panel", None)
        if panel is not None:
            try:
                panel.raise_()
            except Exception:
                pass
            if panel.isVisible():
                available_w = max(1, holder_w - pad * 2)
                available_h = max(1, holder_h - pad * 2)
                panel_w = min(480, available_w)
                panel_h = min(340, int(available_h * 0.7))
                if available_h >= 160:
                    panel_h = max(160, panel_h)
                panel_h = min(panel_h, available_h)
                panel.setFixedSize(panel_w, panel_h)
                panel.move(max(pad, holder_w - panel_w - pad), pad)

    def _dismiss_node_details(self) -> None:
        node_id = self.selected_node_id()
        self._details_dismissed_for_node_id = str(node_id) if node_id else None
        if self._node_detail_panel is not None:
            self._node_detail_panel.hide()
        self._position_canvas_overlays()

    def _on_node_detail_advanced_toggled(self, _checked: bool) -> None:
        try:
            node_id = self.selected_node_id()
        except Exception:
            node_id = None
        self._update_node_details(node_id)

    def _build_inline_callout(self, message: str) -> QFrame:
        callout = QFrame(self)
        callout.setObjectName("DagInlineCallout")
        callout.setStyleSheet(
            "QFrame#DagInlineCallout {"
            " background: palette(alternate-base);"
            " border: 1px solid palette(mid);"
            " border-radius: 8px;"
            " }"
            "QLabel { color: palette(window-text); font-size: 11px; }"
            "QToolButton { color: palette(link); font-size: 11px; }"
        )
        layout = QHBoxLayout(callout)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(8)

        label = QLabel(message, callout)
        label.setTextFormat(Qt.RichText)
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextBrowserInteraction)
        label.linkActivated.connect(self._on_open_limitations)
        layout.addWidget(label, stretch=1)

        dismiss = QToolButton(callout)
        dismiss.setText("Dismiss")
        dismiss.clicked.connect(callout.hide)
        layout.addWidget(dismiss)
        return callout

    def _build_canvas_notice(self, parent: QWidget) -> QFrame:
        notice = QFrame(parent)
        notice.setObjectName("DagCanvasNotice")
        notice.setStyleSheet(
            "QFrame#DagCanvasNotice {"
            " background: palette(alternate-base);"
            " border: 1px solid palette(mid);"
            " border-radius: 10px;"
            " }"
            "QLabel { font-size: 11px; }"
        )
        layout = QHBoxLayout(notice)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(8)

        label = QLabel(notice)
        label.setTextFormat(Qt.RichText)
        label.setTextInteractionFlags(Qt.TextBrowserInteraction)
        label.setWordWrap(True)
        label.setStyleSheet("color: palette(window-text);")
        label.setText(
            "<b>Exploratory simulation graph</b><br/>"
            "Edge weights are <b>model-estimated population fractions</b>, not observed rates. "
            "<a href=\"open\">Limitations</a>"
        )
        label.linkActivated.connect(self._on_open_limitations)
        layout.addWidget(label, stretch=1)
        return notice

    def _build_canvas_disclosure(self, parent: QWidget) -> QFrame:
        disclosure = QFrame(parent)
        disclosure.setObjectName("DagCanvasDisclosure")
        disclosure.setStyleSheet(
            "QFrame#DagCanvasDisclosure {"
            " background: palette(base);"
            " border: 1px solid palette(mid);"
            " border-radius: 10px;"
            " }"
            "QToolButton { color: palette(window-text); font-size: 11px; font-weight: 600; }"
            "QLabel { color: palette(mid); font-size: 11px; }"
        )
        layout = QVBoxLayout(disclosure)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        toggle = QToolButton(disclosure)
        toggle.setText("What this DAG is NOT")
        toggle.setCheckable(True)
        toggle.setChecked(False)
        toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        toggle.setArrowType(Qt.RightArrow)
        toggle.toggled.connect(self._on_canvas_disclosure_toggled)
        self._canvas_disclosure_toggle = toggle
        layout.addWidget(toggle)

        body = QLabel(disclosure)
        body.setTextFormat(Qt.RichText)
        body.setWordWrap(True)
        body.setTextInteractionFlags(Qt.TextBrowserInteraction)
        body.linkActivated.connect(self._on_open_limitations)
        body.setVisible(False)
        body.setText(
            "<ul style=\"margin-left: 16px;\">"
            "<li>Cell-level time dynamics or per-cell fate tracking</li>"
            "<li>Experimentally calibrated rates (unless explicitly marked)</li>"
            "<li>Clinical outcome likelihoods or decision-grade safety claims</li>"
            "</ul>"
            "Timeline layout uses <b>simulation step depth</b> (t=0,1,2…), not real time. "
            "<a href=\"open\">Limitations</a>"
        )
        self._canvas_disclosure_body = body
        layout.addWidget(body)
        return disclosure

    def _on_canvas_disclosure_toggled(self, checked: bool) -> None:
        body = self._canvas_disclosure_body
        toggle = self._canvas_disclosure_toggle
        if body is not None:
            body.setVisible(bool(checked))
        if toggle is not None:
            toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)

    def _build_tail_risk_panel(self) -> QFrame:
        panel = QFrame(self)
        panel.setObjectName("TailRiskPanel")
        panel.setStyleSheet(
            "QFrame#TailRiskPanel {"
            " background: palette(base);"
            " border: 1px solid palette(mid);"
            " border-radius: 8px;"
            " }"
            "QLabel { font-size: 11px; }"
        )
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(6)

        title = QLabel("Tail Risk", panel)
        title.setStyleSheet("font-weight: 650; color: palette(window-text);")
        header.addWidget(title)
        header.addStretch(1)

        self._tail_toggle = QCheckBox("Enable", panel)
        self._tail_toggle.setChecked(self._tail_risk_enabled)
        self._tail_toggle.setToolTip("Show top tail outcomes ranked by expected harm.")
        self._tail_toggle.toggled.connect(self._on_tail_risk_toggled)
        header.addWidget(self._tail_toggle)

        layout.addLayout(header)

        self._tail_summary = QLabel("Tail risk view disabled.", panel)
        self._tail_summary.setWordWrap(True)
        self._tail_summary.setStyleSheet("color: palette(mid);")
        layout.addWidget(self._tail_summary)

        self._tail_list = QListWidget(panel)
        self._tail_list.setAlternatingRowColors(True)
        self._tail_list.itemClicked.connect(self._on_tail_item_clicked)
        layout.addWidget(self._tail_list, stretch=1)

        self._refresh_tail_risk_panel(force_clear=not self._tail_risk_enabled)
        return panel

    def _current_outcomes(self) -> list[Mapping[str, Any]]:
        outcomes_raw = []
        try:
            outcomes_raw = list(getattr(self._session.state, "outcomes", []) or [])
        except Exception:
            outcomes_raw = []

        outcomes: list[Mapping[str, Any]] = []
        for oc in outcomes_raw:
            if isinstance(oc, Mapping):
                outcomes.append(oc)
                continue
            if hasattr(oc, "to_dict"):
                try:
                    outcomes.append(oc.to_dict())  # type: ignore[arg-type]
                    continue
                except Exception:
                    pass
            try:
                outcomes.append(dict(oc))  # type: ignore[arg-type]
            except Exception:
                continue
        return outcomes

    def _on_tail_risk_toggled(self, checked: bool) -> None:
        self._tail_risk_enabled = bool(checked)
        try:
            cfg = update_tail_risk_flag(self._session.state.config, self._tail_risk_enabled)
            # Mark viz dirty so the change persists; no need to force rerun.
            self._session.update(config=cfg, viz_dirty=True)
        except Exception:
            pass
        self._refresh_tail_risk_panel(force_clear=not self._tail_risk_enabled)

    def _refresh_tail_risk_panel(self, *, force_clear: bool = False) -> None:
        if self._tail_list is None or self._tail_summary is None:
            return
        if force_clear or not self._tail_risk_enabled:
            self._tail_entries = []
            self._tail_list.clear()
            self._tail_list.setEnabled(False)
            self._tail_summary.setText("Tail risk view disabled.")
            return

        entries = build_tail_risk_entries(
            self._current_outcomes(),
            dominant_outcome_id=self._dominant_leaf_id,
            top_k=TAIL_RISK_TOP_K_DEFAULT,
        )
        self._tail_entries = entries
        self._tail_list.clear()
        if not entries:
            self._tail_list.setEnabled(False)
            self._tail_summary.setText("No tail outcomes available.")
            return

        self._tail_list.setEnabled(True)
        self._tail_summary.setText(f"Top {len(entries)} tail outcomes ranked by expected harm.")
        for entry in entries:
            text = f"{entry.label} · {self._prob_label}={entry.probability * 100:.2f}% · severity={entry.severity}"
            if entry.ci_low is not None and entry.ci_high is not None:
                text += f" (CI {entry.ci_low * 100:.1f}–{entry.ci_high * 100:.1f}%)"
            item = QListWidgetItem(text)
            item.setData(Qt.UserRole, entry.outcome_id)
            item.setToolTip(text)
            self._tail_list.addItem(item)

    def _on_tail_item_clicked(self, item: QListWidgetItem) -> None:  # type: ignore[override]
        if item is None:
            return
        outcome_id = item.data(Qt.UserRole)
        if not outcome_id:
            return
        try:
            self.select_node(str(outcome_id))
        except Exception:
            pass

    def _build_decision_panel(self) -> QFrame:
        panel = QFrame(self)
        panel.setObjectName("DagDecisionPanel")
        panel.setStyleSheet(
            "QFrame#DagDecisionPanel {"
            " background: palette(base);"
            " border: 1px solid palette(mid);"
            " border-radius: 10px;"
            " }"
            "QLabel { color: palette(window-text); font-size: 11px; }"
        )
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        title = QLabel("Decision views (feature-flagged)", panel)
        title.setStyleSheet("font-weight: 650; color: palette(window-text);")
        layout.addWidget(title)

        subtitle = QLabel("Most probable vs most dangerous (tail-risk) outcomes.", panel)
        subtitle.setStyleSheet("color: palette(mid); font-size: 11px;")
        layout.addWidget(subtitle)

        top_row = QHBoxLayout()
        top_row.setContentsMargins(0, 0, 0, 0)
        top_row.setSpacing(8)

        def _build_box(label_text: str) -> tuple[QFrame, QLabel]:
            box = QFrame(panel)
            box.setStyleSheet(
                "QFrame {"
                " background: palette(alternate-base);"
                " border: 1px solid palette(mid);"
                " border-radius: 8px;"
                " }"
            )
            box_layout = QVBoxLayout(box)
            box_layout.setContentsMargins(8, 6, 8, 6)
            box_layout.setSpacing(4)
            label = QLabel(label_text, box)
            label.setStyleSheet("font-weight: 600; color: palette(window-text);")
            box_layout.addWidget(label)
            detail = QLabel("—", box)
            detail.setWordWrap(True)
            box_layout.addWidget(detail)
            return box, detail

        prob_box, prob_detail = _build_box("Most probable")
        risk_box, risk_detail = _build_box("Most dangerous")
        self._decision_prob_label = prob_detail
        self._decision_risk_label = risk_detail
        top_row.addWidget(prob_box)
        top_row.addWidget(risk_box)
        layout.addLayout(top_row)

        tail_title = QLabel("Tail-risk view (top-k worst outcomes by severity class)", panel)
        tail_title.setStyleSheet("font-weight: 600;")
        layout.addWidget(tail_title)

        self._tail_risk_label = QLabel("—", panel)
        self._tail_risk_label.setTextFormat(Qt.RichText)
        self._tail_risk_label.setWordWrap(True)
        layout.addWidget(self._tail_risk_label)

        self._decision_note = QLabel("", panel)
        self._decision_note.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._decision_note.setWordWrap(True)
        layout.addWidget(self._decision_note)
        return panel

    def _build_zero_outcomes_panel(self) -> QFrame:
        panel = QFrame(self)
        panel.setObjectName("DagZeroOutcomesPanel")
        panel.setStyleSheet(
            "QFrame#DagZeroOutcomesPanel {"
            " background: palette(alternate-base);"
            " border: 1px solid palette(mid);"
            " border-radius: 10px;"
            " }"
            "QLabel { color: palette(window-text); font-size: 11px; }"
        )
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)

        self._zero_outcomes_title = QLabel("Run produced 0 outcomes", panel)
        self._zero_outcomes_title.setStyleSheet("font-weight: 650; color: palette(window-text);")
        layout.addWidget(self._zero_outcomes_title)

        self._zero_outcomes_causes = QLabel("", panel)
        self._zero_outcomes_causes.setTextFormat(Qt.RichText)
        self._zero_outcomes_causes.setWordWrap(True)
        layout.addWidget(self._zero_outcomes_causes)

        self._zero_outcomes_note = QLabel("Run marked invalid; exports disabled.", panel)
        self._zero_outcomes_note.setStyleSheet("color: palette(mid); font-size: 11px;")
        layout.addWidget(self._zero_outcomes_note)

        self._apply_locus_btn = QPushButton("Apply suggested locus", panel)
        self._apply_locus_btn.setVisible(False)
        self._apply_locus_btn.clicked.connect(self._on_apply_suggested_locus)
        layout.addWidget(self._apply_locus_btn)
        return panel

    def _show_zero_outcomes_panel(self, causes: Sequence[str]) -> None:
        items = "".join(f"<li>{cause}</li>" for cause in causes if cause)
        if not items:
            items = "<li>Outcome model returned 0 outcomes</li>"
        self._zero_outcomes_causes.setText(f"<ul>{items}</ul>")
        self._zero_outcomes_panel.setVisible(True)
        self._apply_locus_btn.setVisible(self._apply_locus_btn.isVisible())

    def _hide_zero_outcomes_panel(self) -> None:
        self._zero_outcomes_panel.setVisible(False)
        self._apply_locus_btn.setVisible(False)
        self._banner_suggestion = None
        self._banner_digest = None

    def _on_apply_suggested_locus(self) -> None:
        suggestion = self._banner_suggestion
        if not (suggestions_enabled() and actionable(suggestion, self._banner_digest)):
            return
        best = suggestion.get("best") if isinstance(suggestion, Mapping) else None
        label = str(best.get("label") or "") if isinstance(best, Mapping) else ""
        if not label:
            return
        chrom = label
        start = None
        end = None
        if ":" in label and "-" in label:
            try:
                chrom_part, coords = label.split(":", 1)
                start_str, end_str = coords.split("-", 1)
                chrom = chrom_part
                start = int(start_str.replace(",", ""))
                end = int(end_str.replace(",", ""))
            except Exception:
                pass
        spec = experiment_spec_to_dict(self._session.state.experiment_spec)
        locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
        locus["chr"] = chrom
        if start is not None and end is not None:
            locus["start"] = start
            locus["end"] = end
        spec["locus"] = locus
        spec["locus_source"] = SOURCE_USER_APPLIED
        spec["locus_inference_ref"] = str(suggestion.get("suggestion_id") or "")
        spec["locus_updatedAt"] = clock.utc_now_iso()
        try:
            self._session.update(experiment_spec=experiment_spec_to_dict(spec))
            self._session.log(f"Applied inferred locus from banner: {label}")
        finally:
            # keep banner visible until other causes resolved; do not rerun automatically
            self._apply_locus_btn.setVisible(False)
            self._banner_suggestion = None
            self._banner_digest = None

    def _on_open_limitations(self, *_args: object) -> None:
        open_limitations(self)

    def _on_generate_outcome_summary(self) -> None:
        receipt = self.export_outcome_summary_receipt()
        if not receipt:
            return
        json_text = json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
        md_text = _format_outcome_receipt_markdown(receipt)

        dlg = QDialog(self)
        dlg.setWindowTitle("Outcome summary receipt")
        dlg.setModal(True)
        dlg.resize(900, 560)

        layout = QVBoxLayout(dlg)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(10)

        title = QLabel("Outcome summary receipt (copy/paste to attach to notes, emails, or reports).", dlg)
        title.setStyleSheet("font-weight: 650; font-size: 15px; color: palette(window-text);")
        layout.addWidget(title)

        tabs = QTabWidget(dlg)
        tabs.setDocumentMode(True)

        json_body = QPlainTextEdit(dlg)
        json_body.setReadOnly(True)
        json_body.setLineWrapMode(QPlainTextEdit.NoWrap)
        json_body.setFont(monospace_font())
        json_body.setPlainText(json_text)
        json_body.setStyleSheet("background-color: palette(base); color: palette(window-text);")
        tabs.addTab(json_body, "JSON")

        md_body = QPlainTextEdit(dlg)
        md_body.setReadOnly(True)
        md_body.setLineWrapMode(QPlainTextEdit.WidgetWidth)
        md_body.setFont(monospace_font())
        md_body.setPlainText(md_text)
        md_body.setStyleSheet("background-color: palette(base); color: palette(window-text);")
        tabs.addTab(md_body, "Markdown")

        layout.addWidget(tabs, stretch=1)

        actions = QHBoxLayout()
        actions.addStretch(1)

        copy_btn = QPushButton("Copy to clipboard", dlg)
        copy_btn.clicked.connect(
            lambda: QApplication.clipboard()
            and isinstance(tabs.currentWidget(), QPlainTextEdit)
            and QApplication.clipboard().setText(tabs.currentWidget().toPlainText())
        )
        actions.addWidget(copy_btn)

        save_btn = QPushButton("Save…", dlg)
        save_btn.setToolTip("Save receipt as JSON or Markdown (based on active tab).")

        def _save() -> None:
            is_json = tabs.currentIndex() == 0
            default_name = "outcome_summary_receipt.json" if is_json else "outcome_summary_receipt.md"
            file_filter = "JSON (*.json)" if is_json else "Markdown (*.md *.markdown)"
            path, _filter = QFileDialog.getSaveFileName(
                dlg,
                "Save outcome summary receipt",
                default_name,
                file_filter,
            )
            if not path:
                return
            try:
                with open(path, "w", encoding="utf-8") as f:
                    current = tabs.currentWidget()
                    if isinstance(current, QPlainTextEdit):
                        f.write(current.toPlainText())
            except Exception:
                return

        save_btn.clicked.connect(_save)
        actions.addWidget(save_btn)

        close_btn = QPushButton("Close", dlg)
        close_btn.clicked.connect(dlg.accept)
        actions.addWidget(close_btn)

        layout.addLayout(actions)
        dlg.exec()

    def _on_highlight_toggled(self, _checked: bool) -> None:
        if not self._dominant_callout_shown:
            self._dominant_callout_shown = True
            self._dominant_callout.setVisible(True)
        self._on_display_options_changed(_checked)

    def get_view_state(self) -> dict[str, Any]:
        return {
            "layout": str(self._layout_combo.currentData() or "timeline"),
            "selected_node": self.selected_node_id(),
        }

    def apply_view_state(self, state: Mapping[str, Any] | None) -> None:
        if not isinstance(state, Mapping):
            return

        layout = state.get("layout")
        if isinstance(layout, str):
            idx = self._layout_combo.findData(layout)
            if idx >= 0 and idx != self._layout_combo.currentIndex():
                self._layout_combo.setCurrentIndex(idx)

        selected = state.get("selected_node")
        if isinstance(selected, str) and selected:
            self._pending_select_node_id = selected
            self._select_node_if_present(selected)

    def selected_node_id(self) -> str | None:
        selected = self._scene.selectedItems()
        if not selected:
            return None
        node_id = selected[0].data(0)
        if node_id is None:
            return None
        text = str(node_id)
        return text if text else None

    def select_node(self, node_id: str) -> bool:
        if not node_id:
            return False
        self._pending_select_node_id = node_id
        return self._select_node_if_present(node_id)

    def _on_display_options_changed(self, _checked: bool) -> None:
        if self._latest_payload is None:
            return
        prior = self.selected_node_id()
        if prior:
            self._pending_select_node_id = prior
        self._render(self._latest_payload, self._latest_artifact)

    def _on_layout_changed(self, _idx: int) -> None:
        if self._latest_payload is None:
            return
        self._node_overrides.clear()
        self._layout_signature = None
        prior = self.selected_node_id()
        if prior:
            self._pending_select_node_id = prior
        self._render(self._latest_payload, self._latest_artifact)

    def _empty_message_for_state(self, state: ExperimentState) -> str:
        config = state.config
        run_config = config.get("run_config") if isinstance(config, Mapping) else None
        mode = run_config.get("mode") if isinstance(run_config, Mapping) else None
        if state.run_kind == RunKind.PRIME:
            return (
                "No edit DAG yet.\n\n"
                "Prime edit DAGs are not available in Studio yet.\n"
                "Run CRISPR in DAG mode to populate this view."
            )
        if isinstance(mode, str) and mode.lower() not in {"dag", "edit_dag"}:
            return (
                "No edit DAG yet.\n\n"
                "The last run used legacy mode. Enable DAG mode in CRISPR/Prime settings\n"
                "or set HELIX_DAG_MODE=1, then rerun to populate the edit DAG graph."
            )
        if isinstance(config, Mapping) and (config.get("sim_payload") or state.outcomes):
            return (
                "No edit DAG yet.\n\n"
                "Enable DAG mode in CRISPR/Prime settings or set HELIX_DAG_MODE=1,\n"
                "then rerun to populate the edit DAG graph."
            )
        return self._empty_message

    def _latest_run(self) -> RunModel | None:
        try:
            runs = getattr(self._session, "runs", None)
            if runs:
                return runs[-1]
        except Exception:
            return None
        return None

    def _missing_outcome_prereqs(self, state: ExperimentState, run: RunModel | None) -> list[str]:
        reasons: list[str] = []
        try:
            cfg = state.config if isinstance(state.config, Mapping) else {}
            outcome_cfg = cfg.get("outcome_model") if isinstance(cfg, Mapping) else {}
            search_mode = outcome_cfg.get("search_mode") if isinstance(outcome_cfg, Mapping) else None
            fm_ready = None
            if isinstance(outcome_cfg, Mapping):
                fm_ready = outcome_cfg.get("fm_index_path") or outcome_cfg.get("fm_ready")
        except Exception:
            cfg = {}
            search_mode = None
            fm_ready = None

        if run is None:
            reasons.append("No recorded run")
        else:
            if not run.target_locus:
                reasons.append("Target locus unset")
            if run.cut_index is None and run.pam_index is None and run.edit_type != "prime_edit":
                reasons.append("Cut/PAM index unavailable")
        if search_mode == "whole" and not fm_ready:
            reasons.append("Whole-genome off-target enabled but FM index missing")
        return reasons

    def _claims_dirty(self, state: ExperimentState, run: RunModel | None) -> bool:
        try:
            cfg = state.config if isinstance(state.config, Mapping) else {}
            if bool(cfg.get("claims_dirty")):
                return True
        except Exception:
            pass
        if run is not None:
            meta = getattr(run, "metadata", None)
            if isinstance(meta, Mapping) and (meta.get("invalid") or meta.get("claims_disabled")):
                return True
        return False

    def _dag_has_branch_mass(self, payload: object) -> bool:
        dag = _coerce_dag(payload)
        if dag is None or not dag.nodes:
            return False
        if len(dag.nodes) <= 1:
            return False
        root_id = dag.root_id
        root_log_p = float(dag.nodes[root_id].log_prob) if root_id in dag.nodes else 0.0
        for node_id, node in dag.nodes.items():
            if node_id == root_id:
                continue
            try:
                prob = math.exp(float(node.log_prob) - root_log_p)
            except Exception:
                continue
            if prob > 1e-12:
                return True
        return False

    def _diagnose_zero_outcomes(self, state: ExperimentState, run: RunModel) -> list[str]:
        causes: list[str] = []
        try:
            if self._dag_has_branch_mass(state.dag_from_runtime):
                causes.append("Edit DAG shows non-zero branch mass but outcomes are empty")
        except Exception:
            pass
        if not run.sequence:
            causes.append("Sequence missing")
        if not run.target_locus:
            causes.append("Target locus unset")
        if run.cut_index is None and run.pam_index is None and run.edit_type != "prime_edit":
            causes.append("Cut/PAM index unavailable")
        try:
            cfg = state.config if isinstance(state.config, Mapping) else {}
            run_cfg = cfg.get("run_config") if isinstance(cfg, Mapping) else {}
            if isinstance(run_cfg, Mapping):
                mode = str(run_cfg.get("mode") or "")
                if mode and mode.lower() not in {"dag", "edit_dag"}:
                    causes.append("DAG mode disabled (legacy mode)")
            outcome_cfg = cfg.get("outcome_model") if isinstance(cfg, Mapping) else {}
            if isinstance(outcome_cfg, Mapping):
                search_mode = outcome_cfg.get("search_mode")
                fm_ready = outcome_cfg.get("fm_index_path") or outcome_cfg.get("fm_ready")
                if str(search_mode or "") == "whole" and not fm_ready:
                    causes.append("Whole-genome search requested but FM index is not built")
        except Exception:
            pass
        if not causes:
            causes.append("Incompatible settings or guide/PAM combination")
        causes.append("Outcome model returned 0 outcomes")
        return causes[:3]

    def _show_prereq_gate(self, reasons: Sequence[str]) -> None:
        msg = "Edit DAG unavailable:\n\n" + "\n".join(f"• {r}" for r in reasons if r)
        self._selection.hide()
        self._placeholder.setText(msg)
        self._stack.setCurrentWidget(self._placeholder)
        self._scene.clear()
        self._refresh_tail_risk_panel(force_clear=True)
        if self._suppressed_label is not None:
            self._suppressed_label.hide()
        if self._mass_audit_label is not None:
            self._mass_audit_label.hide()
        if self._mass_audit_callout is not None:
            self._mass_audit_callout.hide()
        if getattr(self, "_node_detail_panel", None) is not None:
            self._node_detail_panel.hide()
        self._update_outcome_summary(None)

    def _artifact_blocked_message(self, artifact: Mapping[str, Any]) -> str:
        labels = {
            "TARGET_LOCUS_UNRESOLVED": "Target locus unresolved",
            "PAM_INDEX_MISSING": "Genome index missing for whole-genome off-target search",
            "NO_TERMINAL_REACHABLE": "No terminal outcomes reachable",
            "TERMINAL_MASS_NOT_ONE": "Terminal outcome mass not conserved",
            "PRUNING_REMOVED_ALL_TERMINALS": "Pruning removed all terminal outcomes",
            "CALIBRATION_MISSING": "Calibration missing for probabilistic output",
            "CLAIMS_UNSUPPORTED": "Claims unsupported (provenance incomplete)",
            "GRAPH_CYCLE_DETECTED": "Graph contains a cycle",
            "CUT_INDEX_UNAVAILABLE": "Cut index unavailable",
        }
        causes = artifact_root_causes(artifact)
        if not causes:
            return "Run blocked: invalid artifact."
        lines = [labels.get(code, code) for code in causes]
        return "Run blocked.\n\n" + "\n".join(f"• {line}" for line in lines)

    def _on_state_changed(self, state: ExperimentState) -> None:
        self._tail_risk_enabled = tail_risk_flag_from_config(state.config)
        if self._tail_toggle is not None and self._tail_toggle.isChecked() != self._tail_risk_enabled:
            try:
                self._tail_toggle.blockSignals(True)
                self._tail_toggle.setChecked(self._tail_risk_enabled)
            finally:
                self._tail_toggle.blockSignals(False)
        if self._tail_panel is not None:
            self._tail_panel.setVisible(self._tail_risk_enabled)
        meta = state.config.get("metadata") if isinstance(state.config, Mapping) else {}
        candidate_suggestion = meta.get("locus_suggestion") if suggestions_enabled() else None
        candidate_digest = meta.get("input_digest") if suggestions_enabled() else None
        if actionable(candidate_suggestion, candidate_digest):
            self._banner_suggestion = candidate_suggestion
            self._banner_digest = candidate_digest
        else:
            self._banner_suggestion = None
            self._banner_digest = None
        run = self._latest_run()
        prereq_reasons = self._missing_outcome_prereqs(state, run)
        claims_dirty = self._claims_dirty(state, run)
        self._structural_mode = bool(prereq_reasons or claims_dirty)
        outcomes_present = bool(self._current_outcomes())
        if run is not None and not run.outcomes and not outcomes_present:
            causes = self._diagnose_zero_outcomes(state, run)
            self._show_zero_outcomes_panel(causes)
            try:
                self._session.mark_run_invalid(run, reason="zero_outcomes", causes=causes)
            except Exception:
                pass
            needs_locus = any("Target locus unset" in str(cause) for cause in causes)
            self._apply_locus_btn.setVisible(bool(self._banner_suggestion and needs_locus))
        else:
            self._hide_zero_outcomes_panel()
        artifact = None
        try:
            artifact = self._session.ensure_run_artifact()
        except Exception:
            artifact = None
        self._latest_artifact = artifact if isinstance(artifact, Mapping) else None
        decision_ok = artifact_decision_mode_eligible(self._latest_artifact) if self._latest_artifact is not None else False
        if self._structural_mode:
            self._prob_label = "flow"
        elif self._latest_artifact is not None:
            self._prob_label = "p" if decision_ok else "score"
        else:
            self._prob_label = "score"
        if self._latest_artifact is None or not artifact_is_valid(self._latest_artifact):
            self._latest_payload = None
            self._selection.hide()
            if getattr(self, "_node_detail_panel", None) is not None:
                self._node_detail_panel.hide()
            if self._latest_artifact is not None:
                self._placeholder.setText(self._artifact_blocked_message(self._latest_artifact))
            else:
                self._placeholder.setText("Run blocked: missing artifact.")
            self._stack.setCurrentWidget(self._placeholder)
            self._scene.clear()
            self._refresh_tail_risk_panel(force_clear=True)
            if self._suppressed_label is not None:
                self._suppressed_label.hide()
            if self._mass_audit_label is not None:
                self._mass_audit_label.hide()
            self._update_outcome_summary(None)
            return
        graph_meta = self._latest_artifact.get("graph") if isinstance(self._latest_artifact.get("graph"), Mapping) else {}
        if str(graph_meta.get("source") or "") != "dag":
            self._latest_payload = None
            self._selection.hide()
            if getattr(self, "_node_detail_panel", None) is not None:
                self._node_detail_panel.hide()
            self._placeholder.setText("Edit DAG unavailable.\n\nRun CRISPR in DAG mode to populate this view.")
            self._stack.setCurrentWidget(self._placeholder)
            self._scene.clear()
            self._refresh_tail_risk_panel(force_clear=True)
            if self._suppressed_label is not None:
                self._suppressed_label.hide()
            if self._mass_audit_label is not None:
                self._mass_audit_label.hide()
            self._update_outcome_summary(None)
            return
        payload = state.dag_from_runtime
        if prereq_reasons:
            self._show_prereq_gate(prereq_reasons)
            self._latest_payload = None
            return
        if claims_dirty:
            self._show_prereq_gate(["Claims dirty: recompute claims to proceed"])
            self._latest_payload = None
            return
        if _is_empty_payload(payload):
            self._latest_payload = None
            self._selection.hide()
            if getattr(self, "_node_detail_panel", None) is not None:
                self._node_detail_panel.hide()
            self._placeholder.setText(self._empty_message_for_state(state))
            self._stack.setCurrentWidget(self._placeholder)
            self._scene.clear()
            self._refresh_tail_risk_panel(force_clear=True)
            if self._suppressed_label is not None:
                self._suppressed_label.hide()
            if self._mass_audit_label is not None:
                self._mass_audit_label.hide()
            if self._mass_audit_callout is not None:
                self._mass_audit_callout.hide()
            self._mass_audit_ok = None
            self._update_outcome_summary(None)
            return
        prior = self.selected_node_id()
        if prior:
            self._pending_select_node_id = prior
        self._latest_payload = payload
        self._render(payload, self._latest_artifact)

    def _render(self, payload: object, artifact: Mapping[str, Any] | None) -> None:
        show_exact_values = False
        if self._exact_values_toggle is not None:
            try:
                show_exact_values = bool(self._exact_values_toggle.isChecked())
            except Exception:
                show_exact_values = False
        collapse_threshold_pct = 0.0
        try:
            collapse_threshold_pct = float(self._collapse_spin.value())
        except Exception:
            collapse_threshold_pct = 0.0

        def _build() -> _DagSceneModel:
            return self._build_scene_model(
                payload,
                artifact,
                collapse_threshold_pct=collapse_threshold_pct,
                show_exact_values=show_exact_values,
            )

        def _on_ok(model: _DagSceneModel) -> None:
            self._apply_model(model)

        def _on_err(message: str) -> None:
            self._scene.clear()
            self._selection.hide()
            self._update_outcome_summary(None)
            self._placeholder.setText(
                "Failed to render edit DAG.\n\n" + message.splitlines()[-1]
            )
            self._stack.setCurrentWidget(self._placeholder)

        run_bg(
            _build,
            _on_ok,
            _on_err,
            label="Edit DAG render",
            token=self._render_token,
        )

    def _build_scene_model(
        self,
        payload: object,
        artifact: Mapping[str, Any] | None = None,
        *,
        collapse_threshold_pct: float | None = None,
        show_exact_values: bool | None = None,
    ) -> _DagSceneModel:
        nx_mod = require_networkx()

        dag = _coerce_dag(payload)
        graph_payload = artifact.get("graph") if isinstance(artifact, Mapping) else None
        if not isinstance(graph_payload, Mapping) or not graph_payload.get("nodes"):
            raise ValueError("Run artifact missing graph nodes.")
        if str(graph_payload.get("source") or "") != "dag":
            raise ValueError("Edit DAG view requires a DAG-backed run artifact.")
        graph_hash = str(graph_payload.get("graph_hash") or "")
        if graph_hash and graph_hash != self._hash_dag(dag):
            raise ValueError("Run artifact graph hash mismatch.")
        signature = (str(dag.root_id), len(dag.nodes), len(dag.edges))
        if self._layout_signature != signature:
            self._node_overrides.clear()
            self._layout_signature = signature
        root_id = dag.root_id
        node_prob_raw: dict[str, float] = {}
        for entry in graph_payload.get("nodes", []):
            if not isinstance(entry, Mapping):
                continue
            nid = str(entry.get("id") or "")
            if not nid:
                continue
            node_prob_raw[nid] = max(0.0, float(entry.get("p_node", 0.0)))
        node_prob_raw.setdefault(str(root_id), 1.0)
        node_prob_display = dict(node_prob_raw)
        edge_prob_map: dict[tuple[str, str], float] = {}
        for edge in graph_payload.get("edges", []):
            if not isinstance(edge, Mapping):
                continue
            src = str(edge.get("source") or "")
            dst = str(edge.get("target") or "")
            if not src or not dst:
                continue
            edge_prob_map[(src, dst)] = float(edge.get("prob", 0.0))

        # Depth = time_step if provided, else topological distance from root.
        graph = nx_mod.DiGraph()
        node_depth: dict[str, int] = {}
        node_stage: dict[str, str] = {}
        parents: dict[str, tuple[str, ...]] = {}
        for node_id, node in dag.nodes.items():
            stage = str((node.metadata or {}).get("stage") or "unknown")
            node_stage[node_id] = stage
            parent_ids = tuple(node.parents or ())
            parents[node_id] = parent_ids
            graph.add_node(node_id)
            try:
                t = int((node.metadata or {}).get("time_step"))
            except Exception:
                t = None
            if t is not None:
                node_depth[node_id] = max(0, t)
        for edge in dag.edges:
            graph.add_edge(edge.source, edge.target, rule=edge.rule_name or "", metadata=edge.metadata or {})
            if edge.target not in node_depth:
                # fallback: depth = parent depth + 1
                node_depth[edge.target] = max(node_depth.get(edge.source, 0) + 1, node_depth.get(edge.target, 0))

        # Ensure root depth = 0 and propagate depths forward.
        node_depth[root_id] = 0
        for node_id in nx_mod.topological_sort(graph):
            if node_id == root_id:
                continue
            pred_depths = [node_depth.get(p, 0) for p in parents.get(node_id, [])]
            if pred_depths:
                node_depth[node_id] = max(pred_depths) + 1
            else:
                node_depth[node_id] = node_depth.get(node_id, 0)

        # Collapse very low-probability branches (except root). Keep ancestors for connectivity.
        if collapse_threshold_pct is None:
            threshold = float(self._collapse_spin.value()) / 100.0
        else:
            threshold = float(collapse_threshold_pct) / 100.0
        keep_nodes = {root_id}
        for nid, p in node_prob_display.items():
            if p >= threshold:
                keep_nodes.add(nid)
        stack = list(keep_nodes)
        while stack:
            nid = stack.pop()
            for parent in parents.get(nid, ()):
                if parent not in keep_nodes:
                    keep_nodes.add(parent)
                    stack.append(parent)
        suppressed: list[tuple[str, float, tuple[str, ...]]] = []
        for nid, p in node_prob_display.items():
            if nid in keep_nodes or nid == root_id:
                continue
            suppressed.append((nid, node_prob_raw.get(nid, 0.0), parents.get(nid, ())))
        graph = graph.subgraph(keep_nodes).copy()
        terminals = set(str(t) for t in graph_payload.get("terminals", []) if isinstance(t, (str, int)))
        suppressed_terminal_mass = 0.0
        if terminals:
            for tid in terminals:
                if tid not in keep_nodes:
                    suppressed_terminal_mass += float(node_prob_raw.get(tid, 0.0))
        other_id = None
        if suppressed_terminal_mass > 0.0:
            other_id = "__other__"
            graph.add_node(other_id)
            graph.add_edge(root_id, other_id, rule="pruned", metadata={"kind": "other"})
            parents[other_id] = (root_id,)
            node_depth[other_id] = node_depth.get(root_id, 0) + 1
            node_stage[other_id] = "other"
            node_prob_raw[other_id] = float(suppressed_terminal_mass)
            node_prob_display[other_id] = float(suppressed_terminal_mass)
            edge_prob_map[(str(root_id), other_id)] = float(suppressed_terminal_mass)

        # Dominant path (highest-prob leaf) for optional highlighting.
        main_path_nodes: set[str] = set()
        main_path_edges: set[tuple[str, str]] = set()
        dominant_leaf: str | None = None
        try:
            leaves = [n for n in graph.nodes if graph.out_degree(n) == 0]
            best_leaf = max(leaves or [root_id], key=lambda n: node_prob_display.get(n, 0.0))
            dominant_leaf = best_leaf
            current = best_leaf
            while True:
                main_path_nodes.add(current)
                preds = list(graph.predecessors(current))
                if not preds:
                    break
                best_parent = max(preds, key=lambda n: node_prob_display.get(n, 0.0))
                main_path_edges.add((best_parent, current))
                current = best_parent
        except Exception:
            main_path_nodes = set()
            main_path_edges = set()
            dominant_leaf = None
        self._main_path_nodes = main_path_nodes
        self._main_path_edges = main_path_edges

        # Layered, axis-aligned layout (depth → x).
        layers: dict[int, list[str]] = {}
        for nid in graph.nodes:
            d = node_depth.get(nid, 0)
            layers.setdefault(d, []).append(nid)
        for lst in layers.values():
            lst.sort(key=lambda n: node_prob_display.get(n, 0.0), reverse=True)

        layer_gap = 240.0
        margin_x = 100.0
        margin_y = 90.0
        padding_y = 24.0
        base_w = 150.0
        base_h = 60.0

        nodes: list[_DagNodeView] = []
        mass_audit = self._audit_mass(dag, node_prob_raw, suppressed)
        weight_label = self._prob_label or "flow"
        show_exact = bool(show_exact_values) if show_exact_values is not None else False

        for depth, nids in sorted(layers.items(), key=lambda kv: kv[0]):
            layer_x_px = margin_x + depth * layer_gap
            current_y = margin_y
            for nid in nids:
                x_px = layer_x_px
                stage = node_stage.get(nid, "unknown")
                # If a "root" shows up downstream, frame it as a baseline state to avoid duplicate-root confusion.
                stage_display = "baseline" if (stage == "root" and depth > 0) else stage
                raw_node = dag.nodes.get(nid)
                prob = node_prob_display.get(nid, 0.0)
                prob_pct = prob * 100.0

                role = "internal"
                if nid == root_id:
                    role = "root"
                elif graph.out_degree(nid) == 0:
                    role = "terminal"
                stage_label = _format_node_title(stage=stage_display, node=raw_node, role=role)

                scale = 0.9 + 1.6 * math.sqrt(max(0.0, min(1.0, prob)))
                width = base_w * scale
                # Terminals: cap height to keep them calm; width still conveys mass.
                height_scale = 1.0 if role != "terminal" else 1.0
                height = base_h * height_scale
                min_w, min_h = 110.0, 48.0
                max_w, max_h = 320.0, 120.0 if role == "terminal" else 180.0
                width = max(min_w, min(max_w, width))
                height = max(min_h, min(max_h, height))

                y_px = current_y + height / 2.0
                current_y += height + padding_y
                override = self._node_overrides.get(str(nid))
                if override is not None:
                    x_px = float(override.x())
                    y_px = float(override.y())

                semantics = self._build_semantics(
                    node_id=nid,
                    node=raw_node,
                    stage=stage_display,
                    prob=prob,
                    time_step=depth,
                    parents=parents.get(nid, ()),
                    mass_audit=mass_audit.get(nid),
                )

                nodes.append(
                    _DagNodeView(
                        node_id=nid,
                        stage=stage_display,
                        title=stage_label,
                        subtitle=_format_weight_display(label=weight_label, value=prob, exact=show_exact),
                        prob=prob,
                        time_step=depth,
                        x=x_px,
                        y=y_px,
                        role=role,
                        width=width,
                        height=height,
                        semantics=semantics,
                    )
                )

        edges: list[_DagEdgeView] = []
        edge_meta: dict[tuple[str, str], Mapping[str, Any]] = {}
        for src, dst, data in graph.edges(data=True):
            rule = str((data or {}).get("rule") or "")
            weight = float(edge_prob_map.get((str(src), str(dst)), 0.0))
            metadata = (data or {}).get("metadata") if isinstance(data, Mapping) else {}
            edge_meta[(str(src), str(dst))] = dict(metadata) if isinstance(metadata, Mapping) else {}
            constraints, issues = self._build_edge_constraints(metadata)
            edges.append(
                _DagEdgeView(
                    source=str(src),
                    target=str(dst),
                    rule=rule,
                    weight=weight,
                    constraints=constraints,
                    issues=tuple(issues),
                )
            )

        edge_events = {(str(e.source), str(e.target)): e.event for e in dag.edges}

        return _DagSceneModel(
            nodes=nodes,
            edges=edges,
            suppressed=suppressed,
            dominant_leaf_id=dominant_leaf,
            dag=dag,
            mass_audit=mass_audit,
            edge_events=edge_events,
            edge_meta=edge_meta,
        )

    def _audit_mass(
        self,
        dag: EditDAG,
        node_prob_raw: Mapping[str, float],
        suppressed: list[tuple[str, float, tuple[str, ...]]],
    ) -> dict[str, MassAudit]:
        issues: list[str] = []
        provenance = build_provenance(
            None,
            default_source="dag",
            default_method="mass_audit",
            issues=issues,
        )
        suppressed_nodes = [
            SuppressedNode(node_id=nid, prob=float(prob), parents=tuple(parents))
            for nid, prob, parents in suppressed
        ]
        return audit_mass_conservation(
            dag,
            node_prob_raw,
            suppressed_nodes,
            epsilon=1e-6,
            provenance=provenance,
        )

    def _build_semantics(
        self,
        *,
        node_id: str,
        node: Any,
        stage: str,
        prob: float,
        time_step: int,
        parents: Sequence[str],
        mass_audit: MassAudit | None,
    ) -> _SemanticBinding:
        issues: list[str] = []
        metadata = getattr(node, "metadata", {}) if node is not None else {}
        meta_map = metadata if isinstance(metadata, Mapping) else {}

        provenance = build_provenance(
            meta_map.get("provenance") if isinstance(meta_map.get("provenance"), Mapping) else None,
            default_source="dag",
            default_method="node_metadata",
            issues=issues,
        )
        phys = meta_map.get("physical_state") if isinstance(meta_map.get("physical_state"), Mapping) else {}

        mol_cfg = phys.get("molecular_config") if isinstance(phys, Mapping) else None
        if not mol_cfg:
            mol_cfg = meta_map.get("molecular_config")
        molecular_config = mol_cfg if isinstance(mol_cfg, str) and mol_cfg else unknown("molecular_config missing")

        strand_pol = phys.get("strand_polarity") if isinstance(phys, Mapping) else None
        if not strand_pol:
            strand_pol = meta_map.get("strand")
        strand_polarity = strand_pol if isinstance(strand_pol, str) and strand_pol else unknown("strand polarity missing")

        energy = meta_map.get("energy_margin")
        if energy is None:
            for key in ("dG_total", "dG", "delta_g"):
                if key in meta_map:
                    energy = meta_map.get(key)
                    break
        energy_prov = build_provenance(
            phys.get("energy_provenance") if isinstance(phys, Mapping) and isinstance(phys.get("energy_provenance"), Mapping) else None,
            default_source="simulation",
            default_method="energy_model",
            issues=issues,
        )
        base_pair_energy = build_scalar(
            energy if isinstance(energy, (float, int)) else None,
            Unit.KCAL_PER_MOL,
            energy_prov,
            issues=issues,
            field_label="physical_state.base_pair_energy",
            missing_reason="base pair energy missing",
        )

        physical_state = PhysicalState(
            molecular_config=molecular_config,
            strand_polarity=strand_polarity,
            base_pair_energy=base_pair_energy,
        )

        causal_role = self._coerce_causal_role(str(meta_map.get("causal_role") or stage or "unknown"))

        unc_prov = build_provenance(
            meta_map.get("uncertainty_provenance") if isinstance(meta_map.get("uncertainty_provenance"), Mapping) else None,
            default_source="dag",
            default_method="uncertainty_model",
            issues=issues,
        )
        uncertainty = build_uncertainty(
            meta_map.get("uncertainty") if isinstance(meta_map.get("uncertainty"), Mapping) else None,
            provenance=unc_prov,
            issues=issues,
        )
        # Record the node flow weight as a provenance-backed parameter (display-normalized).
        try:
            uncertainty.params["flow_weight"] = ScalarValue(value=float(prob), unit=Unit.UNITLESS, provenance=provenance)
        except Exception:
            issues.append("uncertainty.flow_weight invalid")

        time_stage = self._coerce_time_stage(str(meta_map.get("time_locality") or stage or "unknown"))
        time_prov = build_provenance(
            meta_map.get("time_provenance") if isinstance(meta_map.get("time_provenance"), Mapping) else None,
            default_source="dag",
            default_method="time_step",
            issues=issues,
        )
        time_locality = TimeLocality(stage=time_stage, time_step=int(time_step), provenance=time_prov)

        parent_label = ", ".join(parents) or "root"
        weight_txt = f"{prob:.4f}"
        if mass_audit is not None and mass_audit.violated:
            invariant = (
                f"Removing this node hides flow_weight={weight_txt} "
                f"and disconnects the displayed path from {parent_label} (unnormalized)."
            )
        else:
            invariant = (
                f"Removing this node hides flow_weight={weight_txt} "
                f"and disconnects the displayed path from {parent_label}."
            )

        evidence: list[Evidence] = []
        evidence_raw = meta_map.get("evidence") if isinstance(meta_map.get("evidence"), list) else []
        for entry in evidence_raw:
            if isinstance(entry, Mapping):
                ev_type = str(entry.get("type") or "other").lower()
                try:
                    parsed_type = EvidenceType(ev_type)
                except Exception:
                    issues.append(f"evidence.type unknown: {ev_type}")
                    parsed_type = EvidenceType.OTHER
                detail = str(entry.get("detail") or entry.get("label") or "evidence")
                ev_prov = build_provenance(
                    entry.get("provenance") if isinstance(entry.get("provenance"), Mapping) else None,
                    default_source="measurement",
                    default_method="evidence",
                    issues=issues,
                )
                evidence.append(Evidence(evidence_type=parsed_type, detail=detail, provenance=ev_prov))
            elif entry:
                ev_prov = build_provenance(
                    None,
                    default_source="measurement",
                    default_method="evidence",
                    issues=issues,
                )
                evidence.append(Evidence(evidence_type=EvidenceType.OTHER, detail=str(entry), provenance=ev_prov))

        cal_raw = meta_map.get("calibration") if isinstance(meta_map.get("calibration"), Mapping) else {}
        cal_badge = str(cal_raw.get("badge") or cal_raw.get("status") or "unknown").lower()
        try:
            calibration = CalibrationBadge(cal_badge)
        except Exception:
            issues.append(f"calibration badge unknown: {cal_badge}")
            calibration = CalibrationBadge.UNKNOWN

        conservation = mass_audit
        if conservation is None:
            fallback_prov = build_provenance(None, default_source="dag", default_method="mass_audit", issues=issues)
            conservation = MassAudit(
                mass_out_total=ScalarValue(value=1.0, unit=Unit.PROBABILITY, provenance=fallback_prov),
                mass_suppressed=ScalarValue(value=0.0, unit=Unit.PROBABILITY, provenance=fallback_prov),
                mass_unaccounted=ScalarValue(value=0.0, unit=Unit.PROBABILITY, provenance=fallback_prov),
                epsilon=1e-3,
                violated=False,
            )

        binding = SemanticBinding(
            physical_state=physical_state,
            causal_role=causal_role,
            uncertainty=uncertainty,
            time_locality=time_locality,
            invariant=invariant,
            evidence=evidence,
            calibration=calibration,
            provenance=provenance,
            conservation=conservation,
        )
        issues.extend(validate_semantic_binding(binding))
        return _SemanticBinding(binding=binding, issues=tuple(issues))

    def _coerce_causal_role(self, value: str) -> CausalRole:
        key = (value or "").strip().lower().replace(" ", "_")
        mapping = {
            "root": CausalRole.ROOT,
            "baseline": CausalRole.BASELINE,
            "binding": CausalRole.BINDING,
            "pam": CausalRole.PAM_RECOGNITION,
            "pam_recognition": CausalRole.PAM_RECOGNITION,
            "conformational_change": CausalRole.CONFORMATIONAL_CHANGE,
            "cut": CausalRole.CUT,
            "resection": CausalRole.RESECTION,
            "synthesis": CausalRole.SYNTHESIS,
            "ligation": CausalRole.LIGATION,
            "mismatch_repair": CausalRole.MISMATCH_REPAIR,
            "repair": CausalRole.REPAIR,
            "resolve": CausalRole.RESOLVE,
        }
        return mapping.get(key, CausalRole.UNKNOWN)

    def _coerce_time_stage(self, value: str) -> TimeStage:
        key = (value or "").strip().lower().replace(" ", "_")
        mapping = {
            "pre_cut": TimeStage.PRE_CUT,
            "post_cut": TimeStage.POST_CUT,
            "repair": TimeStage.REPAIR_IN_PROGRESS,
            "repair_in_progress": TimeStage.REPAIR_IN_PROGRESS,
            "resolved": TimeStage.RESOLVED,
        }
        return mapping.get(key, TimeStage.UNKNOWN)

    def _build_edge_constraints(self, metadata: Mapping[str, Any] | None) -> tuple[EdgeConstraints, list[str]]:
        issues: list[str] = []
        meta = metadata if isinstance(metadata, Mapping) else {}
        constraints_raw = meta.get("constraints") if isinstance(meta.get("constraints"), Mapping) else {}
        exclusive_with = constraints_raw.get("exclusive_with") if isinstance(constraints_raw.get("exclusive_with"), list) else []
        requires = constraints_raw.get("requires") if isinstance(constraints_raw.get("requires"), list) else []
        forbids = constraints_raw.get("forbids") if isinstance(constraints_raw.get("forbids"), list) else []
        prov = build_provenance(
            constraints_raw.get("provenance") if isinstance(constraints_raw.get("provenance"), Mapping) else None,
            default_source="dag",
            default_method="edge_constraints",
            issues=issues,
        )
        constraints = EdgeConstraints(
            exclusive_with=[str(x) for x in exclusive_with if x],
            requires=[str(x) for x in requires if x],
            forbids=[str(x) for x in forbids if x],
            provenance=prov,
        )
        if not (constraints.exclusive_with or constraints.requires or constraints.forbids):
            issues.append("constraints missing")
        return constraints, issues

    def _apply_model(self, model: _DagSceneModel) -> None:
        self._scene.blockSignals(True)
        self._dominant_leaf_id = model.dominant_leaf_id
        self._latest_model = model
        try:
            has_audit, ok, _worst, _epsilon = self._mass_audit_status(model.mass_audit)
            self._mass_audit_ok = ok if has_audit else None
            if self._mass_audit_callout is not None:
                self._mass_audit_callout.setVisible(bool(not self._structural_mode and has_audit and not ok))

            self._scene.clear()
            self._stack.setCurrentWidget(self._view)

            max_prob = max((node.prob for node in model.nodes), default=1e-9)
            self._node_items: dict[str, QGraphicsItem] = {}
            self._edge_items: list[tuple[str, str, QGraphicsItem]] = []
            node_prob_map = {n.node_id: n.prob for n in model.nodes}

            max_edge_weight = max((edge.weight for edge in model.edges), default=1e-6)

            for node in model.nodes:
                prob_weight = 0.0 if max_prob <= 0 else min(1.0, node.prob / max_prob)
                item = self._make_node_item(node, prob_weight)
                self._scene.addItem(item)
                self._node_items[node.node_id] = item

            for edge in model.edges:
                src_item = self._node_items.get(edge.source)
                dst_item = self._node_items.get(edge.target)
                if src_item is None or dst_item is None:
                    continue
                item = self._make_edge_item(edge, src_item, dst_item, max_edge_weight)
                self._scene.addItem(item)
                self._edge_items.append((edge.source, edge.target, item))
                if isinstance(src_item, _DagNodeItem) and isinstance(item, _DagEdgeItem):
                    src_item.add_edge(item)
                if isinstance(dst_item, _DagNodeItem) and isinstance(item, _DagEdgeItem):
                    dst_item.add_edge(item)

            self._scene.setSceneRect(
                self._scene.itemsBoundingRect().adjusted(-80, -80, 80, 80)
            )
            try:
                self._view.fitInView(self._scene.sceneRect(), Qt.KeepAspectRatio)
            except Exception:
                pass
            if self._pending_select_node_id:
                try:
                    self._select_node_if_present(self._pending_select_node_id)
                    self._update_node_details(self._pending_select_node_id)
                finally:
                    self._pending_select_node_id = None
            else:
                self._apply_focus_filter(None)
                self._update_node_details(None)
            self._refresh_tail_risk_panel()
            self._update_suppressed_label(model)
            self._update_mass_audit_label(model)
            self._update_outcome_summary(model)
            self._sync_layout_edit_state()
        finally:
            self._scene.blockSignals(False)

    def _update_suppressed_label(self, model: _DagSceneModel) -> None:
        if self._suppressed_label is None:
            return
        suppressed = model.suppressed or []
        if not suppressed:
            self._suppressed_label.hide()
            return
        mass = sum(p for _, p, _ in suppressed)
        self._suppressed_label.setText(
            f"Suppressed {len(suppressed)} low-flow branches · hidden relative mass={mass:.4f} (reachable if threshold lowered)"
        )
        self._suppressed_label.show()

    def _mass_audit_status(
        self,
        audits: Mapping[str, MassAudit] | None,
    ) -> tuple[bool, bool, float, float]:
        if self._structural_mode:
            return False, True, 0.0, 1e-3
        if not audits:
            return False, True, 0.0, 1e-3
        worst = max_mass_violation(audits)
        epsilon = next(iter(audits.values())).epsilon if audits else 1e-3
        ok = worst <= epsilon
        return True, bool(ok), float(worst), float(epsilon)

    def _update_mass_audit_label(self, model: _DagSceneModel) -> None:
        if self._mass_audit_label is None:
            return
        # Prefer explicit mass block if present (e.g., leakage sinks enabled).
        mass_line = None
        try:
            payload_mass = None
            if isinstance(self._latest_payload, Mapping):
                payload_mass = self._latest_payload.get("mass")
            mass_line = format_mass_audit_line(payload_mass)
        except Exception:
            mass_line = None

        if mass_line:
            self._mass_audit_label.setText(mass_line)
            self._mass_audit_label.setStyleSheet("color: palette(window-text); font-size: 11px;")
            self._mass_audit_label.show()
            return

        has_audit, ok, worst, epsilon = self._mass_audit_status(model.mass_audit)
        if self._structural_mode:
            self._mass_audit_label.setText("Mass audit: N/A (visual weights only)")
            self._mass_audit_label.setStyleSheet("color: palette(mid); font-size: 11px;")
            self._mass_audit_label.show()
            return
        if not has_audit:
            self._mass_audit_label.hide()
            return
        if ok:
            self._mass_audit_label.setText(f"Mass audit: OK (max |1−total|={worst:.4f} ≤ ε={epsilon})")
            self._mass_audit_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        else:
            self._mass_audit_label.setText(f"Mass audit: FAIL (max |1−total|={worst:.4f} > ε={epsilon})")
            self._mass_audit_label.setStyleSheet("color: palette(highlight); font-size: 11px;")
        self._mass_audit_label.show()

    def _update_outcome_summary(self, model: _DagSceneModel | None) -> None:
        bar = self._summary_bar
        label = self._summary_label
        confidence_label = self._confidence_label
        btn = self._summary_receipt_btn
        if bar is None or label is None or btn is None:
            return
        if model is None:
            bar.setVisible(False)
            btn.setEnabled(False)
            self._summary_sentence_plain = None
            label.setText("")
            if confidence_label is not None:
                confidence_label.setText("")
                confidence_label.setVisible(False)
            return

        terminals = [n for n in (model.nodes or []) if getattr(n, "role", "") == "terminal"]
        if not terminals:
            bar.setVisible(False)
            btn.setEnabled(False)
            self._summary_sentence_plain = None
            label.setText("")
            if confidence_label is not None:
                confidence_label.setText("")
                confidence_label.setVisible(False)
            return
        terminals.sort(key=lambda n: float(getattr(n, "prob", 0.0)), reverse=True)
        top = terminals[:3]

        def _pct(prob: float) -> int:
            try:
                p = max(0.0, min(1.0, float(prob)))
            except Exception:
                p = 0.0
            return int(round(p * 100.0))

        prefix = "Dominant simulated outcome"
        qualifier = "visual weights" if (self._structural_mode or self._mass_audit_ok is False) else None

        def _fragment_plain(node: _DagNodeView) -> str:
            return f"{node.title} (~{_pct(node.prob)}%)"

        def _fragment_html(node: _DagNodeView, *, emphasize: bool) -> str:
            title = html.escape(str(node.title or ""))
            pct = _pct(node.prob)
            title_html = f"<span style=\"font-weight: 650;\">{title}</span>" if emphasize else title
            pct_html = f"<span style=\"font-size: 11px; font-weight: 400;\">(~{pct}%)</span>"
            return f"{title_html} {pct_html}".strip()

        fragments_plain = [_fragment_plain(n) for n in top]
        text_plain = f"{prefix}{f' ({qualifier})' if qualifier else ''}: {fragments_plain[0]}"
        if len(fragments_plain) > 1:
            text_plain += ", secondary: " + ", ".join(fragments_plain[1:])
        text_plain += "."

        prefix_html = f"<b>{html.escape(prefix)}</b>"
        if qualifier:
            prefix_html += f" <span style=\"font-size: 11px; font-weight: 400;\">({html.escape(qualifier)})</span>"
        text_html = f"{prefix_html}: {_fragment_html(top[0], emphasize=True)}"
        if len(top) > 1:
            text_html += ", secondary: " + ", ".join(_fragment_html(n, emphasize=False) for n in top[1:])
        text_html += "."

        self._summary_sentence_plain = text_plain

        label.setText(text_html)
        bar.setVisible(True)
        btn.setEnabled(True)
        if confidence_label is not None:
            level, reasons = self._confidence_for_model(model)
            line = f"Confidence: {level}"
            if reasons:
                line += " (" + ", ".join(reasons) + ")"
            confidence_label.setText(line)
            confidence_label.setToolTip(
                "Qualitative confidence is derived from calibration/evidence tags in the semantic schema.\n"
                "It is a transparency aid for simulation outputs, not a clinical/safety claim."
            )
            confidence_label.setVisible(True)

    def _confidence_for_model(self, model: _DagSceneModel) -> tuple[str, list[str]]:
        """Return a qualitative confidence tag + short reasons for display."""
        reasons: list[str] = []

        if self._structural_mode:
            reasons.append("structural mode")
        if self._mass_audit_ok is False:
            reasons.append("mass audit failed")

        node: _DagNodeView | None = None
        dom_id = getattr(model, "dominant_leaf_id", None)
        if dom_id:
            node = next((n for n in (model.nodes or []) if n.node_id == dom_id), None)
        if node is None:
            terminals = [n for n in (model.nodes or []) if getattr(n, "role", "") == "terminal"]
            if terminals:
                node = max(terminals, key=lambda n: float(getattr(n, "prob", 0.0)))

        if node is not None:
            sem = node.semantics.binding
            if sem.calibration != CalibrationBadge.MEASURED:
                reasons.append("uncalibrated model")
            if not sem.evidence:
                reasons.append("missing evidence tags")

        if self._structural_mode or self._mass_audit_ok is False:
            return "Low", reasons
        if "uncalibrated model" in reasons and "missing evidence tags" in reasons:
            return "Low", reasons
        if "uncalibrated model" in reasons or "missing evidence tags" in reasons:
            return "Medium", reasons
        return "High", reasons

    def _confidence_for_node(self, node: _DagNodeView) -> tuple[str, list[str]]:
        reasons: list[str] = []
        if self._structural_mode:
            reasons.append("structural mode")
        if self._mass_audit_ok is False:
            reasons.append("mass audit failed")
        sem = node.semantics.binding
        if sem.calibration != CalibrationBadge.MEASURED:
            reasons.append("uncalibrated model")
        if not sem.evidence:
            reasons.append("missing evidence tags")
        if self._structural_mode or self._mass_audit_ok is False:
            return "Low", reasons
        if "uncalibrated model" in reasons and "missing evidence tags" in reasons:
            return "Low", reasons
        if "uncalibrated model" in reasons or "missing evidence tags" in reasons:
            return "Medium", reasons
        return "High", reasons

    def _select_node_if_present(self, node_id: str) -> bool:
        wanted = str(node_id)
        if not wanted:
            return False
        try:
            items = list(self._scene.items())
        except Exception:
            items = []
        for item in items:
            try:
                data = item.data(0)
            except Exception:
                continue
            if data is None:
                continue
            if str(data) != wanted:
                continue
            try:
                self._scene.clearSelection()
                item.setSelected(True)
                self._view.centerOn(item)
                self._selection.setText(f"Selected: {wanted}")
                self._selection.show()
                self._position_canvas_overlays()
                self._update_node_details(wanted)
            except Exception:
                pass
            return True
        return False

    def _make_node_item(self, node: _DagNodeView, prob_weight: float) -> QGraphicsItem:
        stage_key = (node.stage or "unknown").strip().lower()
        stage_color = {
            "root": QColor(125, 211, 252),
            "binding": QColor(167, 139, 250),
            "cut": QColor(251, 113, 133),
            "repair": QColor(52, 211, 153),
            "repaired": QColor(52, 211, 153),
            "resolve": QColor(251, 191, 36),
            "cycled": QColor(96, 165, 250),
            "amplicon": QColor(52, 211, 153),
            "error": QColor(251, 113, 133),
            "no_edit": QColor(156, 163, 175),
            "no_product": QColor(156, 163, 175),
        }.get(stage_key, QColor(169, 185, 212))

        alpha = int(30 + 150 * math.sqrt(max(0.0, min(1.0, prob_weight))))
        fill_base = QColor(stage_color)
        fill_base.setAlpha(alpha)
        fill_hi = QColor(stage_color)
        hi_boost = 40
        if stage_key in {"no_edit", "no_cut"}:
            # Keep "No edit" outcomes solid (not disabled-looking).
            hi_boost = 14
        fill_hi.setAlpha(min(220, alpha + hi_boost))

        padding_x = 12.0
        padding_y = 8.0
        width = float(node.width)
        height = float(node.height)

        gradient = QLinearGradient(0.0, 0.0, 0.0, height)
        gradient.setColorAt(0.0, fill_hi)
        gradient.setColorAt(1.0, fill_base)
        fill_brush = QBrush(gradient)

        path = QPainterPath()
        if node.role == "root":
            path.addEllipse(0, 0, width, height)
            pen_width = 2.6
        elif node.role == "terminal":
            path.addRoundedRect(0, 0, width, height, 14.0, 14.0)
            pen_width = 2.2
        else:
            path.addRoundedRect(0, 0, width, height, 10.0, 10.0)
            pen_width = 1.8

        palette = self.palette()
        selected_color = QColor(palette.color(QPalette.Highlight))
        sem = node.semantics.binding
        inferred = sem.calibration != CalibrationBadge.MEASURED
        pen_style = Qt.SolidLine if stage_key in {"no_edit", "no_cut"} else (Qt.DashLine if inferred else Qt.SolidLine)
        box = _DagNodeItem(
            node.node_id,
            path,
            fill=fill_brush,
            border_color=stage_color,
            pen_width=pen_width,
            pen_style=pen_style,
            selected_color=selected_color,
            palette=palette,
            on_move=self._register_node_override,
        )
        is_sink = stage_key == "sink" or node.node_id.startswith("sink.") or bool(node.semantics.binding.invariant == "sink")
        badge, badge_tooltip = sink_badge_and_tooltip(
            {"id": node.node_id, "stage": stage_key, "type": stage_key, "is_sink": is_sink}
        )

        tooltip_lines = [
            f"Node: {node.node_id}",
            f"Stage: {node.stage}",
            f"Depth: {node.time_step}",
            f"Flow weight (normalized): {node.prob:.4f}",
            f"Role: {node.role}",
            f"Physical.molecular_config: {sem.physical_state.molecular_config}",
            f"Physical.strand_polarity: {sem.physical_state.strand_polarity}",
            f"Physical.base_pair_energy: {format_scalar(sem.physical_state.base_pair_energy)}",
            f"Causal role: {sem.causal_role.value}",
            f"Uncertainty.type: {sem.uncertainty.type.value}",
            f"Uncertainty.family: {sem.uncertainty.distribution_family.value}",
            f"Time: {sem.time_locality.stage.value} @ t={sem.time_locality.time_step}",
            f"Invariant: {sem.invariant}",
            f"Calibration: {sem.calibration.value}",
            f"Mass_out_total: {format_scalar(sem.conservation.mass_out_total)}",
            f"Mass_suppressed: {format_scalar(sem.conservation.mass_suppressed)}",
            f"Mass_unaccounted: {format_scalar(sem.conservation.mass_unaccounted)}",
        ]
        tooltip_lines.append(
            f"Provenance: {sem.provenance.source}/{sem.provenance.method} v{sem.provenance.version} @ {sem.provenance.timestamp}"
        )
        if isinstance(sem.physical_state.base_pair_energy, ScalarValue):
            ep = sem.physical_state.base_pair_energy.provenance
            tooltip_lines.append(f"Energy provenance: {ep.source}/{ep.method} v{ep.version} @ {ep.timestamp}")
        if sem.uncertainty.correlation_id:
            tooltip_lines.append(f"Uncertainty correlation_id: {sem.uncertainty.correlation_id}")
        tooltip_lines.append(
            f"Uncertainty provenance: {sem.uncertainty.provenance.source}/{sem.uncertainty.provenance.method}"
        )
        if sem.conservation.violated:
            tooltip_lines.append(f"Mass audit violated (ε={sem.conservation.epsilon})")
        if sem.evidence:
            tooltip_lines.append("Evidence: " + ", ".join(e.detail for e in sem.evidence))
        if node.semantics.issues:
            tooltip_lines.append("Schema issues: " + "; ".join(node.semantics.issues))
        if badge_tooltip:
            tooltip_lines.append(badge_tooltip)
        if self._mass_audit_ok is False:
            tooltip_lines.append("Visualization weight only. Not normalized as probabilities. Do not interpret as likelihood.")
        if self._layout_editing:
            tooltip_lines.append("Drag nodes: enabled (drag background to pan)")
        box.setToolTip("\n".join(tooltip_lines))

        # Title (stage)
        title_text = f"{badge} · {node.title}" if badge else node.title
        title_item = QGraphicsTextItem(title_text)
        title_font = QFont("Inter", 10)
        title_font.setBold(True)
        title_item.setFont(title_font)
        title_color = QColor(palette.color(QPalette.WindowText))
        title_item.setDefaultTextColor(title_color)

        hint_item: QGraphicsTextItem | None = None
        if stage_key == "cut":
            hint_item = QGraphicsTextItem("branching point")
            hint_item.setFont(QFont("Inter", 8))
        elif stage_key in {"no_edit", "no_cut"}:
            hint_item = QGraphicsTextItem("repair without indel")
            hint_font = QFont("Inter", 8)
            hint_font.setItalic(True)
            hint_item.setFont(hint_font)
        if hint_item is not None:
            hint_color = QColor(palette.color(QPalette.Mid))
            hint_color.setAlpha(190)
            hint_item.setDefaultTextColor(hint_color)

        # Subtitle (flow weight, muted)
        subtitle_item = QGraphicsTextItem(node.subtitle)
        subtitle_font = QFont("Inter", 8)
        subtitle_item.setFont(subtitle_font)
        subtitle_color = QColor(palette.color(QPalette.Mid))
        subtitle_color.setAlpha(155)
        subtitle_item.setDefaultTextColor(subtitle_color)
        for text_item in (title_item, hint_item, subtitle_item):
            if text_item is None:
                continue
            try:
                text_item.setAcceptedMouseButtons(Qt.NoButton)
            except Exception:
                pass

        weight_tooltip = [
            "Flow weight = model-estimated fraction of simulated outcomes reaching this node (normalized within this DAG view).",
            "Shown as an approximate band to avoid false precision; enable “Exact values” to see the raw number.",
        ]
        if self._mass_audit_ok is False:
            weight_tooltip.append(
                "Note: mass audit failed, so weights are relative visualization weights (do not interpret as probabilities)."
            )
        subtitle_item.setToolTip("\n".join(weight_tooltip))

        title_item.setParentItem(box)
        if hint_item is not None:
            hint_item.setParentItem(box)
        subtitle_item.setParentItem(box)
        # Subtle scrim/shadow to keep the label readable on bright fills.
        title_shadow = QGraphicsDropShadowEffect()
        title_shadow.setBlurRadius(6.0)
        title_shadow.setOffset(0.0, 1.0)
        shadow_color = QColor(palette.color(QPalette.Shadow))
        shadow_color.setAlpha(180)
        title_shadow.setColor(shadow_color)
        title_item.setGraphicsEffect(title_shadow)
        title_item.setPos(padding_x, padding_y)
        y = padding_y + title_item.boundingRect().height() + 2
        if hint_item is not None:
            hint_item.setPos(padding_x, y)
            y += hint_item.boundingRect().height() + 2
        subtitle_item.setPos(padding_x, y)

        box.setPos(node.x - width / 2.0, node.y - height / 2.0)
        box.set_drag_enabled(self._layout_editing)
        return box

    def _make_edge_item(
        self,
        edge: _DagEdgeView,
        src_item: QGraphicsItem,
        dst_item: QGraphicsItem,
        max_weight: float,
    ) -> QGraphicsItem:
        item = _DagEdgeItem(
            edge,
            src_item,
            dst_item,
            max_weight=max_weight,
            main_path=bool(self._highlight_main.isChecked() and (edge.source, edge.target) in self._main_path_edges),
            palette=self.palette(),
        )
        tooltip_lines = [
            f"{edge.source} → {edge.target}",
            f"Rule: {edge.rule or '—'}",
            f"Edge flow_weight (child/parent mass share): {edge.weight:.4f}",
        ]
        if self._mass_audit_ok is False:
            tooltip_lines.append("Note: edge weights are heuristic (mass not conserved)")
        if edge.constraints is not None:
            tooltip_lines.append(f"exclusive_with: {edge.constraints.exclusive_with or ['—']}")
            tooltip_lines.append(f"requires: {edge.constraints.requires or ['—']}")
            tooltip_lines.append(f"forbids: {edge.constraints.forbids or ['—']}")
            tooltip_lines.append(
                f"constraint provenance: {edge.constraints.provenance.source}/{edge.constraints.provenance.method}"
            )
        if edge.issues:
            tooltip_lines.append("Constraint issues: " + "; ".join(edge.issues))
        item.setToolTip("\n".join(tooltip_lines))
        return item

    def _on_scene_selection_changed(self) -> None:
        selected = self._scene.selectedItems()
        if not selected:
            self._details_dismissed_for_node_id = None
            self._selection.hide()
            self._apply_focus_filter(None)
            self._update_node_details(None)
            self._position_canvas_overlays()
            return
        node_id = selected[0].data(0)
        if not node_id:
            self._details_dismissed_for_node_id = None
            self._selection.hide()
            self._apply_focus_filter(None)
            self._update_node_details(None)
            self._position_canvas_overlays()
            return
        node_id_str = str(node_id)
        if self._details_dismissed_for_node_id is not None and self._details_dismissed_for_node_id != node_id_str:
            self._details_dismissed_for_node_id = None
        self._selection.setText(f"Selected: {node_id_str}")
        self._selection.show()
        self._position_canvas_overlays()
        self.nodeSelected.emit(node_id_str)
        self._apply_focus_filter(node_id_str)
        self._update_node_details(node_id_str)

    def _apply_focus_filter(self, node_id: str | None) -> None:
        # Reset if nothing selected
        if not getattr(self, "_node_items", None):
            return
        main_boost = self._highlight_main.isChecked()
        fade = 0.14
        if node_id is None:
            latest_model = getattr(self, "_latest_model", None)
            model_nodes = latest_model.nodes if latest_model is not None else []
            node_prob_map = {n.node_id: float(n.prob) for n in model_nodes}
            if not main_boost:
                for item in self._node_items.values():
                    item.setOpacity(1.0)
                    if isinstance(item, _DagNodeItem):
                        item.set_main_path_glow(False)
                    for child in item.childItems():
                        try:
                            child.setOpacity(item.opacity())
                        except Exception:
                            pass
                for _, _, eitem in getattr(self, "_edge_items", []):
                    try:
                        eitem.setGraphicsEffect(None)
                    except Exception:
                        pass
                    base_w = float(eitem.data(3) or eitem.pen().widthF())
                    pen = eitem.pen()
                    pen.setWidthF(base_w)
                    eitem.setPen(pen)
                    eitem.setOpacity(1.0)
                return

            # Dominant path emphasis (baseline state)
            for nid, item in self._node_items.items():
                if self._main_path_nodes and nid in self._main_path_nodes:
                    item.setOpacity(1.0)
                    if isinstance(item, _DagNodeItem):
                        item.set_main_path_glow(True)
                else:
                    prob = max(0.0, min(1.0, float(node_prob_map.get(nid, 0.0))))
                    item.setOpacity(0.10 + 0.28 * math.sqrt(prob))
                    if isinstance(item, _DagNodeItem):
                        item.set_main_path_glow(False)
                for child in item.childItems():
                    try:
                        child.setOpacity(item.opacity())
                    except Exception:
                        pass

            for src, dst, eitem in getattr(self, "_edge_items", []):
                in_main = bool(self._main_path_edges and (src, dst) in self._main_path_edges)
                base_w = float(eitem.data(3) or eitem.pen().widthF())
                pen = eitem.pen()
                if in_main:
                    eitem.setOpacity(1.0)
                    pen.setWidthF(base_w * 2.1)
                    color = QColor(self.palette().color(QPalette.Highlight))
                    color.setAlpha(245)
                    pen.setColor(color)
                    eitem.setPen(pen)
                    glow = QGraphicsDropShadowEffect()
                    glow.setBlurRadius(18.0)
                    glow.setOffset(0.0, 0.0)
                    glow_color = QColor(color)
                    glow_color.setAlpha(200)
                    glow.setColor(glow_color)
                    eitem.setGraphicsEffect(glow)
                else:
                    try:
                        eitem.setGraphicsEffect(None)
                    except Exception:
                        pass
                    pen.setWidthF(base_w * 0.55)
                    eitem.setPen(pen)
                    eitem.setOpacity(0.06)
            return

        related_nodes: set[str] = set()
        related_edges: set[tuple[str, str]] = set()
        try:
            # ancestry + descendants walk
            for src, dst, _ in getattr(self, "_edge_items", []):
                if src == node_id or dst == node_id:
                    related_edges.add((src, dst))
                    related_nodes.add(src)
                    related_nodes.add(dst)
        except Exception:
            pass
        for nid, item in self._node_items.items():
            if nid == node_id or nid in related_nodes:
                item.setOpacity(1.0)
            elif main_boost and nid in getattr(self, "_main_path_nodes", set()):
                item.setOpacity(0.70)
            else:
                item.setOpacity(fade)
            if isinstance(item, _DagNodeItem):
                item.set_main_path_glow(bool(main_boost and nid in getattr(self, "_main_path_nodes", set())))
        for src, dst, eitem in getattr(self, "_edge_items", []):
            edge_in_path = (src == node_id or dst == node_id or (src, dst) in related_edges)
            base_w = float(eitem.data(3) or eitem.pen().widthF())
            pen = eitem.pen()
            pen.setWidthF(base_w)
            if main_boost and (src, dst) in getattr(self, "_main_path_edges", set()):
                eitem.setOpacity(1.0)
                pen.setWidthF(base_w * 2.1)
                color = QColor(self.palette().color(QPalette.Highlight))
                color.setAlpha(245)
                pen.setColor(color)
                glow = QGraphicsDropShadowEffect()
                glow.setBlurRadius(18.0)
                glow.setOffset(0.0, 0.0)
                glow_color = QColor(color)
                glow_color.setAlpha(200)
                glow.setColor(glow_color)
                eitem.setGraphicsEffect(glow)
            else:
                try:
                    eitem.setGraphicsEffect(None)
                except Exception:
                    pass
                if edge_in_path:
                    eitem.setOpacity(0.85)
                else:
                    eitem.setOpacity(fade)
                    pen.setWidthF(base_w * 0.55)
            eitem.setPen(pen)

        for nid, item in self._node_items.items():
            try:
                for child in item.childItems():
                    child.setOpacity(item.opacity())
            except Exception:
                continue

    def _update_node_details(self, node_id: str | None) -> None:
        panel = getattr(self, "_node_detail_panel", None)
        body = getattr(self, "_node_detail_body", None)
        if panel is None or body is None:
            return
        if not node_id or self._latest_model is None:
            panel.setVisible(False)
            body.setPlainText("")
            self._position_canvas_overlays()
            return
        if self._details_dismissed_for_node_id == node_id:
            panel.setVisible(False)
            self._position_canvas_overlays()
            return
        model = self._latest_model
        node_view = next((n for n in model.nodes if n.node_id == node_id), None)
        if node_view is None:
            panel.setVisible(False)
            body.setPlainText("")
            self._position_canvas_overlays()
            return

        advanced_toggle = getattr(self, "_node_detail_advanced_toggle", None)
        advanced = bool(advanced_toggle is not None and advanced_toggle.isChecked())
        title = getattr(self, "_node_detail_title", None)
        if title is not None:
            title.setText(f"{node_view.title}{' (advanced)' if advanced else ''}")
            title.setToolTip(f"id={node_view.node_id}")

        sem = node_view.semantics.binding

        if not advanced:
            try:
                body.setFont(base_font())
            except Exception:
                pass
            body.setStyleSheet("color: palette(window-text); font-size: 11px;")

            level, reasons = self._confidence_for_node(node_view)
            pct = int(round(max(0.0, min(1.0, float(node_view.prob))) * 100.0))
            low, high, _decimals = _approx_display_band(float(node_view.prob))
            low_pct = int(round(low * 100.0))
            high_pct = int(round(high * 100.0))
            band_txt = f"{low_pct}–{high_pct}%" if low_pct != high_pct else f"{low_pct}%"

            assumptions = [
                str(a).strip()
                for a in (sem.provenance.assumptions or [])
                if a and str(a).strip()
            ]
            if assumptions:
                assumptions_txt = ", ".join(assumptions[:4]) + (", …" if len(assumptions) > 4 else "")
            else:
                assumptions_txt = "—"

            evidence_txt = "missing"
            if sem.evidence:
                tags = []
                for ev in sem.evidence[:3]:
                    kind = getattr(getattr(ev, "evidence_type", None), "value", None) or str(getattr(ev, "evidence_type", ""))
                    detail = str(getattr(ev, "detail", "") or "").strip()
                    tags.append(f"{kind}:{detail}" if detail else str(kind))
                evidence_txt = f"{len(sem.evidence)} tag(s): " + ", ".join(tags) + (" …" if len(sem.evidence) > 3 else "")

            cal_txt = getattr(getattr(sem, "calibration", None), "value", None) or str(getattr(sem, "calibration", "unknown"))

            lines: list[str] = []
            lines.append(f"Event type: {node_view.stage} · role: {node_view.role} · t={node_view.time_step}")
            lines.append(f"Estimated fraction: ~{pct}% (band {band_txt})")
            conf_line = f"Confidence: {level}"
            if reasons:
                conf_line += " (" + ", ".join(reasons) + ")"
            lines.append(conf_line)
            lines.append(f"Calibration: {cal_txt}")
            lines.append(f"Evidence: {evidence_txt}")
            lines.append(f"Assumptions: {assumptions_txt}")
            lines.append("")
            lines.append("Notes")
            lines.append("- Flow weights are model-estimated fractions of simulated outcomes (not observed rates).")
            if self._mass_audit_ok is False:
                lines.append("- Mass audit failed: treat weights as relative visualization only.")
            body.setPlainText("\\n".join(lines).strip())
        else:
            try:
                body.setFont(monospace_font())
            except Exception:
                pass
            body.setStyleSheet("color: palette(mid); font-size: 10px;")

            lines = []
            lines.append(f"{node_view.title} | id={node_view.node_id}")
            lines.append(
                f"flow_weight={node_view.prob:.4f} (normalized, visualization only) | t={node_view.time_step} | role={node_view.role}"
            )
            lines.append(f"Invariant: {sem.invariant}")

            lines.append("")
            lines.append("Causal provenance")
            incoming = [e for e in model.edges if e.target == node_id]
            edge_meta = model.edge_meta or {}
            edge_events = model.edge_events or {}
            if incoming:
                for edge in self._sort_incoming_edges(incoming, edge_events):
                    meta = edge_meta.get((edge.source, edge.target), {})
                    lines.extend(self._format_edge_provenance(edge, meta))
            else:
                lines.append("- none (root)")

            lines.append("")
            lines.append("Edge strength & uncertainty")
            if incoming:
                for edge in self._sort_incoming_edges(incoming, edge_events):
                    meta = edge_meta.get((edge.source, edge.target), {})
                    lines.extend(self._format_edge_strength(edge, meta))
            else:
                lines.append("- none")

            lines.append("")
            lines.append("Edit deltas")
            diffs: list[str] = []
            if incoming:
                for edge in self._sort_incoming_edges(incoming, edge_events):
                    event = edge_events.get((edge.source, edge.target))
                    meta = edge_meta.get((edge.source, edge.target), {})
                    diffs.extend(self._format_edge_diff(edge, event, meta))
            if diffs:
                lines.extend(diffs)
            else:
                lines.append("- no event payloads")

            lines.append("")
            lines.append("Constraints & feasibility")
            lines.extend(self._format_constraints(node_id, incoming))

            lines.append("")
            lines.append("Physical / system state deltas")
            lines.extend(self._format_physical_state(sem))

            lines.append("")
            lines.append("Evidence & validation")
            lines.extend(self._format_evidence(sem))

            lines.append("")
            lines.append("Uncertainty & brittleness")
            lines.extend(self._format_uncertainty(sem))

            lines.append("")
            lines.append("Most likely path (heuristic)")
            lines.extend(self._format_path_diagnostics(node_id))

            body.setPlainText("\\n".join(lines).strip())

        panel.setVisible(True)
        self._position_canvas_overlays()

    def _format_edge_event(self, event: object | None) -> str:
        if event is None:
            return "event —"
        try:
            chrom = getattr(event, "chrom", "") or "chr?"
            start = int(getattr(event, "start", 0))
            end = int(getattr(event, "end", 0))
            repl = str(getattr(event, "replacement", "") or "")
            span = max(0, end - start)
            if span == 0 and repl:
                delta = f"ins{len(repl)}"
            elif span > 0 and not repl:
                delta = f"del{span}"
            elif span > 0 and repl:
                delta = f"replace{span}->{len(repl)}"
            else:
                delta = "no-op"
            return f"{chrom}:{start}-{end} {delta}"
        except Exception:
            return "event —"

    def _best_path_to(self, node_id: str) -> list[str]:
        model = self._latest_model
        if model is None or model.dag is None:
            return []
        root_id = model.dag.root_id
        if node_id == root_id:
            return [node_id]
        node_prob = {n.node_id: n.prob for n in model.nodes}
        parents: dict[str, list[str]] = {}
        for edge in model.edges:
            parents.setdefault(edge.target, []).append(edge.source)
        path = [node_id]
        current = node_id
        visited = {node_id}
        while current != root_id and current in parents:
            cand = parents.get(current, [])
            if not cand:
                break
            best = max(cand, key=lambda nid: node_prob.get(nid, 0.0))
            if best in visited:
                break
            path.append(best)
            visited.add(best)
            current = best
        return list(reversed(path))

    def _sort_incoming_edges(
        self,
        incoming: list[_DagEdgeView],
        edge_events: Mapping[tuple[str, str], object],
    ) -> list[_DagEdgeView]:
        def score(edge: _DagEdgeView) -> float:
            event = edge_events.get((edge.source, edge.target))
            delta = self._event_delta_bp(event)
            if delta is None:
                return float(edge.weight)
            return abs(float(delta)) + float(edge.weight)

        incoming_sorted = sorted(incoming, key=score, reverse=True)
        return incoming_sorted[:6]

    def _format_edge_provenance(self, edge: _DagEdgeView, meta: Mapping[str, Any]) -> list[str]:
        rule_id = meta.get("rule_id") or meta.get("ruleId") or edge.rule or "unknown"
        rule_name = meta.get("rule_name") or meta.get("ruleName") or edge.rule or "unknown"
        rule_version = meta.get("rule_version") or meta.get("ruleVersion") or meta.get("version") or "unknown"
        rule_kind = meta.get("rule_kind") or meta.get("ruleKind") or meta.get("kind") or "unknown"
        event_id = meta.get("event_id") or meta.get("eventId") or "unknown"
        run_id = meta.get("run_id") or meta.get("runId") or "unknown"
        step_index = meta.get("step_index") or meta.get("stepIndex") or meta.get("step") or "unknown"
        timestamp = meta.get("timestamp") or meta.get("time") or "unknown"
        trigger = meta.get("trigger") or meta.get("predicate") or meta.get("condition") or "unknown"
        refs = []
        for key in ("artifact_id", "dataset_id", "doc_id", "code_commit"):
            val = meta.get(key) or meta.get(key.replace("_", ""))
            if val:
                refs.append(f"{key}={val}")
        ref_txt = " | ".join(refs) if refs else "refs: unknown"
        return [
            f"- {edge.source} -> {edge.target} | rule_id={rule_id} | name={rule_name} | v={rule_version} | kind={rule_kind}",
            f"  event_id={event_id} | run_id={run_id} | step={step_index} | time={timestamp}",
            f"  trigger={trigger} | {ref_txt}",
        ]

    def _format_edge_strength(self, edge: _DagEdgeView, meta: Mapping[str, Any]) -> list[str]:
        p_model = meta.get("p_model") or meta.get("model") or "unknown"
        uncertainty = None
        for key in ("ci_95", "sigma", "entropy", "logit_var"):
            if key in meta:
                uncertainty = f"{key}={meta.get(key)}"
                break
        if uncertainty is None:
            uncertainty = "uncertainty=unknown"
        calibrated = meta.get("calibrated")
        calibration_set = meta.get("calibration_set") or meta.get("calibrationSet") or "unknown"
        ece = meta.get("ece") or meta.get("mce")
        cal_txt = "calibrated=unknown"
        if isinstance(calibrated, bool):
            cal_txt = f"calibrated={calibrated}"
            if calibration_set:
                cal_txt += f" ({calibration_set})"
            if ece is not None:
                cal_txt += f" ece={ece}"
        sensitivity = meta.get("sensitivity") or meta.get("importance") or "unknown"
        return [
            f"- {edge.source} -> {edge.target} | edge_weight={edge.weight:.4f} | p_model={p_model} | {uncertainty}",
            f"  {cal_txt} | sensitivity={sensitivity}",
        ]

    def _event_delta_bp(self, event: object | None) -> int | None:
        if event is None:
            return None
        try:
            start = int(getattr(event, "start", 0))
            end = int(getattr(event, "end", 0))
            repl = getattr(event, "replacement", "")
            repl_len = len(str(repl or ""))
            return repl_len - (end - start)
        except Exception:
            return None

    def _format_edge_diff(self, edge: _DagEdgeView, event: object | None, meta: Mapping[str, Any]) -> list[str]:
        if event is None:
            return [f"- {edge.source} -> {edge.target} | delta_summary=unknown (event missing)"]
        try:
            chrom = getattr(event, "chrom", "") or "chr?"
            start = int(getattr(event, "start", 0))
            end = int(getattr(event, "end", 0))
            repl = str(getattr(event, "replacement", "") or "")
            span = max(0, end - start)
            delta_bp = len(repl) - span
            if span == 0 and repl:
                delta_summary = f"ins{len(repl)}"
            elif span > 0 and not repl:
                delta_summary = f"del{span}"
            elif span > 0 and repl:
                delta_summary = f"replace{span}->{len(repl)}"
            else:
                delta_summary = "no-op"
            normed = "unknown"
            scale = meta.get("typical_scale_bp") or meta.get("scale_bp") or meta.get("scaleBp")
            if scale:
                try:
                    normed = f"{delta_bp / float(scale):.3g}"
                except Exception:
                    normed = "unknown"
            return [
                f"- {edge.source} -> {edge.target} | delta_summary={delta_summary}",
                f"  diff: field_path=genome.{chrom} | before={span} bp | after={len(repl)} bp | delta={delta_bp} bp | normed_delta={normed}",
            ]
        except Exception:
            return [f"- {edge.source} -> {edge.target} | delta_summary=unknown (parse error)"]

    def _format_constraints(self, node_id: str, incoming: list[_DagEdgeView]) -> list[str]:
        lines: list[str] = []
        if incoming:
            active: list[str] = []
            for edge in incoming:
                if edge.constraints is None:
                    continue
                if edge.constraints.exclusive_with:
                    active.append("exclusive_with=" + ",".join(edge.constraints.exclusive_with))
                if edge.constraints.requires:
                    active.append("requires=" + ",".join(edge.constraints.requires))
                if edge.constraints.forbids:
                    active.append("forbids=" + ",".join(edge.constraints.forbids))
            if active:
                lines.append(f"- status=active | tightest={active[0]}")
                lines.append("- active: " + "; ".join(active[:6]))
            else:
                lines.append("- status=missing | active=none")
        else:
            lines.append("- status=missing | active=none")

        node_constraints = {}
        if self._latest_model is not None and self._latest_model.dag is not None:
            try:
                node_meta = self._latest_model.dag.nodes.get(node_id).metadata  # type: ignore[union-attr]
                if isinstance(node_meta, Mapping) and isinstance(node_meta.get("constraints"), Mapping):
                    node_constraints = node_meta.get("constraints")  # type: ignore[assignment]
            except Exception:
                node_constraints = {}
        if node_constraints:
            cid = node_constraints.get("id") or node_constraints.get("set_id") or "unknown"
            version = node_constraints.get("version") or "unknown"
            lines.append(f"- constraint_set={cid} v{version}")
            active_list = node_constraints.get("active") if isinstance(node_constraints.get("active"), list) else []
            if active_list:
                lines.append("- node_constraints: " + ", ".join(str(x) for x in active_list[:8]))
        return lines

    def _format_physical_state(self, sem: SemanticBinding) -> list[str]:
        return [
            f"- molecular_config={sem.physical_state.molecular_config}",
            f"- strand_polarity={sem.physical_state.strand_polarity}",
            f"- base_pair_energy={format_scalar(sem.physical_state.base_pair_energy)}",
        ]

    def _format_evidence(self, sem: SemanticBinding) -> list[str]:
        lines: list[str] = []
        lines.append(f"- calibration={sem.calibration.value}")
        if not sem.evidence:
            lines.append("- evidence: none")
            lines.append("- missing_evidence=true")
            return lines
        lines.append(f"- evidence_count={len(sem.evidence)}")
        for ev in sem.evidence[:3]:
            lines.append(f"- {ev.evidence_type.value}: {ev.detail}")
        if len(sem.evidence) > 3:
            lines.append(f"- ... {len(sem.evidence) - 3} more")
        return lines

    def _format_uncertainty(self, sem: SemanticBinding) -> list[str]:
        u = sem.uncertainty
        lines = [f"- type={u.type.value} | family={u.distribution_family.value}"]
        if u.params:
            params = ", ".join(f"{k}={format_scalar(v)}" for k, v in list(u.params.items())[:3])
            lines.append(f"- params: {params}")
        if u.correlation_id:
            lines.append(f"- correlation_id={u.correlation_id}")
        if u.provenance:
            lines.append(
                f"- provenance={u.provenance.source}/{u.provenance.method} v{u.provenance.version}"
            )
        if sem.conservation.violated:
            lines.append(f"- mass_audit=violated (eps={sem.conservation.epsilon})")
        return lines

    def _format_path_diagnostics(self, node_id: str) -> list[str]:
        best_path, best_logp, weak_link = self._best_path_with_score(node_id)
        if not best_path:
            return ["- path unavailable"]
        lines = [f"- path_score={best_logp:.3f} | weak_link={weak_link}"]
        if self._mass_audit_ok is False:
            lines.append("- note=edge weights unnormalized; path score is heuristic")
        else:
            lines.append("- note=score uses edge_weight along best-parent chain (heuristic)")
        alternatives = self._alt_paths(node_id, best_logp)
        if alternatives:
            for alt in alternatives:
                lines.append(f"- alt_path={alt['path']} | dscore={alt['dlogp']:.3f}")
        else:
            lines.append("- alt_paths=none")
        return lines

    def _best_path_with_score(self, node_id: str) -> tuple[list[str], float, str]:
        model = self._latest_model
        if model is None or model.dag is None:
            return [], 0.0, "unknown"
        root_id = model.dag.root_id
        if node_id == root_id:
            return [node_id], 0.0, "n/a"
        parents: dict[str, list[tuple[str, float]]] = {}
        for edge in model.edges:
            parents.setdefault(edge.target, []).append((edge.source, edge.weight))
        node_prob = {n.node_id: n.prob for n in model.nodes}
        path = [node_id]
        current = node_id
        logp = 0.0
        weak_edge = ("", "", 1.0)
        visited = {node_id}
        while current != root_id and current in parents:
            cand = parents.get(current, [])
            if not cand:
                break
            best_parent = max(cand, key=lambda c: node_prob.get(c[0], 0.0))
            w = max(best_parent[1], 1e-12)
            logp += math.log(w)
            if w < weak_edge[2]:
                weak_edge = (best_parent[0], current, w)
            parent_id = best_parent[0]
            if parent_id in visited:
                break
            path.append(parent_id)
            visited.add(parent_id)
            current = parent_id
        path = list(reversed(path))
        weak_txt = f"{weak_edge[0]}->{weak_edge[1]} p={weak_edge[2]:.3g}" if weak_edge[0] else "unknown"
        return path, logp, weak_txt

    def _alt_paths(self, node_id: str, best_logp: float) -> list[dict[str, Any]]:
        model = self._latest_model
        if model is None or model.dag is None:
            return []
        parents: dict[str, list[tuple[str, float]]] = {}
        for edge in model.edges:
            parents.setdefault(edge.target, []).append((edge.source, edge.weight))
        if node_id not in parents:
            return []
        candidates = []
        for parent_id, w in parents.get(node_id, []):
            path = self._best_path_to(parent_id) + [node_id]
            if not path or path[0] != model.dag.root_id:
                continue
            logp = 0.0
            for idx in range(1, len(path)):
                src = path[idx - 1]
                dst = path[idx]
                edge = next((e for e in model.edges if e.source == src and e.target == dst), None)
                if edge is None:
                    continue
                logp += math.log(max(edge.weight, 1e-12))
            candidates.append((path, logp))
        candidates.sort(key=lambda x: x[1], reverse=True)
        out = []
        for path, logp in candidates[1:4]:
            out.append({"path": "->".join(path), "dlogp": logp - best_logp})
        return out

    def _register_node_override(self, node_id: str, pos: QPointF) -> None:
        if not self._layout_editing:
            return
        self._node_overrides[str(node_id)] = QPointF(pos)
        try:
            self._scene.setSceneRect(self._scene.itemsBoundingRect().adjusted(-80, -80, 80, 80))
        except Exception:
            pass

    def _on_layout_edit_toggled(self, checked: bool) -> None:
        self._layout_editing = bool(checked)
        self._sync_layout_edit_state()

    def _sync_layout_edit_state(self) -> None:
        # Panning is handled by the view itself (background drag) so we can keep NoDrag.
        try:
            self._view.setDragMode(QGraphicsView.NoDrag)
        except Exception:
            pass
        for item in getattr(self, "_node_items", {}).values():
            if isinstance(item, _DagNodeItem):
                item.set_drag_enabled(self._layout_editing)

    def _on_layout_reset(self) -> None:
        self._node_overrides.clear()
        self._layout_signature = None
        if self._latest_payload is not None:
            self._render(self._latest_payload, self._latest_artifact)

    # Semantic API surface -------------------------------------------------
    def semantic_for_node(self, node_id: str) -> Mapping[str, Any] | None:
        if self._latest_model is None:
            return None
        for node in self._latest_model.nodes:
            if node.node_id == node_id:
                sem = node.semantics.binding
                return {
                    "node_id": node_id,
                    "physical_state": sem.physical_state,
                    "causal_role": sem.causal_role,
                    "uncertainty": sem.uncertainty,
                    "time_locality": sem.time_locality,
                    "invariant": sem.invariant,
                    "evidence": list(sem.evidence),
                    "calibration": sem.calibration,
                    "conservation": sem.conservation,
                    "schema_issues": list(node.semantics.issues),
                }
        return None

    def paths_preserving_reading_frame(self) -> dict[str, Any]:
        try:
            dag = _coerce_dag(self._latest_payload) if self._latest_payload is not None else None
        except Exception:
            dag = None
        if dag is None or nx is None:
            return {"paths": [], "reason": "dag unavailable", "rule_set": "unavailable"}

        transcripts, reason, selected_id = self._load_transcripts_for_frame()
        rule_set = (
            "frame preservation = in-frame indels within coding exons, "
            "no exon boundary crossings, NMD rule (PTC >50 nt upstream of last exon-exon junction), "
            "start codon must be ATG (alt initiation not modeled); "
            "coordinates assumed 0-based half-open"
        )
        if not transcripts:
            return {
                "paths": [],
                "reason": reason or "transcript models missing",
                "rule_set": rule_set,
                "selected_transcript_id": selected_id,
            }

        g = nx.DiGraph()
        for edge in dag.edges:
            g.add_edge(edge.source, edge.target)
        root = dag.root_id
        if root not in g.nodes:
            g.add_node(root)

        reports: list[dict[str, Any]] = []
        for tx in transcripts:
            preserved: list[list[str]] = []
            indeterminate: list[list[str]] = []
            not_preserved: list[list[str]] = []
            path_notes: list[dict[str, Any]] = []
            for leaf in [n for n in g.nodes if g.out_degree(n) == 0]:
                try:
                    for path in nx.all_simple_paths(g, source=root, target=leaf):
                        verdict, reasons = self._path_frame_verdict(dag, path, tx)
                        if verdict == "preserved":
                            preserved.append(path)
                        elif verdict == "indeterminate":
                            indeterminate.append(path)
                            path_notes.append({"path": path, "verdict": verdict, "reasons": reasons})
                        else:
                            not_preserved.append(path)
                            path_notes.append({"path": path, "verdict": verdict, "reasons": reasons})
                except Exception:
                    continue
            reports.append(
                {
                    "transcript_id": tx["transcript_id"],
                    "name": tx["name"],
                    "strand": tx["strand"],
                    "cds_start": tx["cds_start"],
                    "cds_end": tx["cds_end"],
                    "paths": preserved,
                    "indeterminate_paths": indeterminate,
                    "not_preserved_paths": not_preserved,
                    "path_notes": path_notes,
                }
            )

        return {
            "rule_set": rule_set,
            "transcripts": reports,
            "selected_transcript_id": selected_id,
        }

    def states_violating_strand_continuity(self) -> dict[str, Any]:
        try:
            dag = _coerce_dag(self._latest_payload) if self._latest_payload is not None else None
        except Exception:
            dag = None
        if dag is None:
            return {"violations": [], "assumptions": {}, "counterexamples": [], "reason": "dag unavailable"}

        assumptions = {
            "coordinate_system": "0-based half-open",
            "continuity_definition": "phosphodiester backbone continuity; gaps/nicks/overhangs violate unless explicitly repaired",
            "heteroduplex": "allowed if backbone is continuous",
            "mismatch_pairs": "do not break continuity unless metadata says otherwise",
        }
        violations: list[str] = []
        counterexamples: list[dict[str, Any]] = []
        unknown = False

        for nid, node in dag.nodes.items():
            meta = node.metadata if isinstance(node.metadata, Mapping) else {}
            topology = meta.get("strand_topology") if isinstance(meta.get("strand_topology"), Mapping) else {}
            violates = False
            if isinstance(meta, Mapping) and meta.get("strand_continuity") is False:
                violates = True
            elif isinstance(topology, Mapping) and topology:
                if topology.get("gaps") or topology.get("nicks") or topology.get("overhangs"):
                    violates = True
            else:
                unknown = True
            if violates:
                violations.append(nid)
                events = list(getattr(node, "diffs", []) or [])
                if events:
                    smallest = min(events, key=lambda e: abs((e.end - e.start) - len(e.replacement or "")))
                    counterexamples.append(
                        {
                            "node_id": nid,
                            "event": {
                                "chrom": smallest.chrom,
                                "start": smallest.start,
                                "end": smallest.end,
                                "replacement": smallest.replacement,
                            },
                        }
                    )

        return {
            "violations": violations,
            "assumptions": assumptions,
            "counterexamples": counterexamples,
            "unknown_topology": unknown,
        }

    def _load_transcripts_for_frame(self) -> tuple[list[dict[str, Any]], str | None, str | None]:
        try:
            annotations = self._session.state.annotations
        except Exception:
            annotations = None
        if not isinstance(annotations, Mapping):
            annotations = self._session.state.annotation if isinstance(getattr(self._session.state, "annotation", None), Mapping) else {}
        tx_raw = annotations.get("transcripts") if isinstance(annotations, Mapping) else None
        transcripts: list[dict[str, Any]] = []
        selected_id: str | None = None

        def _parse_exons_1based(exons_raw: Any) -> list[tuple[int, int]]:
            out: list[tuple[int, int]] = []
            if isinstance(exons_raw, list):
                for item in exons_raw:
                    if isinstance(item, (list, tuple)) and len(item) == 2:
                        try:
                            a = int(item[0])
                            b = int(item[1])
                        except Exception:
                            continue
                        s = min(a, b)
                        e = max(a, b)
                        if s > 0 and e >= s:
                            out.append((s, e))
                    elif isinstance(item, Mapping):
                        start = item.get("start")
                        end = item.get("end")
                        if start is None or end is None:
                            continue
                        try:
                            s = min(int(start), int(end))
                            e = max(int(start), int(end))
                        except Exception:
                            continue
                        if s > 0 and e >= s:
                            out.append((s, e))
            return out

        if isinstance(tx_raw, list):
            for idx, tx in enumerate(tx_raw):
                if not isinstance(tx, Mapping):
                    continue
                tid = str(tx.get("id") or tx.get("transcript_id") or tx.get("name") or f"TX{idx+1}")
                name = str(tx.get("name") or tid)
                strand = "-" if str(tx.get("strand") or "+").strip() in {"-", "minus"} else "+"
                cds_start = tx.get("cds_start") if tx.get("cds_start") is not None else tx.get("cdsStart")
                cds_end = tx.get("cds_end") if tx.get("cds_end") is not None else tx.get("cdsEnd")
                chrom = str(tx.get("chrom") or tx.get("chr") or "")
                try:
                    cds_start_i = int(cds_start)
                    cds_end_i = int(cds_end)
                except Exception:
                    continue
                exons = _parse_exons_1based(tx.get("exons"))
                if not exons:
                    continue
                transcripts.append(
                    {
                        "transcript_id": tid,
                        "name": name,
                        "strand": strand,
                        "cds_start": cds_start_i,
                        "cds_end": cds_end_i,
                        "exons": exons,
                        "chrom": chrom,
                    }
                )

        if not transcripts:
            spec = experiment_spec_to_dict(self._session.state.experiment_spec)
            coding = spec.get("coding") if isinstance(spec.get("coding"), Mapping) else {}
            if isinstance(coding, Mapping) and coding:
                cds_start = coding.get("cds_start")
                cds_end = coding.get("cds_end")
                try:
                    cds_start_i = int(cds_start)
                    cds_end_i = int(cds_end)
                except Exception:
                    cds_start_i = None
                    cds_end_i = None
                exons = _parse_exons_1based(coding.get("exons") or coding.get("exon_intervals"))
                strand = "-" if str(coding.get("strand") or "+").strip() in {"-", "minus"} else "+"
                tid = str(coding.get("id") or coding.get("transcript_id") or coding.get("name") or "TX1")
                name = str(coding.get("name") or tid)
                chrom = str(coding.get("chrom") or coding.get("chr") or "")
                if cds_start_i and cds_end_i and exons:
                    transcripts.append(
                        {
                            "transcript_id": tid,
                            "name": name,
                            "strand": strand,
                            "cds_start": cds_start_i,
                            "cds_end": cds_end_i,
                            "exons": exons,
                            "chrom": chrom,
                        }
                    )

        # Optional isoform selection.
        try:
            cfg = self._session.state.config if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        try:
            spec = experiment_spec_to_dict(self._session.state.experiment_spec)
        except Exception:
            spec = {}
        selected_id = str(
            cfg.get("frame_transcript_id")
            or cfg.get("transcript_id")
            or (spec.get("coding", {}) or {}).get("transcript_id")
            or ""
        ).strip()
        if selected_id:
            filtered = [tx for tx in transcripts if tx.get("transcript_id") == selected_id or tx.get("name") == selected_id]
            if not filtered:
                return [], f"transcript id '{selected_id}' not found", selected_id
            transcripts = filtered

        if not transcripts:
            return [], "transcript models not available", selected_id or None
        return transcripts, None, selected_id or None

    def _path_frame_verdict(self, dag: EditDAG, path: Sequence[str], tx: Mapping[str, Any]) -> tuple[str, list[str]]:
        exons = tx.get("exons") if isinstance(tx.get("exons"), list) else []
        cds_start = int(tx.get("cds_start") or 0)
        cds_end = int(tx.get("cds_end") or 0)
        if not exons or cds_start <= 0 or cds_end <= 0:
            return "indeterminate", ["transcript missing exons or cds"]

        coding_intervals: list[tuple[int, int]] = []
        for start, end in exons:
            s = max(start, cds_start)
            e = min(end, cds_end)
            if s <= e:
                coding_intervals.append((s, e))

        if not coding_intervals:
            return "indeterminate", ["no coding intervals"]

        def _overlaps_coding(start0: int, end0: int) -> bool:
            for s1, e1 in coding_intervals:
                # exons are 1-based inclusive; convert to 0-based half-open
                s0 = s1 - 1
                e0 = e1
                if start0 < e0 and end0 > s0:
                    return True
            return False

        def _crosses_exon_boundary(start0: int, end0: int) -> bool:
            for s1, e1 in coding_intervals:
                s0 = s1 - 1
                e0 = e1
                if start0 < s0 < end0 or start0 < e0 < end0:
                    return True
            return False

        verdict = "preserved"
        reasons: list[str] = []
        for node_id in path:
            node = dag.nodes.get(node_id)
            if node is None:
                continue
            meta = node.metadata if isinstance(node.metadata, Mapping) else {}
            if isinstance(meta, Mapping) and meta.get("frameshift") is True:
                return "not_preserved", ["frameshift flag set in metadata"]
            for event in getattr(node, "diffs", []) or []:
                start0 = int(event.start)
                end0 = int(event.end)
                delta = len(event.replacement or "") - (end0 - start0)
                if not _overlaps_coding(start0, end0):
                    continue
                if _crosses_exon_boundary(start0, end0):
                    verdict = "indeterminate"
                    reasons.append("edit crosses exon boundary")
                    continue
                if delta % 3 != 0:
                    return "not_preserved", ["frameshift indel within coding region"]

            # Sequence-level checks (PTC/NMD)
            seq_result = self._evaluate_transcript_sequence(node, tx)
            if seq_result[0] == "not_preserved":
                return seq_result
            if seq_result[0] == "indeterminate":
                verdict = "indeterminate"
                reasons.extend(seq_result[1])

        return verdict, reasons

    def _evaluate_transcript_sequence(self, node: Any, tx: Mapping[str, Any]) -> tuple[str, list[str]]:
        try:
            chrom = str(tx.get("chrom") or "")
            if not chrom:
                # fallback: pick first chrom in genome view
                chroms = list(getattr(node.genome_view, "base").sequences.keys())  # type: ignore[attr-defined]
                chrom = chroms[0] if chroms else ""
            if not chrom:
                return "indeterminate", ["chromosome missing for transcript"]
            seq = node.genome_view.materialize_chrom(chrom)  # type: ignore[attr-defined]
        except Exception:
            return "indeterminate", ["genome view unavailable"]

        exons = tx.get("exons") if isinstance(tx.get("exons"), list) else []
        cds_start = int(tx.get("cds_start") or 0)
        cds_end = int(tx.get("cds_end") or 0)
        if not exons or cds_start <= 0 or cds_end <= 0:
            return "indeterminate", ["transcript missing CDS"]

        def _slice(start1: int, end1: int) -> str:
            s0 = max(0, start1 - 1)
            e0 = max(s0, end1)
            return seq[s0:e0]

        coding_chunks: list[str] = []
        exon_lengths: list[int] = []
        for start, end in exons:
            s = max(start, cds_start)
            e = min(end, cds_end)
            if s <= e:
                chunk = _slice(s, e)
                coding_chunks.append(chunk)
                exon_lengths.append(len(chunk))
        if not coding_chunks:
            return "indeterminate", ["coding sequence empty"]

        strand = str(tx.get("strand") or "+")
        coding_seq = "".join(coding_chunks)
        if strand in {"-", "minus"}:
            comp = {"A": "T", "T": "A", "C": "G", "G": "C", "N": "N"}
            coding_seq = "".join(comp.get(b, "N") for b in reversed(coding_seq.upper()))
        else:
            coding_seq = coding_seq.upper()

        if len(coding_seq) % 3 != 0:
            return "not_preserved", ["coding sequence length not divisible by 3"]

        if coding_seq[:3] != "ATG":
            return "indeterminate", ["start codon not ATG (alt initiation not modeled)"]

        stop_codons = {"TAA", "TAG", "TGA"}
        first_stop = None
        for idx in range(0, len(coding_seq) - 2, 3):
            codon = coding_seq[idx : idx + 3]
            if codon in stop_codons:
                first_stop = idx
                break

        if first_stop is None:
            return "indeterminate", ["no stop codon found"]

        if first_stop < len(coding_seq) - 3:
            # Premature termination codon
            last_junction = None
            if len(exon_lengths) > 1:
                last_junction = sum(exon_lengths[:-1])
            if last_junction is not None:
                dist = last_junction - first_stop
                if dist > 50:
                    return "not_preserved", [f"NMD triggered (PTC {dist} nt upstream of last junction)"]
            return "not_preserved", ["premature stop codon before CDS end"]

        return "preserved", []

    def export_causal_proof(self) -> dict[str, Any]:
        if self._latest_model is None:
            return {}
        def _plain(value: Any) -> Any:
            if value is None:
                return None
            if hasattr(value, "model_dump"):
                try:
                    return value.model_dump()
                except Exception:
                    pass
            if is_dataclass(value):
                try:
                    return asdict(value)
                except Exception:
                    pass
            if isinstance(value, Enum):
                return value.value
            if isinstance(value, Mapping):
                return {str(k): _plain(v) for k, v in value.items()}
            if isinstance(value, (list, tuple)):
                return [_plain(v) for v in value]
            return value

        nodes = []
        for n in self._latest_model.nodes:
            sem = n.semantics.binding
            nodes.append(
                {
                    "id": n.node_id,
                    "prob": n.prob,
                    "time_step": n.time_step,
                    "semantics": {
                        "physical_state": _plain(sem.physical_state),
                        "causal_role": _plain(sem.causal_role),
                        "uncertainty": _plain(sem.uncertainty),
                        "time_locality": _plain(sem.time_locality),
                        "invariant": sem.invariant,
                        "evidence": _plain(list(sem.evidence)),
                        "calibration": _plain(sem.calibration),
                        "conservation": _plain(sem.conservation),
                        "provenance": _plain(sem.provenance),
                    },
                    "schema_issues": list(n.semantics.issues),
                }
            )
        edges = []
        constraints: list[dict[str, Any]] = []
        for e in self._latest_model.edges:
            edge_payload = {
                "source": e.source,
                "target": e.target,
                "rule": e.rule,
                "branch_probability": e.weight,
            }
            if e.constraints is not None:
                edge_payload["constraints"] = {
                    "exclusive_with": e.constraints.exclusive_with,
                    "requires": e.constraints.requires,
                    "forbids": e.constraints.forbids,
                    "provenance": _plain(e.constraints.provenance),
                }
                constraints.append(
                    {
                        "edge_id": f"{e.source}->{e.target}",
                        "type": "exclusive_with",
                        "targets": e.constraints.exclusive_with,
                    }
                )
                if e.constraints.requires:
                    constraints.append(
                        {
                            "edge_id": f"{e.source}->{e.target}",
                            "type": "requires",
                            "targets": e.constraints.requires,
                        }
                    )
                if e.constraints.forbids:
                    constraints.append(
                        {
                            "edge_id": f"{e.source}->{e.target}",
                            "type": "forbids",
                            "targets": e.constraints.forbids,
                        }
                    )
            if e.issues:
                edge_payload["constraint_issues"] = list(e.issues)
            edges.append(edge_payload)

        suppressed = [
            {
                "node_id": nid,
                "prob": prob,
                "parents": list(parents),
                "suppression_reason": "flow_weight below threshold",
                "reachable": True,
            }
            for nid, prob, parents in self._latest_model.suppressed
        ]

        input_seal = {"git_sha": current_git_sha() or "unknown"}
        dag = self._latest_model.dag
        if dag is not None:
            input_seal["dag_hash"] = self._hash_dag(dag)

        proof = build_causal_proof(
            nodes=nodes,
            edges=edges,
            constraints=constraints,
            model_versions=self._model_versions(),
            input_seal=input_seal,
        )
        proof["suppressed"] = suppressed
        proof["dominant_leaf"] = self._latest_model.dominant_leaf_id
        return proof

    def _dominant_path_ids(self, model: _DagSceneModel) -> list[str]:
        root_id = ""
        try:
            if model.dag is not None:
                root_id = str(model.dag.root_id or "")
        except Exception:
            root_id = ""
        if not root_id:
            root_node = next((n for n in (model.nodes or []) if getattr(n, "role", "") == "root"), None)
            root_id = str(getattr(root_node, "node_id", "") or "") if root_node is not None else ""
        if not root_id:
            return []

        next_by_src: dict[str, str] = {}
        for src, dst in sorted(getattr(self, "_main_path_edges", set())):
            src = str(src)
            dst = str(dst)
            if src and dst and src not in next_by_src:
                next_by_src[src] = dst

        path: list[str] = [root_id]
        seen = {root_id}
        cur = root_id
        for _ in range(len(model.nodes) + 2):
            nxt = next_by_src.get(cur)
            if not nxt or nxt in seen:
                break
            path.append(nxt)
            seen.add(nxt)
            cur = nxt
        return path

    def export_outcome_summary_receipt(self) -> dict[str, Any]:
        model = self._latest_model
        if model is None:
            return {}

        show_exact = False
        try:
            show_exact = bool(self._exact_values_toggle is not None and self._exact_values_toggle.isChecked())
        except Exception:
            show_exact = False

        collapse_threshold_pct = None
        try:
            collapse_threshold_pct = float(self._collapse_spin.value())
        except Exception:
            collapse_threshold_pct = None

        run_kind = None
        run_id = None
        run_artifact_hash = None
        input_digest = None
        intent_sha256 = None
        exp_sha256 = None
        try:
            state = self._session.state
            run_kind = state.run_kind.name.lower() if isinstance(state.run_kind, RunKind) else str(state.run_kind)
            run_id = int(state.run_id)
            run_artifact_hash = str(getattr(state, "run_artifact_hash", "") or "").strip() or None
            meta = state.config.get("metadata") if isinstance(state.config, Mapping) else {}
            raw_input = meta.get("input_digest")
            if isinstance(raw_input, str) and raw_input.strip():
                input_digest = raw_input.strip()
                if not input_digest.startswith("sha256:"):
                    input_digest = f"sha256:{input_digest}"
            try:
                from helix.studio.experiment_intent_spec import experiment_intent_spec_sha256
                from helix.studio.experiment_spec import experiment_spec_sha256

                intent_sha256 = f"sha256:{experiment_intent_spec_sha256(state.experiment_intent_spec)}"
                exp_sha256 = f"sha256:{experiment_spec_sha256(state.experiment_spec)}"
            except Exception:
                intent_sha256 = None
                exp_sha256 = None
        except Exception:
            run_kind = None
            run_id = None
            run_artifact_hash = None
            input_digest = None
            intent_sha256 = None
            exp_sha256 = None

        dag_hash = None
        try:
            if model.dag is not None:
                dag_hash = self._hash_dag(model.dag)
        except Exception:
            dag_hash = None

        artifact_graph_hash = None
        try:
            graph_meta = (
                self._latest_artifact.get("graph") if isinstance(getattr(self, "_latest_artifact", None), Mapping) else {}
            )
            if isinstance(graph_meta, Mapping):
                artifact_graph_hash = graph_meta.get("graph_hash")
        except Exception:
            artifact_graph_hash = None

        weight_label = self._prob_label or "flow"
        dominant_path_ids = self._dominant_path_ids(model)
        node_by_id = {n.node_id: n for n in (model.nodes or []) if getattr(n, "node_id", None)}

        def _path_entry(node_id: str) -> dict[str, Any]:
            node = node_by_id.get(str(node_id))
            if node is None:
                return {"id": str(node_id)}
            return {
                "id": node.node_id,
                "stage": node.stage,
                "title": node.title,
                "role": node.role,
                "time_step": node.time_step,
                "flow_weight": float(node.prob),
                "display": _format_weight_display(label=weight_label, value=float(node.prob), exact=show_exact),
            }

        terminals = [n for n in (model.nodes or []) if getattr(n, "role", "") == "terminal"]
        terminals.sort(key=lambda n: float(getattr(n, "prob", 0.0)), reverse=True)
        top_outcomes = [
            {
                "id": n.node_id,
                "title": n.title,
                "flow_weight": float(n.prob),
                "display": _format_weight_display(label=weight_label, value=float(n.prob), exact=show_exact),
            }
            for n in terminals[:3]
        ]

        limitations_notes = [
            DOMINANT_CALLOUT_TEXT,
            "Flow weights are model outputs for this simulated run; interpret as relative mass, not real-world frequency.",
        ]
        if self._mass_audit_ok is False:
            limitations_notes.append("Mass audit failed: weights are not normalized as probabilities.")

        view_layout = None
        try:
            view_layout = str(self._layout_combo.currentData() or "timeline")
        except Exception:
            view_layout = None

        level, reasons = self._confidence_for_model(model)
        calibration_badge = None
        try:
            node = next((n for n in (model.nodes or []) if n.node_id == model.dominant_leaf_id), None)
            if node is None:
                terminals = [n for n in (model.nodes or []) if getattr(n, "role", "") == "terminal"]
                if terminals:
                    node = max(terminals, key=lambda n: float(getattr(n, "prob", 0.0)))
            if node is not None:
                calibration_badge = node.semantics.binding.calibration.value
        except Exception:
            calibration_badge = None

        receipt: dict[str, Any] = {
            "schema": "helix_studio_outcome_summary_receipt_v2",
            "created_at_utc": clock.utc_now_iso(),
            "model_versions": self._model_versions(),
            "input": {
                "input_digest": input_digest,
                "experiment_intent_spec_sha256": intent_sha256,
                "experiment_spec_sha256": exp_sha256,
            },
            "run": {
                "run_kind": run_kind,
                "run_id": run_id,
                "run_artifact_hash": f"sha256:{run_artifact_hash}" if run_artifact_hash else None,
            },
            "view": {
                "layout": view_layout,
                "collapse_threshold_pct": collapse_threshold_pct,
                "exact_values": show_exact,
                "highlight_dominant_path": bool(self._highlight_main.isChecked()),
                "structural_mode": bool(self._structural_mode),
            },
            "confidence": {
                "level": level,
                "reasons": reasons,
            },
            "calibration": {
                "badge": calibration_badge,
            },
            "limitations": {
                "url": limitations_doc_url() or None,
                "notes": limitations_notes,
            },
            "dag": {
                "dag_hash": dag_hash,
                "artifact_graph_hash": artifact_graph_hash,
                "dominant_leaf_id": model.dominant_leaf_id,
                "dominant_path": [_path_entry(nid) for nid in dominant_path_ids],
                "top_outcomes": top_outcomes,
            },
            "summary_sentence": self._summary_sentence_plain
            if self._summary_sentence_plain is not None
            else (self._summary_label.text() if self._summary_label is not None else None),
        }
        payload_for_hash = dict(receipt)
        payload_for_hash.pop("receipt_hash", None)
        canonical = json.dumps(payload_for_hash, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
        receipt["receipt_hash"] = f"sha256:{hashlib.sha256(canonical.encode('utf-8')).hexdigest()}"
        return receipt

    def _hash_dag(self, dag: EditDAG) -> str:
        payload = {
            "root_id": dag.root_id,
            "nodes": [
                {
                    "id": node_id,
                    "log_prob": float(node.log_prob),
                    "parents": list(node.parents),
                }
                for node_id, node in sorted(dag.nodes.items(), key=lambda kv: kv[0])
            ],
            "edges": [
                {
                    "source": edge.source,
                    "target": edge.target,
                    "rule": edge.rule_name,
                }
                for edge in sorted(dag.edges, key=lambda e: (e.source, e.target, e.rule_name or ""))
            ],
        }
        blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n"
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()

    def _model_versions(self) -> dict[str, Any]:
        versions: dict[str, Any] = {}
        try:
            cfg = self._session.state.config if isinstance(self._session.state.config, Mapping) else {}
            models = cfg.get("model_versions") if isinstance(cfg.get("model_versions"), Mapping) else {}
            versions.update({str(k): v for k, v in models.items()})
        except Exception:
            pass
        versions["git_sha"] = current_git_sha() or "unknown"
        return versions
