from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Sequence

from helix.studio.calibration import CALIBRATION_PROFILE_SCHEMA_ID, PRIME_CATEGORIES, _safe_float
from helix.studio.experiment_spec import experiment_spec_to_dict

SUGGESTED_PRIORS_SCHEMA_ID = "helix_suggested_priors_v1"
SUGGESTED_PRIORS_CAP = 20
SUGGESTED_PRIORS_HISTORY_CAP = 20
SUGGESTED_PRIORS_JSON_MAX_BYTES = 64 * 1024


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def suggested_priors_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(payload))


def suggested_priors_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(suggested_priors_json_bytes(payload)).hexdigest()


def _round(value: float, digits: int = 6) -> float:
    return round(float(value), digits)


def _normalize_text(value: Any) -> str:
    return str(value or "").strip()


def _infer_model_compatibility(modality: str, report_payload: Mapping[str, Any] | None) -> list[dict[str, str]]:
    if isinstance(report_payload, Mapping):
        model_id = str(report_payload.get("modelId") or "")
        model_version = str(report_payload.get("modelVersion") or "")
        if model_id:
            return [{"modelId": model_id, "modelVersion": model_version}]
    if modality == "prime":
        return [{"modelId": "prime_model", "modelVersion": "v1"}]
    return [{"modelId": "cut_model", "modelVersion": "v1"}]


def build_suggested_priors(
    calibration_profile: Mapping[str, Any],
    *,
    results_records: Sequence[Mapping[str, Any]] | None = None,
    outcome_report_payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if str(calibration_profile.get("schema") or "") not in {CALIBRATION_PROFILE_SCHEMA_ID, ""}:
        raise ValueError("Unsupported calibration profile schema")

    scope = calibration_profile.get("scope") if isinstance(calibration_profile.get("scope"), Mapping) else {}
    modality = str(scope.get("modality") or "cut").strip().lower()
    if modality not in {"cut", "prime"}:
        modality = "cut"

    results_ids = calibration_profile.get("sourceResults") if isinstance(calibration_profile.get("sourceResults"), list) else []
    results_ids = [str(r) for r in results_ids if str(r)]

    derived_from = {
        "calibrationProfileId": str(calibration_profile.get("profileId") or ""),
        "resultsRecordIds": results_ids,
        "scope": dict(scope),
    }

    priors: dict[str, Any] = {}
    rationale: list[str] = []

    if modality == "cut":
        alpha = _safe_float(calibration_profile.get("parameters", {}).get("desiredPosteriorAlpha"), 0.0)
        beta = _safe_float(calibration_profile.get("parameters", {}).get("desiredPosteriorBeta"), 0.0)
        total = alpha + beta
        if total <= 0:
            total = 1.0
        p_cal = alpha / total
        strength = min(200, max(20, int(round(total))))
        desired_k = int(round(p_cal * strength))
        alpha0 = desired_k + 1
        beta0 = (strength - desired_k) + 1
        priors["cut"] = {
            "defaultBetaPriorStrength": int(strength),
            "desiredAlpha0": int(alpha0),
            "desiredBeta0": int(beta0),
        }
        rationale.append(f"Posterior mean p={_round(p_cal, 6)} from alpha={int(alpha)} beta={int(beta)}.")
        rationale.append(f"Suggested strength S={int(strength)}.")
    else:
        alpha_map = calibration_profile.get("parameters", {}).get("dirichletAlpha")
        if not isinstance(alpha_map, Mapping):
            alpha_map = {cat: 1.0 for cat in PRIME_CATEGORIES}
        total = sum(_safe_float(alpha_map.get(cat), 0.0) for cat in PRIME_CATEGORIES)
        if total <= 0:
            total = 1.0
        strength = min(200, max(20, int(round(total))))
        scaled: dict[str, float] = {}
        for cat in PRIME_CATEGORIES:
            frac = _safe_float(alpha_map.get(cat), 0.0) / total
            scaled[cat] = _round(frac * strength, 6)
        priors["prime"] = {
            "defaultDirichletStrength": int(strength),
            "alphaByCategory": scaled,
        }
        rationale.append(f"Dirichlet total strength {int(total)} scaled to S={int(strength)}.")

    results_count = len(results_ids)
    if results_count:
        rationale.insert(0, f"Derived from {results_count} result record(s).")
    profile_id = str(calibration_profile.get("profileId") or "")
    if profile_id:
        rationale.insert(0, f"Derived from calibration profile {profile_id}.")

    compatibility = _infer_model_compatibility(modality, outcome_report_payload)

    payload = {
        "schema": SUGGESTED_PRIORS_SCHEMA_ID,
        "suggestedId": "",
        "derivedFrom": derived_from,
        "priors": priors,
        "rationale": rationale,
        "compatibility": compatibility,
    }

    suggested_id = hashlib.sha256(_canonical_json_bytes(dict(payload))).hexdigest()
    payload["suggestedId"] = suggested_id
    return payload


def attach_suggested_priors(
    session: Any,
    suggested: Mapping[str, Any],
    *,
    cap: int = SUGGESTED_PRIORS_CAP,
    history_cap: int = SUGGESTED_PRIORS_HISTORY_CAP,
) -> list[dict[str, Any]]:
    current = list(getattr(session.state, "suggested_priors", []) or []) if session is not None else []
    suggested_id = str(suggested.get("suggestedId") or "")
    current = [p for p in current if str(p.get("suggestedId") or "") != suggested_id]
    current.append(dict(suggested))
    if cap > 0 and len(current) > cap:
        current = current[-cap:]

    history = list(getattr(session.state, "suggested_priors_history", []) or []) if session is not None else []
    seq = int(getattr(session.state, "suggested_priors_seq", 0) or 0) + 1 if session is not None else 1
    scope = suggested.get("derivedFrom", {}).get("scope") if isinstance(suggested.get("derivedFrom"), Mapping) else {}
    scope = dict(scope) if isinstance(scope, Mapping) else {}
    modality = _normalize_text(scope.get("modality")) or "any"
    cell_line = _normalize_text(scope.get("cellLine")) or "any"
    delivery = _normalize_text(scope.get("delivery")) or "any"
    nuclease = _normalize_text(scope.get("nuclease")) or "any"
    scope_summary = f"{modality} • {cell_line} • {delivery} • {nuclease}"
    compat = suggested.get("compatibility") if isinstance(suggested.get("compatibility"), list) else []
    model_id = ""
    if compat and isinstance(compat[0], Mapping):
        model_id = _normalize_text(compat[0].get("modelId"))
    raw_bytes = suggested_priors_json_bytes(suggested)
    stored_externally = len(raw_bytes) > SUGGESTED_PRIORS_JSON_MAX_BYTES
    if stored_externally:
        preview_payload = {
            "schema": SUGGESTED_PRIORS_SCHEMA_ID,
            "suggestedId": suggested_id,
            "note": "stored externally",
            "preview": True,
        }
        suggested_json = _canonical_json_bytes(preview_payload).decode("utf-8")
    else:
        suggested_json = raw_bytes.decode("utf-8")

    history_entry = {
        "suggestedId": suggested_id,
        "scopeSummary": scope_summary,
        "sequence": seq,
        "modelId": model_id,
        "suggestedJson": suggested_json,
        "storedExternally": stored_externally,
        "suggestedJsonBytes": int(len(raw_bytes)),
    }
    history = [h for h in history if str(h.get("suggestedId") or "") != suggested_id]
    history.append(history_entry)
    if history_cap > 0 and len(history) > history_cap:
        history = history[-history_cap:]

    if session is not None:
        session.update(
            suggested_priors=current,
            suggested_priors_history=history,
            suggested_priors_seq=seq,
        )
    return current


def apply_priors_override(
    report_payload: Mapping[str, Any],
    overrides: Mapping[str, Any],
) -> dict[str, Any]:
    payload = json.loads(json.dumps(report_payload))
    if not overrides:
        return payload

    # Cut prior adjustment: scale desired allele to prior mean.
    cut_alpha = overrides.get("cutPriorAlpha0")
    cut_beta = overrides.get("cutPriorBeta0")
    if cut_alpha is not None and cut_beta is not None:
        alpha = _safe_float(cut_alpha, 0.0)
        beta = _safe_float(cut_beta, 0.0)
        if alpha + beta > 0:
            p_prior = alpha / (alpha + beta)
            from helix.studio.outcomes.clone_yield import build_clone_plan
            from helix.studio.outcomes.hotspots import allele_key_from_entry

            allele_spectrum = payload.get("alleleSpectrum") if isinstance(payload.get("alleleSpectrum"), list) else []
            entries = [e for e in allele_spectrum if isinstance(e, Mapping)]
            clone_plan = build_clone_plan(payload)
            desired_key = str(clone_plan.get("desiredAlleleKey") or "")
            p_pred = _safe_float(clone_plan.get("desiredFrequency"), 0.0)
            desired_idx = None
            for idx, entry in enumerate(entries):
                try:
                    if allele_key_from_entry(entry) == desired_key:
                        desired_idx = idx
                        break
                except Exception:
                    continue
            if desired_idx is not None:
                scale = 0.0
                if p_pred < 1.0:
                    scale = (1.0 - p_prior) / max(1e-12, 1.0 - p_pred)
                new_entries: list[dict[str, Any]] = []
                for idx, entry in enumerate(entries):
                    freq = _safe_float(entry.get("frequency"), 0.0)
                    new_entry = dict(entry)
                    if idx == desired_idx:
                        new_entry["frequency"] = _round(p_prior, 8)
                    else:
                        new_entry["frequency"] = _round(freq * scale, 8)
                    new_entries.append(new_entry)
                remainder = 1.0 - sum(_safe_float(e.get("frequency"), 0.0) for e in new_entries)
                if new_entries and remainder != 0.0:
                    adjust_idx = len(new_entries) - 1
                    if adjust_idx == desired_idx and len(new_entries) > 1:
                        adjust_idx -= 1
                    new_entries[adjust_idx]["frequency"] = _round(
                        _safe_float(new_entries[adjust_idx].get("frequency"), 0.0) + remainder, 8
                    )
                payload["alleleSpectrum"] = new_entries

    # Prime prior adjustment: use Dirichlet alpha map to set category probabilities.
    prime_alpha = overrides.get("primeDirichletAlpha") or overrides.get("alphaByCategory")
    if isinstance(prime_alpha, Mapping):
        total = sum(_safe_float(prime_alpha.get(cat), 0.0) for cat in PRIME_CATEGORIES)
        if total > 0:
            target_probs = {cat: _safe_float(prime_alpha.get(cat), 0.0) / total for cat in PRIME_CATEGORIES}
            prime_outcomes = payload.get("primeOutcomes") if isinstance(payload.get("primeOutcomes"), list) else []
            if isinstance(prime_outcomes, list) and prime_outcomes:
                new_outcomes: list[dict[str, Any]] = []
                for entry in prime_outcomes:
                    if not isinstance(entry, Mapping):
                        continue
                    cat = str(entry.get("category") or "")
                    prob = target_probs.get(cat, _safe_float(entry.get("probability"), 0.0))
                    new_entry = dict(entry)
                    new_entry["probability"] = _round(prob, 6)
                    new_outcomes.append(new_entry)
                remainder = 1.0 - sum(_safe_float(e.get("probability"), 0.0) for e in new_outcomes)
                if new_outcomes and remainder != 0.0:
                    new_outcomes[-1]["probability"] = _round(
                        _safe_float(new_outcomes[-1].get("probability"), 0.0) + remainder, 6
                    )
                payload["primeOutcomes"] = new_outcomes

            allele_spectrum = payload.get("alleleSpectrum") if isinstance(payload.get("alleleSpectrum"), list) else []
            if isinstance(allele_spectrum, list) and allele_spectrum:
                def _category_for_entry(entry: Mapping[str, Any]) -> str:
                    delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
                    label = str(delta.get("label") or "")
                    if label in PRIME_CATEGORIES:
                        return label
                    kind = str(delta.get("type") or "")
                    mapping = {
                        "prime_desired": "desired_edit",
                        "prime_partial": "partial_edit",
                        "prime_truncation": "rt_template_truncation",
                        "prime_nick": "nick_indels",
                        "prime_failure": "pegRNA_failure",
                    }
                    return mapping.get(kind, "")

                totals = {cat: 0.0 for cat in PRIME_CATEGORIES}
                entries = []
                for entry in allele_spectrum:
                    if not isinstance(entry, Mapping):
                        continue
                    cat = _category_for_entry(entry)
                    freq = _safe_float(entry.get("frequency"), 0.0)
                    if cat:
                        totals[cat] += freq
                    entries.append((dict(entry), cat, freq))

                new_entries: list[dict[str, Any]] = []
                for entry, cat, freq in entries:
                    if not cat:
                        new_entries.append(entry)
                        continue
                    target = target_probs.get(cat, 0.0)
                    scale = 0.0 if totals[cat] <= 0 else target / totals[cat]
                    entry["frequency"] = _round(freq * scale, 8)
                    new_entries.append(entry)

                remainder = 1.0 - sum(_safe_float(e.get("frequency"), 0.0) for e in new_entries)
                if new_entries and remainder != 0.0:
                    new_entries[-1]["frequency"] = _round(
                        _safe_float(new_entries[-1].get("frequency"), 0.0) + remainder, 8
                    )
                payload["alleleSpectrum"] = new_entries

    payload["priorsOverrideApplied"] = True
    return payload


def check_suggested_priors_compatibility(
    suggested: Mapping[str, Any] | None,
    *,
    experiment_spec: Mapping[str, Any] | None,
    outcome_report_payload: Mapping[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(suggested, Mapping):
        return {"status": "unknown", "reasons": ["missing suggested priors"]}

    reasons_incompatible: list[str] = []
    reasons_missing: list[str] = []

    scope = {}
    derived = suggested.get("derivedFrom") if isinstance(suggested.get("derivedFrom"), Mapping) else {}
    if isinstance(derived, Mapping):
        scope = derived.get("scope") if isinstance(derived.get("scope"), Mapping) else {}

    modality_expected = str(scope.get("modality") or "").strip().lower()

    spec = experiment_spec_to_dict(experiment_spec)
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}

    modality_current = ""
    if isinstance(outcome_report_payload, Mapping):
        if isinstance(outcome_report_payload.get("primeOutcomes"), list):
            modality_current = "prime"
    if not modality_current:
        intent = str(spec.get("intent") or "").strip().lower()
        modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
        if intent == "prime_edit" or any(str(m).lower() == "prime" for m in modalities):
            modality_current = "prime"
        else:
            if intent:
                modality_current = "cut"
            elif modalities:
                modality_current = "cut"
    if modality_expected:
        if not modality_current:
            reasons_missing.append("missing modality")
        elif modality_expected != modality_current:
            reasons_incompatible.append("modality mismatch")
    elif modality_current:
        reasons_missing.append("missing suggested modality")
    else:
        reasons_missing.append("missing modality")

    current_model_id = str(outcome_report_payload.get("modelId") or "") if isinstance(outcome_report_payload, Mapping) else ""
    current_model_version = str(outcome_report_payload.get("modelVersion") or "") if isinstance(outcome_report_payload, Mapping) else ""

    compatibility = suggested.get("compatibility") if isinstance(suggested.get("compatibility"), list) else []
    compat_entries = [c for c in compatibility if isinstance(c, Mapping)]
    if compat_entries:
        if not current_model_id:
            reasons_missing.append("missing model id")
        else:
            matches = [c for c in compat_entries if str(c.get("modelId") or "") == current_model_id]
            if not matches:
                reasons_incompatible.append("model id mismatch")
            else:
                def _major(v: str) -> str | None:
                    token = "".join(ch if ch.isdigit() else "." for ch in v)
                    parts = [p for p in token.split(".") if p]
                    return parts[0] if parts else None

                expected_versions = [str(m.get("modelVersion") or "") for m in matches]
                if not current_model_version:
                    reasons_missing.append("missing model version")
                else:
                    exp = expected_versions[0] if expected_versions else ""
                    if exp:
                        cur_major = _major(current_model_version)
                        exp_major = _major(exp)
                        if cur_major and exp_major:
                            if cur_major != exp_major:
                                reasons_incompatible.append("model major version mismatch")
                        else:
                            if current_model_version != exp:
                                reasons_incompatible.append("model version mismatch")
                    else:
                        reasons_missing.append("missing model version")
    else:
        reasons_missing.append("missing compatibility list")

    def _check_scope(key: str, label: str) -> None:
        expected = str(scope.get(key) or "").strip()
        current = str(assumptions.get(key) or "").strip()
        if expected:
            if not current:
                reasons_missing.append(f"missing {label}")
            elif current != expected:
                reasons_incompatible.append(f"{label} mismatch")
        else:
            if current:
                reasons_missing.append(f"missing {label} in suggested")

    _check_scope("cellLine", "cellLine")
    _check_scope("delivery", "delivery")
    _check_scope("nuclease", "nuclease")

    if reasons_incompatible:
        return {"status": "incompatible", "reasons": reasons_incompatible}
    if reasons_missing:
        return {"status": "unknown", "reasons": reasons_missing}
    return {"status": "compatible", "reasons": []}


__all__ = [
    "SUGGESTED_PRIORS_SCHEMA_ID",
    "SUGGESTED_PRIORS_CAP",
    "SUGGESTED_PRIORS_HISTORY_CAP",
    "suggested_priors_json_bytes",
    "suggested_priors_sha256",
    "build_suggested_priors",
    "attach_suggested_priors",
    "apply_priors_override",
    "check_suggested_priors_compatibility",
]
