from __future__ import annotations

import hashlib
import re
from concurrent.futures import Future
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol

from PySide6.QtCore import QObject, Signal, Slot
from PySide6.QtWidgets import QLabel, QWidget

from helix.studio.plugins.policy import WebPanelsPolicy

from .ui_dispatcher import ui_post
from .web_panel_csp import build_web_panel_csp
from .web_panel_policy import (
    decide_web_panel_download,
    decide_web_panel_navigation,
    decide_web_panel_popup,
    decide_web_panel_request,
)


class _ExtensionHost(Protocol):
    def is_running(self) -> bool: ...

    def call_async(self, method: str, params: Any) -> Future[Any]: ...

    def cancel(self, request_id: int) -> None: ...


@dataclass(slots=True)
class WebPanelSpec:
    plugin_id: str
    panel_id: str
    title: str
    entry_html: Path
    assets_root: Path
    handler_id: int | None
    policy: WebPanelsPolicy = field(default_factory=WebPanelsPolicy)
    report_violation: Callable[[str], None] | None = None
    report_decision: Callable[[dict[str, Any]], None] | None = None
    profile_storage_root: Path | None = None
    profile_cache_root: Path | None = None


class WebPanelBridge(QObject):
    response = Signal(int, object, object)
    message = Signal(object)

    def __init__(
        self,
        spec: WebPanelSpec,
        *,
        get_extension_host: Callable[[], _ExtensionHost | None],
        rpc_method: str,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._spec = spec
        self._get_extension_host = get_extension_host
        self._rpc_method = (rpc_method or "").strip()
        self._js_to_ext_request: dict[int, int] = {}

    @Slot(int, str, object)
    def call(self, request_id: int, method: str, params: object) -> None:
        js_id = int(request_id)
        call_method = (method or "").strip()
        if not call_method:
            self.response.emit(js_id, None, {"message": "method is required"})
            return

        ext = self._get_extension_host()
        if ext is None or not ext.is_running():
            self.response.emit(
                js_id,
                None,
                {"message": "extension host is not running"},
            )
            return
        if self._spec.handler_id is None:
            self.response.emit(js_id, None, {"message": "panel has no RPC handler"})
            return

        fut = ext.call_async(
            self._rpc_method,
            {
                "handler_id": int(self._spec.handler_id),
                "panel_id": self._spec.panel_id,
                "method": call_method,
                "params": params,
            },
        )
        ext_request_id = getattr(fut, "_ext_request_id", None)
        if isinstance(ext_request_id, int):
            self._js_to_ext_request[js_id] = int(ext_request_id)

        def _done() -> None:
            self._js_to_ext_request.pop(js_id, None)
            try:
                result = fut.result()
            except Exception as exc:
                self.response.emit(js_id, None, {"message": str(exc)})
                return
            if isinstance(result, dict) and "result" in result and len(result) == 1:
                self.response.emit(js_id, result.get("result"), None)
            else:
                self.response.emit(js_id, result, None)

        fut.add_done_callback(lambda _f: ui_post(_done))

    @Slot(int)
    def cancel(self, request_id: int) -> None:
        js_id = int(request_id)
        ext = self._get_extension_host()
        if ext is None or not ext.is_running():
            return
        ext_rid = self._js_to_ext_request.get(js_id)
        if isinstance(ext_rid, int):
            try:
                ext.cancel(int(ext_rid))
            except Exception:
                return

    def deliver_message(self, payload: Any) -> None:
        self.message.emit(payload)


def build_web_panel_widget(
    spec: WebPanelSpec,
    *,
    get_extension_host: Callable[[], _ExtensionHost | None],
    rpc_method: str,
    parent: QWidget | None = None,
) -> tuple[QWidget, WebPanelBridge | None]:
    try:
        from PySide6.QtCore import QUrl
        from PySide6.QtWebChannel import QWebChannel
        from PySide6.QtWebEngineCore import (
            QWebEnginePage,
            QWebEngineProfile,
            QWebEngineUrlRequestInfo,
            QWebEngineUrlRequestInterceptor,
        )
        from PySide6.QtWebEngineWidgets import QWebEngineView
    except Exception as exc:
        label = QLabel(f"Web panel unavailable: {exc}", parent)
        label.setWordWrap(True)
        return label, None

    entry = spec.entry_html
    assets_root = spec.assets_root
    try:
        entry_resolved = entry.resolve()
        assets_resolved = assets_root.resolve()
    except Exception:
        entry_resolved = entry
        assets_resolved = assets_root

    def _safe_segment(value: str) -> str:
        raw = (value or "").strip()
        if not raw:
            return "x"
        s = re.sub(r"[^a-zA-Z0-9_.-]+", "_", raw).strip("._-")
        return s or "x"

    def _profile_storage_name() -> str:
        raw = f"{spec.plugin_id}:{spec.panel_id}"
        prefix = f"{_safe_segment(spec.plugin_id)}.{_safe_segment(spec.panel_id)}"
        prefix = prefix[:80]
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12]
        return f"helix.web_panel.{prefix}.{digest}"

    def _panel_storage_paths(name: str) -> tuple[Path, Path]:
        pid = _safe_segment(spec.plugin_id).lower()
        safe_name = _safe_segment(name)
        data_root = spec.profile_storage_root
        cache_root = spec.profile_cache_root
        if data_root is None or cache_root is None:
            try:
                from PySide6.QtCore import QStandardPaths

                data_base = QStandardPaths.writableLocation(
                    QStandardPaths.AppDataLocation
                )
                cache_base = QStandardPaths.writableLocation(
                    QStandardPaths.CacheLocation
                )
            except Exception:
                data_base = ""
                cache_base = ""
            if data_root is None:
                data_root = (
                    Path(data_base)
                    if data_base
                    else (Path.home() / ".helix" / "studio")
                )
            if cache_root is None:
                cache_root = (
                    Path(cache_base)
                    if cache_base
                    else (Path.home() / ".helix" / "studio" / "cache")
                )
        storage_dir = data_root / "plugins" / pid / "data" / "web_panels" / safe_name
        cache_dir = cache_root / "plugins" / pid / "web_panels" / safe_name
        try:
            storage_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        try:
            cache_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        return storage_dir, cache_dir

    def _emit_decision(payload: dict[str, Any]) -> None:
        cb = spec.report_decision
        if cb is None:
            return
        try:
            cb(payload)
        except Exception:
            return

    class _StaticAssetsOnlyInterceptor(QWebEngineUrlRequestInterceptor):
        def interceptRequest(self, info) -> None:  # type: ignore[override]
            try:
                url = info.requestUrl()
            except Exception:
                return
            try:
                resource_type = info.resourceType()
                resource_name = getattr(resource_type, "name", "unknown")
            except Exception:
                resource_type = None
                resource_name = "unknown"
            try:
                is_nav = resource_type in {
                    QWebEngineUrlRequestInfo.ResourceType.ResourceTypeMainFrame,
                    QWebEngineUrlRequestInfo.ResourceType.ResourceTypeSubFrame,
                    QWebEngineUrlRequestInfo.ResourceType.ResourceTypeNavigationPreloadMainFrame,
                    QWebEngineUrlRequestInfo.ResourceType.ResourceTypeNavigationPreloadSubFrame,
                }
            except Exception:
                is_nav = False
            try:
                is_main = bool(info.isMainFrame())
            except Exception:
                is_main = False
            decision = decide_web_panel_request(
                url.toString(),
                assets_root=assets_resolved,
                policy=spec.policy,
                is_main_frame=bool(is_nav or is_main),
            )
            _emit_decision(
                {
                    "kind": "request",
                    "url": url.toString(),
                    "resource_type": resource_name,
                    "is_main_frame": bool(is_nav or is_main),
                    "allowed": bool(decision.allowed),
                    "reason": str(decision.reason or ""),
                }
            )
            if decision.allowed:
                return
            info.block(True)
            if spec.report_violation is not None:
                try:
                    spec.report_violation(
                        f"blocked request ({resource_name}): {decision.reason} "
                        f"({url.toString()})"
                    )
                except Exception:
                    pass

    view = QWebEngineView(parent)
    profile: QWebEngineProfile
    storage_name = _profile_storage_name()
    if spec.policy.allow_persistent_storage:
        profile = QWebEngineProfile(storage_name, view)
        storage_dir, cache_dir = _panel_storage_paths(storage_name)
        try:
            profile.setPersistentStoragePath(str(storage_dir))
        except Exception:
            pass
        try:
            profile.setCachePath(str(cache_dir))
        except Exception:
            pass
        try:
            profile.setHttpCacheType(QWebEngineProfile.DiskHttpCache)
        except Exception:
            pass
    else:
        profile = QWebEngineProfile(view)
        try:
            profile.setHttpCacheType(QWebEngineProfile.MemoryHttpCache)
        except Exception:
            pass
        if spec.profile_storage_root is not None or spec.profile_cache_root is not None:
            storage_dir, cache_dir = _panel_storage_paths(storage_name)
            try:
                profile.setPersistentStoragePath(str(storage_dir))
            except Exception:
                pass
            try:
                profile.setCachePath(str(cache_dir))
            except Exception:
                pass

    try:
        profile.setPersistentPermissionsPolicy(QWebEngineProfile.StoreInMemory)
    except Exception:
        pass

    try:
        if spec.policy.allow_persistent_storage and spec.policy.allow_cookies:
            profile.setPersistentCookiesPolicy(QWebEngineProfile.ForcePersistentCookies)
        else:
            profile.setPersistentCookiesPolicy(QWebEngineProfile.NoPersistentCookies)
    except Exception:
        pass
    if not spec.policy.allow_cookies:
        try:
            store = profile.cookieStore()
            try:
                store.deleteAllCookies()
            except Exception:
                pass

            def _deny(_req) -> bool:
                return False

            store.setCookieFilter(_deny)
        except Exception:
            pass
    interceptor = _StaticAssetsOnlyInterceptor(view)
    try:
        profile.setUrlRequestInterceptor(interceptor)
    except Exception:
        pass

    def _on_download(item) -> None:
        try:
            url = item.url().toString()  # type: ignore[attr-defined]
        except Exception:
            url = ""
        decision = decide_web_panel_download(
            url,
            assets_root=assets_resolved,
            policy=spec.policy,
        )
        _emit_decision(
            {
                "kind": "download",
                "url": url,
                "allowed": bool(decision.allowed),
                "reason": str(decision.reason or ""),
            }
        )
        if decision.allowed:
            try:
                item.accept()  # type: ignore[attr-defined]
            except Exception:
                pass
            return
        try:
            item.cancel()  # type: ignore[attr-defined]
        except Exception:
            pass
        if spec.report_violation is not None:
            try:
                spec.report_violation(f"blocked download: {decision.reason} ({url})")
            except Exception:
                pass

    try:
        profile.downloadRequested.connect(_on_download)  # type: ignore[attr-defined]
    except Exception:
        pass

    class _PolicyPage(QWebEnginePage):
        def acceptNavigationRequest(self, url, nav_type, isMainFrame):  # type: ignore[override]
            # Treat *all* frame navigations (main + subframes) as navigations for
            # policy purposes. Subresources are handled by the request interceptor.
            decision = decide_web_panel_navigation(
                url.toString(),
                assets_root=assets_resolved,
                policy=spec.policy,
            )
            _emit_decision(
                {
                    "kind": "navigation",
                    "url": url.toString(),
                    "is_main_frame": bool(isMainFrame),
                    "allowed": bool(decision.allowed),
                    "reason": str(decision.reason or ""),
                }
            )
            if decision.allowed:
                # Make the Helix policy authoritative; avoid relying on Qt
                # defaults which can vary across WebEngine builds.
                return True
            if spec.report_violation is not None:
                try:
                    spec.report_violation(
                        f"blocked navigation: {decision.reason} ({url.toString()})"
                    )
                except Exception:
                    pass
            return False

        def createWindow(self, windowType):  # type: ignore[override]
            decision = decide_web_panel_popup(policy=spec.policy)
            _emit_decision(
                {
                    "kind": "popup",
                    "allowed": bool(decision.allowed),
                    "reason": str(decision.reason or ""),
                }
            )
            if decision.allowed:
                return super().createWindow(windowType)
            if spec.report_violation is not None:
                try:
                    spec.report_violation(f"blocked popup: {decision.reason}")
                except Exception:
                    pass
            return None

    page = _PolicyPage(profile, view)
    try:
        from PySide6.QtWebEngineCore import QWebEngineSettings

        settings = page.settings()
        view_settings = view.settings()
        try:
            settings.setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls,
                True,
            )
        except Exception:
            pass
        try:
            view_settings.setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls,
                True,
            )
        except Exception:
            pass
        try:
            net_mode = (spec.policy.network.mode or "").strip().lower()
            allow_remote = net_mode not in {"none", "deny"}
            settings.setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls,
                bool(allow_remote),
            )
        except Exception:
            pass
        try:
            net_mode = (spec.policy.network.mode or "").strip().lower()
            allow_remote = net_mode not in {"none", "deny"}
            view_settings.setAttribute(
                QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls,
                bool(allow_remote),
            )
        except Exception:
            pass
    except Exception:
        pass
    try:
        # Defense-in-depth: block javascript: URL execution (which can bypass
        # acceptNavigationRequest on some QtWebEngine builds).
        from PySide6.QtWebEngineCore import QWebEngineScript

        guard_js = (
            "(function(){try{"
            "var re=/^\\s*javascript:/i;"
            "function isJsUrl(u){try{return re.test(String(u||''));}"
            "catch(e){return false;}}"
            "document.addEventListener('click',function(e){try{"
            "var el=e.target;"
            "while(el){"
            "if(el.tagName&&String(el.tagName).toLowerCase()==='a'){"
            "var href=el.getAttribute('href')||'';"
            "if(isJsUrl(href)){e.preventDefault();e.stopImmediatePropagation();"
            "return false;}"
            "break;"
            "}"
            "el=el.parentElement;"
            "}"
            "}catch(_){}} ,true);"
            "try{"
            "var _set=Element.prototype.setAttribute;"
            "Element.prototype.setAttribute=function(name,value){"
            "try{"
            "var n=String(name||'').toLowerCase();"
            "if(n==='href'&&this&&this.tagName&&String(this.tagName).toLowerCase()==='a'&&isJsUrl(value)){return;}"
            "if(n==='src'&&this&&this.tagName&&String(this.tagName).toLowerCase()==='iframe'&&isJsUrl(value)){return;}"
            "}catch(__){ }"
            "return _set.call(this,name,value);"
            "};"
            "}catch(_){ }"
            "try{"
            "var aDesc=Object.getOwnPropertyDescriptor(HTMLAnchorElement.prototype,"
            "'href');"
            "if(aDesc&&aDesc.set){Object.defineProperty(HTMLAnchorElement.prototype,"
            "'href',{get:aDesc.get,set:function(v){if(isJsUrl(v)){return;}return "
            "aDesc.set.call(this,v);}});}"
            "}catch(_){ }"
            "try{"
            "var fDesc=Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype,"
            "'src');"
            "if(fDesc&&fDesc.set){Object.defineProperty(HTMLIFrameElement.prototype,"
            "'src',{get:fDesc.get,set:function(v){if(isJsUrl(v)){return;}return "
            "fDesc.set.call(this,v);}});}"
            "}catch(_){ }"
            "try{"
            "var loc=window.location;"
            "if(loc&&typeof loc.assign==='function'){var _a=loc.assign.bind(loc);"
            "loc.assign=function(u){if(isJsUrl(u)){return;}return _a(u);};}"
            "}catch(_){ }"
            "try{"
            "var loc2=window.location;"
            "if(loc2&&typeof loc2.replace==='function'){var _r=loc2.replace.bind(loc2);"
            "loc2.replace=function(u){if(isJsUrl(u)){return;}return _r(u);};}"
            "}catch(_){ }"
            "}catch(e){}})();"
        )
        guard = QWebEngineScript()
        guard.setName("helix.web_panel.guard")
        guard.setInjectionPoint(QWebEngineScript.DocumentCreation)
        guard.setWorldId(QWebEngineScript.MainWorld)
        guard.setRunsOnSubFrames(True)
        guard.setSourceCode(guard_js)
        try:
            page.scripts().insert(guard)
        except Exception:
            pass
    except Exception:
        pass
    if spec.policy.csp_enabled:
        try:
            import json

            from PySide6.QtWebEngineCore import QWebEngineScript

            csp = build_web_panel_csp(spec.policy)
            js = (
                "(function(){try{"
                "var m=document.createElement('meta');"
                "m.httpEquiv='Content-Security-Policy';"
                f"m.content={json.dumps(csp)};"
                "(document.head||document.documentElement).appendChild(m);"
                "}catch(e){}})();"
            )
            script = QWebEngineScript()
            script.setName("helix.web_panel.csp")
            script.setInjectionPoint(QWebEngineScript.DocumentCreation)
            script.setWorldId(QWebEngineScript.MainWorld)
            script.setRunsOnSubFrames(True)
            script.setSourceCode(js)
            try:
                page.scripts().insert(script)
            except Exception:
                pass
        except Exception:
            pass
    view.setPage(page)

    channel = QWebChannel(view)
    bridge = WebPanelBridge(
        spec,
        get_extension_host=get_extension_host,
        rpc_method=rpc_method,
        parent=view,
    )
    channel.registerObject("HelixWebPanel", bridge)
    try:
        view.page().setWebChannel(channel)
    except Exception:
        pass

    # Ensure objects stay alive (PySide ownership edge cases).
    view._helix_web_channel = channel  # type: ignore[attr-defined]
    view._helix_web_bridge = bridge  # type: ignore[attr-defined]
    view._helix_web_request_interceptor = interceptor  # type: ignore[attr-defined]

    view.load(QUrl.fromLocalFile(str(entry_resolved)))
    return view, bridge


__all__ = ["WebPanelBridge", "WebPanelSpec", "build_web_panel_widget"]
