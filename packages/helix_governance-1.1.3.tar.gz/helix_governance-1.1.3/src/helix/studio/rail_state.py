from __future__ import annotations

from dataclasses import replace
from typing import Any, Callable

from PySide6.QtCore import QObject, Signal

from helix import clock
from .rail_model import (
    CacheState,
    RailGraph,
    RailSelection,
    RailSegment,
    RecomputeResult,
    StageKind,
    build_graph_from_session,
)


class RailStateStore(QObject):
    """Central rail state (graph + selection + cache status + recompute bookkeeping)."""

    selectionChanged = Signal(object)  # RailSelection | None
    graphChanged = Signal(object)  # RailGraph
    segmentStatusChanged = Signal(str, object)  # segment_id, CacheState
    recomputeRequested = Signal(str)  # segment_id
    recomputeDownstreamRequested = Signal(str)  # segment_id
    recomputeResultChanged = Signal(str, object)  # segment_id, RecomputeResult
    recomputeRejected = Signal(str, str)  # segment_id, reason
    chainProgressChanged = Signal(str, int, int, str)  # chain_id, index, total, stage
    staleResultDropped = Signal(str, str)  # segment_id, reason

    def __init__(self, session: Any | None = None, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._graph: RailGraph | None = None
        self._selection: RailSelection | None = None
        self._inflight: dict[str, str] = {}
        self._chain: dict[str, str | None] = {}
        self._started_at: dict[str, float] = {}
        self._expected_upstream: dict[str, str | None] = {}
        self._last_reason: dict[str, str | None] = {}
        if session is not None:
            try:
                session.stateChanged.connect(self._on_session_state_changed)
                self._graph = build_graph_from_session(session.state)
            except Exception:
                pass

    # --- public API -------------------------------------------------

    @property
    def graph(self) -> RailGraph | None:
        return self._graph

    @property
    def selection(self) -> RailSelection | None:
        return self._selection

    def set_graph(self, graph: RailGraph) -> None:
        if graph is None or graph == self._graph:
            return
        self._graph = graph
        self.graphChanged.emit(graph)

    def set_selection(self, selection: RailSelection | None) -> None:
        if selection == self._selection:
            return
        self._selection = selection
        self.selectionChanged.emit(selection)

    def mark_segment_state(self, segment_id: str, cache_state: CacheState) -> None:
        self._update_segment(segment_id, cache_state=cache_state)
        self.segmentStatusChanged.emit(segment_id, cache_state)

    def request_recompute_from(self, segment_id: str) -> None:
        self.recomputeRequested.emit(segment_id)
    def request_recompute_downstream(self, segment_id: str) -> None:
        self.recomputeDownstreamRequested.emit(segment_id)

    # --- recompute state machine -----------------------------------

    def begin_compute(
        self,
        segment_id: str,
        inflight_id: str,
        *,
        chain_id: str | None = None,
        expected_upstream_hash: str | None = None,
    ) -> bool:
        if segment_id in self._inflight:
            self.recomputeRejected.emit(segment_id, "already_computing")
            return False
        self._inflight[segment_id] = inflight_id
        self._chain[segment_id] = chain_id
        self._started_at[segment_id] = clock.unix_time_s()
        self._expected_upstream[segment_id] = expected_upstream_hash
        self._last_reason[segment_id] = None
        self._update_segment(
            segment_id,
            cache_state=CacheState.COMPUTING,
            last_recompute_result=None,
            last_compute_ts=clock.unix_time_s(),
        )
        return True

    def end_compute(
        self,
        segment_id: str,
        inflight_id: str,
        *,
        new_hash: str | None,
        current_upstream_hash: str | None = None,
        chain_id: str | None = None,
    ) -> None:
        if self._inflight.get(segment_id) != inflight_id:
            return
        expected_chain = self._chain.get(segment_id)
        if chain_id is not None and expected_chain not in {None, chain_id}:
            self._mark_stale(segment_id, inflight_id, reason="chain_mismatch")
            return
        expected_up = self._expected_upstream.get(segment_id)
        if expected_up is not None and current_upstream_hash is not None and expected_up != current_upstream_hash:
            self._mark_stale(segment_id, inflight_id, reason="upstream_changed")
            return
        prev_hash = self._segment_hash(segment_id)
        result = RecomputeResult.CACHE_HIT if prev_hash and new_hash == prev_hash else RecomputeResult.CHANGED
        duration_ms = self._compute_duration_ms(segment_id)
        self._update_segment(
            segment_id,
            cache_state=CacheState.CLEAN,
            last_recompute_result=result,
            output_hash=new_hash,
            last_compute_ts=clock.unix_time_s(),
            duration_ms=duration_ms,
            last_success_duration_ms=duration_ms,
            last_success_ts=clock.unix_time_s(),
            last_result_reason=None,
        )
        self._teardown(segment_id)
        self.recomputeResultChanged.emit(segment_id, result)

    def fail_compute(self, segment_id: str, inflight_id: str) -> None:
        if self._inflight.get(segment_id) != inflight_id:
            return
        duration_ms = self._compute_duration_ms(segment_id)
        self._update_segment(
            segment_id,
            cache_state=CacheState.ERROR,
            last_recompute_result=RecomputeResult.FAILED,
            last_compute_ts=clock.unix_time_s(),
            duration_ms=duration_ms,
            last_result_reason=None,
        )
        self._teardown(segment_id)
        self.recomputeResultChanged.emit(segment_id, RecomputeResult.FAILED)

    # --- helpers ----------------------------------------------------

    def _on_session_state_changed(self, state: Any) -> None:
        try:
            graph = build_graph_from_session(state)
        except Exception:
            return
        self.set_graph(graph)

    def _update_segment(
        self,
        segment_id: str,
        *,
        cache_state: CacheState | None = None,
        last_recompute_result: RecomputeResult | None = None,
        output_hash: str | None = None,
        last_compute_ts: float | None = None,
        duration_ms: float | None = None,
        last_success_duration_ms: float | None = None,
        last_success_ts: float | None = None,
        last_result_reason: str | None = None,
    ) -> None:
        graph = self._graph
        if graph is None:
            return
        segment = graph.get(segment_id)
        if segment is None:
            return
        # Enforce invariant: claims dirty implies evidence dirty.
        if cache_state is CacheState.DIRTY and segment.kind is StageKind.CLAIMS:
            ev = graph.get("evidence")
            if ev is not None and ev.cache_state is CacheState.CLEAN:
                ev_updated = replace(ev, cache_state=CacheState.DIRTY)
                graph = graph.replace_segment(ev_updated)
                self._graph = graph
                self.segmentStatusChanged.emit(ev.segment_id, CacheState.DIRTY)
        updated = segment
        if cache_state is not None:
            updated = replace(updated, cache_state=cache_state)
        if last_recompute_result is not None:
            updated = replace(updated, last_recompute_result=last_recompute_result)
        if output_hash is not None:
            updated = replace(updated, output_hash=output_hash)
        if last_compute_ts is not None:
            updated = replace(updated, last_compute_ts=last_compute_ts)
        if duration_ms is not None:
            updated = replace(updated, duration_ms=duration_ms)
        if last_success_duration_ms is not None:
            updated = replace(updated, last_success_duration_ms=last_success_duration_ms)
        if last_success_ts is not None:
            updated = replace(updated, last_success_ts=last_success_ts)
        if last_result_reason is not None:
            updated = replace(updated, last_result_reason=last_result_reason)
        self._graph = graph.replace_segment(updated)
        self.graphChanged.emit(self._graph)
        if cache_state is not None:
            self.segmentStatusChanged.emit(segment_id, cache_state)
        # Emit progress updates for any active chain (UI hooks can ignore if not needed).
        chain_id = self._chain.get(segment_id)
        if cache_state is CacheState.COMPUTING and chain_id:
            # Index/total handled by caller via chainProgressChanged; no-op here.
            pass

    def _compute_duration_ms(self, segment_id: str) -> float | None:
        start = self._started_at.get(segment_id)
        if start is None:
            return None
        return max(0.0, (clock.unix_time_s() - start) * 1000.0)

    def _mark_stale(self, segment_id: str, inflight_id: str, *, reason: str) -> None:
        self._update_segment(
            segment_id,
            cache_state=CacheState.DIRTY,
            last_recompute_result=RecomputeResult.DROPPED_STALE,
            last_compute_ts=clock.unix_time_s(),
            duration_ms=self._compute_duration_ms(segment_id),
            last_result_reason=reason,
        )
        self._teardown(segment_id)
        self.staleResultDropped.emit(segment_id, reason)
        self.recomputeResultChanged.emit(segment_id, RecomputeResult.DROPPED_STALE)

    def _segment_hash(self, segment_id: str) -> str | None:
        graph = self._graph
        if graph is None:
            return None
        seg = graph.get(segment_id)
        return seg.output_hash if seg else None

    def chain_id_for(self, segment_id: str) -> str | None:
        return self._chain.get(segment_id)

    def drop_stale(self, segment_id: str, inflight_id: str, *, reason: str) -> None:
        if self._inflight.get(segment_id) != inflight_id:
            return
        self._mark_stale(segment_id, inflight_id, reason=reason)

    def _teardown(self, segment_id: str) -> None:
        self._inflight.pop(segment_id, None)
        self._started_at.pop(segment_id, None)
        self._chain.pop(segment_id, None)
        self._expected_upstream.pop(segment_id, None)
        self._last_reason.pop(segment_id, None)


def with_selection(store: RailStateStore, *, branch_id: str = "trunk", segment_id: str) -> Callable[[], None]:
    """Convenience helper to produce a click handler that updates selection."""

    def _handler() -> None:
        store.set_selection(RailSelection(branch_id=branch_id, segment_id=segment_id))

    return _handler
