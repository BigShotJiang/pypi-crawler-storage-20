from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from helix.studio.plugins.policy import NetworkPolicy, WebPanelsPolicy


@dataclass(frozen=True, slots=True)
class WebPanelDecision:
    allowed: bool
    reason: str = ""


def _host_matches(pattern: str, host: str) -> bool:
    p = (pattern or "").strip().lower().lstrip(".")
    h = (host or "").strip().lower()
    if not p or not h:
        return False
    if h == p:
        return True
    return h.endswith(f".{p}")


def _network_allows(
    policy: NetworkPolicy,
    *,
    scheme: str,
    host: str,
) -> WebPanelDecision:
    mode = (policy.mode or "").strip().lower()
    s = (scheme or "").strip().lower()
    h = (host or "").strip().lower()

    if s in {"ws", "wss"} and not policy.allow_websocket:
        return WebPanelDecision(False, "websocket blocked by policy")
    if s == "http" and not policy.allow_insecure_http:
        return WebPanelDecision(False, "insecure http blocked by policy")

    if mode in {"full", "all", "any"}:
        return WebPanelDecision(True, "")
    if mode in {"none", "deny"}:
        return WebPanelDecision(False, "network blocked by policy")

    allow = tuple(x for x in policy.allow if isinstance(x, str) and x.strip())
    for pat in allow:
        if _host_matches(pat, h):
            return WebPanelDecision(True, "")
    return WebPanelDecision(False, f"host not in allowlist: {h}")


def _file_allowed(*, local_path: Path, assets_root: Path) -> bool:
    try:
        p = local_path.resolve()
        root = assets_root.resolve()
    except Exception:
        p = local_path
        root = assets_root
    try:
        return p.is_relative_to(root)
    except Exception:
        try:
            p.relative_to(root)
            return True
        except Exception:
            return False


def decide_web_panel_request(
    url: str,
    *,
    assets_root: Path,
    policy: WebPanelsPolicy,
    is_main_frame: bool,
) -> WebPanelDecision:
    raw = (url or "").strip()
    if not raw:
        return WebPanelDecision(False, "empty url")

    # Treat these as internal; they don't represent external IO.
    lower = raw.lower()
    if lower.startswith("data:"):
        # Allow data: for subresources (e.g., inline images), but deny
        # navigation to data: documents by default.
        if is_main_frame:
            return WebPanelDecision(False, "data url navigation blocked by policy")
        return WebPanelDecision(True, "")
    if lower.startswith("about:") or lower.startswith("qrc:"):
        return WebPanelDecision(True, "")

    try:
        from urllib.parse import unquote, urlparse

        parsed = urlparse(raw)
    except Exception:
        return WebPanelDecision(False, "invalid url")

    scheme = (parsed.scheme or "").strip().lower()
    host = (parsed.hostname or "").strip().lower()

    if scheme == "" and raw.startswith("/"):
        # Likely a relative file request interpreted as path.
        scheme = "file"
        host = ""

    if scheme == "file":
        path_str = unquote(parsed.path or "")
        if not path_str:
            return WebPanelDecision(False, "invalid file url")
        try:
            from urllib.request import url2pathname

            local = Path(url2pathname(path_str))
        except Exception:
            local = Path(path_str)
        if _file_allowed(local_path=local, assets_root=assets_root):
            return WebPanelDecision(True, "")
        return WebPanelDecision(False, "file outside plugin assets root")

    if scheme in {"http", "https", "ws", "wss"}:
        if is_main_frame and not policy.allow_external_navigation:
            return WebPanelDecision(False, "external navigation blocked by policy")
        return _network_allows(policy.network, scheme=scheme, host=host)

    if scheme in {"", "qrc", "data", "about"}:
        return WebPanelDecision(True, "")

    return WebPanelDecision(False, f"scheme blocked: {scheme}")


def decide_web_panel_navigation(
    url: str,
    *,
    assets_root: Path,
    policy: WebPanelsPolicy,
) -> WebPanelDecision:
    return decide_web_panel_request(
        url,
        assets_root=assets_root,
        policy=policy,
        is_main_frame=True,
    )


def decide_web_panel_popup(
    *_args: Any,
    policy: WebPanelsPolicy,
) -> WebPanelDecision:
    if policy.allow_popups:
        return WebPanelDecision(True, "")
    return WebPanelDecision(False, "popups blocked by policy")


def decide_web_panel_download(
    url: str,
    *,
    assets_root: Path,
    policy: WebPanelsPolicy,
) -> WebPanelDecision:
    if not policy.allow_downloads:
        return WebPanelDecision(False, "downloads blocked by policy")
    return decide_web_panel_request(
        url,
        assets_root=assets_root,
        policy=policy,
        is_main_frame=False,
    )


__all__ = [
    "WebPanelDecision",
    "decide_web_panel_download",
    "decide_web_panel_navigation",
    "decide_web_panel_popup",
    "decide_web_panel_request",
]
